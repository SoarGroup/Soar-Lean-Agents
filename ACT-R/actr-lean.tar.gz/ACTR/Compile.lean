import ACTR.PM
/-!
# ACT-R 7 in Lean — production compilation

Production compilation ([RM] "Production Compilation"; [Src] modules/production-compilation.lisp
and the compilation types in tools/goal-compilation.lisp, imaginal-compilation.lisp,
retrieval-compilation.lisp, perceptual-compilation.lisp, motor-compilation.lisp): when `:epl`
is set, each production that fires is composed with the production that fired just before
it, if both are valid for compilation and their uses of every buffer allow it. The new
production does in one step what the two did in two; a retrieval made by the first and
harvested by the second is replaced by the retrieved chunk's values.

The functions follow the Lisp closely, including the order of lists, because the order of
a compiled production's conditions and actions decides the order of its events in the trace.
SBCL's list functions are reproduced where the order matters: `union` gives the missing
elements of the longer list in reverse order followed by the shorter list, `intersection` the elements of the first list in reverse order,
`remove-duplicates` keeps last occurrences, `sort` and `stable-sort` on lists are stable.

NOT MODELED: dynamic slot names (models that use them are rejected by the parser),
`:ppm` (partial matching in compilation), `:cia` and `:rir` (indirect actions), the `:pct`
trace itself (the harness drops it) and LHS `!safe-bind!` (rejected by the parser).
-/

namespace ACTR

/-! ## The representation of productions used by compilation -/

/-- A value in a slot specification: a variable (stored without `=`) or a constant
(`none` is `nil`). -/
inductive CV where
  | var (x : String)
  | const (v : Option Val)
  deriving Inhabited, Repr

def CV.ofTerm : Option Term → CV
  | some (.var x) => .var x
  | some (.const v) => .const (some v)
  | none => .const none

def CV.toTerm : CV → Option Term
  | .var x => some (.var x)
  | .const (some v) => some (.const v)
  | .const none => none

/-- Lisp's `eq` on values (fixnums are `eq`, floats and strings are not). -/
def CV.eq : CV → CV → Bool
  | .var a, .var b => a == b
  | .const none, .const none => true
  | .const (some (.sym a)), .const (some (.sym b)) => a == b
  | .const (some a@(.num x _)), .const (some b@(.num y _)) => a.isInt && b.isInt && x == y
  | _, _ => false

/-- How a value prints with `~s`. -/
def CV.str : CV → String
  | .var x => "=" ++ x
  | .const none => "NIL"
  | .const (some v) => v.repr

/-- `equalp` normal form: numbers by value, strings ignoring case. -/
def CV.strP : CV → String
  | .const (some (.num x _)) => toString x
  | .const (some (.str s)) => "\"" ++ s.toUpper ++ "\""
  | v => v.str

/-- A slot specification `(op slot value)`. -/
structure SS where
  op : Cmp
  slot : String
  val : CV
  deriving Inhabited, Repr

def Cmp.str : Cmp → String
  | .eq => "=" | .ne => "-" | .lt => "<" | .gt => ">" | .le => "<=" | .ge => ">="

def Cmp.rank : Cmp → Nat
  | .eq => 0 | .ne => 1 | .lt => 2 | .gt => 3 | .le => 4 | .ge => 5

def SS.str (s : SS) : String := "(" ++ s.op.str ++ " " ++ s.slot ++ " " ++ s.val.str ++ ")"
def SS.strP (s : SS) : String := "(" ++ s.op.str ++ " " ++ s.slot ++ " " ++ s.val.strP ++ ")"

partial def Expr.str : Expr → String
  | .lit none => "NIL"
  | .lit (some v) => v.repr
  | .var x => "=" ++ x
  | .app f as => "(" ++ " ".intercalate (f :: as.map Expr.str) ++ ")"
  | .cmd n as => "(\"" ++ n ++ "\"" ++ String.join (as.map (" " ++ ·.str)) ++ ")"

/-- The tokens of an expression as `~s` prints it, with its variables. -/
partial def Expr.toks : Expr → List PTok
  | .lit none => [.lit "NIL"]
  | .lit (some v) => [.lit v.repr]
  | .var x => [.var x]
  | .app f as => [.lit ("(" ++ f)] ++ as.flatMap (fun a => .lit " " :: a.toks) ++ [.lit ")"]
  | .cmd n as => [.lit ("(\"" ++ n ++ "\"")] ++ as.flatMap (fun a => .lit " " :: a.toks) ++ [.lit ")"]

/-- What a statement holds. -/
inductive Body where
  | slots (ss : List SS)
  /-- `!safe-eval!` -/
  | expr (e : Expr)
  /-- `!safe-bind!` -/
  | bind (x : String) (e : Expr)
  /-- `!output!` -/
  | output (ts : List CV)
  /-- `!stop!` -/
  | stop
  deriving Inhabited, Repr

/-- A statement of the compilation representation ([Src] `produce-composition-representation`):
operator (`=`, `?`, `+`, `*`, `-` or `!`), the buffer or the `!…!` operator's name, and the
slots or the operator's arguments. -/
structure Stm where
  op : Char
  name : String
  body : Body
  deriving Inhabited, Repr

def Stm.slots (s : Stm) : List SS := match s.body with | .slots ss => ss | _ => []

/-- `compose-rep-token`: `=GOAL>`, `?RETRIEVAL>`, `!SAFE-EVAL!`. -/
def Stm.token (s : Stm) : String :=
  if s.op == '!' then "!" ++ s.name ++ "!" else s.op.toString ++ s.name ++ ">"

/-- The statement's third element as `~s` prints it. -/
def Stm.defStr (s : Stm) : String := match s.body with
  | .slots ss => "(" ++ " ".intercalate (ss.map SS.str) ++ ")"
  | .expr e => "(" ++ e.str ++ ")"
  | .bind x e => "(=" ++ x ++ " " ++ e.str ++ ")"
  | .output ts => "(" ++ " ".intercalate (ts.map CV.str) ++ ")"
  | .stop => "NIL"

/-- The whole statement as printed, used for `equal`. -/
def Stm.str (s : Stm) : String := s.token ++ " " ++ s.defStr

def Stm.strP (s : Stm) : String := match s.body with
  | .slots ss => s.token ++ " (" ++ " ".intercalate (ss.map SS.strP) ++ ")"
  | _ => s.str

/-- A stable sort with a strict order, as CL's `stable-sort` (an element moves before an
earlier one only when strictly less). -/
def ssort {α : Type} (lt : α → α → Bool) (xs : List α) : List α :=
  xs.mergeSort (fun a b => !lt b a)

/-- SBCL's `remove-duplicates`: the last of equal elements is kept. -/
def removeDupsLast {α : Type} (eq : α → α → Bool) : List α → List α
  | [] => []
  | x :: xs => if xs.any (eq x) then removeDupsLast eq xs else x :: removeDupsLast eq xs

/-- SBCL's `union` (for short lists): the elements of the longer list (the first when the
lengths are equal) missing from the other, in reverse order, then the other list. -/
def lunion (l1 l2 : List String) : List String :=
  if l1.length < l2.length then (l2.filter (!l1.contains ·)).reverse ++ l1
  else (l1.filter (!l2.contains ·)).reverse ++ l2

/-- SBCL's `intersection`. -/
def linter {α : Type} [BEq α] (l1 l2 : List α) : List α :=
  (l1.filter (l2.contains ·)).reverse

/-- A symbol's name: a keyword's without its colon. -/
def symName (s : String) : String := if s.startsWith ":" then (s.drop 1).toString else s

/-- `sort-production-slots`. -/
def slotLt (a b : SS) : Bool :=
  if a.op == b.op then
    if a.slot == b.slot then
      let kind : CV → Nat := fun v => match v with
        | .var _ | .const none | .const (some (.sym _)) => 0
        | .const (some (.str _)) => 1
        | .const (some (.num _ _)) => 2
      match kind a.val, kind b.val, a.val, b.val with
      | 0, 0, va, vb => va.str < vb.str
      | 0, _, _, _ => true
      | 1, 0, _, _ => false
      | 1, 1, .const (some (.str x)), .const (some (.str y)) => x < y
      | 1, _, _, _ => true
      | 2, 2, .const (some (.num x _)), .const (some (.num y _)) => x < y
      | _, _, _, _ => false
    -- `string<` of the slot symbols: a keyword's name has no colon
    else symName a.slot < symName b.slot
  else a.op.rank < b.op.rank

def opRank (c : Char) : Nat :=
  match c with | '!' => 0 | '=' => 1 | '?' => 2 | '+' => 3 | '*' => 4 | '-' => 5 | _ => 6

/-- `sort-production-ops`. -/
def stmLt (a b : Stm) : Bool :=
  if a.op == b.op then
    if a.name < b.name then true
    else if a.name == b.name then
      if a.op == '!' then false
      else if a.slots.length == b.slots.length then a.defStr < b.defStr else false
    else false
  else opRank a.op < opRank b.op

/-- A production in the compilation representation: conditions and actions. -/
structure Rep where
  lhs : List Stm
  rhs : List Stm
  deriving Inhabited

def qtestSS (q : QTest) : SS :=
  ⟨if q.neg then .ne else .eq, q.slot, if q.val == "NIL" then .const none else .const (some (.sym q.val))⟩

def tsSS (ts : List SlotTest) : List SS := ts.map fun t => ⟨t.cmp, t.slot, CV.ofTerm t.arg⟩

/-- `produce-composition-representation`: the conditions (with the implicit `state free`
queries [Src] `p-fct` adds) and actions, each stable-sorted with `sort-production-ops` and
their slots with `sort-production-slots`. -/
def compRep (pp : ProcParams) (p : Production) : Rep :=
  let srt := fun (ss : List SS) => ssort slotLt ss
  let lhs := (p.allConds pp).map fun c => match c with
    | .buf b ts => ⟨'=', b.name, .slots (srt (tsSS ts))⟩
    | .query b qs => ⟨'?', b.name, .slots (srt (qs.map qtestSS))⟩
    | .eval e => ⟨'!', "SAFE-EVAL", .expr e⟩
  let rhs := p.rhs.map fun a => match a with
    | .modify b sets => ⟨'=', b.name, .slots (srt (sets.map fun x => ⟨.eq, x.1, CV.ofTerm x.2⟩))⟩
    | .request b spec => ⟨'+', b.name, .slots (srt (tsSS spec))⟩
    | .modRequest b sets => ⟨'*', b.name, .slots (srt (sets.map fun x => ⟨.eq, x.1, CV.ofTerm x.2⟩))⟩
    | .directRequest b t => ⟨'+', b.name, .slots [⟨.eq, "", CV.ofTerm (some t)⟩]⟩
    | .clear b => ⟨'-', b.name, .slots []⟩
    | .erase b => ⟨'@', b.name, .slots []⟩
    | .overwrite b _ _ => ⟨'@', b.name, .slots []⟩
    | .output ts => ⟨'!', "OUTPUT", .output (ts.map fun t => CV.ofTerm (some t))⟩
    | .stop => ⟨'!', "STOP", .stop⟩
    | .eval e => ⟨'!', "SAFE-EVAL", .expr e⟩
    | .bind x e => ⟨'!', "SAFE-BIND", .bind x e⟩
  ⟨ssort stmLt lhs, ssort stmLt rhs⟩

/-! ### Substitution -/

partial def Expr.substV (x : String) (v : CV) : Expr → Expr
  | .var y => if y == x then (match v with | .var z => .var z | .const c => .lit c) else .var y
  | .app f as => .app f (as.map (Expr.substV x v))
  | .cmd n as => .cmd n (as.map (Expr.substV x v))
  | e => e

def CV.substV (x : String) (v : CV) : CV → CV
  | .var y => if y == x then v else .var y
  | c => c

/-- A variable slot name replaced like any other occurrence of the variable. -/
def slotSubst (x : String) (v : CV) (sl : String) : String :=
  if sl == "=" ++ x then (match v with | .var z => "=" ++ z | c => c.str) else sl

/-- `replace-variables-special` with one binding: slot names and values, `!safe-eval!` and
the expression (not the variable) of `!safe-bind!`. -/
def Stm.substV (x : String) (v : CV) (s : Stm) : Stm :=
  { s with body := match s.body with
    | .slots ss => .slots (ss.map fun t => { t with slot := slotSubst x v t.slot, val := CV.substV x v t.val })
    | .expr e => .expr (e.substV x v)
    | .bind y e => .bind y (e.substV x v)
    | .output ts => .output (ts.map (CV.substV x v))
    | .stop => .stop }

/-- `replace-variables` over a whole statement: also renames a `!safe-bind!` variable. -/
def Stm.renameV (x y : String) (s : Stm) : Stm :=
  let s' := s.substV x (.var y)
  match s'.body with
  | .bind z e => { s' with body := .bind (if z == x then y else z) e }
  | _ => s'

def Rep.map (f : Stm → Stm) (r : Rep) : Rep := ⟨r.lhs.map f, r.rhs.map f⟩

partial def Expr.allVars : Expr → List String
  | .var x => [x]
  | .app _ as | .cmd _ as => as.foldl (fun acc a => acc ++ a.allVars) []
  | .lit _ => []

/-- The variables of a statement (`find-variables` of its slots). -/
def Stm.vars (s : Stm) : List String := match s.body with
  | .slots ss => ss.flatMap fun t =>
    (if isVarSlot t.slot then [(t.slot.drop 1).toString] else []) ++
    (match t.val with | .var x => [x] | _ => [])
  | .expr e => e.allVars
  | .bind x e => x :: e.allVars
  | .output ts => ts.filterMap fun t => match t with | .var x => some x | _ => none
  | .stop => []

/-! ## Productions valid for compilation -/

/-- `valid-compilation-production` (with `:cia` off): no `!eval!`, `!bind!` or indirect
action, only `=` in the conditions' slot tests and queries, and no `!safe-bind!` variable
used in another binding's expression. -/
def Production.validForCompilation (p : Production) : Bool :=
  let bvs := p.rhs.filterMap fun a => match a with | .bind x _ => some x | _ => none
  let bexps := p.rhs.filterMap fun a => match a with | .bind _ e => some e | _ => none
  !p.unsafeBang && p.lhsBinds.isEmpty &&
  !(p.rhs.any fun a => match a with | .directRequest _ _ | .erase _ | .overwrite _ _ _ => true | _ => false) &&
  !(p.lhs.any fun c => match c with
     | .buf _ ts => ts.any (·.cmp != .eq)
     | .query _ qs => qs.any (·.neg)
     | .eval _ => false) &&
  !(bvs.any fun x => bexps.any fun e => e.allVars.contains x)

/-- `valid-1st-p`: no `!stop!` and at most one modification, one request and one
modification request per buffer. -/
def Production.valid1st (p : Production) : Bool :=
  let dup := fun (f : Action → Option Buf) =>
    let bs := p.rhs.filterMap f
    bs.any fun b => (bs.filter (· == b)).length > 1
  !(p.rhs.any fun a => match a with | .stop => true | _ => false) &&
  !dup (fun a => match a with | .modify b _ => some b | _ => none) &&
  !dup (fun a => match a with | .request b _ | .directRequest b _ => some b | _ => none) &&
  !dup (fun a => match a with | .modRequest b _ => some b | _ => none)

/-- Buffers tested with `=` (`production-lhs-buffers`). -/
def Production.lhsBufs (p : Production) : List String :=
  p.lhs.filterMap fun c => match c with | .buf b _ => some b.name | _ => none

/-- Buffers named by actions (`production-rhs-buffers`). -/
def Production.rhsBufs (p : Production) : List String :=
  removeDupsLast (· == ·) (p.rhs.filterMap fun a => a.target?.map Buf.name)

/-- `get-buffer-index`: for each buffer the production uses, in `string<` order, 8 for a
condition, 16 for a query, 1 for a modification, 2 for a clear, 4 for a request and 32
for a modification request. -/
def bufIndices (pp : ProcParams) (p : Production) : List (String × Nat) :=
  let conds := p.allConds pp
  let lhsB := conds.filterMap fun c => match c with | .buf b _ => some b.name | _ => none
  let qB := conds.filterMap fun c => match c with | .query b _ => some b.name | _ => none
  let bufs := ((lhsB ++ qB ++ p.rhsBufs).eraseDups).mergeSort (fun a b => decide (a ≤ b))
  let has := fun (f : Action → Bool) (b : String) =>
    p.rhs.any fun a => f a && a.target?.map Buf.name == some b
  bufs.map fun b => (b,
    (if lhsB.contains b then 8 else 0) + (if qB.contains b then 16 else 0) +
    (if has (fun a => match a with | .modify _ _ => true | _ => false) b then 1 else 0) +
    (if has (fun a => match a with | .clear _ => true | _ => false) b then 2 else 0) +
    (if has (fun a => match a with | .request _ _ | .directRequest _ _ => true | _ => false) b then 4 else 0) +
    (if has (fun a => match a with | .modRequest _ _ => true | _ => false) b then 32 else 0))

/-! ## Compilation types -/

inductive CType where
  | goal | imaginal | retrieval | perceptual | motor
  deriving DecidableEq

def ctypeOf (b : String) : CType :=
  if b == "GOAL" then .goal else if b == "IMAGINAL" then .imaginal
  else if b == "RETRIEVAL" then .retrieval
  else if ["VISUAL-LOCATION", "VISUAL", "AURAL-LOCATION", "AURAL", "TEMPORAL"].contains b then .perceptual
  else .motor

/-- The variables naming buffers, which compilation treats as constants
([Src] `compilation-module-buffer-var-names`). -/
def bufVarNames : List String :=
  Buf.all.map Buf.name ++ ["IMAGINAL-ACTION", "TEMPORAL", "PRODUCTION"]

/-- `constant-value-p`. -/
def CV.isConst : CV → Bool
  | .var x => bufVarNames.contains x
  | .const _ => true

def table_goal : List (Nat × Nat × String) := [(44, 40, "NO-RHS-GOAL-REF"), (44, 9, "NO-RHS-GOAL-REF"), (44, 8, "G-B-C1"), (44, 0, "T"), (40, 44, "T"), (40, 40, "T"), (40, 13, "T"), (40, 12, "T"), (40, 9, "T"), (40, 8, "NO-GOAL-HARVESTING"), (40, 4, "T"), (40, 0, "T"), (13, 40, "NO-RHS-GOAL-REF"), (13, 9, "NO-RHS-GOAL-REF"), (13, 8, "G-B-C1"), (13, 0, "T"), (12, 40, "NO-RHS-GOAL-REF"), (12, 9, "NO-RHS-GOAL-REF"), (12, 8, "G-B-C1"), (12, 0, "T"), (9, 13, "T"), (9, 12, "T"), (9, 9, "T"), (9, 8, "NO-GOAL-HARVESTING-OR-NULL-MOD"), (9, 4, "T"), (9, 0, "T"), (8, 44, "NO-GOAL-HARVESTING"), (8, 40, "NO-GOAL-HARVESTING"), (8, 13, "NO-GOAL-HARVESTING"), (8, 12, "NO-GOAL-HARVESTING"), (8, 9, "NO-GOAL-HARVESTING"), (8, 8, "NO-GOAL-HARVESTING"), (8, 4, "T"), (8, 0, "T"), (4, 40, "NO-RHS-GOAL-REF"), (4, 9, "NO-RHS-GOAL-REF"), (4, 8, "G-B-C1"), (4, 0, "T"), (0, 44, "T"), (0, 40, "T"), (0, 13, "T"), (0, 12, "T"), (0, 9, "T"), (0, 8, "T"), (0, 4, "T")]
def table_imaginal : List (Nat × Nat × String) := [(56, 56, "I-B-C3"), (56, 40, "T"), (56, 25, "I-B-C3"), (56, 24, "I-B-C8"), (56, 16, "I-B-C1"), (56, 9, "T"), (56, 8, "I-B-C5"), (56, 0, "T"), (40, 56, "I-B-C3"), (40, 40, "T"), (40, 25, "I-B-C3"), (40, 24, "I-B-C8"), (40, 16, "I-B-C1"), (40, 9, "T"), (40, 8, "I-B-C5"), (40, 0, "T"), (29, 56, "I-B-C4"), (29, 40, "NO-RHS-IMAGINAL-REF"), (29, 25, "I-B-C3"), (29, 24, "I-B-C8"), (29, 16, "I-B-C1"), (29, 9, "NO-RHS-IMAGINAL-REF"), (29, 8, "I-B-C7"), (29, 0, "T"), (28, 56, "I-B-C4"), (28, 40, "NO-RHS-IMAGINAL-REF"), (28, 25, "I-B-C3"), (28, 24, "I-B-C8"), (28, 16, "I-B-C1"), (28, 9, "NO-RHS-IMAGINAL-REF"), (28, 8, "I-B-C7"), (28, 0, "T"), (25, 29, "I-B-C2"), (25, 28, "I-B-C2"), (25, 25, "I-B-C2"), (25, 24, "I-B-C10"), (25, 20, "I-B-C2"), (25, 16, "I-B-C2"), (25, 13, "T"), (25, 12, "T"), (25, 9, "T"), (25, 8, "I-B-C9"), (25, 4, "T"), (25, 0, "T"), (24, 56, "I-B-C6"), (24, 40, "I-B-C6"), (24, 29, "I-B-C6"), (24, 28, "I-B-C6"), (24, 25, "I-B-C6"), (24, 24, "I-B-C6"), (24, 20, "I-B-C2"), (24, 16, "I-B-C2"), (24, 13, "I-B-C5"), (24, 12, "I-B-C5"), (24, 9, "I-B-C5"), (24, 8, "I-B-C5"), (24, 4, "T"), (24, 0, "T"), (20, 56, "I-B-C4"), (20, 40, "NO-RHS-IMAGINAL-REF"), (20, 25, "I-B-C3"), (20, 24, "I-B-C8"), (20, 16, "I-B-C1"), (20, 9, "NO-RHS-IMAGINAL-REF"), (20, 8, "I-B-C7"), (20, 0, "T"), (16, 56, "I-B-C2"), (16, 40, "T"), (16, 29, "I-B-C2"), (16, 28, "I-B-C2"), (16, 25, "I-B-C2"), (16, 24, "I-B-C2"), (16, 20, "I-B-C2"), (16, 16, "I-B-C2"), (16, 13, "T"), (16, 12, "T"), (16, 9, "T"), (16, 8, "T"), (16, 4, "T"), (16, 0, "T"), (13, 56, "I-B-C4"), (13, 40, "NO-RHS-IMAGINAL-REF"), (13, 25, "I-B-C3"), (13, 24, "I-B-C8"), (13, 16, "I-B-C1"), (13, 9, "NO-RHS-IMAGINAL-REF"), (13, 8, "I-B-C7"), (13, 0, "T"), (12, 56, "I-B-C4"), (12, 40, "NO-RHS-IMAGINAL-REF"), (12, 25, "I-B-C3"), (12, 24, "I-B-C8"), (12, 16, "I-B-C1"), (12, 9, "NO-RHS-IMAGINAL-REF"), (12, 8, "I-B-C7"), (12, 0, "T"), (9, 29, "T"), (9, 28, "T"), (9, 25, "T"), (9, 24, "I-B-C9"), (9, 20, "T"), (9, 16, "T"), (9, 13, "T"), (9, 12, "T"), (9, 9, "T"), (9, 8, "I-B-C9"), (9, 4, "T"), (9, 0, "T"), (8, 56, "I-B-C5"), (8, 40, "I-B-C5"), (8, 29, "I-B-C5"), (8, 28, "I-B-C5"), (8, 25, "I-B-C5"), (8, 24, "I-B-C5"), (8, 20, "T"), (8, 16, "T"), (8, 13, "I-B-C5"), (8, 12, "I-B-C5"), (8, 9, "I-B-C5"), (8, 8, "I-B-C5"), (8, 4, "T"), (8, 0, "T"), (4, 56, "I-B-C4"), (4, 40, "NO-RHS-IMAGINAL-REF"), (4, 25, "I-B-C3"), (4, 24, "I-B-C8"), (4, 16, "I-B-C1"), (4, 9, "NO-RHS-IMAGINAL-REF"), (4, 8, "I-B-C7"), (4, 0, "T"), (0, 56, "T"), (0, 40, "T"), (0, 29, "T"), (0, 28, "T"), (0, 25, "T"), (0, 24, "T"), (0, 20, "T"), (0, 16, "T"), (0, 13, "T"), (0, 12, "T"), (0, 9, "T"), (0, 8, "T"), (0, 4, "T")]
def table_retrieval : List (Nat × Nat × String) := [(28, 28, "T"), (28, 24, "T"), (28, 20, "R-B-C1"), (28, 16, "R-B-C1"), (28, 12, "T"), (28, 8, "T"), (28, 4, "T"), (28, 0, "T"), (24, 20, "R-B-C2"), (24, 16, "R-B-C2"), (24, 4, "T"), (24, 0, "T"), (20, 28, "T"), (20, 24, "T"), (20, 20, "R-B-C1"), (20, 16, "R-B-C1"), (20, 12, "T"), (20, 8, "T"), (20, 4, "T"), (20, 0, "T"), (16, 28, "R-B-C2"), (16, 24, "R-B-C2"), (16, 20, "R-B-C2"), (16, 16, "R-B-C2"), (16, 12, "T"), (16, 8, "T"), (16, 4, "T"), (16, 0, "T"), (12, 28, "T"), (12, 24, "T"), (12, 20, "R-B-C1"), (12, 16, "R-B-C1"), (12, 12, "T"), (12, 8, "T"), (12, 4, "T"), (12, 0, "T"), (8, 20, "T"), (8, 16, "T"), (8, 4, "T"), (8, 0, "T"), (4, 28, "T"), (4, 24, "T"), (4, 20, "R-B-C1"), (4, 16, "R-B-C1"), (4, 12, "T"), (4, 8, "T"), (4, 4, "T"), (4, 0, "T"), (0, 28, "T"), (0, 24, "T"), (0, 20, "T"), (0, 16, "T"), (0, 12, "T"), (0, 8, "T"), (0, 4, "T")]
def table_perceptual : List (Nat × Nat × String) := [(28, 16, "P-B-C1"), (28, 0, "T"), (24, 28, "P-B-C4"), (24, 24, "P-B-C4"), (24, 20, "P-B-C2"), (24, 16, "P-B-C2"), (24, 12, "P-B-C3"), (24, 8, "P-B-C3"), (24, 4, "T"), (24, 0, "T"), (20, 16, "P-B-C1"), (20, 0, "T"), (16, 28, "P-B-C2"), (16, 24, "P-B-C2"), (16, 20, "P-B-C2"), (16, 16, "P-B-C2"), (16, 12, "T"), (16, 8, "T"), (16, 4, "T"), (16, 0, "T"), (12, 16, "P-B-C1"), (12, 0, "T"), (8, 28, "P-B-C3"), (8, 24, "P-B-C3"), (8, 20, "T"), (8, 16, "T"), (8, 12, "P-B-C3"), (8, 8, "P-B-C3"), (8, 4, "T"), (8, 0, "T"), (4, 16, "P-B-C1"), (4, 0, "T"), (0, 28, "T"), (0, 24, "T"), (0, 20, "T"), (0, 16, "T"), (0, 12, "T"), (0, 8, "T"), (0, 4, "T")]
def table_motor : List (Nat × Nat × String) := [(20, 16, "M-B-C1"), (20, 0, "T"), (16, 20, "M-B-C2"), (16, 16, "M-B-C2"), (16, 4, "T"), (16, 0, "T"), (4, 16, "M-B-C1"), (4, 0, "T"), (0, 20, "T"), (0, 16, "T"), (0, 4, "T")]
def CType.table : CType → List (Nat × Nat × String)
  | .goal => table_goal | .imaginal => table_imaginal | .retrieval => table_retrieval
  | .perceptual => table_perceptual | .motor => table_motor

def findStm (l : List Stm) (op : Char) (b : String) : Option Stm :=
  l.find? fun x => x.op == op && x.name == b

def slotsOf (l : List Stm) (op : Char) (b : String) : List SS :=
  ((findStm l op b).map Stm.slots).getD []

/-- Every slot of a query is one of `allowed` (`(= slot value)` compared with `equalp`). -/
def queryOK (allowed : List (String × String)) : Option Stm → Bool
  | none => true
  | some q => q.slots.all fun t => t.op == .eq && match t.val with
    | .const (some (.sym v)) => allowed.contains (t.slot, v)
    | _ => false

/-- The checks named in the compilation tables ([Src] `NO-RHS-GOAL-REF`, `G-B-C1`,
`I-B-C1` … `I-B-C10`, `R-B-C1`, `R-B-C2`, `P-B-C1` … `P-B-C4`, `M-B-C1`, `M-B-C2`). -/
def checkFn (f : String) (b : String) (nh : List String) (s1 s2 : Rep) : Bool :=
  let noRhsRef := !(s2.rhs.any fun x => x.vars.contains b)
  let noHarv := nh.contains b
  let nullMod := match findStm s1.rhs '=' b with | some m => m.slots.isEmpty | none => false
  let q1 := findStm s1.lhs '?' b
  let q2 := findStm s2.lhs '?' b
  let c1 := queryOK [("STATE", "BUSY"), ("BUFFER", "EMPTY")] q2
  let c2 :=
    let a := (q1.map Stm.slots).getD []
    let c := (q2.map Stm.slots).getD []
    a.length == c.length && c.length == (removeDupsLast (fun x y => x.str == y.str) (a ++ c)).length
  let c3 := queryOK [("STATE", "FREE")] q2
  match f with
  | "T" => true
  | "NO-RHS-GOAL-REF" | "NO-RHS-IMAGINAL-REF" => noRhsRef
  | "NO-GOAL-HARVESTING" | "I-B-C5" | "P-B-C3" => noHarv
  | "NO-GOAL-HARVESTING-OR-NULL-MOD" | "I-B-C9" => noHarv || nullMod
  | "G-B-C1" => noRhsRef && noHarv
  | "I-B-C1" | "R-B-C1" | "P-B-C1" => c1
  | "M-B-C1" => queryOK [("STATE", "BUSY")] q2
  | "I-B-C2" | "R-B-C2" | "P-B-C2" | "M-B-C2" => c2
  | "I-B-C3" => c3
  | "I-B-C4" => c3 && noRhsRef
  | "I-B-C6" => noHarv && c2
  | "I-B-C7" => noHarv && noRhsRef
  | "I-B-C8" => noHarv && c3
  | "I-B-C10" => c2 && (noHarv || nullMod)
  | "P-B-C4" => c2 && noHarv
  | _ => false

def instCV (env : Env) : CV → CV
  | .var x => match env.lookup x with | some v => .const (some v) | none => .var x
  | c => c

/-- The name a value gives a slot. -/
def Val.slotName : Val → String
  | .sym n => n
  | v => v.repr

/-- A slot name with a bound variable replaced by its value (`replace-variables`). -/
def instSlotName (env : Env) (sl : String) : String :=
  if isVarSlot sl then ((env.lookup (sl.drop 1).toString).map Val.slotName).getD sl else sl

/-- `(cdr (assoc slot-variable bindings))`: the name a variable slot name is bound to, or
`nil` (`none`) when unbound; `none` too for a slot name that is no variable. -/
def bindName (env : Env) (sl : String) : Option String :=
  if isVarSlot sl then (env.lookup (sl.drop 1).toString).map Val.slotName else none

/-- `instantiate-slot-names`: variable slot names replaced by their bindings. -/
def instSlots (env : Env) (ss : List SS) : List SS :=
  ss.map fun t => if isVarSlot t.slot then { t with slot := (bindName env t.slot).getD "NIL" } else t

/-- The variable slot names of a specification with the names they are bound to (the
`(assoc name bindings)` of each that is bound). -/
def varSlotsOf (env : Env) (ss : List SS) : List (String × String) :=
  (ss.filter (isVarSlot ·.slot)).filterMap fun t =>
    let x := (t.slot.drop 1).toString
    (env.lookup x).map fun v => (x, v.slotName)

/-- `chunk-slot-equal` on instantiated values: names of chunks merged into the same chunk
are equal. -/
def cvSlotEqual (tn : String → String) : CV → CV → Bool
  | .const (some (.sym a)), .const (some (.sym b)) => tn a == tn b
  | .const a, .const b => a == b
  | .var a, .var b => a == b
  | _, _ => false

/-- `check-consistency`: every slot the second production tests that the first one's
action sets holds the value the action sets. -/
def checkConsistency (tn : String → String) (act : Option Stm) (aenv : Env) (cond : Option Stm) (cenv : Env) : Bool :=
  let aspec := ((act.map Stm.slots).getD []).map fun t => (instSlotName aenv t.slot, instCV aenv t.val)
  let cspec := ((cond.map Stm.slots).getD []).map fun t => (instSlotName cenv t.slot, instCV cenv t.val)
  cspec.all fun c =>
    let as := aspec.filter (·.1 == c.1)
    as.isEmpty || as.all (cvSlotEqual tn ·.2 c.2)

/-- `CHECK-GOAL-CONSISTENCY`, `CHECK-IMAGINAL-CONSISTENCY`. -/
def consistency (tn : String → String) (t : CType) (b : String) (s1 s2 : Rep) (i1 : Nat) (e1 e2 : Env) : Bool :=
  let cond := findStm s2.lhs '=' b
  let chk := fun (op : Char) => checkConsistency tn (findStm s1.rhs op b) e1 cond e2
  match t with
  | .goal =>
    if [4, 12, 13, 44].contains i1 then chk '+' else if i1 == 9 then chk '='
    else if i1 == 40 then chk '*' else true
  | .imaginal =>
    if [4, 12, 13, 20, 28, 29].contains i1 then chk '+' else if [9, 25].contains i1 then chk '='
    else if [40, 56].contains i1 then chk '*' else true
  | _ => true

/-- The production's written conditions use the variable `=b`. -/
def Production.lhsMentions (p : Production) (x : String) : Bool :=
  p.lhs.any fun c => match c with
    | .buf _ ts => ts.any fun t => match t.arg with | some (.var y) => y == x | _ => false
    | .eval e => e.allVars.contains x
    | .query _ _ => false

/-- `determine-composable`: every buffer either production names allows the pair by its
compilation type's table; buffers the first one acts on and the second one tests pass
the type's consistency check; and the second does not test `=b` while the first makes a
request to `b`. -/
def composable (tn : String → String) (pp : ProcParams) (p1 p2 : Production) (s1 s2 : Rep) (e1 e2 : Env) : Bool :=
  let ix1 := bufIndices pp p1
  let ix2 := bufIndices pp p2
  let use := fun (ix : List (String × Nat)) (b : String) => (ix.lookup b).getD 0
  let nh := pp.doNotHarvest.map Buf.name
  let bufs := (p1.lhsBufs ++ p2.lhsBufs ++ p1.rhsBufs ++ p2.rhsBufs).eraseDups
  (bufs.all fun b =>
    let u1 := use ix1 b
    let u2 := use ix2 b
    match (ctypeOf b).table.find? (fun x => x.1 == u1 && x.2.1 == u2) with
    | some (_, _, f) => checkFn f b nh s1 s2
    | none => false) &&
  (linter p1.rhsBufs p2.lhsBufs).all fun b =>
    consistency tn (ctypeOf b) b s1 s2 (use ix1 b) e1 e2 &&
    !(p2.lhsMentions b && p1.rhs.any fun a => match a with
        | .request b' _ | .directRequest b' _ => b'.name == b | _ => false)

/-! ## Mappings -/

/-- A mapping of a variable to a value. `tag` marks a mapping that is a binding of the
first production's instantiation itself (Lisp's `assoc` returns the same cons each time,
which `remove-duplicates` treats as one). -/
structure MapE where
  k : CV
  v : CV
  tag : Option Nat := none
  deriving Inhabited

/-- The mappings of one slot of interest for variable slot names ([Src] the "dynamic slots"
part of `MAP-GOAL-BUFFER`): a variable slot name of each production to one of the other
naming the same slot, or to the slot's name where the other names it as a constant. -/
def dynPushes (slot : String) (p1v p1vb p2v p2rv : List (String × String))
    (o1 o1b o2 o2r : List SS) (acc : Array MapE) : Array MapE :=
  let rass := fun (l : List (String × String)) => l.any (·.2 == slot)
  let cars := fun (l : List (String × String)) => (l.filter (·.2 == slot)).map (·.1)
  let has := fun (ss : List SS) => ss.any (·.slot == slot)
  let both := fun (a b : List (String × String)) (acc : Array MapE) =>
    (cars a).foldl (fun acc x => (cars b).foldl (fun acc y => acc.push ⟨.var x, .var y, none⟩) acc) acc
  let toSlot := fun (a : List (String × String)) (acc : Array MapE) =>
    (cars a).foldl (fun acc x => acc.push ⟨.var x, .const (some (.sym slot)), none⟩) acc
  let acc := if rass p1v && rass p2v then both p1v p2v acc else acc
  let acc := if rass p1vb && rass p2rv then both p1vb p2rv acc else acc
  let acc := if rass p1v && has o2 then toSlot p1v acc else acc
  let acc := if rass p1vb && has o2r then toSlot p1vb acc else acc
  let acc := if rass p2v && has o1 then toSlot p2v acc else acc
  if rass p2rv && has o1b then toSlot p2rv acc else acc

/-- The mappings of the slots of interest: for each, the mappings of variable slot names (if
`dyn`), then each pair of a slot of the first and one of the second. -/
def mapSlots (interesting : List String) (p1s p2s : List SS) (opFilter : Bool)
    (dyn : Option (List (String × String) × List (String × String) × List (String × String) ×
      List (String × String) × List SS × List SS × List SS × List SS)) : List MapE :=
  let pushes := interesting.foldl (fun (acc : Array MapE) slot =>
    let acc := match dyn with
      | some (p1v, p1vb, p2v, p2rv, o1, o1b, o2, o2r) =>
        if p1v.isEmpty && p2v.isEmpty && p2rv.isEmpty then acc
        else dynPushes slot p1v p1vb p2v p2rv o1 o1b o2 o2r acc
      | none => acc
    let a := p1s.filter fun x => x.slot == slot && (!opFilter || x.op == .eq)
    let b := p2s.filter fun x => x.slot == slot && (!opFilter || x.op == .eq)
    a.foldl (fun acc x => b.foldl (fun acc y =>
      acc.push (if y.val.isConst then ⟨x.val, y.val, none⟩ else ⟨y.val, x.val, none⟩)) acc) acc) #[]
  pushes.toList.reverse

/-- The mappings between the slots two specifications share (no variable slot names). -/
def mapPairs (interesting : List String) (p1s p2s : List SS) (opFilter : Bool) : List MapE :=
  mapSlots interesting p1s p2s opFilter none

/-- `MAP-GOAL-BUFFER` and `MAP-IMAGINAL-BUFFER` (without `:ppm`): the slot names of each
production instantiated with its own bindings (`e1` for the first, `e2` the second's
renamed instantiation). -/
def mapGI (imag : Bool) (b : String) (s1 s2 : Rep) (i1 i2 : Nat) (e1 e2 : Env) : List MapE :=
  let o2 := slotsOf s2.lhs '=' b
  let o2r := ((s2.rhs.find? fun x => x.name == b && (x.op == '=' || x.op == '*')).map Stm.slots).getD []
  let p2v := varSlotsOf e2 o2
  let p2rv := varSlotsOf e2 o2r
  let p2s := instSlots e2 o2
  let p2r := instSlots e2 o2r
  let eqNames := fun (l : List SS) => (l.filter (·.op == .eq)).map (·.slot)
  let abc := fun (p1s : List SS) => removeDupsLast (· == ·) (eqNames p1s ++ eqNames p2s ++ eqNames p2r)
  let bc := fun (op : Char) =>
    let o1a := slotsOf s1.lhs '=' b
    let o1b := slotsOf s1.rhs op b
    let p1a := instSlots e1 o1a
    let p1b := instSlots e1 o1b
    let p1s := p1a.filter (fun x => x.op == .eq && !(p1b.any (·.slot == x.slot))) ++ p1b
    let p1va := varSlotsOf e1 o1a
    let p1vb := varSlotsOf e1 o1b
    let p1v := removeDupsLast (· == ·) (p1va ++ p1vb)
    mapSlots (abc p1s) p1s p2s false (some (p1v, p1vb, p2v, p2rv, o1a ++ o1b, o1b, o2, o2r))
  let (cA1, cA2, cB1, cB2, cC1, cC2) :=
    if imag then ([4, 12, 13, 20, 28, 29], [8, 9, 12, 13, 24, 25, 28, 29, 40, 56], [9, 25],
                  [8, 9, 12, 13, 24, 25, 28, 29], [40, 56], [8, 9, 24, 25, 40, 56])
    else ([4, 12, 13, 44], [8, 9, 12, 13, 40, 44], [9], [8, 9, 12, 13], [40], [8, 12, 40, 44])
  if cA1.contains i1 && cA2.contains i2 then
    let o1 := slotsOf s1.rhs '+' b
    let p1s := instSlots e1 o1
    let p1v := varSlotsOf e1 o1
    mapSlots (abc p1s) p1s p2s true (some (p1v, p1v, p2v, p2rv, o1, o1, o2, o2r))
  else if cB1.contains i1 && cB2.contains i2 then bc '='
  else if cC1.contains i1 && cC2.contains i2 then bc '*'
  else if imag && [8, 24].contains i1 && [8, 9, 12, 13, 24, 25, 28, 29, 40, 56].contains i2 then
    let p1s := instSlots e1 (slotsOf s1.lhs '=' b)
    mapPairs (linter (eqNames p1s) (eqNames p2s)) p1s p2s true
  -- the goal type's case for a tested and unchanged buffer looks for the first
  -- production's slots among its conditions' requests, so it never maps anything
  else []

/-- `assoc` in the first production's instantiation, as a mapping. -/
def assocE (env : Env) (x : String) : Option MapE :=
  match env.findIdx? (·.1 == x) with
  | some i => some ⟨.var x, .const (some env[i]!.2), some i⟩
  | none => none

/-- `MAP-RETRIEVAL-BUFFER`: the buffer variable maps to the chunk the second production
matched, the variables of the first production's request to their values, and the
variables of the second production's test to the retrieved chunk's slot values. -/
def mapRetrieval (b : String) (s1 s2 : Rep) (i1 i2 : Nat) (e1 e2 instan : Env)
    (chunkOf : String → Option Chunk) : List (Option MapE) :=
  if [4, 12, 20, 28].contains i1 && [8, 12, 24, 28].contains i2 then
    match e2.lookup b with
    | some cv@(.sym cn) =>
      let ch := chunkOf cn
      let pushes : Array (Option MapE) := #[some ⟨.var b, .const (some cv), none⟩]
      -- a variable slot name of the request maps to its instantiation, as its value does
      let pushes := (slotsOf s1.rhs '+' b).foldl (fun acc t =>
        let acc := if isVarSlot t.slot then acc.push (assocE e1 (t.slot.drop 1).toString) else acc
        match t.op, t.val with
        | .eq, .var x => acc.push (assocE e1 x)
        | _, _ => acc) pushes
      -- one of the test, to the second production's instantiation (its own binding in the
      -- renamed instantiation); its value to the retrieved chunk's value of that slot
      let pushes := (slotsOf s2.lhs '=' b).foldl (fun acc t =>
        let (acc, sl) := if isVarSlot t.slot then
            let x := (t.slot.drop 1).toString
            let m := match instan.findIdx? (·.1 == x) with
              | some i => some ⟨.var x, .const (some instan[i]!.2), some (1000000 + i)⟩
              | none => none
            (acc.push m, match m with | some m => (match m.v with | .const (some v) => v.slotName | _ => "NIL") | none => "NIL")
          else (acc, t.slot)
        match t.op, t.val with
        | .eq, .var x => acc.push (some ⟨.var x, .const (ch.bind (·.get sl)), none⟩)
        | _, _ => acc) pushes
      pushes.toList.reverse
    | _ => []
  else []

/-! ## Composition -/

/-- `buffer+-union`: the first action's slots not set by the second, then the second's. -/
def plusUnion (bnd : Env) (a1 : Stm) (a2 : Option Stm) : Stm :=
  let a2s := (a2.map Stm.slots).getD []
  let names := a2s.map (·.slot)
  -- the second's slot names with variables replaced by their bindings (`a2-no-dynamic`)
  let noDyn : List (Option String) := names.map fun n => if isVarSlot n then bindName bnd n else some n
  let rem := a1.slots.filter fun x => !(x.op == .eq &&
    (names.contains x.slot || noDyn.contains (some x.slot) ||
     (isVarSlot x.slot && noDyn.contains (bindName bnd x.slot))))
  { a1 with body := .slots (rem ++ a2s) }

/-- `buffer-condition-union`: the first conditions and those of the second not set by the
first production's action. -/
def condUnion (bnd : Env) (c1 c2 a1 : Option Stm) : Option Stm :=
  match c1, c2 with
  | none, none => none
  | c1, none => c1
  | _, some c2 =>
    let a1n := ((a1.map Stm.slots).getD []).map (instSlotName bnd ·.slot)
    let rem := c2.slots.filter fun x => !(match bindName bnd x.slot with
      | some v => a1n.contains v
      | none => a1n.contains x.slot)
    match c1 with
    | none => some { c2 with body := .slots rem }
    | some c1 => some { c1 with body := .slots (removeDupsLast (fun x y => x.str == y.str) (c1.slots ++ rem)) }

/-- A query of the second production on a strictly harvested buffer loses `buffer empty`. -/
def dropEmpty (nh : List String) (b : String) (q2 : Stm) : List Stm :=
  if nh.contains b then [q2]
  else
    let ss := q2.slots.filter fun t => !(t.op == .eq && t.slot == "BUFFER" &&
      match t.val with | .const (some (.sym "EMPTY")) => true | _ => false)
    if ss.isEmpty then [] else [{ q2 with body := .slots ss }]

/-- The `compose` functions of the compilation types ([Src] `COMPOSE-GOAL-BUFFER`,
`COMPOSE-IMAGINAL-BUFFER`, `COMPOSE-RETRIEVAL-BUFFER`, `COMPOSE-PERCEPTUAL-BUFFER`,
`COMPOSE-MOTOR-BUFFER`): the buffer's conditions and actions in the new production. -/
def composeBuf (t : CType) (nh : List String) (b : String) (s1 s2 : Rep) (i1 i2 : Nat) (bnd : Env) :
    List Stm × List Stm :=
  let plusUnion := plusUnion bnd
  let condUnion := condUnion bnd
  let c1 := findStm s1.lhs '=' b
  let c2 := findStm s2.lhs '=' b
  let q1 := findStm s1.lhs '?' b
  let q2 := findStm s2.lhs '?' b
  let a1e := findStm s1.rhs '=' b
  let a2e := findStm s2.rhs '=' b
  let a1p := findStm s1.rhs '+' b
  let a2p := findStm s2.rhs '+' b
  let a1s := findStm s1.rhs '*' b
  let a2s := findStm s2.rhs '*' b
  let o := fun (x : Option Stm) => x.toList
  let firstReq : List Stm :=
    (if a1e.isSome then o a1e else o a1s) ++
    (match a1p with
     | some ap => if a2e.isSome then [plusUnion ap a2e] else if a2s.isSome then [plusUnion ap a2s] else [ap]
     | none => [])
  let nullA1 := match a1e with | some m => m.slots.isEmpty | none => true
  let modActs := fun (harvested : Bool) =>
    if harvested && !nh.contains b && nullA1 then []
    else match a1s, a2e with
      | some x, some _ => [plusUnion x a2e]
      | _, _ =>
        if a1e.isSome || a2e.isSome then (match a1e with | some x => [plusUnion x a2e] | none => o a2e)
        else if a1s.isSome || a2s.isSome then (match a1s with | some x => [plusUnion x a2s] | none => o a2s)
        else []
  match t with
  | .goal =>
    if [4, 12, 13, 44].contains i1 then (o c1, firstReq)
    else if [0, 8].contains i1 then (o (condUnion c1 c2 a1e), o a2e ++ o a2s ++ o a2p)
    else if [9, 40].contains i1 then
      (o (condUnion c1 c2 (if a1e.isSome then a1e else a1s)), modActs (i2 == 8) ++ o a2p)
    else ([], [])
  | .imaginal =>
    if [4, 12, 13, 20, 28, 29].contains i1 then (o c1 ++ o q1, firstReq)
    else if [0, 8, 16, 24].contains i1 then
      (o (condUnion c1 c2 a1e) ++
        (match q1, q2 with
         | some q, _ => [q]
         | none, some q => dropEmpty nh b q
         | none, none => []),
       o a2e ++ o a2s ++ o a2p)
    else if [9, 40, 25, 56].contains i1 then
      (o (condUnion c1 c2 (if a1e.isSome then a1e else a1s)) ++
        (match q1, q2 with
         | some q, _ => [q]
         | none, some q => if i1 == 40 && [24, 25, 56].contains i2 then [] else [q]
         | none, none => []),
       modActs ([8, 24].contains i2) ++ o a2p)
    else ([], [])
  | .retrieval =>
    if i1 == 0 then (o c2 ++ o q2, o a2p)
    else if [4, 12].contains i1 then (o c1, if [0, 16].contains i2 then o a1p else o a2p)
    else if i1 == 8 then (o c1 ++ (match q2 with | some q => dropEmpty nh b q | none => []), o a2p)
    else if i1 == 16 then (o c2 ++ o q1, o a2p)
    else if i1 == 24 then (o c1 ++ o q1, o a2p)
    else if [20, 28].contains i1 then (o c1 ++ o q1, if [0, 16].contains i2 then o a1p else o a2p)
    else ([], [])
  | .perceptual =>
    if i1 == 0 then (o c2 ++ o q2, o a2p)
    else if [4, 12].contains i1 then (o c1, o a1p)
    else if i1 == 8 then
      (o (condUnion c1 c2 none) ++ (match q2 with | some q => dropEmpty nh b q | none => []), o a2p)
    else if [16, 24].contains i1 then (o (condUnion c1 c2 none) ++ o q1, o a2p)
    else if [20, 28].contains i1 then (o c1 ++ o q1, o a1p)
    else ([], [])
  | .motor =>
    if i1 == 0 then (o q2, o a2p)
    else if i1 == 4 then ([], o a1p)
    else if i1 == 16 then (o q1, o a2p)
    else if i1 == 20 then (o q1, o a1p)
    else ([], [])

/-- Apply the mappings in order ([Src] `compose-productions`): each one substitutes its
variable in both productions and becomes the key of later mappings with the same key; a
`nil` mapping ends the loop. -/
partial def applyMaps : List (Option MapE) → Rep → Rep → Rep × Rep
  | [], r1, r2 => (r1, r2)
  | none :: _, r1, r2 => (r1, r2)
  | some m :: rest, r1, r2 =>
    let (r1, r2) := match m.k with
      | .var x => (r1.map (Stm.substV x m.v), r2.map (Stm.substV x m.v))
      | _ => (r1, r2)
    let rest := rest.map fun e => match e with
      | some e => if e.k.eq m.k then some { e with k := m.v, tag := none } else some e
      | none => if m.k.eq (.const none) then some ⟨m.v, .const none, none⟩ else none
    applyMaps rest r1 r2

/-- `basic-variables`: the production's variables except buffer variables of its
conditions and of the retrieval buffer. -/
def basicVars (p : Production) : List String :=
  let lhsB := p.lhsBufs
  let all := removeDupsLast (· == ·) (p.vars ++ lhsB)
  (all.filter fun x => x != "RETRIEVAL" && !lhsB.contains x).reverse

/-- `new-name-fct`: the prefix and the next number of its counter whose name is not taken. -/
def newNameIn (names : List (String × Nat)) (taken : String → Bool) (pre : String) :
    String × List (String × Nat) := Id.run do
  let mut n := (names.lookup pre).getD 0
  for _ in [0:100000] do
    if taken (pre ++ toString n) then n := n + 1 else break
  return (pre ++ toString n, (pre, n + 1) :: names.filter (·.1 != pre))

def Stm.toCond (s : Stm) : Option Cond :=
  match s.op, s.body with
  | '=', .slots ss => (Buf.ofName? s.name).map fun b => .buf b (ss.map fun t => ⟨t.op, t.slot, t.val.toTerm⟩)
  | '?', .slots ss => (Buf.ofName? s.name).map fun b => .query b (ss.map fun t =>
      ⟨t.op == .ne, t.slot, match t.val with
        | .const (some v) => v.show | .const none => "NIL" | .var x => "=" ++ x⟩)
  | '!', .expr e => some (.eval e)
  | _, _ => none

def Stm.toAction (s : Stm) : Option Action :=
  let sets := fun (ss : List SS) => ss.map fun t => (t.slot, t.val.toTerm)
  match s.op, s.body with
  | '=', .slots ss => (Buf.ofName? s.name).map fun b => .modify b (sets ss)
  | '*', .slots ss => (Buf.ofName? s.name).map fun b => .modRequest b (sets ss)
  | '+', .slots ss => (Buf.ofName? s.name).map fun b => .request b (ss.map fun t => ⟨t.op, t.slot, t.val.toTerm⟩)
  | '-', _ => (Buf.ofName? s.name).map .clear
  | '!', .expr e => some (.eval e)
  | '!', .bind x e => some (.bind x e)
  | '!', .output ts => some (.output (ts.filterMap CV.toTerm))
  | '!', .stop => some .stop
  | _, _ => none

/-- The representation [Src] `produce-standard-representation` builds to find a production
that already exists: variables of slot tests renamed after the buffer and slot,
`!safe-bind!` variables numbered, the `!` statements sorted by their printed form. Compared
with `equalp`. -/
def stdRep (pp : ProcParams) (p : Production) : String :=
  let r := compRep pp p
  let bufVars := (r.lhs.filter (·.op == '=')).map (·.name)
  let slotVars := r.lhs.foldl (fun acc c => if c.op != '=' then acc else c.slots.foldl (fun acc x =>
      match x.op, x.val with
      | .eq, .var v => if acc.any (·.1 == v) || bufVars.contains v then acc
                       else acc ++ [(v, c.name ++ "-&-" ++ x.slot)]
      | _, _ => acc) acc) ([] : List (String × String))
  let ren := fun (s : Stm) => slotVars.foldl (fun s (v : String × String) => s.renameV v.1 v.2) s
  let lhs := r.lhs.map ren
  let rhs := r.rhs.map ren
  let lhsOther := ssort (fun a b => a.defStr < b.defStr) (lhs.filter (·.op == '!')).reverse
  let lhs := lhs.filter (·.op != '!') ++ lhsOther
  let binds := ssort (fun (a b : Stm) => a.defStr.drop 1 < b.defStr.drop 1)
    (rhs.filter (fun x => x.op == '!' && x.name == "SAFE-BIND")).reverse
  let bren := (List.range binds.length).zip (binds.map fun s => match s.body with | .bind x _ => x | _ => "")
  let bren := bren.map fun (i, x) => (x, "RHS-BIND-VAR-" ++ toString i)
  let binds := binds.map fun s => match s.body with
    | .bind x e => { s with body := .bind ((bren.lookup x).getD x) e }
    | _ => s
  let renB := fun (s : Stm) => bren.foldl (fun s (v : String × String) => s.substV v.1 (.var v.2)) s
  let others := ssort (fun a b => a.defStr < b.defStr)
    ((rhs.filter fun x => x.op == '!' && x.name != "SAFE-BIND").reverse.map renB)
  let rhs := ssort stmLt ((rhs.filter (·.op != '!')).map renB) ++ binds ++ others
  " ".intercalate (lhs.map Stm.strP) ++ " ==> " ++ " ".intercalate (rhs.map Stm.strP)

/-- Production compilation's state ([Src] `compilation-module`): the previous production
with its instantiation and firing time, and the pairs already tested. -/
structure CompState where
  prev : Option (Nat × Env) := none
  prevTime : Nat := 0
  cache : List ((String × String) × Bool) := []
  deriving Inhabited

/-- What composition needs from the rest of the model. -/
structure CompEnv where
  P : Params
  /-- A chunk by name. -/
  chunkOf : String → Option Chunk
  /-- Whether a name is a chunk's, which `new-name` skips. -/
  taken : String → Bool
  /-- The name a merged chunk's name stands for. -/
  trueName : String → String := id

/-- `compose-productions` and `update-params-for-compiled-production`: the new production,
added unless an equivalent one exists; an equivalent production made by compilation has
its utility moved toward the first parent's ([Src] `update-utility-for-compiled-production`). -/
def composeProds (E : CompEnv) (prods : Array Production) (names : List (String × Nat))
    (j : Nat) (e1 : Env) (i : Nat) (e2 : Env) : Array Production × List (String × Nat) × String := Id.run do
  let pp := E.P.proc
  let p1 := prods[j]!
  let p2 := prods[i]!
  let s1 := compRep pp p1
  let s2₀ := compRep pp p2
  let b1 := basicVars p1
  let b2 := basicVars p2
  let notVars := lunion b1 b2
  let mut names := names
  let mut ren : List (String × String) := []
  for x in linter b1 b2 do
    let mut y := x
    for _ in [0:100] do
      let (n, ns) := newNameIn names (fun _ => false) ("=" ++ x)
      names := ns
      y := n.drop 1 |>.toString
      if !notVars.contains y then break
    ren := ren ++ [(x, y)]
  let s2 := s2₀.map fun s => ren.foldl (fun s (v : String × String) => s.renameV v.1 v.2) s
  let instan := e2.map fun (k, v) => ((ren.lookup k).getD k, v)
  let ix1 := bufIndices pp p1
  let ix2 := bufIndices pp p2
  let use := fun (ix : List (String × Nat)) (b : String) => (ix.lookup b).getD 0
  let used := lunion (ix1.map (·.1)) (ix2.map (·.1))
  let mut ms : List (Option MapE) := []
  for b in used do
    let m : List (Option MapE) := match ctypeOf b with
      | .goal => (mapGI false b s1 s2 (use ix1 b) (use ix2 b) e1 instan).map some
      | .imaginal => (mapGI true b s1 s2 (use ix1 b) (use ix2 b) e1 instan).map some
      | .retrieval => mapRetrieval b s1 s2 (use ix1 b) (use ix2 b) e1 e2 instan E.chunkOf
      | _ => []
    ms := m ++ ms
  for x in s1.rhs do
    if let .bind v e := x.body then
      ms := ms ++ [assocE e1 v] ++ (removeDupsLast (· == ·) e.allVars).map (assocE e1)
  ms := removeDupsLast (fun a b => match a, b with
    | none, none => true
    | some a, some b => a.tag.isSome && a.tag == b.tag
    | _, _ => false) ms
  let key := fun (m : Option MapE) => match m with
    | none => 1
    | some m => if m.v.isConst then (if m.k.isConst then 1 else 2) else 0
  ms := ssort (fun a b => key a < key b) ms
  let (s1, s2) : Rep × Rep := applyMaps ms s1 s2
  let nh := pp.doNotHarvest.map Buf.name
  let mut conds : List Stm := []
  let mut acts : List Stm := []
  for b in used do
    let (c, a) := composeBuf (ctypeOf b) nh b s1 s2 (use ix1 b) (use ix2 b) (e1 ++ instan)
    conds := conds ++ c
    acts := acts ++ a
  let isBang := fun (x : Stm) (ns : List String) => x.op == '!' && ns.contains x.name
  for x in s2.lhs do if isBang x ["SAFE-EVAL"] then conds := x :: conds
  for x in s2.rhs do if isBang x ["SAFE-EVAL", "OUTPUT", "STOP"] then acts := x :: acts
  for x in s2.rhs do if isBang x ["SAFE-BIND"] then acts := x :: acts
  for x in s1.lhs do
    if isBang x ["SAFE-EVAL"] && !(conds.any (·.str == x.str)) then conds := x :: conds
  for x in s1.rhs do
    if isBang x ["OUTPUT"] || (isBang x ["SAFE-EVAL"] && !(acts.any (·.str == x.str))) then
      acts := x :: acts
  -- variables left unbound take the second production's values
  let lhsVars := conds.flatMap Stm.vars
  let rhsBinds := acts.filterMap fun x => match x.body with | .bind v _ => some v | _ => none
  for v in (acts.flatMap Stm.vars).eraseDups do
    if !(rhsBinds.contains v || lhsVars.contains v || bufVarNames.contains v) then
      if let some val := instan.lookup v then
        acts := acts.map (Stm.substV v (.const (some val)))
  if E.P.pct then
    conds := ssort (fun a b => (if a.op == '!' then "z" else a.token) < (if b.op == '!' then "z" else b.token)) conds
    acts := ssort (fun a b => b.token < a.token) acts
  conds := conds.filter (·.op != '!') ++ conds.filter (·.op == '!')
  -- `new-production-name`
  let mut pname := ""
  for _ in [0:prods.size + 1] do
    let (n, ns) := newNameIn names E.taken "PRODUCTION"
    names := ns
    pname := n
    if !(prods.any (·.name == n)) then break
  let at1 := p1.actTime.getD E.P.dat
  let at2 := p2.actTime.getD E.P.dat
  let reward := match p1.reward, p2.reward with
    | some r1, some r2 => some (if r2.1 > r1.1 then r2 else r1)
    | some r, none | none, some r => some r
    | none, none => none
  -- the text of the new production, its `!…!` conditions first as the parser puts them
  let cvTok := fun (c : CV) => match c with | .var x => PTok.var x | c => PTok.lit c.str
  let text := fun (x : Stm) => match x.body with
    | .expr e => some (PStmt.bang "SAFE-EVAL" e.toks)
    | .bind v e => some (PStmt.bang "SAFE-BIND" (.var v :: .lit " " :: e.toks))
    | .output ts => some (PStmt.bang "OUTPUT" ([PTok.lit "("] ++ ((ts.map fun t => [cvTok t]).intersperse [.lit " "]).flatten ++ [.lit ")"]))
    | .stop => some (PStmt.bang "STOP" [])
    | .slots _ => none
  let lhsText := (conds.filter (·.op == '!')).filterMap text ++
    (conds.filter (·.op != '!')).filterMap fun x => x.toCond.map PStmt.cond
  let rhsText := acts.filterMap fun x => if x.op == '!' then text x else x.toAction.map PStmt.act
  let p3 : Production := {
    name := pname, lhs := conds.filterMap Stm.toCond, rhs := acts.filterMap Stm.toAction,
    u := E.P.nu, reward := reward, actTime := some (max at1 at2), userCreated := false,
    lhsText := lhsText, rhsText := rhsText, doc := some s!"{p1.name} & {p2.name}" }
  -- `p-fct` rejects a production with an unbound variable
  if !p3.wellBound then
    return (prods, names, s!"#PCT {p1.name} & {p2.name}: {pname} not defined")
  let rep3 := stdRep pp p3
  let flat := fun (x : Stm) => x.token ++ (match x.body with
    | .slots ss => String.join (ss.map fun t => (if t.op == .eq then "" else " " ++ t.op.str) ++ " " ++ t.slot ++ " " ++ t.val.str)
    | .expr e => " " ++ e.str
    | .bind v e => " =" ++ v ++ " " ++ e.str
    | .output ts => " (" ++ " ".intercalate (ts.map CV.str) ++ ")"
    | .stop => "")
  let txt := " ".intercalate (conds.map flat) ++ " ==> " ++ " ".intercalate (acts.map flat)
  match prods.findIdx? (fun q => stdRep pp q == rep3) with
  | none => return (prods.push p3, names, s!"#PCT NEW {pname} {txt}")
  | some k =>
    let q := prods[k]!
    if q.userCreated || !E.P.ul then return (prods, names, s!"#PCT {p1.name} & {p2.name}: is {q.name}")
    else
      let u := q.u + E.P.alpha * (p1.u - q.u)
      return (prods.set! k { q with u := u }, names, s!"#PCT {p1.name} & {p2.name}: recreate {q.name}")

/-- `compile-productions`, called when production `i` has fired with instantiation `env`
at time `now`. -/
def compileFired (E : CompEnv) (C : CompState) (prods : Array Production)
    (names : List (String × Nat)) (now : Nat) (i : Nat) (env : Env) :
    CompState × Array Production × List (String × Nat) × List String :=
  let p := prods[i]!
  let first := fun (C : CompState) =>
    if p.valid1st then { C with prev := some (i, env), prevTime := now } else { C with prev := none }
  if !E.P.epl then (C, prods, names, [])
  else if !p.validForCompilation then ({ C with prev := none }, prods, names, [])
  else match C.prev with
    | none => (first C, prods, names, [])
    | some (j, e1) =>
      if now - C.prevTime > E.P.ttMs then (first C, prods, names, [])
      else
        let p1 := prods[j]!
        let key := (p1.name, p.name)
        let (ok, C) := match C.cache.lookup key with
          | some ok => (ok, C)
          | none =>
            let ok := composable E.trueName E.P.proc p1 p (compRep E.P.proc p1) (compRep E.P.proc p) e1 env
            (ok, { C with cache := (key, ok) :: C.cache })
        if !ok then (first C, prods, names, [s!"#PCT {p1.name} & {p.name}: cannot"])
        else
          let (prods, names, log) := composeProds E prods names j e1 i env
          (first C, prods, names, [log])

end ACTR
