import CMC.Meta
import ACTR.Sim
/-!
# ACT-R and the Common Model of Cognition

This file maps the state of the ACT-R model onto the working memory of the CMC with
metacognition (`CMC.Meta`) and records, as theorems, where ACT-R keeps the CMC's commitments
and where it departs from them. The last section states four candidate rules for the
retrieval result and two candidate mappings, and proves which combinations ACT-R satisfies
(provisional, for review by Christian Lebiere and the CMC authors). It does not yet build a `CMC.Meta.Arch` instance: the first
departure below shows that ACT-R cannot satisfy `Arch.select_respects_arch` as stated.

Mapping (OPEN: every line is a proposal for review)
* goal and imaginal buffer chunks → the region (`CMC.Base`: "ACT-R calls its version the
  imaginal buffer; earlier versions had a goal buffer");
* the retrieval buffer's chunk → the result part of the declarative buffer;
* the retrieval buffer's query flags (busy, error, failure, requested) → the declarative
  buffer's process data;
* the goal and imaginal flags → working-memory process data;
* the cue part of the declarative buffer is always empty: an ACT-R request is handed to the
  module and is never visible to productions;
* the visual-location and visual buffers → the content of the vision percept buffer, the
  aural-location and aural buffers → the content of the audition percept buffer, and the
  vision and audio module states → their process parts;
* the manual and vocal modules → the motor buffers: the command part is always empty (a
  `+manual>` request is handed to the module), and the preparation, processor and execution
  states are the process part.

Findings for the CMC (see the theorems and the notes at the end)
1. Productions remove and modify retrieval results (`clear_removes_result`).
2. A retrieval cue is not held in working memory.
3. ACT-R has explicit time: retrieval and production firing have durations, and "busy" is
   visible to productions. The CMC has no time.
4. Declarative learning is one mechanism triggered by clearing any buffer, and it serves
   both creation and tuning; retrieval itself changes nothing (`request_dm`).
5. No declarative content is ever forgotten (`ACTR.mergeDM_keeps`).
-/

namespace ACTR.Conform
open CMC.Meta

/-- ACT-R's perceptual modules. -/
inductive PMod where
  | vision | audition
  deriving DecidableEq

/-- ACT-R's motor modules. -/
inductive MMod where
  | manual | vocal
  deriving DecidableEq

/-- The CMC signature of the ACT-R modules modeled here: one declarative memory, vision and
audition, manual and vocal output. -/
@[reducible] def σA : Sig where
  Sym := String
  Val := Float
  PMod := PMod
  MMod := MMod
  DMem := Unit
  Input := Unit
  PLearn := Unit
  MLearn := Unit
  Output := Unit
  MK := Fin 3
  utilityK := 0
  frequencyK := 1
  recencyK := 2
  epi := ()

/-- A chunk in a buffer as CMC relations: one relation per slot, `slot(buffer, value)`. -/
def encChunk (tag : String) (c : Option Chunk) : List (Elem σA) :=
  match c with
  | none => []
  | some c => c.slots.map fun p => ⟨⟨p.1, [tag, p.2.show]⟩, fun _ => none⟩

/-- A buffer's query flags as symbolic process data: the module's busy and error states and
the buffer's failure and requested flags. -/
def encFlags (s : St) (b : Buf) : List (Elem σA) :=
  let q := s.qstate
  [("busy", q.busy b), ("error", q.error b), ("failure", (s.bufs b).failure),
   ("requested", (s.bufs b).requested)].filterMap
    fun p => if p.2 then some ⟨⟨p.1, [b.name]⟩, fun _ => none⟩ else none

/-- The CMC working memory of an ACT-R state. -/
def enc (s : St) : WM σA
  | .region => encChunk "goal" (s.bufs .goal).chunk ++ encChunk "imaginal" (s.bufs .imaginal).chunk
  | .decl () .result => encChunk "retrieval" (s.bufs .retrieval).chunk
  | .decl () .process => encFlags s .retrieval
  | .wmProcess => encFlags s .goal ++ encFlags s .imaginal
  | .percept .vision .content =>
    encChunk "visual-location" (s.bufs .visualLocation).chunk ++ encChunk "visual" (s.bufs .visual).chunk
  | .percept .vision .process => encFlags s .visualLocation ++ encFlags s .visual
  | .percept .audition .content =>
    encChunk "aural-location" (s.bufs .auralLocation).chunk ++ encChunk "aural" (s.bufs .aural).chunk
  | .percept .audition .process => encFlags s .auralLocation ++ encFlags s .aural
  | .motor .manual .process => encFlags s .manual
  | .motor .vocal .process => encFlags s .vocal
  | _ => []

/-- **Departure 1: productions remove retrieval results.** Clearing the retrieval buffer,
which every production that tests it does by strict harvesting unless it modifies it, and
which `-retrieval>` and `+retrieval>` do explicitly, empties the result part of the
declarative buffer. `CMC.Base` requires that "only retrieval changes results"
(`select_respects_results`) and `CMC.Meta` that a deliberate act leaves every
architecture-written location unchanged (`select_respects_arch`). Soar departs from this by
adding to results; ACT-R departs by removing them (and, with `=retrieval>`, by modifying
them). -/
theorem clear_removes_result (s : St) (c : Chunk) (h : (s.bufs .retrieval).chunk = some c)
    (hne : c.slots ≠ []) :
    enc (clearBuf' s .retrieval) (.decl () .result) ≠ enc s (.decl () .result) := by
  have h1 : enc (clearBuf' s .retrieval) (.decl () .result) = [] := by
    simp [enc, encChunk, clearBuf_empty]
  have h2 : enc s (.decl () .result) ≠ [] := by
    simp [enc, encChunk, h, hne]
  rw [h1]; exact fun e => h2 e.symm

/-- The retrieval result is a location the CMC reserves for the architecture. -/
theorem result_is_arch_written : (Loc.decl () DPart.result : L σA).archWritten = true := rfl

/-- **Kept, with a qualification: clearing one buffer leaves the chunks in the others.**
Clearing the goal or imaginal buffer never removes or replaces the retrieved chunk. But when
the cleared chunk merges with one already in declarative memory, ACT-R (with `:dcnn t`)
renames every reference to it, so a slot value of the retrieved chunk can change: the
result's identity is kept, not necessarily its content. -/
theorem clear_other_keeps_result (s : St) (b : Buf) (h : b ≠ .retrieval) :
    ((clearBuf' s b).bufs .retrieval).chunk.map (·.name) = (s.bufs .retrieval).chunk.map (·.name) :=
  clearBuf_other s b .retrieval (fun e => h e.symm)

/-- **Kept: the cue area is never used.** (Finding 2.) -/
theorem cue_empty (s : St) : enc s (.decl () .cue) = [] := rfl

/-- **Departure: motor commands are not held in working memory.** A `+manual>` or `+vocal>`
request goes to the module when the production fires; the motor buffers' command parts are
always empty, and only the module states (preparation, processor, execution) are visible. -/
theorem motor_command_empty (s : St) (m : MMod) : enc s (.motor m .command) = [] := by
  cases m <;> rfl

/-!
## Notes on the other findings

3. *Time.* `St.now`, the event queue, `:dat`, the retrieval-time equation and
   `:imaginal-delay` have no counterpart in `CMC.Meta.State`. The CMC's `cycleMs := 50` is
   an annotation; in ACT-R the 50 ms is the gap between `production-selected` and
   `production-fired`, during which other modules' events run. A CMC `cycle` step
   corresponds to the pair (conflict resolution, production fired), and a `retrieve` step to
   the pair (start-retrieval, retrieved-chunk) with other steps in between.
4. *Declarative learning.* `clearBuf` is the only place declarative memory changes. It adds
   a chunk (`declCreate`) or adds a reference to an existing chunk (`declTune`), and it is
   triggered by a procedural action or by a module, not by a separate learning step after
   the cycle. Retrieval does not touch the memory (`request_dm`), so `CMC.Meta`'s
   `retrieveTouch` is the identity for ACT-R: a retrieved chunk is strengthened only when it
   is later cleared from the buffer.
5. *Forgetting.* The CMC's `forgetDecl` step never applies: `forgettable` is constantly
   false for ACT-R. A chunk whose activation is below the threshold cannot be retrieved but
   is still in memory.
6. *Goals.* `CMC.Base` says goals are content, not architecture. In ACT-R 7 the goal buffer
   belongs to a goal module that accepts requests, and by default it spreads no activation
   (`:ga 0`), while the imaginal buffer does.
7. *Procedural learning.* Utility learning changes only `Production.u` (`propagateReward`), as
   `rlTune_only_utility` requires. Production compilation (the CMC's `compose`) is not yet
   modeled.
8. *Perception.* Buffer stuffing puts a visual or aural location into its buffer without a
   request, and the vision module re-encodes the attended object when the display changes:
   perception writes the percept buffers on its own schedule, as the CMC requires, but
   attention (`+visual>`, `+aural>`) is a request from procedural memory that the module
   carries out later.
-/

/-!
## Candidate rules and mappings for the retrieval result (provisional, 2026-11-12)

OPEN (for Christian Lebiere and the CMC authors): which rule the CMC should state for
declarative results, and which mapping of ACT-R's retrieval buffer is the right one. Nothing
below decides either; each combination is a theorem, so the choice can be made on the facts.

Rules, on the symbolic content of the result area before and after a procedural operation:
* `Strict`: unchanged (`CMC.Base`, `CMC.Meta`: only retrieval writes results);
* `AddOnly`: nothing removed (`CMC.Proc.Keeps`, the form adopted for Soar);
* `RemoveOnly`: nothing added or changed;
* `NoOrigin`: an empty result stays empty (provenance only: procedural processing may change
  or remove a result that retrieval produced, but cannot create one).

Mappings:
* A (`enc`, above): the chunk in the retrieval buffer is the declarative result.
* B (`encB`): the chunk in the retrieval buffer is a working-memory copy, in the region with
  the goal and imaginal chunks; the result proper is the chunk in declarative memory, which
  productions cannot reach, so the result area of working memory is unused, as the cue area is.
-/

abbrev Rels := List (Rel σA)

def Strict (b a : Rels) : Prop := a = b
def AddOnly (b a : Rels) : Prop := ∀ r ∈ b, r ∈ a
def RemoveOnly (b a : Rels) : Prop := ∀ r ∈ a, r ∈ b
def NoOrigin (b a : Rels) : Prop := b = [] → a = []

/-- The result area under mapping A, as a function of the retrieval buffer's chunk. -/
def resultOf (c : Option Chunk) : Rels := (encChunk "retrieval" c).map Elem.rel

/-- Mapping A's result area is `resultOf` of the retrieval buffer's chunk. -/
theorem enc_result (s : St) :
    (enc s (.decl () .result)).map Elem.rel = resultOf (s.bufs .retrieval).chunk := rfl

/-! ### Mapping A: the three procedural operations on the retrieval buffer -/

/-- **Clearing** (strict harvesting, `-retrieval>`, the clear before `+retrieval>`): the
result becomes empty. -/
theorem clear_result (s : St) : resultOf ((clearBuf' s .retrieval).bufs .retrieval).chunk = [] := by
  simp [resultOf, encChunk, clearBuf_empty]

/-- Clearing satisfies `RemoveOnly`. -/
theorem clear_removeOnly (s : St) :
    RemoveOnly (resultOf (s.bufs .retrieval).chunk) (resultOf ((clearBuf' s .retrieval).bufs .retrieval).chunk) := by
  rw [clear_result]; intro r hr; cases hr

/-- Clearing satisfies `NoOrigin`. -/
theorem clear_noOrigin (s : St) :
    NoOrigin (resultOf (s.bufs .retrieval).chunk) (resultOf ((clearBuf' s .retrieval).bufs .retrieval).chunk) := by
  intro _; exact clear_result s

/-- Clearing breaks `AddOnly` (and so `Strict`) whenever the retrieved chunk has a slot. -/
theorem clear_not_addOnly (s : St) (c : Chunk) (h : (s.bufs .retrieval).chunk = some c)
    (hne : c.slots ≠ []) :
    ¬ AddOnly (resultOf (s.bufs .retrieval).chunk) (resultOf ((clearBuf' s .retrieval).bufs .retrieval).chunk) := by
  rw [clear_result, h]
  intro hk
  cases hs : c.slots with
  | nil => exact hne hs
  | cons p ps =>
    have := hk ⟨p.1, ["retrieval", p.2.show]⟩ (by simp [resultOf, encChunk, hs])
    cases this

/-- **Modification** (`=retrieval>` with slots; [Src] `mod-buffer-chunk`): the chunk in the
buffer is changed in place. -/
def modResult (c : Option Chunk) (sets : List (Slot × Option Val)) : Option Chunk :=
  c.map fun c => sets.foldl (fun c x => c.set x.1 x.2) c

/-- Modification satisfies `NoOrigin`: it cannot create a result. -/
theorem modify_noOrigin (sets : List (Slot × Option Val)) :
    NoOrigin (resultOf none) (resultOf (modResult none sets)) := by
  intro _; rfl

/-- Modification breaks `RemoveOnly`: changing a slot's value adds a relation that was not
there. -/
theorem modify_not_removeOnly :
    ¬ RemoveOnly (resultOf (some ⟨"C", [("A", .sym "X")]⟩))
        (resultOf (modResult (some ⟨"C", [("A", .sym "X")]⟩) [("A", some (.sym "Y"))])) := by
  intro h
  have := h ⟨"A", ["retrieval", "Y"]⟩ (by simp [resultOf, encChunk, modResult, Chunk.set, Val.show])
  simp [resultOf, encChunk, Val.show] at this

/-- Modification breaks `AddOnly`: the old value's relation is gone. -/
theorem modify_not_addOnly :
    ¬ AddOnly (resultOf (some ⟨"C", [("A", .sym "X")]⟩))
        (resultOf (modResult (some ⟨"C", [("A", .sym "X")]⟩) [("A", some (.sym "Y"))])) := by
  intro h
  have := h ⟨"A", ["retrieval", "X"]⟩ (by simp [resultOf, encChunk, Val.show])
  simp [resultOf, encChunk, modResult, Chunk.set, Val.show] at this

/-- **Overwriting** (`@retrieval>`; [Src] `overwrite-buffer-chunk`): the buffer then holds a
chunk with the source's slots, whatever it held before. -/
theorem overwrite_slots (s : St) (b : Buf) (src : Chunk) (fromSpec req : Bool) :
    ((putInBuffer s b src fromSpec req (clear := false)).bufs b).chunk.map (·.slots) = some src.slots := by
  simp only [putInBuffer]
  simp [St.setBuf, upd_same]

/-- Overwriting breaks `NoOrigin`: a production can put a chunk in an empty retrieval buffer
that no retrieval produced. -/
theorem overwrite_not_noOrigin (s : St) (src : Chunk) (fromSpec req : Bool)
    (he : (s.bufs .retrieval).chunk = none) (hne : src.slots ≠ []) :
    ¬ NoOrigin (resultOf (s.bufs .retrieval).chunk)
        (resultOf ((putInBuffer s .retrieval src fromSpec req (clear := false)).bufs .retrieval).chunk) := by
  intro h
  have h1 := h (by simp [he, resultOf, encChunk])
  have h2 := overwrite_slots s .retrieval src fromSpec req
  cases hc : ((putInBuffer s .retrieval src fromSpec req (clear := false)).bufs .retrieval).chunk with
  | none => simp [hc] at h2
  | some c =>
    simp [hc] at h2
    simp [hc, resultOf, encChunk, h2] at h1
    exact hne h1

/-! ### Mapping B: the retrieval buffer's chunk is a working-memory copy -/

/-- Mapping B: as `enc`, but the retrieval buffer's chunk is in the region and the result
area is unused. -/
def encB (s : St) : WM σA
  | .region => enc s .region ++ encChunk "retrieval" (s.bufs .retrieval).chunk
  | .decl () .result => []
  | ℓ => enc s ℓ

/-- Under mapping B every rule holds for any change of state whatever: the result area is
always empty. The retrieved chunk is ordinary working-memory content, which procedural
memory may change. -/
theorem encB_strict (s s' : St) :
    Strict ((encB s (.decl () .result)).map Elem.rel) ((encB s' (.decl () .result)).map Elem.rel) := rfl

/-- The region is not an architecture-written location, so no rule constrains it. -/
theorem region_not_arch_written : (Loc.region : L σA).archWritten = false := rfl

end ACTR.Conform
