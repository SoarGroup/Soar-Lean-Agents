/-!
# ACT-R 7 in Lean — chunks, buffers and the production language

Sources
* [RM] Bothell, D. *ACT-R 7.26+ Reference Manual* (docs/reference-manual.pdf in the ACT-R
  distribution). Section names refer to this manual.
* [Src] The ACT-R 7 Lisp sources: framework/ (buffers.lisp, meta-process.lisp,
  scheduling.lisp, naming-module.lisp), core-modules/ (declarative-memory.lisp,
  procedural.lisp, goal.lisp, imaginal.lisp) and support/production-parsing.lisp. Function
  names refer to these files.
* [Tut] The ACT-R tutorial (tutorial/ in the distribution).

Conventions (as in the CMC and Soar files)
* Every definition that models ACT-R names the ACT-R function(s) it follows.
* `SIMPLIFIED:` marks a place where the model is deliberately coarser than ACT-R.
* `NOT MODELED:` marks a mechanism left out.
* `OPEN:` marks a question for review.

Scope: the goal, imaginal (with the imaginal-action buffer), declarative and procedural
modules, with variable slot names (dynamic pattern matching); vision, audition, manual output
(keyboard and mouse) and vocal output; utility learning and its trace; partial matching;
production compilation (ACTR/Compile.lean); the temporal module; the blending module of
extras/blending; the event scheduler that connects them; and replay of the tutorial's Lisp
task code (ACTR/Sim.lean, "The task"; `:sim-hook` results are replayed as ACT-R computed
them, and `:utility-hook`, `:cycle-hook` and `:retrieved-chunk-hook` given as task commands
are called as ACT-R calls them). The expressions of `!eval!`, `!bind!` and `!mv-bind!` (on
either side) are evaluated with Common Lisp's numbers (integers, ratios, single floats) and
the functions listed in `Expr.evalM`. NOT MODELED: other hooks written in Lisp, visual
tracking, the cursor in the visicon (`:process-cursor`), joysticks, more than one model, and
Lisp in expressions beyond `Expr.evalM` and calls of task commands. Models that use any of
these are reported as unsupported rather than run.
-/

namespace ACTR

/-- Point update of a function. -/
def upd {α β : Type} [DecidableEq α] (f : α → β) (a : α) (v : β) : α → β :=
  fun x => if x = a then v else f x

theorem upd_same {α β : Type} [DecidableEq α] (f : α → β) (a : α) (v : β) :
    upd f a v a = v := by simp [upd]

theorem upd_other {α β : Type} [DecidableEq α] (f : α → β) (a : α) (v : β) {x : α}
    (h : x ≠ a) : upd f a v x = f x := by simp [upd, h]

/-! ## Values and chunks -/

/-- A slot value: a symbol (every symbol used as a slot value names a chunk in ACT-R 7), a
number, or a string. Numbers keep the text they are printed with. -/
inductive Val where
  | sym (s : String)
  | num (x : Float) (txt : String)
  | str (s : String)
  deriving Inhabited, Repr

/-- Equality of slot values ([Src] `chunk-slot-equal`): numbers by value. -/
def Val.beq : Val → Val → Bool
  | .sym a, .sym b => a == b
  | .num a _, .num b _ => a == b
  | .str a, .str b => a.toLower == b.toLower
  | _, _ => false

instance : BEq Val := ⟨Val.beq⟩

/-- How Lisp's `princ` prints a value (used by `!output!`). -/
def Val.show : Val → String
  | .sym s => s
  | .num _ t => t
  | .str s => s

/-- How `~s` prints a value (used in the state dump). -/
def Val.repr : Val → String
  | .str s => "\"" ++ s ++ "\""
  | v => v.show

abbrev Slot := String

/-- A variable slot name (dynamic pattern matching) is written `=x` in a slot position. -/
def isVarSlot (sl : Slot) : Bool := sl.startsWith "="

/-- A chunk: a name and its filled slots. A slot whose value is `nil` does not exist
([RM] "Chunks"). -/
structure Chunk where
  name : String
  slots : List (Slot × Val)
  deriving Inhabited, Repr

namespace Chunk

def get (c : Chunk) (s : Slot) : Option Val := c.slots.lookup s

/-- Set a slot; `none` removes it. -/
def set (c : Chunk) (s : Slot) (v : Option Val) : Chunk :=
  let rest := c.slots.filter (fun p => p.1 != s)
  match v with
  | none => { c with slots := rest }
  | some v =>
    if c.slots.any (fun p => p.1 == s) then
      { c with slots := c.slots.map (fun p => if p.1 == s then (s, v) else p) }
    else { c with slots := c.slots ++ [(s, v)] }

def sub (a b : Chunk) : Bool := a.slots.all (fun p => b.get p.1 == some p.2)

/-- Value identity in the merge table (`equal` on `hash-chunk-contents`): numbers by `eql`,
so an integer and a float differ; strings ignoring case. -/
def Val.same : Val → Val → Bool
  | .num a t, .num b u => a == b && (t.contains '.' == u.contains '.')
  | .str a, .str b => a.toUpper == b.toUpper
  | a, b => a == b

def subSame (a b : Chunk) : Bool :=
  a.slots.all (fun p => match b.get p.1 with | some v => Val.same p.2 v | none => false)

/-- Two chunks have the same content: the test `merge-chunk-into-dm` makes through
`hash-chunk-contents`. -/
def sameContent (a b : Chunk) : Bool := subSame a b && subSame b a

end Chunk

/-! ## Buffers -/

/-- The buffers of the modules modeled here. -/
inductive Buf where
  | goal | imaginal | retrieval
  | visualLocation | visual | manual | vocal | auralLocation | aural
  /-- The buffer of the blending module (extras/blending). -/
  | blending
  /-- The imaginal module's action buffer. -/
  | imaginalAction
  /-- The temporal module's buffer (modules/temporal.lisp). -/
  | temporal
  deriving DecidableEq, Repr, Inhabited

def Buf.name : Buf → String
  | .goal => "GOAL" | .imaginal => "IMAGINAL" | .retrieval => "RETRIEVAL"
  | .visualLocation => "VISUAL-LOCATION" | .visual => "VISUAL" | .manual => "MANUAL"
  | .vocal => "VOCAL" | .auralLocation => "AURAL-LOCATION" | .aural => "AURAL"
  | .blending => "BLENDING" | .imaginalAction => "IMAGINAL-ACTION" | .temporal => "TEMPORAL"

def Buf.all : List Buf :=
  [.goal, .imaginal, .retrieval, .visualLocation, .visual, .manual, .vocal, .auralLocation, .aural,
   .blending, .imaginalAction, .temporal]

def Buf.ofName? (s : String) : Option Buf := Buf.all.find? (·.name == s)

/-- A buffer: at most one chunk, the failure flag and the requested flag
([Src] `act-r-buffer`). -/
structure BufSt where
  chunk : Option Chunk := none
  failure : Bool := false
  requested : Bool := false
  deriving Inhabited, Repr

/-! ## Productions -/

/-- A term in a production: a constant or a variable (`=x`, stored without the `=`). -/
inductive Term where
  | const (v : Val)
  | var (x : String)
  deriving Inhabited, Repr

/-- Slot modifiers ([RM] "p": `=` is the default, then `-`, `<`, `>`, `<=`, `>=`). -/
inductive Cmp where
  | eq | ne | lt | gt | le | ge
  deriving DecidableEq, Repr, Inhabited

/-- A slot test or slot specification. `arg := none` stands for `nil`. -/
structure SlotTest where
  cmp : Cmp := .eq
  slot : Slot
  arg : Option Term
  deriving Repr, Inhabited

/-- A query test `[-] slot value`, e.g. `state free` or `- buffer full`. -/
structure QTest where
  neg : Bool := false
  slot : String
  val : String
  deriving Repr, Inhabited

/-- A Lisp expression in `!eval!`, `!bind!` or `!safe-eval!` ([RM] "p", "!eval!"). Only the
functions tutorial models use are modeled (`Expr.evalPure`); a list whose head is a string
calls an ACT-R command, which here is a command of the task code. -/
inductive Expr where
  | lit (v : Option Val)
  | var (x : String)
  | app (f : String) (args : List Expr)
  | cmd (name : String) (args : List Expr)
  deriving Repr, Inhabited

/-- A condition: a buffer test (`=buffer>`), a query (`?buffer>`), or `!eval!` /
`!safe-eval!`, which holds when the expression is not `nil`. -/
inductive Cond where
  | buf (b : Buf) (tests : List SlotTest)
  | query (b : Buf) (qs : List QTest)
  | eval (e : Expr)
  deriving Repr, Inhabited

/-- An action. -/
inductive Action where
  /-- `=buffer>`: modify the chunk in the buffer. -/
  | modify (b : Buf) (sets : List (Slot × Option Term))
  /-- `+buffer>`: a request to the buffer's module. -/
  | request (b : Buf) (spec : List SlotTest)
  /-- `*buffer>`: a modification request to the buffer's module. -/
  | modRequest (b : Buf) (sets : List (Slot × Option Term))
  /-- `+buffer> chunk`: a request built from a chunk's slots. -/
  | directRequest (b : Buf) (c : Term)
  /-- `-buffer>`: clear the buffer. -/
  | clear (b : Buf)
  /-- `@buffer>` with nothing after it: erase the buffer's chunk without clearing it (the
  chunk does not go to declarative memory). -/
  | erase (b : Buf)
  /-- `@buffer> chunk` or `@buffer> slot value …`: put a chunk (a copy of the named one, or one
  made from the specification) in the buffer without clearing it ([Src]
  `schedule-overwrite-buffer-chunk`). -/
  | overwrite (b : Buf) (c : Option Term) (spec : List SlotTest)
  /-- `!output!`. -/
  | output (ts : List Term)
  /-- `!stop!`. -/
  | stop
  /-- `!eval!` / `!safe-eval!`: evaluate for effect. -/
  | eval (e : Expr)
  /-- `!bind!`: bind a variable to the value of an expression. -/
  | bind (x : String) (e : Expr)
  deriving Repr, Inhabited

/-- A token of a `!…!` statement as written: text, or a variable. -/
inductive PTok where
  | lit (s : String)
  | var (x : String)
  deriving Repr, Inhabited

/-- A statement of a production as written, for `print-production-text`. -/
inductive PStmt where
  | cond (c : Cond)
  | act (a : Action)
  /-- `!name!` and its definition as tokens. -/
  | bang (name : String) (toks : List PTok)
  deriving Repr, Inhabited

/-- `!bind!`, `!safe-bind!` or `!mv-bind!` on the left-hand side: the variables bound, the
variables the expression uses, the expression, and whether it binds several values. -/
structure LBind where
  vars : List String
  deps : List String
  e : Expr
  mv : Bool := false
  safe : Bool := false
  deriving Repr, Inhabited

/-- `sort-for-bind-order` ([Src] production-parsing.lisp): in the written order, each entry
whose key (the variables it binds) some entry already placed depends on goes just before the
first such entry; the others go last. An entry with no key is never moved forward. -/
def sortForBindOrder {α : Type} (xs : List (Option (List String) × List String × α)) :
    List (Option (List String) × List String × α) :=
  xs.foldl (fun res x =>
    match x.1 with
    | some ks =>
      match res.findIdx? (fun y => y.2.1.any ks.contains) with
      | some i => res.take i ++ [x] ++ res.drop i
      | none => res ++ [x]
    | none => res ++ [x]) []

structure Production where
  name : String
  lhs : List Cond
  rhs : List Action
  /-- Utility ([RM] "Utility"; `spp :u`), a single float as in ACT-R under SBCL. -/
  u : Float32 := 0.0
  /-- Reward triggered when the production fires (`spp :reward`), with its printed form. -/
  reward : Option (Float32 × String) := none
  /-- Action time in ms (`spp :at`); `:dat` when not set. -/
  actTime : Option Nat := none
  /-- The statements as written ([Src] `production-lhs`, `production-rhs`), for the
  conflict-set trace; the `!…!` conditions come first. -/
  lhsText : List PStmt := []
  rhsText : List PStmt := []
  /-- The documentation string: `"P1 & P2"` for a production made by compilation. -/
  doc : Option String := none
  /-- Defined by the model rather than made by production compilation
  ([Src] `production-user-created`). -/
  userCreated : Bool := true
  /-- Uses `!eval!` or `!bind!` (not the `safe` forms), which keeps it out of production
  compilation ([Src] `valid-compilation-production`). -/
  unsafeBang : Bool := false
  /-- Left-hand side `!bind!`s in the order they are evaluated ([Src] `sort-for-bind-order`). -/
  lhsBinds : List LBind := []
  deriving Repr, Inhabited

def Action.target? : Action → Option Buf
  | .modify b _ | .request b _ | .clear b | .modRequest b _ | .directRequest b _ | .erase b
  | .overwrite b _ _ => some b
  | _ => none

def Cond.buf? : Cond → Option Buf
  | .buf b _ | .query b _ => some b
  | .eval _ => none

partial def Expr.vars : Expr → List String
  | .var x => [x]
  | .app _ as | .cmd _ as => as.foldl (fun acc a => acc ++ a.vars) []
  | .lit _ => []

/-! ### What a production does besides its written actions ([Src] `p-fct`,
support/production-parsing.lisp) -/

/-- Module parameters of the procedural module that change the implicit actions.
Defaults are those set when the goal and declarative modules are reset: `:do-not-harvest
goal`, `:do-not-query goal` and `:do-not-query retrieval` ([Src] `goal-reset`,
`reset-declarative-module`). -/
structure ProcParams where
  doNotHarvest : List Buf := [.goal, .temporal]
  doNotQuery : List Buf := [.goal, .retrieval, .visualLocation, .temporal]
  deriving Repr

/-- Strict safety: a `state free` query is added for every buffer that receives a request
and has no query on the left-hand side, unless the buffer is in `:do-not-query`
([Src] `p-fct`, "Add explicit state free queries"). -/
def implicitQueries (pp : ProcParams) (p : Production) : List Buf :=
  (p.rhs.filterMap fun a => match a with
    | .request b _ | .modRequest b _ | .directRequest b _ => some b | _ => none).filter fun b =>
    !pp.doNotQuery.contains b &&
    !(p.lhs.any fun c => match c with | .query b' _ => b' == b | _ => false)

/-- The conditions actually tested: the written ones, then the implicit queries. -/
def Production.allConds (pp : ProcParams) (p : Production) : List Cond :=
  p.lhs ++ (implicitQueries pp p).map fun b => .query b [⟨false, "STATE", "FREE"⟩]

/-- A buffer is strictly harvested when a production tests its chunk, or queries it for
`buffer failure`, and does not name the buffer in any action, unless it is in
`:do-not-harvest` ([RM] "strict harvesting"; [Src] `p-fct`, "Add the implicit clears for
strict harvesting"). -/
def harvested (pp : ProcParams) (p : Production) : List Buf :=
  p.lhs.filterMap fun c =>
    let b? := match c with
      | .buf b _ => some b
      | .query b qs => if qs.any (fun q => !q.neg && q.slot == "BUFFER" && q.val == "FAILURE")
                       then some b else none
      | .eval _ => none
    match b? with
    | some b => if pp.doNotHarvest.contains b || p.rhs.any (·.target? == some b) then none
                else some b
    | none => none

/-- Request clearing: every buffer with a request and no explicit clear is cleared
([RM] "request clearing"; [Src] `p-fct`, "Add the implicit clears for requests"). -/
def requestCleared (p : Production) : List Buf :=
  p.rhs.filterMap fun a => match a with
    | .request b _ | .directRequest b _ =>
      if p.rhs.any (fun a' => match a' with | .clear b' => b' == b | _ => false) then none
      else some b
    | _ => none

/-- Every variable a production mentions. -/
def Production.vars (p : Production) : List String :=
  let tv : Option Term → List String := fun t => match t with | some (.var x) => [x] | _ => []
  -- a variable slot name comes before its value
  let sv : Slot → List String := fun sl => if isVarSlot sl then [(sl.drop 1).toString] else []
  let ts : List SlotTest → List String := fun ts => ts.foldl (fun acc t => acc ++ sv t.slot ++ tv t.arg) []
  p.lhs.foldl (fun acc c => match c with
    | .buf _ t => acc ++ ts t | .eval e => acc ++ e.vars | _ => acc) [] ++
  p.rhs.foldl (fun acc a => match a with
    | .modify _ s | .modRequest _ s => acc ++ s.foldl (fun a2 x => a2 ++ sv x.1 ++ tv x.2) []
    | .request _ s => acc ++ ts s
    | .directRequest _ t => acc ++ tv (some t)
    | .overwrite _ c s => acc ++ tv c ++ ts s
    | .output o => acc ++ o.foldl (fun a2 t => a2 ++ tv (some t)) []
    | .eval e => acc ++ e.vars
    | .bind x e => acc ++ x.splitOn " " ++ e.vars
    | _ => acc) [] ++
  p.lhsBinds.foldl (fun acc b => acc ++ b.vars ++ b.deps) []

/-- `p-fct`'s check that every variable is bound: a variable slot name of a condition by a
buffer variable or a slot named by a constant; the other variables of the conditions by
those, or by the value of a variable slot name; those of the actions also by `!bind!`. -/
def Production.wellBound (p : Production) : Bool :=
  let fixed := p.lhs.foldl (fun acc c => match c with
    | .buf b ts => acc ++ b.name :: ts.filterMap fun t => match t.cmp, t.arg with
        | .eq, some (.var x) => if isVarSlot t.slot then none else some x
        | _, _ => none
    | _ => acc) []
  let slotVar := fun (t : SlotTest) => (t.slot.drop 1).toString
  let lhsSlotVars := p.lhs.foldl (fun acc c => match c with
    | .buf _ ts => acc ++ (ts.filter (isVarSlot ·.slot)).map slotVar
    | _ => acc) []
  let viaSlots := p.lhs.foldl (fun acc c => match c with
    | .buf _ ts => acc ++ ts.filterMap fun t => match t.cmp, t.arg with
        | .eq, some (.var x) => if isVarSlot t.slot && fixed.contains (slotVar t) then some x else none
        | _, _ => none
    | _ => acc) []
  let bound := fixed ++ viaSlots ++ p.lhsBinds.flatMap (·.vars)
  let binds := p.rhs.flatMap fun a => match a with | .bind x _ => x.splitOn " " | _ => []
  let lhsVars := p.lhs.foldl (fun acc c => match c with
    | .buf _ ts => acc ++ ts.flatMap fun t =>
        (if isVarSlot t.slot then [slotVar t] else []) ++ (match t.arg with | some (.var x) => [x] | _ => [])
    | .eval e => acc ++ e.vars
    | _ => acc) [] ++ p.lhsBinds.flatMap (·.deps)
  lhsSlotVars.all fixed.contains && lhsVars.all bound.contains &&
    p.vars.all fun x => bound.contains x || binds.contains x

/-- Buffers whose variable (`=goal` for the goal buffer) a production uses outside the
buffer test. Such buffers hold copies of chunks rather than a reused chunk, because the
chunk's name is then meaningful to the model ([RM] "Buffer variable usage";
[Src] `buffer-requires-copies`). -/
def copyBuffers (prods : List Production) : List Buf :=
  Buf.all.filter fun b => b == .visualLocation || prods.any fun p =>
    (p.lhs.any fun c => match c with | .buf b' _ => b' == b | _ => false) &&
    p.vars.contains b.name

/-! ## Matching -/

abbrev Env := List (String × Val)

/-- A slot test with its variables replaced by values. -/
structure ITest where
  cmp : Cmp
  slot : Slot
  arg : Option Val
  deriving Repr, Inhabited

def cmpVal : Cmp → Val → Val → Bool
  | .eq, a, b => a == b
  | .ne, a, b => !(a == b)
  | .lt, .num a _, .num b _ => a < b
  | .gt, .num a _, .num b _ => a > b
  | .le, .num a _, .num b _ => a ≤ b
  | .ge, .num a _, .num b _ => a ≥ b
  | _, _, _ => false

/-- Whether a chunk passes an instantiated slot test ([RM] "p", slot tests). A test against
`nil` tests that the slot is empty (`=`) or filled (`-`); `-` with a value holds when the
slot is empty or holds another value; the relational tests need two numbers. The tested
value is the chunk's value (`<` holds when the chunk's value is below the argument). -/
def ITest.holds (c : Chunk) (t : ITest) : Bool :=
  match t.arg, c.get t.slot with
  | none, none => t.cmp == .eq
  | none, some _ => t.cmp == .ne
  | some _, none => t.cmp == .ne
  | some v, some w => cmpVal t.cmp w v


/-- The slot a slot position names: a variable slot name is the name its variable is bound
to (a symbol). -/
def resolveSlot (env : Env) (sl : Slot) : Option Slot :=
  if isVarSlot sl then
    match env.lookup (sl.drop 1).toString with
    | some (.sym n) => some n
    | _ => none
  else some sl

def SlotTest.inst (env : Env) (t : SlotTest) : Option ITest := do
  let sl ← resolveSlot env t.slot
  match t.arg with
  | none => some ⟨t.cmp, sl, none⟩
  | some (.const v) => some ⟨t.cmp, sl, some v⟩
  | some (.var x) => (env.lookup x).map fun v => ⟨t.cmp, sl, some v⟩

/-- Bind the variables of `=` tests against the slots of a chunk. A variable cannot bind
to `nil` ([RM] "p"). -/
def bindTests (c : Chunk) : Env → List SlotTest → Option Env
  | env, [] => some env
  | env, t :: ts =>
    -- variable slot names bind in a second step (`bindVarSlots`)
    if isVarSlot t.slot then bindTests c env ts else
    match t.cmp, t.arg with
    | .eq, some (.var x) =>
      match env.lookup x with
      | some _ => bindTests c env ts
      | none =>
        match c.get t.slot with
        | some v => bindTests c ((x, v) :: env) ts
        | none => none
    | _, _ => bindTests c env ts

/-- The second step of binding ([Src] production-parsing.lisp, `bind-var-slot`): an `=`
test of a variable slot name binds its value variable, if no other condition bound it, to
the value of the slot the name's variable is bound to. -/
def bindVarSlots (c : Chunk) : Env → List SlotTest → Option Env
  | env, [] => some env
  | env, t :: ts =>
    if !isVarSlot t.slot then bindVarSlots c env ts else
    match t.cmp, t.arg with
    | .eq, some (.var x) =>
      match env.lookup x with
      | some _ => bindVarSlots c env ts
      | none =>
        match (resolveSlot env t.slot).bind c.get with
        | some v => bindVarSlots c ((x, v) :: env) ts
        | none => none
    | _, _ => bindVarSlots c env ts

/-- The module states the queries read. -/
structure QState where
  /-- `state busy` of each buffer's module. -/
  busy : Buf → Bool
  /-- `state error` of each buffer's module. -/
  error : Buf → Bool
  /-- Other queries of the perceptual and motor modules (`preparation free`,
  `attended new`, …). -/
  other : Buf → String → String → Bool := fun _ _ _ => false

/-- A query ([Src] `query-buffer`): `buffer empty` is false while the failure flag is set,
and `buffer requested`/`unrequested` hold only when the buffer has a chunk or a failure. -/
def QTest.holds (bs : BufSt) (qs : QState) (b : Buf) (q : QTest) : Bool :=
  let full := bs.chunk.isSome
  let r := match q.slot, q.val with
    | "BUFFER", "FULL" => full
    | "BUFFER", "EMPTY" => !full && !bs.failure
    | "BUFFER", "FAILURE" => bs.failure
    | "BUFFER", "REQUESTED" => (full || bs.failure) && bs.requested
    | "BUFFER", "UNREQUESTED" => (full || bs.failure) && !bs.requested
    | "STATE", "FREE" => !qs.busy b
    | "STATE", "BUSY" => qs.busy b
    | "STATE", "ERROR" => qs.error b
    | "MODALITY", "FREE" => !qs.busy b
    | "MODALITY", "BUSY" => qs.busy b
    -- `error t`/`error nil` is `state error` ([Src] `query-module`)
    | "ERROR", v => if v == "NIL" then !qs.error b else qs.error b
    | sl, v => qs.other b sl v
  r != q.neg

/-! ## Lisp expressions -/

def Val.isInt : Val → Bool
  | .num _ t => !(t.contains '.' || t.contains 'e' || t.contains 'E' || t.contains '/')
  | _ => false

/-- An integer value. -/
def Val.ofInt (i : Int) : Val := .num (Float.ofInt i) (toString i)

/-- Digits of a single float as SBCL prints it: the fewest significant digits that read
back as the same single float, in fixed notation between 1e-3 and 1e7 and `d.ddde±x`
outside. -/
def f32Text (x : Float32) : String := Id.run do
  let d := x.toFloat
  if d == 0.0 then return (if 1.0 / d < 0.0 then "-0.0" else "0.0")
  let a := Float.abs d
  let e := (Float.floor (Float.log10 a)).toInt64.toInt
  let mut digits := ""
  let mut ee := e
  for k in [1:10] do
    let scale := Float.pow 10.0 (Float.ofInt ((k : Int) - 1 - e))
    let m := (Float.round (a * scale)).toUInt64.toNat
    let back := (Float.ofNat m / scale).toFloat32
    if back == x.abs then
      digits := toString m
      -- rounding up may add a digit (9.99 → 10.0)
      ee := e + ((digits.length : Int) - k)
      break
  if digits.isEmpty then return toString d
  let ds := digits.toList
  let sgn := if d < 0.0 then "-" else ""
  let strip (l : List Char) := (l.reverse.dropWhile (· == '0')).reverse
  if a ≥ 1e-3 && a < 1e7 then
    if ee ≥ 0 then
      let n := ee.toNat + 1
      let ip := ds.take n ++ List.replicate (n - min n ds.length) '0'
      let fp := strip (ds.drop n)
      return sgn ++ String.ofList ip ++ "." ++ (if fp.isEmpty then "0" else String.ofList fp)
    else
      return sgn ++ "0." ++ String.ofList (List.replicate ((-ee).toNat - 1) '0') ++ String.ofList (strip ds)
  else
    let fp := strip ds.tail
    return sgn ++ String.ofList [ds.head!] ++ "." ++ (if fp.isEmpty then "0" else String.ofList fp) ++ "e" ++ toString ee

/-- `format`'s `~f` of a single float with no parameters: the digits of `f32Text`, always
in fixed notation. -/
def f32FText (x : Float32) : String :=
  let t := f32Text x
  match t.splitOn "e" with
  | [m, e] =>
    let neg := m.startsWith "-"
    let m := if neg then (m.drop 1).toString else m
    let ds := (m.toList.filter (· != '.'))
    let ds := (ds.reverse.dropWhile (· == '0')).reverse
    let ds := if ds.isEmpty then ['0'] else ds
    let ee := (if e.startsWith "-" then -(((e.drop 1).toString.toNat?).getD 0 : Int) else ((e.toNat?).getD 0 : Int))
    let body :=
      if ee < 0 then "0." ++ String.ofList (List.replicate ((-ee).toNat - 1) '0') ++ String.ofList ds
      else
        let n := ee.toNat + 1
        let ip := ds.take n ++ List.replicate (n - min n ds.length) '0'
        let fp := ds.drop n
        String.ofList ip ++ "." ++ (if fp.isEmpty then "0" else String.ofList fp)
    (if neg then "-" else "") ++ body
  | _ => t

/-- A single-float value. -/
def Val.ofF32 (x : Float32) : Val := .num x.toFloat (f32Text x)

/-- A number's value as an integer, if it is one. -/
def Val.int? (v : Val) : Option Int :=
  match v with
  | .num x _ => if v.isInt then some (Float.round x).toInt64.toInt else none
  | _ => none

/-- A Lisp real: an integer, a ratio `n/d` (in lowest terms, `d > 1`) or a single float. -/
inductive LNum where
  | int (i : Int)
  | rat (n : Int) (d : Nat)
  | flt (x : Float32)
  deriving Inhabited

namespace LNum

/-- `n/d` in lowest terms, an integer when `d` divides `n`. -/
def mkRat (n : Int) (d : Int) : LNum :=
  let g := Nat.gcd n.natAbs d.natAbs
  let (n, d) := if d < 0 then (-n, -d) else (n, d)
  let n := n / (g : Int)
  let d := (d / (g : Int)).toNat
  if d == 1 then .int n else .rat n d

/-- As a fraction. -/
def frac : LNum → Option (Int × Nat)
  | .int i => some (i, 1)
  | .rat n d => some (n, d)
  | .flt _ => none

def toF32 : LNum → Float32
  | .int i => (Float.ofInt i).toFloat32
  | .rat n d => (Float.ofInt n / Float.ofNat d).toFloat32
  | .flt x => x

def toVal : LNum → Val
  | .int i => Val.ofInt i
  | .rat n d => .num (Float.ofInt n / Float.ofNat d) s!"{n}/{d}"
  | .flt x => Val.ofF32 x

def ofVal? : Val → Option LNum
  | v@(.num x t) =>
    match t.splitOn "/" with
    | [a, b] => match a.toInt?, b.toNat? with
      | some n, some d => if d == 0 then none else some (mkRat n d)
      | _, _ => none
    | _ => if v.isInt then some (.int (Float.round x).toInt64.toInt) else some (.flt x.toFloat32)
  | _ => none

/-- Exact arithmetic on rationals, single floats when either is a float (Lisp contagion). -/
def op2 (q : Int × Nat → Int × Nat → Option LNum) (f : Float32 → Float32 → Float32) (a b : LNum) : Option LNum :=
  match a.frac, b.frac with
  | some x, some y => q x y
  | _, _ => some (.flt (f a.toF32 b.toF32))

def add := op2 (fun (a, b) (c, d) => some (mkRat (a * d + c * b) (b * d))) (· + ·)
def sub := op2 (fun (a, b) (c, d) => some (mkRat (a * d - c * b) (b * d))) (· - ·)
def mul := op2 (fun (a, b) (c, d) => some (mkRat (a * c) (b * d))) (· * ·)
def div (a b : LNum) : Option LNum :=
  match a.frac, b.frac with
  | some (x, y), some (u, v) => if u == 0 then none else some (mkRat (x * v) (y * u))
  | _, _ => if b.toF32 == 0 then none else some (.flt (a.toF32 / b.toF32))

/-- Exact comparison of rationals; with a float, by value. -/
def cmp (a b : LNum) : Ordering :=
  match a.frac, b.frac with
  | some (x, y), some (u, v) => compare (x * v) (u * y)
  | _, _ =>
    let p := match a with | .flt x => x.toFloat | v => (match v.frac with | some (n, d) => Float.ofInt n / Float.ofNat d | none => 0)
    let q := match b with | .flt x => x.toFloat | v => (match v.frac with | some (n, d) => Float.ofInt n / Float.ofNat d | none => 0)
    if p < q then .lt else if p > q then .gt else .eq

def isZero (a : LNum) : Bool := match a with | .flt x => x == 0 | v => v.frac.map (·.1 == 0) |>.getD false

/-- `floor` and friends: the integer quotient and the remainder. -/
def divMode (mode : String) (a b : LNum) : Option (LNum × LNum) := do
  if b.isZero then none
  match a.frac, b.frac with
  | some (x, y), some (u, v) =>
    -- (x/y)/(u/v) = (x v)/(y u)
    let num := x * v
    let den := (y : Int) * u
    let (num, den) := if den < 0 then (-num, -den) else (num, den)
    let fl := Int.fdiv num den
    let r := num - fl * den
    let q : Int := match mode with
      | "FLOOR" => fl
      | "CEILING" => if r == 0 then fl else fl + 1
      | "TRUNCATE" => if num < 0 && r != 0 then fl + 1 else fl
      | _ => if 2 * r < den then fl else if 2 * r > den then fl + 1 else if fl % 2 == 0 then fl else fl + 1
    let rem ← sub a (← mul (.int q) b)
    return (.int q, rem)
  | _, _ =>
    let x := a.toF32
    let y := b.toF32
    let d := x / y
    let fl := (Float.floor d.toFloat)
    let flI : Int := if fl < 0 then -((-fl).toUInt64.toNat : Int) else (fl.toUInt64.toNat : Int)
    let q : Int := match mode with
      | "FLOOR" => flI
      | "CEILING" => if fl == d.toFloat then flI else flI + 1
      | "TRUNCATE" => if d < 0 && fl != d.toFloat then flI + 1 else flI
      | _ =>
        let fr := d.toFloat - fl
        if fr < 0.5 then flI else if fr > 0.5 then flI + 1 else if flI % 2 == 0 then flI else flI + 1
    return (.int q, .flt (x - (Float.ofInt q).toFloat32 * y))

/-- `expt` with an integer power: exact for rationals, `pow` for floats. -/
def exptInt (a : LNum) (n : Int) : Option LNum :=
  match a.frac with
  | some (x, y) =>
    if n ≥ 0 then some (mkRat (x ^ n.toNat) ((y : Int) ^ n.toNat))
    else if x == 0 then none else some (mkRat ((y : Int) ^ n.natAbs) (x ^ n.natAbs))
  | none =>
    -- SBCL's `real-expt`: `pow` in double floats, rounded to single
    let x := a.toF32.toFloat
    if x == 0 && n < 0 then none
    else some (.flt (Float.pow x (Float.ofInt n)).toFloat32)

end LNum

def lispT : Option Val := some (.sym "T")
def lispBool (b : Bool) : Option Val := if b then lispT else none

/-- Integer arithmetic on integers, single-float arithmetic otherwise (Lisp's contagion
for the reals tutorial models use). -/
def arith (op : Int → Int → Int) (fop : Float32 → Float32 → Float32) : Val → Val → Option Val
  | a@(.num x _), b@(.num y _) =>
    if a.isInt && b.isInt then some (Val.ofInt (op (Float.round x).toInt64.toInt (Float.round y).toInt64.toInt))
    else some (Val.ofF32 (fop x.toFloat32 y.toFloat32))
  | _, _ => none

/-- A number's value as a single float. -/
def Val.f32? : Val → Option Float32
  | .num x _ => some x.toFloat32
  | _ => none

def numCmpN (f : Ordering → Bool) : List (Option Val) → Option (Option Val)
  | [] => none
  | vs => do
    let xs ← vs.mapM fun v => v.bind LNum.ofVal?
    let ok := (xs.zip (xs.drop 1)).all fun (a, b) => f (LNum.cmp a b)
    return lispBool ok

/-- The name of a symbol or the text of a string (`string=` and friends). -/
def Val.strDesig? : Option Val → Option String
  | some (.str s) => some s
  | some (.sym s) => some s
  | none => some "NIL"
  | _ => none

/-- The functions `!eval!`/`!bind!` expressions may use ([Src] Common Lisp, as evaluated by
SBCL): `none` when evaluating the expression would be a Lisp error or needs something not
modeled (a complex number, a task command). The result is the list of values (`values`,
`floor`, …); the first is the expression's value. -/
partial def Expr.evalM (env : Env) : Expr → Option (List (Option Val))
  | .lit v => some [v]
  | .var x => some [env.lookup x]
  | .cmd _ _ => none
  | .app f args =>
    let one := fun (e : Expr) => (Expr.evalM env e).map fun vs => vs.head?.join
    if f == "AND" then
      (args.foldl (fun acc a => match acc with
        | some (some _) => one a
        | r => r) (some lispT)).map ([·])
    else if f == "OR" then
      (args.foldl (fun acc a => match acc with
        | some none => one a
        | r => r) (some none)).map ([·])
    else if f == "IF" then
      match args with
      | [c, t] => do if (← one c).isSome then Expr.evalM env t else some [none]
      | [c, t, e] => do if (← one c).isSome then Expr.evalM env t else Expr.evalM env e
      | _ => none
    else if f == "WHEN" || f == "UNLESS" then
      match args with
      | c :: body => do
        let cv ← one c
        if cv.isSome == (f == "WHEN") then
          body.foldlM (fun _ e => Expr.evalM env e) [none]
        else some [none]
      | [] => none
    else if f == "PROGN" then args.foldlM (fun _ e => Expr.evalM env e) [none]
    else if f == "VALUES" then args.mapM one
    else do
    let vs ← args.mapM one
    let nums : Option (List LNum) := vs.mapM fun v => v.bind LNum.ofVal?
    let single := fun (r : Option Val) => some [r]
    let ret := fun (n : LNum) => some [some n.toVal]
    let pred := fun (b : LNum → Bool) => match nums with
      | some [a] => single (lispBool (b a))
      | _ => none
    match f with
    | "+" => do ret (← (← nums).foldlM LNum.add (.int 0))
    | "*" => do ret (← (← nums).foldlM LNum.mul (.int 1))
    | "-" => do
      match ← nums with
      | [.flt x] => ret (.flt (-x))
      | [a] => ret (← LNum.sub (.int 0) a)
      | a :: r => ret (← r.foldlM LNum.sub a)
      | [] => none
    | "/" => do
      match ← nums with
      | [a] => ret (← LNum.div (.int 1) a)
      | a :: r => ret (← r.foldlM LNum.div a)
      | [] => none
    | "1+" => do match ← nums with | [a] => ret (← LNum.add a (.int 1)) | _ => none
    | "1-" => do match ← nums with | [a] => ret (← LNum.sub a (.int 1)) | _ => none
    | "ABS" => do
      match ← nums with
      | [.flt x] => ret (.flt x.abs)
      | [a] => if LNum.cmp a (.int 0) == .lt then ret (← LNum.sub (.int 0) a) else ret a
      | _ => none
    | "MAX" | "MIN" => do
      let ns ← nums
      let m ← ns.head?
      ret (ns.foldl (fun b v =>
        match LNum.cmp v b with
        | .gt => if f == "MAX" then v else b
        | .lt => if f == "MIN" then v else b
        | .eq => b) m)
    | "FLOOR" | "CEILING" | "TRUNCATE" | "ROUND" => do
      let (q, r) ← match ← nums with
        | [a] => LNum.divMode f a (.int 1)
        | [a, b] => LNum.divMode f a b
        | _ => none
      some [some q.toVal, some r.toVal]
    | "MOD" | "REM" => do
      match ← nums with
      | [a, b] => ret (← LNum.divMode (if f == "MOD" then "FLOOR" else "TRUNCATE") a b).2
      | _ => none
    | "SQRT" => do
      match ← nums with
      | [a] => let x := a.toF32; if x < 0 then none else ret (.flt (Float.sqrt x.toFloat).toFloat32)
      | _ => none
    | "EXP" => do
      match ← nums with
      | [a] => ret (.flt (Float.exp a.toF32.toFloat).toFloat32)
      | _ => none
    | "LOG" => do
      match ← nums with
      | [a] => let x := a.toF32; if x ≤ 0 then none else ret (.flt (Float.log x.toFloat).toFloat32)
      | [a, b] =>
        let x := a.toF32
        let y := b.toF32
        if x ≤ 0 || y ≤ 0 || y == 1 then none
        else ret (.flt ((Float.log x.toFloat).toFloat32 / (Float.log y.toFloat).toFloat32))
      | _ => none
    | "EXPT" => do
      match ← nums with
      | [a, .int n] => ret (← LNum.exptInt a n)
      | [a, b] =>
        let x := a.toF32
        if x < 0 then none else ret (.flt (Float.pow x.toFloat b.toF32.toFloat).toFloat32)
      | _ => none
    | "<" => (numCmpN (· == .lt) vs).map ([·])
    | ">" => (numCmpN (· == .gt) vs).map ([·])
    | "<=" => (numCmpN (· != .gt) vs).map ([·])
    | ">=" => (numCmpN (· != .lt) vs).map ([·])
    | "=" => (numCmpN (· == .eq) vs).map ([·])
    | "/=" => do
      let xs ← nums
      let ok := xs.zipIdx.all fun (x, i) => (xs.drop (i + 1)).all (LNum.cmp · x != .eq)
      single (lispBool ok)
    | "ZEROP" => pred LNum.isZero
    | "PLUSP" => pred (LNum.cmp · (.int 0) == .gt)
    | "MINUSP" => pred (LNum.cmp · (.int 0) == .lt)
    | "EVENP" => match nums with
      | some [.int i] => single (lispBool (i % 2 == 0))
      | _ => none
    | "ODDP" => match nums with
      | some [.int i] => single (lispBool (i % 2 != 0))
      | _ => none
    | _ =>
    match f, vs with
    | "NUMBERP", [a] => single (lispBool (a.bind LNum.ofVal?).isSome)
    | "INTEGERP", [a] => single (lispBool (match a.bind LNum.ofVal? with | some (.int _) => true | _ => false))
    | "FLOATP", [a] => single (lispBool (match a.bind LNum.ofVal? with | some (.flt _) => true | _ => false))
    | "SYMBOLP", [a] => single (lispBool (match a with | some (.sym _) | none => true | _ => false))
    | "STRINGP", [a] => single (lispBool (match a with | some (.str _) => true | _ => false))
    | "NOT", [v] => single (lispBool v.isNone)
    | "NULL", [v] => single (lispBool v.isNone)
    | "EQ", [a, b] => single (lispBool (match a, b with
        | some (.sym x), some (.sym y) => x == y
        | none, none => true
        | some (.num x t), some (.num y u) => x == y && t == u && !t.contains '/'
        | _, _ => false))
    | "EQL", [a, b] | "EQUAL", [a, b] => single (lispBool (match a, b with
        | some (.sym x), some (.sym y) => x == y
        | none, none => true
        | some (.str x), some (.str y) => f == "EQUAL" && x == y
        | some (.num _ t), some (.num _ u) =>
          match (a.bind LNum.ofVal?), (b.bind LNum.ofVal?) with
          | some (.flt x), some (.flt y) => x == y
          | some p@(.int _), some q@(.int _) | some p@(.rat _ _), some q@(.rat _ _) => LNum.cmp p q == .eq && (t.contains '/' == u.contains '/')
          | _, _ => false
        | _, _ => false))
    | "STRING=", [a, b] => do single (lispBool ((← Val.strDesig? a) == (← Val.strDesig? b)))
    | "STRING-EQUAL", [a, b] => do single (lispBool ((← Val.strDesig? a).toUpper == (← Val.strDesig? b).toUpper))
    | _, _ => none

/-- The value of an expression (its first value; `none` as for `evalM`). -/
def Expr.evalPure (env : Env) (e : Expr) : Option (Option Val) :=
  (e.evalM env).map fun vs => vs.head?.join

/-- Match a production against the buffers ([Src] `conflict-resolution`): bind the buffer
variables and the variables of `=` tests, then check every test and query. The result
depends on the buffers and the module states only: productions cannot test declarative
memory, numeric parameters or the event queue.

With procedural partial matching (`:ppm`, [Src] `test-constants`, `test-search-constants`),
`pm` gives the similarity of a tested value and the chunk's value when it is above `:md`;
an `=` slot test that fails then still holds, and its similarity is returned. The
similarities come constant tests first, then variable tests, and in reverse order of
testing, as ACT-R pushes them. -/
def matchCondsPXE (bufs : Buf → BufSt) (qs : QState) (conds : List Cond)
    (pm : Option (Val → Val → Option Float32)) (binds : List LBind := []) :
    Except String (Option (Env × List (Buf × Slot × Val × Val × Float32))) := do
  -- variables bound by `!bind!` are tested, not bound, by the slots that use them
  let bvs := binds.flatMap (·.vars)
  let nb := fun (ts : List SlotTest) => if bvs.isEmpty then ts else ts.filter fun t =>
    match t.arg with | some (.var x) => !bvs.contains x | _ => true
  let env? := conds.foldl (fun acc c =>
    match acc, c with
    | some env, .buf b ts =>
      (match (bufs b).chunk with
       | some ch => bindTests ch ((b.name, Val.sym ch.name) :: env) (nb ts)
       | none => none)
    | acc, _ => acc) (some [])
  let env? := env?.bind fun env => conds.foldl (fun acc c =>
    match acc, c with
    | some env, .buf b ts =>
      (match (bufs b).chunk with
       | some ch => bindVarSlots ch env (nb ts)
       | none => none)
    | acc, _ => acc) (some env)
  match env? with
  | none => return none
  | some env =>
    -- a test of a variable slot name is among the variable tests
    let isConst := fun (t : SlotTest) => !isVarSlot t.slot && match t.arg with | some (.var _) => false | _ => true
    -- each slot test: none if it fails, some [] if it holds, some [s] if it partially matches
    let test := fun (env : Env) (b : Buf) (ch : Chunk) (t : SlotTest) => match t.inst env with
      | some it =>
        if it.holds ch then some ([] : List (Buf × Slot × Val × Val × Float32))
        else match pm, it.cmp, it.arg, ch.get it.slot with
          | some f, .eq, some v, some w => (f v w).map fun x => [(b, it.slot, v, w, x)]
          | _, _, _, _ => none
      | none => none
    -- the constant tests come before the bindings ([Src] `conflict-resolution`)
    let constOK := binds.isEmpty || conds.all fun c => match c with
      | .buf b ts => match (bufs b).chunk with
        | some ch => ts.all fun t => !isConst t || (test env b ch t).isSome
        | none => false
      | _ => true
    if !constOK then return none
    -- `!bind!` and `!mv-bind!` on the left-hand side, in dependency order: `nil` fails
    let mut envB := env
    for lb in binds do
      match lb.e.evalM envB with
      | none => throw s!"the left-hand side expression of {", ".intercalate lb.vars}"
      | some vs =>
        if lb.mv then
          if vs.length != lb.vars.length || vs.any (·.isNone) then return none
          envB := (lb.vars.zip vs).foldl (fun e (x, v) => match v with | some v => (x, v) :: e | none => e) envB
        else match vs.head?.join with
          | some v => envB := (lb.vars.headD "", v) :: envB
          | none => return none
    let env := envB
    let res := conds.foldl (fun (acc : Option (List (Buf × Slot × Val × Val × Float32) × List (Buf × Slot × Val × Val × Float32))) c =>
      match acc with
      | none => none
      | some (cs, vs) =>
        match c with
        | .buf b ts =>
          (match (bufs b).chunk with
           | some ch => ts.foldl (fun a t =>
               match a, test env b ch t with
               | some (cs, vs), some r => if isConst t then some (cs ++ r, vs) else some (cs, vs ++ r)
               | _, _ => none) (some (cs, vs))
           | none => none)
        | .query b qts => if qts.all (·.holds (bufs b) qs b) then some (cs, vs) else none
        | .eval _ => some (cs, vs)) (some ([], []))
    match res with
    | none => return none
    | some (cs, vs) =>
      -- `!eval!` conditions last
      for c in conds do
        match c with
        | .eval e => match e.evalPure env with
          | none => throw "a left-hand side !eval! expression"
          | some none => return none
          | some (some _) => pure ()
        | _ => pure ()
      return some (env, (cs ++ vs).reverse)

def matchCondsPX (bufs : Buf → BufSt) (qs : QState) (conds : List Cond)
    (pm : Option (Val → Val → Option Float32)) (binds : List LBind := []) :
    Option (Env × List (Buf × Slot × Val × Val × Float32)) :=
  match matchCondsPXE bufs qs conds pm binds with
  | .ok r => r
  | .error _ => none

/-- `matchCondsPX` with the similarities of the partial matches only. -/
def matchCondsPM (bufs : Buf → BufSt) (qs : QState) (conds : List Cond)
    (pm : Option (Val → Val → Option Float32)) (binds : List LBind := []) : Option (Env × List Float32) :=
  (matchCondsPX bufs qs conds pm binds).map fun (env, ps) => (env, ps.map (·.2.2.2.2))

def matchConds (bufs : Buf → BufSt) (qs : QState) (conds : List Cond) : Option Env :=
  (matchCondsPM bufs qs conds none).map (·.1)

/-! ## The conflict-set trace (`:cst`) -/

/-- `format`'s `~6,3F` of a single float: the exact value rounded to three decimals,
right-justified in six columns. -/
def fmtF63 (x : Float32) : String :=
  let d := x.toFloat
  let y := d.abs * 1000.0
  let f := Float.floor y
  let r := y - f
  let k := (if r > 0.5 then f + 1.0 else if r < 0.5 then f
    else if (f.toUInt64.toNat % 2 == 0) then f else f + 1.0).toUInt64.toNat
  let fr := toString (1000 + k % 1000)
  let t := (if d < 0 then "-" else "") ++ toString (k / 1000) ++ "." ++ (fr.drop 1).toString
  String.ofList (List.replicate (6 - min 6 t.length) ' ') ++ t

def Cmp.text : Cmp → String
  | .eq => "=" | .ne => "-" | .lt => "<" | .gt => ">" | .le => "<=" | .ge => ">="

/-- The text of a production instantiated with `env` ([Src] `print-production-text`,
`production-statement-text`): bound variables replaced by their values (`~s`), partially
matched slots shown with the chunk's value and the similarity. -/
def instantiationText (p : Production) (env : Env)
    (partials : List (Buf × Slot × Val × Val × Float32)) : List String :=
  let valT := fun (t : Option Term) => match t with
    | none => "NIL"
    | some (.const v) => v.repr
    | some (.var x) => match env.lookup x with | some v => v.repr | none => "=" ++ x
  let slotT := fun (sl : Slot) => (resolveSlot env sl).getD sl
  let pad2 := fun (m : String) => m ++ String.ofList (List.replicate (2 - min 2 m.length) ' ')
  let testLines := fun (b : Option Buf) (ts : List SlotTest) => ts.map fun t =>
    let name := slotT t.slot
    let v := valT t.arg
    let pmatch := match b with
      | some b => partials.find? fun (q : Buf × Slot × Val × Val × Float32) => q.1 == b && q.2.1 == name && q.2.2.1.repr == v
      | none => none
    let body := match pmatch with
      | some (_, _, _, real, sim) => s!"{name} [{v}, {real.repr}, {f32FText sim}]"
      | none => s!"{name} {v}"
    if t.cmp == .eq then "       " ++ body else "    " ++ pad2 t.cmp.text ++ " " ++ body
  let toksT := fun (ts : List PTok) => String.join (ts.map fun t => match t with
    | .lit s => s
    | .var x => match env.lookup x with | some v => v.repr | none => "=" ++ x)
  let stmt := fun (st : PStmt) => match st with
    | .bang n ts => ["   !" ++ n ++ "! " ++ toksT ts]
    | .cond (.buf b ts) => ("   =" ++ b.name ++ ">") :: testLines (some b) ts
    | .cond (.query b qs) => ("   ?" ++ b.name ++ ">") :: qs.map fun q =>
        if q.neg then s!"    -  {q.slot} {q.val}" else s!"       {q.slot} {q.val}"
    | .cond (.eval _) => []
    | .act (.modify b sets) =>
      if sets.isEmpty then ["   =" ++ b.name ++ "> "]
      else ("   =" ++ b.name ++ ">") :: sets.map fun x => s!"       {slotT x.1} {valT x.2}"
    | .act (.modRequest b sets) => ("   *" ++ b.name ++ ">") :: sets.map fun x => s!"       {slotT x.1} {valT x.2}"
    | .act (.request b spec) => ("   +" ++ b.name ++ ">") :: testLines none spec
    | .act (.directRequest b t) => ["   +" ++ b.name ++ "> " ++ valT (some t)]
    | .act (.clear b) => ["   -" ++ b.name ++ ">"]
    | .act (.erase b) => ["   @" ++ b.name ++ ">"]
    | .act (.overwrite b (some t) _) => ["   @" ++ b.name ++ "> " ++ valT (some t)]
    | .act (.overwrite b none spec) => ("   @" ++ b.name ++ ">") :: testLines none spec
    | .act _ => []
  [s!"(P {p.name}"] ++ (p.doc.map fun d => ["  \"" ++ d ++ "\""]).getD [] ++ p.lhsText.flatMap stmt ++ [" ==>"] ++ p.rhsText.flatMap stmt ++ [")"]

end ACTR
