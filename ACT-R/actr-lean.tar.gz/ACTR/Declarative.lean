import ACTR.Core
import ACTR.Random
import Std.Data.HashMap
/-!
# ACT-R 7 in Lean — declarative memory

[RM] "Declarative module": merging of cleared chunks, the activation equation
`A_i = B_i + S_i + P_i + ε_i`, the retrieval threshold and retrieval time.

Arithmetic follows ACT-R under SBCL, where the reader's default float format is
single-float: activations are single floats (`Float32`), and `exp`, `log` and `expt` are
computed in double precision and rounded to single, as SBCL does for single-float
arguments.
-/

namespace ACTR

/-! ## Single-float arithmetic as SBCL computes it -/

def f32 (x : Float) : Float32 := x.toFloat32
def exp32 (x : Float32) : Float32 := f32 (Float.exp x.toFloat)
def log32 (x : Float32) : Float32 := f32 (Float.log x.toFloat)
def pow32 (x y : Float32) : Float32 := f32 (Float.pow x.toFloat y.toFloat)
def nat32 (n : Nat) : Float32 := f32 (Float.ofNat n)

/-- Common Lisp `round`: to the nearest integer, ties to even. -/
def roundEven (x : Float32) : Int :=
  let d := x.toFloat
  let fl := Float.floor d
  let diff := d - fl
  let lo : Int := if fl < 0 then -((-fl).toUInt64.toNat : Int) else (fl.toUInt64.toNat : Int)
  if diff > 0.5 then lo + 1
  else if diff < 0.5 then lo
  else if lo % 2 == 0 then lo else lo + 1

/-- The parameters used by the modeled modules, with ACT-R's default values ([RM] parameter
sections of the declarative, procedural, utility, goal and imaginal modules). -/
structure Params where
  /-- `:esc` enable subsymbolic computations. -/
  esc : Bool := false
  /-- `:dat` default action time, ms. -/
  dat : Nat := 50
  /-- `:bll` base-level learning decay (`none` = off). -/
  bll : Option Float32 := none
  /-- `:ol` optimized learning. `true` is ACT-R's default; a number is NOT MODELED. -/
  ol : Bool := true
  /-- `:blc` base-level constant. -/
  blc : Float32 := 0.0
  /-- `:mas` maximum associative strength (`none` = no spreading activation). -/
  mas : Option Float32 := none
  /-- `:ga` source activation of the goal buffer (0 in ACT-R 7, [Src] goal.lisp). -/
  ga : Float32 := 0.0
  /-- `:imaginal-activation` source activation of the imaginal buffer. -/
  imaginalActivation : Float32 := 1.0
  /-- `:rt` retrieval threshold. -/
  rt : Float32 := 0.0
  /-- `:lf` latency factor, held in whole milliseconds as ACT-R holds it
  ([Src] `seconds->ms` in the `:lf` parameter handler). -/
  lfMs : Nat := 1000
  /-- `:le` latency exponent. -/
  le : Float32 := 1.0
  /-- `:ul` utility learning and its rate `:alpha`. -/
  ul : Bool := false
  /-- `:ult` the utility learning trace. -/
  ult : Bool := false
  /-- `:cst` the conflict-set trace. -/
  cst : Bool := false
  /-- The temporal module: `:time-noise`, `:time-mult`, `:time-master-start-increment` (ms)
  and `:record-ticks`. -/
  timeNoise : Float32 := 0.015
  timeMult : Float32 := 1.1
  timeStartMs : Nat := 11
  recordTicks : Bool := true
  alpha : Float32 := 0.2
  /-- `:ans` transient activation noise. -/
  ans : Option Float32 := none
  /-- `:egs` utility noise. -/
  egs : Float32 := 0.0
  /-- `:er` random choice among equals. -/
  er : Bool := false
  /-- `:mp` mismatch penalty (`none` = no partial matching), `:ms` maximum similarity,
  `:md` maximum difference, and the similarities set with `set-similarities`. -/
  mp : Option Float32 := none
  ms : Float32 := 0.0
  md : Float32 := -1.0
  sims : List (String × String × Float32) := []
  /-- `:seed` of the random-number generator. A model that sets no seed gets `(12345 0)`
  here, and the harness gives ACT-R the same. -/
  seed : Nat × Nat := (12345, 0)
  /-- `:imaginal-delay`, ms. -/
  imaginalDelay : Nat := 200
  /-- `:randomize-time`: the scale `n` of the uniform distribution `time ± time/n` (`t` is 3),
  or `none` when off. -/
  randTime : Option Nat := none
  /-- Explicit `S_ji` values set with `add-sji`: source `j`, chunk `i`, value. -/
  sjis : List (String × String × Float32) := []
  /-- `:declarative-stuffing`: the period (ms) of attempts to stuff the retrieval buffer. -/
  stuff : Option Nat := none
  /-- `:utility-hook`: a task command giving a production's utility (a number overrides it). -/
  utilityHook : Option String := none
  /-- `:cycle-hook`: task commands called with the name of each production that fires. -/
  cycleHooks : List String := []
  /-- `:retrieved-chunk-hook`: task commands called with the retrieved chunk, or `nil`. -/
  retrievedHooks : List String := []
  /-- `:ut` utility threshold: a production whose utility is below it is not selected. -/
  ut : Option Float32 := none
  /-- `:vpft`: production firing times vary (with `:randomize-time`). -/
  vpft : Bool := false
  /-- `:vidt`: imaginal delays vary (with `:randomize-time`). -/
  vidt : Bool := false
  /-- `:nsji t`: negative `S_ji` values are used rather than replaced by 0. -/
  nsjiT : Bool := false
  /-- `:ppm` procedural partial matching. -/
  ppm : Option Float32 := none
  /-- `:pas` permanent activation noise. -/
  pas : Option Float32 := none
  /-- `:ol` set to a number of references. -/
  olN : Option Nat := none
  /-- `:declarative-num-finsts` and `:declarative-finst-span` (ms). -/
  numFinsts : Nat := 4
  finstSpanMs : Nat := 3000
  proc : ProcParams := {}
  /-- Production compilation ([Src] modules/production-compilation.lisp): `:epl` on,
  `:pct` (which also sorts the new production's conditions and actions), the threshold
  time `:tt` in ms, and `:nu`, the utility of new productions. -/
  epl : Bool := false
  pct : Bool := false
  ttMs : Nat := 2000
  nu : Float32 := 0.0
  /-- The blending module (extras/blending): `:tmp`, the temperature (`none`: `√2 · :ans`),
  and `:blend-all-slots`. -/
  tmp : Option Float32 := none
  blendAll : Bool := false
  /-- `:sim-hook`, a similarity function written in Lisp, by its command name, and the
  results of its calls as ACT-R made them (recorded by the task harness), by the printed
  arguments. -/
  simHook : Option String := none
  simTable : List ((String × String) × Option Float32) := []

/-- A chunk in declarative memory with its parameters ([Src] `add-chunk-into-dm`): entry
time, reference count and reference times (ms, most recent first). -/
structure DMEntry where
  chunk : Chunk
  created : Int
  count : Nat
  refs : List Nat
  /-- A base-level set with `set-base-levels` while `:bll` is off. -/
  bl : Option Float32 := none
  /-- Permanent noise (`:pas`), drawn the first time the activation is computed
  ([Src] `default-permanent-noise`, a lazily computed chunk parameter). -/
  pnoise : Option Float32 := none
  /-- Order of entry into memory (for the content index of `St`). -/
  seq : Nat := 0
  /-- The chunk's filled slots, sorted (`Chunk.slotSig`), or empty if not yet computed. -/
  sig : String := ""
  deriving Repr, Inhabited

def DMEntry.name (e : DMEntry) : String := e.chunk.name

/-! ## Base-level activation -/

/-- `(log (expt 1/1000 (- d)))`, the scale ACT-R adds when references are in ms
([Src] the `:bll` parameter handler, `dm-act-scale`). -/
def actScale (d : Float32) : Float32 := log32 (pow32 (f32 0.001) (-d))

/-- Base-level activation ([RM] "Base-level"; [Src] `base-level-activation`,
`compute-references`).
* `:bll nil`: the constant `:blc`.
* `:ol t`: `blc + ln(n · max(0.05, T)^(−d) / (1 − d))`, `T` the seconds since the chunk
  entered memory.
* `:ol nil`: `blc + ln(Σ_j max(50, t_j)^(−d)) + d·ln 1000`, `t_j` the milliseconds since
  each reference. -/
def baseLevel (P : Params) (now : Nat) (e : DMEntry) : Float32 :=
  match P.bll with
  | none => e.bl.getD P.blc
  | some d =>
    let md := -d
    let v :=
      match P.olN with
      | some k =>
        -- `:ol k`: the k most recent references exactly, the rest approximated
        let refs := e.refs.take k
        let s := refs.foldl (fun acc r => acc + pow32 (nat32 (max 50 (now - r))) md) (f32 0.0)
        let last := refs.getLastD 0
        let s := if e.count > k then
            let den := f32 1.0 + md
            s + (nat32 (e.count - k) * (pow32 (nat32 ((now : Int) - e.created).toNat) den - pow32 (nat32 (now - last)) den)) /
                (nat32 (max 50 ((last : Int) - e.created).toNat) * den)
          else s
        log32 s + actScale d
      | none =>
      if P.ol then
        let secs := nat32 ((now : Int) - e.created).toNat / f32 1000.0
        let t := if secs < f32 0.05 then f32 0.05 else secs
        log32 (nat32 e.count * pow32 t md / (f32 1.0 + md))
      else
        let s := e.refs.foldl (fun acc r => acc + pow32 (nat32 (max 50 (now - r))) md) (f32 0.0)
        log32 s + actScale d
    P.blc + v

/-! ## Spreading activation -/

/-- The chunks among a chunk's slot values (symbols other than `t`; numbers and strings are
not chunks). -/
def chunkVals (c : Chunk) : List String :=
  c.slots.filterMap fun p => match p.2 with | .sym "T" => none | .sym s => some s | _ => none

/-- `fan_j` ([Src] `chunk-fan-out`, `chunk-fan-j-to-i`): one plus the number of slots of
chunks in declarative memory that hold `j`. For a chunk in memory the one is its link to
itself; for one outside memory it is the `(max 1 c-fan-out)` term. -/
def fanOut (dm : List DMEntry) (j : String) : Nat :=
  1 + dm.foldl (fun n e => n + ((chunkVals e.chunk).filter (· == j)).length) 0

/-- How often `j` occurs in `i` ([Src] `chunk-fan-in`): its slots holding `j`, plus one if
`i` is `j` itself. -/
def countIn (j : String) (i : Chunk) : Nat :=
  ((chunkVals i).filter (· == j)).length + (if i.name == j then 1 else 0)

/-- `S_ji = S − ln(fan_j / count)` when `j` occurs in `i`, else 0; a negative value is
replaced by 0 unless `:nsji` is `t` ([Src] `compute-sji`). -/
def sji (S : Float32) (dm : List DMEntry) (j : String) (i : Chunk) (neg : Bool := false) : Float32 :=
  let n := countIn j i
  if n == 0 then f32 0.0
  else
    let v := S - log32 (nat32 (fanOut dm j) / nat32 n)
    if neg then v else if v < f32 0.0 then f32 0.0 else v

/-- Spreading activation ([Src] `spreading-activation`): each source buffer with a nonzero
spread divides it equally among the chunks in its chunk's slots.
SIMPLIFIED: the sources are summed goal first, then imaginal; ACT-R sums in the order of
`model-buffers`, which can change the last bit when both spread. -/
def spreading (P : Params) (sources : List (Chunk × Float32)) (dm : List DMEntry)
    (i : Chunk) : Float32 :=
  match P.mas with
  | none => f32 0.0
  | some S =>
    sources.foldl (fun acc (src : Chunk × Float32) =>
      let js := chunkVals src.1
      if js.isEmpty || src.2 == f32 0.0 then acc
      else
        let w := src.2 / nat32 js.length
        js.foldl (fun a j =>
          -- a value set with `add-sji` comes first ([Src] `compute-sji`, `chunk-sjis`)
          let v := match P.sjis.find? (fun t => t.1 == j && t.2.1 == i.name) with
            | some t => t.2.2
            | none => sji S dm j i P.nsjiT
          a + w * v) acc) (f32 0.0)

/-- The set of slots a chunk fills, as a string (its group in `dm-chunks`). -/
def Chunk.slotSig (c : Chunk) : String :=
  " " ++ String.intercalate " " ((c.slots.map (·.1)).toArray.qsort (· < ·) |>.toList)

/-- The order in which the declarative module considers chunks ([Src] `start-retrieval`
walks `dm-chunks`): chunks are grouped by the set of slots they fill, groups newest first,
and within a group the chunks added most recently first. `dm` is in order of addition. -/
def chunkOrder (dm : List DMEntry) : List DMEntry :=
  let (order, groups) := dm.foldl (fun (acc : Array String × Std.HashMap String (List DMEntry)) e =>
    let k := if e.sig.isEmpty then e.chunk.slotSig else e.sig
    match acc.2.get? k with
    | some l => (acc.1, acc.2.insert k (e :: l))
    | none => (acc.1.push k, acc.2.insert k [e])) (#[], {})
  order.toList.reverse.flatMap fun k => groups.getD k []

/-- Similarity of a requested value and a chunk's value ([Src] `chunks-similarity`): the
result of `:sim-hook` when it returns a number; otherwise, for
values that are not both chunks, `:ms` if equal and `:md` if not; for chunks, a similarity
set with `set-similarities` (symmetric), else `:ms` for the same chunk and `:md` otherwise. -/
def similarity (P : Params) (v : Option Val) (w : Option Val) : Float32 :=
  let rep := fun (x : Option Val) => match x with | some x => x.repr | none => "NIL"
  let hooked := if P.simHook.isSome then (P.simTable.lookup (rep v, rep w)).bind id else none
  match hooked with
  | some r => r
  | none =>
  match v, w with
  | some (.sym a), some (.sym b) =>
    match P.sims.find? (fun x => (x.1 == a && x.2.1 == b) || (x.1 == b && x.2.1 == a)) with
    | some x => x.2.2
    | none => if a == b then P.ms else P.md
  | some a, some b => if a == b then P.ms else P.md
  | none, none => P.ms
  | _, _ => P.md

/-- Partial-matching component ([Src] `partial-matching`): over the request's `=` and `-`
slot tests in order, `mp · sim` for `=`, and for `-` `mp · md` when the values are
maximally similar, else 0. -/
def partialMatch (P : Params) (spec : List ITest) (c : Chunk) : Float32 :=
  match P.mp with
  | none => f32 0.0
  | some mp =>
    spec.foldl (fun acc t =>
      let sim := similarity P t.arg (c.get t.slot)
      match t.cmp with
      | .eq => acc + mp * sim
      | .ne => acc + (if sim == P.ms then mp * P.md else f32 0.0)
      | _ => acc) (f32 0.0)

/-- The activation equation `A_i = B_i + S_i + P_i + ε_i` ([RM] "Activation";
[Src] `compute-activation`, `activation-noise`). The transient noise is drawn from the
generator when `:ans` is set; the permanent noise (`:pas`) is drawn after it the first time
the chunk's activation is computed, and returned so that it is kept with the chunk. -/
def activation (P : Params) (now : Nat) (sources : List (Chunk × Float32)) (dm : List DMEntry)
    (spec : List ITest) (e : DMEntry) (rng : MT) : Float32 × MT × Option Float32 :=
  let a := baseLevel P now e + spreading P sources dm e.chunk + partialMatch P spec e.chunk
  let (n, rng) := match P.ans with
    | some s => rng.noise s
    | none => (f32 0.0, rng)
  match P.pas with
  | none => (a + n, rng, none)
  | some ps =>
    match e.pnoise with
    | some pn => (a + (n + pn), rng, none)
    | none => let (pn, rng) := rng.noise ps; (a + (n + pn), rng, some pn)

/-- Keep the permanent noises drawn by `activation`. -/
def setNoises (dm : List DMEntry) (ns : List (String × Float32)) : List DMEntry :=
  if ns.isEmpty then dm
  else dm.map fun e => match ns.lookup e.name with
    | some n => { e with pnoise := some n }
    | none => e

/-- The chunks a request can retrieve, in the order they are considered
([Src] `start-retrieval`). Without partial matching: the chunks that match every test, in
`chunkOrder`. With partial matching (`:esc` and `:mp`): the chunks that fill every slot the
request needs filled, leave empty every slot it needs empty, and pass its relational tests
(`<`, `>`, `<=`, `>=`), in reverse `chunkOrder`. -/
def candidates (P : Params) (dm : List DMEntry) (spec : List ITest) : List DMEntry :=
  let spec := spec.filter (!·.slot.startsWith ":")
  let ord := chunkOrder dm
  if P.esc && P.mp.isSome then
    let ok := fun (e : DMEntry) => spec.all fun t =>
      match t.cmp, t.arg with
      | .eq, none => (e.chunk.get t.slot).isNone
      | .ne, none => (e.chunk.get t.slot).isSome
      | .eq, some _ => (e.chunk.get t.slot).isSome
      | .ne, some _ => true
      | _, _ => t.holds e.chunk
    (ord.filter ok).reverse
  else ord.filter fun e => spec.all (·.holds e.chunk)

/-- Retrieval latency in ms ([Src] `compute-activation-latency`):
`round(F · e^(−f·A))` with `F` in ms. -/
def latency (P : Params) (a : Float32) : Nat :=
  (roundEven (nat32 P.lfMs * exp32 ((f32 (-1.0) * P.le) * a))).toNat

/-- The first chunk in `string<` order of its name. -/
def firstByName (xs : List DMEntry) : Option DMEntry :=
  xs.foldl (fun (b : Option DMEntry) e => match b with
    | none => some e
    | some b => if e.name < b.name then some e else some b) none

/-- A retrieval ([RM] "Declarative Memory"; [Src] `start-retrieval`): the chunk retrieved,
if any, the time the request takes in ms, and the generator.
* `:esc nil`: a matching chunk is retrieved at once.
* `:esc t`: the activation of each matching chunk is computed (in `chunkOrder`, which fixes
  the order of noise draws); the chunk with the highest activation is retrieved if that
  activation reaches the threshold, after its latency, otherwise a failure after the
  threshold's latency.
* Equals: with `:er nil` the first name in `string<` order; with `:er t` one chosen at
  random (`random-item`) from the list of equals, which is in reverse order of encounter
  with `:esc t` and in chunk order with `:esc nil`. The choice is made before the threshold
  test, so it consumes a random number even when the retrieval fails. -/
def retrieve (P : Params) (now : Nat) (sources : List (Chunk × Float32)) (dm : List DMEntry)
    (spec : List ITest) (rng : MT) (finsts : List String := []) (recent : Option Bool := none) :
    Option DMEntry × Nat × MT × List (String × Float32) :=
  let cands := candidates P dm spec
  -- `:recently-retrieved` ([Src] `start-retrieval`): `t` keeps the marked chunks, in the
  -- order `intersection` gives (oldest marker first; reversed again with partial
  -- matching); `nil` removes them
  let cands := match recent with
    | some true =>
      let fs := if P.esc && P.mp.isSome then finsts else finsts.reverse
      fs.filterMap fun n => cands.find? (·.name == n)
    | some false => cands.filter (!finsts.contains ·.name)
    | none => cands
  let spec := spec.filter (!·.slot.startsWith ":")
  let pick := fun (best : List DMEntry) (rng : MT) =>
    if best.length > 1 && P.er then
      let (k, rng) := rng.randNat best.length
      (best[k]?, rng)
    else (firstByName best, rng)
  if !P.esc then
    let (r, rng) := pick cands rng
    (r, 0, rng, [])
  else
    let (best, bestVal, rng, ns) := cands.foldl
      (fun (acc : List DMEntry × Option Float32 × MT × List (String × Float32)) e =>
      let (best, bv, rng, ns) := acc
      let (a, rng, pn) := activation P now sources dm spec e rng
      let ns := match pn with | some n => (e.name, n) :: ns | none => ns
      match bv with
      | none => ([e], some a, rng, ns)
      | some v => if a == v then (e :: best, bv, rng, ns)
                  else if a > v then ([e], some a, rng, ns) else (best, bv, rng, ns)) ([], none, rng, [])
    match bestVal with
    | none => (none, latency P P.rt, rng, ns)
    | some v =>
      -- the choice among equals is made before the threshold test, so it draws even
      -- when the retrieval then fails
      let (r, rng) := pick best rng
      if v < P.rt then (none, latency P P.rt, rng, ns) else (r, latency P v, rng, ns)

/-! ## Adding chunks to declarative memory -/

/-- Merge a chunk cleared from a buffer ([Src] `merge-chunk-into-dm`). The merge table
(`dm-chunk-hash-table`) keeps one chunk per content, the one added last, so a chunk with the
same content as chunks in memory adds a reference to the most recently added of them;
otherwise the chunk is added under `name` with one reference. `dm` is in order of addition.
Returns the new memory. -/
def mergeDM (c : Chunk) (now : Nat) (name : String) (dm : List DMEntry) : List DMEntry :=
  match dm.reverse.findIdx? (·.chunk.sameContent c) with
  | some k =>
    let i := dm.length - 1 - k
    dm.modify i fun e => { e with count := e.count + 1, refs := now :: e.refs }
  | none => dm ++ [⟨{ c with name := name }, (now : Int), 1, [now], none, none, dm.length, c.slotSig⟩]

/-- The content of a chunk as a key: its slots in order of name, values compared as
`Chunk.Val.same` compares them (numbers by value and kind, strings ignoring case). -/
def Chunk.contentKey (c : Chunk) : String :=
  let v := fun (x : Val) => match x with
    | .sym s => "s" ++ s
    | .num f t => (if t.contains '.' then "f" else "i") ++ (if f == 0.0 then "0" else toString f.toBits)
    | .str s => "t" ++ s.toUpper
  let ps := (c.slots.map fun p => p.1 ++ "=" ++ v p.2).toArray.qsort (· < ·)
  String.intercalate "\u0001" ps.toList

/-! ## Properties -/

/-- Merging never shrinks declarative memory. -/
theorem mergeDM_length (c : Chunk) (now : Nat) (nm : String) (dm : List DMEntry) :
    dm.length ≤ (mergeDM c now nm dm).length := by
  unfold mergeDM
  split <;> simp

/-- **No chunk is ever lost from declarative memory.** Merging keeps the content of every
chunk already there, in place; only a reference count changes. ACT-R has no forgetting of
declarative content: decay lowers activation, it does not remove chunks. -/
theorem mergeDM_keeps (c : Chunk) (now : Nat) (nm : String) (dm : List DMEntry) (i : Nat)
    (h : i < dm.length) :
    ((mergeDM c now nm dm)[i]?.map (·.chunk)) = some dm[i].chunk := by
  unfold mergeDM
  split
  · rw [List.getElem?_modify]; simp [h]; split <;> simp
  · simp [List.getElem?_append_left h, List.getElem?_eq_getElem h]

end ACTR
