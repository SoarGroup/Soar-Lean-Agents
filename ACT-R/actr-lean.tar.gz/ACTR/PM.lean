import ACTR.Declarative
/-!
# ACT-R 7 in Lean — perceptual and motor data

Pure data and geometry for the vision and motor modules ([Src] core-modules/vision.lisp,
core-modules/motor.lisp, support/general-pm.lisp, other-files/keyboard.lisp,
framework/device-interface.lisp). The event handlers are in ACTR/Sim.lean.
-/

namespace ACTR

/-! ## Geometry, with SBCL's mixture of single and double floats -/

/-- Lisp's `pi` (a double). -/
def lispPi : Float := 3.141592653589793

/-- `rad->deg`: `r · (180/π)`; with `pi` a double the result is a double. -/
def radToDeg (r : Float32) : Float := r.toFloat * (180.0 / lispPi)

/-- `pixels->angle-mth` with an explicit distance: `rad->deg (2 · atan(p/2, d))`, the
`atan` of two rationals giving a single float. -/
def pixelsToAngle (px dist : Float) : Float :=
  let a : Float32 := (Float.atan2 (px / 2.0).toFloat32.toFloat dist.toFloat32.toFloat).toFloat32
  radToDeg ((2.0 : Float32) * a)

/-- `simple-size`: `0.01 · round(angle(w) · angle(h) / 0.01)`. -/
def simpleSize (w h d : Float) : Val :=
  let x := pixelsToAngle w d * pixelsToAngle h d
  let k := roundEven (x / (0.01 : Float32).toFloat).toFloat32
  Val.ofF32 ((0.01 : Float32) * (Float.ofInt k).toFloat32)

/-- Coordinates of a chunk or feature: `screen-x`, `screen-y`, `distance`. -/
def Chunk.xyz (c : Chunk) : Option (Float × Float × Float) :=
  match c.get "SCREEN-X", c.get "SCREEN-Y", c.get "DISTANCE" with
  | some (.num x _), some (.num y _), some (.num z _) => some (x, y, z)
  | _, _, _ => none

/-- `angle-between-vectors`, in degrees. -/
def angleBetween (v1 v2 : Float × Float × Float) : Float :=
  let s := (v2.1 - v1.1) ^ 2 + (v2.2.1 - v1.2.1) ^ 2 + v2.2.2 ^ 2
  let r : Float32 := s.toFloat32.sqrt
  radToDeg (Float.acos (v2.2.2.toFloat32 / r).toFloat).toFloat32

/-- `dist`: Euclidean distance (a single float). -/
def dist3 (a b : Float × Float × Float) : Float :=
  ((a.1 - b.1) ^ 2 + (a.2.1 - b.2.1) ^ 2 + (a.2.2 - b.2.2) ^ 2).toFloat32.sqrt.toFloat

/-! ## The visicon -/

/-- A visicon feature ([Src] `internal-add-visicon-features`): the visicon chunk
(`VISICON-IDn`), its location chunk (`VISUAL-LOCATIONn`), and the object it becomes when
attended. -/
structure VFeature where
  id : String
  loc : String
  /-- Slots of the visicon chunk (the object's value in `value`). -/
  slots : List (Slot × Val)
  /-- Slots and type of the object chunk. -/
  objType : String
  objSlots : List (Slot × Val)
  tstamp : Nat := 0
  isNew : Bool := true
  deriving Inhabited, Repr

def VFeature.chunk (f : VFeature) : Chunk := ⟨f.id, f.slots⟩

def VFeature.xyz (f : VFeature) : Float × Float × Float :=
  f.chunk.xyz.getD (0, 0, 0)

/-- `visicon-less-than`: by x, y, distance, then name. -/
def VFeature.lt (a b : VFeature) : Bool :=
  let (x1, y1, z1) := a.xyz
  let (x2, y2, z2) := b.xyz
  x1 < x2 || (x1 == x2 && (y1 < y2 || (y1 == y2 && (z1 < z2 || (z1 == z2 && a.id < b.id)))))

/-- `insert-into-visicon`: before the first feature it is less than. -/
def insertVisicon (f : VFeature) : List VFeature → List VFeature
  | [] => [f]
  | x :: xs => if f.lt x then f :: x :: xs else x :: insertVisicon f xs

/-- A change waiting for the next `proc-display`. -/
inductive VUpdate where
  | add (f : VFeature)
  | delete (id : String)
  | deleteAll
  | modify (id : String) (mods : List (Slot × Option Val × Option Val))
  deriving Inhabited

/-- The vision module's state ([Src] `vision-module`, `attn-module`, `pm-module`). -/
structure VisState where
  visicon : List VFeature := []
  updates : List VUpdate := []
  /-- Features changed by the last `proc-display`. -/
  changed : List String := []
  procScheduled : Bool := false
  locks : Nat := 0
  blocked : Bool := false
  visualLock : Bool := false
  /-- Finsts: visicon entries attended, with the time; most recent first. -/
  finsts : List (String × Nat) := []
  marker : Option String := none
  clof : Option (Float × Float × Float) := none
  attended : Option String := none
  moving : Bool := false
  scale : Option String := none
  attendFailure : Bool := false
  locFailure : Bool := false
  exec : Bool := false
  proc : Bool := false
  prep : Bool := false
  lastCmd : String := "NONE"
  /-- The spec of buffer stuffing (`set-visloc-default`). -/
  defaultSpec : List ITest := [⟨.eq, "SCREEN-X", some (.sym "LOWEST")⟩, ⟨.eq, ":ATTENDED", some (.sym "NEW")⟩]
  sceneChange : Option (Float × Nat) := none
  unstuffEv : Option Nat := none
  deriving Inhabited

/-- Vision parameters. -/
structure VisParams where
  latency : Nat := 85
  finstSpan : Nat := 3000
  numFinsts : Nat := 4
  onsetSpan : Nat := 500
  moveTolerance : Float := 0.5
  viewDist : Nat := 1080
  /-- `:viewing-distance` (inches) and `:pixels-per-inch`; `view-dist` is their product
  rounded, and `pm-pixels-to-angle` without a distance uses the product itself. -/
  viewInches : Float32 := 15.0
  ppi : Float32 := 72.0
  sceneThreshold : Float := 0.25
  /-- `:unstuff-visual-location`: ms, or none for nil. -/
  unstuff : Option Nat := some 500
  overstuff : Bool := false
  /-- `:auto-attend`: a successful visual-location request is followed by an attention shift. -/
  autoAttend : Bool := false
  deriving Inhabited, Repr

/-! ## Hands and the keyboard -/

/-- A hand position ([Src] `hand-pos`): the hand's location and each finger's offset. -/
structure HandPos where
  loc : Int × Int
  fingers : List (String × (Int × Int))
  /-- `target-coords` kept in `hand-pos-other` by a cursor movement: where the cursor will
  be, the start of the next cursor movement. -/
  target : Option (Int × Int × Int) := none
  /-- `hand-pos-device` set by a hand movement: the mouse (true) or the keyboard (false). -/
  dev : Option Bool := none
  deriving Inhabited, Repr, BEq

def leftOffsets : List (String × (Int × Int)) :=
  [("INDEX", (0, 0)), ("MIDDLE", (-1, 0)), ("RING", (-2, 0)), ("PINKIE", (-3, 0)), ("THUMB", (1, 2))]
def rightOffsets : List (String × (Int × Int)) :=
  [("INDEX", (0, 0)), ("MIDDLE", (1, 0)), ("RING", (2, 0)), ("PINKIE", (3, 0)), ("THUMB", (-1, 2))]
def leftHome : HandPos := { loc := (4, 4), fingers := leftOffsets }
def rightHome : HandPos := { loc := (7, 4), fingers := rightOffsets }

/-- A cursor location as Lisp prints the list `(x y z)`. -/
def xyzText (l : Int × Int × Int) : String := s!"({l.1} {l.2.1} {l.2.2})"

/-- The mouse's `cursor-pos`: where the right index finger rests on it. -/
def mousePos : Int × Int := (28, 2)

def HandPos.finger (h : HandPos) (f : String) : Int × Int :=
  let o := (h.fingers.lookup f).getD (0, 0)
  (h.loc.1 + o.1, h.loc.2 + o.2)

/-- A style command of a key: style, hand, finger, r, θ as written. -/
structure KeyStyle where
  style : String
  hand : String
  finger : String
  r : String
  theta : String
  deriving Inhabited, Repr

/-- A key ([Src] `specify-key`). -/
structure KeySpec where
  x : Nat
  y : Nat
  names : List String
  default : Bool
  style : Option KeyStyle
  handLoc : String
  deriving Inhabited, Repr

def keyboard : List KeySpec := [
  ⟨0, 0, ["ESC", "ESCAPE"], true, none, ""⟩,
  ⟨2, 0, ["F1"], true, none, ""⟩,
  ⟨3, 0, ["f2"], true, none, ""⟩,
  ⟨4, 0, ["f3"], true, none, ""⟩,
  ⟨5, 0, ["f4"], true, none, ""⟩,
  ⟨7, 0, ["F5"], true, none, ""⟩,
  ⟨8, 0, ["f6"], true, none, ""⟩,
  ⟨9, 0, ["f7"], true, none, ""⟩,
  ⟨10, 0, ["f8"], true, none, ""⟩,
  ⟨12, 0, ["F9"], true, none, ""⟩,
  ⟨13, 0, ["f10"], true, none, ""⟩,
  ⟨14, 0, ["f11"], true, none, ""⟩,
  ⟨15, 0, ["f12"], true, none, ""⟩,
  ⟨17, 0, ["f13", "print-screen"], true, none, ""⟩,
  ⟨18, 0, ["f14", "scroll-lock"], true, none, ""⟩,
  ⟨19, 0, ["f15", "pause"], true, none, ""⟩,
  ⟨0, 2, ["`", "backquote"], true, some ⟨"PECK-RECOIL", "LEFT", "PINKIE", "2.24", "-2.03"⟩, "LEFT-HOME"⟩,
  ⟨1, 2, ["1"], true, some ⟨"PECK-RECOIL", "LEFT", "PINKIE", "2", "-1.57"⟩, "LEFT-HOME"⟩,
  ⟨2, 2, ["2"], true, some ⟨"PECK-RECOIL", "LEFT", "RING", "2", "-1.57"⟩, "LEFT-HOME"⟩,
  ⟨3, 2, ["3"], true, some ⟨"PECK-RECOIL", "LEFT", "MIDDLE", "2", "-1.57"⟩, "LEFT-HOME"⟩,
  ⟨4, 2, ["4"], true, some ⟨"PECK-RECOIL", "LEFT", "INDEX", "2", "-1.57"⟩, "LEFT-HOME"⟩,
  ⟨5, 2, ["5"], true, some ⟨"PECK-RECOIL", "LEFT", "INDEX", "2.24", "-1.11"⟩, "LEFT-HOME"⟩,
  ⟨6, 2, ["6"], true, some ⟨"PECK-RECOIL", "RIGHT", "INDEX", "2.24", "-2.03"⟩, "RIGHT-HOME"⟩,
  ⟨7, 2, ["7"], true, some ⟨"PECK-RECOIL", "RIGHT", "INDEX", "2", "-1.57"⟩, "RIGHT-HOME"⟩,
  ⟨8, 2, ["8"], true, some ⟨"PECK-RECOIL", "RIGHT", "MIDDLE", "2", "-1.57"⟩, "RIGHT-HOME"⟩,
  ⟨9, 2, ["9"], true, some ⟨"PECK-RECOIL", "RIGHT", "RING", "2", "-1.57"⟩, "RIGHT-HOME"⟩,
  ⟨10, 2, ["0"], true, some ⟨"PECK-RECOIL", "RIGHT", "PINKIE", "2", "-1.57"⟩, "RIGHT-HOME"⟩,
  ⟨11, 2, ["-", "hyphen"], true, some ⟨"PECK-RECOIL", "RIGHT", "PINKIE", "2.24", "-1.11"⟩, "RIGHT-HOME"⟩,
  ⟨12, 2, ["=", "equal"], true, some ⟨"PECK-RECOIL", "RIGHT", "PINKIE", "2.83", "-0.78"⟩, "RIGHT-HOME"⟩,
  ⟨13, 2, ["delete"], true, some ⟨"PECK-RECOIL", "RIGHT", "PINKIE", "3.6", "-0.59"⟩, "RIGHT-HOME"⟩,
  ⟨15, 2, ["help"], true, none, ""⟩,
  ⟨16, 2, ["home"], true, none, ""⟩,
  ⟨17, 2, ["pageup"], true, none, ""⟩,
  ⟨19, 2, ["clear"], true, some ⟨"PECK-RECOIL", "RIGHT", "INDEX", "2", "-1.57"⟩, "KEYPAD"⟩,
  ⟨20, 2, ["keypad-=", "keypad-equal"], true, some ⟨"PECK-RECOIL", "RIGHT", "MIDDLE", "2", "-1.57"⟩, "KEYPAD"⟩,
  ⟨21, 2, ["keypad-/", "keypad-slash", "keypad-divide"], true, some ⟨"PECK-RECOIL", "RIGHT", "RING", "2", "-1.57"⟩, "KEYPAD"⟩,
  ⟨22, 2, ["keypad-*", "keypad-asterisk", "keypad-times"], true, some ⟨"PECK-RECOIL", "RIGHT", "PINKIE", "3", "-1.57"⟩, "KEYPAD"⟩,
  ⟨0, 3, ["tab"], true, some ⟨"PECK-RECOIL", "LEFT", "PINKIE", "1.41", "-2.36"⟩, "LEFT-HOME"⟩,
  ⟨1, 3, ["q"], true, some ⟨"PECK-RECOIL", "LEFT", "PINKIE", "1", "-1.57"⟩, "LEFT-HOME"⟩,
  ⟨2, 3, ["w"], true, some ⟨"PECK-RECOIL", "LEFT", "RING", "1", "-1.57"⟩, "LEFT-HOME"⟩,
  ⟨3, 3, ["e"], true, some ⟨"PECK-RECOIL", "LEFT", "MIDDLE", "1", "-1.57"⟩, "LEFT-HOME"⟩,
  ⟨4, 3, ["r"], true, some ⟨"PECK-RECOIL", "LEFT", "INDEX", "1", "-1.57"⟩, "LEFT-HOME"⟩,
  ⟨5, 3, ["t"], true, some ⟨"PECK-RECOIL", "LEFT", "INDEX", "1.41", "-0.79"⟩, "LEFT-HOME"⟩,
  ⟨6, 3, ["y"], true, some ⟨"PECK-RECOIL", "RIGHT", "INDEX", "1.41", "-2.36"⟩, "RIGHT-HOME"⟩,
  ⟨7, 3, ["u"], true, some ⟨"PECK-RECOIL", "RIGHT", "INDEX", "1", "-1.57"⟩, "RIGHT-HOME"⟩,
  ⟨8, 3, ["i"], true, some ⟨"PECK-RECOIL", "RIGHT", "MIDDLE", "1", "-1.57"⟩, "RIGHT-HOME"⟩,
  ⟨9, 3, ["o"], true, some ⟨"PECK-RECOIL", "RIGHT", "RING", "1", "-1.57"⟩, "RIGHT-HOME"⟩,
  ⟨10, 3, ["p"], true, some ⟨"PECK-RECOIL", "RIGHT", "PINKIE", "1", "-1.57"⟩, "RIGHT-HOME"⟩,
  ⟨11, 3, ["[", "left-bracket"], true, some ⟨"PECK-RECOIL", "RIGHT", "PINKIE", "1.41", "-0.78"⟩, "RIGHT-HOME"⟩,
  ⟨12, 3, ["]", "right-bracket"], true, some ⟨"PECK-RECOIL", "RIGHT", "PINKIE", "2.24", "-0.46"⟩, "RIGHT-HOME"⟩,
  ⟨13, 3, ["\\", "backslash"], true, some ⟨"PECK-RECOIL", "RIGHT", "PINKIE", "3.16", "-0.32"⟩, "RIGHT-HOME"⟩,
  ⟨15, 3, ["forward-delete", "del"], true, none, ""⟩,
  ⟨16, 3, ["end"], true, none, ""⟩,
  ⟨17, 3, ["pagedown"], true, none, ""⟩,
  ⟨19, 3, ["keypad-7"], true, some ⟨"PECK-RECOIL", "RIGHT", "INDEX", "1", "-1.57"⟩, "KEYPAD"⟩,
  ⟨20, 3, ["keypad-8"], true, some ⟨"PECK-RECOIL", "RIGHT", "MIDDLE", "1", "-1.57"⟩, "KEYPAD"⟩,
  ⟨21, 3, ["keypad-9"], true, some ⟨"PECK-RECOIL", "RIGHT", "RING", "1", "-1.57"⟩, "KEYPAD"⟩,
  ⟨22, 3, ["keypad--", "keypad-minus", "keypad-hyphen"], true, some ⟨"PECK-RECOIL", "RIGHT", "PINKIE", "2", "-1.57"⟩, "KEYPAD"⟩,
  ⟨0, 4, ["caps-lock"], true, some ⟨"PECK-RECOIL", "LEFT", "PINKIE", "1.0", "3.14"⟩, "LEFT-HOME"⟩,
  ⟨1, 4, ["a"], true, some ⟨"PUNCH", "LEFT", "PINKIE", "0", "0"⟩, "LEFT-HOME"⟩,
  ⟨2, 4, ["s"], true, some ⟨"PUNCH", "LEFT", "RING", "0", "0"⟩, "LEFT-HOME"⟩,
  ⟨3, 4, ["d"], true, some ⟨"PUNCH", "LEFT", "MIDDLE", "0", "0"⟩, "LEFT-HOME"⟩,
  ⟨4, 4, ["f"], true, some ⟨"PUNCH", "LEFT", "INDEX", "0", "0"⟩, "LEFT-HOME"⟩,
  ⟨5, 4, ["g"], true, some ⟨"PECK-RECOIL", "LEFT", "INDEX", "1", "0"⟩, "LEFT-HOME"⟩,
  ⟨6, 4, ["h"], true, some ⟨"PECK-RECOIL", "RIGHT", "INDEX", "1", "3.14"⟩, "RIGHT-HOME"⟩,
  ⟨7, 4, ["j"], true, some ⟨"PUNCH", "RIGHT", "INDEX", "0", "0"⟩, "RIGHT-HOME"⟩,
  ⟨8, 4, ["k"], true, some ⟨"PUNCH", "RIGHT", "MIDDLE", "0", "0"⟩, "RIGHT-HOME"⟩,
  ⟨9, 4, ["l"], true, some ⟨"PUNCH", "RIGHT", "RING", "0", "0"⟩, "RIGHT-HOME"⟩,
  ⟨10, 4, [";", "semicolon"], true, some ⟨"PUNCH", "RIGHT", "PINKIE", "0", "0"⟩, "RIGHT-HOME"⟩,
  ⟨11, 4, ["'", "quote"], true, some ⟨"PECK-RECOIL", "RIGHT", "PINKIE", "1", "0"⟩, "RIGHT-HOME"⟩,
  ⟨12, 4, ["return", "newline"], true, some ⟨"PECK-RECOIL", "RIGHT", "PINKIE", "2", "0"⟩, "RIGHT-HOME"⟩,
  ⟨13, 4, ["return", "newline"], false, none, ""⟩,
  ⟨19, 4, ["keypad-4"], true, some ⟨"PUNCH", "RIGHT", "INDEX", "0", "0"⟩, "KEYPAD"⟩,
  ⟨20, 4, ["keypad-5"], true, some ⟨"PUNCH", "RIGHT", "MIDDLE", "0", "0"⟩, "KEYPAD"⟩,
  ⟨21, 4, ["keypad-6"], true, some ⟨"PUNCH", "RIGHT", "RING", "0", "0"⟩, "KEYPAD"⟩,
  ⟨22, 4, ["keypad-+", "keypad-plus"], true, some ⟨"PECK-RECOIL", "RIGHT", "PINKIE", "1", "-1.57"⟩, "KEYPAD"⟩,
  ⟨0, 5, ["shift", "left-shift"], true, some ⟨"PECK-RECOIL", "LEFT", "PINKIE", "1.41", "2.36"⟩, "LEFT-HOME"⟩,
  ⟨1, 5, ["z"], true, some ⟨"PECK-RECOIL", "LEFT", "PINKIE", "1", "1.57"⟩, "LEFT-HOME"⟩,
  ⟨2, 5, ["x"], true, some ⟨"PECK-RECOIL", "LEFT", "RING", "1", "1.57"⟩, "LEFT-HOME"⟩,
  ⟨3, 5, ["c"], true, some ⟨"PECK-RECOIL", "LEFT", "MIDDLE", "1", "1.57"⟩, "LEFT-HOME"⟩,
  ⟨4, 5, ["v"], true, some ⟨"PECK-RECOIL", "LEFT", "INDEX", "1", "1.57"⟩, "LEFT-HOME"⟩,
  ⟨5, 5, ["b"], true, some ⟨"PECK-RECOIL", "LEFT", "INDEX", "1.41", "0.79"⟩, "LEFT-HOME"⟩,
  ⟨6, 5, ["n"], true, some ⟨"PECK-RECOIL", "RIGHT", "INDEX", "1.41", "2.36"⟩, "RIGHT-HOME"⟩,
  ⟨7, 5, ["m"], true, some ⟨"PECK-RECOIL", "RIGHT", "INDEX", "1", "1.57"⟩, "RIGHT-HOME"⟩,
  ⟨8, 5, [",", "comma"], true, some ⟨"PECK-RECOIL", "RIGHT", "MIDDLE", "1", "1.57"⟩, "RIGHT-HOME"⟩,
  ⟨9, 5, [".", "period", "dot"], true, some ⟨"PECK-RECOIL", "RIGHT", "RING", "1", "1.57"⟩, "RIGHT-HOME"⟩,
  ⟨10, 5, ["/", "slash"], true, some ⟨"PECK-RECOIL", "RIGHT", "PINKIE", "1", "1.57"⟩, "RIGHT-HOME"⟩,
  ⟨11, 5, ["right-shift"], true, some ⟨"PECK-RECOIL", "RIGHT", "PINKIE", "1.41", "0.78"⟩, "RIGHT-HOME"⟩,
  ⟨12, 5, ["right-shift"], false, none, ""⟩,
  ⟨13, 5, ["right-shift"], false, none, ""⟩,
  ⟨16, 5, ["up-arrow"], true, none, ""⟩,
  ⟨19, 5, ["keypad-1"], true, some ⟨"PECK-RECOIL", "RIGHT", "INDEX", "1", "1.57"⟩, "KEYPAD"⟩,
  ⟨20, 5, ["keypad-2"], true, some ⟨"PECK-RECOIL", "RIGHT", "MIDDLE", "1", "1.57"⟩, "KEYPAD"⟩,
  ⟨21, 5, ["keypad-3"], true, some ⟨"PECK-RECOIL", "RIGHT", "RING", "1", "1.57"⟩, "KEYPAD"⟩,
  ⟨22, 5, ["enter", "keypad-enter"], true, some ⟨"PUNCH", "RIGHT", "PINKIE", "0", "0"⟩, "KEYPAD"⟩,
  ⟨0, 6, ["control", "left-control"], true, some ⟨"PECK-RECOIL", "LEFT", "PINKIE", "2.24", "2.03"⟩, "LEFT-HOME"⟩,
  ⟨1, 6, ["option", "left-option"], true, some ⟨"PECK-RECOIL", "LEFT", "PINKIE", "2.0", "1.57"⟩, "LEFT-HOME"⟩,
  ⟨2, 6, ["command", "left-command"], true, some ⟨"PECK-RECOIL", "LEFT", "RING", "2.0", "1.57"⟩, "LEFT-HOME"⟩,
  ⟨3, 6, ["space"], false, none, ""⟩,
  ⟨4, 6, ["space"], false, none, ""⟩,
  ⟨5, 6, ["space"], true, some ⟨"PUNCH", "LEFT", "THUMB", "0", "0"⟩, "LEFT-HOME"⟩,
  ⟨6, 6, ["space"], false, none, ""⟩,
  ⟨7, 6, ["space"], false, none, ""⟩,
  ⟨8, 6, ["space"], false, none, ""⟩,
  ⟨9, 6, ["space"], false, none, ""⟩,
  ⟨10, 6, ["space"], false, none, ""⟩,
  ⟨11, 6, ["right-command"], true, some ⟨"PECK-RECOIL", "RIGHT", "PINKIE", "2.24", "1.11"⟩, "RIGHT-HOME"⟩,
  ⟨12, 6, ["right-option"], true, some ⟨"PECK-RECOIL", "RIGHT", "PINKIE", "2.83", "0.78"⟩, "RIGHT-HOME"⟩,
  ⟨13, 6, ["right-control"], true, some ⟨"PECK-RECOIL", "RIGHT", "PINKIE", "3.6", "0.59"⟩, "RIGHT-HOME"⟩,
  ⟨15, 6, ["left-arrow"], true, none, ""⟩,
  ⟨16, 6, ["down-arrow"], true, none, ""⟩,
  ⟨17, 6, ["right-arrow"], true, none, ""⟩,
  ⟨19, 6, ["keypad-0"], true, some ⟨"PUNCH", "RIGHT", "THUMB", "0", "0"⟩, "KEYPAD"⟩,
  ⟨20, 6, ["keypad-0"], false, none, ""⟩,
  ⟨21, 6, ["keypad-.", "keypad-dot", "keypad-period"], true, some ⟨"PECK-RECOIL", "RIGHT", "RING", "2", "1.57"⟩, "KEYPAD"⟩,
  ⟨22, 6, ["enter", "keypad-enter"], false, none, ""⟩
]

/-- `loc->key`: the first name given for the location, the last specification winning. -/
def locKey (x y : Int) : Option String :=
  (keyboard.filter (fun k => (k.x : Int) == x && (k.y : Int) == y)).getLast?.map (·.names.head!)

/-- `key->loc`: the location of the last specification naming the key. -/
def keyLoc (key : String) : Option (Int × Int) :=
  (keyboard.filter (fun k => k.names.any (·.toUpper == key.toUpper))).getLast?.map fun k => ((k.x : Int), (k.y : Int))

/-- `key->cmd`: the style of the last default specification naming the key. -/
def keyCmd (key : String) : Option KeyStyle :=
  ((keyboard.filter (fun k => k.default && k.style.isSome &&
    k.names.any (·.toUpper == key.toUpper))).getLast?).bind (·.style)

/-- A movement ([Src] `movement-style` and its subclasses). -/
structure Movement where
  /-- The style name used to compare preparations (`:PUNCH`, `:PECK`; peck-recoil is
  `:PECK`). -/
  styleName : String
  /-- The class: PUNCH, PECK, PECK-RECOIL. -/
  kind : String
  hand : String
  finger : String
  r : Float32 := 0
  theta : Float32 := 0
  requestTime : Nat
  execTime : Float32 := 0
  finishTime : Float32 := 0
  moveTime : Float32 := 0
  /-- A cursor movement (`cursor-ply`): the distance in degrees (a double), the target's
  approach width (a double) and the target coordinates. -/
  rD : Float := 0
  width : Float := 1.0
  target : Int × Int × Int := (0, 0, 0)
  /-- `updated-pos`: the hand's position after the movement, computed at preparation. -/
  upd : Option HandPos := none
  /-- A hand movement's device: the mouse (true) or the keyboard (false). -/
  toMouse : Bool := false
  /-- `exec-immediate-p`: false for a movement prepared with a `prepare` request, which
  waits for `execute`. -/
  execImm : Bool := true
  deriving Inhabited, Repr

/-- `num-to-prepare`: one plus the features set (a ply's finger is a dummy). -/
def Movement.numToPrepare (m : Movement) : Nat :=
  if m.kind == "PUNCH" then 3 else if m.styleName == "PLY" then 4 else 5

/-- `feat-differences`. -/
def Movement.featDiff (m1 m2 : Movement) : Nat :=
  if m1.kind == "PUNCH" then
    if m1.hand != m2.hand then 2 else if m1.finger != m2.finger then 1 else 0
  else
    -- `num-possible-feats`: one less for a ply
    let maxf := if m1.styleName == "PLY" then 4 else 5
    if m1.hand != m2.hand then maxf - 1
    else if m1.finger != m2.finger then maxf - 2
    else
      let dist := if m1.styleName == "PLY" then (m1.rD - m2.rD).abs < 2.0
        else (m1.r - m2.r).abs < 2.0
      let delta := (m1.theta.toFloat - m2.theta.toFloat).abs
      let dir := lispPi / 4.0 > delta || delta > 7.0 / 4.0 * lispPi
      (if dist then 0 else 1) + (if dir then 0 else 1)

/-- The motor module's state. -/
structure MotorState where
  prep : Bool := false
  proc : Bool := false
  exec : Bool := false
  lastCmd : String := "NONE"
  lastPrep : Option Movement := none
  queue : List Movement := []
  /-- `init-stamp` in ms; negative before any movement. -/
  initStamp : Int := -100
  left : HandPos := leftHome
  right : HandPos := rightHome
  /-- The hands' `next-loc`: where the last prepared movement leaves them. -/
  leftNext : Option HandPos := none
  rightNext : Option HandPos := none
  /-- The installed mouse cursor's location (`cursor-loc`), if a mouse is installed. -/
  mouse : Option (Int × Int × Int) := none
  /-- The right hand's device is the mouse (otherwise the keyboard). -/
  rightOnMouse : Bool := false
  deriving Inhabited

/-- Motor parameters (seconds, single floats). -/
structure MotorParams where
  featPrep : Float32 := 0.05
  initTime : Float32 := 0.05
  burst : Float32 := 0.05
  keyClosure : Float32 := 0.01
  minFitts : Float32 := 0.1
  peckCoef : Float32 := 0.075
  mouseCoef : Float32 := 0.1
  defaultTargetWidth : Float32 := 1.0
  deriving Inhabited, Repr

/-- `seconds->ms`. -/
def secToMs (x : Float32) : Nat := (roundEven (x * 1000.0)).toNat

/-- `fitts`: `max(min-fitts-time, coef · log2(d/w + 0.5))`. -/
def fitts (P : MotorParams) (coef d : Float32) (w : Float32 := 1.0) : Float32 :=
  let v := coef * (Float.log2 (d / w + 0.5).toFloat).toFloat32
  if P.minFitts > v then P.minFitts else v

/-- `round` of a double: to the nearest integer, ties to even. -/
def roundEvenD (d : Float) : Int :=
  let fl := Float.floor d
  let diff := d - fl
  let lo : Int := if fl < 0 then -((-fl).toUInt64.toNat : Int) else (fl.toUInt64.toNat : Int)
  if diff > 0.5 then lo + 1
  else if diff < 0.5 then lo
  else if lo % 2 == 0 then lo else lo + 1

/-- `seconds->ms` of a double. -/
def secToMsD (x : Float) : Nat := (roundEvenD (x * 1000.0)).toNat

/-- `fitts` with a double distance and width: `log` to base 2 of a double is a double. -/
def fittsD (P : MotorParams) (coef : Float32) (d w : Float) : Float :=
  let w := if w ≤ 0.0 then P.defaultTargetWidth.toFloat else w
  let v := coef.toFloat * (Float.log (d / w + 0.5) / Float.log 2.0)
  if P.minFitts.toFloat > v then P.minFitts.toFloat else v

/-- A single-float `atan` of two reals (SBCL: in double precision, then rounded). -/
def atanS (y x : Float) : Float32 := (Float.atan2 y x).toFloat32

/-- `xy-to-polar` of integer points: the distance and angle as single floats. -/
def xyToPolar (a b : Int × Int) : Float32 × Float32 :=
  let dx := b.1 - a.1
  let dy := b.2 - a.2
  let d : Float32 := (Float.sqrt (Float.ofInt (dx * dx + dy * dy))).toFloat32
  (d, if d == 0 then 0 else atanS (Float.ofInt dy) (Float.ofInt dx))

/-- `pixels->angle` of a double width (the result of `approach-width`'s double branches). -/
def pixelsToAngleD (px dist : Float) : Float :=
  (2.0 * Float.atan2 (px / 2.0) dist) * (180.0 / lispPi)

/-- `approach-width` of a target `w`×`h` pixels at distance `z`, approached at angle `theta`. -/
def approachWidth (w h : Int) (z : Float) (theta : Float32) : Float :=
  let ct : Float32 := atanS (Float.ofInt h) (Float.ofInt w)
  let th := if theta < 0 then -theta else theta
  if th.toFloat > lispPi / 2.0 then
    -- `(- pi theta)` is a double
    let t := lispPi - th.toFloat
    let ret := if t ≤ ct.toFloat then Float.ofInt w / Float.cos t
      else Float.ofInt h / Float.cos (lispPi / 2.0 - t)
    pixelsToAngleD ret z
  else if th == 0 then pixelsToAngle (Float.ofInt w) z
  else if th ≤ ct then
    let c : Float32 := (Float.cos th.toFloat).toFloat32
    pixelsToAngle ((Float.ofInt w).toFloat32 / c).toFloat z
  else pixelsToAngleD (Float.ofInt h / Float.cos (lispPi / 2.0 - th.toFloat)) z

def fmax (a b : Float32) : Float32 := if a ≥ b then a else b

/-- `polar-move-xy` rounded (`round-xy`). -/
def polarMove (p : Int × Int) (r theta : Float32) : Int × Int :=
  let x := (Float.ofInt p.1).toFloat32 + r * (Float.cos theta.toFloat).toFloat32
  let y := (Float.ofInt p.2).toFloat32 + r * (Float.sin theta.toFloat).toFloat32
  ((roundEven x : Int), (roundEven y : Int))

/-! ## Sounds and speech -/

/-- A sound event ([Src] `sound-event`): its sound chunk (`sname`) and its location chunk
(`ename`). Times in ms. -/
structure SoundEvt where
  sname : String
  ename : String
  onset : Nat
  offset : Nat
  content : Val
  delay : Nat
  kind : String
  attended : Bool := false
  location : String := "EXTERNAL"
  recode : Nat
  pitch : String := "MIDDLE"
  deriving Inhabited, Repr

/-- The audio module's state. -/
structure AudState where
  audicon : List SoundEvt := []
  prep : Bool := false
  proc : Bool := false
  exec : Bool := false
  lastCmd : String := "NONE"
  locFailure : Bool := false
  attendFailure : Bool := false
  attended : Option String := none
  lastStuffed : Option String := none
  defaultSpec : List ITest := [⟨.eq, ":ATTENDED", none⟩]
  deriving Inhabited

structure AudParams where
  digitDetect : Nat := 300
  digitRecode : Nat := 500
  digitDuration : Nat := 600
  toneDetect : Nat := 50
  toneRecode : Nat := 285
  decay : Nat := 3000
  /-- `:overstuff-aural-location`. -/
  overstuff : Bool := false
  deriving Inhabited, Repr

/-- A speak movement. -/
structure SpeakMv where
  text : String
  requestTime : Nat
  /-- `subvocalize` rather than `speak`. -/
  sub : Bool := false
  deriving Inhabited, Repr

/-- The speech module's state. -/
structure SpeechState where
  prep : Bool := false
  proc : Bool := false
  exec : Bool := false
  lastCmd : String := "NONE"
  lastPrep : Option SpeakMv := none
  queue : List SpeakMv := []
  deriving Inhabited

/-- Speech parameters: `:syllable-rate` (ms) and `:char-per-syllable`. -/
structure SpeechParams where
  syllableRate : Nat := 150
  charPerSyllable : Nat := 3
  /-- `:subvocalize-detect-delay`, ms. -/
  subvocalDelay : Nat := 300
  deriving Inhabited, Repr

/-- `get-art-time` in ms: `round(max(rate, rate · len/cps))`, the ratio exact. -/
def artTimeMs (P : SpeechParams) (text : String) : Nat :=
  let num := P.syllableRate * text.length
  let cps := P.charPerSyllable
  if num ≤ P.syllableRate * cps then P.syllableRate
  else
    -- round(num / cps), ties to even
    let q := num / cps
    let r := num % cps
    if 2 * r > cps then q + 1 else if 2 * r < cps then q else (if q % 2 == 0 then q else q + 1)

end ACTR
