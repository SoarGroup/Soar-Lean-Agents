import ACTR.Sim
/-!
# Reading ACT-R model files

An S-expression reader and the model commands used by tutorial-style model files:
`clear-all`, `define-model`, `sgp`, `chunk-type`, `add-dm`, `define-chunks`, `p`,
`goal-focus` and `spp`. Anything else inside a model is reported as unsupported, so the
harness skips the model instead of comparing it wrongly.
-/

namespace ACTR.Parse
open ACTR

inductive SX where
  | atom (s : String)      -- symbols upcased; numbers as written
  | str (s : String)
  | list (xs : List SX)
  deriving Inhabited, Repr

/-! ## Reader -/

partial def skipWs (cs : List Char) : List Char :=
  match cs with
  | [] => []
  | ';' :: rest => skipWs (rest.dropWhile (· != '\n'))
  | '#' :: '|' :: rest =>
    let rec blk : List Char → List Char
      | '|' :: '#' :: r => r
      | _ :: r => blk r
      | [] => []
    skipWs (blk rest)
  | c :: rest => if c.isWhitespace then skipWs rest else cs

def delim (c : Char) : Bool := c.isWhitespace || c == '(' || c == ')' || c == '"' || c == ';'

partial def readSX (cs : List Char) (q : Bool := false) : Except String (SX × List Char) := do
  match skipWs cs with
  | [] => throw "unexpected end of file"
  | '(' :: rest =>
    let rec items (cs : List Char) (acc : Array SX) : Except String (List SX × List Char) := do
      match skipWs cs with
      | ')' :: r => return (acc.toList, r)
      | [] => throw "unclosed ("
      | cs' =>
        let (x, r) ← readSX cs' q
        items r (acc.push x)
    let (xs, r) ← items rest #[]
    return (.list xs, r)
  | ')' :: _ => throw "unexpected )"
  | '"' :: rest =>
    let rec str (cs : List Char) (acc : String) : Except String (String × List Char) :=
      match cs with
      | '\\' :: c :: r => str r (acc.push c)
      | '"' :: r => .ok (acc, r)
      | c :: r => str r (acc.push c)
      | [] => .error "unclosed string"
    let (s, r) ← str rest ""
    return (.str s, r)
  | '\'' :: rest =>
    -- a quote is kept as `(QUOTE x)` when asked (for printing productions), else dropped
    if q then do
      let (x, r) ← readSX rest q
      return (.list [.atom "QUOTE", x], r)
    else readSX rest q
  | cs' =>
    let tok := String.ofList (cs'.takeWhile (!delim ·))
    return (.atom tok.toUpper, cs'.dropWhile (!delim ·))

partial def readAll (cs : List Char) (acc : Array SX := #[]) (q : Bool := false) : Except String (List SX) :=
  match skipWs cs with
  | [] => .ok acc.toList
  | cs' => do
    let (x, r) ← readSX cs' q
    readAll r (acc.push x) q

/-- The S-expression with each `(QUOTE x)` replaced by `x`. -/
partial def stripQuotes : SX → SX
  | .list [.atom "QUOTE", x] => stripQuotes x
  | .list xs => .list (xs.map stripQuotes)
  | x => x

/-! ## Values -/

def sdrop (s : String) (n : Nat) : String := String.ofList (s.toList.drop n)
def sdropR (s : String) (n : Nat) : String := String.ofList (s.toList.take (s.length - n))

def isDigits (s : String) : Bool := !s.isEmpty && s.all Char.isDigit

def stripSign (s : String) : String × String :=
  if s.startsWith "-" then ("-", sdrop s 1) else if s.startsWith "+" then ("", sdrop s 1) else ("", s)

/-- Lisp number syntax: an integer (`12`, `12.`) or a float (`.5`, `1.25`, `1e-3`). -/
def parseNum (tok : String) : Option Val :=
  let (sgn, t) := stripSign tok
  let t := if t.endsWith "." && isDigits (sdropR t 1) then sdropR t 1 else t
  if isDigits t then
    let n := t.toNat!
    some (.num (if sgn == "-" then -(Float.ofNat n) else Float.ofNat n) (sgn ++ toString n))
  else if (match t.splitOn "/" with | [a, b] => isDigits a && isDigits b && b.toNat! != 0 | _ => false) then
    -- a ratio, as Lisp prints one (`-3/10`)
    match t.splitOn "/" with
    | [a, b] =>
      let x := Float.ofNat a.toNat! / Float.ofNat b.toNat!
      some (.num (if sgn == "-" then -x else x) tok)
    | _ => none
  else
    let (mant, ex) := match (t.replace "D" "E").splitOn "E" with
      | [m] => (m, "")
      | [m, e] => (m, e)
      | _ => ("", "x")
    let (ip, fp) := match mant.splitOn "." with
      | [a] => (a, "")
      | [a, b] => (a, b)
      | _ => ("x", "")
    let okEx := ex.isEmpty || isDigits (stripSign ex).2
    if (isDigits ip || ip.isEmpty) && (isDigits fp || fp.isEmpty) && !(ip.isEmpty && fp.isEmpty)
       && okEx && (mant.contains '.' || !ex.isEmpty) then
      let digits := (if ip.isEmpty then "0" else ip) ++ fp
      let e10 : Int := (if ex.isEmpty then 0 else
        (let (es, ed) := stripSign ex; if es == "-" then -(ed.toNat! : Int) else ed.toNat!)) - fp.length
      let m := Float.ofNat digits.toNat!
      let x := if e10 ≥ 0 then m * Float.pow 10.0 (Float.ofInt e10)
               else m / Float.pow 10.0 (Float.ofInt (-e10))
      let x := if sgn == "-" then -x else x
      let txt := sgn ++ (if ip.isEmpty then "0" else ip) ++ "." ++ (if fp.isEmpty then "0" else fp) ++
                 (if ex.isEmpty then "" else "e" ++ ex)
      some (.num x txt)
    else none

def sxVal : SX → Option Val
  | .str s => some (.str s)
  | .atom "NIL" => none
  | .atom a => some ((parseNum a).getD (.sym a))
  | .list _ => none

def sxFloat (x : SX) : Option Float :=
  match x with
  | .atom a => match parseNum a with | some (.num f _) => some f | _ => none
  | _ => none

/-- How Lisp's `~s` prints an S-expression. -/
partial def sxRepr : SX → String
  | .atom a => a
  | .str s => "\"" ++ s ++ "\""
  | .list xs => "(" ++ " ".intercalate (xs.map sxRepr) ++ ")"

/-- How Lisp's `~a` prints an S-expression. -/
partial def sxPrinc : SX → String
  | .atom a => a
  | .str s => s
  | .list xs => "(" ++ " ".intercalate (xs.map sxPrinc) ++ ")"

/-- Seconds to ms as `seconds->ms` does it: rounded single-float product. -/
def secMs (x : Float) : Nat := (roundEven (f32 x * f32 1000.0)).toNat

/-- `schedule-event-relative` with its keyword arguments. -/
def schedCmd (d a : SX) (keys : List SX) : Except String TCmd := do
  let some delay := sxFloat d | throw "schedule-event delay"
  let action ← match a with
    | .str s => pure s
    | .atom s => pure s
    | _ => throw "schedule-event action"
  let rec kv : List SX → List (String × SX)
    | .atom k :: v :: r => (k, v) :: kv r
    | _ => []
  let ks := kv keys
  let (params, sp) := match ks.lookup ":PARAMS" with
    | some (.list xs) => (xs.map sxRepr, xs.map sxPrinc)
    | _ => ([], [])
  let inMs := match ks.lookup ":TIME-IN-MS" with | some (.atom "NIL") | none => false | _ => true
  let (prio, mx, mn) := match ks.lookup ":PRIORITY" with
    | some (.atom ":MAX") => ((0 : Int), true, false)
    | some (.atom ":MIN") => (0, false, true)
    | some v => (match sxFloat v with | some f => (Float.round f).toInt64.toInt | none => 0, false, false)
    | none => (0, false, false)
  let module := match ks.lookup ":MODULE" with
    | some (.atom m) => if m == ":NONE" then "NONE" else sdrop m (if m.startsWith ":" then 1 else 0)
    | _ => "NONE"
  let details := match ks.lookup ":DETAILS" with
    | some (.str s) => some s
    | _ => none
  let shown := match ks.lookup ":OUTPUT" with
    | some (.atom "NIL") => false
    | _ => true
  if (ks.lookup ":MAINTENANCE").any (fun v => match v with | .atom "NIL" => false | _ => true) then
    throw "maintenance task event"
  let dms := if inMs then (Float.round delay).toUInt64.toNat else secMs delay
  if action.toUpper == "SET-IMAGINAL-FREE" then
    return .schedAct dms .imaginalFree prio mx mn module (details.getD "SET-IMAGINAL-FREE") shown
  if action.toUpper == "SET-IMAGINAL-ERROR" then
    return .schedAct dms .imaginalError prio mx mn module (details.getD "SET-IMAGINAL-ERROR") shown
  -- `schedule-set-buffer-chunk` with a specification
  if action == "SET-BUFFER-CHUNK" then
    match ks.lookup ":PARAMS" with
    | some (.list (.atom b :: .list spec :: _)) =>
      let rec pairs : List SX → List ITest
        | .atom sl :: v :: r => ⟨.eq, sl, sxVal v⟩ :: pairs r
        | _ => []
      match Buf.ofName? b with
      | some bb =>
        return .schedAct dms (.setBufferSpec bb (pairs spec)) prio mx mn module (details.getD "") shown
      | none => throw "schedule-set-buffer-chunk"
    | _ => throw "schedule-set-buffer-chunk"
  return .sched dms action params sp prio mx mn module details shown

/-- Functions `Expr.evalPure` knows. -/
def knownFns : List String :=
  ["+", "-", "*", "/", "1+", "1-", "ABS", "MAX", "MIN", "FLOOR", "CEILING", "TRUNCATE", "ROUND",
   "MOD", "REM", "SQRT", "EXP", "LOG", "EXPT", "<", ">", "<=", ">=", "=", "/=", "ZEROP", "PLUSP",
   "MINUSP", "EVENP", "ODDP", "NUMBERP", "INTEGERP", "FLOATP", "SYMBOLP", "STRINGP", "NOT",
   "NULL", "EQ", "EQL", "EQUAL", "STRING=", "STRING-EQUAL", "AND", "OR", "IF", "WHEN", "UNLESS",
   "PROGN", "VALUES"]

/-- A Lisp expression of `!eval!`/`!bind!`. -/
partial def exprOf : SX → Except String Expr
  | .str s => .ok (.lit (some (.str s)))
  | .atom "NIL" => .ok (.lit none)
  | .atom a =>
    if a.startsWith "=" && a.length > 1 then .ok (.var (sdrop a 1))
    else .ok (.lit (sxVal (.atom a)))
  | .list (.str n :: args) => do return .cmd n (← args.mapM exprOf)
  | .list (.atom "CALL-ACT-R-COMMAND" :: .str n :: args) => do return .cmd n (← args.mapM exprOf)
  | .list (.atom f :: args) =>
    if knownFns.contains f then do return .app f (← args.mapM exprOf)
    else .error s!"Lisp function {f.toLower}"
  | _ => .error "Lisp expression"

/-! ## Models -/

/-- The slot names ACT-R defines before a model's own ([Src] the chunk-types of the modules). -/
def builtinSlots : List String :=
  ["ACTION", "ATTENDED", "BUFFER", "CENTER", "CLEAR", "CMD", "COLOR", "COLORS", "CONTENT",
   "DISTANCE", "DURATION", "EMPTY-SPACE", "END1-X", "END1-Y", "END2-X", "END2-Y", "ERROR",
   "EVENT", "EXECUTION", "FINGER", "FINISHED", "HAND", "HEIGHT", "ID", "KEY", "KIND",
   "LAST-COMMAND", "LEFT", "LINE", "LOC", "LOCATION", "MODALITY", "MP-VALUE", "NAME", "NEAREST",
   "OBJECT", "OBJECTS", "OFFSET", "OFFSETS", "ONSET", "OVAL", "PHRASE!", "PITCH", "PREPARATION",
   "PROCESSOR", "R", "RECENTLY-RETRIEVED", "RESULT", "RIGHT", "RT-VALUE", "SCALE",
   "SCENE-CHANGE", "SCENE-CHANGE-VALUE", "SCREEN-POS", "SCREEN-X", "SCREEN-Y",
   "SET-AUDLOC-DEFAULT", "SET-VISLOC-DEFAULT", "SIMPLE", "SIZE", "SLOTS", "SPEAK", "STATE",
   "STATUS", "STRING", "STYLE", "SUBVOCALIZE", "TEXT", "THETA", "TICKS", "TO-KEY", "VALUE",
   "WIDTH", "WORDS", "TICKS"]

/-- Chunk-types with default values defined by the vision and motor modules
([Src] `create-vision-module`, `create-motor-module`, `extend-manual-requests`). -/
def builtinDefaults : List (String × List (Slot × Val)) :=
  let cmd := fun (n : String) => (n, [("CMD", Val.sym n)])
  [("TEXT", [("TEXT", .sym "T")]), ("OVAL", [("OVAL", .sym "T")]), ("LINE", [("LINE", .sym "T")]),
   ("SET-VISLOC-DEFAULT", [("SET-VISLOC-DEFAULT", .sym "T")]), ("CLEAR", [("CLEAR", .sym "T")]),
   cmd "MOVE-ATTENTION", cmd "START-TRACKING", cmd "ASSIGN-FINST", cmd "CLEAR-SCENE-CHANGE",
   cmd "CLEAR-ALL-FINSTS", cmd "PREPARE", cmd "EXECUTE", cmd "PUNCH", cmd "PECK", cmd "PECK-RECOIL",
   cmd "PRESS-KEY", cmd "MOVE-CURSOR", cmd "CLICK-MOUSE", cmd "HAND-TO-MOUSE", cmd "HAND-TO-HOME",
   cmd "POINT-HAND-AT-KEY", cmd "SPEAK", cmd "SUBVOCALIZE", ("SIMPLE-ACTION", [("SIMPLE", .sym "T")]),
   ("TIME", [("TICKS", .num 0 "0")])]

structure Model where
  name : String := ""
  P : Params := {}
  prods : List Production := []
  chunks : List Chunk := []
  dm : List String := []
  /-- Default slot values of chunk-types (`chunk-type` with `(slot value)`), starting with
  the chunk-types the modules define. -/
  defaults : List (String × List (Slot × Val)) := builtinDefaults
  VP : VisParams := {}
  MP : MotorParams := {}
  AP : AudParams := {}
  SP : SpeechParams := {}
  /-- Commands of the model definition run at every reset, in order (`goal-focus`,
  `schedule-event`, `set-buffer-chunk`, `call-act-r-command`). -/
  init : List TCmd := []
  /-- `set-base-levels`: chunk, level, creation time (ms). -/
  bls : List (String × Float32 × Option Int) := []
  /-- `:iu`, the utility of productions defined from now on. -/
  iu : Float32 := 0.0
  /-- The model sets `:seed` itself. -/
  seedSet : Bool := false
  /-- The blending module is loaded (`(require-extra "blending")`). -/
  blending : Bool := false
  /-- Slot names of the model's chunk-types (with those of their parents). -/
  ctSlots : List String := []
  unsupported : List String := []
  deriving Inhabited

def Model.note (m : Model) (msg : String) : Model := { m with unsupported := m.unsupported ++ [msg] }

/-- Every symbol used as a slot value names a chunk ([Src] "Creating chunk X with no
slots"); add the ones not yet defined. -/
def Model.ensureChunk (m : Model) (n : String) : Model :=
  if m.chunks.any (·.name == n) then m else { m with chunks := m.chunks ++ [⟨n, []⟩] }

def Model.ensureVal (m : Model) : Option Val → Model
  | some (.sym "T") => m
  | some (.sym s) => m.ensureChunk s
  | _ => m

def isMarker (s : String) : Bool :=
  s.length > 2 && s.endsWith ">" &&
  (s.startsWith "=" || s.startsWith "?" || s.startsWith "+" || s.startsWith "-" ||
   s.startsWith "*" || s.startsWith "@")

def termOf : SX → Option Term
  | .atom a => if a.startsWith "=" && a.length > 1 then some (.var (sdrop a 1))
               else (sxVal (.atom a)).map .const
  | x => (sxVal x).map .const

def cmpOf : String → Option Cmp
  | "=" => some .eq | "-" => some .ne | "<" => some .lt | ">" => some .gt
  | "<=" => some .le | ">=" => some .ge | _ => none

/-- Request parameters modeled. -/
def requestParams : List String := [":RECENTLY-RETRIEVED", ":ATTENDED", ":NEAREST", ":CENTER",
  ":IGNORE-SLOTS", ":DO-NOT-GENERALIZE"]

/-- A request parameter whose value is a list of slot names (the blending module's
`:ignore-slots` and `:do-not-generalize`), kept as a string of the names. -/
def listParamVal : SX → Option Term
  | .list xs => some (.const (.str (" ".intercalate (xs.filterMap fun x => match x with
      | .atom a => some a | _ => none))))
  | .atom "NIL" => some (.const (.str ""))
  | _ => none

/-- Slot tests or specifications: `[ISA type] {[modifier] slot value}*`. -/
partial def parseTests2 (xs : List SX) (acc : Array SlotTest := #[]) : Except String (List SlotTest) :=
  match xs with
  | [] => .ok acc.toList
  | .atom "ISA" :: _ :: r => parseTests2 r acc
  | .atom m :: rest =>
    match cmpOf m with
    | some c =>
      match rest with
      | .atom slot :: v :: r =>
        if slot.startsWith ":" then .error s!"modifier on request parameter {slot}"
        else parseTests2 r (acc.push ⟨c, slot, termOf v⟩)
      | _ => .error "malformed slot test"
    | none =>
      if m.startsWith ":" && !requestParams.contains m then .error s!"request parameter {m}"
      else match rest with
        | v :: r =>
          if m == ":IGNORE-SLOTS" || m == ":DO-NOT-GENERALIZE" || (m == "SLOTS" && match v with | .list _ => true | _ => false) then
            match listParamVal v with
            | some t => parseTests2 r (acc.push ⟨.eq, m, some t⟩)
            | none => .error s!"request parameter {m}"
          else parseTests2 r (acc.push ⟨.eq, m, termOf v⟩)
        | [] => .error "slot without value"
  | _ => .error "malformed slot test"

partial def parseQueries (xs : List SX) (acc : Array QTest := #[]) : Except String (List QTest) :=
  match xs with
  | [] => .ok acc.toList
  | .atom "-" :: .atom s :: .atom v :: r => parseQueries r (acc.push ⟨true, s, v⟩)
  | .atom "=" :: .atom s :: .atom v :: r => parseQueries r (acc.push ⟨false, s, v⟩)
  | .atom s :: .atom v :: r => parseQueries r (acc.push ⟨false, s, v⟩)
  | _ => .error "malformed query"

/-- Split the items of a production side at buffer markers and `!…!` actions. -/
def segments (xs : List SX) : List (String × List SX) :=
  let r := xs.foldl (fun (acc : Array (String × Array SX)) x =>
    match x with
    | .atom a =>
      if isMarker a || (a.startsWith "!" && a.endsWith "!" && a.length > 2) then acc.push (a, #[])
      else if acc.isEmpty then acc.push ("", #[x])
      else acc.modify (acc.size - 1) fun p => (p.1, p.2.push x)
    | _ => if acc.isEmpty then acc.push ("", #[x])
           else acc.modify (acc.size - 1) fun p => (p.1, p.2.push x)) #[]
  r.toList.map fun p => (p.1, p.2.toList)

def bufOfMarker (m : String) : Except String Buf :=
  let n := sdropR (sdrop m 1) 1
  match Buf.ofName? n with
  | some b => .ok b
  | none => .error s!"buffer {n}"

/-- The chunk-type of a specification (`isa type`), if any. -/
def isaOf : List SX → Option String
  | .atom "ISA" :: .atom t :: _ => some t
  | _ => none

/-- A slot specification with its chunk-type's default values added for the slots it does
not test as filled or empty ([Src] `process-slots-specs`). -/
def specOf (defaults : List (String × List (Slot × Val))) (xs : List SX) :
    Except String (List SlotTest) := do
  let ts ← parseTests2 xs
  match isaOf xs with
  | some t =>
    let ds := (defaults.lookup t).getD []
    let fixed := fun (sl : Slot) => ts.any fun x => x.slot == sl &&
      (x.cmp != .ne || x.arg.isNone)
    return ts ++ (ds.filter (!fixed ·.1)).map fun d => ⟨.eq, d.1, some (.const d.2)⟩
  | none => return ts

/-- The tokens of S-expressions as `~s` prints them after `replace-variables`: variables
stay variables, numbers as Lisp prints them. -/
partial def sxToks : SX → List PTok
  | .atom a =>
    if a.startsWith "=" && a.length > 1 then [.var (a.drop 1).toString]
    else match parseNum a with
      | some v => [.lit v.repr]
      | none => [.lit a]
  | .str s => [.lit ("\"" ++ s ++ "\"")]
  | .list [.atom "QUOTE", x] => .lit "'" :: sxToks x
  | .list xs => [.lit "("] ++ ((xs.map sxToks).intersperse [.lit " "]).flatten ++ [.lit ")"]

def defToks (xs : List SX) : List PTok := ((xs.map sxToks).intersperse [.lit " "]).flatten

def parseProduction (name : String) (body : List SX) (defaults : List (String × List (Slot × Val)) := [])
    (rawBody : Option (List SX) := none) : Except String Production := do
  -- the body as written (with quotes) for the text of `!…!` statements
  let raw := (rawBody.getD body)
  let raw := match raw with | .str _ :: r => r | r => r
  let ri := (raw.findIdx? (fun x => match x with | .atom "==>" => true | _ => false)).getD raw.length
  let rawL := (segments (raw.take ri)).map (·.2)
  let rawR := (segments (raw.drop (ri + 1))).map (·.2)
  let parseTests2 := specOf defaults
  let body := match body with | .str _ :: r => r | r => r
  let i := body.findIdx? (fun x => match x with | .atom "==>" => true | _ => false)
  let some i := i | throw "no ==>"
  let lhs := segments (body.take i)
  let rhs := segments (body.drop (i + 1))
  let unsafeBang := (lhs ++ rhs).any fun x => x.1 == "!EVAL!" || x.1 == "!BIND!" || x.1 == "!MV-BIND!"
  let mut conds : Array Cond := #[]
  let mut lbinds : Array (Option (List String) × List String × LBind) := #[]
  let mut bangs : Array PStmt := #[]
  let mut li := 0
  for (m, xs) in lhs do
    let rxs := rawL[li]?.getD xs
    li := li + 1
    if m.startsWith "=" then
      conds := conds.push (.buf (← bufOfMarker m) (← parseTests2 xs))
    else if m.startsWith "?" then
      conds := conds.push (.query (← bufOfMarker m) (← parseQueries xs))
    else if m == "!EVAL!" || m == "!SAFE-EVAL!" then
      match xs with
      | [x] =>
        let e ← exprOf x
        if (match e with | .cmd _ _ => true | _ => false) then throw "task command in a condition"
        conds := conds.push (.eval e)
        bangs := bangs.push (.bang (sdropR (sdrop m 1) 1) (defToks rxs))
      | _ => throw s!"malformed {m}"
    else if m == "!BIND!" || m == "!SAFE-BIND!" then
      match xs with
      | [.atom v, x] =>
        if !v.startsWith "=" then throw "malformed !bind!"
        let e ← exprOf x
        if (match e with | .cmd _ _ => true | _ => false) then throw "task command in a condition"
        let x := sdrop v 1
        if (lbinds.toList.any fun b => b.2.2.vars.contains x) then throw s!"variable ={x} bound twice on the left-hand side"
        let deps := e.vars.eraseDups
        -- `(assoc var dependencies)`: an expression with no variables gives no key
        lbinds := lbinds.push (if deps.isEmpty then none else some [x], deps, { vars := [x], deps := deps, e := e, safe := m == "!SAFE-BIND!" })
        bangs := bangs.push (.bang (sdropR (sdrop m 1) 1) (defToks rxs))
      | _ => throw "malformed !bind!"
    else if m == "!MV-BIND!" then
      match xs with
      | [.list vs, x] =>
        let names := vs.filterMap fun v => match v with
          | .atom a => if a.startsWith "=" then some (sdrop a 1) else none
          | _ => none
        if names.length != vs.length || names.isEmpty then throw "malformed !mv-bind!"
        let e ← exprOf x
        if (match e with | .cmd _ _ => true | _ => false) then throw "task command in a condition"
        let deps := e.vars.eraseDups
        lbinds := lbinds.push (some names, deps, { vars := names, deps := deps, e := e, mv := true })
        bangs := bangs.push (.bang (sdropR (sdrop m 1) 1) (defToks rxs))
      | _ => throw "malformed !mv-bind!"
    else throw s!"condition {m}"
  -- a variable bound by a `!bind!` is not a slot name, and the bindings are not circular
  let lbs := lbinds.toList.map (·.2.2)
  let bvs := lbs.flatMap (·.vars)
  for c in conds do
    match c with
    | .buf _ ts => for t in ts do
        if isVarSlot t.slot && bvs.contains (t.slot.drop 1).toString then
          throw "a slot-name variable bound by !bind!"
    | _ => pure ()
  if lbs.any (fun b => b.deps.any b.vars.contains) then throw "circular variable bindings on the left-hand side"
  let lhsBinds := (sortForBindOrder lbinds.toList).map (·.2.2)
  let lhsText := bangs.toList ++ (conds.toList.filter (fun c => match c with | .eval _ => false | _ => true)).map PStmt.cond
  let mut acts : Array Action := #[]
  let mut rhsText : Array PStmt := #[]
  let mut ri2 := 0
  for (m, xs) in rhs do
    let rxs := rawR[ri2]?.getD xs
    ri2 := ri2 + 1
    if m.startsWith "!" then rhsText := rhsText.push (.bang (sdropR (sdrop m 1) 1) (defToks rxs))
    if m == "!OUTPUT!" then
      match xs with
      | [.list ts] => acts := acts.push (.output (ts.filterMap termOf))
      | [x] => acts := acts.push (.output ((termOf x).toList))
      | _ => throw "malformed !output!"
    else if m == "!STOP!" then acts := acts.push .stop
    else if m == "!EVAL!" || m == "!SAFE-EVAL!" then
      match xs with
      | [x] => acts := acts.push (.eval (← exprOf x))
      | _ => throw s!"malformed {m}"
    else if m == "!BIND!" || m == "!SAFE-BIND!" then
      match xs with
      | [.atom v, x] =>
        if v.startsWith "=" then acts := acts.push (.bind (sdrop v 1) (← exprOf x))
        else throw "malformed !bind!"
      | _ => throw "malformed !bind!"
    else if m == "!MV-BIND!" then
      -- several variables: their names joined by spaces
      match xs with
      | [.list vs, x] =>
        let names := vs.filterMap fun v => match v with
          | .atom a => if a.startsWith "=" then some (sdrop a 1) else none
          | _ => none
        if names.length != vs.length || names.isEmpty then throw "malformed !mv-bind!"
        acts := acts.push (.bind (" ".intercalate names) (← exprOf x))
      | _ => throw "malformed !mv-bind!"
    else if m.startsWith "!" then throw s!"action {m}"
    else if m.startsWith "=" then
      let b ← bufOfMarker m
      if !(conds.any fun c => match c with | .buf b' _ => b' == b | _ => false) then
        throw "modification of an untested buffer"
      match xs with
      | [.atom v] => if v.startsWith "=" then throw "buffer overwrite with a chunk" else throw "malformed modification"
      | _ =>
        let ts ← parseTests2 xs
        if ts.any (·.cmp != .eq) then throw "modifier in a modification"
        acts := acts.push (.modify b (ts.map fun t => (t.slot, t.arg)))
    else if m.startsWith "*" then
      let b ← bufOfMarker m
      if b == .retrieval then throw "modification request to the retrieval buffer"
      if !(conds.any fun c => match c with | .buf b' _ => b' == b | _ => false) then
        throw "modification request of an untested buffer"
      let ts ← parseTests2 xs
      if ts.any (·.cmp != .eq) then throw "modifier in a modification request"
      acts := acts.push (.modRequest b (ts.map fun t => (t.slot, t.arg)))
    else if m.startsWith "+" then
      let b ← bufOfMarker m
      match xs with
      | [x] => match termOf x with
        | some t => acts := acts.push (.directRequest b t)
        | none => throw "direct request"
      | _ =>
        let spec ← parseTests2 xs
        let cmd := (spec.find? (·.slot == "CMD")).bind (·.arg)
        let cname := match cmd with | some (.const v) => v.show | _ => "?"
        let ok := fun (cs : List String) => match cmd with
          | some (.const (.sym c)) => cs.contains c
          | some (.var _) => false
          | _ => spec.any (·.slot == "CLEAR")
        match b with
        | .manual => if !ok ["PRESS-KEY", "PUNCH", "PECK", "PECK-RECOIL", "CLEAR", "MOVE-CURSOR", "CLICK-MOUSE", "HAND-TO-MOUSE", "HAND-TO-HOME", "PREPARE", "EXECUTE", "POINT-HAND-AT-KEY"] then
            throw s!"manual request {cname.toLower}"
        | .visual => if !ok ["MOVE-ATTENTION", "CLEAR"] then throw s!"visual request {cname.toLower}"
        | .vocal => if !ok ["SPEAK", "SUBVOCALIZE", "CLEAR"] then throw s!"vocal request {cname.toLower}"
        | _ => pure ()
        acts := acts.push (.request b spec)
    else if m.startsWith "-" then
      acts := acts.push (.clear (← bufOfMarker m))
    else if m.startsWith "@" then
      let b ← bufOfMarker m
      match xs with
      | [] => acts := acts.push (.erase b)
      | [x] => match termOf x with
        | some t => acts := acts.push (.overwrite b (some t) [])
        | none => throw s!"malformed {m}"
      | _ => acts := acts.push (.overwrite b none (← parseTests2 xs))
    else throw s!"action {m}"
  -- the text of the actions as written, the `!…!` ones already recorded in place
  let mut j := 0
  let mut text : Array PStmt := #[]
  let mut k := 0
  for (m, _) in rhs do
    if m.startsWith "!" then
      text := text.push rhsText[k]!
      k := k + 1
    else
      -- the actions that are not `!…!` keep their order among themselves
      let nonBang := acts.toList.filter fun a => match a with
        | .output _ | .stop | .eval _ | .bind _ _ => false
        | _ => true
      match nonBang[j]? with
      | some a => text := text.push (.act a)
      | none => pure ()
      j := j + 1
  return { name := name, lhs := conds.toList, rhs := acts.toList, unsafeBang := unsafeBang, lhsBinds := lhsBinds,
           lhsText := lhsText, rhsText := text.toList }

/-- Model parameters set with `sgp`. Parameters that only change output are ignored; any
other parameter not modeled makes the model unsupported. -/
def ignoredParams : List String :=
  [":V", ":TRACE-DETAIL", ":ACT", ":LHST", ":RHST", ":CRT",
   ":MODEL-WARNINGS", ":STYLE-WARNINGS", ":SAVE-BUFFER-TRACE", ":SHOW-FOCUS",
   ":TRACE-FILTER", ":BUFFER-TRACE", ":NCNAR", ":USE-TREE", ":SAVE-DM-HISTORY",
   ":SAVE-P-HISTORY", ":CMDT", ":TRACE-MODULES", ":PRODUCTION-HIGHLIGHTING", ":SACT",
   ":SHOW-ALL-SLOTS", ":DCSC-HOOK", ":RECORD-TICKS", ":TIME-OUTPUT-LENGTH",
   -- `:optimize-visual` has no effect: nil is refused with a warning
   ":OPTIMIZE-VISUAL"]

def applySgp (m : Model) (args : List SX) : Model := Id.run do
  let mut m := m
  let mut xs := args
  while true do
    match xs with
    | .atom k :: v :: r =>
      xs := r
      let P := m.P
      let fv := sxFloat v
      let isNil := match v with | .atom "NIL" => true | _ => false
      let isT := match v with | .atom "T" => true | _ => false
      match k with
      | ":ESC" => m := { m with P := { P with esc := isT } }
      | ":LF" => match fv with
        | some f => m := { m with P := { P with lfMs := (roundEven (f32 f * f32 1000.0)).toNat } }
        | none => m := m.note "sgp :lf"
      | ":LE" => m := { m with P := { P with le := f32 (fv.getD 1.0) } }
      | ":RT" => m := { m with P := { P with rt := f32 (fv.getD 0.0) } }
      | ":BLC" => m := { m with P := { P with blc := f32 (fv.getD 0.0) } }
      | ":BLL" => m := { m with P := { P with bll := fv.map f32 } }
      | ":OL" => if isT then m := { m with P := { P with ol := true, olN := none } }
                 else if isNil then m := { m with P := { P with ol := false, olN := none } }
                 else match fv with
                   | some k => m := { m with P := { P with ol := false, olN := some (Float.round k).toUInt64.toNat } }
                   | none => m := m.note "sgp :ol"
      | ":MAS" => m := { m with P := { P with mas := fv.map f32 } }
      | ":GA" => m := { m with P := { P with ga := f32 (fv.getD 0.0) } }
      | ":IMAGINAL-ACTIVATION" => m := { m with P := { P with imaginalActivation := f32 (fv.getD 0.0) } }
      | ":DAT" => m := { m with P := { P with dat := (roundEven (f32 (fv.getD 0.05) * f32 1000.0)).toNat } }
      | ":IMAGINAL-DELAY" => m := { m with P := { P with imaginalDelay := (roundEven (f32 (fv.getD 0.2) * f32 1000.0)).toNat } }
      | ":UL" => m := { m with P := { P with ul := isT } }
      | ":IU" => m := { m with iu := f32 (fv.getD 0.0) }
      | ":NU" => m := { m with P := { P with nu := f32 (fv.getD 0.0) } }
      | ":ALPHA" => m := { m with P := { P with alpha := f32 (fv.getD 0.2) } }
      | ":ANS" => m := { m with P := { P with ans := fv.map f32 } }
      | ":DECLARATIVE-NUM-FINSTS" => m := { m with P := { P with numFinsts := (Float.round (fv.getD 4.0)).toUInt64.toNat } }
      | ":DECLARATIVE-FINST-SPAN" => m := { m with P := { P with finstSpanMs := secMs (fv.getD 3.0) } }
      | ":EGS" => m := { m with P := { P with egs := f32 (fv.getD 0.0) } }
      | ":MP" => m := { m with P := { P with mp := fv.map f32 } }
      | ":MS" => m := { m with P := { P with ms := f32 (fv.getD 0.0) } }
      | ":MD" => m := { m with P := { P with md := f32 (fv.getD (-1.0)) } }
      | ":ER" => m := { m with P := { P with er := isT } }
      | ":SEED" => match v with
        | .list [a, b] => match sxFloat a, sxFloat b with
          | some x, some y => m := { m with seedSet := true, P := { P with seed := (x.toUInt64.toNat, y.toUInt64.toNat) } }
          | _, _ => m := m.note "sgp :seed"
        | _ => m := m.note "sgp :seed"
      | ":EPL" => m := { m with P := { P with epl := isT } }
      | ":PCT" => m := { m with P := { P with pct := isT } }
      | ":TT" => m := { m with P := { P with ttMs := secMs (fv.getD 2.0) } }
      | ":CIA" | ":RIR" => if !isNil then m := m.note s!"sgp {k}"
      | ":PPM" => m := { m with P := { P with ppm := fv.map f32 } }
      | ":PPM-HOOK" => if !isNil then m := m.note "sgp :ppm-hook"
      | ":PAS" => m := { m with P := { P with pas := fv.map f32 } }
      | ":TMP" => m := { m with P := { P with tmp := fv.map f32 } }
      | ":SIM-HOOK" => match v with
        | .str h => m := { m with P := { P with simHook := some h.toLower } }
        | .atom "NIL" => m := { m with P := { P with simHook := none } }
        | _ => m := m.note "sgp :sim-hook (a Lisp function)"
      | ":CACHE-SIM-HOOK-RESULTS" => pure ()
      | ":BLEND-ALL-SLOTS" => m := { m with P := { P with blendAll := isT } }
      | ":BLT" | ":SBLT" => pure ()
      | ":CST" => m := { m with P := { P with cst := isT } }
      | ":NSJI" => m := { m with P := { P with nsjiT := isT } }
      | ":DCNN" => if !isT then m := m.note "sgp :dcnn nil"
      | ":NEEDS-MOUSE" => pure ()
      | ":ULT" => m := { m with P := { P with ult := isT } }
      | ":TIME-NOISE" => m := { m with P := { P with timeNoise := f32 (fv.getD 0.015) } }
      | ":TIME-MULT" => m := { m with P := { P with timeMult := f32 (fv.getD 1.1) } }
      | ":TIME-MASTER-START-INCREMENT" => m := { m with P := { P with timeStartMs := secMs (fv.getD 0.011) } }
      | ":RECORD-TICKS" => m := { m with P := { P with recordTicks := !isNil } }
      | ":PROCESS-CURSOR" => if !isNil then m := m.note "sgp :process-cursor (the cursor in the visicon)"
      | ":CURSOR-NOISE" => if !isNil then m := m.note "sgp :cursor-noise"
      | ":INCREMENTAL-MOUSE-MOVES" => if !isNil then m := m.note "sgp :incremental-mouse-moves"
      | ":MOUSE-FITTS-COEFF" => m := { m with MP := { m.MP with mouseCoef := f32 (fv.getD 0.1) } }
      | ":DEFAULT-TARGET-WIDTH" => m := { m with MP := { m.MP with defaultTargetWidth := f32 (fv.getD 1.0) } }
      | ":VIEWING-DISTANCE" | ":PIXELS-PER-INCH" =>
        match fv with
        | some f =>
          let VP := if k == ":VIEWING-DISTANCE" then { m.VP with viewInches := f32 f } else { m.VP with ppi := f32 f }
          m := { m with VP := { VP with viewDist := (roundEven (VP.viewInches * VP.ppi)).toNat } }
        | none => m := m.note s!"sgp {k}"
      | ":MIN-BL" | ":MAG->VALUE" | ":BLENDING-REQUEST-HOOK" | ":BLENDING-RESULT-HOOK" | ":BLENDING-SET-HOOK" =>
        if !isNil then m := m.note s!"sgp {k}"
      | ":VALUE->MAG" => if !(match v with | .atom "IDENTITY" => true | _ => false) then m := m.note s!"sgp {k}"
      | ":VISUAL-ATTENTION-LATENCY" => m := { m with VP := { m.VP with latency := secMs (fv.getD 0.085) } }
      | ":VISUAL-FINST-SPAN" => m := { m with VP := { m.VP with finstSpan := secMs (fv.getD 3.0) } }
      | ":VISUAL-NUM-FINSTS" => m := { m with VP := { m.VP with numFinsts := (Float.round (fv.getD 4.0)).toUInt64.toNat } }
      | ":VISUAL-ONSET-SPAN" => m := { m with VP := { m.VP with onsetSpan := secMs (fv.getD 0.5) } }
      | ":VISUAL-MOVEMENT-TOLERANCE" => m := { m with VP := { m.VP with moveTolerance := fv.getD 0.5 } }
      | ":SCENE-CHANGE-THRESHOLD" => m := { m with VP := { m.VP with sceneThreshold := (fv.getD 0.25).toFloat32.toFloat } }
      | ":UNSTUFF-VISUAL-LOCATION" =>
        if isNil then m := { m with VP := { m.VP with unstuff := none } }
        else match fv with
          | some f => m := { m with VP := { m.VP with unstuff := some (secMs f) } }
          | none => m := { m with VP := { m.VP with unstuff := some m.VP.onsetSpan } }
      | ":OVERSTUFF-VISUAL-LOCATION" => m := { m with VP := { m.VP with overstuff := !isNil } }
      | ":OVERSTUFF-AURAL-LOCATION" => m := { m with AP := { m.AP with overstuff := !isNil } }
      | ":AUTO-ATTEND" => m := { m with VP := { m.VP with autoAttend := !isNil } }
      | ":RANDOMIZE-TIME" =>
        let n? : Option Nat := match v with | .atom a => a.toNat? | _ => none
        if isNil then m := { m with P := { P with randTime := none } }
        else if isT then m := { m with P := { P with randTime := some 3 } }
        else if n?.any (· > 0) then m := { m with P := { P with randTime := n? } }
        else m := m.note "sgp :randomize-time"
      | ":DECLARATIVE-STUFFING" =>
        if isNil then m := { m with P := { P with stuff := none } }
        else match fv with
          | some f => if f > 0 then m := { m with P := { P with stuff := some (secMs f) } } else m := m.note "sgp :declarative-stuffing"
          | none => m := m.note "sgp :declarative-stuffing"
      | ":DIGIT-DETECT-DELAY" | ":DIGIT-DURATION" | ":DIGIT-RECODE-DELAY" | ":SOUND-DECAY-TIME"
      | ":TONE-DETECT-DELAY" | ":TONE-RECODE-DELAY" | ":SYLLABLE-RATE" | ":SUBVOCALIZE-DETECT-DELAY" =>
        match fv with
        | some f =>
          let ms := secMs f
          let AP := m.AP
          m := match k with
            | ":DIGIT-DETECT-DELAY" => { m with AP := { AP with digitDetect := ms } }
            | ":DIGIT-DURATION" => { m with AP := { AP with digitDuration := ms } }
            | ":DIGIT-RECODE-DELAY" => { m with AP := { AP with digitRecode := ms } }
            | ":SOUND-DECAY-TIME" => { m with AP := { AP with decay := ms } }
            | ":TONE-DETECT-DELAY" => { m with AP := { AP with toneDetect := ms } }
            | ":TONE-RECODE-DELAY" => { m with AP := { AP with toneRecode := ms } }
            | ":SYLLABLE-RATE" => { m with SP := { m.SP with syllableRate := ms } }
            | _ => { m with SP := { m.SP with subvocalDelay := ms } }
        | none => m := m.note s!"sgp {k}"
      | ":CHAR-PER-SYLLABLE" =>
        match v with
        | .atom a => match a.toNat? with
          | some n => if n > 0 then m := { m with SP := { m.SP with charPerSyllable := n } } else m := m.note "sgp :char-per-syllable"
          | none => m := m.note "sgp :char-per-syllable"
        | _ => m := m.note "sgp :char-per-syllable"
      | ":UTILITY-HOOK" => match v with
        | .str h => m := { m with P := { P with utilityHook := some h } }
        | .atom "NIL" => m := { m with P := { P with utilityHook := none } }
        | _ => m := m.note "sgp :utility-hook (a Lisp function)"
      | ":CYCLE-HOOK" => match v with
        | .str h => m := { m with P := { P with cycleHooks := h :: P.cycleHooks } }
        | .atom "NIL" => m := { m with P := { P with cycleHooks := [] } }
        | _ => m := m.note "sgp :cycle-hook (a Lisp function)"
      | ":RETRIEVED-CHUNK-HOOK" => match v with
        | .str h => m := { m with P := { P with retrievedHooks := h :: P.retrievedHooks } }
        | .atom "NIL" => m := { m with P := { P with retrievedHooks := [] } }
        | _ => m := m.note "sgp :retrieved-chunk-hook (a Lisp function)"
      | ":UT" =>
        if isNil then m := { m with P := { P with ut := none } }
        else if fv.isSome then m := { m with P := { P with ut := fv.map f32 } }
        else m := m.note "sgp :ut"
      | ":VPFT" => m := { m with P := { P with vpft := !isNil } }
      | ":VIDT" => m := { m with P := { P with vidt := !isNil } }
      | ":MOTOR-FEATURE-PREP-TIME" => m := { m with MP := { m.MP with featPrep := f32 (fv.getD 0.05) } }
      | ":MOTOR-INITIATION-TIME" => m := { m with MP := { m.MP with initTime := f32 (fv.getD 0.05) } }
      | ":MOTOR-BURST-TIME" => m := { m with MP := { m.MP with burst := f32 (fv.getD 0.05) } }
      | ":PECK-FITTS-COEFF" => m := { m with MP := { m.MP with peckCoef := f32 (fv.getD 0.075) } }
      | ":MIN-FITTS-TIME" => m := { m with MP := { m.MP with minFitts := f32 (fv.getD 0.1) } }
      | ":KEY-CLOSURE-TIME" => m := { m with MP := { m.MP with keyClosure := f32 (fv.getD 0.01) } }
      | ":DO-NOT-HARVEST" => match v with
        | .atom b => match Buf.ofName? b with
          | some bb => m := { m with P := { P with proc := { P.proc with doNotHarvest := P.proc.doNotHarvest ++ [bb] } } }
          | none => m := m.note s!"sgp :do-not-harvest {b}"
        | _ => m := m.note "sgp :do-not-harvest"
      | _ => if !ignoredParams.contains k then m := m.note s!"sgp {k}"
    | [] => break
    | _ => m := m.note "malformed sgp"; break
  return m

def addChunkDef (m : Model) (x : SX) (inDM : Bool) : Model :=
  let x := match x with | .atom n => SX.list [.atom n] | x => x
  match x with
  | .list (.atom n :: rest) =>
    let ds := match isaOf rest with | some t => (m.defaults.lookup t).getD [] | none => []
    let rest := match rest with | .atom "ISA" :: _ :: r => r | r => r
    let named := (rest.zipIdx.filter (·.2 % 2 == 0)).filterMap fun y => match y.1 with | .atom a => some a | _ => none
    let rest := rest ++ (ds.filter (!named.contains ·.1)).flatMap fun d =>
      [SX.atom d.1, match d.2 with | .str s => .str s | v => .atom v.show]
    let rec pairs (xs : List SX) (acc : List (Slot × Val)) (m : Model) : List (Slot × Val) × Model :=
      match xs with
      | .atom s :: v :: r =>
        let val := sxVal v
        pairs r (match val with | some vv => acc ++ [(s, vv)] | none => acc) (m.ensureVal val)
      | _ => (acc, m)
    let (slots, m) := pairs rest [] m
    let m := { m with chunks := m.chunks.filter (·.name != n) ++ [⟨n, slots⟩] }
    if inDM then { m with dm := m.dm ++ [n] } else m
  | _ => m.note "malformed chunk definition"

def applySpp (m : Model) (args : List SX) : Model :=
  let (names, ps) : List String × List SX := match args with
    | SX.atom n :: r => if n.startsWith ":" then (m.prods.map Production.name, args) else ([n], r)
    | SX.list ns :: r => (ns.filterMap (fun (x : SX) => match x with | SX.atom a => some a | _ => none), r)
    | _ => ([], [])
  let rec go (xs : List SX) (m : Model) : Model :=
    match xs with
    | .atom ":U" :: v :: r =>
      go r { m with prods := m.prods.map fun (p : Production) => if names.contains p.name then { p with u := f32 ((sxFloat v).getD 0.0) } else p }
    | .atom ":REWARD" :: v :: r =>
      -- ACT-R sets a reward only when :ul is on ("PARAMETER REWARD CAN ONLY BE SET WHEN UL IS T")
      if !m.P.ul then go r m else
      go r { m with prods := m.prods.map fun (p : Production) => if names.contains p.name then { p with reward := (sxFloat v).map (fun x => (f32 x, match v with | .atom a => a | _ => "")) } else p }
    | .atom ":AT" :: v :: r =>
      go r { m with prods := m.prods.map fun (p : Production) => if names.contains p.name then
        { p with actTime := some (roundEven (f32 ((sxFloat v).getD 0.05) * f32 1000.0)).toNat } else p }
    | .atom k :: _ :: r => go r (m.note s!"spp {k}")
    | _ => m
  go ps m

/-- A chunk defined without a name (`(define-chunks (isa type ...))`): named by `new-name` from
its type, or CHUNK. -/
def Model.anonChunk (m : Model) (d : SX) : String × Model :=
  match d with
  | .list xs =>
    let pre := match isaOf xs with | some t => (if t == "CHUNK" then "CHUNK" else t) | none => "CHUNK"
    let n := Id.run do
      let mut k := 0
      while m.chunks.any (·.name == pre ++ toString k) do k := k + 1
      return pre ++ toString k
    (n, addChunkDef m (.list (.atom n :: xs)) false)
  | _ => ("", m.note "define-chunks")

def modelForm (m : Model) (x : SX) : Model :=
  let raw := x
  let x := stripQuotes x
  match x with
  | .list (.atom "SGP" :: args) => applySgp m args
  | .list (.atom "CHUNK-TYPE" :: hd :: rest) =>
    let (name, parents) : String × List String := match hd with
      | SX.atom n => (n, [])
      | SX.list (SX.atom n :: opts) => (n, opts.filterMap fun (o : SX) => match o with
          | SX.list [SX.atom ":INCLUDE", SX.atom p] => some p
          | _ => none)
      | _ => ("", [])
    let inherited : List (Slot × Val) := parents.flatMap fun p => (m.defaults.lookup p).getD []
    let own : List (Slot × Val) := rest.filterMap fun (y : SX) => match y with
      | SX.list [SX.atom sl, v] => (sxVal v).map (sl, ·)
      | _ => none
    let ds := own ++ inherited.filter (fun (d : Slot × Val) => !own.any (·.1 == d.1))
    let m := ds.foldl (fun (m : Model) (d : Slot × Val) => m.ensureVal (some d.2)) m
    let m := { m with ctSlots := m.ctSlots ++ rest.filterMap fun (y : SX) => match y with
      | SX.atom sl => some sl
      | SX.list (SX.atom sl :: _) => some sl
      | _ => none }
    if ds.isEmpty then m else { m with defaults := (name, ds) :: m.defaults }
  | .list (.atom "ADD-DM" :: es) => es.foldl (fun m e => addChunkDef m e true) m
  | .list (.atom "DEFINE-CHUNKS" :: es) => es.foldl (fun m e => addChunkDef m e false) m
  | .list [.atom "GOAL-FOCUS-FCT", .list [.atom "CAR", .list (.atom "DEFINE-CHUNKS" :: d :: _)]] =>
    let (n, m) := m.anonChunk d
    { m with init := m.init ++ [.goalFocus n] }
  | .list [.atom "SET-BUFFER-CHUNK", .atom b, .list [.atom "CAR", .list (.atom "DEFINE-CHUNKS" :: d :: _)]] =>
    match Buf.ofName? b with
    | some bb => let (n, m) := m.anonChunk d; { m with init := m.init ++ [.setBufferChunk bb n true] }
    | none => m.note s!"set-buffer-chunk {b}"
  | .list (.atom "GOAL-FOCUS" :: .atom g :: _) | .list [.atom "GOAL-FOCUS-FCT", .atom g] =>
    { m with init := m.init ++ [.goalFocus g] }
  | .list (.atom "SCHEDULE-EVENT" :: d :: a :: keys) | .list (.atom "SCHEDULE-EVENT-RELATIVE" :: d :: a :: keys) =>
    match schedCmd d a keys with
    | .ok c => { m with init := m.init ++ [c] }
    | .error e => m.note e
  | .list [.atom "SET-BUFFER-CHUNK", .atom b, .list spec] =>
    match Buf.ofName? b, specOf m.defaults spec with
    | some bb, .ok ts =>
      let its := ts.filterMap fun t => match t.arg with
        | some (.const v) => some (ITest.mk t.cmp t.slot (some v))
        | none => some (ITest.mk t.cmp t.slot none)
        | _ => none
      let m := its.foldl (fun m t => m.ensureVal t.arg) m
      { m with init := m.init ++ [.setBufferSpec bb its] }
    | _, _ => m.note s!"set-buffer-chunk {b}"
  | .list [.atom "SET-BUFFER-CHUNK", .atom b, .atom c] =>
    match Buf.ofName? b with
    | some b => { m with init := m.init ++ [.setBufferChunk b c true] }
    | none => m.note s!"set-buffer-chunk {b}"
  | .list (.atom "SET-VISLOC-DEFAULT" :: xs) =>
    match parseTests2 xs with
    | .ok ts =>
      let its := ts.filterMap fun t => match t.arg with
        | some (.const v) => some (ITest.mk t.cmp t.slot (some v))
        | none => some (ITest.mk t.cmp t.slot none)
        | some (.var _) => none
      { m with init := m.init ++ [.setVislocDefault its] }
    | .error e => m.note s!"set-visloc-default: {e}"
  | .list (.atom "SET-AUDLOC-DEFAULT" :: xs) =>
    match parseTests2 xs with
    | .ok ts =>
      let its := ts.filterMap fun t => match t.arg with
        | some (.const v) => some (ITest.mk t.cmp t.slot (some v))
        | none => some (ITest.mk t.cmp t.slot none)
        | some (.var _) => none
      { m with init := m.init ++ [.setAudlocDefault its] }
    | .error e => m.note s!"set-audloc-default: {e}"
  | .list (.atom "CALL-ACT-R-COMMAND" :: .str n :: args) =>
    { m with init := m.init ++ [.call n (args.map sxRepr)] }
  | .list (.atom "SPP" :: args) => applySpp m args
  | .list (.atom "DECLARE-BUFFER-USAGE" :: _) => m
  | .list (.atom "SET-BASE-LEVELS" :: xs) =>
    if m.P.bll.isSome && (!m.P.ol || m.P.olN.isSome) then m.note "set-base-levels with :ol nil or a number" else
    xs.foldl (fun m x => match x with
      | .list (.atom c :: lv :: rest) => match sxFloat lv with
        | some l =>
          let ct := match rest with
            | [t] => (sxFloat t).map fun t => roundEven (f32 t * f32 1000.0)
            | _ => none
          { m with bls := m.bls ++ [(c, f32 l, ct)] }
        | none => m.note "set-base-levels"
      | _ => m.note "set-base-levels") m
  | .list (.atom "SET-ALL-BASE-LEVELS" :: lv :: rest) =>
    if m.P.bll.isSome && (!m.P.ol || m.P.olN.isSome) then m.note "set-all-base-levels with :ol nil or a number" else
    match sxFloat lv with
    | some l =>
      let ct := match rest with
        | [t] => (sxFloat t).map fun t => roundEven (f32 t * f32 1000.0)
        | _ => none
      { m with bls := m.bls ++ m.dm.map fun c => (c, f32 l, ct) }
    | none => m.note "set-all-base-levels"
  | .list (.atom "ADD-SJI" :: xs) | .list [.atom "ADD-SJI-FCT", .list xs] =>
    xs.foldl (fun m x => match x with
      | .list [.atom j, .atom i, v] => match sxFloat v with
        | some f =>
          -- "Bad Sji setting" for a name that is not a chunk
          if !(m.chunks.any (·.name == j) && m.chunks.any (·.name == i)) then m else
          let keep := m.P.sjis.filter fun y => !(y.1 == j && y.2.1 == i)
          { m with P := { m.P with sjis := (j, i, f32 f) :: keep } }
        | none => m
      | _ => m) m
  | .list (.atom "SET-SIMILARITIES" :: xs) =>
    xs.foldl (fun m x => match x with
      | .list [.atom a, .atom b, v] => match sxFloat v with
        -- a pair naming a chunk that does not exist yet is ignored ("Bad similarity setting")
        | some _ => if !(m.chunks.any (·.name == a) && m.chunks.any (·.name == b)) then m else
          match sxFloat v with
          | none => m
          | some f =>
          let keep := m.P.sims.filter (fun y => !((y.1 == a && y.2.1 == b) || (y.1 == b && y.2.1 == a)))
          { m with P := { m.P with sims := (a, b, f32 f) :: keep } }
        | none => m.note "set-similarities"
      | _ => m.note "set-similarities") m
  | .list (.atom "P" :: .atom n :: body) =>
    let rawBody := match raw with | .list (_ :: _ :: b) => some b | _ => none
    match parseProduction n body m.defaults rawBody with
    -- a production with an unbound variable is not defined (ACT-R warns)
    | .ok p => if !p.wellBound then m else
      -- a production's action time is `:dat` when it is defined ([Src] `production-at`)
      let p := { p with u := m.iu, actTime := some m.P.dat }
      let consts := p.lhs.foldl (fun acc c => match c with
        | .buf _ ts => acc ++ ts.filterMap (fun t => match t.arg with | some (.const v) => some v | _ => none)
        | _ => acc) [] ++
        p.rhs.foldl (fun acc a => match a with
        | .modify _ s => acc ++ s.filterMap (fun t => match t.2 with | some (.const v) => some v | _ => none)
        | .request _ ts => acc ++ ts.filterMap (fun t => if t.slot.startsWith ":" then none else match t.arg with | some (.const v) => some v | _ => none)
        | _ => acc) []
      let m := consts.foldl (fun m v => m.ensureVal (some v)) m
      { m with prods := m.prods ++ [p] }
    | .error e => m.note s!"production {n}: {e}"
  -- the keyboard and the hands are always there in this model
  | .list [.atom "INSTALL-DEVICE", .list [.str "motor", .str "keyboard"]] => m
  | .list (.atom f :: _) => m.note f.toLower
  | _ => m

def parseModel (src : String) : Except String Model := do
  let rawForms ← readAll src.toList (q := true)
  let mut m : Model := {}
  let mut found := false
  for rf in rawForms do
    let f := stripQuotes rf
    let rbody := match rf with | .list (_ :: _ :: b) => b | _ => []
    match f with
    | .list (.atom "DEFINE-MODEL" :: .atom n :: _) =>
      found := true
      m := rbody.foldl modelForm { m with name := n }
    | .list (.atom "CLEAR-ALL" :: _) => pure ()
    | .list [.atom "REQUIRE-EXTRA", .str x] =>
      if x.toLower == "blending" then m := { m with blending := true }
      else m := m.note s!"extra {x}"
    | .list (.atom g :: _) => m := m.note s!"top-level {g.toLower}"
    | _ => pure ()
  if !found then throw "no define-model"
  if m.P.epl && m.P.ppm.isSome then m := m.note "production compilation with :ppm"
  if m.P.cst && m.P.utilityHook.isSome then m := m.note "the conflict-set trace with :utility-hook"
  if m.P.epl && m.prods.any (·.lhsBinds.any (·.safe)) then
    m := m.note "production compilation with a left-hand side !safe-bind!"
  -- goal-focus of a chunk that does not exist fails
  return m

/-! ## Task commands recorded by tools/actr/task.lisp -/

def atomName : SX → String
  | .atom a => a | .str s => s | _ => ""

/-- Chunk definitions of `add-dm`/`define-chunks` as recorded. -/
def chunkDefs (xs : List SX) : List Chunk :=
  let m := xs.foldl (fun m e => addChunkDef m e false) ({} : Model)
  m.chunks

/-- A visicon feature as given to `add-visicon-features`: slot, value or values. -/
def featureOf : SX → List (Slot × List Val)
  | .list xs =>
    let rec go : List SX → List (Slot × List Val)
      | .atom sl :: v :: r =>
        let vs := match v with
          | .list ys => ys.map fun y => (sxVal y).getD (.sym "NIL")
          | y => (sxVal y).toList
        (sl, vs) :: go r
      | _ => []
    go xs
  | _ => []

/-- An onset given to a new sound: seconds, or ms with `time-in-ms`. -/
def onsetOf (o ms : SX) : Option Nat :=
  match sxFloat o with
  | some x => match ms with
    | .atom "NIL" => some (secMs x)
    | _ => some (Float.round x).toUInt64.toNat
  | none => none

/-- A `#CMD` line (without `#CMD `) other than `RESET` and `RUN`. -/
def parseTCmd (body : String) : Except String TCmd := do
  let (cmd, rest) := match body.splitOn " " with
    | c :: r => (c, " ".intercalate r)
    | [] => ("", "")
  let args ← readAll rest.toList
  match cmd, args with
  | "PDISABLE", _ => return .pdisable (args.map atomName)
  | "PENABLE", _ => return .penable (args.map atomName)
  | "MOD-CHUNK", .atom n :: mods =>
    let rec pairs : List SX → List (Slot × Option Val)
      | .atom sl :: v :: r => (sl, sxVal v) :: pairs r
      | _ => []
    return .modChunk n (pairs mods)
  | "SGP", ps0 =>
    let ps := match ps0 with | [.list xs] => xs | xs => xs
    -- a query (all names): nothing changes
    if ps.all (fun x => match x with | .atom k => k.startsWith ":" | _ => false) then return .noop
    -- parameters set by task code: only those the model handles, and not the seed
    let test := applySgp {} ps
    if !test.unsupported.isEmpty then throw s!"task {"; ".intercalate test.unsupported}"
    if ps.any (fun x => match x with | .atom ":SEED" => true | _ => false) then throw "task sgp :seed"
    return .setParams fun (P, VP, MP) =>
      let m := applySgp { P := P, VP := VP, MP := MP } ps
      (m.P, m.VP, m.MP)
  | "CLEAR-BUFFER", [.atom b] =>
    match Buf.ofName? b with
    | some bb => return .clearBuffer bb
    | none => throw s!"clear-buffer {b}"
  | "MOD-FOCUS", mods =>
    let rec pairs2 : List SX → List (Slot × Option Val)
      | .atom sl :: v :: r => (sl, sxVal v) :: pairs2 r
      | _ => []
    return .modFocus (pairs2 mods)
  | "GOAL-FOCUS", [.atom g] => return .goalFocus g
  | "SET-BUFFER-CHUNK", .atom b :: .list spec :: r =>
    let rec pairs3 : List SX → List ITest
      | .atom sl :: v :: r => ⟨.eq, sl, sxVal v⟩ :: pairs3 r
      | _ => []
    match Buf.ofName? b, r with
    | some bb, [] | some bb, [.atom "T"] => return .setBufferSpec bb (pairs3 spec)
    | _, _ => throw s!"set-buffer-chunk {b} with a specification"
  | "SET-BUFFER-CHUNK", .atom b :: .atom c :: r =>
    match Buf.ofName? b with
    | some b => return .setBufferChunk b c (match r with | [.atom "NIL"] => false | _ => true)
    | none => throw s!"set-buffer-chunk {b}"
  | "SCHEDULE-EVENT-RELATIVE", d :: a :: keys => schedCmd d a keys
  | "TRIGGER-REWARD", [v] =>
    match sxFloat v with
    | some r => return .triggerReward (f32 r) (sxRepr v)
    | none => throw "non-numeric reward"
  | "ADD-DM", [.list ds] => return .addDM (chunkDefs ds)
  | "ADD-VISICON-FEATURES", [_, .list fs] => return .addVisicon (fs.map featureOf)
  | "DELETE-VISICON-FEATURES", ids => return .deleteVisicon (ids.map atomName)
  | "DELETE-ALL-VISICON-FEATURES", [] => return .deleteAllVisicon
  | "MODIFY-VISICON-FEATURES", [.list ms] =>
    return .modifyVisicon (ms.filterMap fun m => match m with
      | .list (.atom id :: r) => some (id, featureOf (.list r))
      | _ => none)
  | "NEW-OTHER-SOUND", [c, du, de, re, o, loc, kind, ms] =>
    let sec := fun (x : SX) => (sxFloat x).map secMs
    match sec du, sec de, sec re, loc, kind with
    | some du, some de, some re, .atom l, .atom k =>
      return .newOtherSound ((sxVal c).getD (.sym "NIL")) du de re (onsetOf o ms) l k
    | _, _, _, _, _ => throw "new-other-sound"
  | "NEW-DIGIT-SOUND", [d, o, ms] =>
    return .newSound "DIGIT" ((sxVal d).getD (.sym "NIL")) none (onsetOf o ms) "EXTERNAL"
  | "NEW-TONE-SOUND", [f, d, o, ms] =>
    return .newSound "TONE" ((sxVal f).getD (.sym "NIL")) ((sxFloat d).map secMs) (onsetOf o ms) "EXTERNAL"
  | "NEW-WORD-SOUND", [w, o, l, ms] =>
    return .newSound "WORD" ((sxVal w).getD (.sym "NIL")) none (onsetOf o ms) (atomName l)
  | "MONITOR", [.str c, .str m] => return .monitor c m
  | "UNMONITOR", [.str c, .str m] => return .unmonitor c m
  | "INSTALL-DEVICE", [.list [.list [.str "motor", .str "cursor", .str "mouse"]]] => return .installMouse
  | "INSTALL-DEVICE", [.list [.list [.str "vision", .str "cursor", _]]] => throw "install-device of a cursor for vision"
  | "INSTALL-DEVICE", [.list [.list [.str "motor", .str "cursor", _]]] => throw "install-device of a joystick"
  | "INSTALL-DEVICE", _ => return .noop
  | "START-HAND-AT-MOUSE", [] => return .startHandAtMouse
  | "COPY-CHUNK", [.atom c] => return .copyChunk c
  | "SET-IMAGINAL-FREE", [] => return .setImaginalFree
  | "SET-IMAGINAL-ERROR", [] => return .setImaginalError
  | "SET-CURSOR-POSITION", [.list xyz, .str "mouse"] =>
    let ns := xyz.filterMap fun x => (sxFloat x).map fun f => (Float.toInt64 f).toInt
    match ns with
    | [x, y] => return .setCursorPosition x y none
    | [x, y, z] => return .setCursorPosition x y (some z)
    | _ => throw "set-cursor-position"
  | "DEFINE-CHUNKS", [.list ds] => return .defineChunks (chunkDefs ds)
  | _, _ => throw s!"command {cmd}"

/-- A `#Q` line (without `#Q `). -/
def parseQuery (line body : String) : TCmd :=
  let (name, rest) := match body.splitOn " " with
    | c :: r => (c, " ".intercalate r)
    | [] => ("", "")
  let args := match readAll rest.toList with | .ok xs => xs.map sxVal | .error _ => []
  .query line name args

/-- `valid-slot-name`: the slots of ACT-R's own chunk-types, of the model's chunk-types, of
its chunks (a chunk definition extends the possible slots) and the constant slot names of
its productions. -/
def Model.slotNames (m : Model) : Std.HashSet String :=
  let fromProds := m.prods.flatMap fun p =>
    (p.lhs.flatMap fun c => match c with | .buf _ ts => ts.map (·.slot) | _ => []) ++
    (p.rhs.flatMap fun a => match a with
      | .modify _ ss | .modRequest _ ss => ss.map (·.1)
      | .request _ ts | .overwrite _ _ ts => ts.map (·.slot)
      | _ => [])
  let all := builtinSlots ++ m.ctSlots ++ m.chunks.flatMap (fun c => c.slots.map (·.1)) ++ fromProds
  Std.HashSet.ofList (all.filter (!isVarSlot ·))

/-- The model at time 0, or after `reset`: the generator carries over unless the model sets
its own seed (`reset` re-runs the model definition but not the random module's
initialization). -/
def Model.toSt (m : Model) (rng : MT) (cbs : List Callback := []) : St :=
  let rng := if m.seedSet then MT.seeded m.P.seed.1 m.P.seed.2 else rng
  { St.init m.P m.prods m.chunks m.dm m.init rng m.bls cbs with
    modelName := m.name, VP := m.VP, MP := m.MP, AP := m.AP, SP := m.SP, slotNames := m.slotNames }

end ACTR.Parse
