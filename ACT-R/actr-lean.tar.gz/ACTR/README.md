# ACT-R 7 in Lean, built on the CMC (2026-11-12)

A Lean 4 specification of ACT-R 7 that runs ACT-R model files and the Lisp tutorial tasks,
and reproduces ACT-R's high-detail trace line for line. It is checked against ACT-R 7.27.7
running under SBCL.

Build: `lake build ACTR actr-lean`. This needs Lean 4.35.0 and the core library only. There
is no `sorry`, and only the standard axioms are used.

Sources: the ACT-R 7 Lisp code and reference manual ("ACT-R 7.26+"), taken from the GitHub
mirror asmaloney/ACT-R. The CMU site was not reachable from the build environment.

## Files

| File | Contents |
|---|---|
| `Core.lean` | Values, chunks, buffers, the production language (`!eval!`/`!bind!` expressions included), matching (with variable slot names and procedural partial matching, `:ppm`), queries, strict harvesting and strict safety, the conflict-set trace text (`:cst`) |
| `Random.lean` | ACT-R's Mersenne Twister: seeding (including 64-bit seeds through `init_by_array`), `act-r-random`, noise, `permute-list` |
| `Declarative.lean` | Base-level learning (`:ol` t, nil or a number), spreading activation (`:nsji`), partial matching (with `:sim-hook` results), transient and permanent noise (`:pas`), retrieval, finsts, merging |
| `PM.lean` | Visicon features, the vision state, hands, the virtual keyboard and the mouse, movements (punch, peck, peck-recoil, cursor and hand plies) and Fitts' law, approach widths, sounds, speech timing |
| `Compile.lean` | Production compilation (`:epl`): the five compilation types (goal, imaginal, retrieval, perceptual, motor), their tables and checks, variable mappings (with variable slot names), composition, duplicate detection, utilities of new productions |
| `Sim.lean` | The event scheduler (priorities, `:max`/`:min`, waiting and dynamic events, maintenance events, preconditions) and the modules: goal, imaginal (with the imaginal-action buffer), declarative, procedural (utility learning and its trace, compilation), vision, audio, manual (keyboard and mouse), speech, temporal, blending. It also replays the task code |
| `Parse.lean` | The reader for model files: `sgp`, `chunk-type` (with defaults), `add-dm`, `define-chunks`, `p`, `spp`, `goal-focus`, `set-base-levels`, `set-similarities`, `set-visloc-default`, `set-buffer-chunk`, `schedule-event`, `require-extra "blending"`, … |
| `Conform.lean` | The mapping onto `CMC.Meta`, and theorems recording where ACT-R keeps or departs from the CMC |
| `../ActrMain.lean` | The `actr-lean` executable |

Proved properties include:

- `selectProd_blind`: conflict resolution cannot see declarative memory or the queue.
- `request_dm`: a retrieval request does not change declarative memory.
- `mergeDM_keeps`: no declarative content is ever lost.
- `clearBuf_empty` and `clearBuf_other`.
- `St.insert_dm`.
- In `Conform.lean`: `clear_removes_result` and `motor_command_empty`.

## Running and comparing

```
actr-lean 10 model.lisp ...              # run a model file for 10 s: trace and final state
actr-lean --script task.log              # replay a task recorded by tools/actr/task.lisp
python3 tools/actr/diff.py DIR|FILE...   # model files: ACT-R vs Lean, trace and final state
python3 tools/actr/taskdiff.py [NAME]    # tutorial tasks: ACT-R vs Lean
python3 tools/actr/pctdiff.py A.actr A.lean   # the productions compilation created, one by one
python3 tools/actr/gen.py OUT N SEED     # random models (NOISE=0..1; EPL, PAS, PPM, NSJI, DYN, CST,
                                         #   RT, UT, OW, STUFF, SJI = 0..1)
python3 tools/actr/genlisp.py OUT N SEED   # random models evaluating Lisp expressions (LHS and RHS
                                           #   !bind!, !safe-bind!, !mv-bind!, !eval!)
python3 tools/actr/genblend.py OUT N SEED  # random models using the blending module
python3 tools/actr/gentemp.py OUT N SEED   # random models using the temporal module
python3 tools/actr/taskloop.py TASK.lisp "(form {})" A B   # one task, seeds A..B
```

The task harness, `tools/actr/task.lisp`, runs a tutorial experiment in ACT-R and records the
following:

- every command the task code sends to ACT-R (reset, `run`, `run-full-time`, `run-until-time`,
  `run-n-events`, `run-until-condition` with the number of events it ran,
  `sgp`, `clear-buffer`, `mod-chunk`, `mod-focus`, `copy-chunk`, `pdisable`, visicon changes
  made by the experiment window, the mouse (`start-hand-at-mouse`, `set-cursor-position`,
  installing the cursor), sounds (including `new-other-sound`) with the random draws made
  before them, scheduled events including `schedule-set-buffer-chunk`,
  `set-imaginal-free`, monitors);
- the answers to its queries (`buffer-slot-value`, `get-time`, …);
- each call of a task command made during a run (`!eval!`, a scheduled event, an
  imaginal-action, a monitored key press, mouse click, cursor movement or utterance, and calls
  nested in those), together with the commands sent during that call and the random
  draws it made;
- the results of the model's `:sim-hook` command, which Lean uses as a table; calls of
  `:utility-hook`, `:cycle-hook` and `:retrieved-chunk-hook` commands are recorded as calls of
  task commands;
- any command that changes the model's state and that the replay does not model
  (`mod-buffer-chunk`, `set-chunk-slot-value`, `spp`/`sdp` settings, …):
  the task is then reported unsupported.

`actr-lean --script` replays these on the Lean model. It answers the queries from its own
state, and it makes each call of a task command when its own model does. The ACT-R trace and
the Lean trace are then compared line by line. Output that the task code prints itself is not
compared, because it is computed from the queries, which are compared. The traces ACT-R
prints for production compilation (`:pct`) and blending (`:blt`) are recorded but not
compared.

## Results (ACT-R 7.27.7, SBCL 2.2.9)

Added November 12 (full regression the same day: every set below identical, 72 of 72 tasks):

| Check | Result |
|---|---|
| Random models with `:randomize-time` (with `:vpft`, `:vidt`), `:ut`, buffer overwrites (`@buffer>`), `:declarative-stuffing`, `add-sji` (`RT`, `UT`, `OW`, `STUFF`, `SJI`; 1300) | 1293 of 1293 identical (7 that grow without bound compared at 0.5 s) |
| Random models evaluating Lisp (`genlisp.py`: LHS `!bind!`, `!safe-bind!`, `!mv-bind!`, RHS `!mv-bind!`, ratios, `floor`/`round`/…, predicates; 1150) | 1125 of 1125 identical; 25 unsupported, each a Lisp error in ACT-R as well (division by zero) |
| Tutorial tasks with `:randomize-time t :vpft t :vidt t` (14), `:auto-attend t` (6), `:viewing-distance 20 :pixels-per-inch 96` (4), other audio and speech timing (3), visual and aural overstuffing (6), every `run` replaced by `run-n-events` (6) | 39 of 39 identical |
| Added tasks: `prep` (`prepare`, `execute`, `point-hand-at-key`), `othersound` 1–3 (`new-other-sound`, `set-audloc-default`, aural overstuffing), `events` (`run-n-events`, `run-until-condition`), `hooks` (`:utility-hook`, `:cycle-hook`, `:retrieved-chunk-hook`) | 6 of 6 identical |
| Mouse task with `:randomize-time` (25 seeds) and with another viewing distance (15 seeds) | 40 of 40 identical |

Earlier results:

| Check | Result |
|---|---|
| Random models (`gen.py`, 3 × 400) | 1200 of 1200 identical |
| Random models with variable slot names and the conflict-set trace (`DYN`, `CST`, with `PPM` in part; 1000) | 1000 of 1000 identical |
| Random models with variable slot names and production compilation (`DYN`, `EPL`, with `PAS`, `CST` and noise in part; 1100) | 1100 of 1100 identical (19 that grow without bound, in ACT-R as well, compared at 0.5 s) |
| Random models using the temporal module (`gentemp.py`, 450) | 450 of 450 identical |
| Mouse task (`models/mouse-task.lisp`: moves to locations and objects, moves prepared during execution, moves without clicks, hand to keyboard and back), 120 layouts | 120 of 120 identical |
| Random models with production compilation (`EPL=1`, 900; with `:pas` too, 300) | 1200 of 1200 identical (one compared at 0.5 s: a self-composed production doubles its `!output!` every cycle, in ACT-R as well) |
| Random models with permanent noise (`PAS=1`, 400), procedural partial matching (`PPM=1`, 200), `:nsji t` (`NSJI=1`, 200) | 800 of 800 identical |
| Random blending models (`genblend.py`, 400) and the blending tests of extras/blending | 406 of 408 identical, 2 unsupported |
| Tutorial model files, units 1–8 | 25 identical, 0 different, 6 unsupported |
| Tutorial tasks (and variants and added tests) | 27 identical, 0 different, 0 unsupported |

The tutorial tasks with identical traces:

| Task | Runs | Trace lines |
|---|---|---|
| fan-no-pm | 36 | 2,055 |
| grouped | 1 | 191 |
| ul-issues | 1 | 335 |
| demo2 | 1 | 83 |
| unit2 | 1 | 26 |
| subitize | 10 | 305 |
| sperling | 4 | 1,183 |
| paired | 320 | 17,332 |
| zbrodoff | 1 | 202,851 |
| fan | 36 | 4,824 |
| onehit (`:sim-hook`) | 10 | 317 |
| onehit, 200 hands | 400 | 12,407 |
| siegler | 6 | 747 |
| bst (unit 6, the mouse) | 15 | 14,716 |
| bst-ppm (unit 8, the mouse, `:ppm`, `:sim-hook`, the imaginal-action buffer) | 15 | 16,785 |
| pcomp-issues | 1 | 27,158 |
| pcomp-issues with `:epl t :pct t` (163 compiled productions) | 1 | 22,675 |
| paired-learning (unit 7, `:epl`; 170 compiled productions) | 640 | 61,356 |
| paired-dynamic (unit 8, variable slot names, `:epl`; 148 compiled productions, each identical) | 640 | 62,251 |
| pm-issues | 1 | 80 |
| sgp-task (`sgp` and `clear-buffer` from task code) | 4 | 457 |
| mouse (added test) | 1 | 1,550 |
| imaction (added test: simple, failing and generic imaginal actions) | 1 | 591 |
| until (added test: `run-until-time`) | 4 | 392 |
| choice, categorize, past-tense | — | — |

`choice`, `categorize` and `past-tense` match but test little: their tutorial models are
exercise stubs, and no production fires. The unsupported tutorial model files are the
deliberately broken `broken-addition`, the task-driven models compared through `taskdiff.py`
(1hit-blackjack, grouped, utility-learning-issues, bst-ppm, categorize, paired-dynamic).
Blending tests 3 and 4 use Lisp functions for `:sim-hook`, `:value->mag` and `:mag->value`.

A model or task that uses something not modeled is reported as unsupported rather than run.

## Not modeled

Modules and mechanisms:
- More than one model, the extras other than blending (threads, tracker, EMMA, extended
  motor actions, associative learning, …).
- Manual: joysticks, the cursor in the visicon (`:process-cursor`), `:cursor-noise`,
  `:incremental-mouse-moves`, `point-hand-at-key` with a list of offsets, `prepare` of styles
  other than punch, peck and peck-recoil.
- Vision: tracking, `assign-finst`, `clear-scene-change`, `clear-all-finsts`,
  `:delete-visicon-chunks nil`. Visicon modifications are modeled only in part.
- Audio and speech: `new-other-sound` with extra features, `:unstuff-aural-location`,
  `register-articulation-time`.
- `:utility-offsets`, `:activation-offsets`, `:dcnn nil`.

Production language:
- Lisp in expressions beyond the functions `Expr.evalM` evaluates (arithmetic on integers,
  ratios and single floats; `floor`, `round`, `mod`, `expt`, `log`, …; comparisons and
  predicates; `and`, `or`, `if`, `when`, `unless`, `progn`, `values`) and calls of task
  commands. An expression whose evaluation would be a Lisp error, or would need something
  not modeled (a complex number), makes the run unsupported at that point.
- Production compilation with `:cia`, `:rir` or `:ppm`, or with a left-hand side
  `!safe-bind!`; `:ppm-hook`.

Hooks written in Lisp: all of them except `:utility-hook`, `:cycle-hook` and
`:retrieved-chunk-hook` given as task commands (strings) in a recorded task, and `:sim-hook`
as before. Not modeled: `:bl-hook`, `:noise-hook`, `:spreading-hook`, `:sji-hook`,
`:reward-hook`, `:conflict-set-hook`, `:retrieval-request-hook`, `:retrieval-set-hook`, the
encoding hooks and the blending module's `:value->mag`, `:mag->value`, `:min-bl` and hooks.

Commands: breaks and `run-until-action`, and the state-changing commands listed in
`tools/actr/task.lisp`, which make a task unsupported. `run-until-condition` is replayed as
the number of events ACT-R ran before its condition held. Output-only commands (`pp`, `dm`,
`whynot`, `buffer-status`, `print-visicon`, …) and traces other than the high-detail trace
(`:act`, `:pct`, `:blt`) are not reproduced; the conflict-set trace (`:cst`) and the utility
learning trace (`:ult`) are.
