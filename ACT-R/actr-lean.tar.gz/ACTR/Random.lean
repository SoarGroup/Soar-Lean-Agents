/-!
# ACT-R's random-number generator

ACT-R's own Mersenne Twister (MT19937) and the functions built on it
([Src] framework/random.lisp: `init_genrand`, `genrand_int32`, `act-r-random`,
`act-r-noise`, `permute-list`). Reproduced bit for bit, so that models with noise can be
compared with ACT-R run with the same `:seed`.
-/

namespace ACTR

structure MT where
  mt : Array UInt32 := Array.replicate 624 0
  mti : Nat := 625
  /-- Draws since seeding ([Src] `mt-count`). -/
  count : Nat := 0
  deriving Inhabited

/-- `init_genrand`. -/
def MT.init (s : UInt32) : MT := Id.run do
  let mut a := Array.replicate 624 (0 : UInt32)
  a := a.set! 0 s
  for i in [1:624] do
    let p := a[i-1]!
    a := a.set! i ((1812433253 : UInt32) * (p ^^^ (p >>> (30 : UInt32))) + i.toUInt32)
  return { mt := a, mti := 624 }

/-- `genrand_int32`. -/
def MT.next (m : MT) : UInt32 × MT := Id.run do
  let mut m := m
  if m.mti ≥ 624 then
    if m.mti > 624 then m := { MT.init 5489 with count := m.count }
    let mut a := m.mt
    let mag : UInt32 → UInt32 := fun y => if y &&& (1 : UInt32) == 0 then 0 else 0x9908b0df
    for kk in [0:227] do
      let y : UInt32 := (a[kk]! &&& (0x80000000 : UInt32)) ||| (a[kk+1]! &&& (0x7fffffff : UInt32))
      a := a.set! kk (a[kk+397]! ^^^ (y >>> (1 : UInt32)) ^^^ mag y)
    for kk in [227:623] do
      let y : UInt32 := (a[kk]! &&& (0x80000000 : UInt32)) ||| (a[kk+1]! &&& (0x7fffffff : UInt32))
      a := a.set! kk (a[kk-227]! ^^^ (y >>> (1 : UInt32)) ^^^ mag y)
    let y : UInt32 := (a[623]! &&& (0x80000000 : UInt32)) ||| (a[0]! &&& (0x7fffffff : UInt32))
    a := a.set! 623 (a[396]! ^^^ (y >>> (1 : UInt32)) ^^^ mag y)
    m := { mt := a, mti := 0, count := m.count }
  let mut y : UInt32 := m.mt[m.mti]!
  y := y ^^^ (y >>> (11 : UInt32))
  y := y ^^^ ((y <<< (7 : UInt32)) &&& (0x9d2c5680 : UInt32))
  y := y ^^^ ((y <<< (15 : UInt32)) &&& (0xefc60000 : UInt32))
  y := y ^^^ (y >>> (18 : UInt32))
  return (y, { m with mti := m.mti + 1, count := m.count + 1 })

/-- `init_by_array`. -/
def MT.initByArray (key : Array UInt32) : MT := Id.run do
  let mut a := (MT.init 19650218).mt
  let n := 624
  let mut i := 1
  let mut j := 0
  for _ in [0:max n key.size] do
    let p := a[i-1]!
    a := a.set! i ((a[i]! ^^^ ((p ^^^ (p >>> 30)) * 1664525)) + key[j]! + j.toUInt32)
    i := i + 1; j := j + 1
    if j == key.size then j := 0
    if i == n then a := a.set! 0 a[n-1]!; i := 1
  for _ in [0:n-1] do
    let p := a[i-1]!
    a := a.set! i ((a[i]! ^^^ ((p ^^^ (p >>> 30)) * 1566083941)) - i.toUInt32)
    i := i + 1
    if i == n then a := a.set! 0 a[n-1]!; i := 1
  a := a.set! 0 0x80000000
  return { mt := a, mti := 624 }

/-- Seed the generator as `:seed (seed count)` does ([Src] `init-random-state-from-seed`):
a seed of up to 32 bits with `init_genrand`, a larger one with `init_by_array` of its two
32-bit halves; then `count` draws. -/
def MT.seeded (seed count : Nat) : MT := Id.run do
  let mut m := if seed ≤ 2 ^ 32 then MT.init seed.toUInt32
    else MT.initByArray #[(seed % 2 ^ 32).toUInt32, ((seed / 2 ^ 32) % 2 ^ 32).toUInt32]
  for _ in [0:count] do m := (m.next).2
  return { m with count := count }

/-- Advance the generator to `n` draws since seeding (draws made by task code). -/
def MT.advanceTo (m : MT) (n : Nat) : MT := Id.run do
  let mut m := m
  for _ in [0:n - m.count] do m := (m.next).2
  return m

/-- `act-r-random` with a float limit: `limit · genrand_int32 / 4294967296.0` in single
floats (the integer is converted to single first). -/
def MT.randFloat (m : MT) (limit : Float32) : Float32 × MT :=
  let (y, m) := m.next
  (limit * (y.toFloat.toFloat32 / (4294967296.0 : Float).toFloat32), m)

/-- `act-r-random` with an integer limit: `floor(limit · genrand_int32 / 2^32)` in double
(long) floats. -/
def MT.randNat (m : MT) (limit : Nat) : Nat × MT :=
  let (y, m) := m.next
  ((Float.floor (Float.ofNat limit * (y.toFloat / 4294967296.0))).toUInt64.toNat, m)

/-- `act-r-noise`: a logistic sample `s · ln((1 − p)/p)`, `p` uniform clipped to
`[0.0001, 0.9999]`, in single floats. -/
def MT.noise (m : MT) (s : Float32) : Float32 × MT :=
  let (r, m) := m.randFloat 1.0
  let lo : Float32 := (0.0001 : Float).toFloat32
  let hi : Float32 := (0.9999 : Float).toFloat32
  let p := if r < hi then (if r > lo then r else lo) else (if lo > hi then lo else hi)
  (s * (Float.log (((1.0 : Float32) - p) / p).toFloat).toFloat32, m)

/-- `permute-list`: picks an element at random, then another from the rest, …; the result
lists the picks in reverse order (one draw per element). -/
def MT.permute {α : Type} (m : MT) (xs : List α) : List α × MT := Id.run do
  let mut m := m
  let mut rest := xs
  let mut res : List α := []
  for _ in xs do
    let (k, m') := m.randNat rest.length
    m := m'
    match rest[k]? with
    | some x => res := x :: res; rest := rest.eraseIdx k
    | none => pure ()
  return (res, m)

end ACTR
