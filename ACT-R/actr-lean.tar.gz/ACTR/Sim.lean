import ACTR.Compile
import Std.Data.HashMap
import Std.Data.HashSet
/-!
# ACT-R 7 in Lean — the event scheduler and the modules

ACT-R is a discrete-event system ([RM] "Scheduling"): modules schedule events at times in
milliseconds and the meta-process runs them in order. This file models the scheduler
([Src] meta-process.lisp, scheduling.lisp) and the events of the goal, imaginal,
declarative and procedural modules, so that a run produces ACT-R's high-detail trace.
-/

namespace ACTR

/-! ## Events -/

/-- What an event does. -/
inductive Act where
  | conflictResolution
  | prodSelected (p : Nat) (env : Env)
  | bufferRead (b : Buf)
  | queryBuffer (b : Buf)
  | prodFired (p : Nat) (env : Env)
  | modBuffer (b : Buf) (sets : List (Slot × Option Val))
  | moduleRequest (b : Buf) (spec : List ITest)
  | modRequest (b : Buf) (sets : List (Slot × Option Val))
  /-- The hidden step of a direct request: the request is built from the chunk now. -/
  | directRequest (b : Buf) (c : Val)
  /-- `overwrite-buffer-chunk` with a chunk or a specification. -/
  | overwriteBuffer (b : Buf) (c : String)
  | overwriteSpec (b : Buf) (spec : List ITest)
  | clearBuffer (b : Buf)
  | startRetrieval (spec : List ITest)
  | retrievedChunk (name : String)
  | retrievalFailure
  /-- `check-declarative-stuffing` and `stuff-declarative-chunk`. -/
  | checkStuff
  | stuffChunk (n : String)
  | setBufferChunk (b : Buf) (src : String) (requested : Bool)
  | setBufferSpec (b : Buf) (spec : List ITest)
  | goalStyleRequest (b : Buf) (spec : List ITest)
  | imaginalFree
  /-- `set-imaginal-error`: the error state, and failure in both imaginal buffers. -/
  | imaginalError
  /-- `next-time-tick` of the temporal module. -/
  | temporalTick
  | triggerReward (r : Float32) (txt : String)
  | propagateReward (r : Float32)
  | stop
  /-- An event of the task code (`schedule-event-relative`): calls the task command. -/
  | task (action : String) (params : List String)
  /-- An event that only shows in the trace or releases waiting events. -/
  | noop
  -- vision
  | procDisplay
  | visiconUpdate
  | findLocation (spec : List ITest)
  | moveAttention (loc : String) (scale : String)
  | encodingComplete (loc : String) (clof : Option (Float × Float × Float)) (requested : Bool)
  | unlockVision
  | visExecBusy
  /-- `visual-auto-attend`, and the state change just before its attention shift. -/
  | visAutoAttend
  | visExecProcFree
  | unstuff (entry : String)
  | eraseBuffer (b : Buf)
  | visClear
  /-- The end of a module's clear: `change-state :last none :prep free :proc free`. -/
  | pmFree (b : Buf)
  | motorClear
  | setVislocDefault (spec : List ITest)
  | setAudlocDefault (spec : List ITest)
  -- motor
  | motorStyle (m : Movement)
  | pressKey (key : String)
  | prepComplete
  /-- `execute` of the movement last prepared. -/
  | motorExecute
  | initComplete
  | finishMovement
  | motorNotify (hand : String) (loc : Int × Int)
  | setHandPos (hand : String) (pos : HandPos)
  | outputKey (key : String)
  -- the mouse ([Src] other-files/mouse.lisp)
  | moveCursor (loc obj hand : Option Val)
  | clickMouse
  | handToMouse
  | handToHome (hand : String)
  | pointHandAtKey (h key : String) (standard : Bool)
  | setHandDevice (hand : String) (mouse : Bool)
  /-- A movement's notification of the mouse: a press of a finger at `loc`. -/
  | cursorPress (loc : Int × Int)
  /-- The cursor moving to its target. -/
  | cursorMove (loc : Int × Int × Int)
  | mouseMoved (loc : Int × Int × Int)
  | mouseClicked (loc : Int × Int × Int) (finger : String)
  -- audio
  | newSoundShown
  | stuffSound
  | findSound (spec : List ITest) (stuffed : Bool)
  | findSoundFailure (stuffed : Bool)
  | audioEventEnded (ename : String)
  | attendSound (chunk : String)
  | audioEncodingComplete (ename : String)
  | attendSoundFailure
  -- speech
  | speak (text : String) (sub : Bool)
  | speechPrepComplete
  | speechInitComplete
  | speechFinish
  | speechNotify (text : String)
  | outputSpeech (text : String)
  -- blending
  | startBlending (spec : List ITest)
  | blendingComplete (spec : List ITest)
  | blendingFailure
  deriving Inhabited

/-! ## The task

Task code (the experiment) is Lisp that talks to ACT-R through commands. The harness
(tools/actr/task.lisp) records them; the commands sent while a task command runs are kept
with that call, so that when the model calls the task (`!eval!`, a scheduled task event)
the Lean model does what the task did. -/

/-- A command task code sends to ACT-R. -/
inductive TCmd where
  | pdisable (ns : List String)
  | penable (ns : List String)
  | modChunk (n : String) (mods : List (Slot × Option Val))
  /-- `set-buffer-chunk` with a specification. -/
  | setBufferSpec (b : Buf) (spec : List ITest)
  /-- `sgp` from task code: the new parameters from the current ones. -/
  | setParams (f : Params × VisParams × MotorParams → Params × VisParams × MotorParams)
  /-- `clear-buffer` from task code (at once, not as an event). -/
  | clearBuffer (b : Buf)
  /-- `schedule-event-relative` of an ACT-R command that is not task code (delay in ms,
  the action, priority, `:max`, `:min`, module, details, shown). -/
  | schedAct (delay : Nat) (a : Act) (prio : Int) (isMax isMin : Bool) (module details : String) (shown : Bool)
  /-- `mod-focus`: a modification of the goal buffer's chunk, as an event now. -/
  | modFocus (mods : List (Slot × Option Val))
  | goalFocus (g : String)
  /-- `copy-chunk-fct` from task code: a copy named `<source>-n`. -/
  | copyChunk (src : String)
  /-- `set-imaginal-free` and `set-imaginal-error` from task code. -/
  | setImaginalFree
  | setImaginalError
  /-- A line of the recording reproduced as it is (the start and end of a call of a task
  command made inside another). -/
  | echo (l : String)
  /-- Draws made by task code before this point (`#RNG n`): the generator is advanced to
  `n` draws, so that a draw by the next command (a sound's randomized delays) matches. -/
  | rngSync (n : Nat)
  /-- `install-device` of the mouse cursor for the motor interface. -/
  | installMouse
  /-- `set-cursor-position` of the mouse (z defaults to the cursor distance). -/
  | setCursorPosition (x y : Int) (z : Option Int)
  /-- `start-hand-at-mouse`. -/
  | startHandAtMouse
  | setBufferChunk (b : Buf) (c : String) (requested : Bool)
  /-- `schedule-event-relative`: delay (ms), action, parameters as printed, priority,
  `:max`, `:min`, module, details, shown in the trace. -/
  | sched (delay : Nat) (action : String) (params : List String) (shownParams : List String) (prio : Int)
      (isMax isMin : Bool) (module : String) (details : Option String) (shown : Bool)
  /-- A query; `line` is the `#Q` line. -/
  | query (line : String) (name : String) (args : List (Option Val))
  | triggerReward (r : Float32) (txt : String)
  | addDM (cs : List Chunk)
  | defineChunks (cs : List Chunk)
  /-- A call of a task command from model code (`call-act-r-command`). -/
  | call (name : String) (args : List String)
  /-- Visicon features added by the device or the task. -/
  | addVisicon (feats : List (List (Slot × List Val)))
  | deleteVisicon (ids : List String)
  | deleteAllVisicon
  | modifyVisicon (mods : List (String × List (Slot × List Val)))
  /-- A sound from the task: kind (DIGIT, TONE, WORD), content, duration (ms, tones),
  onset (ms, absolute), location. -/
  | newSound (kind : String) (content : Val) (duration : Option Nat) (onset : Option Nat) (location : String)
  /-- `new-other-sound`: content, duration, delay, recode (ms), onset, location, kind. -/
  | newOtherSound (content : Val) (du de re : Nat) (onset : Option Nat) (location kind : String)
  | setVislocDefault (spec : List ITest)
  | setAudlocDefault (spec : List ITest)
  | monitor (cmd mon : String)
  | unmonitor (cmd mon : String)
  | noop
  deriving Inhabited

/-- One call of a task command: the commands it sent, and at its return the generator's
draw count and the result. -/
structure Callback where
  name : String
  /-- The arguments as printed (`~s`). -/
  args : List String := []
  cmds : List TCmd
  rng : Nat
  result : Option Val
  deriving Inhabited

/-- An event ([Src] `act-r-event`). `isMax`/`isMin` are the `:max` and `:min` priorities. -/
structure Ev where
  time : Nat
  prio : Int := 0
  isMax : Bool := false
  isMin : Bool := false
  num : Nat := 0
  module : String
  maint : Bool := false
  /-- Shown in the high-detail trace. -/
  shown : Bool := true
  details : String
  act : Act
  deriving Inhabited

/-- `compare-events`: a new event goes before an old one if it is earlier, or at the same
time when the old one is not `:max`, the new one is not `:min`, and the new one is `:max`,
the old one `:min`, or the new priority higher. Among equals the new event goes last. -/
def before (new old : Ev) : Bool :=
  new.time < old.time ||
  (new.time == old.time && !old.isMax && !new.isMin &&
    (new.isMax || old.isMin || new.prio > old.prio))

def insertQ (e : Ev) : List Ev → List Ev
  | [] => [e]
  | x :: xs => if before e x then e :: x :: xs else x :: insertQ e xs

/-! ## State -/

structure St where
  now : Nat := 0
  P : Params := {}
  prods : Array Production := #[]
  /-- Every chunk that exists, by name (DM chunks, buffer chunks, chunks created for
  symbols); `new-name` skips these names. -/
  chunks : Std.HashMap String Chunk := {}
  /-- Every name that has been a slot value of a chunk in `chunks` or memory (a superset of
  the names that are): a merge renames references only when its name is here. -/
  everRef : Std.HashSet String := {}
  /-- Declarative memory indexed by content (`Chunk.contentKey`): order of entry and name. -/
  dmIdx : Std.HashMap String (List (Nat × String)) := {}
  dm : List DMEntry := []
  bufs : Buf → BufSt := fun _ => {}
  /-- The chunk each reusing buffer holds and reuses ([Src] `act-r-buffer-reuse-chunk`). -/
  reuse : Buf → Option String := fun _ => none
  copies : List Buf := []
  /-- Counters of `new-name`, by prefix. -/
  names : List (String × Nat) := []
  queue : List Ev := []
  /-- Waiting events ([Src] `meta-p-delayed`). -/
  delayed : List Ev := []
  /-- Dynamic waiting events placed in the queue, with the time they are placed at
  ([Src] `meta-p-dynamics`). -/
  dyn : List (Nat × Nat) := []
  evId : Nat := 0
  /-- Declarative module: the pending retrieval event, and the failure flag. -/
  dmBusy : Option Nat := none
  dmFailed : Bool := false
  /-- Imaginal module. -/
  imBusy : Bool := false
  imError : Bool := false
  /-- Utility learning history: productions selected since the last reward, with their
  selection times, most recent first ([Src] `utility-history`). -/
  used : List (String × Nat) := []
  stopped : Bool := false
  /-- Productions disabled with `pdisable`. -/
  disabled : List String := []
  /-- Declarative finsts: recently retrieved chunks with the time, most recent first
  ([Src] `dm-finsts`). -/
  finsts : List (String × Nat) := []
  /-- Calls of task commands still to happen, in order. -/
  cbs : List Callback := []
  /-- The model's name. -/
  modelName : String := ""
  VP : VisParams := {}
  MP : MotorParams := {}
  vis : VisState := {}
  mot : MotorState := {}
  /-- The visicon entry of location and object chunks and their copies
  ([Src] `chunk-visicon-entry`). -/
  vinfo : Std.HashMap String String := {}
  /-- Chunks made as copies, with their originals ([Src] `chunk-copied-from`). -/
  copyOf : Std.HashMap String String := {}
  aud : AudState := {}
  AP : AudParams := {}
  spc : SpeechState := {}
  SP : SpeechParams := {}
  /-- Command monitors: (command, monitoring command). -/
  monitors : List (String × String) := []
  /-- Names of chunks merged into declarative memory, with the name of the chunk they were
  merged into ([Src] `act-r-chunk-merged-chunks`). -/
  aliases : Std.HashMap String String := {}
  /-- ACT-R's random-number generator. -/
  rng : MT := {}
  /-- Something the model did at run time that is not modeled (a Lisp error in an expression,
  a ratio, …): the run is then reported unsupported. -/
  err : Option String := none
  /-- The pending declarative stuffing event ([Src] `dm-stuff-event`). -/
  stuffEv : Option Nat := none
  /-- Production compilation ([Src] modules/production-compilation.lisp). -/
  comp : CompState := {}
  /-- Permanent noise (`:pas`) of chunks outside declarative memory that have one
  ([Src] the chunk parameter `permanent-noise`). -/
  pn : List (String × Float32) := []
  /-- Blending module: the pending event and the error flag. -/
  blBusy : Option Nat := none
  blError : Bool := false
  /-- Trace and output lines, most recent first. -/
  out : List String := []
  /-- `valid-slot-name`: the slot names chunks may have. -/
  slotNames : Std.HashSet String := {}
  /-- The temporal module: the noisy start increment (drawn at the first request), the
  current tick length (ms), the ticks counted, and the pending increment event. -/
  tmStart : Option Float32 := none
  tmTick : Float32 := 0
  tmTicks : Nat := 0
  tmNext : Option Nat := none

/-- `feat-attended` of a visicon entry: T with a finst, NEW while new, else NIL. -/
def VisState.attendedOf (v : VisState) (id : String) : String :=
  if v.finsts.any (·.1 == id) then "T"
  else match v.visicon.find? (·.id == id) with
    | some f => if f.isNew then "NEW" else "NIL"
    | none => "NIL"

/-- `test-attended`. -/
def testAttended (marker : String) (t : ITest) : Bool :=
  let v := match t.arg with | some (.sym x) => x | some _ => "T" | none => "NIL"
  let r := if v == "NEW" then marker == "NEW"
           else if v == "NIL" then marker == "NEW" || marker == "NIL" else marker == "T"
  if t.cmp == .ne then !r else r

def pmState (prep proc exec : Bool) (lastCmd : String) (slot v : String) : Bool :=
  match slot, v with
  | "PREPARATION", "FREE" => !prep | "PREPARATION", "BUSY" => prep
  | "PROCESSOR", "FREE" => !proc | "PROCESSOR", "BUSY" => proc
  | "EXECUTION", "FREE" => !exec | "EXECUTION", "BUSY" => exec
  | "LAST-COMMAND", c => c == lastCmd
  | _, _ => false

def St.qstate (s : St) : QState where
  busy := fun b => match b with
    | .retrieval => s.dmBusy.isSome
    | .imaginal | .imaginalAction => s.imBusy
    | .visual => s.vis.exec || s.vis.proc || s.vis.prep
    | .manual => s.mot.prep || s.mot.proc || s.mot.exec
    | .vocal => s.spc.prep || s.spc.proc || s.spc.exec
    | .aural => s.aud.prep || s.aud.proc || s.aud.exec
    | .blending => s.blBusy.isSome
    | _ => false
  error := fun b => match b with
    | .blending => s.blError
    | .retrieval => s.dmFailed
    | .imaginal | .imaginalAction => s.imError
    | .visual => s.vis.attendFailure
    | .visualLocation => s.vis.locFailure
    | .aural => s.aud.attendFailure
    | .auralLocation => s.aud.locFailure
    | _ => false
  other := fun b sl v => match b with
    | .visual =>
      if sl == "SCENE-CHANGE" then
        let det := match s.vis.sceneChange with
          | some (c, t) => c ≥ s.VP.sceneThreshold && s.now ≤ t + s.VP.onsetSpan
          | none => false
        (det && v != "NIL") || (!det && v == "NIL")
      else pmState s.vis.prep s.vis.proc s.vis.exec s.vis.lastCmd sl v
    | .manual => pmState s.mot.prep s.mot.proc s.mot.exec s.mot.lastCmd sl v
    | .vocal => pmState s.spc.prep s.spc.proc s.spc.exec s.spc.lastCmd sl v
    | .aural => pmState s.aud.prep s.aud.proc s.aud.exec s.aud.lastCmd sl v
    | .auralLocation =>
      match (s.bufs .auralLocation).chunk.bind (·.get "ID") with
      | some (.sym id) => match s.aud.audicon.find? (·.ename == id) with
        | some e =>
          if sl == "ATTENDED" then (v == "T") == e.attended
          else if sl == "FINISHED" then (v == "T") == decide (s.now ≥ e.offset)
          else false
        | none => false
      | _ => false
    | .visualLocation =>
      if sl == "ATTENDED" then
        match (s.bufs .visualLocation).chunk with
        | some c =>
          let e := (s.vinfo.get? c.name).getD c.name
          testAttended (s.vis.attendedOf e) ⟨.eq, ":ATTENDED", if v == "NIL" then none else some (.sym v)⟩
        | none => false
      else false
    | _ => false

def St.emit (s : St) (line : String) : St := { s with out := line :: s.out }

/-- `true-chunk-name-fct`: the name a merged chunk's name stands for. -/
def St.trueName (s : St) (n : String) : String := Id.run do
  -- an alias of an alias: follow the chain
  let mut x := n
  for _ in [0:16] do
    match s.aliases.get? x with
    | some y => x := y
    | none => break
  return x

/-- A slot value as ACT-R stores it with `:dcnn t` ([Src] `get-true-slot-value-name`):
a merged chunk's name is replaced by the true name. -/
def St.trueVal (s : St) : Val → Val
  | .sym n => .sym (s.trueName n)
  | v => v

def St.findChunk (s : St) (n : String) : Option Chunk :=
  s.chunks.get? (s.trueName n)

/-- Record the chunk names a chunk holds. -/
def St.noteRefs (s : St) (c : Chunk) : St :=
  { s with everRef := c.slots.foldl (fun h p => match p.2 with | .sym x => h.insert x | _ => h) s.everRef }

/-- Change the chunk named `n`, if there is one. -/
def St.modChunk (s : St) (n : String) (f : Chunk → Chunk) : St :=
  let s := { s with chunks := s.chunks.modify n f }
  match s.chunks.get? n with
  | some c => s.noteRefs c
  | none => s

/-! ### Declarative memory by content -/

def St.idxAdd (s : St) (key : String) (seq : Nat) (n : String) : St :=
  { s with dmIdx := s.dmIdx.insert key ((seq, n) :: s.dmIdx.getD key []) }

def St.idxRemove (s : St) (key : String) (n : String) : St :=
  { s with dmIdx := s.dmIdx.insert key ((s.dmIdx.getD key []).filter (·.2 != n)) }

/-- The entry of declarative memory with the content of `c` added last (the merge table
`dm-chunk-hash-table`, as `mergeDM` finds it). -/
def St.dmFind (s : St) (c : Chunk) : Option String :=
  ((s.dmIdx.getD c.contentKey []).foldl (fun (b : Option (Nat × String)) x => match b with
    | some y => if x.1 > y.1 then some x else b
    | none => some x) none).map (·.2)

/-- A new reference to the entry named `n`. -/
def St.dmRef (s : St) (n : String) : St :=
  { s with dm := s.dm.map fun e => if e.name == n then { e with count := e.count + 1, refs := s.now :: e.refs } else e }

/-- A new entry: chunk `c` under `name`, with one reference now. -/
def St.dmAdd (s : St) (c : Chunk) (name : String) : St :=
  let seq := s.dm.length
  let s := { s with dm := s.dm ++ [(⟨{ c with name := name }, (s.now : Int), 1, [s.now], none, none, seq, c.slotSig⟩ : DMEntry)] }
  (s.idxAdd c.contentKey seq name).noteRefs c

@[simp] theorem St.noteRefs_bufs (s : St) (c : Chunk) : (s.noteRefs c).bufs = s.bufs := rfl
@[simp] theorem St.idxAdd_bufs (s : St) (k : String) (q : Nat) (n : String) : (s.idxAdd k q n).bufs = s.bufs := rfl
@[simp] theorem St.dmRef_bufs (s : St) (n : String) : (s.dmRef n).bufs = s.bufs := rfl
@[simp] theorem St.dmAdd_bufs (s : St) (c : Chunk) (n : String) : (s.dmAdd c n).bufs = s.bufs := rfl

/-- Change the content of the entry named `n` (task `mod-chunk`), keeping the index. -/
def St.dmModify (s : St) (n : String) (f : Chunk → Chunk) : St :=
  match s.dm.find? (fun (x : DMEntry) => x.name == n) with
  | none => s
  | some e =>
    let c' := f e.chunk
    let s := { s with dm := s.dm.map fun (x : DMEntry) => if x.name == n then { x with chunk := c', sig := c'.slotSig } else x }
    ((s.idxRemove e.chunk.contentKey n).idxAdd c'.contentKey e.seq n).noteRefs c'

/-- Replace a chunk name used as a slot value. -/
def Chunk.renameRef (old new : String) (c : Chunk) : Chunk :=
  { c with slots := c.slots.map fun p => match p.2 with
      | .sym x => if x == old then (p.1, .sym new) else p
      | _ => p }

/-- After `merge-chunks-fct` merges chunk `old` into `new` ([Src] chunks.lisp, with `:dcnn t`):
every slot holding `old` now holds `new`, and `old` becomes another name for `new` unless
it is a buffer's reused chunk, whose name stays its own (`make-chunk-reusable`). -/
def St.mergeName (s : St) (old new : String) (alias : Bool) : St :=
  if old == new then s
  else
    let r := Chunk.renameRef old new
    let refs := fun (c : Chunk) => c.slots.any fun p => match p.2 with | .sym x => x == old | _ => false
    -- only chunks that hold `old` change; none can unless `old` was ever a slot value
    let scan := s.everRef.contains old
    let users := if scan then s.chunks.fold (fun (acc : List String) n c => if refs c then n :: acc else acc) [] else []
    let dmUsers := if scan then s.dm.filter (fun e => refs e.chunk) else []
    let idx := dmUsers.foldl (fun (idx : Std.HashMap String (List (Nat × String))) e =>
      let k0 := e.chunk.contentKey
      let k1 := (r e.chunk).contentKey
      let idx := idx.insert k0 ((idx.getD k0 []).filter (·.2 != e.name))
      idx.insert k1 ((e.seq, e.name) :: idx.getD k1 [])) s.dmIdx
    { s with
      everRef := if scan then s.everRef.insert new else s.everRef
      dmIdx := idx
      chunks := users.foldl (fun m n => m.modify n r) s.chunks
      dm := if dmUsers.isEmpty then s.dm else s.dm.map fun e => { e with chunk := r e.chunk }
      bufs := fun b => let st := s.bufs b; { st with chunk := st.chunk.map r }
      aliases := if alias then s.aliases.insert old new else s.aliases
      -- `visicon-entry` merges `:second-if`: the merged-in chunk's feature, if it has one
      vinfo := match s.vinfo.get? old with
        | some e => s.vinfo.insert new e
        | none => s.vinfo }

def St.putChunk (s : St) (c : Chunk) : St :=
  { s with chunks := s.chunks.insert c.name c,
           everRef := c.slots.foldl (fun h p => match p.2 with | .sym x => h.insert x | _ => h) s.everRef }

/-- The first number from `n` whose name is not taken. -/
def nextFree (taken : String → Bool) (pre : String) : Nat → Nat → Nat
  | 0, n => n
  | fuel + 1, n => if taken (pre ++ toString n) then nextFree taken pre fuel (n + 1) else n

/-- `new-name-fct`: the prefix followed by the next number, skipping names of existing
chunks; counters are kept per prefix. -/
def St.newName (s : St) (pre : String) : String × St :=
  let n := nextFree s.chunks.contains pre (s.chunks.size + 1) ((s.names.lookup pre).getD 0)
  (pre ++ toString n, { s with names := (pre, n + 1) :: s.names.filter (·.1 != pre) })

theorem St.newName_bufs (s : St) (pre : String) : (s.newName pre).2.bufs = s.bufs := rfl
theorem St.putChunk_bufs (s : St) (c : Chunk) : (s.putChunk c).bufs = s.bufs := by
  rfl

/-! ## The scheduler -/

/-- `update-waiting-events`: a new event that is not a maintenance event releases the
waiting events and moves a dynamic event placed later than it to its time, with `:min`
priority. -/
def St.insertF : Nat → St → Ev → St
  | 0, s, e => { s with queue := insertQ e s.queue }
  | fuel + 1, s, e =>
    let s := { s with queue := insertQ e s.queue }
    if e.maint then s
    else
      let moved := s.delayed.map fun d => { d with time := e.time, isMin := true }
      let s := { s with delayed := [] }
      let s := moved.foldl (fun s d => St.insertF fuel s d) s
      s.dyn.foldl (fun s (dn : Nat × Nat) =>
        if e.time < dn.2 then
          match s.queue.find? (·.num == dn.1) with
          | some d =>
            let s := { s with queue := s.queue.filter (·.num != dn.1), dyn := (dn.1, e.time) :: s.dyn.filter (·.1 != dn.1) }
            St.insertF fuel s { d with time := e.time, isMin := true }
          | none => s
        else s) s

/-- Insert an event (`update-waiting-events`): a new event that is not a maintenance event
releases the waiting events and moves a dynamic event placed later than it to its time, with
`:min` priority. The recursion is bounded by fuel; releases nest at most a few levels. -/
def St.insert (s : St) (e : Ev) : St := St.insertF 64 s e

theorem foldl_dm {α : Type} (l : List α) (f : St → α → St) (h : ∀ s a, (f s a).dm = s.dm) (s : St) :
    (l.foldl f s).dm = s.dm := by
  induction l generalizing s with
  | nil => rfl
  | cons a l ih => simp only [List.foldl]; rw [ih, h]

/-- Scheduling does not touch declarative memory. -/
theorem St.insertF_dm : ∀ (fuel : Nat) (s : St) (e : Ev), (St.insertF fuel s e).dm = s.dm
  | 0, s, e => rfl
  | fuel + 1, s, e => by
    unfold St.insertF
    simp only
    split
    · rfl
    · rw [foldl_dm]
      · rw [foldl_dm]; intro s d; exact St.insertF_dm fuel s d
      · intro s dn
        split
        · split
          · rw [St.insertF_dm]
          · rfl
        · rfl

theorem St.insert_dm (s : St) (e : Ev) : (s.insert e).dm = s.dm := St.insertF_dm 64 s e

/-- Schedule an event `delay` ms from now; returns its number. -/
def St.sched (s : St) (delay : Nat) (e : Ev) : St × Nat :=
  let n := s.evId + 1
  ({ s with evId := n }.insert { e with time := s.now + delay, num := n }, n)

def St.sched_ (s : St) (delay : Nat) (e : Ev) : St := (s.sched delay e).1

/-- Common Lisp `(round a b)` for naturals: the nearest integer to `a/b`, ties to even. -/
def roundDiv (a b : Nat) : Nat :=
  let q := a / b
  let r := a % b
  if 2 * r > b then q + 1 else if 2 * r < b then q else if q % 2 == 0 then q else q + 1

/-- `randomize-time-ms` ([Src] random.lisp): with `:randomize-time` `n`, a uniform integer from
`t − round(t/n)` to `t + round(t/n)` (one draw); otherwise `t`. -/
def St.randMs (s : St) (t : Nat) : Nat × St :=
  match s.P.randTime with
  | some n =>
    if t == 0 then (t, s) else
    let step := roundDiv t n
    let (k, rng) := s.rng.randNat (2 * step + 1)
    (t - step + k, { s with rng := rng })
  | none => (t, s)

/-- `randomize-time` for a single-float time: `(t/n)·(n − 1 + r)`, `r` uniform in `[0, 2)`. -/
def St.rand32 (s : St) (t : Float32) : Float32 × St :=
  match s.P.randTime with
  | some n =>
    if t == 0 then (t, s) else
    let (r, rng) := s.rng.randFloat 2.0
    ((t / nat32 n) * (nat32 (n - 1) + r), { s with rng := rng })
  | none => (t, s)

/-- `randomize-time` for a double-float time (the factor is a single float). -/
def St.randD (s : St) (t : Float) : Float × St :=
  match s.P.randTime with
  | some n =>
    if t == 0 then (t, s) else
    let (r, rng) := s.rng.randFloat 2.0
    ((t / Float.ofNat n) * (nat32 (n - 1) + r).toFloat, { s with rng := rng })
  | none => (t, s)

/-- The imaginal module's delay, varied with `:vidt`. -/
def St.imDelay (s : St) : Nat × St :=
  if s.P.vidt then s.randMs s.P.imaginalDelay else (s.P.imaginalDelay, s)

theorem St.sched_dm (s : St) (d : Nat) (e : Ev) : (s.sched d e).1.dm = s.dm := by
  simp [St.sched, St.insert_dm]

/-- `schedule-event-after-change` with `:dynamic t` ([Src] `insert-waiting-event`): the event
waits for the next event that is not a maintenance event. If one is already scheduled it
goes at that event's time with `:min` priority and stays dynamic; otherwise it waits. -/
def St.schedAfterChange (s : St) (e : Ev) : St :=
  let n := s.evId + 1
  let s := { s with evId := n }
  let e := { e with num := n, isMin := true }
  match s.queue.find? (!·.maint) with
  | some m =>
    let s := s.insert { e with time := m.time }
    { s with dyn := (n, m.time) :: s.dyn }
  | none => { s with delayed := s.delayed ++ [e] }

def St.deleteEv (s : St) (n : Nat) : St :=
  { s with queue := s.queue.filter (·.num != n), dyn := s.dyn.filter (·.1 != n),
           delayed := s.delayed.filter (·.num != n) }

/-- `chunk-spec-to-chunk-def` succeeds: apart from request parameters, each slot is named
once and with `=`. -/
def specDefOK (spec : List ITest) : Bool :=
  let ss := spec.filter (!·.slot.startsWith ":")
  ss.all (·.cmp == .eq) && (ss.map (·.slot)).eraseDups.length == ss.length

/-- An event to schedule (its time and number are set by `sched`). -/
def mkEv (module details : String) (a : Act) (prio : Int := 0) (shown : Bool := true)
    (isMax : Bool := false) (isMin : Bool := false) (maint : Bool := false) : Ev :=
  { time := 0, module := module, details := details, act := a, prio := prio, shown := shown,
    isMax := isMax, isMin := isMin, maint := maint }

def crEv : Ev := { time := 0, module := "PROCEDURAL", details := "CONFLICT-RESOLUTION",
                   act := .conflictResolution }

/-! ## Buffers -/

def St.setBuf (s : St) (b : Buf) (f : BufSt → BufSt) : St :=
  { s with bufs := upd s.bufs b (f (s.bufs b)) }

/-- `:pas` for a chunk `c` cleared into declarative memory as `nm`: it keeps its permanent
noise; a reused chunk is stored as a copy, and copying draws the noise if the chunk has
none yet ([Src] `copy-chunk-fct`). -/
def St.storeNoise (s : St) (c nm : String) (reused : Bool) : St :=
  match s.P.pas, s.pn.lookup c with
  | some _, some v => { s with dm := s.dm.map fun e => if e.name == nm then { e with pnoise := some v } else e }
  | some ps, none =>
    if reused then
      let (v, r) := s.rng.noise ps
      { s with rng := r, dm := s.dm.map fun e => if e.name == nm then { e with pnoise := some v } else e }
    else s
  | none, _ => s

theorem St.storeNoise_bufs (s : St) (c nm : String) (r : Bool) : (s.storeNoise c nm r).bufs = s.bufs := by
  unfold St.storeNoise; split
  · rfl
  · split <;> rfl
  · rfl

/-- Clear a buffer ([Src] `clear-buffer-process`, `merge-chunk-into-dm`): the flags are
reset, and the chunk, if any, is merged into declarative memory. A chunk with the same
content as one in memory adds a reference to it; otherwise the chunk is added, as a copy
named `<name>-n` if it is a buffer's reused chunk. -/
def clearBuf' (s₀ : St) (b : Buf) : St :=
  match (s₀.bufs b).chunk with
  | none => s₀.setBuf b fun st => { st with failure := false, requested := false }
  | some c =>
    let s := s₀.setBuf b fun st => { st with chunk := none, failure := false, requested := false }
    let reused := Buf.all.any fun b' => s.reuse b' == some c.name
    match s.dmFind c with
    | some tn =>
      let s := s.dmRef tn
      s.mergeName c.name tn (!reused)
    | none =>
      let (nm, s) := if reused then s.newName (c.name ++ "-") else (c.name, s)
      let s := s.putChunk { c with name := nm }
      (s.dmAdd c nm).storeNoise c.name nm reused

/-- `merge-chunk-into-dm` of a chunk cleared from the retrieval buffer starts a stuffing
attempt when none is pending. -/
def St.stuffOnClear (s : St) (b : Buf) (had : Bool) : St :=
  if had && b == .retrieval && s.P.stuff.isSome && s.stuffEv.isNone then
    let (s, n) := s.sched 0 (mkEv "DECLARATIVE" "CHECK-DECLARATIVE-STUFFING" .checkStuff (isMin := true) (maint := true))
    { s with stuffEv := some n }
  else s

/-- `clear-buffer` with the stuffing attempt it may start. -/
def St.clearBufS (s : St) (b : Buf) : St :=
  (clearBuf' s b).stuffOnClear b (s.bufs b).chunk.isSome

/-- Put a chunk into a buffer ([Src] `set-buffer-chunk`): a full buffer is cleared first;
a buffer that requires copies gets a copy named `<source>-n`, others copy the content into
the chunk they reuse, `<BUFFER>-CHUNKn`. -/
def putInBuffer (s : St) (b : Buf) (src : Chunk) (fromSpec : Bool) (requested : Bool)
    (clear : Bool := true) : St :=
  let s := if clear && (s.bufs b).chunk.isSome then s.clearBufS b else s
  let (nm, s) :=
    if s.copies.contains b then
      if fromSpec then s.newName "CHUNK" else s.newName (src.name ++ "-")
    else match s.reuse b with
      | some r => (r, s)
      | none =>
        let (r, s) := s.newName (b.name ++ "-CHUNK")
        (r, { s with reuse := upd s.reuse b (some r) })
  let c := { src with name := nm }
  -- `:pas`: a copy takes the source's permanent noise, drawn now if the source has none
  -- (the source keeps none); a chunk made from a specification has none
  let s := match s.P.pas with
    | none => s
    | some ps =>
      let rest := s.pn.filter fun (x : String × Float32) => x.1 != nm
      if fromSpec then { s with pn := rest }
      else
        let srcN := match s.dm.find? (fun (e : DMEntry) => e.name == src.name) with
          | some e => e.pnoise
          | none => s.pn.lookup src.name
        match srcN with
        | some v => { s with pn := (nm, v) :: rest }
        | none => let (v, r) := s.rng.noise ps; { s with pn := (nm, v) :: rest, rng := r }
  let s := s.putChunk c
  let s := match s.vinfo.get? src.name with
    | some e => { s with vinfo := s.vinfo.insert nm e }
    | none => s
  let s := if fromSpec || nm == src.name then s else { s with copyOf := s.copyOf.insert nm src.name }
  s.setBuf b fun st => { st with chunk := some c, requested := requested }

/-- The chunk a goal or imaginal request describes: its `=` slots with values. -/
def chunkOfSpec (spec : List ITest) : Chunk :=
  spec.foldl (fun c t => if t.cmp == .eq then c.set t.slot t.arg else c) ⟨"", []⟩

/-- The source buffers of spreading activation and their spreads (`:ga`,
`:imaginal-activation`; the retrieval buffer spreads nothing). -/
def sources (s : St) : List (Chunk × Float32) :=
  [(Buf.goal, s.P.ga), (Buf.imaginal, s.P.imaginalActivation)].filterMap fun p =>
    (s.bufs p.1).chunk.map fun c => (c, p.2)

def termVal (env : Env) : Term → Option Val
  | .const v => some v
  | .var x => env.lookup x

/-! ## Utility -/

/-- `propagate-reward` ([RM] "Utility", `trigger-reward`): with `:esc` and `:ul`, every
production selected since the last reward, in order of selection, is updated by
`U ← U + α (R − Δt − U)`, `Δt` the seconds since that selection, and the history is
cleared. NOT MODELED: `:fixed-utility`, reward hooks. -/
def propagateReward (s : St) (r : Float32) : St :=
  if !(s.P.esc && s.P.ul) then s
  else
    let ult := s.P.ult
    let s := if ult then s.emit s!"OUTPUT  Utility updates with Reward = {f32FText r}   alpha = {f32FText s.P.alpha}" else s
    s.used.reverse.foldl (fun (s : St) (u : String × Nat) =>
      let dt := nat32 (s.now - u.2) / f32 1000.0
      let rr := r - dt
      match s.prods.findIdx? (·.name == u.1) with
      | none => s
      | some i =>
        let p := s.prods[i]!
        let u1 := p.u + s.P.alpha * (rr - p.u)
        let s := if ult then
            (((s.emit s!"OUTPUT   Updating utility of production {p.name}").emit
              s!"OUTPUT    U(n-1) = {f32FText p.u}   R(n) = {f32FText rr} [{f32FText r} - {f32FText dt} seconds since selection]").emit
              s!"OUTPUT    U(n) = {f32FText u1}")
          else s
        { s with prods := s.prods.map fun q => if q.name == u.1 then { q with u := u1 } else q })
      { s with used := [] }

/-- **Conflict resolution** ([RM] "Conflict Resolution"; [Src] `conflict-resolution`,
`compute-utility`): the productions are tested in definition order; each one that matches
gets its utility, `U + noise` with the noise drawn when `:esc` and `:egs` are set. The
highest utility wins, if it reaches `:ut`; with `:ppm`, a production whose slot tests match only partially has
`:ppm` times the summed similarities added. Among equals, with `:er nil` the last one tested; with `:er t` the
list of equals is permuted (`permute-list`) and its first element taken. -/
def selectProd (s : St) (over : String → Option Float32 := fun _ => none) : Option (Nat × Env) × MT :=
  let (best, _, rng) := (List.range s.prods.size).foldl
    (fun (acc : List (Nat × Env) × Option Float32 × MT) i =>
      let (best, bu, rng) := acc
      let p := s.prods[i]!
      if s.disabled.contains p.name then acc else
      let pm := s.P.ppm.map fun _ => fun (v w : Val) =>
        let sim := similarity s.P (some v) (some w)
        if sim > s.P.md then some sim else none
      match matchCondsPM s.bufs s.qstate (p.allConds s.P.proc) pm p.lhsBinds with
      | none => acc
      | some (env, sims) =>
        -- a number from `:utility-hook` is the utility, with no noise ([Src] `compute-utility`)
        let (u, rng) := match over p.name with
          | some x => (x, rng)
          | none =>
            let (n, rng) := if s.P.esc && s.P.egs != f32 0.0 then rng.noise s.P.egs else (f32 0.0, rng)
            -- `ppm-offset`: `:ppm` times the summed similarities of the mismatched slots
            let off := match s.P.ppm, sims with
              | some k, x :: xs => some (k * xs.foldl (· + ·) x)
              | _, _ => none
            (match off with | some o => (n + p.u) + o | none => n + p.u, rng)
        match bu with
        | none => ([(i, env)], some u, rng)
        | some v =>
          if u > v then ([(i, env)], some u, rng)
          else if u == v then (if s.P.er then (best ++ [(i, env)], bu, rng) else ([(i, env)], bu, rng))
          else (best, bu, rng)) ([], s.P.ut, s.rng)
  if s.P.er && !best.isEmpty then
    let (perm, rng) := rng.permute best
    (perm.head?, rng)
  else (best.head?, rng)

/-- The conflict-set trace (`:cst`, [Src] `conflict-resolution`): each production that
matches, instantiated, with its utility as `selectProd` computes it (the same draws of
noise) and `:u`. -/
def conflictSetTrace (s : St) : List String :=
  let (out, _) := (List.range s.prods.size).foldl
    (fun (acc : List String × MT) i =>
      let (out, rng) := acc
      let p := s.prods[i]!
      if s.disabled.contains p.name then acc else
      let pm := s.P.ppm.map fun _ => fun (v w : Val) =>
        let sim := similarity s.P (some v) (some w)
        if sim > s.P.md then some sim else none
      match matchCondsPX s.bufs s.qstate (p.allConds s.P.proc) pm p.lhsBinds with
      | none => acc
      | some (env, parts) =>
        let sims := parts.map (·.2.2.2.2)
        let (n, rng) := if s.P.esc && s.P.egs != f32 0.0 then rng.noise s.P.egs else (f32 0.0, rng)
        let off := match s.P.ppm, sims with
          | some k, x :: xs => some (k * xs.foldl (· + ·) x)
          | _, _ => none
        let u := match off with | some o => (n + p.u) + o | none => n + p.u
        let implicit := (implicitQueries s.P.proc p).map fun b =>
          PStmt.cond (.query b [⟨false, "STATE", "FREE"⟩])
        let txt := instantiationText { p with lhsText := p.lhsText ++ implicit } env parts
        (out ++ txt ++ [s!"Parameters for production {p.name}:", s!" :UTILITY {fmtF63 u}", s!" :U {fmtF63 p.u}"], rng))
    ([], s.rng)
  out

/-! ## Vision ([Src] core-modules/vision.lisp) -/

def objsMinVal {α : Type} (xs : List α) (f : α → Float) : List α :=
  (xs.foldl (fun (acc : Option Float × List α) y =>
    let v := f y
    match acc.1 with
    | none => (some v, [y])
    | some b => if v < b then (some v, [y]) else if v == b then (some b, y :: acc.2) else acc)
    (none, [])).2

def objsMaxVal {α : Type} (xs : List α) (f : α → Float) : List α :=
  objsMinVal xs (fun x => -(f x))

def St.vinfoOf (s : St) (n : String) : Option String :=
  match s.vinfo.get? n with
  | some e => some e
  | none => s.vinfo.get? (s.trueName n)

def St.feature (s : St) (id : String) : Option VFeature := s.vis.visicon.find? (·.id == id)

def St.setVis (s : St) (f : VisState → VisState) : St := { s with vis := f s.vis }

/-- `update-new`: features stop being new `:visual-onset-span` after they appeared. -/
def St.updateNew (s : St) : St :=
  s.setVis fun v => { v with visicon := v.visicon.map (fun f =>
    if f.isNew && s.now - f.tstamp > s.VP.onsetSpan then { f with isNew := false } else f) }

/-- `check-finsts`: finsts end with their feature or after `:visual-finst-span`. -/
def St.checkFinsts (s : St) : St :=
  s.setVis fun v => { v with finsts := v.finsts.filter (fun f =>
    v.visicon.any (·.id == f.1) && !(s.now - f.2 > s.VP.finstSpan)) }

/-- `find-current-locs-with-spec`: the features a visual-location request matches. -/
def St.findLocs (s : St) (spec : List ITest) : List VFeature × St :=
  let attended := spec.find? (·.slot == ":ATTENDED")
  let nearest := (spec.find? (·.slot == ":NEAREST")).bind (·.arg)
  let cur := (s.vis.marker.bind s.vinfoOf).bind s.feature
  let slots := (spec.filter (!·.slot.startsWith ":")).filterMap fun (t : ITest) => match t.arg with
    | some (.sym "CURRENT") => (cur.bind (·.chunk.get t.slot)).map fun v => { t with arg := some v }
    | some (.sym x) => if x.startsWith "&" then none else some t
    | _ => some t
  let isMM := fun (t : ITest) => match t.arg with
    | some (.sym "LOWEST") | some (.sym "HIGHEST") => true | _ => false
  let mm := slots.filter isMM
  let slots := slots.filter (!isMM ·)
  let s := if attended.isSome then s.updateNew.checkFinsts else s
  let possible := match attended with
    | some a => s.vis.visicon.filter fun (f : VFeature) => testAttended (s.vis.attendedOf f.id) a
    | none => s.vis.visicon
  -- `find-matching-chunks` returns its matches in reverse order
  let matching := (possible.filter fun (f : VFeature) => slots.all (·.holds f.chunk)).reverse
  let matching := if matching.isEmpty then matching else mm.foldl (fun (ms : List VFeature) (t : ITest) =>
    let low := t.arg == some (.sym "LOWEST")
    let vals := ms.filterMap fun (f : VFeature) => match f.chunk.get t.slot with | some (.num x _) => some x | _ => none
    match vals with
    | [] => ms
    | v :: vs =>
      let best := vs.foldl (fun (b x : Float) => if (low && x < b) || (!low && x > b) then x else b) v
      (ms.filter fun (f : VFeature) => (ITest.mk t.cmp t.slot (some (.num best ""))).holds f.chunk).reverse) matching
  let vd := Float.ofNat s.VP.viewDist
  let c := s.vis.clof.getD (0, 0, vd)
  let matching := if matching.isEmpty then matching else match nearest with
    | some (.sym "CURRENT") => objsMinVal matching fun (f : VFeature) => dist3 f.xyz c
    | some (.sym "CURRENT-X") => objsMinVal matching fun (f : VFeature) => (f.xyz.1 - c.1).abs
    | some (.sym "CURRENT-Y") => objsMinVal matching fun (f : VFeature) => (f.xyz.2.1 - c.2.1).abs
    | some (.sym "CURRENT-DISTANCE") => objsMinVal matching fun (f : VFeature) => (f.xyz.2.2 - c.2.2).abs
    | some (.sym n) => match s.findChunk n with
      | some ch =>
        let p := match ch.xyz with
          | some p => p
          | none => match ch.get "SCREEN-X", ch.get "SCREEN-Y" with
            | some (.num x _), some (.num y _) => (x, y, vd)
            | _, _ => c
        objsMinVal matching fun (f : VFeature) => dist3 f.xyz p
      | none => matching
    | _ => matching
  (matching, s)

/-- `within-move`: features within `:visual-movement-tolerance` degrees of a point, in
reverse visicon order. -/
def St.withinMove (s : St) (p : Float × Float × Float) : List VFeature :=
  s.vis.visicon.foldl (fun acc f =>
    let ok := if s.VP.moveTolerance == 0 then f.xyz == p
              else s.VP.moveTolerance ≥ angleBetween p f.xyz
    if ok then f :: acc else acc) []

/-- `stuff-visloc-buffer`: an empty visual-location buffer gets the location the default
specification finds (newest first, ties by a random choice among names). -/
def St.stuffVisloc (s : St) : St :=
  let old := (s.bufs .visualLocation).chunk
  -- `:overstuff-visual-location`: an unrequested buffer holding an unmodified copy
  let over := s.VP.overstuff && !(s.bufs .visualLocation).requested &&
    old.any fun c => (s.copyOf.get? c.name).isSome
  if !(old.isNone || over) || s.vis.locks != 0 then s else
  let (cands, s) := s.findLocs s.vis.defaultSpec
  if cands.isEmpty then s else
  let ms := objsMaxVal cands (fun f => Float.ofNat f.tstamp)
  let ms := (ms.toArray.qsort (fun a b => a.id < b.id)).toList
  let (k, rng) := s.rng.randNat ms.length
  let s := { s with rng := rng }
  let f := ms[k]!
  -- the same location is not stuffed again
  let same := match old, s.findChunk f.loc with
    | some o, some c => o.sub c && c.sub o
    | _, _ => false
  if same then s else
  let s := if old.isSome then
      s.sched_ 0 (mkEv "VISION" ("OVERWRITE-BUFFER-CHUNK VISUAL-LOCATION " ++ f.loc ++ " NIL")
        (.overwriteBuffer .visualLocation f.loc) 10)
    else s.sched_ 0 (mkEv "VISION" ("SET-BUFFER-CHUNK VISUAL-LOCATION " ++ f.loc ++ " NIL")
      (.setBufferChunk .visualLocation f.loc false) 10)
  let s := s.setVis fun v => { v with locks := v.locks + 1 }
  let s := s.sched_ 0 (mkEv "VISION" "" .unlockVision 9 (shown := false) (maint := true))
  match s.VP.unstuff with
  | some d =>
    let s := match s.vis.unstuffEv with | some n => s.deleteEv n | none => s
    let (s, n) := s.sched d (mkEv "VISION" "" (.unstuff f.id) (shown := false) (maint := true))
    s.setVis fun v => { v with unstuffEv := some n }
  | none => s

/-- `check-unstuff-buffer`: the stuffed location is still in the buffer, unchanged and
unrequested. -/
def St.unstuffOk (s : St) (entry : String) : Bool :=
  let b := s.bufs .visualLocation
  match b.chunk with
  | some c => (s.copyOf.get? c.name).isSome && s.vinfoOf c.name == some entry && !b.requested
  | none => false

/-- `update-attended-loc`: when the attended object leaves or changes, or something appears
where attention is, it is encoded again. -/
def St.updateAttendedLoc (s : St) : St :=
  if s.vis.moving || s.vis.exec then s else
  let entry := s.vis.attended.bind s.vinfoOf
  let inVis := fun (e : String) => s.vis.visicon.any (·.id == e)
  let trig := (s.vis.attended.isSome && !(entry.any inVis)) ||
    (s.vis.marker.isSome && s.vis.attended.isNone && (s.vis.clof.any fun c => !(s.withinMove c).isEmpty)) ||
    (s.vis.attended.isSome && entry.any (s.vis.changed.contains ·))
  if !trig then s else
  let s := s.setVis fun v => { v with exec := true }
  let s := s.sched_ 0 (mkEv "VISION" "" .visExecBusy (shown := false) (isMax := true))
  match s.vis.marker with
  | some m =>
    let (lat, s) := s.randMs s.VP.latency
    s.sched_ lat (mkEv "VISION" s!"Encoding-complete {m} {s.vis.scale.getD "NIL"}"
      (.encodingComplete m s.vis.clof false))
  | none => s

/-- `process-display`: apply the changes to the visicon, then update the module. -/
def St.processDisplay (s : St) : St :=
  let o := s.vis.visicon.length
  let attended := fun (id : String) => s.vis.finsts.any (·.1 == id)
  -- deleted features with a finst: their finsts go to an equal feature, if one appears
  let (vic, temp, d, mods, transfer) := s.vis.updates.foldl (fun (acc : List VFeature × List VFeature × Nat × List (String × List (Slot × Option Val × Option Val)) × List VFeature) u =>
    let (vic, temp, d, mods, tr) := acc
    match u with
    | .add f => (vic, { f with tstamp := s.now, isNew := true } :: temp, d, mods, tr)
    | .delete id =>
      match vic.find? (·.id == id) with
      | some f => (vic.filter (·.id != id), temp, d + 1, mods, if attended id then f :: tr else tr)
      | none => (vic, temp.filter (·.id != id), d, mods, tr)
    | .deleteAll => ([], [], d + vic.length, [], (vic.filter (attended ·.id)).reverse ++ tr)
    | .modify id ms => (vic, temp, d, mods ++ [(id, ms)], tr)) (s.vis.visicon, [], 0, [], [])
  -- modifications: the visicon chunk takes the object value, the location the location value
  let changed := mods.map (·.1)
  let vic := vic.map fun f => match mods.lookup f.id with
    | some ms => ms.foldl (fun f (m : Slot × Option Val × Option Val) =>
        { f with slots := (Chunk.set ⟨"", f.slots⟩ m.1 (m.2.2.orElse fun _ => m.2.1)).slots, objSlots := if ["SCREEN-X", "SCREEN-Y", "DISTANCE"].contains m.1 then f.objSlots
                             else (Chunk.set ⟨"", f.objSlots⟩ m.1 (m.2.2.orElse fun _ => m.2.1)).slots }) f
    | none => f
  let s := mods.foldl (fun s (m : String × List (Slot × Option Val × Option Val)) =>
    match vic.find? (·.id == m.1) with
    | some f => s.modChunk f.loc fun c => m.2.foldl (fun c x => c.set x.1 x.2.1) c
    | none => s) s
  let vic := vic.foldl (fun l f => if mods.any (·.1 == f.id) then insertVisicon f (l.filter (·.id != f.id)) else l) vic
  let vic := temp.foldl (fun l f => insertVisicon f l) vic
  -- `transfer-finst`: to the first feature of the visicon with the same content
  let sameContent := fun (a b : VFeature) =>
    a.slots.length == b.slots.length && a.slots.all fun p => match b.slots.lookup p.1 with
      | some v => v == p.2
      | none => false
  let (vic, finsts) := transfer.foldl (fun (acc : List VFeature × List (String × Nat)) (x : VFeature) =>
    let (vic, fs) := acc
    match vic.find? (sameContent x ·), fs.find? (·.1 == x.id) with
    | some t, some fi =>
      (vic.map (fun f => if f.id == t.id then { f with tstamp := fi.2, isNew := x.isNew } else f),
       fs.map fun q => if q.1 == x.id then (t.id, q.2) else q)
    | _, _ => (vic, fs)) (vic, s.vis.finsts)
  let s := s.setVis fun v => { v with finsts := finsts }
  let n := temp.length
  let c := (changed.filter fun id => vic.any (·.id == id)).eraseDups.length
  let change : Float := if o + n == 0 then 0.0
    else ((Float.ofNat (d + n + c)) / (Float.ofNat (o + n))).toFloat32.toFloat
  let s := s.setVis fun v => { v with visicon := vic, updates := [], changed := changed, sceneChange := some (change, s.now) }
  let s := s.updateNew.checkFinsts.updateAttendedLoc.stuffVisloc
  s.sched_ 0 (mkEv "VISION" "visicon-update" .visiconUpdate)

/-- `schedule-proc-display`. -/
def St.scheduleProcDisplay (s : St) : St :=
  if s.vis.procScheduled then s
  else
    let s := s.setVis fun v => { v with procScheduled := true }
    s.sched_ 0 (mkEv "VISION" "proc-display" .procDisplay (-100) (maint := true))

/-- `unlock-vision`. -/
def St.unlockVision (s : St) : St :=
  let s := s.setVis fun v => { v with locks := v.locks - 1 }
  if s.vis.locks == 0 && s.vis.blocked then
    (s.setVis fun v => { v with blocked := false, procScheduled := false }).processDisplay
  else s

/-- `find-best-feature`: the feature the attended location came from if it is there,
else the nearest of those sharing most features with it (a random choice among equals). -/
def St.findBestFeature (s : St) (feats : List VFeature) (loc : String) (p : Float × Float × Float) :
    VFeature × St :=
  match s.vinfoOf loc with
  | some e =>
    match feats.find? (·.id == e) with
    | some f => if (s.copyOf.get? loc).isSome then (f, s) else bestByMatch s feats loc p
    | none => bestByMatch s feats loc p
  | none => bestByMatch s feats loc p
where
  bestByMatch (s : St) (feats : List VFeature) (loc : String) (p : Float × Float × Float) : VFeature × St :=
    let ref : Chunk := match (s.vinfoOf loc).bind s.feature with
      | some f => f.chunk
      | none => (s.findChunk loc).getD ⟨loc, []⟩
    let spec := ref.slots.filter fun q => !["SCREEN-X", "SCREEN-Y", "DISTANCE"].contains q.1
    let ms := objsMaxVal feats fun f => Float.ofNat (spec.countP fun q => f.chunk.get q.1 == some q.2)
    let ns := objsMinVal ms fun f => dist3 f.xyz p
    let (k, rng) := s.rng.randNat ns.length
    (ns[k]!, { s with rng := rng })

/-- `add-finst`. -/
def St.addFinst (s : St) (obj : String) : St :=
  match s.vinfoOf obj with
  | none => s
  | some e =>
    let fs := if s.vis.finsts.any (·.1 == e) then s.vis.finsts.map (fun f => if f.1 == e then (e, s.now) else f)
              else (e, s.now) :: s.vis.finsts
    let fs := if fs.length > s.VP.numFinsts then (fs.mergeSort (fun a b => a.2 ≤ b.2)).tail else fs
    s.setVis fun v => { v with finsts := fs, visicon := v.visicon.map (fun f => if f.id == e then { f with isNew := false } else f) }

/-- `encoding-complete`: the object at the attended location goes to the visual buffer. -/
def St.encodingComplete (s : St) (loc : String) (clof : Option (Float × Float × Float)) (req : Bool) : St :=
  let s := s.setVis fun v => { v with moving := false, exec := false, proc := false }
  let p := clof.getD (0, 0, 0)
  let feats := s.withinMove p
  let locXyz := (s.findChunk loc).bind (·.xyz)
  if feats.isEmpty then
    let s := s.setVis fun v => { v with marker := some loc, clof := locXyz.orElse fun _ => clof, attended := none, attendFailure := true }
    let s := if (s.bufs .visual).chunk.isNone then
        s.setBuf .visual fun st => { st with failure := true, requested := req } else s
    s.sched_ 0 (mkEv "VISION" "No visual-object found" .noop (maint := true))
  else
    let (best, s) := s.findBestFeature feats loc p
    let (nm, s) := s.newName best.objType
    let pos := if (s.findChunk loc).isSome then loc else best.loc
    let s := s.putChunk ⟨nm, best.objSlots ++ [("SCREEN-POS", .sym pos)]⟩
    let s := { s with vinfo := s.vinfo.insert nm best.id }
    let s := s.setVis fun v => { v with marker := some loc, clof := locXyz.orElse fun _ => clof, attended := some nm }
    let s := s.sched_ 0 (mkEv "VISION" ("SET-BUFFER-CHUNK VISUAL " ++ nm ++ (if req then "" else " NIL"))
      (.setBufferChunk .visual nm req) 10)
    s.addFinst nm

/-- `move-attention`. -/
def St.moveAttention (s : St) (loc scale : String) : St :=
  if s.vis.exec then s else
  let s := s.setVis fun v => { v with moving := true, attended := none, marker := some loc, clof := ((s.findChunk loc).bind (·.xyz)).orElse fun _ => v.clof, scale := if scale == "NIL" then none else some scale, attendFailure := false }
  let (lat, s) := s.randMs s.VP.latency
  let s := s.sched_ lat (mkEv "VISION" s!"Encoding-complete {loc} {scale}"
    (.encodingComplete loc s.vis.clof true))
  s.setVis fun v => { v with exec := true, proc := true }

/-- `find-location`. -/
def St.findLocation (s : St) (spec : List ITest) : St :=
  let (cands, s) := s.findLocs spec
  if cands.isEmpty then
    let s := s.setBuf .visualLocation fun st => { st with failure := true, requested := true }
    let s := s.setVis fun v => { v with locFailure := true }
    s.sched_ 0 (mkEv "VISION" "find-loc-failure" .noop)
  else
    let ms := objsMaxVal cands (fun f => Float.ofNat f.tstamp)
    let (k, rng) := s.rng.randNat ms.length
    let s := { s with rng := rng }
    let f := ms[k]!
    let s := s.setVis fun v => { v with locFailure := false }
    let s := s.sched_ 0 (mkEv "VISION" ("SET-BUFFER-CHUNK VISUAL-LOCATION " ++ f.loc)
      (.setBufferChunk .visualLocation f.loc true) 10)
    let s := s.setVis fun v => { v with locks := v.locks + 1 }
    let s := s.sched_ 0 (mkEv "VISION" "" .unlockVision 9 (shown := false) (maint := true))
    if s.VP.autoAttend then s.sched_ 0 (mkEv "VISION" ("automatically attending " ++ f.id) .visAutoAttend)
    else s

/-- A feature added by the device or the task ([Src] `internal-add-visicon-features`):
the location and visicon chunks are created now; the feature enters the visicon at the next
`proc-display`. `spec` is the feature list as given: slot, value or (location-value
object-value), and `isa (location-type object-type)`. -/
def St.addFeature (s : St) (spec : List (Slot × List Val)) : St :=
  let isa := (spec.lookup "ISA").getD []
  let (locType, objType) := match isa with
    | [.sym l, .sym o] => (l, o)
    | [.sym l] => (l, "VISUAL-OBJECT")
    | _ => ("VISUAL-LOCATION", "VISUAL-OBJECT")
  let rest := spec.filter (·.1 != "ISA")
  -- (slot location-value object-value?) as in the source
  let rest : List (Slot × Option Val × Option Val × Bool) := rest.map fun p => match p.2 with
    | [a, b] => (p.1, some a, some b, true)
    | [a] => (p.1, some a, none, false)
    | _ => (p.1, none, none, false)
  let rest := if isa.length == 2 && !rest.any (·.1 == "KIND") then rest ++ [("KIND", some (.sym objType), none, true)] else rest
  let rest := if objType == "TEXT" && !rest.any (·.1 == "TEXT") then rest ++ [("TEXT", none, some (.sym "T"), true)]
    else if objType == "OVAL" && !rest.any (·.1 == "OVAL") then rest ++ [("OVAL", none, some (.sym "T"), true)]
    else if objType == "LINE" && !rest.any (·.1 == "LINE") then rest ++ [("LINE", none, some (.sym "T"), true)]
    else rest
  let locSlots := rest.filterMap fun q => q.2.1.map (q.1, ·)
  let isLoc := fun (sl : Slot) => ["SCREEN-X", "SCREEN-Y", "DISTANCE"].contains sl
  let objSlots := rest.filterMap fun q => if isLoc q.1 then none
    else if q.2.2.2 then q.2.2.1.map (q.1, ·) else q.2.1.map (q.1, ·)
  let visSlots := rest.filterMap fun q => (q.2.2.1.orElse fun _ => q.2.1).map (q.1, ·)
  let vd := Val.num (Float.ofNat s.VP.viewDist) (toString s.VP.viewDist)
  let withD := fun (sl : List (Slot × Val)) =>
    if sl.any (fun q => q.1 == "DISTANCE" && match q.2 with | .num _ _ => true | _ => false) then sl
    else (Chunk.set ⟨"", sl⟩ "DISTANCE" (some vd)).slots
  let withSize := fun (sl : List (Slot × Val)) =>
    let c : Chunk := ⟨"", sl⟩
    let sz := match c.get "WIDTH", c.get "HEIGHT", c.get "DISTANCE" with
      | some (.num w _), some (.num h _), some (.num d _) => simpleSize w h d
      | _, _, _ => Val.ofF32 1.0
    if sl.any (fun q => q.1 == "SIZE" && match q.2 with | .num _ _ => true | _ => false) then sl
    else (c.set "SIZE" (some sz)).slots
  let locSlots := withSize (withD locSlots)
  let visSlots := withSize (withD visSlots)
  let (ln, s) := s.newName locType
  let (vn, s) := s.newName "VISICON-ID"
  let s := (s.putChunk ⟨ln, locSlots⟩).putChunk ⟨vn, visSlots⟩
  let s := { s with vinfo := (s.vinfo.insert vn vn).insert ln vn }
  let f : VFeature := { id := vn, loc := ln, slots := visSlots, objType := objType, objSlots := if objSlots.isEmpty then [] else objSlots }
  let s := s.setVis fun v => { v with updates := v.updates ++ [.add f] }
  s.scheduleProcDisplay

/-! ## Motor ([Src] core-modules/motor.lisp, support/general-pm.lisp, other-files/keyboard.lisp) -/

def St.setMot (s : St) (f : MotorState → MotorState) : St := { s with mot := f s.mot }

def St.handPos (s : St) (h : String) : HandPos := if h == "LEFT" then s.mot.left else s.mot.right

/-- `hand-position :current nil`: the hand's next location, if a prepared movement set one. -/
def St.nextPos (s : St) (h : String) : HandPos :=
  if h == "LEFT" then s.mot.leftNext.getD s.mot.left else s.mot.rightNext.getD s.mot.right

/-- `device-for-hand`: whether the hand's device is the mouse. -/
def St.onMouse (s : St) (h : String) : Bool := h == "RIGHT" && s.mot.rightOnMouse && s.mot.mouse.isSome

/-- `device-for-hand :current nil`: the device a prepared hand movement takes the hand to,
else the hand's device. -/
def St.devNext (s : St) (h : String) : Bool :=
  let nx := if h == "LEFT" then s.mot.leftNext else s.mot.rightNext
  match nx.bind (·.dev) with
  | some d => d
  | none => h == "RIGHT" && s.mot.rightOnMouse

def reqTime (now : Nat) : String := f32Text (nat32 now / f32 1000.0)

/-- `prepare-movement`: preparation takes `:motor-feature-prep-time` per feature that differs
from the last movement prepared. -/
def St.prepareMovement (s : St) (m : Movement) : St :=
  if s.mot.prep && m.execImm then s else  -- `check-jam` (a `prepare` request does not check)
  -- `prepare-features`: a peck's finger moves from where the hand will be
  let m := if m.kind == "PECK" then
      let h := s.nextPos m.hand
      { m with upd := some { h with fingers := h.fingers.map fun f =>
          if f.1 == m.finger && m.r != 0 then (f.1, polarMove f.2 m.r m.theta) else f } }
    else m
  let n := match s.mot.lastPrep with
    | some l => if l.styleName == m.styleName then m.featDiff l else m.numToPrepare
    | none => m.numToPrepare
  let (t, s) := s.rand32 (s.MP.featPrep * nat32 n)
  let s := s.setMot fun ms => { ms with prep := true, proc := true, lastPrep := some m }
  s.sched_ (secToMs t) (mkEv "MOTOR" s!"PREPARATION-COMPLETE {reqTime m.requestTime}" .prepComplete)

/-- `perform-movement`. -/
def St.performMovement (s : St) (m : Movement) : St :=
  let P := s.MP
  let s := s.sched_ (secToMs P.initTime) (mkEv "MOTOR" s!"INITIATION-COMPLETE {reqTime m.requestTime}" .initComplete)
  let s := s.setMot fun ms => { ms with proc := true, exec := true, initStamp := s.now }
  let h := s.handPos m.hand
  -- the hand's device, as at the start of execution
  let notify := fun (loc : Int × Int) =>
    mkEv "MOTOR" "" (if s.onMouse m.hand then .cursorPress loc else .motorNotify m.hand loc) (shown := false)
  let ((finishMs, outEvs), s) : (Nat × List (Nat × Ev)) × St := match m.kind with
    | "PUNCH" =>
      let ex := P.initTime + P.keyClosure
      ((secToMs (P.initTime + P.burst + P.burst),
        [(secToMs ex, notify (h.finger m.finger))]), s)
    | "PECK" =>
      let (f, s) := s.rand32 (fitts P P.peckCoef m.r)
      let ex := P.initTime + fmax P.burst f
      let h2 : HandPos := m.upd.getD h
      ((secToMs (P.burst + ex),
        [(secToMs ex, mkEv "MOTOR" "" (.setHandPos m.hand h2) (shown := false)),
         (secToMs ex, notify (h2.finger m.finger))]), s)
    | "HAND-PLY" =>
      -- `hand-ply`: the device changes and the hand moves at execution
      let (f, s) := s.rand32 (fitts P P.mouseCoef m.r m.width.toFloat32)
      let ex := P.initTime + f
      ((secToMs (P.burst + ex),
        [(secToMs ex, mkEv "MOTOR" "" (.setHandDevice m.hand m.toMouse) 1 (shown := false)),
         (secToMs ex, mkEv "MOTOR" s!"MOVE-A-HAND {m.hand} {f32Text m.r} {f32Text m.theta}" (.setHandPos m.hand (m.upd.getD h)))]), s)
    | "CURSOR-PLY" =>
      -- `cursor-ply`: the Fitts coefficient times 2^control-order (0 for the mouse)
      let (f, s) := s.randD (fittsD P P.mouseCoef m.rD m.width)
      let ex := P.initTime.toFloat + f
      ((secToMsD (P.burst.toFloat + ex),
        [(secToMsD ex, mkEv "MOTOR" "" (.cursorMove m.target) (shown := false)),
         (secToMsD ex, mkEv "MOTOR" "" (.setHandPos m.hand (m.upd.getD h)) (shown := false))]), s)
    | _ => -- PECK-RECOIL
      let mv := fmax P.burst (fitts P P.peckCoef m.r)
      let (r1, s) := s.rand32 mv
      let ex := P.initTime + fmax P.burst r1
      let (r2, s) := s.rand32 mv
      ((secToMs (ex + P.burst + fmax P.burst r2),
        [(secToMs ex, notify (polarMove (h.finger m.finger) m.r m.theta))]), s)
  let s := outEvs.foldl (fun s (e : Nat × Ev) => s.sched_ e.1 e.2) s
  s.sched_ finishMs (mkEv "MOTOR" s!"FINISH-MOVEMENT {reqTime m.requestTime}" .finishMovement)

/-- `chunk-to-visual-position`: the x, y, z of a location chunk, or of the location in an
object's `screen-pos`. -/
def St.visualPosition (s : St) (c : String) : Option (Chunk × (Int × Int × Int)) := do
  let ch ← s.findChunk c
  let pc := match ch.get "SCREEN-POS" with
    | some (.sym p) => (s.findChunk p).getD ch
    | _ => ch
  let num := fun (sl : String) => match pc.get sl with
    | some (.num x _) => if x == Float.floor x then some (Float.toInt64 x).toInt else none
    | _ => none
  return (ch, (← num "SCREEN-X", ← num "SCREEN-Y", ← num "DISTANCE"))

/-- `move-cursor` ([Src] motor.lisp): a cursor-ply of the right hand's mouse to the target,
from where the last cursor movement left it. -/
def St.moveCursor (s : St) (loc obj hand : Option Val) : St :=
  let h := match hand with | some (.sym "LEFT") => "LEFT" | _ => "RIGHT"
  if !(h == "RIGHT" && s.devNext h && s.mot.mouse.isSome) then s  -- "Hand is not on a cursor device"
  else if s.mot.prep then s  -- `check-jam`
  else
    let pos : Option Val → Option (Chunk × (Int × Int × Int)) := fun v => match v with
      | some (.sym c) => s.visualPosition c
      | _ => none
    match (pos obj).orElse fun _ => pos loc with
    | none => s
    | some (target, tl) =>
      let cur := s.mot.mouse.getD (0, 0, 0)
      let start := (s.nextPos h).target.getD cur
      let (r, theta) := xyToPolar (start.1, start.2.1) (tl.1, tl.2.1)
      if r == 0 && start.2.2 == tl.2.2 then s  -- "Move-cursor action aborted"
      else
        let z : Float := match target.get "DISTANCE" with
          | some (.num x _) => x
          | _ => Float.ofNat s.VP.viewDist
        let w := match target.get "WIDTH", target.get "HEIGHT" with
          | some (.num w _), some (.num ht _) =>
            approachWidth (Float.toInt64 w).toInt (Float.toInt64 ht).toInt z theta
          | _, _ => s.MP.defaultTargetWidth.toFloat
        let upd := { s.nextPos h with target := some tl }
        let m : Movement := { styleName := "PLY", kind := "CURSOR-PLY", hand := h, finger := "DUMMY",
                              theta := theta, rD := pixelsToAngle r.toFloat (s.VP.viewInches * s.VP.ppi).toFloat,
                              width := w, target := tl, upd := some upd, requestTime := s.now }
        s.prepareMovement m

/-- `point-hand`: a hand-ply of `hand` by `r`, `theta` (keyboard units) with the given finger
offsets, to the mouse or the keyboard. -/
def St.pointHand (s : St) (h : String) (r theta : Float32) (offsets : List (String × (Int × Int)))
    (toMouse : Bool) (twidth : Float32 := 4.0) : St :=
  let hp := s.nextPos h
  let upd : HandPos := { hp with loc := polarMove hp.loc r theta, fingers := offsets, dev := some toMouse }
  let m : Movement := { styleName := "PLY", kind := "HAND-PLY", hand := h, finger := "DUMMY", r := r,
                        theta := theta, rD := r.toFloat, width := twidth.toFloat, upd := some upd,
                        toMouse := toMouse, requestTime := s.now }
  s.prepareMovement m

/-- `point-hand-at-key` ([Src] keyboard.lisp): the hand moves so that the index finger is on
the key; the fingers keep their offsets, or take the standard ones (`offsets standard`). -/
def St.pointHandAtKey (s : St) (h key : String) (standard : Bool) : St :=
  match keyLoc key with
  | none => s  -- "No key mapping available"
  | some loc =>
    let hp := s.nextPos h
    let (r, th) := xyToPolar hp.loc loc
    let home := if h == "LEFT" then leftOffsets else rightOffsets
    let same := home.all fun f => hp.fingers.lookup f.1 == some f.2
    if r == 0 && !s.devNext h && same then s  -- "already is (or will be) at the requested key position"
    else s.pointHand h r th (if standard then home else hp.fingers) false s.MP.defaultTargetWidth

/-- `hand-to-mouse` ([Src] mouse.lisp `hand-to-cursor`). -/
def St.handToMouse (s : St) : St :=
  if s.mot.mouse.isNone then s  -- "no mouse device available"
  else
    let hp := s.nextPos "RIGHT"
    if hp.loc == mousePos && s.devNext "RIGHT" then s  -- "hand already is (or will be) at the mouse"
    else
      let (r, th) := xyToPolar hp.loc mousePos
      s.pointHand "RIGHT" r th rightOffsets true

/-- `hand-to-home` ([Src] keyboard.lisp): back to the home row of the keyboard. -/
def St.handToHome (s : St) (h : String) : St :=
  let home := if h == "LEFT" then leftHome else rightHome
  let hp := s.nextPos h
  let (r, th) := xyToPolar hp.loc home.loc
  let same := home.fingers.all fun f => hp.fingers.lookup f.1 == some f.2
  if r == 0 && !s.devNext h && same then s  -- "hand already is (or will be) at the home position"
  else s.pointHand h r th home.fingers false

def St.maybeExecute (s : St) : St :=
  match s.mot.queue with
  | m :: rest => if s.mot.exec then s else (s.setMot fun ms => { ms with queue := rest }).performMovement m
  | [] => s

/-- A movement of a key ([Src] `press-key`, `key->cmd`). -/
def St.keyMovement (s : St) (key : String) : Option Movement :=
  (keyCmd key).map fun k =>
    let num := fun (t : String) => match t.toList with
      | '-' :: r => -((String.ofList r).toNat?.map (·.toFloat32) |>.getD (parseF r))
      | r => ((String.ofList r).toNat?.map (·.toFloat32)).getD (parseF r)
    { styleName := if k.style == "PUNCH" then "PUNCH" else "PECK", kind := k.style, hand := k.hand, finger := k.finger, r := num k.r, theta := num k.theta, requestTime := s.now }
where
  parseF (r : List Char) : Float32 :=
    let (ip, fp) := (r.takeWhile (· != '.'), (r.dropWhile (· != '.')).drop 1)
    let i := (String.ofList ip).toNat!
    let f := (String.ofList fp).toNat!
    -- a decimal read as a single float (correctly rounded for these short decimals)
    ((Float.ofNat i) + Float.ofNat f / Float.pow 10.0 (Float.ofNat fp.length)).toFloat32

/-! ## Audio ([Src] core-modules/audio.lisp) -/

def St.setAud (s : St) (f : AudState → AudState) : St := { s with aud := f s.aud }

/-- `update-sound-evt`: the event chunk shows the sound's onset, location, kind, id,
pitch, and once it is over its offset and duration. -/
def St.updateSoundEvt (s : St) (e : SoundEvt) : St :=
  let fin := s.now ≥ e.offset
  let sets : List (Slot × Val) := [("ONSET", Val.ofInt e.onset), ("LOCATION", .sym e.location),
    ("KIND", .sym e.kind), ("ID", .sym e.ename), ("PITCH", .sym e.pitch)] ++
    (if fin then [("OFFSET", Val.ofInt e.offset),
                  ("DURATION", Val.ofF32 (nat32 (e.offset - e.onset) / f32 1000.0))] else [])
  s.modChunk e.ename fun c => sets.foldl (fun c x => c.set x.1 (some x.2)) c

/-- `purge-old-sounds`: sounds over for longer than `:sound-decay-time` leave. -/
def St.purgeSounds (s : St) : St :=
  s.setAud fun a => { a with audicon := a.audicon.filter fun e => !(e.offset + s.AP.decay < s.now) }

/-- A new sound ([Src] `new-sound-event`): its chunks are created, it joins the audicon,
the buffer can be stuffed once it is detectable, and its onset shows in the trace. -/
def St.newSound (s : St) (kind : String) (content : Val) (dur : Option Nat) (onset : Option Nat)
    (location : String) (other : Option (Nat × Nat × Nat) := none) : St :=
  let onset := onset.getD s.now
  let (sn, s) := s.newName (if other.isSome then "SOUND" else kind)
  let (en, s) := s.newName "AUDIO-EVENT"
  let base := kind == "SOUND" && other.isNone
  let kind := if base then "WORD" else kind
  let ((duration, delay, recode, pitch), s) : (Nat × Nat × Nat × String) × St :=
    match other with
    | some (du, de, re) => ((du, de, re, "MIDDLE"), s)  -- `new-other-sound`: as given
    | none => match kind with
    | "DIGIT" =>
      let (du, s) := s.randMs s.AP.digitDuration
      let (de, s) := s.randMs s.AP.digitDetect
      ((du, de, s.AP.digitRecode, "MIDDLE"), s)
    | "TONE" =>
      let f := match content with | .num x _ => x | _ => 1000.0
      let (de, s) := s.randMs s.AP.toneDetect
      ((dur.getD 0, de, s.AP.toneRecode,
        if f > 1500.0 then "HIGH" else if f < 900.0 then "LOW" else "MIDDLE"), s)
    | _ =>
      let d := dur.getD (artTimeMs s.SP (match content with | .str t => t | v => v.show))
      if base then ((d, s.SP.subvocalDelay, 0, "MIDDLE"), s)
      else
        let (de, s) := s.randMs s.AP.digitDetect
        ((d, de, max (d / 2) (d - 150), "MIDDLE"), s)
  let e : SoundEvt := { sname := sn, ename := en, onset := onset, offset := onset + duration, content := content, delay := delay, kind := kind, location := location, recode := recode, pitch := pitch }
  let s := (s.putChunk ⟨sn, []⟩).putChunk ⟨en, []⟩
  let s := s.setAud fun a => { a with audicon := a.audicon ++ [e] }
  let s := s.sched_ (onset + delay - s.now) (mkEv "AUDIO" "" .stuffSound (shown := false))
  s.sched_ (onset - s.now) (mkEv "AUDIO" "new-sound" .newSoundShown)

/-- `find-sound`. -/
def St.findSound (s : St) (spec : List ITest) (stuffed : Bool) : St :=
  let s := s.purgeSounds
  let evs := s.aud.audicon.filter fun e => s.now ≥ e.onset + e.delay
  let evs := match spec.find? (·.slot == ":ATTENDED") with
    | some t => evs.filter fun (e : SoundEvt) => e.attended == t.arg.isSome
    | none => evs
  let evs := match spec.find? (·.slot == ":FINISHED") with
    | some t => evs.filter fun (e : SoundEvt) => decide (s.now ≥ e.offset) == t.arg.isSome
    | none => evs
  let s := evs.foldl St.updateSoundEvt s
  let isMM := fun (t : ITest) => match t.arg with
    | some (.sym "LOWEST") | some (.sym "HIGHEST") => true | _ => false
  let slots := spec.filter fun t => !t.slot.startsWith ":" && !isMM t
  let mm := spec.filter fun t => !t.slot.startsWith ":" && isMM t
  let chunkOf := fun (e : SoundEvt) => (s.findChunk e.ename).getD ⟨e.ename, []⟩
  let matching := (evs.filter fun e => slots.all (·.holds (chunkOf e))).reverse
  let matching := mm.foldl (fun (ms : List SoundEvt) (t : ITest) =>
    let low := t.arg == some (.sym "LOWEST")
    let vals := ms.filterMap fun (e : SoundEvt) => match (chunkOf e).get t.slot with | some (.num x _) => some x | _ => none
    if vals.length != ms.length then ms else
    match vals with
    | [] => ms
    | v :: vs =>
      let best := vs.foldl (fun (b x : Float) => if (low && x < b) || (!low && x > b) then x else b) v
      (ms.filter fun (e : SoundEvt) => (ITest.mk t.cmp t.slot (some (.num best ""))).holds (chunkOf e)).reverse) matching
  let s := s.setAud fun a => { a with locFailure := false }
  if matching.isEmpty then
    s.sched_ 0 (mkEv "AUDIO" "find-sound-failure" (.findSoundFailure stuffed))
  else
    let (k, rng) := s.rng.randNat matching.length
    let s := { s with rng := rng }
    let e := matching[k]!
    let s := if stuffed && (s.bufs .auralLocation).chunk.isSome then
        s.sched_ 0 (mkEv "AUDIO" ("OVERWRITE-BUFFER-CHUNK AURAL-LOCATION " ++ e.ename ++ " NIL")
          (.overwriteBuffer .auralLocation e.ename) 10)
      else s.sched_ 0 (mkEv "AUDIO" ("SET-BUFFER-CHUNK AURAL-LOCATION " ++ e.ename ++ (if stuffed then " NIL" else ""))
        (.setBufferChunk .auralLocation e.ename (!stuffed)) 10)
    let s := if stuffed then s.setAud fun a => { a with lastStuffed := some e.ename } else s
    if s.now ≥ e.offset then s
    else s.sched_ (e.offset - s.now) (mkEv "AUDIO" ("AUDIO-EVENT-ENDED " ++ e.ename) (.audioEventEnded e.ename) 9 (maint := true))

/-- `aural-location-update-check`: the aural-location buffer still holds the event. -/
def St.auralHolds (s : St) (ename : String) : Bool :=
  match (s.bufs .auralLocation).chunk.bind (·.get "ID") with
  | some (.sym id) => id == ename
  | _ => false

/-- `attend-sound`. -/
def St.attendSound (s : St) (chunk : String) : St :=
  if s.aud.exec then s else
  let s := s.purgeSounds
  let id := match (s.findChunk chunk).bind (·.get "ID") with | some (.sym i) => i | _ => ""
  let ev := s.aud.audicon.find? fun e => e.ename == id && e.onset ≤ s.now
  let s := s.setAud fun a => { a with attendFailure := false, exec := true }
  match ev with
  | some e =>
    let (d, s) := s.randMs e.recode
    s.sched_ d (mkEv "AUDIO" ("AUDIO-ENCODING-COMPLETE " ++ id) (.audioEncodingComplete e.ename))
  | none =>
    let (d, s) := s.randMs s.AP.digitRecode
    s.sched_ d (mkEv "AUDIO" "attend-sound-failure" .attendSoundFailure)

/-! ## Speech ([Src] core-modules/speech.lisp, other-files/microphone.lisp) -/

def St.setSpc (s : St) (f : SpeechState → SpeechState) : St := { s with spc := f s.spc }

def St.speakPrepare (s : St) (m : SpeakMv) : St :=
  if s.spc.prep then s else
  let n := match s.spc.lastPrep with
    | some l => if l.sub != m.sub then 3 else if l.text.toUpper == m.text.toUpper then 0 else 2
    | none => 3
  let s := s.setSpc fun ms => { ms with prep := true, proc := true, lastPrep := some m }
  let (t, s) := s.rand32 (s.MP.featPrep * nat32 n)
  s.sched_ (secToMs t) (mkEv "SPEECH" s!"PREPARATION-COMPLETE {reqTime m.requestTime}" .speechPrepComplete)

def St.speakPerform (s : St) (m : SpeakMv) : St :=
  let ex := s.MP.initTime
  let art := nat32 (artTimeMs s.SP m.text) / f32 1000.0
  let fin := ex + art
  let s := s.sched_ (secToMs s.MP.initTime) (mkEv "SPEECH" s!"INITIATION-COMPLETE {reqTime m.requestTime}" .speechInitComplete)
  let s := s.setSpc fun ms => { ms with proc := true, exec := true }
  let s := if m.sub then
      s.newSound "SOUND" (.str m.text) (some (artTimeMs s.SP m.text)) (some (s.now + secToMs ex)) "INTERNAL"
    else s.newSound "WORD" (.str m.text) none (some (s.now + secToMs ex)) "SELF"
  let s := if m.sub then s else
    let s := s.sched_ (secToMs ex) (mkEv "SPEECH" "" (.speechNotify m.text) (shown := false))
    s.sched_ (secToMs fin) (mkEv "SPEECH" "" .noop (shown := false))
  s.sched_ (secToMs fin) (mkEv "SPEECH" s!"FINISH-MOVEMENT {reqTime m.requestTime}" .speechFinish)

def St.speakMaybeExecute (s : St) : St :=
  match s.spc.queue with
  | m :: rest => if s.spc.exec then s else (s.setSpc fun ms => { ms with queue := rest }).speakPerform m
  | [] => s

/-! ## Task commands -/

def St.chunkNamed (s : St) (n : String) : Option Chunk :=
  match Buf.all.findSome? (fun b => (s.bufs b).chunk.filter (·.name == n)) with
  | some c => some c
  | none => s.findChunk n

def optRepr : Option Val → String
  | some v => v.repr
  | none => "NIL"

/-- The answer to a query of the task code. -/
def St.answer (s : St) (name : String) (args : List (Option Val)) : String :=
  let slotOf (c : Option Chunk) (sl : Option Val) : String :=
    match c, sl with
    | some c, some (.sym sl) => optRepr (c.get sl)
    | _, _ => "NIL"
  match name, args with
  | "BUFFER-READ", [some (.sym b)] =>
    match Buf.ofName? b with
    | some b => match (s.bufs b).chunk with | some c => c.name | none => "NIL"
    | none => "NIL"
  | "BUFFER-SLOT-VALUE", [some (.sym b), sl] =>
    match Buf.ofName? b with
    | some b => slotOf (s.bufs b).chunk sl
    | none => "NIL"
  | "CHUNK-SLOT-VALUE-FCT", [some (.sym c), sl] => slotOf (s.chunkNamed c) sl
  | "GET-TIME", _ | "MP-TIME-MS", _ => toString s.now
  | "MP-TIME", _ => f32Text (nat32 s.now / f32 1000.0)
  | _, _ => "?"

def goalFocusEv (g : String) : Ev :=
  mkEv "GOAL" ("SET-BUFFER-CHUNK GOAL " ++ g ++ " NIL") (.setBufferChunk .goal g false) (isMax := true)

/-- Add chunks to declarative memory now (`add-dm`). -/
def St.addDM (s : St) (cs : List Chunk) : St :=
  cs.foldl (fun s c =>
    let s := s.putChunk c
    match s.dmFind c with
    | some tn => s.dmRef tn
    | none => s.dmAdd c c.name) s

mutual
/-- Carry out a command of the task code. -/
partial def St.applyCmd (s : St) : TCmd → St
  | .pdisable ns => { s with disabled := s.disabled ++ ns }
  | .penable ns => { s with disabled := s.disabled.filter (!ns.contains ·) }
  | .setBufferSpec b spec => putInBuffer s b (chunkOfSpec spec) true true
  | .setParams f =>
    let (P, VP, MP) := f (s.P, s.VP, s.MP)
    { s with P := P, VP := VP, MP := MP }
  | .clearBuffer b => s.clearBufS b
  | .schedAct d a prio mx mn module details shown =>
    s.sched_ d { time := 0, module := module, details := details, act := a,
                 prio := prio, isMax := mx, isMin := mn, shown := shown }
  | .modFocus mods =>
    if (s.bufs .goal).chunk.isNone then s
    else s.sched_ 0 (mkEv "GOAL" "GOAL-MODIFICATION" (.modBuffer .goal mods) (isMax := true))
  | .modChunk n mods =>
    let n := s.trueName n
    let f := fun (c : Chunk) => mods.foldl (fun c x => c.set x.1 (x.2.map s.trueVal)) c
    { (s.modChunk n f).dmModify n f with
             bufs := fun b => let st := s.bufs b
               { st with chunk := st.chunk.map fun c => if c.name == n then f c else c } }
  | .goalFocus g =>
    if (s.findChunk g).isSome then
      -- and `clear-delayed-goal` after it, a hidden event (it counts for `run-n-events`)
      (s.sched_ 0 (goalFocusEv g)).sched_ 0 (mkEv "GOAL" "CLEAR-DELAYED-GOAL" .noop (shown := false) (isMin := true) (maint := true))
    else s
  | .echo l => s.emit l
  | .rngSync n => { s with rng := s.rng.advanceTo n }
  | .copyChunk src =>
    -- the chunk as it is now: a buffer's chunk may have been modified there
    let inBuf := Buf.all.findSome? fun b => (s.bufs b).chunk.filter (·.name == s.trueName src)
    match inBuf.orElse fun _ => s.findChunk src with
    | some c =>
      let (nm, s) := s.newName (c.name ++ "-")
      let s := s.putChunk { c with name := nm }
      let s := match s.vinfo.get? c.name with
        | some e => { s with vinfo := s.vinfo.insert nm e }
        | none => s
      { s with copyOf := s.copyOf.insert nm c.name }
    | none => s
  | .setImaginalFree => { s with imBusy := false }
  | .setImaginalError =>
    let s := { s with imError := true }
    (s.setBuf .imaginal fun st => { st with failure := true }).setBuf .imaginalAction fun st => { st with failure := true }
  | .installMouse =>
    s.setMot fun m => if m.mouse.isSome then m else { m with mouse := some (0, 0, (s.VP.viewDist : Int)) }
  | .setCursorPosition x y z =>
    s.setMot fun m => if m.mouse.isSome then { m with mouse := some (x, y, z.getD (s.VP.viewDist : Int)) } else m
  | .startHandAtMouse =>
    s.setMot fun m => { m with mouse := m.mouse <|> some (0, 0, (s.VP.viewDist : Int)),
                               right := { loc := mousePos, fingers := rightOffsets }, rightOnMouse := true }
  | .setBufferChunk b c req =>
    match s.findChunk c with
    | some ch => putInBuffer s b ch false req
    | none => s
  | .sched d action params sp prio mx mn module details shown =>
    let det := details.getD (" ".intercalate (action :: sp))
    s.sched_ d { time := 0, module := module, details := det, act := .task action params,
                 prio := prio, isMax := mx, isMin := mn, shown := shown }
  | .query line name args => (s.emit line).emit ("#A " ++ s.answer name args)
  | .triggerReward r txt =>
    s.sched_ 0 (mkEv "UTILITY" ("PROPAGATE-REWARD " ++ txt) (.propagateReward r) (isMax := true))
  | .addDM cs => s.addDM cs
  | .defineChunks cs => cs.foldl St.putChunk s
  | .call name args => (s.callTask name args).1
  | .addVisicon fs => fs.foldl St.addFeature s
  | .deleteVisicon ids =>
    let ok := ids.filter fun id => s.vis.visicon.any (·.id == id) ||
      s.vis.updates.any fun u => match u with | .add f => f.id == id | _ => false
    (s.setVis fun v => { v with updates := v.updates ++ ok.map .delete }).scheduleProcDisplay
  | .deleteAllVisicon => (s.setVis fun v => { v with updates := v.updates ++ [.deleteAll] }).scheduleProcDisplay
  | .modifyVisicon ms =>
    let ups := ms.map fun m => VUpdate.modify m.1 (m.2.map fun q => match q.2 with
      | [a, b] => (q.1, some a, some b)
      | [a] => (q.1, some a, none)
      | _ => (q.1, none, none))
    (s.setVis fun v => { v with updates := v.updates ++ ups }).scheduleProcDisplay
  | .newSound k c d o l => s.newSound k c d o l
  | .newOtherSound c du de re o l k => s.newSound k c (some du) o l (some (du, de, re))
  | .setVislocDefault spec => s.setVis fun v => { v with defaultSpec := spec }
  | .setAudlocDefault spec => s.setAud fun a => { a with defaultSpec := spec }
  | .monitor c m => { s with monitors := s.monitors ++ [(c, m)] }
  | .unmonitor c m => { s with monitors := s.monitors.filter (· != (c, m)) }
  | .noop => s

/-- A call of a task command: the next recorded call is replayed. -/
partial def St.callTask (s : St) (name : String) (args : List String) : St × Option Val :=
  let s := s.emit ("#CB " ++ " ".intercalate (name :: args))
  match s.cbs with
  | cb :: rest =>
    let s := cb.cmds.foldl St.applyCmd { s with cbs := rest }
    ({ s with rng := s.rng.advanceTo cb.rng }.emit "#ENDCB", cb.result)
  | [] => (s.emit "#ENDCB (no recorded call)", none)
end

/-- Evaluate an expression of a production; task commands are called. -/
partial def St.eval (s : St) (env : Env) : Expr → Option Val × St
  | .cmd name args =>
    let (vs, s) := args.foldl (fun (acc : List (Option Val) × St) a =>
      let (v, s) := acc.2.eval env a
      (acc.1 ++ [v], s)) ([], s)
    let (s, r) := s.callTask name (vs.map optRepr)
    (r, s)
  | e => match e.evalPure env with
    | some v => (v, s)
    | none => (none, { s with err := s.err.orElse fun _ => some "a Lisp expression the model evaluates" })

/-- All the values of an expression (`!mv-bind!`). -/
def St.evalM (s : St) (env : Env) (e : Expr) : List (Option Val) × St :=
  match e with
  | .cmd _ _ => let (v, s) := s.eval env e; ([v], s)
  | e => match e.evalM env with
    | some vs => (vs, s)
    | none => ([], { s with err := s.err.orElse fun _ => some "a Lisp expression the model evaluates" })

/-! ## Event handlers -/

def pev (details : String) (a : Act) (prio : Int := 0) : Ev :=
  { time := 0, module := "PROCEDURAL", details := details, act := a, prio := prio }

/-- `production-selected`: the buffer-read and query events of the selected production's
conditions, then the production-fired event `:dat` later. -/
def onSelected (s : St) (i : Nat) (env : Env) : St :=
  let p := s.prods[i]!
  -- the hidden request to the `production` buffer ([Src] `production-selected`)
  let s := s.sched_ 0 (pev p.name .noop |> fun e => { e with isMax := true, shown := false })
  let s := (p.allConds s.P.proc).foldl (fun s c => match c with
    | .buf b _ => s.sched_ 0 (pev ("BUFFER-READ-ACTION " ++ b.name) (.bufferRead b))
    | .query b _ => s.sched_ 0 (pev ("QUERY-BUFFER-ACTION " ++ b.name) (.queryBuffer b))
    | .eval _ => s) s
  let s := if s.P.ul then { s with used := (p.name, s.now) :: s.used } else s
  let (d, s) := if s.P.vpft then s.randMs (p.actTime.getD s.P.dat) else (p.actTime.getD s.P.dat, s)
  s.sched_ d (pev ("PRODUCTION-FIRED " ++ p.name) (.prodFired i env))

/-- `print-production-output`: the values with `~s`, or, when the first item written is a
string (`fmt`), that string used as a `format` control (`~a`, `~s`, `~%`, `~~`) on the
others. -/
def outputText (fmt : Bool) (vs : List (Option Val)) : String :=
  let rep := fun (v : Option Val) => match v with | some v => v.repr | none => "NIL"
  match fmt, vs with
  | true, some (.str ctl) :: args => Id.run do
    let mut out := ""
    let mut rest := args
    let mut cs := ctl.toList
    while !cs.isEmpty do
      match cs with
      | '~' :: d :: r =>
        cs := r
        if d == 'a' || d == 'A' then
          out := out ++ (match rest.head? with | some (some v) => v.show | _ => "NIL"); rest := rest.drop 1
        else if d == 's' || d == 'S' then
          out := out ++ rep (rest.head?.getD none); rest := rest.drop 1
        else if d == '%' then out := out ++ "\n"
        else if d == '~' then out := out ++ "~"
        else out := out ++ String.ofList ['~', d]
      | c :: r => out := out.push c; cs := r
      | [] => cs := []
    return out
  | _, _ => " ".intercalate (vs.map rep)

/-- `production-fired` ([Src] `production-fired` and the action closures built by `p-fct`):
`!output!` first, then each action in order (modifications at priority 100, requests at 50,
clears at 10, `!stop!` at `:min`), then the strict-harvesting clears and the request clears
at 10, then a new conflict resolution at `:min`. -/
def onFired (s : St) (i : Nat) (env : Env) : St :=
  let p := s.prods[i]!
  -- `!bind!`, `!mv-bind!`, `!output!` and `!eval!` in the written order, a binding moved before
  -- the first of those that uses its variables ([Src] `p-fct`, `sort-for-bind-order`)
  let bangs : List (Option (List String) × List String × Action) := p.rhs.filterMap fun a => match a with
    | .bind x e => some (some (x.splitOn " "), e.vars, a)
    | .eval e => some (none, e.vars, a)
    | .output ts => some (none, ts.filterMap (fun t => match t with | .var x => some x | _ => none), a)
    | _ => none
  let (s, env) := (sortForBindOrder bangs).foldl (fun (acc : St × Env) x =>
    let (s, env) := acc
    match x.2.2 with
    | .bind x e =>
      let names := x.splitOn " "
      if names.length > 1 then
        -- `!mv-bind!`: one value per variable, `nil` for the missing ones
        let (vs, s) := s.evalM env e
        (s, (names.zipIdx).foldl (fun env (n, i) =>
          -- `rhs-bind-variable`: `nil` is replaced by `t`
          (n, (vs[i]?.join).getD (.sym "T")) :: env) env)
      else
        let (v, s) := s.eval env e
        (s, (x, v.getD (.sym "T")) :: env)
    | .output ts => (s.emit ("OUTPUT " ++ outputText (match ts with | .const (.str _) :: _ => true | _ => false)
        (ts.map (termVal env))), env)
    | .eval e => ((s.eval env e).2, env)
    | _ => (s, env)) (s, env)
  -- `instantiate-chunk-spec`: a variable slot name that names no slot yet extends the
  -- possible slots (shown for a modification as `extend-buffer-chunk`)
  let resolve := fun (s : St) (sets : List (Slot × Option Term)) =>
    let rs := sets.filterMap fun x => (resolveSlot env x.1).map fun sl => (sl, x.2.bind (termVal env))
    let new := (rs.map (·.1)).filter (!s.slotNames.contains ·)
    (rs, !new.isEmpty, { s with slotNames := new.foldl (·.insert ·) s.slotNames })
  let s := p.rhs.foldl (fun s a => match a with
    | .modify b sets =>
      if sets.isEmpty then s
      else
        let (rs, ext, s) := resolve s sets
        -- a slot named twice (through a variable slot name) is an invalid modification
        let dup := (rs.map (·.1)).eraseDups.length != rs.length
        let s := if dup then s else s.sched_ 0 (pev ("MOD-BUFFER-CHUNK " ++ b.name) (.modBuffer b rs) 100)
        if ext then s.sched_ 0 (pev ("EXTEND-BUFFER-CHUNK " ++ b.name) .noop 101) else s
    | .clear b => s.sched_ 0 (pev ("CLEAR-BUFFER " ++ b.name) (.clearBuffer b) 10)
    | .erase b => s.sched_ 0 (pev ("ERASE-BUFFER " ++ b.name) (.eraseBuffer b) 90)
    | .request b spec =>
      let its := spec.filterMap (·.inst env)
      let s := { s with slotNames := its.foldl (fun (h : Std.HashSet String) (t : ITest) => h.insert t.slot) s.slotNames }
      s.sched_ 0 (pev ("MODULE-REQUEST " ++ b.name) (.moduleRequest b its) 50)
    | .modRequest b sets =>
      let (rs, ext, s) := resolve s sets
      let dup := (rs.map (·.1)).eraseDups.length != rs.length
      let s := if dup then s else s.sched_ 0 (pev ("MODULE-MOD-REQUEST " ++ b.name) (.modRequest b rs) 60)
      if ext then s.sched_ 0 (pev ("EXTEND-BUFFER-CHUNK " ++ b.name) .noop 61) else s
    | .directRequest b t =>
      match termVal env t with
      | some v => s.sched_ 0 (pev "" (.directRequest b v) 99 |> fun e => { e with shown := false })
      | none => s
    | .overwrite b (some t) _ =>
      match termVal env t with
      | some (.sym c) =>
        if (s.findChunk c).isSome then
          s.sched_ 0 (pev s!"OVERWRITE-BUFFER-CHUNK {b.name} {c} NIL" (.overwriteBuffer b c) 90)
        else s
      | _ => s
    | .overwrite b none spec =>
      let its := spec.filterMap (·.inst env)
      let new := (its.map (·.slot)).filter (!s.slotNames.contains ·)
      let s := { s with slotNames := new.foldl (·.insert ·) s.slotNames }
      let s := s.sched_ 0 (pev s!"OVERWRITE-BUFFER-CHUNK-FROM-SPEC {b.name}  NIL" (.overwriteSpec b its) 90)
      if new.isEmpty then s else s.sched_ 0 (pev ("EXTEND-BUFFER-CHUNK " ++ b.name) .noop 91)
    | .stop => s.sched_ 0 (mkEv "------" "BREAK-EVENT Stopped by !stop!" .stop (isMin := true))
    | _ => s) s
  let s := (harvested s.P.proc p ++ requestCleared p).foldl (fun s b =>
    s.sched_ 0 (pev ("CLEAR-BUFFER " ++ b.name) (.clearBuffer b) 10)) s
  -- `learn-parameters`: a production with a reward triggers it at `:min` priority
  let s := match p.reward with
    | some (r, txt) => s.sched_ 0 (mkEv "PROCEDURAL" ("TRIGGER-REWARD " ++ txt) (.triggerReward r txt) (isMin := true))
    | none => s
  let s := s.sched_ 0 { crEv with isMin := true }
  -- `:cycle-hook`
  let s := s.P.cycleHooks.foldl (fun s h => (s.callTask h [p.name]).1) s
  -- `compile-productions` ([Src] `production-fired` calls it last)
  if s.P.epl then
    let E : CompEnv := {
      P := s.P
      chunkOf := fun n => match (s.bufs .retrieval).chunk with
        | some c => if c.name == n then some c else s.findChunk n
        | none => s.findChunk n
      taken := s.chunks.contains
      trueName := s.trueName }
    let (C, prods, names, log) := compileFired E s.comp s.prods s.names s.now i env
    { s with comp := C, prods := prods, names := names, out := log ++ s.out }
  else s

/-- A module request ([Src] `goal-style-request`, `imaginal-request`,
`start-retrieval`'s caller `dm-request`). -/
def onRequest (s : St) (b : Buf) (spec : List ITest) : St :=
  match b with
  | .goal =>
    if specDefOK spec then
      s.sched_ 0 (mkEv "GOAL" "SET-BUFFER-CHUNK-FROM-SPEC GOAL" (.setBufferSpec .goal spec) (-1000))
    else s
  | .temporal =>
    -- `temporal-request`: a new request stops the counting; the start increment is drawn
    -- at the first request
    let s := match s.tmNext with | some n => { s.deleteEv n with tmNext := none } | none => s
    let (start, s) := match s.tmStart with
      | some x => (x, s)
      | none =>
        let m : Float32 := nat32 s.P.timeStartMs
        let (n, rng) := s.rng.noise (m * (5 : Float32) * s.P.timeNoise)
        let x := m + n
        let x := if (1 : Float32) > x then 1 else x
        (x, { s with tmStart := some x, rng := rng })
    if spec.any (·.slot == "CLEAR") then s.sched_ 0 (mkEv "TEMPORAL" "Clear" .noop)
    else if !spec.any (·.slot == "TICKS") then s
    else
      let s := s.sched_ 0 (mkEv "TEMPORAL" "SET-BUFFER-CHUNK-FROM-SPEC TEMPORAL"
        (.setBufferSpec .temporal [⟨.eq, "TICKS", some (.num 0 "0")⟩]) (-1000))
      let (n, rng) := s.rng.noise (s.P.timeNoise * start)
      let t := start + n
      let t := if (1 : Float32) > t then 1 else t
      let s := { s with rng := rng, tmTick := t, tmTicks := 0 }
      let (s, e) := s.sched (roundEven t).toNat (mkEv "TEMPORAL" "Incrementing time ticks to 1" .temporalTick (isMin := true))
      { s with tmNext := some e }
  | .imaginalAction =>
    -- `imaginal-request` of the action buffer: the action is called now; a simple action's
    -- result is the chunk the imaginal buffer gets after the delay
    let get := fun (sl : Slot) => (spec.find? (·.slot == sl)).bind (·.arg)
    match s.imBusy, get "ACTION" with
    | false, some act =>
      let name := match act with | .sym n => n.toLower | v => v.show
      let simple := match get "SIMPLE" with | some (.sym "NIL") | none => false | _ => true
      -- `slots`: the slot names are passed to the action; they need a chunk in the buffer
      let slots := match get "SLOTS" with
        | some (.str x) => (x.splitOn " ").filter (!·.isEmpty)
        | _ => []
      if !slots.isEmpty && (s.bufs .imaginal).chunk.isNone then s else
      let s := { s with imBusy := true, imError := false }
      let (s, r) := s.callTask name slots
      if !simple then s
      else
        let (d, s) := s.imDelay
        let s := s.sched_ 0 (mkEv "IMAGINAL" "CLEAR-BUFFER IMAGINAL" (.clearBuffer .imaginal))
        match r with
        | none =>
          let s := s.sched_ d (mkEv "IMAGINAL" "" .imaginalFree (shown := false))
          s.sched_ d (mkEv "IMAGINAL" "" .imaginalError (shown := false))
        | some v =>
          let c := match v with | .sym c => c | .str c => c.toUpper | v => v.show
          if (s.findChunk c).isSome then
            let s := s.sched_ d (mkEv "IMAGINAL" s!"SET-BUFFER-CHUNK IMAGINAL {c}" (.setBufferChunk .imaginal c true) (-1000))
            s.sched_ d (mkEv "IMAGINAL" "" .imaginalFree (-1001) (shown := false) (maint := true))
          else { s with imBusy := false }  -- "Invalid result from the action"
    | _, _ => s
  | .imaginal =>
    if s.imBusy then s
    else
      let s := { s with imBusy := true, imError := false }
      let (d, s) := s.imDelay
      let s := s.sched_ d (mkEv "IMAGINAL" "" .imaginalFree (-1010) (shown := false))
      s.sched_ d (mkEv "IMAGINAL" "" (.goalStyleRequest .imaginal spec) (shown := false))
  | .retrieval =>
    let s := match s.dmBusy with
      | some n => s.deleteEv n
      | none => s
    let (s, n) := { s with dmFailed := false }.sched 0
      (mkEv "DECLARATIVE" "start-retrieval" (.startRetrieval spec) (-2000))
    { s with dmBusy := some n }
  | .visualLocation =>
    if spec.any (·.slot == "SET-VISLOC-DEFAULT") then
      let s := s.setVis fun v => { v with lastCmd := "SET-VISLOC-DEFAULT" }
      s.sched_ 0 (mkEv "VISION" "Set-visloc-default" (.setVislocDefault spec) 9)
    else
      let s := s.setVis fun v => { v with lastCmd := "FIND-LOCATION" }
      s.sched_ 0 (mkEv "VISION" "Find-location" (.findLocation spec))
  | .visual =>
    let s := if s.vis.visualLock then
        (s.setVis fun v => { v with visualLock := false }).sched_ 0
          (mkEv "VISION" "" .unlockVision (shown := false) (isMin := true) (maint := true))
      else s
    let cmd := (spec.find? (·.slot == "CMD")).bind (·.arg)
    let isClear := (spec.length == 1 && spec.any (fun t => t.slot == "CLEAR" && t.arg.isSome)) ||
      (spec.length == 1 && cmd == some (.sym "CLEAR"))
    if isClear then
      (s.setVis fun v => { v with lastCmd := "CLEAR" }).sched_ 0 (mkEv "VISION" "CLEAR" .visClear)
    else match cmd with
      | some (.sym "MOVE-ATTENTION") =>
        let sp := match (spec.find? (·.slot == "SCREEN-POS")).bind (·.arg) with
          | some (.sym n) => n | _ => ""
        let scale := match (spec.find? (·.slot == "SCALE")).bind (·.arg) with
          | some v => v.show | none => "NIL"
        let s := s.setVis fun v => { v with lastCmd := "MOVE-ATTENTION" }
        if ((s.chunkNamed sp).bind (·.xyz)).isSome then
          s.sched_ 0 (mkEv "VISION" s!"Move-attention {sp} {scale}" (.moveAttention sp scale))
        else s
      | some (.sym c) => s.setVis fun v => { v with lastCmd := c }
      | _ => s
  | .manual =>
    let cmd := (spec.find? (·.slot == "CMD")).bind (·.arg)
    let get := fun (sl : Slot) => (spec.find? (·.slot == sl)).bind (·.arg)
    let isClear := (spec.length == 1 && spec.any (fun t => t.slot == "CLEAR" && t.arg.isSome)) ||
      (spec.length == 1 && cmd == some (.sym "CLEAR"))
    if isClear then
      (s.setMot fun m => { m with lastCmd := "CLEAR" }).sched_ 0 (mkEv "MOTOR" "CLEAR" .motorClear)
    else
    let s := match cmd with | some (.sym c) => s.setMot fun m => { m with lastCmd := c } | _ => s
    match cmd with
    | some (.sym "PRESS-KEY") =>
      match get "KEY" with
      | some k => s.sched_ 0 (mkEv "MOTOR" s!"PRESS-KEY KEY {k.show}" (.pressKey k.show))
      | none => s
    | some (.sym "MOVE-CURSOR") =>
      let parts := ["LOC", "OBJECT", "HAND"].filterMap fun sl => (get sl).map fun v => sl ++ " " ++ v.show
      s.sched_ 0 (mkEv "MOTOR" ("MOVE-CURSOR " ++ " ".intercalate parts)
        (.moveCursor (get "LOC") (get "OBJECT") (get "HAND")))
    | some (.sym "CLICK-MOUSE") => s.sched_ 0 (mkEv "MOTOR" "CLICK-MOUSE" .clickMouse)
    | some (.sym "EXECUTE") => s.sched_ 0 (mkEv "MOTOR" "EXECUTE" .motorExecute)
    | some (.sym "POINT-HAND-AT-KEY") =>
      match get "HAND", get "TO-KEY" with
      | some (.sym h), some k =>
        let std := match get "OFFSETS" with | some (.sym "STANDARD") => true | _ => false
        if (get "OFFSETS").isSome && !std then { s with err := s.err.orElse fun _ => some "point-hand-at-key with a list of offsets" }
        else
          let parts := ["HAND", "TO-KEY", "OFFSETS"].filterMap fun sl => (get sl).map fun v => sl ++ " " ++ v.show
          s.sched_ 0 (mkEv "MOTOR" ("POINT-HAND-AT-KEY " ++ " ".intercalate parts) (.pointHandAtKey h k.show std))
      | _, _ => s
    | some (.sym "PREPARE") =>
      -- `prepare` with the style and the features the request gives
      let feats := ["HAND", "FINGER", "R", "THETA"].filterMap fun sl => (get sl).map (sl, ·)
      let txt := " ".intercalate (feats.map fun (sl, v) => sl ++ " " ++ v.show)
      let num := fun (sl : Slot) => match get sl with | some (.num x _) => x.toFloat32 | _ => 0
      let sym := fun (sl : Slot) => match get sl with | some (.sym x) => x | _ => ""
      match get "STYLE" with
      | some (.sym st) =>
        if st == "PUNCH" || st == "PECK" || st == "PECK-RECOIL" then
          s.sched_ 0 (mkEv "MOTOR" s!"PREPARE {st}{if txt.isEmpty then "" else " " ++ txt}"
            (.motorStyle { styleName := if st == "PUNCH" then "PUNCH" else "PECK", kind := st,
                           hand := sym "HAND", finger := sym "FINGER", r := num "R", theta := num "THETA",
                           requestTime := 0, execImm := false }))
        else { s with err := s.err.orElse fun _ => some s!"a prepare request of style {st}" }
      | _ => s
    | some (.sym "HAND-TO-MOUSE") => s.sched_ 0 (mkEv "MOTOR" "HAND-TO-MOUSE" .handToMouse)
    | some (.sym "HAND-TO-HOME") =>
      match get "HAND" with
      | some v => s.sched_ 0 (mkEv "MOTOR" s!"HAND-TO-HOME HAND {v.show}" (.handToHome (match v with | .sym "LEFT" => "LEFT" | _ => "RIGHT")))
      | none => s.sched_ 0 (mkEv "MOTOR" "HAND-TO-HOME " (.handToHome "RIGHT"))
    | some (.sym "PUNCH") =>
      match get "HAND", get "FINGER" with
      | some (.sym h), some (.sym f) =>
        s.sched_ 0 (mkEv "MOTOR" s!"PUNCH HAND {h} FINGER {f}"
          (.motorStyle { styleName := "PUNCH", kind := "PUNCH", hand := h, finger := f, requestTime := 0 }))
      | _, _ => s
    | some (.sym st) =>
      if st == "PECK" || st == "PECK-RECOIL" then
        match get "HAND", get "FINGER", get "R", get "THETA" with
        | some (.sym h), some (.sym f), some (.num r rt), some (.num t tt) =>
          s.sched_ 0 (mkEv "MOTOR" s!"{st} HAND {h} FINGER {f} R {rt} THETA {tt}"
            (.motorStyle { styleName := "PECK", kind := st, hand := h, finger := f,
                           r := r.toFloat32, theta := t.toFloat32, requestTime := 0 }))
        | _, _, _, _ => s
      else s
    | _ => s
  | .auralLocation =>
    if spec.any (·.slot == "SET-AUDLOC-DEFAULT") then
      let s := s.setAud fun a => { a with lastCmd := "SET-AUDLOC-DEFAULT" }
      s.sched_ 0 (mkEv "AUDIO" "SET-AUDLOC-DEFAULT" (.setAudlocDefault (spec.filter (·.slot != "SET-AUDLOC-DEFAULT"))))
    else
    let s := s.setAud fun a => { a with lastCmd := "FIND-SOUND" }
    s.sched_ 0 (mkEv "AUDIO" "FIND-SOUND" (.findSound spec false))
  | .aural =>
    let s := s.setAud fun a => { a with lastCmd := "SOUND" }
    match (spec.find? (·.slot == "EVENT")).bind (·.arg) with
    | some (.sym e) => s.sched_ 0 (mkEv "AUDIO" ("ATTEND-SOUND " ++ e) (.attendSound e))
    | _ => s
  | .vocal =>
    let cmd := (spec.find? (·.slot == "CMD")).bind (·.arg)
    let s := match cmd with | some (.sym c) => s.setSpc fun m => { m with lastCmd := c } | _ => s
    match cmd, (spec.find? (·.slot == "STRING")).bind (·.arg) with
    | some (.sym "SPEAK"), some (.str t) => s.sched_ 0 (mkEv "SPEECH" s!"SPEAK TEXT {t}" (.speak t false))
    | some (.sym "SUBVOCALIZE"), some (.str t) => s.sched_ 0 (mkEv "SPEECH" s!"SUBVOCALIZE TEXT {t}" (.speak t true))
    | _, _ => s
  | .blending =>
    -- `blending-request`: a pending request is aborted; the real start comes at priority
    -- -3000, after the other buffers' changes at this time
    let s := match s.blBusy with
      | some n => s.deleteEv n
      | none => s
    let (s, n) := { s with blError := false }.sched 0
      (mkEv "BLENDING" "START-BLENDING" (.startBlending spec) (-3000))
    { s with blBusy := some n }

def onStartRetrieval (s : St) (spec : List ITest) : St :=
  let s := match s.stuffEv with
    | some n => { s.deleteEv n with stuffEv := none }
    | none => s
  let rr := spec.find? (·.slot == ":RECENTLY-RETRIEVED")
  let (s, recent) : St × Option Bool := match rr with
    | some ⟨.eq, _, some (.sym "RESET")⟩ => ({ s with finsts := [] }, none)
    | some t =>
      -- `remove-old-dm-finsts`
      let s := { s with finsts := s.finsts.filter fun f => s.now - f.2 ≤ s.P.finstSpanMs }
      (s, some ((t.cmp == .eq) == t.arg.isSome))
    | none => (s, none)
  let (r1, r2, rng, ns) := retrieve s.P s.now (sources s) s.dm spec s.rng (s.finsts.map (·.1)) recent
  let r := (r1, r2)
  let s := { s with rng := rng, dm := setNoises s.dm ns }
  let (s, n) := match r.1 with
    | some e => s.sched r.2 (mkEv "DECLARATIVE" ("RETRIEVED-CHUNK " ++ e.name) (.retrievedChunk e.name))
    | none => s.sched r.2 (mkEv "DECLARATIVE" "RETRIEVAL-FAILURE" .retrievalFailure)
  { s with dmBusy := some n }

/-- `check-declarative-stuffing`: the chunk of declarative memory with the highest activation
(computed for every chunk, in `chunkOrder`, with an empty request; with `:esc nil` every
chunk) goes to the retrieval buffer after its latency, if it reaches `:rt`; otherwise another
attempt `:declarative-stuffing` later. Equals: one at random with `:er`, else the first name. -/
def St.checkStuff (s : St) : St :=
  let P := s.P
  let all := chunkOrder s.dm
  let (best, bestVal, rng, ns) : List DMEntry × Option Float32 × MT × List (String × Float32) :=
    if !P.esc then (all, none, s.rng, [])
    else all.foldl (fun (acc : List DMEntry × Option Float32 × MT × List (String × Float32)) e =>
      let (best, bv, rng, ns) := acc
      let (a, rng, pn) := activation P s.now (sources s) s.dm [] e rng
      let ns := match pn with | some n => (e.name, n) :: ns | none => ns
      match bv with
      | none => ([e], some a, rng, ns)
      | some v => if a == v then (e :: best, bv, rng, ns)
                  else if a > v then ([e], some a, rng, ns) else (best, bv, rng, ns)) ([], none, s.rng, [])
  let s := { s with rng := rng, dm := setNoises s.dm ns }
  let (pick, s) : Option DMEntry × St :=
    if best.length > 1 then
      if P.er then
        let (k, rng) := s.rng.randNat best.length
        (best[k]?, { s with rng := rng })
      else (firstByName best, s)
    else (best.head?, s)
  let fail := pick.isNone || (P.esc && bestVal.any (· < P.rt))
  let (s, n) := if fail then
      s.sched (P.stuff.getD 0) (mkEv "DECLARATIVE" "CHECK-DECLARATIVE-STUFFING" .checkStuff (maint := true))
    else
      let e := pick.get!
      s.sched (if P.esc then latency P (bestVal.getD 0) else 0)
        (mkEv "DECLARATIVE" ("STUFFING-CHUNK " ++ e.name) (.stuffChunk e.name))
  { s with stuffEv := some n }

/-! ## Blending ([Src] extras/blending/blending.lisp) -/

/-- The slot names in a list-valued request parameter (`:ignore-slots (a b)`), which the
parser keeps as a string of names. -/
def listParam (spec : List ITest) (p : String) : List String :=
  match (spec.find? (·.slot == p)).bind (·.arg) with
  | some (.str x) => (x.splitOn " ").filter (!·.isEmpty)
  | _ => []

/-- Whether a chunk fills the slots a request needs filled and leaves empty the ones it
needs empty ([Src] `slots-vector-match-signature` with `chunk-spec-filled-slots` and
`chunk-spec-empty-slots`). -/
def fitsSignature (spec : List ITest) (c : Chunk) : Bool :=
  spec.all fun t => match t.cmp, t.arg with
    | .eq, none => (c.get t.slot).isNone
    | .ne, some _ => true
    | _, _ => (c.get t.slot).isSome

/-- `start-blending`: the chunks of declarative memory that match the request (all tests
without partial matching; with `:esc` and `:mp` only the relational tests), their
activations as for a retrieval (noise drawn in that order), and from them a blended chunk:
the request's `=` values (unless `:blend-all-slots`) and for each other slot of the matching
chunks, outside `:ignore-slots`, a value blended over the chunks with recall probabilities
`P_i = e^(A_i/t) / Σ_j e^(A_j/t)`, `t` = `:tmp` or `√2 · :ans`: numbers by the weighted
average, other values by the candidate minimizing `Σ_i P_i · Sim(v, v_i)²`. The candidates
are the declarative chunks that fill the slots all the values fill when the values are
chunks (unless the slot is in `:do-not-generalize`), else the distinct values. The blended
chunk's activation is `ln Σ_i e^(A_i)`; it arrives after the retrieval latency of that
activation if it reaches `:rt`, otherwise a failure arrives after the latency of `:rt`.
NOT MODELED: `:value->mag`, `:mag->value`, `:min-bl` and the hooks (rejected by the parser),
and the blending trace `:blt`. -/
def St.startBlending (s : St) (spec0 : List ITest) : St := Id.run do
  let P := s.P
  let ignore := listParam spec0 ":IGNORE-SLOTS"
  let dontGen := listParam spec0 ":DO-NOT-GENERALIZE"
  let spec := spec0.filter (!·.slot.startsWith ":")
  let fixed := spec.filter (·.cmp == .eq)
  let chunkList := (chunkOrder s.dm).filter fun e => fitsSignature spec e.chunk
  -- `find-matching-chunks` returns the matches in reverse order
  let matching :=
    if !(P.esc && P.mp.isSome) then (chunkList.filter fun e => spec.all (·.holds e.chunk)).reverse
    else
      let extra := spec.filter fun t => t.cmp != .eq && t.cmp != .ne
      if extra.isEmpty then chunkList
      else (chunkList.filter fun e => extra.all (·.holds e.chunk)).reverse
  -- activations, in the order of `matching`
  let mut rng := s.rng
  let mut acts : List (Float32 × DMEntry) := []
  let mut ns : List (String × Float32) := []
  for e in matching do
    let (a, r, pn) := activation P s.now (sources s) s.dm spec e rng
    rng := r
    if let some n := pn then ns := (e.name, n) :: ns
    acts := acts ++ [(a, e)]
  let s := { s with rng := rng, dm := setNoises s.dm ns }
  if acts.isEmpty then
    let (s, n) := s.sched (latency P P.rt) (mkEv "BLENDING" "BLENDING-FAILURE" .blendingFailure)
    return { s with blBusy := some n }
  let temp := match P.tmp with
    | some t => t
    | none => match P.ans with
      | some a => f32 (Float.sqrt 2.0) * a
      | none => f32 1.0
  let maxA := acts.foldl (fun m x => if x.1 > m then x.1 else m) acts.head!.1
  let ws := acts.map fun x => (exp32 ((x.1 - maxA) / temp), x.2)
  let sum := ws.foldl (fun t x => t + x.1) (f32 0.0)
  let probs := ws.map fun x => (x.1 / sum, x.2)
  -- the slots of the matching chunks in the order slots are defined, which only changes
  -- the order of the blended chunk's slots
  let allSlots := (matching.flatMap fun e => e.chunk.slots.map (·.1)).eraseDups
  let fixedNames := fixed.map (·.slot)
  let blended := (if P.blendAll then allSlots else allSlots.filter (!fixedNames.contains ·)).filter
    (!ignore.contains ·)
  let mut result : List ITest := if P.blendAll then [] else fixed
  for slot in blended do
    let poss := probs.filterMap fun x => (x.2.chunk.get slot).map fun v => (x.1, v)
    if poss.isEmpty then continue
    if poss.all (fun x => match x.2 with | .num _ _ => true | _ => false) then
      let v := poss.foldl (fun acc x => match x.2 with
        | .num m _ => acc + m.toFloat32 * x.1
        | _ => acc) (f32 0.0)
      result := result ++ [⟨.eq, slot, some (Val.ofF32 v)⟩]
    else
      let isChunk := fun (v : Val) => match v with
        | .sym n => n != "T" && (s.findChunk n).isSome
        | _ => false
      let cands : List Val :=
        if poss.all (isChunk ·.2) && !dontGen.contains slot then
          -- the slots every value's chunk fills
          let common := poss.foldl (fun (acc : Option (List String)) x =>
            let sl := match x.2 with
              | .sym n => ((s.findChunk n).map fun c => c.slots.map (·.1)).getD []
              | _ => []
            match acc with
            | none => some sl
            | some a => some (a.filter sl.contains)) none |>.getD []
          (chunkOrder s.dm).filterMap fun e =>
            if common.all (fun sl => (e.chunk.get sl).isSome) then some (Val.sym e.name) else none
        else removeDupsLast (fun a b => Chunk.Val.same a b) (poss.map (·.2))
      let best : Option Val :=
        if cands.length == 1 then cands.head?
        else (cands.foldl (fun (acc : Option (Val × Float32)) v =>
          let tot := poss.foldl (fun t x =>
            let sim := similarity P (some v) (some x.2)
            t + x.1 * (sim * sim)) (f32 0.0)
          match acc with
          | some (_, b) => if tot < b then some (v, tot) else acc
          | none => some (v, tot)) none).map (·.1)
      result := result ++ [⟨.eq, slot, best⟩]
  let act := log32 (acts.foldl (fun t x => t + exp32 x.1) (f32 0.0))
  let (s, n) :=
    if act ≥ P.rt then s.sched (latency P act) (mkEv "BLENDING" "BLENDING-COMPLETE" (.blendingComplete result))
    else s.sched (latency P P.rt) (mkEv "BLENDING" "BLENDING-FAILURE" .blendingFailure)
  return { s with blBusy := some n }

def handle (s : St) (e : Ev) : St :=
  match e.act with
  | .conflictResolution =>
    -- queries of `attended` update the visicon's new and finst markers first
    let s := if s.prods.any (fun p => p.lhs.any fun c => match c with
        | .query .visualLocation qs => qs.any (·.slot == "ATTENDED") | _ => false)
      then s.updateNew.checkFinsts else s
    let s := if s.P.cst then (conflictSetTrace s).foldl (fun s l => s.emit ("OUTPUT " ++ l)) s else s
    -- `:utility-hook`: called for each matching production in order
    let (s, over) : St × List (String × Float32) := match s.P.utilityHook with
      | none => (s, [])
      | some h =>
        let pm := s.P.ppm.map fun _ => fun (v w : Val) =>
          let sim := similarity s.P (some v) (some w)
          if sim > s.P.md then some sim else none
        s.prods.toList.foldl (fun (acc : St × List (String × Float32)) p =>
          let (s, ov) := acc
          if s.disabled.contains p.name then acc
          else match matchCondsPM s.bufs s.qstate (p.allConds s.P.proc) pm p.lhsBinds with
            | none => acc
            | some _ =>
              -- the generator is not advanced to the call's count: in ACT-R the utility
              -- noise of each production is drawn right after its hook returns
              let rng0 := s.rng
              let (s, r) := s.callTask h [p.name]
              let s := { s with rng := rng0 }
              match r with
              | some (.num x _) => (s, (p.name, f32 x) :: ov)
              | _ => (s, ov)) (s, [])
    let (sel, rng) := selectProd s (fun n => over.lookup n)
    let s := { s with rng := rng }
    -- an expression of a condition that ACT-R could not evaluate
    let s := if s.err.isSome then s else
      match (s.prods.toList.filter fun p => !s.disabled.contains p.name &&
          (!p.lhsBinds.isEmpty || p.lhs.any fun c => match c with | .eval _ => true | _ => false)).findSome? fun p =>
          match matchCondsPXE s.bufs s.qstate (p.allConds s.P.proc) none p.lhsBinds with
          | .error e => some s!"{e} of production {p.name} cannot be evaluated"
          | .ok _ => none with
      | some e => { s with err := some e }
      | none => s
    match sel with
    | some (i, env) =>
      -- `warn-vision`: a selected production with a visual request locks the display
      let s := if !s.vis.visualLock && s.prods[i]!.rhs.any (fun a => match a with
          | .request .visual _ | .directRequest .visual _ => true | _ => false)
        then s.setVis fun v => { v with locks := v.locks + 1, visualLock := true } else s
      s.sched_ 0 (mkEv "PROCEDURAL" ("PRODUCTION-SELECTED " ++ s.prods[i]!.name) (.prodSelected i env)
        (isMax := true))
    | none => s.schedAfterChange crEv
  | .prodSelected i env => onSelected s i env
  | .bufferRead _ | .queryBuffer _ => s
  | .prodFired i env => onFired s i env
  | .modBuffer b sets =>
    let f : Chunk → Chunk := fun c =>
      sets.foldl (fun c (x : Slot × Option Val) => c.set x.1 (x.2.map s.trueVal)) c
    s.setBuf b fun st => { st with chunk := st.chunk.map f }
  | .moduleRequest b spec => onRequest s b (spec.map fun t => { t with arg := t.arg.map s.trueVal })
  | .directRequest b v =>
    let spec : List ITest := match v with
      | .sym n => match s.chunkNamed n with
        | some c => c.slots.map fun p => ⟨.eq, p.1, some p.2⟩
        | none => []
      | _ => []
    s.sched_ 0 (pev ("MODULE-REQUEST " ++ b.name) (.moduleRequest b spec) 50)
  | .modRequest b sets =>
    match b with
    | .imaginal =>
      -- `imaginal-mod-request`: ignored while busy
      if s.imBusy then s
      else
        let (d, s) := s.imDelay
        let s := { s with imBusy := true }
        let s := s.sched_ d (mkEv "IMAGINAL" "MOD-BUFFER-CHUNK IMAGINAL" (.modBuffer .imaginal sets))
        s.sched_ d (mkEv "IMAGINAL" "" .imaginalFree (-1) (shown := false))
    | .goal =>
      -- `goal-style-mod-request`
      s.sched_ 0 (mkEv "GOAL" "MOD-BUFFER-CHUNK GOAL" (.modBuffer .goal sets) 20)
    | .temporal =>
      -- `temporal-mod-request`
      s.sched_ 0 (mkEv "TEMPORAL" "MOD-BUFFER-CHUNK TEMPORAL" (.modBuffer .temporal sets))
    | _ => s
  | .clearBuffer b => s.clearBufS b
  | .startRetrieval spec => onStartRetrieval s spec
  | .checkStuff => s.checkStuff
  | .stuffChunk n =>
    let s := s.sched_ 0 (mkEv "DECLARATIVE" ("SET-BUFFER-CHUNK RETRIEVAL " ++ n ++ " NIL")
      (.setBufferChunk .retrieval n false) (isMax := true))
    let (s, k) := s.sched (s.P.stuff.getD 0) (mkEv "DECLARATIVE" "CHECK-DECLARATIVE-STUFFING" .checkStuff (maint := true))
    { s with stuffEv := some k }
  | .retrievedChunk n =>
    let s := { s with dmBusy := none }
    let s := s.P.retrievedHooks.foldl (fun s h => (s.callTask h [n]).1) s
    -- `update-declarative-finsts`
    let fs := (n, s.now) :: s.finsts.filter (·.1 != n)
    let s := { s with finsts := fs.take s.P.numFinsts }
    s.sched_ 0 (mkEv "DECLARATIVE" ("SET-BUFFER-CHUNK RETRIEVAL " ++ n)
      (.setBufferChunk .retrieval n true) (isMax := true))
  | .retrievalFailure =>
    let s := { s with dmBusy := none, dmFailed := true }
    let s := s.P.retrievedHooks.foldl (fun s h => (s.callTask h ["NIL"]).1) s
    if (s.bufs .retrieval).chunk.isSome then s
    else s.setBuf .retrieval fun st => { st with failure := true, requested := true }
  | .setBufferChunk b src req =>
    match s.findChunk src with
    | some c => putInBuffer s b c false req
    | none => s
  | .setBufferSpec b spec => putInBuffer s b (chunkOfSpec spec) true true
  | .overwriteBuffer b c =>
    match s.findChunk c with
    | some ch => putInBuffer s b ch false false (clear := false)
    | none => s
  | .overwriteSpec b spec =>
    if specDefOK spec then putInBuffer s b (chunkOfSpec spec) true false (clear := false) else s
  | .goalStyleRequest b spec =>
    -- `chunk-spec-to-chunk-def`: each slot once (a variable slot name may repeat one), only `=`
    if specDefOK spec then
      s.sched_ 0 (mkEv b.name ("SET-BUFFER-CHUNK-FROM-SPEC " ++ b.name) (.setBufferSpec b spec) (-1000))
    else s
  | .imaginalFree => { s with imBusy := false }
  | .temporalTick =>
    -- `next-time-tick`: counts while the buffer holds a chunk whose ticks is a number
    let s := { s with tmNext := none }
    match (s.bufs .temporal).chunk.bind (·.get "TICKS") with
    | some (.num _ _) =>
      let k := s.tmTicks + 1
      let t := s.tmTick * s.P.timeMult
      let (n, rng) := s.rng.noise (s.P.timeNoise * t)
      let t := t + n
      let t := if (1 : Float32) > t then 1 else t
      let s := { s with rng := rng, tmTicks := k, tmTick := t }
      let mods : List (Slot × Option Val) := [("TICKS", some (Val.ofInt k))]
      let s := if s.P.recordTicks
        then s.sched_ 0 (mkEv "TEMPORAL" "MODULE-MOD-REQUEST TEMPORAL" (.modRequest .temporal mods))
        else s.sched_ 0 (mkEv "TEMPORAL" "MOD-BUFFER-CHUNK TEMPORAL" (.modBuffer .temporal mods))
      let (s, e) := s.sched (roundEven t).toNat
        (mkEv "TEMPORAL" s!"Incrementing time ticks to {k + 1}" .temporalTick (isMin := true))
      { s with tmNext := some e }
    | _ => s
  | .imaginalError =>
    let s := { s with imError := true }
    (s.setBuf .imaginal fun st => { st with failure := true }).setBuf .imaginalAction fun st => { st with failure := true }
  | .startBlending spec => s.startBlending spec
  | .blendingComplete spec =>
    { s with blBusy := none }.sched_ 0
      (mkEv "BLENDING" "SET-BUFFER-CHUNK-FROM-SPEC BLENDING" (.setBufferSpec .blending spec) (-1000))
  | .blendingFailure =>
    let s := { s with blBusy := none, blError := true }
    if (s.bufs .blending).chunk.isNone then s.setBuf .blending fun st => { st with failure := true, requested := true }
    else s
  | .triggerReward r txt =>
    s.sched_ 0 (mkEv "UTILITY" ("PROPAGATE-REWARD " ++ txt) (.propagateReward r) (isMax := true))
  | .propagateReward r => propagateReward s r
  | .stop => { s with stopped := true }
  | .task action params => (s.callTask action params).1
  | .noop | .visiconUpdate => s
  | .procDisplay =>
    if s.vis.locks == 0 then
      (s.setVis fun v => { v with procScheduled := false, blocked := false }).processDisplay
    else s.setVis fun v => { v with blocked := true }
  | .findLocation spec => s.findLocation spec
  | .moveAttention loc scale => s.moveAttention loc scale
  | .encodingComplete loc clof req => s.encodingComplete loc clof req
  | .unlockVision => s.unlockVision
  | .visExecBusy => s.setVis fun v => { v with exec := true }
  | .visAutoAttend =>
    match (s.bufs .visualLocation).chunk with
    | some c =>
      let s := s.setVis fun v => { v with exec := true, proc := true }
      let s := s.sched_ 50 (mkEv "VISION" ("Move-attention " ++ c.name) (.moveAttention c.name "NIL"))
      s.sched_ 50 (mkEv "VISION" "" .visExecProcFree 1 (shown := false))
    | none => s
  | .visExecProcFree => s.setVis fun v => { v with exec := false, proc := false }
  | .unstuff entry =>
    let s := s.setVis fun v => { v with unstuffEv := none }
    if s.unstuffOk entry then
      s.sched_ 0 (mkEv "VISION" "ERASE-BUFFER VISUAL-LOCATION" (.eraseBuffer .visualLocation))
    else s
  | .eraseBuffer b => s.setBuf b fun st => { st with chunk := none, failure := false }
  | .visClear =>
    -- `clear` of a pm-module, then the vision module's `:after` method
    let s := s.setVis fun v => { v with prep := true, attended := none, marker := none, clof := none, locFailure := false, attendFailure := false, sceneChange := none }
    s.sched_ (secToMs s.MP.featPrep) (mkEv "VISION" "CHANGE-STATE LAST NONE PREP FREE PROC FREE" (.pmFree .visual))
  | .motorClear =>
    let s := s.setMot fun m => { m with prep := true, lastPrep := none, queue := [], initStamp := -100 }
    s.sched_ (secToMs s.MP.featPrep) (mkEv "MOTOR" "CHANGE-STATE LAST NONE PREP FREE PROC FREE" (.pmFree .manual))
  | .pmFree b =>
    if b == .visual then s.setVis fun v => { v with lastCmd := "NONE", prep := false, proc := false }
    else s.setMot fun m => { m with lastCmd := "NONE", prep := false, proc := false }
  | .setVislocDefault spec =>
    s.setVis fun v => { v with defaultSpec := spec.filter (·.slot != "SET-VISLOC-DEFAULT") }
  | .setAudlocDefault spec => s.setAud fun a => { a with defaultSpec := spec }
  | .motorStyle m => s.prepareMovement { m with requestTime := s.now }
  | .pressKey k =>
    match s.keyMovement k with
    -- "The hand in a press-key action is not on the keyboard"
    | some m => if s.devNext m.hand then s else s.prepareMovement m
    | none => s
  | .prepComplete =>
    let s := s.setMot fun m => { m with prep := false }
    let s := match s.mot.lastPrep with
      | some l =>
        if !l.execImm then
          -- a prepared movement waits; the processor frees once initiation would be over
          let st := s.mot.initStamp
          if st < 0 || (st > 0 && (s.now : Int) ≥ st + (secToMs s.MP.initTime : Int)) then
            s.setMot fun m => { m with proc := false }
          else s
        else
        let s := s.setMot fun m => { m with queue := m.queue ++ [l] }
        -- `update-prepared`
        match l.upd with
        | some u => s.setMot fun m => if l.hand == "LEFT" then { m with leftNext := some u } else { m with rightNext := some u }
        | none => s
      | none => s
    s.maybeExecute
  | .initComplete => s.setMot fun m => { m with proc := false }
  | .motorExecute =>
    -- `execute`: the movement last prepared, unless one is being prepared
    match s.mot.lastPrep with
    | some l =>
      if s.mot.prep then s else
      let s := s.setMot fun m => { m with queue := m.queue ++ [l] }
      let s := match l.upd with
        | some u => s.setMot fun m => if l.hand == "LEFT" then { m with leftNext := some u } else { m with rightNext := some u }
        | none => s
      s.maybeExecute
    | none => s
  | .finishMovement => (s.setMot fun m => { m with exec := false }).maybeExecute
  | .motorNotify _ loc =>
    match locKey loc.1 loc.2 with
    | some k => s.sched_ 0 (mkEv "KEYBOARD" s!"output-key {s.modelName} {k}" (.outputKey k) (maint := true))
    | none => s
  | .setHandPos h pos => s.setMot fun m => if h == "LEFT" then { m with left := pos } else { m with right := pos }
  | .moveCursor loc obj hand => s.moveCursor loc obj hand
  | .handToMouse => s.handToMouse
  | .handToHome h => s.handToHome h
  | .pointHandAtKey h k std => s.pointHandAtKey h k std
  | .setHandDevice h mouse => if h == "RIGHT" then s.setMot fun m => { m with rightOnMouse := mouse } else s
  | .clickMouse =>
    -- a punch of the right index finger, if the right hand is (or will be) on the mouse
    if s.devNext "RIGHT" && s.mot.mouse.isSome then
      s.prepareMovement { styleName := "PUNCH", kind := "PUNCH", hand := "RIGHT", finger := "INDEX", requestTime := s.now }
    else s
  | .cursorPress loc =>
    -- which finger pressed, from the finger's place relative to the mouse
    let (mx, my) := mousePos
    let f := if loc == (mx, my) then some "INDEX"
      else if loc == (mx + 1, my) then some "MIDDLE"
      else if loc == (mx + 2, my) then some "RING"
      else if loc == (mx + 3, my) then some "PINKIE"
      else if loc == (mx - 1, my + 2) then some "THUMB"
      else none
    match f, s.mot.mouse with
    | some f, some c =>
      s.sched_ 0 (mkEv "MOUSE" s!"click-mouse {s.modelName} {xyzText c} {f}" (.mouseClicked c f) (maint := true))
    | _, _ => s
  | .cursorMove loc =>
    let s := s.setMot fun m => { m with mouse := some loc }
    s.sched_ 0 (mkEv "MOUSE" s!"move-cursor {s.modelName} mouse {xyzText loc}" (.mouseMoved loc) (maint := true))
  | .mouseMoved loc =>
    s.monitors.foldl (fun s (mo : String × String) =>
      if mo.1 == "move-cursor" then (s.callTask mo.2 [s.modelName, "\"mouse\"", xyzText loc]).1 else s) s
  | .mouseClicked loc f =>
    s.monitors.foldl (fun s (mo : String × String) =>
      if mo.1 == "click-mouse" then (s.callTask mo.2 [s.modelName, xyzText loc, f]).1 else s) s
  | .newSoundShown => s
  | .stuffSound =>
    -- `stuff-sound-buffer`: an empty buffer, or with `:overstuff-aural-location` an unrequested
    -- one holding an unmodified copy or the last stuffed event's chunk
    let b := s.bufs .auralLocation
    let over := s.AP.overstuff && !b.requested && match b.chunk with
      | some c => (s.copyOf.get? c.name).isSome ||
          (match s.aud.lastStuffed.bind s.findChunk with
           | some l => c.sub l && l.sub c
           | none => false)
      | none => false
    if b.chunk.isNone || over then s.findSound s.aud.defaultSpec true else s
  | .findSound spec st => s.findSound spec st
  | .findSoundFailure st =>
    let s := s.setAud fun a => { a with locFailure := true }
    if (s.bufs .auralLocation).chunk.isNone then
      s.setBuf .auralLocation fun b => { b with failure := true, requested := !st } else s
  | .audioEventEnded en =>
    if !s.auralHolds en then s else
    match s.aud.audicon.find? (·.ename == en) with
    | some e =>
      let s := s.updateSoundEvt e
      s.sched_ 0 (mkEv "AUDIO" "MOD-BUFFER-CHUNK AURAL-LOCATION"
        (.modBuffer .auralLocation [("OFFSET", some (Val.ofInt e.offset)),
          ("DURATION", some (Val.ofF32 (nat32 (e.offset - e.onset) / f32 1000.0)))]) (isMax := true))
    | none => s
  | .attendSound c => s.attendSound c
  | .audioEncodingComplete en =>
    match s.aud.audicon.find? (·.ename == en) with
    | some e =>
      let s := s.setAud fun a => { a with exec := false, attended := some e.sname, audicon := a.audicon.map fun x => if x.ename == en then { x with attended := true } else x }
      let s := s.modChunk e.sname fun (c : Chunk) =>
        ((c.set "CONTENT" (some e.content)).set "KIND" (some (.sym e.kind))).set "EVENT" (some (.sym e.ename))
      s.sched_ 0 (mkEv "AUDIO" ("SET-BUFFER-CHUNK AURAL " ++ e.sname) (.setBufferChunk .aural e.sname true))
    | none => s
  | .attendSoundFailure =>
    let s := s.setAud fun a => { a with attendFailure := true, exec := false, attended := none }
    if (s.bufs .aural).chunk.isNone then s.setBuf .aural fun b => { b with failure := true, requested := true } else s
  | .speak t sub => s.speakPrepare { text := t, requestTime := s.now, sub := sub }
  | .speechPrepComplete =>
    let s := s.setSpc fun m => { m with prep := false }
    let s := match s.spc.lastPrep with
      | some l => s.setSpc fun m => { m with queue := m.queue ++ [l] }
      | none => s
    s.speakMaybeExecute
  | .speechInitComplete => s.setSpc fun m => { m with proc := false }
  | .speechFinish => (s.setSpc fun m => { m with exec := false }).speakMaybeExecute
  | .speechNotify t => s.sched_ 0 (mkEv "MICROPHONE" s!"output-speech {s.modelName} {t}" (.outputSpeech t))
  | .outputSpeech t =>
    s.monitors.foldl (fun s (mo : String × String) =>
      if mo.1 == "output-speech" then (s.callTask mo.2 [s.modelName, "\"" ++ t ++ "\""]).1 else s) s
  | .outputKey k =>
    s.monitors.foldl (fun s (mo : String × String) =>
      if mo.1 == "output-key" then (s.callTask mo.2 [s.modelName, "\"" ++ k ++ "\""]).1 else s) s

/-! ## Running -/

def fmtTime (ms : Nat) : String :=
  s!"{ms / 1000}.{(toString (1000 + ms % 1000)).drop 1}"

/-- `skip-unnecessary-events`: events at the head of the queue whose precondition fails
now are dropped. -/
partial def skipUnnecessary (s : St) : St :=
  match s.queue with
  | e :: q =>
    match e.act with
    | .unstuff entry => if s.unstuffOk entry then s else skipUnnecessary { s with queue := q }
    | .audioEventEnded en => if s.auralHolds en then s else skipUnnecessary { s with queue := q }
    | _ => s
  | [] => s

/-- A function on the buffers as a table, looked up in constant time instead of through
the chain of updates that built the function. -/
def lookupBuf {α : Type} [Inhabited α] (a : Array α) (b : Buf) : α :=
  match b with
  | .goal => a[0]! | .imaginal => a[1]! | .retrieval => a[2]! | .visualLocation => a[3]!
  | .visual => a[4]! | .manual => a[5]! | .vocal => a[6]! | .auralLocation => a[7]!
  | .aural => a[8]! | .blending => a[9]! | .imaginalAction => a[10]! | .temporal => a[11]!

/-- The values of a function on the buffers, in the order of `Buf.all`. -/
@[noinline] def tabArr {α : Type} (g : Buf → α) : Array α := Buf.all.toArray.map g

/-- The state with its buffer functions replaced by table lookups (no change to their
values). The tables are computed here, once: a function returning a function would be
eta-expanded by the compiler and recompute them at every lookup. -/
def St.compact (s : St) : St :=
  let a := tabArr s.bufs
  let r := tabArr s.reuse
  { s with bufs := lookupBuf a, reuse := lookupBuf r }

/-- Run events until none is left, the time limit (ms) is passed, `!stop!`, or `fuel` runs
out. An event at exactly the limit still runs ([Src] `run-sched-queue`). -/
def run (limit : Nat) (full : Bool := false) : Nat → St → St
  | 0, s => s
  | fuel + 1, s =>
    if s.stopped then s
    else
    let s := skipUnnecessary s
    match s.queue with
      | [] =>
        if full then s.emit s!"{fmtTime s.now} ------ Stopped because time limit reached"
        else s.emit s!"{fmtTime s.now} ------ Stopped because no events left to process"
      | e :: q =>
        if e.time > limit then
          let s := { s with now := limit }
          s.emit s!"{fmtTime limit} ------ Stopped because time limit reached"
        else
          let s := { s with now := e.time, queue := q, dyn := s.dyn.filter (·.1 != e.num) }
          let s := if e.shown then s.emit s!"{fmtTime e.time} {e.module} {e.details}" else s
          run limit full fuel (handle s e).compact

/-- Run at most `count` events ([Src] `run-sched-queue` with the event-count test of
`run-n-events`); returns the state and the number of events run. -/
def runCount (count : Nat) : Nat → Nat → St → St × Nat
  | 0, k, s => (s, k)
  | fuel + 1, k, s =>
    if s.stopped then (s, k)
    else
    let s := skipUnnecessary s
    match s.queue with
      | [] => (s, k)
      | e :: q =>
        if k ≥ count then (s, k)
        else
          let s := { s with now := e.time, queue := q, dyn := s.dyn.filter (·.1 != e.num) }
          let s := if e.shown then s.emit s!"{fmtTime e.time} {e.module} {e.details}" else s
          runCount count fuel (k + 1) (handle s e).compact

/-- `run-n-events` (`cond := false`), or `run-until-condition` replayed as the number of
events ACT-R ran before the condition held (`cond := true`). -/
def St.runEvents (s : St) (count : Nat) (cond : Bool) : St :=
  let s := if (s.queue ++ s.delayed).any (·.module == "PROCEDURAL") then s
           else s.schedAfterChange crEv
  let (s, k) := runCount count 5000000 0 { s with stopped := false }
  if s.stopped then s
  else if cond then
    if s.queue.isEmpty then s.emit s!"{fmtTime s.now} ------ Stopped because no events to process"
    else s.emit s!"{fmtTime s.now} ------ Stopped because condition is true"
  else if k < count then s.emit s!"{fmtTime s.now} ------ Stopped because no events to process"
  else s.emit s!"{fmtTime s.now} ------ Stopped because event limit reached"

/-- A model at time 0 ([Src] `reset-model`): declarative memory from `add-dm` (each chunk
with one reference at time 0, then `set-base-levels`), conflict resolution at time 0 with
`:min` priority, and the commands of the model definition (`goal-focus`, `schedule-event`,
…) in order. -/
def St.init (P : Params) (prods : List Production) (chunks : List Chunk) (dmNames : List String)
    (init : List TCmd) (rng : MT) (bls : List (String × Float32 × Option Int) := [])
    (cbs : List Callback := []) : St :=
  let dm := dmNames.filterMap (fun n => (chunks.find? (·.name == n)).map
              fun c => (⟨c, 0, 1, [0], none, none, 0, c.slotSig⟩ : DMEntry))
  let dm := dm.zipIdx.map fun (e, i) => { e with seq := i }
  let dm := bls.foldl (fun dm (b : String × Float32 × Option Int) => dm.map fun e =>
    if e.name != b.1 then e
    else
      let e := match b.2.2 with | some ct => { e with created := ct } | none => e
      match P.bll with
      | some _ => { e with count := (roundEven b.2.1).toNat, refs := [] }
      | none => { e with bl := some b.2.1 }) dm
  let s : St := { P := P, prods := prods.toArray, chunks := Std.HashMap.ofList (chunks.map fun c => (c.name, c)), rng := rng, dm := dm,
                  copies := copyBuffers prods, cbs := cbs }
  let s := chunks.foldl St.noteRefs s
  let s := dm.foldl (fun s e => s.idxAdd e.chunk.contentKey e.seq e.name) s
  -- `central-parameters-reset`: the hidden `check-for-esc-nil` event
  let s := s.sched_ 0 (mkEv "NONE" "CHECK-FOR-ESC-NIL" .noop (shown := false) (isMax := true) (maint := true))
  -- `tertiary-reset-dm-module`: a first stuffing attempt
  let s := if P.stuff.isSome then
      let (s, n) := s.sched 0 (mkEv "DECLARATIVE" "CHECK-DECLARATIVE-STUFFING" .checkStuff (maint := true))
      { s with stuffEv := some n }
    else s
  let s := s.sched_ 0 { crEv with isMin := true }
  init.foldl St.applyCmd s

/-- `run` for `dt` ms from now ([Src] `run`, `procedural-run-check`): conflict resolution is
added to wait for the next change when no procedural event is pending. -/
def St.runFor (s : St) (dt : Nat) : St :=
  let s := if (s.queue ++ s.delayed).any (·.module == "PROCEDURAL") then s
           else s.schedAfterChange crEv
  run (s.now + dt) false 5000000 { s with stopped := false }

/-- `run-full-time` ([Src] scheduling.lisp): a hidden maintenance event at the end time
makes the run last the whole time. -/
def St.runFull (s : St) (dt : Nat) : St :=
  let s := if (s.queue ++ s.delayed).any (·.module == "PROCEDURAL") then s
           else s.schedAfterChange crEv
  let s := s.sched_ dt (mkEv "NONE" "" .noop (shown := false) (isMin := true) (maint := true))
  run (s.now + dt) true 5000000 { s with stopped := false }

/-! ## Properties -/

/-- Clearing empties the buffer. -/
theorem clearBuf_empty (s : St) (b : Buf) : ((clearBuf' s b).bufs b).chunk = none := by
  unfold clearBuf'
  split
  · rename_i h; simp [St.setBuf, upd_same, h]
  · simp only
    split
    · simp only [St.mergeName]; split <;> simp [St.setBuf, upd_same]
    · split <;> simp [St.storeNoise_bufs, St.putChunk_bufs, St.newName_bufs, St.setBuf, upd_same]

/-- Clearing leaves the other buffers holding the chunks they held (a merge may rename a
slot value inside them). -/
theorem clearBuf_other (s : St) (b b' : Buf) (h : b' ≠ b) :
    ((clearBuf' s b).bufs b').chunk.map (·.name) = (s.bufs b').chunk.map (·.name) := by
  unfold clearBuf'
  split
  · simp [St.setBuf, upd_other _ _ _ h]
  · simp only
    split
    · simp only [St.mergeName]; split
      · simp [St.setBuf, upd_other _ _ _ h]
      · simp [St.setBuf, upd_other _ _ _ h, Chunk.renameRef, Option.map_map, Function.comp_def]
    · split <;> simp [St.storeNoise_bufs, St.putChunk_bufs, St.newName_bufs, St.setBuf, upd_other _ _ _ h]

/-- **Productions cannot see declarative memory.** Conflict resolution gives the same result
in two states that agree on the productions, the buffers and the module states, whatever
declarative memory and the event queue hold. -/
theorem selectProd_blind (s₁ s₂ : St) (hp : s₁.prods = s₂.prods) (hb : s₁.bufs = s₂.bufs)
    (hq : s₁.dmBusy = s₂.dmBusy) (hf : s₁.dmFailed = s₂.dmFailed)
    (hi : s₁.imBusy = s₂.imBusy) (he : s₁.imError = s₂.imError) (hP : s₁.P = s₂.P)
    (hr : s₁.rng = s₂.rng) (hd : s₁.disabled = s₂.disabled)
    (hv : s₁.vis = s₂.vis) (hm : s₁.mot = s₂.mot) (hvi : s₁.vinfo = s₂.vinfo)
    (hVP : s₁.VP = s₂.VP) (hn : s₁.now = s₂.now) (ha : s₁.aud = s₂.aud) (hs : s₁.spc = s₂.spc)
    (hbb : s₁.blBusy = s₂.blBusy) (hbe : s₁.blError = s₂.blError) :
    selectProd s₁ = selectProd s₂ := by
  simp [selectProd, St.qstate, hp, hb, hq, hf, hi, he, hP, hr, hd, hv, hm, hvi, hVP, hn, ha, hs, hbb, hbe]

/-- **A retrieval request does not change declarative memory**: the request and the start of
a retrieval only schedule events; chunks and references are added only when a buffer is
cleared. -/
theorem request_dm (s : St) (spec : List ITest) : (onRequest s .retrieval spec).dm = s.dm := by
  simp only [onRequest]
  split <;> simp [St.sched_dm, St.deleteEv]

end ACTR
