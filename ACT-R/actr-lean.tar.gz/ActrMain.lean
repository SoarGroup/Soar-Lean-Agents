import ACTR.Parse
/-!
# `actr-lean`: run ACT-R model files on the Lean specification

`actr-lean LIMIT file...` runs each model for at most LIMIT seconds and prints the
high-detail trace and the final state in the format of the harness's Lisp driver
(tools/actr/driver.lisp), so the two can be compared line by line.
-/
open ACTR ACTR.Parse

def tf (b : Bool) : String := if b then "T" else "NIL"

def fmt4 (x : Float) : String :=
  let neg := x < 0
  let n := (Float.round (Float.abs x * 10000.0)).toUInt64.toNat
  let s := s!"{n / 10000}.{(toString (10000 + n % 10000)).drop 1}"
  if neg && n != 0 then "-" ++ s else s

def slotStr (c : Chunk) : List String :=
  (c.slots.map fun p => p.1 ++ "=" ++ p.2.repr).toArray.qsort (· < ·) |>.toList

def dump (s : St) : List String :=
  let dm := (s.dm.toArray.qsort (fun a b => a.name < b.name)).toList.map fun e =>
    s!"DM {e.name} {" ".intercalate (slotStr e.chunk)} | ct={e.created} n={e.count}"
  let bufs := [Buf.goal, Buf.imaginal, Buf.retrieval].map fun b =>
    let st := s.bufs b
    let q := s.qstate
    let full := st.chunk.isSome
    let slots := match st.chunk with | some c => " " ++ " ".intercalate (slotStr c) | none => ""
    s!"BUF {b.name} {if full then "FULL" else "EMPTY"}{slots} | free={tf (!q.busy b)} busy={tf (q.busy b)} error={tf (q.error b)} failure={tf st.failure} requested={tf ((full || st.failure) && st.requested)}"
  let us := (s.prods.qsort (fun a b => a.name < b.name)).toList.map fun p => s!"U {p.name} {fmt4 p.u.toFloat}"
  [s!"TIME {s.now}"] ++ dm ++ bufs ++ us

def runFile (limitMs : Nat) (f : String) : IO Unit := do
  IO.println s!"#MODEL {f}"
  let src ← IO.FS.readFile f
  match parseModel src with
  | .error e => IO.println s!"#UNSUPPORTED parse error: {e}"; IO.println "#END"
  | .ok m =>
    let callsTask := m.init.any (fun c => match c with | .sched .. | .call .. => true | _ => false) ||
      m.P.utilityHook.isSome || !m.P.cycleHooks.isEmpty || !m.P.retrievedHooks.isEmpty ||
      m.prods.any fun p => p.rhs.any fun a => match a with
        | .eval (.cmd _ _) | .bind _ (.cmd _ _) => true | _ => false
    if !m.unsupported.isEmpty then
      IO.println s!"#UNSUPPORTED {"; ".intercalate m.unsupported.eraseDups}"
      IO.println "#END"
    else if m.P.simHook.isSome then
      IO.println "#UNSUPPORTED sgp :sim-hook (its results come from a task recorded with tools/actr/taskdiff.py)"
      IO.println "#END"
    else if callsTask then
      IO.println "#UNSUPPORTED the model calls its task code: compare it with tools/actr/taskdiff.py"
      IO.println "#END"
    else
      let s := m.toSt (MT.seeded m.P.seed.1 m.P.seed.2)
      let s := run limitMs false 2000000 s
      for l in s.out.reverse do IO.println l
      if let some e := s.err then IO.println s!"#UNSUPPORTED at run time: {e}"
      IO.println "#STATE"
      for l in dump s do IO.println l
      IO.println "#END"

/-! ## Replaying tasks -/

/-- A step of a recorded task, with the calls of task commands made while ACT-R carried it
out. -/
inductive Entry where
  | echo (l : String)
  | load (l path : String) (cbs : List Callback)
  | reset (l : String) (cbs : List Callback)
  | run (l : String) (ms : Nat) (rng : Nat) (cbs : List Callback) (full : Bool) (absEnd : Bool := false)
  /-- `run-n-events` (`cond := false`) or `run-until-condition` with the number of events ACT-R ran. -/
  | runEvents (l : String) (count : Nat) (rng : Nat) (cbs : List Callback) (cond : Bool)
  | cmd (l : String) (c : TCmd) (cbs : List Callback)
  | query (c : TCmd)
  | ret (l : String)
  | bad (msg : String)

/-- Read a `#CB` … `#ENDCB` block starting at line `i`; returns the call and the next line.
Calls nested in it are replayed as part of it. -/
partial def readCB (ls : Array String) (i : Nat) : Callback × Nat := Id.run do
  let hdr := sdrop ls[i]! 4
  let (name, args) := match hdr.splitOn " " with
    | n :: r => (n, match readAll (" ".intercalate r).toList with
        | .ok xs => xs.map sxRepr | .error _ => [])
    | [] => ("", [])
  let mut cmds : Array TCmd := #[]
  let mut j := i + 1
  while j < ls.size do
    let l := ls[j]!
    if l.startsWith "#ENDCB" then
      let rest := sdrop l 7
      let (rngTxt, resTxt) := match rest.splitOn " " with
        | r :: t => (r, " ".intercalate t)
        | [] => ("", "")
      let n := ((sdrop rngTxt 4).toNat?).getD 0
      let res := match readAll resTxt.toList with
        | .ok [x] => sxVal x
        | _ => none
      return ({ name := name, args := args, cmds := cmds.toList, rng := n, result := res }, j + 1)
    else if l.startsWith "#CB " then
      let (cb, k) := readCB ls j
      cmds := (cmds.push (.echo ls[j]!) ++ cb.cmds.toArray).push (.echo "#ENDCB")
      j := k
    else if l.startsWith "#CMD " then
      match parseTCmd (sdrop l 5) with
      | .ok c => cmds := cmds.push c
      | .error _ => pure ()
      j := j + 1
    else if l.startsWith "#RNG " then
      cmds := cmds.push (.rngSync (((sdrop l 5).trimAscii.toString.toNat?).getD 0))
      j := j + 1
    else if l.startsWith "#Q " then
      cmds := cmds.push (parseQuery l (sdrop l 3))
      j := j + 1
    else j := j + 1
  return ({ name := name, args := args, cmds := cmds.toList, rng := 0, result := none }, j)

/-- The calls recorded from line `i` on, up to the next step (or, inside a run, up to
`#ENDRUN`). -/
partial def readCBs (ls : Array String) (i : Nat) (inRun : Bool) : List Callback × Nat := Id.run do
  let mut cbs : Array Callback := #[]
  let mut j := i
  while j < ls.size do
    let l := ls[j]!
    if l.startsWith "#CB " then
      let (cb, k) := readCB ls j
      cbs := cbs.push cb
      j := k
    else if inRun then
      if l.startsWith "#ENDRUN" then return (cbs.toList, j + 1)
      j := j + 1
    else if l.startsWith "#" then return (cbs.toList, j)
    else j := j + 1
  return (cbs.toList, j)

partial def readEntries (ls : Array String) : List Entry := Id.run do
  let mut es : Array Entry := #[]
  let mut i := 0
  while i < ls.size do
    let l := ls[i]!
    if l.startsWith "#TASK" || l.startsWith "#END" && !l.startsWith "#ENDRUN" && !l.startsWith "#ENDCB"
        || l.startsWith "#ERROR" then
      es := es.push (.echo l); i := i + 1
    else if l.startsWith "#LOAD " then
      let (cbs, j) := readCBs ls (i + 1) false
      es := es.push (.load l (sdrop l 6).trimAscii.toString cbs); i := j
    else if l == "#CMD RESET" then
      let (cbs, j) := readCBs ls (i + 1) false
      es := es.push (.reset l cbs); i := j
    else if l.startsWith "#CMD RUN-EVENTS " || l.startsWith "#CMD RUN-COND " then
      let cond := l.startsWith "#CMD RUN-COND "
      let (cbs, j) := readCBs ls (i + 1) true
      let ws := (sdrop l (if cond then 14 else 16)).splitOn " "
      let n := match ws with | [_, r] => ((sdrop r 4).toNat?).getD 0 | _ => 0
      let count := if cond then
          ((ls.extract (i + 1) j).toList.find? (·.startsWith "#EVENTS ")).bind (fun x => (sdrop x 8).trimAscii.toString.toNat?) |>.getD 0
        else match ws with | c :: _ => c.toNat?.getD 0 | [] => 0
      es := es.push (.runEvents l count n cbs cond)
      es := es.push (.echo "#ENDRUN"); i := j
    else if l.startsWith "#CMD RUN " || l.startsWith "#CMD RUN-FULL " || l.startsWith "#CMD RUN-UNTIL " then
      let absEnd := l.startsWith "#CMD RUN-UNTIL "
      let full := l.startsWith "#CMD RUN-FULL " || absEnd
      let (cbs, j) := readCBs ls (i + 1) true
      let ws := (sdrop l (if absEnd then 15 else if full then 14 else 9)).splitOn " "
      let secs := match ws with | t :: _ => (Parse.parseNum t) | [] => none
      let ms := match secs with | some (.num x _) => secMs x | _ => 0
      let n := match ws with | [_, r] => ((sdrop r 4).toNat?).getD 0 | _ => 0
      es := es.push (.run l ms n cbs full absEnd)
      es := es.push (.echo "#ENDRUN"); i := j
    else if l.startsWith "#CMD " then
      match parseTCmd (sdrop l 5) with
      | .ok c =>
        let (cbs, j) := readCBs ls (i + 1) false
        es := es.push (.cmd l c cbs); i := j
      | .error e => es := es.push (.bad s!"{e}"); i := i + 1
    else if l.startsWith "#Q " then
      es := es.push (.query (parseQuery l (sdrop l 3))); i := i + 1
    else if l.startsWith "#RNG " then
      es := es.push (.query (.rngSync (((sdrop l 5).trimAscii.toString.toNat?).getD 0))); i := i + 1
    else if l.startsWith "#RET" then
      es := es.push (.ret l); i := i + 1
    else if l.startsWith "#CB " then
      let (cbs, j) := readCBs ls i false
      es := es.push (.cmd "" (.penable []) cbs); i := j
    else i := i + 1
  return es.toList

/-- Calls the Lean model did not make itself are the task's own: replay them in order. -/
partial def leftovers (s : St) : St :=
  match s.cbs with
  | cb :: _ => leftovers (s.callTask cb.name cb.args).1
  | [] => s

def flush (s : St) : IO St := do
  for o in s.out.reverse do IO.println o
  if let some e := s.err then IO.println s!"#UNSUPPORTED at run time: {e}"
  return { s with out := [], err := none }

/-- Replay a task recorded by tools/actr/task.lisp: the same model, the same commands from
the task code, the same draws of the random-number generator by task code, and the same
calls of task commands by the model. -/
def runScript (file : String) : IO Unit := do
  let ls := ((← IO.FS.readFile file).splitOn "\n").toArray
  -- a command the replay does not model, anywhere in the recording
  if let some l := ls.find? (·.startsWith "#CMD UNSUPPORTED") then
    IO.println s!"#UNSUPPORTED task command {sdrop l 17}"
    return
  -- the results of the model's `:sim-hook` as ACT-R called it (`#SIM name args => result`)
  let sims : List (List String × Option Val) := ls.toList.filterMap fun l =>
    if l.startsWith "#SIM " then
      match (sdrop l 5).splitOn " => " with
      | [call, res] => match readAll call.toList, readAll res.toList with
        | .ok xs, .ok [r] => some (xs.map sxRepr, sxVal r)
        | _, _ => none
      | _ => none
    else none
  let simTable := fun (hook : Option String) => match hook with
    | some h => sims.filterMap fun (call, res) => match call with
      | [n, a, b] => if n.toLower == h then some ((a, b), res.bind fun v => match v with
          | .num x _ => some (f32 x) | _ => none) else none
      | _ => none
    | none => []
  let dropHook := fun (m : Model) (cbs : List Callback) => match m.P.simHook with
    | some h => cbs.filter (·.name != h)
    | none => cbs
  let mut model : Model := {}
  let mut st : St := {}
  let mut start := 0
  for e in readEntries ls do
    match e with
    | .echo l => IO.println l
    | .bad msg => IO.println s!"#UNSUPPORTED {msg}"; return
    | .load l path cbs =>
      IO.println l
      match parseModel (← IO.FS.readFile path) with
      | .error e => IO.println s!"#UNSUPPORTED parse error: {e}"; return
      | .ok m =>
        if !m.unsupported.isEmpty then
          IO.println s!"#UNSUPPORTED {"; ".intercalate m.unsupported.eraseDups}"; return
        let m := { m with P := { m.P with simTable := simTable m.P.simHook } }
        model := m
        st := leftovers (m.toSt (MT.seeded m.P.seed.1 m.P.seed.2) (dropHook m cbs))
        st ← flush st
    | .reset l cbs =>
      IO.println l
      -- command monitors belong to the dispatcher, not the model: they survive a reset
      st := leftovers { model.toSt st.rng (dropHook model cbs) with monitors := st.monitors }
      st ← flush st
    | .cmd l c cbs =>
      if !l.isEmpty then IO.println l
      st := leftovers ({ st with cbs := dropHook model cbs }.applyCmd c)
      st ← flush st
    | .query c => st := st.applyCmd c; st ← flush st
    | .run l ms n cbs full absEnd =>
      IO.println l
      start := st.now
      -- `run-until-time`: up to an absolute time, or nothing when it has passed
      if absEnd && ms ≤ st.now then
        IO.println s!"{fmtTime st.now} ------ Stopped because end time already passed"
        continue
      let ms := if absEnd then ms - st.now else ms
      if st.rng.count > n then IO.eprintln s!"#DBG rng {st.rng.count} > {n}"
      st := { st with rng := st.rng.advanceTo n, cbs := dropHook model cbs }
      st := leftovers (if full then st.runFull ms else st.runFor ms)
      st ← flush st
    | .runEvents l count n cbs cond =>
      IO.println l
      start := st.now
      if st.rng.count > n then IO.eprintln s!"#DBG rng {st.rng.count} > {n}"
      st := { st with rng := st.rng.advanceTo n, cbs := dropHook model cbs }
      st := leftovers (st.runEvents count cond)
      st ← flush st
    | .ret _ => IO.println s!"#RET {f32Text (nat32 (st.now - start) / f32 1000.0)}"

def main (args : List String) : IO Unit := do
  match args with
  | ["--script", f] => runScript f
  | lim :: files =>
    let secs := match Parse.parseNum lim with | some (.num x _) => x | _ => 10.0
    let ms := (Float.round (secs * 1000.0)).toUInt64.toNat
    for f in files do runFile ms f
  | [] => IO.println "usage: actr-lean LIMIT-SECONDS model.lisp ..."
