#!/usr/bin/env python3
"""Compare ACT-R (SBCL) and actr-lean on ACT-R model files.

usage: diff.py [--limit SECONDS] [--verbose] files-or-directories...

Each model runs in both; the high-detail trace, the !output! lines and the final state
(declarative memory, buffers, utilities) are compared. Models the Lean side reports as
unsupported are counted separately.
"""
import os, re, subprocess, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))
LEAN = os.environ.get("ACTR_LEAN", os.path.join(ROOT, ".lake/build/bin/actr-lean"))
# ACT-R indents its trace lines; actr-lean does not, and prints model output as OUTPUT lines
TRACE = re.compile(r"^\s+(\d+\.\d{3})\s+(\S+)\s+(.*?)\s*$")
TRACE_LEAN = re.compile(r"^(\d+\.\d{3}) (\S+) (.*?)\s*$")
NUM = re.compile(r"^-?(\d+\.?\d*|\.\d+)([eEdD][-+]?\d+)?$")

def norm_tok(t):
    if NUM.match(t):
        try:
            x = float(t.replace("d", "e").replace("D", "e"))
            return ("%.6g" % x)
        except ValueError:
            pass
    return t

def norm(line):
    return " ".join(norm_tok(t) for t in line.split())

def split_models(text):
    out, cur, name = {}, None, None
    for line in text.splitlines():
        if line.startswith("#MODEL "):
            name, cur = line[7:].strip(), []
        elif line.startswith("#END") and name is not None:
            out[name] = cur; name = cur = None
        elif cur is not None:
            cur.append(line)
    return out

def strip_warnings(lines):
    res, inw = [], False
    for l in lines:
        if not inw and l.lstrip().startswith("#|Warning"):
            inw = not l.rstrip().endswith("|#")
            continue
        if inw:
            if l.rstrip().endswith("|#"): inw = False
            continue
        res.append(l)
    return res

def canon(lines, lisp):
    if lisp: lines = strip_warnings(lines)
    trace, state, unsup, err = [], [], None, None
    instate = False
    for l in lines:
        if l.startswith("#UNSUPPORTED"): unsup = l[13:]; continue
        if l.startswith("#PCT"): continue
        if l.startswith("#ERROR"): err = l; continue
        if l.startswith("#STATE"): instate = True; continue
        if instate: state.append(norm(l)); continue
        if not l.strip(): continue
        m = (TRACE if lisp else TRACE_LEAN).match(l)
        if m:
            trace.append(norm("%s %s %s" % m.groups()))
        elif lisp:
            trace.append("OUTPUT " + norm(l))
        elif l.startswith("OUTPUT "):
            trace.append(norm(l))
        else:
            trace.append(norm(l))
    return trace, state, unsup, err

def first_diff(a, b):
    for i in range(max(len(a), len(b))):
        x = a[i] if i < len(a) else "<none>"
        y = b[i] if i < len(b) else "<none>"
        if x != y: return i, x, y
    return None

def main():
    args = sys.argv[1:]
    limit, verbose = "10", False
    while args and args[0].startswith("--"):
        if args[0] == "--limit": limit = args[1]; args = args[2:]
        elif args[0] == "--verbose": verbose = True; args = args[1:]
        else: sys.exit("unknown option " + args[0])
    files = []
    for a in args:
        if os.path.isdir(a):
            files += sorted(os.path.join(a, f) for f in os.listdir(a) if f.endswith(".lisp"))
        else: files.append(a)
    if os.environ.get("ONLY"):
        files = [f for f in files if os.environ["ONLY"] in f]
    lean = split_models(subprocess.run([LEAN, limit] + files, capture_output=True, text=True).stdout)
    run = [f for f in files if f in lean and not any(l.startswith("#UNSUPPORTED") for l in lean[f])]
    lisp = {}
    if run:
        p = subprocess.run(["sbcl", "--script", os.path.join(HERE, "driver.lisp"), limit] + run,
                           capture_output=True, text=True)
        lisp = split_models(p.stdout)
    same = diff = unsup = 0
    for f in files:
        lt, ls, lu, _ = canon(lean.get(f, []), False)
        if lu is not None or f not in lean:
            unsup += 1
            if verbose: print("UNSUPPORTED %s: %s" % (f, lu))
            continue
        at, ast, _, aerr = canon(lisp.get(f, []), True)
        if aerr:
            diff += 1; print("ACT-R ERROR %s: %s" % (f, aerr)); continue
        d1 = first_diff(at, lt)
        d2 = first_diff(ast, ls)
        if d1 is None and d2 is None:
            same += 1
            if verbose: print("same      %s (%d trace lines)" % (f, len(at)))
        else:
            diff += 1
            print("DIFFERENT %s" % f)
            if d1: print("  trace line %d\n    ACT-R: %s\n    Lean:  %s" % d1)
            elif d2: print("  final state line %d\n    ACT-R: %s\n    Lean:  %s" % d2)
    print("== %d same, %d different, %d unsupported (of %d)" % (same, diff, unsup, len(files)))
    sys.exit(1 if diff else 0)

if __name__ == "__main__":
    main()
