;;; ACT-R side of the harness. Usage:
;;;   sbcl --script driver.lisp LIMIT model1.lisp model2.lisp ...
;;; For each model: load it, force the high-detail trace, run for LIMIT seconds,
;;; then print the final state between #STATE and #END lines.
(setf *load-verbose* nil *compile-verbose* nil)
(load (concatenate (quote string) (or (sb-ext:posix-getenv "ACTR_HOME") "/home/claude/actr-dl/actr") "/load-single-threaded-act-r.lisp"))
(format t "~&#READY~%")

;; Production compilation's own trace (:pct) is marked #PCT and not compared.
(defvar *in-compile* nil)
(defun pct-lines (string)
  (with-input-from-string (in string)
    (loop for l = (read-line in nil) while l do (format t "~&#PCT ~a~%" l))))
(sb-int:encapsulate 'compile-productions 'harness-log
  (lambda (f p) (let ((*in-compile* t)) (funcall f p))))
(sb-int:encapsulate 'model-output-internal 'harness-log
  (lambda (f string) (if *in-compile* (pct-lines string) (funcall f string))))
(sb-int:encapsulate 'print-production 'harness-log
  (lambda (f &rest args)
    (if *in-compile*
        (pct-lines (with-output-to-string (*standard-output*) (apply f args)))
        (apply f args))))
(sb-int:encapsulate 'spp-fct 'harness-log
  (lambda (f &rest args) (if *in-compile* nil (apply f args))))

(defun val->string (v)
  (cond ((null v) "NIL")
        ((stringp v) (format nil "~s" v))
        ((numberp v) (format nil "~a" v))
        (t (format nil "~a" v))))

(defun dump-state ()
  (format t "~&#STATE~%")
  (format t "TIME ~d~%" (mp-time-ms))
  (dolist (c (sort (mapcar #'symbol-name (no-output (dm))) #'string<))
    (let* ((c (intern c))
           (slots (sort (mapcar (lambda (s) (format nil "~a=~a" s (val->string (fast-chunk-slot-value-fct c s))))
                                (chunk-filled-slots-list-fct c)) #'string<))
           (p (car (no-output (sdp-fct (list c :creation-time :reference-count))))))
      (format t "DM ~a ~{~a~^ ~} | ct=~d n=~d~%" c slots (round (* 1000 (first p))) (second p))))
  (dolist (b '(goal imaginal retrieval))
    (let ((c (buffer-read b)))
      (format t "BUF ~a ~a~{ ~a~} | free=~a busy=~a error=~a failure=~a requested=~a~%" b
              (if c "FULL" "EMPTY")
              (when c (sort (mapcar (lambda (s) (format nil "~a=~a" s (val->string (fast-chunk-slot-value-fct c s))))
                                    (chunk-filled-slots-list-fct c)) #'string<))
              (query-buffer b '(state free)) (query-buffer b '(state busy)) (query-buffer b '(state error))
              (query-buffer b '(buffer failure)) (query-buffer b '(buffer requested)))))
  (dolist (p (sort (mapcar #'symbol-name (all-productions)) #'string<))
    (format t "U ~a ~,4f~%" p (caar (no-output (spp-fct (list (intern p) :u))))))
  (format t "#END~%"))

(let* ((args (cdr sb-ext:*posix-argv*))
       (limit (read-from-string (car args))))
  (dolist (f (cdr args))
    (format t "~&#MODEL ~a~%" f)
    (handler-case
        (progn
          (let ((*error-output* *standard-output*))
            (load f))
          ;; a model that sets no seed gets the one actr-lean uses by default
          (unless (search ":SEED" (string-upcase (with-open-file (in f) (let ((s (make-string (file-length in)))) (subseq s 0 (read-sequence s in))))))
            (sgp :seed (12345 0)))
          (sgp :v t :trace-detail high :act nil)
          ;; the blending module's own trace is not compared
          (when (fboundp 'start-blending) (sgp :blt nil))
          (run limit)
          (dump-state))
      (error (e) (format t "~&#ERROR ~a~%#END~%" e)))
    (finish-output)))
(sb-ext:exit)
