#!/usr/bin/env python3
"""Random ACT-R models within the subset actr-lean supports.

usage: gen.py OUTDIR COUNT [SEED]
Each model has a goal chunk with a state slot, a small declarative memory and productions
that move between states while testing and requesting the goal, imaginal and retrieval
buffers, with variables, modifiers and queries. Parameters vary per model.
"""
import os, random, sys

SLOTS = ["a", "b", "c", "d"]
SYMS = ["v1", "v2", "v3", "v4", "v5"]
NOISE = float(os.environ.get("NOISE", "0.5"))
# Probability that a model uses production compilation (:epl t). Its choices come from a
# separate generator so that models generated with EPL=0 are unchanged.
EPL = float(os.environ.get("EPL", "0"))
# Probability that a model sets permanent noise (:pas), from another separate generator.
PAS = float(os.environ.get("PAS", "0"))
# Probability of procedural partial matching (:ppm), with similarities among the symbols.
PPM = float(os.environ.get("PPM", "0"))
# Probability of :nsji t (negative Sji values kept).
NSJI = float(os.environ.get("NSJI", "0"))
# Probability that a model uses variable slot names (dynamic pattern matching), and that it
# turns on the conflict-set trace (:cst), each from its own generator.
DYN = float(os.environ.get("DYN", "0"))
CST = float(os.environ.get("CST", "0"))
# Probability of :randomize-time (with :vpft and :vidt), from its own generator.
RT = float(os.environ.get("RT", "0"))
# Probability of a utility threshold (:ut), from its own generator.
UT = float(os.environ.get("UT", "0"))
# Probability per production of a buffer overwrite (@buffer> chunk or specification).
OW = float(os.environ.get("OW", "0"))
# Probability of :declarative-stuffing.
STUFF = float(os.environ.get("STUFF", "0"))
# Probability of explicit Sji values (add-sji), with spreading activation on.
SJI = float(os.environ.get("SJI", "0"))

def val(r, allow_num=True):
    if allow_num and r.random() < 0.35:
        return str(r.randint(0, 4))
    return r.choice(SYMS)

def gen(r, idx):
    re_ = random.Random(idx * 7919 + 17)
    epl = EPL > 0 and re_.random() < EPL
    # with compilation, conditions mostly avoid modifiers (they block compilation)
    clean = lambda: epl and re_.random() < 0.8
    nstates = r.randint(3, 7)
    states = ["s%d" % i for i in range(nstates)]
    lines = ["(clear-all)", "(define-model m%d" % idx]
    params = []
    esc = r.random() < 0.8
    params.append(":esc %s" % ("t" if esc else "nil"))
    if esc:
        params.append(":lf %s" % r.choice([".05", ".1", ".2", ".4", "1.0"]))
        params.append(":rt %s" % r.choice(["-3", "-1", "-0.5", "0", "0.5"]))
        bll = r.choice([None, ".5", ".3", ".7"])
        if bll: params.append(":bll %s" % bll)
        if bll and r.random() < 0.5: params.append(":ol %s" % r.choice(["nil", "nil", "1", "2", "4"]))
        mas = r.choice([None, None, "1.0", "2.5", "4"])
        if mas:
            params.append(":mas %s" % mas)
            if r.random() < 0.4: params.append(":ga %s" % r.choice(["1.0", "0.5"]))
            if r.random() < 0.3: params.append(":imaginal-activation %s" % r.choice(["0", "2.0"]))
        if r.random() < 0.3: params.append(":blc %s" % r.choice(["0.5", "-1", "2"]))
        if r.random() < 0.3: params.append(":le %s" % r.choice(["0.5", "2"]))
        if r.random() < NOISE: params.append(":ans %s" % r.choice(["0.1", "0.25", "0.5", "1.0"]))
        if r.random() < NOISE * 0.6:
            params.append(":mp %s" % r.choice(["1.0", "2", "5"]))
            if r.random() < 0.3: params.append(":md %s" % r.choice(["-2", "-0.5"]))
            if r.random() < 0.3: params.append(":ms %s" % r.choice(["0.5", "0"]))
        if r.random() < NOISE: params.append(":egs %s" % r.choice(["0.1", "0.5", "2"]))
    if r.random() < NOISE * 0.6: params.append(":er t")
    if esc and r.random() < NOISE * 0.5:
        params.append(":ul t")
        if r.random() < 0.5: params.append(":alpha %s" % r.choice(["0.1", "0.5"]))
    if r.random() < NOISE * 0.3: params.append(":seed (%d %d)" % (r.randint(1, 99999), r.randint(0, 50)))
    elif r.random() < NOISE * 0.1: params.append(":seed (%d %d)" % (r.randint(2**32 + 1, 2**40), r.randint(0, 50)))
    if r.random() < 0.2: params.append(":declarative-num-finsts %d" % r.randint(1, 5))
    if r.random() < 0.2: params.append(":declarative-finst-span %s" % r.choice(["0.2", "1.0", "5"]))
    if r.random() < 0.3: params.append(":dat %s" % r.choice([".03", ".1"]))
    if r.random() < 0.2: params.append(":imaginal-delay %s" % r.choice([".1", ".05", "0"]))
    rp = random.Random(idx * 104729 + 3)
    rd = random.Random(idx * 15485863 + 11)
    dyn = DYN > 0 and rd.random() < DYN
    if CST > 0 and rd.random() < CST: params.append(":cst t")
    if esc and PAS > 0 and rp.random() < PAS:
        params.append(":pas %s" % rp.choice(["0.1", "0.3", "1.0"]))
    if esc and NSJI > 0 and rp.random() < NSJI:
        params.append(":nsji t :mas %s :ga 1" % rp.choice(["0.2", "0.5", "1"]))
    ppm = PPM > 0 and rp.random() < PPM
    if ppm:
        params.append(":ppm %s" % rp.choice(["1", "0.5", "3"]))
        if rp.random() < 0.3: params.append(":md %s" % rp.choice(["-0.5", "-2"]))
    rt = random.Random(idx * 32452843 + 5)
    if RT > 0 and rt.random() < RT:
        params.append(":randomize-time %s" % rt.choice(["t", "t", "2", "5", "10"]))
        if rt.random() < 0.7: params.append(":vpft t")
        if rt.random() < 0.6: params.append(":vidt t")
    rj = random.Random(idx * 86028121 + 13)
    sji_on = esc and SJI > 0 and rj.random() < SJI
    if sji_on: params.append(":mas %s :ga 1" % rj.choice(["1", "2"]))
    rs_ = random.Random(idx * 67867967 + 9)
    if STUFF > 0 and rs_.random() < STUFF:
        params.append(":declarative-stuffing %s" % rs_.choice(["0.05", "0.1", "0.5", "1"]))
    ru = random.Random(idx * 49979687 + 7)
    if UT > 0 and ru.random() < UT:
        params.append(":ut %s" % ru.choice(["0", "-0.5", "0.2", "1", "-2"]))
    if epl:
        params.append(":epl t")
        if re_.random() < 0.5: params.append(":pct t")
        if re_.random() < 0.3: params.append(":tt %s" % re_.choice(["0.1", "0.5", "5"]))
        if re_.random() < 0.3: params.append(":nu %s" % re_.choice(["1", "-2", "5"]))
        if re_.random() < 0.3: params.append(":do-not-harvest imaginal")
        if re_.random() < 0.2: params.append(":do-not-harvest retrieval")
    lines.append("(sgp %s)" % " ".join(params))
    isa = lambda: ""
    if r.random() < 0.3:
        ds = r.sample(SLOTS, r.randint(1, 2))
        lines.append("(chunk-type ctd %s)" % " ".join("(%s %s)" % (x, val(r)) if x in ds else x for x in SLOTS))
        isa = lambda: "isa ctd " if r.random() < 0.4 else ""
    dm = []
    for i in range(r.randint(2, 8)):
        slots = r.sample(SLOTS, r.randint(1, 3))
        dm.append("(c%d %s%s)" % (i, isa(), " ".join("%s %s" % (s, val(r)) for s in slots)))
    for s in SYMS: dm.append("(%s)" % s)
    if dyn:
        # chunks named like the slots, so that slot values can name slots
        for s in SLOTS: dm.append("(%s)" % s)
    gslots = " ".join("%s %s" % (s, val(r)) for s in r.sample(SLOTS, r.randint(2, 4)))
    if dyn: gslots += " ptr %s" % rd.choice(SLOTS)
    dm.append("(g state s0 %s)" % gslots)
    lines.append("(add-dm %s)" % " ".join(dm))
    if sji_on:
        names = ["c%d" % i for i in range(len(dm) - len(SYMS) - 1)] + SYMS
        lines.append("(add-sji %s)" % " ".join("(%s %s %s)" % (rj.choice(SYMS + ["c0"]), rj.choice(names), rj.choice(["1", "-0.5", "2.5", "0"])) for _ in range(rj.randint(1, 6))))
    lines.append("(goal-focus g)")
    if ppm:
        pairs = []
        for _ in range(rp.randint(2, 6)):
            a, b = rp.sample(SYMS, 2)
            pairs.append("(%s %s %s)" % (a, b, rp.choice(["-0.1", "-0.3", "-0.6", "-0.9"])))
        spairs = []
        for _ in range(rp.randint(1, 4)):
            if len(states) > 1:
                a, b = rp.sample(states, 2)
                spairs.append("(%s %s %s)" % (a, b, rp.choice(["-0.2", "-0.5", "-0.8"])))
        lines.append("(set-similarities %s)" % " ".join(pairs))
    elif r.random() < NOISE * 0.4:
        pairs = []
        for _ in range(r.randint(1, 4)):
            a, b = r.sample(SYMS, 2)
            pairs.append("(%s %s %s)" % (a, b, r.choice(["-0.1", "-0.5", "-0.9", "0"])))
        lines.append("(set-similarities %s)" % " ".join(pairs))
    plan = []
    for st in states:
        plan.append((st, True))
        for _ in range(r.randint(0, 2)): plan.append((st, False))
    for pi, (st, simple) in enumerate(plan):
        lhs = ["=goal>", "state %s" % st]
        bound = []
        for s in ([] if simple else r.sample(SLOTS, r.randint(0, 2))):
            if r.random() < 0.5:
                v = "=x%d" % len(bound); bound.append(v); lhs.append("%s %s" % (s, v))
            else:
                m_ = r.choice(["", "- "])
                lhs.append("%s%s %s" % ("" if clean() else m_, s, r.choice([val(r), "nil"])))
        dslot = None
        if dyn and not simple and rd.random() < 0.6:
            dslot = "=sn"
            lhs.append("ptr =sn")
            k = rd.random()
            if k < 0.4:
                v = "=d%d" % len(bound); bound.append(v); lhs.append("=sn %s" % v)
            elif k < 0.6:
                lhs.append("%s=sn %s" % (rd.choice(["", "- "]), rd.choice([val(rd), "nil"])))
        if not simple and r.random() < 0.5:
            lhs.append("=retrieval> " + isa())
            if dslot and rd.random() < 0.5:
                v = "=e%d" % len(bound); bound.append(v); lhs.append("=sn %s" % v)
            for s in r.sample(SLOTS, r.randint(0, 2)):
                k = r.random()
                if k < 0.5:
                    v = "=y%d" % len(bound); bound.append(v); lhs.append("%s %s" % (s, v))
                elif k < 0.7 and bound:
                    b_ = r.choice(bound)
                    lhs.append(("%s %s" if clean() else "- %s %s") % (s, b_))
                elif k < 0.85:
                    m_ = r.choice(["<", ">", "<=", ">="]); n_ = r.randint(0, 4)
                    lhs.append(("%s %s" % (s, n_)) if clean() else ("%s %s %s" % (m_, s, n_)))
                else:
                    lhs.append("%s %s" % (s, val(r)))
        elif not simple and r.random() < 0.6:
            q = r.choice(["state free", "state busy", "state error", "buffer failure",
                          "buffer empty", "buffer full", "- state busy", "buffer requested"])
            lhs.append("?retrieval> %s" % q)
        if not simple and r.random() < 0.35:
            if r.random() < 0.5:
                lhs.append("=imaginal>")
                for s in r.sample(SLOTS, r.randint(0, 1)):
                    v = "=z%d" % len(bound); bound.append(v); lhs.append("%s %s" % (s, v))
                if dslot and rd.random() < 0.5:
                    v = "=y%d" % len(bound); bound.append(v); lhs.append("=sn %s" % v)
            else:
                lhs.append("?imaginal> %s" % r.choice(["state free", "buffer empty", "buffer full", "state busy"]))
        rhs = []
        nxt = r.choice(states)
        gm = ["state %s" % nxt]
        if dyn and rd.random() < 0.3:
            gm.append("ptr %s" % rd.choice(SLOTS + ["v1"]))
        if dslot and rd.random() < 0.4:
            gm.append("=sn %s" % rd.choice(bound + [val(rd)] if bound else [val(rd)]))
        for s in r.sample(SLOTS, r.randint(0, 2)):
            gm.append("%s %s" % (s, r.choice(bound + [val(r), "nil"]) if bound else r.choice([val(r), "nil"])))
        k = r.random()
        if k < 0.08:
            rhs.append("+goal> state %s %s" % (nxt, " ".join("%s %s" % (s, r.choice(bound or [val(r)])) for s in r.sample(SLOTS, r.randint(0, 2)))))
        else:
            rhs.append(("*goal> " if r.random() < 0.1 else "=goal> ") + " ".join(gm))
        if r.random() < 0.55:
            spec = []
            for s in r.sample(SLOTS, r.randint(1, 2)):
                kk = r.random()
                if kk < 0.4 and bound: spec.append("%s %s" % (s, r.choice(bound)))
                elif kk < 0.6: spec.append("- %s %s" % (s, val(r)))
                elif kk < 0.7: spec.append("%s %s %s" % (r.choice(["<", ">"]), s, r.randint(0, 4)))
                elif kk < 0.8: spec.append("%s nil" % s)
                else: spec.append("%s %s" % (s, val(r)))
            if dslot and rd.random() < 0.4:
                spec.append("=sn %s" % rd.choice(bound + [val(rd)] if bound else [val(rd)]))
            if r.random() < 0.3:
                spec.append(r.choice([":recently-retrieved t", ":recently-retrieved nil",
                                      ":recently-retrieved reset"]))
            rhs.append("+retrieval> " + isa() + " ".join(spec))
        elif r.random() < 0.1:
            rhs.append("+retrieval> c%d" % r.randint(0, 1))
        elif r.random() < 0.15:
            rhs.append("-retrieval>")
        dsp = (" =sn %s" % rd.choice(bound or [val(rd)])) if dslot and rd.random() < 0.4 else ""
        if "=imaginal>" in lhs and r.random() < 0.3:
            rhs.append("*imaginal> " + " ".join("%s %s" % (s, r.choice(bound or [val(r)])) for s in r.sample(SLOTS, r.randint(1, 2))) + dsp)
        elif dslot and "=imaginal>" in lhs and rd.random() < 0.3:
            rhs.append("=imaginal> =sn %s" % rd.choice(bound or [val(rd)]))
        elif r.random() < 0.25:
            rhs.append("+imaginal> " + " ".join("%s %s" % (s, r.choice(bound or [val(r)])) for s in r.sample(SLOTS, r.randint(1, 2))) + dsp)
        elif r.random() < 0.1:
            rhs.append("-imaginal>")
        if bound and r.random() < 0.3:
            rhs.append("!output! (%s)" % " ".join(r.sample(bound, min(len(bound), 2))))
        if r.random() < 0.15:
            a = r.choice(bound + ["2", "3.5"]) if bound else r.choice(["2", "3.5", "-1"])
            rhs.insert(0, ("!safe-bind!" if epl and re_.random() < 0.7 else "!bind!") + " =w (%s %s %s)" % (r.choice(["+", "-", "*"]), r.choice(["1", "2.5", "4"]), r.choice(["1", "0.25", "3"])))
            rhs.append("!output! (=w)")
        if bound and r.random() < 0.1:
            lhs.append(("!safe-eval!" if epl and re_.random() < 0.7 else "!eval!") + " (%s %s '%s)" % (r.choice(["eq", "equal"]), r.choice(bound), val(r)))
        if OW > 0:
            rw = random.Random(idx * 1000003 + pi * 7 + 1)
            if rw.random() < OW:
                b = rw.choice(["imaginal", "imaginal", "retrieval", "goal"])
                k = rw.random()
                if k < 0.35:
                    rhs.append("@%s> c%d" % (b, rw.randint(0, 1)))
                elif k < 0.5 and "=retrieval>" in lhs and b != "retrieval":
                    rhs.append("@%s> =retrieval" % b)
                else:
                    sp = ["%s %s" % (x, rw.choice(bound + [val(rw)]) if bound else val(rw)) for x in rw.sample(SLOTS, rw.randint(1, 3))]
                    if b == "goal": sp.append("state %s" % rw.choice(states))
                    if rw.random() < 0.1: sp.append("newslot%d v1" % rw.randint(0, 2))
                    rhs.append("@%s> %s" % (b, " ".join(sp)))
        if r.random() < 0.06:
            rhs.append("!stop!")
        lines.append("(p p%d\n  %s\n==>\n  %s)" % (pi, "\n  ".join(lhs), "\n  ".join(rhs)))
        if r.random() < NOISE * 0.4:
            lines.append("(spp p%d :u %s)" % (pi, r.choice(["1", "2.5", "-1", "0.5"])))
        if r.random() < NOISE * 0.3:
            lines.append("(spp p%d :reward %s)" % (pi, r.choice(["10", "0", "2.5", "-5"])))
    if ppm and spairs:
        # the states exist as chunks once the productions have used them
        lines.append("(set-similarities %s)" % " ".join(spairs))
    lines.append(")")
    return "\n".join(lines) + "\n"

def main():
    out, n = sys.argv[1], int(sys.argv[2])
    seed = int(sys.argv[3]) if len(sys.argv) > 3 else 1
    os.makedirs(out, exist_ok=True)
    r = random.Random(seed)
    for i in range(n):
        with open(os.path.join(out, "g%04d.lisp" % i), "w") as f:
            f.write(gen(r, i))

if __name__ == "__main__":
    main()
