#!/usr/bin/env python3
"""Random ACT-R models that use the blending module (extras/blending).

usage: genblend.py OUTDIR COUNT [SEED]
Each model has items with a key, numeric and chunk-valued slots, chunks for the values with
similarities between them, and productions that repeatedly make blending requests with
varying specifications and use, modify, erase or clear the blended chunk.
"""
import os, random, sys

def gen(r, idx):
    L = ["(clear-all)", '(require-extra "blending")', "(define-model b%d" % idx]
    p = [":esc t", ":rt %s" % r.choice(["-2", "0", "1", "2", "3"])]
    p.append(":ans %s" % r.choice(["0.1", "0.25", "0.5"]))
    if r.random() < 0.4: p.append(":tmp %s" % r.choice(["0.5", "1", "1.5", "3"]))
    if r.random() < 0.3: p.append(":mp %s" % r.choice(["1", "2", "0.5"]))
    if r.random() < 0.2: p.append(":blend-all-slots t")
    if r.random() < 0.4: p.append(":bll 0.5")
    if r.random() < 0.3: p.append(":lf %s" % r.choice(["0.1", "0.5", "2"]))
    if r.random() < 0.2: p.append(":mas 2 :ga 1")
    if r.random() < 0.3: p.append(":ul t :egs 0.3")
    if r.random() < 0.3: p.append(":seed (%d %d)" % (r.randint(1, 9999), r.randint(0, 9)))
    L.append("(sgp %s)" % " ".join(p))
    L.append("(chunk-type item key num size color)")
    L.append("(chunk-type size (size-type t))")
    L.append("(chunk-type shade (shade-type t))")
    L.append("(chunk-type task state count)")
    sizes = ["tiny", "small", "medium", "large", "huge"]
    colors = ["sred", "sgreen", "sblue"]
    keys = ["k1", "k2", "k3"]
    dm = ["(%s isa size)" % s for s in sizes] + ["(%s isa shade)" % c for c in colors]
    dm += ["(%s)" % k for k in keys]
    items = []
    for i in range(r.randint(3, 9)):
        sl = ["key %s" % r.choice(keys)]
        if r.random() < 0.85: sl.append("num %s" % r.choice(["1", "2", "3", "4", "2.5", "-1", "10"]))
        if r.random() < 0.8: sl.append("size %s" % r.choice(sizes))
        if r.random() < 0.6: sl.append("color %s" % r.choice(colors + ['"red"', '"x"']))
        items.append("i%d" % i)
        dm.append("(i%d isa item %s)" % (i, " ".join(sl)))
    dm.append("(g isa task state s0 count 0)")
    L.append("(add-dm %s)" % " ".join(dm))
    L.append("(goal-focus g)")
    if r.random() < 0.7:
        L.append("(set-base-levels %s)" % " ".join("(%s %d %d)" % (i, r.randint(1, 6), r.choice([-10, -5, -100])) for i in items))
    sims = []
    for a in range(len(sizes)):
        for b in range(a + 1, len(sizes)):
            if r.random() < 0.7: sims.append("(%s %s %s)" % (sizes[a], sizes[b], r.choice(["-0.1", "-0.2", "-0.3", "-0.5"])))
    if r.random() < 0.5: sims.append("(sred sgreen -0.5)")
    if sims: L.append("(set-similarities %s)" % " ".join(sims))
    n = r.randint(2, 4)
    for st in range(n):
        spec = []
        k = r.random()
        if k < 0.5: spec.append("key %s" % r.choice(keys))
        elif k < 0.6: spec.append("- key %s" % r.choice(keys))
        if r.random() < 0.25: spec.append(r.choice(["< num 3", "> num 1", "<= num 2.5", ">= num 2", "- size nil", "color nil", "size %s" % r.choice(sizes)]))
        if r.random() < 0.2: spec.append(":ignore-slots (%s)" % " ".join(r.sample(["num", "size", "color"], r.randint(1, 2))))
        if r.random() < 0.2: spec.append(":do-not-generalize (%s)" % r.choice(["size", "color", "size color"]))
        L.append("(p req%d\n  =goal> state s%d\n  ?blending> state free buffer empty\n==>\n  =goal> state w%d\n  +blending> isa item %s)" % (st, st, st, " ".join(spec)))
        nxt = "s%d" % r.randrange(n)
        out = r.choice(["num", "size", "color"])
        tail = r.choice(["@blending>", "-blending>", "=blending> num nil", "", "=blending> key done"])
        L.append("(p got%d\n  =goal> state w%d\n  =blending> %s =v\n==>\n  !output! (=v)\n  =goal> state %s\n  %s)" % (st, st, out, nxt, tail))
        L.append("(p got%db\n  =goal> state w%d\n  =blending>\n==>\n  =goal> state %s\n  %s)" % (st, st, nxt, r.choice(["@blending>", "-blending>", ""])))
        L.append("(p fail%d\n  =goal> state w%d\n  ?blending> state error\n==>\n  =goal> state %s)" % (st, st, nxt))
        if r.random() < 0.3:
            L.append("(spp got%d :u %s)" % (st, r.choice(["1", "2", "-1"])))
    L.append(")")
    return "\n".join(L) + "\n"

def main():
    out, n = sys.argv[1], int(sys.argv[2])
    seed = int(sys.argv[3]) if len(sys.argv) > 3 else 1
    os.makedirs(out, exist_ok=True)
    r = random.Random(seed)
    for i in range(n):
        with open(os.path.join(out, "b%04d.lisp" % i), "w") as f:
            f.write(gen(r, i))

if __name__ == "__main__":
    main()
