#!/usr/bin/env python3
"""Random ACT-R models that evaluate Lisp expressions in productions.

usage: genlisp.py OUTDIR COUNT [SEED]
Each model steps a goal through states; each production binds variables on its left-hand
side (!bind!, !safe-bind!, !mv-bind!), may test an !eval! condition, binds more on its
right-hand side (!bind!, !mv-bind!), prints with !output! and stores a result in the goal.
The expressions use the arithmetic, comparison and predicate functions actr-lean evaluates.
"""
import os, random, sys

VARS = ["a", "b", "c"]
NUM1 = ["1+", "1-", "abs", "-", "floor", "ceiling", "round", "truncate", "sqrt", "exp", "log"]
NUM2 = ["+", "-", "*", "max", "min", "floor", "ceiling", "round", "truncate", "mod", "rem", "/", "expt", "log"]
NUMN = ["+", "*", "max", "min", "-"]
CMP = ["<", ">", "<=", ">=", "=", "/="]
PRED1 = ["zerop", "plusp", "minusp", "evenp", "oddp", "integerp", "floatp", "numberp"]

def const(r):
    k = r.random()
    if k < 0.5: return str(r.randint(-5, 12))
    if k < 0.8: return r.choice(["0.5", "2.5", "1.5", "0.1", "-1.25", "3.0", "0.25", "10.0"])
    return r.choice(["1", "2", "3", "4"])

def num(r, vs, d=0):
    if d >= 2 or r.random() < 0.3:
        return "=" + r.choice(vs) if r.random() < 0.7 else const(r)
    k = r.random()
    if k < 0.35:
        f = r.choice(NUM1)
        a = num(r, vs, d + 1)
        if f in ("sqrt", "log"): a = "(abs %s)" % a if f == "sqrt" else "(+ 1 (abs %s))" % a
        if f == "exp": a = "(min 3 %s)" % a
        return "(%s %s)" % (f, a)
    if k < 0.8:
        f = r.choice(NUM2)
        a, b = num(r, vs, d + 1), num(r, vs, d + 1)
        if f in ("floor", "ceiling", "round", "truncate", "mod", "rem", "/"):
            b = "(+ 1 (abs %s))" % b if r.random() < 0.9 else b
        if f == "expt": b = r.choice(["2", "3", "0", "-1", "0.5"]); a = "(+ 1 (abs %s))" % a if b == "0.5" else a
        if f == "log": a, b = "(+ 1 (abs %s))" % a, r.choice(["2", "10", "2.0"])
        return "(%s %s %s)" % (f, a, b)
    f = r.choice(NUMN)
    return "(%s %s)" % (f, " ".join(num(r, vs, d + 1) for _ in range(r.randint(1, 3))))

def test(r, vs):
    k = r.random()
    if k < 0.5:
        c = r.choice(CMP)
        return "(%s %s)" % (c, " ".join(num(r, vs, 1) for _ in range(r.randint(2, 3))))
    if k < 0.75:
        p = r.choice(PRED1)
        a = num(r, vs, 1)
        if p in ("evenp", "oddp"): a = "(floor %s)" % a
        return "(%s %s)" % (p, a)
    c1, c2 = test(r, vs) if r.random() < 0.3 else "(< %s 4)" % num(r, vs, 2), "(> %s -2)" % num(r, vs, 2)
    return "(%s %s %s)" % (r.choice(["and", "or"]), c1, c2)

def gen(r, idx):
    n = r.randint(2, 6)
    states = ["s%d" % i for i in range(n + 1)]
    L = ["(clear-all)", "(define-model l%d" % idx, "(sgp :esc nil :v t :trace-detail high)",
         "(chunk-type g state a b c)"]
    L.append("(define-chunks %s)" % " ".join("(%s)" % s for s in states))
    L.append("(add-dm (goal isa g state s0 a %s b %s c %s))" % (const(r), const(r), const(r)))
    for i in range(n):
        lhs = ["=goal>", "state %s" % states[i], "a =a", "b =b", "c =c"]
        vs = list(VARS)
        k = r.random()
        if k < 0.3:
            lhs.append("!bind! =x %s" % num(r, vs))
            vs.append("x")
        elif k < 0.45:
            lhs.append("!safe-bind! =x %s" % num(r, vs))
            vs.append("x")
        elif k < 0.6:
            f = r.choice(["floor", "round", "truncate", "ceiling"])
            lhs.append("!mv-bind! (=x =z) (%s %s %s)" % (f, num(r, vs), r.choice(["2", "3", "(+ 1 (abs =b))", "1.5"])))
            vs += ["x", "z"]
        elif k < 0.65:
            lhs.append("!mv-bind! (=x =z) (values %s %s)" % (num(r, vs), num(r, vs)))
            vs += ["x", "z"]
        if "x" in vs and r.random() < 0.3:
            # a slot test of a variable bound by !bind! (a test, not a binding)
            lhs.insert(5, "%s %s =x" % (r.choice(["", "-", "<", ">=", ">"]), r.choice(["a", "b", "c"])))
        if r.random() < 0.5:
            lhs.append("!eval! %s" % test(r, vs))
        rhs = []
        if r.random() < 0.6:
            rhs.append("!bind! =y %s" % num(r, vs))
            vs.append("y")
        if r.random() < 0.3:
            rhs.append("!mv-bind! (=q =w) (%s %s 2)" % (r.choice(["floor", "round"]), num(r, vs)))
            vs += ["q", "w"]
        if r.random() < 0.3:
            rhs.append("!bind! =t %s" % test(r, vs))
            vs.append("t")
        rhs.append("!output! (%s)" % " ".join("=" + v for v in vs[3:] + ["a"]))
        store = r.choice([v for v in vs if v not in ("t",)])
        rhs.append("=goal> state %s %s =%s" % (states[i + 1], r.choice(["a", "b", "c"]), store))
        L.append("(p p%d %s ==> %s)" % (i, " ".join(lhs), " ".join(rhs)))
        # an alternative that fires when the first does not
        L.append("(p q%d =goal> state %s ==> =goal> state %s)" % (i, states[i], states[i + 1]))
        L.append("(spp q%d :u -1)" % i)
    L.append("(goal-focus goal))")
    return "\n".join(L) + "\n"

def main():
    out, count = sys.argv[1], int(sys.argv[2])
    seed = int(sys.argv[3]) if len(sys.argv) > 3 else 1
    r = random.Random(seed)
    os.makedirs(out, exist_ok=True)
    for i in range(count):
        with open(os.path.join(out, "l%04d.lisp" % i), "w") as f:
            f.write(gen(r, i))

main()
