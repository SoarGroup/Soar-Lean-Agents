#!/usr/bin/env python3
"""Random models that use the temporal module (tests it).

usage: gentemp.py OUTDIR COUNT [SEED]
"""
import os, random, sys

def gen(r, idx):
    ns = r.randint(3, 6)
    states = ["s%d" % i for i in range(ns)]
    params = [":esc t", ":seed (%d %d)" % (r.randint(1, 9999), r.randint(0, 20))]
    if r.random() < 0.5: params.append(":egs %s" % r.choice(["0.1", "0.5"]))
    if r.random() < 0.3: params.append(":time-noise %s" % r.choice(["0.005", "0.05", "0.1"]))
    if r.random() < 0.3: params.append(":time-mult %s" % r.choice(["1.02", "1.2", "1.5"]))
    if r.random() < 0.3: params.append(":time-master-start-increment %s" % r.choice([".005", ".02", ".1"]))
    if r.random() < 0.3: params.append(":record-ticks nil")
    if r.random() < 0.2: params.append(":do-not-harvest imaginal")
    lines = ["(clear-all)", "(define-model t%d" % idx, "(sgp %s)" % " ".join(params),
             "(chunk-type task state n)",
             "(define-chunks (g isa task state s0 n 0) %s)" % " ".join("(%s)" % s for s in states)]
    for pi in range(r.randint(ns, 2 * ns + 2)):
        st = r.choice(states)
        lhs = ["=goal> state %s" % st]
        k = r.random()
        if k < 0.35:
            lhs.append("=temporal> %s" % r.choice(["ticks =t", "> ticks %d" % r.randint(1, 12),
                                                  "< ticks %d" % r.randint(2, 8), "ticks %d" % r.randint(0, 6), ""]))
        elif k < 0.5:
            lhs.append("?temporal> %s" % r.choice(["buffer empty", "buffer full", "state free", "- buffer full"]))
        rhs = ["=goal> state %s" % r.choice(states)]
        k = r.random()
        if k < 0.3:
            rhs.append("+temporal> %s" % r.choice(["isa time", "ticks 0", "isa time ticks 3", "isa clear"]))
        elif k < 0.4 and "=temporal>" in lhs[-1]:
            rhs.append("*temporal> ticks %d" % r.randint(0, 5))
        elif k < 0.5 and "=temporal>" in lhs[-1]:
            rhs.append("=temporal> ticks %d" % r.randint(0, 5))
        elif k < 0.6:
            rhs.append("-temporal>")
        if "ticks =t" in lhs[-1] and r.random() < 0.5:
            rhs.append("!output! (ticks =t)")
        if r.random() < 0.2:
            rhs.append("+retrieval> state %s" % r.choice(states))
        lines.append("(p p%d\n  %s\n==>\n  %s)" % (pi, "\n  ".join(lhs), "\n  ".join(rhs)))
    lines.append("(goal-focus g))")
    return "\n".join(lines) + "\n"

def main():
    out, n = sys.argv[1], int(sys.argv[2])
    seed = int(sys.argv[3]) if len(sys.argv) > 3 else 1
    os.makedirs(out, exist_ok=True)
    r = random.Random(seed)
    for i in range(n):
        with open(os.path.join(out, "t%04d.lisp" % i), "w") as f:
            f.write(gen(r, i))

if __name__ == "__main__":
    main()
