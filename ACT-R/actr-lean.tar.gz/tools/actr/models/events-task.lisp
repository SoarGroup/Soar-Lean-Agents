;;; Runs by event count and by condition (tests run-n-events and run-until-condition).
(load-act-r-model (merge-pathnames "sgp-model.lisp" *load-truename*))

(defun events-test ()
  (reset)
  (run-n-events 7)
  (run-n-events 3)
  (run 0.3)
  (run-until-condition (lambda (time) (> time 900)))
  (run-n-events 50)
  (run-until-condition (lambda (time) (> time 1600))))
