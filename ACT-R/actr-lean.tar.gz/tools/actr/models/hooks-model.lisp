;;; Productions competing under utility noise, with a utility hook and two cycle hooks
;;; (tests :utility-hook and :cycle-hook given as task commands).
(clear-all)
(define-model hooks
  (sgp :v t :trace-detail high :esc t :egs 0.5 :ul t
       :utility-hook "hooks-utility" :cycle-hook "hooks-cycle" :cycle-hook "hooks-cycle2"
       :retrieved-chunk-hook "hooks-retrieved" :rt 0 :ans 0.3 :lf 0.01)
  (chunk-type g state n)
  (add-dm (g1 isa g state go n 0) (f1 isa g state fact n 1) (f2 isa g state fact n 2))
  (goal-focus g1)
  (p a =goal> state go ==> =goal> state go)
  (p b =goal> state go ==> =goal> state go)
  (p c =goal> state go ==> =goal> state go +retrieval> state fact)
  (spp a :u 1 :reward 2)
  (spp b :u 2))
