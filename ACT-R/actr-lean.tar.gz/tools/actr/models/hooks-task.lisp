;;; The hooks of hooks-model.lisp: a utility for b that changes with the count of
;;; productions fired, and cycle hooks that count and sometimes modify the goal.
(defvar *fired* 0)
(defun hooks-utility (p)
  (cond ((eq p 'b) (if (oddp *fired*) 5 nil))
        ((eq p 'c) (if (zerop (mod *fired* 3)) 1.5 nil))
        (t nil)))
(defun hooks-cycle (p) (declare (ignore p)) (incf *fired*))
(defun hooks-cycle2 (p)
  (when (and (eq p 'a) (> *fired* 5)) (mod-focus n 1)))
(defvar *retrieved* nil)
(defun hooks-retrieved (c) (push c *retrieved*) (when (null c) (mod-focus n 9)))
(add-act-r-command "hooks-retrieved" 'hooks-retrieved "test")
(add-act-r-command "hooks-utility" 'hooks-utility "test")
(add-act-r-command "hooks-cycle" 'hooks-cycle "test")
(add-act-r-command "hooks-cycle2" 'hooks-cycle2 "test")
(load-act-r-model (merge-pathnames "hooks-model.lisp" *load-truename*))

(defun hooks-test () (setf *fired* 0) (reset) (run 2))
