;;; Requests to the imaginal-action buffer: simple actions returning a chunk or nil, and a
;;; generic action that frees the module later itself (tests the imaginal-action buffer).
(clear-all)
(define-model imaction
(sgp :v nil :esc t :egs 0.3)
(chunk-type item n result)
(chunk-type task state)
(define-chunks (g isa task state start) (start) (wait) (check) (generic) (done))

(p start
   =goal> state start
   ?imaginal> state free buffer empty
==>
   +imaginal> isa item n 1
   =goal> state wait)

(p simple-request
   =goal> state wait
   =imaginal> n =n
   ?imaginal-action> state free
==>
   +imaginal-action> action "imaction-double" simple t
   =goal> state check)

(p simple-isa
   =goal> state wait
   =imaginal> n =n
   ?imaginal-action> state free
==>
   +imaginal-action> isa simple-action action "imaction-double"
   =goal> state check)

(p with-slots
   =goal> state wait
   =imaginal> n =n
   ?imaginal-action> state free
==>
   +imaginal-action> action "imaction-slots" simple t slots (n result)
   =goal> state check)

(p failing
   =goal> state wait
   =imaginal>
   ?imaginal-action> state free
==>
   +imaginal-action> action "imaction-fail" simple t
   =goal> state check)

(p generic
   =goal> state wait
   =imaginal>
   ?imaginal-action> state free
==>
   +imaginal-action> action "imaction-generic"
   =imaginal>
   =goal> state generic)

(p generic-done
   =goal> state generic
   ?imaginal> state free
   ?imaginal-action> state free
==>
   =goal> state wait)

(p got-result
   =goal> state check
   =imaginal> n =n
   ?imaginal> state free
==>
   !output! (result =n)
   =imaginal>
   =goal> state wait)

(p got-error
   =goal> state check
   ?imaginal> state error
==>
   !output! (error)
   +imaginal> isa item n 1
   =goal> state wait)

(p restart
   =goal> state wait
   =imaginal> > n 50
==>
   +imaginal> isa item n 1
   =goal> state wait)

(goal-focus g))
