;;; The actions called by the imaginal-action requests of imaction-model.lisp.
(load-act-r-model (merge-pathnames "imaction-model.lisp" *load-truename*))

(defun double-n ()
  (let* ((c (buffer-read 'imaginal))
         (new (copy-chunk-fct c)))
    (mod-chunk-fct new (list 'n (* 2 (chunk-slot-value-fct c 'n))))))
(defun fail-action () nil)
(defun slots-action (&rest names)
  (let* ((c (buffer-read 'imaginal))
         (new (copy-chunk-fct c)))
    (mod-chunk-fct new (list 'n (+ (length names) (chunk-slot-value-fct c 'n))))))
(defun generic-action ()
  (schedule-event-relative 0.3 "set-imaginal-free" :module 'imaginal :output nil))

(add-act-r-command "imaction-double" 'double-n "test")
(add-act-r-command "imaction-fail" 'fail-action "test")
(add-act-r-command "imaction-slots" 'slots-action "test")
(add-act-r-command "imaction-generic" 'generic-action "test")

(defun imaction-test () (reset) (run 10))
