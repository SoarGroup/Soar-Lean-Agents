;;; Buttons at pseudo-random places; a click on one replaces it with another elsewhere.
(load-act-r-model (merge-pathnames "mouse-model.lisp" *load-truename*))

(defvar *state* 1)
(defvar *window* nil)
(defun next-int (n)
  (setf *state* (mod (+ (* *state* 1103515245) 12345) 2147483648))
  (mod (floor *state* 65536) n))

(defun add-target ()
  (let ((w (+ 10 (next-int 60))) (h (+ 10 (next-int 40))))
    (add-button-to-exp-window *window* :text "" :x (next-int (- 560 w)) :y (next-int (- 360 h))
                              :width w :height h :action "mouse-target-pressed")))

(defun target-pressed (&rest args)
  (declare (ignore args))
  (add-target))

(add-act-r-command "mouse-target-pressed" 'target-pressed "mouse test button")

(defun mouse-test (seed &optional (time 20))
  (reset)
  (setf *state* seed)
  (setf *window* (open-exp-window "Mouse" :visible nil :width 600 :height 400))
  (dotimes (i 3) (add-target))
  (install-device *window*)
  (when (evenp seed) (start-hand-at-mouse))
  (run time))
