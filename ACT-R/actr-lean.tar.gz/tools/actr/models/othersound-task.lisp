;;; Sounds made with new-other-sound (tests new-other-sound and aural encoding of them).
(load-act-r-model (merge-pathnames "othersound-model.lisp" *load-truename*))

(defun othersound-test ()
  (reset)
  (new-other-sound "hello" .5 .1 .2 .3 'external 'speech)
  (new-other-sound 'beep .2 .05 .1 1.0 'external 'tone)
  (new-other-sound 42 .3 .2 .15 1.5 'internal 'digit)
  (run 3))
