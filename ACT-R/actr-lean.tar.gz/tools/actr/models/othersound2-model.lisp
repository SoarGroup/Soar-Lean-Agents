;;; Sounds made with new-other-sound (tests new-other-sound and aural encoding of them).
(clear-all)
(define-model others2
  (sgp :v t :trace-detail high)
  (chunk-type g state)
  (add-dm (g1 isa g state listen))
  (goal-focus g1)
  (set-audloc-default kind digit :attended nil)
  (p hear
     =goal> state listen
     =aural-location>
     ?aural> state free
   ==>
     +aural> event =aural-location
     =goal> state attend)
  (p heard
     =goal> state attend
     =aural>
       content =c
       kind =k
   ==>
     !output! (=c =k)
     +aural-location> set-audloc-default t :attended nil
     =goal> state listen))

