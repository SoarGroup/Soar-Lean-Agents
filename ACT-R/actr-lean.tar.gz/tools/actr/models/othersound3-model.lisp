;;; Sounds arriving while the aural-location buffer holds a stuffed chunk (tests
;;; :overstuff-aural-location).
(clear-all)
(define-model others3
  (sgp :v t :trace-detail high :overstuff-aural-location t)
  (chunk-type g state)
  (add-dm (g1 isa g state idle))
  (goal-focus g1)
  (p wait
     =goal> state idle
     ?aural-location> buffer full
   ==>
     =goal> state waited))
