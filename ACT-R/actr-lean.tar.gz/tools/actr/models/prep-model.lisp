;;; Manual prepare and execute requests (tests prepare, execute and their timing).
(clear-all)
(define-model prep
  (sgp :v t :trace-detail high)
  (chunk-type g state n)
  (add-dm (g1 isa g state start n 0))
  (goal-focus g1)
  (p prep-punch
     =goal> state start
     ?manual> state free
   ==>
     +manual> cmd prepare style punch hand left finger index
     =goal> state wait1)
  (p exec-1
     =goal> state wait1
     ?manual> preparation free
   ==>
     +manual> cmd execute
     =goal> state prep2)
  (p prep-peck
     =goal> state prep2
     ?manual> preparation free
   ==>
     +manual> cmd prepare style peck hand right finger middle r 1 theta 0
     =goal> state wait2)
  (p exec-2
     =goal> state wait2
     ?manual> preparation free
   ==>
     +manual> cmd execute
     =goal> state again)
  (p exec-again
     =goal> state again
     ?manual> state free
   ==>
     +manual> cmd execute
     =goal> state recoil)
  (p prep-recoil
     =goal> state recoil
     ?manual> state free
   ==>
     +manual> cmd prepare style peck-recoil hand left finger ring r 1 theta 3.14
     =goal> state early)
  (p exec-early
     =goal> state early
   ==>
     +manual> cmd execute
     =goal> state late)
  (p exec-late
     =goal> state late
     ?manual> preparation free
   ==>
     +manual> cmd execute
     =goal> state done)
  (p press
     =goal> state done
     ?manual> state free
   ==>
     +manual> cmd press-key key "a"
     =goal> state point1)
  (p point1
     =goal> state point1
     ?manual> state free
   ==>
     +manual> cmd point-hand-at-key hand right to-key "u"
     =goal> state peck-u)
  (p peck-u
     =goal> state peck-u
     ?manual> state free
   ==>
     +manual> cmd punch hand right finger middle
     =goal> state point2)
  (p point2
     =goal> state point2
     ?manual> state free
   ==>
     +manual> cmd point-hand-at-key hand left to-key q offsets standard
     =goal> state point3)
  (p point3
     =goal> state point3
     ?manual> state free
   ==>
     +manual> cmd point-hand-at-key hand left to-key q
     =goal> state home)
  (p home
     =goal> state home
     ?manual> state free
   ==>
     +manual> cmd hand-to-home hand right
     =goal> state end))
