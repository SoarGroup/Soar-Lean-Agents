;;; Runs prep-model.lisp with a keyboard (tests prepare and execute).
(load-act-r-model (merge-pathnames "prep-model.lisp" *load-truename*))

(defun prep-test ()
  (reset)
  (install-device '("motor" "keyboard"))
  (run 6))
