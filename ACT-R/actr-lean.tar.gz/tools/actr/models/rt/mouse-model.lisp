;;; A model that points and clicks at buttons with the mouse: the cursor is moved to a
;;; location or to an attended object, moves follow one another without a click, and
;;; movements are prepared while the previous one executes (tests the mouse).
(clear-all)
(define-model mouse

(sgp :randomize-time t :vpft t :vidt t)

(sgp :v nil :esc t :egs 0.4 :needs-mouse t :seed (101 7))
(chunk-type task state mode)
(define-chunks (g isa task state find) (find) (attend) (move) (click) (again) (loc) (obj) (early) (twice) (home) (type) (back) (keys))

(p find-loc
   =goal> state find
==>
   +visual-location> :attended nil kind oval
   =goal> state attend mode loc)

(p find-obj
   =goal> state find
==>
   +visual-location> :attended nil kind oval
   =goal> state attend mode obj)

(p find-early
   =goal> state find
==>
   +visual-location> :attended nil kind oval
   =goal> state attend mode early)

(p find-twice
   =goal> state find
   - mode twice
==>
   +visual-location> :attended nil kind oval
   =goal> state attend mode twice)

(p attend
   =goal> state attend
   =visual-location>
   ?visual> state free
==>
   +visual> cmd move-attention screen-pos =visual-location
   =goal> state move)

(p move-to-location
   =goal> state move mode loc
   =visual> screen-pos =loc
   ?manual> state free
==>
   +manual> cmd move-cursor loc =loc
   =goal> state click)

(p move-to-object
   =goal> state move mode obj
   =visual>
   ?manual> state free
==>
   +manual> cmd move-cursor object =visual
   =goal> state click)

(p move-early
   =goal> state move mode early
   =visual> screen-pos =loc
   ?manual> preparation free
==>
   +manual> cmd move-cursor loc =loc
   =goal> state click)

(p move-twice
   =goal> state move mode twice
   =visual> screen-pos =loc
   ?manual> state free
==>
   +manual> cmd move-cursor loc =loc
   =goal> state again)

(p move-again
   =goal> state again
   ?manual> state free
   ?visual-location> buffer empty
==>
   +visual-location> kind oval :nearest current
   =goal> state attend mode loc)

(p click
   =goal> state click
   ?manual> preparation free
==>
   +manual> cmd click-mouse
   =goal> state find)

(p find-home
   =goal> state find
   - mode home
==>
   =goal> state home mode home)

(p find-keys
   =goal> state find
   - mode keys
==>
   =goal> state type mode keys)

(p go-home
   =goal> state home
   ?manual> state free
==>
   +manual> cmd hand-to-home
   =goal> state type)

(p type-key
   =goal> state type
   ?manual> state free
==>
   +manual> cmd press-key key "j"
   =goal> state back)

(p type-other-key
   =goal> state type
   ?manual> state free
==>
   +manual> cmd press-key key "k"
   =goal> state back)

(p back-to-mouse
   =goal> state back
   ?manual> state free
==>
   +manual> cmd hand-to-mouse
   =goal> state find)

(p back-early
   =goal> state back
   ?manual> preparation free
==>
   +manual> cmd hand-to-mouse
   =goal> state find)

(goal-focus g))
