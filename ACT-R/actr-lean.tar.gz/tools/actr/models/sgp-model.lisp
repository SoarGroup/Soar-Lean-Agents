(clear-all)
(define-model m7
(sgp :esc t :lf .4 :rt 0.5 :mas 4 :imaginal-activation 0 :le 2 :ans 0.5)
(add-dm (c0 d v5 c v4 b v2) (c1 a v4 d v1) (c2 c v5 b v2) (c3 b v1) (v1) (v2) (v3) (v4) (v5) (g state s0 d v2 c v1 b v3))
(goal-focus g)
(p p0
  =goal>
  state s0
==>
  =goal> state s2 a nil c nil
  +retrieval> - b v1 :recently-retrieved reset)
(spp p0 :reward 2.5)
(p p1
  =goal>
  state s1
==>
  =goal> state s3 b 1
  +retrieval> c1)
(p p2
  =goal>
  state s1
  d =x0
  b =x1
==>
  =goal> state s1
  +retrieval> b =x1 :recently-retrieved reset)
(p p3
  =goal>
  state s2
==>
  =goal> state s1
  +retrieval> d 3 > c 4
  -imaginal>)
(spp p3 :u -1)
(p p4
  =goal>
  state s2
  - d nil
  b nil
  =retrieval> 
  a =y0
  ?imaginal> buffer full
==>
  =goal> state s0 b v5
  +retrieval> - c v3 :recently-retrieved t
  !output! (=y0))
(p p5
  =goal>
  state s3
==>
  !bind! =w (* 2.5 0.25)
  =goal> state s0 a v1
  +retrieval> c nil :recently-retrieved t
  !output! (=w))
(spp p5 :u -1)
)
