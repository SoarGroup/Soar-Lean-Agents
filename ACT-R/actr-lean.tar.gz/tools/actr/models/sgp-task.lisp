;;; A task that changes parameters and clears a buffer from task code between runs
;;; (tests the replay of sgp and clear-buffer).
(load-act-r-model (merge-pathnames "sgp-model.lisp" *load-truename*))

(defun sgp-test ()
  (reset)
  (run 0.5)
  (sgp :egs 0.7 :ans 0.3 :esc t)
  (run 0.5)
  (clear-buffer 'retrieval)
  (clear-buffer 'goal)
  (goal-focus g)
  (run 0.5)
  (sgp :rt -5 :lf 0.3 :dat 0.07)
  (clear-buffer 'imaginal)
  (run 1))
