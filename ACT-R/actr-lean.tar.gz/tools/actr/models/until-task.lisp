;;; Runs to absolute times with run-until-time, including a time already passed
;;; (tests run-until-time).
(load-act-r-model (merge-pathnames "sgp-model.lisp" *load-truename*))

(defun until-test ()
  (reset)
  (run-until-time 0.7)
  (run-until-time 0.5)
  (run 0.3)
  (run-until-time 2.25))
