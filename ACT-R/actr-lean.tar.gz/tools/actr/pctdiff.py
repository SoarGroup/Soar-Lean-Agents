#!/usr/bin/env python3
"""Compare the productions made by production compilation in ACT-R (#PCT lines of a task
recording) and in actr-lean (#PCT NEW lines). usage: pctdiff.py REC.actr REC.lean"""
import sys, re
def actr(path):
    out, cur, skip = [], None, False
    for l in open(path):
        if not l.startswith("#PCT"): continue
        t = l[5:].strip()
        if t.startswith("(P "):
            cur = [t[3:].strip()]; continue
        if cur is not None:
            if t == ")":
                out.append(" ".join(cur)); cur = None
            elif t.startswith('"'): pass
            else: cur.append(t)
    return out
def lean(path):
    return [l[len("#PCT NEW "):].strip() for l in open(path) if l.startswith("#PCT NEW ")]
a, b = actr(sys.argv[1]), lean(sys.argv[2])
norm = lambda s: re.sub(r"\s+", " ", s)
for i, (x, y) in enumerate(zip(a, b)):
    if norm(x) != norm(y):
        print("first difference at production", i); print(" ACT-R:", x); print(" Lean: ", y); break
else:
    print("same %d productions" % min(len(a), len(b)), "(ACT-R %d, Lean %d)" % (len(a), len(b)))
