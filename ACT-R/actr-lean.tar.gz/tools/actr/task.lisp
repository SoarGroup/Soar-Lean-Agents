(setf *print-pretty* nil)
;;; ACT-R side of the harness for tutorial tasks. Usage:
;;;   sbcl --script task.lisp EXPERIMENT-FILE "(experiment-form)"
;;; Loads the experiment code (which loads its model), records every command the task
;;; code sends to ACT-R between runs as a #CMD line, and lets ACT-R print its
;;; high-detail trace during each run. Output from the task code itself is suppressed.
;;; actr-lean --script replays the #CMD lines on the Lean model.
(setf *load-verbose* nil *compile-verbose* nil)
(load (concatenate 'string (or (sb-ext:posix-getenv "ACTR_HOME") "/home/claude/actr-dl/actr")
                   "/load-single-threaded-act-r.lisp"))
(defvar *out* *standard-output*)
(defvar *depth* 0)
(defvar *model-file* nil)

(defun out (fmt &rest args) (apply #'format *out* fmt args) (finish-output *out*))

(defun rng-count ()
  (let ((m (get-module random-module)))
    (if m (mt-count (act-r-random-module-state m)) 0)))

(defun flat (x) (format nil "~{~s~^ ~}" x))

(defmacro logged (name lambda-list &body body)
  "Encapsulate NAME so that an outermost call (from task code) is logged."
  `(sb-int:encapsulate ',name 'harness-log
     (lambda (f ,@lambda-list)
       (if (> *depth* 0)
           ,(if (member '&rest lambda-list)
                `(apply f ,@(remove '&rest lambda-list))
                `(funcall f ,@lambda-list))
           (let ((*depth* (1+ *depth*)))
             ,@body)))))

(logged reset (&rest args)
  (out "~&#CMD RESET~%")
  (apply f args)
  (sgp :v t :trace-detail high :act nil))

(logged run (time &rest args)
  (out "~&#CMD RUN ~a RNG=~d~%" time (rng-count))
  (let ((r (multiple-value-list (apply f time args))))
    (out "~&#ENDRUN~%#RET ~s~%" (car r))
    (values-list r)))

(logged run-until-time (time &rest args)
  (out "~&#CMD RUN-UNTIL ~a RNG=~d~%" time (rng-count))
  (prog1 (apply f time args) (out "~&#ENDRUN~%")))

(logged run-n-events (count &rest args)
  (out "~&#CMD RUN-EVENTS ~a RNG=~d~%" count (rng-count))
  (let ((r (multiple-value-list (apply f count args))))
    (out "~&#ENDRUN~%")
    (values-list r)))

;; The condition is the task's own code: the replay runs as many events as ACT-R did.
(logged run-until-condition (condition &rest args)
  (out "~&#CMD RUN-COND 0 RNG=~d~%" (rng-count))
  (let ((r (multiple-value-list (apply f condition args))))
    (out "~&#EVENTS ~d~%#ENDRUN~%" (second r))
    (values-list r)))

(logged run-full-time (time &rest args)
  (out "~&#CMD RUN-FULL ~a RNG=~d~%" time (rng-count))
  (prog1 (apply f time args) (out "~&#ENDRUN~%")))

(logged pdisable-fct (names)
  (out "~&#CMD PDISABLE ~a~%" (flat names)) (funcall f names))
(logged penable-fct (names)
  (out "~&#CMD PENABLE ~a~%" (flat names)) (funcall f names))
(logged mod-chunk-fct (name mods)
  (out "~&#CMD MOD-CHUNK ~s ~a~%" name (flat mods)) (funcall f name mods))
(logged mod-focus-fct (mods)
  (out "~&#CMD MOD-FOCUS ~a~%" (flat mods)) (funcall f mods))
(logged goal-focus-fct (&rest args)
  (out "~&#CMD GOAL-FOCUS ~a~%" (flat args)) (apply f args))
(logged set-buffer-chunk (buffer chunk &rest args)
  (out "~&#CMD SET-BUFFER-CHUNK ~s ~s ~a~%" buffer chunk (flat args)) (apply f buffer chunk args))
(logged define-chunks-fct (defs)
  (let ((r (funcall f defs)))
    (out "~&#CMD DEFINE-CHUNKS ~s~%" (mapcar (lambda (n d) (if (and (consp d) (symbolp (car d)) (not (eq (car d) 'isa))) d (cons n d))) r defs))
    r))
(logged add-dm-fct (defs &rest args)
  (let ((r (apply f defs args)))
    (out "~&#CMD ADD-DM ~s~%" (mapcar (lambda (n d) (if (and (consp d) (symbolp (car d)) (not (eq (car d) 'isa))) d (cons n d))) r defs))
    r))
(logged trigger-reward (value &rest args)
  (out "~&#CMD TRIGGER-REWARD ~s~%" value) (apply f value args))
(logged schedule-event-relative (delay action &rest keys)
  (out "~&#CMD SCHEDULE-EVENT-RELATIVE ~s ~s ~a~%" delay action (flat keys))
  (apply f delay action keys))
(logged schedule-event (&rest args)
  (out "~&#CMD UNSUPPORTED schedule-event~%") (apply f args))

;; The device: visicon changes made by the experiment window (AGI) or task code, and
;; command monitors (e.g. the task watching output-key).
(logged add-visicon-features (&rest features)
  (let ((r (apply f features)))
    (let ((*print-pretty* nil)) (out "~&#CMD ADD-VISICON-FEATURES ~s ~s~%" r features))
    r))
(logged delete-visicon-features (&rest names)
  (out "~&#CMD DELETE-VISICON-FEATURES ~a~%" (flat names)) (apply f names))
(logged delete-all-visicon-features ()
  (out "~&#CMD DELETE-ALL-VISICON-FEATURES~%") (funcall f))
(logged modify-visicon-features (&rest mods)
  (out "~&#CMD MODIFY-VISICON-FEATURES ~s~%" mods) (apply f mods))
(logged monitor-act-r-command (cmd monitor &rest args)
  (out "~&#CMD MONITOR ~s ~s~%" cmd monitor) (apply f cmd monitor args))
(logged remove-act-r-command-monitor (cmd monitor &rest args)
  (out "~&#CMD UNMONITOR ~s ~s~%" cmd monitor) (apply f cmd monitor args))
;; Chunks copied by task code (e.g. in an imaginal-action function), and the imaginal
;; module's state set by task code.
(logged copy-chunk-fct (name)
  (out "~&#CMD COPY-CHUNK ~s~%" name) (funcall f name))
(logged set-imaginal-free ()
  (out "~&#CMD SET-IMAGINAL-FREE~%") (funcall f))
(logged set-imaginal-error ()
  (out "~&#CMD SET-IMAGINAL-ERROR~%") (funcall f))

;; The mouse: its position set by task code or by installing an experiment window.
(logged start-hand-at-mouse ()
  (out "~&#CMD START-HAND-AT-MOUSE~%") (funcall f))
(sb-int:encapsulate 'set-cursor-position-fct 'harness-log
  (lambda (f xyloc &rest args)
    (when (= *depth* 0) (out "~&#CMD SET-CURSOR-POSITION ~s ~s~%" (coerce xyloc 'list) (if args (first args) "mouse")))
    (let ((*depth* (1+ *depth*))) (apply f xyloc args))))
(sb-int:encapsulate 'install-device 'harness-log
  (lambda (f &rest args)
    (when (= *depth* 0) (out "~&#CMD INSTALL-DEVICE ~s~%" args))
    (apply f args)))

;; Experiment-window commands run by ACT-R events (e.g. a scheduled clear-exp-window): the
;; visicon changes they make are recorded as a call of that command.
(dolist (name '(clear-exp-window add-text-to-exp-window add-button-to-exp-window
                add-line-to-exp-window add-items-to-exp-window remove-items-from-exp-window))
  (let ((name name))
    (sb-int:encapsulate name 'harness-log
      (lambda (f &rest args)
        (if (> *depth* 0)
            (progn
              (out "~&#CB ~(~a~)~{ ~s~}~%" name args)
              (let ((r (let ((*depth* 0)) (apply f args))))
                (out "~&#ENDCB RNG=~d ~s~%" (rng-count) r)
                r))
            (apply f args))))))

;; Production compilation's own trace (:pct) is recorded but not compared.
(defvar *in-compile* nil)
(sb-int:encapsulate 'compile-productions 'harness-log
  (lambda (f p) (let ((*in-compile* t)) (funcall f p))))
(sb-int:encapsulate 'model-output-internal 'harness-log
  (lambda (f string)
    (if *in-compile*
        (with-input-from-string (in string)
          (loop for l = (read-line in nil) while l do (out "~&#PCT ~a~%" l)))
        (funcall f string))))
(defun setting-p (params)
  "Whether an spp/sdp parameter list sets a value (a keyword followed by a value)."
  (loop for (a b) on (if (listp params) params (list params))
        thereis (and (keywordp a) b (not (keywordp b)))))
(sb-int:encapsulate 'spp-fct 'harness-log
  (lambda (f &rest args)
    (cond (*in-compile* nil)
          ((and (= *depth* 0) (setting-p (first args)))
           (out "~&#CMD UNSUPPORTED spp~%") (let ((*depth* 1)) (apply f args)))
          (t (apply f args)))))
(sb-int:encapsulate 'sdp-fct 'harness-log
  (lambda (f &rest args)
    (if (and (= *depth* 0) (setting-p (first args)))
        (progn (out "~&#CMD UNSUPPORTED sdp~%") (let ((*depth* 1)) (apply f args)))
        (apply f args))))

;; Commands that change the model's state which the replay does not model: a task that
;; sends one of them is reported unsupported rather than compared.
(dolist (name '(mod-buffer-chunk overwrite-buffer-chunk erase-buffer set-buffer-failure
                schedule-mod-buffer-chunk schedule-overwrite-buffer-chunk module-request
                module-mod-request schedule-module-request schedule-module-mod-request
                set-chunk-slot-value-fct merge-dm-fct merge-chunks-fct delete-chunk-fct
                purge-chunk-fct make-chunk-reusable clear-dm
                set-parameter-value set-system-parameter-value set-base-levels-fct
                set-all-base-levels set-similarities-fct add-sji-fct set-hand-location-fct
                add-word-characters set-audloc-default-fct
                schedule-event-now schedule-event-after-module schedule-event-after-change
                schedule-periodic-event delete-event remove-visual-finsts
                attend-visual-coordinates reset-declarative-finsts simulate-retrieval-request-fct
                simulate-retrieval-request-plus-seed-fct clear-productions
                run-until-action schedule-break
                schedule-break-relative schedule-break-after-module schedule-break-after-all
                pbreak-fct punbreak-fct))
  (let ((name name))
    (when (fboundp name)
      (sb-int:encapsulate name 'harness-log
        (lambda (f &rest args)
          (when (= *depth* 0) (out "~&#CMD UNSUPPORTED ~(~a~)~%" name))
          (let ((*depth* (1+ *depth*))) (apply f args)))))))
(sb-int:encapsulate 'print-production 'harness-log
  (lambda (f &rest args)
    (if *in-compile*
        (let ((txt (with-output-to-string (*standard-output*) (apply f args))))
          (with-input-from-string (in txt)
            (loop for l = (read-line in nil) while l do (out "~&#PCT ~a~%" l))))
        (apply f args))))

;; Parameters set by task code (the trace stays on).
(sb-int:encapsulate 'sgp-fct 'harness-log
  (lambda (f params)
    (if (> *depth* 0)
        (funcall f params)
        (let ((keep (loop for (k v) on params by #'cddr unless (eq k :v) append (list k v))))
          (when keep (out "~&#CMD SGP ~s~%" keep))
          (prog1 (when keep (let ((*depth* 1)) (funcall f keep)))
            (let ((*depth* 1)) (funcall f '(:v t))))))))
(logged clear-buffer (b)
  (out "~&#CMD CLEAR-BUFFER ~s~%" b) (funcall f b))

;; Sounds the task presents.
(logged new-digit-sound (digit &optional onset time-in-ms)
  (out "~&#RNG ~d~%" (rng-count)) (out "~&#CMD NEW-DIGIT-SOUND ~s ~s ~s~%" digit onset time-in-ms) (funcall f digit onset time-in-ms))
(logged new-tone-sound (freq duration &optional onset time-in-ms)
  (out "~&#RNG ~d~%" (rng-count)) (out "~&#CMD NEW-TONE-SOUND ~s ~s ~s ~s~%" freq duration onset time-in-ms) (funcall f freq duration onset time-in-ms))
(logged new-other-sound (&rest args)
  (destructuring-bind (content duration delay recode &optional onset (location 'external) (kind 'speech) time-in-ms &rest other) args
    (when other (out "~&#CMD UNSUPPORTED new-other-sound with other features~%"))
    (out "~&#CMD NEW-OTHER-SOUND ~s ~s ~s ~s ~s ~s ~s ~s~%" content duration delay recode onset location kind time-in-ms))
  (apply f args))
(logged new-word-sound (word &optional onset (location 'external) time-in-ms)
  (out "~&#RNG ~d~%" (rng-count)) (out "~&#CMD NEW-WORD-SOUND ~s ~s ~s ~s~%" word onset location time-in-ms) (funcall f word onset location time-in-ms))

;; Queries: the task's view of the model. actr-lean answers them from its own state.
(defmacro queried (name lambda-list call)
  `(logged ,name ,lambda-list
     (let ((r ,call))
       (out "~&#Q ~a~{ ~s~}~%#A ~s~%" ',name (list ,@(remove '&optional lambda-list)) r)
       r)))
(queried buffer-read (b) (funcall f b))
(queried buffer-slot-value (b s) (funcall f b s))
(queried chunk-slot-value-fct (c s) (funcall f c s))
(queried mp-time () (funcall f))
(queried mp-time-ms () (funcall f))
(sb-int:encapsulate 'get-time 'harness-log
  (lambda (f &optional (model-time t))
    (if (or (> *depth* 0) (not model-time))
        (funcall f model-time)
        (let ((r (let ((*depth* 1)) (funcall f model-time))))
          (out "~&#Q GET-TIME~%#A ~s~%" r)
          r))))

;; Task commands called by the model (!eval!), by monitors or by scheduled events: the
;; call, the commands the task code sends meanwhile, and the result.
(sb-int:encapsulate 'add-act-r-command 'harness-log
  (lambda (f name &optional function &rest args)
    (if (or (> *depth* 0) (null function))
        (apply f name function args)
        (apply f name
               (lambda (&rest cargs)
                 (if (let ((hook (let ((*depth* 1)) (ignore-errors (car (no-output (sgp :sim-hook)))))))
                       (and (stringp hook) (string-equal hook name)))
                     ;; the model's :sim-hook: only its results are needed
                     (let ((r (let ((*depth* 1)) (apply function cargs))))
                       (out "~&#SIM ~a~{ ~s~} => ~s~%" name cargs r)
                       r)
                     (progn
                       (out "~&#CB ~a~{ ~s~}~%" name cargs)
                       (let ((r (let ((*depth* 0)) (apply function cargs))))
                         (out "~&#ENDCB RNG=~d ~s~%" (rng-count) r)
                         r))))
               args))))

(sb-int:encapsulate 'load-act-r-model 'harness-log
  (lambda (f path &rest args)
    (let ((p (namestring (translate-logical-pathname path))))
      (setf *model-file* p)
      (out "~&#LOAD ~a~%" p)
      (prog1 (let ((*depth* (1+ *depth*))) (apply f path args))
        ;; a model that sets no seed gets the one actr-lean uses by default
        (let ((*depth* 1))
          (unless (search ":SEED" (string-upcase (with-open-file (in p) (let ((s (make-string (file-length in)))) (subseq s 0 (read-sequence s in))))))
            (sgp :seed (12345 0)))
          (sgp :v t :trace-detail high :act nil))))))

(let* ((args (cdr sb-ext:*posix-argv*)))
  (out "~&#TASK ~a ~a~%" (first args) (second args))
  (handler-case
      (let ((*error-output* (make-broadcast-stream)))
        (load (first args))
        (let ((*standard-output* (make-broadcast-stream)))
          (eval (read-from-string (second args)))))
    (error (e) (out "~&#ERROR ~a~%" e)))
  (out "~&#END~%"))
(sb-ext:exit)
