#!/usr/bin/env python3
"""Compare ACT-R and actr-lean on tutorial tasks.

usage: taskdiff.py [--verbose] [NAME ...]

Each task runs in ACT-R through task.lisp, which records the commands the task code sends
to ACT-R; actr-lean --script replays them on the Lean model. The two outputs (commands,
high-detail traces and !output! lines) are compared line by line.
"""
import os, subprocess, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from diff import norm, strip_warnings, TRACE, TRACE_LEAN, first_diff, LEAN, HERE

ACTR = os.environ.get("ACTR_HOME", "/home/claude/actr-dl/actr")
T = os.path.join(ACTR, "tutorial", "lisp")
# name: (experiment file, form)
TASKS = {
    "fan-no-pm": ("fan-no-pm.lisp", "(fan-experiment)"),
    "grouped": ("grouped.lisp", "(grouped-recall)"),
    "ul-issues": ("ul-issues.lisp", "(run 100)"),
    "demo2": ("demo2.lisp", "(demo2-experiment)"),
    "unit2": ("unit2.lisp", "(unit2-experiment)"),
    "subitize": ("subitize.lisp", "(subitize-experiment)"),
    "sperling": ("sperling.lisp", "(sperling-experiment 1)"),
    "paired": ("paired.lisp", "(paired-experiment 1)"),
    "zbrodoff": ("zbrodoff.lisp", "(zbrodoff-experiment nil t)"),
    "fan": ("fan.lisp", "(fan-experiment)"),
    "choice": ("choice.lisp", "(choice-model)"),
    "onehit": ("onehit.lisp", "(onehit-hands 5)"),
    "onehit-200": ("onehit.lisp", "(onehit-hands 200)"),
    "siegler": ("siegler.lisp", "(siegler-experiment 1)"),
    "bst": ("bst.lisp", "(bst-experiment 1)"),
    "pcomp-issues": ("pcomp-issues.lisp", "(pcomp-issues-game 1)"),
    "pm-issues": ("pm-issues.lisp", "(pm-issues-task)"),
    "past-tense": ("past-tense.lisp", "(past-tense-trials 100)"),
    "categorize": ("categorize.lisp", "(do-experiment)"),
    # production compilation (unit 7)
    "pcomp-epl": ("pcomp-issues.lisp", '(progn (load-act-r-model "%s") (pcomp-issues-game 1))' % os.path.join(os.path.dirname(os.path.abspath(__file__)), "models", "pcomp-epl-model.lisp")),
    # sgp and clear-buffer sent by task code
    "sgp-task": (os.path.join(os.path.dirname(os.path.abspath(__file__)), "models", "sgp-task.lisp"), "(sgp-test)"),
    "bst-ppm": ("bst-ppm.lisp", "(bst-ppm-experiment 1)"),
    "mouse": (os.path.join(os.path.dirname(os.path.abspath(__file__)), "models", "mouse-task.lisp"), "(mouse-test 2)"),
    "imaction": (os.path.join(os.path.dirname(os.path.abspath(__file__)), "models", "imaction-task.lisp"), "(imaction-test)"),
    "prep": (os.path.join(os.path.dirname(os.path.abspath(__file__)), "models", "prep-task.lisp"), "(prep-test)"),
    "othersound": (os.path.join(os.path.dirname(os.path.abspath(__file__)), "models", "othersound-task.lisp"), "(othersound-test)"),
    "othersound2": (os.path.join(os.path.dirname(os.path.abspath(__file__)), "models", "othersound-task.lisp"), '(progn (load-act-r-model "%s") (othersound-test))' % os.path.join(os.path.dirname(os.path.abspath(__file__)), "models", "othersound2-model.lisp")),
    "othersound3": (os.path.join(os.path.dirname(os.path.abspath(__file__)), "models", "othersound-task.lisp"), '(progn (load-act-r-model "%s") (othersound-test))' % os.path.join(os.path.dirname(os.path.abspath(__file__)), "models", "othersound3-model.lisp")),
    "events": (os.path.join(os.path.dirname(os.path.abspath(__file__)), "models", "events-task.lisp"), "(events-test)"),
    "hooks": (os.path.join(os.path.dirname(os.path.abspath(__file__)), "models", "hooks-task.lisp"), "(hooks-test)"),
    "until": (os.path.join(os.path.dirname(os.path.abspath(__file__)), "models", "until-task.lisp"), "(until-test)"),
    "paired-dynamic": ("paired.lisp", '(progn (load-act-r-model "ACT-R:tutorial;unit8;paired-dynamic-model.lisp") (paired-experiment 2))'),
    "paired-learning": ("paired.lisp", '(progn (load-act-r-model "ACT-R:tutorial;unit7;paired-learning-model.lisp") (paired-experiment 2))'),
}

# The same tasks with :randomize-time t, :vpft t and :vidt t (models/rt/, made from the
# tutorial models by inserting that sgp).
for _n in ["bst", "sperling", "paired", "pm-issues", "demo2", "zbrodoff", "siegler", "subitize",
           "onehit", "unit2", "fan", "grouped", "mouse", "imaction"]:
    _f, _form = TASKS[_n]
    _m = os.path.join(os.path.dirname(os.path.abspath(__file__)), "models", "rt", _n + "-model.lisp")
    TASKS["rt-" + _n] = (_f, '(progn (load-act-r-model "%s") %s)' % (_m, _form))

# The same tasks with :auto-attend t (models/aa/).
for _n in ["demo2", "unit2", "subitize", "sperling", "bst", "zbrodoff"]:
    _f, _form = TASKS[_n]
    _m = os.path.join(os.path.dirname(os.path.abspath(__file__)), "models", "aa", _n + "-model.lisp")
    TASKS["aa-" + _n] = (_f, '(progn (load-act-r-model "%s") %s)' % (_m, _form))

# The same tasks with :viewing-distance 20 and :pixels-per-inch 96 (models/vd/).
for _n in ["bst", "zbrodoff", "subitize", "mouse"]:
    _f, _form = TASKS[_n]
    _m = os.path.join(os.path.dirname(os.path.abspath(__file__)), "models", "vd", _n + "-model.lisp")
    TASKS["vd-" + _n] = (_f, '(progn (load-act-r-model "%s") %s)' % (_m, _form))

# The same tasks with other audio and speech timing parameters (models/ap/).
for _n in ["sperling", "siegler", "paired"]:
    _f, _form = TASKS[_n]
    _m = os.path.join(os.path.dirname(os.path.abspath(__file__)), "models", "ap", _n + "-model.lisp")
    TASKS["ap-" + _n] = (_f, '(progn (load-act-r-model "%s") %s)' % (_m, _form))

# The same tasks with :overstuff-visual-location t and :overstuff-aural-location t (models/os/).
for _n in ["sperling", "subitize", "bst", "zbrodoff", "othersound", "siegler"]:
    _f, _form = TASKS[_n]
    _m = os.path.join(os.path.dirname(os.path.abspath(__file__)), "models", "os", _n + "-model.lisp")
    TASKS["os-" + _n] = (_f, '(progn (load-act-r-model "%s") %s)' % (_m, _form))

# The same tasks with each run replaced by run-n-events of 3 events per second asked for
# (tests the hidden events run-n-events counts).
for _n in ["sperling", "bst", "subitize", "siegler", "zbrodoff", "mouse"]:
    _f, _form = TASKS[_n]
    TASKS["ev-" + _n] = (_f, '(progn (sb-int:encapsulate (quote run) (quote events) (lambda (f time &rest args) (declare (ignore f args)) (run-n-events (max 1 (round (* 3 time)))))) %s)' % _form)

def canon(text, lisp=False):
    """Commands, queries and answers, calls of task commands, and inside runs the trace and
    !output! lines. Output of the task code itself (outside runs) is dropped: it is
    computed from the answers to its queries, which are compared."""
    out, inrun, incb = [], False, 0
    for l in strip_warnings(text.splitlines()):
        if not l.strip(): continue
        if l.startswith("#PCT") or l.startswith("#SIM ") or l.startswith("#RNG ") or l.startswith("#EVENTS "): continue
        if l.startswith("#CB "): incb += 1
        if l.startswith("#ENDCB"): incb -= 1
        if incb and l.startswith("#CMD "): continue
        if l.startswith("#"):
            if l.startswith("#CMD RUN"): inrun = True
            if l.startswith("#ENDRUN"): inrun = False
            if l.startswith("#ENDCB"): l = "#ENDCB"
            out.append(norm(l)); continue
        if not inrun: continue
        m = (TRACE if lisp else TRACE_LEAN).match(l)
        if m: out.append(norm("%s %s %s" % m.groups()))
        elif l.startswith("OUTPUT "): out.append(norm(l))
        else: out.append("OUTPUT " + norm(l))
    return out

def main():
    args = sys.argv[1:]
    verbose = "--verbose" in args
    names = [a for a in args if not a.startswith("--")] or list(TASKS)
    os.makedirs("/tmp/actr-tasks", exist_ok=True)
    for n in names:
        f, form = TASKS[n]
        rec = "/tmp/actr-tasks/%s.actr" % n
        p = subprocess.run(["sbcl", "--script", os.path.join(HERE, "task.lisp"), f if os.path.isabs(f) else os.path.join(T, f), form],
                           capture_output=True, text=True, timeout=3600)
        txt = p.stdout[p.stdout.find("#TASK"):]
        open(rec, "w").write(txt)
        lean = subprocess.run([LEAN, "--script", rec], capture_output=True, text=True).stdout
        open("/tmp/actr-tasks/%s.lean" % n, "w").write(lean)
        a, b = canon(txt, True), canon(lean)
        unsup = [l for l in b if l.startswith("#UNSUPPORTED")] + [l for l in a if l.startswith("#CMD UNSUPPORTED") or l.startswith("#ERROR")]
        runs = sum(1 for l in a if l.startswith("#CMD RUN"))
        if unsup:
            print("UNSUPPORTED %-12s %s" % (n, unsup[0][:200]))
            continue
        d = first_diff(a, b)
        if d is None:
            print("same        %-12s (%d runs, %d lines)" % (n, runs, len(a)))
        else:
            print("DIFFERENT   %-12s line %d of %d\n    ACT-R: %s\n    Lean:  %s" % (n, d[0], len(a), d[1], d[2]))

if __name__ == "__main__":
    main()
