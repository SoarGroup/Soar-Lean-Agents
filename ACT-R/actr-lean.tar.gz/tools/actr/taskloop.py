"""Compare ACT-R and actr-lean on one task run with many seeds.

usage: taskloop.py TASK-FILE FORM-TEMPLATE FIRST LAST
  FORM-TEMPLATE has {} where the seed goes, e.g. "(mouse-test {})".
"""
import os, subprocess, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from taskdiff import canon, first_diff
from diff import LEAN, HERE

def main():
    f, tmpl, a, b = sys.argv[1], sys.argv[2], int(sys.argv[3]), int(sys.argv[4])
    os.makedirs("/tmp/actr-loop", exist_ok=True)
    same = diff = uns = 0
    for seed in range(a, b + 1):
        form = tmpl.replace("{}", str(seed))
        p = subprocess.run(["sbcl", "--script", os.path.join(HERE, "task.lisp"), os.path.abspath(f), form],
                           capture_output=True, text=True, timeout=3600)
        txt = p.stdout[p.stdout.find("#TASK"):]
        rec = "/tmp/actr-loop/%d.actr" % seed
        open(rec, "w").write(txt)
        lean = subprocess.run([LEAN, "--script", rec], capture_output=True, text=True).stdout
        open("/tmp/actr-loop/%d.lean" % seed, "w").write(lean)
        x, y = canon(txt, True), canon(lean)
        u = [l for l in y if l.startswith("#UNSUPPORTED")] + [l for l in x if l.startswith("#CMD UNSUPPORTED") or l.startswith("#ERROR")]
        if u:
            uns += 1; print("UNSUPPORTED %d %s" % (seed, u[0][:150])); continue
        d = first_diff(x, y)
        if d is None: same += 1
        else:
            diff += 1
            print("DIFFERENT %d line %d\n    ACT-R: %s\n    Lean:  %s" % (seed, d[0], d[1], d[2]))
        sys.stdout.flush()
    print("== %d same, %d different, %d unsupported" % (same, diff, uns))

if __name__ == "__main__":
    main()
