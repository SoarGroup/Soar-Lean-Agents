import CMC.Meta
import ACTR.Run
/-!
# ACT-R and the Common Model of Cognition

This file maps the state of the ACT-R model onto the working memory of the CMC with
metacognition (`CMC.Meta`) and records, as theorems, where ACT-R keeps the CMC's commitments
and where it departs from them. It does not yet build a `CMC.Meta.Arch` instance: the first
departure below shows that ACT-R cannot satisfy `Arch.select_respects_arch` as stated.

Mapping (OPEN: every line is a proposal for review)
* goal and imaginal buffer chunks → the region (`CMC.Base`: "ACT-R calls its version the
  imaginal buffer; earlier versions had a goal buffer");
* the retrieval buffer's chunk → the result part of the declarative buffer;
* the retrieval buffer's query flags (busy, error, failure, requested) → the declarative
  buffer's process data;
* the goal and imaginal flags → working-memory process data;
* the cue part of the declarative buffer is always empty: an ACT-R request is handed to the
  module and is never visible to productions.

Findings for the CMC (see the theorems and the notes at the end)
1. Productions remove and modify retrieval results (`clear_removes_result`).
2. A retrieval cue is not held in working memory.
3. ACT-R has explicit time: retrieval and production firing have durations, and "busy" is
   visible to productions. The CMC has no time.
4. Declarative learning is one mechanism triggered by clearing any buffer, and it serves
   both creation and tuning; retrieval itself changes nothing (`request_dm`).
5. No declarative content is ever forgotten (`clearBuf_keeps_dm`).
-/

namespace ACTR.Conform
open CMC.Meta

/-- The CMC signature of the ACT-R modules modeled here: one declarative memory, no
perceptual or motor modules yet. -/
@[reducible] def σA : Sig where
  Sym := String
  Val := Float
  PMod := Empty
  MMod := Empty
  DMem := Unit
  Input := Unit
  PLearn := Unit
  MLearn := Unit
  Output := Unit
  MK := Fin 3
  utilityK := 0
  frequencyK := 1
  recencyK := 2
  epi := ()

/-- A chunk in a buffer as CMC relations: one relation per slot, `slot(buffer, value)`. -/
def encChunk (tag : String) (c : Option Chunk) : List (Elem σA) :=
  match c with
  | none => []
  | some c => c.slots.map fun p => ⟨⟨p.1, [tag, p.2.show]⟩, fun _ => none⟩

/-- A buffer's query flags as symbolic process data. -/
def encFlags (tag : String) (b : BufSt) : List (Elem σA) :=
  [("busy", b.busy), ("error", b.error), ("failure", b.failure), ("requested", b.requested)].filterMap
    fun p => if p.2 then some ⟨⟨p.1, [tag]⟩, fun _ => none⟩ else none

/-- The CMC working memory of an ACT-R state. -/
def enc (s : St) : WM σA
  | .region => encChunk "goal" (s.bufs .goal).chunk ++ encChunk "imaginal" (s.bufs .imaginal).chunk
  | .decl () .result => encChunk "retrieval" (s.bufs .retrieval).chunk
  | .decl () .process => encFlags "retrieval" (s.bufs .retrieval)
  | .wmProcess => encFlags "goal" (s.bufs .goal) ++ encFlags "imaginal" (s.bufs .imaginal)
  | _ => []

/-- **Departure 1: productions remove retrieval results.** Clearing the retrieval buffer,
which every production that tests it does by strict harvesting unless it modifies it, and
which `-retrieval>` and `+retrieval>` do explicitly, empties the result part of the
declarative buffer. `CMC.Base` requires that "only retrieval changes results"
(`select_respects_results`) and `CMC.Meta` that a deliberate act leaves every
architecture-written location unchanged (`select_respects_arch`). Soar departs from this by
adding to results; ACT-R departs by removing them (and, with `=retrieval>`, by modifying
them). -/
theorem clear_removes_result (s : St) (c : Chunk) (h : (s.bufs .retrieval).chunk = some c)
    (hne : c.slots ≠ []) :
    enc (clearBuf s .retrieval) (.decl () .result) ≠ enc s (.decl () .result) := by
  have h1 : enc (clearBuf s .retrieval) (.decl () .result) = [] := by
    simp [enc, encChunk, clearBuf_empty]
  have h2 : enc s (.decl () .result) ≠ [] := by
    simp [enc, encChunk, h, hne]
  rw [h1]; exact fun e => h2 e.symm

/-- The retrieval result is a location the CMC reserves for the architecture. -/
theorem result_is_arch_written : (Loc.decl () DPart.result : L σA).archWritten = true := rfl

/-- **Kept: clearing one buffer leaves the others alone.** In particular clearing the goal or
imaginal buffer never changes the retrieval result. -/
theorem clear_other_keeps_result (s : St) (b : Buf) (h : b ≠ .retrieval) :
    enc (clearBuf s b) (.decl () .result) = enc s (.decl () .result) := by
  simp [enc, clearBuf_other s b .retrieval (fun e => h e.symm)]

/-- **Kept: the cue area is never used.** (Finding 2.) -/
theorem cue_empty (s : St) : enc s (.decl () .cue) = [] := rfl

/-!
## Notes on the other findings

3. *Time.* `St.now`, the event queue, `:dat`, the retrieval-time equation and
   `:imaginal-delay` have no counterpart in `CMC.Meta.State`. The CMC's `cycleMs := 50` is
   an annotation; in ACT-R the 50 ms is the gap between `production-selected` and
   `production-fired`, during which other modules' events run. A CMC `cycle` step
   corresponds to the pair (conflict resolution, production fired), and a `retrieve` step to
   the pair (start-retrieval, retrieved-chunk) with other steps in between.
4. *Declarative learning.* `clearBuf` is the only place declarative memory changes. It adds
   a chunk (`declCreate`) or adds a reference to an existing chunk (`declTune`), and it is
   triggered by a procedural action or by a module, not by a separate learning step after
   the cycle. Retrieval does not touch the memory (`request_dm`), so `CMC.Meta`'s
   `retrieveTouch` is the identity for ACT-R: a retrieved chunk is strengthened only when it
   is later cleared from the buffer.
5. *Forgetting.* The CMC's `forgetDecl` step never applies: `forgettable` is constantly
   false for ACT-R. A chunk whose activation is below the threshold cannot be retrieved but
   is still in memory.
6. *Goals.* `CMC.Base` says goals are content, not architecture. In ACT-R 7 the goal buffer
   belongs to a goal module that accepts requests, and by default it spreads no activation
   (`:ga 0`), while the imaginal buffer does.
7. *Procedural learning.* Utility learning changes only `Production.u` (`applyReward`), as
   `rlTune_only_utility` requires. Production compilation (the CMC's `compose`) is not yet
   modeled.
-/

end ACTR.Conform
