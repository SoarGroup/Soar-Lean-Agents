/-!
# ACT-R 7 in Lean — chunks, buffers and the production language

Sources
* [RM] Bothell, D. *ACT-R 7.26+ Reference Manual* (docs/reference-manual.pdf in the ACT-R
  distribution). Section names refer to this manual.
* [Src] The ACT-R 7 Lisp sources (core-modules/declarative-memory.lisp,
  core-modules/procedural.lisp, …). Function names refer to these files.
* [Tut] The ACT-R tutorial, units 1–5 (tutorial/ in the distribution).

Conventions (as in the CMC and Soar files)
* `SIMPLIFIED:` marks a place where the model is deliberately coarser than ACT-R.
* `NOT MODELED:` marks a mechanism left out.
* `OPEN:` marks a question for review.

Scope of this first version: the goal, imaginal, declarative and procedural modules, the
utility module without production compilation, and the event schedule that connects them.
NOT MODELED: the perceptual and motor modules (vision, audio, motor, speech, temporal),
production compilation, `!eval!`/`!bind!` and other Lisp escapes, chunk types (ACT-R 7 does
not use them at run time), buffer-modification requests (`*buffer>`), overwrite actions
(`@buffer>`), request parameters such as `:recently-retrieved`, multiple models, and the
remote interface.
-/

namespace ACTR

/-- Point update of a function. -/
def upd {α β : Type} [DecidableEq α] (f : α → β) (a : α) (v : β) : α → β :=
  fun x => if x = a then v else f x

theorem upd_same {α β : Type} [DecidableEq α] (f : α → β) (a : α) (v : β) :
    upd f a v a = v := by simp [upd]

theorem upd_other {α β : Type} [DecidableEq α] (f : α → β) (a : α) (v : β) {x : α}
    (h : x ≠ a) : upd f a v x = f x := by simp [upd, h]

/-! ## Chunks -/

/-- A slot value: a symbol (which may name a chunk), a number or a string.
SIMPLIFIED: numbers are integers; ACT-R also allows floats and arbitrary Lisp values. -/
inductive Val where
  | sym (s : String)
  | num (n : Int)
  | str (s : String)
  deriving DecidableEq, Repr, Inhabited

def Val.show : Val → String
  | .sym s => s
  | .num n => toString n
  | .str s => "\"" ++ s ++ "\""

abbrev Slot := String

/-- A chunk: a set of slots with values. A slot whose value is `nil` does not exist
([RM] "Chunks": "a slot with a value of nil is the same as not having that slot").
Invariant maintained by `Chunk.set`: no slot occurs twice. -/
structure Chunk where
  slots : List (Slot × Val)
  deriving DecidableEq, Repr, Inhabited

namespace Chunk

def get (c : Chunk) (s : Slot) : Option Val := c.slots.lookup s

/-- Set a slot; `none` removes it. -/
def set (c : Chunk) (s : Slot) (v : Option Val) : Chunk :=
  let rest := c.slots.filter (fun p => p.1 != s)
  match v with
  | none => ⟨rest⟩
  | some v => ⟨rest ++ [(s, v)]⟩

def sub (a b : Chunk) : Bool := a.slots.all (fun p => b.get p.1 == some p.2)

/-- Two chunks are equivalent when they have the same slots with the same values; this is
the test used when a cleared chunk is merged into declarative memory ([Src] `equal-chunks`). -/
def equiv (a b : Chunk) : Bool := a.sub b && b.sub a

end Chunk

/-! ## Buffers and queries -/

/-- The buffers of the modules modeled here. -/
inductive Buf where
  | goal | imaginal | retrieval
  deriving DecidableEq, Repr

def Buf.name : Buf → String
  | .goal => "GOAL" | .imaginal => "IMAGINAL" | .retrieval => "RETRIEVAL"

/-- A buffer holds at most one chunk ([RM] "Buffers"), plus the flags that queries read. The
`busy` and `error` flags belong to the buffer's module; they are kept here because each
modeled module has one buffer. -/
structure BufSt where
  chunk : Option Chunk := none
  /-- `buffer failure`: the last request to this buffer failed. -/
  failure : Bool := false
  /-- `buffer requested`: the chunk was placed by a request. -/
  requested : Bool := false
  /-- `state busy`: the module is working on a request. -/
  busy : Bool := false
  /-- `state error`: the module's last request failed. -/
  error : Bool := false
  deriving Repr, Inhabited

/-- The queries every buffer answers ([RM] "Queries"). -/
inductive Query where
  | bufferFull | bufferEmpty | bufferFailure | bufferRequested | bufferUnrequested
  | stateFree | stateBusy | stateError
  deriving DecidableEq, Repr

def queryHolds (b : BufSt) : Query → Bool
  | .bufferFull => b.chunk.isSome
  | .bufferEmpty => b.chunk.isNone && !b.failure
  | .bufferFailure => b.failure
  | .bufferRequested => b.chunk.isSome && b.requested
  | .bufferUnrequested => b.chunk.isSome && !b.requested
  | .stateFree => !b.busy
  | .stateBusy => b.busy
  | .stateError => b.error

/-! ## Productions -/

inductive Term where
  | const (v : Val)
  | var (x : String)
  deriving DecidableEq, Repr

/-- Slot modifiers ([RM] "p": `=` is the default, then `-`, `<`, `>`, `<=`, `>=`). -/
inductive Cmp where
  | eq | ne | lt | gt | le | ge
  deriving DecidableEq, Repr

/-- One slot test or slot specification. `arg := none` stands for `nil`. -/
structure SlotTest where
  cmp : Cmp := .eq
  slot : Slot
  arg : Option Term
  deriving Repr

/-- A condition: a buffer test (`=buffer>`) or a query (`?buffer>`, negated with `-`). -/
inductive Cond where
  | buf (b : Buf) (tests : List SlotTest)
  | query (b : Buf) (q : Query) (neg : Bool := false)
  deriving Repr

/-- An action. -/
inductive Action where
  /-- `=buffer>`: modify the chunk in the buffer. -/
  | modify (b : Buf) (sets : List (Slot × Option Term))
  /-- `+buffer>`: a request to the buffer's module. -/
  | request (b : Buf) (spec : List SlotTest)
  /-- `-buffer>`: clear the buffer. -/
  | clear (b : Buf)
  /-- `!output!`. -/
  | output (ts : List Term)
  /-- `!stop!`. -/
  | stop
  deriving Repr

structure Production where
  name : String
  lhs : List Cond
  rhs : List Action
  /-- Utility ([RM] "Utility": `spp :u`). -/
  u : Float := 0.0
  /-- Reward triggered when the production fires (`spp :reward`). -/
  reward : Option Float := none
  deriving Repr

abbrev Env := List (String × Val)

/-- A slot test with its variables replaced by values. -/
structure ITest where
  cmp : Cmp
  slot : Slot
  arg : Option Val
  deriving Repr

def cmpVal : Cmp → Val → Val → Bool
  | .eq, a, b => a == b
  | .ne, a, b => a != b
  | .lt, .num a, .num b => a < b
  | .gt, .num a, .num b => a > b
  | .le, .num a, .num b => a ≤ b
  | .ge, .num a, .num b => a ≥ b
  | _, _, _ => false

/-- Whether a chunk passes an instantiated slot test. A test against `nil` is a test that
the slot is absent (`=`) or present (`-`); a negated test of a value holds when the slot is
absent ([RM] "p", slot tests). -/
def ITest.holds (c : Chunk) (t : ITest) : Bool :=
  match t.arg, c.get t.slot with
  | none, none => t.cmp == .eq
  | none, some _ => t.cmp == .ne
  | some _, none => t.cmp == .ne
  | some v, some w => cmpVal t.cmp w v

def SlotTest.inst (env : Env) (t : SlotTest) : Option ITest :=
  match t.arg with
  | none => some ⟨t.cmp, t.slot, none⟩
  | some (.const v) => some ⟨t.cmp, t.slot, some v⟩
  | some (.var x) => (env.lookup x).map fun v => ⟨t.cmp, t.slot, some v⟩

/-- Bind the variables that occur in `=` tests of a buffer's chunk. A variable can only be
bound to a slot that exists ([RM] "p": "a variable cannot bind to nil"). -/
def bindTests (c : Chunk) : Env → List SlotTest → Option Env
  | env, [] => some env
  | env, t :: ts =>
    match t.cmp, t.arg with
    | .eq, some (.var x) =>
      match env.lookup x with
      | some _ => bindTests c env ts
      | none =>
        match c.get t.slot with
        | some v => bindTests c ((x, v) :: env) ts
        | none => none
    | _, _ => bindTests c env ts

/-- Match a production against the buffers: bind variables, then check every test and query.
The result depends on the buffers only: productions cannot test declarative memory, numeric
parameters or the event queue. -/
def matchProd (bufs : Buf → BufSt) (p : Production) : Option Env :=
  let env? := p.lhs.foldl (fun acc c =>
    match acc, c with
    | some env, .buf b ts =>
      (match (bufs b).chunk with
       | some ch => bindTests ch env ts
       | none => none)
    | acc, _ => acc) (some [])
  match env? with
  | none => none
  | some env =>
    if p.lhs.all (fun c =>
        match c with
        | .buf b ts =>
          (match (bufs b).chunk with
           | some ch => ts.all (fun t =>
               match t.inst env with
               | some it => it.holds ch
               | none => false)
           | none => false)
        | .query b q neg => queryHolds (bufs b) q != neg)
    then some env else none

end ACTR
