import ACTR.Core
/-!
# ACT-R 7 in Lean — declarative memory

[RM] "Declarative module": merging of cleared chunks, the activation equation
`A_i = B_i + S_i + P_i + ε_i`, the retrieval threshold and retrieval time.
-/

namespace ACTR

/-- The parameters used by the modeled modules, with ACT-R's default values ([RM] parameter
sections of the declarative, procedural, utility, goal and imaginal modules). -/
structure Params where
  /-- `:esc` enable subsymbolic computations. -/
  esc : Bool := false
  /-- `:dat` default action time, ms. -/
  dat : Nat := 50
  /-- `:bll` base-level learning decay (`nil` = off). -/
  bll : Option Float := none
  /-- `:blc` base-level constant. -/
  blc : Float := 0.0
  /-- `:mas` maximum associative strength (`nil` = no spreading activation). -/
  mas : Option Float := none
  /-- `:ga` source activation of the goal buffer (default 0 in ACT-R 7). -/
  ga : Float := 0.0
  /-- `:imaginal-activation` source activation of the imaginal buffer. -/
  imaginalActivation : Float := 1.0
  /-- `:rt` retrieval threshold. -/
  rt : Float := 0.0
  /-- `:lf` latency factor. -/
  lf : Float := 1.0
  /-- `:le` latency exponent. -/
  le : Float := 1.0
  /-- `:mp` mismatch penalty (`nil` = no partial matching). -/
  mp : Option Float := none
  /-- `:md` maximum difference, `:ms` maximum similarity. -/
  md : Float := -1.0
  ms : Float := 0.0
  /-- Activation noise (`:ans`). SIMPLIFIED: ACT-R draws from a logistic distribution with
  its random-number generator; here the sample for a chunk at a time is a parameter. -/
  ansNoise : String → Nat → Float := fun _ _ => 0.0
  /-- Utility noise (`:egs`), with the same simplification. -/
  egsNoise : String → Nat → Float := fun _ _ => 0.0
  /-- `:ul` utility learning, `:alpha` its learning rate. -/
  ul : Bool := false
  alpha : Float := 0.2
  /-- `:imaginal-delay`, ms. -/
  imaginalDelay : Nat := 200
  /-- `:do-not-harvest` buffers exempt from strict harvesting. -/
  doNotHarvest : List Buf := []

/-- A chunk in declarative memory with its numeric parameters: the times (ms) at which it
was referenced and the time it entered memory. -/
structure DMEntry where
  name : String
  chunk : Chunk
  refs : List Nat
  created : Nat
  deriving Repr, Inhabited

/-- Merge a cleared chunk into declarative memory ([RM] "Declarative Memory"; [Src]
`merge-chunk-into-dm`): if an equivalent chunk is there it gets another reference at the
current time; otherwise the chunk is added with one reference. -/
def mergeDM (c : Chunk) (now : Nat) (nm : String) : List DMEntry → List DMEntry
  | [] => [⟨nm, c, [now], now⟩]
  | e :: es =>
    if e.chunk.equiv c then { e with refs := now :: e.refs } :: es
    else e :: mergeDM c now nm es

/-- Base-level activation ([RM] "Base-level"; [Src] `base-level-activation`,
`compute-references`): `B_i = ln(Σ_j t_j^(-d)) + β` with `:bll`, the constant `β` without.
Times are in seconds, and a reference less than 50 ms old counts as 50 ms old, as in
`compute-references`. NOT MODELED: optimized learning (`:ol`); this is the `:ol nil` formula. -/
def baseLevel (P : Params) (now : Nat) (e : DMEntry) : Float :=
  match P.bll with
  | none => P.blc
  | some d =>
    let s := e.refs.foldl (fun acc t =>
      acc + Float.pow (Float.ofNat (max 50 (now - t)) / 1000.0) (-d)) 0.0
    Float.log s + P.blc

/-- `fan_j`: one, plus the number of slots in declarative memory that hold chunk `j`
([Src] `chunk-fan-out`). -/
def fanOut (dm : List DMEntry) (j : String) : Nat :=
  1 + dm.foldl (fun n e => n + (e.chunk.slots.filter (fun p => p.2 == .sym j)).length) 0

/-- How often `j` occurs in `i`: its slots holding `j`, plus one if `i` is `j` itself. -/
def countIn (j : String) (i : DMEntry) : Nat :=
  (i.chunk.slots.filter (fun p => p.2 == .sym j)).length + (if i.name == j then 1 else 0)

/-- Strength of association ([RM] "Spreading activation"; [Src] `compute-sji`,
`chunk-fan-j-to-i`): `S_ji = S − ln(fan_j / count)` when `j` occurs in `i`, otherwise 0. A
negative value is replaced by 0, the default `:nsji` behaviour. -/
def sji (S : Float) (dm : List DMEntry) (j : String) (i : DMEntry) : Float :=
  let n := countIn j i
  if n == 0 then 0.0
  else
    let v := S - Float.log (Float.ofNat (fanOut dm j) / Float.ofNat n)
    if v < 0.0 then 0.0 else v

/-- Spreading activation ([Src] `spreading-activation`): each source buffer divides its
source activation equally among the slots of its chunk that hold chunks.
SIMPLIFIED: a slot value counts as a chunk only when it names a chunk in declarative memory. -/
def spreading (P : Params) (sources : List (Chunk × Float)) (dm : List DMEntry)
    (i : DMEntry) : Float :=
  match P.mas with
  | none => 0.0
  | some S =>
    sources.foldl (fun acc (src : Chunk × Float) =>
      let js := src.1.slots.filterMap (fun p =>
        match p.2 with
        | .sym n => if dm.any (fun e => e.name == n) then some n else none
        | _ => none)
      if js.isEmpty || src.2 == 0.0 then acc
      else
        let w := src.2 / Float.ofNat js.length
        js.foldl (fun a j => a + w * sji S dm j i) acc) 0.0

/-- Similarity of two values: `:ms` when equal, `:md` otherwise ([RM] "Partial matching").
NOT MODELED: similarities set with `set-similarities`. -/
def similarity (P : Params) (a b : Val) : Float := if a == b then P.ms else P.md

/-- Partial-matching component: for each `=` test of a value, the mismatch penalty times
the similarity between the requested and the actual value. -/
def partialMatch (P : Params) (spec : List ITest) (i : DMEntry) : Float :=
  match P.mp with
  | none => 0.0
  | some mp =>
    spec.foldl (fun acc t =>
      match t.cmp, t.arg, i.chunk.get t.slot with
      | .eq, some v, some w => acc + mp * similarity P v w
      | _, _, _ => acc) 0.0

/-- Whether a chunk is a candidate for a request. Without partial matching it must pass
every test. With partial matching an `=` test of a value only requires the slot to exist. -/
def candidate (P : Params) (spec : List ITest) (i : DMEntry) : Bool :=
  match P.mp with
  | none => spec.all (·.holds i.chunk)
  | some _ => spec.all (fun t =>
      match t.cmp, t.arg with
      | .eq, some _ => (i.chunk.get t.slot).isSome
      | _, _ => t.holds i.chunk)

/-- The activation equation `A_i = B_i + S_i + P_i + ε_i` ([RM] "Activation"). -/
def activation (P : Params) (now : Nat) (sources : List (Chunk × Float)) (dm : List DMEntry)
    (spec : List ITest) (i : DMEntry) : Float :=
  baseLevel P now i + spreading P sources dm i + partialMatch P spec i + P.ansNoise i.name now

/-- The first element with the largest score. -/
def argmax {α : Type} (xs : List (α × Float)) : Option (α × Float) :=
  xs.foldl (fun best x =>
    match best with
    | none => some x
    | some b => if x.2 > b.2 then some x else some b) none

/-- Seconds to whole milliseconds (ACT-R keeps time in milliseconds). -/
def toMs (x : Float) : Nat := (Float.round (x * 1000.0)).toUInt64.toNat

/-- A retrieval ([RM] "Declarative Memory", "Retrieval time"; [Src] `start-retrieval`):
the chunk retrieved, if any, and the time the request takes in ms.
* `:esc nil`: a matching chunk is retrieved immediately.
* `:esc t`: the matching chunk with the highest activation is retrieved if that activation
  reaches the threshold, after `F·e^(−f·A)`; otherwise the request fails after `F·e^(−f·τ)`.
SIMPLIFIED: among equally good chunks the first in memory order is taken; ACT-R leaves the
deterministic choice (`:er nil`) unspecified and chooses randomly with `:er t`. -/
def retrieve (P : Params) (now : Nat) (sources : List (Chunk × Float)) (dm : List DMEntry)
    (spec : List ITest) : Option DMEntry × Nat :=
  let cands := dm.filter (candidate P spec)
  if !P.esc then (cands.head?, 0)
  else
    let failT := toMs (P.lf * Float.exp (-(P.le * P.rt)))
    match argmax (cands.map fun e => (e, activation P now sources dm spec e)) with
    | some (e, a) =>
      if a ≥ P.rt then (some e, toMs (P.lf * Float.exp (-(P.le * a)))) else (none, failT)
    | none => (none, failT)

/-! ## Properties -/

/-- Merging never shrinks declarative memory. -/
theorem mergeDM_length (c : Chunk) (now : Nat) (nm : String) (dm : List DMEntry) :
    dm.length ≤ (mergeDM c now nm dm).length := by
  induction dm with
  | nil => simp [mergeDM]
  | cons e es ih =>
    simp only [mergeDM]
    split <;> simp_all

/-- **No chunk is ever lost from declarative memory.** Merging keeps the symbolic content
of every chunk already there; only reference lists change. ACT-R has no forgetting of
declarative content: decay lowers activation, it does not remove chunks. -/
theorem mergeDM_keeps (c : Chunk) (now : Nat) (nm : String) (dm : List DMEntry) :
    ∀ ch, ch ∈ dm.map DMEntry.chunk → ch ∈ (mergeDM c now nm dm).map DMEntry.chunk := by
  induction dm with
  | nil => intro ch h; simp at h
  | cons e es ih =>
    intro ch h
    simp only [mergeDM]
    split
    · simpa using h
    · simp only [List.map_cons, List.mem_cons] at h ⊢
      rcases h with h | h
      · exact Or.inl h
      · exact Or.inr (ih ch h)

end ACTR
