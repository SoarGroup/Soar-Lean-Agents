import ACTR.Run
/-!
# Tutorial models as tests

The count and semantic models of tutorial unit 1, written directly as Lean data, with the
traces printed in the tutorial text as `#guard` checks. A parser for ACT-R model files is
not yet written.
-/

namespace ACTR.Examples
open ACTR

def s (x : String) : Val := .sym x
def v (x : String) : Option Term := some (.var x)
def c (x : String) : Option Term := some (.const (.sym x))

/-! # The count model (tutorial/unit1/count.lisp) -/

def number (n next : String) : String × Chunk :=
  (n.toUpper, ⟨[("number", s n)] ++ (if next == "" then [] else [("next", s next)])⟩)

def countDM : List (String × Chunk) :=
  [number "one" "two", number "two" "three", number "three" "four", number "four" "five",
   number "five" ""]

def start : Production :=
  { name := "START"
    lhs := [.buf .goal [⟨.eq, "start", v "num1"⟩, ⟨.eq, "count", none⟩]]
    rhs := [.modify .goal [("count", v "num1")],
            .request .retrieval [⟨.eq, "number", v "num1"⟩]] }

def increment : Production :=
  { name := "INCREMENT"
    lhs := [.buf .goal [⟨.eq, "count", v "num1"⟩, ⟨.ne, "end", v "num1"⟩],
            .buf .retrieval [⟨.eq, "number", v "num1"⟩, ⟨.eq, "next", v "num2"⟩]]
    rhs := [.modify .goal [("count", v "num2")],
            .request .retrieval [⟨.eq, "number", v "num2"⟩],
            .output [.var "num1"]] }

def stop : Production :=
  { name := "STOP"
    lhs := [.buf .goal [⟨.eq, "count", v "num"⟩, ⟨.eq, "end", v "num"⟩],
            .buf .retrieval [⟨.eq, "number", v "num"⟩]]
    rhs := [.clear .goal, .output [.var "num"]] }

/-- `(sgp :esc t :lf .05)`. -/
def countParams : Params := { esc := true, lf := 0.05 }

def countModel : St :=
  St.init [start, increment, stop] countDM (some ⟨[("start", s "two"), ("end", s "four")]⟩)

def showTrace (st : St) : List String :=
  st.trace.reverse.map fun p =>
    let ms := p.1
    s!"{ms / 1000}.{(toString (1000 + ms % 1000)).drop 1}  {p.2}"

def countFinal : St := run countParams 100 countModel
def countTrace : List String := showTrace countFinal

-- The events of the trace in [Tut] unit 1, section 1.6.
#guard countTrace ==
  ["0.000  PRODUCTION-SELECTED START", "0.050  PRODUCTION-FIRED START", "0.050  START-RETRIEVAL",
   "0.100  RETRIEVED-CHUNK TWO", "0.100  PRODUCTION-SELECTED INCREMENT",
   "0.150  PRODUCTION-FIRED INCREMENT", "0.150  OUTPUT two", "0.150  START-RETRIEVAL",
   "0.200  RETRIEVED-CHUNK THREE", "0.200  PRODUCTION-SELECTED INCREMENT",
   "0.250  PRODUCTION-FIRED INCREMENT", "0.250  OUTPUT three", "0.250  START-RETRIEVAL",
   "0.300  RETRIEVED-CHUNK FOUR", "0.300  PRODUCTION-SELECTED STOP",
   "0.350  PRODUCTION-FIRED STOP", "0.350  OUTPUT four"]

-- Declarative memory at the end: retrieved chunks gained a reference when they were cleared
-- from the retrieval buffer, and the cleared goal chunk was added.
#guard (countFinal.dm.map fun e => (e.name, e.refs)) ==
  [("ONE", [0]), ("TWO", [150, 0]), ("THREE", [250, 0]), ("FOUR", [350, 0]), ("FIVE", [0]),
   ("GOAL-CHUNK2", [350])]

-- Base-level learning: one reference 10 s ago with d = 0.5 gives ln(10^-0.5) = -1.1513.
#guard Float.abs (baseLevel { bll := some 0.5 } 10000 ⟨"X", ⟨[]⟩, [0], 0⟩ + 1.151293) < 0.00001

/-! # The semantic model of tutorial unit 1 (tutorial/unit1/semantic.lisp) -/

def prop (n obj attr val : String) : String × Chunk :=
  (n, ⟨[("object", s obj), ("attribute", s attr), ("value", s val)]⟩)

def semanticDM : List (String × Chunk) :=
  [prop "P1" "shark" "dangerous" "true", prop "P2" "shark" "locomotion" "swimming",
   prop "P3" "shark" "category" "fish", prop "P4" "salmon" "edible" "true",
   prop "P5" "salmon" "locomotion" "swimming", prop "P6" "salmon" "category" "fish",
   prop "P7" "fish" "breathe" "gills", prop "P8" "fish" "locomotion" "swimming",
   prop "P9" "fish" "category" "animal", prop "P10" "animal" "moves" "true",
   prop "P11" "animal" "skin" "true", prop "P12" "canary" "color" "yellow",
   prop "P13" "canary" "sings" "true", prop "P14" "canary" "category" "bird",
   prop "P15" "ostrich" "flies" "false", prop "P16" "ostrich" "height" "tall",
   prop "P17" "ostrich" "category" "bird", prop "P18" "bird" "wings" "true",
   prop "P19" "bird" "locomotion" "flying", prop "P20" "bird" "category" "animal"]

def initialRetrieve : Production :=
  { name := "INITIAL-RETRIEVE"
    lhs := [.buf .goal [⟨.eq, "object", v "obj"⟩, ⟨.eq, "category", v "cat"⟩, ⟨.eq, "judgment", none⟩]]
    rhs := [.modify .goal [("judgment", c "pending")],
            .request .retrieval [⟨.eq, "object", v "obj"⟩, ⟨.eq, "attribute", c "category"⟩]] }

def directVerify : Production :=
  { name := "DIRECT-VERIFY"
    lhs := [.buf .goal [⟨.eq, "object", v "obj"⟩, ⟨.eq, "category", v "cat"⟩, ⟨.eq, "judgment", c "pending"⟩],
            .buf .retrieval [⟨.eq, "object", v "obj"⟩, ⟨.eq, "attribute", c "category"⟩, ⟨.eq, "value", v "cat"⟩]]
    rhs := [.modify .goal [("judgment", c "yes")]] }

def chainCategory : Production :=
  { name := "CHAIN-CATEGORY"
    lhs := [.buf .goal [⟨.eq, "object", v "obj1"⟩, ⟨.eq, "category", v "cat"⟩, ⟨.eq, "judgment", c "pending"⟩],
            .buf .retrieval [⟨.eq, "object", v "obj1"⟩, ⟨.eq, "attribute", c "category"⟩,
                             ⟨.eq, "value", v "obj2"⟩, ⟨.ne, "value", v "cat"⟩]]
    rhs := [.modify .goal [("object", v "obj2")],
            .request .retrieval [⟨.eq, "object", v "obj2"⟩, ⟨.eq, "attribute", c "category"⟩]] }

def fail : Production :=
  { name := "FAIL"
    lhs := [.buf .goal [⟨.eq, "object", v "obj1"⟩, ⟨.eq, "category", v "cat"⟩, ⟨.eq, "judgment", c "pending"⟩],
            .query .retrieval .bufferFailure]
    rhs := [.modify .goal [("judgment", c "no")]] }

/-- The main events of a run of the semantic model for "is a canary a `cat`?". -/
def semantic (cat : String) : List String :=
  let st := run { esc := true, lf := 0.05 } 100
    (St.init [initialRetrieve, directVerify, chainCategory, fail] semanticDM
      (some ⟨[("object", s "canary"), ("category", s cat)]⟩))
  (showTrace st).filter fun l =>
    (l.splitOn "FIRED").length > 1 || (l.splitOn "  RETRIEV").length > 1

-- [Tut] unit 1, sections 1.7.2 to 1.7.4: goals g1, g2 and g3.
#guard semantic "bird" ==
  ["0.050  PRODUCTION-FIRED INITIAL-RETRIEVE", "0.100  RETRIEVED-CHUNK P14",
   "0.150  PRODUCTION-FIRED DIRECT-VERIFY"]
#guard semantic "animal" ==
  ["0.050  PRODUCTION-FIRED INITIAL-RETRIEVE", "0.100  RETRIEVED-CHUNK P14",
   "0.150  PRODUCTION-FIRED CHAIN-CATEGORY", "0.200  RETRIEVED-CHUNK P20",
   "0.250  PRODUCTION-FIRED DIRECT-VERIFY"]
#guard semantic "fish" ==
  ["0.050  PRODUCTION-FIRED INITIAL-RETRIEVE", "0.100  RETRIEVED-CHUNK P14",
   "0.150  PRODUCTION-FIRED CHAIN-CATEGORY", "0.200  RETRIEVED-CHUNK P20",
   "0.250  PRODUCTION-FIRED CHAIN-CATEGORY", "0.300  RETRIEVAL-FAILURE",
   "0.350  PRODUCTION-FIRED FAIL"]

end ACTR.Examples
