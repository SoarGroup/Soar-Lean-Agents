# ACT-R 7 on the CMC in Lean — first version (2026-11-11)

Add `ACTR/`, `ACTR.lean` and the `lean_lib ACTR` line of `lakefile.lean` to the cmcsoar project,
then `lake build ACTR` (Lean 4.35.0, core library only). No `sorry`, standard axioms only.

Sources: ACT-R 7 Lisp code and reference manual ("ACT-R 7.26+", July 2022) from the GitHub
mirror asmaloney/ACT-R. The CMU site lists a newer release; it was not reachable from the
build environment.

- `Core.lean` — chunks, buffers, queries, productions, matching.
- `Declarative.lean` — merging, activation (base-level, spreading, partial matching), retrieval.
- `Run.lean` — goal and imaginal requests, production firing, strict harvesting, conflict
  resolution, utility learning, the event schedule; properties.
- `Conform.lean` — mapping onto `CMC.Meta` and the findings for the CMC.
- `Examples.lean` — the count and semantic models of tutorial unit 1, checked against the
  traces printed in the tutorial.

Not modeled yet: perceptual and motor modules, production compilation, Lisp escapes, a parser
for model files, optimized learning, random noise and random tie-breaking. Not yet compared
with a running ACT-R.
