import ACTR.Declarative
/-!
# ACT-R 7 in Lean — the procedural module and the event schedule

[RM] "Procedural module" (conflict resolution, the `p` command, implicit clearing actions),
"Utility module", "Goal module", "Imaginal module", and "Scheduling events".

ACT-R is a discrete-event system: modules schedule events at times in milliseconds and the
scheduler runs them in order. This file models the events of the four cognitive modules.

SIMPLIFIED: the actions of a production are applied in one step at the production-fired
event, in the order ACT-R's event priorities give them: buffer modifications, then all
clearing (request clearing, explicit clears, strict harvesting), then the module requests.
ACT-R schedules each as its own event at the same time; no production can be selected
between them, because conflict resolution has the lowest priority.
-/

namespace ACTR

inductive Event where
  /-- `conflict-resolution`. -/
  | cr
  /-- `production-fired`: the production, its bindings and its selection time. -/
  | fire (p : Production) (env : Env) (selAt : Nat)
  /-- The declarative module finishes a request (`retrieved-chunk` or `retrieval-failure`). -/
  | retrieved (r : Option DMEntry) (id : Nat)
  /-- The imaginal module finishes creating a chunk. -/
  | imaginalSet (c : Chunk) (id : Nat)

def Event.isCR : Event → Bool
  | .cr => true
  | _ => false

/-- The state of a model. -/
structure St where
  /-- Current time, ms. -/
  now : Nat := 0
  bufs : Buf → BufSt := fun _ => {}
  dm : List DMEntry := []
  prods : List Production := []
  /-- Scheduled events in the order they will run. -/
  queue : List (Nat × Event) := []
  /-- Counter for naming new chunks in declarative memory. -/
  nextName : Nat := 0
  /-- Identifies the current retrieval and imaginal requests; a finished request with an
  older number was superseded and is ignored. -/
  retrId : Nat := 0
  imId : Nat := 0
  /-- Productions selected since the last reward, with their selection times
  ([RM] `trigger-reward`). -/
  used : List (String × Nat) := []
  stopped : Bool := false
  /-- Trace, most recent first. -/
  trace : List (Nat × String) := []

/-- Insert an event: after the events already scheduled for the same time, except that
conflict resolution runs after every other event of its time ([RM] "Conflict Resolution":
its events have the lowest priority). -/
def insertEv (t : Nat) (e : Event) : List (Nat × Event) → List (Nat × Event)
  | [] => [(t, e)]
  | (t', e') :: q =>
    if t' < t || (t' == t && (e.isCR || !e'.isCR)) then (t', e') :: insertEv t e q
    else (t, e) :: (t', e') :: q

def St.sched (s : St) (t : Nat) (e : Event) : St := { s with queue := insertEv t e s.queue }

/-- At most one conflict-resolution event is pending. -/
def St.schedCR (s : St) (t : Nat) : St :=
  if s.queue.any (·.2.isCR) then s else s.sched t .cr

def St.log (s : St) (m : String) : St := { s with trace := (s.now, m) :: s.trace }

def St.setBuf (s : St) (b : Buf) (f : BufSt → BufSt) : St :=
  { s with bufs := upd s.bufs b (f (s.bufs b)) }

/-- Clear a buffer ([RM] "Buffers", `clear-buffer`): its chunk, if any, is merged into
declarative memory, and the buffer's failure and requested flags are reset. Chunks cleared
from *any* buffer enter declarative memory, not only retrieved ones. -/
def clearBuf (s : St) (b : Buf) : St :=
  match (s.bufs b).chunk with
  | none => s.setBuf b fun st => { st with failure := false, requested := false }
  | some c =>
    { s with
      bufs := upd s.bufs b { (s.bufs b) with chunk := none, failure := false, requested := false }
      dm := mergeDM c s.now (b.name ++ "-CHUNK" ++ toString s.nextName) s.dm
      nextName := s.nextName + 1 }

/-- The chunk a goal or imaginal request describes: its `=` slots. -/
def chunkOfSpec (spec : List ITest) : Chunk :=
  spec.foldl (fun c t => if t.cmp == .eq then c.set t.slot t.arg else c) ⟨[]⟩

/-- The buffers that spread activation, with their source activations. -/
def sources (P : Params) (s : St) : List (Chunk × Float) :=
  [(Buf.goal, P.ga), (Buf.imaginal, P.imaginalActivation)].filterMap fun p =>
    (s.bufs p.1).chunk.map fun c => (c, p.2)

/-- A module request (`+buffer>`), made after the buffer was cleared.
* goal ([RM] "Goal module"): a new chunk is placed in the buffer at once.
* imaginal ([RM] "Imaginal module"): the module is busy for `:imaginal-delay`, then the new
  chunk is placed in the buffer.
* retrieval: the declarative module becomes busy and its error state is reset; the outcome
  is computed now and delivered after the retrieval time. A new request supersedes one still
  in progress. -/
def request (P : Params) (s : St) (b : Buf) (spec : List ITest) : St :=
  match b with
  | .goal => s.setBuf .goal fun st => { st with chunk := some (chunkOfSpec spec), requested := true }
  | .imaginal =>
    let s := s.setBuf .imaginal fun st => { st with busy := true, error := false }
    { s with imId := s.imId + 1 }.sched (s.now + P.imaginalDelay)
      (.imaginalSet (chunkOfSpec spec) (s.imId + 1))
  | .retrieval =>
    let r := retrieve P s.now (sources P s) s.dm spec
    let s := s.setBuf .retrieval fun st => { st with busy := true, error := false }
    ({ s with retrId := s.retrId + 1 }.log "START-RETRIEVAL").sched (s.now + r.2)
      (.retrieved r.1 (s.retrId + 1))

def termVal (env : Env) : Term → Option Val
  | .const v => some v
  | .var x => env.lookup x

/-- The buffers a production clears implicitly or explicitly ([RM] "Implicit production
clearing actions"): every buffer with a request, every explicit clear, and (strict
harvesting) every buffer tested on the left-hand side and not modified on the right, unless
it is in `:do-not-harvest`. -/
def clearedBufs (P : Params) (p : Production) : List Buf :=
  let req := p.rhs.filterMap fun a => match a with | .request b _ => some b | _ => none
  let exp := p.rhs.filterMap fun a => match a with | .clear b => some b | _ => none
  let mods := p.rhs.filterMap fun a => match a with | .modify b _ => some b | _ => none
  let lhs := p.lhs.filterMap fun c => match c with | .buf b _ => some b | _ => none
  let harvest := lhs.filter fun b => !mods.contains b && !P.doNotHarvest.contains b
  (req ++ exp ++ harvest).eraseDups

/-- Utility learning when a reward is triggered ([RM] "Utility", `trigger-reward`):
`U ← U + α (R − Δt − U)` for every production selected since the last reward, where `Δt` is
the time in seconds since that selection. -/
def applyReward (P : Params) (s : St) (r : Float) : St :=
  let prods := s.used.reverse.foldl (fun (ps : List Production) (u : String × Nat) =>
    ps.map fun p =>
      if p.name == u.1 then
        { p with u := p.u + P.alpha * (r - Float.ofNat (s.now - u.2) / 1000.0 - p.u) }
      else p) s.prods
  { s with prods := prods, used := [] }

/-- The production-fired event. -/
def fire (P : Params) (s : St) (p : Production) (env : Env) (selAt : Nat) : St :=
  let s := s.log ("PRODUCTION-FIRED " ++ p.name)
  let s := { s with used := (p.name, selAt) :: s.used }
  -- buffer modifications
  let s := p.rhs.foldl (fun s a =>
    match a with
    | .modify b sets =>
      s.setBuf b fun st =>
        { st with chunk := st.chunk.map fun c =>
            sets.foldl (fun c (sv : Slot × Option Term) => c.set sv.1 (sv.2.bind (termVal env))) c }
    | .output ts =>
      s.log ("OUTPUT " ++ " ".intercalate (ts.map fun t =>
        match termVal env t with | some v => v.show | none => "?"))
    | _ => s) s
  -- clearing
  let s := (clearedBufs P p).foldl clearBuf s
  -- module requests
  let s := p.rhs.foldl (fun s a =>
    match a with
    | .request b spec => request P s b (spec.filterMap (·.inst env))
    | _ => s) s
  -- reward
  let s := match p.reward with
    | some r => if P.ul then applyReward P s r else s
    | none => s
  if p.rhs.any (fun a => match a with | .stop => true | _ => false) then { s with stopped := true }
  else s.schedCR s.now

/-- The productions that match, with their bindings (the conflict set). -/
def conflictSet (s : St) : List (Production × Env) :=
  s.prods.filterMap fun p => (matchProd s.bufs p).map fun env => (p, env)

/-- Utility used in conflict resolution: `U`, plus noise when `:esc` is on. -/
def utility (P : Params) (s : St) (p : Production) : Float :=
  p.u + (if P.esc then P.egsNoise p.name s.now else 0.0)

/-- **Conflict resolution** ([RM] "Conflict Resolution"): of the productions that match, the
one with the highest utility. At most one production is selected.
SIMPLIFIED: ties go to the first production in definition order; ACT-R leaves the
deterministic choice (`:er nil`) unspecified and chooses randomly with `:er t`. -/
def selectProd (P : Params) (s : St) : Option (Production × Env) :=
  (argmax ((conflictSet s).map fun pe => (pe, utility P s pe.1))).map (·.1)

def handle (P : Params) (s : St) : Event → St
  | .cr =>
    match selectProd P s with
    | some (p, env) =>
      (s.log ("PRODUCTION-SELECTED " ++ p.name)).sched (s.now + P.dat) (.fire p env s.now)
    | none =>
      -- no production matches: try again after the next event, if there is one
      match s.queue with
      | [] => s
      | (t, _) :: _ => s.schedCR t
  | .fire p env selAt => fire P s p env selAt
  | .retrieved r id =>
    if id != s.retrId then s
    else
      match r with
      | some e =>
        (s.setBuf .retrieval fun st =>
          { st with chunk := some e.chunk, busy := false, requested := true }).log
          ("RETRIEVED-CHUNK " ++ e.name) |>.schedCR s.now
      | none =>
        (s.setBuf .retrieval fun st =>
          { st with busy := false, failure := true, error := true }).log
          "RETRIEVAL-FAILURE" |>.schedCR s.now
  | .imaginalSet c id =>
    if id != s.imId then s
    else
      (s.setBuf .imaginal fun st => { st with chunk := some c, busy := false, requested := true }).log
        "SET-BUFFER-CHUNK IMAGINAL" |>.schedCR s.now

/-- Run the next event. `none` when no events are left. -/
def step (P : Params) (s : St) : Option St :=
  match s.queue with
  | [] => none
  | (t, e) :: q => some (handle P { s with now := t, queue := q } e)

/-- Run at most `n` events. -/
def run (P : Params) : Nat → St → St
  | 0, s => s
  | n + 1, s =>
    if s.stopped then s
    else match step P s with
      | none => s
      | some s' => run P n s'

/-- A model at time 0: declarative memory from `add-dm` (each chunk with one reference at
time 0), an optional chunk in the goal buffer (`goal-focus`), and the first
conflict-resolution event. -/
def St.init (prods : List Production) (dm : List (String × Chunk)) (goal : Option Chunk) : St :=
  { prods := prods
    dm := dm.map fun p => ⟨p.1, p.2, [0], 0⟩
    bufs := upd (fun _ => {}) Buf.goal { chunk := goal }
    queue := [(0, .cr)] }

/-! ## Properties -/

/-- Clearing empties the buffer. -/
theorem clearBuf_empty (s : St) (b : Buf) : ((clearBuf s b).bufs b).chunk = none := by
  unfold clearBuf
  cases h : (s.bufs b).chunk with
  | none => simp [St.setBuf, upd_same, h]
  | some c => simp [upd_same]

/-- Clearing changes no other buffer. -/
theorem clearBuf_other (s : St) (b b' : Buf) (h : b' ≠ b) : (clearBuf s b).bufs b' = s.bufs b' := by
  unfold clearBuf
  cases (s.bufs b).chunk with
  | none => simp [St.setBuf, upd_other _ _ _ h]
  | some c => simp [upd_other _ _ _ h]

/-- Clearing never loses a chunk from declarative memory. -/
theorem clearBuf_keeps_dm (s : St) (b : Buf) :
    ∀ ch, ch ∈ s.dm.map DMEntry.chunk → ch ∈ (clearBuf s b).dm.map DMEntry.chunk := by
  unfold clearBuf
  cases (s.bufs b).chunk with
  | none => intro ch h; simpa [St.setBuf] using h
  | some c => intro ch h; exact mergeDM_keeps c _ _ s.dm ch h

/-- **A request does not change declarative memory.** Retrieval reads the memory; chunks and
references are added only when a buffer is cleared. -/
theorem request_dm (P : Params) (s : St) (b : Buf) (spec : List ITest) :
    (request P s b spec).dm = s.dm := by
  cases b <;> simp [request, St.setBuf, St.sched, St.log]

/-- **Productions cannot see declarative memory.** Conflict resolution gives the same result
in two states that agree on the buffers, the productions and the time, whatever declarative
memory and the event queue hold. -/
theorem selectProd_blind (P : Params) (s₁ s₂ : St) (hb : s₁.bufs = s₂.bufs)
    (hp : s₁.prods = s₂.prods) (ht : s₁.now = s₂.now) : selectProd P s₁ = selectProd P s₂ := by
  simp [selectProd, conflictSet, utility, hb, hp, ht]

end ACTR
