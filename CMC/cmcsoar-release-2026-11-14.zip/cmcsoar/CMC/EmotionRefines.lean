import CMC.Emotion
/-!
# The metacognition version is the emotion version with neutral emotion

Every architecture of the CMC with metacognition (`CMC.Meta.Arch`) is, unchanged, an
architecture of the CMC with metacognition and emotion (`liftArch`): its emotion module
keeps the vector as it is and writes nothing, its assessment module reports nothing,
physiology is left alone, and no module operation depends on the emotion vector. Its runs are
the metacognition model's runs (`exec_lift`, `execAll_lift`): working memory is the same at
every location the metacognition model has, and empty at the two new buffers.

So the emotion version is a conservative extension: it adds structure and admits the
metacognition model as the case with no emotion, and every theorem of `CMC/Emotion.lean`
holds of every metacognition architecture.
-/

namespace CMC.Emo

open CMC.Meta (Rel Elem SelFail DeclMem)

variable {σ : Sig}

/-- The two point-update functions (`CMC.upd`, used here, and `CMC.Meta.upd`) are the same. -/
theorem meta_upd_eq : @CMC.Meta.upd = @CMC.upd := by
  funext α β _ f a v; rfl

/-! ## Working memory: restriction and extension -/

/-- The metacognition model's working memory inside this model's. -/
def restrict (w : WM σ) : CMC.Meta.WM σ.base := fun ℓ => w (Loc.ofMeta ℓ)

/-- A metacognition working memory with these new buffers. -/
def merge (m : CMC.Meta.WM σ.base) (w : WM σ) : WM σ
  | .percept p q => m (.percept p q)
  | .motor x q => m (.motor x q)
  | .decl d q => m (.decl d q)
  | .procProcess => m .procProcess
  | .wmProcess => m .wmProcess
  | .region => m .region
  | .emo q => w (.emo q)
  | .assess q => w (.assess q)

/-- A metacognition working memory, with the new buffers empty. -/
def extend (m : CMC.Meta.WM σ.base) : WM σ := merge m (fun _ => [])

theorem restrict_merge (m : CMC.Meta.WM σ.base) (w : WM σ) : restrict (merge m w) = m := by
  funext ℓ; cases ℓ <;> rfl

theorem restrict_extend (m : CMC.Meta.WM σ.base) : restrict (σ := σ) (extend m) = m :=
  restrict_merge m _

theorem merge_extend (m m' : CMC.Meta.WM σ.base) : merge m (extend (σ := σ) m') = extend m := by
  funext ℓ; cases ℓ <;> rfl

theorem upd_extend (m : CMC.Meta.WM σ.base) (ℓ : CMC.Meta.L σ.base) (v : List (Elem σ.base)) :
    upd (extend (σ := σ) m) (Loc.ofMeta ℓ) v = extend (upd m ℓ v) := by
  funext x
  cases x <;> cases ℓ <;> simp [upd, extend, merge, Loc.ofMeta]

def restrictE (e : WM σ × WM σ) : CMC.Meta.WM σ.base × CMC.Meta.WM σ.base :=
  (restrict e.1, restrict e.2)

def extendE (e : CMC.Meta.WM σ.base × CMC.Meta.WM σ.base) : WM σ × WM σ := (extend e.1, extend e.2)

theorem restrictE_extendE (e : CMC.Meta.WM σ.base × CMC.Meta.WM σ.base) :
    restrictE (σ := σ) (extendE e) = e := by
  simp [restrictE, extendE, restrict_extend]

/-! ## Rules -/

def liftRule (r : CMC.Meta.Rule σ.base) : Rule σ :=
  { cond := fun w => r.cond (restrict w), act := fun w => merge (r.act (restrict w)) w,
    «meta» := r.«meta» }

def lowerRule (r : Rule σ) : CMC.Meta.Rule σ.base :=
  { cond := fun w => r.cond (extend w), act := fun w => restrict (r.act (extend w)),
    «meta» := r.«meta» }

theorem lower_lift (r : CMC.Meta.Rule σ.base) : lowerRule (liftRule (σ := σ) r) = r := by
  cases r
  simp [lowerRule, liftRule, restrict_extend, restrict_merge]

theorem lower_lift_map (pm : CMC.Meta.ProcMem σ.base) :
    (pm.map (liftRule (σ := σ))).map lowerRule = pm := by
  simp [List.map_map, Function.comp_def, lower_lift]

/-- The metadata of each rule of `pm` replaced by that of the matching rule of `ps`. -/
def withMeta (pm : ProcMem σ) (ps : CMC.Meta.ProcMem σ.base) : ProcMem σ :=
  List.zipWith (fun r r' => { r with «meta» := r'.«meta» }) pm ps

theorem withMeta_symbolic : ∀ (pm : ProcMem σ) (ps : CMC.Meta.ProcMem σ.base),
    ps.length = pm.length →
    (withMeta pm ps).map (fun r => (r.cond, r.act)) = pm.map (fun r => (r.cond, r.act))
  | [], _, _ => by simp [withMeta]
  | r :: pm, [], h => by simp at h
  | r :: pm, r' :: ps, h => by
    simp only [withMeta, List.zipWith_cons_cons, List.map_cons] at *
    exact congrArg _ (withMeta_symbolic pm ps (by simpa using h))

theorem withMeta_meta (g : CMC.Meta.Meta σ.base → CMC.Meta.Meta σ.base) :
    ∀ (pm : ProcMem σ) (ps : CMC.Meta.ProcMem σ.base), ps.length = pm.length →
    (withMeta pm ps).map (fun r => g r.«meta») = ps.map (fun r => g r.«meta»)
  | [], [], _ => by simp [withMeta]
  | [], _ :: _, h => by simp at h
  | r :: pm, [], h => by simp at h
  | r :: pm, r' :: ps, h => by
    simp only [withMeta, List.zipWith_cons_cons, List.map_cons] at *
    exact congrArg _ (withMeta_meta g pm ps (by simpa using h))

/-- With the same conditions and actions, `withMeta` of lifted rules is the lifted result. -/
theorem withMeta_lift : ∀ (pm ps : CMC.Meta.ProcMem σ.base),
    ps.map (fun r => (r.cond, r.act)) = pm.map (fun r => (r.cond, r.act)) →
    withMeta (pm.map (liftRule (σ := σ))) ps = ps.map liftRule
  | [], [], _ => rfl
  | [], _ :: _, h => by simp at h
  | _ :: _, [], h => by simp at h
  | r :: pm, r' :: ps, h => by
    simp only [List.map_cons, List.cons.injEq, Prod.mk.injEq] at h
    obtain ⟨⟨hc, ha⟩, h⟩ := h
    simp only [withMeta, List.map_cons, List.zipWith_cons_cons, List.cons.injEq]
    refine ⟨?_, withMeta_lift pm ps h⟩
    simp [liftRule, hc, ha]

/-! ## The architecture -/

/-- A metacognition architecture as an emotion architecture with neutral emotion. -/
def liftArch (A : CMC.Meta.Arch σ.base) : Arch σ where
  select := fun _ pm w => match A.select (pm.map lowerRule) (restrict w) with
    | .act a => .act (fun w' => merge (a (restrict w')) w')
    | .fail r => .fail r
  select_respects_arch := by
    intro ev pm w a h ℓ hℓ
    split at h
    · rename_i a₀ h₀
      cases h
      cases ℓ with
      | percept p q =>
        have := A.select_respects_arch _ _ a₀ h₀ (.percept p q) (by cases q <;> simp_all [Loc.archWritten, CMC.Meta.Loc.archWritten])
        simpa [merge, restrict, Loc.ofMeta] using this
      | motor x q =>
        have := A.select_respects_arch _ _ a₀ h₀ (.motor x q) (by cases q <;> simp_all [Loc.archWritten, CMC.Meta.Loc.archWritten])
        simpa [merge, restrict, Loc.ofMeta] using this
      | decl d q =>
        have := A.select_respects_arch _ _ a₀ h₀ (.decl d q) (by cases q <;> simp_all [Loc.archWritten, CMC.Meta.Loc.archWritten])
        simpa [merge, restrict, Loc.ofMeta] using this
      | procProcess =>
        have := A.select_respects_arch _ _ a₀ h₀ .procProcess rfl
        simpa [merge, restrict, Loc.ofMeta] using this
      | wmProcess =>
        have := A.select_respects_arch _ _ a₀ h₀ .wmProcess rfl
        simpa [merge, restrict, Loc.ofMeta] using this
      | region => simp [Loc.archWritten] at hℓ
      | emo q => rfl
      | assess q => rfl
    · cases h
  procReport := A.procReport
  retrieve := fun _ => A.retrieve
  retrieveTouch := fun _ => A.retrieveTouch
  retrieveTouch_symbolic := fun _ => A.retrieveTouch_symbolic
  perceive := fun _ p l i w => let r := A.perceive p l i (restrict w); (r.1, r.2, [])
  motor := A.motor
  motorStatus := A.motorStatus
  appraise := fun w => A.appraise (restrict w)
  assess := fun _ _ _ _ _ _ => ([], [])
  emote := fun _ _ _ _ ev => (ev, [])
  toBody := fun _ ph => ph
  record := fun _ dm w => A.record dm (restrict w)
  record_incremental := fun _ dm w r h => A.record_incremental dm (restrict w) r h
  perceptLearn := fun p l i w => A.perceptLearn p l i (restrict w)
  motorLearn := A.motorLearn
  compose := fun pm e =>
    pm ++ ((A.compose (pm.map lowerRule) (restrictE e)).drop pm.length).map liftRule
  rlTune := fun _ pm e => withMeta pm (A.rlTune (pm.map lowerRule) (restrictE e))
  declCreate := fun _ d dm e => A.declCreate d dm (restrictE e)
  declTune := fun _ d dm e => A.declTune d dm (restrictE e)
  rlTune_symbolic := by
    intro _ pm e
    apply withMeta_symbolic
    have := congrArg List.length (A.rlTune_symbolic (pm.map lowerRule) (restrictE e))
    simpa using this
  rlTune_only_utility := by
    intro _ pm e
    have hl := congrArg List.length (A.rlTune_symbolic (pm.map lowerRule) (restrictE e))
    simp only [List.length_map] at hl
    rw [withMeta_meta (fun m k => if k = σ.utilityK then none else m k) pm _ hl]
    have := A.rlTune_only_utility (pm.map lowerRule) (restrictE e)
    rw [this]
    simp [List.map_map, Function.comp_def, lowerRule]
  declTune_symbolic := fun _ d dm e => A.declTune_symbolic d dm (restrictE e)
  learnBound := A.learnBound
  declCreate_incremental := fun _ d dm e => A.declCreate_incremental d dm (restrictE e)
  declCreate_bounded := fun _ d dm e => A.declCreate_bounded d dm (restrictE e)
  compose_bounded := by
    intro pm e
    obtain ⟨new, hn, he⟩ := A.compose_bounded (pm.map lowerRule) (restrictE e)
    refine ⟨((A.compose (pm.map lowerRule) (restrictE e)).drop pm.length).map liftRule, ?_, rfl⟩
    rw [he]; simpa using hn
  decayWM := A.decayWM
  decayDM := A.decayDM
  forgettable := A.forgettable
  cycleMs := A.cycleMs

/-! ## Simulation -/

/-- A metacognition state as an emotion state, with a given emotion vector and physiology. -/
def liftState (ev₀ : σ.EVec) (ph₀ : σ.Phys) (s : CMC.Meta.State σ.base) : State σ :=
  { wm := extend s.wm, pm := s.pm.map liftRule, dm := s.dm, lastCycle := s.lastCycle.map extendE,
    ps := s.ps, ms := s.ms, ev := ev₀, low := [], fromPercept := fun _ => [], phys := ph₀ }

def liftLabel : CMC.Meta.Label σ.base → Label σ
  | .perceive p i => .perceive p i
  | .retrieve d => .retrieve d
  | .motor m => .motor m
  | .appraise => .appraise
  | .learnPercept p i => .learnPercept p i
  | .learnMotor m => .learnMotor m
  | .cycle => .cycle
  | .compose => .compose
  | .rl => .rl
  | .create d => .create d
  | .tune d => .tune d
  | .decay => .decay
  | .forgetWM b => .forgetWM (Loc.ofMeta b)
  | .forgetDecl d => .forgetDecl d

theorem cycleWM_lift (A : CMC.Meta.Arch σ.base) (ev : σ.EVec) (pm : CMC.Meta.ProcMem σ.base)
    (w : CMC.Meta.WM σ.base) :
    cycleWM (liftArch A) ev (pm.map liftRule) (extend w) = extend (CMC.Meta.cycleWM A pm w) := by
  unfold cycleWM CMC.Meta.cycleWM
  simp only [liftArch, lower_lift_map, restrict_extend]
  cases h : A.select pm w with
  | act a =>
    simp only [Outc.apply, Outc.failure, CMC.Meta.Outcome.apply, CMC.Meta.Outcome.failure,
      restrict_extend, merge_extend]
    exact upd_extend _ .procProcess _
  | fail r =>
    simp only [Outc.apply, Outc.failure, CMC.Meta.Outcome.apply, CMC.Meta.Outcome.failure]
    exact upd_extend _ .procProcess _

/-- **Each step of a metacognition architecture is the same step of its lift.** -/
theorem exec_lift (A : CMC.Meta.Arch σ.base) (ev₀ : σ.EVec) (ph₀ : σ.Phys)
    (l : CMC.Meta.Label σ.base) (s : CMC.Meta.State σ.base) :
    exec (liftArch A) (liftLabel l) (liftState ev₀ ph₀ s) =
      (liftState ev₀ ph₀ (CMC.Meta.exec A l s).1, (CMC.Meta.exec A l s).2) := by
  have hfp : ∀ p, upd (fun _ : σ.PMod => ([] : List (Elem σ.base))) p [] = fun _ => [] := by
    intro p; funext x; simp [upd]
  cases l with
  | perceive p i =>
    simp only [meta_upd_eq, liftLabel, exec, CMC.Meta.exec, liftState, liftArch, restrict_extend, hfp]
    rw [show (Loc.percept p .content : L σ) = Loc.ofMeta (.percept p .content) from rfl,
        show (Loc.percept p .process : L σ) = Loc.ofMeta (.percept p .process) from rfl,
        upd_extend, upd_extend]
  | retrieve d =>
    simp only [meta_upd_eq, liftLabel, exec, CMC.Meta.exec, liftState, liftArch]
    rw [show (Loc.decl d .cue : L σ) = Loc.ofMeta (.decl d .cue) from rfl,
        show (Loc.decl d .result : L σ) = Loc.ofMeta (.decl d .result) from rfl,
        show (Loc.decl d .process : L σ) = Loc.ofMeta (.decl d .process) from rfl]
    simp only [extend, merge, Loc.ofMeta]
    rw [show (Loc.decl d .result : L σ) = Loc.ofMeta (.decl d .result) from rfl,
        show (Loc.decl d .process : L σ) = Loc.ofMeta (.decl d .process) from rfl]
    rw [← extend, upd_extend, upd_extend]
    rfl
  | motor m =>
    simp only [meta_upd_eq, liftLabel, exec, CMC.Meta.exec, liftState, liftArch]
    rw [show (Loc.motor m .command : L σ) = Loc.ofMeta (.motor m .command) from rfl,
        show (Loc.motor m .process : L σ) = Loc.ofMeta (.motor m .process) from rfl]
    simp only [extend, merge, Loc.ofMeta]
    rw [show (Loc.motor m .process : L σ) = Loc.ofMeta (.motor m .process) from rfl,
        ← extend, upd_extend]
    rfl
  | appraise =>
    simp only [meta_upd_eq, liftLabel, exec, CMC.Meta.exec, liftState, liftArch, restrict_extend]
    rw [show (Loc.wmProcess : L σ) = Loc.ofMeta .wmProcess from rfl, upd_extend]
  | learnPercept p i =>
    simp only [meta_upd_eq, liftLabel, exec, CMC.Meta.exec, liftState, liftArch, restrict_extend]
  | learnMotor m =>
    simp only [meta_upd_eq, liftLabel, exec, CMC.Meta.exec, liftState, liftArch]
    rfl
  | cycle =>
    simp only [meta_upd_eq, liftLabel, exec, CMC.Meta.exec, liftState, cycleWM_lift]
    simp [liftArch, restrict_extend, Option.map, extendE]
  | compose =>
    simp only [meta_upd_eq, liftLabel, exec, CMC.Meta.exec, liftState]
    cases hc : s.lastCycle with
    | none => simp [hc]
    | some e =>
      simp only [Option.map_some, liftArch, lower_lift_map, restrictE_extendE]
      obtain ⟨new, _, he⟩ := A.compose_bounded s.pm e
      simp [he, List.drop_left' (List.length_map ..).symm]
  | rl =>
    simp only [meta_upd_eq, liftLabel, exec, CMC.Meta.exec, liftState]
    cases hc : s.lastCycle with
    | none => simp [hc]
    | some e =>
      simp only [Option.map_some, liftArch, lower_lift_map, restrictE_extendE]
      simp [withMeta_lift s.pm _ (A.rlTune_symbolic s.pm e)]
  | create d =>
    simp only [meta_upd_eq, liftLabel, exec, CMC.Meta.exec, liftState]
    cases hc : s.lastCycle with
    | none => simp [hc]
    | some e => simp [liftArch, restrictE_extendE]
  | tune d =>
    simp only [meta_upd_eq, liftLabel, exec, CMC.Meta.exec, liftState]
    cases hc : s.lastCycle with
    | none => simp [hc]
    | some e => simp [liftArch, restrictE_extendE]
  | decay =>
    simp only [meta_upd_eq, liftLabel, exec, CMC.Meta.exec, liftState, liftArch]
    simp only [Prod.mk.injEq, and_true, State.mk.injEq, true_and]
    refine ⟨?_, rfl⟩
    funext b; cases b <;> rfl
  | forgetWM b =>
    simp only [meta_upd_eq, liftLabel, exec, CMC.Meta.exec, Loc.archWritten_ofMeta]
    split
    · rfl
    · simp only [liftState, liftArch]
      have : (extend (σ := σ) s.wm) (Loc.ofMeta b) = s.wm b := by cases b <;> rfl
      rw [this, upd_extend]
  | forgetDecl d =>
    simp only [meta_upd_eq, liftLabel, exec, CMC.Meta.exec, liftState, liftArch]

/-- **Whole runs of a metacognition architecture are runs of its lift**: the same working
memory at every location of the metacognition model (and nothing at the new buffers), the
same memories and the same actions. -/
theorem execAll_lift (A : CMC.Meta.Arch σ.base) (ev₀ : σ.EVec) (ph₀ : σ.Phys)
    (ls : List (CMC.Meta.Label σ.base)) (s : CMC.Meta.State σ.base) :
    execAll (liftArch A) (ls.map liftLabel) (liftState ev₀ ph₀ s) =
      (liftState ev₀ ph₀ (CMC.Meta.execAll A ls s).1, (CMC.Meta.execAll A ls s).2) := by
  induction ls generalizing s with
  | nil => rfl
  | cons l ls ih =>
    simp only [List.map_cons, execAll, CMC.Meta.execAll, exec_lift, ih]

end CMC.Emo
