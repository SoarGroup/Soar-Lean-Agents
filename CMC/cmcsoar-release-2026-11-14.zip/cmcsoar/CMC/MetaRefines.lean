import CMC.Base
import CMC.Meta
/-!
# The 2017 model is the metacognition version with nothing reading the new structures

The metacognition version of the CMC (`CMC/Meta.lean`) adds process-data areas to every
module, a separate episodic memory, appraisal of working memory, and reports of selection
failure. This file shows that it is a conservative extension of the 2017 model
(`CMC/Base.lean`): every 2017 architecture, combined with *any* choice of the new
metacognitive behaviour, is a metacognition architecture (`liftArch`) whose runs, restricted
to the locations and memories the 2017 model has (`proj`), are 2017 runs.

## The correspondence

DECIDED (Laird, 2026-11-14):
* **Motor status goes into working memory.** The 2017 motor buffer's result part (execution
  status) is the metacognition motor buffer's process part.
* **There is a separate episodic memory.** Long-term declarative memory is split into
  semantic and episodic memories, both with buffers in working memory. The 2017 declarative
  memories are the semantic side: `DMem := Option σ.DMem`, where `some d` is the 2017 memory
  `d` and `none` is the new episodic memory (`epi := none`).

| 2017 location            | metacognition location        |
|--------------------------|-------------------------------|
| `percept p`              | `percept p content`           |
| `motor m cue`            | `motor m command`             |
| `motor m result`         | `motor m process`             |
| `decl d cue`, `result`   | `decl (some d) cue`, `result` |
| `region`                 | `region`                      |
| (none)                   | `percept p process`, `decl (some d) process`, all of `decl none`, `procProcess`, `wmProcess` |

## What may be chosen freely, and what may not

The new behaviour is a parameter (`Ext`): the reason reported for a selection failure, the
procedural report, perception's process data, semantic retrieval's process data, episodic
retrieval and its metadata effect, episodic recording, and appraisal. Whatever is chosen,
the 2017 behaviour is unchanged (`exec_proj`, `execAll_proj`), because no 2017 rule reads
a new location and no 2017 module reads the episodic memory.

One metacognition feature cannot be chosen freely: the **metadata effect of semantic
retrieval** (`retrieveTouch`) must be the identity on the semantic memories. A non-trivial
effect changes the recency and frequency that 2017 retrieval reads, so 2017 behaviour would
change. In the 2017 model, retrieval leaves declarative memory alone and only the `tune`
learning step changes declarative metadata. This is a substantive difference between the
versions, not an addition: see the comparison paper, Section 5.

## Results

* `exec_proj`: each metacognition step that corresponds to a 2017 step does exactly that
  step on the projection, with the same external action.
* `exec_new`: each metacognition step with no 2017 counterpart (appraisal, episodic
  retrieval, learning and forgetting in episodic memory, forgetting in a new location)
  leaves the projection unchanged and produces no action.
* `execAll_proj`: the projection of any metacognition run is the 2017 run of its
  corresponding steps, with the same actions.
* `exec_lift`, `execAll_lift`: every 2017 run is the projection of a metacognition run.
-/

namespace CMC.Refine

/-! ## Signatures, elements and memories -/

/-- The metacognition signature of a 2017 signature: the 2017 declarative memories become
the semantic memories, and `none` is the new episodic memory. The 2017 symbolic signals
(`Signal`, `sigSym`) have no counterpart; in the metacognition version, status signals are
process data. -/
@[reducible] def metaSig (σ : CMC.Sig) : CMC.Meta.Sig where
  Sym := σ.Sym
  Val := σ.Val
  PMod := σ.PMod
  MMod := σ.MMod
  DMem := Option σ.DMem
  Input := σ.Input
  PLearn := σ.PLearn
  MLearn := σ.MLearn
  Output := σ.Output
  MK := σ.MK
  utilityK := σ.utilityK
  frequencyK := σ.frequencyK
  recencyK := σ.recencyK
  epi := none

variable {σ : CMC.Sig}

local notation "τ" => metaSig σ

def up (e : CMC.Elem σ) : CMC.Meta.Elem τ := ⟨⟨e.rel.pred, e.rel.args⟩, e.«meta»⟩
def down (e : CMC.Meta.Elem τ) : CMC.Elem σ := ⟨⟨e.rel.pred, e.rel.args⟩, e.«meta»⟩

@[simp] theorem down_up (e : CMC.Elem σ) : down (up e) = e := rfl
@[simp] theorem up_down (e : CMC.Meta.Elem τ) : up (down e) = e := rfl

@[simp] theorem down_comp_up : (down ∘ up : CMC.Elem σ → CMC.Elem σ) = id := rfl
@[simp] theorem up_comp_down : (up ∘ down : CMC.Meta.Elem τ → CMC.Meta.Elem τ) = id := rfl

@[simp] theorem down_up_list (l : List (CMC.Elem σ)) : (l.map up).map down = l := by
  induction l with
  | nil => rfl
  | cons e l ih => simp only [List.map_cons, ih, down_up]

@[simp] theorem up_down_list (l : List (CMC.Meta.Elem τ)) : (l.map down).map up = l := by
  induction l with
  | nil => rfl
  | cons e l ih => simp only [List.map_cons, ih, up_down]

def dUp (m : CMC.DeclMem σ) : CMC.Meta.DeclMem τ := ⟨m.elems.map up⟩
def dDown (m : CMC.Meta.DeclMem τ) : CMC.DeclMem σ := ⟨m.elems.map down⟩

@[simp] theorem dDown_dUp (m : CMC.DeclMem σ) : dDown (dUp m) = m := by
  cases m; simp [dDown, dUp]

/-! ## Locations -/

/-- Where each 2017 location lives in the metacognition model. -/
def ofBase : CMC.L σ → CMC.Meta.L τ
  | .percept p => .percept p .content
  | .motor m .cue => .motor m .command
  | .motor m .result => .motor m .process
  | .decl d .cue => .decl (some d) .cue
  | .decl d .result => .decl (some d) .result
  | .region => .region

theorem ofBase_inj {a b : CMC.L σ} (h : ofBase a = ofBase b) : a = b := by
  cases a with
  | percept p => cases b with
    | percept _ => cases h; rfl
    | motor _ q => cases q <;> cases h
    | decl _ q => cases q <;> cases h
    | region => cases h
  | motor m q => cases q <;> cases b with
    | percept _ => cases h
    | motor _ q' => cases q' <;> cases h <;> rfl
    | decl _ q' => cases q' <;> cases h
    | region => cases h
  | decl d q => cases q <;> cases b with
    | percept _ => cases h
    | motor _ q' => cases q' <;> cases h
    | decl _ q' => cases q' <;> cases h <;> rfl
    | region => cases h
  | region => cases b with
    | percept _ => cases h
    | motor _ q => cases q <;> cases h
    | decl _ q => cases q <;> cases h
    | region => rfl

/-- The 2017 location at a metacognition location, if there is one. -/
def unBase : CMC.Meta.L τ → Option (CMC.L σ)
  | .percept p .content => some (.percept p)
  | .motor m .command => some (.motor m .cue)
  | .motor m .process => some (.motor m .result)
  | .decl (some d) .cue => some (.decl d .cue)
  | .decl (some d) .result => some (.decl d .result)
  | .region => some .region
  | _ => none

theorem unBase_ofBase (b : CMC.L σ) : unBase (ofBase b) = some b := by
  rcases b with p | ⟨m, _ | _⟩ | ⟨d, _ | _⟩ | _ <;> rfl

theorem unBase_some {ℓ : CMC.Meta.L τ} {b : CMC.L σ} (h : unBase ℓ = some b) :
    ofBase b = ℓ := by
  rcases ℓ with ⟨p, _ | _⟩ | ⟨m, _ | _⟩ | ⟨_ | d, _ | _ | _⟩ | _ | _ | _ <;>
    simp [unBase] at h <;> subst h <;> rfl

theorem unBase_none {ℓ : CMC.Meta.L τ} (h : unBase ℓ = none) (b : CMC.L σ) : ofBase b ≠ ℓ := by
  intro hb; subst hb; rw [unBase_ofBase] at h; cases h

/-- The motor status and the declarative results are architecture-written in both versions;
nothing else at a 2017 location is. -/
theorem archWritten_ofBase (b : CMC.L σ) : (ofBase b).archWritten = b.isResult := by
  rcases b with p | ⟨m, _ | _⟩ | ⟨d, _ | _⟩ | _ <;> rfl

/-! ## Working memory: restriction and merging -/

/-- The 2017 working memory inside a metacognition working memory. -/
def restrict (w : CMC.Meta.WM τ) : CMC.WM σ := fun b => (w (ofBase b)).map down

/-- A 2017 working memory placed into a metacognition one, which supplies the new
locations. -/
def merge (v : CMC.WM σ) (w : CMC.Meta.WM τ) : CMC.Meta.WM τ := fun ℓ =>
  match unBase ℓ with
  | some b => (v b).map up
  | none => w ℓ

/-- A 2017 working memory with the new locations empty. -/
def extend (v : CMC.WM σ) : CMC.Meta.WM τ := merge v (fun _ => [])

theorem restrict_merge (v : CMC.WM σ) (w : CMC.Meta.WM τ) : restrict (merge v w) = v := by
  funext b; simp [restrict, merge, unBase_ofBase]

theorem restrict_extend (v : CMC.WM σ) : restrict (extend v) = v := restrict_merge v _

theorem merge_new (v : CMC.WM σ) (w : CMC.Meta.WM τ) {ℓ : CMC.Meta.L τ} (h : unBase ℓ = none) :
    merge v w ℓ = w ℓ := by simp [merge, h]

theorem restrict_upd_ofBase (w : CMC.Meta.WM τ) (b : CMC.L σ) (l : List (CMC.Meta.Elem τ)) :
    restrict (CMC.Meta.upd w (ofBase b) l) = CMC.upd (restrict w) b (l.map down) := by
  funext x
  by_cases hx : x = b
  · subst hx; simp [restrict, CMC.Meta.upd, CMC.upd]
  · have : ofBase x ≠ ofBase b := fun h => hx (ofBase_inj h)
    simp [restrict, CMC.Meta.upd, CMC.upd, hx, this]

theorem restrict_upd_new (w : CMC.Meta.WM τ) {ℓ : CMC.Meta.L τ} (h : unBase ℓ = none)
    (l : List (CMC.Meta.Elem τ)) : restrict (CMC.Meta.upd w ℓ l) = restrict w := by
  funext x
  simp [restrict, CMC.Meta.upd, unBase_none h x]

def restrictE (e : CMC.Meta.WM τ × CMC.Meta.WM τ) : CMC.WM σ × CMC.WM σ :=
  (restrict e.1, restrict e.2)

def extendE (e : CMC.WM σ × CMC.WM σ) : CMC.Meta.WM τ × CMC.Meta.WM τ :=
  (extend e.1, extend e.2)

theorem restrictE_extendE (e : CMC.WM σ × CMC.WM σ) : restrictE (extendE e) = e := by
  simp [restrictE, extendE, restrict_extend]

/-! ## Rules -/

/-- A 2017 rule in the metacognition model: it reads and writes only 2017 locations. -/
def liftRule (r : CMC.Rule σ) : CMC.Meta.Rule τ :=
  { cond := fun w => r.cond (restrict w), act := fun w => merge (r.act (restrict w)) w,
    «meta» := r.«meta» }

/-- A metacognition rule seen from the 2017 model, with the new locations empty. -/
def lowerRule (r : CMC.Meta.Rule τ) : CMC.Rule σ :=
  { cond := fun w => r.cond (extend w), act := fun w => restrict (r.act (extend w)),
    «meta» := r.«meta» }

theorem lower_lift (r : CMC.Rule σ) : lowerRule (liftRule r) = r := by
  cases r
  simp [lowerRule, liftRule, restrict_extend, restrict_merge]

theorem lower_lift_map (pm : CMC.ProcMem σ) : (pm.map liftRule).map lowerRule = pm := by
  simp [List.map_map, Function.comp_def, lower_lift]

/-- The metadata of each rule of `pm` replaced by that of the matching rule of `ps`. -/
def withMeta (pm : CMC.Meta.ProcMem τ) (ps : CMC.ProcMem σ) : CMC.Meta.ProcMem τ :=
  List.zipWith (fun r r' => { r with «meta» := r'.«meta» }) pm ps

theorem withMeta_symbolic : ∀ (pm : CMC.Meta.ProcMem τ) (ps : CMC.ProcMem σ),
    ps.length = pm.length →
    (withMeta pm ps).map (fun r => (r.cond, r.act)) = pm.map (fun r => (r.cond, r.act))
  | [], _, _ => by simp [withMeta]
  | r :: pm, [], h => by simp at h
  | r :: pm, r' :: ps, h => by
    simp only [withMeta, List.zipWith_cons_cons, List.map_cons] at *
    exact congrArg _ (withMeta_symbolic pm ps (by simpa using h))

theorem withMeta_meta (g : CMC.Meta σ → CMC.Meta σ) :
    ∀ (pm : CMC.Meta.ProcMem τ) (ps : CMC.ProcMem σ), ps.length = pm.length →
    (withMeta pm ps).map (fun r => g r.«meta») = ps.map (fun r => g r.«meta»)
  | [], [], _ => by simp [withMeta]
  | [], _ :: _, h => by simp at h
  | r :: pm, [], h => by simp at h
  | r :: pm, r' :: ps, h => by
    simp only [withMeta, List.zipWith_cons_cons, List.map_cons] at *
    exact congrArg _ (withMeta_meta g pm ps (by simpa using h))

/-- Lowering after `withMeta` gives the 2017 result, when conditions and actions agree. -/
theorem lower_withMeta : ∀ (pm : CMC.Meta.ProcMem τ) (ps : CMC.ProcMem σ),
    ps.map (fun r => (r.cond, r.act)) = (pm.map lowerRule).map (fun r => (r.cond, r.act)) →
    (withMeta pm ps).map lowerRule = ps
  | [], [], _ => rfl
  | [], _ :: _, h => by simp at h
  | _ :: _, [], h => by simp at h
  | r :: pm, r' :: ps, h => by
    simp only [List.map_cons, List.cons.injEq, Prod.mk.injEq] at h
    obtain ⟨⟨hc, ha⟩, h⟩ := h
    simp only [withMeta, List.map_cons, List.zipWith_cons_cons, List.cons.injEq]
    refine ⟨?_, lower_withMeta pm ps h⟩
    cases r'
    simp only [lowerRule] at hc ha ⊢
    simp [hc, ha]

/-! ## The metacognitive behaviour: free parameters -/

/-- The behaviour the metacognition version adds. Any choice leaves the 2017 behaviour
intact. -/
structure Ext (σ : CMC.Sig) where
  /-- The reason reported when selection finds no act (the 2017 model says only "none"). -/
  failReason : CMC.Meta.WM (metaSig σ) → CMC.Meta.SelFail
  procReport : Option CMC.Meta.SelFail → List (CMC.Meta.Elem (metaSig σ))
  perceptProc : σ.PMod → σ.PLearn → σ.Input → CMC.Meta.WM (metaSig σ) →
    List (CMC.Meta.Elem (metaSig σ))
  /-- Process data for semantic retrieval (failure, confidence, partiality). -/
  retrieveProc : σ.DMem → CMC.Meta.DeclMem (metaSig σ) → List (CMC.Meta.Elem (metaSig σ)) →
    List (CMC.Meta.Elem (metaSig σ))
  /-- Episodic retrieval: result and process data. -/
  epiRetrieve : CMC.Meta.DeclMem (metaSig σ) → List (CMC.Meta.Elem (metaSig σ)) →
    List (CMC.Meta.Elem (metaSig σ)) × List (CMC.Meta.Elem (metaSig σ))
  /-- The metadata effect of episodic retrieval. -/
  epiTouch : CMC.Meta.DeclMem (metaSig σ) → List (CMC.Meta.Elem (metaSig σ)) →
    CMC.Meta.DeclMem (metaSig σ)
  epiTouch_symbolic : ∀ dm c,
    (epiTouch dm c).elems.map CMC.Meta.Elem.rel = dm.elems.map CMC.Meta.Elem.rel
  record : CMC.Meta.DeclMem (metaSig σ) → CMC.Meta.WM (metaSig σ) → CMC.Meta.DeclMem (metaSig σ)
  record_incremental : ∀ dm w r, r ∈ dm.elems.map CMC.Meta.Elem.rel →
    r ∈ (record dm w).elems.map CMC.Meta.Elem.rel
  appraise : CMC.Meta.WM (metaSig σ) → List (CMC.Meta.Elem (metaSig σ))

/-- The trivial choice: nothing is reported, recorded or retrieved. -/
def Ext.silent (σ : CMC.Sig) : Ext σ where
  failReason := fun _ => .noCandidates
  procReport := fun _ => []
  perceptProc := fun _ _ _ _ => []
  retrieveProc := fun _ _ _ => []
  epiRetrieve := fun _ _ => ([], [])
  epiTouch := fun dm _ => dm
  epiTouch_symbolic := fun _ _ => rfl
  record := fun dm _ => dm
  record_incremental := fun _ _ _ h => h
  appraise := fun _ => []

/-! ## Transfer lemmas for declarative obligations -/

theorem mem_rel_dUp {m : CMC.DeclMem σ} {e : CMC.Meta.Elem τ}
    (h : (down e).rel ∈ m.elems.map CMC.Elem.rel) :
    e.rel ∈ (dUp m).elems.map CMC.Meta.Elem.rel := by
  obtain ⟨e', he', hr⟩ := List.mem_map.1 h
  refine List.mem_map.2 ⟨up e', List.mem_map.2 ⟨e', he', rfl⟩, ?_⟩
  show CMC.Meta.Rel.mk e'.rel.pred e'.rel.args = e.rel
  rw [hr]; rfl

theorem rel_dDown_mem {m : CMC.Meta.DeclMem τ} {e : CMC.Meta.Elem τ}
    (h : e.rel ∈ m.elems.map CMC.Meta.Elem.rel) :
    (down e).rel ∈ (dDown m).elems.map CMC.Elem.rel := by
  obtain ⟨e', he', hr⟩ := List.mem_map.1 h
  refine List.mem_map.2 ⟨down e', List.mem_map.2 ⟨e', he', rfl⟩, ?_⟩
  show CMC.Rel.mk e'.rel.pred e'.rel.args = CMC.Rel.mk e.rel.pred e.rel.args
  rw [hr]

/-! ## The architecture -/

/-- A 2017 architecture, with chosen metacognitive behaviour, as a metacognition
architecture. -/
def liftArch (A : CMC.Arch σ) (X : Ext σ) : CMC.Meta.Arch τ where
  select := fun pm w => match A.select (pm.map lowerRule) (restrict w) with
    | some a => .act (fun w' => merge (a (restrict w')) w')
    | none => .fail (X.failReason w)
  select_respects_arch := by
    intro pm w a h ℓ hℓ
    split at h
    · rename_i a₀ h₀
      cases h
      have hr := A.select_respects_results _ _ a₀ h₀
      cases hu : unBase ℓ with
      | none => exact merge_new _ _ hu
      | some b =>
        have hb := unBase_some hu
        subst hb
        rw [archWritten_ofBase] at hℓ
        simp only [merge, unBase_ofBase]
        rcases b with p | ⟨m, _ | _⟩ | ⟨d, _ | _⟩ | _ <;> simp [CMC.Loc.isResult] at hℓ
        · rw [hr.2 m]; simp [restrict]
        · rw [hr.1 d]; simp [restrict]
    · cases h
  procReport := X.procReport
  retrieve := fun d dm c => match d with
    | some d => ((A.retrieve d (dDown dm) (c.map down)).map up, X.retrieveProc d dm c)
    | none => X.epiRetrieve dm c
  retrieveTouch := fun d dm c => match d with
    | some _ => dm
    | none => X.epiTouch dm c
  retrieveTouch_symbolic := by
    intro d dm c; cases d
    · exact X.epiTouch_symbolic dm c
    · rfl
  perceive := fun p l i w => ((A.perceive p l i (restrict w)).map up, X.perceptProc p l i w)
  motor := fun m l c => A.motor m l (c.map down)
  motorStatus := fun m l c => (A.motorStatus m l (c.map down)).map up
  appraise := X.appraise
  record := X.record
  record_incremental := X.record_incremental
  perceptLearn := fun p l i w => A.perceptLearn p l i (restrict w)
  motorLearn := fun m l c o => A.motorLearn m l (c.map down) o
  compose := fun pm e =>
    pm ++ ((A.compose (pm.map lowerRule) (restrictE e)).drop pm.length).map liftRule
  rlTune := fun pm e => withMeta pm (A.rlTune (pm.map lowerRule) (restrictE e))
  declCreate := fun d dm e => match d with
    | some d => dUp (A.declCreate d (dDown dm) (restrictE e))
    | none => dm
  declTune := fun d dm e => match d with
    | some d => dUp (A.declTune d (dDown dm) (restrictE e))
    | none => dm
  rlTune_symbolic := by
    intro pm e
    apply withMeta_symbolic
    have := congrArg List.length (A.rlTune_symbolic (pm.map lowerRule) (restrictE e))
    simpa using this
  rlTune_only_utility := by
    intro pm e
    have hl := congrArg List.length (A.rlTune_symbolic (pm.map lowerRule) (restrictE e))
    simp only [List.length_map] at hl
    rw [withMeta_meta (fun m k => if k = (metaSig σ).utilityK then none else m k) pm _ hl]
    have := A.rlTune_only_utility (pm.map lowerRule) (restrictE e)
    refine this.trans ?_
    simp [List.map_map, Function.comp_def, lowerRule]
  declTune_symbolic := by
    intro d dm e
    cases d with
    | none => rfl
    | some d =>
      have h := congrArg (List.map fun (r : CMC.Rel σ) => (⟨r.pred, r.args⟩ : CMC.Meta.Rel τ))
        (A.declTune_symbolic d (dDown dm) (restrictE e))
      simp only [List.map_map, dDown] at h
      simp only [dUp, List.map_map]
      exact h
  learnBound := A.learnBound
  declCreate_incremental := by
    intro d dm e r hr
    cases d with
    | none => exact hr
    | some d =>
      obtain ⟨e₀, he₀, rfl⟩ := List.mem_map.1 hr
      exact mem_rel_dUp (A.declCreate_incremental d (dDown dm) (restrictE e) _
        (rel_dDown_mem (List.mem_map.2 ⟨e₀, he₀, rfl⟩)))
  declCreate_bounded := by
    intro d dm e
    cases d with
    | none => simp
    | some d =>
      have := A.declCreate_bounded d (dDown dm) (restrictE e)
      simpa [dUp, dDown] using this
  compose_bounded := by
    intro pm e
    obtain ⟨new, hn, he⟩ := A.compose_bounded (pm.map lowerRule) (restrictE e)
    refine ⟨((A.compose (pm.map lowerRule) (restrictE e)).drop pm.length).map liftRule, ?_, rfl⟩
    rw [he]; simpa using hn
  decayWM := A.decayWM
  decayDM := A.decayDM
  forgettable := A.forgettable
  cycleMs := A.cycleMs

/-! ## Projection -/

/-- The 2017 state inside a metacognition state: the 2017 locations, the semantic memories,
and procedural memory as seen from the 2017 locations. -/
def proj (S : CMC.Meta.State τ) : CMC.State σ :=
  { wm := restrict S.wm, pm := S.pm.map lowerRule, dm := fun d => dDown (S.dm (some d)),
    lastCycle := S.lastCycle.map restrictE, ps := S.ps, ms := S.ms }

/-- A 2017 state as a metacognition state, with the new locations and the episodic memory
empty. -/
def liftState (s : CMC.State σ) : CMC.Meta.State τ :=
  { wm := extend s.wm, pm := s.pm.map liftRule,
    dm := fun d => match d with | some d => dUp (s.dm d) | none => ⟨[]⟩,
    lastCycle := s.lastCycle.map extendE, ps := s.ps, ms := s.ms }

theorem proj_liftState (s : CMC.State σ) : proj (liftState s) = s := by
  cases s with
  | mk wm pm dm lc ps ms =>
    simp only [proj, liftState, restrict_extend, lower_lift_map, dDown_dUp]
    cases lc <;> simp [restrictE_extendE]

/-! ## Labels -/

def liftLabel : CMC.Label σ → CMC.Meta.Label τ
  | .perceive p i => .perceive p i
  | .retrieve d => .retrieve (some d)
  | .motor m => .motor m
  | .cycle => .cycle
  | .compose => .compose
  | .rl => .rl
  | .create d => .create (some d)
  | .tune d => .tune (some d)
  | .decay => .decay
  | .forgetWM b => .forgetWM (ofBase b)
  | .forgetDecl d => .forgetDecl (some d)
  | .learnPercept p i => .learnPercept p i
  | .learnMotor m => .learnMotor m

/-- The 2017 step a metacognition step corresponds to, if any. -/
def lowerLabel : CMC.Meta.Label τ → Option (CMC.Label σ)
  | .perceive p i => some (.perceive p i)
  | .retrieve (some d) => some (.retrieve d)
  | .retrieve none => none
  | .motor m => some (.motor m)
  | .appraise => none
  | .learnPercept p i => some (.learnPercept p i)
  | .learnMotor m => some (.learnMotor m)
  | .cycle => some .cycle
  | .compose => some .compose
  | .rl => some .rl
  | .create (some d) => some (.create d)
  | .create none => none
  | .tune (some d) => some (.tune d)
  | .tune none => none
  | .decay => some .decay
  | .forgetWM ℓ => (unBase ℓ).map .forgetWM
  | .forgetDecl (some d) => some (.forgetDecl d)
  | .forgetDecl none => none

theorem lowerLabel_liftLabel (l : CMC.Label σ) : lowerLabel (liftLabel l) = some l := by
  cases l <;> simp [liftLabel, lowerLabel, unBase_ofBase]

/-! ## Simulation -/

variable (A : CMC.Arch σ) (X : Ext σ)

theorem dm_upd_some (f : Option σ.DMem → CMC.Meta.DeclMem τ) (d : σ.DMem)
    (v : CMC.Meta.DeclMem τ) :
    (fun d' => dDown (CMC.Meta.upd f (some d) v (some d'))) = CMC.upd (fun d' => dDown (f (some d'))) d (dDown v) := by
  funext d'
  by_cases h : d' = d
  · subst h; simp [CMC.Meta.upd, CMC.upd]
  · simp [CMC.Meta.upd, CMC.upd, h]

theorem dm_upd_none (f : Option σ.DMem → CMC.Meta.DeclMem τ) (v : CMC.Meta.DeclMem τ) :
    (fun d' => dDown (CMC.Meta.upd f none v (some d'))) = fun d' => dDown (f (some d')) := by
  funext d'; simp [CMC.Meta.upd]

theorem cycleWM_proj (pm : CMC.Meta.ProcMem τ) (w : CMC.Meta.WM τ) :
    restrict (CMC.Meta.cycleWM (liftArch A X) pm w) = CMC.cycleWM A (pm.map lowerRule) (restrict w) := by
  unfold CMC.Meta.cycleWM CMC.cycleWM
  rw [restrict_upd_new _ (rfl : unBase (σ := σ) .procProcess = none)]
  simp only [liftArch]
  cases A.select (pm.map lowerRule) (restrict w) with
  | some a => simp [CMC.Meta.Outcome.apply, restrict_merge]
  | none => rfl

/-- **Each metacognition step with a 2017 counterpart does that step on the projection**,
with the same external action. -/
theorem exec_proj (l : CMC.Meta.Label τ) (l' : CMC.Label σ) (h : lowerLabel l = some l')
    (S : CMC.Meta.State τ) :
    CMC.exec A l' (proj S) =
      (proj (CMC.Meta.exec (liftArch A X) l S).1, (CMC.Meta.exec (liftArch A X) l S).2) := by
  cases l with
  | perceive p i =>
    simp [lowerLabel] at h; subst h
    simp only [CMC.exec, CMC.Meta.exec, proj, liftArch]
    rw [restrict_upd_new _ (rfl : unBase (σ := σ) (.percept p .process) = none),
      show (CMC.Meta.Loc.percept p .content : CMC.Meta.L τ) = ofBase (.percept p) from rfl,
      restrict_upd_ofBase, down_up_list]
  | retrieve d =>
    cases d with
    | none => simp [lowerLabel] at h
    | some d =>
      simp [lowerLabel] at h; subst h
      simp only [CMC.exec, CMC.Meta.exec, proj, liftArch]
      rw [restrict_upd_new _ (rfl : unBase (σ := σ) (.decl (some d) .process) = none),
        show (CMC.Meta.Loc.decl (some d) .result : CMC.Meta.L τ) = ofBase (.decl d .result) from rfl,
        restrict_upd_ofBase, down_up_list]
      simp only [Prod.mk.injEq, and_true]
      congr 1
      funext d'
      by_cases hd : d' = d
      · subst hd; simp [CMC.Meta.upd]
      · simp [CMC.Meta.upd, hd]
  | motor m =>
    simp [lowerLabel] at h; subst h
    simp only [CMC.exec, CMC.Meta.exec, proj, liftArch]
    rw [show (CMC.Meta.Loc.motor m .process : CMC.Meta.L τ) = ofBase (.motor m .result) from rfl,
      restrict_upd_ofBase, down_up_list]
    rfl
  | appraise => simp [lowerLabel] at h
  | learnPercept p i =>
    simp [lowerLabel] at h; subst h
    rfl
  | learnMotor m =>
    simp [lowerLabel] at h; subst h
    rfl
  | cycle =>
    simp [lowerLabel] at h; subst h
    simp only [CMC.exec, CMC.Meta.exec, proj, cycleWM_proj]
    simp only [Prod.mk.injEq, and_true, CMC.State.mk.injEq, true_and]
    refine ⟨?_, ?_⟩
    · exact (dm_upd_none _ _).symm
    · simp [Option.map, restrictE, cycleWM_proj]
  | compose =>
    simp [lowerLabel] at h; subst h
    simp only [CMC.exec, CMC.Meta.exec, proj]
    cases hc : S.lastCycle with
    | none => simp [hc]
    | some e =>
      simp only [Option.map_some, Prod.mk.injEq, and_true, CMC.State.mk.injEq, true_and,
        and_true]
      simp only [liftArch, List.map_append, List.map_map]
      obtain ⟨new, _, he⟩ := A.compose_bounded (S.pm.map lowerRule) (restrictE e)
      rw [he, List.drop_left' (List.length_map ..)]
      simp [Function.comp_def, lower_lift]
  | rl =>
    simp [lowerLabel] at h; subst h
    simp only [CMC.exec, CMC.Meta.exec, proj]
    cases hc : S.lastCycle with
    | none => simp [hc]
    | some e =>
      simp only [Option.map_some, Prod.mk.injEq, and_true, CMC.State.mk.injEq, true_and,
        and_true]
      exact (lower_withMeta _ _ (A.rlTune_symbolic _ _)).symm
  | create d =>
    cases d with
    | none => simp [lowerLabel] at h
    | some d =>
      simp [lowerLabel] at h; subst h
      simp only [CMC.exec, CMC.Meta.exec, proj]
      cases hc : S.lastCycle with
      | none => simp [hc]
      | some e =>
        simp only [Option.map_some, Prod.mk.injEq, and_true, CMC.State.mk.injEq, true_and,
          and_self, dm_upd_some]
        simp [liftArch, dDown_dUp]
  | tune d =>
    cases d with
    | none => simp [lowerLabel] at h
    | some d =>
      simp [lowerLabel] at h; subst h
      simp only [CMC.exec, CMC.Meta.exec, proj]
      cases hc : S.lastCycle with
      | none => simp [hc]
      | some e =>
        simp only [Option.map_some, Prod.mk.injEq, and_true, CMC.State.mk.injEq, true_and,
          and_self, dm_upd_some]
        simp [liftArch, dDown_dUp]
  | decay =>
    simp [lowerLabel] at h; subst h
    simp only [CMC.exec, CMC.Meta.exec, proj]
    simp only [Prod.mk.injEq, and_true, CMC.State.mk.injEq, true_and]
    refine ⟨?_, ?_⟩
    · funext b; simp only [restrict, List.map_map, Function.comp_def]; rfl
    · funext d; simp only [dDown, List.map_map, Function.comp_def]; rfl
  | forgetWM ℓ =>
    cases hu : unBase ℓ with
    | none => simp [lowerLabel, hu] at h
    | some b =>
      simp [lowerLabel, hu] at h; subst h
      have hb := unBase_some hu; subst hb
      have ha := archWritten_ofBase (σ := σ) b
      simp only [CMC.exec, CMC.Meta.exec]
      by_cases hr : b.isResult = true
      · have ha' : CMC.Meta.Loc.archWritten (ofBase (σ := σ) b) = true := ha.trans hr
        rw [ite_eq_left hr, ite_eq_left ha']
      · have ha' : ¬ CMC.Meta.Loc.archWritten (ofBase (σ := σ) b) = true := by rw [ha]; exact hr
        rw [ite_eq_right hr, ite_eq_right ha']
        simp only [proj, Prod.mk.injEq, and_true, CMC.State.mk.injEq]
        rw [restrict_upd_ofBase]
        congr 1
        simp only [restrict, List.filter_map, Function.comp_def]
        rfl
  | forgetDecl d =>
    cases d with
    | none => simp [lowerLabel] at h
    | some d =>
      simp [lowerLabel] at h; subst h
      simp only [CMC.exec, CMC.Meta.exec, proj, dm_upd_some]
      simp only [Prod.mk.injEq, and_true, CMC.State.mk.injEq, true_and]
      congr 1
      simp [dDown, List.filter_map, Function.comp_def]
      rfl

/-- **Each metacognition step with no 2017 counterpart leaves the 2017 state alone** and
produces no external action. -/
theorem exec_new (l : CMC.Meta.Label τ) (h : lowerLabel l = none) (S : CMC.Meta.State τ) :
    proj (CMC.Meta.exec (liftArch A X) l S).1 = proj S ∧
      (CMC.Meta.exec (liftArch A X) l S).2 = none := by
  cases l with
  | perceive => simp [lowerLabel] at h
  | motor => simp [lowerLabel] at h
  | learnPercept => simp [lowerLabel] at h
  | learnMotor => simp [lowerLabel] at h
  | cycle => simp [lowerLabel] at h
  | compose => simp [lowerLabel] at h
  | rl => simp [lowerLabel] at h
  | decay => simp [lowerLabel] at h
  | appraise =>
    refine ⟨?_, rfl⟩
    simp only [CMC.Meta.exec, proj]
    rw [restrict_upd_new _ (rfl : unBase (σ := σ) .wmProcess = none)]
  | retrieve d =>
    cases d with
    | some => simp [lowerLabel] at h
    | none =>
      refine ⟨?_, rfl⟩
      simp only [CMC.Meta.exec, proj]
      rw [restrict_upd_new _ (rfl : unBase (σ := σ) (.decl none .process) = none),
        restrict_upd_new _ (rfl : unBase (σ := σ) (.decl none .result) = none), dm_upd_none]
  | create d =>
    cases d with
    | some => simp [lowerLabel] at h
    | none =>
      refine ⟨?_, ?_⟩ <;> simp only [CMC.Meta.exec] <;> cases hc : S.lastCycle <;> simp [proj, dm_upd_none, hc]
  | tune d =>
    cases d with
    | some => simp [lowerLabel] at h
    | none =>
      refine ⟨?_, ?_⟩ <;> simp only [CMC.Meta.exec] <;> cases hc : S.lastCycle <;> simp [proj, dm_upd_none, hc]
  | forgetDecl d =>
    cases d with
    | some => simp [lowerLabel] at h
    | none =>
      refine ⟨?_, rfl⟩
      simp only [CMC.Meta.exec, proj, dm_upd_none]
  | forgetWM ℓ =>
    have hu : unBase ℓ = none := by
      simp only [lowerLabel, Option.map_eq_none_iff] at h; exact h
    refine ⟨?_, ?_⟩ <;> simp only [CMC.Meta.exec] <;> split <;> try rfl
    simp only [proj]
    rw [restrict_upd_new _ hu]

/-- Keep the entries of `os` whose step has a 2017 counterpart. -/
def keep : List (CMC.Meta.Label τ) → List α → List α
  | l :: ls, o :: os => if (lowerLabel l).isSome then o :: keep ls os else keep ls os
  | _, _ => []

/-- **Whole runs.** The projection of any run of the lifted architecture is the 2017 run of
its corresponding steps, with the same external actions. -/
theorem execAll_proj (ls : List (CMC.Meta.Label τ)) (S : CMC.Meta.State τ) :
    CMC.execAll A (ls.filterMap lowerLabel) (proj S) =
      (proj (CMC.Meta.execAll (liftArch A X) ls S).1,
       keep ls (CMC.Meta.execAll (liftArch A X) ls S).2) := by
  induction ls generalizing S with
  | nil => rfl
  | cons l ls ih =>
    cases hl : lowerLabel l with
    | none =>
      have ⟨h1, _⟩ := exec_new A X l hl S
      simp only [List.filterMap_cons, hl, CMC.Meta.execAll, keep, Option.isSome_none,
        Bool.false_eq_true, ↓reduceIte]
      rw [← h1, ih]
    | some l' =>
      simp only [List.filterMap_cons, hl, CMC.execAll, CMC.Meta.execAll, keep,
        Option.isSome_some, ↓reduceIte, exec_proj A X l l' hl S, ih]

/-- **Every 2017 step is the projection of a metacognition step.** -/
theorem exec_lift (l : CMC.Label σ) (s : CMC.State σ) :
    CMC.exec A l s =
      (proj (CMC.Meta.exec (liftArch A X) (liftLabel l) (liftState s)).1,
       (CMC.Meta.exec (liftArch A X) (liftLabel l) (liftState s)).2) := by
  rw [← exec_proj A X _ l (lowerLabel_liftLabel l), proj_liftState]

theorem keep_lift (ls : List (CMC.Label σ)) (os : List α) (h : os.length = ls.length) :
    keep (ls.map liftLabel) os = os := by
  induction ls generalizing os with
  | nil => cases os <;> simp_all [keep]
  | cons l ls ih =>
    cases os with
    | nil => simp at h
    | cons o os =>
      simp only [List.map_cons, keep, lowerLabel_liftLabel, Option.isSome_some, ↓reduceIte,
        ih os (by simpa using h)]

theorem execAll_length (A' : CMC.Meta.Arch τ) (ls : List (CMC.Meta.Label τ)) (S) :
    (CMC.Meta.execAll A' ls S).2.length = ls.length := by
  induction ls generalizing S with
  | nil => rfl
  | cons l ls ih => simp [CMC.Meta.execAll, ih]

/-- **Every 2017 run is the projection of a metacognition run**, for any choice of the
metacognitive behaviour, with the same external actions. -/
theorem execAll_lift (ls : List (CMC.Label σ)) (s : CMC.State σ) :
    CMC.execAll A ls s =
      (proj (CMC.Meta.execAll (liftArch A X) (ls.map liftLabel) (liftState s)).1,
       (CMC.Meta.execAll (liftArch A X) (ls.map liftLabel) (liftState s)).2) := by
  have h := execAll_proj A X (ls.map liftLabel) (liftState s)
  rw [List.filterMap_map, show (lowerLabel ∘ liftLabel : CMC.Label σ → _) = some from
      funext lowerLabel_liftLabel, List.filterMap_some, proj_liftState] at h
  rw [h, keep_lift _ _ (by rw [execAll_length, List.length_map])]

/-! ## Coverage

| claim | theorem |
|---|---|
| every 2017 architecture, with any metacognitive behaviour, is a metacognition architecture | `liftArch` |
| motor status is the motor process area; 2017 declarative memories are the semantic memories | `ofBase`, `metaSig` |
| architecture-written locations agree | `archWritten_ofBase` |
| corresponding steps agree on the 2017 part, with the same action | `exec_proj` |
| new steps leave the 2017 part alone and act on nothing | `exec_new` |
| whole runs project to 2017 runs | `execAll_proj` |
| every 2017 run is a projected metacognition run | `exec_lift`, `execAll_lift` |
| semantic retrieval must not touch metadata for this to hold | `liftArch.retrieveTouch` (identity on `some d`) |
-/

end CMC.Refine
