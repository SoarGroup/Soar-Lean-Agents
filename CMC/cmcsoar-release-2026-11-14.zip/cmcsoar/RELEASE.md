# Release 2026-11-14 (locked)

This is the reference version of the Lean specification of the CMC and of Soar (cmcsoar).
Every chat and project that uses the Lean specification starts from this release:
`cmcsoar-release-2026-11-14.zip` in Soar-Lean-Agents/CMC. Later work builds on it and makes a
new release; it does not start from an older zip.

| Item | Value |
|---|---|
| Lean toolchain | leanprover/lean4:v4.35.0 (`lean-toolchain`) |
| Reference Soar | Soar 9.6.6 (SoarSuite_9_6_6-bigbugfixrelease; kernel reports 9.6.50) |
| Contents | CMC 2017, metacognition and emotion versions; Soar on the CMC, including chunking, RL, semantic and episodic memory, WMA, the Rete model and SVS; executable `soar-lean` with the incremental execution layer (speed work closed) |
| Theorems | 691 (682 Soar, 9 CMC backbone) checked by `lake build`, no unproved steps, standard axioms only; plus 74 in the CMC version files |
| Regression | 5,859 of 5,865 programs match Soar 9.6.6 (differences: AlphabetAgentAllOn and SVS heap-address ties) |
| Map | doc/Soar-Lean-map.xlsx: 1,029 definitions linked to the Soar 9.6.6 source |
| Supersedes | all earlier cmcsoar zips (2026-11-13, -966, -cmc, -svsin, -speed1 to -speed4, -map) |

Check a copy: `lake build && lake build soar-lean`, then `tools/run_all.sh` for the regression.
