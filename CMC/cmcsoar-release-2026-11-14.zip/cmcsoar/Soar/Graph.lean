import Std.Data.HashMap
import Std.Data.HashSet
/-!
# Soar 9.6 — closure of a graph on identifiers

`closure succ roots fuel`: the identifiers reachable from `roots` along `succ`, found level by
level. `mem_closure_iff`: with enough fuel (more than the length of any list `U` that holds
the roots and every successor), an identifier is in the closure exactly when it is reachable.

The specification's `reach` (working memory linked to a state, [Man] §2.2) is the closure of
the links of working-memory elements; the execution layer (Soar/Cycle.lean, `WmIx`) computes the
same closure from an index of the links kept up to date between working-memory phases.
-/

namespace Soar

/-- Reachability along `succ` from `roots`. -/
inductive RG (succ : Nat → List Nat) (roots : List Nat) : Nat → Prop
  | root {i : Nat} : i ∈ roots → RG succ roots i
  | step {j i : Nat} : RG succ roots j → i ∈ succ j → RG succ roots i

/-- One level: add the successors not seen yet to `seen`, and list them. -/
def closureStep (seen : Std.HashSet Nat) (next : List Nat) : Std.HashSet Nat × List Nat :=
  next.foldl (fun (acc : Std.HashSet Nat × List Nat) j =>
    if acc.1.contains j then acc else (acc.1.insert j, j :: acc.2)) (seen, [])

/-- The search, level by level: `seen` holds what has been found, `frontier` what was found at
the last level. -/
def closureGo (succ : Nat → List Nat) : Nat → Std.HashSet Nat → List Nat → Std.HashSet Nat
  | 0, seen, _ => seen
  | n + 1, seen, frontier =>
    let r := closureStep seen (frontier.flatMap succ)
    if r.2.isEmpty then seen else closureGo succ n r.1 r.2

/-- The identifiers reachable from `roots` along `succ` (`fuel` levels at most). -/
def closure (succ : Nat → List Nat) (roots : List Nat) (fuel : Nat) : Std.HashSet Nat :=
  closureGo succ fuel (Std.HashSet.ofList roots) roots

theorem closureStep_spec (seen : Std.HashSet Nat) : ∀ (l : List Nat) (acc : Std.HashSet Nat × List Nat),
    (∀ x, seen.contains x = true → acc.1.contains x = true) →
    (∀ x, x ∈ acc.2 ↔ acc.1.contains x = true ∧ seen.contains x = false) →
    let r := l.foldl (fun (acc : Std.HashSet Nat × List Nat) j =>
      if acc.1.contains j then acc else (acc.1.insert j, j :: acc.2)) acc
    (∀ x, r.1.contains x = true ↔ acc.1.contains x = true ∨ x ∈ l) ∧
    (∀ x, x ∈ r.2 ↔ r.1.contains x = true ∧ seen.contains x = false) := by
  intro l
  induction l with
  | nil => intro acc _ h2; refine ⟨fun x => ?_, h2⟩; simp
  | cons a l ih =>
    intro acc h1 h2
    simp only [List.foldl_cons]
    by_cases ha : acc.1.contains a = true
    · simp only [ha, ↓reduceIte]
      obtain ⟨r1, r2⟩ := ih acc h1 h2
      refine ⟨fun x => ?_, r2⟩
      rw [r1, List.mem_cons]
      constructor
      · rintro (h | h)
        · exact Or.inl h
        · exact Or.inr (Or.inr h)
      · rintro (h | rfl | h)
        · exact Or.inl h
        · exact Or.inl ha
        · exact Or.inr h
    · have ha' : acc.1.contains a = false := by simpa using ha
      simp only [ha', Bool.false_eq_true, ↓reduceIte]
      have hs : seen.contains a = false := by
        cases hc : seen.contains a
        · rfl
        · exact absurd (h1 a hc) ha
      obtain ⟨r1, r2⟩ := ih (acc.1.insert a, a :: acc.2)
        (fun x hx => by simp [Std.HashSet.contains_insert, h1 x hx])
        (fun x => by
          simp only [List.mem_cons, Std.HashSet.contains_insert]
          constructor
          · rintro (rfl | h)
            · simp [hs]
            · have := (h2 x).mp h; simp [this.1, this.2]
          · rintro ⟨h, hx⟩
            by_cases hxa : x = a
            · exact Or.inl hxa
            · have : acc.1.contains x = true := by
                simp only [Bool.or_eq_true, beq_iff_eq] at h
                rcases h with h | h
                · exact absurd h.symm hxa
                · exact h
              exact Or.inr ((h2 x).mpr ⟨this, hx⟩))
      refine ⟨fun x => ?_, r2⟩
      rw [r1, List.mem_cons, Std.HashSet.contains_insert]
      simp only [Bool.or_eq_true, beq_iff_eq]
      constructor
      · rintro ((h | h) | h)
        · exact Or.inr (Or.inl h.symm)
        · exact Or.inl h
        · exact Or.inr (Or.inr h)
      · rintro (h | h | h)
        · exact Or.inl (Or.inr h)
        · exact Or.inl (Or.inl h.symm)
        · exact Or.inr h

theorem closureStep_contains (seen : Std.HashSet Nat) (l : List Nat) (x : Nat) :
    (closureStep seen l).1.contains x = true ↔ seen.contains x = true ∨ x ∈ l :=
  (closureStep_spec seen l (seen, []) (fun _ h => h) (fun x => by
    simp only [List.not_mem_nil, false_iff, not_and]; intro h1 h2; rw [h1] at h2; cases h2)).1 x

theorem closureStep_new (seen : Std.HashSet Nat) (l : List Nat) (x : Nat) :
    x ∈ (closureStep seen l).2 ↔ x ∈ l ∧ seen.contains x = false := by
  have := (closureStep_spec seen l (seen, []) (fun _ h => h) (fun x => by
    simp only [List.not_mem_nil, false_iff, not_and]; intro h1 h2; rw [h1] at h2; cases h2)).2 x
  unfold closureStep
  rw [this, ← closureStep.eq_def, closureStep_contains]
  constructor
  · rintro ⟨h | h, hs⟩
    · rw [h] at hs; cases hs
    · exact ⟨h, hs⟩
  · rintro ⟨h, hs⟩; exact ⟨Or.inr h, hs⟩

/-- The measure of the search: the identifiers of `U` not seen yet. -/
def unseenCnt (U : List Nat) (seen : Std.HashSet Nat) : Nat := U.countP (fun x => !seen.contains x)

theorem unseenCnt_lt (U : List Nat) (seen seen' : Std.HashSet Nat)
    (hsub : ∀ x, seen.contains x = true → seen'.contains x = true)
    (j : Nat) (hj : j ∈ U) (h1 : seen.contains j = false) (h2 : seen'.contains j = true) :
    unseenCnt U seen' < unseenCnt U seen := by
  unfold unseenCnt
  induction U with
  | nil => cases hj
  | cons a U ih =>
    simp only [List.countP_cons]
    rcases List.mem_cons.mp hj with rfl | hj
    · have hle : U.countP (fun x => !seen'.contains x) ≤ U.countP (fun x => !seen.contains x) :=
        List.countP_mono_left (fun x _ hx => by
          cases hs : seen.contains x
          · rfl
          · simp [hsub x hs] at hx)
      simp [h1, h2]; omega
    · have := ih hj
      have hle : (if (!seen'.contains a) = true then 1 else 0) ≤ (if (!seen.contains a) = true then 1 else 0) := by
        cases hs : seen.contains a
        · simp; split <;> omega
        · simp [hsub a hs]
      omega

theorem closureGo_spec (succ : Nat → List Nat) (roots U : List Nat)
    (hU : ∀ i j, j ∈ succ i → j ∈ U) :
    ∀ (n : Nat) (seen : Std.HashSet Nat) (frontier : List Nat),
    (∀ x, seen.contains x = true → RG succ roots x) →
    (∀ x ∈ frontier, seen.contains x = true) →
    (∀ x, seen.contains x = true → x ∉ frontier → ∀ y ∈ succ x, seen.contains y = true) →
    (∀ x ∈ roots, seen.contains x = true) →
    unseenCnt U seen < n →
    ∀ x, (closureGo succ n seen frontier).contains x = true ↔ RG succ roots x := by
  intro n
  induction n with
  | zero => intro _ _ _ _ _ _ h; exact absurd h (Nat.not_lt_zero _)
  | succ n ih =>
    intro seen frontier H1 H2 H3 H4 hn
    unfold closureGo
    simp only
    by_cases he : (closureStep seen (frontier.flatMap succ)).2.isEmpty = true
    · simp only [he, ↓reduceIte]
      have hnil := List.isEmpty_iff.mp he
      -- every successor of the frontier is seen
      have hfr : ∀ x ∈ frontier, ∀ y ∈ succ x, seen.contains y = true := by
        intro x hx y hy
        cases hc : seen.contains y
        · have := (closureStep_new seen _ y).mpr ⟨List.mem_flatMap.mpr ⟨x, hx, hy⟩, hc⟩
          rw [hnil] at this; cases this
        · rfl
      intro x
      constructor
      · exact H1 x
      · intro hr
        induction hr with
        | root h => exact H4 _ h
        | @step j i _ hi ihj =>
          by_cases hj : j ∈ frontier
          · exact hfr j hj i hi
          · exact H3 j ihj hj i hi
    · have he' : (closureStep seen (frontier.flatMap succ)).2.isEmpty = false := by simpa using he
      simp only [he', Bool.false_eq_true, ↓reduceIte]
      generalize hr : closureStep seen (frontier.flatMap succ) = r at he' ⊢
      have hc : ∀ x, r.1.contains x = true ↔ seen.contains x = true ∨ x ∈ frontier.flatMap succ := by
        intro x; rw [← hr]; exact closureStep_contains seen _ x
      have hnw : ∀ x, x ∈ r.2 ↔ x ∈ frontier.flatMap succ ∧ seen.contains x = false := by
        intro x; rw [← hr]; exact closureStep_new seen _ x
      obtain ⟨j, hj⟩ : ∃ j, j ∈ r.2 := by
        cases h : r.2 with
        | nil => rw [h] at he'; cases he'
        | cons a _ => exact ⟨a, by simp⟩
      apply ih r.1 r.2
      · intro x hx
        rcases (hc x).mp hx with h | h
        · exact H1 x h
        · obtain ⟨y, hy, hxy⟩ := List.mem_flatMap.mp h
          exact RG.step (H1 y (H2 y hy)) hxy
      · intro x hx; exact (hc x).mpr (Or.inr ((hnw x).mp hx).1)
      · intro x hx hxn y hy
        rcases (hc x).mp hx with h | h
        · by_cases hxf : x ∈ frontier
          · exact (hc y).mpr (Or.inr (List.mem_flatMap.mpr ⟨x, hxf, hy⟩))
          · exact (hc y).mpr (Or.inl (H3 x h hxf y hy))
        · -- x was found at this level, so it is new unless it was already seen
          by_cases hs : seen.contains x = true
          · by_cases hxf : x ∈ frontier
            · exact (hc y).mpr (Or.inr (List.mem_flatMap.mpr ⟨x, hxf, hy⟩))
            · exact (hc y).mpr (Or.inl (H3 x hs hxf y hy))
          · have : seen.contains x = false := by simpa using hs
            exact absurd ((hnw x).mpr ⟨h, this⟩) hxn
      · intro x hx; exact (hc x).mpr (Or.inl (H4 x hx))
      · have hjn := (hnw j).mp hj
        obtain ⟨y, _, hjy⟩ := List.mem_flatMap.mp hjn.1
        have := unseenCnt_lt U seen r.1 (fun x h => (hc x).mpr (Or.inl h)) j (hU y j hjy) hjn.2
          ((hc j).mpr (Or.inr hjn.1))
        omega

/-- **The closure is reachability**, given more fuel than the length of a list holding every
successor. -/
theorem mem_closure_iff (succ : Nat → List Nat) (roots U : List Nat)
    (hU : ∀ i j, j ∈ succ i → j ∈ U) (fuel : Nat)
    (hf : U.length < fuel) (x : Nat) :
    (closure succ roots fuel).contains x = true ↔ RG succ roots x := by
  unfold closure
  apply closureGo_spec succ roots U hU fuel
  · intro y hy; exact RG.root (by simpa [Std.HashSet.contains_ofList] using hy)
  · intro y hy; simp [Std.HashSet.contains_ofList, hy]
  · intro y hy hyn; exact absurd (by simpa [Std.HashSet.contains_ofList] using hy) hyn
  · intro y hy; simp [Std.HashSet.contains_ofList, hy]
  · have : unseenCnt U (Std.HashSet.ofList roots) ≤ U.length := List.countP_le_length
    omega

end Soar
