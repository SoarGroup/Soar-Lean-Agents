import Soar.SVS.Gjk
/-!
# SVS — the remaining spatial algorithms

Soar 9.6.6 `sgnode_algs.cpp`, `filters/calculate_placement.cpp`, `mat.cpp`: placement,
occlusion, overlap (by random sampling) and the size adjustment of `copy_node` and
`copy_transform` (`^adjust`).

Overlap samples points with C's `rand()`, which nothing else in Soar calls and nothing seeds:
it is glibc's generator from its default seed, continuing through the whole process (so in
Soar, through every agent run in it). The model has one generator per run, as a new process.
-/

namespace Soar.SVS

/-! ## glibc's `rand()` -/

/-- glibc's `random()` state (`TYPE_3`: the last 34 outputs of the additive generator). -/
structure CRand where
  tab : Array UInt32
  deriving Inhabited

/-- `srand(1)`, glibc's default: the table from the seed by the minimal standard generator,
then 310 values discarded. -/
def CRand.init : CRand := Id.run do
  let mut r : Array UInt32 := #[1]
  for i in [1:31] do
    let prev : Int := (r[i - 1]!.toNat : Int)
    let hi := prev / 127773
    let lo := prev % 127773
    let mut w := 16807 * lo - 2836 * hi
    if w < 0 then w := w + 2147483647
    r := r.push (UInt32.ofNat w.toNat)
  for i in [31:34] do r := r.push r[i - 31]!
  for i in [34:344] do r := r.push (r[i - 31]! + r[i - 3]!)
  return { tab := r.extract (344 - 34) 344 }

/-- `rand()`: the next value in `[0, RAND_MAX]`. -/
def CRand.next (g : CRand) : Nat × CRand :=
  let v := g.tab[3]! + g.tab[31]!   -- r[i-31] + r[i-3]
  ((v >>> 1).toNat, { tab := (g.tab.extract 1 34).push v })

def randMax : Float := 2147483647.0

/-- `bbox::get_random_point` (`randomize_vec`). -/
def BBox.randomPoint (b : BBox) (g : CRand) : V3 × CRand := Id.run do
  let mut g := g
  let mut v := V3.zero
  for i in [0, 1, 2] do
    let (r, g') := g.next
    g := g'
    v := v.set i (b.lo.get i + (Float.ofNat r / randMax) * (b.hi.get i - b.lo.get i))
  return (v, g)

/-! ## Quaternions (for `transform3('r', v)`) -/

structure Quat where
  x : Float
  y : Float
  z : Float
  w : Float

/-- `Quaternion(AngleAxis)`. -/
def Quat.ofAA (ang : Float) (ax : V3) : Quat :=
  let ha := 0.5 * ang
  let s := ha.sin
  ⟨s * ax.x, s * ax.y, s * ax.z, ha.cos⟩

/-- Eigen's quaternion product on SSE (`quat_product<…, double>`, Geometry_SIMD.h). -/
def Quat.mul (a b : Quat) : Quat :=
  ⟨(a.w * b.x + a.y * b.z) - (a.z * b.y - a.x * b.w),
   (a.w * b.y + a.y * b.w) + (a.z * b.x - a.x * b.z),
   (a.w * b.z - a.y * b.x) + (a.z * b.w + a.x * b.y),
   (a.w * b.w - a.y * b.y) - (a.z * b.z + a.x * b.x)⟩

def Quat.toM3 (q : Quat) : M3 :=
  let tx := 2 * q.x
  let ty := 2 * q.y
  let tz := 2 * q.z
  let twx := tx * q.w
  let twy := ty * q.w
  let twz := tz * q.w
  let txx := tx * q.x
  let txy := ty * q.x
  let txz := tz * q.x
  let tyy := ty * q.y
  let tyz := tz * q.y
  let tzz := tz * q.z
  ⟨⟨1 - (tyy + tzz), txy - twz, txz + twy⟩,
   ⟨txy + twz, 1 - (txx + tzz), tyz - twx⟩,
   ⟨txz - twy, tyz + twx, 1 - (txx + tyy)⟩⟩

/-- `transform3('r', v)`: `AngleAxis(v.z, Z) * AngleAxis(v.y, Y) * AngleAxis(v.x, X)`, which
Eigen multiplies as quaternions. -/
def rotXf (r : V3) : Xf :=
  let q := Quat.mul (Quat.mul (Quat.ofAA r.z ⟨0, 0, 1⟩) (Quat.ofAA r.y ⟨0, 1, 0⟩)) (Quat.ofAA r.x ⟨1, 0, 0⟩)
  ⟨q.toM3, V3.zero⟩

namespace Scene

/-- `calculate_placement`: where to put `a` beside `b`, separated along each axis of `ref`'s
rotation (or the world's) by the given amounts. -/
def placement (sc : Scene) (a b : Nat) (ref : Option Nat) (sep : V3) : V3 := Id.run do
  let pa := sc.centroid a
  let pb := sc.centroid b
  let mut axes : Array V3 := #[⟨1, 0, 0⟩, ⟨0, 1, 0⟩, ⟨0, 0, 1⟩]
  if let some r := ref then
    let rot := rotXf (sc.node r).rot
    axes := axes.map rot.apply
  let mut mina := V3.zero
  let mut minb := V3.zero
  let mut maxa := V3.zero
  let mut maxb := V3.zero
  for d in [0, 1, 2] do
    let ax := axes[d]!
    mina := mina.set d (sc.minProj a ax - ax.dot pa)
    minb := minb.set d (sc.minProj b ax - ax.dot pb)
    maxa := maxa.set d (sc.maxProj a ax - ax.dot pa)
    maxb := maxb.set d (sc.maxProj b ax - ax.dot pb)
  let mut pos := pb
  for d in [0, 1, 2] do
    let ax := axes[d]!
    let sd := sep.get d
    if sd > 0 then
      let k := maxb.get d + sd - mina.get d
      pos := V3.add pos ⟨ax.x * k, ax.y * k, ax.z * k⟩
    else if sd < 0 then
      let k := -minb.get d - sd + maxa.get d
      pos := V3.sub pos ⟨ax.x * k, ax.y * k, ax.z * k⟩
  return pos

/-- The number given to temporary nodes (not in the scene's tree). -/
def tmpBase : Nat := 2 ^ 40

/-- `convex_distance` from a scene node to a standalone node (`n` has no parent). -/
def distTo (sc : Scene) (a : Nat) (n : Node) : Float :=
  let u := tmpBase
  (sc.insertNew u n).convexDistance a u

/-- `calc_view_lines`: from the eye's centroid to each vertex of the target's convex parts,
a two-point convex node centred halfway (`create_view_line`). -/
def viewLines (sc : Scene) (target eye : Nat) : List (V3 × V3) :=
  let eyePos := sc.centroid eye
  (sc.geoms target).flatMap fun g =>
    match (sc.node g).shape with
    | .convex _ => (sc.worldVerts g).map fun v =>
      let d : V3 := ⟨(v.x - eyePos.x) / 2, (v.y - eyePos.y) / 2, (v.z - eyePos.z) / 2⟩
      (V3.add eyePos d, d)
    | _ => []

def lineNode (c d : V3) : Node :=
  { name := "_temp_line_", shape := .convex [d, ⟨-d.x, -d.y, -d.z⟩], pos := c }

/-- `convex_occlusion`: the fraction of the view lines that some occluder touches. -/
def occlusion (sc : Scene) (lines : Array (V3 × V3)) (occluders : List Nat) : Float := Id.run do
  if lines.isEmpty || occluders.isEmpty then return 0
  let mut occl : Array Bool := lines.map fun _ => false
  let mut num := 0
  for n in occluders do
    for j in [0:lines.size] do
      if occl[j]! then continue
      let (c, d) := lines[j]!
      if sc.distTo n (lineNode c d) ≤ 0 then
        occl := occl.set! j true
        num := num + 1
  return Float.ofNat num / Float.ofNat lines.size

/-- `convex_overlap`: the fraction of random points of `n1`'s box inside `n1` that are inside
`n2` (up to `ns` such points, 100 000 tries). -/
def overlap (sc : Scene) (n1 n2 : Nat) (ns : Nat) (g : CRand) : Float × CRand := Id.run do
  if n1 == n2 || sc.hasDesc n1 n2 || sc.hasDesc n2 n1 then return (0, g)
  let g1 := sc.geoms n1
  let g2 := sc.geoms n2
  if g2.isEmpty then return (0, g)
  if g1.isEmpty then
    let pt := sc.centroid n1
    for x in g2 do
      if Ccd.gjkDist sc (.pt pt) (.node x) ≤ 0 then return (1, g)
    return (0, g)
  if sc.convexDistance n1 n2 > 0 then return (0, g)
  let bounds := sc.bounds n1
  let mut g := g
  let mut nS := 0
  let mut nI := 0
  let mut it := 0
  while nS < ns && it < 100000 do
    it := it + 1
    let (p, g') := bounds.randomPoint g
    g := g'
    if !(g1.any fun x => Ccd.gjkDist sc (.pt p) (.node x) ≤ 0) then continue
    nS := nS + 1
    if !(g2.any fun x => Ccd.gjkDist sc (.pt p) (.node x) ≤ 0) then continue
    nI := nI + 1
  return (if nS == 0 then 0 else Float.ofNat nI / Float.ofNat nS, g)

/-- A copy of node `u` and its descendants, standalone (not attached), numbered from `next`. -/
partial def cloneLoose (sc : Scene) (u : Nat) (par : Option Nat) (next : Nat) : Scene × Nat × Nat :=
  let n := sc.node u
  let me := next
  let sc' := sc.insertNew me { n with parent := par, kids := [] }
  let (sc', k, ks) := n.kids.foldl (fun (acc : Scene × Nat × List Nat) c =>
    let (s, k, ks) := acc
    let (s, k, cu) := cloneLoose s c (some me) k
    (s, k, ks ++ [cu])) (sc', next + 1, [])
  (sc'.upd me fun m => { m with kids := ks }, k, me)

def intersectsAny (sc : Scene) (n : Nat) (ts : List Nat) : Bool := ts.any (sc.convexIntersects n)

/-- `adjust_on_dims`: shrink the copy's scale along the given dimensions by bisection until it
no longer intersects the targets. -/
def adjustOnDims (sc : Scene) (n : Nat) (ts : List Nat) (d1 d2 d3 : Nat) : V3 := Id.run do
  let scale := (sc.node n).scl
  let mut t := scale
  let mut lo := 0.001
  let mut hi := 1.0
  let mut sc := sc
  for _ in [0:8] do
    let s := (hi + lo) / 2
    t := ((t.set d1 (scale.get d1 * s)).set d2 (scale.get d2 * s)).set d3 (scale.get d3 * s)
    sc := sc.upd n fun m => { m with scl := t }
    if sc.intersectsAny n ts then hi := s else lo := s
  t := ((t.set d1 (scale.get d1 * lo * 0.98)).set d2 (scale.get d2 * lo * 0.98)).set d3 (scale.get d3 * lo * 0.98)
  return t

/-- `adjust_sgnode_size(n, scn)`: the new scale for `n` so that it does not intersect the nodes
tagged `object-source belief`, or `none` to leave it. -/
def adjustSize (sc : Scene) (n : Nat) : Option V3 := Id.run do
  let targets := (sc.order.filter (· != n)).filter fun u =>
    (sc.node u).tags.any (fun (k, v) => k == "object-source" && v == "belief")
  let inter := targets.filter fun t => t != n && sc.convexIntersects n t
  if inter.isEmpty then return none
  let cpt : Node := { name := "temp-centroid", shape := .convex [sc.centroid n] }
  let cu := tmpBase
  if (sc.insertNew cu cpt).intersectsAny cu inter then return none
  let (sc1, _, cp) := sc.cloneLoose n none (tmpBase + 1)
  let scale := (sc.node n).scl
  let setS (s : Scene) (v : V3) : Scene := s.upd cp fun m => { m with scl := v }
  let mut free : Int := -1
  for d in ([0, 1, 2] : List Nat) do
    let s := setS sc1 (scale.set d (scale.get d * 0.001))
    if !s.intersectsAny cp inter then
      if free == -1 then free := (d : Int) else
        free := -1
        break
  let sc1 := setS sc1 scale
  if free != -1 then
    let d := free.toNat
    return some (sc1.adjustOnDims cp inter d d d)
  for d in ([0, 1, 2] : List Nat) do
    let d1 := (d + 1) % 3
    let d2 := (d + 2) % 3
    let s := setS sc1 ((scale.set d1 (scale.get d1 * 0.001)).set d2 (scale.get d2 * 0.001))
    if !s.intersectsAny cp inter then
      if free == -1 then free := (d : Int) else
        free := -1
        break
  if free != -1 then
    let d := free.toNat
    return some (sc1.adjustOnDims cp inter ((d + 1) % 3) ((d + 2) % 3) ((d + 2) % 3))
  return some (sc1.adjustOnDims cp inter 0 1 2)

end Scene
end Soar.SVS
