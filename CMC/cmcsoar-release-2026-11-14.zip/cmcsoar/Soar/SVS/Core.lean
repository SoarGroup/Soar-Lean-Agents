import Soar.SVS.Filter
import Soar.SVS.Algs
/-!
# SVS — states, the scene-graph mirror, commands and the kernel's callbacks

Soar 9.6.6 `svs.cpp`, `command.cpp`, `commands/*.cpp`, `filter_table.cpp` (`parse_filter_spec`).

For each state (all states unless `svs --disable-in-substates`) SVS keeps a scene, and links
it into working memory: `(<s> ^svs <v>)`, `(<v> ^command <c> ^spatial-scene <i>)`, and below
`<i>` a mirror of the scene graph — `(<i> ^id world ^child <c1> …)`, `(<c1> ^id box1 ^color
red …)`, a node's tags as its attributes. A substate's scene starts as a copy of its
superstate's.

The agent gives commands by linking structures to `^command`. In the output phase SVS notes
which commands are new and which are gone (`process_cmds`); in the input phase it runs the
commands that change the scene, in all states, then those that read it (`extract`, which
puts a tree of filters' results in working memory). The elements SVS makes are architecture
elements: they have no preferences, and SVS removes them (`add_module_wme`,
`remove_module_wme`).
-/

namespace Soar.SVS

/-- One node's part of the working-memory mirror (`sgwme`). -/
structure Mir where
  id : Nat
  idW : WME
  /-- Tag elements by tag name (sorted). -/
  tags : List (String × WME) := []
  /-- Children: the child node and its `^child` element. -/
  kids : List (Nat × WME) := []
  parent : Option Nat := none
  deriving Inhabited

inductive CK where
  | addNode | copyNode | delNode | setTrans | setTag | delTag | copyTrans | extract (once : Bool)
  deriving Inhabited, BEq

def CK.ofName : String → Option CK
  | "add_node" => some .addNode | "copy_node" => some .copyNode | "delete_node" => some .delNode
  | "set_transform" => some .setTrans | "set_tag" => some .setTag | "delete_tag" => some .delTag
  | "copy_transform" => some .copyTrans | "extract" => some (.extract false)
  | "extract_once" => some (.extract true)
  | _ => none

def CK.isRead : CK → Bool
  | .extract _ => true
  | _ => false

/-- An `extract` record: `(<result> ^record <r>)`, `(<r> ^value … ^params <p>)`. -/
structure Rec where
  params : Option Nat
  recW : WME
  recId : Nat
  valW : WME
  parId : Nat
  deriving Inhabited

structure Cmd where
  ck : CK
  root : Nat
  name : String
  /-- The command's own first update. -/
  first : Bool := true
  status : String := ""
  statusW : Option WME := none
  /-- `command::changed`: its first call, and the size of the command's structure then. -/
  chFirst : Bool := true
  subSize : Nat := 0
  resRoot : Option Nat := none
  tree : Option Tree := none
  top : Nat := 0
  recs : List (Nat × Rec) := []
  deriving Inhabited

structure SState where
  goal : Nat
  level : Nat
  svsLink : Nat
  cmdLink : Nat
  sceneLink : Nat
  scene : Scene
  mir : Std.HashMap Nat Mir := {}
  /-- The current commands, ordered by their identifiers' names (`curr_cmds`). -/
  cmds : Array Cmd := #[]
  deriving Inhabited

structure SvsSt where
  on : Bool := false
  inSub : Bool := true
  states : List SState := []
  /-- `svs::filter_dirty_bit` (a static member, initially true). -/
  dirty : Bool := true
  uid : Nat := 1
  key : Nat := 1
  serial : Nat := 0
  /-- The top state's scene, kept when the top state goes (`scn_cache`). -/
  cache : Option Scene := none
  /-- The elements SVS has made that are in working memory, oldest first. -/
  own : Array WME := #[]
  /-- Elements made when a state was made, with the state's level (for numbering them). -/
  initW : Std.HashMap WME Nat := {}
  /-- C's `rand()` (overlap sampling). -/
  rng : CRand := CRand.init
  deriving Inhabited

structure Ctx where
  sv : SvsSt
  next : Nat
  view : View
  adds : Array WME := #[]
  rems : Array WME := #[]
  lets : Array (Nat × Nat) := #[]

abbrev M := StateM Ctx

/-- The first element number SVS uses (`WME.dup`): each element it makes is distinct, as in
Soar, where one removed and made again is a new element. -/
def dupBase : Nat := 1000000

def newId (c : Char) : M Nat := modifyGet fun x =>
  (x.next, { x with next := x.next + 1, lets := x.lets.push (x.next, c.toNat) })

def mkW (id : Nat) (a : String) (v : Sym) : M WME := modifyGet fun x =>
  let w : WME := { id, attr := .str a, val := v, dup := dupBase + x.sv.serial }
  (w, { x with sv := { x.sv with serial := x.sv.serial + 1, own := x.sv.own.push w }, adds := x.adds.push w })

/-- The letter `make_new_identifier` gives for a name letter: upper case; `S` becomes `I`. -/
def idLetter (c : Char) : Char :=
  if c.isAlpha then (if c.toUpper == 'S' then 'I' else c.toUpper) else 'I'

/-- `soar_interface::make_id_wme`: a new identifier, lettered by the attribute's first letter. -/
def mkIdW (id : Nat) (a : String) (letter : Option Char := none) : M (WME × Nat) := do
  let c := match letter with | some c => c | none => idLetter (a.toList.headD 'a')
  let n ← newId c
  let w ← mkW id a (.id n)
  return (w, n)

def rmW (w : WME) : M Unit := modify fun x =>
  if x.sv.own.contains w then { x with sv := { x.sv with own := x.sv.own.erase w }, rems := x.rems.push w } else x

def newKey : M Nat := modifyGet fun x => (x.sv.key, { x with sv := { x.sv with key := x.sv.key + 1 } })
def newUid : M Nat := modifyGet fun x => (x.sv.uid, { x with sv := { x.sv with uid := x.sv.uid + 1 } })

/-- An identifier's elements as `get_child_wmes` lists them: SVS's own, newest first, then the
agent's in Soar's order. -/
def kidsOf (n : Nat) : M (List WME) := do
  let x ← get
  return (x.sv.own.toList.reverse.filter (·.id == n)) ++ x.view.kids n

def findChild (n : Nat) (a : String) : M (Option WME) := do
  return (← kidsOf n).find? (·.attr == .str a)

def symStr? : Sym → Option String
  | .str s => some s
  | _ => none

def symNum? : Sym → Option Float
  | .int i => some (Float.ofInt i)
  | .float b => some (Float.ofBits b)
  | _ => none

/-- `get_const_attr` for a string. -/
def constStr (n : Nat) (a : String) : M (Option String) := do
  match ← findChild n a with
  | some w => return symStr? w.val
  | none => return none

/-- `soar_interface::get_vec3`. -/
def getVec3 (n : Nat) (a : String) : M (Option V3) := do
  match ← findChild n a with
  | some w =>
    match w.val with
    | .id r =>
      let dim (d : String) : M (Option Float) := do
        match ← findChild r d with
        | some x => return symNum? x.val
        | none => return none
      match ← dim "x", ← dim "y", ← dim "z" with
      | some x, some y, some z => return some ⟨x, y, z⟩
      | _, _, _ => return none
    | _ => return none
  | none => return none

/-! ## Filters: updating -/

abbrev TM := StateT Tree M

def gf (i : Nat) : TM Flt := return (← get).fl[i]!
def mf (i : Nat) (g : Flt → Flt) : TM Unit := modify fun t => { t with fl := t.fl.modify i g }
def tKey : TM Nat := liftM newKey
def useRng {α : Type} (f : CRand → α × CRand) : TM α := liftM (m := M) (modifyGet fun x =>
  let (a, g) := f x.sv.rng
  (a, { x with sv := { x.sv with rng := g } }))
def setVal (k : Nat) (v : FV) (dirty : Bool := true) : TM Unit :=
  modify fun t => { t with vals := t.vals.insert k (v, dirty) }
def getVal (k : Nat) : TM FV := return ((← get).vals.get? k).map (·.1) |>.getD default

/-- `filter::set_status`. -/
def fStatus (i : Nat) (msg : String) : TM Unit := do
  let f ← gf i
  if f.status == msg then return
  mf i fun f => { f with status := msg }
  match f.root with
  | some r =>
    if let some w := f.statusW then liftM (rmW w)
    let w ← liftM (mkW r "status" (.str msg))
    mf i fun f => { f with statusW := some w }
  | none => pure ()

def outAdd (i k : Nat) : TM Unit := mf i fun f => { f with out := f.out.add k }
def outRemove (i k : Nat) : TM Unit := mf i fun f => { f with out := f.out.remove k }
def outChange (i k : Nat) : TM Unit := mf i fun f => { f with out := (f.out.change k).1 }

/-- `typed_filter::set_output`. -/
def setOutput (i p : Nat) (v : FV) : TM Unit := do
  let f ← gf i
  if f.kind.nodeTyped then
    let u := match v with | .node u => u | _ => 0
    let k ← match f.in2out.get? p with
      | some k =>
        let old ← getVal k
        if v.same old then return
        -- SOAR 9.6.6 DEFECT: the old output is removed and the same value object, still
        -- holding the old node, is added again for the new node (`typed_filter<sgnode*>`)
        removeOutputN i p
        pure k
      | none => do let k ← tKey; setVal k v; pure k
    mf i fun f => { f with nodeOuts := f.nodeOuts.insert u ((f.nodeOuts.getD u []).filter (· != k) ++ [k]),
                           in2out := f.in2out.insert p k, out2in := f.out2in.insert k p }
    outAdd i k
  else
    match f.in2out.get? p with
    | some k =>
      let old ← getVal k
      if v.same old then return
      setVal k v
      outChange i k
    | none =>
      let k ← tKey
      setVal k v
      mf i fun f => { f with in2out := f.in2out.insert p k, out2in := f.out2in.insert k p }
      outAdd i k
where
  removeOutputN (i p : Nat) : TM Unit := do
    let f ← gf i
    match f.in2out.get? p with
    | some k =>
      let v ← getVal k
      mf i fun f =>
        let no := match v with
          | .node u => match f.nodeOuts.get? u with
            | some l => if l.contains k then (if l.length == 1 then f.nodeOuts.erase u else f.nodeOuts.insert u (l.erase k)) else f.nodeOuts
            | none => f.nodeOuts
          | _ => f.nodeOuts
        { f with in2out := f.in2out.erase p, out2in := f.out2in.erase k, nodeOuts := no }
      outRemove i k
    | none => pure ()

/-- `typed_filter::remove_output`. -/
def removeOutput (i p : Nat) : TM Unit := do
  let f ← gf i
  if f.kind.nodeTyped then setOutput.removeOutputN i p else
  match f.in2out.get? p with
  | some k =>
    mf i fun f => { f with in2out := f.in2out.erase p, out2in := f.out2in.erase k }
    outRemove i k
  | none => pure ()

/-- `clear_output`: a typed filter forgets its outputs; the list is cleared. SOAR 9.6.6
DEFECT (reproduced): `all_nodes` keeps its map of nodes (and its listening) and, its first
update done, never lists them again; `rank_filter` keeps its ranked sets and best; a select
filter keeps its active sets. -/
def clearOutput (i : Nat) : TM Unit := mf i fun f =>
  if f.kind.cls == .all then { f with out := f.out.clear }
  else { f with out := f.out.clear, in2out := {}, out2in := {}, nodeOuts := {} }

/-- A parameter's value. -/
def par (p : Nat) (name : String) : TM (Option FV) := do
  let t ← get
  match t.pars.get? p with
  | some l => match l.find? (·.1 == name) with
    | some (_, k) => return (t.vals.get? k).map (·.1)
    | none => return none
  | none => return none

/-- `get_filter_param` for a node, a string, a double (a double or an integer); with a filter
given, a parameter of the wrong type sets its status. -/
def pNode (f : Option Nat) (p : Nat) (name : String) : TM (Option Nat) := do
  match ← par p name with
  | some (.node u) => return some u
  | some _ => if let some i := f then fStatus i s!"parameter \"{name}\" has wrong type"
              return none
  | none => return none

def pStr (f : Option Nat) (p : Nat) (name : String) : TM (Option String) := do
  match ← par p name with
  | some (.s s) => return some s
  | some _ => if let some i := f then fStatus i s!"parameter \"{name}\" has wrong type"
              return none
  | none => return none

def pDbl (f : Option Nat) (p : Nat) (name : String) : TM (Option Float) := do
  match ← par p name with
  | some (.d x) => return some x
  | some (.i n) => return some (Float.ofInt n)
  | some _ => if let some i := f then fStatus i s!"parameter \"{name}\" has wrong type"
              return none
  | none => return none

/-- `compare_distance`. -/
def compareDistance (sc : Scene) (a b p : Nat) : TM Float := do
  if a == b then return 0
  let ty := (← pStr none p "distance_type").getD "centroid"
  return if ty == "hull" then sc.convexDistance a b else sc.centroidDist a b

/-- `compare_axis_distance`. -/
def compareAxisDistance (sc : Scene) (a b p : Nat) : TM Float := do
  let some nm ← pStr none p "axis" | return 0
  let c := (nm.toList.headD '\x00').toLower
  let dim : Nat := if 'x' ≤ c && c ≤ 'z' then c.toNat - 'x'.toNat
    else if '0' ≤ c && c ≤ '2' then c.toNat - '0'.toNat else 0
  match ← pNode none p "reference" with
  | some r =>
    let ax := V3.zero.set dim 1.0
    let w := sc.world r
    return sc.axisDistVec a b (V3.sub (w.apply ax) (w.apply V3.zero))
  | none => return sc.axisDistDim a b dim

/-- `evaluate_volume`. -/
def evalVolume (sc : Scene) (a p : Nat) : TM Float := do
  let ty := (← pStr none p "volume_type").getD "bbox"
  return if ty == "scale" then sc.scaleVolume a else sc.bboxVolume a

/-- The two-node tests: `larger_test`, `smaller_test`, `intersect_test`, `contain_test`. -/
def nodeTest (k : Kind) (sc : Scene) (a b p : Nat) : TM Bool := do
  match k with
  | .larger | .largerSel | .smaller | .smallerSel =>
    if a == b then return false
    let ty := (← pStr none p "volume_type").getD "bbox"
    let (va, vb) := if ty == "scale" then (sc.scaleVolume a, sc.scaleVolume b) else (sc.bboxVolume a, sc.bboxVolume b)
    return match k with | .larger | .largerSel => va > vb | _ => va < vb
  | .intersect | .intersectSel =>
    if a == b then return true
    let ty := (← pStr none p "intersect_type").getD "bbox"
    return if ty == "hull" then sc.convexIntersects a b else sc.bboxIntersects a b
  | _ =>
    if a == b then return true
    return sc.bboxContains a b

/-- `set_range_from_params` (the range persists from one parameter set to the next). -/
def setRange (i p : Nat) : TM Unit := do
  if let some x ← pDbl (some i) p "min" then mf i fun f => { f with rmin := x }
  if let some x ← pDbl (some i) p "max" then mf i fun f => { f with rmax := x }
  if let some s ← pStr (some i) p "include_min" then mf i fun f => { f with inclMin := s != "false" }
  if let some s ← pStr (some i) p "include_max" then mf i fun f => { f with inclMax := s != "false" }

def fallsInRange (f : Flt) (v : Float) : Bool :=
  !((f.inclMin && v < f.rmin) || (!f.inclMin && v ≤ f.rmin) ||
    (f.inclMax && v > f.rmax) || (!f.inclMax && v ≥ f.rmax))

/-- Nodes `a` and `b` of a parameter set, with the filter's message when one is missing. -/
def nodesAB (i p : Nat) (msg : String) : TM (Option (Nat × Nat)) := do
  match ← pNode (some i) p "a" with
  | some a =>
    match ← pNode (some i) p "b" with
    | some b => return some (a, b)
    | none => fStatus i msg; return none
  | none => fStatus i msg; return none

/-- A map filter's `compute`. -/
def computeMap (sc : Scene) (i p : Nat) : TM (Option FV) := do
  let f ← gf i
  match f.kind with
  | .nodePos | .nodeRot | .nodeScl =>
    let some a ← pNode (some i) p "a" | return none
    let n := sc.node a
    return some (.v3 (match f.kind with | .nodePos => n.pos | .nodeRot => n.rot | _ => n.scl))
  | .nodeBBox =>
    let some a ← pNode (some i) p "a" | return none
    return some (.bb (sc.bounds a))
  | .combine =>
    let t ← get
    match t.pars.get? p with
    | some ((_, k) :: _) => match ((t.vals.get? k).map (·.1) : Option FV) with
      | some (.node u) => return some (.node u)
      | _ => return none
    | _ => return none
  | .distance | .axisDist =>
    let some (a, b) ← nodesAB i p "Need nodes a and b as input" | return none
    let r ← if f.kind matches .distance then compareDistance sc a b p else compareAxisDistance sc a b p
    return some (.d r)
  | .volume =>
    let some a ← pNode (some i) p "a" | (do fStatus i "Need node a input"; return none)
    return some (.d (← evalVolume sc a p))
  | .larger | .smaller | .intersect | .contain =>
    let some (a, b) ← nodesAB i p "Need nodes a and b as input" | return none
    return some (.b (← nodeTest f.kind sc a b p))
  | .monitorVol =>
    let some a ← pNode (some i) p "a" | (do fStatus i "expecting parameter a"; return none)
    let s := (sc.node a).scl
    let cur := s.x * s.y * s.z
    match f.monV.get? a with
    | none => mf i fun f => { f with monV := f.monV.insert a cur }; return some (.d 1.0)
    | some v => return some (.d ((cur + 0.000000001) / (v + 0.000000001)))
  | .monitorPos =>
    let some a ← pNode (some i) p "a" | (do fStatus i "expecting parameter a"; return none)
    let pos := (sc.node a).pos
    match f.monP.get? a with
    | none => mf i fun f => { f with monP := f.monP.insert a pos }; return some (.d 0)
    | some v =>
      let d := V3.sub pos v
      return some (.d (d.x * d.x + d.y * d.y + d.z * d.z).sqrt)
  | .calcPlace =>
    let some a ← pNode (some i) p "a" | (do fStatus i "expecting sgnode parameter 'a'"; return none)
    let some b ← pNode (some i) p "b" | (do fStatus i "expecting sgnode parameter 'b'"; return none)
    let ref ← pNode (some i) p "reference"
    let xs := (← pDbl (some i) p "x_axis_separation").getD 0
    let ys := (← pDbl (some i) p "y_axis_separation").getD 0
    let zs := (← pDbl (some i) p "z_axis_separation").getD 0
    return some (.v3 (sc.placement a b ref ⟨xs, ys, zs⟩))
  | .overlap =>
    let some (a, b) ← nodesAB i p "Need nodes a and b as input" | return none
    if a == b then return some (.d 1)
    return some (.d (← useRng (sc.overlap a b 200)))
  | _ => return none

/-- A select filter's `compute`: the output and whether it is selected. -/
def computeSel (sc : Scene) (i p : Nat) : TM (Option (Option Nat × Bool)) := do
  let f ← gf i
  match f.kind with
  | .node =>
    let some id ← pStr (some i) p "id" | (do fStatus i "expecting parameter id"; return none)
    let o := sc.find id
    return some (o, o.isSome)
  | .removeNode =>
    let some a ← pNode (some i) p "a" | (do fStatus i "expecting parameter a"; return none)
    let some id ← pStr (some i) p "id" | (do fStatus i "expecting parameter id"; return none)
    let some b := sc.find id | (do fStatus i "The given node doesn't exist"; return none)
    return some (some a, a != b)
  | .tagSelect =>
    let some a ← pNode (some i) p "a" | (do fStatus i "Needs node a as input"; return none)
    let some tn ← pStr (some i) p "tag_name" | (do fStatus i "Needs tag_name as input"; return none)
    let some tv ← pStr (some i) p "tag_value" | (do fStatus i "Needs tag_value as input"; return none)
    let sel := match (sc.node a).tags.find? (·.1 == tn) with | some (_, v) => v == tv | none => false
    return some (some a, sel)
  | .distanceSel | .axisDistSel =>
    let some (a, b) ← nodesAB i p "Need nodes a and b as input" | return none
    setRange i p
    let r ← if f.kind matches .distanceSel then compareDistance sc a b p else compareAxisDistance sc a b p
    return some (some b, fallsInRange (← gf i) r)
  | .volumeSel =>
    let some a ← pNode (some i) p "a" | (do fStatus i "Need node a input"; return none)
    setRange i p
    let r ← evalVolume sc a p
    return some (some a, fallsInRange (← gf i) r)
  | .largerSel | .smallerSel | .intersectSel | .containSel =>
    let some (a, b) ← nodesAB i p "Need nodes a and b as input" | return none
    return some (some b, (← nodeTest f.kind sc a b p))
  | .overlapSel =>
    let some (a, b) ← nodesAB i p "Need nodes a and b as input" | return none
    setRange i p
    let r ← if a == b then pure 1.0 else useRng (sc.overlap a b 200)
    return some (some b, fallsInRange (← gf i) r)
  | .axisRelSel =>
    let some a ← pNode (some i) p "a" | (do fStatus i "Need node a as input"; return none)
    let some b ← pNode (some i) p "b" | (do fStatus i "Need node b as input"; return none)
    let some an ← pStr (some i) p "axis" | (do fStatus i "Need axis x, y, or z specified"; return none)
    let axis : Int := ((an.toList.headD '\x00').toLower.toNat : Int) - ('x'.toNat : Int)
    let flag (nm : String) : TM Bool := do return (← pStr (some i) p nm).getD "false" == "true"
    let greater ← flag "greater"
    let aligned ← flag "aligned"
    let less ← flag "less"
    let bot := (← pDbl (some i) p "bottom").getD 0
    let top := (← pDbl (some i) p "top").getD 0
    let base := (← pStr (some i) p "base").getD "b"
    -- `test_axis_relation`
    let test (x y : Nat) : Bool :=
      let dist := sc.axisDistDim x y axis
      (aligned && dist == 0.0) || (less && -top < dist && dist < -bot) ||
      (less && aligned && -top < dist && dist ≤ 0.0) || (greater && bot < dist && dist < top) ||
      (greater && aligned && 0.0 ≤ dist && dist < top)
    let sel := if base == "a" || base == "A" then test a b else test b a
    return some (some b, sel)
  | _ => return none

/-- A rank filter's `rank`. -/
def computeRank (sc : Scene) (i p : Nat) : TM (Option Float) := do
  let f ← gf i
  match f.kind with
  | .closest | .farthest =>
    let some (a, b) ← nodesAB i p "Need nodes a and b as input" | return none
    return some (← compareDistance sc a b p)
  | _ =>
    let some a ← pNode (some i) p "a" | (do fStatus i "Need node a as input"; return none)
    return some (← evalVolume sc a p)

def insertElem' (l : List (Nat × Nat)) (p : Nat) (r : Nat) : List (Nat × Nat) :=
  let l := l.filter (·.1 != p)
  let (a, b) := l.span (fun e => e.1 < p)
  a ++ [(p, r)] ++ b

def insertElem (l : List (Nat × Float)) (p : Nat) (r : Float) : List (Nat × Float) :=
  let l := l.filter (·.1 != p)
  let (a, b) := l.span (fun e => e.1 < p)
  a ++ [(p, r)] ++ b

/-- `update_outputs` of each kind of filter. -/
def updOut (sc : Scene) (i : Nat) : TM Bool := do
  let f ← gf i
  match f.kind.cls with
  | .map =>
    for p in f.inp.isNew ++ f.inp.chg.toList do
      let some v ← computeMap sc i p | return false
      setOutput i p v
    for p in f.inp.rem.toList do removeOutput i p
    return true
  | .sel =>
    for p in f.inp.isNew do
      let some (o, sel) ← computeSel sc i p | return false
      if sel then
        mf i fun f => { f with active := f.active.insert p }
        setOutput i p (.node (o.getD 0))
    for p in f.inp.chg.toList do
      let some (o, sel) ← computeSel sc i p | return false
      if (← gf i).active.contains p then
        if sel then setOutput i p (.node (o.getD 0))
        else
          mf i fun f => { f with active := f.active.erase p }
          removeOutput i p
      else if sel then
        mf i fun f => { f with active := f.active.insert p }
        setOutput i p (.node (o.getD 0))
    for p in f.inp.rem.toList do
      mf i fun f => { f with active := f.active.erase p }
      removeOutput i p
    return true
  | .rank =>
    let mut changed := false
    for p in f.inp.isNew ++ f.inp.chg.toList do
      let some r ← computeRank sc i p | return false
      mf i fun f => { f with elems := insertElem f.elems p r }
      changed := true
    for p in f.inp.rem.toList do
      mf i fun f => { f with elems := f.elems.filter (·.1 != p) }
      changed := true
    let f ← gf i
    let high := match f.kind with | .farthest | .largest => true | _ => false
    match f.elems with
    | e :: es =>
      if changed then
        let (cb, bv) := es.foldl (fun (acc : Nat × Float) (p, r) =>
          if high && r > acc.2 then (p, r) else if !high && r < acc.2 then (p, r) else acc) e
        match f.best with
        | none => mf i fun f => { f with best := some cb }; setOutput i cb (.d bv)
        | some b =>
          if cb != b then
            removeOutput i b
            mf i fun f => { f with best := some cb }
            setOutput i cb (.d bv)
          else setOutput i b (.d bv)
    | [] =>
      if changed then
        if let some b := f.best then
          removeOutput i b
          mf i fun f => { f with best := none }
    return true
  | .occ =>
    -- `occlusion_filter::update_outputs`
    let mut changed := false
    for p in f.inp.isNew do
      -- `initialize`: the view lines from the eye to `a` are added to those made before
      let a? ← pNode (some i) p "a"
      if a?.isNone then
        fStatus i "expecting parameter a"
        return false
      let eye ← match ← pNode (some i) p "eye" with
        | some e => pure (some e)
        | none => pure (sc.find "eye")
      if eye.isNone then
        fStatus i "expecting parameter eye"
        return false
      mf i fun f => { f with vlines := f.vlines ++ (sc.viewLines a?.get! eye.get!).toArray }
      let b? ← pNode (some i) p "b"
      if b?.isNone then
        fStatus i "expecting parameter b"
        return false
      mf i fun f => { f with occ := insertElem' f.occ p b?.get! }
      changed := true
    for p in f.inp.chg.toList do
      let b? ← pNode (some i) p "b"
      if b?.isNone then
        fStatus i "Error getting parameter b"
        return false
      mf i fun f => { f with occ := insertElem' f.occ p b?.get! }
      changed := true
    for p in f.inp.rem.toList do
      mf i fun f => { f with occ := f.occ.filter (·.1 != p) }
      changed := true
    if changed then
      let f ← gf i
      setOutput i 0 (.d (sc.occlusion f.vlines (f.occ.map (·.2))))
    return true
  | .const =>
    if !f.added then
      let v : FV := match f.kind with | .constS s => .s s | .constI n => .i n | .constD x => .d x | _ => .s ""
      setOutput i 0 v
      mf i fun f => { f with added := true }
    return true
  | .all =>
    if f.first then
      for u in sc.order.drop 1 do
        let k ← tKey
        setVal k (.node u)
        mf i fun f => { f with allOuts := f.allOuts ++ [(u, k)] }
        outAdd i k
      mf i fun f => { f with first := false }
    return true

/-- A change to the input's parameter set `p` (`change_tracking_list::change`); the root
filter's input announces it to its `extract` command. -/
def inpChange (top i p : Nat) : TM Unit := do
  let f ← gf i
  let (c, ann) := f.inp.change p
  mf i fun f => { f with inp := c }
  if ann && i == top then modify fun t => { t with rootChg := t.rootChg.push p }

/-- `concat_filter_input::combine` and `product_filter_input::combine`. -/
def combine (top i : Nat) : TM Unit := do
  let f ← gf i
  match f.inKind with
  | .null => pure ()
  | .concat =>
    for (nm, c) in f.ins do
      let o := (← gf c).out
      for v in o.isNew do
        let p ← tKey
        modify fun t => { t with pars := t.pars.insert p [(nm, v)] }
        mf i fun f => { f with v2p := f.v2p.insert v [p], inp := f.inp.add p }
      for v in o.rem.toList do
        match (← gf i).v2p.get? v with
        | some (p :: _) => mf i fun f => { f with v2p := f.v2p.erase v, inp := f.inp.remove p }
        | _ => pure ()
      for v in o.chg.toList do
        match (← gf i).v2p.get? v with
        | some (p :: _) => inpChange top i p
        | _ => pure ()
  | .product =>
    for (_, c) in f.ins do
      let o := (← gf c).out
      for r in o.rem.toList do
        match (← gf i).v2p.get? r with
        | some l =>
          for p in l do
            mf i fun f => { f with inp := f.inp.remove p }
            -- `erase_param_set`
            let ps := ((← get).pars.get? p).getD []
            for (_, v) in ps do
              mf i fun f => { f with v2p := f.v2p.insert v ((f.v2p.getD v []).erase p) }
          mf i fun f => { f with v2p := f.v2p.erase r }
        | none => pure ()
    for (_, c) in f.ins do
      let o := (← gf c).out
      for v in o.chg.toList do
        match (← gf i).v2p.get? v with
        | some l => for p in l do inpChange top i p
        | none => pure ()
    genNew i
where
  /-- `gen_new_combinations`: every combination with a new value, list by list. SOAR 9.6.6
  DEFECT (reproduced): it returns after the first list that has new values, so combinations of
  that list's old values with a later list's new values are never made. -/
  genNew (i : Nat) : TM Unit := do
    let f ← gf i
    let outs ← f.ins.toList.mapM fun (nm, c) => do return (nm, (← gf c).out)
    let n := outs.length
    for idx in List.range n do
      let ranges := (outs.enum.map fun (j, (_, o)) =>
        if j < idx then (0, o.ab) else if j == idx then (o.ab, o.cur.size) else (0, o.cur.size))
      if ranges.any (fun (b, e) => b == e) then continue
      -- enumerate, the first list varying fastest
      let combos := ranges.foldr (fun (b, e) acc =>
        (acc.flatMap fun rest => (List.range (e - b)).map fun k => (b + k) :: rest)) [[]]
      -- foldr builds the last list varying slowest only if we order: recompute explicitly
      let _ := combos
      let rec enumC (rs : List (Nat × Nat)) : List (List Nat) :=
        match rs with
        | [] => [[]]
        | (b, e) :: rest =>
          let tails := enumC rest
          tails.flatMap fun t => (List.range (e - b)).map fun k => (b + k) :: t
      for cmb in enumC ranges do
        let p ← tKey
        let ps := (outs.zip cmb).map fun ((nm, o), j) => (nm, o.cur[j]!)
        modify fun t => { t with pars := t.pars.insert p ps }
        for (_, v) in ps do
          mf i fun f => { f with v2p := f.v2p.insert v (f.v2p.getD v [] ++ [p]) }
        mf i fun f => { f with inp := f.inp.add p }
      return

/-- `filter::update`, with `filter_input::update`. -/
partial def fUpdate (sc : Scene) (top i : Nat) : TM Bool := do
  let f ← gf i
  let mut ok := true
  for (_, c) in f.ins do
    if ok then
      if !(← fUpdate sc top c) then
        -- `filter_input::clear`
        mf i fun f => { f with inp := f.inp.clear }
        for (_, c2) in f.ins do mf c2 fun g => { g with out := g.out.reset }
        ok := false
  if !ok then
    fStatus i "Errors in input"
    clearOutput i
    return false
  combine top i
  for (_, c) in f.ins do mf c fun g => { g with out := g.out.clearChanges }
  if !(← updOut sc i) then
    mf i fun f => { f with inp := f.inp.reset }
    clearOutput i
    return false
  fStatus i "success"
  mf i fun f => { f with inp := f.inp.clearChanges }
  return true

/-- A scene event reaching the filters that listen to the node. -/
def Tree.onEv (t : Tree) (world : Nat) (e : Ev) : Tree :=
  { t with fl := t.fl.map fun f =>
    match f.kind.cls with
    | .all =>
      if f.first then f else
      let has (u : Nat) := f.allOuts.find? (·.1 == u)
      match e with
      | .childAdded p c =>
        if p == world || (has p).isSome then
          -- the key is made by `Tree.onEvs`
          f
        else f
      | .deleted u => match has u with
        | some (_, k) => { f with out := f.out.remove k, allOuts := f.allOuts.filter (·.1 != u) }
        | none => f
      | .trans u | .shape u | .tagChanged u _ | .tagDeleted u _ => match has u with
        | some (_, k) => { f with out := (f.out.change k).1 }
        | none => f
    | _ =>
      if !f.kind.nodeTyped then f else
      match e with
      | .deleted u => match f.nodeOuts.get? u with
        | some ks =>
          let ks := ks.mergeSort (· ≤ ·)
          let f := ks.foldl (fun f k =>
            let f := match f.out2in.get? k with
              | some p => { f with in2out := f.in2out.erase p }
              | none => f
            { f with out2in := f.out2in.erase k, out := f.out.remove k }) f
          { f with nodeOuts := f.nodeOuts.erase u }
        | none => f
      | .trans u | .shape u => match f.nodeOuts.get? u with
        | some ks => (ks.mergeSort (· ≤ ·)).foldl (fun f k => { f with out := (f.out.change k).1 }) f
        | none => f
      | _ => f }

/-- Scene events reaching a tree: `all_nodes` takes a node attached below a node it lists. -/
def Tree.onEvs (t : Tree) (world : Nat) (evs : List Ev) : M Tree := do
  let mut t := t
  for e in evs do
    t := t.onEv world e
    if let .childAdded p c := e then
      for i in List.range t.fl.size do
        let f := t.fl[i]!
        if f.kind.cls == .all && !f.first && (p == world || f.allOuts.any (·.1 == p)) then
          let k ← newKey
          t := { t with vals := t.vals.insert k (.node c, true),
                        fl := t.fl.modify i fun f => { f with allOuts := f.allOuts ++ [(c, k)], out := f.out.add k } }
  return t

/-- `parse_filter_spec`: the tree of filters a command's structure describes; `none` if it is
malformed (`incorrect filter syntax`). -/
partial def parseSpec (v : Sym) : TM (Option Nat) := do
  let push (f : Flt) : TM Nat := modifyGet fun t => (t.fl.size, { t with fl := t.fl.push f })
  match v with
  | .str s => return some (← push { kind := .constS s })
  | .int n => return some (← push { kind := .constI n })
  | .float b => return some (← push { kind := .constD (Float.ofBits b) })
  | .id n =>
    let kids ← liftM (kidsOf n)
    let mut ftype := ""
    let mut itype := ""
    let mut params : Array WME := #[]
    for w in kids do
      let some pn := symStr? w.attr | continue
      if pn == "type" then
        let some t := symStr? w.val | return none
        ftype := t
      else if pn == "input-type" then
        let some t := symStr? w.val | return none
        itype := t
      else if pn != "status" && pn != "result" then
        params := params.push w
    let ik : InKind := if itype == "concat" || ftype == "combine_nodes" then .concat
      else if params.isEmpty then .null else .product
    let mut ins : Array (String × Nat) := #[]
    for w in params do
      let some pn := symStr? w.attr | continue
      let some c ← parseSpec w.val | return none
      ins := ins.push (pn, c)
    if ftype == "" || ftype == "combine" then return none
    let some k := Kind.ofName ftype | return none
    let sw ← liftM (findChild n "status")
    return some (← push { kind := k, root := some n, inKind := ik, ins, statusW := sw })

/-! ## The scene-graph mirror -/

/-- `sgwme::sgwme`: a node's `^id`, its children (each `^child`), then its tags. -/
partial def mirNew (sc : Scene) (mir : Std.HashMap Nat Mir) (u wid : Nat) (parent : Option Nat) :
    M (Std.HashMap Nat Mir) := do
  let n := sc.node u
  let idW ← mkW wid "id" (.str n.name)
  let mut mir := mir.insert u { id := wid, idW, parent }
  if n.isGroup then
    for c in n.kids do mir ← mirAddChild sc mir u c
  for (k, v) in n.tags do mir ← mirSetTag mir u k v
  return mir
where
  mirAddChild (sc : Scene) (mir : Std.HashMap Nat Mir) (p c : Nat) : M (Std.HashMap Nat Mir) := do
    let some m := mir.get? p | return mir
    let (w, cid) ← mkIdW m.id "child"
    let mir := mir.insert p { m with kids := m.kids ++ [(c, w)] }
    mirNew sc mir c cid (some p)
  mirSetTag (mir : Std.HashMap Nat Mir) (u : Nat) (k v : String) : M (Std.HashMap Nat Mir) := do
    let some m := mir.get? u | return mir
    if let some (_, w) := m.tags.find? (·.1 == k) then rmW w
    let w ← mkW m.id k (.str v)
    let tags := m.tags.filter (·.1 != k)
    let (a, b) := tags.span (fun e => decide (e.1 < k))
    return mir.insert u { m with tags := a ++ [(k, w)] ++ b }

/-- `sgwme::~sgwme`. -/
partial def mirDelete (mir : Std.HashMap Nat Mir) (u : Nat) (detach : Bool) : M (Std.HashMap Nat Mir) := do
  let some m := mir.get? u | return mir
  rmW m.idW
  for (_, w) in m.tags do rmW w
  let mut mir := mir
  for (c, w) in m.kids do
    mir ← mirDelete mir c false
    rmW w
  if detach then
    if let some p := m.parent then
      if let some pm := mir.get? p then
        if let some (_, w) := pm.kids.find? (·.1 == u) then rmW w
        mir := mir.insert p { pm with kids := pm.kids.filter (·.1 != u) }
  return mir.erase u

/-- A scene event reaching the mirror. -/
def mirEv (sc : Scene) (mir : Std.HashMap Nat Mir) (e : Ev) : M (Std.HashMap Nat Mir) := do
  match e with
  | .childAdded p c => if mir.contains p then mirNew.mirAddChild sc mir p c else return mir
  | .deleted u => if mir.contains u then mirDelete mir u true else return mir
  | .tagChanged u k =>
    if !mir.contains u then return mir
    match (sc.node u).tags.find? (·.1 == k) with
    | some (_, v) => mirNew.mirSetTag mir u k v
    | none => return mir
  | .tagDeleted u k =>
    let some m := mir.get? u | return mir
    match m.tags.find? (·.1 == k) with
    | some (_, w) => rmW w; return mir.insert u { m with tags := m.tags.filter (·.1 != k) }
    | none => return mir
  | _ => return mir

/-- A change to a state's scene: the new scene and its events, which reach the mirror and the
filters of the state's commands. -/
def SState.apply (st : SState) (r : Scene × List Ev) : M SState := do
  let (sc, evs) := r
  let mut mir := st.mir
  for e in evs do mir ← mirEv sc mir e
  let mut cmds := st.cmds
  for j in List.range cmds.size do
    if let some t := cmds[j]!.tree then
      let t ← t.onEvs st.scene.root evs
      cmds := cmds.modify j fun c => { c with tree := some t }
  return { st with scene := sc, mir, cmds }

/-! ## SGEL (`scene::parse_sgel`) -/

def parseVec3 (f : Array String) (start : Nat) : Option V3 × Nat := Id.run do
  let mut s := start
  let mut v := V3.zero
  for i in [0, 1, 2] do
    match f[s]?.bind parseDouble with
    | some x => v := v.set i x; s := s + 1
    | none => return (none, s)
  return (some v, s)

/-- `parse_mods`: the modifiers from field `start`: `p`/`r`/`s` and three numbers, `v` and
vertices, `b` and a radius; anything else ends them. -/
def parseMods (f : Array String) (start : Nat) : Option (List (Char × List V3)) := Id.run do
  let mut s := start
  let mut out : List (Char × List V3) := []
  while s < f.size do
    let m := (f[s]!.toList.headD ' ')
    if m == 'p' || m == 'r' || m == 's' then
      match parseVec3 f (s + 1) with
      | (some v, s') => out := out ++ [(m, [v])]; s := s'
      | (none, _) => return none
    else if m == 'v' then
      s := s + 1
      let mut vs : List V3 := []
      let mut go := true
      while go && s < f.size do
        match parseVec3 f s with
        | (some v, s') => vs := vs ++ [v]; s := s'
        | (none, s') => if s' == s then go := false else return none
      out := out ++ [('v', vs)]
    else if m == 'b' then
      match f[s + 1]?.bind parseDouble with
      | some r => out := out ++ [('b', [⟨r, 0, 0⟩])]; s := s + 2
      | none => return none
    else return some out
  return some out

/-- One SGEL line on a state's scene; `false` if it has an error (later lines are not read). -/
def SState.sgelLine (st : SState) (line : String) : M (SState × Bool) := do
  let fs := splitWs line
  match fs with
  | [] => return (st, true)
  | c :: rest =>
    let f := rest.toArray
    let sc := st.scene
    match c.toList.headD ' ' with
    | 'a' =>
      let some id := f[0]? | return (st, false)
      if (sc.find id).isSome then return (st, false)
      let some par := f[1]?.bind sc.findGroup | return (st, false)
      let some mods := parseMods f 2 | return (st, false)
      let isC := mods.any (·.1 == 'v')
      let isB := mods.any (·.1 == 'b')
      if isC && isB then return (st, false)
      let verts := (mods.reverse.find? (·.1 == 'v')).map (·.2) |>.getD []
      let rad := (mods.reverse.find? (·.1 == 'b')).map (fun m => (m.2.headD V3.zero).x) |>.getD 0
      let shape : Shape := if isC then .convex verts else if isB then .ball rad else .group
      let mut n : Node := { name := id, shape }
      for (m, vs) in mods do
        let v := vs.headD V3.zero
        if m == 'p' then n := { n with pos := v }
        else if m == 'r' then n := { n with rot := v }
        else if m == 's' then n := { n with scl := v }
      let u ← newUid
      let st ← st.apply ((sc.insertNew u n).attach par u)
      return (st, true)
    | 'c' =>
      let some id := f[0]? | return (st, false)
      let some u := sc.find id | return (st, false)
      let some mods := parseMods f 1 | return (st, false)
      let mut st := st
      for (m, vs) in mods do
        let v := vs.headD V3.zero
        if m == 'p' || m == 'r' || m == 's' then
          st ← st.apply (st.scene.setTrans u m v)
        else if m == 'v' then
          match (st.scene.node u).shape with
          | .convex _ =>
            let sc := st.scene.upd u fun n => { n with shape := .convex vs }
            st ← st.apply (sc, sc.shapeDirty u)
          | _ => return (st, false)
        else if m == 'b' then
          match (st.scene.node u).shape with
          | .ball _ =>
            let sc := st.scene.upd u fun n => { n with shape := .ball v.x }
            st ← st.apply (sc, sc.shapeDirty u)
          | _ => return (st, false)
      return (st, true)
    | 'd' =>
      let some id := f[0]? | return (st, false)
      let some u := sc.find id | return (st, false)
      return (← st.apply (sc.delete u), true)
    | 't' =>
      let some sub := f[0]? | return (st, false)
      let some id := f[1]? | return (st, false)
      let some u := sc.find id | return (st, false)
      let some tn := f[2]? | return (st, false)
      match sub.toList.headD ' ' with
      | 'a' | 'c' =>
        let some tv := f[3]? | return (st, false)
        return (← st.apply (sc.setTag u tn tv), true)
      | 'd' => return (← st.apply (sc.delTag u tn), true)
      | _ => return (st, false)
    | _ => return (st, false)

def SState.sgel (st : SState) (text : String) : M SState := do
  let mut st := st
  for l in text.splitOn "\n" do
    let (st', ok) ← st.sgelLine l
    st := st'
    if !ok then return st
  return st

/-! ## Commands -/

/-- `command::set_status`. -/
def Cmd.setStatus (c : Cmd) (s : String) : M Cmd := do
  if c.status == s then return c
  if let some w := c.statusW then rmW w
  let w ← mkW c.root "status" (.str s)
  return { c with status := s, statusW := some w }

/-- `command::changed`: the number of elements in the command's structure (not its `^result`
and `^status` elements, at any depth) differs from the last call's, or this is the first.
SOAR 9.6.6 DEFECT (reproduced): SVS also means to compare the newest timetag in the structure,
but starts its maximum at the largest 64-bit number (`uint64_t max_time = -1`), so only the
count is compared — a command changed without changing its size is not noticed. -/
def Cmd.changed (c : Cmd) : M (Cmd × Bool) := do
  let mut seen : Std.HashSet Nat := {}
  let mut stack : List Nat := [c.root]
  let mut size := 0
  let mut fuel := 100000
  while !stack.isEmpty && fuel > 0 do
    fuel := fuel - 1
    let n := stack.head!
    stack := stack.tail
    for w in ← kidsOf n do
      if w.attr == .str "result" || w.attr == .str "status" then continue
      size := size + 1
      if let .id v := w.val then
        if !seen.contains v then
          seen := seen.insert v
          stack := v :: stack
  if c.chFirst || size != c.subSize then
    return ({ c with chFirst := false, subSize := size }, true)
  return (c, false)

def unitBoxVerts : List V3 :=
  [(-0.5, -0.5, -0.5), (-0.5, -0.5, 0.5), (-0.5, 0.5, -0.5), (-0.5, 0.5, 0.5),
   (0.5, -0.5, -0.5), (0.5, -0.5, 0.5), (0.5, 0.5, -0.5), (0.5, 0.5, 0.5)].map fun (a, b, c) => ⟨a, b, c⟩

/-- Tags given under `^tags` (`add_node`, `copy_node`), sorted by name. -/
def readTags (root : Nat) : M (List (String × String)) := do
  match ← findChild root "tags" with
  | some w =>
    match w.val with
    | .id t =>
      let mut tags : List (String × String) := []
      for x in ← kidsOf t do
        if let (some a, some v) := (symStr? x.attr, symStr? x.val) then tags := tagSet tags a v
      return tags
    | _ => return []
  | none => return []

/-- A command that changes the scene, on its first update (`add_node`, `copy_node`,
`delete_node`, `set_transform`, `set_tag`, `delete_tag`, `copy_transform`). -/
def runWrite (st : SState) (c : Cmd) : M (SState × Cmd) := do
  if !c.first then return (st, c)
  let c := { c with first := false }
  let r := c.root
  let sc := st.scene
  match c.ck with
  | .addNode =>
    let par ← match ← constStr r "parent" with
      | none => pure (some sc.root)
      | some pid => pure (sc.findGroup pid)
    let some par := par | return (st, ← c.setStatus "no parent group node found")
    let some id ← constStr r "id" | return (st, ← c.setStatus "no id specified")
    if (sc.find id).isSome then return (st, ← c.setStatus "id already exists")
    let p ← getVec3 r "position"
    let ro ← getVec3 r "rotation"
    let s ← getVec3 r "scale"
    let geom := (← constStr r "geometry").getD "group"
    let tags ← readTags r
    let shape : Shape := match geom with
      | "box" => .convex unitBoxVerts | "point" => .convex [V3.zero] | "sphere" => .ball 1.0 | _ => .group
    let n : Node := { name := id, shape, pos := p.getD V3.zero, rot := ro.getD V3.zero, scl := s.getD V3.one }
    let u ← newUid
    let parName := (sc.node par).name
    let some par' := sc.findGroup parName | return (st, ← c.setStatus "error adding node to scene")
    let mut st ← st.apply ((sc.insertNew u n).attach par' u)
    for (k, v) in tags do st ← st.apply (st.scene.setTag u k v)
    return (st, ← c.setStatus "success")
  | .copyNode =>
    let par ← match ← constStr r "parent" with
      | none => pure (some sc.root)
      | some pid => pure (sc.findGroup pid)
    let some par := par | return (st, ← c.setStatus "no group node parent")
    let some sid ← constStr r "source" | return (st, ← c.setStatus "must specify a source")
    let some src := sc.find sid | return (st, ← c.setStatus "Could not find the given source node")
    let some id ← constStr r "id" | return (st, ← c.setStatus "^id must be specified")
    if (sc.find id).isSome then return (st, ← c.setStatus "Node already exists")
    let sn := sc.node src
    let p := (← getVec3 r "position").getD sn.pos
    let ro := (← getVec3 r "rotation").getD sn.rot
    let s := (← getVec3 r "scale").getD sn.scl
    let copyTags := (← constStr r "copy_tags") == some "true"
    let tags ← readTags r
    let adjust := (← constStr r "adjust") == some "true"
    let shape : Shape := match sn.shape with
      | .ball rad => .ball rad | .convex vs => .convex vs | .group => .group
    let u ← newUid
    let mut st ← st.apply ((sc.insertNew u { name := id, shape }).attach par u)
    st ← st.apply (st.scene.setTrans u 'p' p)
    st ← st.apply (st.scene.setTrans u 'r' ro)
    st ← st.apply (st.scene.setTrans u 's' s)
    if copyTags then
      for (k, v) in sn.tags do st ← st.apply (st.scene.setTag u k v)
    for (k, v) in tags do st ← st.apply (st.scene.setTag u k v)
    if adjust then
      if let some v := st.scene.adjustSize u then st ← st.apply (st.scene.setTrans u 's' v)
    return (st, ← c.setStatus "success")
  | .delNode =>
    let some w ← findChild r "id" | return (st, ← c.setStatus "^id must be specified")
    let some id := symStr? w.val | return (st, ← c.setStatus "^id must be a string")
    match sc.find id with
    | some u => return (← st.apply (sc.delete u), ← c.setStatus "success")
    | none => return (st, ← c.setStatus "Could not find the given node")
  | .setTrans =>
    let some w ← findChild r "id" | return (st, ← c.setStatus "no object id specified")
    let some id := symStr? w.val | return (st, ← c.setStatus "object id must be a std::string")
    let props := [('p', ← getVec3 r "position"), ('r', ← getVec3 r "rotation"), ('s', ← getVec3 r "scale")]
    let some u := sc.find id | return (st, ← c.setStatus s!"Couldn't find node {id}")
    let mut st := st
    for (k, v) in props do
      if let some v := v then st ← st.apply (st.scene.setTrans u k v)
    return (st, ← c.setStatus "success")
  | .setTag | .delTag =>
    let some w ← findChild r "id" | return (st, ← c.setStatus "no object id specified")
    let some id := symStr? w.val | return (st, ← c.setStatus "object id must be a std::string")
    let some tw ← findChild r "tag_name" | return (st, ← c.setStatus "no tag_name specified")
    let some tn := symStr? tw.val | return (st, ← c.setStatus "tag_name must be a std::string")
    if c.ck == .setTag then
      let some vw ← findChild r "tag_value" | return (st, ← c.setStatus "no value specified")
      let some tv := symStr? vw.val | return (st, ← c.setStatus "tag_value must be a std::string")
      let some u := sc.find id | return (st, ← c.setStatus s!"Couldn't find node {id}")
      return (← st.apply (sc.setTag u tn tv), ← c.setStatus "success")
    else
      let some u := sc.find id | return (st, ← c.setStatus s!"Couldn't find node {id}")
      return (← st.apply (sc.delTag u tn), ← c.setStatus "success")
  | .copyTrans =>
    let some sid ← constStr r "source" | return (st, ← c.setStatus "must specify a source")
    let some src := sc.find sid | return (st, ← c.setStatus "Could not find the given source node")
    let some did ← constStr r "destination" | return (st, ← c.setStatus "must specify a destination")
    let some dst := sc.find did | return (st, ← c.setStatus "Could not find the given destination node")
    let yes (o : Option String) := o == some "yes" || o == some "true"
    let cp := yes (← constStr r "position")
    let cr := yes (← constStr r "rotation")
    let cs := yes (← constStr r "scale")
    let sn := sc.node src
    let mut st := st
    if cp then st ← st.apply (st.scene.setTrans dst 'p' sn.pos)
    if cr then st ← st.apply (st.scene.setTrans dst 'r' sn.rot)
    if cs then st ← st.apply (st.scene.setTrans dst 's' sn.scl)
    if yes (← constStr r "adjust") then
      if let some v := st.scene.adjustSize dst then st ← st.apply (st.scene.setTrans dst 's' v)
    return (st, ← c.setStatus "success")
  | .extract _ => return (st, c)

/-! ## `extract` -/

/-- `make_filter_val_wme`: a value as an element: a number, `true`/`false`, a string or a node's
name; a vector or box as an identifier with one element per coordinate, each number written
with `%g` and read back. -/
def fvWme (sc : Scene) (id : Nat) (attr : String) (v : FV) : M WME := do
  let num (x : Float) : Sym := match parseDouble (gStr x) with
    | some y => Sym.ofFloat y
    | none => .str (gStr x)
  match v with
  | .i n => mkW id attr (.int n)
  | .d x => mkW id attr (Sym.ofFloat x)
  | .b b => mkW id attr (.str (if b then "true" else "false"))
  | .s s => mkW id attr (.str s)
  | .node u => mkW id attr (.str (sc.node u).name)
  | .v3 x =>
    let (w, sub) ← mkIdW id attr
    let _ ← mkW sub "x" (num x.x)
    let _ ← mkW sub "y" (num x.y)
    let _ ← mkW sub "z" (num x.z)
    return w
  | .bb b =>
    let (w, sub) ← mkIdW id attr
    for (k, x) in [("max-x", b.hi.x), ("max-y", b.hi.y), ("max-z", b.hi.z),
                   ("min-x", b.lo.x), ("min-y", b.lo.y), ("min-z", b.lo.z)] do
      let _ ← mkW sub k (num x)
    return w

/-- `sym_reps_filter_val`. A boolean value is written `true`/`false` but compared with `t`/`f`
(SOAR 9.6.6 DEFECT, reproduced: a boolean parameter's element is remade at every update). -/
def symReps (sc : Scene) (s : Sym) (v : FV) : Bool :=
  match v with
  | .i n => match symNum? s with | some x => x == Float.ofInt n | none => false
  | .d d => match symNum? s with | some x => x == d | none => false
  | .b b => match s with | .str t => (b && t == "t") || (!b && t == "f") | _ => false
  | .s str => (symStr? s).getD "" == str
  | .node u => (symStr? s).getD "" == (sc.node u).name
  | _ => false

/-- `update_param_struct`. -/
def updParams (sc : Scene) (t : Tree) (p pid : Nat) : M Unit := do
  for (nm, k) in (t.pars.get? p).getD [] do
    let v := ((t.vals.get? k).map (·.1)).getD default
    let pw ← findChild pid nm
    let same := match pw with | some w => symReps sc w.val v | none => false
    if !same then
      if let some w := pw then rmW w
      let _ ← fvWme sc pid nm v

def Cmd.clearResults (c : Cmd) : M Cmd := do
  for (_, r) in c.recs do rmW r.recW
  return { c with recs := [] }

/-- `handle_output`: a new output gets a record; a changed one whose value changed gets a new
`^value`. -/
def handleOutput (sc : Scene) (c : Cmd) (t : Tree) (k : Nat) : M (Cmd × Tree) := do
  let some resRoot := c.resRoot | return (c, t)
  let (v, dirty) := (t.vals.get? k).getD (default, false)
  match c.recs.find? (·.1 == k) with
  | some (_, r) =>
    let c ← if dirty then do
        rmW r.valW
        let vw ← fvWme sc r.recId "value" v
        pure { c with recs := c.recs.map fun (k', r') => if k' == k then (k', { r' with valW := vw }) else (k', r') }
      else pure c
    return (c, { t with vals := t.vals.insert k (v, false) })
  | none =>
    let (rw, rid) ← mkIdW resRoot "record"
    let vw ← fvWme sc rid "value" v
    let (_, pid) ← mkIdW rid "params"
    let f := t.fl[c.top]!
    let ps := match f.kind.cls with
      | .all => none
      | _ => match f.out2in.get? k with | some 0 => none | some p => some p | none => none
    if let some p := ps then updParams sc t p pid
    let rec_ : Rec := { params := ps, recW := rw, recId := rid, valW := vw, parId := pid }
    return ({ c with recs := c.recs ++ [(k, rec_)] }, { t with vals := t.vals.insert k (v, false) })

/-- `extract_command::update_sub`. -/
def runExtract (st : SState) (c : Cmd) (once dirtyBit : Bool) : M Cmd := do
  if !once && !c.first && !dirtyBit then return c
  let mut c := c
  if c.resRoot.isNone then
    let (_, r) ← mkIdW c.root "result"
    c := { c with resRoot := some r }
  let (c', ch) ← c.changed
  c := c'
  if ch then
    c ← c.clearResults
    let (top, t) ← (parseSpec (.id c.root)).run {}
    match top with
    | none =>
      c := { c with tree := none }
      return ← c.setStatus "incorrect filter syntax"
    | some top => c := { c with tree := some t, top, first := true }
  match c.tree with
  | some t =>
    if !once || c.first then
      let (ok, t) ← (fUpdate st.scene c.top c.top).run { t with rootChg := #[] }
      if !ok then
        c ← c.clearResults
        return { c with tree := some t }
      -- parameter sets of records that changed (`handle_ctlist_change`)
      for p in t.rootChg do
        if let some (_, r) := c.recs.find? (fun (_, r) => r.params == some p) then
          updParams st.scene t p r.parId
      let out := t.fl[c.top]!.out
      let mut t := t
      for k in out.isNew do
        let (c', t') ← handleOutput st.scene c t k
        c := c'; t := t'
      for k in out.rem.toList do
        match c.recs.find? (·.1 == k) with
        | some (_, r) =>
          rmW r.recW
          c := { c with recs := c.recs.filter (·.1 != k) }
        | none => pure ()
      for k in out.chg.toList do
        let (c', t') ← handleOutput st.scene c t k
        c := c'; t := t'
      t := { t with fl := t.fl.modify c.top fun f => { f with out := f.out.clearChanges } }
      return { c with tree := some t, first := false }
    else return c
  | none => return c

/-! ## States and callbacks -/

/-- `svs_state::init`: `(<s> ^svs <v>)`, `(<v> ^command <c>)`, `(<v> ^spatial-scene <i>)`, and
the mirror of the scene. -/
def SState.init (goal level : Nat) (sc : Scene) : M SState := do
  let (_, v) ← mkIdW goal "svs" (some 'V')
  let (_, c) ← mkIdW v "command"
  let (_, i) ← mkIdW v "spatial-scene"
  let mir ← mirNew sc {} sc.root i none
  return { goal, level, svsLink := v, cmdLink := c, sceneLink := i, scene := sc, mir }

/-- `svs::state_creation_callback`. -/
def stateCreated (goal level : Nat) (top : Bool) : M Unit := do
  let x ← get
  if !(top || x.sv.inSub) then return
  let a0 := x.adds.size
  let st ← match x.sv.states.getLast? with
    | none =>
      let sc ← match x.sv.cache with
        | some sc => pure sc
        | none => do pure (Scene.fresh (← newUid))
      modify fun x => { x with sv := { x.sv with cache := none } }
      SState.init goal level sc
    | some par =>
      let (sc, nx) := par.scene.clone (← get).sv.uid
      modify fun x => { x with sv := { x.sv with uid := nx } }
      SState.init goal level sc
  modify fun x =>
    let made := (x.adds.toList.drop a0)
    { x with sv := { x.sv with states := x.sv.states ++ [st],
                               initW := made.foldl (fun m w => m.insert w level) x.sv.initW } }

/-- `svs::state_deletion_callback`: the state's commands and scene go; the top state's scene is
kept for the next top state. -/
def stateRemoved (top : Bool) : M Unit := modify fun x =>
  if !(top || x.sv.inSub) then x else
  match x.sv.states.getLast? with
  | none => x
  | some st =>
    let cache := if x.sv.states.length == 1 then some st.scene else x.sv.cache
    { x with sv := { x.sv with states := x.sv.states.dropLast, cache } }

/-- `svs_state::process_cmds` (the output phase): commands no longer linked to `^command` are
deleted; new ones are made, in the order of their identifiers' names. -/
def SState.processCmds (st : SState) : M SState := do
  let all ← kidsOf st.cmdLink
  let view := (← get).view
  let mut live : List (String × WME) := []
  for w in all do
    if let .id v := w.val then
      let nm := view.name v
      if !live.any (·.1 == nm) then live := live ++ [(nm, w)]
  let live2 := live.mergeSort (fun a b => decide (a.1 ≤ b.1))
  let curr := st.cmds.toList
  let kept := curr.filter fun c => live2.any (·.1 == c.name)
  let fresh := live2.filter fun (nm, _) => !curr.any (·.name == nm)
  let mut cmds := kept
  for (nm, w) in fresh do
    match (symStr? w.attr).bind CK.ofName, w.val with
    | some ck, .id root =>
      cmds := cmds ++ [{ ck, root, name := nm }]
      modify fun x => { x with sv := { x.sv with dirty := true } }
    | _, _ => pure ()
  let sorted := cmds.mergeSort (fun a b => decide (a.name ≤ b.name))
  return { st with cmds := sorted.toArray }

def outputCb : M Unit := do
  let x ← get
  if !x.sv.on then return
  let mut sts : List SState := []
  for st in x.sv.states do sts := sts ++ [← st.processCmds]
  modify fun x => { x with sv := { x.sv with states := sts } }

/-- `svs::input_callback`: first the environment's SGEL input (`proc_input`: each line sent with
`Agent::SendSVSInput` since the last input phase, on the top state's scene; any input sets the
dirty bit); then the commands that change the scene run, state by state; then those that read
it; then the dirty bit is cleared. -/
def inputCb (env : List String := []) : M Unit := do
  let x ← get
  if !x.sv.on then return
  let mut sts := x.sv.states.toArray
  -- `proc_input(topstate)`: each line is parsed on its own (`scene::parse_sgel`), so an error
  -- in one does not stop the next
  if h : 0 < sts.size then
    let mut top := sts[0]
    for l in env do
      let (top', _) ← top.sgelLine l
      top := top'
    sts := sts.set! 0 top
  unless env.isEmpty do
    modify fun x => { x with sv := { x.sv with dirty := true } }
  for si in List.range sts.size do
    let mut st := sts[si]!
    for j in List.range st.cmds.size do
      let c := st.cmds[j]!
      if !c.ck.isRead then
        let (st', c') ← runWrite st c
        st := { st' with cmds := st'.cmds.set! j c' }
    sts := sts.set! si st
  let dirty := (← get).sv.dirty
  for si in List.range sts.size do
    let mut st := sts[si]!
    for j in List.range st.cmds.size do
      let c := st.cmds[j]!
      if let .extract once := c.ck then
        let c' ← runExtract st c once dirty
        st := { st with cmds := st.cmds.set! j c' }
    sts := sts.set! si st
  modify fun x => { x with sv := { x.sv with states := sts.toList, dirty := false } }

/-- `svs S1.scene.sgel …` from the command line: on the state's scene, at once (the dirty bit
is not set). -/
def cliSgel (goal : Nat) (text : String) : M Unit := do
  let x ← get
  let mut sts := x.sv.states.toArray
  for si in List.range sts.size do
    if sts[si]!.goal == goal then
      let st ← sts[si]!.sgel text
      sts := sts.set! si st
  modify fun x => { x with sv := { x.sv with states := sts.toList } }

/-- The outcome of one of SVS's callbacks: its state, the next free identifier, the elements
it added and removed, and the letters of the identifiers it made. -/
structure Out where
  sv : SvsSt
  next : Nat
  adds : List WME
  rems : List WME
  lets : List (Nat × Nat)

def run (sv : SvsSt) (next : Nat) (view : View) (m : M Unit) : Out :=
  let ((), x) := m.run { sv, next, view }
  -- an element made and removed in the same callback is neither
  let remS : Std.HashSet WME := Std.HashSet.ofList x.rems.toList
  let addS : Std.HashSet WME := Std.HashSet.ofList x.adds.toList
  { sv := x.sv, next := x.next,
    adds := x.adds.toList.filter (!remS.contains ·),
    rems := x.rems.toList.filter (!addS.contains ·),
    lets := x.lets.toList }

end Soar.SVS
