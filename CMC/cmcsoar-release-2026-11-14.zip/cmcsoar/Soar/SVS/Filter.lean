import Soar.SVS.Scene
import Soar.Syntax
import Std.Data.HashMap
import Std.Data.HashSet
/-!
# SVS — filters

Filters ([Man] §8.3; Soar 9.6.6 `filter.h`, `filter_input.*`, `change_tracking_list.h`,
`filter_table.cpp`, `filters/*.cpp`) compute spatial relations over the scene. A filter takes
parameter sets from its inputs and produces a list of values; a command `extract` puts the
values of a tree of filters in working memory.

SVS updates filters incrementally: each list keeps which of its items are new, changed and
removed since it was last read (`change_tracking_list`), and a filter recomputes only for the
input parameter sets that are new or changed. What a filter outputs therefore depends on this
bookkeeping, and the model keeps it as SVS does, with its defects (each reproduced and marked
SOAR 9.6.6 DEFECT below), because they decide what is in working memory.

Values and parameter sets are SVS objects compared by pointer; here each has a number (its
`key`), given in the order the objects are made. Where SVS orders by pointer (a `std::map`
keyed by pointer), the model orders by key, i.e. by the order of allocation, which is what
glibc's allocator gives for objects of one size made in sequence with none freed between;
it decides only which of equally ranked candidates `closest` and its relatives report.
-/

namespace Soar.SVS

/-! ## The context: working-memory changes and identifiers -/

/-- What SVS reads of working memory: an identifier's elements in Soar's order (not those SVS
made, which it tracks itself), and an identifier's name (`S1`, `C12`). -/
structure View where
  kids : Nat → List WME := fun _ => []
  name : Nat → String := fun n => s!"I{n}"

/-- A value a filter outputs (`filter_val_c<T>`). -/
inductive FV where
  | node (u : Nat)
  | b (v : Bool)
  | d (v : Float)
  | i (v : Int)
  | s (v : String)
  | v3 (v : V3)
  | bb (v : BBox)
  deriving Inhabited

/-- `v == old` in `typed_filter::set_output` (same type assumed). -/
def FV.same : FV → FV → Bool
  | .node x, .node y => x == y
  | .b x, .b y => x == y
  | .d x, .d y => x == y
  | .i x, .i y => x == y
  | .s x, .s y => x == y
  | .v3 x, .v3 y => x == y
  | .bb x, .bb y => x == y
  | _, _ => false

/-- A list that tracks its changes (`change_tracking_list`), of keys. Items before `ab` are
old (reported before); items from `ab` on were added since. -/
structure CT where
  cur : Array Nat := #[]
  rem : Array Nat := #[]
  chg : Array Nat := #[]
  ab : Nat := 0
  deriving Inhabited

namespace CT
def add (c : CT) (k : Nat) : CT := { c with cur := c.cur.push k }
/-- `remove`: an item not present is not reported as removed (SVS asserts; release builds go
on). -/
def remove (c : CT) (k : Nat) : CT :=
  match c.cur.idxOf? k with
  | some i =>
    { cur := c.cur.eraseIdxIfInBounds i, rem := c.rem.push k, chg := c.chg.erase k,
      ab := if i < c.ab then c.ab - 1 else c.ab }
  | none => { c with chg := c.chg.erase k }
/-- `change`: only an old item not already changed is reported (and announced: `true`). -/
def change (c : CT) (k : Nat) : CT × Bool :=
  match c.cur.idxOf? k with
  | some i => if i < c.ab && !c.chg.contains k then ({ c with chg := c.chg.push k }, true) else (c, false)
  | none => (c, false)
def clearChanges (c : CT) : CT := { c with ab := c.cur.size, chg := #[], rem := #[] }
def reset (c : CT) : CT := { c with chg := #[], rem := #[], ab := 0 }
/-- `clear`: every item goes without being reported as removed. -/
def clear (_ : CT) : CT := {}
def isNew (c : CT) : List Nat := (c.cur.toList.drop c.ab)
end CT

/-! ## Filters -/

inductive Kind where
  | node | allNodes | removeNode | nodePos | nodeRot | nodeScl | nodeBBox | combine
  | distance | distanceSel | closest | farthest
  | volume | volumeSel | largest | smallest | larger | smaller | largerSel | smallerSel
  | axisDist | axisDistSel | intersect | intersectSel | contain | containSel | tagSelect
  | monitorPos | monitorVol | axisRelSel | calcPlace | occlusion | overlap | overlapSel
  | constS (v : String) | constI (v : Int) | constD (v : Float)
  deriving Inhabited

/-- The filter table (`filter_table::filter_table`): the types this model implements. -/
def Kind.ofName : String → Option Kind
  | "node" => some .node | "all_nodes" => some .allNodes | "remove_node" => some .removeNode
  | "node_position" => some .nodePos | "node_rotation" => some .nodeRot | "node_scale" => some .nodeScl
  | "node_bbox" => some .nodeBBox | "combine_nodes" => some .combine
  | "distance" => some .distance | "distance_select" => some .distanceSel
  | "closest" => some .closest | "farthest" => some .farthest
  | "volume" => some .volume | "volume_select" => some .volumeSel
  | "largest" => some .largest | "smallest" => some .smallest
  | "larger" => some .larger | "smaller" => some .smaller
  | "larger_select" => some .largerSel | "smaller_select" => some .smallerSel
  | "axis_distance" => some .axisDist | "axis_distance_select" => some .axisDistSel
  | "intersect" => some .intersect | "intersect_select" => some .intersectSel
  | "contain" => some .contain | "contain_select" => some .containSel
  | "tag_select" => some .tagSelect
  | "monitor_position" => some .monitorPos | "monitor_volume" => some .monitorVol
  | "axis_relation_select" => some .axisRelSel | "calculate_placement" => some .calcPlace
  | "occlusion" => some .occlusion | "overlap" => some .overlap | "overlap_select" => some .overlapSel
  | _ => none

/-- How the filter's class handles its outputs. -/
inductive Cls where
  | map | sel | rank | const | all | occ
  deriving BEq

def Kind.cls : Kind → Cls
  | .node | .removeNode | .tagSelect | .distanceSel | .volumeSel | .axisDistSel
  | .largerSel | .smallerSel | .intersectSel | .containSel | .axisRelSel | .overlapSel => .sel
  | .occlusion => .occ
  | .closest | .farthest | .largest | .smallest => .rank
  | .constS _ | .constI _ | .constD _ => .const
  | .allNodes => .all
  | _ => .map

/-- Filters whose outputs are nodes (`typed_filter<sgnode*>`): they follow the nodes. -/
def Kind.nodeTyped : Kind → Bool
  | .node | .removeNode | .tagSelect | .distanceSel | .volumeSel | .axisDistSel
  | .largerSel | .smallerSel | .intersectSel | .containSel | .combine | .axisRelSel | .overlapSel => true
  | _ => false

/-- Range selection (`node_select_range_filter`). -/
def Kind.ranged : Kind → Bool
  | .distanceSel | .volumeSel | .axisDistSel | .overlapSel => true
  | _ => false

inductive InKind where
  | null | concat | product
  deriving BEq, Inhabited

structure Flt where
  kind : Kind
  /-- The filter's identifier in working memory (`none` for a constant). -/
  root : Option Nat := none
  inKind : InKind := .null
  /-- The inputs: parameter name and the filter's index in the tree. -/
  ins : Array (String × Nat) := #[]
  /-- The input's list of parameter sets. -/
  inp : CT := {}
  /-- `val2params`: for each input value, the parameter sets made with it (in order). -/
  v2p : Std.HashMap Nat (List Nat) := {}
  out : CT := {}
  status : String := ""
  statusW : Option WME := none
  in2out : Std.HashMap Nat Nat := {}
  out2in : Std.HashMap Nat Nat := {}
  /-- Node-typed filters: for each node, the outputs holding it. -/
  nodeOuts : Std.HashMap Nat (List Nat) := {}
  active : Std.HashSet Nat := {}
  rmin : Float := -1000000000
  rmax : Float := 1000000000
  inclMin : Bool := true
  inclMax : Bool := true
  /-- `rank_filter`: the ranked parameter sets (by key) and the best one. -/
  elems : List (Nat × Float) := []
  best : Option Nat := none
  added : Bool := false
  /-- `all_nodes_filter`. -/
  first : Bool := true
  allOuts : List (Nat × Nat) := []
  /-- `monitor_volume`, `monitor_position`: the value first seen for each node. -/
  monV : Std.HashMap Nat Float := {}
  monP : Std.HashMap Nat V3 := {}
  /-- `occlusion_filter`: the view lines (centre, half-length vector, occluded) made so far,
  and the occluder of each parameter set. -/
  vlines : Array (V3 × V3) := #[]
  occ : List (Nat × Nat) := []
  deriving Inhabited

/-- A tree of filters (one `extract` command's), with its values and parameter sets. -/
structure Tree where
  fl : Array Flt := #[]
  vals : Std.HashMap Nat (FV × Bool) := {}
  pars : Std.HashMap Nat (List (String × Nat)) := {}
  /-- Parameter sets of the root filter's input that changed in this update
  (`handle_ctlist_change`). -/
  rootChg : Array Nat := #[]
  deriving Inhabited

end Soar.SVS
