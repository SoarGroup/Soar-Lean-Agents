import Soar.Rhs
/-!
# SVS — geometry

The spatial visual system's geometry ([Man] chapter 8; Soar 9.6.6 `SVS/src/mat.h`, `mat.cpp`):
3-vectors, affine transforms and axis-aligned bounding boxes, in double precision.

SVS computes with Eigen 3.4. A model that is to give the same numbers must do the same
floating-point operations in the same order; the order below was read from Eigen's source and
checked bit for bit against Eigen compiled as Soar 9.6.6 compiles it (`g++ -O3 -DNDEBUG`,
x86-64; 2026-11-14, 200 000 random cases each, `tools/svs`):

* a 3-vector dot product, and each row of a transform applied to a vector, is
  `(x₀ + x₁) + x₂` (Eigen's packet reduction);
* in the product of two affine transforms, rows 0 and 1 of the linear part are summed
  `(x₀ + x₁) + x₂` and row 2 `x₀ + (x₁ + x₂)` (rows 0–1 form one SSE packet, row 2 is the
  scalar tail); the translation is the linear part times the translation plus the translation;
* an angle-axis rotation matrix is Eigen's `AngleAxis::toRotationMatrix`, with the products by
  the axis's zero components kept (they decide signed zeros).
-/

namespace Soar.SVS

/-- A 3-vector (Eigen's `Vector3d`, SVS's `vec3`). Equality is IEEE equality per component, as
Eigen's `==` (so `0 = -0`). -/
structure V3 where
  x : Float
  y : Float
  z : Float
  deriving Inhabited, Repr

instance : BEq V3 := ⟨fun a b => a.x == b.x && a.y == b.y && a.z == b.z⟩

namespace V3
def zero : V3 := ⟨0, 0, 0⟩
def one : V3 := ⟨1, 1, 1⟩
def get (v : V3) : Nat → Float
  | 0 => v.x | 1 => v.y | _ => v.z
def set (v : V3) (i : Nat) (a : Float) : V3 :=
  match i with | 0 => { v with x := a } | 1 => { v with y := a } | _ => { v with z := a }
def add (a b : V3) : V3 := ⟨a.x + b.x, a.y + b.y, a.z + b.z⟩
def sub (a b : V3) : V3 := ⟨a.x - b.x, a.y - b.y, a.z - b.z⟩
def smul (k : Float) (a : V3) : V3 := ⟨k * a.x, k * a.y, k * a.z⟩
def sdiv (a : V3) (k : Float) : V3 := ⟨a.x / k, a.y / k, a.z / k⟩
/-- Eigen's `dot` on `Vector3d`. -/
def dot (a b : V3) : Float := (a.x * b.x + a.y * b.y) + a.z * b.z
def sqNorm (a : V3) : Float := (a.x * a.x + a.y * a.y) + a.z * a.z
def norm (a : V3) : Float := a.sqNorm.sqrt
/-- Eigen's `normalized`: unchanged if the squared norm is not positive. -/
def normalized (a : V3) : V3 :=
  let n := a.sqNorm
  if n > 0 then a.sdiv n.sqrt else a
end V3

/-- A 3×3 matrix, by rows. -/
structure M3 where
  r0 : V3
  r1 : V3
  r2 : V3
  deriving Inhabited, Repr

namespace M3
def col (m : M3) (j : Nat) : V3 := ⟨m.r0.get j, m.r1.get j, m.r2.get j⟩
def ident : M3 := ⟨⟨1, 0, 0⟩, ⟨0, 1, 0⟩, ⟨0, 0, 1⟩⟩
/-- One row of a product summed as Eigen's packet reduction does. -/
def rowP (a : V3) (m : M3) : V3 :=
  let f (j : Nat) := (a.x * (m.col j).x + a.y * (m.col j).y) + a.z * (m.col j).z
  ⟨f 0, f 1, f 2⟩
/-- One row of a product summed as Eigen's scalar reduction does. -/
def rowS (a : V3) (m : M3) : V3 :=
  let f (j : Nat) := a.x * (m.col j).x + (a.y * (m.col j).y + a.z * (m.col j).z)
  ⟨f 0, f 1, f 2⟩
/-- The product of two linear parts inside a transform product (`Transform * Transform`). -/
def mulT (a b : M3) : M3 := ⟨rowP a.r0 b, rowP a.r1 b, rowS a.r2 b⟩
/-- The product of a linear part by a rotation matrix (`Transform::rotate`); on rotation
matrices the order of summation does not matter (checked), the packet order is used. -/
def mulR (a b : M3) : M3 := ⟨rowP a.r0 b, rowP a.r1 b, rowP a.r2 b⟩
/-- `M · v`, packet order. -/
def apply (m : M3) (v : V3) : V3 := ⟨m.r0.dot v, m.r1.dot v, m.r2.dot v⟩
/-- `M · v` inside a transform product (rows 0–1 packet order, row 2 scalar). -/
def applyT (m : M3) (v : V3) : V3 :=
  ⟨m.r0.dot v, m.r1.dot v, m.r2.x * v.x + (m.r2.y * v.y + m.r2.z * v.z)⟩
def transpose (m : M3) : M3 := ⟨m.col 0, m.col 1, m.col 2⟩
/-- Columns scaled: `M · diag(s)`. -/
def scaleCols (m : M3) (s : V3) : M3 :=
  let f (r : V3) : V3 := ⟨r.x * s.x, r.y * s.y, r.z * s.z⟩
  ⟨f m.r0, f m.r1, f m.r2⟩
end M3

/-- Eigen's `AngleAxisd(angle, axis).toRotationMatrix()` for a unit axis. -/
def angleAxis (ang : Float) (ax : V3) : M3 :=
  let s := ang.sin
  let c := ang.cos
  let sa := V3.smul s ax
  let ca := V3.smul (1 - c) ax
  let t01 := ca.x * ax.y
  let t02 := ca.x * ax.z
  let t12 := ca.y * ax.z
  ⟨⟨ca.x * ax.x + c, t01 - sa.z, t02 + sa.y⟩,
   ⟨t01 + sa.z, ca.y * ax.y + c, t12 - sa.x⟩,
   ⟨t02 - sa.y, t12 + sa.x, ca.z * ax.z + c⟩⟩

/-- An affine transform (Eigen's `Transform<double, 3, Affine>`, SVS's `transform3`). -/
structure Xf where
  lin : M3
  tr : V3
  deriving Inhabited, Repr

namespace Xf
def ident : Xf := ⟨M3.ident, V3.zero⟩
/-- SVS's `transform3(p, r, s)`: `Translation(p) · AngleAxis(r.z, Z) · AngleAxis(r.y, Y) ·
AngleAxis(r.x, X) · Scaling(s)`. The translation is `0 + p` (Eigen's `pretranslate` on a
zero translation, so a position of `-0` becomes `+0`). -/
def ofPRS (p r s : V3) : Xf :=
  let rz := angleAxis r.z ⟨0, 0, 1⟩
  let ry := angleAxis r.y ⟨0, 1, 0⟩
  let rx := angleAxis r.x ⟨1, 0, 0⟩
  let l := M3.scaleCols (M3.mulR (M3.mulR rz ry) rx) s
  ⟨l, V3.add V3.zero p⟩
/-- `a * b` (Eigen's `transform_transform_product_impl` for affine transforms). -/
def mul (a b : Xf) : Xf :=
  ⟨M3.mulT a.lin b.lin, V3.add (M3.applyT a.lin b.tr) a.tr⟩
/-- `t(v)`: the translation plus the linear part times `v`. -/
def apply (t : Xf) (v : V3) : V3 := V3.add t.tr (M3.apply t.lin v)
end Xf

/-- An axis-aligned bounding box (SVS's `bbox`). -/
structure BBox where
  lo : V3
  hi : V3
  deriving Inhabited, Repr

instance : BEq BBox := ⟨fun a b => a.lo == b.lo && a.hi == b.hi⟩

namespace BBox
def ofPoint (v : V3) : BBox := ⟨v, v⟩
/-- `include(v)`: each coordinate widened only by a strict comparison. -/
def incl (b : BBox) (v : V3) : BBox := Id.run do
  let mut lo := b.lo
  let mut hi := b.hi
  for d in [0, 1, 2] do
    if v.get d < lo.get d then lo := lo.set d (v.get d)
    if v.get d > hi.get d then hi := hi.set d (v.get d)
  return ⟨lo, hi⟩
def ofPoints : List V3 → BBox
  | [] => ⟨V3.zero, V3.zero⟩
  | p :: ps => ps.foldl incl (ofPoint p)
def inclBox (a b : BBox) : BBox := (a.incl b.lo).incl b.hi
def intersects (a b : BBox) : Bool :=
  [0, 1, 2].all fun d => !(a.hi.get d < b.lo.get d || a.lo.get d > b.hi.get d)
def contains (a b : BBox) : Bool :=
  [0, 1, 2].all fun d => !(a.hi.get d < b.hi.get d || a.lo.get d > b.lo.get d)
def volume (b : BBox) : Float := (b.hi.x - b.lo.x) * (b.hi.y - b.lo.y) * (b.hi.z - b.lo.z)
def centroid (b : BBox) : V3 := V3.sdiv (V3.add b.hi b.lo) 2.0
end BBox

/-! ## Numbers as text

SVS turns numbers into text with C++'s default stream format (`tostring`: `%g`, six significant
digits) and back with `strtod` (`parse_double`, which accepts a string only if the whole of it
is a number). -/

/-- `x` as C's `%g` with precision 6 prints it (glibc: exact decimal value, ties to even). -/
def gStr (x : Float) : String :=
  let bits := x.toBits
  if x.isNaN then (if bits >>> 63 == 1 then "-nan" else "nan")
  else if x.isInf then (if x < 0 then "-inf" else "inf") else
  let neg := bits >>> 63 == 1
  let sign := if neg then "-" else ""
  let e := ((bits >>> 52) &&& 0x7ff).toNat
  let f := (bits &&& 0xfffffffffffff).toNat
  if e == 0 && f == 0 then sign ++ "0" else
  -- |x| = m / 2^k · 2^j exactly as num / den
  let (m, ex) : Nat × Int := if e == 0 then (f, -1074) else (f + 2 ^ 52, (e : Int) - 1075)
  let (num, den) : Nat × Nat := if ex ≥ 0 then (m * 2 ^ ex.toNat, 1) else (m, 2 ^ (-ex).toNat)
  -- the decimal exponent X with 10^X ≤ |x| < 10^(X+1)
  let approx : Int := ((Nat.log2 num : Int) - (Nat.log2 den : Int)) * 30103 / 100000
  let geq (k : Int) : Bool :=   -- |x| ≥ 10^k
    if k ≥ 0 then num ≥ den * 10 ^ k.toNat else num * 10 ^ (-k).toNat ≥ den
  let rec fix (k : Int) (fuel : Nat) : Int :=
    match fuel with
    | 0 => k
    | fuel + 1 =>
      if !geq k then fix (k - 1) fuel
      else if geq (k + 1) then fix (k + 1) fuel
      else k
  let X0 := fix approx 40
  -- six significant digits: q = round(|x| · 10^(5 - X)), ties to even
  let sc : Int := 5 - X0
  let (n2, d2) : Nat × Nat := if sc ≥ 0 then (num * 10 ^ sc.toNat, den) else (num, den * 10 ^ (-sc).toNat)
  let q0 := n2 / d2
  let r := n2 % d2
  let q := if 2 * r > d2 || (2 * r == d2 && q0 % 2 == 1) then q0 + 1 else q0
  let (q, X) := if q ≥ 1000000 then (q / 10, X0 + 1) else (q, X0)
  let ds := toString q   -- six digits
  let strip (s : String) : String :=
    let cs := s.toList.reverse.dropWhile (· == '0')
    String.ofList cs.reverse
  if X < -4 || X ≥ 6 then
    let frac := strip (String.ofList (ds.toList.drop 1))
    let mant := String.ofList (ds.toList.take 1) ++ (if frac.isEmpty then "" else "." ++ frac)
    let ea := X.natAbs
    let es := (if X < 0 then "-" else "+") ++ (if ea < 10 then "0" else "") ++ toString ea
    sign ++ mant ++ "e" ++ es
  else
    -- fixed: 5 - X digits after the point
    let nd := (5 - X).toNat
    let all := ds   -- q has exactly 6 digits; the value is q / 10^nd
    let ip := if nd ≥ 6 then "0" else String.ofList (all.toList.take (6 - nd))
    let fp := if nd ≥ 6 then String.ofList (List.replicate (nd - 6) '0') ++ all else String.ofList (all.toList.drop (6 - nd))
    let fp := strip fp
    sign ++ ip ++ (if fp.isEmpty then "" else "." ++ fp)

/-- The length of the longest prefix of `cs` that `strtod` reads as a decimal number (after
leading white space), 0 if none. -/
def strtodLen (cs : List Char) : Nat :=
  let ws := cs.takeWhile (fun c => c == ' ' || c == '\t' || c == '\n' || c == '\r' || c == '\x0b' || c == '\x0c')
  let r := cs.drop ws.length
  let sg := match r with | '+' :: _ | '-' :: _ => 1 | _ => 0
  let r := r.drop sg
  let low := String.ofList (r.take 8 |>.map Char.toLower)
  if low.startsWith "infinity" then ws.length + sg + 8
  else if low.startsWith "inf" || low.startsWith "nan" then ws.length + sg + 3
  else
  let ip := r.takeWhile Char.isDigit
  let r1 := r.drop ip.length
  let (fpn, r2) := match r1 with
    | '.' :: q => let f := q.takeWhile Char.isDigit; (f.length + 1, q.drop f.length)
    | q => (0, q)
  if ip.isEmpty && fpn ≤ 1 then 0 else
  let en := match r2 with
    | c :: q => if c == 'e' || c == 'E' then
        let s := match q with | '+' :: _ | '-' :: _ => 1 | _ => 0
        let d := (q.drop s).takeWhile Char.isDigit
        if d.isEmpty then 0 else 1 + s + d.length
      else 0
    | [] => 0
  ws.length + sg + ip.length + fpn + en

/-- SVS's `parse_double`: the whole (non-empty) string must be a number. -/
def parseDouble (s : String) : Option Float :=
  if s.isEmpty then none else
  let cs := s.toList
  if strtodLen cs != cs.length then none else
  -- glibc sets errno on overflow or underflow but `parse_double` does not look at it
  match strtod s with
  | some x => some x
  | none => some 0

/-- SVS's `parse_int` (`strtol`, base 10, whole string). -/
def parseInt (s : String) : Option Int :=
  if s.isEmpty then none else
  let cs := s.toList.dropWhile (fun c => c == ' ' || c == '\t' || c == '\n' || c == '\r' || c == '\x0b' || c == '\x0c')
  let (neg, r) := match cs with | '-' :: q => (true, q) | '+' :: q => (false, q) | q => (false, q)
  let ds := r.takeWhile Char.isDigit
  if ds.isEmpty || ds.length != r.length then none else
  let v : Nat := ds.foldl (fun a c => a * 10 + (c.toNat - '0'.toNat)) 0
  some (if neg then -(v : Int) else v)

/-- SVS's `split(s, "", fields)`: fields separated by white space. -/
def splitWs (s : String) : List String :=
  let isW (c : Char) := c == ' ' || c == '\t' || c == '\n' || c == '\r' || c == '\x0b' || c == '\x0c'
  let (acc, cur) := s.toList.foldl (fun (acc : List String × List Char) c =>
    if isW c then (if acc.2.isEmpty then acc else (String.ofList acc.2.reverse :: acc.1, []))
    else (acc.1, c :: acc.2)) ([], [])
  (if cur.isEmpty then acc else String.ofList cur.reverse :: acc).reverse

end Soar.SVS
