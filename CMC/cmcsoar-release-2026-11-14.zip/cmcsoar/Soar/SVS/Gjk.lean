import Soar.SVS.Scene
/-!
# SVS — distance between convex shapes

SVS measures the distance between two convex shapes with the GJK algorithm of libccd
(`ccdGJKDist`, Soar 9.6.6 `SVS/ccd/ccd.c`, `vec3.c`; `sgnode_algs.cpp` `convex_distance`), in
double precision, with at most 100 iterations and a tolerance of `INTERSECT_THRESH` = 1e-15.
The functions below follow libccd's operations one by one (vector arithmetic is libccd's own,
summed left to right), since the distance reported is libccd's.
-/

namespace Soar.SVS

namespace Ccd

def eps : Float := 2.220446049250313e-16   -- DBL_EPSILON
def realMax : Float := 1.7976931348623157e308

def isZero (x : Float) : Bool := x.abs < eps
def eq (a b : Float) : Bool :=
  let ab := (a - b).abs
  if ab.abs < eps then true else
  let a := a.abs
  let b := b.abs
  if b > a then ab < eps * b else ab < eps * a
def sign (x : Float) : Int := if isZero x then 0 else if x < 0 then -1 else 1

def dot (a b : V3) : Float := (a.x * b.x + a.y * b.y) + a.z * b.z
def len2 (a : V3) : Float := dot a a
def sub (a b : V3) : V3 := ⟨a.x - b.x, a.y - b.y, a.z - b.z⟩
def add (a b : V3) : V3 := ⟨a.x + b.x, a.y + b.y, a.z + b.z⟩
def scale (a : V3) (k : Float) : V3 := ⟨a.x * k, a.y * k, a.z * k⟩
def dist2 (a b : V3) : Float := len2 (sub a b)
def cross (a b : V3) : V3 :=
  ⟨a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x⟩
def normalize (d : V3) : V3 := scale d (1.0 / (len2 d).sqrt)
def veq (a b : V3) : Bool := eq a.x b.x && eq a.y b.y && eq a.z b.z
def tripleCross (a b c : V3) : V3 := cross (cross a b) c

/-- `__ccdVec3PointSegmentDist2`, with the witness point. -/
def pointSegDist2 (P x0 b : V3) : Float × V3 :=
  let d := sub b x0
  let a := sub x0 P
  let t := (-1.0 * dot a d) / len2 d
  if t < 0 || isZero t then (dist2 x0 P, x0)
  else if t > 1 || eq t 1 then (dist2 b P, b)
  else
    let w := add (scale d t) x0
    (dist2 w P, w)

/-- The same without a witness (libccd computes the inner case differently then). -/
def pointSegDist2N (P x0 b : V3) : Float :=
  let d := sub b x0
  let a := sub x0 P
  let t := (-1.0 * dot a d) / len2 d
  if t < 0 || isZero t then dist2 x0 P
  else if t > 1 || eq t 1 then dist2 b P
  else len2 (add (scale d t) a)

/-- `ccdVec3PointTriDist2`; `wit` says whether the caller asked for the witness. -/
def pointTriDist2 (P x0 B C : V3) (wit : Bool) : Float × V3 :=
  let d1 := sub B x0
  let d2 := sub C x0
  let a := sub x0 P
  let u := dot a a
  let v := dot d1 d1
  let w := dot d2 d2
  let p := dot a d1
  let q := dot a d2
  let r := dot d1 d2
  let s := (q * r - w * p) / (w * v - r * r)
  let t := (-s * r - q) / w
  if (isZero s || s > 0) && (eq s 1 || s < 1) && (isZero t || t > 0) && (eq t 1 || t < 1) &&
      (eq (t + s) 1 || t + s < 1) then
    if wit then
      let wv := add (add x0 (scale d1 s)) (scale d2 t)
      (dist2 wv P, wv)
    else
      let dist := s * s * v
      let dist := dist + t * t * w
      let dist := dist + 2.0 * s * t * r
      let dist := dist + 2.0 * s * p
      let dist := dist + 2.0 * t * q
      (dist + u, V3.zero)
  else
    let (d, wv) := if wit then pointSegDist2 P x0 B else (pointSegDist2N P x0 B, V3.zero)
    let (d2', w2) := pointSegDist2 P x0 C
    let (d, wv) := if d2' < d then (d2', w2) else (d, wv)
    let (d3, w3) := pointSegDist2 P B C
    if d3 < d then (d3, w3) else (d, wv)

end Ccd

/-- A shape for GJK: a node of the scene, or a point. -/
inductive Obj where
  | node (u : Nat)
  | pt (p : V3)

/-- `geometry_node::gjk_support`: the support point in world coordinates. -/
def Scene.support (sc : Scene) (o : Obj) (dir : V3) : V3 :=
  match o with
  | .pt p => p
  | .node u =>
    let t := sc.world u
    -- B.block(0,0,3,3).transpose() * dir
    let tdir : V3 := ⟨(t.lin.col 0).dot dir, (t.lin.col 1).dot dir, (t.lin.col 2).dot dir⟩
    let loc := match (sc.node u).shape with
      | .convex vs =>
        let (_, best) := vs.foldl (fun (acc : Option Float × V3) v =>
          let dp := tdir.dot v
          match acc.1 with
          | none => (some dp, v)
          | some b => if dp > b then (some dp, v) else acc) (none, V3.zero)
        best
      | .ball r => V3.smul r tdir.normalized
      | .group => V3.zero
    t.apply loc

/-- `__ccdSupport`: a point of the Minkowski difference. -/
def Scene.ccdSupport (sc : Scene) (a b : Obj) (dir : V3) : V3 :=
  Ccd.sub (sc.support a dir) (sc.support b (Ccd.scale dir (-1.0)))

namespace Ccd

/-- `doSimplex2`; the simplex lists points oldest first, the last added last. -/
def doSimplex2 (sx : Array V3) : Int × Array V3 × V3 :=
  let A := sx[1]!
  let B := sx[0]!
  let AB := sub B A
  let AO := scale A (-1.0)
  let d := dot AB AO
  let tmp := cross AB AO
  if isZero (len2 tmp) && d > 0 then (1, sx, V3.zero)
  else if isZero d || d < 0 then (0, #[A], AO)
  else (0, sx, tripleCross AB AO AB)

def doSimplex3 (sx : Array V3) : Int × Array V3 × V3 :=
  let A := sx[2]!
  let B := sx[1]!
  let C := sx[0]!
  let (dist, _) := pointTriDist2 V3.zero A B C false
  if isZero dist then (1, sx, V3.zero)
  else if veq A B || veq A C then (-1, sx, V3.zero)
  else
  let AO := scale A (-1.0)
  let AB := sub B A
  let AC := sub C A
  let ABC := cross AB AC
  let case45 : Int × Array V3 × V3 :=
    let d := dot AB AO
    if isZero d || d > 0 then (0, #[B, A], tripleCross AB AO AB)
    else (0, #[A], AO)
  let tmp := cross ABC AC
  let d := dot tmp AO
  if isZero d || d > 0 then
    let d := dot AC AO
    if isZero d || d > 0 then (0, #[C, A], tripleCross AC AO AC)
    else case45
  else
    let tmp := cross AB ABC
    let d := dot tmp AO
    if isZero d || d > 0 then case45
    else
      let d := dot ABC AO
      if isZero d || d > 0 then (0, sx, ABC)
      else (0, #[B, C, A], scale ABC (-1.0))

def doSimplex4 (sx : Array V3) : Int × Array V3 × V3 :=
  let A := sx[3]!
  let B := sx[2]!
  let C := sx[1]!
  let D := sx[0]!
  if isZero (pointTriDist2 A B C D false).1 then (-1, sx, V3.zero)
  else if isZero (pointTriDist2 V3.zero A B C false).1 then (1, sx, V3.zero)
  else if isZero (pointTriDist2 V3.zero A C D false).1 then (1, sx, V3.zero)
  else if isZero (pointTriDist2 V3.zero A B D false).1 then (1, sx, V3.zero)
  else if isZero (pointTriDist2 V3.zero B C D false).1 then (1, sx, V3.zero)
  else
  let AO := scale A (-1.0)
  let AB := sub B A
  let AC := sub C A
  let AD := sub D A
  let ABC := cross AB AC
  let ACD := cross AC AD
  let ADB := cross AD AB
  let bOnACD := sign (dot ACD AB)
  let cOnADB := sign (dot ADB AC)
  let dOnABC := sign (dot ABC AD)
  let abO := sign (dot ACD AO) == bOnACD
  let acO := sign (dot ADB AO) == cOnADB
  let adO := sign (dot ABC AO) == dOnABC
  if abO && acO && adO then (1, sx, V3.zero)
  else if !abO then doSimplex3 #[D, C, A]
  else if !acO then doSimplex3 #[B, D, A]
  else doSimplex3 #[C, B, A]

def doSimplex (sx : Array V3) : Int × Array V3 × V3 :=
  if sx.size == 2 then doSimplex2 sx else if sx.size == 3 then doSimplex3 sx else doSimplex4 sx

/-- `__ccdGJK`: `some simplex` if no intersection was found (libccd's -1 with the simplex it
reached), `none` if the shapes intersect. -/
def gjk (sc : Scene) (a b : Obj) (maxIt : Nat) : Option (Array V3) := Id.run do
  let first := sc.ccdSupport a b ⟨1, 0, 0⟩
  let mut sx : Array V3 := #[first]
  let mut dir := scale first (-1.0)
  for _ in [0:maxIt] do
    let last := sc.ccdSupport a b dir
    if dot last dir < 0 then return some sx
    sx := sx.push last
    let (res, sx', dir') := doSimplex sx
    sx := sx'
    dir := dir'
    if res == 1 then return none
    if res == -1 then return some sx
    if isZero (len2 dir) then return some sx
  return some sx

/-- `simplexReduceToTriangle`. -/
def reduceToTriangle (sx : Array V3) (dist : Float) (bestW : V3) : Float × Array V3 × V3 := Id.run do
  let mut dist := dist
  let mut best : Option Nat := none
  let mut bw := bestW
  for i in [0, 1, 2] do
    let (nd, w) := pointTriDist2 V3.zero (if i == 0 then sx[3]! else sx[0]!)
      (if i == 1 then sx[3]! else sx[1]!) (if i == 2 then sx[3]! else sx[2]!) true
    let nd := nd.sqrt
    if nd < dist then
      dist := nd
      best := some i
      bw := w
  let sx := match best with | some i => sx.set! i sx[3]! | none => sx
  return (dist, sx.extract 0 3, bw)

/-- `ccdGJKDist`: the distance, or -1 if the shapes intersect or touch. -/
def gjkDist (sc : Scene) (a b : Obj) (maxIt : Nat := 100) (tol : Float := 1.0e-15) : Float := Id.run do
  let some sx0 := gjk sc a b maxIt | return -1.0
  let mut sx := sx0
  let mut lastDist := realMax
  let mut dir := V3.zero
  for _ in [0:maxIt] do
    let mut dist := 0.0
    if sx.size == 1 then
      dir := sx[0]!
      dist := (len2 sx[0]!).sqrt
    else if sx.size == 2 then
      let (d, w) := pointSegDist2 V3.zero sx[0]! sx[1]!
      dist := d.sqrt
      dir := w
    else if sx.size == 3 then
      let (d, w) := pointTriDist2 V3.zero sx[0]! sx[1]! sx[2]! true
      dist := d.sqrt
      dir := w
    else
      let (d, sx', w) := reduceToTriangle sx lastDist dir
      dist := d
      sx := sx'
      dir := w
    if isZero dist then return -1.0
    if (lastDist - dist) < tol then return dist
    dir := normalize (scale dir (-1.0))
    let last := sc.ccdSupport a b dir
    lastDist := dist
    let d2 := (len2 last).sqrt
    if (lastDist - d2).abs < tol then return lastDist
    sx := sx.push last
  return -1.0

end Ccd

/-- `convex_distance` (`sgnode_algs.cpp`): 0 for a node and its own descendant or ancestor;
otherwise the least distance between their geometry nodes (a group without any measured from
its centroid), clamped at 0. -/
def Scene.convexDistance (sc : Scene) (a b : Nat) : Float :=
  if a == b || sc.hasDesc a b || sc.hasDesc b a then 0 else
  let clamp (d : Float) : Float := if d > 0 then d else 0
  let g1 := sc.geoms a
  let g2 := sc.geoms b
  let ds : List Float :=
    if g1.isEmpty && g2.isEmpty then [(V3.sub (sc.centroid a) (sc.centroid b)).norm]
    else if g1.isEmpty then
      let c := sc.centroid a
      g2.map fun g => clamp (Ccd.gjkDist sc (.pt c) (.node g))
    else if g2.isEmpty then
      let c := sc.centroid b
      g1.map fun g => clamp (Ccd.gjkDist sc (.pt c) (.node g))
    else g1.flatMap fun x => g2.map fun y => clamp (Ccd.gjkDist sc (.node x) (.node y))
  match ds with
  | d :: rest => rest.foldl (fun m x => if x < m then x else m) d
  | [] => 0

/-- `convex_intersects`: the boxes meet and the distance is below 1e-15. -/
def Scene.convexIntersects (sc : Scene) (a b : Nat) : Bool :=
  (sc.bounds a).intersects (sc.bounds b) && sc.convexDistance a b < 1.0e-15

end Soar.SVS
