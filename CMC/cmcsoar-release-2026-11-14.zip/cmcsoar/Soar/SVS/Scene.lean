import Soar.SVS.Geom
import Std.Data.HashMap
/-!
# SVS — the scene graph

A scene ([Man] §8.1; Soar 9.6.6 `scene.cpp`, `sgnode.cpp`) is a tree of nodes rooted at
`world`. A node is a group (with children), a convex polyhedron (its vertices) or a ball (its
radius); each has a position, rotation and scale relative to its parent, and tags (string
attribute–value pairs).

Nodes are objects in SVS, compared by pointer; here each node has a number (`uid`) that plays
the pointer's part. A change to a node is announced to the node's listeners as an event
(`sgnode::send_update`): the scene itself, the working-memory mirror of the scene graph and the
filters that read the node. The operations below return the events they announce, in order.

The scene's node list (`scene::nodes`) has the root first and each node attached to a node in
the list appended when it is attached; a node deleted leaves it. A node copied with its
descendants (`clone`) brings the descendants along without listing them, so they cannot be
found by name — except in a substate's copy of the scene, which lists every node (`clone`
walks the whole tree). Soar 9.6.6 behaves so; the model reproduces it.
-/

namespace Soar.SVS

inductive Shape where
  | group
  | convex (verts : List V3)
  | ball (r : Float)
  deriving Inhabited

structure Node where
  name : String
  parent : Option Nat := none
  kids : List Nat := []
  shape : Shape
  pos : V3 := V3.zero
  rot : V3 := V3.zero
  scl : V3 := V3.one
  /-- Tags, sorted by name (`std::map`). -/
  tags : List (String × String) := []
  deriving Inhabited

def Node.isGroup (n : Node) : Bool := match n.shape with | .group => true | _ => false

/-- The events of `sgnode::change_type`. -/
inductive Ev where
  | childAdded (parent child : Nat)
  | deleted (n : Nat)
  | trans (n : Nat)
  | shape (n : Nat)
  | tagChanged (n : Nat) (name : String)
  | tagDeleted (n : Nat) (name : String)
  deriving Inhabited, Repr, BEq

structure Scene where
  nodes : Std.HashMap Nat Node := {}
  /-- `scene::nodes`: the listed nodes, root first. -/
  order : List Nat := []
  root : Nat := 0
  deriving Inhabited

/-- Insert into a list sorted by key, replacing an entry with the same key. -/
def tagSet (l : List (String × String)) (k v : String) : List (String × String) :=
  let l := l.filter (·.1 != k)
  let (a, b) := l.span (fun p => decide (p.1 < k))
  a ++ [(k, v)] ++ b

namespace Scene

def get? (sc : Scene) (u : Nat) : Option Node := sc.nodes.get? u
def node (sc : Scene) (u : Nat) : Node := (sc.nodes.get? u).getD default
def upd (sc : Scene) (u : Nat) (f : Node → Node) : Scene :=
  match sc.nodes.get? u with
  | some n => { sc with nodes := sc.nodes.insert u (f n) }
  | none => sc

/-- `scene::get_node`: the first listed node with that name. -/
def find (sc : Scene) (name : String) : Option Nat :=
  sc.order.find? fun u => (sc.node u).name == name

/-- `scene::get_group`. -/
def findGroup (sc : Scene) (name : String) : Option Nat :=
  match sc.find name with
  | some u => if (sc.node u).isGroup then some u else none
  | none => none

/-- A new scene with only `world` (`scene::scene`); `uid` is the root's number. -/
def fresh (uid : Nat) : Scene :=
  { nodes := ({} : Std.HashMap Nat Node).insert uid { name := "world", shape := .group }, order := [uid], root := uid }

/-- Ancestors from the root down to `u`'s parent. -/
partial def ancestors (sc : Scene) (u : Nat) : List Nat :=
  match (sc.node u).parent with
  | some p => ancestors sc p ++ [p]
  | none => []

/-- `set_shape_dirty` on `u`: shape events for `u`'s ancestors from the root down, then `u`. -/
def shapeDirty (sc : Scene) (u : Nat) : List Ev :=
  (sc.ancestors u ++ [u]).map .shape

/-- `set_transform_dirty` on `u`: the parent's `set_shape_dirty`, the same for each child in
turn (a group's `set_transform_dirty_sub`), then `u`'s transform event. -/
partial def transDirty (sc : Scene) (u : Nat) : List Ev :=
  let n := sc.node u
  let up := match n.parent with | some p => sc.shapeDirty p | none => []
  up ++ n.kids.flatMap (sc.transDirty ·) ++ [.trans u]

/-- `sgnode::set_trans(type, v)`: only a change is announced. -/
def setTrans (sc : Scene) (u : Nat) (ty : Char) (v : V3) : Scene × List Ev :=
  let n := sc.node u
  let old := match ty with | 'p' => n.pos | 'r' => n.rot | _ => n.scl
  if old == v then (sc, []) else
  let sc := sc.upd u fun n => match ty with
    | 'p' => { n with pos := v } | 'r' => { n with rot := v } | _ => { n with scl := v }
  (sc, sc.transDirty u)

/-- `group_node::attach_child`: the child is appended; its transform and the parent's shape
change; the parent announces the child. The scene lists a child of a listed node. -/
def attach (sc : Scene) (p c : Nat) : Scene × List Ev :=
  let sc := sc.upd p fun n => { n with kids := n.kids ++ [c] }
  let sc := sc.upd c fun n => { n with parent := some p }
  let evs := sc.transDirty c ++ sc.shapeDirty p ++ [.childAdded p c]
  let sc := if sc.order.contains p then { sc with order := sc.order ++ [c] } else sc
  (sc, evs)

/-- Deleting a node (its destructor): a group's children are deleted first, each before its
own deletion is announced and without detaching (`group_node::~group_node`); then the node is
detached from its parent (the parent's shape changes) and its deletion announced. A listed node
leaves the list. -/
partial def delete (sc : Scene) (u : Nat) : Scene × List Ev :=
  let rec dropSub (sc : Scene) (u : Nat) : Scene × List Ev :=
    let n := sc.node u
    let (sc, evs) := n.kids.foldl (fun (acc : Scene × List Ev) c =>
      let (sc, e) := dropSub acc.1 c
      (sc, acc.2 ++ e)) (sc, [])
    let sc := { sc with nodes := sc.nodes.erase u, order := sc.order.filter (· != u) }
    (sc, evs ++ [.deleted u])
  let n := sc.node u
  let (sc, evs) := n.kids.foldl (fun (acc : Scene × List Ev) c =>
      let (sc, e) := dropSub acc.1 c
      (sc, acc.2 ++ e)) (sc, [])
  let (sc, evs2) := match n.parent with
    | some p =>
      let sc := sc.upd p fun m => { m with kids := m.kids.filter (· != u) }
      (sc, sc.shapeDirty p)
    | none => (sc, [])
  let sc := { sc with nodes := sc.nodes.erase u, order := sc.order.filter (· != u) }
  (sc, evs ++ evs2 ++ [.deleted u])

def setTag (sc : Scene) (u : Nat) (k v : String) : Scene × List Ev :=
  (sc.upd u fun n => { n with tags := tagSet n.tags k v }, [.tagChanged u k])

def delTag (sc : Scene) (u : Nat) (k : String) : Scene × List Ev :=
  if (sc.node u).tags.any (·.1 == k) then
    (sc.upd u fun n => { n with tags := n.tags.filter (·.1 != k) }, [.tagDeleted u k])
  else (sc, [])

/-- Add a node made apart from the scene (not yet attached), numbered `uid`. -/
def insertNew (sc : Scene) (uid : Nat) (n : Node) : Scene :=
  { sc with nodes := sc.nodes.insert uid n }

/-- A copy of the whole scene for a substate (`scene::clone`), its nodes numbered from `next`:
every node, including those not listed in the original, is listed in the copy, in preorder
(`group_node::walk`). Returns the copy and the next free number. -/
partial def clone (sc : Scene) (next : Nat) : Scene × Nat :=
  let rec go (u : Nat) (par : Option Nat) (acc : Scene × Nat) : Scene × Nat × Nat :=
    let (c, k) := acc
    let me := k
    let n := sc.node u
    let c := { c with nodes := c.nodes.insert me { n with parent := par, kids := [] }, order := c.order ++ [me] }
    let (c, k, kidsNew) := n.kids.foldl (fun (st : Scene × Nat × List Nat) ch =>
      let (c, k, ks) := st
      let (c, k, cu) := go ch (some me) (c, k)
      (c, k, ks ++ [cu])) (c, k + 1, [])
    let c := c.upd me fun m => { m with kids := kidsNew }
    (c, k, me)
  let (c, k, r) := go sc.root none ({}, next)
  ({ c with root := r }, k)

/-! ## Transforms and bounds -/

/-- The node's own transform (`ltransform`). -/
def localXf (sc : Scene) (u : Nat) : Xf :=
  let n := sc.node u
  Xf.ofPRS n.pos n.rot n.scl

/-- The node's world transform: its parent's world transform times its own. -/
partial def world (sc : Scene) (u : Nat) : Xf :=
  match (sc.node u).parent with
  | some p => Xf.mul (sc.world p) (sc.localXf u)
  | none => sc.localXf u

/-- A convex node's vertices in world coordinates. -/
def worldVerts (sc : Scene) (u : Nat) : List V3 :=
  match (sc.node u).shape with
  | .convex vs => let w := sc.world u; vs.map w.apply
  | _ => []

/-- The node's bounding box (`update_shape`): a convex node's world vertices; a ball's eight
transformed corners; a group's children's boxes, or the point at its origin if it has none. -/
partial def bounds (sc : Scene) (u : Nat) : BBox :=
  let n := sc.node u
  match n.shape with
  | .convex _ => BBox.ofPoints (sc.worldVerts u)
  | .ball r =>
    let w := sc.world u
    BBox.ofPoints ([(-r, -r, -r), (-r, -r, r), (-r, r, -r), (-r, r, r),
      (r, -r, -r), (r, -r, r), (r, r, -r), (r, r, r)].map fun (a, b, c) => w.apply ⟨a, b, c⟩)
  | .group =>
    match n.kids with
    | [] => BBox.ofPoint ((sc.world u).apply V3.zero)
    | c :: cs => cs.foldl (fun b k => b.inclBox (sc.bounds k)) (sc.bounds c)

def centroid (sc : Scene) (u : Nat) : V3 := (sc.bounds u).centroid

/-- `max_project_on_axis`. SOAR 9.6.6 DEFECT (reproduced): a ball's uses the length of its
world transform applied to `(r, 0, 0)`, translation included (`ball_node::max_project_on_axis`),
which is its radius only for a ball at the origin. -/
partial def maxProj (sc : Scene) (u : Nat) (ax : V3) : Float :=
  let n := sc.node u
  let c := (sc.centroid u).dot ax
  match n.shape with
  | .ball r => c + ((sc.world u).apply ⟨r, 0, 0⟩).norm
  | .convex _ => (sc.worldVerts u).foldl (fun m v => let p := v.dot ax; if p > m then p else m) c
  | .group => n.kids.foldl (fun m k => let p := sc.maxProj k ax; if p > m then p else m) c

partial def minProj (sc : Scene) (u : Nat) (ax : V3) : Float :=
  let n := sc.node u
  let c := (sc.centroid u).dot ax
  match n.shape with
  | .ball r => c - ((sc.world u).apply ⟨r, 0, 0⟩).norm
  | .convex _ => (sc.worldVerts u).foldl (fun m v => let p := v.dot ax; if p < m then p else m) c
  | .group => n.kids.foldl (fun m k => let p := sc.minProj k ax; if p < m then p else m) c

/-- `has_descendent`: `d` is below `u`. -/
partial def hasDesc (sc : Scene) (u d : Nat) : Bool :=
  match (sc.node d).parent with
  | some p => p == u || sc.hasDesc u p
  | none => false

/-- The geometry nodes at or below `u` (`walk_geoms`). -/
partial def geoms (sc : Scene) (u : Nat) : List Nat :=
  let n := sc.node u
  match n.shape with
  | .group => n.kids.flatMap sc.geoms
  | _ => [u]

/-! ## Spatial relations (`sgnode_algs.cpp`) -/

/-- `centroid_distance`: between the nodes' positions relative to their parents. -/
def centroidDist (sc : Scene) (a b : Nat) : Float := (V3.sub (sc.node b).pos (sc.node a).pos).norm

/-- `axis_distance(a, b, dim)`: the signed gap between the boxes along a coordinate axis. -/
def axisDistDim (sc : Scene) (a b : Nat) (d : Int) : Float :=
  if d < 0 || d > 2 then 0 else
  let i := d.toNat
  let ba := sc.bounds a
  let bb := sc.bounds b
  let mina := ba.lo.get i
  let maxa := ba.hi.get i
  let minb := bb.lo.get i
  let maxb := bb.hi.get i
  if minb > maxa then minb - maxa else if maxb < mina then maxb - mina else 0

/-- `axis_distance(a, b, axis)`: the same along a direction, by projections. -/
def axisDistVec (sc : Scene) (a b : Nat) (ax : V3) : Float :=
  let len := ax.norm
  if len == 0 then len else
  let u := ax.sdiv len
  let mina := sc.minProj a u
  let maxa := sc.maxProj a u
  let minb := sc.minProj b u
  let maxb := sc.maxProj b u
  if minb > maxa then minb - maxa else if maxb < mina then maxb - mina else 0

def bboxVolume (sc : Scene) (a : Nat) : Float := (sc.bounds a).volume
def scaleVolume (sc : Scene) (a : Nat) : Float := let s := (sc.node a).scl; s.x * s.y * s.z
def bboxIntersects (sc : Scene) (a b : Nat) : Bool := (sc.bounds a).intersects (sc.bounds b)
def bboxContains (sc : Scene) (a b : Nat) : Bool := (sc.bounds a).contains (sc.bounds b)

end Scene
end Soar.SVS
