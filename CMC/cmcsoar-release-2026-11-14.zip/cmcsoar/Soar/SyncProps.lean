import Soar.Cycle
/-!
# Soar 9.6 — synchronising working memory with preference memory is idempotent

`St.sync` brings the elements made from preference memory (`slots`) in line with what the
preferences require (`desired`) and then gives the elements their timetags (`retag`). This file
shows that doing it again changes nothing once it has finished (`sync_fixed`, `sync_settles`):
the elements `desired` lists have no repeats, so a state whose slots hold exactly the desired
elements is a fixed point, and `retag` of a state whose table lists the elements of working
memory in order is the state itself. It justifies skipping the second `sync` in `St.gc` when no
preference was removed (S23 in the code review).
-/

namespace Soar

/-- The table `retag` builds lists the elements of working memory, in order. -/
theorem retag_keys (s : St) : (s.retag).tt.map (·.1) = s.raw := by
  obtain ⟨a, b, h⟩ := noteSyms_fr (s.raw.filter (!(insTab s.tt).contains ·))
    ({ s with tt := (s.raw.foldl (tagStep (insTab s.tt)) ([], s.tNext)).1.reverse,
              tNext := (s.raw.foldl (tagStep (insTab s.tt)) ([], s.tNext)).2 } : St)
  rw [retag_eq, h]
  simp only
  rw [tag_fold_keys]
  simp

/-- `retag` twice is `retag` once. -/
theorem retag_idem (s : St) : s.retag.retag = s.retag := by
  apply retag_fixed
  rw [retag_keys, (retag_fr s).raw]

/-! ## The desired elements have no repeats -/

/-! ## The synchronisation step -/

theorem filterMap_self {α : Type} (f : α → Option α) :
    ∀ (l : List α), (∀ x ∈ l, f x = some x) → l.filterMap f = l
  | [], _ => rfl
  | x :: l, h => by
    rw [List.filterMap_cons, h x (by simp), filterMap_self f l (fun y hy => h y (List.mem_cons_of_mem _ hy))]

theorem insW_present (k : WME) : ∀ (L : List WEnt) (m : Std.HashMap WME WEnt),
    k ∈ L.map (·.w) → ((L.foldl (fun m e => m.insert e.w e) m)[k]?).isSome = true
  | [], m, h => by simp at h
  | x :: L, m, h => by
    rw [List.foldl_cons]
    by_cases hk : k ∈ L.map (·.w)
    · exact insW_present k L _ hk
    · have hx : x.w = k := by
        rcases List.mem_map.mp h with ⟨y, hy, rfl⟩
        rcases List.mem_cons.mp hy with rfl | hy
        · rfl
        · exact absurd (List.mem_map.mpr ⟨y, hy, rfl⟩) hk
      rw [insW_notmem k L _ hk]
      simp [Std.HashMap.getElem?_insert, hx]

theorem olds_contains (k : WME) : ∀ (L : List WEnt) (S : Std.HashSet WME),
    (L.foldl (fun m e => m.insert e.w) S).contains k = true ↔ S.contains k = true ∨ k ∈ L.map (·.w)
  | [], S => by simp
  | e :: L, S => by
    rw [List.foldl_cons, olds_contains k L, Std.HashSet.contains_insert]
    simp only [Bool.or_eq_true, beq_iff_eq, List.map_cons, List.mem_cons]
    constructor
    · rintro ((h | h) | h)
      · exact Or.inr (Or.inl h.symm)
      · exact Or.inl h
      · exact Or.inr (Or.inr h)
    · rintro (h | h | h)
      · exact Or.inl (Or.inr h)
      · exact Or.inl (Or.inl h.symm)
      · exact Or.inr h

/-- The slots hold exactly the elements preference memory requires. -/
def Settled (s : St) : Prop := (∀ e ∈ s.slots, e ∈ s.desired) ∧ (∀ e ∈ s.desired, e ∈ s.slots)

theorem dm_get (s : St) (e : WEnt) (he : e ∈ s.desired) :
    (s.desired.foldl (fun m e => m.insert e.w e) ({} : Std.HashMap WME WEnt))[e.w]? = some e :=
  insW_mem e _ _ (desired_nodup s) he

theorem syncPlan_settled {t : St} (h : Settled t) : t.syncPlan = (t.slots, [], []) := by
  unfold St.syncPlan
  simp only
  have hk : t.slots.filterMap (fun e => (t.desired.foldl (fun m e => m.insert e.w e)
      ({} : Std.HashMap WME WEnt)).get? e.w) = t.slots :=
    filterMap_self _ _ (fun e he => dm_get t e (h.1 e he))
  have hn : t.desired.filter (fun e => !(t.slots.foldl (fun m e => m.insert e.w) ({} : Std.HashSet WME)).contains e.w) = [] := by
    rw [List.filter_eq_nil_iff]
    intro e he
    have := (olds_contains e.w t.slots {}).mpr (Or.inr (List.mem_map.mpr ⟨e, h.2 e he, rfl⟩))
    simp [this]
  have hg : t.slots.filter (fun e => !(t.desired.foldl (fun m e => m.insert e.w e)
      ({} : Std.HashMap WME WEnt)).contains e.w) = [] := by
    rw [List.filter_eq_nil_iff]
    intro e he
    have := dm_get t e (h.1 e he)
    simp [Std.HashMap.contains_eq_isSome_getElem?, this]
  rw [hk, hn, hg]

theorem sync_settled {t : St} (hS : Settled t) (hC : t.tt.map (·.1) = t.raw) (m : Nat) :
    t.sync (m + 1) = t := by
  rw [St.sync]
  simp only [syncPlan_settled hS]
  have hstep : t.syncStep (t.slots, [], []) = t := by
    unfold St.syncStep; simp
  rw [hstep]
  have hl : St.syncLost t [] = none := by simp [St.syncLost]
  rw [hl]
  exact retag_fixed t hC

theorem desired_fr {s t : St} (h : TagFr s t) : t.desired = s.desired := by
  obtain ⟨_, _, _, _, rfl⟩ := h; rfl

theorem settled_step (s : St) : Settled (s.syncStep s.syncPlan) := by
  have hd : (s.syncStep s.syncPlan).desired = s.desired := rfl
  have hs : (s.syncStep s.syncPlan).slots = s.syncPlan.1 ++ s.syncPlan.2.1 := rfl
  unfold Settled
  rw [hd, hs]
  unfold St.syncPlan
  simp only
  constructor
  · intro e he
    rcases List.mem_append.mp he with h1 | h1
    · obtain ⟨a, _, ha⟩ := List.mem_filterMap.mp h1
      rcases insW_some a.w e s.desired {} ha with h2 | h2
      · exact h2
      · simp at h2
    · exact (List.mem_filter.mp h1).1
  · intro e he
    by_cases hc : (s.slots.foldl (fun m e => m.insert e.w) ({} : Std.HashSet WME)).contains e.w = true
    · apply List.mem_append_left
      obtain ⟨a, ha, haw⟩ := List.mem_map.mp (((olds_contains e.w s.slots {}).mp hc).resolve_left (by simp))
      refine List.mem_filterMap.mpr ⟨a, ha, ?_⟩
      have := dm_get s e he
      rw [haw]
      exact this
    · apply List.mem_append_right
      exact List.mem_filter.mpr ⟨he, by simpa using hc⟩

theorem settled_retag {s : St} (h : Settled s) : Settled s.retag := by
  have fr := retag_fr s
  unfold Settled
  rw [fr.slots, desired_fr fr]
  exact h

/-- `sync` has finished within `n` steps: the operator cascade ends before the fuel does. -/
def St.syncDone : St → Nat → Prop
  | _, 0 => False
  | s, n + 1 =>
    match St.syncLost (s.syncStep s.syncPlan) s.syncPlan.2.2 with
    | none => True
    | some g => ((s.syncStep s.syncPlan).removeOperator g).syncDone n

theorem sync_result : ∀ (n : Nat) (s : St), s.syncDone (n + 1) →
    Settled (s.sync (n + 1)) ∧ (s.sync (n + 1)).tt.map (·.1) = (s.sync (n + 1)).raw
  | n, s, h => by
    have heq : s.sync (n + 1) = match St.syncLost (s.syncStep s.syncPlan) s.syncPlan.2.2 with
        | some g => ((s.syncStep s.syncPlan).removeOperator g).sync n
        | none => (s.syncStep s.syncPlan).retag := rfl
    unfold St.syncDone at h
    cases hl : St.syncLost (s.syncStep s.syncPlan) s.syncPlan.2.2 with
    | none =>
      rw [heq, hl]
      simp only
      refine ⟨settled_retag (settled_step s), ?_⟩
      rw [retag_keys, (retag_fr _).raw]
    | some g =>
      rw [heq, hl]
      simp only
      rw [hl] at h
      cases n with
      | zero => exact absurd h (by simp [St.syncDone])
      | succ k => exact sync_result k _ h

/-- **Synchronising twice is synchronising once.** If the first `sync` finishes (the cascade of
operator removals ends within its fuel), a second `sync`, with any fuel, changes nothing: the
slots already hold exactly the desired elements, and the table of timetags already lists the
elements of working memory in order. -/
theorem sync_idem (s : St) (n m : Nat) (h : s.syncDone (n + 1)) :
    (s.sync (n + 1)).sync (m + 1) = s.sync (n + 1) := by
  obtain ⟨h1, h2⟩ := sync_result n s h
  exact sync_settled h1 h2 m

end Soar
