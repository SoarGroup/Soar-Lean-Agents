import Soar.Syntax
import Soar.Graph
/-!
# Soar 9.6 — execution layer: an index of working memory

Execution only. The specification computes working memory from scratch whenever it is needed
(`St.wm`: the elements of the architecture, the input and the slots, without repeats, that are
linked to a state). The compiled program instead keeps an index of the elements (`WIx`) and
brings it up to date as slots change (`St.sync`, through `St.sync_eq_fast`), so that working
memory and the identifiers linked to a state are found without rebuilding everything.

`WIx.Ok L x`: the index `x` describes the list `L` — how many times each element, each
identifier and each link occurs in it — and, when `x.nd` is set, `L` has no repeats. The
property depends only on the elements of `L` with their multiplicities (`WIx.Ok_perm`), so it
survives reordering; `Ok_add` and `Ok_rem` give it for one element added or removed.
-/

namespace Soar

instance {α : Type u} : Repr (Squash α) := ⟨fun _ _ => "⟨index⟩"⟩

/-- The identifiers an element links its identifier to: its value and its attribute (Soar 9.6.6
`add_wme_to_wm`, `post_link_addition` for an identifier value and for an identifier
attribute; `remove_wme_from_wm` likewise). An identifier that appears only in an attribute
field (`(S1 ^X1 yes)`) is reachable, as the manual intends ([Man] §2.2).

Soar 9.6.5 linked the value only, so such an identifier was collected with its elements
(kernel defect 30, fixed in 9.6.6; tests/mapdiff/exe/dc1_attrlink.soar,
bugs/gc-attribute-identifier.soar). -/
def wmeLinks (w : WME) : List Nat :=
  (match w.val with | .id n => [n] | _ => []) ++ (match w.attr with | .id n => [n] | _ => [])

/-! ## Counters -/

section Counters
variable {α : Type} [BEq α] [Hashable α] [LawfulBEq α]

/-- Add one to the count of `k`. -/
def cntInc (m : Std.HashMap α Nat) (k : α) : Std.HashMap α Nat := m.insert k (m.getD k 0 + 1)

/-- Take one from the count of `k`; a count that reaches zero is removed. -/
def cntDec (m : Std.HashMap α Nat) (k : α) : Std.HashMap α Nat :=
  let c := m.getD k 0
  if c ≤ 1 then m.erase k else m.insert k (c - 1)

theorem cntInc_getD (m : Std.HashMap α Nat) (k a : α) :
    (cntInc m k).getD a 0 = m.getD a 0 + (if k == a then 1 else 0) := by
  unfold cntInc
  rw [Std.HashMap.getD_insert]
  by_cases h : k = a
  · subst h; simp
  · have : (k == a) = false := by simpa using h
    simp [this]

theorem cntDec_getD (m : Std.HashMap α Nat) (k a : α) :
    (cntDec m k).getD a 0 = m.getD a 0 - (if k == a then 1 else 0) := by
  unfold cntDec
  simp only
  by_cases h : k = a
  · subst h
    split
    · rw [Std.HashMap.getD_erase]; simp; omega
    · rw [Std.HashMap.getD_insert]; simp
  · have hb : (k == a) = false := by simpa using h
    split
    · rw [Std.HashMap.getD_erase]; simp [hb]
    · rw [Std.HashMap.getD_insert]; simp [hb]

/-- No key has a zero count. -/
def NoZero (m : Std.HashMap α Nat) : Prop := ∀ k, k ∈ m → 0 < m.getD k 0

theorem NoZero.mem_iff {m : Std.HashMap α Nat} (h : NoZero m) (k : α) : k ∈ m ↔ 0 < m.getD k 0 := by
  constructor
  · exact h k
  · intro hk
    by_cases hm : k ∈ m
    · exact hm
    · rw [Std.HashMap.getD_eq_fallback hm] at hk
      exact absurd hk (Nat.lt_irrefl 0)

theorem NoZero.empty : NoZero ({} : Std.HashMap α Nat) := by
  intro k hk; simp at hk

theorem NoZero.inc {m : Std.HashMap α Nat} (h : NoZero m) (k : α) : NoZero (cntInc m k) := by
  intro a ha
  rw [cntInc_getD]
  unfold cntInc at ha
  rw [Std.HashMap.mem_insert] at ha
  by_cases hk : k = a
  · subst hk; simp
  · have hb : (k == a) = false := by simpa using hk
    rcases ha with ha | ha
    · simp [hb] at ha
    · have := h a ha; simp [hb]; omega

theorem NoZero.dec {m : Std.HashMap α Nat} (h : NoZero m) (k : α) : NoZero (cntDec m k) := by
  intro a ha
  rw [cntDec_getD]
  unfold cntDec at ha
  simp only at ha
  split at ha
  · rename_i hc
    rw [Std.HashMap.mem_erase] at ha
    have hka : (k == a) = false := by simpa using ha.1
    have := h a ha.2; simp [hka]; omega
  · rename_i hc
    rw [Std.HashMap.mem_insert] at ha
    by_cases hk : k = a
    · subst hk; simp; omega
    · have hb : (k == a) = false := by simpa using hk
      rcases ha with ha | ha
      · simp [hb] at ha
      · have := h a ha; simp [hb]; omega

end Counters

/-! ## Links, two levels deep -/

/-- Add one to the count of the link `i → j`. -/
def lnkInc (m : Std.HashMap Nat (Std.HashMap Nat Nat)) (i j : Nat) : Std.HashMap Nat (Std.HashMap Nat Nat) :=
  m.insert i (cntInc (m.getD i {}) j)

/-- Take one from the count of the link `i → j`; an identifier with no links left is removed. -/
def lnkDec (m : Std.HashMap Nat (Std.HashMap Nat Nat)) (i j : Nat) : Std.HashMap Nat (Std.HashMap Nat Nat) :=
  let inner := cntDec (m.getD i {}) j
  if inner.isEmpty then m.erase i else m.insert i inner

theorem lnkInc_getD (m : Std.HashMap Nat (Std.HashMap Nat Nat)) (i j a b : Nat) :
    ((lnkInc m i j).getD a {}).getD b 0 = (m.getD a {}).getD b 0 + (if i == a && j == b then 1 else 0) := by
  unfold lnkInc
  rw [Std.HashMap.getD_insert]
  by_cases h : i = a
  · subst h; simp [cntInc_getD]
  · have : (i == a) = false := by simpa using h
    simp [this]

theorem lnkDec_getD (m : Std.HashMap Nat (Std.HashMap Nat Nat)) (i j a b : Nat) :
    ((lnkDec m i j).getD a {}).getD b 0 = (m.getD a {}).getD b 0 - (if i == a && j == b then 1 else 0) := by
  unfold lnkDec
  simp only
  by_cases h : i = a
  · subst h
    split
    · rename_i he
      rw [Std.HashMap.getD_erase]; simp only [beq_self_eq_true, ↓reduceIte, Bool.true_and]
      have : (cntDec (m.getD i {}) j).getD b 0 = 0 := by
        rw [Std.HashMap.isEmpty_iff_forall_not_mem] at he
        exact Std.HashMap.getD_eq_fallback (he b)
      rw [cntDec_getD] at this
      rw [Std.HashMap.getD_empty]
      split at this <;> simp_all <;> omega
    · rw [Std.HashMap.getD_insert]; simp [cntDec_getD]
  · have hb : (i == a) = false := by simpa using h
    split
    · rw [Std.HashMap.getD_erase]; simp [hb]
    · rw [Std.HashMap.getD_insert]; simp [hb]

/-- Every identifier's link counts have no zeros. -/
def LnkNoZero (m : Std.HashMap Nat (Std.HashMap Nat Nat)) : Prop := ∀ i, NoZero (m.getD i {})

theorem LnkNoZero.empty : LnkNoZero ({} : Std.HashMap Nat (Std.HashMap Nat Nat)) := by
  intro i; rw [Std.HashMap.getD_empty]; exact NoZero.empty

theorem LnkNoZero.inc {m : Std.HashMap Nat (Std.HashMap Nat Nat)} (h : LnkNoZero m) (i j : Nat) :
    LnkNoZero (lnkInc m i j) := by
  intro a
  unfold lnkInc
  rw [Std.HashMap.getD_insert]
  split
  · rename_i hia
    have : i = a := by simpa using hia
    subst this; exact (h i).inc j
  · exact h a

theorem LnkNoZero.dec {m : Std.HashMap Nat (Std.HashMap Nat Nat)} (h : LnkNoZero m) (i j : Nat) :
    LnkNoZero (lnkDec m i j) := by
  intro a
  unfold lnkDec
  simp only
  split
  · rw [Std.HashMap.getD_erase]
    split
    · exact NoZero.empty
    · exact h a
  · rw [Std.HashMap.getD_insert]
    split
    · rename_i _ hia
      have : i = a := by simpa using hia
      subst this; exact (h i).dec j
    · exact h a

/-! ## The index -/

/-- An index of a list of elements: how often each element, each identifier and each link
occurs, and (`nd`) whether the list is known to have no repeats. -/
structure WIx where
  cnt : Std.HashMap WME Nat := {}
  nid : Std.HashMap Nat Nat := {}
  lk  : Std.HashMap Nat (Std.HashMap Nat Nat) := {}
  nd  : Bool := true

/-- The links of the elements of `L` whose identifier is `i`. -/
def linksOf (L : List WME) (i : Nat) : List Nat := (L.filter (·.id == i)).flatMap wmeLinks

/-- `x` describes `L`. -/
structure WIx.Ok (L : List WME) (x : WIx) : Prop where
  cnt : ∀ w, x.cnt.getD w 0 = L.count w
  nid : ∀ i, x.nid.getD i 0 = L.countP (·.id == i)
  lk  : ∀ i j, (x.lk.getD i {}).getD j 0 = (linksOf L i).count j
  nzN : NoZero x.nid
  nzL : LnkNoZero x.lk
  nd  : x.nd = true → L.Nodup

/-- Add an element. -/
def WIx.add (x : WIx) (w : WME) : WIx :=
  match x with
  | ⟨cnt, nid, lk, nd⟩ =>
    let fresh := cnt.getD w 0 == 0
    { cnt := cntInc cnt w, nid := cntInc nid w.id,
      lk := (wmeLinks w).foldl (fun m j => lnkInc m w.id j) lk,
      nd := nd && fresh }

/-- Remove an element. -/
def WIx.rem (x : WIx) (w : WME) : WIx :=
  match x with
  | ⟨cnt, nid, lk, nd⟩ =>
    { cnt := cntDec cnt w, nid := cntDec nid w.id,
      lk := (wmeLinks w).foldl (fun m j => lnkDec m w.id j) lk,
      nd := nd }

/-- The index of a list. -/
def WIx.build (L : List WME) : WIx := L.foldl WIx.add {}

theorem lk_fold_inc (i : Nat) : ∀ (ls : List Nat) (m : Std.HashMap Nat (Std.HashMap Nat Nat)) (a b : Nat),
    ((ls.foldl (fun m j => lnkInc m i j) m).getD a {}).getD b 0 =
      (m.getD a {}).getD b 0 + (if i == a then ls.count b else 0) := by
  intro ls
  induction ls with
  | nil => intro m a b; simp
  | cons j ls ih =>
    intro m a b
    rw [List.foldl_cons, ih, lnkInc_getD]
    by_cases h : i = a
    · subst h; by_cases hj : j = b
      · subst hj; simp [List.count_cons]; omega
      · have : (j == b) = false := by simpa using hj
        simp [List.count_cons, this]
    · have : (i == a) = false := by simpa using h
      simp [this]

theorem lk_fold_dec (i : Nat) : ∀ (ls : List Nat) (m : Std.HashMap Nat (Std.HashMap Nat Nat)) (a b : Nat),
    ((ls.foldl (fun m j => lnkDec m i j) m).getD a {}).getD b 0 =
      (m.getD a {}).getD b 0 - (if i == a then ls.count b else 0) := by
  intro ls
  induction ls with
  | nil => intro m a b; simp
  | cons j ls ih =>
    intro m a b
    rw [List.foldl_cons, ih, lnkDec_getD]
    by_cases h : i = a
    · subst h; by_cases hj : j = b
      · subst hj; simp [List.count_cons]; omega
      · have : (j == b) = false := by simpa using hj
        simp [List.count_cons, this]
    · have : (i == a) = false := by simpa using h
      simp [this]

theorem lk_fold_inc_nz (i : Nat) : ∀ (ls : List Nat) (m : Std.HashMap Nat (Std.HashMap Nat Nat)),
    LnkNoZero m → LnkNoZero (ls.foldl (fun m j => lnkInc m i j) m) := by
  intro ls; induction ls with
  | nil => intro m h; exact h
  | cons j ls ih => intro m h; exact ih _ (h.inc i j)

theorem lk_fold_dec_nz (i : Nat) : ∀ (ls : List Nat) (m : Std.HashMap Nat (Std.HashMap Nat Nat)),
    LnkNoZero m → LnkNoZero (ls.foldl (fun m j => lnkDec m i j) m) := by
  intro ls; induction ls with
  | nil => intro m h; exact h
  | cons j ls ih => intro m h; exact ih _ (h.dec i j)

theorem linksOf_cons (w : WME) (L : List WME) (i : Nat) :
    linksOf (w :: L) i = (if w.id == i then wmeLinks w else []) ++ linksOf L i := by
  unfold linksOf
  by_cases h : w.id == i
  · simp [List.filter_cons, h]
  · simp [List.filter_cons, h]

theorem WIx.Ok_add {L : List WME} {x : WIx} (h : WIx.Ok L x) (w : WME) : WIx.Ok (w :: L) (x.add w) where
  cnt := by
    intro a; simp only [WIx.add]; rw [cntInc_getD, h.cnt, List.count_cons]
  nid := by
    intro i; simp only [WIx.add]; rw [cntInc_getD, h.nid, List.countP_cons]
  lk := by
    intro a b; simp only [WIx.add]; rw [lk_fold_inc, h.lk, linksOf_cons]
    split <;> simp_all [List.count_append] <;> omega
  nzN := h.nzN.inc _
  nzL := lk_fold_inc_nz _ _ _ h.nzL
  nd := by
    intro hn
    simp only [WIx.add, Bool.and_eq_true, beq_iff_eq] at hn
    refine List.nodup_cons.mpr ⟨?_, h.nd hn.1⟩
    intro hw
    have := h.cnt w
    rw [hn.2] at this
    exact absurd (List.count_pos_iff.mpr hw) (by omega)

theorem WIx.Ok_rem {L : List WME} {x : WIx} (w : WME) (h : WIx.Ok (w :: L) x) : WIx.Ok L (x.rem w) where
  cnt := by
    intro a; simp only [WIx.rem]; rw [cntDec_getD, h.cnt, List.count_cons]; split <;> simp_all
  nid := by
    intro i; simp only [WIx.rem]; rw [cntDec_getD, h.nid, List.countP_cons]; split <;> simp_all
  lk := by
    intro a b; simp only [WIx.rem]; rw [lk_fold_dec, h.lk, linksOf_cons]
    split <;> simp_all [List.count_append]
  nzN := h.nzN.dec _
  nzL := lk_fold_dec_nz _ _ _ h.nzL
  nd := by
    intro hn
    exact (List.nodup_cons.mp (h.nd hn)).2

theorem WIx.Ok_perm {L L' : List WME} {x : WIx} (h : WIx.Ok L x) (hp : L.Perm L') : WIx.Ok L' x where
  cnt := by intro w; rw [h.cnt]; exact hp.count_eq w
  nid := by intro i; rw [h.nid]; exact hp.countP_eq _
  lk := by
    intro i j; rw [h.lk]; unfold linksOf
    exact ((hp.filter _).flatMap_right _).count_eq j
  nzN := h.nzN
  nzL := h.nzL
  nd := fun hn => (h.nd hn).perm hp

theorem WIx.Ok_empty : WIx.Ok [] ({} : WIx) where
  cnt := by intro w; simp
  nid := by intro i; simp
  lk := by intro i j; simp [linksOf]
  nzN := NoZero.empty
  nzL := LnkNoZero.empty
  nd := fun _ => List.nodup_nil

/-- Adding the elements of `N` one by one. -/
theorem WIx.Ok_addAll : ∀ (N : List WME) {L : List WME} {x : WIx}, WIx.Ok L x →
    WIx.Ok (N.reverse ++ L) (N.foldl WIx.add x)
  | [], _, _, h => by simpa using h
  | w :: N, _, _, h => by
    rw [List.foldl_cons, List.reverse_cons, List.append_assoc]
    exact WIx.Ok_addAll N (WIx.Ok_add h w)

/-- Removing the elements of `G` one by one. -/
theorem WIx.Ok_remAll : ∀ (G : List WME) {L : List WME} {x : WIx}, WIx.Ok (G ++ L) x →
    WIx.Ok L (G.foldl WIx.rem x)
  | [], _, _, h => by simpa using h
  | w :: G, _, _, h => by
    rw [List.foldl_cons]
    exact WIx.Ok_remAll G (WIx.Ok_rem w h)

theorem WIx.Ok_build (L : List WME) : WIx.Ok L (WIx.build L) := by
  unfold WIx.build
  have := WIx.Ok_addAll L WIx.Ok_empty
  simp only [List.append_nil] at this
  exact WIx.Ok_perm this (List.reverse_perm L)

/-- The identifiers `i` links to through the indexed elements. -/
def WIx.succ (x : WIx) (i : Nat) : List Nat := (x.lk.getD i {}).keys

theorem WIx.mem_succ {L : List WME} {x : WIx} (h : WIx.Ok L x) (i j : Nat) :
    j ∈ x.succ i ↔ ∃ w ∈ L, w.id = i ∧ j ∈ wmeLinks w := by
  unfold WIx.succ
  rw [Std.HashMap.mem_keys, (h.nzL i).mem_iff, h.lk, List.count_pos_iff]
  unfold linksOf
  rw [List.mem_flatMap]
  constructor
  · rintro ⟨w, hw, hj⟩
    rw [List.mem_filter] at hw
    exact ⟨w, hw.1, by simpa using hw.2, hj⟩
  · rintro ⟨w, hw, hi, hj⟩
    exact ⟨w, List.mem_filter.mpr ⟨hw, by simpa using hi⟩, hj⟩

/-- The identifiers of the indexed elements. -/
theorem WIx.mem_ids {L : List WME} {x : WIx} (h : WIx.Ok L x) (i : Nat) :
    i ∈ x.nid.keys ↔ ∃ w ∈ L, w.id = i := by
  rw [Std.HashMap.mem_keys, h.nzN.mem_iff, h.nid, List.countP_pos_iff]
  simp

end Soar
