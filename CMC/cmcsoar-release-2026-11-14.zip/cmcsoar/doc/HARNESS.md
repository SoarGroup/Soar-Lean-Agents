# Comparison harness: versions and run times

## Versions

| Component | Version |
| --- | --- |
| Lean | 4.35.0 (`lean-toolchain`), core library only |
| Soar (reference) | 9.6.6, SoarSuite_9.6.6-bigbugfixrelease (kernel version 9.6.50), through its own Python bindings (`tools/soar966`); source: SoarGroup/Soar branch `fix/lean4-kernel-defects` (fix commits 18b84ba22, 70de740c3, 1d3f71063, 2d5bf6bdc, eb8dcb442 on base 94a15d6d5) |
| Soar (earlier reference) | 9.6.5, the Python bindings `soar-sml==9.6.5` from PyPI, tag `releases/9.6.5` (commit d726fbc); docstrings cite its source where 9.6.6 did not change it, and record its behaviour where 9.6.6 fixed a defect |
| Python | 3.13 |
| Report builder | Node.js with the `docx` package (`doc/build_soar.js`); LibreOffice for the PDF |

## How a comparison runs

`tools/diff.py DIR OPTIONS` loads each `.soar` file in DIR into a Soar 9.6.6 kernel through
soar_sml and runs it for the number of decisions in the matching `.n` file, with
`decide indifferent-selection --first` and `srand 0` (RL sets: epsilon-greedy, epsilon 0.3,
seed 42). It records the decision trace and the final working memory, and as the options ask,
learned rules, RL values, the semantic store and every episode. It then runs `soar-lean` on the
same file with the same settings and compares, with identifiers, LTIs and episode nodes matched
up to renaming. With `--replay` (and RL sets by default) the model follows Soar's choices among
indifferent operators, recorded as a `.hints` file; with `--exe` or `--noreplay` it makes its
own. Each program prints one line, `== name MATCH (…)` or `== name DIFF (…)` with the first
differences.

**Two runs.** When `X.pre.soar` (with `X.pre.n`) exists beside `X.soar`, the files named by
`--set path` and `--backup` in either program are deleted, `X.pre.soar` runs in an agent of its
own that is then destroyed (Soar commits and closes its databases then), and `X.soar` runs in a
new agent that opens the file the first left. soar-lean does the same with two runs whose stores
are kept in `DIR/.lean-db` (`--db-dir`). `tests/dbfile` uses this for the memory databases on
disk.

## Run times

Measured on October 31, 2026, on a two-core cloud machine with 7 GB of memory, three groups in
parallel (`tools/run_all.sh` groups; wall-clock minutes, including Soar's own runs):

| Group | Sets | Minutes |
| --- | --- | --- |
| A | decision cycle, real agents, RL (with replay) | 2 |
| E | input, RL variants, LTI, exploration, function library, settings, parser; the sets again without replay | 3 |
| B | semantic memory | 5 |
| D | chunking (chunkdemo about 3.5) | 4 |
| W | working-memory activation, spreading activation | 7 |
| C | episodic memory (epfuzz about 10, epfuzz2 about 26) | 37 |
| All, three in parallel | | about 45 |

Building: `lake build` about 2 minutes from scratch, `lake build soar-lean` about 1 more.
Timings of individual agents against the C++ kernel are in the report, Appendix E.

## Known quirks

- Soar 9.6.5's Towers of Hanoi test agent (tests/real) exhausts memory after decision 32 (kernel
  defect 1, fixed in 9.6.6); it is still run for 31 decisions.
- A few programs depend on heap addresses in Soar (SVS rank ties); those are listed in
  doc/DIFFERENCES.md and match or not from run to run.
- Programs that read stdin (`(accept)`, tests/rhslib/accept.soar) wait for input when the
  harness's standard input is a terminal or an open pipe: run the harness with `</dev/null`.
- Generated sets (tools/gen_*.py) take a random seed; the
  programs in tests/ are the generated files themselves, so regenerating is not needed to rerun.

## Choosing the Soar release

The tools import `tools/soarsel.py` before `soar_sml`. By default it puts `tools/soar966` first
on the path, whose `soar_sml` loads the Python bindings in `$SOAR966`, the `bin/<platform>`
directory of the Soar 9.6.6 suite:

    SOAR966=<SoarSuite_9.6.6>/bin/linux_x86-64 tools/run_all.sh results.txt

With `SOAR_VERSION=9.6.5` the PyPI package `soar-sml==9.6.5` is used instead. The model follows
9.6.6, so against 9.6.5 the programs that show the defects 9.6.6 fixed differ. (Before the model
was moved to 9.6.6 on November 14, 5,429 of the 5,850 programs then in the regression matched
9.6.6; after, all but six of 5,857.)
