# A reactive environment: it makes the scene, then moves ball1 to the x the agent writes on
# its output link (^goto X).
def step(k, output):
    out = []
    if k == 1:
        out += ["svs add box1 world v -1 -1 -1 1 -1 -1 -1 1 -1 1 1 -1 -1 -1 1 1 -1 1 -1 1 1 1 1 1", "svs add ball1 world b 0.5 p 6 0 0"]
    for (i, a, v) in output:
        if a == "goto":
            out.append(f"svs change ball1 p {v} 0 0")
    return out
