"""Load a Soar agent (following `source` commands) into Soar 9.6.5 and print every production
in Soar's canonical form, as one flat file."""
import os as _os, sys as _sys; _sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__))); import soarsel  # Soar 9.6.6 unless SOAR_VERSION=9.6.5
import soar_sml as sml, sys, os
src, out = sys.argv[1], sys.argv[2]
k = sml.Kernel.CreateKernelInCurrentThread(True, 0)
a = k.CreateAgent("flat")
d, f = os.path.split(os.path.abspath(src))
a.ExecuteCommandLine(f"cd {d}")
r = a.ExecuteCommandLine(f"source {f}")
text = a.ExecuteCommandLine("print --full")
open(out, "w").write(text)
print(f"{text.count('sp {')} productions", "| source said:", r.strip().splitlines()[-1] if r.strip() else "")
