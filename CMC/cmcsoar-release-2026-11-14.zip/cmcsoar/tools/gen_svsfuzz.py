"""Random SVS agents (tests/svsfuzz): an SGEL scene, commands that change it at random steps,
and extract commands of random filter trees, some persistent and some present only for a
range of steps; some agents make substates that give commands of their own.
Usage: python3 tools/gen_svsfuzz.py OUTDIR N [SEED]"""
import random, sys, os

out, N = sys.argv[1], int(sys.argv[2])
rnd = random.Random(int(sys.argv[3]) if len(sys.argv) > 3 else 7)
os.makedirs(out, exist_ok=True)

BOX = "v -1 -1 -1 1 -1 -1 -1 1 -1 1 1 -1 -1 -1 1 1 -1 1 -1 1 1 1 1 1"
def num(a=-2, b=2):
    x = rnd.uniform(a, b)
    return f"{x:.2f}" if rnd.random() < 0.8 else str(rnd.randint(int(a), int(b)))
def vec(a=-2, b=2): return f"{num(a,b)} {num(a,b)} {num(a,b)}"

def scene():
    names, groups, lines, tags = [], ["world"], [], []
    for i in range(rnd.randint(3, 7)):
        nm = f"n{i}"
        par = rnd.choice(groups)
        k = rnd.random()
        geo = "" if k < 0.25 else (BOX if k < 0.5 else (f"b {num(0.2,1.5)}" if k < 0.8 else "v 0 0 0"))
        mods = f"p {vec()}"
        if rnd.random() < 0.5: mods += f" r {vec(-3,3)}"
        if rnd.random() < 0.5: mods += f" s {vec(0.2,2)}"
        lines.append(f"svs S1.scene.sgel add {nm} {par} {geo} {mods}")
        if geo == "": groups.append(nm)
        names.append(nm)
        if rnd.random() < 0.5:
            lines.append(f"svs S1.scene.sgel tag add {nm} color {rnd.choice(['red','blue'])}")
    return names, lines

def node_in(names, d=0):
    k = rnd.random()
    if k < 0.35 or d > 1: return f"(<X> ^type node ^id {rnd.choice(names + ['ghost'])})"
    if k < 0.6: return "(<X> ^type all_nodes)"
    if k < 0.75: return f"(<X> ^type tag_select ^a <Xa> ^tag_name color ^tag_value {rnd.choice(['red','blue'])}) (<Xa> ^type all_nodes)"
    if k < 0.85: return f"(<X> ^type remove_node ^a <Xa> ^id {rnd.choice(names)}) (<Xa> ^type all_nodes)"
    return f"(<X> ^type combine_nodes ^a <Xa> ^b <Xb>) " + node_in(names, d+1).replace("<X", "<Xa") + " " + node_in(names, d+1).replace("<X", "<Xb")

FILTERS = [("distance", "ab", ["^distance_type hull", "^distance_type centroid", ""]),
           ("distance_select", "ab", ["^min 0.5 ^max 3", "^distance_type hull ^max 1"]),
           ("closest", "ab", ["", "^distance_type hull"]), ("farthest", "ab", [""]),
           ("volume", "a", ["", "^volume_type scale"]), ("volume_select", "a", ["^min 1", "^max 2 ^include_max false"]),
           ("largest", "a", [""]), ("smallest", "a", [""]), ("larger", "ab", [""]), ("smaller_select", "ab", [""]),
           ("axis_distance", "ab", ["^axis x", "^axis z", "^axis 1"]), ("axis_distance_select", "ab", ["^axis y ^min 0 ^max 0"]),
           ("intersect", "ab", ["^intersect_type hull", ""]), ("intersect_select", "ab", ["^intersect_type hull", ""]),
           ("contain", "ab", [""]), ("contain_select", "ab", [""]),
           ("node_position", "a", [""]), ("node_rotation", "a", [""]), ("node_scale", "a", [""]), ("node_bbox", "a", [""]),
           ("tag_select", "a", ["^tag_name color ^tag_value red"]),
           ("monitor_position", "a", [""]), ("monitor_volume", "a", [""]),
           ("axis_relation_select", "ab", ["^axis x ^greater true ^top 5", "^axis y ^less true ^aligned true ^top 3 ^bottom 0.1"]),
           ("calculate_placement", "ab", ["^x_axis_separation 0.5", "^z_axis_separation -0.3 ^y_axis_separation 0.2"])]

def extract(names, k):
    f, ps, opts = rnd.choice(FILTERS)
    e = f"<e{k}>"
    body = f"({e} ^type {f} {rnd.choice(opts)}"
    subs = []
    for p in ps:
        v = f"e{k}{p}"
        body += f" ^{p} <{v}>"
        subs.append(node_in(names).replace("X", v))
    body += ")"
    return e, body + " " + " ".join(subs)

def command(names, k):
    c = f"<c{k}>"
    t = rnd.random()
    nm = rnd.choice(names + ["ghost", f"new{k}"])
    if t < 0.2:
        par = rnd.choice(["world", "world"] + names)
        geo = rnd.choice(["box", "sphere", "point", "group", ""])
        g = f" ^geometry {geo}" if geo else ""
        tg = f" ^tags <t{k}>) (<t{k}> ^color {rnd.choice(['red','blue'])}" if rnd.random() < 0.4 else ""
        return "add_node", f"({c} ^id new{k} ^parent {par}{g} ^position <p{k}>{tg}) (<p{k}> ^x {num()} ^y {num()} ^z {num()})"
    if t < 0.35: return "delete_node", f"({c} ^id {nm})"
    if t < 0.55:
        what = rnd.choice(["position", "rotation", "scale"])
        return "set_transform", f"({c} ^id {nm} ^{what} <p{k}>) (<p{k}> ^x {num(0.2,2)} ^y {num(0.2,2)} ^z {num(0.2,2)})"
    if t < 0.7: return "set_tag", f"({c} ^id {nm} ^tag_name color ^tag_value {rnd.choice(['red','blue'])})"
    if t < 0.78: return "delete_tag", f"({c} ^id {nm} ^tag_name color)"
    if t < 0.9:
        return "copy_node", f"({c} ^id copy{k} ^source {rnd.choice(names)} ^copy_tags {rnd.choice(['true','false'])})"
    return "copy_transform", f"({c} ^source {rnd.choice(names)} ^destination {rnd.choice(names)} ^position yes ^rotation true)"

for i in range(N):
    names, sg = scene()
    steps = rnd.randint(6, 12)
    L = ["svs --enable"] + sg
    L += ["sp {propose*init (state <s> ^superstate nil -^step) --> (<s> ^operator <o> + =) (<o> ^name init)}",
          "sp {apply*init (state <s> ^operator.name init) --> (<s> ^step 0)}",
          f"sp {{propose*tick (state <s> ^superstate nil ^step {{<n> < {steps}}}) --> (<s> ^operator <o> + =) (<o> ^name tick)}}",
          "sp {apply*tick (state <s> ^operator.name tick ^step <n>) --> (<s> ^step <n> - ^step (+ <n> 1))}"]
    sub = rnd.random() < 0.35
    if sub:
        # at one step the tick operator has no application: a substate gives commands, then ticks
        st = rnd.randint(1, steps - 2)
        L[-1] = f"sp {{apply*tick (state <s> ^operator.name tick ^step {{<n> <> {st}}}) --> (<s> ^step <n> - ^step (+ <n> 1))}}"
        L.append(f"sp {{sub*propose (state <s> ^superstate <ss>) (<ss> ^operator.name tick ^step {st}) --> (<s> ^operator <o> + =) (<o> ^name subtick)}}")
        L.append(f"sp {{sub*apply (state <s> ^operator.name subtick ^superstate <ss>) (<ss> ^step <n>) --> (<ss> ^step <n> - ^step (+ <n> 1))}}")
        acts, binds = [], []
        for k in range(rnd.randint(1, 3)):
            a, b = command(names, 100 + k); acts.append(f"^{a} <c{100+k}>"); binds.append(b)
        for k in range(rnd.randint(1, 2)):
            e, b = extract(names, 100 + k); acts.append(f"^extract {e}"); binds.append(b)
        L.append(f"sp {{sub*cmds (state <s> ^superstate.operator.name tick ^svs.command <c>) --> (<c> {' '.join(acts)}) {' '.join(binds)}}}")
    for k in range(rnd.randint(2, 6)):
        e, b = extract(names, k)
        kind = rnd.choice(["extract", "extract", "extract_once"])
        if rnd.random() < 0.6:
            L.append(f"sp {{ext{k} (state <s> ^superstate nil ^svs.command <c>) --> (<c> ^{kind} {e}) {b}}}")
        else:
            lo = rnd.randint(0, steps - 1); hi = rnd.randint(lo, steps)
            L.append(f"sp {{ext{k} (state <s> ^superstate nil ^step {{>= {lo} <= {hi}}} ^svs.command <c>) --> (<c> ^{kind} {e}) {b}}}")
    for k in range(rnd.randint(2, 6)):
        s = rnd.randint(1, steps)
        a, b = command(names, k)
        L.append(f"sp {{cmd{k} (state <s> ^superstate nil ^step {s} ^svs.command <c>) --> (<c> ^{a} <c{k}>) {b}}}")
    name = f"s{i:03d}"
    open(os.path.join(out, name + ".soar"), "w").write("\n".join(L) + "\n")
    open(os.path.join(out, name + ".n"), "w").write(str(rnd.randint(2, steps + 3)) + "\n")
