#!/usr/bin/env python3
"""Bring doc/Soar-Lean-map.xlsx up to date with the Lean sources and the Soar 9.6.6 source.

Usage: python3 tools/map_update.py SOAR_SRC [MAP.xlsx]
  SOAR_SRC: a Soar checkout at the 9.6.6 release (its Core/ directory is read).

What it does, keeping every review already made:
  * re-extracts the documented definitions (Definitions sheet) and undocumented helpers
    (Helpers sheet) from the Lean files, with file, line, kind, section, first sentence of the
    docstring, Soar functions named in the docstring, manual sections, SIMPLIFIED / NOT
    FORMALIZED notes and the theorems whose statements mention the definition;
  * finds each Soar function's definition in the 9.6.6 source (paths relative to
    Core/SoarKernel/src, or starting Core/SVS/ for SVS);
  * keeps the area, mapping source, related findings, review status, reviewer notes and
    fixing program of each definition already in the map (matched by file and name, or by name
    alone when it moved file);
  * gives new definitions the review status "Not reviewed" (execution-only definitions, which
    are proved equal to the specification, "Not applicable"), and says in column T what changed
    since the October 31 review;
  * lists definitions no longer in the sources on a sheet "Removed since review".
The other sheets are kept; the Summary formulas are re-pointed at the new row count.
"""
import os, re, sys, glob, collections, datetime
import openpyxl
from openpyxl.styles import PatternFill, Font, Alignment
from copy import copy

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SOAR = sys.argv[1]
MAP = sys.argv[2] if len(sys.argv) > 2 else os.path.join(ROOT, 'doc', 'Soar-Lean-map.xlsx')

FILES = (['CMC/Proc.lean'] +
         sorted(os.path.relpath(f, ROOT) for f in glob.glob(os.path.join(ROOT, 'Soar', '**', '*.lean'), recursive=True)))

# ---------------------------------------------------------------- Soar function index
KERNEL = os.path.join(SOAR, 'Core', 'SoarKernel', 'src')
SVSDIR = os.path.join(SOAR, 'Core', 'SVS')
DEF_RE = re.compile(r'^[A-Za-z_][\w:<>,\*&\s]*?\b((?:[A-Za-z_]\w*::)*~?[A-Za-z_]\w*)\s*\([^;]*$')
func_index = collections.defaultdict(list)

def index_dir(base, label):
    for f in glob.glob(os.path.join(base, '**', '*.*'), recursive=True):
        if not f.endswith(('.cpp', '.h', '.c', '.hpp')):
            continue
        rel = os.path.relpath(f, base) if label is None else label + '/' + os.path.relpath(f, base)
        try:
            lines = open(f, errors='replace').read().split('\n')
        except Exception:
            continue
        for i, line in enumerate(lines, 1):
            if not line or line[0] in ' \t#/{}' or line.rstrip().endswith(';'):
                continue
            m = DEF_RE.match(line)
            if not m:
                continue
            name = m.group(1)
            if name in ('if', 'while', 'for', 'switch', 'return', 'sizeof'):
                continue
            loc = f'{rel}:{i}'
            func_index[name].append(loc)
            if '::' in name:
                func_index[name.split('::')[-1]].append(loc)

index_dir(KERNEL, None)
index_dir(SVSDIR, 'Core/SVS')

# names cited in the map that are not functions (fields, types, timers) or not in Soar 9.6.6
EXTRA_LOC = {
    'Symbol_Manager::make_str_constant': 'soar_representation/symbol_manager.cpp:512',
    'preferences_from_goal': 'field of iddata, soar_representation/symbol.h:187',
    'wma_o_set': 'field of preference, soar_representation/preference.h:149',
    'rl_rho': 'field of preference, soar_representation/preference.h:147',
    'FIRING_TYPE': 'field of agent, soar_representation/agent.h:434',
    'wma_d_cycle': 'type, soar_representation/working_memory_activation.h:155',
    'wma_forgetting': 'parameter forgetting, soar_representation/working_memory_activation.h:71',
    'wma_activation_predicate': 'soar_representation/working_memory_activation.cpp:99',
    'build_chunk_or_justification': 'no function of this name in Soar 9.6.6 (chunk building is in explanation_based_chunking/ebc_build.cpp)',
}

def locate(fn):
    fn = fn.split(' (')[0]
    if fn in EXTRA_LOC:
        return EXTRA_LOC[fn]
    locs = func_index.get(fn, [])
    cpp = [l for l in locs if '.cpp:' in l or '.c:' in l]
    return (cpp or locs or [None])[0]

def soar_functions(doc):
    cands = re.findall(r'(?:[A-Za-z_]\w*::)*[A-Za-z_]\w*', doc)
    out = []
    for c in cands:
        if ('_' in c or '::' in c) and c in func_index and c not in out and len(c) > 3:
            out.append(c)
    return out

# ---------------------------------------------------------------- Lean extraction
DECL_RE = re.compile(r'^(?:@\[[^\]]*\]\s*)*(?:private |protected |noncomputable |partial |unsafe )*'
                     r'(def|structure|inductive|abbrev|class|instance)\s+([^\s:({\[]+)?')
THM_RE = re.compile(r'^(?:@\[[^\]]*\]\s*)*(?:private |protected )*theorem\s+(\S+)')

def first_sentence(doc):
    d = ' '.join(doc.split())
    m = re.search(r'(.+?[.!?])(\s|$)', d)
    return (m.group(1) if m else d)[:400]

def notes_of(doc):
    d = ' '.join(doc.split())
    out = []
    for m in re.finditer(r'(SIMPLIFIED|NOT FORMALIZED|NOT MODELED)[^.]*\.', d):
        out.append(m.group(0))
    return ' '.join(out)

defs, helpers, theorems = [], [], []
for rel in FILES:
    text = open(os.path.join(ROOT, rel)).read()
    lines = text.split('\n')
    section = None
    doc_lines, in_doc, pending_doc = [], False, None
    scopes = []   # ('ns', name) or ('sec', name); the root namespace Soar is not part of the map's names
    i = 0
    while i < len(lines):
        line = lines[i]
        st = line.strip()
        if st.startswith('/-!'):
            m = re.match(r'/-!\s*#+\s*(.+?)(\s*-/)?$', st)
            if m:
                section = m.group(1).strip()
            else:
                # header on the next line
                if i + 1 < len(lines):
                    m2 = re.match(r'#+\s*(.+)', lines[i + 1].strip())
                    if m2:
                        section = m2.group(1).strip()
            pending_doc = None
            while '-/' not in lines[i]:
                i += 1
            i += 1
            continue
        if st.startswith('/--'):
            buf = [st[3:]]
            while '-/' not in lines[i]:
                i += 1
                buf.append(lines[i].strip())
            pending_doc = ' '.join(buf).replace('-/', '').strip()
            i += 1
            continue
        nm = re.match(r'^namespace\s+(\S+)', line)
        if nm:
            n = nm.group(1)
            n = '' if n == 'Soar' else (n[5:] if n.startswith('Soar.') else n)
            scopes.append(('ns', n))
            pending_doc = None
            i += 1
            continue
        if re.match(r'^mutual\b', line):
            scopes.append(('mutual', ''))
            i += 1
            continue
        sm = re.match(r'^(?:noncomputable )?section\b\s*(\S*)', line)
        if sm:
            scopes.append(('sec', sm.group(1)))
            i += 1
            continue
        if re.match(r'^end\b', line) and scopes:
            scopes.pop()
            pending_doc = None
            i += 1
            continue
        tm = THM_RE.match(line)
        if tm:
            stmt = [line]
            j = i
            while j + 1 < len(lines) and ":=" not in lines[j] and j < i + 40:
                j += 1
                stmt.append(lines[j])
            theorems.append((tm.group(1), ' '.join(stmt).split(':=')[0]))
            pending_doc = None
            i += 1
            continue
        dm = DECL_RE.match(line)
        if dm and dm.group(2) and dm.group(1) != 'instance':
            kind, name = dm.group(1), dm.group(2)
            prefix = '.'.join(n for k, n in scopes if k == 'ns' and n)
            if prefix and not name.startswith('_root_.'):
                name = prefix + '.' + name
            name = name.replace('_root_.', '')
            rec = dict(file=rel, line=i + 1, kind=kind, name=name, bare=dm.group(2).replace('_root_.', ''),
                       section=section, doc=pending_doc)
            (defs if pending_doc else helpers).append(rec)
        if st and not st.startswith('--') and not st.startswith('@['):
            pending_doc = None
        i += 1

thm_by_def = collections.defaultdict(list)
for tname, stmt in theorems:
    for d in defs:
        n = d['name']
        short = n.split('.')[-1]
        if re.search(r'(?<![\w.])' + re.escape(n) + r'(?![\w])', stmt) or \
           ('.' in n and re.search(r'\.' + re.escape(short) + r'(?![\w])', stmt) and len(short) > 3):
            if tname not in thm_by_def[(d['file'], n)]:
                thm_by_def[(d['file'], n)].append(tname)

# ---------------------------------------------------------------- the existing map
wb = openpyxl.load_workbook(MAP)
ws = wb['Definitions']
hdr = [c.value for c in ws[1]]
old = []
for r in ws.iter_rows(min_row=2, values_only=True):
    if r[0]:
        old.append(dict(zip(range(len(r)), r)))
by_fn = {(o[2], o[5]): o for o in old}
by_name = collections.defaultdict(list)
shared = set()   # rows that name several definitions ("Store.putSMem, getSMem, putEp, getEp")
for o in old:
    by_name[o[5]].append(o)
    if ', ' in (o[5] or ''):
        parts = o[5].split(', ')
        pre = parts[0].rsplit('.', 1)[0] + '.' if '.' in parts[0] else ''
        for k, q in enumerate(parts):
            n = q if k == 0 or not pre else pre + q
            by_name[n].append(o)
            by_fn[(o[2], n)] = o
        shared.add(id(o))

area_by_sec = collections.defaultdict(collections.Counter)
area_by_file = collections.defaultdict(collections.Counter)
tests_by_area = {}
for o in old:
    area_by_sec[(o[2], o[1])][o[0]] += 1
    area_by_file[o[2]][o[0]] += 1
    tests_by_area.setdefault(o[0], o[14])

def area_of(d):
    if d['file'].startswith('Soar/SVS/'):
        return 'Spatial visual system'
    c = area_by_sec.get((d['file'], d['section'])) or area_by_file.get(d['file'])
    if c:
        return c.most_common(1)[0][0]
    return {'Soar/WmIx.lean': 'Decision cycle', 'Soar/Graph.lean': 'Decision cycle'}.get(d['file'], 'Decision cycle')

tests_by_area['Spatial visual system'] = 'svs, svsgen, svsfuzz, svschunk, svsenv'

# programs found to fix differences the map did not record (checked November 14: each is in
# tests/mapdiff, names the definition and matches Soar 9.6.6 in the full regression, group E)
FIXED_LINKS = {
    'costPos': 'exe/costpos-novalue.soar; exe/costpos-order.soar',
    'soarCondOrder': 'exe/costpos-novalue.soar; exe/restore-nonequality-rel.soar',
    'St.wm': 'exe/dc1_attrlink.soar',
    'St.gc': 'exe/dc1_attrlink.soar',
    'St.removeGoalsFrom': 'rl/dc1_rlretract.soar',
    'St.makeResults': 'chunk/dc2_result_smemlink.soar; chunk/dc2_result_noconds.soar',
    'St.wmPhase': 'exe/dc2_gds_second_osup.soar',
    'St.deepCopy': 'exe/deepcopy_state.soar; exe/deepcopy_io.soar; exe/deepcopy_top.soar; exe/deepcopy_idattr.soar',
    'St.resultsAbove': 'chunk/dc2_bottomup_results.soar',
    'spreadPrep': 'smem/smem_bigspread.soar',
    'cliRemove': 'smem/smem_cliremove_unknown_attr.soar',
    'cliQuery': 'smem/smem_cliquery_badlti.soar',
    'reteConds': 'exe/dc3_reteconds_neg.soar',
    'St.reteMatchOf': 'exe/retematch-novalue.soar',
    'St.reteCache': 'exe/retematch-novalue.soar',
}

def is_exec_only(d):
    doc = d['doc'] or ''
    return doc.startswith('Execution only') or re.search(r'(Fast|X)$', d['name'].split('.')[-1]) is not None \
        and 'Execution only' in doc

# definitions reviewed on October 31 that have no docstring now stay in Definitions with their reviews
def_keys = {(d['file'], d['name']) for d in defs}
def_names = {d['name'] for d in defs}
promoted = []
# definitions renamed since the review: current name -> name in the October 31 map
RENAMED = {'STest.eqVars': 'STest.binds', 'STest.useVars': 'STest.uses'}

def old_match(d, used):
    if d['name'] in RENAMED:
        c = [o for o in by_name.get(RENAMED[d['name']], []) if id(o) not in used]
        if len(c) == 1:
            return c[0], c[0][2]
    for key in (d['name'], d['bare']):
        o = by_fn.get((d['file'], key))
        if o is not None and (id(o) not in used or id(o) in shared):
            return o, None
    # moved to another file: only under the same full name
    c = [o for o in by_name.get(d['name'], []) if id(o) not in used or id(o) in shared]
    if len(c) == 1:
        return c[0], c[0][2]
    return None, None

for h in helpers:
    o, _ = old_match(h, set())
    if o is not None and o[2] == h['file'] or (o is not None and h['name'] not in def_names):
        h['undocumented'] = True
        promoted.append(h)
helpers = [h for h in helpers if not h.get('undocumented')]
defs = defs + promoted
for d in promoted:
    d['doc'] = d['doc'] or ''
thm_extra = collections.defaultdict(list)
for tname, stmt in theorems:
    for d in promoted:
        n = d['name']
        if re.search(r'(?<![\w.])' + re.escape(n) + r'(?![\w])', stmt) and tname not in thm_by_def[(d['file'], n)]:
            thm_by_def[(d['file'], n)].append(tname)

def is_proof_only(d):
    f = d['file']
    return f.endswith('Props.lean') or f in ('Soar/JoinOrderSem.lean', 'Soar/OrderSafe.lean')

rows, used = [], set()
for d in defs:
    o, moved = old_match(d, used)
    if moved == d['file']:
        moved = None
    renamed = RENAMED.get(d['name']) if o is not None and o[5] == RENAMED.get(d['name']) else None
    if o is not None:
        used.add(id(o))
    doc = d['doc'] or ''
    fns = soar_functions(doc)
    src = 'cited in the code' if fns else None
    if o is not None and o[9] and 'added for this map' in o[9]:
        for f in (o[7] or '').split('; '):
            if f and f not in fns:
                fns.append(f)
        src = 'cited in the code; added for this map' if src else 'added for this map'
    locs = [locate(f) for f in fns]
    note = notes_of(doc)
    manual = '; '.join(dict.fromkeys(re.findall(r'§\s?\d+(?:\.\d+)*', doc))) or None
    if fns:
        corr = 'Models the Soar code listed'
        if 'SIMPLIFIED' in note:
            corr += ', simplified'
        elif 'NOT FORMALIZED' in note or 'NOT MODELED' in note:
            corr += ', in part'
    elif manual:
        corr = 'Follows the manual (no Soar function cited)'
        if 'SIMPLIFIED' in note:
            corr += ', simplified'
        elif 'NOT FORMALIZED' in note or 'NOT MODELED' in note:
            corr += ', in part'
    else:
        corr = 'Model structure or helper' + (', with a noted difference' if note else ' (documented)')
    since = [x for x in ((o.get(19) or '').split('; ') if o is not None else []) if x]   # kept from an earlier run
    if o is None:
        since.append('added (execution only)' if is_exec_only(d) else
                     'added (proof only)' if is_proof_only(d) else 'added')
    def note_since(x):
        if x not in since:
            since.append(x)
    if renamed:
        note_since(f'renamed from {renamed}')
    if moved:
        note_since(f'moved from {moved}')
    if d.get('undocumented') and not any(x.startswith('added') for x in since):
        note_since('docstring missing in the current sources (reviewed definition kept)')
    if '9.6.6' in doc:
        note_since('changed for Soar 9.6.6: review notes describe 9.6.5')
    area = o[0] if o is not None else area_of(d)
    if o is not None:
        status, rnotes, fixed, findings = o[16], o[17], o[18], o[15]
    elif is_exec_only(d):
        status, rnotes, fixed, findings = ('Not applicable',
            'Execution only: proved equal to the specification (a csimp lemma); nothing in Soar to compare.', None, None)
    elif is_proof_only(d):
        status, rnotes, fixed, findings = ('Not applicable',
            'Proof only: used to state or prove theorems, not run; nothing in Soar to compare.', None, None)
    else:
        status, rnotes, fixed, findings = 'Not reviewed', None, None, None
    fl = FIXED_LINKS.get(d['name']) or FIXED_LINKS.get(d['bare'])
    if fl and status == 'Differs' and not fixed:
        fixed = fl
        note_since('fixing program linked (Nov 14)')
    rows.append([area, d['section'], d['file'], d['line'], d['kind'], d['name'], first_sentence(doc),
                 '; '.join(fns) or None, '; '.join(l or '(not found)' for l in locs) or None, src, corr,
                 note or None, manual, ', '.join(thm_by_def.get((d['file'], d['name']), [])) or None,
                 tests_by_area.get(area, 'test, real'), findings, status, rnotes, fixed,
                 '; '.join(since) or None])

removed = [o for o in old if id(o) not in used]

# ---------------------------------------------------------------- write
AREAS = ['CMC with expanded procedural module', 'Working memory and production language', 'Right-hand side',
         'Matching and condition ordering', 'Preference semantics', 'Decision cycle',
         'Chunking (learning computation)', 'Semantic memory store', 'Episodic memory store',
         'Working-memory activation', 'Parser', 'Soar as a CMC instance', 'Exploration and random numbers',
         'Spatial visual system']
order = {a: i for i, a in enumerate(AREAS)}
rows.sort(key=lambda r: (order.get(r[0], 99), r[2], r[3]))

hdr_style = [copy(c._style) for c in ws[1]]
body_style = [copy(c._style) for c in ws[2]]
widths = {c.column_letter: ws.column_dimensions[c.column_letter].width for c in ws[1]}
new_hdr = list(hdr)
new_hdr[7] = 'Soar function(s)'
new_hdr[8] = 'Soar 9.6.6 source location(s)'
new_hdr[18] = 'Fixed by (program in tests/mapdiff)'
new_hdr = new_hdr[:19] + ['Since the review (November 14, 2026)']
ws.delete_rows(1, ws.max_row)
ws.append(new_hdr)
for r in rows:
    ws.append(r)
for j, c in enumerate(ws[1]):
    c._style = copy(hdr_style[min(j, len(hdr_style) - 1)])
yellow = PatternFill('solid', fgColor='FFF2CC')
for row in ws.iter_rows(min_row=2, max_row=ws.max_row):
    for j, c in enumerate(row):
        c._style = copy(body_style[min(j, len(body_style) - 1)])
        if j in (16, 17):
            c.fill = yellow
for k, v in widths.items():
    ws.column_dimensions[k].width = v
ws.column_dimensions['T'].width = 34
n = ws.max_row
ws.freeze_panes = 'C2'
ws.auto_filter.ref = f'A1:T{n}'

# helpers
wh = wb['Helpers']
hs = [copy(c._style) for c in wh[1]]
bs = [copy(c._style) for c in wh[2]]
wh.delete_rows(1, wh.max_row)
wh.append(['Area', 'Section', 'Lean file', 'Line', 'Kind', 'Lean definition'])
for h in sorted(helpers, key=lambda h: (order.get(area_of(h), 99), h['file'], h['line'])):
    wh.append([area_of(h), h['section'], h['file'], h['line'], h['kind'], h['name']])
for j, c in enumerate(wh[1]):
    c._style = copy(hs[j])
for row in wh.iter_rows(min_row=2, max_row=wh.max_row):
    for j, c in enumerate(row):
        c._style = copy(bs[j])
nh = wh.max_row

# removed
earlier_removed = []
if 'Removed since review' in wb.sheetnames:
    names_now = {r[5] for r in rows}
    earlier_removed = [r for r in wb['Removed since review'].iter_rows(min_row=2, values_only=True)
                       if r[2] and r[2] not in names_now and r[2] not in {o[5] for o in removed}]
    del wb['Removed since review']
wr = wb.create_sheet('Removed since review', index=wb.sheetnames.index('Helpers') + 1)
wr.append(['Area', 'Lean file (October 31)', 'Lean definition', 'Review status', 'Reviewer notes',
           'Fixed by (program in tests/mapdiff)'])
for r in earlier_removed:
    wr.append(list(r))
for o in removed:
    if o.get(19) and str(o[19]).startswith('added'):
        continue   # added after the review and gone again: nothing reviewed to keep
    wr.append([o[0], o[2], o[5], o[16], o[17], o[18] or FIXED_LINKS.get(o[5])])
for c in wr[1]:
    c.font = Font(bold=True)
for k, w in zip('ABCDEF', (30, 24, 30, 14, 80, 40)):
    wr.column_dimensions[k].width = w

# summary: one row per area, formulas over the new range
s = wb['Summary']
tmpl = [[c.value for c in row] for row in s.iter_rows(min_row=1, max_row=s.max_row)]
area_tmpl = tmpl[1]
def fix(v, r_old, r_new):
    if isinstance(v, str):
        v = re.sub(r'Definitions!\$([A-Z])\$2:\$\1\$\d+', lambda m: f'Definitions!${m.group(1)}$2:${m.group(1)}${n}', v)
        v = re.sub(r'Helpers!F2:F\d+', f'Helpers!F2:F{nh}', v)
        v = re.sub(r'\$A' + str(r_old) + r'\b', f'$A{r_new}', v)
    return v
EXTRA = ('Not reviewed (new since October 31)', 'Changed for Soar 9.6.6 since the review')
tot = next(i for i, r in enumerate(tmpl) if r[0] == 'All areas')
trailer = [r for r in tmpl[tot + 1:] if r[0] and r[0] not in EXTRA]
styles = [[copy(c._style) for c in row] for row in s.iter_rows(min_row=1, max_row=s.max_row)]
s.delete_rows(1, s.max_row)
s.append(tmpl[0])
for i, a in enumerate(AREAS):
    s.append([a] + [fix(v, 2, i + 2) for v in area_tmpl[1:]])
k = len(AREAS) + 1
total = ['All areas'] + [f'=SUM({openpyxl.utils.get_column_letter(j)}2:{openpyxl.utils.get_column_letter(j)}{k})'
                          for j in range(2, len(tmpl[0]) + 1)]
s.append(total)
for row in trailer:
    s.append([fix(v, 0, 0) for v in row])
s.append(['Not reviewed (new since October 31)', f'=COUNTIF(Definitions!$Q$2:$Q${n},"Not reviewed")'])
s.append(['Changed for Soar 9.6.6 since the review', f'=COUNTIF(Definitions!$T$2:$T${n},"*9.6.6*")'])
for i, row in enumerate(s.iter_rows(min_row=1, max_row=s.max_row)):
    src = styles[min(i, 1) if i <= k else min(tot, len(styles) - 1)]
    for j, c in enumerate(row):
        if j < len(src):
            c._style = copy(src[j])

# README
rd = wb['README']
TEXT = {
    'Purpose': 'Connects each definition of the Lean specification of Soar (cmcsoar project) to the Soar kernel '
               'code it models (Soar 9.6.6), so that a developer working on a Soar bug or a questionable '
               'implementation can move between the two.',
    'Snapshot': f'Lean sources as of {datetime.date.today():%B %-d, %Y} (the model follows Soar 9.6.6). '
                'Soar source: the 9.6.6 release (Core/SoarKernel/src; paths are relative to it, and SVS paths '
                'start Core/SVS/). Line numbers refer to these versions. The reviews in columns Q to S were made '
                'against Soar 9.6.5 (October 31 to November 1, 2026); column T says what has changed for each '
                'definition since then.',
    'Sheets': 'Definitions: one row per documented Lean definition, and every definition reviewed on October 31 '
              'that is still in the sources. Helpers: other undocumented helper definitions. Summary: counts by '
              'area and correspondence (formulas). Removed since review: definitions reviewed on October 31 that '
              'are no longer in the sources (merged or deleted). Remaining differences: tests that still differ '
              'from Soar. Ad hoc places: parts of the implementation to rework. Manual issues: the 43 places where '
              'the manual is wrong, silent or ambiguous. Kernel defects: the 33 findings about the 9.6.5 kernel '
              '(source locations and recommended fixes are in Soar-9.6.5-Kernel-Defects.docx).',
    'How the Definitions sheet was made': 'Extracted automatically from the Lean files: name (with its namespace, '
              'except the root namespace Soar), file, line and kind; the first sentence of the docstring; Soar '
              'functions named in the docstring, each checked to exist in the 9.6.6 source (column I gives the '
              'location; a few names are fields, types or parameters and are located as such); manual sections '
              'cited; SIMPLIFIED / NOT FORMALIZED notes; theorems whose statements mention the definition. For '
              'about 70 central definitions with no citation in the code, the Soar function was added by hand '
              '(Mapping source = "added for this map"); each such name was checked to exist in the source, but '
              'the correspondence itself has not been reviewed line by line. Definitions added since the review '
              'are "Not reviewed", except execution-only versions proved equal to their specification and '
              'proof-only definitions (in the *Props, JoinOrderSem and OrderSafe files), which are "Not '
              'applicable".',
    'Updating': 'python3 tools/map_update.py SOAR_SRC re-extracts the Definitions and Helpers sheets from the Lean '
                'sources and the Soar source tree SOAR_SRC, keeping every review made; run it after changing the '
                'sources.',
}
seen = set()
for row in rd.iter_rows(min_row=1, max_row=rd.max_row):
    key = row[0].value
    if key in TEXT:
        row[1].value = TEXT[key]
        seen.add(key)
    if row[0].row == 1:
        row[0].value = 'Soar 9.6.6 ↔ Lean specification map'
for key in TEXT:
    if key not in seen:
        rd.append([key, TEXT[key]])
wb.save(MAP)
print(f'definitions {len(rows)} (new {sum(1 for r in rows if r[19] and r[19].startswith("added"))}), '
      f'helpers {len(helpers)}, removed {len(removed)}, '
      f'9.6.6 {sum(1 for r in rows if r[19] and "9.6.6" in r[19])}, '
      f'links {sum(1 for r in rows if r[19] and "linked" in r[19])}, '
      f'not found {sum(1 for r in rows if r[8] and "(not found)" in r[8])}')
