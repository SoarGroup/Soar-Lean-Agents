#!/bin/bash
# Compare every test set in tests/ with Soar 9.6.6, with the options each set needs.
# Usage: SOAR966=<SoarSuite_9.6.6>/bin/<platform> tools/run_all.sh [OUTFILE]
# (SOAR_VERSION=9.6.5 compares with the PyPI soar-sml 9.6.5 package instead; tools/soarsel.py)
# Needs: lake build soar-lean. Takes several hours on one core;
# the groups below are independent and can be run in parallel (GROUP=A tools/run_all.sh ...).
cd "$(dirname "$0")/.."
OUT=${1:-results.txt}; : > "$OUT"
T=tools/diff.py
run() { dir=$1; shift; r=$(python3 $T tests/$dir "$@" 2>&1); tot=$(echo "$r" | grep -c '^== '); ok=$(echo "$r" | grep -c '^== .* MATCH'); echo "## $dir $* : $ok / $tot" | tee -a "$OUT"; echo "$r" | grep '^== ' | grep -v MATCH >> "$OUT"; }
g() { [ -z "$GROUP" ] || [ "$GROUP" = "$1" ]; }
# A: decision cycle, real agents, reinforcement learning (with Soar's choices replayed)
g A && { run rlsettings --rl --explore; run test --replay; run fuzz --replay; run fuzz2 --replay; run real --replay
         run rl --rl --explore; run rltests --rl --explore; run rlhier --rl --explore; run rlfuzz --rl --explore; }
# B: semantic memory
g B && { run smemcli --smem; run smembl --smem; run smem --smem; run smemextra --smem; run smemfuzz --smem; run batchfuzz --smem; run batchfuzz2 --smem; run batchfuzz4s --smem
         run smemfuzz2 --smem; run realsmem --smem; run epsem --epmem; }
# C: episodic memory
g C && { run epltichange --epmem --smem; run epsettings --epmem; run epfuzz --epmem; run batchfuzz3 --epmem; run batchfuzz4e --epmem; run epfuzz2 --epmem
         run realep --epmem --replay
         run dbfile --smem --epmem; }
# W: working-memory activation and spreading activation
g W && { run wma --exe; run realwma --exe --epmem --replay; run wmafuzz --exe; run wmadup --exe; run epwma --epmem
         run smemwma --smem; run smemspread --smem; }
# D: chunking
g D && [ -z "$NOCHUNK" ] && { run chunkmem --chunk --epmem --smem; run chunkall --chunk; run chunkextra --chunk; run chunkdeep --chunk
         run chunkdemo --chunk --replay; run agentlib-repro --chunk; }
# E: the rest, and the sets run again without replaying Soar's choices
g E && { run input --exe; run rlvariants --rl --explore; run rltemplates --rl --explore; run lti --smem; run ltifuzz --smem; run ltifuzzB --smem; run idattr --exe --allwm; run idattrB --exe --allwm; run idorder --exe --allwm; run idorderB --exe --allwm; run dupwme --exe --allwm; run dupwmeB --exe --allwm; run bwbook/world --rl --explore --epmem --chunk; run mapdiff/rl --rl --explore; run mapdiff/smem --smem; run mapdiff/epmem --epmem; run mapdiff/chunk --chunk; run mapdiff/exe --exe
         run explore --exe; run rhslib --exe; run rhsfuzz --exe; run justfuzz --exe; run settings --exe; run parser --exe
         run rlsettings --rl --explore --noreplay; run rl --rl --explore --noreplay
         run rltests --rl --explore --noreplay; run rlhier --rl --explore --noreplay
         run rlfuzz --rl --explore --noreplay; run rlvariants --rl --explore --noreplay
         run rltemplates --rl --explore --noreplay; run real --exe; run test --exe; run fuzz --exe; run fuzz2 --exe; }
# S: the spatial visual system (SVS), with tests/svsenv for SGEL input from an environment
# (`K svs LINE` in an input script). Soar 9.6.5 and 9.6.6 behave the same on these sets. The
# overlap filter samples with C's rand(), whose state runs on through every agent in one
# process, so tests/svsextra runs each program in a process of its own.
runeach() { dir=$1; shift; r=$(for f in tests/$dir/*.soar; do ONLY=$(basename $f .soar) python3 $T tests/$dir "$@" 2>&1; done); tot=$(echo "$r" | grep -c '^== '); ok=$(echo "$r" | grep -c '^== .* MATCH'); echo "## $dir $* : $ok / $tot" | tee -a "$OUT"; echo "$r" | grep '^== ' | grep -v MATCH >> "$OUT"; }
g S && { run svs --exe; run svsgen --exe; run svsfuzz --exe; runeach svsextra --exe; run svschunk --chunk; run svsenv --exe; }
# K: the programs that show Soar 9.6.5 kernel defects (bugs/), which match Soar 9.6.6
g K && { run kerneldefects --smem --epmem --chunk; }
# L: the agent library (every agent given for testing, tests/agentlib/README.md); SHARD=i/n splits it
g L && { run agentlib/runs --rl --explore --epmem --smem --chunk; }
echo DONE >> "$OUT"
