# Soar 9.6.6 (kernel 9.6.50) in place of the PyPI soar-sml 9.6.5 package, for the comparison
# tools (tools/soarsel.py puts this directory first on the path unless SOAR_VERSION=9.6.5).
# Use: SOAR966=<SoarSuite_9.6.6>/bin/linux_x86-64 python3 tools/diff.py ...
import os, sys
sys.path.insert(0, os.environ["SOAR966"])
from Python_sml_ClientInterface import *
