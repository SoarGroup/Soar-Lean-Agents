"""Select the Soar the comparison tools run against (import before soar_sml).

Soar 9.6.6 is the reference: set SOAR966 to the bin/<platform> directory of a Soar 9.6.6
build (for example SoarSuite_9.6.6/bin/linux_x86-64); tools/soar966 then loads its Python
interface in place of the PyPI package. SOAR_VERSION=9.6.5 uses the PyPI soar-sml 9.6.5
package instead (pip install soar-sml==9.6.5).
"""
import os, sys
if os.environ.get('SOAR_VERSION', '9.6.6') != '9.6.5':
    if 'SOAR966' not in os.environ:
        sys.exit('set SOAR966 to the bin/<platform> directory of Soar 9.6.6 (or SOAR_VERSION=9.6.5 for the PyPI 9.6.5 package)')
    sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'soar966'))
