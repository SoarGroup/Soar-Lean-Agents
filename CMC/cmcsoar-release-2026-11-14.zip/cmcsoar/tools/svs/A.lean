import Soar.SVS.Algs
open Soar.SVS
def fb (s : String) : Float := Float.ofBits s.toNat!.toUInt64
def v3 (l : List String) : V3 := ⟨fb l[0]!, fb l[1]!, fb l[2]!⟩
def eqb (a b : Float) : Bool := a.toBits == b.toBits
def eqv (a b : V3) : Bool := eqb a.x b.x && eqb a.y b.y && eqb a.z b.z
def main (args : List String) : IO Unit := do
  let ls ← IO.FS.lines args[0]!
  let mut sc : Scene := Scene.fresh 0
  let mut g := CRand.init
  let mut bad : Std.HashMap String Nat := {}
  let mut n := 0
  for l in ls do
    let w := l.splitOn " "
    let note (k : String) (ok : Bool) (msg : String) : IO (Std.HashMap String Nat) := do
      if !ok then
        if bad.getD k 0 < 3 then IO.println s!"{k}: {msg}"
        return bad.insert k (bad.getD k 0 + 1)
      return bad
    match w with
    | "scene" :: _ => sc := Scene.fresh 0
    | "add" :: i :: p :: k :: rest =>
      let (shape, rest) := match k with
        | "0" => (Shape.group, rest)
        | "1" => let m := rest[0]!.toNat!
                 let vs := (List.range m).map fun q => v3 (rest.drop (1 + 3*q))
                 (Shape.convex vs, rest.drop (1 + 3*m))
        | _ => (Shape.ball (fb rest[0]!), rest.drop 1)
      let u := i.toNat!
      sc := sc.insertNew u { name := s!"n{u}", shape, pos := v3 rest, rot := v3 (rest.drop 3), scl := v3 (rest.drop 6) }
      sc := (sc.attach p.toNat! u).1
    | ["tag", i] => sc := (sc.setTag i.toNat! "object-source" "belief").1
    | "pl" :: a :: b :: r :: xs :: ys :: zs :: res =>
      n := n + 1
      let ref : Option Nat := if r == "-1" then none else some r.toNat!
      let got := sc.placement a.toNat! b.toNat! ref ⟨fb xs, fb ys, fb zs⟩
      bad ← note "pl" (eqv got (v3 res)) s!"{l} got {repr got}"
    | ["ov", a, b, res] =>
      n := n + 1
      let (o, g') := sc.overlap a.toNat! b.toNat! 200 g
      g := g'
      bad ← note "ov" (eqb o (fb res)) s!"{l} got {o} want {fb res}"
    | "oc" :: t :: e :: k :: rest =>
      n := n + 1
      let occ := (rest.take k.toNat!).map String.toNat!
      let res := fb rest[k.toNat!]!
      let lines := (sc.viewLines t.toNat! e.toNat!).toArray
      let got := sc.occlusion lines occ
      bad ← note "oc" (eqb got res) s!"{l} got {got}"
    | "ad" :: a :: res =>
      n := n + 1
      let got := (sc.adjustSize a.toNat!).getD (sc.node a.toNat!).scl
      bad ← note "ad" (eqv got (v3 res)) s!"{l} got {repr got}"
    | _ => pure ()
  IO.println s!"checks {n}, bad {bad.toList}"
