import Soar.SVS.Gjk
open Soar.SVS
def fb (s : String) : Float := Float.ofBits s.toNat!.toUInt64
def v3 (l : List String) : V3 := ⟨fb l[0]!, fb l[1]!, fb l[2]!⟩
def eqb (a b : Float) : Bool := a.toBits == b.toBits
def eqv (a b : V3) : Bool := eqb a.x b.x && eqb a.y b.y && eqb a.z b.z
def main (args : List String) : IO Unit := do
  let ls ← IO.FS.lines args[0]!
  let mut sc : Scene := Scene.fresh 0
  let mut ax : V3 := V3.zero
  let mut bad := 0
  let mut n := 0
  for l in ls do
    let w := l.splitOn " "
    match w with
    | "scene" :: _ => sc := Scene.fresh 0
    | "add" :: i :: p :: k :: rest =>
      let (shape, rest) := match k with
        | "0" => (Shape.group, rest)
        | "1" => let m := rest[0]!.toNat!
                 let vs := (List.range m).map fun q => v3 (rest.drop (1 + 3*q))
                 (Shape.convex vs, rest.drop (1 + 3*m))
        | _ => (Shape.ball (fb rest[0]!), rest.drop 1)
      let u := i.toNat!
      sc := sc.insertNew u { name := s!"n{u}", shape, pos := v3 rest, rot := v3 (rest.drop 3), scl := v3 (rest.drop 6) }
      sc := (sc.attach p.toNat! u).1
    | "axis" :: rest => ax := v3 rest
    | "q" :: i :: rest =>
      let u := i.toNat!
      let b := sc.bounds u
      n := n + 1
      let ok := eqv b.lo (v3 rest) && eqv b.hi (v3 (rest.drop 3)) && eqv (sc.centroid u) (v3 (rest.drop 6)) &&
        eqb (sc.maxProj u ax) (fb rest[9]!) && eqb (sc.minProj u ax) (fb rest[10]!)
      if !ok then
        bad := bad + 1
        if bad < 5 then IO.println s!"q {u}: {repr b} vs {rest}"
    | "d" :: i :: j :: cd :: ce :: axd :: ci :: bi :: bc :: _ =>
      let a := i.toNat!
      let b := j.toNat!
      n := n + 1
      let cv := sc.convexDistance a b
      if !eqb cv (fb cd) || (sc.convexIntersects a b != (ci == "1")) then
        bad := bad + 1
        if bad < 8 then IO.println s!"cd {a} {b}: {cv} vs {fb cd}"
      let ok := eqb (sc.centroidDist a b) (fb ce) && eqb (sc.axisDistVec a b ax) (fb axd) &&
        (sc.bboxIntersects a b == (bi == "1")) && (sc.bboxContains a b == (bc == "1"))
      if !ok then
        bad := bad + 1
        if bad < 5 then IO.println s!"d {a} {b}: {sc.centroidDist a b} {sc.axisDistVec a b ax} vs {fb ce} {fb axd}"
    | _ => pure ()
  IO.println s!"bad {bad} of {n}"
