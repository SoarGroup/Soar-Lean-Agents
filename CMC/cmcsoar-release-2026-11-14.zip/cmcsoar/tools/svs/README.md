# The SVS oracle

`build.sh SOAR_SRC` compiles SVS's own geometry (sgnode.cpp, sgnode_algs.cpp, mat.cpp, Eigen
3.4, libccd) as Soar 9.6.6 compiles it (`g++ -O3 -DNDEBUG`, x86-64), generates random scenes and
queries, and checks the Lean model (Soar/SVS/) against the results bit for bit:

- `gen.cpp` → `G.lean`: bounding boxes, centroids, projections, centroid, axis and hull (GJK)
  distances, box and hull intersection, containment (300 scenes).
- `gen2.cpp` → `A.lean`: `calculate_placement` (Eigen's quaternion product), `convex_overlap`
  (glibc `rand()`), `convex_occlusion`, `adjust_sgnode_size` (120 scenes).
- `gfmt.c` → `T.lean`: `%g` formatting and reading back, against glibc.

`order*.cpp` are the experiments that established Eigen's order of floating-point operations
(see the header of Soar/SVS/Geom.lean). `stub.cpp` supplies the one scene function the oracle
links but does not use.

Expected output: `bad 0 of 8202`, `checks 1200, bad []`, `bad 0 of 20020` (the last also lists
three subnormal numbers that read back as 0, as `strtod` in the model reports underflow).
