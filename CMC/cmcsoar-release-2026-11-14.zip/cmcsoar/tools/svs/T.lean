import Soar.SVS.Geom
open Soar.SVS
def main : IO Unit := do
  let ls ← IO.FS.lines "g.txt"
  let mut bad := 0
  for l in ls do
    match l.splitOn " " with
    | [b, s] =>
      let x := Float.ofBits b.toNat!.toUInt64
      if gStr x != s then
        bad := bad + 1
        if bad < 10 then IO.println s!"{b} want {s} got {gStr x}"
      match parseDouble s with
      | some y => if gStr y != s then IO.println s!"reparse {s} -> {gStr y}"
      | none => IO.println s!"noparse {s}"
    | _ => pure ()
  IO.println s!"bad {bad} of {ls.size}"
