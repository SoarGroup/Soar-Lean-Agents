#!/bin/bash
# Build the SVS oracle from Soar's own sources and compare the Lean geometry with it.
# Usage: tools/svs/build.sh SOAR_SRC   (a checkout of the Soar source, e.g. SoarGroup/Soar)
# Needs g++ and gcc; run from the repository root after `lake build`.
set -e
S=${1:?give the Soar source directory}/Core/SVS
P=$1/Core/shared
W=$(mktemp -d)
for f in sgnode mat common cliproxy sgnode_algs serialize; do
  g++ -O3 -DNDEBUG -w -I$S/src -I$S/eigen -I$S/ccd -I$P -c $S/src/$f.cpp -o $W/$f.o
done
for f in ccd mpr polytope support vec3; do gcc -O3 -DNDEBUG -w -I$S/ccd -c $S/ccd/$f.c -o $W/ccd_$f.o; done
for f in stub gen gen2; do g++ -O3 -DNDEBUG -w -I$S/src -I$S/eigen -I$S/ccd -I$P -I$S/../SoarKernel/src/shared -c tools/svs/$f.cpp -o $W/$f.o; done
L="$W/sgnode.o $W/mat.o $W/common.o $W/cliproxy.o $W/sgnode_algs.o $W/serialize.o $W/stub.o $W/ccd_*.o"
g++ -O3 $L $W/gen.o -o $W/gen
g++ -O3 $L $W/gen2.o -o $W/gen2
gcc -O2 tools/svs/gfmt.c -o $W/gfmt -lm
$W/gen 300 > $W/geo.txt
$W/gen2 120 > $W/alg.txt
(cd $W && ./gfmt > g.txt)
lake env lean --run tools/svs/G.lean $W/geo.txt
lake env lean --run tools/svs/A.lean $W/alg.txt
(cd $W && lake --dir "$OLDPWD" env lean --run "$OLDPWD/tools/svs/T.lean")
