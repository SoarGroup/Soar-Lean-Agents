#include "sgnode.h"
#include "sgnode_algs.h"
#include <cstdio>
#include <cstring>
#include <random>
#include <vector>
#include <stdint.h>
std::mt19937_64 g(11);
double R(double a,double b){ std::uniform_real_distribution<double> u(a,b); double x=u(g); if(g()%5==0) x=std::round(x*10)/10; return x;}
uint64_t B(double x){uint64_t b; memcpy(&b,&x,8); return b;}
void pv(const vec3& v){ printf(" %llu %llu %llu",(unsigned long long)B(v(0)),(unsigned long long)B(v(1)),(unsigned long long)B(v(2))); }
int main(int argc,char**argv){
  int nscen=atoi(argv[1]);
  for(int sc=0;sc<nscen;sc++){
    group_node* w=new group_node("world"); std::vector<sgnode*> ns; ns.push_back(w);
    printf("scene\n");
    int n=2+g()%6;
    for(int i=1;i<=n;i++){
      // choose parent among groups
      std::vector<int> gs; for(int j=0;j<(int)ns.size();j++) if(ns[j]->is_group()) gs.push_back(j);
      int par=gs[g()%gs.size()];
      int k=g()%3; sgnode* nd; char nm[16]; sprintf(nm,"n%d",i);
      vec3 p(R(-2,2),R(-2,2),R(-2,2)), r(R(-3.2,3.2),R(-3.2,3.2),R(-3.2,3.2)), s(R(0.05,2),R(0.05,2),R(0.05,2));
      if(g()%4==0) r=vec3(0,0,0); if(g()%4==0) s=vec3(1,1,1);
      printf("add %d %d %d",i,par,k);
      if(k==0) nd=new group_node(nm);
      else if(k==1){ ptlist v; int m=1+g()%8; printf(" %d",m); for(int q=0;q<m;q++){ vec3 x(R(-1,1),R(-1,1),R(-1,1)); v.push_back(x); pv(x);} nd=new convex_node(nm,v);}
      else { double rad=R(0.1,1.5); printf(" %llu",(unsigned long long)B(rad)); nd=new ball_node(nm,rad);}
      pv(p);pv(r);pv(s); printf("\n");
      nd->set_trans(p,r,s);
      ns[par]->as_group()->attach_child(nd); ns.push_back(nd);
    }
    vec3 ax(R(-1,1),R(-1,1),R(-1,1)); vec3 ua=ax/ax.norm();
    printf("axis"); pv(ua); printf("\n");
    for(int i=0;i<(int)ns.size();i++){
      const bbox& b=ns[i]->get_bounds(); printf("q %d",i); pv(b.get_min()); pv(b.get_max()); pv(ns[i]->get_centroid());
      printf(" %llu %llu", (unsigned long long)B(ns[i]->max_project_on_axis(ua)), (unsigned long long)B(ns[i]->min_project_on_axis(ua)));
      printf("\n");
    }
    for(int i=1;i<(int)ns.size();i++) for(int j=1;j<(int)ns.size();j++){
      printf("d %d %d %llu %llu %llu %d %d %d\n",i,j,(unsigned long long)B(convex_distance(ns[i],ns[j])),(unsigned long long)B(centroid_distance(ns[i],ns[j])),
        (unsigned long long)B(axis_distance(ns[i],ns[j],ua)), (int)convex_intersects(ns[i],ns[j]), (int)bbox_intersects(ns[i],ns[j]), (int)bbox_contains(ns[i],ns[j]));
    }
    delete w;
  }
}
