#include "sgnode.h"
#include "sgnode_algs.h"
#include <cstdio>
#include <cstring>
#include <random>
#include <vector>
#include <stdint.h>
vec3 calculate_placement(const sgnode* a, const sgnode* b, const sgnode* ref, double xsep, double ysep, double zsep){
    vec3 sep(xsep, ysep, zsep);
    vec3 pa = a->get_centroid();
    vec3 pb = b->get_centroid();
    vec3 axes[3];
    axes[0] = vec3(1.0, 0.0, 0.0);
    axes[1] = vec3(0.0, 1.0, 0.0);
    axes[2] = vec3(0.0, 0.0, 1.0);
    if(ref != 0) { transform3 rot('r', ref->get_trans('r')); for(int dim = 0; dim < 3; dim++) axes[dim] = rot(axes[dim]); }
    vec3 mina, minb, maxa, maxb;
    for(int dim = 0; dim < 3; dim++) {
      mina[dim] = a->min_project_on_axis(axes[dim]) - axes[dim].dot(pa);
      minb[dim] = b->min_project_on_axis(axes[dim]) - axes[dim].dot(pb);
      maxa[dim] = a->max_project_on_axis(axes[dim]) - axes[dim].dot(pa);
      maxb[dim] = b->max_project_on_axis(axes[dim]) - axes[dim].dot(pb);
    }
    vec3 pos = pb;
    for(int dim = 0; dim < 3; dim++){
        if(sep[dim] > 0) pos = pos + axes[dim] * (maxb[dim] + sep[dim] - mina[dim]);
        else if(sep[dim] < 0) pos = pos - axes[dim] * (-minb[dim] - sep[dim] + maxa[dim]);
    }
    return pos;
}
std::mt19937_64 g(23);
double R(double a,double b){ std::uniform_real_distribution<double> u(a,b); double x=u(g); if(g()%5==0) x=std::round(x*10)/10; return x;}
uint64_t B(double x){uint64_t b; memcpy(&b,&x,8); return b;}
void pv(const vec3& v){ printf(" %llu %llu %llu",(unsigned long long)B(v(0)),(unsigned long long)B(v(1)),(unsigned long long)B(v(2))); }
int main(int argc,char**argv){
  int nscen=atoi(argv[1]);
  for(int sc=0;sc<nscen;sc++){
    group_node* w=new group_node("world"); std::vector<sgnode*> ns; ns.push_back(w);
    printf("scene\n");
    int n=2+g()%5;
    for(int i=1;i<=n;i++){
      std::vector<int> gs; for(int j=0;j<(int)ns.size();j++) if(ns[j]->is_group()) gs.push_back(j);
      int par=gs[g()%gs.size()];
      int k=g()%3; sgnode* nd; char nm[16]; sprintf(nm,"n%d",i);
      vec3 p(R(-1,1),R(-1,1),R(-1,1)), r(R(-3.2,3.2),R(-3.2,3.2),R(-3.2,3.2)), s(R(0.3,2),R(0.3,2),R(0.3,2));
      if(g()%4==0) r=vec3(0,0,0); if(g()%4==0) s=vec3(1,1,1);
      printf("add %d %d %d",i,par,k);
      if(k==0) nd=new group_node(nm);
      else if(k==1){ ptlist v; int m=4+g()%6; printf(" %d",m); for(int q=0;q<m;q++){ vec3 x(R(-1,1),R(-1,1),R(-1,1)); v.push_back(x); pv(x);} nd=new convex_node(nm,v);}
      else { double rad=R(0.3,1.5); printf(" %llu",(unsigned long long)B(rad)); nd=new ball_node(nm,rad);}
      pv(p);pv(r);pv(s); printf("\n");
      nd->set_trans(p,r,s);
      if (g()%3==0) { nd->set_tag("object-source","belief"); printf("tag %d\n", i); }
      ns[par]->as_group()->attach_child(nd); ns.push_back(nd);
    }
    int N=ns.size();
    for(int t=0;t<4;t++){
      int a=1+g()%(N-1), b=1+g()%(N-1); int ref = (g()%2)? (int)(g()%N) : -1;
      double xs=R(-1,1), ys=R(-1,1), zs=R(-1,1); if(g()%3==0) xs=0;
      vec3 r=calculate_placement(ns[a],ns[b],ref<0?0:ns[ref],xs,ys,zs);
      printf("pl %d %d %d %llu %llu %llu",a,b,ref,(unsigned long long)B(xs),(unsigned long long)B(ys),(unsigned long long)B(zs)); pv(r); printf("\n");
    }
    for(int t=0;t<3;t++){
      int a=1+g()%(N-1), b=1+g()%(N-1);
      double o=convex_overlap(ns[a],ns[b],200);
      printf("ov %d %d %llu\n",a,b,(unsigned long long)B(o));
    }
    for(int t=0;t<2;t++){
      int tg=1+g()%(N-1), eye=g()%N; std::vector<view_line> lines; calc_view_lines(ns[tg],ns[eye],lines);
      std::vector<const sgnode*> occ; printf("oc %d %d",tg,eye); int k=g()%N; printf(" %d",k);
      for(int q=0;q<k;q++){ int o=1+g()%(N-1); occ.push_back(ns[o]); printf(" %d",o);} 
      double res=convex_occlusion(lines,occ); printf(" %llu\n",(unsigned long long)B(res));
      for(size_t q=0;q<lines.size();q++) delete lines[q].first;
    }
    { int a=1+g()%(N-1); std::vector<const sgnode*> tg; for(int q=0;q<N;q++){ std::string v; if(ns[q]!=ns[a] && ns[q]->get_tag("object-source",v) && v=="belief") tg.push_back(ns[q]); }
      adjust_sgnode_size(ns[a], tg); printf("ad %d",a); pv(ns[a]->get_trans('s')); printf("\n"); }
    delete w;
  }
}
