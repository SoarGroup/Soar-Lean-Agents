#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdint.h>
int main(){ srand(3);
 double specials[]={0.0,-0.0,1,0.5,0.1,1e-5,1e-4,9.9999949e-5,999999.5,999999.4,1e6,123456.5,0.072,-0.22929,1e100,5e-324,2.5,0.000123456789, 1234567, 100000};
 for(int i=0;i<20;i++){ double x=specials[i]; uint64_t b; memcpy(&b,&x,8); printf("%llu %g\n",(unsigned long long)b,x);}
 for(int i=0;i<20000;i++){ double x; uint64_t b;
   int k=rand()%4;
   if(k==0) x=((double)rand()/RAND_MAX-0.5)*pow(10, rand()%20-10);
   else if(k==1){ x = round(((double)rand()/RAND_MAX)*1e7)/pow(10,rand()%12); }
   else if(k==2){ b=((uint64_t)rand()<<33)^((uint64_t)rand()<<2)^rand(); memcpy(&x,&b,8); if(isnan(x)||isinf(x)) x=1.5;}
   else x=(rand()%2000000-1000000)*0.0000005;
   memcpy(&b,&x,8); printf("%llu %g\n",(unsigned long long)b,x);}
}
