#include <Eigen/Dense>
#include <Eigen/Geometry>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <random>
typedef Eigen::Vector3d vec3;
typedef Eigen::Transform<double,3,Eigen::Affine> T3;
T3 mk(const vec3& p, const vec3& r, const vec3& s){
  T3 t; t = Eigen::Translation<double,3>(p) * Eigen::AngleAxisd(r(2), Eigen::Vector3d::UnitZ()) *
            Eigen::AngleAxisd(r(1), Eigen::Vector3d::UnitY()) * Eigen::AngleAxisd(r(0), Eigen::Vector3d::UnitX()) * Eigen::Scaling(s);
  return t;
}
// manual
typedef double M[3][3];
void aa(double ang, int ax, M R){
  double axis[3]={0,0,0}; axis[ax]=1.0;
  double s=sin(ang), c=cos(ang);
  double sa[3]={s*axis[0],s*axis[1],s*axis[2]}; double ca[3]={(1-c)*axis[0],(1-c)*axis[1],(1-c)*axis[2]};
  double tmp;
  tmp=ca[0]*axis[1]; R[0][1]=tmp-sa[2]; R[1][0]=tmp+sa[2];
  tmp=ca[0]*axis[2]; R[0][2]=tmp+sa[1]; R[2][0]=tmp-sa[1];
  tmp=ca[1]*axis[2]; R[1][2]=tmp-sa[0]; R[2][1]=tmp+sa[0];
  R[0][0]=ca[0]*axis[0]+c; R[1][1]=ca[1]*axis[1]+c; R[2][2]=ca[2]*axis[2]+c;
}
int mode;
double d3(double a0,double b0,double a1,double b1,double a2,double b2){
  if(mode==0) return a0*b0 + (a1*b1 + a2*b2);
  return (a0*b0 + a1*b1) + a2*b2;
}
void mul(M A, M B, M C){ M t; for(int i=0;i<3;i++)for(int j=0;j<3;j++) t[i][j]=d3(A[i][0],B[0][j],A[i][1],B[1][j],A[i][2],B[2][j]); memcpy(C,t,sizeof(M)); }
int main(){
  std::mt19937_64 g(42); std::uniform_real_distribution<double> u(-3,3);
  for(mode=0;mode<2;mode++){
    int bad=0, badw=0, badv=0;
    for(int k=0;k<200000;k++){
      vec3 p(u(g),u(g),u(g)), r(u(g),u(g),u(g)), s(u(g),u(g),u(g));
      T3 t=mk(p,r,s);
      M Rz,Ry,Rx,L; aa(r(2),2,Rz); aa(r(1),1,Ry); aa(r(0),0,Rx);
      mul(Rz,Ry,L); mul(L,Rx,L);
      for(int i=0;i<3;i++)for(int j=0;j<3;j++) L[i][j]=L[i][j]*s(j);
      double tr[3]={0.0+p(0),0.0+p(1),0.0+p(2)};
      for(int i=0;i<3;i++){ for(int j=0;j<3;j++) if(t.linear()(i,j)!=L[i][j]) bad++; if(t.translation()(i)!=tr[i]) bad++;}
      // world compose
      vec3 p2(u(g),u(g),u(g)), r2(u(g),u(g),u(g)), s2(u(g),u(g),u(g));
      T3 t2=mk(p2,r2,s2); T3 w = t*t2;
      M L2; for(int i=0;i<3;i++)for(int j=0;j<3;j++) L2[i][j]=t2.linear()(i,j);
      M WL; mul(L,L2,WL);
      for(int i=0;i<3;i++){ for(int j=0;j<3;j++) if(w.linear()(i,j)!=WL[i][j]) badw++;
        double wt = d3(L[i][0],t2.translation()(0),L[i][1],t2.translation()(1),L[i][2],t2.translation()(2)) + tr[i];
        if(w.translation()(i)!=wt) badw++; }
      vec3 v(u(g),u(g),u(g)); vec3 o = t*v;
      for(int i=0;i<3;i++){ double e = tr[i] + d3(L[i][0],v(0),L[i][1],v(1),L[i][2],v(2)); if(o(i)!=e) badv++; }
    }
    printf("mode %d: local %d world %d apply %d\n", mode, bad, badw, badv);
  }
}
