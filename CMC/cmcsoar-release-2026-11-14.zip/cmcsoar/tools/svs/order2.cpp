#include <Eigen/Dense>
#include <Eigen/Geometry>
#include <cstdio>
#include <random>
typedef Eigen::Vector3d vec3;
typedef Eigen::Transform<double,3,Eigen::Affine> T3;
T3 mk(const vec3& p, const vec3& r, const vec3& s){
  T3 t; t = Eigen::Translation<double,3>(p) * Eigen::AngleAxisd(r(2), Eigen::Vector3d::UnitZ()) *
            Eigen::AngleAxisd(r(1), Eigen::Vector3d::UnitY()) * Eigen::AngleAxisd(r(0), Eigen::Vector3d::UnitX()) * Eigen::Scaling(s);
  return t;
}
int main(){
  std::mt19937_64 g(42); std::uniform_real_distribution<double> u(-3,3);
  int bad[8]={0};
  for(int k=0;k<200000;k++){
    vec3 p(u(g),u(g),u(g)), r(u(g),u(g),u(g)), s(u(g),u(g),u(g));
    vec3 p2(u(g),u(g),u(g)), r2(u(g),u(g),u(g)), s2(u(g),u(g),u(g));
    T3 a=mk(p,r,s), b=mk(p2,r2,s2); T3 w=a*b;
    Eigen::Matrix4d A=a.matrix(), B=b.matrix();
    for(int i=0;i<3;i++)for(int j=0;j<4;j++){
      double x[4]; for(int k2=0;k2<4;k2++) x[k2]=A(i,k2)*B(k2,j);
      double v[6];
      v[0]=((x[0]+x[1])+x[2])+x[3];
      v[1]=(x[0]+x[2])+(x[1]+x[3]);
      v[2]=(x[0]+x[1])+(x[2]+x[3]);
      v[3]=x[0]+(x[1]+(x[2]+x[3]));
      v[4]=x[3]+((x[0]+x[1])+x[2]);
      v[5]=x[3]+(x[0]+(x[1]+x[2]));
      for(int m=0;m<6;m++) if(w.matrix()(i,j)!=v[m]) bad[m]++;
    }
  }
  for(int m=0;m<6;m++) printf("%d: %d\n",m,bad[m]);
}
