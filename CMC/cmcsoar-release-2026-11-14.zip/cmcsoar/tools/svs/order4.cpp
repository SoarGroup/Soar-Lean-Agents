#include <Eigen/Dense>
#include <cstdio>
#include <cmath>
#include <random>
typedef Eigen::Vector3d vec3;
int main(){
  std::mt19937_64 g(7); std::uniform_real_distribution<double> u(-3,3);
  int b[6]={0};
  for(int k=0;k<500000;k++){
    vec3 a(u(g),u(g),u(g)), c(u(g),u(g),u(g));
    double d=a.dot(c); double x0=a(0)*c(0),x1=a(1)*c(1),x2=a(2)*c(2);
    if(d!=(x0+x1)+x2) b[0]++; if(d!=x0+(x1+x2)) b[1]++;
    double n=a.norm(); double s0=a(0)*a(0),s1=a(1)*a(1),s2=a(2)*a(2);
    if(n!=std::sqrt((s0+s1)+s2)) b[2]++; if(n!=std::sqrt(s0+(s1+s2))) b[3]++;
    vec3 nz=a.normalized(); double nn=std::sqrt((s0+s1)+s2);
    if(nz(0)!=a(0)/nn || nz(1)!=a(1)/nn || nz(2)!=a(2)/nn) b[4]++;
  }
  for(int i=0;i<5;i++) printf("%d: %d\n",i,b[i]);
}
