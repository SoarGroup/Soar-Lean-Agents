#include "scene.h"
void scene::get_all_nodes(std::vector<const sgnode*>& n) const {}
