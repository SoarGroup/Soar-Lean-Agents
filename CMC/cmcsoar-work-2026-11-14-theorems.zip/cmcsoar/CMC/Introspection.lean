import CMC.Meta

/-!
# The limits of introspection in the Common Model of Cognition

The CMC (with the metacognition extension, `CMC/Meta.lean`) decides that numeric metadata on
memory elements — activation, recency, frequency, utility — is never examinable by rules
(DECIDED, Laird, 2026-10-28). This file proves what that decision implies for what a mind can
know about itself.

**Theorem (`introspection_limit`).** Take two minds that are the same symbolically — the same
working memory, procedural memory, declarative and episodic memories and learning state — but
whose memories may differ in any numeric metadata. Run both through any sequence of steps.
If, at each step, the four places where the architecture is allowed to consult metadata give
the same symbolic outcome in both minds —

1. what the cognitive cycle did (which deliberate act was selected and its effect),
2. what a retrieval returned, with its process data (failure, confidence, partiality),
3. what the working-memory appraisal reported,
4. what forgetting removed,

— then the two minds remain symbolically identical for the whole run and produce exactly the
same actions. In particular no rule-testable fact (`MetaBlind` predicate), and so no report
the agent could make about itself, ever distinguishes them (`report_cannot_see_metadata`).

**What it means.** Whatever an agent comes to know about the strength of its own memories,
it knows only from those four channels: from *what happened* (what it chose, what came to
mind, what it lost) and from the architecture's own reports (process data and appraisals,
such as a feeling of familiarity or confidence). It never observes the strength itself. A
mind's account of *why* it retrieved or chose something is therefore an inference from
outcomes and reports, not an observation of the cause. This is the pattern of Nisbett and
Wilson's results on verbal reports, here a consequence of the CMC's architecture rather than
an empirical generalization, and it holds for every architecture that conforms to the CMC.

**What it does not say.** The architecture's reports are not limited: process data "may be
quantitative", so an architecture could report a memory's strength exactly through channel 2
or 3. The theorem locates every route by which metadata can reach knowledge; how much a mind
can learn about its memories depends on how informative the architecture makes those reports.

**Assumptions.** The other functions of the architecture (perception, motor, episodic
recording, rule composition, creation of declarative structures) do not read metadata to
decide symbolic content (`Blind`); the CMC is silent on them, and they hold in Soar and in
ACT-R. The theorem does not assume anything about the four channels: they may depend on
metadata in any way, and the toy architecture shows `Blind` can be met (`Toy.blind`).
-/

namespace CMC.Meta
namespace Introspection

variable {σ : Sig}

/-- The symbolic content of a list of elements: metadata erased. -/
def syms (l : List (Elem σ)) : List (Rel σ) := l.map Elem.rel

/-- The symbolic content of procedural memory: each rule's condition and action, without its
metadata (utility). -/
def pmSyms (pm : ProcMem σ) : List ((WM σ → Prop) × (WM σ → WM σ)) :=
  pm.map fun r => (r.cond, r.act)

/-- The symbolic content of the record of the last cycle. -/
def lastSyms (c : Option (WM σ × WM σ)) : Option ((L σ → List (Rel σ)) × (L σ → List (Rel σ))) :=
  c.map fun e => (symView e.1, symView e.2)

/-- **Two minds that differ at most in numeric metadata**: the same working memory,
procedural memory, declarative memories, record of the last cycle and learning state, up to
metadata. -/
structure Variant (s₁ s₂ : State σ) : Prop where
  wm : symView s₁.wm = symView s₂.wm
  pm : pmSyms s₁.pm = pmSyms s₂.pm
  dm : ∀ d, syms (s₁.dm d).elems = syms (s₂.dm d).elems
  last : lastSyms s₁.lastCycle = lastSyms s₂.lastCycle
  ps : s₁.ps = s₂.ps
  ms : s₁.ms = s₂.ms

/-- **The functions outside the four channels do not read metadata** to decide symbolic
content: perception, motor execution and its status, perceptual and motor learning, episodic
recording, rule composition and the creation of declarative structures. -/
structure Blind (A : Arch σ) : Prop where
  perceive : ∀ p l i (w₁ w₂ : WM σ), symView w₁ = symView w₂ →
    syms (A.perceive p l i w₁).1 = syms (A.perceive p l i w₂).1 ∧
    syms (A.perceive p l i w₁).2 = syms (A.perceive p l i w₂).2
  perceptLearn : ∀ p l i (w₁ w₂ : WM σ), symView w₁ = symView w₂ →
    A.perceptLearn p l i w₁ = A.perceptLearn p l i w₂
  motor : ∀ m l (c₁ c₂ : List (Elem σ)), syms c₁ = syms c₂ → A.motor m l c₁ = A.motor m l c₂
  motorStatus : ∀ m l (c₁ c₂ : List (Elem σ)), syms c₁ = syms c₂ →
    syms (A.motorStatus m l c₁) = syms (A.motorStatus m l c₂)
  motorLearn : ∀ m l (c₁ c₂ : List (Elem σ)) o, syms c₁ = syms c₂ →
    A.motorLearn m l c₁ o = A.motorLearn m l c₂ o
  record : ∀ (dm₁ dm₂ : DeclMem σ) (w₁ w₂ : WM σ), syms dm₁.elems = syms dm₂.elems →
    symView w₁ = symView w₂ → syms (A.record dm₁ w₁).elems = syms (A.record dm₂ w₂).elems
  compose : ∀ (pm₁ pm₂ : ProcMem σ) e₁ e₂, pmSyms pm₁ = pmSyms pm₂ →
    lastSyms (some e₁) = lastSyms (some e₂) → pmSyms (A.compose pm₁ e₁) = pmSyms (A.compose pm₂ e₂)
  declCreate : ∀ d (dm₁ dm₂ : DeclMem σ) e₁ e₂, syms dm₁.elems = syms dm₂.elems →
    lastSyms (some e₁) = lastSyms (some e₂) →
    syms (A.declCreate d dm₁ e₁).elems = syms (A.declCreate d dm₂ e₂).elems

/-- **The four channels** through which the architecture may consult metadata, at one step:
the step gives the same symbolic outcome in both minds. Steps of other kinds consult no
metadata, so they impose nothing. -/
def Channels (A : Arch σ) : Label σ → State σ → State σ → Prop
  | .cycle, s₁, s₂ => symView (cycleWM A s₁.pm s₁.wm) = symView (cycleWM A s₂.pm s₂.wm)
  | .retrieve d, s₁, s₂ =>
      syms (A.retrieve d (s₁.dm d) (s₁.wm (Loc.decl d .cue))).1 =
        syms (A.retrieve d (s₂.dm d) (s₂.wm (Loc.decl d .cue))).1 ∧
      syms (A.retrieve d (s₁.dm d) (s₁.wm (Loc.decl d .cue))).2 =
        syms (A.retrieve d (s₂.dm d) (s₂.wm (Loc.decl d .cue))).2
  | .appraise, s₁, s₂ => syms (A.appraise s₁.wm) = syms (A.appraise s₂.wm)
  | .forgetWM b, s₁, s₂ =>
      syms ((s₁.wm b).filter fun e => !A.forgettable e.«meta») =
        syms ((s₂.wm b).filter fun e => !A.forgettable e.«meta»)
  | .forgetDecl d, s₁, s₂ =>
      syms ((s₁.dm d).elems.filter fun e => !A.forgettable e.«meta») =
        syms ((s₂.dm d).elems.filter fun e => !A.forgettable e.«meta»)
  | _, _, _ => True

/-- The channels agree at every step of a run. -/
def ChannelsAlong (A : Arch σ) : List (Label σ) → State σ → State σ → Prop
  | [], _, _ => True
  | l :: ls, s₁, s₂ => Channels A l s₁ s₂ ∧ ChannelsAlong A ls (exec A l s₁).1 (exec A l s₂).1

/-! ## Lemmas -/

theorem symView_apply (w : WM σ) (ℓ : L σ) : symView w ℓ = syms (w ℓ) := rfl

theorem symView_upd {w₁ w₂ : WM σ} {a : L σ} {v₁ v₂ : List (Elem σ)}
    (hw : symView w₁ = symView w₂) (hv : syms v₁ = syms v₂) :
    symView (upd w₁ a v₁) = symView (upd w₂ a v₂) := by
  funext ℓ
  simp only [symView, upd]
  split
  · exact hv
  · exact congrFun hw ℓ

theorem dm_upd {dm₁ dm₂ : σ.DMem → DeclMem σ} {d : σ.DMem} {x₁ x₂ : DeclMem σ}
    (h : ∀ d, syms (dm₁ d).elems = syms (dm₂ d).elems) (hx : syms x₁.elems = syms x₂.elems) :
    ∀ d', syms ((upd dm₁ d x₁) d').elems = syms ((upd dm₂ d x₂) d').elems := by
  intro d'
  simp only [upd]
  split
  · exact hx
  · exact h d'

theorem syms_decay (A : Arch σ) (l : List (Elem σ)) : syms (l.map (decayElemWM A)) = syms l := by
  simp [syms, decayElemWM]

theorem syms_decayDM (A : Arch σ) (l : List (Elem σ)) : syms (l.map (decayElemDM A)) = syms l := by
  simp [syms, decayElemDM]

/-! ## One step -/

/-- **One step.** Two variants whose channels agree at a step are variants after it, and
produce the same output. -/
theorem exec_variant {A : Arch σ} (hB : Blind A) (l : Label σ) {s₁ s₂ : State σ}
    (h : Variant s₁ s₂) (hc : Channels A l s₁ s₂) :
    Variant (exec A l s₁).1 (exec A l s₂).1 ∧ (exec A l s₁).2 = (exec A l s₂).2 := by
  obtain ⟨hw, hp, hd, hl, hps, hms⟩ := h
  cases l with
  | perceive p i =>
    obtain ⟨h1, h2⟩ := hB.perceive p (s₁.ps p) i s₁.wm s₂.wm hw
    have h1' : syms (A.perceive p (s₁.ps p) i s₁.wm).1 = syms (A.perceive p (s₂.ps p) i s₂.wm).1 := by
      rw [← hps]; exact h1
    have h2' : syms (A.perceive p (s₁.ps p) i s₁.wm).2 = syms (A.perceive p (s₂.ps p) i s₂.wm).2 := by
      rw [← hps]; exact h2
    exact ⟨⟨symView_upd (symView_upd hw h1') h2', hp, hd, hl, hps, hms⟩, rfl⟩
  | retrieve d =>
    obtain ⟨h1, h2⟩ := hc
    refine ⟨⟨symView_upd (symView_upd hw h1) h2, hp, dm_upd hd ?_, hl, hps, hms⟩, rfl⟩
    have t1 := A.retrieveTouch_symbolic d (s₁.dm d) (s₁.wm (Loc.decl d .cue))
    have t2 := A.retrieveTouch_symbolic d (s₂.dm d) (s₂.wm (Loc.decl d .cue))
    simp only [syms] at hd ⊢
    rw [t1, t2]; exact hd d
  | motor m =>
    have hcmd : syms (s₁.wm (Loc.motor m .command)) = syms (s₂.wm (Loc.motor m .command)) :=
      congrFun hw _
    refine ⟨⟨symView_upd hw ?_, hp, hd, hl, hps, hms⟩, ?_⟩
    · rw [hms]; exact hB.motorStatus m _ _ _ hcmd
    · show some _ = some _
      rw [hms, hB.motor m _ _ _ hcmd]
  | appraise =>
    exact ⟨⟨symView_upd hw hc, hp, hd, hl, hps, hms⟩, rfl⟩
  | learnPercept p i =>
    refine ⟨⟨hw, hp, hd, hl, ?_, hms⟩, rfl⟩
    show upd s₁.ps p _ = upd s₂.ps p _
    rw [hps, hB.perceptLearn p (s₂.ps p) i s₁.wm s₂.wm hw]
  | learnMotor m =>
    have hcmd : syms (s₁.wm (Loc.motor m .command)) = syms (s₂.wm (Loc.motor m .command)) :=
      congrFun hw _
    refine ⟨⟨hw, hp, hd, hl, hps, ?_⟩, rfl⟩
    show upd s₁.ms m _ = upd s₂.ms m _
    rw [hms, hB.motor m (s₂.ms m) _ _ hcmd, hB.motorLearn m (s₂.ms m) _ _ _ hcmd]
  | cycle =>
    have hc' : symView (cycleWM A s₁.pm s₁.wm) = symView (cycleWM A s₂.pm s₂.wm) := hc
    refine ⟨⟨hc', hp, dm_upd hd (hB.record _ _ _ _ (hd σ.epi) hc'), ?_, hps, hms⟩, rfl⟩
    show some (symView s₁.wm, symView (cycleWM A s₁.pm s₁.wm)) =
      some (symView s₂.wm, symView (cycleWM A s₂.pm s₂.wm))
    rw [hw, hc']
  | compose =>
    cases h1 : s₁.lastCycle with
    | none =>
      cases h2 : s₂.lastCycle with
      | none => simp only [exec, h1, h2]; exact ⟨⟨hw, hp, hd, hl, hps, hms⟩, by trivial⟩
      | some e₂ => rw [h1, h2] at hl; cases hl
    | some e₁ =>
      cases h2 : s₂.lastCycle with
      | none => rw [h1, h2] at hl; cases hl
      | some e₂ =>
        rw [h1, h2] at hl
        simp only [exec, h1, h2]
        exact ⟨⟨hw, hB.compose _ _ _ _ hp hl, hd, hl, hps, hms⟩, by trivial⟩
  | rl =>
    cases h1 : s₁.lastCycle with
    | none =>
      cases h2 : s₂.lastCycle with
      | none => simp only [exec, h1, h2]; exact ⟨⟨hw, hp, hd, hl, hps, hms⟩, by trivial⟩
      | some e₂ => rw [h1, h2] at hl; cases hl
    | some e₁ =>
      cases h2 : s₂.lastCycle with
      | none => rw [h1, h2] at hl; cases hl
      | some e₂ =>
        simp only [exec, h1, h2]
        refine ⟨⟨hw, ?_, hd, ?_, hps, hms⟩, by trivial⟩
        · show pmSyms (A.rlTune s₁.pm e₁) = pmSyms (A.rlTune s₂.pm e₂)
          simp only [pmSyms]
          rw [A.rlTune_symbolic, A.rlTune_symbolic]; exact hp
        · first | exact hl | (rw [h1, h2] at hl; exact hl)
  | create d =>
    cases h1 : s₁.lastCycle with
    | none =>
      cases h2 : s₂.lastCycle with
      | none => simp only [exec, h1, h2]; exact ⟨⟨hw, hp, hd, hl, hps, hms⟩, by trivial⟩
      | some e₂ => rw [h1, h2] at hl; cases hl
    | some e₁ =>
      cases h2 : s₂.lastCycle with
      | none => rw [h1, h2] at hl; cases hl
      | some e₂ =>
        have hl' := hl
        rw [h1, h2] at hl'
        simp only [exec, h1, h2]
        exact ⟨⟨hw, hp, dm_upd hd (hB.declCreate d _ _ _ _ (hd d) hl'), hl', hps, hms⟩, by trivial⟩
  | tune d =>
    cases h1 : s₁.lastCycle with
    | none =>
      cases h2 : s₂.lastCycle with
      | none => simp only [exec, h1, h2]; exact ⟨⟨hw, hp, hd, hl, hps, hms⟩, by trivial⟩
      | some e₂ => rw [h1, h2] at hl; cases hl
    | some e₁ =>
      cases h2 : s₂.lastCycle with
      | none => rw [h1, h2] at hl; cases hl
      | some e₂ =>
        have hl' := hl
        rw [h1, h2] at hl'
        simp only [exec, h1, h2]
        refine ⟨⟨hw, hp, dm_upd hd ?_, hl', hps, hms⟩, by trivial⟩
        simp only [syms] at hd ⊢
        rw [A.declTune_symbolic, A.declTune_symbolic]; exact hd d
  | decay =>
    refine ⟨⟨?_, hp, ?_, hl, hps, hms⟩, rfl⟩
    · funext b
      show syms ((s₁.wm b).map (decayElemWM A)) = syms ((s₂.wm b).map (decayElemWM A))
      rw [syms_decay, syms_decay]; exact congrFun hw b
    · intro d
      show syms ((s₁.dm d).elems.map (decayElemDM A)) = syms ((s₂.dm d).elems.map (decayElemDM A))
      rw [syms_decayDM, syms_decayDM]; exact hd d
  | forgetWM b =>
    by_cases hb : b.archWritten = true
    · simp only [exec, hb, ite_true]; exact ⟨⟨hw, hp, hd, hl, hps, hms⟩, by trivial⟩
    · simp only [exec, hb]
      exact ⟨⟨symView_upd hw hc, hp, hd, hl, hps, hms⟩, rfl⟩
  | forgetDecl d =>
    exact ⟨⟨hw, hp, dm_upd hd hc, hl, hps, hms⟩, rfl⟩

/-! ## Whole runs -/

/-- **The limits of introspection.** Two minds that differ only in numeric metadata, and whose
four metadata channels (cycle outcome, retrieval, appraisal, forgetting) agree at every step,
stay symbolically identical over the whole run and produce the same actions. -/
theorem introspection_limit {A : Arch σ} (hB : Blind A) (ls : List (Label σ)) {s₁ s₂ : State σ}
    (h : Variant s₁ s₂) (hc : ChannelsAlong A ls s₁ s₂) :
    Variant (execAll A ls s₁).1 (execAll A ls s₂).1 ∧
    (execAll A ls s₁).2 = (execAll A ls s₂).2 := by
  induction ls generalizing s₁ s₂ with
  | nil => exact ⟨h, rfl⟩
  | cons l ls ih =>
    obtain ⟨hc1, hcs⟩ := hc
    obtain ⟨h1, ho⟩ := exec_variant hB l h hc1
    obtain ⟨h2, hos⟩ := ih h1 hcs
    exact ⟨h2, by simp [execAll, ho, hos]⟩

/-- **No report sees metadata.** Under the same conditions, every fact a rule could test
(any `MetaBlind` predicate on working memory) has the same truth value in both minds at the
end of the run; so does every rule condition of a well-formed procedural memory. -/
theorem report_cannot_see_metadata {A : Arch σ} (hB : Blind A) (ls : List (Label σ))
    {s₁ s₂ : State σ} (h : Variant s₁ s₂) (hc : ChannelsAlong A ls s₁ s₂)
    {c : WM σ → Prop} (hm : MetaBlind c) :
    c (execAll A ls s₁).1.wm ↔ c (execAll A ls s₂).1.wm :=
  hm _ _ (introspection_limit hB ls h hc).1.wm

/-- **Changing only the strength of memories changes nothing an agent can know, unless it
changes an outcome.** A special case of `introspection_limit`: start from one state and
change any numeric metadata in its working and declarative memories (`f`, `g`) and in its
rules (`u`). -/
def remeta (s : State σ) (f g : Elem σ → Meta σ) (u : Rule σ → Meta σ) : State σ :=
  { s with wm := fun b => (s.wm b).map (fun e => { e with «meta» := f e }),
           dm := fun d => ⟨(s.dm d).elems.map (fun e => { e with «meta» := g e })⟩,
           pm := s.pm.map (fun r => { r with «meta» := u r }) }

theorem remeta_variant (s : State σ) (f g : Elem σ → Meta σ) (u : Rule σ → Meta σ) :
    Variant s (remeta s f g u) := by
  refine ⟨?_, ?_, ?_, rfl, rfl, rfl⟩
  · funext b; simp [symView, remeta]
  · simp [pmSyms, remeta, Function.comp_def]
  · intro d; simp [syms, remeta]

theorem introspection_limit_remeta {A : Arch σ} (hB : Blind A) (ls : List (Label σ))
    (s : State σ) (f g : Elem σ → Meta σ) (u : Rule σ → Meta σ)
    (hc : ChannelsAlong A ls s (remeta s f g u)) {c : WM σ → Prop} (hm : MetaBlind c) :
    (c (execAll A ls s).1.wm ↔ c (execAll A ls (remeta s f g u)).1.wm) ∧
    (execAll A ls s).2 = (execAll A ls (remeta s f g u)).2 :=
  ⟨report_cannot_see_metadata hB ls (remeta_variant s f g u) hc hm,
   (introspection_limit hB ls (remeta_variant s f g u) hc).2⟩

/-! ## The assumptions can be met -/

/-- The toy architecture of `CMC/Meta.lean` meets `Blind`. -/
theorem Toy.blind : Blind Toy.arch where
  perceive := by intro _ _ _ _ _ _; exact ⟨rfl, rfl⟩
  perceptLearn := by intro _ _ _ _ _ _; rfl
  motor := by
    intro _ _ c₁ c₂ h
    show c₁.map (fun e => e.rel.pred) = c₂.map (fun e => e.rel.pred)
    have : c₁.map (fun e => e.rel.pred) = (syms c₁).map Rel.pred := by simp [syms]
    rw [this, h]; simp [syms]
  motorStatus := by intro _ _ _ _ _; rfl
  motorLearn := by intro _ _ _ _ _ _; rfl
  record := by
    intro dm₁ dm₂ w₁ w₂ hd hw
    show syms (dm₁.elems ++ w₁ .region) = syms (dm₂.elems ++ w₂ .region)
    simp only [syms, List.map_append] at hd ⊢
    rw [hd]; exact congrArg _ (congrFun hw .region)
  compose := by intro _ _ _ _ h _; exact h
  declCreate := by intro _ _ _ _ _ h _; exact h

/-! ## The channels are real

Metadata does reach the symbolic level through the channels. In a variant of the toy
architecture whose retrieval prefers elements of frequency 1, two minds that differ only in
that metadata retrieve different things, and from then on they differ symbolically: memory
strength affects what comes to mind, and the agent knows only what came to mind. -/

/-- The toy architecture with retrieval by frequency (metadata kind 1). -/
def strengthArch : Arch Toy.σ₀ :=
  { Toy.arch with
    retrieve := fun _ dm _ => ((dm.elems.filter fun e => decide (e.«meta» 1 = some 1)).take 1, []) }

/-- An element with frequency 1. -/
def strongElem : Elem Toy.σ₀ := ⟨⟨7, []⟩, fun k => if k = 1 then some 1 else none⟩

/-- A mind whose declarative memories hold that element. -/
def strongMind : State Toy.σ₀ :=
  { wm := fun _ => [], pm := [], dm := fun _ => ⟨[strongElem]⟩, lastCycle := none,
    ps := fun _ => (), ms := fun _ => () }

/-- The same mind with every metadata value of its declarative memories erased. -/
def weakMind : State Toy.σ₀ := remeta strongMind (fun e => e.«meta») (fun _ _ => none) (fun r => r.«meta»)

theorem strong_weak_variant : Variant strongMind weakMind := remeta_variant _ _ _ _

theorem channel_carries_metadata :
    ¬ Variant (exec strengthArch (.retrieve false) strongMind).1
              (exec strengthArch (.retrieve false) weakMind).1 := by
  intro h
  have := congrArg List.length (congrFun h.wm (Loc.decl false .result))
  simp [symView, exec, strengthArch, strongMind, weakMind, remeta, strongElem, upd] at this

end Introspection
end CMC.Meta
