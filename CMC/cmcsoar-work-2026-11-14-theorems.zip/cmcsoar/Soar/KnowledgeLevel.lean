import Soar.Prefs

/-!
# Symbolic knowledge decides; graded values only break the ties it leaves

Soar's decision procedure combines two kinds of knowledge. Symbolic preferences (acceptable,
reject, prohibit, better, worse, best, worst, indifferent) say what is possible, what is
ruled out and how options compare. A selection policy — random choice, or exploration driven
by learned numeric values (reinforcement learning) — picks among the options that remain.
In `resolve` that policy is the parameter `choose`.

**Theorem (`policy_only_among_equals`).** For any preferences and any two selection policies,
the decisions are identical, or both are made by the policies picking from one and the same
set of at least two options, each of which

* is acceptable and neither rejected nor prohibited,
* is not known to be worse than any other in the set, and
* is marked indifferent by the agent's preferences: by a unary indifferent preference, by a
  numeric-indifferent preference, or by binary indifferent preferences with every other option.

**Corollary (`impasse_independent_of_policy`).** Whether an impasse arises, of which type and
over which options, never depends on the selection policy: an impasse is decided by
symbolic knowledge alone.

**What it means.** In Soar, subsymbolic influences — chance, or values learned from reward —
act only inside the space that symbolic knowledge leaves open, and only where that knowledge
marks the options indifferent. They never override a symbolic comparison. One qualification:
a numeric-indifferent preference itself marks its operator as indifferent, so a rule that
carries a learned value does contribute knowledge by being there; only the size of its value
is irrelevant to whether and how an impasse arises (`resolve_revalue`). When knowledge is
missing or contradictory (a tie among options not marked indifferent, a conflict, nothing
acceptable), the result is an impasse, whatever the policy and whatever the values. This is the knowledge-level
reading of Soar's decision: a choice is made by knowledge, by declared indifference, or not
at all. It gives a precise sense to the claim that graded, learned values tune behavior
without being able to make the agent act against what it knows.
-/

namespace Soar

/-- `d₁` and `d₂` are the same decision, or both are the two policies' picks from one set of at
least two options that the knowledge leaves equal: acceptable and not rejected or prohibited,
none known worse than another, and all marked indifferent. -/
def OnlyAmongEquals (ps : List Pref) (c₁ c₂ : List Sym → Sym) (d₁ d₂ : Decision) : Prop :=
  d₁ = d₂ ∨ ∃ cs : List Sym, 2 ≤ cs.length ∧ (∀ o ∈ cs, o ∈ afterReject ps) ∧
    (∀ o ∈ cs, ∀ o₂ ∈ cs, worseThan ps o o₂ = false) ∧ mutuallyIndifferent ps cs = true ∧
    d₁ = .winner (c₁ cs) ∧ d₂ = .winner (c₂ cs)

section
variable {ps : List Pref} {c₁ c₂ : List Sym → Sym}

theorem afterBetterWorse_notWorse {c : List Sym} {o : Sym} (h : o ∈ afterBetterWorse ps c) :
    ∀ o₂ ∈ c, worseThan ps o o₂ = false := by
  intro o₂ ho₂
  simp only [afterBetterWorse, List.mem_filter, Bool.not_eq_true', List.any_eq_false] at h
  have := h.2 o₂ ho₂
  simpa using this

theorem stage5_equals {c : List Sym} (hs : ∀ o ∈ c, o ∈ afterReject ps)
    (hn : ∀ o ∈ c, ∀ o₂ ∈ c, worseThan ps o o₂ = false) :
    OnlyAmongEquals ps c₁ c₂ (stage5 c₁ ps c) (stage5 c₂ ps c) := by
  match c with
  | [] => exact Or.inl rfl
  | [o] => exact Or.inl rfl
  | a :: b :: rest =>
    by_cases hm : mutuallyIndifferent ps (a :: b :: rest) = true
    · refine Or.inr ⟨a :: b :: rest, by simp, hs, hn, hm, ?_, ?_⟩ <;> simp [stage5, hm]
    · exact Or.inl (by simp [stage5, hm])

theorem stage4_equals {c : List Sym} (hs : ∀ o ∈ c, o ∈ afterReject ps)
    (hn : ∀ o ∈ c, ∀ o₂ ∈ c, worseThan ps o o₂ = false) :
    OnlyAmongEquals ps c₁ c₂ (stage4 c₁ ps c) (stage4 c₂ ps c) := by
  match c with
  | [] => exact Or.inl rfl
  | [o] => exact Or.inl rfl
  | a :: b :: rest =>
    simp only [stage4]
    exact stage5_equals (fun o h => hs o (afterWorst_sub h))
      (fun o h o₂ h₂ => hn o (afterWorst_sub h) o₂ (afterWorst_sub h₂))

theorem stage3_equals : OnlyAmongEquals ps c₁ c₂ (stage3 c₁ ps (afterReject ps)) (stage3 c₂ ps (afterReject ps)) := by
  simp only [stage3]
  match h : afterBetterWorse ps (afterReject ps) with
  | [] => exact Or.inl rfl
  | [o] => exact Or.inl rfl
  | a :: b :: rest =>
    have hin : ∀ o ∈ a :: b :: rest, o ∈ afterBetterWorse ps (afterReject ps) := by rw [h]; exact fun _ x => x
    apply stage4_equals
    · intro o ho
      exact afterBetterWorse_sub (hin o (afterBest_sub ho))
    · intro o ho o₂ ho₂
      exact afterBetterWorse_notWorse (hin o (afterBest_sub ho)) o₂
        (afterBetterWorse_sub (hin o₂ (afterBest_sub ho₂)))

theorem stage2_equals : OnlyAmongEquals ps c₁ c₂ (stage2 c₁ ps) (stage2 c₂ ps) := by
  unfold stage2
  match h : afterReject ps with
  | [] => exact Or.inl rfl
  | [o] => exact Or.inl rfl
  | a :: b :: rest =>
    have := stage3_equals (ps := ps) (c₁ := c₁) (c₂ := c₂)
    rw [h] at this
    exact this
end

/-- **Symbolic knowledge decides; the policy only breaks ties it declares.** For any
preferences and any two selection policies, the decisions are the same, or both are the
policies' picks from one set of at least two options that the knowledge leaves equal. -/
theorem policy_only_among_equals (ps : List Pref) (c₁ c₂ : List Sym → Sym) :
    OnlyAmongEquals ps c₁ c₂ (resolve c₁ ps) (resolve c₂ ps) := by
  unfold resolve
  match h : required ps with
  | [o] => exact Or.inl rfl
  | [] => exact stage2_equals
  | a :: b :: rest => exact Or.inl rfl

/-- **Impasses are decided by knowledge alone.** Whether an impasse arises, its type and the
options involved do not depend on the selection policy. -/
theorem impasse_independent_of_policy {ps : List Pref} {c₁ : List Sym → Sym} (c₂ : List Sym → Sym)
    {k : Impasse} {items : List Sym} (h : resolve c₁ ps = .impasse k items) :
    resolve c₂ ps = .impasse k items := by
  rcases policy_only_among_equals ps c₁ c₂ with he | ⟨cs, -, -, -, -, h1, -⟩
  · rw [← he]; exact h
  · rw [h] at h1; cases h1

/-- **A winner the policies disagree on comes from declared equals.** If two policies select
different operators, both come from one set of options the agent's knowledge marks as equally
good, and none of which it knows to be worse than another. -/
theorem disagreement_only_among_equals {ps : List Pref} {c₁ c₂ : List Sym → Sym} {o₁ o₂ : Sym}
    (h₁ : resolve c₁ ps = .winner o₁) (h₂ : resolve c₂ ps = .winner o₂) (hne : o₁ ≠ o₂) :
    ∃ cs : List Sym, 2 ≤ cs.length ∧ (∀ o ∈ cs, o ∈ afterReject ps) ∧
      (∀ o ∈ cs, ∀ o' ∈ cs, worseThan ps o o' = false) ∧ mutuallyIndifferent ps cs = true ∧
      o₁ = c₁ cs ∧ o₂ = c₂ cs := by
  rcases policy_only_among_equals ps c₁ c₂ with he | ⟨cs, hl, hs, hn, hm, e1, e2⟩
  · rw [h₁, h₂] at he; cases he; exact absurd rfl hne
  · rw [h₁] at e1; rw [h₂] at e2; cases e1; cases e2
    exact ⟨cs, hl, hs, hn, hm, rfl, rfl⟩

/-! ## The size of a numeric value never matters to the symbolic outcome

A numeric-indifferent preference marks its operator as indifferent (`mutuallyIndifferent`), so
the *presence* of such a preference is knowledge the decision uses: a rule that carries a
learned value can turn a tie into a choice. Its *value* is not: changing every numeric value
changes no decision made with a given policy. -/

/-- Replace the numeric value of every preference. -/
def revalue (f : Pref → Option Sym) (ps : List Pref) : List Pref := ps.map fun p => { p with num := f p }

theorem has_revalue (f : Pref → Option Sym) (ps : List Pref) (k : PrefKind) (o : Sym) :
    has (revalue f ps) k o = has ps k o := by
  simp [has, revalue, List.any_map, Function.comp_def]

theorem hasBin_revalue (f : Pref → Option Sym) (ps : List Pref) (k : PrefKind) (o o₂ : Sym) :
    hasBin (revalue f ps) k o o₂ = hasBin ps k o o₂ := by
  simp [hasBin, revalue, List.any_map, Function.comp_def]

theorem opsOf_revalue (f : Pref → Option Sym) (ps : List Pref) (k : PrefKind) :
    opsOf (revalue f ps) k = opsOf ps k := by
  simp [opsOf, revalue, List.filter_map, Function.comp_def]

/-- **Values do not decide.** With the selection policy fixed, changing the numeric values of
the preferences changes nothing: the same winner or the same impasse. -/
theorem resolve_revalue (f : Pref → Option Sym) (choose : List Sym → Sym) (ps : List Pref) :
    resolve choose (revalue f ps) = resolve choose ps := by
  have hh : has (revalue f ps) = has ps := by funext k o; exact has_revalue f ps k o
  have hb : hasBin (revalue f ps) = hasBin ps := by funext k o o₂; exact hasBin_revalue f ps k o o₂
  have ho : opsOf (revalue f ps) = opsOf ps := by funext k; exact opsOf_revalue f ps k
  have hw : worseThan (revalue f ps) = worseThan ps := by funext o o₂; simp [worseThan, hb]
  have hm : mutuallyIndifferent (revalue f ps) = mutuallyIndifferent ps := by
    funext cs; simp [mutuallyIndifferent, hh, hb]
  have h5 : stage5 choose (revalue f ps) = stage5 choose ps := by funext c; simp [stage5, hm]
  have hwo : afterWorst (revalue f ps) = afterWorst ps := by funext c; simp [afterWorst, hh]
  have h4 : stage4 choose (revalue f ps) = stage4 choose ps := by funext c; simp [stage4, h5, hwo]
  have hbe : afterBest (revalue f ps) = afterBest ps := by funext c; simp [afterBest, hh]
  have hbw : afterBetterWorse (revalue f ps) = afterBetterWorse ps := by
    funext c; simp [afterBetterWorse, hw]
  have h3 : stage3 choose (revalue f ps) = stage3 choose ps := by funext c; simp [stage3, h4, hbe, hbw]
  have hr : afterReject (revalue f ps) = afterReject ps := by simp [afterReject, acceptables, hh, ho]
  have h2 : stage2 choose (revalue f ps) = stage2 choose ps := by simp [stage2, h3, hr]
  simp [resolve, required, ho, hh, h2]

end Soar
