# CLAUDE.md — working on Soar on CMC Lean

A Lean 4 specification of the Common Model of Cognition (CMC/) with Soar 9.6 built on it (Soar/),
and `soar-lean`, a program that runs `.soar` agents on the specification so that it can be
compared with the Soar 9.6.5 release. Read README.md for the layout and STATUS.md for where
things stand. The report, doc/Soar-on-CMC-Lean.pdf, explains the design (Section 5 for running and
testing, Section 10 for the ad hoc places, Appendix B for the user guide).

## Build

- Toolchain: Lean 4.35.0, pinned in `lean-toolchain`; elan installs it on first use. Core library
  only; no Mathlib.
- `lake build` checks every definition and proof. `lake build soar-lean` builds the program at
  `.lake/build/bin/soar-lean`. A clean build of both takes about three minutes.
- No `sorry`, no new axioms: `#print axioms` on any theorem lists only `propext`,
  `Classical.choice` and `Quot.sound`. Keep it that way.

## Compare with Soar 9.6.5

- `pip install soar-sml==9.6.5` (Python bindings for the release; see doc/HARNESS.md).
- `python3 tools/diff.py tests/<set> <options>` runs every program of a set in both and compares;
  each set needs particular options (`tools/run_all.sh` lists them). `GROUP=A tools/run_all.sh`
  runs one group. The whole regression takes under an hour with three groups in parallel on two
  cores (timings in doc/HARNESS.md).
- `SOAR_LEAN=/path/to/binary` makes the tools use another build. `ONLY=name` limits diff.py to
  matching files.
- A program `X.soar` with `X.pre.soar` and `X.pre.n` beside it is run in two agents (the first
  leaves its semantic or episodic store in a file, the second opens it); see doc/HARNESS.md.
- When a program differs:
  - `tools/firstdiff.py` finds the first decision that differs.
  - `tools/firecmp.py agent.soar N` finds the first rule firing that differs.
  - `tools/ttcmp.py agent.soar N` compares every element with its timetag (`TTRANGE=lo-hi` to
    print a range).
  - `soar-lean --wma-debug F` prints activation histories as Soar's `wma --history`;
    `--smem-debug F`, `--rete-debug F` and `--watch` print the other internals.
  - In Soar (through soar_sml): `wma --history <timetag>`, `print --internal`, `trace`,
    `preferences <id> <attr> --names`.
- doc/DIFFERENCES.md records how each remaining difference was diagnosed.

## Conventions

- Every definition that models Soar names the Soar 9.6.5 function(s) it follows in its docstring
  (for example "Soar 9.6.5 `decide_non_context_slot`"). The map doc/Soar-Lean-map.xlsx is drawn
  from these docstrings; keep them accurate when changing code.
- Mark simplifications in docstrings with `SIMPLIFIED:` and gaps with `NOT FORMALIZED:` or
  `NOT MODELED:`.
- Where Soar's behaviour is a defect, the model reproduces it when tests depend on it and says so
  in the docstring; the defect is listed in doc/Soar-9.6.5-Kernel-Defects.docx and the map's
  Kernel defects sheet.
- After a change: `lake build`, then the regression groups the change can affect; update
  doc/results.json and rebuild the report with
  `NODE_PATH=$(npm root -g) node doc/build_soar.js doc/Soar-on-CMC-Lean.docx doc/results.json`
  (run in doc/).

## Where things are

- Soar/Cycle.lean — the decision cycle, preference memory, memories' interfaces, WMA, RL hooks.
- Soar/Match.lean, Soar/MatchComplete.lean, Soar/JoinOrder.lean — the matcher, its soundness and
  completeness, and the join order.
- Soar/Rete.lean — Soar's Rete: the matcher
  and the order in which matches fire.
- Soar/Chunk.lean — chunking. Soar/SMem.lean, Soar/EpMem.lean, Soar/WMA.lean — the memories;
  Soar/Store.lean — writing and reading their files (`database file`).
- Soar/Props.lean, Soar/Seriality.lean, Soar/SMemProps.lean, Soar/EpMemProps.lean, Soar/OrderSafe.lean,
  Soar/ReorderProps.lean — theorems.
- tests/ — about 5,200 programs; `.n` files give the number of decisions.
- tests/agentlib/ — the agent library: every agent given for testing, versioned (README.md,
  CATALOG.md); `tools/agentlib.py` maintains it and `GROUP=L tools/run_all.sh` compares it.
- bugs/ — programs that show Soar 9.6.5 defects.
- tests/mapdiff/ — one program per difference found by the line-by-line review of the map (README.txt
  lists each set's options).
