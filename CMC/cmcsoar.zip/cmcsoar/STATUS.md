# Status — October 31, 2026

A Lean 4 specification of the Common Model of Cognition (CMC) and of Soar 9.6 built on it,
with an executable model (`soar-lean`) checked against the Soar 9.6.5 release. The report,
doc/Soar-on-CMC-Lean.pdf, is the main document; this file is a short summary.

## What is covered

- The decision cycle: preference memory, elaboration loops, i- and o-support, impasses and
  substates, results, the goal dependency set, input and output.
- Chunking (explanation-based learning).
- Reinforcement learning, including Q-learning, eligibility traces, GQ(λ) and templates.
- Exploration policies and Soar's random-number generator, bit for bit.
- Semantic memory, including base-level and spreading activation.
- Episodic memory.
- Semantic and episodic stores kept in files between agents (`database file`, `path`,
  `append`; `smem --backup`, `--clear`, `--init`), as Soar 9.6.5 reopens its databases.
- Working-memory activation and forgetting.
- The right-hand-side function library.
- Soar's Rete: the order in which matches fire and retract, and Soar's timetags. The model of
  the Rete is also the matcher, for all rules (long-term-identifier tests included, since November 1).

Out of scope by decision: the explainer and the spatial-visual system. Brought back into scope
on October 31 and done the same day: the memory databases on disk, and rules made from RL
templates while chunking.

## Evidence

- **Proofs.** `lake build` checks 618 theorems (609 about Soar, 9 for the CMC backbone),
  with no unproved steps and only Lean's standard axioms, also in the compiled program (its
  hash-table lookup is proved equal to the matcher it stands for). Besides properties of the
  cycle and the memories:
  - the matcher is proved sound and complete for positive conditions, negations and negated
    conjunctions (inner negations to any depth, with the variables of an inner negation local to it), and the order of positive patterns is proved
    not to change the matches (Soar/MatchComplete.lean);
  - the join order returns the rule's own conditions, reordered, and exactly a permutation when
    no relational test between variables has to move; a moved test keeps its meaning between
    numbers and between identifiers, but not between values of different types, in Soar too
    (kernel defect 6) (Soar/JoinOrder.lean); and, when every relational test between variables
    compares values of one kind (and the patterns have no `@` test), the positive patterns of the
    join order hold under the same bindings as the rule's own and the matcher finds the same
    instantiations (`joinOrder_posSat`, `joinOrder_matches`, `joinOrder_matches_rev`,
    Soar/JoinOrderSem.lean);
  - the join order loses no match when each condition's tests need only variables bound before it
    (`joinOrder_safe`, `joinOrder_matches'`, Soar/OrderSafe.lean), which cannot be dropped:
    `joinOrder_loses_matches` is a rule for which it does; and Soar's reorderer, a total function,
    places every positive condition exactly once (`order_perm`, `soarOrder_idx_perm`,
    Soar/ReorderProps.lean);
  - `reach` (working memory's link to a state) returns exactly the identifiers reachable from
    the roots (`mem_reach_iff`, Soar/ReachProps.lean);
  - from the initial state, every state has at most one selected operator after any number of
    decision cycles (Soar/Seriality.lean).

  The theorems are properties of the model; they do not prove that the model is equivalent to
  Soar 9.6.5.
- **Comparison with Soar 9.6.5.** About 5,200 programs in tests/ plus the agent library, compared with
  `tools/run_all.sh` (see the README). Hand-written programs, generated programs and the Soar
  repository's own test agents match in decisions and final working memory, and where relevant
  in learned rules, learned values, memory stores and activations. Every set that is also run
  without Soar's choices replayed matches that way too. Full regression November 3 (afternoon): 5,715 of 5,718 match;
  the 3 that differ are those below (two episodic programs that differ from run to run matched
  this time).
- **Agent library** (tests/agentlib, added November 2):
  - **Contents:** every agent given for testing, 824 versions of 596 agents from 14 zips: 813
    received (deduplicated by content and numbered V1, V2, … in the order received) and 11
    corrected versions (each a new version; the received one is kept). 45 versions are Soar's
    default libraries, sourced by agents rather than run alone.
  - **CATALOG.md:** lists where each copy came from, how it runs in Soar, and a diagnosis where
    one was made.
  - **Comparison:** `GROUP=L tools/run_all.sh` compares the 747 versions that run on their own,
    at most 100 decisions each (results.txt; the 16 saved RL value tables with 5,000–68,000
    rules are in runs-big/).
  - **November 3 results (complete):** 603 of the 614 that run in both match; 133 have a load
    error in Soar itself. The earlier figure (497 of 515) was incomplete: the rule comparer
    crashed on a quoted `|\||` in kenken and took down the rest of its shard, so 147 versions
    had never been compared. The comparer is fixed.
  - **The 11 that differ, all known or not modeled:** kernel defect 28 in four RL-template
    copies; AlphabetAgentAllOn; SVS; `(cmd stop-soar)` and `:interrupt`, which stop a run in a
    way soar-lean does not model; the Bug510 chunk loop; and two that time out in soar-lean
    (ToH_Recursive, taxi-rl). graph-search-smem, whose `smem --add` numbering depends on memory
    addresses, matched in this run.
  - **What it found and fixed:**
    - model defects in chunking: identifier promotion stopping early; relational tests on an
      element with no equality test (local and superstate conditions); duplicate keys for
      empty negated tests; rules learned mid-pass not firing in the same pass, with their
      support from the p-node's earlier matches; state tests only on root state variables;
      literalization of values made by unevaluable functions; the learned rule's own
      instantiation;
    - in justifications and the goal dependency set: negated conditions on superstate
      identifiers; superstate elements reached through local elements already gone; operator
      proposals of intermediate states for results two levels up;
    - in replay: choices drawing on the random-number generator;
    - in RL templates: the letters of identifier variables, and duplicate detection in stored
      order;
    - parser gaps: trailing comments on setting lines, dashed words as function arguments,
      number lexing (`^2.<< 2 >>.h`, `2.5.`), `(state <s>)` with no attribute test, two equality
      tests in one conjunction, a failed redefinition of a rule, and five earlier ones;
    - six harness errors;
    - one new Soar crash, kernel defect 33 (bugs/chunk-computed-numeric-pref.soar);
    - soar-lean's run time grows faster than linearly in long runs (partly fixed).
- **Remaining differences** (report Section 2; doc/DIFFERENCES.md), none of them in the
  decision cycle, all from Soar's undefined or address-dependent behaviour:
  - Three episodic programs (two of them matching or not from run to run): Soar tries
    graph-match mappings in memory-address order.
  - One semantic-memory test agent (AlphabetAgentAllOn), and 9 of 30 edge-updating
    programs (generated, not in tests/): Soar reads freed or out-of-bounds memory.
  - One of the 11 Soar-book blocks-world agents (tests/bwbook, added November 2): a template
    rule's variables collide in Soar through a reused identifier address (kernel defect 28).

## Findings

- **Soar 9.6.5 kernel:** 33 numbered defects across nine modules.
  doc/Soar-9.6.5-Kernel-Defects.docx gives the source location, cause and a recommended
  fix for each. The fixes are untested sketches. bugs/ has programs that show the main ones.
- **Soar manual:** 43 places where it is wrong, silent or ambiguous (report Section 11).
- **The CMC:** five findings (report Section 13).

## Not yet done

- **Proofs:** the chunking computation; the same preservation for negations and for Soar's
  reorderer (which in the model affects only chunking), and that `joinOrder` yields a safe order.
- **The ad hoc places** listed in report Section 10, among them justifications in the Rete
  model (probed: 300 programs, no effect), Soar's batches of working-memory changes (probed: 450
  programs; one real difference found and fixed, the order of semantic-memory results).
  Long-term-identifier tests are now evaluated in the network (done November 1).
- **The map spreadsheet** (doc/Soar-Lean-map.xlsx): six areas reviewed line by line against
  Soar (126 of 607 definitions: 71 agree, 44 differ, 11 are data types; six right-hand-side
  differences fixed, most parser and syntax differences not yet confirmed by runs); the other
  areas not yet.

The plan is in doc/Soar-on-CMC-Lean-Remaining-Work.docx; a code review for simplifications and
optimizations (October 31) is in doc/Soar-on-CMC-Lean-Code-Review.docx, with the five
reviewers' reports in doc/review/. Done from the review (October 31): the speed items S1, S2,
S4–S6, S7, S8–S12, S14–S19 (hash sets and maps beside the lists, `dedupFirst`, `ttMap` with
`ttMap_getD_eq_ttOf`, the empty-list short-circuits), P1 (`Conform.cmcStep_pst` and
`runCMC_pst`: a CMC cycle of the Soar instance is `St.cycle`, via `St.cycleElab`, `St.cycleDec`
and `St.cycleApply`), the stale files (Soar/Examples.lean, Fuzz*.lean and their outputs), and
part of the dead code and docstring list. Also done (October 31; the full regression after the last change to the executable shows only the known differences): S3, S13, S20–S28 (S25 includes the `learn` accumulators and hash-based union-find); the dead parameters `Goal.rlQ`, `_deselected`, `_pre`, `isFirst`; from P2, the `foldl_rel` lemma (replacing seven fold inductions), the merged `decideImpasse` lemmas, the shared `stage2_impasse` lemma for the three impasse-cause theorems, the `St.Same` relation, and the move of the reinforcement-learning, template-rule and tie-picking lemmas from Cycle.lean to Props.lean; the merged `STest` and `eqOf` duplicates; two docstring fixes. Later the same day: the remaining fold inductions in SMemProps and EpMemProps now use `foldl_rel`; `Pat.binds` is merged into `Pat.eqVars`; `symRank` is an array and `Rete.names` a hash set; `keepEdges` is linear (a hash map of the new rows) instead of removed through `calcSpread_content`, which is not proved; `curMatches_off` and `matchConds_neg_eq_ncc` are proved; docstrings in SMem, Chunk and EpMem fixed; `NegTree.holds` is structural (mutual with `NegTree.noneHold`) instead of `partial`; with it, matcher completeness is proved for negated conjunctions nested to any depth (`tree_complete`, `tree_clear`). Then `rlUpdate_frame` (one lemma for what a reinforcement-learning update leaves alone) and `fireMatch_eq_fireOneBase`; the P3 equalities `deepCopy_eq`, `dedupFirst_eq`, `cycSub_eq` and `ttMap_getD_eq_ttOf` already existed. The code review is closed (November 1): every item is done or closed with its reason in doc/Soar-on-CMC-Lean-Code-Review.docx (Closure). Also then: `sync_idem` (SyncProps), `reteSupport_nil` (SupportProps), `calcSpread` proved through its stages (`calcSpread_keeps`; `keepEdges` removed), the reinforcement-learning tables merged into `rlTab`, `upd` once in CMC/Util.lean, strength notes on `quiescence_ie/pe` and `cycle_independent_of_decl`. Also: `mem_reach_iff` and the preservation of matches by the join order (`joinOrder_matches`) are proved. Developer notes: CLAUDE.md,
doc/HARNESS.md (versions and run times) and doc/DIFFERENCES.md (diagnoses).
