import CMC.Proc
import Soar.Cycle
/-!
# Soar as an instance of the CMC with an expanded procedural module

This file builds a `CMC.Proc.PArch` from the executable Soar semantics and discharges its
obligations. It fixes how Soar's working memory maps onto the CMC's locations:

* elements on the input link → perceptual buffer content;
* rule-created elements under the output link → motor command;
* architecture-created state and substate structures → procedural process data (DECIDED
  2026-10-28 for substates; the top state's initial structures are treated the same way);
* everything else, including operator selections → the region.

OPEN: the selected-operator augmentation `(<s> ^operator <o>)` is architecture-created and
cannot be removed by rules, but it was not classed as procedural process data; it is placed
in the region here.

DECIDED (Laird, 2026-10-29): leave this as is for now and decide how to map semantic and
episodic memory together once episodic memory is formalized.

OPEN (2026-10-29): semantic memory is formalized (`Soar.SMem`, `St.smemPass`), but its store
is held, for now, in the procedural module state, and its command and result structures are
placed in the region; the CMC's declarative module, buffers and `retrieve` step are unused
(`DMem := Unit`). So the obligations hold, `PArch.Strict` included, but they say nothing about
semantic memory. Mapping Soar's semantic memory onto the CMC's declarative module needs a
decision: Soar stores after every elaboration cycle and retrieves at the end of the output
phase, inside one decision cycle, while the CMC's retrieval and learning are separate steps;
and rules can add to and remove from Soar's retrieval results, which the CMC protects.

DECIDED (Laird, 2026-10-29): keep the provisional mapping below for now. The preferred option,
deferred and kept for later, is to map semantic and episodic memory onto the CMC's single
declarative module as one module with two stores, with declarative steps at named points
inside the cycle, a buffer per state for each store, the protection of result areas weakened
only for the declarative result buffers (a recorded departure), and automatic (episodic) and
deliberate (semantic) declarative learning.

Provisional mapping (2026-10-29): episodic memory is now formalized
(`Soar.EpMem`, `St.epPass`) and is mapped provisionally in the same way: the episode store and
the encoder's bookkeeping are held in the procedural module state, and the `^epmem` command,
result and `^present-id` structures are placed in the region. The same two obstacles apply —
recording and retrieval happen inside the decision cycle (at the end of the output phase, or
after the decision phase with `phase selection`), and rules can change retrieved episodes.
One difference from semantic memory bears on the decision: episodic retrieval does not change
the store at all (not even metadata; `St.epState_store`), and recording never changes an
earlier episode (`EpDB.newEpisode_past`), so episodic memory satisfies the CMC's read-only
retrieval property more strictly than semantic memory does.

DECIDED (Laird, 2026-10-29, chunking): keep as is — rules learned by chunking are kept, like
reinforcement learning's values, in the procedural module state (`St.chunks`, with the
explanation records `St.xinsts`), and are matched together with production memory, so the
CMC's procedural learning step (`compose`) is the identity. CMC.Proc will be revised in one
major iteration once the functionality is complete.
-/

namespace Soar.Conform
open CMC.Meta CMC.Proc

/-- The CMC signature of Soar's core. -/
@[reducible] def σS : PSig where
  Sym := Soar.Sym
  Val := Int
  PMod := Unit
  MMod := Unit
  DMem := Unit
  Input := List WME
  PLearn := Unit
  MLearn := Unit
  Output := List WME
  MK := Fin 3
  utilityK := 0
  frequencyK := 1
  recencyK := 2
  epi := ()
  PM := List Production
  PState := St

/-- A working-memory element as a CMC element: the attribute is the relation, the identifier,
value and acceptable mark its arguments. No numeric metadata is exposed. -/
def enc (w : WME) : E σS :=
  ⟨⟨w.attr, [.id w.id, w.val, .str (if w.acc then "+" else ""), .int w.dup]⟩, fun _ => none⟩

def dec (e : E σS) : Option WME :=
  match e.rel.args with
  | [.id i, v, .str a, .int d] => some { id := i, attr := e.rel.pred, val := v, acc := a == "+", dup := d.toNat }
  | _ => none

/-- Where a Soar working-memory element sits in the CMC's working memory. -/
def locate (s : St) (w : WME) : Lc σS :=
  if s.arch.contains w && !(isOpAttr w.attr && !w.acc) then Loc.procProcess
  else if s.input.contains w then Loc.percept () .content
  else if (reach s.wm [outputLink]).contains w.id then Loc.motor () .command
  else Loc.region

/-- The locations Soar's core manages. -/
def managed : Lc σS → Bool
  | .procProcess => true
  | .percept () .content => true
  | .motor () .command => true
  | .region => true
  | _ => false

/-- The CMC view of a Soar state, laid over `w` for the locations Soar does not manage. -/
def view (s : St) (w : W σS) : W σS := fun ℓ =>
  if managed ℓ then (s.wm.filter (fun x => locate s x == ℓ)).map enc else w ℓ

theorem view_unmanaged (s : St) (w : W σS) (ℓ : Lc σS) (h : managed ℓ = false) :
    view s w ℓ = w ℓ := by
  simp [view, h]

theorem archWritten_unmanaged (ℓ : Lc σS) (ha : ℓ.archWritten = true)
    (hℓ : ℓ ≠ Loc.procProcess) : managed ℓ = false := by
  cases ℓ with
  | percept p q => cases q <;> simp_all [Loc.archWritten, managed]
  | motor m q => cases q <;> simp_all [Loc.archWritten, managed]
  | decl d q => simp [managed]
  | procProcess => exact absurd rfl hℓ
  | wmProcess => rfl
  | region => simp [Loc.archWritten] at ha

/-- Map Soar's impasses onto the CMC's reasons for selection failure.

OPEN: the CMC has no separate constraint failure; it is mapped to conflict. -/
def failOf : Impasse → SelFail
  | .tie => .tie
  | .conflict => .conflict
  | .constraintFailure => .conflict
  | .stateNoChange => .noCandidates
  | .operatorNoChange => .noProgress

/-- Did the decision create a substate? Then the decision was an impasse, of this type.
(Selecting an operator never creates a substate; an impasse always does, or persists.) -/
def newImpasse (before after : St) : Option Impasse :=
  match after.goals.getLast? with
  | some g => if before.goals.any (·.id == g.id) then none else g.impasse.map (·.1)
  | none => none

theorem dec_enc (w : WME) : dec (enc w) = some w := by
  cases w with
  | mk i a v c d => cases c <;> simp [dec, enc]

/-- Soar's core as a CMC architecture. Each step runs the part of `St.cycle` that corresponds to it
(`St.cycleElab`, `St.cycleRest`), so that a CMC cycle is a Soar cycle (`cycle_pst`).
* `elaborate`: the input phase and the proposal phase (i-supported elaboration to
  quiescence). The input is the perceptual buffer's content, or the environment's if the buffer is
  empty.
* `select`: the decision phase, the application phase and the output phase; if the decision
  creates a substate, the impasse is the reason for failure, otherwise the act is the selection.
* `procReport`: the architecture's state and substate structures.
The agent's own limit on elaboration cycles (`St.maxElab`) is used. -/
def soarArch (env : Env := {}) (choose : List Sym → Sym := defaultChoose) :
    PArch σS where
  elaborate pm p w :=
    if p.halted || p.stopped then (w, p) else
    let inp := ((w (Loc.percept () .content)).filterMap dec)
    let st := p.cycleElab (if inp.isEmpty then env.input p.dc p.output else inp) pm choose p.maxElab
    (view st w, st)
  select pm p w :=
    if p.halted || p.stopped then (.fail .noProgress, p) else
    let d := p.cycleRest pm choose p.maxElab
    match newImpasse p d with
    | some k => (.fail (failOf k), d)
    | none => (.act (fun w' => view d w'), d)
  procReport _ p w := view p w Loc.procProcess
  elaborate_keeps pm p w ℓ ha hℓ := by
    intro e he
    simp only
    split
    · exact he
    · dsimp only; rw [view_unmanaged _ _ _ (archWritten_unmanaged ℓ ha hℓ)]; exact he
  select_keeps pm p w a p' h ℓ ha hℓ := by
    intro e he
    simp only at h
    split at h
    · cases h
    · split at h
      · cases h
      · injection h with h1 h2
        injection h1 with h1
        subst h1
        dsimp only; rw [view_unmanaged _ _ _ (archWritten_unmanaged ℓ ha hℓ)]; exact he
  retrieve _ _ _ := ([], [])
  retrieveTouch _ dm _ := dm
  retrieveTouch_symbolic _ _ _ := rfl
  perceive _ _ i _ := (i.map enc, [])
  motor _ _ cmd := cmd.filterMap dec
  motorStatus _ _ _ := []
  appraise _ := []
  record dm _ := dm
  record_incremental _ _ _ h := h
  perceptLearn _ l _ _ := l
  motorLearn _ l _ _ := l
  -- learned rules are kept in procedural module state (`St.chunks`; DECIDED, above)
  compose pm _ := pm
  -- Soar's RL updates happen inside the decision; learned values are kept in procedural
  -- module state (`St.rlTab`), so the CMC's separate tuning step is the identity
  -- (DECIDED 2026-10-29, Laird; to be revisited with chunking).
  rlTune pm _ := pm
  declCreate _ dm _ := dm
  declTune _ dm _ := dm
  declTune_symbolic _ _ _ := rfl
  declCreate_incremental _ _ _ _ h := h
  decayWM := id
  decayDM := id
  forgettable _ := false

/-- In the core (no semantic memory), Soar also meets the strict requirement. -/
theorem soar_core_strict (env : Env) (choose : List Sym → Sym) :
    (soarArch env choose).Strict := by
  intro pm p w a p' h ℓ ha hℓ
  simp only [soarArch] at h
  split at h
  · cases h
  · split at h
    · cases h
    · injection h with h1 h2
      injection h1 with h1
      subst h1
      dsimp only; exact view_unmanaged _ _ _ (archWritten_unmanaged ℓ ha hℓ)

/-- The initial CMC state of a Soar agent. -/
def init (pm : List Production) : State σS :=
  { wm := view St.init (fun _ => []), pm := pm, pst := St.init, dm := fun _ => ⟨[]⟩,
    lastCycle := none, ps := fun _ => (), ms := fun _ => () }

/-- One cycle of the CMC with the Soar instance: the input phase is the CMC's perception of the
environment's input, then the cycle. -/
def cmcStep (env : Env) (s : State σS) : State σS :=
  let s := (CMC.Proc.exec (soarArch env) (.perceive () (env.input s.pst.dc s.pst.output)) s).1
  (CMC.Proc.exec (soarArch env) .cycle s).1

/-- `n` CMC cycles from `s`. -/
def cmcRun (env : Env) : Nat → State σS → State σS
  | 0, s => s
  | k + 1, s => cmcRun env k (cmcStep env s)

/-- Run `n` CMC cycles of the Soar instance. -/
def runCMC (pm : List Production) (n : Nat) (env : Env := {}) : State σS :=
  cmcRun env n (init pm)

/-- **A CMC cycle of the Soar instance is a Soar decision cycle.** The agent state after one cycle
is that of `St.cycle` (or the same state, if the agent has halted or stopped, as `St.run`
leaves it). -/
theorem cmcStep_pst (env : Env) (s : State σS) :
    (cmcStep env s).pst =
      if s.pst.halted || s.pst.stopped then s.pst
      else s.pst.cycle s.pm env defaultChoose s.pst.maxElab := by
  have hdec : ∀ l : List WME, List.filterMap dec (List.map enc l) = l := by
    intro l
    induction l with
    | nil => rfl
    | cons x l ih => simp [dec_enc, ih]
  simp only [cmcStep, CMC.Proc.exec, CMC.Proc.cycle, soarArch]
  rw [CMC.upd_other _ _ _ (by intro h; cases h), CMC.upd_same, hdec]
  simp only [ite_self]
  by_cases h : (s.pst.halted || s.pst.stopped) = true
  · simp [h]
  · simp only [h, Bool.false_eq_true, ite_false]
    unfold St.cycle St.cycleFrom
    simp only [h, Bool.false_eq_true, ite_false]
    generalize St.cycleElab s.pst (env.input s.pst.dc (St.output s.pst)) s.pm defaultChoose s.pst.maxElab = e
    by_cases h2 : (e.halted || e.stopped) = true
    · simp [h2]
    · simp only [h2, Bool.false_eq_true, ite_false]
      generalize St.cycleRest e s.pm defaultChoose e.maxElab = d
      cases newImpasse e d <;> rfl

theorem cmcStep_pm (env : Env) (s : State σS) : (cmcStep env s).pm = s.pm := by
  simp [cmcStep, CMC.Proc.exec]

/-- **Soar is the CMC instance.** Running `n` CMC cycles from `s` gives the agent state that
`St.runN` (Soar's run, without the reinforcement-learning update at a halt) gives. -/
theorem cmcRun_pst (env : Env) : ∀ (n : Nat) (s : State σS),
    (cmcRun env n s).pst = s.pst.runN s.pm env n defaultChoose
  | 0, s => rfl
  | k + 1, s => by
    simp only [cmcRun]
    rw [cmcRun_pst env k (cmcStep env s), cmcStep_pm, cmcStep_pst]
    by_cases h : (s.pst.halted || s.pst.stopped) = true
    · simp only [h, ite_true]
      rw [St.runN_stopped _ _ _ _ h, St.runN_stopped _ _ _ _ h]
    · simp [h, St.runN]

theorem runCMC_pst (pm : List Production) (n : Nat) (env : Env) :
    (runCMC pm n env).pst = St.init.runN pm env n :=
  cmcRun_pst env n (init pm)

end Soar.Conform
