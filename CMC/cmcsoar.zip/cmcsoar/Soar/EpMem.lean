import Soar.Syntax
import Std.Data.HashMap
/-!
# Soar 9.6 — episodic memory: the episode store, encoding and cue-based retrieval

Episodic memory ([Man] chapter 7) records snapshots of the top state's working memory
("episodes") and retrieves them by time, by temporal neighbour, or by a cue. How commands are
read from working memory and how results are placed there is in `Soar.Cycle`.

The store is modelled on Soar 9.6.5's SQLite schema and its incremental encoder (checked
against the 9.6.5 source, `episodic_memory/episodic_memory.cpp` and the working-memory hooks in
`decision_process/rete.cpp`, 2026-10-29), because a cue-based retrieval's result can depend on
the *identity* of stored structures over time, not only on each episode's content:

* identifiers become *nodes* and elements become *edges* (identifier-valued) or *constant
  edges*; each edge has the intervals of episodes in which it was present;
* an identifier keeps its node while it stays in working memory; a new identifier that
  appears where one left (same parent node, same attribute) re-uses that node, so a
  replaced but identical structure continues the old intervals;
* a cue-based retrieval walks backwards through time over the intervals of the edges that
  can match the cue (Soar's "interval search"), and the episodes it considers — and so which
  of two equally good episodes it returns, and whether a graph match is tried — depend on
  where those intervals begin and end.

SIMPLIFIED: Soar applies its encoding hooks at every working-memory change; here they are
applied once per decision cycle, in the output phase or, with `phase` set to `selection`,
after the decision, to the net change since the previous time (adds before removes, as Soar
does within a phase). An element added and removed between two such times is not seen. With `balance` below 1 a cue element's literal is weighted by its working-memory activation (`Soar.WMA`). `merge`
and `lazy-commit` are accepted and have no observable effect in Soar 9.6.5. An identifier edge
records the LTI of its value per interval, as Soar does: an open interval the LTI at opening, a
closed one the LTI at closing, so episodes before an identifier changed its LTI show the new one.
-/

namespace Soar

/-- Soar's `LLONG_MAX`, the time of an edge still present. -/
def epInf : Int := 4611686018427387904


/-- The value end of a stored edge: a node (an identifier) or a constant. -/
inductive EVal where
  | node  : Nat → EVal
  | const : Sym → EVal
  deriving DecidableEq, Repr, Inhabited

/-- A stored edge — `epmem_wmes_identifier` or `epmem_wmes_constant` — with the episodes in
which it was present: closed intervals, and the start of an open one. Acceptable-preference
elements are stored with the attribute `operator*`. -/
structure EEdge where
  parent : Nat
  attr   : Sym
  child  : EVal
  closed : List (Nat × Nat) := []
  now    : Option Nat := none
  /-- The last episode it was present in (`epInf` while present); identifier edges only. -/
  lastEp : Int := epInf
  /-- The last thing done to it was to close an interval (Soar's `epmem_*_maxes`). -/
  maxed  : Bool := false
  /-- The LTI of its value for the open interval: the one it had when the interval opened
  (Soar's `epmem_wmes_identifier_now.lti_id`). -/
  lti    : Nat := 0
  /-- The LTI of each closed interval (in the order of `closed`): the one the value had when the
  interval closed (`epmem_wmes_identifier_range.lti_id`, `_point.lti_id`). -/
  closedLti : List Nat := []
  deriving Repr, Inhabited

def EEdge.at (e : EEdge) (t : Nat) : Bool :=
  (match e.now with | some s => decide (s ≤ t) | none => false) ||
    e.closed.any fun (a, b) => decide (a ≤ t) && decide (t ≤ b)

/-- The LTI of the value in episode `t`: that of the interval containing `t`. -/
def EEdge.ltiAt (e : EEdge) (t : Nat) : Nat :=
  let closedL := ((e.closed.zip e.closedLti).find? fun ((a, b), _) => decide (a ≤ t) && decide (t ≤ b)).map (·.2)
  match e.now with
  | some s => if s ≤ t then e.lti else closedL.getD 0
  | none => closedL.getD 0

inductive EpTrigger where
  | dc | output | none
  deriving DecidableEq, Repr, Inhabited

/-- The episodic store and the encoder's bookkeeping. Edge number `k` is at index `k - 1`;
node 0 is the top state. -/
structure EpDB where
  wcs : List EEdge := []
  wis : List EEdge := []
  /-- The number the next episode will get (episodes are 1, …, `time - 1`). -/
  time : Nat := 1
  connected : Bool := false
  /-- Identifiers with a node. -/
  known : Std.HashMap Nat Nat := {}
  /-- Encoded elements and their edges. -/
  enc : Std.HashMap WME Nat := {}
  /-- For each node, the encoded elements that have it as value (Soar's ref sets). -/
  refs : Std.HashMap Nat (List WME) := {}
  /-- Edges free for re-use, per parent node and attribute: (child node, edge). -/
  pools : List ((Nat × Sym) × List (Nat × Nat)) := []
  /-- Where each identifier edge returns to when its element goes. -/
  repl : Std.HashMap Nat ((Nat × Sym) × Nat) := {}
  nodeRem : List (Nat × Bool) := []
  edgeRem : List (Nat × Bool) := []
  /-- The LTI of the value of each identifier edge marked for closing, when it was removed. -/
  remLti : Std.HashMap Nat Nat := {}
  /-- Identifiers with a node that have new elements. -/
  adds : List Nat := []
  nextNode : Nat := 1
  /-- Working memory when the encoder last looked. -/
  prevWM : List WME := []
  exclusions : List Sym := [.str "epmem", .str "smem"]
  trigger : EpTrigger := .dc
  graphMatch : Bool := true
  /-- `graph-match-ordering`: `undefined` (Soar orders by memory address; here, the order the
  literals were made), `dfs` or `mcv`. -/
  gmOrder : String := "undefined"
  /-- `phase selection`: episodic memory runs after the decision phase instead of at the end of
  the output phase. -/
  phaseSel : Bool := false
  /-- `balance`: below 1, a cue element's literal is weighted by the element's working-memory
  activation instead of 1. -/
  balance : Float := 1
  /-- `force`: record (true) or skip (false) the next episode regardless of the trigger. -/
  force : Option Bool := none
  /-- Output-link elements seen by the `output` trigger. -/
  olSeen : List WME := []
  deriving Repr, Inhabited

namespace EpDB

def nodeOf (db : EpDB) (x : Nat) : Option Nat := db.known[x]?

def refsOf (db : EpDB) (n : Nat) : List WME := (db.refs[n]?).getD []

/-- The attribute an element is stored under. -/
def hashOf (w : WME) : Sym := if w.acc then .str "operator*" else w.attr

/-! ## Encoding hooks (Soar's `add_wme_to_rete` / `_epmem_remove_wme`) -/

def hookAdd (db : EpDB) (w : WME) : EpDB :=
  let db := match w.val with
    | .id x => match db.nodeOf x with
      | some n =>
        let rs := db.refsOf n
        if rs.contains w then db else { db with refs := Std.HashMap.insert db.refs n (rs ++ [w]) }
      | none => db
    | _ => db
  if (db.nodeOf w.id).isSome && !db.adds.contains w.id then { db with adds := db.adds ++ [w.id] } else db

/-- An element leaves: its edge is marked for closing, an identifier edge returns to its
pool, and an identifier no longer referenced loses its node (queued on `stack`). -/
def removeOne (ltiOf : Nat → Nat) (db : EpDB) (w : WME) (stack : List Nat) : EpDB × List Nat :=
  let e := db.enc[w]?
  match w.val with
  | .id x =>
    let db := match e with
      | some wi =>
        let db := { db with edgeRem := alSet db.edgeRem wi true, remLti := Std.HashMap.insert db.remLti wi (ltiOf x) }
        match db.repl[wi]? with
        | some (key, cn) =>
          { db with pools := alSet db.pools key ((cn, wi) :: (alGet db.pools key).getD []),
                    repl := Std.HashMap.erase db.repl wi }
        | none => db
      | none => db
    let (db, stack) := match db.nodeOf x with
      | some n =>
        let rs := db.refsOf n
        if rs.contains w then
          let rs' := rs.filter (· != w)
          let db := { db with refs := Std.HashMap.insert db.refs n rs' }
          if rs'.isEmpty && n != 0 then (db, x :: stack) else (db, stack)
        else (db, stack)
      | none => (db, stack)
    ({ db with enc := Std.HashMap.erase db.enc w }, stack)
  | _ => match e with
    | some wc => ({ db with nodeRem := alSet db.nodeRem wc true, enc := Std.HashMap.erase db.enc w }, stack)
    | none => (db, stack)

/-- Identifiers that lost their node: their elements leave the encoding too. -/
def processIds (augs : Nat → List WME) (ltiOf : Nat → Nat) : Nat → EpDB → List Nat → EpDB
  | 0, db, _ => db
  | _, db, [] => db
  | f + 1, db, x :: rest =>
    if (db.nodeOf x).isNone then processIds augs ltiOf f db rest else
    let db := { db with known := Std.HashMap.erase db.known x }
    let (db, stack) := (augs x).foldl (fun (acc : EpDB × List Nat) w => acc.1.removeOne ltiOf w acc.2) (db, rest)
    processIds augs ltiOf f db stack

def hookRemove (augs : Nat → List WME) (ltiOf : Nat → Nat) (db : EpDB) (w : WME) : EpDB :=
  let (db, st) := db.removeOne ltiOf w []
  processIds augs ltiOf (db.known.size * 4 + db.enc.size + 2) db st

/-- Bring the encoder up to date with working memory `wm`; `augs` lists an identifier's
elements in Soar's order. The first time, the store is initialized: the top state is node 0
and its augmentations are to be encoded. -/
def sync (db : EpDB) (top : Nat) (wm : List WME) (augs : Nat → List WME) (ltiOf : Nat → Nat := fun _ => 0) : EpDB :=
  if !db.connected then
    { db with connected := true, known := ({} : Std.HashMap Nat Nat).insert top 0, refs := ({} : Std.HashMap Nat (List WME)).insert 0 [], adds := [top], prevWM := wm }
  else
    let prevS : Std.HashSet WME := Std.HashSet.ofList db.prevWM
    let nowS : Std.HashSet WME := Std.HashSet.ofList wm
    let added := wm.filter (!prevS.contains ·)
    let removed := db.prevWM.filter (!nowS.contains ·)
    let db := added.foldl hookAdd db
    let db := removed.foldl (hookRemove augs ltiOf) db
    { db with prevWM := wm }

/-! ## Recording an episode (Soar's `epmem_new_episode`, `_epmem_store_level`) -/

structure Resv where
  key  : Nat × Sym
  myId : Option Nat
  deriving Inhabited

structure StoreAcc where
  db      : EpDB
  queue   : List (Nat × Nat) := []
  visited : List Nat := []
  resv    : List (WME × Resv) := []
  newIds  : List Nat := []
  nodesQ  : List Nat := []
  /-- Identifier edges to open, each with its value's LTI now. -/
  edgesQ  : List (Nat × Nat) := []
  deriving Inhabited

/-- Change the `i`-th element of a list. -/
def modAt {α : Type} (f : α → α) : List α → Nat → List α
  | [], _ => []
  | x :: xs, 0 => f x :: xs
  | x :: xs, n + 1 => x :: modAt f xs n

def modWi (db : EpDB) (i : Nat) (f : EEdge → EEdge) : EpDB := { db with wis := modAt f db.wis (i - 1) }
def modWc (db : EpDB) (i : Nat) (f : EEdge → EEdge) : EpDB := { db with wcs := modAt f db.wcs (i - 1) }

/-- The first pool entry satisfying `p`, removed from the pool. -/
def takePool (db : EpDB) (key : Nat × Sym) (p : Nat × Nat → Bool) : EpDB × Option (Nat × Nat) :=
  let pool := (alGet db.pools key).getD []
  match pool.find? p with
  | some e =>
    let i := (pool.findIdx? (· == e)).getD 0
    ({ db with pools := alSet db.pools key (pool.eraseIdx i) }, some e)
  | none => (db, none)

/-- Reservations for elements whose identifier value already has a node. -/
def reserve (pid : Nat) (acc : StoreAcc) (w : WME) : StoreAcc :=
  if (acc.db.enc[w]?).isSome then acc else
  match w.val with
  | .id x => match acc.db.nodeOf x with
    | some n =>
      if acc.db.exclusions.contains w.attr then acc else
      let key := (pid, hashOf w)
      let r := acc.db.takePool key (·.1 == n)
      { acc with db := r.1, resv := acc.resv ++ [(w, { key := key, myId := r.2.map (·.2) })] }
    | none => acc
  | _ => acc

/-- An edge to re-use for an element whose identifier value has node `n` (Soar's cases 1 and
2): its reservation, or else an entry for `n` in the pool. -/
def reuseKnown (acc : StoreAcc) (w : WME) (key : Nat × Sym) (n : Nat) : StoreAcc × Option Nat :=
  match alGet acc.resv w with
  | some r =>
    let acc := { acc with resv := alErase acc.resv w }
    match r.myId with
    | some i => ({ acc with db := { acc.db with repl := Std.HashMap.insert acc.db.repl i (r.key, n) } }, some i)
    | none => (acc, none)
  | none =>
    let r := acc.db.takePool key (·.1 == n)
    match r.2 with
    | some e => ({ acc with db := { r.1 with repl := Std.HashMap.insert r.1.repl e.2 (key, n) } }, some e.2)
    | none => ({ acc with db := r.1 }, none)

/-- An edge (and node) to re-use for a new identifier `x` (Soar's case 3): the first pool entry
whose node no element refers to. -/
def reuseNew (acc : StoreAcc) (x : Nat) (key : Nat × Sym) : StoreAcc × Option Nat :=
  let acc := { acc with newIds := acc.newIds ++ [x] }
  let db := acc.db
  let r := db.takePool key (fun p => (db.refsOf p.1).isEmpty)
  match r.2 with
  | some e => ({ acc with db := { r.1 with known := Std.HashMap.insert r.1.known x e.1, repl := Std.HashMap.insert r.1.repl e.2 (key, e.1) } }, some e.2)
  | none => ({ acc with db := r.1 }, none)

/-- The node of identifier `x`, made if it has none. -/
def ensureNode (db : EpDB) (x : Nat) : EpDB :=
  match db.nodeOf x with
  | some _ => db
  | none => { db with known := Std.HashMap.insert db.known x db.nextNode, refs := Std.HashMap.insert db.refs db.nextNode [],
                      nextNode := db.nextNode + 1 }

/-- Encode identifier-valued element `w` with the edge `wid` found for it, or a new edge. -/
def addIdEdge (pid : Nat) (ltiOf : Nat → Nat) (acc : StoreAcc) (w : WME) (x : Nat) (key : Nat × Sym)
    (wid : Option Nat) : StoreAcc :=
  match wid with
  | none =>
    let db := ensureNode acc.db x
    let xn := (db.nodeOf x).getD 0
    let wi := db.wis.length + 1
    let db := { db with wis := db.wis ++ [{ parent := pid, attr := hashOf w, child := .node xn, lti := ltiOf x }],
                        enc := Std.HashMap.insert db.enc w wi, repl := Std.HashMap.insert db.repl wi (key, xn) }
    { acc with db := db, edgesQ := acc.edgesQ ++ [(wi, ltiOf x)] }
  | some wi =>
    let db := { acc.db with enc := Std.HashMap.insert acc.db.enc w wi, edgeRem := alSet acc.db.edgeRem wi false }
    if (db.wis[wi - 1]?.map (·.maxed)).getD false then
      { acc with db := db.modWi wi (fun e => { e with maxed := false }), edgesQ := acc.edgesQ ++ [(wi, ltiOf x)] }
    else { acc with db := db }

/-- A new identifier's node counts the element; the identifier is queued for encoding. -/
def noteId (acc : StoreAcc) (w : WME) (x : Nat) : StoreAcc :=
  let xn := (acc.db.nodeOf x).getD 0
  let acc := if acc.newIds.contains x then
      let rs := acc.db.refsOf xn
      { acc with db := { acc.db with refs := Std.HashMap.insert acc.db.refs xn (if rs.contains w then rs else rs ++ [w]) } }
    else acc
  if acc.visited.contains x then acc else { acc with queue := acc.queue ++ [(x, xn)] }

/-- Encode constant-valued element `w`: the edge with its parent, attribute and value, or a
new one. -/
def storeConst (pid : Nat) (acc : StoreAcc) (w : WME) (c : Sym) : StoreAcc :=
  let db := acc.db
  match db.wcs.findIdx? (fun e => e.parent == pid && e.attr == w.attr && e.child == .const c) with
  | some k =>
    let i := k + 1
    let db := { db with enc := Std.HashMap.insert db.enc w i, nodeRem := alSet db.nodeRem i false }
    if (db.wcs[k]?.map (·.maxed)).getD false then
      { acc with db := db.modWc i (fun e => { e with maxed := false }), nodesQ := acc.nodesQ ++ [i] }
    else { acc with db := db }
  | none =>
    let i := db.wcs.length + 1
    let db := { db with wcs := db.wcs ++ [{ parent := pid, attr := w.attr, child := .const c }],
                        enc := Std.HashMap.insert db.enc w i }
    { acc with db := db, nodesQ := acc.nodesQ ++ [i] }

/-- Encode one element of the identifier with node `pid`. -/
def storeOne (pid : Nat) (ltiOf : Nat → Nat) (acc : StoreAcc) (w : WME) : StoreAcc :=
  if (acc.db.enc[w]?).isSome then acc else
  if acc.db.exclusions.contains w.attr then acc else
  match w.val with
  | .id x =>
    let key := (pid, hashOf w)
    let r := match acc.db.nodeOf x with
      | some n => reuseKnown acc w key n
      | none => reuseNew acc x key
    noteId (addIdEdge pid ltiOf r.1 w x key r.2) w x
  | c => storeConst pid acc w c

def storeLevel (pid : Nat) (ltiOf : Nat → Nat) (acc : StoreAcc) (ws : List WME) : StoreAcc :=
  let acc := ws.foldl (reserve pid) acc
  ws.foldl (storeOne pid ltiOf) acc

/-- Breadth-first encoding below one identifier. -/
def storeBfs (augs : Nat → List WME) (ltiOf : Nat → Nat) : Nat → StoreAcc → StoreAcc
  | 0, acc => acc
  | f + 1, acc =>
    match acc.queue with
    | [] => acc
    | (x, pid) :: rest =>
      let acc := { acc with queue := rest }
      if acc.visited.contains x then storeBfs augs ltiOf f acc else
      let acc := { acc with visited := acc.visited ++ [x] }
      let ws := augs x
      storeBfs augs ltiOf f (if ws.isEmpty then acc else storeLevel pid ltiOf acc ws)

/-- Encode everything new below the identifiers with new elements. -/
def storeAll (db : EpDB) (augs : Nat → List WME) (ltiOf : Nat → Nat) (fuel : Nat) : StoreAcc :=
  db.adds.foldl (fun (acc : StoreAcc) p =>
    match acc.db.nodeOf p with
    | some n => storeBfs augs ltiOf fuel { acc with queue := [(p, n)] }
    | none => acc) { db := db }

/-- Open an interval at episode `t` (for an edge with none open). -/
def openAt (t : Nat) (e : EEdge) : EEdge :=
  match e.now with
  | some _ => e
  | none => { e with now := some t }

/-- Close the open interval, if any, at episode `t - 1`. -/
def closeAt (t : Nat) (e : EEdge) : EEdge :=
  match e.now with
  | some s => { e with now := none, closed := (s, t - 1) :: e.closed, maxed := true }
  | none => { e with maxed := true }

/-- Open an identifier edge's interval, with the LTI its value has now. -/
def openLti (t l : Nat) (e : EEdge) : EEdge :=
  match e.now with
  | some _ => e
  | none => { e with now := some t, lti := l }

/-- Close an identifier edge's interval, recording the LTI its value had when it was removed. -/
def closeLti (t l : Nat) (e : EEdge) : EEdge :=
  match e.now with
  | some s => { e with now := none, closed := (s, t - 1) :: e.closed, closedLti := l :: e.closedLti, maxed := true }
  | none => { e with maxed := true }

def openAll (t : Nat) (nodesQ : List Nat) (edgesQ : List (Nat × Nat)) (db : EpDB) : EpDB :=
  let db := nodesQ.foldl (fun db i => db.modWc i (openAt t)) db
  edgesQ.foldl (fun db (x : Nat × Nat) => db.modWi x.1 (fun e => { openLti t x.2 e with lastEp := epInf })) db

def closeAll (t : Nat) (db : EpDB) : EpDB :=
  let db := db.nodeRem.foldl (fun db p => if p.2 then db.modWc p.1 (closeAt t) else db) db
  db.edgeRem.foldl (fun db p =>
    if p.2 then db.modWi p.1 (fun e => { closeLti t ((db.remLti[p.1]?).getD 0) e with lastEp := (t : Int) - 1 }) else db) db

/-- Record episode `db.time`: encode what is new, open intervals for edges now present and
close those of edges gone. -/
def newEpisode (db : EpDB) (augs : Nat → List WME) (ltiOf : Nat → Nat) (fuel : Nat) : EpDB :=
  let t := db.time
  let acc := db.storeAll augs ltiOf fuel
  let db := closeAll t (openAll t acc.nodesQ acc.edgesQ acc.db)
  { db with nodeRem := [], edgeRem := [], remLti := {}, adds := [], time := t + 1 }

def validEp (db : EpDB) (t : Int) : Bool := decide (1 ≤ t) && decide (t < db.time)

/-- The edges present in episode `t`, as (parent, attribute, value, LTI). -/
def episode (db : EpDB) (t : Nat) : List (Nat × Sym × EVal × Nat) :=
  (db.wis.filter (·.at t)).map (fun e => (e.parent, e.attr, e.child, e.ltiAt t)) ++
  (db.wcs.filter (·.at t)).map (fun e => (e.parent, e.attr, e.child, 0))

/-! ## Reconstructing an episode (Soar's `epmem_install_memory`) -/

/-- Working-memory elements reconstructing episode `t` below the new identifier `hdr`, one new
identifier per node (numbered from `next`), identifier edges first in order of parent and
child node, an edge whose parent is not yet placed being retried until no progress is made,
then constant edges. Returns the elements, the next free identifier, the node ↦ identifier
table and LTI links. -/
def install (db : EpDB) (t : Nat) (hdr next : Nat) :
    List WME × Nat × List (Nat × Nat) × List (Nat × Nat) :=
  let ies := ((db.wis.filter (·.at t)).toArray.qsort (fun a b =>
    a.parent < b.parent || (a.parent == b.parent && (match a.child, b.child with
      | .node x, .node y => x < y | _, _ => false)))).toList
  let step (acc : List (Nat × Nat) × List WME × Nat × List (Nat × Nat) × List EEdge) (e : EEdge) :=
    let (ids, ws, next, ltis, orph) := acc
    match alGet ids e.parent, e.child with
    | some p, .node c =>
      match alGet ids c with
      | some y => (ids, ws ++ [{ id := p, attr := e.attr, val := .id y }], next, ltis, orph)
      | none => (ids ++ [(c, next)], ws ++ [{ id := p, attr := e.attr, val := .id next }], next + 1,
                 if e.ltiAt t != 0 then ltis ++ [(next, e.ltiAt t)] else ltis, orph)
    | _, _ => (ids, ws, next, ltis, orph ++ [e])
  let rec retry (fuel : Nat) (acc : List (Nat × Nat) × List WME × Nat × List (Nat × Nat) × List EEdge) :=
    match fuel with
    | 0 => acc
    | f + 1 =>
      let (ids, ws, next, ltis, orph) := acc
      if orph.isEmpty then acc else
      let acc' := orph.foldl step (ids, ws, next, ltis, [])
      if acc'.2.2.2.2.length == orph.length then acc' else retry f acc'
  let acc := ies.foldl step ([(0, hdr)], [], next, [], [])
  let (ids, ws, next, ltis, _) := retry (ies.length + 1) acc
  let ws := (db.wcs.filter (·.at t)).foldl (fun ws e =>
    match alGet ids e.parent, e.child with
    | some p, .const c => ws ++ [{ id := p, attr := e.attr, val := c }]
    | _, _ => ws) ws
  (ws, next, ids, ltis)

/-! ## Cue-based retrieval (Soar's `epmem_process_query`)

A port of the interval search: literals of the cue's disjunctive-normal-form graph, partial
edges (cue patterns at a parent node, walked in order of the last episode an edge was present),
unique edges with their intervals, and a walk backwards in time that tracks which literals are
satisfied, scoring an episode only when it begins a stretch of time in which the score has
changed. -/

abbrev Triple := Option Nat × Option Sym × Option EVal

structure Lit where
  idSym    : Option Sym
  valSym   : Sym
  valIsId  : Bool
  isLeaf   : Bool
  attr     : Option Sym
  child    : Option EVal
  isNeg    : Bool
  weight   : Float
  parents  : List Nat := []
  children : List Nat := []
  mts  : List (Option Nat × EVal) := []
  values   : List (EVal × Nat) := []
  deriving Inhabited

structure Pedge where
  triple : Triple
  isId   : Bool
  lits   : List Nat
  /-- Remaining rows (edge number, value, time); the head is the current row. -/
  rows   : List (Nat × EVal × Int)
  deriving Inhabited

def Pedge.time (p : Pedge) : Int := (p.rows.head?.map (·.2.2)).getD 0

structure Uedge where
  triple    : Triple
  isId      : Bool
  count     : Int := 0
  pedges    : List Nat := []
  activated : Bool := false
  deriving Inhabited

structure Iv where
  u     : Nat
  isEnd : Bool
  times : List Int
  deriving Inhabited

def Iv.time (v : Iv) : Int := v.times.headD 0

/-- A binary max-heap of indices (S26 in the code review). The order is the total order of
`PQ.gt` on a key that ends in the index, so the maximum is unique and `pop` returns the same
element as a scan of the queue for the greatest (the keys of the elements in the heap do not
change while they are in it). -/
structure PQ where
  a : Array Nat := #[]
  deriving Repr

namespace PQ
def gt (key : Nat → Int × Nat × Nat) (x y : Nat) : Bool :=
  let kx := key x; let ky := key y
  kx.1 > ky.1 || (kx.1 == ky.1 && (kx.2.1 > ky.2.1 || (kx.2.1 == ky.2.1 && kx.2.2 > ky.2.2)))
def isEmpty (q : PQ) : Bool := q.a.isEmpty
def peek (q : PQ) : Option Nat := q.a[0]?
def siftUp (key : Nat → Int × Nat × Nat) : Nat → Array Nat → Nat → Array Nat
  | 0, a, _ => a
  | f + 1, a, i =>
    if i == 0 then a else
    let p := (i - 1) / 2
    if gt key (a.getD i 0) (a.getD p 0) then siftUp key f (a.swapIfInBounds i p) p else a
def siftDown (key : Nat → Int × Nat × Nat) : Nat → Array Nat → Nat → Array Nat
  | 0, a, _ => a
  | f + 1, a, i =>
    let l := 2 * i + 1
    let r := l + 1
    let m := if l < a.size && gt key (a.getD l 0) (a.getD i 0) then l else i
    let m := if r < a.size && gt key (a.getD r 0) (a.getD m 0) then r else m
    if m == i then a else siftDown key f (a.swapIfInBounds i m) m
def push (q : PQ) (key : Nat → Int × Nat × Nat) (x : Nat) : PQ :=
  ⟨siftUp key (q.a.size + 1) (q.a.push x) q.a.size⟩
def pop (q : PQ) (key : Nat → Int × Nat × Nat) : Option (Nat × PQ) :=
  if q.a.isEmpty then none else
  let top := q.a.getD 0 0
  let last := q.a.getD (q.a.size - 1) 0
  let a := q.a.pop
  if a.isEmpty then some (top, ⟨a⟩) else some (top, ⟨siftDown key (a.size + 1) (a.set! 0 last) 0⟩)
end PQ

structure Walk where
  lits    : Array Lit
  pedges  : Array Pedge := #[]
  pcache  : List ((Bool × Triple) × Nat) := []
  ppq     : PQ := {}
  uedges  : Array Uedge := #[]
  ucache  : List ((Bool × Triple) × Nat) := []
  ivs     : Array Iv := #[]
  ipq     : PQ := {}
  symInc  : List (Sym × Nat) := []
  symNode : List ((Sym × EVal) × Nat) := []
  score   : Float := 0
  card    : Int := 0
  deriving Inhabited

def mkey : Option Nat × EVal → Nat × Nat
  | (p, c) => ((p.map (· + 1)).getD 0, match c with | .node n => n | .const _ => 0)

def lexLt (a b : Nat × Nat) : Bool := a.1 < b.1 || (a.1 == b.1 && a.2 < b.2)

def insertSorted (x : Option Nat × EVal) (l : List (Option Nat × EVal)) : List (Option Nat × EVal) :=
  if l.contains x then l else
  let (lo, hi) := l.span (fun y => lexLt (mkey y) (mkey x))
  lo ++ [x] ++ hi

def Walk.lit (w : Walk) (i : Nat) : Lit := w.lits[i]?.getD default
def Walk.setLit (w : Walk) (i : Nat) (l : Lit) : Walk := { w with lits := w.lits.set! i l }

/-- Uedges in the cache with a given parent and attribute, in triple order. -/
def Walk.uedgesAt (w : Walk) (isId : Bool) (p : Nat) (a : Option Sym) : List (Nat × Uedge) :=
  let us := w.ucache.filter (fun ((b, (p', a', c)), _) => b == isId && p' == some p && a' == a && c.isSome)
  let us := (us.toArray.qsort (fun x y => lexLt (mkey (x.1.2.1, x.1.2.2.2.getD (.node 0)))
    (mkey (y.1.2.1, y.1.2.2.2.getD (.node 0))))).toList
  us.map fun (_, i) => (i, w.uedges[i]?.getD default)

/-- Satisfy literal `li` by the edge from `parent` to `child` (Soar's `epmem_satisfy_literal`);
true if the score changed. -/
def satisfy : Nat → Walk → Nat → Option Nat → EVal → Walk × Bool
  | 0, w, _, _, _ => (w, false)
  | f + 1, w, li, parent, child =>
    let L := w.lit li
    let ok := match L.idSym with
      | none => true
      | some sym => match parent with
        | some p => alGet w.symNode (sym, .node p) == some ((alGet w.symInc sym).getD 0)
        | none => false
    if !ok then (w, false) else
    let L := { L with mts := insertSorted (parent, child) L.mts }
    match alGet L.values child with
    | some k => (w.setLit li { L with values := alSet L.values child (k + 1) }, false)
    | none =>
      let L := { L with values := alSet L.values child 1 }
      let w := w.setLit li L
      if L.isLeaf then
        if L.mts.length == 1 then
          ({ w with score := w.score + L.weight, card := w.card + (if L.isNeg then -1 else 1) }, true)
        else (w, false)
      else
        let key := (L.valSym, child)
        let w := { w with symNode := alSet w.symNode key ((alGet w.symNode key).getD 0 + 1) }
        match child with
        | .node cn =>
          L.children.foldl (fun (acc : Walk × Bool) ch =>
            let (w, changed) := acc
            let C := w.lit ch
            let cands := match C.child with
              | none => w.uedgesAt C.valIsId cn C.attr
              | some cv => match alGet w.ucache (C.valIsId, (some cn, C.attr, some cv)) with
                | some i => [(i, w.uedges[i]?.getD default)]
                | none => []
            cands.foldl (fun (acc : Walk × Bool) (_, u) =>
              if u.activated && u.count == 1 then
                let (w, b) := satisfy f acc.1 ch u.triple.1 (u.triple.2.2.getD (.node 0))
                (w, acc.2 || b)
              else acc) (w, changed)) (w, false)
        | .const _ => (w, false)

def unsatisfy : Nat → Walk → Nat → Option Nat → EVal → Walk × Bool
  | 0, w, _, _, _ => (w, false)
  | f + 1, w, li, parent, child =>
    let L := w.lit li
    if L.mts.isEmpty || !L.mts.contains (parent, child) then (w, false) else
    let L := { L with mts := L.mts.filter (· != (parent, child)) }
    let k := (alGet L.values child).getD 1
    if k > 1 then (w.setLit li { L with values := alSet L.values child (k - 1) }, false) else
    let L := { L with values := alErase L.values child }
    let w := w.setLit li L
    if L.isLeaf then
      if L.mts.isEmpty then
        ({ w with score := w.score - L.weight, card := w.card - (if L.isNeg then -1 else 1) }, true)
      else (w, false)
    else
      let key := (L.valSym, child)
      let c := (alGet w.symNode key).getD 1
      let w := { w with symNode := if c ≤ 1 then alErase w.symNode key else alSet w.symNode key (c - 1) }
      if L.mts.isEmpty then
        L.children.foldl (fun (acc : Walk × Bool) ch =>
          (acc.1.lit ch).mts.foldl (fun (acc : Walk × Bool) (p, c) =>
            let (w, b) := unsatisfy f acc.1 ch p c
            (w, acc.2 || b)) acc) (w, false)
      else
        match child with
        | .node cn =>
          L.children.foldl (fun (acc : Walk × Bool) ch =>
            -- only the first match whose parent is this node (as Soar does)
            match (acc.1.lit ch).mts.find? (·.1 == some cn) with
            | some (p, c) => let (w, b) := unsatisfy f acc.1 ch p c; (w, acc.2 || b)
            | none => acc) (w, false)
        | .const _ => (w, false)

/-- The rows of a partial edge: identifier edges by decreasing last episode (only those last
present after `after`), or the one constant edge. -/
def pedgeRows (db : EpDB) (isId : Bool) (t : Triple) (after : Int) : List (Nat × EVal × Int) :=
  match t with
  | (some p, some a, c) =>
    if isId then
      let rs := (db.wis.enum.filter (fun (_, e) => e.parent == p && e.attr == a && decide (after < e.lastEp))).map
        fun (k, e) => (k + 1, e.child, e.lastEp)
      (rs.toArray.qsort (fun x y => x.2.2 > y.2.2 || (x.2.2 == y.2.2 && x.1 < y.1))).toList
    else match c with
      | some (.const v) =>
        match db.wcs.findIdx? (fun e => e.parent == p && e.attr == a && e.child == .const v) with
        | some k => [(k + 1, .const v, epInf)]
        | none => []
      | _ => []
  | _ => []

def popMax (q : List Nat) (key : Nat → Int × Nat × Nat) : Option (Nat × List Nat) :=
  match q with
  | [] => none
  | x :: xs =>
    let gt (a b : Nat) : Bool := let ka := key a; let kb := key b
      ka.1 > kb.1 || (ka.1 == kb.1 && (ka.2.1 > kb.2.1 || (ka.2.1 == kb.2.1 && ka.2.2 > kb.2.2)))
    let m := xs.foldl (fun m y => if gt y m then y else m) x
    some (m, q.erase m)

def Walk.pkey (w : Walk) (i : Nat) : Int × Nat × Nat := ((w.pedges[i]?.getD default).time, 0, i)
def Walk.ikey (w : Walk) (i : Nat) : Int × Nat × Nat :=
  let v := w.ivs[i]?.getD default
  (v.time, if v.isEnd then 0 else 1, i)   -- at equal times, starts before ends

def Walk.topP (w : Walk) : Option Int := w.ppq.peek.map fun i => (w.pedges[i]?.getD default).time
def Walk.topI (w : Walk) : Option Int := w.ipq.peek.map fun i => (w.ivs[i]?.getD default).time

/-- Register partial edges for literal `li` below node `parent` (Soar's `epmem_register_pedges`). -/
def register (db : EpDB) (after : Int) : Nat → Walk → Nat → Nat → Walk × Bool
  | 0, w, _, _ => (w, false)
  | f + 1, w, parent, li =>
    let L := w.lit li
    let t : Triple := (some parent, L.attr, L.child)
    match alGet w.pcache (L.valIsId, t) with
    | none =>
      let rows := pedgeRows db L.valIsId t after
      if rows.isEmpty then (w, false) else
      let i := w.pedges.size
      let w := { w with pedges := w.pedges.push { triple := t, isId := L.valIsId, lits := [li], rows := rows },
                        pcache := alSet w.pcache (L.valIsId, t) i }
      ({ w with ppq := w.ppq.push w.pkey i }, true)
    | some pi =>
      let P := w.pedges[pi]?.getD default
      if P.lits.contains li then (w, true) else
      let w := { w with pedges := w.pedges.set! pi { P with lits := (P.lits ++ [li]).mergeSort } }
      if !L.isLeaf && L.child.isNone then
        (w.uedgesAt L.valIsId parent L.attr).foldl (fun (acc : Walk × Bool) (_, u) =>
          match u.triple.2.2 with
          | some (.node cn) =>
            if u.isId then
              L.children.foldl (fun (acc : Walk × Bool) ch =>
                let (w, b) := register db after f acc.1 cn ch; (w, acc.2 || b)) acc
            else acc
          | _ => acc) (w, false)
      else (w, true)

/-- The endpoints of an edge's intervals that started by episode `cur`. -/
def ivTimes (db : EpDB) (isId : Bool) (k : Nat) (cur : Int) : List Int × List Int :=
  let e := (if isId then db.wis else db.wcs)[k - 1]?.getD default
  let cl := e.closed.filter (fun (s, _) => decide ((s : Int) ≤ cur))
  let nw : List Nat := match e.now with | some s => if decide ((s : Int) ≤ cur) then [s] else [] | none => []
  let starts : List Int := cl.map (fun (s, _) => (s : Int) - 1) ++ nw.map (fun (s : Nat) => (s : Int) - 1)
  let ends : List Int := cl.map (fun (_, e) => (e : Int)) ++ nw.map (fun _ => cur)
  let srt (l : List Int) := (l.toArray.qsort (· > ·)).toList
  (srt starts, srt ends)

structure QState where
  w        : Walk
  cur      : Int
  after    : Int
  prohib   : List Int
  best     : Int := 0
  bestScore : Float := 0
  bestGm   : Bool := false
  bestCard : Int := 0
  bestBind : List (Nat × (Option Nat × EVal)) := []
  changed  : Bool := false
  deriving Inhabited

abbrev Bindings := List (Nat × (Option Nat × EVal))
abbrev Bound := List ((Bool × EVal) × Sym)

mutual
/-- Graph match (Soar's `epmem_graph_match`): bind each literal in `order` to one of its
mts, consistently with bound parents and children and with distinct cue identifiers
bound to distinct nodes. Returns the bindings found, and the table of bound nodes as the
search left it.

Soar 9.6.5 keeps the bound nodes in one table that the whole search changes
(`bound_nodes`): binding a literal sets the entry of its node, and backtracking from it
erases that entry, even when an earlier literal with the same value had set it, so a later
literal with another value can then take the node. The model reproduces this: the table is
threaded through the search and an entry is erased, not restored, on backtracking (a Soar
defect, episodic_memory.cpp:4221-4360). -/
partial def gmatch (w : Walk) (order : List Nat) (b : Bindings) (bound : Bound) : Option Bindings × Bound :=
  match order with
  | [] => (some b, bound)
  | li :: rest => if (alGet b li).isSome then (none, bound) else gmTry w li rest b bound (w.lit li).mts []

partial def gmTry (w : Walk) (li : Nat) (rest : List Nat) (b : Bindings) (bound : Bound)
    (ms : List (Option Nat × EVal)) (failedP : List (Option Nat)) : Option Bindings × Bound :=
  match ms with
  | [] => (none, bound)
  | (p, c) :: ms' =>
    let L := w.lit li
    if failedP.contains p then gmTry w li rest b bound ms' failedP else
    let okP := L.parents.all fun pl => match alGet b pl with
      | some (_, c') => (match p with | some n => c' == .node n | none => false)
      | none => true
    if !okP then gmTry w li rest b bound ms' (failedP ++ [p]) else
    let okB := match alGet bound (L.valIsId, c) with | some sym => sym == L.valSym | none => true
    if !okB then gmTry w li rest b bound ms' failedP else
    let okC := (L.child.isNone || L.child == some c) && L.children.all fun cl => match alGet b cl with
      | some (p', _) => (match c with | .node n => p' == some n | .const _ => false)
      | none => true
    if !okC then gmTry w li rest b bound ms' failedP else
    match gmatch w rest ((li, (p, c)) :: b) (alSet bound (L.valIsId, c) L.valSym) with
    | (some r, bound') => (some r, bound')
    | (none, bound') => gmTry w li rest b (alErase bound' (L.valIsId, c)) ms' failedP
end

/-! ### The walk -/

/-- Process the current row of partial edge `pi`: register partial edges for the literals
below it, create its unique edge (with the endpoints of its intervals) or link to it, and
step to the next row. -/
def processPedge (db : EpDB) (after : Int) (fuel : Nat) (q : QState) (pi : Nat) : QState :=
  let w := q.w
  let P := w.pedges[pi]?.getD default
  match P.rows with
  | [] => q
  | (eid, child, _) :: _ =>
    let t : Triple := (P.triple.1, P.triple.2.1, some child)
    let w := if P.isId then match child with
      | .node cn => P.lits.foldl (fun w li =>
          (w.lit li).children.foldl (fun w ch => (register db after fuel w cn ch).1) w) w
      | _ => w
      else w
    let (w, ch) : Walk × Bool := match alGet w.ucache (P.isId, t) with
      | none =>
        let (st, en) := ivTimes db P.isId eid q.cur
        if st.isEmpty && en.isEmpty then (w, false) else
        let ui := w.uedges.size
        let w := { w with uedges := w.uedges.push { triple := t, isId := P.isId, pedges := [pi] },
                          ucache := alSet w.ucache (P.isId, t) ui }
        let w := if st.isEmpty then w else
          let w := { w with ivs := w.ivs.push { u := ui, isEnd := false, times := st } }
          { w with ipq := w.ipq.push w.ikey (w.ivs.size - 1) }
        let w := if en.isEmpty then w else
          let w := { w with ivs := w.ivs.push { u := ui, isEnd := true, times := en } }
          { w with ipq := w.ipq.push w.ikey (w.ivs.size - 1) }
        (w, false)
      | some ui =>
        let U0 : Uedge := w.uedges[ui]?.getD default
        let U : Uedge := { U0 with pedges := if U0.pedges.contains pi then U0.pedges else (U0.pedges ++ [pi]).mergeSort }
        let w := { w with uedges := w.uedges.set! ui U }
        if U.activated && U.count == 1 then
          P.lits.foldl (fun (acc : Walk × Bool) li =>
            let (w, b) := satisfy fuel acc.1 li t.1 child; (w, acc.2 || b)) (w, false)
        else (w, false)
    let P' := w.pedges[pi]?.getD default
    let rest := P'.rows.drop 1
    let w := { w with pedges := w.pedges.set! pi { P' with rows := rest } }
    let w := if rest.isEmpty then w else { w with ppq := w.ppq.push w.pkey pi }
    { q with w := w, changed := q.changed || ch }

def pedgeLoop (db : EpDB) (after : Int) (fuel : Nat) : Nat → QState → Int → QState
  | 0, q, _ => q
  | f + 1, q, nextEdge =>
    match q.w.ppq.pop q.w.pkey with
    | none => q
    | some (pi, rest) =>
      let t := (q.w.pedges[pi]?.getD default).time
      if t == nextEdge || t ≥ q.cur then
        pedgeLoop db after fuel f (processPedge db after fuel { q with w := { q.w with ppq := rest } } pi) nextEdge
      else q

/-- An interval endpoint: an end (walking backwards, the edge appears) or a start (it goes). -/
def processIv (fuel : Nat) (q : QState) (vi : Nat) : QState :=
  let w := q.w
  let V := w.ivs[vi]?.getD default
  let U := w.uedges[V.u]?.getD default
  let child := U.triple.2.2.getD (.node 0)
  let U := if V.isEnd then { U with activated := true, count := U.count + 1 }
           else { U with activated := false, count := U.count - 1 }
  let w := { w with uedges := w.uedges.set! V.u U }
  let lits := U.pedges.flatMap fun pi => (w.pedges[pi]?.getD default).lits
  let (w, ch) : Walk × Bool :=
    if V.isEnd then
      if U.count == 1 then
        lits.foldl (fun (acc : Walk × Bool) li =>
          let (w, b) := satisfy fuel acc.1 li U.triple.1 child; (w, acc.2 || b)) (w, false)
      else (w, false)
    else
      lits.foldl (fun (acc : Walk × Bool) li =>
        let (w, b) := unsatisfy fuel acc.1 li U.triple.1 child; (w, acc.2 || b)) (w, false)
  let rest := V.times.drop 1
  let w := { w with ivs := w.ivs.set! vi { V with times := rest } }
  let w := if rest.isEmpty then w else { w with ipq := w.ipq.push w.ikey vi }
  { q with w := w, changed := q.changed || ch }

def ivInner (fuel : Nat) : Nat → QState → QState
  | 0, q => q
  | f + 1, q =>
    match q.w.ipq.pop q.w.ikey with
    | some (vi, rest) =>
      if (q.w.ivs[vi]?.getD default).time ≥ q.cur then
        ivInner fuel f (processIv fuel { q with w := { q.w with ipq := rest } } vi)
      else q
    | none => q

/-- Drop prohibited episodes at the newest end of the stretch being considered. -/
def skipProhibited (cur nextEp : Int) (pr : List Int) : Nat → Int × List Int
  | 0 => (cur, pr)
  | f + 1 =>
    match pr.getLast? with
    | some x => if cur > nextEp && cur == x then skipProhibited (cur - 1) nextEp pr.dropLast f else (cur, pr)
    | none => (cur, pr)

/-- Score the episode beginning the current stretch (Soar's "new king" test). -/
def consider (gm : Bool) (order : List Nat) (perfectCard : Int) (q : QState) (nextEp : Int)
    (mcv : Bool := false) : QState :=
  if q.cur > nextEp && q.changed &&
      (q.best == 0 || q.w.score > q.bestScore || (gm && q.w.score == q.bestScore && !q.bestGm)) then
    let q := if q.best == 0 || q.w.score > q.bestScore then
        { q with best := q.cur, bestScore := q.w.score, bestCard := q.w.card } else q
    if q.w.card == perfectCard then
      let order := if mcv then order.mergeSort (fun a b => (q.w.lit a).mts.length ≤ (q.w.lit b).mts.length) else order
      match (if gm then (gmatch q.w order [] []).1 else some []) with
      | some b => { q with best := q.cur, bestGm := true, cur := 0, bestBind := b }
      | none => { q with bestBind := [] }
    else q
  else q

def ivLoop (gm mcv : Bool) (order : List Nat) (perfectCard : Int) (fuel : Nat) : Nat → QState → Int → QState
  | 0, q, _ => q
  | f + 1, q, nextEdge =>
    match q.w.topI with
    | some top =>
      if top > nextEdge && q.cur > q.after then
        let q := ivInner fuel fuel q
        let nextIv := q.w.topI.getD q.after
        let nextEp := max nextEdge nextIv
        let pr := q.prohib.reverse.dropWhile (· > q.cur) |>.reverse
        let (cur, pr) := skipProhibited q.cur nextEp pr (pr.length + 1)
        let q := consider gm order perfectCard { q with cur := cur, prohib := pr } nextEp mcv
        if q.cur == 0 then q else ivLoop gm mcv order perfectCard fuel f { q with cur := nextEp } nextEdge
      else q
    | none => q

def outer (db : EpDB) (gm : Bool) (order : List Nat) (perfectCard : Int) (fuel : Nat) : Nat → QState → QState
  | 0, q => q
  | f + 1, q =>
    if q.w.ppq.isEmpty || !(q.cur > q.after) then q else
    let q := { q with changed := false }
    let nextEdge := q.w.topP.getD 0
    let q := pedgeLoop db q.after fuel fuel q nextEdge
    let nextEdge := q.w.topP.getD q.after
    let q := ivLoop gm (db.gmOrder == "mcv") order perfectCard fuel fuel q nextEdge
    outer db gm order perfectCard fuel f q

/-! ### The cue's literals (Soar's `epmem_build_dnf`) -/

structure Dnf where
  lits   : Array Lit
  cache  : List (WME × Nat) := []
  leaves : List Nat := []
  symInc : List (Sym × Nat) := []
  cue    : List WME := []
  /-- Positive literals in Soar's `gm_ordering` deque (each pushed at the front when made). -/
  dfs    : List Nat := []
  deriving Inhabited

def Dnf.modLit (d : Dnf) (i : Nat) (f : Lit → Lit) : Dnf := { d with lits := d.lits.modify i f }

def buildDnf (augs : Nat → List WME) : Nat → Dnf → WME → Bool → List Sym → Dnf × Option Nat
  | 0, d, _, _, _ => (d, none)
  | f + 1, d, w, neg, visiting =>
    if visiting.contains w.val then (d, none) else
    match alGet d.cache w with
    | some i => (d, some i)
    | none =>
      let d := { d with cue := if d.cue.contains w then d.cue else d.cue ++ [w] }
      let idx := d.lits.size
      let base : Lit := { idSym := some (.id w.id), valSym := w.val, valIsId := false, isLeaf := true,
                          attr := some w.attr, child := none, isNeg := neg, weight := if neg then -1 else 1 }
      let d := { d with lits := d.lits.push base }
      match w.val with
      | .id x =>
        let kids := augs x
        if kids.isEmpty then
          ({ d with lits := d.lits.set! idx { base with valIsId := true }, leaves := d.leaves ++ [idx],
                    cache := alSet d.cache w idx, dfs := if neg then d.dfs else idx :: d.dfs }, some idx)
        else
          let (d, chs, cyc) := kids.foldl (fun (acc : Dnf × List Nat × Bool) k =>
            let (d, chs, cyc) := acc
            let (d, r) := buildDnf augs f d k neg (w.val :: visiting)
            match r with
            | some c => (d.modLit c (fun L => { L with parents := if L.parents.contains idx then L.parents
                                                                   else (L.parents ++ [idx]).mergeSort }),
                         if chs.contains c then chs else (chs ++ [c]).mergeSort, cyc)
            | none => (d, chs, true)) (d, [], false)
          if cyc && chs.isEmpty then (d, none) else
          ({ d with lits := d.lits.set! idx { base with valIsId := true, isLeaf := false, children := chs },
                    symInc := alSet d.symInc w.val ((alGet d.symInc w.val).getD 0 + 1),
                    cache := alSet d.cache w idx, dfs := if neg then d.dfs else idx :: d.dfs }, some idx)
      | c =>
        ({ d with lits := d.lits.set! idx { base with child := some (.const c) }, leaves := d.leaves ++ [idx],
                  cache := alSet d.cache w idx, dfs := if neg then d.dfs else idx :: d.dfs }, some idx)

/-- What a command produces: status and other meta elements, the retrieved elements, the
next free identifier, the state's last retrieved episode, LTI links of new identifiers, and
the elements the result depends on. -/
structure CmdOut where
  «meta» : List WME := []
  ws   : List WME := []
  next : Nat
  last : Nat
  ltis : List (Nat × Nat) := []
  cue  : List WME := []
  deriving Inhabited

def stw (i : Nat) (a : String) (v : Sym) : WME := { id := i, attr := a, val := v }

/-- Place episode `t` under `(r ^retrieved R)`, with its number and the present time;
`record` lists nodes whose new identifiers are wanted back. -/
def installCmd (db : EpDB) (r t next : Nat) (out : CmdOut) : CmdOut × List (Nat × Nat) :=
  if !db.validEp t then
    ({ out with «meta» := out.«meta» ++ [stw r "retrieved" "no-memory"], last := 0 }, [])
  else
    let hdr := next
    let (ws, next, ids, ltis) := db.install t hdr (next + 1)
    ({ out with «meta» := out.«meta» ++ [stw r "retrieved" (.id hdr), stw r "memory-id" (.int t),
                                     stw r "present-id" (.int db.time)],
                ws := out.ws ++ ws, next := next, last := t, ltis := out.ltis ++ ltis }, ids)

def floatSym (x : Float) : Sym := .float x.toBits

/-- A cue-based retrieval (Soar's `epmem_process_query`). -/
def runQuery (db : EpDB) (augs : Nat → List WME) (r q : Nat) (neg : Option Nat) (prohib : List Int)
    (before after : Int) (out : CmdOut) (wact : WME → Float := fun _ => 1) : CmdOut :=
  if before != 0 && after != 0 && before ≤ after then
    { out with «meta» := out.«meta» ++ [stw r "status" "bad-cmd"] } else
  let root : Lit := { idSym := none, valSym := .id q, valIsId := true, isLeaf := false, attr := none,
                      child := some (.node 0), isNeg := false, weight := 0 }
  let fuel := (db.enc.size + db.wis.length + db.wcs.length + 2) * 4
  let d : Dnf := { lits := #[root], symInc := [(.id q, 1)] }
  let visiting : List Sym := [.id q] ++ (neg.map Sym.id).toList
  let roots : List (Nat × Bool) := [(q, false)] ++ (neg.map (·, true)).toList
  let d := roots.foldl (fun d (qr, isNeg) =>
    (augs qr).foldl (fun d w =>
      let (d, res) := buildDnf augs fuel d w isNeg visiting
      match res with
      | some c =>
        let d := d.modLit c (fun L =>
          { L with idSym := some (Sym.id q), parents := if L.parents.contains 0 then L.parents else (L.parents ++ [0]).mergeSort })
        d.modLit 0 (fun L =>
          { L with children := if L.children.contains c then L.children else (L.children ++ [c]).mergeSort })
      | none => d) d) d
  -- with `balance` below 1, each literal is weighted by its cue element's activation
  let d := if db.balance ≥ 1.0 - 1.0e-8 then d else
    d.cache.foldl (fun d (w, i) => d.modLit i fun L => { L with weight := (if L.isNeg then -1 else 1) * wact w }) d
  let posLeaves := d.leaves.filter fun i => !(d.lits[i]?.getD default).isNeg
  let perfectScore : Float := posLeaves.foldl (fun a i => a + (d.lits[i]?.getD default).weight) 0
  let perfectCard : Int := posLeaves.length
  let before' : Int := if before == 0 then (db.time : Int) - 1 else before - 1
  let order := if db.gmOrder == "undefined" then
      ((d.cache.map (·.2)).filter fun i => !(d.lits[i]?.getD default).isNeg).mergeSort else d.dfs
  let rootT : Triple := (none, none, some (.node 0))
  let p0 : Pedge := { triple := rootT, isId := true, lits := [0], rows := [(0, .node 0, epInf), (0, .node 0, 0)] }
  let u0 : Uedge := { triple := rootT, isId := true }
  let v0 : Iv := { u := 0, isEnd := true, times := [before', before'] }
  let w : Walk := { lits := d.lits, symInc := d.symInc, pedges := #[p0], ppq := ⟨#[0]⟩,
                    pcache := [((true, rootT), 0)], uedges := #[u0], ucache := [((true, rootT), 0)],
                    ivs := #[v0], ipq := ⟨#[0]⟩ }
  let q0 : QState := { w := w, cur := before', after := after, prohib := (prohib.toArray.qsort (· < ·)).toList }
  let big := fuel * (d.lits.size + 2) * 4 + 1000
  let qf := outer db db.graphMatch order perfectCard big big q0
  let out := { out with cue := out.cue ++ d.cue }
  let negL := (neg.map fun n => [n]).getD []
  if qf.best == 0 then
    { out with «meta» := out.«meta» ++ ([q] ++ negL).map fun x => stw r "failure" (.id x) }
  else
    let «meta» : List WME :=
      [stw r "cue-size" (.int d.leaves.length), stw r "match-cardinality" (.int qf.bestCard),
       stw r "match-score" (floatSym qf.bestScore),
       stw r "normalized-match-score" (floatSym (qf.bestScore / perfectScore))] ++
      ([q] ++ negL).map (fun x => stw r "success" (.id x)) ++
      (if db.graphMatch then [stw r "graph-match" (.int (if qf.bestGm then 1 else 0))] else [])
    let («meta», next, nodeMap) : List WME × Nat × List (Nat × Nat) :=
      if db.graphMatch && qf.bestGm then
        let m := out.next
        let binds := (qf.bestBind.toArray.qsort (fun a b => a.1 < b.1)).toList
        binds.foldl (fun (acc : List WME × Nat × List (Nat × Nat)) (li, (_, c)) =>
          let («meta», next, nm) := acc
          let L := d.lits[li]?.getD default
          if !L.valIsId then acc else
          match c with
          | .node cn => («meta» ++ [stw m "node" (.id next), stw next "cue" L.valSym], next + 1, alSet nm cn next)
          | .const _ => acc) («meta» ++ [stw r "mapping" (.id m)], m + 1, [])
      else («meta», out.next, [])
    let (out, ids) := installCmd db r qf.best.toNat next { out with «meta» := out.«meta» ++ «meta» }
    let maps := nodeMap.filterMap fun (cn, nsym) => (alGet ids cn).map fun y => stw nsym "retrieved" (.id y)
    { out with «meta» := out.«meta» ++ maps }

/-- Respond to a state's command (Soar's `_epmem_respond_to_cmd_parse` and
`epmem_respond_to_cmd`): `cmds` are the command's augmentations, `r` the result identifier,
`last` the state's last retrieved episode. -/
def respond (db : EpDB) (augs : Nat → List WME) (cmds : List WME) (r last next : Nat)
    (wact : WME → Float := fun _ => 1) : CmdOut :=
  -- path: 0 none, 1 retrieve, 2 next/previous, 3 query
  let step (acc : Bool × Nat × Int × Option Sym × Bool × Option Nat × Option Nat × List Int × Int × Int) (w : WME) :=
    let (good, path, ret, np, isNext, qy, nq, pr, bf, af) := acc
    if !good then acc else
    let bad := (false, path, ret, np, isNext, qy, nq, pr, bf, af)
    match w.attr, w.val with
    | .str "retrieve", .int i => if path == 0 && i > 0 then (good, 1, i, np, isNext, qy, nq, pr, bf, af) else bad
    | .str "next", .id _ => if path == 0 then (good, 2, ret, some w.val, true, qy, nq, pr, bf, af) else bad
    | .str "previous", .id _ => if path == 0 then (good, 2, ret, some w.val, false, qy, nq, pr, bf, af) else bad
    | .str "query", .id x =>
      if (path == 0 || path == 3) && qy.isNone then (good, 3, ret, np, isNext, some x, nq, pr, bf, af) else bad
    | .str "neg-query", .id x =>
      if (path == 0 || path == 3) && nq.isNone then (good, 3, ret, np, isNext, qy, some x, pr, bf, af) else bad
    | .str "before", .int i =>
      if path == 0 || path == 3 then (good, 3, ret, np, isNext, qy, nq, pr, (if bf == 0 || i < bf then i else bf), af) else bad
    | .str "after", .int i =>
      if path == 0 || path == 3 then (good, 3, ret, np, isNext, qy, nq, pr, bf, (if af < i then i else af)) else bad
    | .str "prohibit", .int i =>
      if path == 0 || path == 3 then (good, 3, ret, np, isNext, qy, nq, pr ++ [i], bf, af) else bad
    | _, _ => bad
  let (good, path, ret, np, isNext, qy, nq, pr, bf, af) :=
    cmds.foldl step (true, 0, 0, none, false, none, none, [], 0, 0)
  let good := good && !(path == 3 && qy.isNone) && path != 0
  let out : CmdOut := { next := next, last := last, cue := cmds }
  if !good then { out with «meta» := [stw r "status" "bad-cmd"] } else
  match path with
  | 1 => (installCmd db r ret.toNat next out).1
  | 2 =>
    let t := if last == 0 then 0 else if isNext then (if last + 1 < db.time then last + 1 else 0)
             else last - 1
    let out := (installCmd db r t next out).1
    { out with «meta» := out.«meta» ++ [stw r (if out.last == 0 then "failure" else "success") (np.getD (.str ""))] }
  | _ => match qy with
    | some q => runQuery db augs r q nq pr bf af out wact
    | none => out

/-! ## A store kept in a file between agents -/

/-- The store a new agent finds in an existing file database with `append` on (Soar 9.6.5
`epmem_init_db`). `stored` is the store as the earlier agent left it and `fresh` the new agent's
empty store with its own settings. The episodes and the node and edge numbers are kept; the next
episode follows the last one stored. Every interval still open is closed at the last episode
(`epmem_wmes_*_now` rows become points or ranges, an identifier edge's last episode becomes that
episode), each closed with the LTI it opened with, and every edge counts as closed
(`epmem_*_maxes`). The identifier edges' pools are rebuilt from all stored identifier edges, in
the order of their numbers, each put at the front of its (parent, attribute) pool. The encoder
starts over: only the top state will be known, as node 0. -/
def reopen (stored fresh : EpDB) : EpDB :=
  let tl := stored.time - 1
  let closeW (e : EEdge) : EEdge := match e.now with
    | some s => { e with now := none, closed := (s, tl) :: e.closed, closedLti := e.lti :: e.closedLti,
                         maxed := true, lastEp := (tl : Int) }
    | none => { e with maxed := true }
  let closeC (e : EEdge) : EEdge := match e.now with
    | some s => { e with now := none, closed := (s, tl) :: e.closed, maxed := true }
    | none => { e with maxed := true }
  let wis := stored.wis.map closeW
  let pools := wis.enum.foldl (fun (ps : List ((Nat × Sym) × List (Nat × Nat))) (k, e) =>
    match e.child with
    | .node c => alSet ps (e.parent, e.attr) ((c, k + 1) :: (alGet ps (e.parent, e.attr)).getD [])
    | .const _ => ps) []
  { fresh with wcs := stored.wcs.map closeC, wis := wis, time := stored.time,
               nextNode := stored.nextNode, pools := pools }

/-- Reopening continues the episode count of the stored episodes. -/
theorem reopen_time (stored fresh : EpDB) : (reopen stored fresh).time = stored.time := rfl

end EpDB
end Soar
