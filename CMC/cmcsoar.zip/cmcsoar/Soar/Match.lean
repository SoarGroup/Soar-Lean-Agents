import Soar.Syntax
import Std.Data.HashMap
/-!
# Soar 9.6 — matching productions against working memory

> "When variables are bound to specific symbols in working memory elements by Soar's
> matching process, Soar creates an instantiation of the production. This instantiation
> consists of the matched production along with a specific and consistent set of symbols that
> matched the variables. A production instantiation is consistent only if every occurrence of
> a variable is bound to the same value." — [Man] §2.3.1.1

The matcher below is executable. `match_sound` proves that every instantiation it returns
satisfies every positive condition of the production under the instantiation's final
bindings, through the working-memory element recorded for that condition.
-/

namespace Soar

/-- Variable bindings. -/
abbrev Binding := List (String × Sym)

def Binding.get (b : Binding) (v : String) : Option Sym :=
  (b.find? (fun p => p.1 == v)).map (·.2)

/-- The letter code Soar gives an identifier (`name_letter`, upper case), as the matcher is told it:
the bindings hold `#n` ↦ the code of identifier `n`'s letter (`St.letterBindings`), only for a
rule with an ordering test between identifiers. Without it the letter is 0 and identifiers compare
by number. -/
def Binding.letter (b : Binding) (n : Nat) : Nat :=
  match b.get s!"#{n}" with
  | some (.int c) => c.toNat
  | _ => 0

/-- `b'` extends `b`: every binding in `b` is kept, and no identifier's letter changes (a
variable whose name begins with `#` is never bound: `reservedKey`, `STest.run`). -/
structure Extends (b b' : Binding) : Prop where
  get : ∀ v x, b.get v = some x → b'.get v = some x
  letter : ∀ n, b'.letter n = b.letter n

instance {b b' : Binding} : CoeFun (Extends b b') (fun _ => ∀ v x, b.get v = some x → b'.get v = some x) :=
  ⟨Extends.get⟩

theorem Extends.refl (b : Binding) : Extends b b := ⟨fun _ _ h => h, fun _ => rfl⟩
theorem Extends.trans {a b c : Binding} (h₁ : Extends a b) (h₂ : Extends b c) : Extends a c :=
  ⟨fun v x h => h₂.get v x (h₁.get v x h), fun n => (h₂.letter n).trans (h₁.letter n)⟩

theorem get_cons_self (b : Binding) (v : String) (s : Sym) : Binding.get ((v, s) :: b) v = some s := by
  simp [Binding.get]

theorem get_cons_other (b : Binding) {v w : String} (s : Sym) (h : w ≠ v) :
    Binding.get ((v, s) :: b) w = b.get w := by
  simp [Binding.get, List.find?, show (v == w) = false from by simp [Ne.symm h]]

/-- Names the matcher never binds a variable to: they begin with `#` (a letter key, see
`Binding.letter`). -/
def reservedKey (v : String) : Bool := v.toList.head? == some '#'

theorem key_head_hash (n : Nat) : (s!"#{n}").toList.head? = some '#' := by
  have h : toString "#" = "#" := rfl
  simp [String.toList_append, h]

theorem key_head_at (n : Nat) : (s!"@{n}").toList.head? = some '@' := by
  have h : toString "@" = "@" := rfl
  simp [String.toList_append, h]

theorem letter_cons (b : Binding) (v : String) (s : Sym) (hk : reservedKey v = false) (n : Nat) :
    Binding.letter ((v, s) :: b) n = b.letter n := by
  have : s!"#{n}" ≠ v := by
    intro e; subst e
    unfold reservedKey at hk; rw [key_head_hash] at hk; simp at hk
  unfold Binding.letter; rw [get_cons_other _ _ this]

theorem reservedKey_at (m : Nat) : reservedKey s!"@{m}" = false := by
  unfold reservedKey; rw [key_head_at]; decide

theorem letter_cons_at (b : Binding) (m : Nat) (s : Sym) (n : Nat) :
    Binding.letter ((s!"@{m}", s) :: b) n = b.letter n :=
  letter_cons b _ s (reservedKey_at m) n

theorem extends_cons_fresh (b : Binding) (v : String) (s : Sym) (h : b.get v = none)
    (hk : reservedKey v = false) : Extends b ((v, s) :: b) := by
  refine ⟨?_, fun n => letter_cons b v s hk n⟩
  intro w x hw
  by_cases e : w = v
  · subst e; rw [h] at hw; cases hw
  · rw [get_cons_other _ _ e]; exact hw

/-! ### Long-term identifiers in bindings

Which long-term identifier an identifier is linked to is state of semantic memory, not of the
symbol. The matcher is given it in the initial bindings: `@n` ↦ the long-term identifier's
number, for each identifier `n` linked to one (`St.ltiBindings`). A test that finds an identifier
unlinked records that in its output bindings (`@n` ↦ `-`), so that extending the bindings
cannot change the test's outcome. -/

def Sym.ltiKey : Sym → Option String
  | .id n => some s!"@{n}"
  | _ => none

theorem reservedKey_ltiKey {s : Sym} {k : String} (h : s.ltiKey = some k) : reservedKey k = false := by
  cases s <;> simp [Sym.ltiKey] at h <;> (subst h; exact reservedKey_at _)

/-- The long-term identifier an identifier is linked to, if any. -/
def Sym.ltiNum (s : Sym) (b : Binding) : Option Sym :=
  match s.ltiKey with
  | some k => match b.get k with
    | some (.str "-") => none
    | x => x
  | none => none

/-- Record that an identifier's link is known (`-` if it has none). -/
def markLti (b : Binding) (s : Sym) : Binding :=
  match s.ltiKey with
  | some k => if (b.get k).isNone then (k, .str "-") :: b else b
  | none => b

def LtiBound (b : Binding) (s : Sym) : Prop := ∀ k, s.ltiKey = some k → (b.get k).isSome

theorem markLti_extends (b : Binding) (s : Sym) : Extends b (markLti b s) := by
  cases s with
  | id n =>
    unfold markLti; simp only [Sym.ltiKey]
    split
    · rename_i h
      exact extends_cons_fresh _ _ _ (by simpa using h) (reservedKey_at n)
    · exact Extends.refl _
  | str _ => exact Extends.refl _
  | int _ => exact Extends.refl _
  | float _ => exact Extends.refl _

theorem ltiNum_markLti (b : Binding) (s x : Sym) : s.ltiNum (markLti b x) = s.ltiNum b := by
  unfold markLti
  split
  · rename_i kx hx
    split
    · rename_i hn
      have hn' : b.get kx = none := by simpa using hn
      unfold Sym.ltiNum
      split
      · rename_i ks hs
        by_cases e : ks = kx
        · subst e; rw [get_cons_self, hn']; rfl
        · rw [get_cons_other _ _ e]
      · rfl
    · rfl
  · rfl

theorem ltiBound_markLti_self (b : Binding) (s : Sym) : LtiBound (markLti b s) s := by
  intro k hk
  unfold markLti; rw [hk]; simp only
  split
  · simp [get_cons_self]
  · rename_i h; cases hg : b.get k with
    | none => simp [hg] at h
    | some _ => rfl

theorem ltiBound_markLti (b : Binding) (s x : Sym) (h : LtiBound b s) : LtiBound (markLti b x) s := by
  intro k hk
  have hb := h k hk
  unfold markLti
  split
  · split
    · rename_i kx _ _
      by_cases e : k = kx
      · subst e; simp [get_cons_self]
      · rw [get_cons_other _ _ e]; exact hb
    · exact hb
  · exact hb

theorem ltiBound_extends {b b' : Binding} {s : Sym} (h : LtiBound b s) (he : Extends b b') : LtiBound b' s := by
  intro k hk
  have hb := h k hk
  cases hg : b.get k with
  | none => rw [hg] at hb; cases hb
  | some x => rw [he k x hg]; rfl

theorem ltiNum_extends {b b' : Binding} {s : Sym} (h : LtiBound b s) (he : Extends b b') :
    s.ltiNum b' = s.ltiNum b := by
  unfold Sym.ltiNum
  split
  · rename_i k hk
    have hb := h k hk
    cases hg : b.get k with
    | none => rw [hg] at hb; cases hb
    | some x => rw [he k x hg]
  · rfl

theorem markLti_bound {b : Binding} {s : Sym} (h : LtiBound b s) : markLti b s = b := by
  unfold markLti
  split
  · rename_i k hk
    have hb := h k hk
    split
    · rename_i hn; rw [Option.isSome_iff_ne_none] at hb; simp_all
    · rfl
  · rfl

def Term.value (b : Binding) : Term → Option Sym
  | .var v => b.get v
  | .sym s => some s

def Sym.typeTag : Sym → Nat
  | .id _ => 0 | .str _ => 1 | .int _ => 2 | .float _ => 3

/-- Semantics of the relational predicates ([Man] §3.3.5.3), given each identifier's letter `L`.
The numeric ones hold between numbers (integers and reals).

Soar 9.6.5 `compare_symbols` (rete.cpp:4455-4466) orders identifiers by their letter, then their
number; `L` gives the letter (`Binding.letter`). Two letters compare by their codes, as in
`numcmp(name_letter, name_letter)`; the model numbers identifiers by one counter, which orders the
identifiers of one letter as Soar's counter for the letter does.

SIMPLIFIED: Soar compares two integers by `s1 - s2` in 64 bits, which overflows
(rete.cpp:4430); the model compares exactly. -/
def RelOp.holdsL (L : Nat → Nat) : RelOp → Sym → Sym → Bool
  | .ne, a, b => a != b
  | .sameType, a, b => a.typeTag == b.typeTag
  | .lt, .int a, .int b => decide (a < b)
  | .le, .int a, .int b => decide (a ≤ b)
  | .ge, .int a, .int b => decide (a ≥ b)
  | .gt, .int a, .int b => decide (a > b)
  | r, a, b => match a.num?, b.num? with
    | some x, some y => match r with
      | .lt => x < y | .le => x ≤ y | .ge => x ≥ y | .gt => x > y | _ => false
    | _, _ =>
      -- Soar 9.6.5 (`compare_symbols`, checked 2026-10-29): symbolic constants compare
      -- alphabetically, identifiers by letter and number, and a symbol of another type than the
      -- value compared against counts as less (so `foo < 5` and `3 < foo` both hold)
      let c : Int := match a, b with
        | .str x, .str y => if x < y then -1 else if x == y then 0 else 1
        | .id x, .id y => if L x == L y then (x : Int) - y else (L x : Int) - L y
        | _, _ => -1
      match r with
      | .lt => c < 0 | .le => c ≤ 0 | .ge => c ≥ 0 | .gt => c > 0 | _ => false

/-- One simple test against a symbol, extending the bindings if a new variable is bound. -/
def STest.run (b : Binding) (s : Sym) : STest → Option Binding
  | .var v => match reservedKey v with
    | true => none
    | false => match b.get v with
      | some x => if x = s then some b else none
      | none => some ((v, s) :: b)
  | .const c => if c = s then some b else none
  | .rel r t => match t.value b with
    | some x => if r.holdsL b.letter s x then some b else none
    | none => none
  | .disj cs => if cs.contains s then some b else none
  -- the long-term identifier an identifier is linked to is given in the bindings, under `@n`
  -- (see `St.ltiBindings`)
  | .lti pos => if (s.ltiNum b).isSome == pos then some (markLti b s) else none
  | .ltiRel pos t =>
    match t with
    | .var v => match b.get v with
      | some x =>
        if ((s.ltiNum b).isSome && s.ltiNum b == x.ltiNum b) == pos then some (markLti (markLti b s) x) else none
      | none => none
    | .sym c =>
      if ((s.ltiNum b).isSome && s.ltiNum b == some c) == pos then some (markLti b s) else none

def runTest (b : Binding) (s : Sym) : Test → Option Binding
  | [] => some b
  | t :: ts => match t.run b s with
    | some b' => runTest b' s ts
    | none => none

def Pat.run (b : Binding) (p : Pat) (w : WME) : Option Binding :=
  if w.acc = p.acc then
    match runTest b (.id w.id) p.id with
    | none => none
    | some b₁ => match runTest b₁ w.attr p.attr with
      | none => none
      | some b₂ => runTest b₂ w.val p.val
  else none

/-- All ways a conjunction of patterns matches, from bindings `b`. -/
def matchPats (wm : List WME) : List Pat → Binding → List Binding
  | [], b => [b]
  | p :: ps, b => wm.flatMap fun w => match p.run b w with
    | some b' => matchPats wm ps b'
    | none => []

mutual
/-- Does a negated conjunction (as a tree) match from bindings `b`: some extension of `b`
matches its positive patterns and makes every inner negation succeed? -/
def NegTree.holds (wm : List WME) : NegTree → Binding → Bool
  | .node ps ns, b => (matchPats wm ps b).any fun b' => NegTree.noneHold wm ns b'
/-- No tree of the list holds from `b` (every inner negation of a node succeeds). -/
def NegTree.noneHold (wm : List WME) : List NegTree → Binding → Bool
  | [], _ => true
  | n :: ns, b => !NegTree.holds wm n b && NegTree.noneHold wm ns b
end

/-- All instantiations of a condition list: the bindings and, for each positive condition,
the element it matched (in order). A negated conjunction succeeds when no extension of the
current bindings matches it. -/
def matchConds (wm : List WME) : List Cond → Binding → List (Binding × List WME)
  | [], b => [(b, [])]
  | .pos p :: cs, b => wm.flatMap fun w => match p.run b w with
    | some b' => (matchConds wm cs b').map fun r => (r.1, w :: r.2)
    | none => []
  | .neg ps :: cs, b => if (matchPats wm ps b).isEmpty then matchConds wm cs b else []
  | .ncc ps ns :: cs, b =>
    if (matchPats wm ps b).any (fun b' => ns.all fun n => (matchPats wm n b').isEmpty) then []
    else matchConds wm cs b
  | .nccg ns :: cs, b => if ns.tree.holds wm b then [] else matchConds wm cs b

/-- A negated conjunction is the case of `ncc` with no inner negations. -/
theorem matchConds_neg_eq_ncc (wm : List WME) (ps : List Pat) (cs : List Cond) (b : Binding) :
    matchConds wm (.neg ps :: cs) b = matchConds wm (.ncc ps [] :: cs) b := by
  simp only [matchConds, List.all_nil]
  cases hl : matchPats wm ps b <;> simp

/-! ## Soundness of the matcher -/

theorem STest.run_var {b b' : Binding} {s : Sym} {v : String} (h : (STest.var v).run b s = some b') :
    reservedKey v = false ∧ ((b.get v = some s ∧ b' = b) ∨ (b.get v = none ∧ b' = (v, s) :: b)) := by
  simp only [STest.run] at h
  cases hr : reservedKey v with
  | true => simp [hr] at h
  | false =>
    simp only [hr] at h
    refine ⟨rfl, ?_⟩
    cases hg : b.get v with
    | none => simp [hg] at h; exact Or.inr ⟨rfl, h.symm⟩
    | some x =>
      simp only [hg] at h
      split at h
      · rename_i e; cases h; exact Or.inl ⟨by rw [e], rfl⟩
      · cases h

theorem STest.run_extends {b b' : Binding} {s : Sym} {t : STest} (h : t.run b s = some b') :
    Extends b b' := by
  cases t with
  | var v =>
    obtain ⟨hr, h1 | ⟨hn, h2⟩⟩ := STest.run_var h
    · rw [h1.2]; exact Extends.refl _
    · rw [h2]; exact extends_cons_fresh _ _ _ hn hr
  | const c => simp only [STest.run] at h; split at h <;> cases h; exact Extends.refl _
  | rel r t =>
    simp only [STest.run] at h
    split at h
    · split at h <;> cases h; exact Extends.refl _
    · cases h
  | disj cs => simp only [STest.run] at h; split at h <;> cases h; exact Extends.refl _
  | lti pos => simp only [STest.run] at h; split at h <;> cases h; exact markLti_extends _ _
  | ltiRel pos t =>
    simp only [STest.run] at h
    split at h
    · split at h
      · split at h <;> cases h
        exact Extends.trans (markLti_extends _ _) (markLti_extends _ _)
      · cases h
    · split at h <;> cases h; exact markLti_extends _ _

/-- A simple test that succeeded still succeeds, without further binding, under any
extension of its output bindings. -/
theorem STest.run_stable {b b' b'' : Binding} {s : Sym} {t : STest} (h : t.run b s = some b')
    (he : Extends b' b'') : t.run b'' s = some b'' := by
  have hb : Extends b b'' := Extends.trans (STest.run_extends h) he
  cases t with
  | var v =>
    obtain ⟨hr, h1 | ⟨hn, h2⟩⟩ := STest.run_var h
    · have := hb v s h1.1
      simp only [STest.run, hr, this]; simp
    · have := he v s (by rw [h2]; exact get_cons_self _ _ _)
      simp only [STest.run, hr, this]; simp
  | const c => simp only [STest.run] at h ⊢; split at h <;> cases h; rename_i e; rw [ite_eq_left e]
  | rel r t =>
    simp only [STest.run] at h ⊢
    split at h
    · rename_i x hx
      split at h <;> cases h
      rename_i hr
      have : t.value b'' = some x := by
        cases t with
        | var v => exact hb v x hx
        | sym s' => exact hx
      have hl : b''.letter = b.letter := funext (fun n => hb.letter n)
      rw [this, hl]; simp [hr]
    · cases h
  | disj cs => simp only [STest.run] at h ⊢; split at h <;> cases h; rename_i e; rw [ite_eq_left e]
  | lti pos =>
    simp only [STest.run] at h ⊢
    split at h
    · rename_i e; cases h
      have hb := ltiBound_extends (ltiBound_markLti_self b s) he
      rw [ltiNum_extends (ltiBound_markLti_self b s) he, ltiNum_markLti, e]
      simp [markLti_bound hb]
    · cases h
  | ltiRel pos t =>
    simp only [STest.run] at h ⊢
    split at h
    · rename_i v
      split at h
      · rename_i x hx
        split at h
        · rename_i e; cases h
          have h1 : LtiBound (markLti (markLti b s) x) s := ltiBound_markLti _ _ _ (ltiBound_markLti_self _ _)
          have h2 : LtiBound (markLti (markLti b s) x) x := ltiBound_markLti_self _ _
          rw [hb v x hx]
          simp only
          rw [ltiNum_extends h1 he, ltiNum_extends h2 he, ltiNum_markLti, ltiNum_markLti, ltiNum_markLti,
            ltiNum_markLti, e]
          simp [markLti_bound (ltiBound_extends h1 he), markLti_bound (ltiBound_extends h2 he)]
        · cases h
      · cases h
    · split at h
      · rename_i e; cases h
        have h1 := ltiBound_markLti_self b s
        rw [ltiNum_extends h1 he, ltiNum_markLti, e]
        simp [markLti_bound (ltiBound_extends h1 he)]
      · cases h

theorem runTest_extends {b b' : Binding} {s : Sym} {ts : Test} (h : runTest b s ts = some b') :
    Extends b b' := by
  induction ts generalizing b with
  | nil => cases h; exact Extends.refl _
  | cons t ts ih =>
    simp only [runTest] at h
    split at h
    · rename_i b₁ h₁; exact Extends.trans (STest.run_extends h₁) (ih h)
    · cases h

theorem runTest_stable {b b' b'' : Binding} {s : Sym} {ts : Test} (h : runTest b s ts = some b')
    (he : Extends b' b'') : runTest b'' s ts = some b'' := by
  induction ts generalizing b with
  | nil => rfl
  | cons t ts ih =>
    simp only [runTest] at h ⊢
    split at h
    · rename_i b₁ h₁
      rw [STest.run_stable h₁ (Extends.trans (runTest_extends h) he)]
      exact ih h
    · cases h

theorem Pat.run_extends {b b' : Binding} {p : Pat} {w : WME} (h : p.run b w = some b') :
    Extends b b' := by
  unfold Pat.run at h
  split at h
  · split at h
    · cases h
    · rename_i b₁ h₁
      split at h
      · cases h
      · rename_i b₂ h₂
        exact Extends.trans (runTest_extends h₁) (Extends.trans (runTest_extends h₂) (runTest_extends h))
  · cases h

/-- **A matched pattern stays matched.** If a pattern matched an element from some bindings,
it matches the same element, with no new bindings, under any extension of the result. -/
theorem Pat.run_stable {b b' b'' : Binding} {p : Pat} {w : WME} (h : p.run b w = some b')
    (he : Extends b' b'') : p.run b'' w = some b'' := by
  unfold Pat.run at h ⊢
  split at h
  · rename_i hacc
    simp only [hacc, ↓reduceIte]
    split at h
    · cases h
    · rename_i b₁ h₁
      split at h
      · cases h
      · rename_i b₂ h₂
        have e₂ := Extends.trans (runTest_extends h) he
        have e₁ := Extends.trans (runTest_extends h₂) e₂
        rw [runTest_stable h₁ e₁]; simp only
        rw [runTest_stable h₂ e₂]; simp only
        exact runTest_stable h he
  · cases h

/-- The positive patterns of a condition list, in order. -/
def positives : List Cond → List Pat
  | [] => []
  | .pos p :: cs => p :: positives cs
  | .neg _ :: cs => positives cs
  | .ncc _ _ :: cs => positives cs
  | .nccg _ :: cs => positives cs

theorem matchConds_extends {wm : List WME} {cs : List Cond} {b : Binding}
    {r : Binding × List WME} (h : r ∈ matchConds wm cs b) : Extends b r.1 := by
  induction cs generalizing b r with
  | nil => simp [matchConds] at h; subst h; exact Extends.refl _
  | cons c cs ih =>
    cases c with
    | pos p =>
      simp only [matchConds, List.mem_flatMap] at h
      obtain ⟨w, _, hw⟩ := h
      split at hw
      · rename_i b' hb'
        simp only [List.mem_map] at hw
        obtain ⟨r', hr', rfl⟩ := hw
        exact Extends.trans (Pat.run_extends hb') (ih (r := r') hr')
      · cases hw
    | neg ps =>
      simp only [matchConds] at h
      split at h
      · exact ih h
      · cases h
    | ncc ps ns =>
      simp only [matchConds] at h
      split at h
      · cases h
      · exact ih h
    | nccg ns =>
      simp only [matchConds] at h
      split at h
      · cases h
      · exact ih h

/-- **Soundness of matching (positive conditions).** For every instantiation the matcher
returns, the recorded elements are in working memory, one per positive condition, and each
positive condition matches its element under the instantiation's final bindings. -/
theorem match_sound {wm : List WME} {cs : List Cond} {b : Binding}
    {r : Binding × List WME} (h : r ∈ matchConds wm cs b) :
    r.2.length = (positives cs).length ∧
    ∀ i (hi : i < r.2.length) (hp : i < (positives cs).length),
      r.2[i] ∈ wm ∧ (positives cs)[i].run r.1 r.2[i] = some r.1 := by
  induction cs generalizing b r with
  | nil =>
    simp [matchConds] at h; subst h
    exact ⟨rfl, fun i hi => by simp at hi⟩
  | cons c cs ih =>
    cases c with
    | pos p =>
      simp only [matchConds, List.mem_flatMap] at h
      obtain ⟨w, hwm, hw⟩ := h
      split at hw
      · rename_i b' hb'
        simp only [List.mem_map] at hw
        obtain ⟨r', hr', rfl⟩ := hw
        obtain ⟨hlen, hall⟩ := ih (r := r') hr'
        refine ⟨by simp [positives, hlen], fun i hi hp => ?_⟩
        cases i with
        | zero =>
          exact ⟨hwm, Pat.run_stable hb' (matchConds_extends (r := r') hr')⟩
        | succ j =>
          simp only [positives, List.getElem_cons_succ]
          exact hall j (by simpa using hi) (by simpa [positives] using hp)
      · cases hw
    | neg ps =>
      simp only [matchConds] at h
      split at h
      · obtain ⟨hlen, hall⟩ := ih h
        exact ⟨by simpa [positives] using hlen, fun i hi hp => hall i hi hp⟩
      · cases h
    | ncc ps ns =>
      simp only [matchConds] at h
      split at h
      · cases h
      · obtain ⟨hlen, hall⟩ := ih h
        exact ⟨by simpa [positives] using hlen, fun i hi hp => hall i hi hp⟩
    | nccg ns =>
      simp only [matchConds] at h
      split at h
      · cases h
      · obtain ⟨hlen, hall⟩ := ih h
        exact ⟨by simpa [positives] using hlen, fun i hi hp => hall i hi hp⟩

/-! ## Matching through an index on identifiers

The matcher above scans all of working memory for every condition. `matchCondsIx` scans only
the elements on the identifier a condition's identifier test fixes, found through an index
`WmIndex`; `matchCondsIx_eq` proves that it returns exactly what `matchConds` returns, in the
same order. The index's lookup `WmIndex.onId` is defined as a filter of working memory; the
compiled program looks the identifier up in a hash table built from working memory in the
same order (`WmIndex.onIdTable`). An index carries the proof that its table agrees with its
working memory (`WmIndex.ok`, established for `WmIndex.ofList` by `WmIndex.fold_ok`), so the
lookup is proved equal to the filter (`WmIndex.onId_eq_onIdTable`) and the compiler is told to
use it by that theorem (`@[csimp]`): no step here is unproved. -/

/-- Working memory with a table of its elements by identifier, each list in the order of
working memory. -/
structure WmIndex where
  wm : List WME
  tbl : Std.HashMap Nat (Array WME)
  /-- The table holds, under each identifier, the elements on it in the order of working
  memory. -/
  ok : ∀ n, (tbl.getD n #[]).toList = wm.filter (·.id == n)

/-- Building the table element by element keeps it in agreement with the elements seen so far.
(`alter` updates a bucket in place: S27 in the code review, for `insert` of a copy of the array.) -/
theorem WmIndex.fold_ok (rest acc : List WME) (m : Std.HashMap Nat (Array WME))
    (h : ∀ n, (m.getD n #[]).toList = acc.filter (·.id == n)) :
    ∀ n, ((rest.foldl (fun m w => m.alter w.id (fun o => some ((o.getD #[]).push w))) m).getD n #[]).toList
      = (acc ++ rest).filter (·.id == n) := by
  induction rest generalizing acc m with
  | nil => simpa using h
  | cons w rest ih =>
    intro n
    simp only [List.foldl_cons]
    have := ih (acc ++ [w]) (m.alter w.id (fun o => some ((o.getD #[]).push w))) (by
      intro k
      rw [Std.HashMap.getD_eq_getD_getElem?, Std.HashMap.getElem?_alter]
      by_cases hk : w.id = k
      · subst hk
        have h1 := h w.id
        rw [Std.HashMap.getD_eq_getD_getElem?] at h1
        simp [h1, List.filter_append]
      · have : (w.id == k) = false := by simpa using hk
        have h1 := h k
        rw [Std.HashMap.getD_eq_getD_getElem?] at h1
        simp [this, h1, List.filter_append])
    simpa using this n

def WmIndex.ofList (wm : List WME) : WmIndex :=
  { wm := wm, tbl := wm.foldl (fun m w => m.alter w.id (fun o => some ((o.getD #[]).push w))) {},
    ok := fun n => by simpa using WmIndex.fold_ok wm [] {} (fun k => by simp) n }

/-- The elements on identifier `n`, looked up in the table (what the compiled program runs). -/
def WmIndex.onIdTable (ix : WmIndex) (n : Nat) : List WME := (ix.tbl.getD n #[]).toList

/-- The elements on identifier `n`, in the order of working memory. -/
def WmIndex.onId (ix : WmIndex) (n : Nat) : List WME := ix.wm.filter (·.id == n)

/-- **The table lookup is the filter.** Used by the compiler in place of `WmIndex.onId`. -/
@[csimp] theorem WmIndex.onId_eq_onIdTable : @WmIndex.onId = @WmIndex.onIdTable := by
  funext ix n; exact (ix.ok n).symm

/-- The identifier that a simple test fixes under `b`, if it fixes one. -/
def STest.idOf (b : Binding) : STest → Option Nat
  | .var v => match b.get v with
    | some (.id n) => some n
    | _ => none
  | .const (.id n) => some n
  | _ => none

/-- The identifier that a pattern's identifier test fixes under `b`, if it fixes one. -/
def Pat.idKey (b : Binding) (p : Pat) : Option Nat := p.id.findSome? (STest.idOf b)

theorem STest.idOf_some {b : Binding} {st : STest} {n : Nat} (h : st.idOf b = some n) :
    (∃ v, st = .var v ∧ b.get v = some (.id n)) ∨ st = .const (.id n) := by
  cases st with
  | var v =>
    left; refine ⟨v, rfl, ?_⟩
    simp only [STest.idOf] at h
    split at h
    · rename_i m hm; cases h; exact hm
    · cases h
  | const c =>
    right
    cases c with
    | id m => simp only [STest.idOf] at h; cases h; rfl
    | _ => simp [STest.idOf] at h
  | rel _ _ => simp [STest.idOf] at h
  | disj _ => simp [STest.idOf] at h
  | lti _ => simp [STest.idOf] at h
  | ltiRel _ _ => simp [STest.idOf] at h

/-- The elements a pattern can match under `b`. -/
def Pat.cands (ix : WmIndex) (b : Binding) (p : Pat) : List WME :=
  match p.idKey b with
  | some n => ix.onId n
  | none => ix.wm

def matchPatsIx (ix : WmIndex) : List Pat → Binding → List Binding
  | [], b => [b]
  | p :: ps, b => (p.cands ix b).flatMap fun w => match p.run b w with
    | some b' => matchPatsIx ix ps b'
    | none => []

def matchCondsIx (ix : WmIndex) : List Cond → Binding → List (Binding × List WME)
  | [], b => [(b, [])]
  | .pos p :: cs, b => (p.cands ix b).flatMap fun w => match p.run b w with
    | some b' => (matchCondsIx ix cs b').map fun r => (r.1, w :: r.2)
    | none => []
  | .neg ps :: cs, b => if (matchPatsIx ix ps b).isEmpty then matchCondsIx ix cs b else []
  | .ncc ps ns :: cs, b =>
    if (matchPatsIx ix ps b).any (fun b' => ns.all fun n => (matchPatsIx ix n b').isEmpty) then []
    else matchCondsIx ix cs b
  -- (deeper negations are rare; they are matched against working memory directly)
  | .nccg ns :: cs, b => if ns.tree.holds ix.wm b then [] else matchCondsIx ix cs b

theorem runTest_fixed {b b' : Binding} {s : Sym} {t : Test} (h : runTest b s t = some b')
    {st : STest} (hm : st ∈ t) :
    (∀ v x, st = .var v → b.get v = some x → x = s) ∧ (∀ c, st = .const c → c = s) := by
  induction t generalizing b with
  | nil => cases hm
  | cons t₀ ts ih =>
    simp only [runTest] at h
    split at h
    · rename_i b₁ h₁
      rcases List.mem_cons.mp hm with e | hm
      · subst e
        refine ⟨fun v x hv hx => ?_, fun c hc => ?_⟩
        · subst hv
          obtain ⟨_, h1 | ⟨hn, _⟩⟩ := STest.run_var h₁
          · rw [hx] at h1; exact Option.some.inj h1.1
          · rw [hx] at hn; cases hn
        · subst hc; simp only [STest.run] at h₁
          split at h₁
          · assumption
          · cases h₁
      · obtain ⟨h₁v, h₁c⟩ := ih h hm
        exact ⟨fun v x hv hx => h₁v v x hv ((STest.run_extends h₁) v x hx), h₁c⟩
    · cases h

/-- A pattern that matches an element under `b` matches one on the identifier it fixes. -/
theorem Pat.idKey_run {b : Binding} {p : Pat} {w : WME} {n : Nat} (hk : p.idKey b = some n)
    (hr : (p.run b w).isSome) : w.id = n := by
  unfold Pat.idKey at hk
  obtain ⟨st, hm, hst⟩ := List.exists_of_findSome?_eq_some hk
  unfold Pat.run at hr
  split at hr
  · split at hr
    · cases hr
    · rename_i b₁ h₁
      obtain ⟨hv, hc⟩ := runTest_fixed h₁ hm
      rcases STest.idOf_some hst with ⟨v, e, hb⟩ | e
      · have := hv v _ e hb; cases this; rfl
      · have := hc _ e; cases this; rfl
  · cases hr

theorem flatMap_filter_of {l : List α} {q : α → Bool} {f : α → List β}
    (h : ∀ a, q a = false → f a = []) : (l.filter q).flatMap f = l.flatMap f := by
  induction l with
  | nil => rfl
  | cons a l ih =>
    by_cases hq : q a
    · simp [List.filter_cons, hq, ih]
    · simp [List.filter_cons, hq, ih, h a (by simpa using hq)]

/-- Scanning the candidates gives what scanning all of working memory gives. -/
theorem Pat.cands_flatMap (ix : WmIndex) (b : Binding) (p : Pat) (f : Binding → WME → List β) :
    (p.cands ix b).flatMap (fun w => match p.run b w with | some b' => f b' w | none => []) =
    ix.wm.flatMap (fun w => match p.run b w with | some b' => f b' w | none => []) := by
  unfold Pat.cands
  split
  · rename_i n hk
    unfold WmIndex.onId
    apply flatMap_filter_of
    intro w hq
    cases hr : p.run b w with
    | none => rfl
    | some b' =>
      have e := Pat.idKey_run (w := w) hk (by simp [hr])
      have ht : (w.id == n) = true := by rw [e]; exact beq_self_eq_true n
      rw [ht] at hq; cases hq
  · rfl

theorem matchPatsIx_eq (ix : WmIndex) (ps : List Pat) (b : Binding) :
    matchPatsIx ix ps b = matchPats ix.wm ps b := by
  induction ps generalizing b with
  | nil => rfl
  | cons p ps ih =>
    simp only [matchPatsIx, matchPats]
    have := Pat.cands_flatMap ix b p (fun b' _ => matchPatsIx ix ps b')
    rw [this]; congr 1; funext w; split <;> simp [ih]

/-- The indexed matcher returns exactly what `matchConds` returns, in the same order. -/
theorem matchCondsIx_eq (ix : WmIndex) (cs : List Cond) (b : Binding) :
    matchCondsIx ix cs b = matchConds ix.wm cs b := by
  induction cs generalizing b with
  | nil => rfl
  | cons c cs ih =>
    cases c with
    | pos p =>
      simp only [matchCondsIx, matchConds]
      have := Pat.cands_flatMap ix b p (fun b' w => (matchCondsIx ix cs b').map fun r => (r.1, w :: r.2))
      rw [this]; congr 1; funext w; split <;> simp [ih]
    | neg ps => simp only [matchCondsIx, matchConds, matchPatsIx_eq, ih]
    | ncc ps ns => simp only [matchCondsIx, matchConds, matchPatsIx_eq, ih]
    | nccg ns => simp only [matchCondsIx, matchConds, ih]

end Soar

namespace Soar

/-! ## Join order

Soar matches conditions in an order of its own choosing:

> "The order of the conditions of a production do not matter to Soar except that the first
> condition must directly test the state. Internally, Soar will reorder the conditions so
> that the matching process can be more efficient." — [Man] §2.3.1

The matcher above evaluates conditions left to right, binding variables as it goes, so the
order matters to it in two ways: efficiency, and a relational test or negated condition
whose variable is bound only by a later condition. `joinOrder` produces an order in which
every relational test and negation comes after the conditions that bind its variables, and
in which each next pattern is the most constrained one available.

Soar/JoinOrder.lean proves that `joinOrder` returns the rule's own conditions reordered, up to
where relational tests sit (`joinOrder_strip`), and exactly a permutation for a rule with no
relational test between variables (`joinOrder_perm`).
Soar/JoinOrderSem.lean proves that, when the relational tests between variables compare values
of one kind, the positive patterns of the join order hold under the same bindings as the rule's
own (`joinOrder_posSat`) and the matcher finds the same instantiations (`joinOrder_matches`,
`joinOrder_matches_rev`). OPEN: the same for negations, and for Soar's reorderer (which in the
model affects only chunking).
Checked against Soar 9.6.5 on the test corpus. -/

/-- The variables an equality test binds. -/
def STest.eqVars : STest → List String
  | .var v => [v]
  | _ => []

/-- The variables a relational test reads. -/
def STest.useVars : STest → List String
  | .rel _ (.var v) => [v]
  | .ltiRel _ (.var v) => [v]
  | _ => []

def Pat.eqVars (p : Pat) : List String := (p.id ++ p.attr ++ p.val).flatMap STest.eqVars
def Pat.useVars (p : Pat) : List String := (p.id ++ p.attr ++ p.val).flatMap STest.useVars

/-- Variables a condition needs bound before it is evaluated. For a negated conjunction:
the variables it shares with the positive conditions. -/
def Cond.needs (positiveVars : List String) : Cond → List String
  | .pos p => p.useVars.filter (fun v => !p.eqVars.contains v)
  | c =>
    let all := c.pats
    (all.flatMap Pat.eqVars ++ all.flatMap Pat.useVars).filter positiveVars.contains

def testBound (bound : List String) (t : Test) : Bool :=
  t.any fun s => match s with
    | .const _ => true | .disj _ => true
    | .var v => bound.contains v
    | _ => false

/-- How constrained a pattern is, given the variables bound so far. -/
def Pat.score (bound : List String) (p : Pat) : Nat :=
  4 * (if testBound bound p.id then 1 else 0) + (if testBound bound p.attr then 1 else 0) +
  2 * (if testBound bound p.val then 1 else 0)

/-- The expected number of values of a pattern's attribute: as declared by
`multi-attributes` when its identifier is bound, its attribute a constant, its value not yet
bound and every test an equality test (Soar 9.6.5 `cost_of_adding_condition`); else 1. -/
def Pat.multiCost (multi : List (String × Nat)) (bound : List String) (p : Pat) : Nat :=
  match p.id, p.attr, p.val with
  | [.var i], [.const (.str a)], [.var v] =>
    if bound.contains i && !bound.contains v then ((alGet multi a)).getD 1 else 1
  | _, _, _ => 1

/-- Recency of the identifier variable's binding (larger is more recent). -/
def Pat.recency (bound : List String) (p : Pat) : Nat :=
  match p.id with
  | [.var v] => match bound.idxOf? v with | some i => i + 1 | none => 0
  | _ => 0

def RelOp.inv : RelOp → RelOp
  | .lt => .gt | .gt => .lt | .le => .ge | .ge => .le | r => r

/-- The equality term of a test (its first variable or constant). -/
def eqTerm? (t : Test) : Option Term :=
  t.findSome? fun st => match st with
    | .var v => some (.var v) | .const c => some (.sym c) | _ => none

/-- One step of `splitRel`. -/
def splitRelStep (ok : String → Bool) (me : Term) (acc : Test × List (String × STest)) (st : STest) :
    Test × List (String × STest) :=
  match st with
  | .rel r (.var y) => if ok y then (acc.1 ++ [st], acc.2) else (acc.1, acc.2 ++ [(y, .rel r.inv me)])
  -- `@` and `!@` are symmetric
  | .ltiRel b (.var y) => if ok y then (acc.1 ++ [st], acc.2) else (acc.1, acc.2 ++ [(y, .ltiRel b me)])
  | st => (acc.1 ++ [st], acc.2)

/-- Remove from a test the relational tests against variables not yet bound (and not bound by
the pattern itself), returning each as the inverted test to place where that variable is
bound: `x op y` becomes `y op⁻¹ x`. -/
def splitRel (ok : String → Bool) (t : Test) : Test × List (String × STest) :=
  match eqTerm? t with
  | none => (t, [])
  | some me => t.foldl (splitRelStep ok me) ([], [])

/-- Add a test to the element of a pattern whose equality test binds `y`. -/
def Pat.addFor (y : String) (st : STest) (p : Pat) : Option Pat :=
  let has (t : Test) : Bool := eqTerm? t == some (.var y)
  if has p.val then some { p with val := p.val ++ [st] }
  else if has p.id then some { p with id := p.id ++ [st] }
  else if has p.attr then some { p with attr := p.attr ++ [st] }
  else none

/-- One step of `placeRel`. -/
def placeStep (m : String × STest) (acc : List Cond × Bool) (c : Cond) : List Cond × Bool :=
  if acc.2 then (acc.1 ++ [c], true) else match c with
  | .pos q => match q.addFor m.1 m.2 with
    | some q' => (acc.1 ++ [.pos q'], true)
    | none => (acc.1 ++ [c], false)
  | c => (acc.1 ++ [c], false)

/-- Add a moved test `m.2` to the first positive condition that binds `m.1`; the flag says
whether one was found. -/
def placeRel (cs : List Cond) (m : String × STest) : List Cond × Bool :=
  cs.foldl (placeStep m) ([], false)

/-- One step of placing the moved tests. -/
def placeAllStep (acc : List Cond × Bool) (m : String × STest) : List Cond × Bool :=
  ((placeRel acc.1 m).1, acc.2 && (placeRel acc.1 m).2)

/-- When every remaining positive condition tests a variable not yet bound (a cycle of
relational tests), the chosen one's relational tests on unbound variables are moved, inverted,
to the conditions that bind those variables (as Soar 9.6.5's reorderer does with its saved
tests). -/
def moveRel (bound : List String) (best : Cond) (rest : List Cond) : Cond × List Cond :=
  match best with
  | .pos p =>
    let ok (y : String) := bound.contains y || p.eqVars.contains y
    let moved := (splitRel ok p.id).2 ++ (splitRel ok p.attr).2 ++ (splitRel ok p.val).2
    let r := moved.foldl placeAllStep (rest, true)
    let p' : Pat := { p with id := (splitRel ok p.id).1, attr := (splitRel ok p.attr).1, val := (splitRel ok p.val).1 }
    if r.2 then (.pos p', r.1) else (best, rest)
  | c => (c, rest)

/-- The better of two candidate patterns for the next join (`joinOrder`): higher score, then
lower expected cost, then more recent identifier binding; the earlier one on ties. -/
def pickBest (multi : List (String × Nat)) (bound : List String) (b c : Cond) : Cond :=
  match b, c with
  | .pos pb, .pos pc =>
    let (sb, mb, rb) := (pb.score bound, pb.multiCost multi bound, pb.recency bound)
    let (sc, mc, rc) := (pc.score bound, pc.multiCost multi bound, pc.recency bound)
    if sc > sb || (sc == sb && (mc < mb || (mc == mb && rc > rb))) then c else b
  | _, _ => b

/-- The variables bound once a condition is added to the join. -/
def bindNext (bound : List String) : Cond → List String
  | .pos p => bound ++ (p.eqVars.filter (!bound.contains ·))
  | _ => bound

def joinOrder (cs : List Cond) (multi : List (String × Nat) := []) : List Cond :=
  let positiveVars := cs.flatMap fun c => match c with | .pos p => p.eqVars | _ => []
  go multi (cs.length + 1) cs [] [] positiveVars
where
  go (multi : List (String × Nat)) : Nat → List Cond → List String → List Cond → List String → List Cond
  | 0, rest, _, acc, _ => acc ++ rest
  | n + 1, rest, bound, acc, pv =>
    if rest.isEmpty then acc else
    -- negations and relational tests whose variables are now bound go first
    let ready := rest.filter fun c => match c with
      | .pos _ => false
      | _ => (c.needs pv).all bound.contains
    if !ready.isEmpty then
      go multi n (rest.filter fun c => !ready.any (fun r => decide (r = c))) bound (acc ++ ready) pv
    else
      let eligible := rest.filter fun c => match c with
        | .pos _ => (c.needs pv).all bound.contains
        | _ => false
      let pool := if eligible.isEmpty then rest.filter (fun c => match c with | .pos _ => true | _ => false) else eligible
      match pool with
      | [] => acc ++ rest
      | c₀ :: _ =>
        let best := pool.foldl (pickBest multi bound) c₀
        let rest' := (rest.eraseIdx (rest.idxOf best))
        let mr := if eligible.isEmpty then moveRel bound best rest' else (best, rest')
        go multi n mr.2 (bindNext bound mr.1) (acc ++ [mr.1]) pv


/-! ## Soar's condition reorderer

Soar 9.6.5 reorders the conditions of every rule before adding it to the Rete
(`reorder_lhs`, production_reorder.cpp): relational tests and disjunctions are taken out of
the conditions, the bare conditions are ordered greedily by an estimated cost, and the tests
are put back on the first condition, in the new order, at which both of their variables are
bound. The instantiations Soar records for chunking carry the tests where the reorderer put
them, so which condition carries a relational test — and so whether chunking keeps it —
follows this order. `soarOrder` reproduces it; the matcher (`joinOrder`) is unchanged. -/

namespace Reorder

def maxCost : Nat := 10000005

def termBound (bound : List String) : Term → Bool
  | .sym _ => true
  | .var v => bound.contains v

/-- Soar's `cost_of_adding_condition` for a condition reduced to its equality tests. A field
with no equality test (`(<s> ^foo)`, `^a > 5`, `^a << x y >>`) has a new dummy variable in
Soar (`simplify_test`, production_reorder.cpp:298-301, 391-408), which is never bound: an
attribute or value without one costs as an unbound variable (×8). -/
def costPos (multi : List (String × Nat)) (bound roots : List String) (p : Pat) : Nat :=
  -- (no condition's variable has an empty name)
  let dummy : Term := .var ""
  match (eqTerm? p.id).getD dummy, (eqTerm? p.attr).getD dummy, (eqTerm? p.val).getD dummy with
  | i, a, v =>
    if roots.isEmpty then
      if !termBound bound i then maxCost else
      let r := if termBound bound a then
          (match a with
           | .sym (.str s) => ((alGet multi s)).getD 1
           | _ => 1)
        else 8
      if termBound bound v then r else r * 8
    else
      let cov (t : Term) : Bool := termBound bound t || (match t with | .var x => roots.contains x | _ => false)
      if !cov i then maxCost else
      let r := if cov a then 1 else 8
      if cov v then r else r * 8

/-- A condition being ordered: a positive pattern (with its index) or a negation with the
variables it needs bound. -/
inductive Item where
  | pos : Nat → Pat → Item
  | neg : List String → Nat → Item

instance : Inhabited Item := ⟨.neg [] 0⟩

def Item.cost (multi : List (String × Nat)) (bound roots : List String) : Item → Nat
  | .pos _ p => costPos multi bound roots p
  | .neg req _ => if req.all bound.contains then 1 else maxCost

def Item.isPos : Item → Bool
  | .pos _ _ => true
  | .neg _ _ => false

def Item.vars : Item → List String
  | .pos _ p => p.eqVars
  | .neg _ _ => []

/-- Soar's `canonical_test` (a constant's symbol number, else 0) and `canonical_cond_greater`. -/
def canon (rank : Sym → Nat) (t : Test) : Nat :=
  match eqTerm? t with
  | some (.sym y) => rank y
  | _ => 0

def greater (rank : Sym → Nat) : Item → Item → Bool
  | .pos _ p₁, .pos _ p₂ =>
    let a₁ := canon rank p₁.attr; let a₂ := canon rank p₂.attr
    a₁ < a₂ || (a₁ == a₂ && canon rank p₁.val < canon rank p₂.val)
  | _, _ => false

/-- One step of `reorder_simplified_conditions`: the index (in `rest`) of the condition chosen. -/
def choose (rank : Sym → Nat) (multi : List (String × Nat)) (bound roots : List String)
    (rest : List Item) : Nat :=
  let costs := rest.enum.map fun (j, c) => (j, c.cost multi bound roots)
  -- the min-cost set, most recently found first (Soar links ties at the head)
  let (minC, set) := costs.foldl (fun (acc : Nat × List Nat) (j, c) =>
    if acc.2.isEmpty || c < acc.1 then (c, [j])
    else if c == acc.1 then (acc.1, j :: acc.2) else acc) (0, [])
  let item (j : Nat) : Item := rest[j]!
  match set with
  | [] => 0
  | [j] => j
  | j₀ :: _ =>
    if minC > 1 then
      let look (j : Nat) : Nat :=
        let b := bound ++ (item j).vars
        (rest.enum.filter (·.1 != j)).foldl (fun m (_, c) => min m (c.cost multi b roots)) (maxCost + 1)
      (set.foldl (fun (acc : Option (Nat × Nat)) j =>
        let c := look j
        match acc with
        | none => some (j, c)
        | some (bj, bc) =>
          if c < bc then some (j, c)
          else if c == bc && (item j).isPos && greater rank (item bj) (item j) then some (j, c)
          else acc) none).map (·.1) |>.getD j₀
    else
      set.foldl (fun bj j =>
        let c := item j; let b := item bj
        if c.isPos && b.isPos && greater rank b c then j
        else if !c.isPos && b.isPos then j
        else bj) j₀

/-- The ordering loop of `reorder_simplified_conditions`, with a bound `fuel` on the number of
conditions still to place (each step places one, so `rest.length` always suffices; `order`). -/
def orderGo (rank : Sym → Nat) (multi : List (String × Nat)) :
    Nat → List String → List String → List Item → List Item → List Item
  | 0, _, _, _, acc => acc
  | _ + 1, _, _, [], acc => acc
  | n + 1, roots, bound, rest, acc =>
    let j := choose rank multi bound roots rest
    let c := rest[j]!
    let bound := bound ++ c.vars.filter (!bound.contains ·)
    let roots := if roots.all bound.contains then [] else roots
    orderGo rank multi n roots bound (rest.eraseIdx j) (acc ++ [c])

/-- Soar's loop that picks the cheapest condition, adds it to the order and binds its variables
(`reorder_simplified_conditions`). Total: `Reorder.order_perm` shows that it places every
condition exactly once. -/
def order (rank : Sym → Nat) (multi : List (String × Nat)) (roots : List String)
    (bound : List String) (rest acc : List Item) : List Item :=
  orderGo rank multi rest.length roots bound rest acc

/-- Where `restore_and_deallocate_saved_tests` puts the saved tests that belong to one field
of a condition, given the variables bound so far. -/
def placeField (bound : List String) (saved : List (Term × STest)) (t : Test) : Test × List (Term × STest) :=
  match eqTerm? t with
  | none => (t, saved)
  | some e =>
    saved.foldl (fun (acc : Test × List (Term × STest)) (sv, st) =>
      let (t, keep) := acc
      let add (x : STest) : Test := if t.contains x then t else t ++ [x]
      match st with
      | .rel r ref =>
        if e == sv && (termBound bound ref || ref == sv) then (add st, keep)
        else if ref == e && (termBound bound sv || ref == sv) then (add (.rel r.inv sv), keep)
        else (t, keep ++ [(sv, st)])
      -- `@` and `!@` against a term are symmetric: placed like a relational test, where
      -- the term is bound
      | .ltiRel b ref =>
        if e == sv && (termBound bound ref || ref == sv) then (add st, keep)
        else if ref == e && (termBound bound sv || ref == sv) then (add (.ltiRel b sv), keep)
        else (t, keep ++ [(sv, st)])
      | st => if e == sv then (add st, keep) else (t, keep ++ [(sv, st)])) (t, [])

/-- One condition of `restore`. -/
def restoreStep (acc : List (Nat × Pat) × List String × List (Term × STest)) (x : Nat × Pat) :
    List (Nat × Pat) × List String × List (Term × STest) :=
  let (out, bound, saved) := acc
  let (i, p) := x
  let (it, saved) := placeField bound saved p.id
  let bound := bound ++ (it.flatMap STest.eqVars)
  let (att, saved) := placeField bound saved p.attr
  let bound := bound ++ (att.flatMap STest.eqVars)
  let (vt, saved) := placeField bound saved p.val
  let bound := bound ++ (vt.flatMap STest.eqVars)
  (out ++ [(i, { p with id := it, attr := att, val := vt })], bound, saved)

/-- Put the saved tests back (`restore_and_deallocate_saved_tests`). -/
def restore (saved : List (Term × STest)) (ps : List (Nat × Pat)) : List (Nat × Pat) :=
  (ps.foldl restoreStep ([], [], saved)).1

end Reorder

namespace Reorder

/-- The tests of one field that `simplify_test` takes out. A field with an equality test keeps
it and its other tests are saved under it (most recently taken first). A field with none
(`^a > 5`, `^a << x y >>`) gets a new variable `dummy` (production_reorder.cpp:298-301,
391-408) as its equality test, under which all its tests are saved; the variable is never
bound elsewhere, and a relational test that refers to a variable not bound yet is put on the
condition that binds it, inverted, against the dummy variable (`restore`; `dropDummies` leaves
the variable out where no test refers to it). -/
def stripTests (saved : List (Term × STest)) (dummy : String) (t : Test) : List (Term × STest) × Test :=
  match eqTerm? t with
  | none =>
    if t.isEmpty then (saved, t)
    else (t.foldl (fun sv st => ((Term.var dummy, st) :: sv)) saved, [.var dummy])
  | some e => t.foldl (fun (a : List (Term × STest) × Test) st => match st with
      | .var _ | .const _ => (a.1, a.2 ++ [st])
      | st => ((e, st) :: a.1, a.2)) (saved, [])

/-- The variables the reorderer made for fields without an equality test start with `·`. -/
def isDummyVar (v : String) : Bool := v.startsWith "·"

/-- One condition of `stripPats`. -/
def stripStep (acc : List (Term × STest) × List (Nat × Pat)) (x : Nat × Pat) :
    List (Term × STest) × List (Nat × Pat) :=
  let (saved, out) := acc
  let (i, p) := x
  let (saved, it) := stripTests saved s!"·{i}i" p.id
  let (saved, att) := stripTests saved s!"·{i}a" p.attr
  let (saved, vt) := stripTests saved s!"·{i}v" p.val
  (saved, out ++ [(i, { p with id := it, attr := att, val := vt })])

/-- `simplify_condition_list`: take the tests other than equality tests out of the fields, most
recently taken first (`saved`), and leave the conditions with their equality tests only. -/
def stripPats (pos : List (Nat × Pat)) : List (Term × STest) × List (Nat × Pat) :=
  pos.foldl stripStep ([], [])

/-- The dummy variables that tests of the patterns refer to. -/
def dummyRefs (p : Pat) : List String :=
  (p.id ++ p.attr ++ p.val).filterMap fun st => match st with
    | .rel _ (.var d) | .ltiRel _ (.var d) => if isDummyVar d then some d else none
    | _ => none

/-- Take the dummy variables out of the fields that no test refers to. -/
def dropDummies (ps : List (Nat × Pat)) : List (Nat × Pat) :=
  let refs := ps.flatMap (fun x => dummyRefs x.2)
  let f (t : Test) : Test := t.filter fun st => match st with
    | .var d => !(isDummyVar d) || refs.contains d
    | _ => true
  ps.map fun (i, p) => (i, { p with id := f p.id, attr := f p.attr, val := f p.val })

/-- One condition of `buildItems`: `acc.2` counts the positive conditions placed. -/
def itemStep (simp : List (Nat × Pat)) (posVars : List String) (acc : List Item × Nat)
    (x : Nat × Cond) : List Item × Nat :=
  match x.2 with
  | .pos _ => match simp[acc.2]? with
    | some (i, p) => (acc.1 ++ [.pos i p], acc.2 + 1)
    | none => acc
  | c => let all := c.pats
    (acc.1 ++ [.neg ((all.flatMap fun q => q.eqVars ++ q.useVars).filter posVars.contains).eraseDups x.1], acc.2)

/-- The conditions to order: the positive ones (from `simp`, in turn) and the negations with
the variables they need bound. -/
def buildItems (simp : List (Nat × Pat)) (posVars : List String) (cs : List Cond) : List Item :=
  (cs.enum.foldl (itemStep simp posVars) ([], 0)).1

end Reorder

open Reorder in
/-- Soar 9.6.5's order of a rule's conditions (`reorder_lhs`): the conditions in the order
Soar's reorderer gives them, the positive ones with their tests where it puts them, each
positive one with its index among the rule's positive conditions. `rank` stands for Soar's
symbol numbering (the canonical order of constants, used to break ties).
`Reorder.soarCondOrder_perm` shows that every positive condition is placed once. -/
def soarCondOrder (rank : Sym → Nat) (multi : List (String × Nat)) (cs : List Cond) : List (Option Nat × Cond) :=
  let pos := (positives cs).enum
  -- take out the tests other than equality tests from fields with an equality test, most
  -- recently taken first
  let (saved, simp) := stripPats pos
  let valVars := simp.filterMap fun (_, p) => match eqTerm? p.val with | some (.var v) => some v | _ => none
  let roots0 := (simp.filterMap fun (_, p) => match eqTerm? p.id with | some (.var v) => some v | _ => none).eraseDups.filter (!valVars.contains ·)
  let roots := if roots0.isEmpty then
      ((simp.find? fun (_, p) => p.goal).bind fun (_, p) => match eqTerm? p.id with | some (.var v) => some v | _ => none).toList
    else roots0
  let posVars := simp.flatMap fun (_, p) => p.eqVars
  let items : List Item := buildItems simp posVars cs
  let ordered := order rank multi roots [] items []
  let restored := dropDummies (restore saved (ordered.filterMap fun it => match it with
    | .pos i p => some (i, p)
    | .neg _ _ => none))
  ordered.filterMap fun it => match it with
    | .pos i _ => (restored.find? (·.1 == i)).map fun (_, p) => (some i, Cond.pos p)
    | .neg _ k => cs[k]?.map (none, ·)

/-- Soar 9.6.5's order of a rule's positive conditions, each with its index among the rule's
positive conditions and its tests where Soar's reorderer puts them. -/
def soarOrder (rank : Sym → Nat) (multi : List (String × Nat)) (cs : List Cond) : List (Nat × Pat) :=
  (soarCondOrder rank multi cs).filterMap fun (i, c) => match i, c with
    | some i, .pos p => some (i, p)
    | _, _ => none

/-- The conditions in Soar's order, for matching. -/
def soarConds (rank : Sym → Nat) (multi : List (String × Nat)) (cs : List Cond) : List Cond :=
  (soarCondOrder rank multi cs).map (·.2)

end Soar
