import Soar.Match
/-!
# Completeness of the matcher, and independence of condition order

`match_sound` (Soar/Match.lean) shows that every instantiation the matcher returns satisfies
the production's conditions. This file proves the converse for conjunctions of positive
patterns: every assignment of variables under which each pattern matches some element of
working memory is found by the matcher (`matchPats_complete`, `matchConds_complete`); and from
the two together, that the order of the patterns does not change which instantiations are found
(`matchPats_perm`).

The matcher binds a variable at its first occurrence and evaluates a relational test against
the bindings made so far, so completeness needs the order of tests to be *safe*: a variable used
by a relational test is bound by an equality test earlier (`PatsSafe`). Soar's reorderer and the
model's join order both produce such orders, and Soar requires that every variable used in a
relational test be bound by some equality test. Long-term-identifier tests read the links given
in the initial bindings, so the theorems assume that the bindings found agree with those links
(`LinksIn`), and that no pattern variable is named like the key of a link (`VarsOk`).

Negated conditions (`-( … )`) are covered by `matchConds_complete_neg`: a negation is
required to have no match under any extension of the final bindings, and its own variables to
be local to it (not bound by the final bindings unless bound before it).

Negated conjunctions with one level of inner negations (`Cond.ncc`) are covered the same way.

Negated conjunctions nested more deeply (`Cond.nccg`) are covered by `tree_complete` and `tree_clear`, under the
conditions `TreeOk`, `TreeLocal` and `TreeSpec` (the variables of an inner negation that no
enclosing node binds are local to it).
-/

namespace Soar

/-! ## Safe orders -/

def Test.binds (t : Test) : List String := t.flatMap STest.eqVars

/-- Every variable a test reads is bound before it, by `bd` or by an earlier test. -/
def Test.Safe : List String → Test → Prop
  | _, [] => True
  | bd, t :: ts => (∀ v ∈ t.useVars, v ∈ bd) ∧ Test.Safe (bd ++ t.eqVars) ts

theorem Pat.eqVars_eq (p : Pat) : p.eqVars = Test.binds p.id ++ Test.binds p.attr ++ Test.binds p.val := by
  simp [Pat.eqVars, Test.binds, List.flatMap_append]

def Pat.Safe (bd : List String) (p : Pat) : Prop :=
  Test.Safe bd p.id ∧ Test.Safe (bd ++ Test.binds p.id) p.attr ∧
    Test.Safe (bd ++ Test.binds p.id ++ Test.binds p.attr) p.val

def PatsSafe : List String → List Pat → Prop
  | _, [] => True
  | bd, p :: ps => Pat.Safe bd p ∧ PatsSafe (bd ++ p.eqVars) ps

/-- The variables `bd` are bound in `b`. -/
def Bound (bd : List String) (b : Binding) : Prop := ∀ v ∈ bd, (b.get v).isSome

/-- The links to long-term identifiers recorded in `β` are those given in `b`: `β` adds at
most the mark `-` (no link). -/
def LinksIn (b β : Binding) : Prop :=
  ∀ (s : Sym) k x, s.ltiKey = some k → β.get k = some x → x ≠ .str "-" → b.get k = some x

/-- No variable of the patterns is named like the key of a link. -/
def VarsOk (ps : List Pat) : Prop := ∀ p ∈ ps, ∀ v ∈ p.eqVars, ∀ s : Sym, s.ltiKey ≠ some v

theorem Bound.mono {bd : List String} {b b' : Binding} (h : Bound bd b) (he : Extends b b') :
    Bound bd b' := by
  intro v hv
  have := h v hv
  cases hg : b.get v with
  | none => rw [hg] at this; cases this
  | some x => rw [he v x hg]; rfl

theorem LinksIn.mono {b b' β : Binding} (h : LinksIn b β) (he : Extends b b') : LinksIn b' β :=
  fun s k x hk hx hn => he k x (h s k x hk hx hn)

theorem ltiNum_agree {b β : Binding} (he : Extends b β) (hl : LinksIn b β) (s : Sym) :
    s.ltiNum b = s.ltiNum β := by
  unfold Sym.ltiNum
  cases hk : s.ltiKey with
  | none => rfl
  | some k =>
    simp only
    cases hb : b.get k with
    | some y => rw [he k y hb]
    | none =>
      cases hβ : β.get k with
      | none => rfl
      | some y =>
        by_cases hy : y = .str "-"
        · subst hy; rfl
        · have := hl s k y hk hβ hy; rw [hb] at this; cases this

theorem markLti_complete {b β : Binding} {s : Sym} (he : Extends b β) (hl : LinksIn b β)
    (hβ : LtiBound β s) : Extends (markLti b s) β := by
  unfold markLti
  cases hk : s.ltiKey with
  | none => exact he
  | some k =>
    simp only
    split
    · rename_i hn
      have hbk : b.get k = none := by simpa using hn
      have hs := hβ k hk
      cases hg : β.get k with
      | none => rw [hg] at hs; cases hs
      | some y =>
        by_cases hy : y = .str "-"
        · subst hy
          refine ⟨fun v x hv => ?_, fun n => ?_⟩
          · by_cases e : v = k
            · subst e; rw [get_cons_self] at hv; cases hv; exact hg
            · rw [get_cons_other _ _ e] at hv; exact he v x hv
          · rw [he.letter n]; exact (letter_cons _ _ _ (reservedKey_ltiKey hk) n).symm
        · have := hl s k y hk hg hy; rw [hbk] at this; cases this
    · exact he

theorem ltiBound_of_markLti {B β : Binding} {s : Sym} (h : Extends (markLti B s) β) :
    LtiBound β s := ltiBound_extends (ltiBound_markLti_self B s) h

/-! ## Completeness, test by test -/

theorem STest.run_complete {B B' b β : Binding} {s : Sym} {t : STest}
    (hB : t.run B s = some B') (hB' : Extends B' β) (he : Extends b β) (hl : LinksIn b β)
    (hu : ∀ v ∈ t.useVars, (b.get v).isSome) :
    ∃ b', t.run b s = some b' ∧ Extends b' β := by
  have eB : Extends B β := Extends.trans (STest.run_extends hB) hB'
  cases t with
  | var v =>
    obtain ⟨hres, hβv⟩ : reservedKey v = false ∧ β.get v = some s := by
      obtain ⟨hr, h1 | ⟨hn, h2⟩⟩ := STest.run_var hB
      · exact ⟨hr, eB v s h1.1⟩
      · exact ⟨hr, hB' v s (by rw [h2]; exact get_cons_self _ _ _)⟩
    cases hg : b.get v with
    | some y =>
      have := he v y hg; rw [hβv] at this; cases this
      exact ⟨b, by simp [STest.run, hres, hg], he⟩
    | none =>
      refine ⟨(v, s) :: b, by simp [STest.run, hres, hg], fun w x hw => ?_, fun n => ?_⟩
      · by_cases e : w = v
        · subst e; rw [get_cons_self] at hw; cases hw; exact hβv
        · rw [get_cons_other _ _ e] at hw; exact he w x hw
      · rw [he.letter n]; exact (letter_cons _ _ _ hres n).symm
  | const c =>
    simp only [STest.run] at hB ⊢
    split at hB
    · exact ⟨b, by simp_all, he⟩
    · cases hB
  | rel r t =>
    simp only [STest.run] at hB ⊢
    split at hB
    · rename_i x hx
      split at hB
      · rename_i hr
        have hv : t.value b = some x := by
          cases t with
          | sym c => exact hx
          | var v =>
            have := hu v (by simp [STest.useVars])
            cases hg : b.get v with
            | none => rw [hg] at this; cases this
            | some y =>
              have h1 := he v y hg
              have h2 := eB v x hx
              rw [h1] at h2; cases h2
              exact hg
        have hbl : b.letter = B.letter := funext fun n => (he.letter n).symm.trans (eB.letter n)
        rw [hv]; exact ⟨b, by simp [hr, hbl], he⟩
      · cases hB
    · cases hB
  | disj cs =>
    simp only [STest.run] at hB ⊢
    split at hB
    · exact ⟨b, by simp_all, he⟩
    · cases hB
  | lti pos =>
    simp only [STest.run] at hB ⊢
    split at hB
    · rename_i hc; cases hB
      have hsb := ltiBound_of_markLti hB'
      have e1 : s.ltiNum β = s.ltiNum B := by
        rw [ltiNum_extends (ltiBound_markLti_self B s) hB', ltiNum_markLti]
      rw [ltiNum_agree he hl, e1]; simp only [hc, ↓reduceIte]
      exact ⟨_, rfl, markLti_complete he hl hsb⟩
    · cases hB
  | ltiRel pos t =>
    cases t with
    | var v =>
      simp only [STest.run] at hB ⊢
      split at hB
      · rename_i x hx
        split at hB
        · rename_i hc; cases hB
          have hu' := hu v (by simp [STest.useVars])
          cases hg : b.get v with
          | none => rw [hg] at hu'; cases hu'
          | some y =>
            have h1 := he v y hg
            have h2 := eB v x hx
            have hxy : y = x := Option.some.inj (h1.symm.trans h2)
            subst hxy
            simp only
            have hbs : LtiBound (markLti (markLti B s) y) s :=
              ltiBound_markLti _ _ _ (ltiBound_markLti_self _ _)
            have hbx : LtiBound (markLti (markLti B s) y) y := ltiBound_markLti_self _ _
            have es : s.ltiNum β = s.ltiNum B := by
              rw [ltiNum_extends hbs hB', ltiNum_markLti, ltiNum_markLti]
            have ex : y.ltiNum β = y.ltiNum B := by
              rw [ltiNum_extends hbx hB', ltiNum_markLti, ltiNum_markLti]
            rw [ltiNum_agree he hl, ltiNum_agree he hl y, es, ex]; simp only [hc, ↓reduceIte]
            have m1 := markLti_complete he hl (ltiBound_extends hbs hB')
            exact ⟨_, rfl, markLti_complete m1 (hl.mono (markLti_extends b s)) (ltiBound_extends hbx hB')⟩
        · cases hB
      · cases hB
    | sym c =>
      simp only [STest.run] at hB ⊢
      split at hB
      · rename_i hc; cases hB
        have es : s.ltiNum β = s.ltiNum B := by
          rw [ltiNum_extends (ltiBound_markLti_self B s) hB', ltiNum_markLti]
        rw [ltiNum_agree he hl, es]; simp only [hc, ↓reduceIte]
        exact ⟨_, rfl, markLti_complete he hl (ltiBound_of_markLti hB')⟩
      · cases hB

theorem STest.run_binds {b b' : Binding} {s : Sym} {t : STest} (h : t.run b s = some b') :
    ∀ v ∈ t.eqVars, (b'.get v).isSome := by
  cases t with
  | var v =>
    intro w hw
    simp only [STest.eqVars, List.mem_singleton] at hw; subst hw
    obtain ⟨_, h1 | ⟨_, h2⟩⟩ := STest.run_var h
    · rw [h1.2, h1.1]; rfl
    · rw [h2, get_cons_self]; rfl
  | _ => intro v hv; simp [STest.eqVars] at hv

theorem runTest_complete {B B' b β : Binding} {s : Sym} {ts : Test} {bd : List String}
    (hB : runTest B s ts = some B') (hB' : Extends B' β) (he : Extends b β) (hl : LinksIn b β)
    (hs : Test.Safe bd ts) (hbd : Bound bd b) :
    ∃ b', runTest b s ts = some b' ∧ Extends b' β ∧ Bound (bd ++ Test.binds ts) b' := by
  induction ts generalizing B b bd with
  | nil => cases hB; exact ⟨b, rfl, he, by simpa [Test.binds] using hbd⟩
  | cons t ts ih =>
    simp only [runTest] at hB
    split at hB
    · rename_i B₁ h₁
      have e₁ : Extends B₁ β := Extends.trans (runTest_extends hB) hB'
      obtain ⟨hu, hs'⟩ := hs
      obtain ⟨b₁, hb₁, eb₁⟩ := STest.run_complete h₁ e₁ he hl (fun v hv => hbd v (hu v hv))
      have hbd₁ : Bound (bd ++ t.eqVars) b₁ := by
        intro v hv
        rcases List.mem_append.mp hv with hv | hv
        · exact Bound.mono hbd (STest.run_extends hb₁) v hv
        · exact STest.run_binds hb₁ v hv
      obtain ⟨b', hb', eb', hbd'⟩ :=
        ih hB eb₁ (hl.mono (STest.run_extends hb₁)) hs' hbd₁
      refine ⟨b', ?_, eb', ?_⟩
      · simp only [runTest, hb₁]; exact hb'
      · simpa [Test.binds, List.flatMap_cons, List.append_assoc] using hbd'
    · cases hB

theorem Pat.run_complete {B B' b β : Binding} {p : Pat} {w : WME} {bd : List String}
    (hB : p.run B w = some B') (hB' : Extends B' β) (he : Extends b β) (hl : LinksIn b β)
    (hs : Pat.Safe bd p) (hbd : Bound bd b) :
    ∃ b', p.run b w = some b' ∧ Extends b' β ∧ Bound (bd ++ p.eqVars) b' := by
  unfold Pat.run at hB ⊢
  split at hB
  · rename_i hacc
    simp only [hacc, ↓reduceIte]
    split at hB
    · cases hB
    · rename_i B₁ h₁
      split at hB
      · cases hB
      · rename_i B₂ h₂
        have e₂ : Extends B₂ β := Extends.trans (runTest_extends hB) hB'
        have e₁ : Extends B₁ β := Extends.trans (runTest_extends h₂) e₂
        obtain ⟨s₁, s₂, s₃⟩ := hs
        obtain ⟨b₁, hb₁, eb₁, hbd₁⟩ := runTest_complete h₁ e₁ he hl s₁ hbd
        have hl₁ := hl.mono (runTest_extends hb₁)
        obtain ⟨b₂, hb₂, eb₂, hbd₂⟩ := runTest_complete h₂ e₂ eb₁ hl₁ s₂ hbd₁
        have hl₂ := hl₁.mono (runTest_extends hb₂)
        obtain ⟨b₃, hb₃, eb₃, hbd₃⟩ := runTest_complete hB hB' eb₂ hl₂ s₃ hbd₂
        refine ⟨b₃, ?_, eb₃, ?_⟩
        · rw [hb₁]; simp only; rw [hb₂]; exact hb₃
        · simpa [Pat.eqVars, Test.binds, List.append_assoc] using hbd₃
  · cases hB

/-! ## Completeness of conjunctions -/

/-- **Completeness of matching (positive patterns).** If, under bindings `β` that extend `b`,
every pattern matches some element of working memory, and the patterns are in a safe order,
then the matcher, started from `b`, returns bindings that `β` extends. -/
theorem matchPats_complete {wm : List WME} {ps : List Pat} {b β : Binding} {bd : List String}
    (hm : ∀ p ∈ ps, ∃ w ∈ wm, p.run β w = some β) (he : Extends b β) (hl : LinksIn b β)
    (hs : PatsSafe bd ps) (hbd : Bound bd b) :
    ∃ b' ∈ matchPats wm ps b, Extends b' β := by
  induction ps generalizing b bd with
  | nil => exact ⟨b, by simp [matchPats], he⟩
  | cons p ps ih =>
    obtain ⟨w, hw, hr⟩ := hm p (by simp)
    obtain ⟨hsp, hss⟩ := hs
    obtain ⟨b₁, hb₁, eb₁, hbd₁⟩ := Pat.run_complete hr (Extends.refl β) he hl hsp hbd
    obtain ⟨b', hb', eb'⟩ := ih (fun q hq => hm q (by simp [hq])) eb₁
      (hl.mono (Pat.run_extends hb₁)) hss hbd₁
    refine ⟨b', ?_, eb'⟩
    simp only [matchPats, List.mem_flatMap]
    exact ⟨w, hw, by rw [hb₁]; exact hb'⟩

/-- Completeness for a production's positive conditions, with the elements they match: for
any elements `ws` that the patterns match under `β`, the matcher returns an instantiation with
exactly those elements, whose bindings `β` extends. -/
theorem matchConds_complete {wm : List WME} {ps : List Pat} {ws : List WME} {b β : Binding}
    {bd : List String} (hlen : ws.length = ps.length)
    (hm : ∀ i (h₁ : i < ps.length) (h₂ : i < ws.length), ws[i] ∈ wm ∧ ps[i].run β ws[i] = some β)
    (he : Extends b β) (hl : LinksIn b β) (hs : PatsSafe bd ps) (hbd : Bound bd b) :
    ∃ r ∈ matchConds wm (ps.map Cond.pos) b, r.2 = ws ∧ Extends r.1 β := by
  induction ps generalizing ws b bd with
  | nil =>
    cases ws with
    | nil => exact ⟨(b, []), by simp [matchConds], rfl, he⟩
    | cons _ _ => simp at hlen
  | cons p ps ih =>
    cases ws with
    | nil => simp at hlen
    | cons w ws =>
      obtain ⟨hw, hr⟩ := hm 0 (by simp) (by simp)
      simp only [List.getElem_cons_zero] at hw hr
      obtain ⟨hsp, hss⟩ := hs
      obtain ⟨b₁, hb₁, eb₁, hbd₁⟩ := Pat.run_complete hr (Extends.refl β) he hl hsp hbd
      obtain ⟨r, hr', hr2, er⟩ := ih (ws := ws) (by simpa using hlen)
        (fun i h₁ h₂ => by
          have := hm (i + 1) (Nat.succ_lt_succ h₁) (Nat.succ_lt_succ h₂)
          simpa only [List.getElem_cons_succ] using this)
        eb₁ (hl.mono (Pat.run_extends hb₁)) hss hbd₁
      refine ⟨(r.1, w :: r.2), ?_, by simp [hr2], er⟩
      simp only [List.map_cons, matchConds, List.mem_flatMap]
      exact ⟨w, hw, by rw [hb₁]; simp only [List.mem_map]; exact ⟨r, hr', rfl⟩⟩

/-! ## Soundness of conjunctions, and order -/

theorem matchPats_sound {wm : List WME} {ps : List Pat} {b b' : Binding}
    (h : b' ∈ matchPats wm ps b) :
    Extends b b' ∧ ∀ p ∈ ps, ∃ w ∈ wm, p.run b' w = some b' := by
  induction ps generalizing b with
  | nil => simp [matchPats] at h; subst h; exact ⟨Extends.refl _, by simp⟩
  | cons p ps ih =>
    simp only [matchPats, List.mem_flatMap] at h
    obtain ⟨w, hw, hb⟩ := h
    split at hb
    · rename_i b₁ h₁
      obtain ⟨e, hall⟩ := ih hb
      refine ⟨Extends.trans (Pat.run_extends h₁) e, fun q hq => ?_⟩
      rcases List.mem_cons.mp hq with rfl | hq
      · exact ⟨w, hw, Pat.run_stable h₁ e⟩
      · exact hall q hq
    · cases hb

theorem STest.run_links {b b' : Binding} {s : Sym} {t : STest} (h : t.run b s = some b')
    (hv : ∀ v ∈ t.eqVars, ∀ s' : Sym, s'.ltiKey ≠ some v) : LinksIn b b' := by
  have markOk : ∀ (c : Binding) (x : Sym), LinksIn c (markLti c x) := by
    intro c x s' k y hk hy hn
    unfold markLti at hy
    split at hy
    · split at hy
      · rename_i kx _ _
        by_cases e : k = kx
        · subst e; rw [get_cons_self] at hy; cases hy; exact absurd rfl hn
        · rwa [get_cons_other _ _ e] at hy
      · exact hy
    · exact hy
  cases t with
  | var v =>
    obtain ⟨_, h1 | ⟨_, h2⟩⟩ := STest.run_var h
    · rw [h1.2]; exact fun _ _ _ _ hx _ => hx
    · rw [h2]
      intro s' k x hk hx _
      by_cases e : k = v
      · subst e; exact absurd hk (hv k (by simp [STest.eqVars]) s')
      · rwa [get_cons_other _ _ e] at hx
  | const c => simp only [STest.run] at h; split at h <;> cases h; exact fun _ _ _ _ hx _ => hx
  | rel r t =>
    simp only [STest.run] at h
    split at h
    · split at h <;> cases h; exact fun _ _ _ _ hx _ => hx
    · cases h
  | disj cs => simp only [STest.run] at h; split at h <;> cases h; exact fun _ _ _ _ hx _ => hx
  | lti pos => simp only [STest.run] at h; split at h <;> cases h; exact markOk _ _
  | ltiRel pos t =>
    simp only [STest.run] at h
    split at h
    · split at h
      · split at h <;> cases h
        intro s' k y hk hy hn
        exact markOk _ _ s' k y hk (markOk _ _ s' k y hk hy hn) hn
      · cases h
    · split at h <;> cases h; exact markOk _ _

theorem LinksIn.trans {a b c : Binding} (h₁ : LinksIn a b) (h₂ : LinksIn b c) : LinksIn a c :=
  fun s k x hk hx hn => h₁ s k x hk (h₂ s k x hk hx hn) hn

theorem LinksIn.refl (b : Binding) : LinksIn b b := fun _ _ _ _ hx _ => hx

theorem runTest_links {b b' : Binding} {s : Sym} {ts : Test} (h : runTest b s ts = some b')
    (hv : ∀ v ∈ Test.binds ts, ∀ s' : Sym, s'.ltiKey ≠ some v) : LinksIn b b' := by
  induction ts generalizing b with
  | nil => cases h; exact LinksIn.refl _
  | cons t ts ih =>
    simp only [runTest] at h
    split at h
    · rename_i b₁ h₁
      exact LinksIn.trans
        (STest.run_links h₁ (fun v hm => hv v (by simp [Test.binds, List.flatMap_cons]; exact Or.inl hm)))
        (ih h (fun v hm => hv v (by simp [Test.binds, List.flatMap_cons] at hm ⊢; exact Or.inr hm)))
    · cases h

theorem Pat.run_links {b b' : Binding} {p : Pat} {w : WME} (h : p.run b w = some b')
    (hv : ∀ v ∈ p.eqVars, ∀ s' : Sym, s'.ltiKey ≠ some v) : LinksIn b b' := by
  unfold Pat.run at h
  split at h
  · split at h
    · cases h
    · rename_i b₁ h₁
      split at h
      · cases h
      · rename_i b₂ h₂
        exact LinksIn.trans (runTest_links h₁ (fun v hm => hv v (by rw [Pat.eqVars_eq]; simp [hm])))
          (LinksIn.trans (runTest_links h₂ (fun v hm => hv v (by rw [Pat.eqVars_eq]; simp [hm])))
            (runTest_links h (fun v hm => hv v (by rw [Pat.eqVars_eq]; simp [hm]))))
  · cases h

theorem matchPats_links {wm : List WME} {ps : List Pat} {b b' : Binding}
    (h : b' ∈ matchPats wm ps b) (hv : VarsOk ps) : LinksIn b b' := by
  induction ps generalizing b with
  | nil => simp [matchPats] at h; subst h; exact LinksIn.refl _
  | cons p ps ih =>
    simp only [matchPats, List.mem_flatMap] at h
    obtain ⟨w, _, hb⟩ := h
    split at hb
    · rename_i b₁ h₁
      exact LinksIn.trans (Pat.run_links h₁ (hv p (by simp)))
        (ih hb (fun q hq => hv q (by simp [hq])))
    · cases hb

/-- **The order of patterns does not change the matches.** For a reordering `ps'` of the
patterns `ps` (any permutation) in a safe order, every bindings the matcher finds for `ps` are
found, up to variables `ps'` does not bind, for `ps'`: the result for `ps'` is extended by the
result for `ps`. Applied in both directions, the two orders give the same matches. -/
theorem matchPats_perm {wm : List WME} {ps ps' : List Pat} {b b' : Binding} {bd : List String}
    (hp : ps.Perm ps') (h : b' ∈ matchPats wm ps b) (hv : VarsOk ps)
    (hs : PatsSafe bd ps') (hbd : Bound bd b) :
    ∃ b'' ∈ matchPats wm ps' b, Extends b'' b' := by
  obtain ⟨e, hall⟩ := matchPats_sound h
  exact matchPats_complete (fun p hm => hall p (hp.mem_iff.mpr hm)) e (matchPats_links h hv) hs hbd

/-! ## Negated conditions

The matcher evaluates a negation from the bindings made so far. To relate that to the final
bindings, the bindings a match adds are characterized: they are put in front of the old ones,
and are either variables of the patterns or marks of no link (`FrontExt`). -/

/-- `b'` is `b` with entries added in front, each for a key `b` does not bind: a variable of
`vs`, or the key of a link marked `-` (no link). -/
def FrontExt (b b' : Binding) (vs : List String) : Prop :=
  ∃ n : Binding, b' = n ++ b ∧ ∀ e ∈ n, b.get e.1 = none ∧ reservedKey e.1 = false ∧
    (e.1 ∈ vs ∨ ((∃ s : Sym, s.ltiKey = some e.1) ∧ e.2 = .str "-"))

theorem get_append (n b : Binding) (v : String) :
    (n ++ b).get v = match n.get v with | some x => some x | none => b.get v := by
  unfold Binding.get
  rw [List.find?_append]
  cases n.find? (fun p => p.1 == v) <;> simp

theorem get_none_of_extends {b b' : Binding} {k : String} (he : Extends b b') (h : b'.get k = none) :
    b.get k = none := by
  cases hg : b.get k with
  | none => rfl
  | some x => rw [he k x hg] at h; cases h

theorem letter_append (n b : Binding) (hn : ∀ e ∈ n, reservedKey e.1 = false) (k : Nat) :
    (n ++ b).letter k = b.letter k := by
  induction n with
  | nil => rfl
  | cons e n ih =>
    have : (e :: n) ++ b = (e.1, e.2) :: (n ++ b) := rfl
    rw [this, letter_cons _ _ _ (hn e (by simp)) k]
    exact ih (fun e' he' => hn e' (List.mem_cons_of_mem _ he'))

theorem FrontExt.extends {b b' : Binding} {vs : List String} (h : FrontExt b b' vs) : Extends b b' := by
  obtain ⟨n, rfl, hn⟩ := h
  refine ⟨fun v x hv => ?_, fun k => letter_append n b (fun e he => (hn e he).2.1) k⟩
  rw [get_append]
  cases hg : n.get v with
  | none => exact hv
  | some y =>
    exfalso
    unfold Binding.get at hg
    cases hf : n.find? (fun p => p.1 == v) with
    | none => rw [hf] at hg; cases hg
    | some e =>
      have hm := List.mem_of_find?_eq_some hf
      have hk : e.1 = v := by simpa using List.find?_some hf
      have := (hn e hm).1; rw [hk, hv] at this; cases this

theorem FrontExt.refl (b : Binding) (vs : List String) : FrontExt b b vs := ⟨[], by simp, by simp⟩

theorem FrontExt.mono_vs {b b' : Binding} {vs vs' : List String} (h : FrontExt b b' vs)
    (hs : ∀ v ∈ vs, v ∈ vs') : FrontExt b b' vs' := by
  obtain ⟨n, rfl, hn⟩ := h
  exact ⟨n, rfl, fun e he => ⟨(hn e he).1, (hn e he).2.1, (hn e he).2.2.imp (hs _) id⟩⟩

theorem FrontExt.trans {b₁ b₂ b₃ : Binding} {vs vs' : List String} (h₁ : FrontExt b₁ b₂ vs)
    (h₂ : FrontExt b₂ b₃ vs') : FrontExt b₁ b₃ (vs ++ vs') := by
  have e₁ := h₁.extends
  obtain ⟨n₁, rfl, hn₁⟩ := h₁
  obtain ⟨n₂, rfl, hn₂⟩ := h₂
  refine ⟨n₂ ++ n₁, by simp, fun e he => ?_⟩
  rcases List.mem_append.mp he with he | he
  · obtain ⟨hg, hres, hk⟩ := hn₂ e he
    exact ⟨get_none_of_extends e₁ hg, hres, hk.imp (fun h => List.mem_append_right _ h) id⟩
  · obtain ⟨hg, hres, hk⟩ := hn₁ e he
    exact ⟨hg, hres, hk.imp (fun h => List.mem_append_left _ h) id⟩

theorem markLti_front (b : Binding) (x : Sym) (vs : List String) : FrontExt b (markLti b x) vs := by
  unfold markLti
  split
  · rename_i k hk
    split
    · rename_i hn
      exact ⟨[(k, .str "-")], rfl, fun e he => by
        simp only [List.mem_singleton] at he; subst he
        exact ⟨by simpa using hn, reservedKey_ltiKey hk, Or.inr ⟨⟨x, hk⟩, rfl⟩⟩⟩
    · exact FrontExt.refl _ _
  · exact FrontExt.refl _ _

theorem STest.run_front {b b' : Binding} {s : Sym} {t : STest} (h : t.run b s = some b') :
    FrontExt b b' t.eqVars := by
  cases t with
  | var v =>
    obtain ⟨hr, h1 | ⟨hn, h2⟩⟩ := STest.run_var h
    · rw [h1.2]; exact FrontExt.refl _ _
    · rw [h2]
      exact ⟨[(v, s)], rfl, fun e he => by
        simp only [List.mem_singleton] at he; subst he
        exact ⟨hn, hr, Or.inl (by simp [STest.eqVars])⟩⟩
  | const c => simp only [STest.run] at h; split at h <;> cases h; exact FrontExt.refl _ _
  | rel r t =>
    simp only [STest.run] at h
    split at h
    · split at h <;> cases h; exact FrontExt.refl _ _
    · cases h
  | disj cs => simp only [STest.run] at h; split at h <;> cases h; exact FrontExt.refl _ _
  | lti pos => simp only [STest.run] at h; split at h <;> cases h; exact markLti_front _ _ _
  | ltiRel pos t =>
    simp only [STest.run] at h
    split at h
    · split at h
      · split at h <;> cases h
        exact FrontExt.mono_vs ((markLti_front b s []).trans (markLti_front (markLti b s) _ [])) (by simp)
      · cases h
    · split at h <;> cases h; exact markLti_front _ _ _

theorem runTest_front {b b' : Binding} {s : Sym} {ts : Test} (h : runTest b s ts = some b') :
    FrontExt b b' (Test.binds ts) := by
  induction ts generalizing b with
  | nil => cases h; exact FrontExt.refl _ _
  | cons t ts ih =>
    simp only [runTest] at h
    split at h
    · rename_i b₁ h₁
      simpa [Test.binds, List.flatMap_cons] using (STest.run_front h₁).trans (ih h)
    · cases h

theorem Pat.run_front {b b' : Binding} {p : Pat} {w : WME} (h : p.run b w = some b') :
    FrontExt b b' p.eqVars := by
  unfold Pat.run at h
  split at h
  · split at h
    · cases h
    · rename_i b₁ h₁
      split at h
      · cases h
      · rename_i b₂ h₂
        simpa [Pat.eqVars, Test.binds, List.append_assoc] using
          ((runTest_front h₁).trans (runTest_front h₂)).trans (runTest_front h)
  · cases h

theorem matchPats_front {wm : List WME} {ps : List Pat} {b b' : Binding}
    (h : b' ∈ matchPats wm ps b) : FrontExt b b' (ps.flatMap Pat.eqVars) := by
  induction ps generalizing b with
  | nil => simp [matchPats] at h; subst h; exact FrontExt.refl _ _
  | cons p ps ih =>
    simp only [matchPats, List.mem_flatMap] at h
    obtain ⟨w, _, hb⟩ := h
    split at hb
    · rename_i b₁ h₁
      simpa [List.flatMap_cons] using (Pat.run_front h₁).trans (ih hb)
    · cases hb

/-- A match of a negation's patterns from the bindings so far lifts to an extension of the final
bindings `β`, when the negation's variables are not bound by `β` unless bound already: the
bindings it adds go in front of `β`. With no pattern variable named like a link's key, the lift
records no link the match did not have. -/
theorem matchPats_lift {wm : List WME} {ps : List Pat} {b b'' β : Binding}
    (hin : b'' ∈ matchPats wm ps b) (he : Extends b β) (hl : LinksIn b β)
    (hloc : ∀ v ∈ ps.flatMap Pat.eqVars, b.get v = none → β.get v = none) :
    ∃ γ, Extends β γ ∧ Extends b'' γ ∧ (VarsOk ps → LinksIn b'' γ) ∧
      (∀ v, v ∉ ps.flatMap Pat.eqVars → (∀ s : Sym, s.ltiKey ≠ some v) → γ.get v = β.get v) := by
  obtain ⟨n, hn, hent⟩ := matchPats_front hin
  have hres : ∀ e ∈ n, reservedKey e.1 = false := fun e hm => (hent e hm).2.1
  have eγ : Extends b'' (n ++ β) := by
    refine ⟨fun v x hv => ?_, fun k => ?_⟩
    · rw [hn, get_append] at hv
      rw [get_append]
      cases hg : n.get v with
      | some y => rw [hg] at hv; exact hv
      | none => rw [hg] at hv; exact he v x hv
    · rw [hn, letter_append n b hres, letter_append n β hres, he.letter k]
  -- an entry of `n` for key `v`
  have entry : ∀ v y, n.get v = some y → b.get v = none ∧
      (v ∈ ps.flatMap Pat.eqVars ∨ ((∃ s : Sym, s.ltiKey = some v) ∧ y = .str "-")) := by
    intro v y hg
    unfold Binding.get at hg
    cases hf : n.find? (fun p => p.1 == v) with
    | none => rw [hf] at hg; cases hg
    | some e =>
      rw [hf] at hg; simp only [Option.map_some] at hg; cases hg
      have hmem := List.mem_of_find?_eq_some hf
      have hk : e.1 = v := by simpa using List.find?_some hf
      obtain ⟨hbn, hres, hor⟩ := hent e hmem
      rw [hk] at hbn hor
      exact ⟨hbn, hor⟩
  have eβ : Extends β (n ++ β) := by
    refine ⟨fun v x hv => ?_, fun k => letter_append n β hres k⟩
    rw [get_append]
    cases hg : n.get v with
    | none => exact hv
    | some y =>
      obtain ⟨hbn, hor⟩ := entry v y hg
      rcases hor with hv' | ⟨⟨s, hs⟩, hd⟩
      · rw [hloc v hv' hbn] at hv; cases hv
      · by_cases hx : x = .str "-"
        · rw [hx, ← hd]
        · have := hl s v x hs hv hx; rw [hbn] at this; cases this
  have hfr : ∀ v, v ∉ ps.flatMap Pat.eqVars → (∀ s : Sym, s.ltiKey ≠ some v) →
      (n ++ β).get v = β.get v := by
    intro v hvn hnk
    rw [get_append]
    cases hg : n.get v with
    | none => rfl
    | some y =>
      obtain ⟨_, hor⟩ := entry v y hg
      rcases hor with hv' | ⟨⟨s, hs⟩, _⟩
      · exact absurd hv' hvn
      · exact absurd hs (hnk s)
  refine ⟨n ++ β, eβ, eγ, fun hv => ?_, hfr⟩
  intro s k x hk hx hn'
  rw [get_append] at hx
  cases hg : n.get k with
  | some y =>
    rw [hg] at hx; cases hx
    obtain ⟨_, hor⟩ := entry k x hg
    rcases hor with hv' | ⟨_, hd⟩
    · obtain ⟨p, hp, hpv⟩ := List.mem_flatMap.mp hv'
      exact absurd hk (hv p hp k hpv s)
    · exact absurd hd hn'
  | none =>
    rw [hg] at hx
    rw [hn, get_append, hg]
    exact hl s k x hk hx hn'

/-- A negation that no extension of the final bindings matches, and whose variables are not
bound by the final bindings unless bound already, finds no match from the bindings so far. -/
theorem matchPats_neg_empty {wm : List WME} {ps : List Pat} {b β : Binding}
    (hneg : ¬∃ γ, Extends β γ ∧ ∀ p ∈ ps, ∃ w ∈ wm, p.run γ w = some γ)
    (he : Extends b β) (hl : LinksIn b β)
    (hloc : ∀ v ∈ ps.flatMap Pat.eqVars, b.get v = none → β.get v = none) :
    matchPats wm ps b = [] := by
  cases hm : matchPats wm ps b with
  | nil => rfl
  | cons b'' _ =>
    exfalso
    have hin : b'' ∈ matchPats wm ps b := by rw [hm]; simp
    obtain ⟨_, hall⟩ := matchPats_sound hin
    obtain ⟨γ, eβ, eγ, _, _⟩ := matchPats_lift hin he hl hloc
    exact hneg ⟨γ, eβ, fun p hp => by
      obtain ⟨w, hw, hr⟩ := hall p hp
      exact ⟨w, hw, Pat.run_stable hr eγ⟩⟩

theorem runTest_bound {b b' : Binding} {s : Sym} {ts : Test} {bd : List String}
    (h : runTest b s ts = some b') (hb : Bound bd b) : Bound (bd ++ Test.binds ts) b' := by
  induction ts generalizing b bd with
  | nil => cases h; simpa [Test.binds] using hb
  | cons t ts ih =>
    simp only [runTest] at h
    split at h
    · rename_i b₁ h₁
      have hb₁ : Bound (bd ++ t.eqVars) b₁ := by
        intro v hv
        rcases List.mem_append.mp hv with hv | hv
        · exact Bound.mono hb (STest.run_extends h₁) v hv
        · exact STest.run_binds h₁ v hv
      simpa [Test.binds, List.flatMap_cons, List.append_assoc] using ih h hb₁
    · cases h

theorem Pat.run_bound {b b' : Binding} {p : Pat} {w : WME} {bd : List String}
    (h : p.run b w = some b') (hb : Bound bd b) : Bound (bd ++ p.eqVars) b' := by
  unfold Pat.run at h
  split at h
  · split at h
    · cases h
    · rename_i b₁ h₁
      split at h
      · cases h
      · rename_i b₂ h₂
        simpa [Pat.eqVars, Test.binds, List.append_assoc] using
          runTest_bound h (runTest_bound h₂ (runTest_bound h₁ hb))
  · cases h

theorem matchPats_bound {wm : List WME} {ps : List Pat} {b b' : Binding} {bd : List String}
    (h : b' ∈ matchPats wm ps b) (hb : Bound bd b) : Bound (bd ++ ps.flatMap Pat.eqVars) b' := by
  induction ps generalizing b bd with
  | nil => simp [matchPats] at h; subst h; simpa using hb
  | cons p ps ih =>
    simp only [matchPats, List.mem_flatMap] at h
    obtain ⟨w, _, hb'⟩ := h
    split at hb'
    · rename_i b₁ h₁
      simpa [List.flatMap_cons, List.append_assoc] using ih hb' (Pat.run_bound h₁ hb)
    · cases hb'

/-- A negated conjunction `-{ P … -(N) … }` that no extension of the final bindings satisfies
(its patterns matched, and none of its inner negations matched by an extension that respects
the links), with its own variables local to it, inner negations in a safe order and no pattern
variable named like a link's key, does not block the match from the bindings so far. -/
theorem ncc_clear {wm : List WME} {ps : List Pat} {ns : List (List Pat)} {b β : Binding}
    {bd : List String}
    (hneg : ¬∃ γ, Extends β γ ∧ (∀ p ∈ ps, ∃ w ∈ wm, p.run γ w = some γ) ∧
      ∀ n ∈ ns, ¬∃ γ', Extends γ γ' ∧ LinksIn γ γ' ∧ ∀ q ∈ n, ∃ w ∈ wm, q.run γ' w = some γ')
    (he : Extends b β) (hl : LinksIn b β)
    (hloc : ∀ v ∈ ps.flatMap Pat.eqVars, b.get v = none → β.get v = none)
    (hv : VarsOk ps) (hsafe : ∀ n ∈ ns, PatsSafe (bd ++ ps.flatMap Pat.eqVars) n)
    (hbd : Bound bd b) :
    (matchPats wm ps b).any (fun b' => ns.all fun n => (matchPats wm n b').isEmpty) = false := by
  apply Bool.eq_false_iff.mpr
  intro hany
  obtain ⟨b'', hin, hall⟩ := List.any_eq_true.mp hany
  obtain ⟨_, hmatch⟩ := matchPats_sound hin
  obtain ⟨γ, eβ, eγ, hlγ, _⟩ := matchPats_lift hin he hl hloc
  apply hneg
  refine ⟨γ, eβ, fun p hp => ?_, fun n hn => ?_⟩
  · obtain ⟨w, hw, hr⟩ := hmatch p hp
    exact ⟨w, hw, Pat.run_stable hr eγ⟩
  · rintro ⟨γ', e', hl', hm'⟩
    have hempty := List.all_eq_true.mp hall n hn
    obtain ⟨b3, hb3, _⟩ := matchPats_complete hm' (Extends.trans eγ e')
      ((hlγ hv).trans hl') (hsafe n hn) (matchPats_bound hin hbd)
    simp only [List.isEmpty_iff] at hempty
    rw [hempty] at hb3; cases hb3

/-! ## Deeper negated conjunctions (`Cond.nccg`)

A negated conjunction is a tree: its patterns and its inner negated conjunctions. It holds from
bindings `γ` when some extension of `γ` matches its patterns and none of its inner negated
conjunctions holds from that extension, where the variables of an inner node that no enclosing
node binds (and that `bd` does not already bind) are local: unbound in the extension. Two
theorems relate this to the matcher's `NegTree.holds`, by mutual recursion on the tree:
`tree_complete` (the specification holds, so the matcher finds it) and `tree_clear` (it does not
hold, so the matcher finds no match). -/

def NegTree.ps : NegTree → List Pat
  | .node ps _ => ps

mutual
/-- The variables of the nodes below `t` that neither `bd` nor the nodes above bind are unbound
in `γ`. -/
def TreeLocal (bd : List String) : NegTree → Binding → Prop
  | .node ps ns, γ => KidsLocal (bd ++ ps.flatMap Pat.eqVars) ns γ
def KidsLocal (bd : List String) : List NegTree → Binding → Prop
  | [], _ => True
  | k :: ns, γ => (∀ v ∈ k.ps.flatMap Pat.eqVars, v ∉ bd → γ.get v = none) ∧
      TreeLocal bd k γ ∧ KidsLocal bd ns γ
end

mutual
/-- The specification: the negated conjunction `t` holds from `γ`, with `bd` the variables
bound by the enclosing context. -/
def TreeSpec (wm : List WME) (bd : List String) : NegTree → Binding → Prop
  | .node ps ns, γ => ∃ γ', Extends γ γ' ∧ LinksIn γ γ' ∧ (∀ p ∈ ps, ∃ w ∈ wm, p.run γ' w = some γ') ∧
      KidsLocal (bd ++ ps.flatMap Pat.eqVars) ns γ' ∧ KidsClear wm (bd ++ ps.flatMap Pat.eqVars) ns γ'
/-- No tree of the list holds from `γ`. -/
def KidsClear (wm : List WME) (bd : List String) : List NegTree → Binding → Prop
  | [], _ => True
  | n :: ns, γ => ¬ TreeSpec wm bd n γ ∧ KidsClear wm bd ns γ
end

mutual
/-- The conditions on a negated conjunction: no pattern variable is named like a link's key, and
the inner nodes' patterns are in a safe order given the variables bound before them. -/
def TreeOk (bd : List String) : NegTree → Prop
  | .node ps ns => VarsOk ps ∧ KidsOk (bd ++ ps.flatMap Pat.eqVars) ns
def KidsOk (bd : List String) : List NegTree → Prop
  | [] => True
  | n :: ns => PatsSafe bd n.ps ∧ TreeOk bd n ∧ KidsOk bd ns
end

theorem treeOk_vars {bd : List String} : ∀ (t : NegTree), TreeOk bd t → VarsOk t.ps
  | .node _ _, h => h.1

theorem noneHold_iff (wm : List WME) (ns : List NegTree) (b : Binding) :
    NegTree.noneHold wm ns b = true ↔ ∀ k ∈ ns, NegTree.holds wm k b = false := by
  induction ns with
  | nil => simp [NegTree.noneHold]
  | cons n ns ih => simp [NegTree.noneHold, ih]

theorem kidsClear_iff (wm : List WME) (bd : List String) (ns : List NegTree) (γ : Binding) :
    KidsClear wm bd ns γ ↔ ∀ k ∈ ns, ¬ TreeSpec wm bd k γ := by
  induction ns with
  | nil => simp [KidsClear]
  | cons n ns ih => simp [KidsClear, ih]

theorem kidsOk_iff (bd : List String) (ns : List NegTree) :
    KidsOk bd ns ↔ ∀ k ∈ ns, PatsSafe bd k.ps ∧ TreeOk bd k := by
  induction ns with
  | nil => simp [KidsOk]
  | cons n ns ih => simp [KidsOk, ih, and_assoc]

theorem kidsLocal_iff (bd : List String) (ns : List NegTree) (γ : Binding) :
    KidsLocal bd ns γ ↔ ∀ k ∈ ns, (∀ v ∈ k.ps.flatMap Pat.eqVars, v ∉ bd → γ.get v = none) ∧
      TreeLocal bd k γ := by
  induction ns with
  | nil => simp [KidsLocal]
  | cons n ns ih => simp [KidsLocal, ih, and_assoc]

mutual
/-- Bindings that agree outside `vs` (except on link keys) keep the nodes' variables unbound. -/
theorem treeLocal_transfer {β γ : Binding} {vs : List String}
    (hfr : ∀ v, v ∉ vs → (∀ s : Sym, s.ltiKey ≠ some v) → γ.get v = β.get v) :
    ∀ (t : NegTree) {bd : List String}, (∀ v ∈ vs, v ∈ bd) → TreeOk bd t →
      TreeLocal bd t β → TreeLocal bd t γ
  | .node ps ns, bd, hvs, hok, hl => by
    simp only [TreeLocal] at hl ⊢
    exact kidsLocal_transfer hfr ns (fun v hv => List.mem_append_left _ (hvs v hv)) hok.2 hl

theorem kidsLocal_transfer {β γ : Binding} {vs : List String}
    (hfr : ∀ v, v ∉ vs → (∀ s : Sym, s.ltiKey ≠ some v) → γ.get v = β.get v) :
    ∀ (ns : List NegTree) {bd : List String}, (∀ v ∈ vs, v ∈ bd) → KidsOk bd ns →
      KidsLocal bd ns β → KidsLocal bd ns γ
  | [], _, _, _, _ => trivial
  | k :: ns, bd, hvs, hok, hl => by
    simp only [KidsLocal, KidsOk] at hl hok ⊢
    refine ⟨fun v hv hnb => ?_, treeLocal_transfer hfr k hvs hok.2.1 hl.2.1,
      kidsLocal_transfer hfr ns hvs hok.2.2 hl.2.2⟩
    have hnv : v ∉ vs := fun h => hnb (hvs v h)
    obtain ⟨p, hp, hpv⟩ := List.mem_flatMap.mp hv
    have hvo : ∀ s : Sym, s.ltiKey ≠ some v := fun s' =>
      treeOk_vars k hok.2.1 p hp v hpv s'
    rw [hfr v hnv hvo]; exact hl.1 v hv hnb
end


mutual
/-- **The matcher finds a negated conjunction that holds.** If the specification `TreeSpec`
holds from final bindings `γ` that extend the bindings `b` so far, with the patterns in a safe
order and no pattern variable named like a link's key, `NegTree.holds` finds it. -/
theorem tree_complete (wm : List WME) : ∀ (t : NegTree) {bd : List String} {b γ : Binding},
    PatsSafe bd t.ps → TreeOk bd t → Bound bd b → Extends b γ → LinksIn b γ →
    TreeSpec wm bd t γ → NegTree.holds wm t b = true
  | .node ps ns, bd, b, γ, hs, hok, hbd, he, hl, hspec => by
    obtain ⟨hv, hk⟩ := hok
    obtain ⟨γ', e1, l1, hm, hloc, hclear⟩ := hspec
    have e2 : Extends b γ' := he.trans e1
    have l2 : LinksIn b γ' := hl.trans l1
    obtain ⟨b3, hb3, e3⟩ := matchPats_complete hm e2 l2 hs hbd
    have hbd3 := matchPats_bound hb3 hbd
    have hlk : LinksIn b3 γ' := by
      intro s k x hk' hx hn
      exact (matchPats_front hb3).extends k x (l2 s k x hk' hx hn)
    simp only [NegTree.holds, List.any_eq_true]
    exact ⟨b3, hb3, kids_clear wm ns hk hbd3 e3 hlk hloc hclear⟩

/-- Each inner node that does not hold from `β` is not found from the bindings so far. -/
theorem kids_clear (wm : List WME) : ∀ (ns : List NegTree) {bd : List String} {b β : Binding},
    KidsOk bd ns → Bound bd b → Extends b β → LinksIn b β → KidsLocal bd ns β →
    KidsClear wm bd ns β → NegTree.noneHold wm ns b = true
  | [], _, _, _, _, _, _, _, _, _ => rfl
  | k :: ns, bd, b, β, hok, hbd, he, hl, hloc, hcl => by
    simp only [KidsOk, KidsLocal, KidsClear] at hok hloc hcl
    simp only [NegTree.noneHold, Bool.and_eq_true, Bool.not_eq_true']
    refine ⟨?_, kids_clear wm ns hok.2.2 hbd he hl hloc.2.2 hcl.2⟩
    refine tree_clear wm k hok.2.1 hbd he hl (fun v hv hnone => ?_) hloc.2.1 hcl.1
    by_cases hin : v ∈ bd
    · have := hbd v hin; rw [hnone] at this; cases this
    · exact hloc.1 v hv hin

/-- **The matcher finds no match of a negated conjunction that does not hold.** The
conjunction's own variables are unbound in `β` unless `b` binds them, and so are those of the
nodes below it (`TreeLocal`). -/
theorem tree_clear (wm : List WME) : ∀ (t : NegTree) {bd : List String} {b β : Binding},
    TreeOk bd t → Bound bd b → Extends b β → LinksIn b β →
    (∀ v ∈ t.ps.flatMap Pat.eqVars, b.get v = none → β.get v = none) →
    TreeLocal bd t β → ¬ TreeSpec wm bd t β → NegTree.holds wm t b = false
  | .node ps ns, bd, b, β, hok, hbd, he, hl, hloc, hlocK, hneg => by
    cases hh : NegTree.holds wm (.node ps ns) b with
    | false => rfl
    | true =>
      exfalso
      simp only [NegTree.holds, List.any_eq_true] at hh
      obtain ⟨b'', hin, hnone⟩ := hh
      obtain ⟨hv, hk⟩ := hok
      obtain ⟨γ, eβ, eγ, hlγ, hfr⟩ := matchPats_lift hin he hl hloc
      have hl'' := hlγ hv
      apply hneg
      refine ⟨γ, eβ, ?_, ?_, ?_, ?_⟩
      · intro s k x hk' hx hn
        have h1 := hl'' s k x hk' hx hn
        exact he k x (matchPats_links hin hv s k x hk' h1 hn)
      · obtain ⟨_, hmatch⟩ := matchPats_sound hin
        intro p hp
        obtain ⟨w, hw, hr⟩ := hmatch p hp
        exact ⟨w, hw, Pat.run_stable hr eγ⟩
      · exact kidsLocal_transfer hfr ns (fun v hv => List.mem_append_right _ hv) hk hlocK
      · exact kids_notSpec wm ns hk (matchPats_bound hin hbd) eγ hl'' hnone

/-- Each inner node that is found from the bindings so far holds from the final bindings. -/
theorem kids_notSpec (wm : List WME) : ∀ (ns : List NegTree) {bd : List String} {b γ : Binding},
    KidsOk bd ns → Bound bd b → Extends b γ → LinksIn b γ →
    NegTree.noneHold wm ns b = true → KidsClear wm bd ns γ
  | [], _, _, _, _, _, _, _, _ => trivial
  | k :: ns, bd, b, γ, hok, hbd, he, hl, hnone => by
    simp only [KidsOk] at hok
    simp only [NegTree.noneHold, Bool.and_eq_true, Bool.not_eq_true'] at hnone
    refine ⟨fun hspec => ?_, kids_notSpec wm ns hok.2.2 hbd he hl hnone.2⟩
    have := tree_complete wm k hok.1 hok.2.1 hbd he hl hspec
    rw [hnone.1] at this; cases this
end


/-- The conditions of a production in a safe order with respect to final bindings `β`: positive
patterns in a safe order; each negation matched by no extension of `β`, with its variables not
bound by `β` unless bound before it; each negated conjunction of one level of nesting likewise,
with its inner negations in a safe order. A negated conjunction nested more deeply
(`Cond.nccg`) is a tree, with the conditions of `TreeOk`, `TreeLocal` and `TreeSpec` above. -/
def CondsOk (wm : List WME) (β : Binding) : List String → List Cond → Prop
  | _, [] => True
  | bd, .pos p :: cs => Pat.Safe bd p ∧ CondsOk wm β (bd ++ p.eqVars) cs
  | bd, .neg ps :: cs =>
    (∀ v ∈ ps.flatMap Pat.eqVars, v ∉ bd → β.get v = none) ∧
    (¬∃ γ, Extends β γ ∧ ∀ p ∈ ps, ∃ w ∈ wm, p.run γ w = some γ) ∧ CondsOk wm β bd cs
  | bd, .ncc ps ns :: cs =>
    (∀ v ∈ ps.flatMap Pat.eqVars, v ∉ bd → β.get v = none) ∧ VarsOk ps ∧
    (∀ n ∈ ns, PatsSafe (bd ++ ps.flatMap Pat.eqVars) n) ∧
    (¬∃ γ, Extends β γ ∧ (∀ p ∈ ps, ∃ w ∈ wm, p.run γ w = some γ) ∧
      ∀ n ∈ ns, ¬∃ γ', Extends γ γ' ∧ LinksIn γ γ' ∧ ∀ q ∈ n, ∃ w ∈ wm, q.run γ' w = some γ') ∧
    CondsOk wm β bd cs
  | bd, .nccg ns :: cs =>
    (∀ v ∈ ns.tree.ps.flatMap Pat.eqVars, v ∉ bd → β.get v = none) ∧ TreeOk bd ns.tree ∧
    TreeLocal bd ns.tree β ∧ ¬ TreeSpec wm bd ns.tree β ∧ CondsOk wm β bd cs

/-- **Completeness of matching with negations.** If, under bindings `β` that extend `b`, each
positive condition matches its element of `ws`, and the conditions are in a safe order with
each negation unmatched under `β` (`CondsOk`), the matcher returns an instantiation with exactly
the elements `ws`, whose bindings `β` extends. -/
theorem matchConds_complete_neg {wm : List WME} {cs : List Cond} {ws : List WME} {b β : Binding}
    {bd : List String} (hlen : ws.length = (positives cs).length)
    (hm : ∀ i (h₁ : i < (positives cs).length) (h₂ : i < ws.length),
      ws[i] ∈ wm ∧ (positives cs)[i].run β ws[i] = some β)
    (he : Extends b β) (hl : LinksIn b β) (hok : CondsOk wm β bd cs) (hbd : Bound bd b) :
    ∃ r ∈ matchConds wm cs b, r.2 = ws ∧ Extends r.1 β := by
  induction cs generalizing ws b bd with
  | nil =>
    cases ws with
    | nil => exact ⟨(b, []), by simp [matchConds], rfl, he⟩
    | cons _ _ => simp [positives] at hlen
  | cons c cs ih =>
    cases c with
    | pos p =>
      cases ws with
      | nil => simp [positives] at hlen
      | cons w ws =>
        obtain ⟨hw, hr⟩ := hm 0 (by simp [positives]) (by simp)
        simp only [positives, List.getElem_cons_zero] at hw hr
        obtain ⟨hsp, hss⟩ := hok
        obtain ⟨b₁, hb₁, eb₁, hbd₁⟩ := Pat.run_complete hr (Extends.refl β) he hl hsp hbd
        obtain ⟨r, hr', hr2, er⟩ := ih (ws := ws) (by simpa [positives] using hlen)
          (fun i h₁ h₂ => by
            have := hm (i + 1) (by simpa [positives] using Nat.succ_lt_succ h₁) (Nat.succ_lt_succ h₂)
            simpa only [positives, List.getElem_cons_succ] using this)
          eb₁ (hl.mono (Pat.run_extends hb₁)) hss hbd₁
        refine ⟨(r.1, w :: r.2), ?_, by simp [hr2], er⟩
        simp only [matchConds, List.mem_flatMap]
        exact ⟨w, hw, by rw [hb₁]; simp only [List.mem_map]; exact ⟨r, hr', rfl⟩⟩
    | neg ps =>
      obtain ⟨hloc, hneg, hok'⟩ := hok
      have hempty : matchPats wm ps b = [] :=
        matchPats_neg_empty hneg he hl (fun v hv hn => hloc v hv (fun hbv => by
          have := hbd v hbv; rw [hn] at this; cases this))
      obtain ⟨r, hr, hr2, er⟩ := ih (ws := ws) (by simpa [positives] using hlen)
        (fun i h₁ h₂ => by simpa [positives] using hm i (by simpa [positives] using h₁) h₂)
        he hl hok' hbd
      refine ⟨r, ?_, hr2, er⟩
      simp only [matchConds, hempty, List.isEmpty_nil, ↓reduceIte]; exact hr
    | ncc ps ns =>
      obtain ⟨hloc, hvo, hsafe, hneg, hok'⟩ := hok
      have hclear := ncc_clear hneg he hl (fun v hv hn => hloc v hv (fun hbv => by
          have := hbd v hbv; rw [hn] at this; cases this)) hvo hsafe hbd
      obtain ⟨r, hr, hr2, er⟩ := ih (ws := ws) (by simpa [positives] using hlen)
        (fun i h₁ h₂ => by simpa [positives] using hm i (by simpa [positives] using h₁) h₂)
        he hl hok' hbd
      refine ⟨r, ?_, hr2, er⟩
      simp only [matchConds, hclear, Bool.false_eq_true, ↓reduceIte]; exact hr
    | nccg ns =>
      obtain ⟨hloc, hto, htl, hneg, hok'⟩ := hok
      have hclear := tree_clear wm ns.tree hto hbd he hl (fun v hv hn => hloc v hv (fun hbv => by
          have := hbd v hbv; rw [hn] at this; cases this)) htl hneg
      obtain ⟨r, hr, hr2, er⟩ := ih (ws := ws) (by simpa [positives] using hlen)
        (fun i h₁ h₂ => by simpa [positives] using hm i (by simpa [positives] using h₁) h₂)
        he hl hok' hbd
      refine ⟨r, ?_, hr2, er⟩
      simp only [matchConds, hclear, Bool.false_eq_true, ↓reduceIte]; exact hr



end Soar
