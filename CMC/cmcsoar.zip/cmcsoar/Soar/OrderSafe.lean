import Soar.JoinOrderSem
/-!
# The join order is a safe order

`joinOrder_matches` (Soar/JoinOrderSem.lean) assumes that the join order is safe
(`PatsSafe`): every variable a relational test reads is bound earlier. This file shows when
that holds.

`joinOrder` adds a positive pattern when the variables it *needs* — those its relational tests
read and it does not bind itself (`Pat.needs`, the `Cond.needs` of a positive condition) — are
bound by the patterns before it. A variable the pattern binds itself counts as available
anywhere in it. The matcher (`Pat.run`) and `Pat.Safe`, however, evaluate a pattern's tests
left to right, identifier, attribute, value; so a test that reads a variable the same pattern
binds only in a later field (or later in the same field) is safe only if that variable is bound
by an earlier pattern. The greedy choice may put such a pattern first although the rule's own
order is safe: `joinOrder_unsafe_example` gives a rule with a safe order on which the join order
is unsafe and finds no instantiation where the rule's own order finds two
(`joinOrder_loses_matches`). Soar 9.6.5 does not have this problem: its Rete binds the
variables of all three fields of a condition before adding the condition's tests
(`build_network_for_condition_list`, rete.cpp), so the order of tests within a condition does
not matter there; the difference is in the model's matcher.

The theorem is therefore stated under two hypotheses:

* each positive pattern is *in order* (`Pat.InOrder`): a test that reads a variable the
  pattern binds comes after that variable's equality test in the pattern; and
* the patterns' needs are acyclic: in some order, each pattern's needs are bound by the
  patterns before it (`NeedsSafe`), which holds when that order is safe (`needsSafe_of_safe`).

Under them the eligible set is never empty while a positive condition remains, so the
relational tests are never moved (`moveRel`) and the fuel (`cs.length + 1`, one more than the
number of steps, each of which removes a condition) never runs out; the join order is safe
(`joinOrder_safe`), and `joinOrder_matches'` drops the safety assumption of `joinOrder_matches`.

SCOPE. The orders are safe from no bound variable (`[]`), as `joinOrder` starts. A rule whose
own order is safe only given variables bound beforehand may have needs that no pattern binds;
the join order then moves relational tests or places a pattern whose needs are unbound, and is
not covered.
-/

namespace Soar

/-! ## Needs and in-order patterns -/

/-- The variables a positive pattern needs bound before it: those its relational tests read
and that it does not bind itself (`Cond.needs` of `.pos p`). -/
def Pat.needs (p : Pat) : List String := p.useVars.filter (fun v => !p.eqVars.contains v)

/-- `Cond.needs` of a positive condition is `Pat.needs`. -/
theorem Cond.needs_pos (pv : List String) (p : Pat) : Cond.needs pv (.pos p) = p.needs := rfl

/-- A pattern is *in order* when it is safe given only its needs: every test that reads a
variable the pattern binds comes after that variable's equality test (identifier, attribute,
value, each left to right, as `Pat.run` evaluates them). -/
def Pat.InOrder (p : Pat) : Prop := Pat.Safe p.needs p

/-- An order of patterns in which each pattern's needs are bound by `bd` or by the patterns
before it. -/
def NeedsSafe : List String → List Pat → Prop
  | _, [] => True
  | bd, p :: ps => (∀ v ∈ p.needs, v ∈ bd) ∧ NeedsSafe (bd ++ p.eqVars) ps

/-! ## Monotonicity in the bound variables -/

/-- Adding the same variables to two lists keeps one included in the other. -/
theorem sub_append {bd bd' : List String} (hs : ∀ v ∈ bd, v ∈ bd') (l : List String) :
    ∀ v ∈ bd ++ l, v ∈ bd' ++ l := by
  intro v hv
  rcases List.mem_append.mp hv with h | h
  · exact List.mem_append_left _ (hs v h)
  · exact List.mem_append_right _ h

/-- A safe test stays safe when more variables are bound before it. -/
theorem Test.Safe.mono : ∀ {bd bd' : List String} {t : Test}, (∀ v ∈ bd, v ∈ bd') →
    Test.Safe bd t → Test.Safe bd' t
  | _, _, [], _, _ => trivial
  | _, _, _ :: _, hs, ⟨h1, h2⟩ => ⟨fun v hv => hs v (h1 v hv), Test.Safe.mono (sub_append hs _) h2⟩

/-- A safe pattern stays safe when more variables are bound before it. -/
theorem Pat.Safe.mono {bd bd' : List String} {p : Pat} (hs : ∀ v ∈ bd, v ∈ bd') (h : Pat.Safe bd p) :
    Pat.Safe bd' p :=
  ⟨Test.Safe.mono hs h.1, Test.Safe.mono (sub_append hs _) h.2.1,
    Test.Safe.mono (by rw [List.append_assoc, List.append_assoc]; exact sub_append hs _) h.2.2⟩

/-- A safe order stays safe when more variables are bound before it. -/
theorem PatsSafe.mono : ∀ {bd bd' : List String} {ps : List Pat}, (∀ v ∈ bd, v ∈ bd') →
    PatsSafe bd ps → PatsSafe bd' ps
  | _, _, [], _, _ => trivial
  | _, _, _ :: _, hs, ⟨h1, h2⟩ => ⟨Pat.Safe.mono hs h1, PatsSafe.mono (sub_append hs _) h2⟩

/-- A `NeedsSafe` order stays so when more variables are bound before it. -/
theorem NeedsSafe.mono : ∀ {bd bd' : List String} {ps : List Pat}, (∀ v ∈ bd, v ∈ bd') →
    NeedsSafe bd ps → NeedsSafe bd' ps
  | _, _, [], _, _ => trivial
  | _, _, _ :: _, hs, ⟨h1, h2⟩ => ⟨fun v hv => hs v (h1 v hv), NeedsSafe.mono (sub_append hs _) h2⟩

/-- Taking a pattern out of a `NeedsSafe` order keeps it `NeedsSafe` once the pattern's
variables are bound. -/
theorem NeedsSafe.erase : ∀ {bd bd' : List String} {l : List Pat} (p : Pat), NeedsSafe bd l →
    (∀ v ∈ bd, v ∈ bd') → (∀ v ∈ p.eqVars, v ∈ bd') → NeedsSafe bd' (l.erase p)
  | _, _, [], _, _, _, _ => by simp [NeedsSafe]
  | bd, bd', q :: qs, p, ⟨h1, h2⟩, hs, hp => by
    by_cases e : q = p
    · subst e
      rw [List.erase_cons_head]
      refine NeedsSafe.mono (fun v hv => ?_) h2
      rcases List.mem_append.mp hv with h | h
      · exact hs v h
      · exact hp v h
    · rw [List.erase_cons_tail (by simpa using e)]
      exact ⟨fun v hv => hs v (h1 v hv),
        NeedsSafe.erase p h2 (sub_append hs _) (fun v hv => List.mem_append_left _ (hp v hv))⟩

/-! ## Safety and needs -/

/-- An in-order pattern whose needs are bound is safe. -/
theorem Pat.safe_of_inOrder {bd : List String} {p : Pat} (hi : p.InOrder)
    (hn : ∀ v ∈ p.needs, v ∈ bd) : Pat.Safe bd p :=
  Pat.Safe.mono hn hi

/-- An order of in-order patterns is safe when each one's needs are bound before it. -/
theorem patsSafe_of_needsSafe : ∀ {bd : List String} {l : List Pat}, (∀ p ∈ l, p.InOrder) →
    NeedsSafe bd l → PatsSafe bd l
  | _, [], _, _ => trivial
  | _, _ :: _, hi, ⟨h1, h2⟩ =>
    ⟨Pat.safe_of_inOrder (hi _ List.mem_cons_self) h1,
      patsSafe_of_needsSafe (fun q hq => hi q (List.mem_cons_of_mem _ hq)) h2⟩

/-- In a safe test, every variable a relational test reads is bound before it or by the
test. -/
theorem Test.Safe.uses : ∀ {bd : List String} {t : Test}, Test.Safe bd t →
    ∀ v ∈ t.flatMap STest.useVars, v ∈ bd ∨ v ∈ Test.binds t
  | _, [], _, v, hv => by simp at hv
  | bd, st :: ts, ⟨h1, h2⟩, v, hv => by
    unfold Test.binds
    rw [List.flatMap_cons] at hv ⊢
    rcases List.mem_append.mp hv with h | h
    · exact Or.inl (h1 v h)
    · rcases Test.Safe.uses h2 v h with h' | h'
      · rcases List.mem_append.mp h' with h'' | h''
        · exact Or.inl h''
        · exact Or.inr (List.mem_append_left _ h'')
      · exact Or.inr (List.mem_append_right _ h')

/-- In a safe pattern, every variable a relational test reads is bound before it or by the
pattern. -/
theorem Pat.Safe.uses {bd : List String} {p : Pat} (h : Pat.Safe bd p) :
    ∀ v ∈ p.useVars, v ∈ bd ∨ v ∈ p.eqVars := by
  intro v hv
  rw [Pat.eqVars_eq]
  simp only [Pat.useVars, List.flatMap_append, List.mem_append] at hv
  rcases hv with (hv | hv) | hv
  · rcases Test.Safe.uses h.1 v hv with h' | h'
    · exact Or.inl h'
    · exact Or.inr (by simp [h'])
  · rcases Test.Safe.uses h.2.1 v hv with h' | h'
    · rcases List.mem_append.mp h' with h'' | h''
      · exact Or.inl h''
      · exact Or.inr (by simp [h''])
    · exact Or.inr (by simp [h'])
  · rcases Test.Safe.uses h.2.2 v hv with h' | h'
    · simp only [List.mem_append] at h'
      rcases h' with (h'' | h'') | h''
      · exact Or.inl h''
      · exact Or.inr (by simp [h''])
      · exact Or.inr (by simp [h''])
    · exact Or.inr (by simp [h'])

/-- A safe order is one in which each pattern's needs are bound before it. -/
theorem needsSafe_of_safe : ∀ {bd : List String} {l : List Pat}, PatsSafe bd l → NeedsSafe bd l
  | _, [], _ => trivial
  | _, p :: _, ⟨h1, h2⟩ => ⟨fun v hv => by
      obtain ⟨hu, he⟩ := List.mem_filter.mp hv
      rcases Pat.Safe.uses h1 v hu with h | h
      · exact h
      · simp [h] at he, needsSafe_of_safe h2⟩

/-- A pattern none of whose relational tests reads a variable the pattern binds is in order. -/
theorem Pat.inOrder_of_disjoint (p : Pat) (h : ∀ v ∈ p.useVars, v ∉ p.eqVars) : p.InOrder := by
  have hn : ∀ v ∈ p.useVars, v ∈ p.needs := fun v hv =>
    List.mem_filter.mpr ⟨hv, by simp [h v hv]⟩
  have key : ∀ (bd : List String) (t : Test), (∀ v ∈ t.flatMap STest.useVars, v ∈ bd) → Test.Safe bd t := by
    intro bd t
    induction t generalizing bd with
    | nil => intro _; trivial
    | cons st ts ih =>
      intro hu
      rw [List.flatMap_cons] at hu
      exact ⟨fun v hv => hu v (List.mem_append_left _ hv),
        ih _ (fun v hv => List.mem_append_left _ (hu v (List.mem_append_right _ hv)))⟩
  have hu : ∀ v ∈ p.useVars, v ∈ p.needs := hn
  simp only [Pat.useVars, List.flatMap_append, List.mem_append] at hu
  refine ⟨key _ _ (fun v hv => hu v (Or.inl (Or.inl hv))),
    key _ _ (fun v hv => List.mem_append_left _ (hu v (Or.inl (Or.inr hv)))),
    key _ _ (fun v hv => List.mem_append_left _ (List.mem_append_left _ (hu v (Or.inr hv))))⟩

/-! ## Positive patterns of condition lists -/

/-- The pattern of a positive condition. -/
def Cond.pos? : Cond → Option Pat
  | .pos p => some p
  | _ => none

/-- `positives` keeps the patterns of the positive conditions. -/
theorem positives_eq_filterMap : ∀ (l : List Cond), positives l = l.filterMap Cond.pos?
  | [] => rfl
  | c :: l => by cases c <;> simp [positives, Cond.pos?, List.filterMap_cons, positives_eq_filterMap l]

/-- The positive patterns of an append. -/
theorem positives_append (l₁ l₂ : List Cond) : positives (l₁ ++ l₂) = positives l₁ ++ positives l₂ := by
  simp [positives_eq_filterMap, List.filterMap_append]

/-- Reordering the conditions reorders their positive patterns. -/
theorem positives_perm {l₁ l₂ : List Cond} (h : l₁.Perm l₂) : (positives l₁).Perm (positives l₂) := by
  rw [positives_eq_filterMap, positives_eq_filterMap]; exact h.filterMap _

/-- Filtering out conditions that are not positive keeps the positive patterns. -/
theorem positives_filter (f : Cond → Bool) : ∀ (l : List Cond),
    (∀ c ∈ l, f c = false → ∀ p, c ≠ .pos p) → positives (l.filter f) = positives l
  | [], _ => rfl
  | c :: l, h => by
    have ih := positives_filter f l (fun c' hc' => h c' (List.mem_cons_of_mem _ hc'))
    by_cases hf : f c = true
    · rw [List.filter_cons_of_pos hf]
      cases c <;> simp [positives, ih]
    · rw [List.filter_cons_of_neg hf, ih]
      have hn := h c List.mem_cons_self (by simpa using hf)
      cases c with
      | pos p => exact absurd rfl (hn p)
      | _ => rfl

/-- A list of conditions none of which is positive has no positive pattern. -/
theorem positives_nil_of : ∀ (l : List Cond), (∀ c ∈ l, ∀ p, c ≠ .pos p) → positives l = []
  | [], _ => rfl
  | c :: l, h => by
    have ih := positives_nil_of l (fun c' hc' => h c' (List.mem_cons_of_mem _ hc'))
    cases c with
    | pos p => exact absurd rfl (h _ List.mem_cons_self p)
    | _ => simpa [positives] using ih

/-! ## The join order -/

/-- The invariant of `joinOrder.go`: if the remaining positive patterns are in order and can be
ordered so that each one's needs are bound by `bound` and those before it, and the fuel
exceeds the number of remaining conditions, then the positive patterns of the result are
those of `acc` followed by an order that is safe from `bound`. -/
theorem joinOrder_go_safe (multi : List (String × Nat)) (pv : List String) :
    ∀ (n : Nat) (rest : List Cond) (bound : List String) (acc : List Cond),
      rest.length < n → (∀ p, Cond.pos p ∈ rest → p.InOrder) →
      (∃ l, l.Perm (positives rest) ∧ NeedsSafe bound l) →
      ∃ X, positives (joinOrder.go multi n rest bound acc pv) = positives acc ++ X ∧
        PatsSafe bound X
  | 0, rest, bound, acc, hlen, _, _ => absurd hlen (Nat.not_lt_zero _)
  | n + 1, rest, bound, acc, hlen, hi, hn => by
    unfold joinOrder.go
    simp only
    split
    · exact ⟨[], by simp, trivial⟩
    · rename_i hne
      split
      · -- the ready negations go first
        rename_i hr
        generalize hready : rest.filter (fun c => match c with
          | .pos _ => false
          | _ => (c.needs pv).all bound.contains) = ready at hr ⊢
        have hnp : ∀ c ∈ ready, ∀ p, c ≠ .pos p := by
          intro c hc p hcp
          subst hcp
          rw [← hready] at hc
          simp at hc
        have hrm : ∀ c ∈ rest, (!ready.any fun r => decide (r = c)) = false → ∀ p, c ≠ .pos p := by
          intro c _ hf p hcp
          simp only [Bool.not_eq_false', List.any_eq_true, decide_eq_true_eq] at hf
          obtain ⟨r, hr', rfl⟩ := hf
          exact hnp r hr' p hcp
        have hpos := positives_filter _ rest hrm
        obtain ⟨r, hr'⟩ := List.exists_mem_of_ne_nil ready (by simpa using hr)
        have hrin : r ∈ rest := by rw [← hready] at hr'; exact (List.mem_filter.mp hr').1
        have hlt : (rest.filter fun c => !ready.any fun r => decide (r = c)).length < rest.length :=
          List.length_filter_lt_length_iff_exists.mpr ⟨r, hrin, by
            have : ready.any (fun r' => decide (r' = r)) = true :=
              List.any_eq_true.mpr ⟨r, hr', decide_eq_true rfl⟩
            simp [this]⟩
        obtain ⟨X, hX, hs⟩ := joinOrder_go_safe multi pv n
          (rest.filter fun c => !ready.any fun r => decide (r = c)) bound (acc ++ ready) (by omega)
          (fun p hp => hi p (List.mem_filter.mp hp).1) (by rw [hpos]; exact hn)
        refine ⟨X, ?_, hs⟩
        rw [hX, positives_append, positives_nil_of ready hnp, List.append_nil]
      · rename_i hnr
        generalize helig : rest.filter (fun c => match c with
          | .pos _ => (c.needs pv).all bound.contains
          | _ => false) = eligible
        have helig_mem : ∀ c ∈ eligible, ∃ p, c = .pos p ∧ ∀ v ∈ p.needs, v ∈ bound := by
          intro c hc
          rw [← helig] at hc
          obtain ⟨_, hc2⟩ := List.mem_filter.mp hc
          cases c with
          | pos p =>
            refine ⟨p, rfl, fun v hv => ?_⟩
            have := List.all_eq_true.mp hc2 v hv
            simpa using this
          | _ => simp at hc2
        obtain ⟨l, hl, hns⟩ := hn
        split
        · -- an empty pool: no positive condition remains
          rename_i hpool
          refine ⟨positives rest, by rw [positives_append], ?_⟩
          have : positives rest = [] := by
            by_cases he : eligible.isEmpty = true
            · simp only [he, ↓reduceIte] at hpool
              rw [List.filter_eq_nil_iff] at hpool
              refine positives_nil_of rest (fun c hc p hcp => ?_)
              have := hpool c hc
              subst hcp; simp at this
            · simp only [he, Bool.false_eq_true, ↓reduceIte] at hpool
              subst hpool; simp at he
          rw [this]; trivial
        · rename_i pool c₀ tl hpool
          by_cases he : eligible.isEmpty = true
          · -- impossible: some positive condition remains, and the first of `l` is eligible
            exfalso
            have hc0 : c₀ ∈ c₀ :: tl := List.mem_cons_self
            rw [← hpool] at hc0
            simp only [he, ↓reduceIte] at hc0
            obtain ⟨hc0r, hc0p⟩ := List.mem_filter.mp hc0
            cases c₀ with
            | pos p0 =>
              have hp0 : p0 ∈ positives rest := mem_positives.mpr hc0r
              cases l with
              | nil => exact absurd (hl.mem_iff.mpr hp0) (by simp)
              | cons q qs =>
                have hq : Cond.pos q ∈ rest := mem_positives.mp (hl.mem_iff.mp List.mem_cons_self)
                have : Cond.pos q ∈ eligible := by
                  rw [← helig]
                  refine List.mem_filter.mpr ⟨hq, ?_⟩
                  simp only [Cond.needs_pos, List.all_eq_true]
                  intro v hv; simpa using hns.1 v hv
                rw [List.isEmpty_iff] at he
                rw [he] at this; simp at this
            | _ => simp at hc0p
          · simp only [he, Bool.false_eq_true, ↓reduceIte] at hpool
            simp only [he, Bool.false_eq_true, ↓reduceIte]
            generalize hb : eligible.foldl (pickBest multi bound) c₀ = best
            have hbest : best ∈ eligible := by
              rw [← hb]
              rcases List.mem_cons.mp (foldl_pickBest_mem multi bound eligible c₀) with h | h
              · rw [h, hpool]; exact List.mem_cons_self
              · exact h
            obtain ⟨p, rfl, hpn⟩ := helig_mem _ hbest
            have hbr : Cond.pos p ∈ rest := by
              rw [← helig] at hbest; exact (List.mem_filter.mp hbest).1
            have hperm := perm_eraseIdx_idxOf hbr
            generalize rest.eraseIdx (rest.idxOf (Cond.pos p)) = rest' at hperm
            have hlen' : rest'.length < n := by
              have := hperm.length_eq; simp at this; omega
            have hpp : (positives rest).Perm (p :: positives rest') := by
              have := positives_perm hperm; simpa [positives] using this
            have hbn : ∀ v, v ∈ bindNext bound (.pos p) ↔ v ∈ bound ++ p.eqVars := by
              intro v
              simp only [bindNext, List.mem_append, List.mem_filter]
              constructor
              · rintro (h | ⟨h, _⟩)
                · exact Or.inl h
                · exact Or.inr h
              · rintro (h | h)
                · exact Or.inl h
                · by_cases hv : v ∈ bound
                  · exact Or.inl hv
                  · exact Or.inr ⟨h, by simpa using hv⟩
            have hl' : (l.erase p).Perm (positives rest') := by
              have := (hl.trans hpp).erase p
              simpa using this
            have hns' : NeedsSafe (bindNext bound (.pos p)) (l.erase p) :=
              NeedsSafe.erase p hns (fun v hv => (hbn v).mpr (List.mem_append_left _ hv))
                (fun v hv => (hbn v).mpr (List.mem_append_right _ hv))
            obtain ⟨X, hX, hs⟩ := joinOrder_go_safe multi pv n rest' (bindNext bound (.pos p))
              (acc ++ [.pos p]) hlen'
              (fun q hq => hi q (hperm.mem_iff.mpr (List.mem_cons_of_mem _ hq))) ⟨_, hl', hns'⟩
            refine ⟨p :: X, ?_, Pat.safe_of_inOrder (hi p hbr) hpn,
              PatsSafe.mono (fun v hv => (hbn v).mp hv) hs⟩
            rw [hX, positives_append]; simp [positives]

/-- **The join order is safe.** If every positive pattern of a rule is in order (a test that
reads a variable the pattern binds comes after that variable's equality test) and the
patterns can be ordered so that each one's needs are bound by those before it (in particular,
if some order of them is safe, `needsSafe_of_safe`), then the positive patterns of
`joinOrder cs` are in a safe order. The greedy choice never finds the eligible patterns empty
while a positive condition remains, so no relational test is moved and the fuel suffices. -/
theorem joinOrder_safe (cs : List Cond) (multi : List (String × Nat))
    (hi : ∀ p ∈ positives cs, p.InOrder)
    (hn : ∃ l, l.Perm (positives cs) ∧ NeedsSafe [] l) :
    PatsSafe [] (positives (joinOrder cs multi)) := by
  unfold joinOrder
  obtain ⟨X, hX, hs⟩ := joinOrder_go_safe multi _ (cs.length + 1) cs [] [] (Nat.lt_succ_self _)
    (fun p hp => hi p (mem_positives.mpr hp)) hn
  rw [hX]; simpa [positives] using hs

/-- The join order is safe when some order of the rule's in-order positive patterns is safe. -/
theorem joinOrder_safe_of_perm (cs : List Cond) (multi : List (String × Nat))
    (hi : ∀ p ∈ positives cs, p.InOrder) {l : List Pat} (hl : l.Perm (positives cs))
    (hs : PatsSafe [] l) : PatsSafe [] (positives (joinOrder cs multi)) :=
  joinOrder_safe cs multi hi ⟨l, hl, needsSafe_of_safe hs⟩

/-- The join order is safe when the rule's own order is safe and its positive patterns are
in order. -/
theorem joinOrder_safe_of_own (cs : List Cond) (multi : List (String × Nat))
    (hi : ∀ p ∈ positives cs, p.InOrder) (hs : PatsSafe [] (positives cs)) :
    PatsSafe [] (positives (joinOrder cs multi)) :=
  joinOrder_safe_of_perm cs multi hi (List.Perm.refl _) hs

/-- **The join order keeps the matches**, without assuming that the join order is safe. Let
the positive patterns of a rule have no `@` test, compare values of one kind in every
relational test between variables, be in order, and be safe in the rule's own order. Then
every instantiation of the rule's own order whose bindings respect those kinds is found, up to
variables the reordered patterns do not bind, by the matcher on the join order, from any
initial bindings. -/
theorem joinOrder_matches' {wm : List WME} {κ : String → Nat} (cs : List Cond)
    (multi : List (String × Nat)) (hg : AllGood κ cs) {b b' : Binding} {bd : List String}
    (h : b' ∈ matchPats wm (positives cs) b) (hr : Respects κ b') (hv : VarsOk (positives cs))
    (hi : ∀ p ∈ positives cs, p.InOrder) (hs : PatsSafe [] (positives cs)) (hbd : Bound bd b) :
    ∃ b'' ∈ matchPats wm (positives (joinOrder cs multi)) b, Extends b'' b' :=
  joinOrder_matches cs multi hg h hr hv
    (PatsSafe.mono (fun v hv => by simp at hv) (joinOrder_safe_of_own cs multi hi hs)) hbd

/-! ## Without in-order patterns, the join order can be unsafe

The pattern `({<x> > <y>} ^a <y>)` needs nothing (it binds `<y>` itself), but its identifier
test reads `<y>` before its value binds it. With `(<z> ^<w> <y>)` before it the rule's order is
safe; `joinOrder` puts it first (its constant attribute scores higher), and the result is
unsafe: the matcher then finds no instantiation. -/

/-- `({<x> > <y>} ^a <y>)`. -/
def exPat₁ : Pat := { id := [.var "x", .rel .gt (.var "y")], attr := [.const (.str "a")], val := [.var "y"] }
/-- `(<z> ^<w> <y>)`. -/
def exPat₂ : Pat := { id := [.var "z"], attr := [.var "w"], val := [.var "y"] }
/-- The rule's conditions, in its own (safe) order. -/
def exConds : List Cond := [.pos exPat₂, .pos exPat₁]
/-- Working memory `(1 ^b 2) (3 ^a 2)` (identifiers by number). -/
def exWm : List WME := [{ id := 1, attr := .str "b", val := .id 2 }, { id := 3, attr := .str "a", val := .id 2 }]

/-- **A safe rule with an unsafe join order.** The rule's own order is safe, but the join
order puts `({<x> > <y>} ^a <y>)` first and is unsafe; so the hypothesis `Pat.InOrder` of
`joinOrder_safe` cannot be dropped (and `joinOrder_safe` would be false with only "some order
is safe"). -/
theorem joinOrder_unsafe_example :
    PatsSafe [] (positives exConds) ∧ positives (joinOrder exConds) = [exPat₁, exPat₂] ∧
      ¬ PatsSafe [] (positives (joinOrder exConds)) := by
  have hj : positives (joinOrder exConds) = [exPat₁, exPat₂] := by decide
  refine ⟨?_, hj, ?_⟩
  · simp [exConds, positives, PatsSafe, Pat.Safe, Test.Safe, exPat₁, exPat₂, Pat.eqVars,
      STest.useVars, STest.eqVars, Test.binds]
  · rw [hj]
    simp [PatsSafe, Pat.Safe, Test.Safe, exPat₁, STest.useVars, STest.eqVars]

/-- **The model's join order can lose matches.** For the rule of `joinOrder_unsafe_example`,
whose relational test compares two identifiers, the matcher finds two instantiations on the
rule's own order and none on the join order. (Soar's Rete binds the variables of all fields of
a condition before testing it, so Soar matches this rule in either order.) -/
theorem joinOrder_loses_matches :
    (matchPats exWm (positives exConds) []).length = 2 ∧
      matchPats exWm (positives (joinOrder exConds)) [] = [] := by
  constructor <;> decide

end Soar
