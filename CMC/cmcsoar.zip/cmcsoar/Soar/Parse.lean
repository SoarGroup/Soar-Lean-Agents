import Soar.Syntax
import Soar.SMem
import Soar.EpMem
import Soar.Chunk
import Soar.Explore
import Soar.WMA
/-!
# Reading Soar source

A parser for Soar productions (`sp {…}`), following the grammar of [Man] §3.3.7.1. It
expands notation into the core language of `Soar.Syntax`:

* attribute paths `^a.b.c v` become a chain of patterns (on the left-hand side) or of new
  objects (on the right-hand side), [Man] §3.3.5.11;
* several values for one attribute become several patterns or actions, [Man] §3.3.5.8;
* `-^attr v₁ v₂` becomes a negated conjunction, [Man] §3.3.5.8;
* `(state <s> …)` adds the test `(<s> ^type state)`, marked as a test that `<s>` is a state of
  the goal stack (Soar's goal test, [Man] §3.3.5.1);
* right-hand-side preferences become preference actions, with the acceptable preference
  implicit only when no other preference is given, [Man] §3.3.6.5.

Everything outside `sp {…}` blocks (commands such as `learn` or `watch`) is ignored.

Not supported (reported as errors):
long-term-identifier predicates (`@`), negations nested more than two deep, `gp`.
-/

namespace Soar.Parse

inductive Tok where
  | lp | rp | lb | rb | caret | dot | comma | arrow
  | var (s : String)
  | sym (s : String)       -- symbol or number, as written
  | quoted (s : String)    -- |…|
  | str (s : String)       -- "…" documentation
  | op (s : String)        -- - + ! ~ > < = <> <= >= <=> << >> @
  deriving Repr, BEq, Inhabited

def isSymChar (c : Char) : Bool :=
  c.isAlphanum || "-_*$%&/?:+!".contains c

/-- Read a `|…|` constant body (after the opening bar), handling `\|` and `\\` escapes
([Man] §3.1.1). Returns the text and the characters after the closing bar. -/
partial def readQuoted (cs : List Char) (acc : List Char := []) : List Char × List Char :=
  match cs with
  | [] => (acc.reverse, [])
  | '\\' :: c :: rest => readQuoted rest (c :: acc)
  | '|' :: rest => (acc.reverse, rest)
  | c :: rest => readQuoted rest (c :: acc)

/-- Tokenize the body of a production. -/
partial def tokenize (cs : List Char) (acc : Array Tok) : Except String (Array Tok) :=
  match cs with
  | [] => .ok acc
  | c :: rest =>
    if c.isWhitespace || c == '^' then
      let acc := if c == '^' then acc.push .caret else acc
      match rest with
      | '.' :: d :: r =>
        if d.isDigit then
          -- a number written `.5`
          let body := r.takeWhile (fun x => isSymChar x || x == '.')
          tokenize (r.drop body.length) (acc.push (.sym (String.ofList ('0' :: '.' :: d :: body))))
        else tokenize rest acc
      | _ => tokenize rest acc
    else if c == '#' then tokenize (rest.dropWhile (· != '\n')) acc
    -- `;` separates commands (as before a `#` comment)
    else if c == ';' then tokenize rest acc
    else if c == '(' then tokenize rest (acc.push .lp)
    else if c == ')' then tokenize rest (acc.push .rp)
    else if c == '{' then tokenize rest (acc.push .lb)
    else if c == '}' then tokenize rest (acc.push .rb)
    else if c == '^' then tokenize rest (acc.push .caret)
    else if c == '.' then tokenize rest (acc.push .dot)
    else if c == ',' then tokenize rest (acc.push .comma)
    else if c == '|' then
      let (body, r) := readQuoted rest
      tokenize r (acc.push (.quoted (String.ofList body)))
    else if c == '"' then
      let body := rest.takeWhile (· != '"')
      tokenize (rest.drop (body.length + 1)) (acc.push (.str (String.ofList body)))
    else if c == '-' && rest.take 2 == ['-', '>'] then tokenize (rest.drop 2) (acc.push .arrow)
    else if c == '<' then
      match rest with
      | '=' :: '>' :: r => tokenize r (acc.push (.op "<=>"))
      | '>' :: r => tokenize r (acc.push (.op "<>"))
      | '=' :: r => tokenize r (acc.push (.op "<="))
      | '<' :: r => tokenize r (acc.push (.op "<<"))
      | _ =>
        let body := rest.takeWhile (fun x => x != '>' && !x.isWhitespace && x != '<' && x != '(' && x != ')')
        if !body.isEmpty && (rest.drop body.length).head? == some '>' then
          tokenize (rest.drop (body.length + 1)) (acc.push (.var (String.ofList body)))
        else tokenize rest (acc.push (.op "<"))
    else if c == '>' then
      match rest with
      | '=' :: r => tokenize r (acc.push (.op ">="))
      | '>' :: r => tokenize r (acc.push (.op ">>"))
      | _ => tokenize rest (acc.push (.op ">"))
    else if c == '=' then tokenize rest (acc.push (.op "="))
    else if c == '~' then tokenize rest (acc.push (.op "~"))
    else if c == '@' then
      match rest with
      | '+' :: r => if (r.head?.map isSymChar).getD false then tokenize rest (acc.push (.op "@")) else tokenize r (acc.push (.op "@+"))
      | '-' :: r => if (r.head?.map isSymChar).getD false then tokenize rest (acc.push (.op "@")) else tokenize r (acc.push (.op "@-"))
      | _ => tokenize rest (acc.push (.op "@"))
    else if c == '!' && rest.head? == some '@' then tokenize (rest.drop 1) (acc.push (.op "!@"))
    else if (c == '-' || c == '+') && (rest.head?.map Char.isDigit).getD false then
      let body := rest.takeWhile (fun x => isSymChar x || x == '.')
      tokenize (rest.drop body.length) (acc.push (.sym (String.ofList (c :: body))))
    else if c == '-' && rest.head? == some '-' then
      -- a symbolic constant made of dashes, such as `----`
      let body := rest.takeWhile isSymChar
      tokenize (rest.drop body.length) (acc.push (.sym (String.ofList (c :: body))))
    else if c == '-' || c == '+' || c == '!' then tokenize rest (acc.push (.op (String.singleton c)))
    else if c.isDigit then
      -- a number, as Soar 9.6.5's lexer reads it (`lex_digit`, `read_rest_of_floating_point_number`):
      -- digits, then a decimal point with digits and an exponent, which are part of the number
      -- only when no constituent character follows (`^2.handle`, `^2.<< 2 >>.h` are paths;
      -- `0.}` is the number 0.0; `2.5.` is 2.5 and a dot)
      let body := rest.takeWhile isSymChar
      let tok := c :: body
      let after := rest.drop body.length
      let soarConstituent (x : Char) : Bool := x.isAlphanum || "$%&*+-/:<=>?_@".contains x
      if tok.all Char.isDigit && after.head? == some '.' then
        let r1 := after.drop 1
        let ds := r1.takeWhile Char.isDigit
        let r2 := r1.drop ds.length
        let (ex, r3) : List Char × List Char := match r2 with
          | e :: r => if e == 'e' || e == 'E' then
              let (sg, r') : List Char × List Char := match r with
                | s :: r'' => if s == '+' || s == '-' then ([s], r'') else ([], r)
                | [] => ([], r)
              let es := r'.takeWhile Char.isDigit
              (e :: sg ++ es, r'.drop es.length)
            else ([], r2)
          | [] => ([], r2)
        if (r3.head?.map soarConstituent).getD false then
          tokenize (after.drop 1) ((acc.push (.sym (String.ofList tok))).push .dot)
        else tokenize r3 (acc.push (.sym (String.ofList (tok ++ '.' :: ds ++ ex))))
      else tokenize after (acc.push (.sym (String.ofList tok)))
    else if isSymChar c then
      let body := rest.takeWhile isSymChar
      tokenize (rest.drop body.length) (acc.push (.sym (String.ofList (c :: body))))
    -- any other character is skipped, as Soar 9.6.5's lexer does (`Lexer::lex_unknown`)
    else tokenize rest acc

/-- The right-hand-side functions of Soar 9.6.5 that return a value and that the model
evaluates (`rhsFunctions`). -/
def valueFns : List String := (rhsFunctions.filter (·.value)).map (·.name)

/-- A constant from its written form. -/
def constOf (s : String) : Except String Sym :=
  let digits (t : String) := !t.isEmpty && t.all Char.isDigit
  if digits s then .ok (.int s.toNat!)
  else if s.startsWith "-" && digits (s.drop 1).toString then .ok (.int (-(s.drop 1).toNat!))
  else if s.startsWith "+" && digits (s.drop 1).toString then .ok (.int (s.drop 1).toNat!)
  else match parseFloat? s with
    | some f => .ok (Sym.ofFloat f)
    | none =>
      -- Soar 9.6.5 reads an unquoted letter followed by digits (the form of an identifier) as
      -- a symbolic constant in upper case (checked 2026-10-29: `k1` is `|K1|`)
      match s.toList with
      | c :: r => if c.isAlpha && !r.isEmpty && r.all Char.isDigit then .ok (.str s.toUpper) else .ok (.str s)
      | [] => .ok (.str s)
where
  /-- `[+-]digits.digits` (either side may be empty, not both). -/
  parseFloat? (s : String) : Option Float :=
    let (neg, body) := if s.startsWith "-" then (true, (s.drop 1).toString)
      else if s.startsWith "+" then (false, (s.drop 1).toString) else (false, s)
    match body.splitOn "." with
    | [a, b] =>
      if (a.all Char.isDigit) && (b.all Char.isDigit) && !(a.isEmpty && b.isEmpty) then
        let m := (a ++ b).toNat!
        let f := Float.ofScientific m true b.length
        some (if neg then -f else f)
      else none
    | _ => none

structure PState where
  toks : Array Tok
  pos : Nat := 0
  fresh : Nat := 0
  /-- Variables marked `$` in the production being parsed. -/
  lits : List String := []

abbrev P := StateT PState (Except String)

def peek : P (Option Tok) := do let s ← get; return s.toks[s.pos]?
def advance : P Unit := modify fun s => { s with pos := s.pos + 1 }
def next : P Tok := do
  match ← peek with
  | some t => advance; return t
  | none => throw "unexpected end of production"
def expect (t : Tok) : P Unit := do
  let u ← next
  if u != t then throw s!"expected {repr t}, found {repr u}"
def freshVar (pfx : String) : P String := do
  let s ← get; set { s with fresh := s.fresh + 1 }; return s!"_{pfx}{s.fresh}"

/-! ## Left-hand side -/

def relOf : String → Option RelOp
  | "<>" => some .ne | "<" => some .lt | "<=" => some .le | ">=" => some .ge
  | ">" => some .gt | "<=>" => some .sameType | _ => none

partial def parseSingle : P Term := do
  match ← next with
  | .var v => return .var v
  | .sym s => return .sym (← constOf s)
  | .quoted s => return .sym (.str s)
  | t => throw s!"expected a variable or constant, found {repr t}"

partial def parseSimple : P (List STest) := do
  match ← peek with
  | some (.op "<<") =>
    advance
    let rec loop (acc : List Sym) : P (List Sym) := do
      match ← next with
      | .op ">>" => return acc.reverse
      | .sym s => loop ((← constOf s) :: acc)
      | .quoted s => loop (.str s :: acc)
      | t => throw s!"bad disjunction element {repr t}"
    return [.disj (← loop [])]
  -- long-term-identifier tests (Soar 9.6.5 `SMEM_LINK_TEST` and relatives)
  | some (.op "@+") => advance; return [.lti true]
  | some (.op "@-") => advance; return [.lti false]
  | some (.op "@") => advance; return [.ltiRel true (← parseSingle)]
  | some (.op "!@") => advance; return [.ltiRel false (← parseSingle)]
  | some (.op "=") => advance; parseSimple
  -- `$` and `$$` mark a variable to become a constant in a chunk (Laird, 2026-10-29); they
  -- have no effect on matching. NOT IN [Man] 9.6.
  | some (.sym "$") | some (.sym "$$") =>
    advance
    let t ← parseSimple
    for st in t do
      if let .var v := st then modify fun s => { s with lits := v :: s.lits }
    return t
  | some (.op o) =>
    match relOf o with
    | some r => advance; return [.rel r (← parseSingle)]
    | none => throw s!"unexpected {o} in a test"
  | _ =>
    match ← parseSingle with
    | .var v => return [.var v]
    | .sym c => return [.const c]

/-- A test: a simple test or a conjunctive `{ … }` test. -/
partial def parseTest : P Test := do
  match ← peek with
  | some .lb =>
    advance
    let rec loop (acc : List STest) : P (List STest) := do
      match ← peek with
      | some .rb =>
        advance
        -- equality tests first, so that a relational test may refer to the element's own
        -- variable wherever it is written (as Soar does)
        let isEq (st : STest) : Bool := match st with | .var _ => true | .const _ => true | _ => false
        return acc.filter isEq ++ acc.filter (!isEq ·)
      | _ =>
        -- Soar 9.6.5 keeps one equality test in a conjunction ("Soar does not support having
        -- two equality tests in one conjunctive test!", parser.cpp `parse_test`): a later one
        -- is dropped, except that a constant replaces a variable written alone before it
        -- (`{<x> 0.}` tests 0 and leaves `<x>` unbound; checked 2026-11-03)
        let isEq (st : STest) : Bool := match st with | .var _ => true | .const _ => true | _ => false
        let acc' := (← parseSimple).foldl (fun (acc : List STest) st =>
          if !isEq st || !acc.any isEq then acc ++ [st]
          else match acc, st with
            | [.var _], .const _ => [st]
            | _, _ => acc) acc
        loop acc'
    loop []
  | _ => parseSimple

def startsTest : Option Tok → Bool
  | some (.var _) | some (.sym _) | some (.quoted _) | some .lb | some (.op "<<") => true
  | some (.op o) => (relOf o).isSome || o == "=" || o == "@" || o == "@+" || o == "@-" || o == "!@"
  | _ => false

mutual
/-- One `^attr.path v₁ v₂ …` group, as a list of conditions (positive patterns, or a
negated conjunction if prefixed by `-`). -/
partial def parseAttrGroup (idTest : Test) : P (List Cond) := do
  let neg ← (do if (← peek) == some (.op "-") then advance; return true else return false)
  expect .caret
  let first ← parseTest
  let rec path (acc : List Test) : P (List Test) := do
    if (← peek) == some .dot then advance; path (acc ++ [← parseTest]) else return acc
  let attrs ← path [first]
  -- values
  -- a value may be structured, `^a (<x> ^b c …)` ([Man] §3.3.5.11): its conditions are added
  let rec vals (acc : List (Test × Bool)) (more : List Cond) : P (List (Test × Bool) × List Cond) := do
    if startsTest (← peek) then
      let t ← parseTest
      let a ← (do if (← peek) == some (.op "+") then advance; return true else return false)
      vals (acc ++ [(t, a)]) more
    else if (← peek) == some .lp then
      let (t, cs) ← parseStructValue
      vals (acc ++ [(t, false)]) (more ++ cs)
    else return (acc, more)
  let (vs, more) ← vals [] []
  let vs := if vs.isEmpty then [([], false)] else vs
  -- `^a₁.….aₙ v` is `(id ^a₁ <p₁>) (<p₁> ^a₂ <p₂>) … (<pₙ₋₁> ^aₙ v)`
  let rec links (cur : Test) (as : List Test) (acc : List Pat) : P (List Pat × Test × Test) := do
    match as with
    | [] => throw "empty attribute"
    | [a] => return (acc, cur, a)
    | a :: rest =>
      let v ← freshVar "p"
      links [.var v] rest (acc ++ [{ id := cur, attr := a, val := [.var v] }])
  let (pfx, finalId, lastAttr) ← links idTest attrs []
  let pats := vs.map fun (t, a) => ({ id := finalId, attr := lastAttr, val := t, acc := a } : Pat)
  if neg then
    let extra := more.filterMap fun c => match c with | .pos p => some p | _ => none
    let inner := more.filter fun c => match c with | .pos _ => false | _ => true
    if inner.isEmpty then return [.neg (pfx ++ pats ++ extra)]
    -- a negation inside a structured value of a negated condition: `-(<s> ^a (<x> -^b))` is
    -- `-{ (<s> ^a <x>) -(<x> ^b) }`
    let kids : NegNodes := inner.flatMap fun c => match c with
      | .pos _ => []
      | .neg ps => [(1, ps)]
      | .ncc ps ns => (1, ps) :: ns.map (2, ·)
      | .nccg ns => ns.map fun (d, ps) => (d + 1, ps)
    if kids.all (·.1 == 1) then return [.ncc (pfx ++ pats ++ extra) (kids.map (·.2))]
    return [.nccg ((0, pfx ++ pats ++ extra) :: kids)]
  else return (pfx ++ pats).map Cond.pos ++ more

/-- A structured value `(<x> ^b c …)`: its identifier test (a new variable if none is given)
and its conditions. -/
partial def parseStructValue : P (Test × List Cond) := do
  expect .lp
  -- (a new variable also when the first group is negated, `^a (-^b c)`)
  let idTest ← if (← peek) == some .caret || (← peek) == some (.op "-") then do pure [STest.var (← freshVar "sv")] else parseTest
  let rec groups (acc : List Cond) : P (List Cond) := do
    match ← peek with
    | some .rp => advance; return acc
    | _ => groups (acc ++ (← parseAttrGroup idTest))
  return (idTest, ← groups [])
end

/-- A condition in parentheses. The `state` keyword makes a `(<x> ^type state)` condition with
the goal test (`reteConds` folds it into the next condition, as Soar's `fill_in_id_tests` puts
the goal test on the first positive condition), except when every test of the condition is
negated (`(state <x> -^a)`): Soar then has no positive condition and puts the goal test into
each negation (parser.cpp `fill_in_id_tests`, lines 702-716).

SIMPLIFIED: the goal test inside such a negation is not modeled: the negation fails when <x>
has the element even when <x> is not a state, where Soar's holds. -/
partial def parseCondParen : P (List Cond) := do
  expect .lp
  let kw ← match ← peek with
    | some (.sym "state") => do advance; pure (some "state")
    | some (.sym "impasse") => do advance; pure (some "impasse")
    | _ => pure none
  let idTest ← parseTest
  let extra : List Cond := match kw with
    | some _ => [.pos { id := idTest, attr := [.const (.str "type")], val := [.const (.str "state")],
                        goal := kw == some "state" }]
    | none => []
  let extra := if kw == some "impasse" then
      extra ++ [.pos { id := idTest, attr := [.const (.str "impasse")], val := [] }] else extra
  let rec groups (acc : List Cond) : P (List Cond) := do
    match ← peek with
    | some .rp => advance; return acc
    | _ => groups (acc ++ (← parseAttrGroup idTest))
  let gs ← groups []
  -- a state or impasse test with no attribute test is an error in Soar 9.6.5 ("Expected
  -- attribute-value test after state/impasse test", parser.cpp), which stops the loading
  -- (checked 2026-11-03)
  if kw.isSome && gs.isEmpty then throw "expected an attribute-value test after the state/impasse test"
  -- (`(state <x> -^a …)` with no positive test: Soar's parser puts the goal test into each
  -- negation, `fill_in_id_tests`, and makes no positive condition, so no `^type state`
  -- condition is made)
  let allNeg := kw == some "state" && !gs.isEmpty && !gs.any (fun c => match c with | .pos _ => true | _ => false)
  return (if allNeg then [] else extra) ++ gs

mutual
partial def parseCond : P (List Cond) := do
  match ← peek with
  | some (.op "-") =>
    advance
    let inner ← parseCondPositive
    let pats := inner.filterMap fun c => match c with | .pos p => some p | _ => none
    let deep := inner.any fun c => match c with | .ncc _ _ | .nccg _ => true | _ => false
    if deep then
      -- nested more than two deep: the general form, as a preorder list of nodes
      let shift (ns : NegNodes) : NegNodes := ns.map fun (d, ps) => (d + 1, ps)
      let kids : NegNodes := inner.flatMap fun c => match c with
        | .pos _ => []
        | .neg ps => [(1, ps)]
        | .ncc ps ns => (1, ps) :: ns.map (2, ·)
        | .nccg ns => shift ns
      return [.nccg ((0, pats) :: kids)]
    let negs := inner.filterMap fun c => match c with
      | .neg ps => some ps
      | _ => none
    return [if negs.isEmpty then .neg pats else .ncc pats negs]
  | _ => parseCondPositive
partial def parseCondPositive : P (List Cond) := do
  match ← peek with
  | some .lb =>
    advance
    let rec loop (acc : List Cond) : P (List Cond) := do
      if (← peek) == some .rb then advance; return acc
      else loop (acc ++ (← parseCond))
    loop []
  | _ => parseCondParen
end

/-! ## Right-hand side -/

mutual
partial def parseRVal : P RVal := do
  match ← next with
  | .var v => return .var v
  | .sym s => return .sym (← constOf s)
  | .quoted s => return .sym (.str s)
  | .lp => parseCall
  -- a dash starts a symbol in Soar's lexer, as in an option given to `cmd` (`(cmd print <o>
  -- -d 2)`): the dashes and the word after them are one constant
  | .op "-" =>
    let rec dashes (pre : String) : P RVal := do
      match ← peek with
      | some (.op "-") => advance; dashes (pre ++ "-")
      | some (.sym s) => advance; return .sym (← constOf (pre ++ s))
      | _ => return .sym (.str pre)
    dashes "-"
  | t => throw s!"expected a right-hand-side value, found {repr t}"
partial def parseCall : P RVal := do
  let f ← match ← next with
    | .sym s => pure s
    | .op o => pure o
    | .quoted s => pure s
    | t => throw s!"expected a function name, found {repr t}"
  let rec args (acc : List RVal) : P (List RVal) := do
    if (← peek) == some .rp then advance; return acc
    else args (acc ++ [← parseRVal])
  return .call f (← args [])
end

def startsRVal : Option Tok → Bool
  | some (.var _) | some (.sym _) | some (.quoted _) | some .lp => true
  | _ => false

inductive PSpec where
  | unary (k : PrefKind)
  | binary (k : PrefKind) (v : RVal)
  | numeric (n : Sym)

partial def parsePrefs (acc : List PSpec) : P (List PSpec) := do
  match ← peek with
  | some .comma => advance; parsePrefs acc
  | some (.op o) =>
    let unaryOf : String → Option PrefKind
      | "+" => some .acceptable | "-" => some .reject | "!" => some .require
      | "~" => some .prohibit | _ => none
    match unaryOf o with
    | some k => advance; parsePrefs (acc ++ [.unary k])
    | none =>
      if o == ">" || o == "<" || o == "=" then
        advance
        if startsRVal (← peek) then
          let v ← parseRVal
          match o, v with
          | "=", .sym (.int n) => parsePrefs (acc ++ [.numeric (.int n)])
          | "=", .sym (.float b) => parsePrefs (acc ++ [.numeric (.float b)])
          | ">", _ => parsePrefs (acc ++ [.binary .better v])
          | "<", _ => parsePrefs (acc ++ [.binary .worse v])
          | _, _ => parsePrefs (acc ++ [.binary .binaryIndiff v])
        else
          let k := if o == ">" then PrefKind.best else if o == "<" then .worst else .unaryIndiff
          parsePrefs (acc ++ [.unary k])
      else return acc
  | _ => return acc

/-- One `^attr.path value prefs …` group of an action on identifier variable `id`. -/
partial def parseMakeGroup (id : String) : P (List Action) := do
  expect .caret
  let first ← parseRVal
  let rec path (acc : List RVal) : P (List RVal) := do
    if (← peek) == some .dot then advance; path (acc ++ [← parseRVal]) else return acc
  let attrs ← path [first]
  -- intermediate new objects for a path
  let rec chain (cur : String) (as : List RVal) (acc : List Action) : P (String × List Action) := do
    match as with
    | [] | [_] => return (cur, acc)
    | a :: rest =>
      let v ← freshVar "r"
      -- `^operator.name x` proposes the new operator (an acceptable preference)
      let act := match a with
        | .sym (.str "operator") => Action.pref cur (.var v) .acceptable none none
        | _ => .make cur a (.var v)
      chain v rest (acc ++ [act])
  let (target, pre) ← chain id attrs []
  let attr := attrs.getLast!
  let isOp := match attr with | .sym (.str "operator") => true | _ => false
  let rec vals (acc : List Action) : P (List Action) := do
    if startsRVal (← peek) then
      let v ← parseRVal
      let ps ← parsePrefs []
      let acts : List Action ←
        if isOp then
          let ps := if ps.isEmpty then [PSpec.unary .acceptable] else ps
          pure (ps.map fun p => match p with
            | .unary k => Action.pref target v k none none
            | .binary k o => Action.pref target v k (some o) none
            | .numeric n => Action.pref target v .numericIndiff none (some n))
        else
          -- Soar 9.6.5 allows only acceptable and reject preferences on attributes other than
          -- ^operator: other unary preferences are ignored with a warning ("The only allowable
          -- non-operator preference is REJECT"), leaving an acceptable preference if nothing
          -- else remains, and a binary preference is an error (checked 2026-10-30)
          if ps.any (fun p => match p with | .unary _ => false | _ => true) then
            throw "binary preference illegal for non-operator"
          let ks := ps.filterMap fun p => match p with
            | .unary k => if k == .acceptable || k == .reject then some k else none
            | _ => none
          let ks := if ks.isEmpty then [PrefKind.acceptable] else ks
          pure (ks.eraseDups.map fun k => if k == .reject then Action.remove target attr v else Action.make target attr v)
      vals (acc ++ acts)
    else return acc
  return pre ++ (← vals [])

partial def parseAction : P (List Action) := do
  expect .lp
  match ← peek with
  | some (.var id) =>
    advance
    let rec groups (acc : List Action) : P (List Action) := do
      match ← peek with
      | some .rp => advance; return acc
      | _ => groups (acc ++ (← parseMakeGroup id))
    groups []
  | some (.sym "cmd") =>
    advance
    let rec words (acc : List String) (fuel : Nat) : P (List String) := do
      match fuel with
      | 0 => throw "unterminated (cmd …)"
      | f + 1 =>
        match ← next with
        | .rp => return acc
        | .sym w => words (acc ++ [w]) f
        | .quoted w => words (acc ++ [w]) f
        | .var v => words (acc ++ [s!"<{v}>"]) f
        | _ => words acc f
    return [.cmd (← words [] 1000)]
  | _ =>
    match ← parseCall with
    | .call "halt" [] => return [.halt]
    -- `interrupt` stops the run at the end of the current phase
    | .call "interrupt" [] => return [.cmd ["interrupt"]]
    | .call "write" args => return [.write args]
    | .call "crlf" [] => return [.write [.call "crlf" []]]
    -- chunking control ([Man] §3.3.6.7): the state is recorded by the decision cycle
    | .call "force-learn" [.var v] => return [.cmd ["force-learn", s!"<{v}>"]]
    | .call "link-stm-to-ltm" [.var v, .sym (.int k)] => return [.cmd ["link-stm-to-ltm", s!"<{v}>", toString k]]
    | .call "dont-learn" [.var v] => return [.cmd ["dont-learn", s!"<{v}>"]]
    -- functions of Soar's unit-test harness: outside the harness Soar 9.6.5 replaces them by
    -- `halt` ("Replacing function named succeeded with halt since this is a unit test but
    -- running in a non-unit testing environment"; checked 2026-10-29)
    | .call "succeeded" _ | .call "failed" _ | .call "success" _ => return [.halt]
    -- functions called for their side effects on the trace, the statistics or the clock
    -- (`log`, `trace`, `count`, `wait`) change nothing the model represents; a function that
    -- returns a value, called as an action, has its value discarded
    | .call f _ =>
      -- `exec` calls a function the host program registers (`AddRhsFunction`); with none
      -- registered Soar 9.6.5 loads the rule and the call does nothing to working memory
      -- NOT MODELED: host-registered functions
      if ["log", "trace", "count", "wait", "exec"].contains f || valueFns.contains f then return [.cmd []]
      else throw s!"right-hand-side function '{f}' is not supported as an action"
    | _ => throw "bad action"

/-! ## Productions and files -/

partial def parseProduction (name : String) : P Production := do
  -- documentation string and flags
  let rec skipHeader (sup : Option Bool) (tmpl : Bool) : P (Option Bool × Bool) := do
    match ← peek with
    | some (.str _) => advance; skipHeader sup tmpl
    | some (.sym s) =>
      if s == ":o-support" then advance; skipHeader (some true) tmpl
      else if s == ":i-support" then advance; skipHeader (some false) tmpl
      else if s == ":template" then advance; skipHeader sup true
      else if s.startsWith ":" then advance; skipHeader sup tmpl else return (sup, tmpl)
    | _ => return (sup, tmpl)
  let (sup, tmpl) ← skipHeader none false
  let rec conds (acc : List Cond) : P (List Cond) := do
    if (← peek) == some .arrow then advance; return acc
    else conds (acc ++ (← parseCond))
  let cs ← conds []
  let rec acts (acc : List Action) : P (List Action) := do
    match ← peek with
    | none => return acc
    | some .rb => return acc
    | _ => acts (acc ++ (← parseAction))
  let as ← acts []
  -- Soar 9.6.5 (`rl_valid_template`): a template has one action, a numeric-indifferent
  -- preference or a binary-indifferent one whose referent is a variable
  if tmpl then
    let ok := match as with
      | [.pref _ _ .numericIndiff _ (some _)] => true
      | [.pref _ _ .binaryIndiff (some (.var _)) _] => true
      | _ => false
    if !ok then throw "invalid Soar-RL template"
  return { name := name, conds := cs, acts := as, lits := (← get).lits.eraseDups, support := sup, template := tmpl }

/-- Read up to the brace that closes a block whose opening brace has been read: the text before it
(comments removed; `|…|` with its escapes and `"…"` kept verbatim, so braces in them do not
count) and the text after it. Used for `sp {…}` and for the blocks of `smem --add`,
`--remove` and `--query`. -/
partial def braceScan (xs : List Char) (depth : Nat) (out : List Char) : List Char × List Char :=
  match xs with
  | [] => (out.reverse, [])
  | '|' :: r =>
    -- keep the quoted text verbatim, escapes included
    let rec q (xs : List Char) (o : List Char) : List Char × List Char :=
      match xs with
      | [] => (o, [])
      | '\\' :: c :: t => q t (c :: '\\' :: o)
      | '|' :: t => ('|' :: o, t)
      | c :: t => q t (c :: o)
    let (o', r') := q r ('|' :: out)
    braceScan r' depth o'
  | '"' :: r =>
    let q := r.takeWhile (· != '"')
    braceScan (r.drop (q.length + 1)) depth ('"' :: (q.reverse ++ ('"' :: out)))
  | '#' :: r => braceScan (r.dropWhile (· != '\n')) depth out
  | '{' :: r => braceScan r (depth + 1) ('{' :: out)
  | '}' :: r => if depth == 0 then (out.reverse, r) else braceScan r (depth - 1) ('}' :: out)
  | x :: r => braceScan r depth (x :: out)

/-- The bodies of all `sp {…}` blocks in a file, with comments removed. -/
partial def spBlocks (cs : List Char) (acc : Array (List Char)) : Array (List Char) :=
  match cs with
  | [] => acc
  | '#' :: rest => spBlocks (rest.dropWhile (· != '\n')) acc
  | 's' :: 'p' :: c :: rest =>
    if c.isWhitespace || c == '{' then
      let rest := (c :: rest).dropWhile (fun x => x.isWhitespace)
      match rest with
      | '{' :: body =>
        let (b, r) := braceScan body 0 []
        spBlocks r (acc.push b)
      | '"' :: body =>
        -- `sp "…"`: the body runs to the next `"` outside `|…|`
        let rec dq (xs : List Char) (inBar : Bool) (out : List Char) : List Char × List Char :=
          match xs with
          | [] => (out.reverse, [])
          | '\\' :: c :: r => dq r inBar (c :: '\\' :: out)
          | '|' :: r => dq r (!inBar) ('|' :: out)
          | '"' :: r => if inBar then dq r inBar ('"' :: out) else (out.reverse, r)
          | x :: r => dq r inBar (x :: out)
        let (b, r) := dq body false []
        spBlocks r (acc.push b)
      | _ => spBlocks rest acc
    else spBlocks (c :: rest) acc
  | _ :: rest => spBlocks rest acc

/-! ## `gp`: productions generated from value lists -/

/-- The body of a `gp {…}` block: the text with comments removed, and its parts — literal text,
and bracket lists of values. Soar 9.6.5 (`gp`): values are separated by white space, a `|…|`
constant is a value of its own even when not separated, `\ ` is a space inside a value, and
`#` starts a comment outside `|…|`. -/
inductive GpPart where
  | lit : String → GpPart
  | list : List String → GpPart

partial def gpParts (cs : List Char) : Except String (List GpPart) := do
  -- strip comments
  let rec strip (xs : List Char) (inP : Bool) (out : List Char) : List Char :=
    match xs with
    | [] => out.reverse
    | '\\' :: c :: t => strip t inP (c :: '\\' :: out)
    | '|' :: t => strip t (!inP) ('|' :: out)
    | '#' :: t => if inP then strip t inP ('#' :: out) else strip (t.dropWhile (· != '\n')) inP out
    | c :: t => strip t inP (c :: out)
  let cs := strip cs false []
  let rec go (xs : List Char) (inP : Bool) (lit : List Char) (acc : List GpPart) : Except String (List GpPart) :=
    match xs with
    | [] => .ok (acc ++ [.lit (String.ofList lit.reverse)])
    | '\\' :: c :: t => go t inP (c :: '\\' :: lit) acc
    | '|' :: t => go t (!inP) ('|' :: lit) acc
    | '[' :: t =>
      if inP then go t inP ('[' :: lit) acc else
      -- a value list up to the matching `]`
      let rec vals (ys : List Char) (inQ : Bool) (cur : List Char) (closedPipe : Bool) (vs : List String) :
          Except String (List String × List Char) :=
        let push (cur : List Char) (vs : List String) : List String :=
          if cur.isEmpty then vs else vs ++ [String.ofList cur.reverse]
        match ys with
        | [] => .error "unmatched [ in gp"
        | '\\' :: ' ' :: r => vals r inQ (if inQ then ' ' :: '\\' :: cur else ' ' :: cur) false vs
        | '\\' :: c :: r => vals r inQ (c :: '\\' :: cur) false vs
        | '|' :: r =>
          if inQ then vals r false ('|' :: cur) true vs
          else if closedPipe then vals r true ['|'] false (push cur vs)
          else vals r true ('|' :: cur) false vs
        | ']' :: r => if inQ then vals r inQ (']' :: cur) false vs else .ok (push cur vs, r)
        | c :: r =>
          if !inQ && c.isWhitespace then vals r inQ [] false (push cur vs)
          else vals r inQ (c :: cur) false vs
      match vals t false [] false [] with
      | .error e => .error e
      | .ok (vs, rest) =>
        if vs.isEmpty then .error "a gp value list needs at least one value" else
        go rest false [] (acc ++ [.lit (String.ofList lit.reverse), .list vs])
    | c :: t => go t inP (c :: lit) acc
  go cs false [] []

/-- Expand every `gp {name …}` in a source text into `sp {name*k …}` productions, one for each
combination of values, the first list varying fastest (as Soar 9.6.5 numbers them). -/
partial def expandGp (src : String) : Except String String := do
  let cs := src.toList
  let rec find (xs : List Char) (out : List Char) (atStart : Bool) : Except String (List Char) := do
    match xs with
    | [] => return out.reverse
    | 'g' :: 'p' :: c :: rest =>
      if atStart && (c.isWhitespace || c == '{') then
        let rest := (c :: rest).dropWhile Char.isWhitespace
        match rest with
        | '{' :: body =>
          -- the matching brace, skipping |…| and comments
          let rec scan (ys : List Char) (d : Nat) (inP : Bool) (o : List Char) : Option (List Char × List Char) :=
            match ys with
            | [] => none
            | '\\' :: c :: t => scan t d inP (c :: '\\' :: o)
            | '|' :: t => scan t d (!inP) ('|' :: o)
            | '#' :: t => if inP then scan t d inP ('#' :: o) else
                let cm := t.takeWhile (· != '\n'); scan (t.drop cm.length) d inP (cm.reverse ++ '#' :: o)
            | '{' :: t => if inP then scan t d inP ('{' :: o) else scan t (d + 1) inP ('{' :: o)
            | '}' :: t => if inP then scan t d inP ('}' :: o) else
                if d == 0 then some (o.reverse, t) else scan t (d - 1) inP ('}' :: o)
            | c :: t => scan t d inP (c :: o)
          match scan body 0 false [] with
          | none => throw "unterminated gp"
          | some (b, after) =>
            let b := b.dropWhile Char.isWhitespace
            let name := b.takeWhile (fun c => !c.isWhitespace)
            let parts ← gpParts (b.drop name.length)
            let lists := parts.filterMap fun p => match p with | .list vs => some vs | _ => none
            let total := lists.foldl (fun a l => a * l.length) 1
            let combo (k : Nat) : String := Id.run do
              let mut k := k
              let mut out := ""
              for p in parts do
                match p with
                | .lit t => out := out ++ t
                | .list vs => out := out ++ vs[k % vs.length]!; k := k / vs.length
              return out
            let rules := (List.range total).map fun k =>
              "sp {" ++ String.ofList name ++ "*" ++ toString (k + 1) ++ combo k ++ "}\n"
            find after ((String.join rules).toList.reverse ++ out) false
        | _ => find rest (c :: 'p' :: 'g' :: out) false
      else find (c :: rest) ('p' :: 'g' :: out) false
    | c :: rest => find rest (c :: out) (c == '\n' || (atStart && c.isWhitespace))
  return String.ofList (← find cs [] true)

/-- Parse every production in Soar source text. -/
def parseFile (src : String) : Except String (List Production) := do
  let src ← expandGp src
  let blocks := spBlocks src.toList #[]
  let mut out := #[]
  for b in blocks do
    -- the production name is the first whitespace-delimited word
    let b := b.dropWhile Char.isWhitespace
    let nameChars := b.takeWhile (fun c => !c.isWhitespace)
    let name := String.ofList nameChars
    let toks ← tokenize (b.drop nameChars.length) #[]
    match (parseProduction name).run { toks := toks } with
    | .ok (p, st) =>
      if st.pos < st.toks.size then
        throw s!"in {p.name}: unexpected {repr st.toks[st.pos]!}"
      -- Soar replaces a production of the same name, and ignores one identical to an existing
      -- production ("Ignoring … because it is a duplicate of …"). With RL's chunk-stop on (the
      -- default), two rules whose only action is a numeric-indifferent preference are the same
      -- whatever its value (Soar 9.6.5 `same_rhs`; checked 2026-10-30).
      let acts (q : Production) : List Action :=
        match q.acts with
          | [.pref t v .numericIndiff none (some _)] => [Action.pref t v .numericIndiff none none]
          | as => as
      let out' := out.filter (·.name != p.name)
      if out'.any (fun q => q.conds == p.conds && acts q == acts p) then out := out'
      else out := out'.push p
    | .error e => throw s!"in production {name}: {e}"
  return out.toList


/-! ## Semantic-memory directives (`smem --enable`, `smem --add {…}`) -/

/-- One `smem --add` clause. -/
partial def parseAddClause : P AddClause := do
  expect .lp
  let refOf : P AddRef := do
    match ← next with
    | .var v => return .var v
    | .op "@" => match ← next with
      | .sym n => return if !n.isEmpty && n.all Char.isDigit then .lti n.toNat! else .alias n
      | t => throw s!"bad LTI reference {repr t}"
    | .sym s =>
      if s.startsWith "@" then return .lti (s.drop 1).toNat! else
      -- a value of the form of an identifier (`t10`) is a symbolic constant as written: Soar
      -- 9.6.5's `smem --add` makes it from the lexeme's string (`parse_new_ltm`,
      -- `IDENTIFIER_LEXEME`), not upper-cased as in a rule (`constOf`)
      match s.toList with
      | c :: r => if c.isAlpha && !r.isEmpty && r.all Char.isDigit then return .const (.str s) else return .const (← constOf s)
      | [] => return .const (← constOf s)
    | .quoted s => return .const (.str s)
    | t => throw s!"bad value {repr t}"
  let idr ← refOf
  let rec augs (acc : List (AddRef × Sym × AddRef)) (k : Nat) : P (List (AddRef × Sym × AddRef)) := do
    match ← peek with
    | some .rp =>
      advance
      -- Soar 9.6.5 keeps reading attributes after a clause's closing parenthesis if one follows
      if (← peek) == some .caret then augs acc k else return acc
    | some .caret =>
      advance
      let attrOf : P Sym := do
        match ← next with
        | .sym s => constOf s
        | .quoted s => return .str s
        | t => throw s!"bad attribute {repr t}"
      let a ← attrOf
      -- dot paths
      let rec dots (par : AddRef) (a : Sym) (acc : List (AddRef × Sym × AddRef)) (k : Nat) :
          P (AddRef × Sym × List (AddRef × Sym × AddRef) × Nat) := do
        if (← peek) == some .dot then
          advance
          let a' ← attrOf
          -- each step of a dot path is a new identifier (unique within the command)
          let pos := (← get).pos
          let mid := AddRef.var s!"<{a.toSoar.take 1}#{k + 1}.{pos}>"
          dots mid a' (acc ++ [(par, a, mid)]) (k + 1)
        else return (par, a, acc, k)
      let (par, a, acc, k) ← dots idr a acc k
      let rec vals (acc : List (AddRef × Sym × AddRef)) : P (List (AddRef × Sym × AddRef)) := do
        match ← peek with
        | some .caret | some .rp => return acc
        | some .lp => -- an edge weight, ignored
          advance; let _ ← next; expect .rp; vals acc
        | _ => let v ← refOf; vals (acc ++ [(par, a, v)])
      let acc ← vals acc
      augs acc k
    | t => throw s!"bad smem --add clause at {repr t}"
  return { id := idr, augs := ← augs [] 1 }

-- like Soar's `CLI_add`, parsing stops at the first token that does not open a clause
partial def addClauses (acc : List AddClause) : P (List AddClause) := do
  match ← peek with
  | some .lp => addClauses (acc ++ [← parseAddClause])
  | _ => return acc

/-- A value in an `smem --remove` or `smem --query` clause. -/
def cliVal : P CliVal := do
  match ← next with
  | .var _ => return .any
  | .op "@" => match ← next with
    | .sym n => return if !n.isEmpty && n.all Char.isDigit then .lti n.toNat! else .alias n
    | t => throw s!"bad LTI reference {repr t}"
  | .sym s =>
    if s.startsWith "@" then
      let n := (s.drop 1).toString
      return if !n.isEmpty && n.all Char.isDigit then .lti n.toNat! else .alias n
    else return .const (← constOf s)
  | .quoted s => return .const (.str s)
  | t => throw s!"bad value {repr t}"

def cliAttr : P Sym := do
  match ← next with
  | .sym s => constOf s
  | .quoted s => return .str s
  | t => throw s!"bad attribute {repr t}"

/-- `(@n ^a v … ^b …)` of `smem --remove`. -/
partial def removeClause : P (CliVal × List (Sym × List CliVal)) := do
  if (← peek) == some .lp then advance
  let r ← cliVal
  let rec attrs (acc : List (Sym × List CliVal)) : P (List (Sym × List CliVal)) := do
    match ← peek with
    | some .caret =>
      advance
      let a ← cliAttr
      let rec vals (vs : List CliVal) : P (List CliVal) := do
        match ← peek with
        | some .caret | some .rp | none => return vs
        | _ => vals (vs ++ [← cliVal])
      attrs (acc ++ [(a, ← vals [])])
    | _ => return acc
  let as ← attrs []
  expect .rp
  return (r, as)

/-- `(<c> ^a v … -^b w …) (<c> …)` of `smem --query`. -/
partial def queryClauses (acc : List (Sym × CliVal × Bool)) : P (List (Sym × CliVal × Bool)) := do
  match ← peek with
  | some .lp =>
    advance
    let _ ← next
    let rec items (acc : List (Sym × CliVal × Bool)) : P (List (Sym × CliVal × Bool)) := do
      match ← peek with
      | some (.op "-") =>
        advance; expect .caret
        let a ← cliAttr
        items (acc ++ [(a, ← cliVal, false)])
      | some .caret =>
        advance
        let a ← cliAttr
        let rec vals (acc : List (Sym × CliVal × Bool)) : P (List (Sym × CliVal × Bool)) := do
          match ← peek with
          | some .caret | some .rp | some (.op "-") | none => return acc
          | _ => vals (acc ++ [(a, ← cliVal, true)])
        items (← vals acc)
      | _ => return acc
    let els ← items acc
    expect .rp
    queryClauses els
  | _ => return acc

/-- Settings from the semantic-memory commands in a source file: whether it is enabled, and
its `smem --add`, `smem --remove` and `smem --query` commands, in order. -/
structure SMemConfig where
  enabled : Bool := false
  /-- The command-line operations on the store (variables are local to a command). -/
  ops : List SMemOp := []
  activateOnQuery : Bool := true
  frequency : Bool := false
  baseLevel : Bool := false
  baseDecay : Float := 0.5
  baseUpdate : BaseUpdate := .stable
  baseThreshes : List Nat := [10]
  baseOffset : Nat := 0
  baseInhibition : Bool := false
  thresh : Nat := 100
  activateOnAdd : Bool := false
  spreading : Bool := false
  spBaseline : Float := 0.0001
  spContinue : Float := 0.9
  spLimit : Nat := 300
  spDepth : Nat := 10
  spLoop : Bool := false
  spWmaSource : Bool := false
  spEdgeUpd : Bool := false
  spEdgeFactor : Float := 0.99
  /-- `database` (`memory` or `file`), `path` and `append` (default on): where the store is kept
  between agents. -/
  database : String := "memory"
  path : String := ""
  append : Bool := true

partial def smemConfig (src : String) : Except String SMemConfig := do
  let lines := src.splitOn "\n"
  let rec go (ls : List String) (cfg : SMemConfig) : Except String SMemConfig := do
    match ls with
    | [] => return cfg
    | l :: rest =>
      let w := (((l.splitOn "#").head!).trimAscii.toString.splitOn " ").filter (· != "")
      let protectedSet : Bool := match w with
        | "smem" :: "--set" :: k :: _ :: _ =>
          (cfg.spreading && ["spreading-loop-avoidance", "spreading-wma-source", "spreading-limit", "spreading-depth-limit",
            "spreading-baseline", "spreading-continue-probability"].contains k) ||
          (!cfg.ops.isEmpty && (k == "spreading-limit" || k == "spreading-depth-limit"))
        | _ => false
      if protectedSet then go rest cfg else
      match w with
      | "smem" :: "--enable" :: _ | "smem" :: "-e" :: _ | "smem" :: "--on" :: _ =>
        go rest { cfg with enabled := true }
      | "smem" :: "--set" :: "learning" :: "on" :: _ | "smem" :: "--set" :: "enabled" :: "on" :: _ =>
        go rest { cfg with enabled := true }
      | "smem" :: "--set" :: "database" :: v :: _ =>
        go rest (if v == "file" || v == "memory" then { cfg with database := v } else cfg)
      | "smem" :: "--set" :: "path" :: v :: _ => go rest { cfg with path := v }
      | "smem" :: "--set" :: "append" :: v :: _ => go rest { cfg with append := v == "on" }
      | "smem" :: "--set" :: "activate-on-query" :: v :: _ =>
        go rest { cfg with activateOnQuery := v == "on" }
      -- as in Soar 9.6.5: the activation mode cannot change while spreading is on, spreading
      -- needs base-level activation, and the spreading parameters other than edge updating
      -- cannot change once spreading is on (depth and limit not once the store is open)
      | "smem" :: "--set" :: "activation-mode" :: v :: _ =>
        if cfg.spreading then go rest cfg else
        go rest { cfg with frequency := v == "frequency", baseLevel := v == "base-level" }
      | "smem" :: "--set" :: "base-decay" :: v :: _ =>
        go rest (match (Parse.constOf v).toOption.bind Sym.num? with
          | some d => if d > 0 then { cfg with baseDecay := d } else cfg | none => cfg)
      | "smem" :: "--set" :: "base-update-policy" :: v :: _ =>
        go rest { cfg with baseUpdate := if v == "naive" then .naive else if v == "incremental" then .incremental
          else if v == "stable" then .stable else cfg.baseUpdate }
      | "smem" :: "--set" :: "base-incremental-threshes" :: v :: _ =>
        -- Soar 9.6.5 reads one integer (the leading digits) and adds it to the set, or removes
        -- it if it is already there (primitive_set_param::set_string); the default is {10}
        let d := String.ofList (v.toList.takeWhile Char.isDigit)
        go rest (match d.toNat? with
          | some k => { cfg with baseThreshes :=
              if cfg.baseThreshes.contains k then cfg.baseThreshes.erase k
              else ((cfg.baseThreshes ++ [k]).toArray.qsort (· < ·)).toList }
          | none => cfg)
      | "smem" :: "--set" :: "base-unused-age-offset" :: v :: _ =>
        go rest { cfg with baseOffset := v.toNat?.getD cfg.baseOffset }
      | "smem" :: "--set" :: "base-inhibition" :: v :: _ =>
        go rest { cfg with baseInhibition := v == "on" }
      | "smem" :: "--set" :: "thresh" :: v :: _ =>
        go rest { cfg with thresh := v.toNat?.getD cfg.thresh }
      | "smem" :: "--set" :: "activate-on-add" :: v :: _ =>
        go rest { cfg with activateOnAdd := v == "on" }
      | "smem" :: "--set" :: "spreading" :: v :: _ =>
        go rest (if v == "on" then (if cfg.baseLevel then { cfg with spreading := true } else cfg) else { cfg with spreading := false })
      | "smem" :: "--set" :: "spreading-loop-avoidance" :: v :: _ => go rest { cfg with spLoop := v == "on" }
      | "smem" :: "--set" :: "spreading-wma-source" :: v :: _ => go rest { cfg with spWmaSource := v == "on" }
      | "smem" :: "--set" :: "spreading-edge-updating" :: v :: _ => go rest { cfg with spEdgeUpd := v == "on" }
      | "smem" :: "--set" :: "spreading-limit" :: v :: _ => go rest { cfg with spLimit := v.toNat?.getD cfg.spLimit }
      | "smem" :: "--set" :: "spreading-depth-limit" :: v :: _ => go rest { cfg with spDepth := v.toNat?.getD cfg.spDepth }
      | "smem" :: "--set" :: "spreading-baseline" :: v :: _ =>
        go rest (match (Parse.constOf v).toOption.bind Sym.num? with | some x => if x > 0 then { cfg with spBaseline := x } else cfg | none => cfg)
      | "smem" :: "--set" :: "spreading-continue-probability" :: v :: _ =>
        go rest (match (Parse.constOf v).toOption.bind Sym.num? with | some x => if x > 0 then { cfg with spContinue := x } else cfg | none => cfg)
      | "smem" :: "--set" :: "spreading-edge-update-factor" :: v :: _ =>
        go rest (match (Parse.constOf v).toOption.bind Sym.num? with | some x => if x > 0 then { cfg with spEdgeFactor := x } else cfg | none => cfg)
      | "smem" :: "--add" :: _ | "smem" :: "-a" :: _ =>
        -- the block runs to the matching brace
        let text := "\n".intercalate (l :: rest)
        let cs := (text.toList.dropWhile (· != '{')).drop 1
        let (body, after) := braceScan cs 0 []
        let toks ← tokenize body #[]
        match (addClauses []).run { toks := toks } with
        | .ok (cls, _) => go ((String.ofList after).splitOn "\n") { cfg with ops := cfg.ops ++ [.add cls] }
        | .error e => throw s!"in smem --add: {e}"
      | ["smem", "--clear"] =>
        -- only an open store is cleared; the store is open after an --add, --remove or --query
        go rest (if cfg.ops.any (fun o => match o with | .add _ | .remove _ _ | .query _ => true | _ => false)
          then { cfg with ops := cfg.ops ++ [.clear] } else cfg)
      | ["smem", "--backup", f] =>
        go rest (if cfg.ops.any (fun o => match o with | .add _ | .remove _ _ | .query _ => true | _ => false)
          then { cfg with ops := cfg.ops ++ [.backup f] } else cfg)
      | ["smem", "--init"] => go rest { cfg with ops := cfg.ops ++ [.init] }
      | "smem" :: "--remove" :: _ | "smem" :: "-r" :: _ | "smem" :: "--query" :: _ | "smem" :: "-q" :: _ =>
        let isRemove := w[1]! == "--remove" || w[1]! == "-r"
        let text := "\n".intercalate (l :: rest)
        let cs := (text.toList.dropWhile (· != '{')).drop 1
        let (body, after) := braceScan cs 0 []
        let toks ← tokenize body #[]
        if isRemove then
          match removeClause.run { toks := toks } with
          | .ok ((r, as), _) => go ((String.ofList after).splitOn "\n") { cfg with ops := cfg.ops ++ [.remove r as] }
          | .error e => throw s!"in smem --remove: {e}"
        else
          match (queryClauses []).run { toks := toks } with
          | .ok (els, _) => go ((String.ofList after).splitOn "\n") { cfg with ops := cfg.ops ++ [.query els] }
          | .error e => throw s!"in smem --query: {e}"
      | _ => go rest cfg
  go lines {}

/-- Working-memory activation settings from `wma` commands in a source file, in order: as in
Soar 9.6.5, the other settings cannot be changed while activation is on (`wma_activation_predicate`),
and `decay-rate` (between 0 and 1) and `decay-thresh` (above 0) are stored negated. -/
def wmaConfig (src : String) : WmaParams :=
  (src.splitOn "\n").foldl (fun p l =>
    let num (v : String) : Option Float := (Parse.constOf v).toOption.bind Sym.num?
    match (((l.splitOn "#").head!).trimAscii.toString.splitOn " ").filter (· != "") with
    | "wma" :: "--set" :: "activation" :: v :: _ => { p with on := v == "on" }
    | "wma" :: "--on" :: _ | "wma" :: "-e" :: _ | "wma" :: "--enable" :: _ => { p with on := true }
    | "wma" :: "--off" :: _ | "wma" :: "-d" :: _ | "wma" :: "--disable" :: _ => { p with on := false }
    | "wma" :: "--set" :: k :: v :: _ =>
      if p.on then p else
      match k with
      | "decay-rate" => match num v with
        | some x => if 0 ≤ x && x ≤ 1 then { p with decay := -x } else p
        | none => p
      | "decay-thresh" => match num v with
        | some x => if x > 0 then { p with thresh := -x } else p
        | none => p
      | "petrov-approx" => { p with petrov := v == "on" }
      | "forgetting" => match v with
        | "off" => { p with forgetting := .off } | "naive" => { p with forgetting := .naive }
        | "bsearch" => { p with forgetting := .bsearch } | "on" => { p with forgetting := .approx }
        | _ => p
      | "forget-wme" => if v == "lti" then { p with forgetLti := true } else if v == "all" then { p with forgetLti := false } else p
      | "fake-forgetting" => { p with fake := v == "on" }
      | _ => p
    | _ => p) {}

/-- Episodic-memory settings from `epmem` commands in a source file. -/
structure EpConfig where
  enabled : Bool := false
  trigger : EpTrigger := .dc
  graphMatch : Bool := true
  gmOrder : String := "undefined"
  phaseSel : Bool := false
  /-- `epmem --set exclusions X` adds X, or removes it if present. -/
  exclusions : List Sym := [.str "epmem", .str "smem"]
  balance : Float := 1
  /-- `database` (`memory` or `file`), `path` and `append` (default off). -/
  database : String := "memory"
  path : String := ""
  append : Bool := false

def epConfig (src : String) : EpConfig :=
  (src.splitOn "\n").foldl (fun cfg l =>
    match (((l.splitOn "#").head!).trimAscii.toString.splitOn " ").filter (· != "") with
    | "epmem" :: "--enable" :: _ | "epmem" :: "-e" :: _ | "epmem" :: "--on" :: _ => { cfg with enabled := true }
    | "epmem" :: "--set" :: "learning" :: v :: _ => { cfg with enabled := v == "on" }
    | "epmem" :: "--set" :: "trigger" :: v :: _ =>
      { cfg with trigger := if v == "output" then .output else if v == "none" then .none else .dc }
    | "epmem" :: "--set" :: "graph-match" :: v :: _ => { cfg with graphMatch := v == "on" }
    | "epmem" :: "--set" :: "graph-match-ordering" :: v :: _ => { cfg with gmOrder := v }
    | "epmem" :: "--set" :: "phase" :: v :: _ => { cfg with phaseSel := v == "selection" }
    | "epmem" :: "--set" :: "balance" :: v :: _ =>
      match (Parse.constOf v).toOption.bind Sym.num? with
      | some x => if 0 ≤ x && x ≤ 1 then { cfg with balance := x } else cfg
      | none => cfg
    | "epmem" :: "--set" :: "database" :: v :: _ =>
      if v == "file" || v == "memory" then { cfg with database := v } else cfg
    | "epmem" :: "--set" :: "path" :: v :: _ => { cfg with path := v }
    | "epmem" :: "--set" :: "append" :: v :: _ => { cfg with append := v == "on" }
    | "epmem" :: "--set" :: "exclusions" :: v :: _ =>
      let x : Sym := .str v
      { cfg with exclusions := if cfg.exclusions.contains x then cfg.exclusions.erase x else cfg.exclusions ++ [x] }
    | _ => cfg) {}

/-- `multi-attributes <attribute> [n]` declarations (alias of `production
optimize-attribute`, [Man] §9.2.3.8: "If n is not specified, the value 10 is used"). -/
def multiAttributes (src : String) : List (String × Nat) :=
  (src.splitOn "\n").foldl (fun (acc : List (String × Nat)) l =>
    match (((l.splitOn "#").head!).trimAscii.toString.splitOn " ").filter (· != "") with
    | ["multi-attributes", a] | ["production", "optimize-attribute", a] => (a, 10) :: acc.filter (·.1 != a)
    | ["multi-attributes", a, n] | ["production", "optimize-attribute", a, n] => (a, n.toNat!) :: acc.filter (·.1 != a)
    | _ => acc) []

/-- Soar 9.6.5's predefined symbols, in the order the kernel makes them
(`create_predefined_symbols`; `@`, `command`, `result` and others recur and keep their first
number). -/
def predefinedSyms : List String :=
  ["\n"] ++
  ("@ problem-space state operator superstate io object attribute impasse choices none " ++
   "constraint-failure no-change multiple item-count non-numeric-count constant conflict tie " ++
   "item non-numeric quiescence t nil type goal name").splitOn " " ++
  ["Memory System Recall", "Architecture", "[STI]"] ++
  ("input-link output-link reward-link reward " ++
   "value epmem command result retrieved status match-score cue-size normalized-match-score " ++
   "match-cardinality memory-id present-id no-memory graph-match mapping node cue success " ++
   "failure bad-cmd retrieve next previous query neg-query before after prohibit yes no smem " ++
   "depth-retrieved activation depth store-new link-to-new-ltm link-to-ltm store math-query " ++
   "less greater less-or-equal greater-or-equal max min").splitOn " " |>.filter (· != "")

/-- The names of the built-in right-hand-side functions, in the order the kernel registers them
when an agent is made (`rhsFunctions`), each a symbol made after the predefined ones. -/
def rhsFunctionSyms : List String := (rhsFunctions.filter (·.kernel)).map (·.name)

/-- The constants of a source file in the order Soar would first make them: the predefined
symbols, the names of the built-in functions, then the file's constants in reading order, as
the lexer reads them (`^a.b` gives `a` and `b`; `|a b|` is one constant). Soar numbers symbols
in the order it makes them (`get_next_symbol_hash_id`), and its reorderer breaks ties by those
numbers (`canonical_cond_greater`); constants made while the agent runs are numbered as they
first appear in working memory (`St.noteSyms`). SIMPLIFIED: a line the tokenizer cannot read
is split at white space and brackets. -/
def symbolOrder (src : String) : List Sym :=
  let isSep (c : Char) : Bool := c.isWhitespace || "(){}^".contains c
  let skip (t : String) : Bool :=
    t.startsWith "<" || t.startsWith "-->" || t == "-" || t == "+" || t == "!" || t == "~" ||
    t == "=" || t == ">" || t == "<" || t == "@" || t.startsWith ":" || t == "sp"
  let ofWord (t : String) : Option Sym :=
    if skip t then none
    else if t.startsWith "|" && t.endsWith "|" && t.length ≥ 2 then some (Sym.str ((t.drop 1).dropEnd 1).toString)
    else match constOf t with
      | .ok y => some y
      | .error _ => none
  let consts := (src.splitOn "\n").flatMap fun l =>
    let l := (l.splitOn "#").head!
    match tokenize l.toList #[] with
    | .ok toks => toks.toList.filterMap fun t => match t with
      | .sym w => ofWord w
      | .quoted q => some (Sym.str q)
      | _ => none
    | .error _ => ((l.splitToList isSep).filter (· != "")).filterMap ofWord
  dedupFirst (predefinedSyms.map Sym.str ++ rhsFunctionSyms.map Sym.str ++ consts)

/-- Chunking settings from `chunk` commands in a source file. The learning modes take Soar
9.6.5's other names (`enabled`, `all` for `always`; `off`, `disabled`, `none` for `never`;
`flagged` for `only`; `unflagged` for `except`) and the unambiguous prefixes of the four
mode names that Soar's command parser completes (so `chunk on` is `chunk only`); checked with
Soar 9.6.5 through soar_sml, 2026-11-01. The deprecated `learn` command sets the same modes. -/
def chunkConfig (src : String) : ChunkCfg :=
  (src.splitOn "\n").foldl (fun (cfg : ChunkCfg) l =>
    match (((l.splitOn "#").head!).trimAscii.toString.splitOn " ").filter (· != "") with
    | ["chunk", "always"] | ["chunk", "enabled"] | ["chunk", "all"] | ["chunk", "alw"]
    | ["chunk", "alwa"] | ["chunk", "alway"] => { cfg with mode := .always }
    | ["chunk", "never"] | ["chunk", "off"] | ["chunk", "disabled"] | ["chunk", "none"]
    | ["chunk", "ne"] | ["chunk", "nev"] | ["chunk", "neve"] => { cfg with mode := .never }
    | ["chunk", "only"] | ["chunk", "flagged"] | ["chunk", "o"] | ["chunk", "on"]
    | ["chunk", "onl"] => { cfg with mode := .only }
    | ["chunk", "except"] | ["chunk", "unflagged"] | ["chunk", "exc"] | ["chunk", "exce"]
    | ["chunk", "excep"] => { cfg with mode := .except }
    -- the deprecated `learn` command (Soar 9.6.5 cli_learn: each option is the `chunk`
    -- command it names; `--except` names `chunk all-except`, which 9.6.5 rejects, so it changes
    -- nothing; checked through soar_sml, 2026-11-02)
    | "learn" :: opts => opts.foldl (fun (cfg : ChunkCfg) o => match o with
      | "--on" | "-e" | "--enable" => { cfg with mode := .always }
      | "--off" | "-d" | "--disable" => { cfg with mode := .never }
      | "--only" | "-o" => { cfg with mode := .only }
      | "--bottom-up" | "-b" => { cfg with bottomOnly := true }
      | "--all-levels" | "-a" | "--all" => { cfg with bottomOnly := false }
      | _ => cfg) cfg
    | ["chunk", "max-chunks", n] => { cfg with maxChunks := n.toNat! }
    | ["chunk", "max-dupes", n] => { cfg with maxDupes := n.toNat! }
    | ["chunk", "automatically-create-singletons", v] => { cfg with autoSingletons := v == "on" }
    | ["chunk", "add-osk", v] => { cfg with addOsk := v == "on" }
    | ["chunk", "bottom-only", v] => { cfg with bottomOnly := v == "on" }
    | ["chunk", "add-ltm-links", v] => { cfg with addLtmLinks := v == "on" }
    | ["chunk", "singleton", it, a, vt] | ["chunk", "single", it, a, vt] =>
      -- Soar 9.6.5 refuses to change the architecture's singletons
      -- and any type other than any, constant, identifier, operator or state
      if ["operator", "superstate", "smem", "type", "impasse", "epmem"].contains a then cfg
      else match SingletonKind.ofString? it, SingletonKind.ofString? vt with
        | some ik, some vk => { cfg with singletons := (ik, a, vk) :: cfg.singletons.filter (·.2.1 != a) }
        | _, _ => cfg
    | _ => cfg) {}

/-- Exploration settings and the random seed from `decide` and `srand` commands in a source
file (Soar 9.6.5 `decide indifferent-selection`, `decide numeric-indifferent-mode`, `srand`,
and their older names `indifferent-selection`, `numeric-indifferent-mode`). -/
def exploreConfig (src : String) : ExploreCfg × Option UInt32 :=
  let num (x : String) : Option Float := match constOf x with
    | .ok y => y.num?
    | .error _ => none
  let red (r : Reducible) (pol : String) : Reducible :=
    if pol == "linear" then { r with policy := .linear } else if pol == "exponential" then { r with policy := .exponential } else r
  let rate (r : Reducible) (pol x : String) : Reducible := match num x with
    | some v => if pol == "linear" then (if v ≥ 0 then { r with linRate := v } else r)
                else if pol == "exponential" then (if v ≥ 0 && v ≤ 1 then { r with expRate := v } else r) else r
    | none => r
  let sel (c : ExploreCfg) : List String → ExploreCfg
    | ["--first"] | ["-f"] => { c with policy := .first }
    | ["--last"] | ["-l"] => { c with policy := .last }
    | ["--softmax"] | ["-s"] => { c with policy := .softmax }
    | ["--epsilon-greedy"] | ["-g"] => { c with policy := .epsilonGreedy }
    | ["--boltzmann"] | ["-b"] => { c with policy := .boltzmann }
    | ["--epsilon", x] | ["-e", x] => match num x with
      | some v => if v ≥ 0 && v ≤ 1 then { c with epsilon := { c.epsilon with value := v } } else c
      | none => c
    | ["--temperature", x] | ["-t", x] => match num x with
      | some v => if v > 0 then { c with temperature := { c.temperature with value := v } } else c
      | none => c
    | ["--auto-reduce", v] | ["-a", v] => { c with autoReduce := v == "on" }
    | ["--reduction-policy", "epsilon", p] | ["-p", "epsilon", p] => { c with epsilon := red c.epsilon p }
    | ["--reduction-policy", "temperature", p] | ["-p", "temperature", p] => { c with temperature := red c.temperature p }
    | ["--reduction-rate", "epsilon", p, x] | ["-r", "epsilon", p, x] => { c with epsilon := rate c.epsilon p x }
    | ["--reduction-rate", "temperature", p, x] | ["-r", "temperature", p, x] => { c with temperature := rate c.temperature p x }
    | _ => c
  (src.splitOn "\n").foldl (fun (acc : ExploreCfg × Option UInt32) l =>
    let (c, seed) := acc
    let l := (l.splitOn "#").head!
    match (l.trimAscii.toString.splitOn " ").filter (· != "") with
    | "decide" :: "indifferent-selection" :: r | "indifferent-selection" :: r => (sel c r, seed)
    | ["decide", "numeric-indifferent-mode", m] | ["numeric-indifferent-mode", m] =>
      ({ c with avg := if m == "--avg" || m == "-a" then true else if m == "--sum" || m == "-s" then false else c.avg }, seed)
    | ["srand", n] | ["decide", "srand", n] => (c, some n.toNat!.toUInt32)
    | _ => acc) ({}, none)

/-- Agent settings from a source file: Soar 9.6.5's `soar` settings (`soar max-elaborations`,
`max-goal-depth`, `wait-snc`, `keep-all-top-oprefs`, and the older `max-elaborations` and
`waitsnc` commands) and `rl --set` (learning, learning-rate, discount-rate,
temporal-extension, hrl-discount). -/
structure AgentCfg where
  maxElab : Nat := 100
  maxGoalDepth : Nat := 100
  waitSnc : Bool := false
  keepTopOprefs : Bool := false
  rlLearning : Option Bool := none
  alpha : Float := 0.3
  gamma : Float := 0.9
  temporalExtension : Bool := true
  hrlDiscount : Bool := false
  policy : String := "sarsa"
  lambda : Float := 0
  etTolerance : Float := 0.001
  decay : String := "normal"
  eta : Float := 1
  theta : Float := 0.1
  temporalDiscount : Bool := true

def agentConfig (src : String) : AgentCfg :=
  let num (x : String) : Option Float := match constOf x with
    | .ok y => y.num?
    | .error _ => none
  let onOff (v : String) : Bool := v == "on" || v == "true" || v == "1"
  (src.splitOn "\n").foldl (fun (c : AgentCfg) l =>
    let l := (l.splitOn "#").head!
    match (l.trimAscii.toString.splitOn " ").filter (· != "") with
    | ["soar", "max-elaborations", n] | ["max-elaborations", n] =>
      if n.toNat?.isSome && n.toNat! > 0 then { c with maxElab := n.toNat! } else c
    | ["soar", "max-goal-depth", n] =>
      if n.toNat?.isSome && n.toNat! > 1 then { c with maxGoalDepth := n.toNat! } else c
    | ["soar", "wait-snc", v] => { c with waitSnc := onOff v }
    | ["waitsnc", "-e"] | ["waitsnc", "--on"] | ["waitsnc", "--enable"] => { c with waitSnc := true }
    | ["waitsnc", "-d"] | ["waitsnc", "--off"] | ["waitsnc", "--disable"] => { c with waitSnc := false }
    | ["soar", "keep-all-top-oprefs", v] => { c with keepTopOprefs := onOff v }
    | ["rl", "--set", k, v] | ["rl", "-s", k, v] => match k with
      | "learning" => { c with rlLearning := some (onOff v) }
      | "learning-rate" => match num v with
        | some x => if x ≥ 0 && x ≤ 1 then { c with alpha := x } else c
        | none => c
      | "discount-rate" => match num v with
        | some x => if x ≥ 0 && x ≤ 1 then { c with gamma := x } else c
        | none => c
      | "temporal-extension" => { c with temporalExtension := onOff v }
      | "hrl-discount" => { c with hrlDiscount := onOff v }
      | "temporal-discount" => { c with temporalDiscount := onOff v }
      | "learning-policy" =>
        if ["sarsa", "q-learning", "on-policy-gq-lambda", "off-policy-gq-lambda"].contains v then { c with policy := v } else c
      | "decay-mode" => if ["normal", "exp", "log", "delta-bar-delta"].contains v then { c with decay := v } else c
      | "eligibility-trace-decay-rate" => match num v with
        | some x => if x ≥ 0 && x ≤ 1 then { c with lambda := x } else c
        | none => c
      | "eligibility-trace-tolerance" => match num v with
        | some x => if x > 0 then { c with etTolerance := x } else c
        | none => c
      | "step-size-parameter" => match num v with
        | some x => if x ≥ 0 && x ≤ 1 then { c with eta := x } else c
        | none => c
      | "meta-learning-rate" => match num v with
        | some x => if x ≥ 0 && x ≤ 1 then { c with theta := x } else c
        | none => c
      | _ => c
    | ["rl", "--enable"] | ["rl", "-e"] | ["rl", "--on"] => { c with rlLearning := some true }
    | ["rl", "--disable"] | ["rl", "-d"] | ["rl", "--off"] => { c with rlLearning := some false }
    | _ => c) {}

end Soar.Parse
