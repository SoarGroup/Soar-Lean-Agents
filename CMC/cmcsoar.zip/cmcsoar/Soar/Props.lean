import Soar.Cycle
import Soar.SMemProps
/-!
# Soar 9.6 — properties of the decision cycle

Theorems about the executable semantics in `Soar.Cycle`.
-/

namespace Soar

/-! ## Lemmas moved from Cycle.lean: reinforcement learning, template rules and tie picking leave the architecture alone -/

theorem St.rlUpdate_arch (s : St) (gid : Nat) (v : Float) (b u : Bool) :
    (s.rlUpdate gid v b u).arch = s.arch := by
  unfold St.rlUpdate; split
  · rfl
  · split <;> rfl

theorem St.rlStore_arch (s : St) (gid : Nat) (o : Sym) : (s.rlStore gid o).arch = s.arch := rfl

theorem St.rlTabulate_arch (s : St) : s.rlTabulate.arch = s.arch := rfl
theorem St.rlTabulateGoal_arch (s : St) (gid : Nat) : (s.rlTabulateGoal gid).arch = s.arch := rfl

theorem St.rlClearTraces_arch (s : St) (gid : Nat) (c : Bool) : (s.rlClearTraces gid c).arch = s.arch := by
  unfold St.rlClearTraces; split <;> rfl

theorem St.rlSelect_arch (s : St) (gid : Nat) (o : Sym) : (s.rlSelect gid o).arch = s.arch := by
  unfold St.rlSelect; split
  · rfl
  · simp only [St.rlKeepRho, St.rlStore_arch, St.rlClearTraces_arch, St.rlUpdate_arch, St.rlTabulate_arch]

theorem St.rlRetractOne_arch (s : St) (g : Goal) : (s.rlRetractOne g).arch = s.arch := by
  unfold St.rlRetractOne
  show (St.rlUpdate _ _ _ _ _).arch = _
  rw [St.rlUpdate_arch, St.rlTabulateGoal_arch]

theorem foldl_rlRetractOne_arch (gs : List Goal) (s : St) :
    (gs.foldl St.rlRetractOne s).arch = s.arch :=
  foldl_rel (fun a b : St => b.arch = a.arch) (fun _ _ _ h1 h2 => h2.trans h1) (fun _ => rfl)
    St.rlRetractOne (fun s g => St.rlRetractOne_arch s g) gs s

theorem St.rlRetract_arch (s : St) (lvl : Nat) : (s.rlRetract lvl).arch = s.arch := by
  unfold St.rlRetract; split
  · rfl
  · exact foldl_rlRetractOne_arch _ _

theorem St.addTemplateRule_same (s : St) (m : Match) :
    (s.addTemplateRule m).arch = s.arch ∧ (s.addTemplateRule m).goals = s.goals := by
  unfold St.addTemplateRule; simp only
  split
  · exact ⟨rfl, rfl⟩
  · split_rfl

theorem St.pickTie_arch (s : St) (choose : List Sym → Sym) (ps : List Pref) (g : Nat) :
    (s.pickTie choose ps g).1.arch = s.arch := by
  unfold St.pickTie; split
  · rfl
  · simp only; split <;> rfl


/-! ## Elaboration never adds architecture structures, and removes only what the architecture
removes -/

/-- An operator-selection element: `(<s> ^operator <o>)`, not an acceptable preference. -/
def isSel (w : WME) : Bool := isOpAttr w.attr && !w.acc

/-- The id and level of each state in the goal stack. -/
def St.stack (s : St) : List (Nat × Nat) := s.goals.map (fun g => (g.id, g.level))

/-- Every state of `t` is a state of `s`, at the same level. -/
def GoalsSub (s t : St) : Prop := ∀ x ∈ t.stack, x ∈ s.stack

/-- **What the architecture may do to its own structures during elaboration.** From `s` to `t`
no architecture-created element is added, no state is added, and every architecture-created
element removed is either a state's operator selection or belongs to a substate (level 2 or
below). -/
def ArchDrop (s t : St) : Prop :=
  GoalsSub s t ∧ (∀ w ∈ t.arch, w ∈ s.arch) ∧
  ∀ w ∈ s.arch, w ∉ t.arch → ∃ x ∈ s.stack, x.1 = w.id ∧ (2 ≤ x.2 ∨ isSel w = true)

theorem ArchDrop.refl (s : St) : ArchDrop s s :=
  ⟨fun _ h => h, fun _ h => h, fun _ hw hg => absurd hw hg⟩

theorem ArchDrop.same {s t : St} (ha : t.arch = s.arch) (hg : t.stack = s.stack) : ArchDrop s t :=
  ⟨fun x hx => hg ▸ hx, fun w hw => ha ▸ hw, fun w hw hn => absurd (ha ▸ hw) hn⟩

/-- Working-memory activation's state is not an architecture structure. -/
theorem ArchDrop.wmaS {s t : St} (h : ArchDrop s t) (x : WmaSt) : ArchDrop s (t.setWma x) := h

/-- Spreading activation's working-memory hooks change only semantic memory and
working-memory activation's state. -/
theorem ArchDrop.spSync {s t : St} (h : ArchDrop s t) : ArchDrop s t.spSync := by
  unfold St.spSync; split
  · exact h
  · exact h

theorem ArchDrop.trans {s t u : St} (h₁ : ArchDrop s t) (h₂ : ArchDrop t u) : ArchDrop s u := by
  obtain ⟨g₁, a₁, r₁⟩ := h₁
  obtain ⟨g₂, a₂, r₂⟩ := h₂
  refine ⟨fun x hx => g₁ x (g₂ x hx), fun w hw => a₁ w (a₂ w hw), fun w hw hn => ?_⟩
  by_cases ht : w ∈ t.arch
  · obtain ⟨x, hx, h1, h2⟩ := r₂ w ht hn
    exact ⟨x, g₁ x hx, h1, h2⟩
  · exact r₁ w hw ht

theorem stack_map_goals (gs : List Goal) (f : Goal → Goal)
    (hf : ∀ g, (f g).id = g.id ∧ (f g).level = g.level) :
    (gs.map f).map (fun g => (g.id, g.level)) = gs.map (fun g => (g.id, g.level)) := by
  induction gs with
  | nil => rfl
  | cons g gs ih => simp only [List.map_cons, ih, (hf g).1, (hf g).2]

/-! ### Reinforcement learning, preferences and records leave them alone -/

/-- A preference with its numeric value erased. -/
def PRec.skel (p : PRec) : PRec := { p with num := none }

/-- **What a reinforcement-learning update leaves alone.** A Sarsa update leaves working
memory's architecture elements, the goal stack and the instantiations unchanged, and changes
preference memory only in the numeric values of preferences: no rule's conditions, bindings,
elements or preference structure change. -/
theorem rlUpdate_frame (s : St) (gid : Nat) (v : Float) (b u : Bool) :
    (s.rlUpdate gid v b u).arch = s.arch ∧ (s.rlUpdate gid v b u).stack = s.stack ∧
    (s.rlUpdate gid v b u).insts = s.insts ∧ (s.rlUpdate gid v b u).slots = s.slots ∧
    (s.rlUpdate gid v b u).prefs.map PRec.skel = s.prefs.map PRec.skel := by
  refine ⟨St.rlUpdate_arch _ _ _ _ _, ?_⟩
  unfold St.rlUpdate St.stack
  split
  · exact ⟨rfl, rfl, rfl, rfl⟩
  · split
    · refine ⟨stack_map_goals _ _ (fun g => by split_rfl), rfl, rfl, ?_⟩
      simp only [List.map_map]
      apply List.map_congr_left
      intro p _
      simp only [Function.comp]
      split
      · rfl
      · split <;> rfl
    · exact ⟨rfl, rfl, rfl, rfl⟩

theorem rlUpdate_stack (s : St) (gid : Nat) (v : Float) (b u : Bool) :
    (s.rlUpdate gid v b u).stack = s.stack := (rlUpdate_frame s gid v b u).2.1

theorem rlRetractOne_stack (s : St) (g : Goal) : (s.rlRetractOne g).stack = s.stack := rfl

theorem foldl_rlRetractOne_stack (gs : List Goal) (s : St) :
    (gs.foldl St.rlRetractOne s).stack = s.stack :=
  foldl_rel (fun a b : St => b.stack = a.stack) (fun _ _ _ h1 h2 => h2.trans h1) (fun _ => rfl)
    St.rlRetractOne (fun s g => rlRetractOne_stack s g) gs s

theorem rlRetract_stack (s : St) (lvl : Nat) : (s.rlRetract lvl).stack = s.stack := by
  unfold St.rlRetract; split
  · rfl
  · exact foldl_rlRetractOne_stack _ _

/-- `t` has the same architecture elements and goals as `s` (the shape of the `_same` lemmas). -/
abbrev St.Same (s t : St) : Prop := t.arch = s.arch ∧ t.goals = s.goals

theorem St.Same.refl (s : St) : s.Same s := ⟨rfl, rfl⟩

theorem St.Same.trans {r s t : St} (h1 : r.Same s) (h2 : s.Same t) : r.Same t :=
  ⟨h2.1.trans h1.1, h2.2.trans h1.2⟩

theorem markCtx_same (s : St) (i : Nat) (a : Sym) :
    (s.markCtx i a).arch = s.arch ∧ (s.markCtx i a).goals = s.goals := by
  unfold St.markCtx; split_rfl

theorem markSlot_same (s : St) (i : Nat) (a : Sym) (k : PrefKind) :
    (s.markSlot i a k).arch = s.arch ∧ (s.markSlot i a k).goals = s.goals := by
  unfold St.markSlot; split
  · split_rfl
  · split_rfl

theorem markCtxSlot_same (mark : Bool) (s : St) (i : Nat) (a : Sym) (k : PrefKind) :
    ((if mark then (s.markCtx i a).markSlot i a k else s.markCtx i a)).arch = s.arch ∧
    ((if mark then (s.markCtx i a).markSlot i a k else s.markCtx i a)).goals = s.goals := by
  cases mark
  · exact markCtx_same _ _ _
  · exact St.Same.trans (markCtx_same _ _ _) (markSlot_same _ _ _ _)

theorem addPref_same (mark : Bool) (s : St) (p : PRec) :
    (s.addPref mark p).arch = s.arch ∧ (s.addPref mark p).goals = s.goals := by
  unfold St.addPref; simp only; split
  · exact ⟨rfl, rfl⟩
  · split
    · exact ⟨(markSlot_same _ _ _ _).1.trans (markCtx_same _ _ _).1, (markSlot_same _ _ _ _).2.trans (markCtx_same _ _ _).2⟩
    · exact markCtx_same _ _ _

theorem foldl_same {α : Type} (l : List α) (f : St → α → St)
    (hf : ∀ s a, (f s a).arch = s.arch ∧ (f s a).goals = s.goals) (s : St) :
    (l.foldl f s).arch = s.arch ∧ (l.foldl f s).goals = s.goals :=
  foldl_rel (fun a b : St => b.arch = a.arch ∧ b.goals = a.goals)
    (fun _ _ _ h1 h2 => ⟨h2.1.trans h1.1, h2.2.trans h1.2⟩) (fun _ => ⟨rfl, rfl⟩) f hf l s

theorem dropPrefs_same (s : St) (f : PRec → Bool) (mark : Bool := true) :
    (s.dropPrefs f mark).arch = s.arch ∧ (s.dropPrefs f mark).goals = s.goals := by
  unfold St.dropPrefs
  exact foldl_same _ _ (fun s p => markCtxSlot_same mark s p.id p.attr p.kind) _

theorem assertPrefs_same (s : St) (ps : List PRec) (mark : Bool := true) :
    (s.assertPrefs ps mark).arch = s.arch ∧ (s.assertPrefs ps mark).goals = s.goals := by
  unfold St.assertPrefs
  obtain ⟨h1, h2⟩ := foldl_same (ps.filter _) (St.addPref mark) (addPref_same mark)
    (List.foldl (fun s r => s.dropPrefs _) s (ps.filter _))
  obtain ⟨h3, h4⟩ := foldl_same (ps.filter (fun p => p.kind == .reject && p.osup))
    (fun s r => s.dropPrefs (fun q => q.id == r.id && q.attr == r.attr && q.val == r.val))
    (fun s r => dropPrefs_same _ _) s
  exact ⟨h1.trans h3, h2.trans h4⟩

theorem supportResults_same (s : St) (j : Inst) (rw : List WME) (rp : List Pref) (rr : List WME) :
    (s.supportResults j rw rp rr).arch = s.arch ∧ (s.supportResults j rw rp rr).goals = s.goals := by
  unfold St.supportResults
  exact ⟨rfl, rfl⟩

theorem justifyResults_same (s : St) (L : Nat) (i : Inst) (rw : List WME) (rp : List Pref)
    (rr more : List WME) :
    (s.justifyResults L i rw rp rr more).arch = s.arch ∧ (s.justifyResults L i rw rp rr more).goals = s.goals := by
  unfold St.justifyResults
  dsimp only
  split
  · exact ⟨rfl, rfl⟩
  · exact supportResults_same _ _ _ _ _

theorem makeResults_same (s : St) (L : Nat) (ni : List Inst) :
    (s.makeResults L ni).arch = s.arch ∧ (s.makeResults L ni).goals = s.goals := by
  unfold St.makeResults
  apply foldl_same
  intro s i
  simp only
  split
  · exact ⟨rfl, rfl⟩
  · exact justifyResults_same _ _ _ _ _ _ _

/-- **Learning changes only the procedural module's records** (`St.withLearn`). -/
theorem learnResults_same (s pre : St) (L : Nat) (ni : List Inst) :
    (s.learnResults pre L ni).arch = s.arch ∧ (s.learnResults pre L ni).goals = s.goals := by
  unfold St.learnResults; simp only; split_rfl

theorem results_same (s pre : St) (L : Nat) (ni : List Inst) :
    (s.results pre L ni).arch = s.arch ∧ (s.results pre L ni).goals = s.goals := by
  unfold St.results; split
  · split
    · exact learnResults_same _ _ _ _
    · exact makeResults_same _ _ _
  · exact ⟨rfl, rfl⟩

theorem runEpCmd_same (s : St) (ws : List String) :
    (s.runEpCmd ws).arch = s.arch ∧ (s.runEpCmd ws).goals = s.goals := by
  unfold St.runEpCmd; split_rfl

theorem runCmdLine_same (s : St) (ws : List String) :
    (s.runCmdLine ws).arch = s.arch ∧ (s.runCmdLine ws).goals = s.goals := by
  unfold St.runCmdLine; split
  · exact ⟨rfl, rfl⟩
  · exact ⟨rfl, rfl⟩
  · exact ⟨rfl, rfl⟩
  · exact runEpCmd_same _ _
  · exact ⟨rfl, rfl⟩

theorem retract_same (s : St) (is : List Inst) :
    (s.retract is).arch = s.arch ∧ (s.retract is).goals = s.goals := by
  unfold St.retract; split
  · exact ⟨rfl, rfl⟩
  · simp only
    have hm := fun (t : St) => foldl_same is (fun (s : St) (i : Inst) =>
      ((s.prefs.filter (fun p => p.inst == i.iid && !p.osup)).reverse).foldl
        (fun (s : St) p => s.markSlot p.id p.attr p.kind) s)
      (fun s i => foldl_same _ _ (fun s p => markSlot_same _ _ _ _) s) t
    split
    · exact ⟨(dropPrefs_same _ _ _).1.trans (hm _).1, (dropPrefs_same _ _ _).2.trans (hm _).2⟩
    · exact ⟨(dropPrefs_same _ _ _).1.trans (hm _).1, (dropPrefs_same _ _ _).2.trans (hm _).2⟩

theorem addGds_stack (s : St) (L : Nat) (ws : List WME) :
    (s.addGds L ws).arch = s.arch ∧ (s.addGds L ws).stack = s.stack := by
  unfold St.addGds St.stack; split
  · exact ⟨rfl, stack_map_goals _ _ (fun g => by split_rfl)⟩
  · exact ⟨rfl, rfl⟩

theorem ArchDrop.ofSame {s t : St} (h : t.arch = s.arch ∧ t.goals = s.goals) : ArchDrop s t :=
  ArchDrop.same h.1 (by unfold St.stack; rw [h.2])

/-! ### Removal of goals and operators -/

theorem removeGoalsFrom_drop (s : St) (lvl : Nat) (hl : 2 ≤ lvl) :
    ArchDrop s (s.removeGoalsFrom lvl) := by
  have hst := rlRetract_stack s lvl
  have har := St.rlRetract_arch s lvl
  refine ⟨?_, ?_, ?_⟩
  · intro x hx
    unfold St.removeGoalsFrom St.stack at hx
    simp only [List.mem_map, List.mem_filter] at hx
    obtain ⟨g, ⟨hg, _⟩, rfl⟩ := hx
    rw [← hst]; exact List.mem_map_of_mem hg
  · intro w hw
    unfold St.removeGoalsFrom at hw
    have := (List.mem_filter.mp hw).1
    rwa [har] at this
  · intro w hw hgone
    unfold St.removeGoalsFrom at hgone
    have hw' : w ∈ (s.rlRetract lvl).arch := by rw [har]; exact hw
    simp only [List.mem_filter, hw', true_and, Bool.not_eq_true', List.contains_eq_any_beq,
      List.any_eq_false, List.mem_map, beq_iff_eq, not_exists, not_and, Bool.not_eq_false,
      List.any_eq_true] at hgone
    apply Classical.byContradiction
    intro hc
    apply hgone
    intro y ⟨a, ⟨ha, hla⟩, hay⟩ hwy
    have hmem : (a.id, a.level) ∈ s.stack := by
      rw [← hst]; exact List.mem_map_of_mem ha
    exact hc ⟨(a.id, a.level), hmem, hay.trans hwy.symm, Or.inl (Nat.le_trans hl (by simpa using hla))⟩

theorem removeOperator_drop (s : St) (g : Goal) (hg : g ∈ s.goals) :
    ArchDrop s (s.removeOperator g) := by
  unfold St.removeOperator
  refine ArchDrop.trans ?_ (removeGoalsFrom_drop _ _ (Nat.le_max_left _ _))
  refine ⟨fun x hx => hx, fun w hw => (List.mem_filter.mp hw).1, fun w hw hn => ?_⟩
  refine ⟨(g.id, g.level), List.mem_map_of_mem hg, ?_, Or.inr ?_⟩
  · simp only [List.mem_filter, hw, true_and, Bool.not_eq_true', Bool.not_eq_false,
      Bool.and_eq_true, beq_iff_eq] at hn
    exact hn.1.1.symm
  · simp only [List.mem_filter, hw, true_and, Bool.not_eq_true', Bool.not_eq_false,
      Bool.and_eq_true, beq_iff_eq] at hn
    simp only [isSel, hn.1.2, hn.2, Bool.not_false, Bool.and_self]

theorem noteSyms_same (s : St) (ws : List WME) :
    (s.noteSyms ws).arch = s.arch ∧ (s.noteSyms ws).goals = s.goals := by
  unfold St.noteSyms
  exact foldl_same _ _ (fun s w => foldl_same _ _ (fun s y => by split_rfl) s) s

theorem retag_same (s : St) : s.retag.arch = s.arch ∧ s.retag.goals = s.goals := by
  unfold St.retag
  exact noteSyms_same _ _

theorem sync_drop : ∀ (n : Nat) (s : St), ArchDrop s (s.sync n)
  | 0, s => ArchDrop.refl s
  | n + 1, s => by
    unfold St.sync
    simp only
    split
    · rename_i g hg
      refine ArchDrop.trans ?_ (sync_drop n _)
      refine ArchDrop.trans (ArchDrop.ofSame ⟨rfl, rfl⟩) ?_
      exact removeOperator_drop _ g (List.mem_of_find?_eq_some hg)
    · exact ArchDrop.ofSame (retag_same _)

theorem gc_drop (s : St) : ArchDrop s s.gc := by
  unfold St.gc
  simp only
  split
  · exact ArchDrop.ofSame ⟨rfl, rfl⟩
  · exact sync_drop 4 _

theorem gdsCheck_drop (s : St) : ArchDrop s s.gdsCheck := by
  unfold St.gdsCheck
  simp only
  split
  · rename_i g hg
    have hl := (List.find?_some hg)
    simp only [Bool.and_eq_true, decide_eq_true_eq] at hl
    refine ArchDrop.trans (removeGoalsFrom_drop s g.level hl.1) ?_
    refine ArchDrop.trans ?_ (ArchDrop.trans (sync_drop 4 _) (gc_drop _))
    split
    · split <;> exact ArchDrop.ofSame ⟨rfl, rfl⟩
    · exact ArchDrop.refl _
  · exact ArchDrop.refl _

theorem foldl_addGds_drop {α : Type} (l : List α) (f : St → α → St)
    (hf : ∀ s a, ArchDrop s (f s a)) (s : St) : ArchDrop s (l.foldl f s) :=
  foldl_rel ArchDrop (fun _ _ _ => ArchDrop.trans) ArchDrop.refl f hf l s

theorem soarRetag_same (s pre : St) (push : List WME) :
    (s.soarRetag pre push).arch = s.arch ∧ (s.soarRetag pre push).goals = s.goals := by
  unfold St.soarRetag; simp only; split_rfl

theorem notePush_same (s pre : St) : (s.notePush pre).arch = s.arch ∧ (s.notePush pre).goals = s.goals := by
  unfold St.notePush; split
  · exact ⟨rfl, rfl⟩
  · exact soarRetag_same _ _ _

theorem wmPhase_drop (s pre : St) : ArchDrop s (s.wmPhase pre) := by
  unfold St.wmPhase
  simp only
  refine ArchDrop.trans (sync_drop 4 s) ?_
  refine ArchDrop.trans (foldl_addGds_drop _ _ ?_ _) (ArchDrop.trans (gc_drop _) (ArchDrop.trans (gdsCheck_drop _)
    (ArchDrop.ofSame (notePush_same _ _))))
  intro s e
  split
  · split
    · split
      · exact ArchDrop.same (addGds_stack _ _ _).1 (addGds_stack _ _ _).2
      · exact ArchDrop.refl _
    · exact ArchDrop.refl _
  · exact ArchDrop.refl _

/-! ### Firing at a level, and the elaboration cycle -/

theorem newInst_same (s : St) (record : Bool) (tag : String) (L j : Nat) (m : Match) :
    (s.newInst record tag L j m).1.arch = s.arch ∧ (s.newInst record tag L j m).1.goals = s.goals := by
  unfold St.newInst
  exact ⟨rfl, rfl⟩

theorem resultsOf_same (s pre : St) (L : Nat) (i : Inst) (ps : List PRec) :
    (s.resultsOf pre L i ps).arch = s.arch ∧ (s.resultsOf pre L i ps).goals = s.goals := by
  unfold St.resultsOf
  exact results_same (s.viewWith ps) pre L [i]

theorem fireOneBase_same (pre : St) (record : Bool) (tag : String) (L : Nat) (acc : St × Nat) (m : Match) :
    (St.fireOneBase pre record tag L acc m).1.arch = acc.1.arch ∧
      (St.fireOneBase pre record tag L acc m).1.goals = acc.1.goals := by
  unfold St.fireOneBase
  obtain ⟨h3, h4⟩ := newInst_same acc.1 record tag L acc.2 m
  simp only
  split
  · obtain ⟨h1, h2⟩ := resultsOf_same ((acc.1.newInst record tag L acc.2 m).1.addTemplateRule m) pre L
      (acc.1.newInst record tag L acc.2 m).2.1 (acc.1.newInst record tag L acc.2 m).2.2
    obtain ⟨h5, h6⟩ := St.addTemplateRule_same (acc.1.newInst record tag L acc.2 m).1 m
    exact ⟨h1.trans (h5.trans h3), h2.trans (h6.trans h4)⟩
  · obtain ⟨h1, h2⟩ := resultsOf_same (acc.1.newInst record tag L acc.2 m).1 pre L
      (acc.1.newInst record tag L acc.2 m).2.1 (acc.1.newInst record tag L acc.2 m).2.2
    exact ⟨h1.trans h3, h2.trans h4⟩

theorem fireOneT_same (pre : St) (record : Bool) (tag : String) (L : Nat) (acc : St × Nat) (m : Match) :
    (St.fireOneT pre record tag L acc m).1.arch = acc.1.arch ∧
      (St.fireOneT pre record tag L acc m).1.goals = acc.1.goals := by
  obtain ⟨b1, b2⟩ := fireOneBase_same pre record tag L acc m
  unfold St.fireOneT
  simp only
  split
  · exact ⟨b1, b2⟩
  · split
    · exact ⟨b1, b2⟩
    · rename_i rule _
      refine (foldl_rel (fun a b : St × Nat => b.1.arch = a.1.arch ∧ b.1.goals = a.1.goals)
        (fun _ _ _ h1 h2 => ⟨h2.1.trans h1.1, h2.2.trans h1.2⟩) (fun _ => ⟨rfl, rfl⟩)
        (St.fireOneBase pre record tag L) (fireOneBase_same pre record tag L) _ _).imp (fun h => h.trans ?_) (fun h => h.trans ?_)
      · simp only; split <;> exact b1
      · simp only; split <;> exact b2

theorem reteAddRules_same (s : St) : s.reteAddRules.arch = s.arch ∧ s.reteAddRules.goals = s.goals := by
  unfold St.reteAddRules St.fillOrd
  split <;> exact ⟨rfl, rfl⟩

theorem fireOne_same (pre : St) (record : Bool) (tag : String) (L : Nat) (acc : St × Nat) (m : Match) :
    (St.fireOne pre record tag L acc m).1.arch = acc.1.arch ∧
      (St.fireOne pre record tag L acc m).1.goals = acc.1.goals := by
  obtain ⟨b1, b2⟩ := fireOneT_same pre record tag L acc m
  obtain ⟨c1, c2⟩ := reteAddRules_same (St.fireOneT pre record tag L acc m).1
  unfold St.fireOne
  simp only
  split
  · exact ⟨b1, b2⟩
  · refine (foldl_rel (fun a b : St × Nat => b.1.arch = a.1.arch ∧ b.1.goals = a.1.goals)
      (fun _ _ _ h1 h2 => ⟨h2.1.trans h1.1, h2.2.trans h1.2⟩) (fun _ => ⟨rfl, rfl⟩)
      (St.fireOneBase pre record tag L) (fireOneBase_same pre record tag L) _ _).imp (fun h => h.trans ?_) (fun h => h.trans ?_)
    · simp only; split <;> exact c1.trans b1
    · simp only; split <;> exact c2.trans b2

theorem fireOnes_same (pre : St) (record : Bool) (tag : String) (L : Nat) (ms : List Match) :
    ∀ acc : St × Nat,
      (ms.foldl (St.fireOne pre record tag L) acc).1.arch = acc.1.arch ∧
      (ms.foldl (St.fireOne pre record tag L) acc).1.goals = acc.1.goals := by
  induction ms with
  | nil => intro acc; exact ⟨rfl, rfl⟩
  | cons m ms ih =>
    intro acc
    simp only [List.foldl_cons]
    obtain ⟨h1, h2⟩ := ih (St.fireOne pre record tag L acc m)
    obtain ⟨h3, h4⟩ := fireOne_same pre record tag L acc m
    exact ⟨h1.trans h3, h2.trans h4⟩

theorem assertFresh_same (s : St) : s.assertFresh.arch = s.arch ∧ s.assertFresh.goals = s.goals := by
  unfold St.assertFresh
  simp only
  obtain ⟨h1, h2⟩ := foldl_same _ _ (fun (s : St) (p : PRec) => markSlot_same s p.id p.attr p.kind) (St.assertPrefs _ _ false)
  obtain ⟨h3, h4⟩ := assertPrefs_same _ _ false
  exact ⟨h1.trans h3, h2.trans h4⟩

theorem logFirings_same (s : St) (ft : Firing) (L : Nat) (ms : List Match) :
    (s.logFirings ft L ms).arch = s.arch ∧ (s.logFirings ft L ms).goals = s.goals := by
  unfold St.logFirings; simp only; split_rfl

theorem runCmds_same (s : St) (ms : List Match) :
    (s.runCmds ms).arch = s.arch ∧ (s.runCmds ms).goals = s.goals := by
  unfold St.runCmds; exact foldl_same _ _ runCmdLine_same _

theorem bumpX_same (r : Bool) (s : St) : (s.bumpX r).arch = s.arch ∧ (s.bumpX r).goals = s.goals := by
  unfold St.bumpX; split_rfl

/-- **Firing at a level changes no architecture structure and no state**: working memory does
not change until the working-memory phase. -/
theorem fireLevel_same (s pre : St) (ft : Firing) (L : Nat) (ms : List Match) :
    (s.fireLevel pre ft L ms).arch = s.arch ∧ (s.fireLevel pre ft L ms).goals = s.goals := by
  unfold St.fireLevel
  split
  · exact ⟨rfl, rfl⟩
  · simp only
    obtain ⟨a1, a2⟩ := logFirings_same s ft L ms
    obtain ⟨b1, b2⟩ := runCmds_same (s.logFirings ft L ms) ms
    obtain ⟨c1, c2⟩ := fireOnes_same pre (s.learning && decide (L ≥ 2)) (if ft == .ie then "i" else "o") L ms
      ((s.logFirings ft L ms).runCmds ms, 0)
    generalize (ms.foldl _ _) = r at *
    obtain ⟨d1, d2⟩ := assertFresh_same r.1
    obtain ⟨e1, e2⟩ := bumpX_same (s.learning && decide (L ≥ 2)) r.1.assertFresh
    exact ⟨e1.trans (d1.trans (c1.trans (b1.trans a1))), e2.trans (d2.trans (c2.trans (b2.trans a2)))⟩

theorem fireLevel_drop (s pre : St) (ft : Firing) (L : Nat) (ms : List Match) :
    ArchDrop s (s.fireLevel pre ft L ms) :=
  ArchDrop.ofSame (fireLevel_same s pre ft L ms)

theorem retract_drop (s : St) (is : List Inst) : ArchDrop s (s.retract is) :=
  ArchDrop.ofSame (retract_same s is)

/-- Setting working-memory activation's state and then a working-memory phase. -/
theorem wmaPhase_drop (t : St) (x : WmaSt) (y : St) : ArchDrop t ((t.setWma x).wmPhase y) :=
  ArchDrop.trans (ArchDrop.wmaS (ArchDrop.refl t) x) (wmPhase_drop _ _)

/-- **An elaboration cycle never adds architecture structures**, and removes only operator
selections and substates (their removal by the architecture: an operator whose acceptable
preference is gone, a substate whose dependencies changed or that is below a removed
operator). Rules cannot overwrite these structures (DECIDED, Laird, 2026-10-28). -/
theorem elabStep_drop (pre : St) (lt : Nat → Nat) (ph : Phase) (ft : Firing) (H : Nat) (pd : Pend)
    (acc : St × Nat) (l : Nat) : ArchDrop acc.1 (St.elabStep pre lt ph ft H pd acc l).1 := by
  obtain ⟨s, next⟩ := acc
  unfold St.elabStep
  simp only
  split
  · exact ArchDrop.refl _
  · exact fireLevel_drop _ _ _ _ _

theorem foldl_elabStep_drop (pre : St) (lt : Nat → Nat) (ph : Phase) (ft : Firing) (H : Nat) (pd : Pend) :
    ∀ (ls : List Nat) (acc : St × Nat), ArchDrop acc.1 (ls.foldl (St.elabStep pre lt ph ft H pd) acc).1 :=
  fun ls acc => foldl_rel (fun a b : St × Nat => ArchDrop a.1 b.1) (fun _ _ _ => ArchDrop.trans)
    (fun a => ArchDrop.refl _) (St.elabStep pre lt ph ft H pd)
    (fun a l => elabStep_drop pre lt ph ft H pd a l) ls acc

/-- **An elaboration cycle never adds architecture structures**, and removes only operator
selections and substates (the architecture's own removals: an operator whose acceptable
preference is gone, a substate whose dependencies changed or that is below a removed operator).
Rules cannot overwrite these structures (DECIDED, Laird, 2026-10-28). -/
theorem elabCycle_drop (s : St) (ph : Phase) (ft : Firing) (H : Nat) (pd : Pend) :
    ArchDrop s (s.elabCycle ph ft H pd) := by
  unfold St.elabCycle
  simp only
  generalize ((s.goals.map (·.level)).filter (· ≥ H)).mergeSort (· ≤ ·) = ls
  refine ArchDrop.spSync (ArchDrop.wmaS ?_ _)
  refine ArchDrop.trans (foldl_elabStep_drop s s.idLevel ph ft H pd ls (s, H)) ?_
  exact ArchDrop.trans (retract_drop _ _) (wmaPhase_drop _ _ _)

theorem trackSlots_same (s : St) : s.trackSlots.arch = s.arch ∧ s.trackSlots.goals = s.goals := by
  unfold St.trackSlots; split_rfl

theorem smemPass_drop (s : St) (b : Bool) : ArchDrop s (s.smemPass b) := by
  unfold St.smemPass; split
  · exact ArchDrop.refl s
  · refine ArchDrop.spSync (ArchDrop.wmaS ?_ _)
    have h1 := St.smemRun_arch s b
    have h2 := St.noteLti_arch (s.smemRun b) s
    exact ArchDrop.trans (ArchDrop.ofSame ⟨h2.1.trans h1.1, h2.2.trans h1.2⟩) (wmaPhase_drop _ _ _)

theorem consistentThrough_drop (s : St) (L : Nat) (choose : List Sym → Sym) :
    ArchDrop s (s.consistentThrough L choose).1 := by
  unfold St.consistentThrough
  split
  · exact ArchDrop.refl s
  · simp only
    split
    · rename_i g hg
      have hm : g ∈ s.goals := (List.mem_filter.mp (List.mem_of_find?_eq_some hg)).1
      exact ArchDrop.trans (removeOperator_drop s g hm) (sync_drop 4 _)
    · exact ArchDrop.refl s

theorem checkIf_drop (s : St) (c : Bool) (L : Nat) (choose : List Sym → Sym) :
    ArchDrop s (s.checkIf c L choose).1 := by
  unfold St.checkIf; split
  · exact consistentThrough_drop _ _ _
  · exact ArchDrop.refl s

theorem after_drop {s : St} (r : St × Bool) (H : Nat) (ft : Firing) (pd : Pend) (h : ArchDrop s r.1) :
    ArchDrop s (Next.after r H ft pd).st := by
  unfold Next.after; split <;> exact h

theorem lowerRest_drop {s : St} (r : St × Bool) (pd : Pend) (ph : Phase) (H : Nat) (choose : List Sym → Sym)
    (h1 : ArchDrop s r.1) : ArchDrop s (St.lowerRest r pd ph H choose).st := by
  unfold St.lowerRest
  split
  · exact h1
  · split
    · exact after_drop _ _ _ _ (ArchDrop.trans h1 (checkIf_drop _ _ _ _))
    · exact h1

theorem lowerStep_drop (s : St) (pd : Pend) (ph : Phase) (prev H : Nat) (ft : Firing) (choose : List Sym → Sym) :
    ArchDrop s (s.lowerStep pd ph prev H ft choose).st := by
  unfold St.lowerStep
  exact lowerRest_drop _ _ _ _ _ (checkIf_drop _ _ _ _)

theorem determineIn_drop (s : St) (pd : Pend) (ph : Phase) (prev : Nat) (ft : Firing)
    (n maxElab : Nat) (choose : List Sym → Sym) :
    ArchDrop s (s.determineIn pd ph prev ft n maxElab choose).st := by
  unfold St.determineIn
  split
  · exact checkIf_drop _ _ _ _
  · split
    · exact ArchDrop.ofSame ⟨rfl, rfl⟩
    · split
      · exact ArchDrop.refl s
      · split
        · exact lowerStep_drop _ _ _ _ _ _ _
        · split
          · exact after_drop _ _ _ _ (checkIf_drop _ _ _ _)
          · refine after_drop _ _ _ _ (ArchDrop.trans ?_ (consistentThrough_drop _ _ _))
            exact ArchDrop.same rfl (by unfold St.saveFT St.stack; exact stack_map_goals _ _ (fun g => by split_rfl))

theorem reteCache_same (s : St) (pm : List Production) :
    (s.reteCache pm).arch = s.arch ∧ (s.reteCache pm).goals = s.goals := by
  unfold St.reteCache; simp only; split
  · exact ⟨rfl, rfl⟩
  · split
    · exact ⟨rfl, rfl⟩
    · split_rfl

theorem reteSync_same (s : St) (pm : List Production) :
    (s.reteSync pm).arch = s.arch ∧ (s.reteSync pm).goals = s.goals := by
  unfold St.reteSync; split
  · exact ⟨rfl, rfl⟩
  · simp only; split
    · exact ⟨rfl, rfl⟩
    · exact reteCache_same _ _

theorem reteNote_same (s : St) (pd : Pend) :
    (s.reteNote pd).arch = s.arch ∧ (s.reteNote pd).goals = s.goals := by
  unfold St.reteNote
  split
  · exact ⟨rfl, rfl⟩
  · simp only; split_rfl

theorem determine_drop (s : St) (pm : List Production) (ph : Phase) (prev : Nat) (ft : Firing)
    (n maxElab : Nat) (choose : List Sym → Sym) :
    ArchDrop s (s.determine pm ph prev ft n maxElab choose).st :=
  ArchDrop.trans (ArchDrop.ofSame (retag_same s))
    (ArchDrop.trans (ArchDrop.ofSame (reteSync_same _ pm))
      (ArchDrop.trans (ArchDrop.ofSame (reteNote_same _ _)) (determineIn_drop _ _ _ _ _ _ _ _)))

theorem phaseLoop_drop (pm : List Production) (ph : Phase) (choose : List Sym → Sym) (maxElab : Nat) :
    ∀ (fuel : Nat) (s : St) (prev : Nat) (ft : Firing) (n : Nat),
      ArchDrop s (St.phaseLoop pm ph choose maxElab fuel s prev ft n)
  | 0, s, _, _, _ => ArchDrop.refl s
  | fuel + 1, s, prev, ft, n => by
    unfold St.phaseLoop
    have hd := determine_drop s pm ph prev ft n maxElab choose
    split
    · rename_i t ht; rw [ht] at hd; exact hd
    · rename_i t H ft' pd ht
      rw [ht] at hd
      have he : ArchDrop s (((t.setFiring ft').elabCycle ph ft' H pd).trackSlots.smemPass true) :=
        ArchDrop.trans hd (ArchDrop.trans (ArchDrop.ofSame (t := t.setFiring ft') ⟨rfl, rfl⟩) (ArchDrop.trans (elabCycle_drop _ _ _ _ _)
          (ArchDrop.trans (ArchDrop.ofSame (trackSlots_same _)) (smemPass_drop _ _))))
      simp only
      split
      · exact ArchDrop.trans he (determine_drop _ pm ph H ft' (n + 1) maxElab choose)
      · exact ArchDrop.trans he (phaseLoop_drop pm ph choose maxElab fuel _ _ _ _)

theorem resetFT_drop (s : St) (f : Firing) : ArchDrop s { s with goals := s.goals.map ({ · with savedFT := none }), firing := f } :=
  ArchDrop.same rfl (by unfold St.stack; exact stack_map_goals _ _ (fun _ => ⟨rfl, rfl⟩))

/-- **The proposal phase never adds architecture structures**: it can only remove operator
selections and substates, and only by the architecture's own mechanisms — an operator whose
acceptable preference is gone, a decision that is no longer consistent with the preferences,
a substate whose dependencies changed. No rule removes them.

DECIDED (Laird, 2026-10-28): rules cannot overwrite architecture-created structures. -/
theorem propose_drop (s : St) (pm : List Production) (choose : List Sym → Sym) (maxElab : Nat) :
    ArchDrop s (s.propose pm choose maxElab) := by
  unfold St.propose
  exact ArchDrop.trans (resetFT_drop s _) (phaseLoop_drop _ _ _ _ _ _ _ _ _)

/-- **The same for the application phase.** -/
theorem apply_drop (s : St) (pm : List Production) (choose : List Sym → Sym) (maxElab : Nat) :
    ArchDrop s (s.apply pm choose maxElab) := by
  unfold St.apply
  exact ArchDrop.trans (resetFT_drop s _) (phaseLoop_drop _ _ _ _ _ _ _ _ _)

/-! ## One operator selection per decision -/

/-- Elements of `t` that select an operator were already in `s`, except possibly `x`. -/
def SelWithin (s t : List WME) (x : Option WME) : Prop :=
  ∀ w ∈ t, isSel w = true → w ∈ s ∨ some w = x

theorem SelWithin.filter {s t : List WME} {x : Option WME} {p : WME → Bool}
    (h : SelWithin s t x) : SelWithin s (t.filter p) x :=
  fun w hw hs => h w (List.mem_filter.mp hw).1 hs

theorem SelWithin.append_nonsel {s t u : List WME} {x : Option WME} (h : SelWithin s t x)
    (hu : ∀ w ∈ u, isSel w = false) : SelWithin s (t ++ u) x := by
  intro w hw hs
  rcases List.mem_append.mp hw with h1 | h2
  · exact h w h1 hs
  · rw [hu w h2] at hs; cases hs

theorem removeGoalsFrom_arch_sub (s : St) (lvl : Nat) : ∀ w ∈ (s.removeGoalsFrom lvl).arch, w ∈ s.arch := by
  intro w hw
  unfold St.removeGoalsFrom at hw
  have := (List.mem_filter.mp hw).1
  rwa [St.rlRetract_arch] at this

theorem stateLinks_nonsel (n m k : Nat) : ∀ w ∈ stateLinks n m k, isSel w = false := by
  intro w hw
  simp only [stateLinks, List.mem_cons, List.not_mem_nil, or_false] at hw
  rcases hw with h | h | h | h | h | h | h | h <;> (subst h; rfl)

theorem impasseItems_nonsel (n : Nat) (ps : List Pref) (items : List Sym) :
    ∀ w ∈ impasseItems n ps items, isSel w = false := by
  intro w hw
  unfold impasseItems at hw
  simp only [List.mem_append, List.mem_map] at hw
  rcases hw with (⟨o, _, rfl⟩ | h) | h
  · rfl
  · split at h
    · simp at h
    · simp only [List.mem_singleton] at h; subst h; rfl
  · split at h
    · simp at h
    · simp only [List.mem_append, List.mem_map, List.mem_singleton] at h
      rcases h with ⟨o, _, rfl⟩ | h
      · rfl
      · subst h; rfl

theorem createSubstate_arch (s : St) (g : Goal) (k : Impasse) (a : Sym) (items : List Sym) :
    ∀ w ∈ (s.createSubstate g k a items).arch, w ∈ s.arch ∨ isSel w = false := by
  intro w hw
  unfold St.createSubstate at hw
  rw [List.mem_append] at hw
  rcases hw with hw | hl
  case inr => exact Or.inr (stateLinks_nonsel _ _ _ w hl)
  rw [List.mem_append, List.mem_append] at hw
  rcases hw with (h | h) | h
  · exact Or.inl h
  · right; simp only [List.mem_cons, List.not_mem_nil, or_false] at h
    rcases h with h | h | h | h | h | h <;> (subst h; rfl)
  · exact Or.inr (impasseItems_nonsel _ _ _ w h)

theorem SelWithin.removeGoals {A : List WME} {s : St} {x : Option WME} (lvl : Nat)
    (h : SelWithin A s.arch x) : SelWithin A (s.removeGoalsFrom lvl).arch x :=
  fun w hw hs => h w (removeGoalsFrom_arch_sub s lvl w hw) hs

theorem SelWithin.createSubstate {A : List WME} {s : St} {x : Option WME} (g : Goal) (k : Impasse)
    (a : Sym) (items : List Sym) (h : SelWithin A s.arch x) :
    SelWithin A (s.createSubstate g k a items).arch x := by
  intro w hw hs
  rcases createSubstate_arch s g k a items w hw with h1 | h2
  · exact h w h1 hs
  · rw [h2] at hs; cases hs

theorem SelWithin.newImpasse {A : List WME} {s : St} (g : Goal) (k : Impasse)
    (a : Sym) (items : List Sym) (h : SelWithin A s.arch none) :
    SelWithin A (s.newImpasse g k a items).arch none := by
  unfold St.newImpasse
  split
  · split <;> exact h
  · split
    · exact SelWithin.createSubstate _ _ _ _ h
    · exact SelWithin.createSubstate _ _ _ _ h

/-- What deciding one slot can do to the operator selections: a final state with at most one
new selection, or a state (to continue with) with none. -/
def SlotOk (A : List WME) : St ⊕ St → Prop
  | .inl t => ∃ x, SelWithin A t.arch x
  | .inr t => SelWithin A t.arch none

/-- Deciding an impasse never adds an operator selection (the result is a state in either case). -/
theorem decideImpasse_none {A : List WME} (s : St) (g : Goal) (child : Option Goal) (k : Impasse)
    (a : Sym) (items : List Sym) (h : SelWithin A s.arch none) :
    SelWithin A (Sum.elim id id (s.decideImpasse g child k a items)).arch none := by
  unfold St.decideImpasse
  have h' : SelWithin A (if (s.selected g.id).isSome = true then s
      else { s with osk := s.osk.filter (·.1 != g.id) }).arch none := by split <;> exact h
  generalize (if (s.selected g.id).isSome = true then s else { s with osk := s.osk.filter (·.1 != g.id) }) = t at h'
  split
  · split
    · exact SelWithin.append_nonsel (SelWithin.filter h') (impasseItems_nonsel _ _ _)
    · exact SelWithin.newImpasse _ _ _ _ (SelWithin.removeGoals _ h')
  · exact SelWithin.newImpasse _ _ _ _ h'

theorem decideImpasse_ok {A : List WME} (s : St) (g : Goal) (child : Option Goal) (k : Impasse) (a : Sym)
    (items : List Sym) (h : SelWithin A s.arch none) : SlotOk A (s.decideImpasse g child k a items) := by
  have := decideImpasse_none s g child k a items h
  cases hr : s.decideImpasse g child k a items with
  | inl t => rw [hr] at this; exact ⟨none, this⟩
  | inr t => rw [hr] at this; exact this

theorem decideSelect_ok {A : List WME} (s : St) (g : Goal) (o : Sym) (h : SelWithin A s.arch none) :
    ∃ x, SelWithin A (s.decideSelect g o).arch x := by
  refine ⟨some { id := g.id, attr := "operator", val := o }, ?_⟩
  unfold St.decideSelect
  have h' : SelWithin A (s.rlSelect g.id o).arch none := by rw [St.rlSelect_arch]; exact h
  intro w hw hs
  simp only [List.mem_append, List.mem_singleton] at hw
  rcases hw with hw | rfl
  · rcases (SelWithin.removeGoals (g.level + 1) h') w hw hs with h1 | h1
    · exact Or.inl h1
    · cases h1
  · exact Or.inr rfl

theorem decideSlot_ok {A : List WME} (s : St) (choose : List Sym → Sym) (g : Goal) (child : Option Goal)
    (dec : Bool) (h : SelWithin A s.arch none) : SlotOk A (s.decideSlot choose g child dec) := by
  unfold St.decideSlot
  split
  · split <;> exact decideImpasse_ok _ _ _ _ _ _ h
  · have h' : SelWithin A (s.pickTie choose (s.prefsFor g.id) g.id).1.arch none := by
      rw [St.pickTie_arch]; exact h
    simp only
    split
    · exact decideSelect_ok _ _ _ h'
    · exact decideImpasse_ok _ _ _ _ _ _ h'
    · exact decideImpasse_ok _ _ _ _ _ _ h'

theorem decide_go_sel (choose : List Sym → Sym) :
    ∀ (fuel lv : Nat) (s : St) (A : List WME), SelWithin A s.arch none →
      ∃ x, SelWithin A (St.decide.go choose fuel lv s).arch x
  | 0, lv, s, A, h => ⟨none, by simpa [St.decide.go] using h⟩
  | fuel + 1, lv, s, A, h => by
    unfold St.decide.go
    split
    · exact ⟨none, h⟩
    · rename_i g _
      split
      · exact decide_go_sel choose fuel _ _ A h
      · have hs := decideSlot_ok (A := A) ({ s with ctxChanged := s.ctxChanged.filter (· != g.id) } : St)
          choose g (s.goals.find? (·.level == lv + 1)) (s.decidable g) h
        split
        · rename_i t ht; rw [ht] at hs; exact hs
        · rename_i t ht; rw [ht] at hs; exact decide_go_sel choose fuel _ _ A hs

/-- **Seriality of deliberate acts.** A decision phase adds at most one operator selection
to working memory: every operator selection present afterwards was already present, except
possibly one.

`Soar.Seriality` builds on this lemma: it states the theorem against the CMC's `Step` and
proves it from here.

This is the point of correspondence with the CMC: "only a single operator is selected and
applied per cycle" (Laird, 2026-10-28), the CMC's single deliberate act.

> "Procedural memory induces the selection of a single deliberate act per cycle" — [LLR17] -/
theorem decide_selects_at_most_one (s : St) (choose : List Sym → Sym) :
    ∃ x, ∀ w ∈ (s.decide choose).arch, isSel w = true → w ∈ s.arch ∨ some w = x := by
  unfold St.decide
  exact decide_go_sel choose _ _ s s.arch (fun w hw _ => Or.inl hw)

/-! ## Quiescence is a truth-maintenance fixpoint -/

/-- **Quiescence of i-supported processing is a truth-maintenance fixpoint.** When no new
i-supported match and no retraction is pending, (1) every instantiation in the match set still
matches (a justification: its conditions are present, with the same timetags), and (2) every
i-supported match has its instantiation.

NOTE ON STRENGTH: `St.pending` is defined as the filters that the hypotheses empty, so this
theorem unfolds that definition into the two inclusions; the content is the choice of `pending`
(checked against Soar by the regression), not the proof.

> "assertion/retraction process is an example of justification-based truth maintenance" —
> [Intro] §2 -/
theorem quiescence_ie (s : St) (pm : List Production) (hi : (s.pending pm).iAss = [])
    (hr : (s.pending pm).retr = []) :
    (∀ i ∈ s.insts, i.inMs = true → i.just = false →
        i.key ∈ (s.curMatches (pm ++ s.chunks ++ s.rlGen)).map (·.key)) ∧
    (∀ m ∈ s.curMatches (pm ++ s.chunks ++ s.rlGen), m.osup = false →
        m.key ∈ (s.insts.filter (·.inMs)).map (·.key)) := by
  unfold St.pending at hi hr
  simp only [List.filter_eq_nil_iff] at hi hr
  refine ⟨fun i hi' hm hj => ?_, fun m hm ho => ?_⟩
  · have := hr i (List.mem_filter.mpr ⟨hi', hm⟩)
    simp only [hj, Bool.false_eq_true, ↓reduceIte, Bool.not_eq_true', Bool.not_eq_false] at this
    simpa [List.contains_iff_mem] using this
  · have := hi m
    simp only [List.mem_filter, Bool.not_eq_true', ho, and_true] at this
    apply Classical.byContradiction
    intro hn
    exact this ⟨hm, by simpa [List.contains_iff_mem] using hn⟩ trivial

/-- **Quiescence of o-supported processing.** When no new o-supported match is pending, every
o-supported match already has its instantiation (refraction: it does not fire again). As for `quiescence_ie`, this unfolds `St.pending`. -/
theorem quiescence_pe (s : St) (pm : List Production) (ho : (s.pending pm).oAss = []) :
    ∀ m ∈ s.curMatches (pm ++ s.chunks ++ s.rlGen), m.osup = true →
      m.key ∈ (s.insts.filter (·.inMs)).map (·.key) := by
  unfold St.pending at ho
  simp only [List.filter_eq_nil_iff] at ho
  intro m hm hos
  have := ho m
  simp only [List.mem_filter, hos, and_true] at this
  apply Classical.byContradiction
  intro hn
  exact this ⟨hm, by simpa [List.contains_iff_mem] using hn⟩ trivial

/-! ## Chunking -/

/-- A literalized identity stays literalized: literalizing marks the identity's class. -/
theorem UF.find_go_par (u v : UF) (h : u.par = v.par) : ∀ n x, UF.find.go u n x = UF.find.go v n x
  | 0, _ => rfl
  | n + 1, x => by
    simp only [UF.find.go, h]
    split <;> simp [UF.find_go_par u v h n]

theorem UF.lit_isLit (u : UF) (a : Ident) : (u.lit a).isLit a = true := by
  simp only [UF.isLit, UF.lit, UF.find]
  rw [UF.find_go_par { u with lits := u.lits.insert (UF.find.go u 100000 a) } u rfl]
  simp

/-- Joining an identity with itself changes nothing. -/
theorem UF.union_self (u : UF) (a : Ident) : u.union a a = u := by
  simp [UF.union]


/-! ## Theorems added from the code review (P3) -/

/-- With the Rete off, the current matches are the matcher's (the provable half of the claim
in `St.curMatches`; that the Rete gives the same matches is checked at run time by
`--check-match`). -/
theorem curMatches_off (s : St) (pm : List Production) (h : s.reteOn = false) :
    s.curMatches pm = s.matches pm := by
  unfold St.curMatches
  simp [h]


end Soar
