import Soar.Match

/-!
# Properties of Soar's reorderer

`Reorder.order` places every condition exactly once (`order_perm`), so the reordered rule has
the conditions of the original, and `soarCondOrder` keeps the indices of the positive
conditions. -/

namespace Soar
namespace Reorder

theorem enum_fst_lt {l : List α} {x : Nat × α} (h : x ∈ l.enum) : x.1 < l.length := by
  unfold List.enum at h
  obtain ⟨⟨a, i⟩, hm, rfl⟩ := List.mem_map.mp h
  have := List.snd_lt_of_mem_zipIdx (k := 0) hm
  simpa using this

theorem foldl_set_lt (L : Nat) (f : Nat × List Nat → Nat × Nat → Nat × List Nat)
    (hf : ∀ acc x, (∀ j ∈ acc.2, j < L) → x.1 < L → ∀ j ∈ (f acc x).2, j < L) :
    ∀ (l : List (Nat × Nat)) (acc : Nat × List Nat), (∀ j ∈ acc.2, j < L) → (∀ x ∈ l, x.1 < L) →
      ∀ j ∈ (l.foldl f acc).2, j < L
  | [], acc, h, _ => h
  | x :: l, acc, h, hl =>
    foldl_set_lt L f hf l (f acc x) (hf acc x h (hl x (by simp))) (fun y hy => hl y (by simp [hy]))

theorem choose_lt (rank : Sym → Nat) (multi : List (String × Nat)) (bound roots : List String)
    (rest : List Item) (h : rest ≠ []) : choose rank multi bound roots rest < rest.length := by
  have hlen : 0 < rest.length := List.length_pos_iff.2 h
  unfold choose
  simp only []
  -- the set of tied indices
  generalize hS : (rest.enum.map fun (j, c) => (j, c.cost multi bound roots)).foldl
    (fun (acc : Nat × List Nat) (j, c) =>
      if acc.2.isEmpty || c < acc.1 then (c, [j])
      else if c == acc.1 then (acc.1, j :: acc.2) else acc) (0, []) = S
  have hSlt : ∀ j ∈ S.2, j < rest.length := by
    rw [← hS]
    refine foldl_set_lt rest.length _ ?_ _ (0, []) (by simp) ?_
    · intro acc x hacc hx j hj
      dsimp only at hj
      split at hj
      · simp at hj; omega
      · split at hj
        · simp at hj; rcases hj with h | h
          · omega
          · exact hacc j h
        · exact hacc j hj
    · intro x hx
      simp only [List.mem_map] at hx
      obtain ⟨⟨j, c⟩, hjc, rfl⟩ := hx
      exact enum_fst_lt hjc
  obtain ⟨minC, set⟩ := S
  simp only [] at hSlt ⊢
  cases set with
  | nil => exact hlen
  | cons j₀ tl =>
    cases tl with
    | nil => exact hSlt j₀ (by simp)
    | cons j₁ tl' =>
      have hsub : ∀ k ∈ (j₀ :: j₁ :: tl'), k < rest.length := hSlt
      have hj₀ : j₀ < rest.length := hSlt j₀ (by simp)
      by_cases hm : minC > 1
      · dsimp only; rw [if_pos hm]
        have key : ∀ (l : List Nat) (acc : Option (Nat × Nat)), (∀ k ∈ l, k < rest.length) →
            (∀ a, acc = some a → a.1 < rest.length) →
            ∀ a, (l.foldl (fun (acc : Option (Nat × Nat)) j =>
              let c := (let b := bound ++ (rest[j]!).vars
                (rest.enum.filter (·.1 != j)).foldl (fun m (_, c) => min m (c.cost multi b roots)) (maxCost + 1))
              match acc with
              | none => some (j, c)
              | some (bj, bc) =>
                if c < bc then some (j, c)
                else if c == bc && (rest[j]!).isPos && greater rank (rest[bj]!) (rest[j]!) then some (j, c)
                else acc) acc) = some a → a.1 < rest.length := by
          intro l
          induction l with
          | nil => intro acc _ hacc a ha; exact hacc a ha
          | cons x l ih =>
            intro acc hl hacc a ha
            refine ih _ (fun k hk => hl k (by simp [hk])) ?_ a ha
            intro a' ha'
            have hx : x < rest.length := hl x (by simp)
            dsimp only at ha'
            split at ha'
            · simp at ha'; subst ha'; exact hx
            · rename_i bj bc
              split at ha'
              · simp at ha'; subst ha'; exact hx
              · split at ha'
                · simp at ha'; subst ha'; exact hx
                · exact hacc a' ha'
        cases hr : ((j₀ :: j₁ :: tl').foldl (fun (acc : Option (Nat × Nat)) j =>
              let c := (let b := bound ++ (rest[j]!).vars
                (rest.enum.filter (·.1 != j)).foldl (fun m (_, c) => min m (c.cost multi b roots)) (maxCost + 1))
              match acc with
              | none => some (j, c)
              | some (bj, bc) =>
                if c < bc then some (j, c)
                else if c == bc && (rest[j]!).isPos && greater rank (rest[bj]!) (rest[j]!) then some (j, c)
                else acc) none) with
        | none => simpa using hj₀
        | some a =>
          simp only [Option.map_some, Option.getD_some]
          exact key _ none hsub (by simp) a hr
      · dsimp only; rw [if_neg hm]
        have key : ∀ (l : List Nat) (bj : Nat), (∀ k ∈ l, k < rest.length) → bj < rest.length →
            (l.foldl (fun bj j =>
              if (rest[j]!).isPos && (rest[bj]!).isPos && greater rank (rest[bj]!) (rest[j]!) then j
              else if !(rest[j]!).isPos && (rest[bj]!).isPos then j else bj) bj) < rest.length := by
          intro l
          induction l with
          | nil => intro bj _ h; exact h
          | cons x l ih =>
            intro bj hl hb
            refine ih _ (fun k hk => hl k (by simp [hk])) ?_
            have hx : x < rest.length := hl x (by simp)
            dsimp only
            split
            · exact hx
            · split
              · exact hx
              · exact hb
        exact key _ j₀ hsub hj₀


theorem perm_eraseIdx {α : Type} [Inhabited α] : ∀ (l : List α) (i : Nat), i < l.length →
    l.Perm (l[i]! :: l.eraseIdx i)
  | [], i, h => by simp at h
  | x :: l, 0, _ => by simp
  | x :: l, i + 1, h => by
    have ih := perm_eraseIdx l i (by simpa using h)
    simp only [List.eraseIdx_cons_succ, List.getElem!_cons_succ]
    exact ((List.Perm.cons x ih).trans (List.Perm.swap _ _ _))

/-- `order` places every condition once: its result is the placed conditions followed by the
conditions to place, in some order. -/
theorem orderGo_perm (rank : Sym → Nat) (multi : List (String × Nat)) :
    ∀ (n : Nat) (roots bound : List String) (rest acc : List Item), rest.length ≤ n →
      (orderGo rank multi n roots bound rest acc).Perm (acc ++ rest)
  | 0, roots, bound, rest, acc, h => by
    have : rest = [] := List.length_eq_zero_iff.1 (by omega)
    subst this; simp [orderGo]
  | n + 1, roots, bound, [], acc, _ => by simp [orderGo]
  | n + 1, roots, bound, x :: xs, acc, h => by
    have hlt := choose_lt rank multi bound roots (x :: xs) (by simp)
    simp only [orderGo]
    refine (orderGo_perm rank multi n _ _ _ _ ?_).trans ?_
    · rw [List.length_eraseIdx_of_lt hlt]; simp at h ⊢; omega
    · have := perm_eraseIdx (x :: xs) (choose rank multi bound roots (x :: xs)) hlt
      have h2 := List.Perm.append_left acc this.symm
      simpa [List.append_assoc] using h2

theorem order_perm (rank : Sym → Nat) (multi : List (String × Nat)) (roots bound : List String)
    (rest : List Item) : (order rank multi roots bound rest []).Perm rest := by
  simpa [order] using orderGo_perm rank multi rest.length roots bound rest [] (Nat.le_refl _)


/-- The indices of the positive conditions among the items. -/
def posIdx : List Item → List Nat
  | [] => []
  | .pos i _ :: t => i :: posIdx t
  | .neg _ _ :: t => posIdx t

theorem posIdx_append (a b : List Item) : posIdx (a ++ b) = posIdx a ++ posIdx b := by
  induction a with
  | nil => rfl
  | cons x a ih => cases x <;> simp [posIdx, ih]

theorem posIdx_perm {a b : List Item} (h : a.Perm b) : (posIdx a).Perm (posIdx b) := by
  induction h with
  | nil => exact List.Perm.refl _
  | cons x _ ih => cases x <;> simp [posIdx, ih, List.Perm.cons]
  | swap x y l => cases x <;> cases y <;> simp [posIdx] <;> first | exact List.Perm.refl _ | exact List.Perm.swap _ _ _
  | trans _ _ ih1 ih2 => exact ih1.trans ih2

/-- The number of positive conditions in a numbered list of conditions. -/
def cntPos : List (Nat × Cond) → Nat
  | [] => 0
  | (_, .pos _) :: t => cntPos t + 1
  | _ :: t => cntPos t

theorem itemFold (simp : List (Nat × Pat)) (posVars : List String) (m : Nat)
    (hs : simp.map (·.1) = List.range m) :
    ∀ (l : List (Nat × Cond)) (acc : List Item) (n : Nat), n + cntPos l ≤ m →
      (l.foldl (itemStep simp posVars) (acc, n)).2 = n + cntPos l ∧
      posIdx (l.foldl (itemStep simp posVars) (acc, n)).1 = posIdx acc ++ List.range' n (cntPos l)
  | [], acc, n, _ => by simp [cntPos]
  | (k, c) :: t, acc, n, h => by
    cases c with
    | pos q =>
      have hn : n < m := by simp [cntPos] at h; omega
      have hget : ∃ p, simp[n]? = some (n, p) := by
        have h1 : (simp.map (·.1))[n]? = some n := by rw [hs]; simp [hn]
        rw [List.getElem?_map] at h1
        cases hsn : simp[n]? with
        | none => simp [hsn] at h1
        | some y => simp [hsn] at h1; exact ⟨y.2, by rw [← h1]⟩
      obtain ⟨p, hp⟩ := hget
      have ih := itemFold simp posVars m hs t (acc ++ [.pos n p]) (n + 1) (by simp [cntPos] at h ⊢; omega)
      simp only [List.foldl_cons, itemStep, hp] at ih ⊢
      refine ⟨by simpa [cntPos, Nat.add_assoc, Nat.add_comm 1] using ih.1, ?_⟩
      rw [ih.2, posIdx_append]
      simp [posIdx, cntPos, List.range'_succ, Nat.add_comm 1, Nat.add_assoc]
    | neg qs =>
      have ih := itemFold simp posVars m hs t (acc ++ [Item.neg (((Cond.neg qs).pats.flatMap fun q => q.eqVars ++ q.useVars).filter posVars.contains).eraseDups k]) n (by simpa [cntPos] using h)
      simp only [List.foldl_cons, itemStep] at ih ⊢
      refine ⟨by simpa [cntPos] using ih.1, ?_⟩
      rw [ih.2, posIdx_append]; simp [posIdx, cntPos]
    | ncc a b =>
      have ih := itemFold simp posVars m hs t (acc ++ [Item.neg (((Cond.ncc a b).pats.flatMap fun q => q.eqVars ++ q.useVars).filter posVars.contains).eraseDups k]) n (by simpa [cntPos] using h)
      simp only [List.foldl_cons, itemStep] at ih ⊢
      refine ⟨by simpa [cntPos] using ih.1, ?_⟩
      rw [ih.2, posIdx_append]; simp [posIdx, cntPos]
    | nccg a =>
      have ih := itemFold simp posVars m hs t (acc ++ [Item.neg (((Cond.nccg a).pats.flatMap fun q => q.eqVars ++ q.useVars).filter posVars.contains).eraseDups k]) n (by simpa [cntPos] using h)
      simp only [List.foldl_cons, itemStep] at ih ⊢
      refine ⟨by simpa [cntPos] using ih.1, ?_⟩
      rw [ih.2, posIdx_append]; simp [posIdx, cntPos]


theorem stripFold_idx : ∀ (l : List (Nat × Pat)) (acc : List (Term × STest) × List (Nat × Pat)),
    ((l.foldl stripStep acc).2).map (·.1) = acc.2.map (·.1) ++ l.map (·.1)
  | [], acc => by simp
  | x :: l, acc => by
    rw [List.foldl_cons, stripFold_idx l]
    obtain ⟨i, p⟩ := x
    simp [stripStep]

theorem restoreFold_idx : ∀ (l : List (Nat × Pat)) (acc : List (Nat × Pat) × List String × List (Term × STest)),
    ((l.foldl restoreStep acc).1).map (·.1) = acc.1.map (·.1) ++ l.map (·.1)
  | [], acc => by simp
  | x :: l, acc => by
    rw [List.foldl_cons, restoreFold_idx l]
    obtain ⟨i, p⟩ := x
    simp [restoreStep]

theorem dropDummies_idx (ps : List (Nat × Pat)) : (dropDummies ps).map (·.1) = ps.map (·.1) := by
  simp [dropDummies, Function.comp_def]

theorem restore_idx (saved : List (Term × STest)) (ps : List (Nat × Pat)) :
    (restore saved ps).map (·.1) = ps.map (·.1) := by
  simp [restore, restoreFold_idx]

theorem stripPats_idx (pos : List (Nat × Pat)) : ((stripPats pos).2).map (·.1) = pos.map (·.1) := by
  simp [stripPats, stripFold_idx]

theorem cntPos_eq : ∀ (l : List (Nat × Cond)), cntPos l = (positives (l.map (·.2))).length
  | [] => rfl
  | (k, c) :: t => by cases c <;> simp [cntPos, positives, cntPos_eq t]

theorem enum_map_snd (l : List α) : l.enum.map (·.2) = l := by
  simp [List.enum, Function.comp_def]

theorem enum_map_fst (l : List α) : l.enum.map (·.1) = List.range l.length := by
  simp [List.enum, Function.comp_def, List.range_eq_range']

theorem posPairs_idx : ∀ (l : List Item), ((l.filterMap fun it => match it with
    | .pos i p => some (i, p)
    | .neg _ _ => none).map (·.1)) = posIdx l
  | [] => rfl
  | x :: t => by cases x <;> simp [posIdx, List.filterMap_cons, posPairs_idx t]

end Reorder

open Reorder in
/-- **Soar's reorderer places every positive condition once**: the indices of the positive
conditions in `soarOrder` are a permutation of those of the rule's positive conditions, so
no condition is lost or repeated (the order and the places of the tests may differ from the
rule's). -/
theorem soarOrder_idx_perm (rank : Sym → Nat) (multi : List (String × Nat)) (cs : List Cond) :
    ((soarOrder rank multi cs).map (·.1)).Perm (List.range (positives cs).length) := by
  unfold soarOrder soarCondOrder
  generalize hst : stripPats (positives cs).enum = st
  obtain ⟨saved, simp⟩ := st
  have hsimp : simp.map (·.1) = List.range (positives cs).length := by
    have := stripPats_idx (positives cs).enum
    rw [hst] at this; simp only [] at this
    rw [this, enum_map_fst]
  simp only [hst]
  generalize hitems : buildItems simp (simp.flatMap fun (_, p) => p.eqVars) cs = items
  have hpos : posIdx items = List.range (positives cs).length := by
    have := (itemFold simp (simp.flatMap fun (_, p) => p.eqVars) (positives cs).length hsimp
      cs.enum [] 0 (by rw [cntPos_eq, enum_map_snd]; omega)).2
    rw [← hitems]; unfold buildItems
    rw [this, cntPos_eq, enum_map_snd]; simp [posIdx, List.range_eq_range']
  generalize hord : order rank multi _ [] items [] = ordered
  have hperm : ordered.Perm items := hord ▸ order_perm rank multi _ [] items
  have hordpos : (posIdx ordered).Perm (List.range (positives cs).length) :=
    hpos ▸ posIdx_perm hperm
  -- the restored list has the indices of the ordered positive conditions
  generalize hrest : dropDummies (restore saved (ordered.filterMap fun it => match it with
    | .pos i p => some (i, p)
    | .neg _ _ => none)) = restored
  have hidx : restored.map (·.1) = posIdx ordered := by
    rw [← hrest, dropDummies_idx, restore_idx]; exact posPairs_idx ordered
  have key : ∀ (l : List Item), (∀ i ∈ posIdx l, i ∈ restored.map (·.1)) →
      (((l.filterMap fun it => match it with
        | .pos i _ => (restored.find? (·.1 == i)).map fun (_, p) => (some i, Cond.pos p)
        | .neg _ k => cs[k]?.map (none, ·)).filterMap fun (i, c) => match i, c with
          | some i, .pos p => some (i, p)
          | _, _ => none).map (·.1)) = posIdx l := by
    intro l
    induction l with
    | nil => intro _; rfl
    | cons x t ih =>
      intro h
      cases x with
      | neg r k =>
        have := ih (fun i hi => h i (by simpa [posIdx] using hi))
        cases hk : cs[k]? <;> simp [posIdx, List.filterMap_cons, hk, this]
      | pos i p =>
        have hi : i ∈ restored.map (·.1) := h i (by simp [posIdx])
        obtain ⟨y, hy, hyi⟩ := List.mem_map.1 hi
        have hf : (restored.find? (·.1 == i)).isSome := by
          rw [List.find?_isSome]; exact ⟨y, hy, by simp [hyi]⟩
        obtain ⟨z, hz⟩ := Option.isSome_iff_exists.1 hf
        have hz1 : z.1 = i := by
          have := List.find?_some hz; simpa using this
        have := ih (fun j hj => h j (by simp [posIdx, hj]))
        obtain ⟨zi, zp⟩ := z
        simp [posIdx, List.filterMap_cons, hz, this, hz1]
  have hk := key ordered (by intro i hi; rw [hidx]; exact hi)
  exact Eq.subst (motive := fun l => l.Perm (List.range (positives cs).length)) hk.symm hordpos

end Soar

