import Soar.Match
import Std.Data.HashMap
import Std.Data.TreeSet
import Std.Data.TreeMap

/-!
# The order of Soar 9.6.5's Rete

Soar's matcher is a Rete network (rete.cpp). Which matches exist does not depend on it — the
model's matcher (`St.matches`) computes them — but the order in which new matches are taken
does. Soar puts each new match at the head of its state's assertion list when the network
reaches the production node (`p_node_left_addition`), and the preference phase takes matches
from the head (`postpone_assertion`), so the matches of one pass fire newest first. Which match
the network reaches last follows the structure of the network and its memories:

* the network: one node per condition of a rule, in the order Soar's reorderer gives them,
  shared between rules whose conditions agree up to that point (same alpha memory, same tests
  on the same earlier fields); a beta memory merged with its single join (MP node) is split
  when a second join is added under it; negated conjunctions have a CN node and a partner;
* every memory is a list with the newest entry first: alpha memories (`right_mems`), beta
  memories (`tokens`), each element's tokens, each token's children, each node's children;
* right and left unlinking: a join is unlinked from its alpha memory while its beta memory is
  empty and from its beta memory while its alpha memory is empty; it is linked again in front
  of its nearest linked ancestor on the same alpha memory (or at the end), or at the head of
  its beta memory's list — so the order in which an alpha memory activates its joins changes
  as memories empty and fill;
* a new alpha memory is filled from all elements in the Rete, newest first, each put at the
  head, so its oldest element comes first;
* an element is added to the alpha memories of the eight tables in Soar's fixed order.

This file models those structures and their algorithms, following rete.cpp function by
function (names in the comments). It records, for each current match of each rule, the number
of the step at which the network last reached its production node, and for each match removed
the step of its removal; `St.reteOrder` orders new matches and retractions by them. Tests are
evaluated on Soar's variable locations (levels up, field), as the Rete does, so that rules with
different variable names share nodes. Memories are sets of sequence numbers (newer entries
have larger numbers, so a list newest first is the set in descending order), with indexes by
referent and by identifier standing for Soar's two hash tables.

The elements enter in the order Soar makes them: the model numbers new elements as Soar does
(`St.soarRetag`), so additions are taken newest first, and removals in the reverse of the
order Soar queues them (`St.pushOrder`). Rules enter in the order they are loaded, learned rules
when they are learned, with their conditions in Soar's order (`soarCondOrder`, `placeGoals`).

NOT MODELED: justifications are not added to the network (they share and split nodes in
Soar; no effect on the order of matches was found: 300 programs in which later matches share
condition prefixes with a justification, `tests/justfuzz`, all agree with Soar 9.6.5); changes from more than one of Soar's batches (the output phase's memory results, the
next input) are brought in together, at the next elaboration cycle (600 programs built to
expose an effect on the order of matches, `tests/batchfuzz`, `batchfuzz2`, `3`, `4e` and `4s`,
agree with Soar 9.6.5; they found instead that the order in which semantic memory creates a
retrieval's elements was wrong, now fixed); the network's size is
limited (`reteTokenLimit`).
-/

namespace Soar
namespace Rete

/-- A reference in a test: a field of an element some levels up the token, or a constant. -/
inductive LRef where
  | loc : Nat → Nat → LRef
  | sym : Sym → LRef
  deriving BEq, Repr, Inhabited

/-- A Rete test on a field of the element being joined (Soar's `rete_test`). -/
inductive LTest where
  | eq : Nat → LRef → LTest
  | rel : Nat → RelOp → LRef → LTest
  | disj : Nat → List Sym → LTest
  | goal : LTest
  | lti : Nat → Bool → LTest
  | ltiRel : Nat → Bool → LRef → LTest
  deriving BEq, Repr, Inhabited

/-- An alpha memory's constant tests (identifier tests are never constants in rules). -/
structure AMKey where
  attr : Option Sym
  val  : Option Sym
  acc  : Bool
  deriving BEq, Hashable, Repr, Inhabited

/-- A set of token or sequence numbers; Soar's lists put the newest entry first, and newer
entries have larger numbers, so a list is the set in descending order. -/
abbrev TS := Std.TreeSet Nat compare

def desc (t : TS) : List Nat := t.toList.reverse

inductive Kind where
  | dummy | mem | pos | mp | neg | cn | cnp | p
  deriving BEq, Repr, Inhabited

structure Node where
  kind     : Kind
  parent   : Nat := 0
  /-- `first_child` list, newest first. -/
  children : List Nat := []
  /-- Beta memory: its linked join children (`first_linked_child`). -/
  linked   : List Nat := []
  am       : Nat := 0
  tests    : List LTest := []
  /-- The hashed variable location (levels up, field) of a beta memory, MP or negative node. -/
  hash     : Option (Nat × Nat) := none
  nearest  : Option Nat := none
  rUnl     : Bool := false
  lUnl     : Bool := false
  tokens   : TS := {}
  partner  : Nat := 0
  prod     : Nat := 0
  deriving Repr, Inhabited

structure AM where
  key   : AMKey
  /-- Its elements, by the sequence numbers of their entries (newest first; `Net.rmTT`). -/
  seqs  : TS := {}
  /-- Linked successor joins and negative nodes (`beta_nodes`), in Soar's order. -/
  beta  : List Nat := []
  deriving Repr, Inhabited

structure Tok where
  node     : Nat
  parent   : Option Nat
  w        : Option Nat
  children : TS := {}
  negrm    : List Nat := []
  left     : Option Nat := none
  /-- The hashed referent of a token of a hashed node. -/
  ref      : Option Sym := none
  /-- The match key of a token of a production node, made when the token is (S21 in the code
  review: `pLeft` reads the keys of the node's other tokens). -/
  key      : Option (String × List Nat) := none
  deriving Repr, Inhabited

/-- A rule in the network: its name and, per top-level condition depth, the index among the
rule's positive conditions of the condition at that depth (none for a negation). -/
structure PInfo where
  name   : String
  depths : List (Option Nat)
  /-- Whether the rule's support is undeclared, so that its matches' support is classified from
  the production's other matches (`p_node_left_addition`). -/
  needSup : Bool := true
  deriving Repr, Inhabited

/-- A condition as the Rete builds it. -/
inductive RC where
  | pos : Pat → RC
  | neg : Pat → RC
  | ncc : List RC → RC
  deriving Inhabited

structure Net where
  inited : Bool := false
  nodes  : Array Node := #[{ kind := .dummy, tokens := ({} : TS).insert 0 }]
  ams    : Array AM := #[]
  amIx   : Std.HashMap AMKey Nat := {}
  toks   : Std.HashMap Nat Tok := ({} : Std.HashMap Nat Tok).insert 0 { node := 0, parent := none, w := none }
  tNext  : Nat := 1
  wm     : Std.HashMap Nat WME := {}
  wTok   : Std.HashMap Nat TS := {}
  /-- The tokens of a hashed node by referent (Soar's left hash table). -/
  refIx  : Std.HashMap (Nat × Sym) TS := {}
  /-- Alpha-memory entries: each entry's element, an entry by memory and element, and the
  entries of a memory by identifier (Soar's right hash table). -/
  rmTT   : Std.HashMap Nat Nat := {}
  rmSeq  : Std.HashMap (Nat × Nat) Nat := {}
  rmId   : Std.HashMap (Nat × Nat) TS := {}
  rmNext : Nat := 1
  wAm    : Std.HashMap Nat (List Nat) := {}
  /-- The timetags of all elements, by the order they were added (a counter, not the
  timetag), with that counter for each timetag, so a removal does not scan the list. -/
  allW   : Std.TreeMap Nat Nat := {}
  allIx  : Std.HashMap Nat Nat := {}
  allN   : Nat := 0
  prods  : Array PInfo := #[]
  names  : Std.HashSet String := {}
  /-- For each current match (rule name, timetags of its positive conditions in the rule's
  order), the step at which it last reached its production node. -/
  live   : Std.HashMap (String × List Nat) Nat := {}
  /-- For each match removed, the step at which it was removed. -/
  gone   : Std.HashMap (String × List Nat) Nat := {}
  /-- The size of `gone` at which it is next pruned (twice its size after the last pruning, so
  that pruning a record that stays large is not repeated every cycle). -/
  goneCap : Nat := 4096
  step   : Nat := 0
  /-- The step at which `St.reteCache` last brought the cached matches up to date (S22 in the
  code review): nothing to do while `step` has not moved. -/
  cached : Nat := 0
  /-- For each match added since the model last read them, the matches of its production when
  the network reached its production node: the timetags of each of the production node's
  tokens, newest first (the new match first), as `p_node_left_addition` walks them to classify
  the match's support. -/
  sup    : Std.HashMap (String × List Nat) (List (List Nat)) := {}
  goals  : List Nat := []
  ltis   : List (Nat × Nat) := []
  /-- The letter code of each identifier (`Binding.letter`), kept only when a rule has an ordering
  test between identifiers (`Production.usesOrd`). -/
  letters : Std.HashMap Nat Nat := {}
  /-- New matches the model found that the Rete did not have (should stay 0), with examples. -/
  misses : Nat := 0
  missEx : List String := []

instance : Repr Net := ⟨fun n _ => s!"<rete: {n.nodes.size} nodes, {n.ams.size} alpha memories, {n.toks.size} tokens, {n.live.size} matches>"⟩
instance : Inhabited Net := ⟨{}⟩

abbrev M := StateM Net

def gN (i : Nat) : M Node := return (← get).nodes[i]!
def mN (i : Nat) (f : Node → Node) : M Unit := modify fun n => { n with nodes := n.nodes.modify i f }
def gA (i : Nat) : M AM := return (← get).ams[i]!
def mA (i : Nat) (f : AM → AM) : M Unit := modify fun n => { n with ams := n.ams.modify i f }
def gT (t : Nat) : M Tok := return ((← get).toks.get? t).getD default
def mT (t : Nat) (f : Tok → Tok) : M Unit :=
  modify fun n => match n.toks.get? t with
    | some x => { n with toks := n.toks.insert t (f x) }
    | none => n
def gW (tt : Nat) : M WME := return ((← get).wm.get? tt).getD default

def tsIns {α : Type} [BEq α] [Hashable α] (m : Std.HashMap α TS) (k : α) (x : Nat) : Std.HashMap α TS :=
  m.insert k ((m.getD k {}).insert x)
def tsDel {α : Type} [BEq α] [Hashable α] (m : Std.HashMap α TS) (k : α) (x : Nat) : Std.HashMap α TS :=
  match m.get? k with
  | some (t : TS) => let t := t.erase x; if t.isEmpty then m.erase k else m.insert k t
  | none => m

/-- Put an element into an alpha memory, at the head (`add_wme_to_alpha_mem`). -/
def amAdd (a : Nat) (tt : Nat) (w : WME) : M Unit := do
  let n ← get
  let q := n.rmNext
  set { n with rmNext := q + 1, rmTT := n.rmTT.insert q tt, rmSeq := n.rmSeq.insert (a, tt) q,
               rmId := tsIns n.rmId (a, w.id) q, wAm := n.wAm.insert tt (a :: (n.wAm.getD tt [])),
               ams := n.ams.modify a fun am => { am with seqs := am.seqs.insert q } }

def amDel (a : Nat) (tt : Nat) (w : WME) : M Unit := do
  let n ← get
  match n.rmSeq.get? (a, tt) with
  | none => pure ()
  | some q =>
    set { n with rmTT := n.rmTT.erase q, rmSeq := n.rmSeq.erase (a, tt), rmId := tsDel n.rmId (a, w.id) q,
                 ams := n.ams.modify a fun am => { am with seqs := am.seqs.erase q } }

/-- An alpha memory's elements, newest first; with a referent, those whose identifier it is
(the right hash table's bucket). -/
def amElems (a : Nat) (ref : Option Sym) : M (List Nat) := do
  let n ← get
  let qs := match ref with
    | none => desc n.ams[a]!.seqs
    | some (.id i) => desc (n.rmId.getD (a, i) {})
    | some _ => []
  return qs.filterMap n.rmTT.get?

def amEmpty (a : Nat) : M Bool := return (← gA a).seqs.isEmpty

/-- A node's tokens, newest first; for a hashed node, those with referent `r`. -/
def nodeToks (node : Nat) (r : Option Sym) : M (List Nat) := do
  match r with
  | none => return desc (← gN node).tokens
  | some r => return desc ((← get).refIx.getD (node, r) {})

/-- Move tokens to another node (splitting or merging an MP node), keeping their referents. -/
def moveToks (ts : TS) (src dst : Nat) : M Unit := do
  for t in desc ts do
    let x ← gT t
    mT t fun y => { y with node := dst }
    if let some r := x.ref then
      modify fun n => { n with refIx := tsIns (tsDel n.refIx (src, r) t) (dst, r) t }

def fieldSym (w : WME) : Nat → Sym
  | 0 => .id w.id
  | 1 => w.attr
  | _ => w.val

/-- The element `up` levels up from token `t` (`up ≥ 1`: `t`'s own element, then its
parent's, …). -/
partial def tokWme (t : Nat) (up : Nat) : M (Option WME) := do
  let x ← gT t
  if up ≤ 1 then match x.w with
    | some tt => return some (← gW tt)
    | none => return none
  else match x.parent with
    | some p => tokWme p (up - 1)
    | none => return none

def refSym (t : Nat) (w : WME) : LRef → M (Option Sym)
  | .sym s => return some s
  | .loc 0 f => return some (fieldSym w f)
  | .loc up f => return (← tokWme t up).map (fieldSym · f)

def ltiOfSym (s : Sym) : M (Option Nat) := do
  match s with
  | .id n => return ((← get).ltis.find? (·.1 == n)).map (·.2)
  | _ => return none

def testOk (t : Nat) (w : WME) : LTest → M Bool
  | .eq f r => return (← refSym t w r) == some (fieldSym w f)
  | .rel f op r => do
    match ← refSym t w r with
    | some x => do
      let ls := (← get).letters
      return op.holdsL (fun n => ls.getD n 0) (fieldSym w f) x
    | none => return false
  | .disj f cs => return cs.contains (fieldSym w f)
  | .goal => return (← get).goals.contains w.id
  | .lti f pos => return (← ltiOfSym (fieldSym w f)).isSome == pos
  | .ltiRel f pos r => do
    let a ← ltiOfSym (fieldSym w f)
    match r with
    | .sym (.int c) => return (a.isSome && a == some c.toNat) == pos
    | .sym _ => return !pos
    | r => match ← refSym t w r with
      | some x => do let b ← ltiOfSym x; return (a.isSome && a == b) == pos
      | none => return false

def testsOk (t : Nat) (w : WME) (ts : List LTest) : M Bool := do
  for x in ts do
    if !(← testOk t w x) then return false
  return true

/-- The hashed referent for a new token `(tok, w)` of a node hashed at `(up, f)`
(`beta_memory_node_left_addition`): `up = 1` is `w`, else `up - 1` levels above `tok`'s
element… -/
def hashRef (h : Option (Nat × Nat)) (tok : Nat) (w : Option Nat) : M (Option Sym) := do
  match h with
  | none => return none
  | some (up, f) =>
    if up == 1 then match w with
      | some tt => return some (fieldSym (← gW tt) f)
      | none => return none
    else return (← tokWme tok (up - 1)).map (fieldSym · f)

/-- `new_left_token`: in the node's tokens, the parent's children and the element's tokens,
each at the head. -/
def newTok (node : Nat) (parent : Nat) (w : Option Nat) (ref : Option Sym := none) : M Nat := do
  let n ← get
  let t := n.tNext
  set { n with tNext := t + 1, toks := n.toks.insert t { node := node, parent := some parent, w := w, ref := ref } }
  mN node fun x => { x with tokens := x.tokens.insert t }
  mT parent fun x => { x with children := x.children.insert t }
  if let some tt := w then
    modify fun n => { n with wTok := tsIns n.wTok tt t }
  if let some r := ref then
    modify fun n => { n with refIx := tsIns n.refIx (node, r) t }
  return t

/-- `relink_to_right_mem`: before the nearest linked ancestor on the same alpha memory, or at
the end. -/
partial def relinkRight (node : Nat) : M Unit := do
  let x ← gN node
  let rec anc (a : Option Nat) : M (Option Nat) := do
    match a with
    | none => return none
    | some i => let y ← gN i; if y.rUnl then anc y.nearest else return some i
  let a ← anc x.nearest
  mA x.am fun am =>
    let b := am.beta.erase node
    match a with
    | some i => match b.idxOf? i with
      | some k => { am with beta := b.insertIdx k node }
      | none => { am with beta := b ++ [node] }
    | none => { am with beta := b ++ [node] }
  mN node fun y => { y with rUnl := false }

def unlinkRight (node : Nat) : M Unit := do
  let x ← gN node
  mA x.am fun am => { am with beta := am.beta.erase node }
  mN node fun y => { y with rUnl := true }

def relinkLeft (node : Nat) : M Unit := do
  let x ← gN node
  mN x.parent fun p => { p with linked := node :: p.linked.erase node }
  mN node fun y => { y with lUnl := false }

def unlinkLeft (node : Nat) : M Unit := do
  let x ← gN node
  mN x.parent fun p => { p with linked := p.linked.erase node }
  mN node fun y => { y with lUnl := true }

/-- The element (timetag) for each positive condition of a production token, by the rule's
positive-condition index. -/
partial def matchKey (pn : Nat) (tok : Nat) (w : Option Nat) : M (String × List Nat) := do
  let n ← get
  let x ← gN pn
  let info := n.prods[x.prod]!
  let d := info.depths.length
  -- the element at depth d is w; at depth k < d it is (d - k - 1) levels up from tok
  let rec walk (t : Option Nat) (k : Nat) (acc : List (Option Nat)) : M (List (Option Nat)) := do
    if k == 0 then return acc else
    match t with
    | none => return acc
    | some t' => let y ← gT t'; walk y.parent (k - 1) (y.w :: acc)
  let above ← walk (some tok) (d - 1) []
  let ws := above ++ [w]
  let pairs := (info.depths.zip ws).filterMap fun (i, w) => match i, w with
    | some i, some tt => some (i, tt)
    | _, _ => none
  return (info.name, (pairs.mergeSort (fun a b => a.1 ≤ b.1)).map (·.2))

mutual

/-- The join of a new token `t` with the elements of the node's alpha memory: each element that
passes the node's tests is passed on to the children (shared by `positive_node_left_addition`
and `mp_node_left_addition`). -/
partial def joinLeft (node : Nat) (x : Node) (t : Nat) (ref : Option Sym) : M Unit := do
  for rm in ← amElems x.am ref do
    let w ← gW rm
    if ← testsOk t w x.tests then
      for c in (← gN node).children do
        leftAdd c t (some rm)

/-- The join of a new element `wt` with the tokens `toks` of the node's left input: each token that
passes the node's tests is passed on to the children (shared by `positive_node_right_addition`
and `mp_node_right_addition`). -/
partial def joinRight (node : Nat) (tests : List LTest) (toks : List Nat) (wt : Nat) (w : WME) : M Unit := do
  for t in toks do
    if ← testsOk t w tests then
      for c in (← gN node).children do
        leftAdd c t (some wt)

/-- Left activation of `child` with token `tok` and element `w` (`left_addition_routines`). -/
partial def leftAdd (child : Nat) (tok : Nat) (w : Option Nat) : M Unit := do
  let x ← gN child
  match x.kind with
  | .mem => memLeft child tok w
  | .mp => mpLeft child tok w
  | .neg => negLeft child tok w
  | .cn => cnLeft child tok w
  | .cnp => cnpLeft child tok w
  | .p => pLeft child tok w
  | _ => pure ()

/-- `beta_memory_node_left_addition`. -/
partial def memLeft (node : Nat) (tok : Nat) (w : Option Nat) : M Unit := do
  let x ← gN node
  let ref ← hashRef x.hash tok w
  let t ← newTok node tok w ref
  -- the list of linked children is taken before the calls (`next` in Soar)
  for c in (← gN node).linked do
    posLeft c t ref

/-- `positive_node_left_addition` (hashed or not). -/
partial def posLeft (node : Nat) (t : Nat) (ref : Option Sym) : M Unit := do
  let x ← gN node
  if x.rUnl then
    relinkRight node
    if ← amEmpty x.am then
      unlinkLeft node
      return
  joinLeft node x t ref

/-- `mp_node_left_addition`. -/
partial def mpLeft (node : Nat) (tok : Nat) (w : Option Nat) : M Unit := do
  let x ← gN node
  let ref ← hashRef x.hash tok w
  let t ← newTok node tok w ref
  if x.lUnl then return
  if x.rUnl then
    relinkRight node
    if ← amEmpty x.am then
      mN node fun y => { y with lUnl := true }
      return
  joinLeft node x t ref

/-- `negative_node_left_addition`. -/
partial def negLeft (node : Nat) (tok : Nat) (w : Option Nat) : M Unit := do
  let x ← gN node
  if x.rUnl then relinkRight node
  let ref ← hashRef x.hash tok w
  let t ← newTok node tok w ref
  for rm in ← amElems x.am ref do
    let wm ← gW rm
    if ← testsOk t wm x.tests then
      addNegrm node t rm
  if (← gT t).negrm.isEmpty then
    for c in (← gN node).children do
      leftAdd c t none

/-- A negative node's blocking token for `left` and element `rm`. -/
partial def addNegrm (node : Nat) (left : Nat) (rm : Nat) : M Unit := do
  let n ← get
  let nt := n.tNext
  set { n with tNext := nt + 1,
               toks := n.toks.insert nt { node := node, parent := none, w := some rm, left := some left },
               wTok := tsIns n.wTok rm nt }
  mT left fun y => { y with negrm := nt :: y.negrm }

/-- `cn_node_left_addition`. -/
partial def cnLeft (node : Nat) (tok : Nat) (w : Option Nat) : M Unit := do
  for t in ← nodeToks node none do
    let y ← gT t
    if y.parent == some tok && y.w == w then return
  let t ← newTok node tok w
  for c in (← gN node).children do
    leftAdd c t none

/-- `cn_partner_node_left_addition`. -/
partial def cnpLeft (node : Nat) (tok : Nat) (w : Option Nat) : M Unit := do
  let x ← gN node
  let partner := x.partner
  let pp := (← gN partner).parent
  let negrmTok ← newTok node tok w
  -- advance (tok, w) up to the token from the top of the branch
  let mut temp := x.parent
  let mut tk := tok
  let mut ww := w
  let mut fuel := 1000
  while temp != pp && fuel > 0 do
    fuel := fuel - 1
    temp ← realParent temp
    let y ← gT tk
    ww := y.w
    tk := y.parent.getD 0
  let mut left : Option Nat := none
  for t in ← nodeToks partner none do
    let y ← gT t
    if y.parent == some tk && y.w == ww then
      left := some t
      break
  let l ← match left with
    | some l => pure l
    | none => newTok partner tk ww
  mT negrmTok fun y => { y with left := some l }
  mT l fun y => { y with negrm := negrmTok :: y.negrm }
  let mut fuel2 := 100000
  while fuel2 > 0 do
    fuel2 := fuel2 - 1
    match (← gT l).children.max? with
    | some c => removeTree c
    | none => break

/-- `real_parent_node`: a join under a split beta memory takes the memory's parent. -/
partial def realParent (i : Nat) : M Nat := do
  let x ← gN i
  if x.kind == .pos then return (← gN x.parent).parent else return x.parent

/-- `p_node_left_addition`: the match is recorded with a new step number. -/
partial def pLeft (node : Nat) (tok : Nat) (w : Option Nat) : M Unit := do
  let t0 ← newTok node tok w
  let k ← matchKey node tok w
  mT t0 fun y => { y with key := some k }
  let x ← gN node
  if (← get).prods[x.prod]!.needSup then
    let mut others : List (List Nat) := []
    for t in desc x.tokens do
      let y ← gT t
      let kk ← match y.key with
        | some kk => pure kk
        | none => matchKey node (y.parent.getD 0) y.w
      others := kk.2 :: others
    modify fun n => { n with sup := n.sup.insert k others.reverse }
  modify fun n => { n with step := n.step + 1, live := n.live.insert k (n.step + 1) }

/-- `positive_node_right_addition`. -/
partial def posRight (node : Nat) (wt : Nat) : M Unit := do
  let x ← gN node
  if x.lUnl then
    relinkLeft node
    if (← gN x.parent).tokens.isEmpty then
      unlinkRight node
      return
  let w ← gW wt
  let par ← gN x.parent
  joinRight node x.tests (← nodeToks x.parent (if par.hash.isSome then some (.id w.id) else none)) wt w

/-- `mp_node_right_addition`. -/
partial def mpRight (node : Nat) (wt : Nat) : M Unit := do
  let x ← gN node
  if x.lUnl then
    mN node fun y => { y with lUnl := false }
    if x.tokens.isEmpty then
      unlinkRight node
      return
  let w ← gW wt
  let x ← gN node
  joinRight node x.tests (← nodeToks node (if x.hash.isSome then some (.id w.id) else none)) wt w

/-- `negative_node_right_addition`. -/
partial def negRight (node : Nat) (wt : Nat) : M Unit := do
  let x ← gN node
  let w ← gW wt
  for t in ← nodeToks node (if x.hash.isSome then some (.id w.id) else none) do
    if ← testsOk t w x.tests then
      addNegrm node t wt
      let mut fuel := 100000
      while fuel > 0 do
        fuel := fuel - 1
        match (← gT t).children.max? with
        | some c => removeTree c
        | none => break

partial def rightAdd (node : Nat) (wt : Nat) : M Unit := do
  match (← gN node).kind with
  | .pos => posRight node wt
  | .mp => mpRight node wt
  | .neg => negRight node wt
  | _ => pure ()

/-- `remove_token_and_subtree`: the leftmost leaf first. -/
partial def removeTree (root : Nat) : M Unit := do
  let mut tok := root
  let mut fuel := 1000000
  while fuel > 0 do
    fuel := fuel - 1
    -- move down to the leftmost leaf
    let mut fuel2 := 100000
    while fuel2 > 0 do
      fuel2 := fuel2 - 1
      match (← gT tok).children.max? with
      | some c => tok := c
      | none => break
    let x ← gT tok
    let par := x.parent.getD 0
    -- the next sibling is the next older child
    let next : Nat := ((← gT par).children.getLT? tok).getD par
    -- common clean-up
    mN x.node fun y => { y with tokens := y.tokens.erase tok }
    mT par fun y => { y with children := y.children.erase tok }
    if let some tt := x.w then
      modify fun n => { n with wTok := tsDel n.wTok tt tok }
    if let some r := x.ref then
      modify fun n => { n with refIx := tsDel n.refIx (x.node, r) tok }
    let nd ← gN x.node
    match nd.kind with
    | .mp =>
      if !nd.lUnl && (← gN x.node).tokens.isEmpty then unlinkRight x.node
    | .p =>
      let k ← matchKey x.node par x.w
      modify fun n => { n with live := n.live.erase k, sup := n.sup.erase k, step := n.step + 1, gone := n.gone.insert k (n.step + 1) }
    | .neg =>
      if (← gN x.node).tokens.isEmpty then unlinkRight x.node
      for t in x.negrm do
        let y ← gT t
        if let some tt := y.w then
          modify fun n => { n with wTok := tsDel n.wTok tt t }
        modify fun n => { n with toks := n.toks.erase t }
    | .mem =>
      if (← gN x.node).tokens.isEmpty then
        for c in (← gN x.node).linked do
          unlinkRight c
    | .cn =>
      for t in x.negrm do
        let y ← gT t
        if let some tt := y.w then
          modify fun n => { n with wTok := tsDel n.wTok tt t }
        mN y.node fun z => { z with tokens := z.tokens.erase t }
        if let some pp := y.parent then mT pp fun z => { z with children := z.children.erase t }
        modify fun n => { n with toks := n.toks.erase t }
    | .cnp =>
      if let some l := x.left then
        mT l fun y => { y with negrm := y.negrm.erase tok }
        let ly ← gT l
        if ly.negrm.isEmpty then
          for c in (← gN ly.node).children do
            leftAdd c l none
    | _ => pure ()
    modify fun n => { n with toks := n.toks.erase tok }
    if tok == root then break
    tok := next

end

/-! ## Elements entering and leaving the network -/

/-- The alpha-memory keys an element can be in, in the order of Soar's eight tables
(`add_wme_to_rete`; identifier tests are never constants, so only four apply). -/
def keysFor (w : WME) : List AMKey :=
  [{ attr := none, val := none, acc := w.acc }, { attr := some w.attr, val := none, acc := w.acc },
   { attr := none, val := some w.val, acc := w.acc }, { attr := some w.attr, val := some w.val, acc := w.acc }]

def amMatches (k : AMKey) (w : WME) : Bool :=
  w.acc == k.acc && (k.attr.all (· == w.attr)) && (k.val.all (· == w.val))

/-- `add_wme_to_rete`. -/
partial def addWme (tt : Nat) (w : WME) : M Unit := do
  modify fun n => { n with wm := n.wm.insert tt w, allW := n.allW.insert n.allN tt, allIx := n.allIx.insert tt n.allN, allN := n.allN + 1, wAm := n.wAm.insert tt [] }
  for k in keysFor w do
    match (← get).amIx.get? k with
    | none => pure ()
    | some a =>
      amAdd a tt w
      -- the successors, each `next` taken before the call
      let mut cur : Option Nat := (← gA a).beta.head?
      let mut fuel := 100000
      while fuel > 0 do
        fuel := fuel - 1
        match cur with
        | none => break
        | some nd =>
          let b := (← gA a).beta
          let nxt := match b.idxOf? nd with
            | some k => b[k + 1]?
            | none => none
          rightAdd nd tt
          cur := nxt

/-- `remove_wme_from_rete`. -/
partial def removeWme (tt : Nat) : M Unit := do
  modify fun n => match n.allIx.get? tt with
    | some k => { n with allW := n.allW.erase k, allIx := n.allIx.erase tt }
    | none => n
  let w ← gW tt
  for a in (← get).wAm.getD tt [] do
    amDel a tt w
    let am ← gA a
    if am.seqs.isEmpty then
      for nd in am.beta do
        let x ← gN nd
        match x.kind with
        | .pos => unlinkLeft nd
        | .mp => mN nd fun y => { y with lUnl := true }
        | _ => pure ()
  modify fun n => { n with wAm := n.wAm.erase tt }
  let mut fuel := 1000000
  while fuel > 0 do
    fuel := fuel - 1
    match ((← get).wTok.getD tt {}).max? with
    | none => break
    | some t =>
      let x ← gT t
      if x.parent.isNone then
        -- a negative node's blocking token
        modify fun n => { n with wTok := tsDel n.wTok tt t, toks := n.toks.erase t }
        if let some l := x.left then
          mT l fun y => { y with negrm := y.negrm.erase t }
          if (← gT l).negrm.isEmpty then
            for c in (← gN x.node).children do
              leftAdd c l none
      else removeTree t
  modify fun n => { n with wm := n.wm.erase tt, wTok := n.wTok.erase tt }

/-! ## Building the network -/

/-- `find_or_make_alpha_mem`: a new memory is filled from a more general one, or from all
elements in the Rete, each put at the head. -/
def amFor (k : AMKey) : M Nat := do
  match (← get).amIx.get? k with
  | some a => return a
  | none =>
    let n ← get
    let a := n.ams.size
    set { n with ams := n.ams.push { key := k }, amIx := n.amIx.insert k a }
    let general : Option Nat :=
      if k.val.isSome then n.amIx.get? { k with val := none } else none
    let src : List Nat ← match general with
      | some g => amElems g none
      | none => pure (n.allW.toList.reverse.map (·.2))
    for tt in src do
      let w ← gW tt
      if amMatches k w then amAdd a tt w
    return a

/-- The Rete form of a pattern at depth `d`: its alpha memory key, its tests, the hashed
location, and the variables it binds (`make_node_for_positive_cond`, `add_rete_tests_for_test`,
`extract_rete_test_to_hash_with`). -/
def compile (vars : List (String × Nat × Nat)) (d : Nat) (p : Pat) :
    AMKey × List LTest × Option (Nat × Nat) × List (String × Nat × Nat) := Id.run do
  let fields : List (Nat × Test) := [(0, p.id), (1, p.attr), (2, p.val)]
  -- bind the equality variables first
  let mut vs := vars
  for (f, t) in fields do
    for st in t do
      match st with
      | .var v => if !(vs.any (·.1 == v)) then vs := vs ++ [(v, d, f)]
      | _ => pure ()
  let loc (v : String) : LRef := match vs.find? (·.1 == v) with
    | some (_, dv, fv) => .loc (d - dv) fv
    | none => .loc 0 0
  let mut attrK : Option Sym := none
  let mut valK : Option Sym := none
  let mut tests : List LTest := if p.goal then [.goal] else []
  let mut hash : Option (Nat × Nat) := none
  for (f, t) in fields do
    for st in t do
      match st with
      | .var v =>
        match vs.find? (·.1 == v) with
        | some (_, dv, fv) =>
          if dv == d && fv == f then pure ()
          else if f == 0 && hash.isNone && dv < d then hash := some (d - dv, fv)
          else tests := tests ++ [.eq f (.loc (d - dv) fv)]
        | none => pure ()
      | .const c =>
        if f == 1 && attrK.isNone then attrK := some c
        else if f == 2 && valK.isNone then valK := some c
        else tests := tests ++ [.eq f (.sym c)]
      | .rel op (.var y) => tests := tests ++ [.rel f op (loc y)]
      | .rel op (.sym c) => tests := tests ++ [.rel f op (.sym c)]
      | .disj cs => tests := tests ++ [.disj f cs]
      | .lti pos => tests := tests ++ [.lti f pos]
      | .ltiRel pos (.var y) => tests := tests ++ [.ltiRel f pos (loc y)]
      | .ltiRel pos (.sym c) => tests := tests ++ [.ltiRel f pos (.sym c)]
  return ({ attr := attrK, val := valK, acc := p.acc }, tests, hash, vs)

/-- `update_node_with_matches_from_above`. -/
def updateFromAbove (child : Nat) : M Unit := do
  let x ← gN child
  let par ← gN x.parent
  match par.kind with
  | .dummy => leftAdd child 0 none
  | .pos | .mp =>
    if par.rUnl then return
    let saved := par.children
    mN x.parent fun y => { y with children := [child] }
    for rm in ← amElems par.am none do
      rightAdd x.parent rm
    mN x.parent fun y => { y with children := saved }
  | _ =>
    for t in desc par.tokens do
      if (← gT t).negrm.isEmpty then
        leftAdd child t none

def addNode (x : Node) : M Nat := do
  let n ← get
  let i := n.nodes.size
  set { n with nodes := n.nodes.push x }
  mN x.parent fun p => { p with children := i :: p.children }
  return i

/-- `nearest_ancestor_with_same_am`. -/
partial def nearestSameAm (node : Nat) (am : Nat) : M (Option Nat) := do
  let x ← gN node
  if x.kind == .dummy then return none
  let up ← if x.kind == .cn then do pure (← gN x.partner).parent else realParent node
  let y ← gN up
  if (y.kind == .pos || y.kind == .mp || y.kind == .neg) && y.am == am then return some up
  if y.kind == .dummy then return none
  nearestSameAm up am

/-- `make_new_positive_node` under beta memory `mem`. -/
def newPos (mem : Nat) (am : Nat) (ts : List LTest) : M Nat := do
  let i ← addNode { kind := .pos, parent := mem, am := am, tests := ts }
  relinkLeft i
  let na ← nearestSameAm i am
  mN i fun y => { y with nearest := na }
  relinkRight i
  if (← gN mem).tokens.isEmpty then unlinkRight i
  if (← amEmpty am) && !(← gN i).rUnl then unlinkLeft i
  return i

/-- `make_new_mp_node`: a beta memory and its join, merged. -/
def newMp (parent : Nat) (hash : Option (Nat × Nat)) (am : Nat) (ts : List LTest) : M Nat := do
  let mem ← addNode { kind := .mem, parent := parent, hash := hash }
  updateFromAbove mem
  let pos ← newPos mem am ts
  -- `merge_into_mp_node`: the join takes the memory's place (at the head of the parent's children)
  let pn ← gN pos
  let mn ← gN mem
  mN pos fun y => { y with kind := .mp, parent := parent, hash := hash, tokens := mn.tokens, lUnl := pn.lUnl }
  moveToks mn.tokens mem pos
  mN parent fun p => { p with children := pos :: (p.children.erase mem) }
  mN mem fun y => { y with kind := .dummy, children := [], tokens := {}, linked := [] }
  return pos

/-- `split_mp_node`: a beta memory (taking the MP node's tokens) with the join under it. -/
def splitMp (mp : Nat) : M Nat := do
  let x ← gN mp
  mN x.parent fun p => { p with children := p.children.erase mp }
  let mem ← addNode { kind := .mem, parent := x.parent, hash := x.hash, tokens := x.tokens, children := [mp] }
  moveToks x.tokens mp mem
  mN mp fun y => { y with kind := .pos, parent := mem, tokens := {}, lUnl := false }
  relinkLeft mp
  if x.lUnl then unlinkLeft mp
  return mem

def sameHash (h₁ h₂ : Option (Nat × Nat)) : Bool := h₁ == h₂

/-- `make_node_for_positive_cond`. -/
def posCond (parent : Nat) (am : Nat) (ts : List LTest) (hash : Option (Nat × Nat)) : M Nat := do
  let par ← gN parent
  let hashed := hash.isSome
  let mut memN : Option Nat := none
  for c in par.children do
    let y ← gN c
    if y.kind == .mem && y.hash.isSome == hashed && (!hashed || sameHash y.hash hash) then
      memN := some c; break
  match memN with
  | some m =>
    for c in (← gN m).children do
      let y ← gN c
      if y.kind == .pos && y.am == am && y.tests == ts then return c
    newPos m am ts
  | none =>
    let mut mpN : Option Nat := none
    for c in par.children do
      let y ← gN c
      if y.kind == .mp && y.hash.isSome == hashed && (!hashed || sameHash y.hash hash) then
        mpN := some c; break
    match mpN with
    | some mp =>
      let y ← gN mp
      if y.am == am && y.tests == ts then return mp
      let m ← splitMp mp
      newPos m am ts
    | none => newMp parent hash am ts

/-- `make_node_for_negative_cond`. -/
def negCond (parent : Nat) (am : Nat) (ts : List LTest) (hash : Option (Nat × Nat)) : M Nat := do
  for c in (← gN parent).children do
    let y ← gN c
    if y.kind == .neg && y.am == am && y.hash == hash && y.tests == ts then return c
  let i ← addNode { kind := .neg, parent := parent, am := am, tests := ts, hash := hash }
  let na ← nearestSameAm i am
  mN i fun y => { y with nearest := na }
  relinkRight i
  updateFromAbove i
  if (← gN i).tokens.isEmpty then unlinkRight i
  return i

/-- `make_new_cn_node`. -/
def newCn (parent : Nat) (bottom : Nat) : M Nat := do
  -- the top node of the subconditions
  let rec top (i : Nat) : Nat → M Nat
    | 0 => return i
    | fuel + 1 => do
      let x ← gN i
      if x.parent == parent then return i else top x.parent fuel
  let subTop ← top bottom 10000
  let n ← get
  let cn := n.nodes.size
  let cnp := cn + 1
  set { n with nodes := (n.nodes.push { kind := .cn, parent := parent, partner := cnp }).push
                 { kind := .cnp, parent := bottom, partner := cn } }
  -- the CN node goes after the subconditions' top node in the parent's children
  mN parent fun p => { p with children := subTop :: cn :: (p.children.erase subTop) }
  mN bottom fun p => { p with children := cnp :: p.children }
  updateFromAbove cnp
  updateFromAbove cn
  return cn

/-- `build_network_for_condition_list`. -/
partial def build (vars : List (String × Nat × Nat)) (d : Nat) (parent : Nat) :
    List RC → M (Nat × List (String × Nat × Nat))
  | [] => return (parent, vars)
  | c :: cs => do
    match c with
    | .pos p =>
      let (k, ts, h, vs) := compile vars d p
      let am ← amFor k
      let nd ← posCond parent am ts h
      build vs (d + 1) nd cs
    | .neg p =>
      let (k, ts, h, _) := compile vars d p
      let am ← amFor k
      let nd ← negCond parent am ts h
      build vars (d + 1) nd cs
    | .ncc sub =>
      let (bottom, _) ← build vars d parent sub
      let mut found : Option Nat := none
      for ch in (← gN parent).children do
        let y ← gN ch
        if y.kind == .cn && (← gN y.partner).parent == bottom then
          found := some ch; break
      let nd ← match found with
        | some f => pure f
        | none => newCn parent bottom
      build vars (d + 1) nd cs

partial def treeRC : NegTree → RC
  | .node ps ns => .ncc (ps.map .pos ++ ns.map fun t => match t with
      | .node [q] [] => .neg q
      | t => treeRC t)

def toRC : Cond → RC
  | .pos p => .pos p
  | .neg [p] => .neg p
  | .neg ps => .ncc (ps.map .pos)
  | .ncc ps ns => .ncc (ps.map .pos ++ ns.map fun n => match n with
      | [q] => .neg q
      | qs => .ncc (qs.map .pos))
  | .nccg ns => treeRC ns.tree

/-- `add_production_to_rete`: the conditions in Soar's order, each positive one with its index
among the rule's positive conditions. -/
def addProd (name : String) (conds : List (Option Nat × Cond)) (needSup : Bool := true) : M Unit := do
  if (← get).names.contains name then return
  let (bottom, _) ← build [] 1 0 (conds.map fun c => toRC c.2)
  let n ← get
  let pi := n.prods.size
  set { n with prods := n.prods.push { name := name, depths := conds.map (fun (c : Option Nat × Cond) => c.1), needSup := needSup }, names := n.names.insert name }
  let p ← addNode { kind := .p, parent := bottom, prod := pi }
  updateFromAbove p

end Rete
end Soar
