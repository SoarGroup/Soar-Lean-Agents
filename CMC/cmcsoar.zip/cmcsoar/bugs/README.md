# Programs showing Soar 9.6.5 defects and departures from the manual

* `two-state-queries-crash.soar` — a state and its substate both have new queries in the same
  output phase; Soar 9.6.5 aborts with "double free detected" during decision 5
  (`run 5 -d`). Cause: `orquery` in `SMem_Manager::respond_to_cmd` is not cleared between states.
* `status-removal-uaf.soar` — a rule removes a retrieved augmentation and the `^success` status
  element (`zap*` rules); in decision 19 the output phase removes `(O17 ^name deep +)`, a
  preference of `propose*7`, so operator O17 is selected without a name (`watch 5` shows
  "- (O17 ^name deep +) (propose*7)" in the output phase). Cause: `smem_wmes` keeps a pointer to
  the freed status preference.
* `store-new-link.soar` — `^store-new` with `^link-to-new-ltm yes` overwrites the existing LTI
  instead of creating a new one (compare `print @` with manual §6.3.2).
* `epmem-zero-score-retrieval.soar` — a cue-based query whose positive cue matches no episode
  and whose negative cue matches episode 4 returns episode 3 (`^match-score 0`, `^success`),
  an episode containing no cue element, rather than failing or returning the most recent
  episode with that score (episodes 5–7). Manual §7.3.1 says candidates contain at least one
  cue leaf and the most recent best candidate is returned. Run `run 8` and print `s1 -d 4`.
* `../tests/chunkdemo/ChunkingDemoTests_Demo_Blocks_World_Look_Ahead.soar` (run 25 decisions with
  `decide indifferent-selection --first`) — the rule `chunk*selection*select*success-evaluation-becomes-best-preference*t19-2`,
  learned bottom-up through the instantiation of `...*t19-1`, lacks the relational tests on the
  `^bottom-block` values that `...*t19-1` has. Cause: `restore_saved_tests_to_test`
  (production_reorder.cpp) reverses a relational test and updates its `inst_identity` but not its
  `chunk_inst_identity`, so in the learned rule's own instantiation the reversed test compares a
  value with itself and `remove_contradictory_tests_from_chunk` deletes it.
* `../tests/chunkdemo/ChunkingDemoTests_Demo_Graph_Search.soar` (run 25 decisions, then
  `preferences O21 superstate --names`) — `selection*elaborate*evaluate-operator*superstate`, a rule that
  only augments the selected operator, gives `:O` (o-supported) preferences, and the
  augmentations of earlier evaluate-operators persist. Cause: `p_node_left_addition` (rete.cpp)
  decides support by looping over all current matches of the production and comparing each
  one's selected operator with the action identifiers of the new match; a second match in a
  nested selection state, with a different selected operator, makes the new match o-supported.
* `wma-stale-preference.soar` — `elab*use` tests a counter that changes every cycle, so its
  element `^big yes` is re-supported each cycle by a new instantiation after the counter value
  the old instantiation tested was rejected and its preference freed. After 3 decisions,
  `wma --history` of `^count 2` shows 13 references where the source's rules give 12 (the
  model, `soar-lean --wma-debug F`, gives 12 and reports the stale reads). Cause: non-context
  elements hold no reference on `w->preference`, and `wma_activate_wme`
  (`wma_should_have_decay_element`) reads the freed preference of the removed counter element
  when building the old preference's o-set; the pool has given that memory to the new `^big yes`
  preference, whose instantiation tested the new counter value.
* Petrov's approximation with `wma --set decay-rate 1` (for example
  `tests/wmafuzz/w068.soar`): the approximation divides 0 by 0, and elements made from rules
  whose tested elements have more than ten history entries start with 9223372036854775809
  references (`wma --history`); with `forgetting bsearch` such elements are forgotten in the
  cycle they are made.
* `rl-template-variables.soar` — the second rule made from the template,
  `rl*sub*rl*template*2`, uses `<o1>` both for the superstate's selected operator (`go`) and for
  the proposed operator `b`, so it never matches and `b` never gets an RL value (`run 6`, then
  `print rl*sub*rl*template*2`). Cause: `rl_build_template_instantiation`
  (reinforcement_learning.cpp) resets the variable generator for each new rule but does not clear
  the identifier-to-variable map, `m_sym_to_var_map`, that `sti_variablize_test` fills, so
  identifiers keep the variables of the previous template rule while new identifiers get the
  same names again.
* `../tests/dbfile/sm2.soar` (with `sm2.pre.soar` run first in another agent; `tools/diff.py
  tests/dbfile --smem`) — opening a file database with `smem --set append off` prints "table
  smem_constants_store already exists" and the same for `smem_to_delete` and
  `smem_invalid_parents`. Cause: `smem_statement_container::drop_tables` (smem_db.cpp) does not
  drop those three tables, so their rows survive into the emptied store.
* `chunk-computed-numeric-pref.soar` — Soar crashes (segmentation fault) in decision 2 when it
  learns a rule whose only action is a numeric-indifferent preference with a computed value,
  `(<ss> ^operator <o> = (+ 1 <d>))` (`run 4`). Cause: `make_production` (production.cpp:441-445)
  takes such a rule for an RL rule (`rl_valid_rule` checks only for one numeric-indifferent
  action) and calls `get_number_from_symbol(rhs_value_to_symbol(...))` on a function call, not a
  symbol. Found in the agent library: water-jug-look-ahead V1 and water-jug-tie-operator-RL V1
  crash this way (backtrace from a debug build), with selection-RL.soar's
  `selection*select*partial-success-evaluation-becomes-numeric-preference` and chunking on.
  (mac-planning V4 also crashes in the 9.6.5 release, in its look-ahead, but not in the debug
  build; its cause is not yet known.)
