# Remaining differences from Soar 9.6.5, and how each was diagnosed

As of November 2, 2026 (full regression on the final build), every program in tests/ matches Soar 9.6.5 except those below. Each is
traced to Soar's undefined or address-dependent behaviour, not to the specification. The kernel
defects named are described, with source locations and fixes, in
doc/Soar-9.6.5-Kernel-Defects.docx.

## epwma f014 (episodic memory with working-memory activation)

- **What differs:** episodes 17–21 (21 decisions, 1551 elements).
- **Cause:** with the default `graph-match-ordering undefined`, Soar sorts the cue's literals
  by their memory addresses before the graph match (`epmem_process_query`, kernel defect 4).
  The cue unifies with an episode in more than one way, and Soar's choice of mapping, copied
  into working memory by the program, depends on the addresses.
- **Evidence:** with `epmem --set graph-match-ordering dfs` the program matches. The model
  takes the literals in the order they are made.

## epfuzz2 f229 (episodic memory, graph match)

- **What differs:** the last episode (15 decisions, about 3,330 elements), and with it four
  elements copied from a retrieval. The program matched in earlier regression runs on October
  31 and differs in later ones, with Soar's own working memory changing size between runs
  (3,332 and 3,336 elements), the model's run unchanged.
- **Cause:** the same as f014: `graph-match-ordering undefined` sorts the cue's literals by
  memory address (kernel defect 4), and the cue unifies with the episode in more than one way.
  Which mapping Soar returns depends on the addresses the allocator hands out, so the result
  varies between processes.
- **Evidence:** with `epmem --set graph-match-ordering dfs` added to the program it matches.

## realsmem SMemFunctionalTests_testSpreadingActivation_AlphabetAgentAllOn

- **What differs:** four working-memory activations; decisions, working memory and the store
  match (60 decisions).
- **Cause:** Soar reads freed preferences when it builds o-sets and initial boosts (kernel
  defect 22). What it reads depends on which preference the pool has put in the freed memory.
- **Evidence:** `soar-lean --wma-debug F` counts each read of a freed preference that Soar
  would make (the `stale` count), and the agent makes such reads. The mechanism is shown in
  isolation by bugs/wma-stale-preference.soar, where the model gives the references the rules
  call for and Soar one more.

## Spreading activation with edge updating (9 of 30 generated programs, not in tests/)

- **What differs:** edge weights after updating, and the spread values that use them.
- **Cause:** Soar records an edge update for an element whose value is a constant, reading
  the constant as an identifier past the end of its memory (kernel defect 24). Whether a
  phantom update happens depends on that memory.
- **Evidence:** an edge of weight 1 became 0.980 in a program whose only LTI-valued element on
  that identifier was to its real child. The model records updates only for identifier values.

## Resolved October 31: 8 spreading-activation programs (smemspread)

- **What differed:** an element of a log entry recording a bad command started with 25
  activation references in the model and 26 in Soar.
- **How it was found:**
  - `wma --history` in Soar and `--wma-debug` in the model showed the histories agreed up to
    the decision the log entry was made.
  - So the difference was in the initial boost, the mean activation of the elements the
    creating rule tested and of the o-sets behind them.
  - A temporary trace of `St.wmaBoost` listed the elements averaged. The bad-command result's
    instantiation included one element of a neg-query, which Soar's does not have: for a
    malformed command Soar's cue is only the command's top-level elements (`respond_to_cmd`).
- **Fix:** the model's test for a bad command looked for a `^status bad-cmd` element, while the
  status element is `^bad-cmd <c>`. With the test corrected all 8 programs match.

## bwbook/world blocks-world-operator-subgoaling-RL (RL value of a template rule)

Added November 2, 2026 with the Soar book's blocks-world agents. Soar 9.6.5 builds
`rl*blocks-world*select*four-blocks*clear*subgoal*7` and `*8` (made from a template in the
second operator subgoal) with colliding variables: the state and the proposed operator both get
`<o1>` (`(state <o1> ^name move-block ^operator <o1> + …)`), so the rules never match and `*8` is
never updated. This is kernel defect 28 (`rl_build_template_instantiation` does not clear
`m_sym_to_var_map`); here the stale entries match because the map is keyed by `Symbol*` and an
identifier freed with the first subgoal is reallocated at the same address for the second. The
model keys identifiers by number, builds `*8` correctly, and updates it once (value 0.3).
Diagnosed by printing the generated rules in Soar (`print rl*…*8`) and comparing the RL update
traces (`trace --rl`; soar-lean `--watch` now prints the same lines).

## Resolved November 2: relational tests on an element with no equality test (agent library)

- **What differed:** in the agent library's arithmetic V10 (arithmetic-smem with `chunk always`),
  3 of 38 learned rules. Soar's rules learned bottom-up (`chunkx2*…`) kept
  `^zero { <z1> <> <d2> }`, which came from `^counter <count> ^subtrahend <> <count>` in the
  proposal of `count`. The model's rules lacked it.
- **How it was found:** `tests/agentlib-repro/relid4.soar` reproduces it in 15 rules.
  - `relid5.soar` writes the test with a variable, `{ <b> <> <count> }`, and Soar's bottom-up
    rule loses it. This is the stale `chunk_inst_identity` of a test the reorderer reversed,
    as in the chunkdemo case in bugs/README.md.
  - `print sub*propose*count` in Soar showed the reason: Soar stores the rule as
    `^subtrahend <s*1> ^counter { <> <s*1> <c> }`. When the rule is loaded, the reorderer
    gives the element without an equality test a `dummy-` variable. It moves the test, reversed,
    to the condition that binds the variable compared with, because that condition comes later
    in its order (`restore_saved_tests_to_test`). The learned rule's constraint then belongs to
    the counter, and the learned rule is not reordered again there.
  - When the variable is already bound (the library's BW-LA-state-eval,
    `P4*elaborate*object-on-notinplace`, stored as `^bottom-block { <> <blockB> <b*1> }`), the
    test stays where it was written.
- **Fix:** in `LEnv.learn` (Soar/Chunk.lean), such a test is attached, inverted, to the
  condition of the variable it compares with, when that variable is not bound before the
  element's condition in Soar's stored order (`LEnv.soarOrd`). Only elements with no equality
  test are treated this way (SIMPLIFIED). relid4–6, arithmetic V10 and both BW-LA agents match.

## Resolved November 3: agent-library differences in the model and the harness

The library comparison (tests/agentlib, at most 100 decisions per version) found these:

- **Identifier promotion stopped early (model).** `St.relevel` walks from the states, giving
  each identifier the level of the highest state that links it. Its step bound counted only the
  identifiers that have links of their own. In agents with many identifiers whose values are
  all constants (arithmetic facts), the walk ran out of steps.
  - **Effect:** a new column linked under the top state kept its substate level. Elements on it
    made in a substate were therefore not results, and they went with the substate.
  - **Cases:** addition V1 and arithmetic-save V1 (found with `--watch` and a temporary trace of
    `lv`).
  - **Fix:** the bound is now the number of links.
- **Parser gaps (model):**
  - a structured value whose first test is negated, `^condition (-^name refuel …)`
    (taxi-mapping);
  - `(exec …)` actions, which Soar loads and runs as no-ops when the host registers no
    function (simple-robot);
  - unknown characters such as a stray backtick, which Soar's lexer skips (MOUTBot);
  - `source` and `pushd` arguments in braces that contain spaces;
  - a missing sourced file, at which Soar stops loading and soar-lean exited.
- **Harness:**
  - **Saved chunks:** `:chunk` rules that an agent loads from its own files counted as learned
    (Johnbot, count-test).
  - **Halts in replay:** in replay mode a run that halted was given two more phases
    (advanced-move, the Eater agents).
  - **Encoding:** Latin-1 strings from Soar arrive as surrogate escapes (the pyramid agents).
  - **Debug line:** Soar prints a debug line from the epmem graph match into the trace when
    epmem tracing is on (EpMemFunctionalTests encode-selection).
  - **Print depth:** Soar's working memory was read only to depth 100 (arithmetic's
    1,000-problem list).

## Resolved November 3 (continued): the remaining library differences

Diagnosed with a patched debug build of Soar 9.6.5 (prints in `reinstantiate_lhs`,
`p_node_left_addition`, `add_goal_or_impasse_tests` and after a chunk's instantiation).

- **Comments after settings (model).** `chunk add-osk off  # …` (fifteen-puzzle V3): the
  setting parsers matched whole lines and ignored a line with a trailing comment. Soar 9.6.5
  ignores the comment, even within a word (`chunk max-dupes 5#x` sets 5). The line-based setting
  parsers now cut lines at `#`.
- **Rules learned in mid-pass (model).** In mac-planning V3, Soar learned
  `chunkx2*…*t42-2` from a rule it had just learned. That rule also matched the look-ahead
  state, and it fired in the same pass of `do_preference_phase`. Soar adds a learned rule to the
  Rete at once (`add_chunk_to_rete`). Its other matches join the assertion list in front, and
  `get_next_assertion` takes them next.
  - **Support.** The Rete gives each new match its support from the matches its p-node
    already holds (`p_node_left_addition`). These arrive one at a time in
    `update_node_with_matches_from_above`. Here the look-ahead state's match arrived before the
    rule's own instantiation, so it was i-supported. In the other cases (t9, t27) the order was
    the reverse, and the match was o-supported and waited.
  - **Fix:** `St.fireOne` adds the new rules to the Rete model (`St.reteAddRules`). It then
    fires their matches that are not the rules' own instantiations, at the level being fired and
    with the support being fired. The support is computed from the matches the model's Rete
    reached before.
- **State tests on learned rules (model).** Soar adds a state test on the first condition of
  each variable that stands for a state (`add_goal_or_impasse_tests`). The reorderer then
  removes it from variables that are not roots, those in some condition's value
  (`remove_isa_state_tests_for_non_roots`). The model used to put it only on states reached
  through a `^superstate` element. That missed a second variable for the same state (the
  chunkx2 rule's `(state <s2> ^operator <o1>)`), and so changed the Rete's order.
- **Variables of rules made by templates (model).** The letter of an identifier's variable
  was taken from the attribute that holds it. Soar takes it from the right-hand-side variable
  the identifier was made for (`<blockA>` gives `<b1>`, `<table>` gives `<t1>`). With the wrong
  letters, Soar's name collisions between template instantiations (a variable kept from an
  earlier instantiation and a new one with the same name) did not occur (blocks-world V2, whose
  rules have `^destination <b1> ^moving-block <b1>`).
  - Rules made by templates are now compared for duplicates in Soar's stored order.
- **Parser (model):**
  - a dashed word as a right-hand-side function argument, `(cmd print <o> -d 2)`
    (john-nlp);
  - a number followed by a dot and a disjunction or variable in an attribute path,
    `^2.<< 2 >>.handle`;
  - a condition with a state test and no attribute test, `-{(state <s>) …}`. Soar rejects it,
    and loading stops: john-nlp loads 1,260 rules in Soar, and soar-lean loaded all of them;
  - two equality tests in one conjunction, `{<x> 0.}`. Soar keeps only the constant, so `<x>`
    is unbound and makes a new identifier on the right-hand side; of `{<a> <b>}` it keeps
    `<a>` (simple-robot, `parse_test`).
- **Not modeled: the numbering of `smem --add` objects (graph-search-smem V1, V2).** Soar
  9.6.5 numbers the objects of one `smem --add` clause in pointer order
  (`std::set<ltm_object*>`; see `SMem.lean`). The same agent files gave a different numbering
  when run in a directory with more files, so the comparison depends on the environment.
- **Harness: the library comparison was incomplete (fixed).** tools/chunkcmp.py read a quoted
  symbol up to the next bar, so a learned rule with the value `|\||` (kenken V1) raised an
  exception. That ended the shard, and the 147 versions after kenken had not been compared in
  any earlier library run. Quoted symbols now allow backslash escapes, and are compared
  unescaped. The complete comparison exposed eight differences not yet diagnosed (STATUS.md).
- **Goal dependency set: tested superstate elements (model, regression of the same day).** The
  change above for arithmetic-solve-problem dropped every superstate element already gone from
  working memory. Soar records the superstate elements an instantiation tested itself whatever
  their state (decide.cpp:3596-3600), and drops only those reached through a local element with
  no preference. In testPreferenceDeallocation, the tested `(<foo> ^bar bar)` is removed in the
  same phase, and its GDS entry makes the substate go. Directly tested elements are now always
  recorded; both agents match.

## Resolved November 3 (afternoon): the eight differences first seen in the complete library run

- **Negated conditions of justifications (model; testGDSBug1011).** A justification keeps the
  negated conditions on superstate identifiers of the instantiations it summarizes, and is
  retracted when one of them comes to match. Here an operator proposed under `-(<i> ^prefer)`
  led to the result `(<i> ^prefer true)`, so the justification retracted itself and the
  result went. The model's justifications had positive conditions only. `Inst.negs` now holds
  the simple negations of every instantiation, and `St.justifyResults` keeps those on superstate
  identifiers. SIMPLIFIED: conjunctive negations are not kept.
- **Values made by right-hand-side functions (model; testGDSBug1144).** `XInst.actFor` found the
  action that made an element by evaluating the action again. `(make-constant-symbol)` cannot be
  evaluated again, so its element had no action, and the key it made was not literalized. An
  action with a function-call value now matches by identifier and attribute when no action
  matches exactly.
- **Random numbers in replay (model; testRHSRand).** With Soar's choices replayed, the model
  followed the hint without drawing from the generator. `rand-int` and `rand-float` then drew
  different numbers. A replayed choice now draws as the selection policy would.
- **Results two levels up (model; tower-of-hanoi-search).** `St.backtrace` turned a substate's
  `^item` into the superstate's acceptable operator preference and took it as a condition
  whatever that state's level. When the result attaches two levels up, that preference is
  local, and Soar traces through its proposal. The justification then had a condition at the
  intermediate level, and the wrong support. The preference is now traced like any other
  element.
- **Number lexing and failed redefinitions (model; simple-robot-with-avoidance-star).**
  - Soar's lexer takes a decimal point into a number only when no constituent character
    follows it (`lex_digit`, `read_rest_of_floating_point_number`). So `2.5.` is 2.5 and a
    dot, an illegal right-hand-side value; Soar rejects the rule and stops loading.
  - Soar excises an existing rule of the same name as soon as it reads the name
    (`parse_production`), so the failed redefinition leaves no rule of that name. soar-lean cut
    the text at the first rule of that name; it now cuts at the one that fails, and excises the
    earlier one. A test is in tests/parser/redef-fail.soar.
- **Relational tests on superstate elements (model; kenken V1).** The move of a relational test
  on an element with no equality test to the condition of the variable it compares with (above,
  for local conditions) applies to superstate conditions too. Without it, a learned rule lost
  `legal-value <= board-size` and fired without end.
- **The learned rule's own instantiation (model; kenken V2).** The model took the first match
  of a new rule among the elements it was learned from. With two `^cell-check` conditions the
  match could bind them the other way round, and the rule learned from that instantiation lost
  one of its two results. Soar builds the instantiation from the conditions it learned from
  (`reinstantiate_current_rule`). The model now takes the match whose actions make the results.
- **Not modeled: `:interrupt` (testMatchTimeInterrupt).** Soar stops the run when a rule marked
  `:interrupt` matches (`p_node_left_addition`, rete.cpp:6218). soar-lean has no way to stop a
  run except halt, as for `(cmd stop-soar)`.
