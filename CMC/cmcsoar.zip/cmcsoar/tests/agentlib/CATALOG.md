# Agent library catalog

Generated from catalog.json by `python3 -I tools/agentlib.py report`. Soar 9.6.5 run: first
indifferent choice, srand 0, at most 300 decisions ("300+" = still running at the cap).

824 versions of 596 agents.

| Agent | Version | Received (zip: path) | Soar 9.6.5 | Notes |
|---|---|---|---|---|
| 20090418_080403_rl-rules | V1 | knights-tour.zip: taxi/taxi/processed/uninformed/finite/0.9999997/20090418_080403_rl-rules.soar | 100 decisions, 68018 rules |  |
| 20090418_095302_rl-rules | V1 | knights-tour.zip: taxi/taxi/processed/uninformed/finite/0.9999997/20090418_095302_rl-rules.soar | 100 decisions, 6879 rules |  |
| 20090418_104435_rl-rules | V1 | knights-tour.zip: taxi/taxi/processed/omniscient/finite/20090418_104435_rl-rules.soar | 100 decisions, 16010 rules |  |
| 20090418_114553_rl-rules | V1 | knights-tour.zip: taxi/taxi/processed/omniscient/finite/20090418_114553_rl-rules.soar | 100 decisions, 20001 rules |  |
| 20090418_135103_rl-rules | V1 | knights-tour.zip: taxi/taxi/processed/uninformed/infinite/20090418_135103_rl-rules.soar | 100 decisions, 68018 rules |  |
| 20090418_141756_rl-rules | V1 | knights-tour.zip: taxi/taxi/processed/uninformed/infinite/20090418_141756_rl-rules.soar | 100 decisions, 6879 rules |  |
| 20090418_143203_rl-rules | V1 | knights-tour.zip: taxi/taxi/processed/omniscient/infinite/20090418_143203_rl-rules.soar | 100 decisions, 16010 rules |  |
| 20090418_144955_rl-rules | V1 | knights-tour.zip: taxi/taxi/processed/omniscient/infinite/20090418_144955_rl-rules.soar | 100 decisions, 20001 rules |  |
| 20090508_143710_rl-rules | V1 | knights-tour.zip: taxi/taxi/rules/20090508_143710_rl-rules.soar | 100 decisions, 20001 rules |  |
| addition | V1 | epmem-tutorial.zip: all-test/Arithmetic/OLD/addition.soar | 32 decisions, 33 rules |  |
| advanced-move | V1 | epmem-tutorial.zip: Eater Bootstrap/advanced-move.soar | 100 decisions, 10 rules |  |
| advanced-move | V2 | epmem-tutorial.zip: eaters 8.5.2/tutorial/advanced-move.soar | 100 decisions, 9 rules |  |
| agent_1 | V1 | epmem-tutorial.zip: breakout/agent_1/agent_1/agent_1.soar | 101 decisions, 23 rules |  |
| algebra | V1 | RL-general-state.zip: Algebra projects/9-6-algebra/algebra/algebra.soar | 300+ decisions, 221 rules | interactive: waits for an equation typed on the output link (accept-input) |
| algebra | V2 | RL-general-state.zip: Algebra projects/algebra.soar | 300+ decisions, 221 rules | interactive: waits for an equation typed on the output link (accept-input) |
| algebra | V3 | RL-general-state.zip: Algebra/algebra.soar | 92 decisions, 176 rules |  |
| all-test | V1 | epmem-tutorial.zip: all-test/all-test.soar | 300+ decisions, 759 rules; load error: Failed to open file for reading: move-to-area.soar |  |
| arithmetic | V1 | epmem-tutorial.zip: Arithmetic-smem/arithmetic.soar | 165 decisions, 147 rules | Soar 9.6: same as V8; corrected as V11 |
| arithmetic | V2 | epmem-tutorial.zip: Arithmetic/arithmetic.soar | 103 decisions, 54 rules; load error: Failed to open file for reading: carry-borrow.soar | missing: carry-borrow.soar, carry-borrow_source.soar, compute-result.soar, compute-result_source.soar |
| arithmetic | V3 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/arithmetic/arithmetic.soar | 300+ decisions, 99 rules |  |
| arithmetic | V4 | epmem-tutorial.zip: arithmetic-old/arithmetic.soar | 300+ decisions, 87 rules |  |
| arithmetic | V5 | epmem-tutorial.zip: arithmetic2/arithmetic.soar<br>arithmetic.zip: arithmetic/arithmetic.soar | 300+ decisions, 86 rules |  |
| arithmetic | V6 | 2026-agents-verified.zip: 2026-agents-verified/Arithmetic/Aritimetic-plain/arithmetic.soar<br>Water-jugs.zip: Arithmetic/Aritimetic-plain/arithmetic.soar | 300+ decisions, 95 rules |  |
| arithmetic | V7 | RL-general-state.zip: Arithmetic-smem/arithmetic.soar | crash | Soar 9.6: same as V8; with chunk always, runaway learning in retrieve-digits exhausts memory; corrected as V10 |
| arithmetic | V8 | arithmetic-smem.zip: arithmetic-smem/arithmetic.soar | 103 decisions, 151 rules | Soar 9.6: no-change loop to depth 100 (smem retrievals make new identifiers; ^problem 0 query); corrected as V9 |
| arithmetic | V9 | — | 300+ decisions, 153 rules | corrected V8: Soar 9.6 smem: digits found by value (retrievals make new identifiers); query for digit 0; no ^depth with ^query; facts store field values; retrieved facts tested against the column digits (chunking does not trace retrievals); no learning in retrieve-digits; digits printed by value |
| arithmetic | V10 | — | 300+ decisions, 156 rules | corrected V7: Soar 9.6 smem: digits found by value (retrievals make new identifiers); query for digit 0; no ^depth with ^query; facts store field values; retrieved facts tested against the column digits (chunking does not trace retrievals); no learning in retrieve-digits; digits printed by value |
| arithmetic | V11 | — | 300+ decisions, 149 rules | corrected V1: Soar 9.6 smem: digits found by value (retrievals make new identifiers); query for digit 0; no ^depth with ^query; facts store field values; retrieved facts tested against the column digits (chunking does not trace retrievals); no learning in retrieve-digits; digits printed by value |
| arithmetic-save | V1 | epmem-tutorial.zip: all-test/Arithmetic/OLD/arithmetic-save.soar | 300+ decisions, 83 rules |  |
| arithmetic-solve-problem | V1 | 2026-agents-verified.zip: 2026-agents-verified/Arithmetic/Arithmetic-hierarchial/arithmetic-solve-problem.soar<br>Water-jugs.zip: Arithmetic/Arithmetic-hierarchial/arithmetic-solve-problem.soar | 178 decisions, 98 rules | Differed from Soar in learned rules until the model fixes of November 3 (negation keys, GDS); matches since. |
| avoider-robot | V1 | epmem-tutorial.zip: current-robots/avoider-robot.soar | 300+ decisions, 23 rules |  |
| barracks | V1 | arithmetic-smem.zip: john-nlp/manage-world-state/internal-worlds/barracks.soar | 100 decisions, 1 rules |  |
| barracks | V2 | arithmetic-smem.zip: john-nlp/manage-world-state/waypoint-maps/barracks.soar | 100 decisions, 1 rules |  |
| BasicTests_testBasicElaborationAndMatch | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/BasicTests_testBasicElaborationAndMatch.soar | 0 decisions, 2 rules |  |
| BasicTests_testInitialState | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/BasicTests_testInitialState.soar | 0 decisions, 1 rules |  |
| bid46 | V1 | epmem-tutorial.zip: Dice Game/dicegame-0.1.1/agents/bid46.soar | 300+ decisions, 2 rules |  |
| big | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/big.soar | 0 decisions, 717 rules |  |
| blending1 | V1 | arithmetic-smem.zip: john-nlp/manage-world-state/internal-worlds/blending1.soar | 100 decisions, 1 rules |  |
| blending2 | V1 | arithmetic-smem.zip: john-nlp/manage-world-state/internal-worlds/blending2.soar | 100 decisions, 1 rules |  |
| blending3 | V1 | arithmetic-smem.zip: john-nlp/manage-world-state/internal-worlds/blending3.soar | 100 decisions, 1 rules |  |
| block-world-HRL-3level | V1 | knights-tour.zip: taxi/taxi/inheritance/blocks-world/block-world-HRL-3level.soar | 300+ decisions, 287 rules |  |
| block-world-HRL-3level | V2 | BW-Hierarchical.zip: blocks-world-not-book/block-world-HRL-3level.soar<br>RL-general-state.zip: BLOCKS-WORLD/blocks-world-not-book/block-world-HRL-3level.soar | 100 decisions, 0 rules |  |
| blocks-opsub | V1 | epmem-tutorial.zip: all-test/blocks-world/blocks-opsub.soar | 7 decisions, 26 rules |  |
| blocks-opsub | V2 | xx-BLOCKS-WORLD: blocks-world-book/blocks-opsub.soar<br>blocks-world-book.zip: blocks-world-book/blocks-opsub.soar | 7 decisions, 27 rules | missing: ../default/simple.soar; defaults filled: simple.soar |
| blocks-world | V1 | BW-Hierarchical.zip: blocks-world-not-book/blocks-world-2-level/blocks-world.soar<br>RL-general-state.zip: BLOCKS-WORLD/blocks-world-not-book/blocks-world-2-level/blocks-world.soar | 300+ decisions, 20 rules |  |
| blocks-world | V2 | BW-Hierarchical.zip: blocks-world-not-book/blocks-world-RL/blocks-world.soar<br>RL-general-state.zip: BLOCKS-WORLD/blocks-world-not-book/blocks-world-RL/blocks-world.soar | 4 decisions, 17 rules | RL template rules differed until November 3 (variable letters, duplicate detection in stored order); matches since. |
| blocks-world | V3 | BW-Hierarchical.zip: blocks-world-not-book/blocks-world.soar<br>RL-general-state.zip: BLOCKS-WORLD/blocks-world-not-book/blocks-world.soar | 4 decisions, 15 rules |  |
| blocks-world-epmem | V1 | xx-BLOCKS-WORLD: blocks-world-book/blocks-world-epmem.soar | 300+ decisions, 104 rules; load error: Error changing to evaluate-operator | missing: simple.soar, selection.soar, selection-epmem.soar, evaluate-operator_source.soar; defaults filled: selection-epmem.soar, selection.soar, simple.soar |
| blocks-world-epmem | V2 | blocks-world-book.zip: blocks-world-book/blocks-world-epmem.soar<br>blocks-world-book-2019.zip: blocks-world-book-2019/blocks-world-epmem.soar<br>blocks-world-book-2019-x.zip: blocks-world-book-2019-x/blocks-world-epmem.soar<br>blocks-world-book-2019-world.zip: blocks-world-book-2019-world/blocks-world-epmem.soar<br>RL-general-state.zip: BLOCKS-WORLD/blocks-world-book-2019-world/blocks-world-epmem.soar<br>RL-general-state.zip: BLOCKS-WORLD/blocks-world-book-2019/blocks-world-epmem.soar | 300+ decisions, 118 rules | missing: simple.soar, selection.soar, selection-epmem.soar; defaults filled: selection-epmem.soar, selection.soar, simple.soar |
| blocks-world-H-3level-lookahead | V1 | BW-Hierarchical.zip: blocks-world-not-book/blocks-world-H-3level-lookahead.soar<br>RL-general-state.zip: BLOCKS-WORLD/blocks-world-not-book/blocks-world-H-3level-lookahead.soar | timeout | missing: selection.soar; defaults filled: selection.soar |
| blocks-world-hierachical-lookahead | V1 | xx-BLOCKS-WORLD: blocks-world-book/blocks-world-hierachical-lookahead.soar | 300+ decisions, 101 rules; load error: Error changing to evaluate-operator | missing: simple.soar, selection.soar, evaluate-operator_source.soar, pick-up_source.soar; defaults filled: selection.soar, simple.soar |
| blocks-world-hierachical-lookahead | V2 | BW-Hierarchical.zip: BWHL/blocks-world-hierachical-lookahead.soar | 55 decisions, 156 rules | missing: simple.soar, selection.soar; defaults filled: selection.soar, simple.soar |
| blocks-world-hierachical-lookahead | V3 | blocks-world-book.zip: blocks-world-book/blocks-world-hierachical-lookahead.soar | 82 decisions, 154 rules | missing: simple.soar, selection.soar; defaults filled: selection.soar, simple.soar |
| blocks-world-hierachical-lookahead | V4 | blocks-world-book-2019.zip: blocks-world-book-2019/blocks-world-hierachical-lookahead.soar<br>RL-general-state.zip: BLOCKS-WORLD/blocks-world-book-2019/blocks-world-hierachical-lookahead.soar | 300+ decisions, 163 rules | missing: simple.soar, selection.soar; defaults filled: selection.soar, simple.soar |
| blocks-world-hierachical-lookahead | V5 | blocks-world-book-2019-x.zip: blocks-world-book-2019-x/blocks-world-hierachical-lookahead.soar<br>blocks-world-book-2019-world.zip: blocks-world-book-2019-world/blocks-world-hierachical-lookahead.soar<br>RL-general-state.zip: BLOCKS-WORLD/blocks-world-book-2019-world/blocks-world-hierachical-lookahead.soar | 300+ decisions, 168 rules | missing: simple.soar, selection.soar; defaults filled: selection.soar, simple.soar |
| blocks-world-hierachical-lookahead | V6 | RL-general-state.zip: BLOCKS-WORLD/BWHL/blocks-world-hierachical-lookahead.soar | 55 decisions, 156 rules | missing: simple.soar, selection.soar; defaults filled: selection.soar, simple.soar |
| blocks-world-hierarchical | V1 | xx-BLOCKS-WORLD: blocks-world-book/blocks-world-hierarchical.soar | 300+ decisions, 33 rules; load error: Error changing to pick-up | missing: simple.soar, pick-up_source.soar; defaults filled: simple.soar |
| blocks-world-hierarchical | V2 | BW-Hierarchical.zip: blocks-world-hierarchical/blocks-world-hierarchical.soar | 42 decisions, 51 rules | missing: simple.soar; defaults filled: simple.soar |
| blocks-world-hierarchical | V3 | blocks-world-book.zip: blocks-world-book/blocks-world-hierarchical.soar | 42 decisions, 51 rules | missing: simple.soar; defaults filled: simple.soar |
| blocks-world-hierarchical | V4 | blocks-world-book-2019.zip: blocks-world-book-2019/blocks-world-hierarchical.soar<br>blocks-world-book-2019-x.zip: blocks-world-book-2019-x/blocks-world-hierarchical.soar<br>blocks-world-book-2019-world.zip: blocks-world-book-2019-world/blocks-world-hierarchical.soar<br>RL-general-state.zip: BLOCKS-WORLD/blocks-world-book-2019-world/blocks-world-hierarchical.soar<br>RL-general-state.zip: BLOCKS-WORLD/blocks-world-book-2019/blocks-world-hierarchical.soar | 42 decisions, 51 rules | missing: simple.soar; defaults filled: simple.soar |
| blocks-world-hierarchical | V5 | RL-general-state.zip: BLOCKS-WORLD/blocks-world-hierarchical/blocks-world-hierarchical.soar | 42 decisions, 51 rules |  |
| blocks-world-hierarcical-RL | V1 | xx-BLOCKS-WORLD: blocks-world-book/blocks-world-hierarcical-RL.soar | 300+ decisions, 375 rules; load error: Error changing to pick-up | missing: simple.soar, pick-up_source.soar; defaults filled: simple.soar |
| blocks-world-hierarcical-RL | V2 | blocks-world-book.zip: blocks-world-book/blocks-world-hierarcical-RL.soar<br>blocks-world-book-2019.zip: blocks-world-book-2019/blocks-world-hierarcical-RL.soar<br>blocks-world-book-2019-x.zip: blocks-world-book-2019-x/blocks-world-hierarcical-RL.soar<br>blocks-world-book-2019-world.zip: blocks-world-book-2019-world/blocks-world-hierarcical-RL.soar<br>RL-general-state.zip: BLOCKS-WORLD/blocks-world-book-2019-world/blocks-world-hierarcical-RL.soar<br>RL-general-state.zip: BLOCKS-WORLD/blocks-world-book-2019/blocks-world-hierarcical-RL.soar | 300+ decisions, 549 rules | missing: simple.soar; defaults filled: simple.soar |
| blocks-world-HRL | V1 | BW-Hierarchical.zip: blocks-world-not-book/blocks-world-HRL.soar<br>RL-general-state.zip: BLOCKS-WORLD/blocks-world-not-book/blocks-world-HRL.soar | 300+ decisions, 375 rules |  |
| blocks-world-look-ahead | V1 | epmem-tutorial.zip: all-test/blocks-world/blocks-world-look-ahead.soar | 27 decisions, 81 rules |  |
| blocks-world-look-ahead | V2 | BW-Hierarchical.zip: blocks-world-not-book/blocks-world-RL/blocks-world-look-ahead.soar<br>RL-general-state.zip: BLOCKS-WORLD/blocks-world-not-book/blocks-world-RL/blocks-world-look-ahead.soar | 33 decisions, 126 rules | missing: selection.soar; defaults filled: selection.soar |
| blocks-world-lookahead | V1 | xx-BLOCKS-WORLD: blocks-world-book/blocks-world-lookahead.soar<br>blocks-world-book.zip: blocks-world-book/blocks-world-lookahead.soar | 25 decisions, 98 rules | missing: simple.soar, selection.soar; defaults filled: selection.soar, simple.soar |
| blocks-world-lookahead | V2 | BW-Hierarchical.zip: Soar-BW-Opsub-Examples/blocks-world/blocks-world-lookahead.soar<br>RL-general-state.zip: BLOCKS-WORLD/Soar-BW-Opsub-Examples/blocks-world/blocks-world-lookahead.soar | 87 decisions, 113 rules |  |
| blocks-world-lookahead | V3 | BW-Hierarchical.zip: blocks-world-lookahead/blocks-world-lookahead.soar<br>RL-general-state.zip: BLOCKS-WORLD/blocks-world-lookahead/blocks-world-lookahead.soar | 25 decisions, 98 rules | missing: simple.soar, selection.soar; defaults filled: selection.soar, simple.soar |
| blocks-world-lookahead | V4 | blocks-world-book-2019.zip: blocks-world-book-2019/blocks-world-lookahead.soar<br>blocks-world-book-2019-x.zip: blocks-world-book-2019-x/blocks-world-lookahead.soar<br>RL-general-state.zip: BLOCKS-WORLD/blocks-world-book-2019-world/blocks-world-lookahead.soar<br>RL-general-state.zip: BLOCKS-WORLD/blocks-world-book-2019/blocks-world-lookahead.soar | 300+ decisions, 101 rules | missing: simple.soar, selection.soar; defaults filled: selection.soar, simple.soar |
| blocks-world-lookahead-state-evaluation | V1 | xx-BLOCKS-WORLD: blocks-world-book/blocks-world-lookahead-state-evaluation.soar | 300+ decisions, 94 rules; load error: Failed to open file for reading: Impasse__Operator_Tie_source.soar | missing: simple.soar, selection.soar, Impasse__Operator_Tie_source.soar; defaults filled: selection.soar, simple.soar |
| blocks-world-lookahead-state-evaluation | V2 | BW-Hierarchical.zip: blocks-world-lookahead-state-evaluation/blocks-world-lookahead-state-evaluation.soar<br>RL-general-state.zip: BLOCKS-WORLD/blocks-world-lookahead-state-evaluation/blocks-world-lookahead-state-evaluation.soar | 54 decisions, 103 rules | missing: simple.soar, selection.soar; defaults filled: selection.soar, simple.soar |
| blocks-world-lookahead-state-evaluation | V3 | blocks-world-book.zip: blocks-world-book/blocks-world-lookahead-state-evaluation.soar<br>blocks-world-book-2019.zip: blocks-world-book-2019/blocks-world-lookahead-state-evaluation.soar<br>blocks-world-book-2019-x.zip: blocks-world-book-2019-x/blocks-world-lookahead-state-evaluation.soar<br>blocks-world-book-2019-world.zip: blocks-world-book-2019-world/blocks-world-lookahead-state-evaluation.soar<br>RL-general-state.zip: BLOCKS-WORLD/blocks-world-book-2019-world/blocks-world-lookahead-state-evaluation.soar<br>RL-general-state.zip: BLOCKS-WORLD/blocks-world-book-2019/blocks-world-lookahead-state-evaluation.soar | 300+ decisions, 103 rules | missing: simple.soar, selection.soar; defaults filled: selection.soar, simple.soar |
| blocks-world-operator-subgoaling | V1 | epmem-tutorial.zip: all-test/blocks-world/blocks-world-operator-subgoaling.soar | 5 decisions, 16 rules |  |
| blocks-world-operator-subgoaling | V2 | xx-BLOCKS-WORLD: blocks-world-book/blocks-world-operator-subgoaling.soar | 100 decisions, 0 rules; load error: For a detailed article about the chunk command, use 'help chunk'. | missing: all_source.soar, elaborations_source.soar, move-block_source.soar |
| blocks-world-operator-subgoaling | V3 | BW-Hierarchical.zip: Soar-BW-Opsub-Examples/blocks-world/blocks-world-operator-subgoaling.soar<br>blocks-world-book-2019.zip: blocks-world-book-2019/blocks-world-operator-subgoaling.soar<br>RL-general-state.zip: BLOCKS-WORLD/Soar-BW-Opsub-Examples/blocks-world/blocks-world-operator-subgoaling.soar<br>RL-general-state.zip: BLOCKS-WORLD/blocks-world-book-2019/blocks-world-operator-subgoaling.soar | 5 decisions, 16 rules |  |
| blocks-world-operator-subgoaling | V4 | BW-Hierarchical.zip: blocks-world-operator-subgoaling/blocks-world-operator-subgoaling.soar<br>RL-general-state.zip: BLOCKS-WORLD/blocks-world-operator-subgoaling/blocks-world-operator-subgoaling.soar | 5 decisions, 20 rules |  |
| blocks-world-operator-subgoaling | V5 | blocks-world-book.zip: blocks-world-book/blocks-world-operator-subgoaling.soar | 5 decisions, 19 rules; load error: For a detailed article about the chunk command, use 'help chunk'. |  |
| blocks-world-operator-subgoaling | V6 | blocks-world-book-2019-x.zip: blocks-world-book-2019-x/blocks-world-operator-subgoaling.soar<br>blocks-world-book-2019-world.zip: blocks-world-book-2019-world/blocks-world-operator-subgoaling.soar<br>RL-general-state.zip: BLOCKS-WORLD/blocks-world-book-2019-world/blocks-world-operator-subgoaling.soar | 5 decisions, 19 rules |  |
| blocks-world-operator-subgoaling-lookahead | V1 | xx-BLOCKS-WORLD: blocks-world-book/blocks-world-operator-subgoaling-lookahead.soar | 100 decisions, 0 rules; load error: Error changing to all | missing: all_source.soar, elaborations_source.soar, move-block_source.soar |
| blocks-world-operator-subgoaling-lookahead | V2 | blocks-world-book.zip: blocks-world-book/blocks-world-operator-subgoaling-lookahead.soar | 101 decisions, 20 rules |  |
| blocks-world-operator-subgoaling-RL | V1 | xx-BLOCKS-WORLD: blocks-world-book/blocks-world-operator-subgoaling-RL.soar | 100 decisions, 0 rules; load error: Error changing to all | missing: all_source.soar, elaborations_source.soar, move-block_source.soar |
| blocks-world-operator-subgoaling-RL | V2 | blocks-world-book.zip: blocks-world-book/blocks-world-operator-subgoaling-RL.soar<br>blocks-world-book-2019-x.zip: blocks-world-book-2019-x/blocks-world-operator-subgoaling-RL.soar<br>blocks-world-book-2019-world.zip: blocks-world-book-2019-world/blocks-world-operator-subgoaling-RL.soar<br>RL-general-state.zip: BLOCKS-WORLD/blocks-world-book-2019-world/blocks-world-operator-subgoaling-RL.soar | 9 decisions, 23 rules |  |
| blocks-world-operator-subgoaling-RL | V3 | blocks-world-book-2019.zip: blocks-world-book-2019/blocks-world-operator-subgoaling-RL.soar<br>RL-general-state.zip: BLOCKS-WORLD/blocks-world-book-2019/blocks-world-operator-subgoaling-RL.soar | 9 decisions, 23 rules |  |
| blocks-world-operator-subgoaling-RL | V4 | RL-general-state.zip: BLOCKS-WORLD/blocks-world-operator-subgoaling-RL/blocks-world-operator-subgoaling-RL.soar | 16 decisions, 23 rules |  |
| blocks-world-operator-subgoaling-RL-world | V1 | blocks-world-book-2019.zip: blocks-world-book-2019/blocks-world-operator-subgoaling-RL-world.soar<br>RL-general-state.zip: BLOCKS-WORLD/blocks-world-book-2019/blocks-world-operator-subgoaling-RL-world.soar | 6 decisions, 20 rules |  |
| blocks-world-opsub-lookahead | V1 | BW-Hierarchical.zip: Soar-BW-Opsub-Examples/blocks-world/blocks-world-opsub-lookahead.soar<br>RL-general-state.zip: BLOCKS-WORLD/Soar-BW-Opsub-Examples/blocks-world/blocks-world-opsub-lookahead.soar | 38 decisions, 125 rules |  |
| blocks-world-opsub-lookahead | V2 | blocks-world-book-2019.zip: blocks-world-book-2019/blocks-world-opsub-lookahead.soar<br>RL-general-state.zip: BLOCKS-WORLD/blocks-world-book-2019/blocks-world-opsub-lookahead.soar | 300+ decisions, 113 rules | missing: simple.soar, selection.soar; defaults filled: selection.soar, simple.soar |
| blocks-world-opsub-lookahead | V3 | blocks-world-book-2019-x.zip: blocks-world-book-2019-x/blocks-world-opsub-lookahead.soar<br>blocks-world-book-2019-world.zip: blocks-world-book-2019-world/blocks-world-opsub-lookahead.soar<br>RL-general-state.zip: BLOCKS-WORLD/blocks-world-book-2019-world/blocks-world-opsub-lookahead.soar | 300+ decisions, 114 rules | missing: simple.soar, selection.soar; defaults filled: selection.soar, simple.soar |
| blocks-world-opsub-lookahead-hierarchical | V1 | blocks-world-book-2019.zip: blocks-world-book-2019/blocks-world-opsub-lookahead-hierarchical.soar<br>blocks-world-book-2019-x.zip: blocks-world-book-2019-x/blocks-world-opsub-lookahead-hierarchical.soar<br>blocks-world-book-2019-world.zip: blocks-world-book-2019-world/blocks-world-opsub-lookahead-hierarchical.soar<br>RL-general-state.zip: BLOCKS-WORLD/blocks-world-book-2019-world/blocks-world-opsub-lookahead-hierarchical.soar<br>RL-general-state.zip: BLOCKS-WORLD/blocks-world-book-2019/blocks-world-opsub-lookahead-hierarchical.soar | 300+ decisions, 95 rules; load error: Production addition failed. | missing: simple.soar, selection.soar; defaults filled: selection.soar, simple.soar |
| blocks-world-RL | V1 | xx-BLOCKS-WORLD: blocks-world-book/blocks-world-RL.soar | 100 decisions, 0 rules; load error: Error changing to all | missing: all_source.soar, elaborations_source.soar |
| blocks-world-RL | V2 | blocks-world-book.zip: blocks-world-book/blocks-world-RL.soar | 300+ decisions, 5131 rules |  |
| blocks-world-RL | V3 | blocks-world-book-2019.zip: blocks-world-book-2019/blocks-world-RL.soar<br>blocks-world-book-2019-x.zip: blocks-world-book-2019-x/blocks-world-RL.soar<br>blocks-world-book-2019-world.zip: blocks-world-book-2019-world/blocks-world-RL.soar<br>RL-general-state.zip: BLOCKS-WORLD/blocks-world-book-2019-world/blocks-world-RL.soar<br>RL-general-state.zip: BLOCKS-WORLD/blocks-world-book-2019/blocks-world-RL.soar | 300+ decisions, 14 rules |  |
| blocks-world-simple | V1 | xx-BLOCKS-WORLD: blocks-world-book/blocks-world-simple.soar | 100 decisions, 0 rules; load error: Error changing to all | missing: all_source.soar, elaborations_source.soar |
| blocks-world-simple | V2 | blocks-world-book.zip: blocks-world-book/blocks-world-simple.soar | 8 decisions, 12 rules |  |
| blocks-world-simple | V3 | blocks-world-book-2019.zip: blocks-world-book-2019/blocks-world-simple.soar<br>blocks-world-book-2019-x.zip: blocks-world-book-2019-x/blocks-world-simple.soar<br>RL-general-state.zip: BLOCKS-WORLD/blocks-world-book-2019-world/blocks-world-simple.soar | 8 decisions, 12 rules |  |
| blocks-world-simple | V4 | RL-general-state.zip: BLOCKS-WORLD/blocks-world-book-2019/blocks-world-simple.soar | 8 decisions, 12 rules |  |
| blocksworld | V1 | BW-Hierarchical.zip: BW-SoarManual/blocksworld.soar<br>RL-general-state.zip: BLOCKS-WORLD/BW-SoarManual/blocksworld.soar | 2 decisions, 9 rules |  |
| blocksworld | V2 | arithmetic-smem.zip: john-nlp/manage-world-state/internal-worlds/blocksworld.soar | 100 decisions, 1 rules |  |
| blocksworld | V3 | arithmetic-smem.zip: john-nlp/manage-world-state/waypoint-maps/blocksworld.soar | 100 decisions, 1 rules |  |
| buttons | V1 | epmem-tutorial.zip: all-test/Mummy/buttons.soar | 105 decisions, 161 rules |  |
| BW-Agent-Simple | V1 | arithmetic-smem.zip: xxxxxblocks-world-agent/BW-Agent-Simple.soar | 100 decisions, 0 rules; load error: Failed to open file for reading: selection-world2.soar | obsolete (xxxxx folder): needs selection-world2.soar and selection-iterative-deepening2.soar (not in the zip) and an event source for agent-world; missing: selection-world2.soar, selection-iterative-deepening2.soar |
| BW-Hierarchical | V1 | BW-Hierarchical.zip: BW-Hierarchical/BW-Hierarchical.soar | 300+ decisions, 51 rules | missing: simple.soar; defaults filled: simple.soar |
| BW-Hierarchical | V2 | 2026-agents-verified.zip: 2026-agents-verified/Blocks-world/BW-Hierarchical/BW-Hierarchical.soar<br>Water-jugs.zip: Blocks-world/BW-Hierarchical/BW-Hierarchical.soar | 300+ decisions, 51 rules |  |
| BW-Hierarchical-LA | V1 | BW-Hierarchical.zip: BW-Hierarchical-LA/BW-Hierarchical-LA.soar | 300+ decisions, 113 rules; load error: Failed to open file for reading: Impasse__State_No-Change_source.soar | missing: simple.soar, selection.soar, Impasse__State_No-Change_source.soar; defaults filled: selection.soar, simple.soar |
| BW-Hierarchical-LA | V2 | RL-general-state.zip: BLOCKS-WORLD/BW-Hierarchical-LA/BW-Hierarchical-LA.soar | 300+ decisions, 113 rules; load error: Error changing to Impasse__State_No-Change | dangling pushd of an empty nested impasse folder stops loading; corrected as V3; missing: Impasse__State_No-Change_source.soar |
| BW-Hierarchical-LA | V3 | — | 51 decisions, 157 rules | corrected V2: an empty VisualSoar impasse folder nested in itself makes a pushd fail; Soar stops loading there |
| BW-LA | V1 | BW-Hierarchical.zip: BW-LA/BW-LA.soar | 25 decisions, 98 rules | missing: simple.soar, selection.soar; defaults filled: selection.soar, simple.soar |
| BW-LA | V2 | 2026-agents-verified.zip: 2026-agents-verified/Blocks-world/BW-LA/BW-LA.soar<br>Water-jugs.zip: Blocks-world/BW-LA/BW-LA.soar | 25 decisions, 97 rules |  |
| BW-LA-state-eval | V1 | BW-Hierarchical.zip: BW-LA-state-eval/BW-LA-state-eval.soar | 43 decisions, 103 rules | missing: simple.soar, selection.soar; defaults filled: selection.soar, simple.soar |
| BW-LA-state-eval | V2 | 2026-agents-verified.zip: 2026-agents-verified/Blocks-world/BW-LA-state-eval/BW-LA-state-eval.soar<br>Water-jugs.zip: Blocks-world/BW-LA-state-eval/BW-LA-state-eval.soar | 43 decisions, 102 rules |  |
| BW-LA-X | V1 | 2026-agents-verified.zip: 2026-agents-verified/Blocks-world/BW-LA/BW-LA-X.soar<br>Water-jugs.zip: Blocks-world/BW-LA/BW-LA-X.soar | 25 decisions, 97 rules |  |
| BW-Op-Subgoal | V1 | BW-Hierarchical.zip: BW-Op-Subgoal/BW-Op-Subgoal.soar<br>RL-general-state.zip: BLOCKS-WORLD/BW-Op-Subgoal/BW-Op-Subgoal.soar | 5 decisions, 20 rules |  |
| BW-Op-Subgoal-RL | V1 | BW-Hierarchical.zip: BW-Op-Subgoal-RL/BW-Op-Subgoal-RL.soar<br>RL-general-state.zip: BLOCKS-WORLD/BW-Op-Subgoal-RL/BW-Op-Subgoal-RL.soar | 16 decisions, 23 rules |  |
| BW-RL | V1 | BW-Hierarchical.zip: BW-RL/BW-RL.soar | 300+ decisions, 5131 rules |  |
| BW-RL | V2 | 2026-agents-verified.zip: 2026-agents-verified/Blocks-world/BW-RL/BW-RL.soar<br>Water-jugs.zip: Blocks-world/BW-RL/BW-RL.soar | 300+ decisions, 5131 rules |  |
| BW-Simple | V1 | BW-Hierarchical.zip: BW-Simple/BW-Simple.soar | 8 decisions, 18 rules |  |
| BW-Simple | V2 | 2026-agents-verified.zip: 2026-agents-verified/Blocks-world/BW-Simple/BW-Simple.soar<br>Water-jugs.zip: Blocks-world/BW-Simple/BW-Simple.soar | 8 decisions, 18 rules |  |
| chal | V1 | epmem-tutorial.zip: Dice Game/dicegame-0.1.1/agents/chal.soar | 300+ decisions, 2 rules |  |
| ChunkingDemoTests_Demo_Arithmetic | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingDemoTests_Demo_Arithmetic.soar | 300+ decisions, 86 rules |  |
| ChunkingDemoTests_Demo_Arithmetic_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingDemoTests_Demo_Arithmetic_expected.soar | 100 decisions, 29 rules |  |
| ChunkingDemoTests_Demo_Blocks_World_Hierarchical | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingDemoTests_Demo_Blocks_World_Hierarchical.soar | 300+ decisions, 52 rules |  |
| ChunkingDemoTests_Demo_Blocks_World_Hierarchical_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingDemoTests_Demo_Blocks_World_Hierarchical_expected.soar | 100 decisions, 20 rules |  |
| ChunkingDemoTests_Demo_Blocks_World_Hierarchical_Look_Ahead | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingDemoTests_Demo_Blocks_World_Hierarchical_Look_Ahead.soar | 51 decisions, 158 rules |  |
| ChunkingDemoTests_Demo_Blocks_World_Hierarchical_Look_Ahead_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingDemoTests_Demo_Blocks_World_Hierarchical_Look_Ahead_expected.soar | 100 decisions, 1 rules |  |
| ChunkingDemoTests_Demo_Blocks_World_Look_Ahead | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingDemoTests_Demo_Blocks_World_Look_Ahead.soar | 25 decisions, 99 rules |  |
| ChunkingDemoTests_Demo_Blocks_World_Look_Ahead_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingDemoTests_Demo_Blocks_World_Look_Ahead_expected.soar | 100 decisions, 8 rules |  |
| ChunkingDemoTests_Demo_Blocks_World_Look_Ahead_State_Evaluation | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingDemoTests_Demo_Blocks_World_Look_Ahead_State_Evaluation.soar | 92 decisions, 104 rules |  |
| ChunkingDemoTests_Demo_Blocks_World_Look_Ahead_State_Evaluation_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingDemoTests_Demo_Blocks_World_Look_Ahead_State_Evaluation_expected.soar | 100 decisions, 24 rules |  |
| ChunkingDemoTests_Demo_Blocks_World_Operator_Subgoaling | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingDemoTests_Demo_Blocks_World_Operator_Subgoaling.soar | 5 decisions, 20 rules |  |
| ChunkingDemoTests_Demo_Blocks_World_Operator_Subgoaling_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingDemoTests_Demo_Blocks_World_Operator_Subgoaling_expected.soar | 100 decisions, 1 rules |  |
| ChunkingDemoTests_Demo_Eight_Puzzle | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingDemoTests_Demo_Eight_Puzzle.soar | 29 decisions, 87 rules |  |
| ChunkingDemoTests_Demo_Eight_Puzzle_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingDemoTests_Demo_Eight_Puzzle_expected.soar | 100 decisions, 7 rules |  |
| ChunkingDemoTests_Demo_Graph_Search | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingDemoTests_Demo_Graph_Search.soar | 300+ decisions, 125 rules |  |
| ChunkingDemoTests_Demo_MaC_Planning | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingDemoTests_Demo_MaC_Planning.soar | 123 decisions, 94 rules |  |
| ChunkingDemoTests_Demo_MaC_Planning_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingDemoTests_Demo_MaC_Planning_expected.soar | 100 decisions, 34 rules |  |
| ChunkingDemoTests_Demo_RL_Unit | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingDemoTests_Demo_RL_Unit.soar | 25 decisions, 37 rules |  |
| ChunkingDemoTests_Demo_RL_Unit_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingDemoTests_Demo_RL_Unit_expected.soar | 100 decisions, 15 rules |  |
| ChunkingDemoTests_Demo_ToH_Recursive | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingDemoTests_Demo_ToH_Recursive.soar | 300+ decisions, 19 rules | soar-lean exceeds the 600 s limit (run time grows faster than linearly) |
| ChunkingDemoTests_Demo_ToH_Recursive_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingDemoTests_Demo_ToH_Recursive_expected.soar | 100 decisions, 61 rules |  |
| ChunkingDemoTests_Demo_Water_Jug_Hierarchy | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingDemoTests_Demo_Water_Jug_Hierarchy.soar | 300+ decisions, 22 rules |  |
| ChunkingDemoTests_Demo_Water_Jug_Hierarchy_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingDemoTests_Demo_Water_Jug_Hierarchy_expected.soar | 100 decisions, 3 rules |  |
| ChunkingDemoTests_Demo_Water_Jug_Look_Ahead | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingDemoTests_Demo_Water_Jug_Look_Ahead.soar | 300+ decisions, 96 rules |  |
| ChunkingDemoTests_Demo_Water_Jug_Look_Ahead_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingDemoTests_Demo_Water_Jug_Look_Ahead_expected.soar | 100 decisions, 26 rules |  |
| ChunkingDemoTests_Demo_Water_Jug_Tie | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingDemoTests_Demo_Water_Jug_Tie.soar | 300+ decisions, 30 rules |  |
| ChunkingDemoTests_Demo_Water_Jug_Tie_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingDemoTests_Demo_Water_Jug_Tie_expected.soar | 100 decisions, 5 rules |  |
| ChunkingDemoTests_Elio_Agent | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingDemoTests_Elio_Agent.soar | 100 decisions, 0 rules | invalid chunk settings (lhs-repair, rhs-repair) stop loading in Soar 9.6.5; corrected as V2 |
| ChunkingDemoTests_Elio_Agent | V2 | — | 23 decisions, 0 rules; load error: Open file failed. | corrected V1: chunk lhs-repair / rhs-repair are not Soar 9.6.5 settings; Soar stops loading there (no rules load) |
| ChunkingDemoTests_Elio_Agent_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingDemoTests_Elio_Agent_expected.soar | 100 decisions, 135 rules |  |
| ChunkingDemoTests_PRIMS_Sanity1 | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingDemoTests_PRIMS_Sanity1.soar | 300+ decisions, 268 rules |  |
| ChunkingDemoTests_PRIMS_Sanity1_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingDemoTests_PRIMS_Sanity1_expected.soar | 100 decisions, 23 rules |  |
| ChunkingDemoTests_PRIMS_Sanity2 | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingDemoTests_PRIMS_Sanity2.soar | 300+ decisions, 262 rules |  |
| ChunkingDemoTests_PRIMS_Sanity2_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingDemoTests_PRIMS_Sanity2_expected.soar | 100 decisions, 19 rules |  |
| ChunkingDemoTests_Teach_Soar_90_Games | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingDemoTests_Teach_Soar_90_Games.soar | 100 decisions, 0 rules | invalid chunk settings (lhs-repair, rhs-repair) stop loading in Soar 9.6.5; corrected as V2 |
| ChunkingDemoTests_Teach_Soar_90_Games | V2 | — | 300+ decisions, 4736 rules | corrected V1: chunk lhs-repair / rhs-repair are not Soar 9.6.5 settings; Soar stops loading there (no rules load) |
| ChunkingDemoTests_Teach_Soar_90_Games_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingDemoTests_Teach_Soar_90_Games_expected.soar | 100 decisions, 28 rules |  |
| ChunkingDemoTests_Teach_Soar_9_Games | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingDemoTests_Teach_Soar_9_Games.soar | 100 decisions, 0 rules | invalid chunk settings (lhs-repair, rhs-repair) stop loading in Soar 9.6.5; corrected as V2 |
| ChunkingDemoTests_Teach_Soar_9_Games | V2 | — | 300+ decisions, 3941 rules | corrected V1: chunk lhs-repair / rhs-repair are not Soar 9.6.5 settings; Soar stops loading there (no rules load) |
| ChunkingDemoTests_Teach_Soar_9_Games_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingDemoTests_Teach_Soar_9_Games_expected.soar | 100 decisions, 60 rules |  |
| ChunkingTests_All_Test_Types | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_All_Test_Types.soar | 5 decisions, 7 rules |  |
| ChunkingTests_All_Test_Types_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_All_Test_Types_expected.soar | 100 decisions, 1 rules |  |
| ChunkingTests_BUNCPS_0 | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_BUNCPS_0.soar | 5 decisions, 8 rules |  |
| ChunkingTests_BUNCPS_0_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_BUNCPS_0_expected.soar | 100 decisions, 1 rules |  |
| ChunkingTests_BUNCPS_1 | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_BUNCPS_1.soar | 5 decisions, 9 rules |  |
| ChunkingTests_BUNCPS_1_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_BUNCPS_1_expected.soar | 100 decisions, 1 rules |  |
| ChunkingTests_BUNCPS_2 | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_BUNCPS_2.soar | 5 decisions, 9 rules |  |
| ChunkingTests_BUNCPS_2_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_BUNCPS_2_expected.soar | 100 decisions, 1 rules |  |
| ChunkingTests_BUNCPS_3 | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_BUNCPS_3.soar | 4 decisions, 6 rules |  |
| ChunkingTests_BUNCPS_3_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_BUNCPS_3_expected.soar | 100 decisions, 1 rules |  |
| ChunkingTests_BUNCPS_4 | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_BUNCPS_4.soar | 5 decisions, 9 rules |  |
| ChunkingTests_BUNCPS_4_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_BUNCPS_4_expected.soar | 100 decisions, 1 rules |  |
| ChunkingTests_BUNCPS_5 | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_BUNCPS_5.soar | 6 decisions, 8 rules |  |
| ChunkingTests_BUNCPS_5_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_BUNCPS_5_expected.soar | 100 decisions, 1 rules |  |
| ChunkingTests_BUNCPS_6_Four_Level | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_BUNCPS_6_Four_Level.soar | 4 decisions, 7 rules |  |
| ChunkingTests_BUNCPS_6_Four_Level_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_BUNCPS_6_Four_Level_expected.soar | 100 decisions, 2 rules |  |
| ChunkingTests_BUNCPS_7_with_Constraints | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_BUNCPS_7_with_Constraints.soar | 4 decisions, 8 rules |  |
| ChunkingTests_BUNCPS_7_with_Constraints_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_BUNCPS_7_with_Constraints_expected.soar | 100 decisions, 1 rules |  |
| ChunkingTests_Chunk_All_Only_Except | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_Chunk_All_Only_Except.soar | 3 decisions, 7 rules |  |
| ChunkingTests_Chunk_Operator_Tie_Impasse | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_Chunk_Operator_Tie_Impasse.soar | 3 decisions, 9 rules |  |
| ChunkingTests_Chunk_Operator_Tie_Impasse_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_Chunk_Operator_Tie_Impasse_expected.soar | 100 decisions, 2 rules |  |
| ChunkingTests_Chunk_Operator_Tie_Item_Links | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_Chunk_Operator_Tie_Item_Links.soar | 1 decisions, 5 rules |  |
| ChunkingTests_Chunk_Operator_Tie_Item_Links_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_Chunk_Operator_Tie_Item_Links_expected.soar | 100 decisions, 1 rules |  |
| ChunkingTests_Chunk_RL_Proposal | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_Chunk_RL_Proposal.soar | 101 decisions, 3 rules |  |
| ChunkingTests_Chunk_RL_Proposal_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_Chunk_RL_Proposal_expected.soar | 100 decisions, 2 rules |  |
| ChunkingTests_Chunk_Superstate_Operator_Preference | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_Chunk_Superstate_Operator_Preference.soar | 2 decisions, 7 rules |  |
| ChunkingTests_Chunk_Superstate_Operator_Preference_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_Chunk_Superstate_Operator_Preference_expected.soar | 100 decisions, 1 rules |  |
| ChunkingTests_Chunked_Justification_with_extras | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_Chunked_Justification_with_extras.soar | 7 decisions, 15 rules |  |
| ChunkingTests_Chunked_Justification_with_extras_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_Chunked_Justification_with_extras_expected.soar | 100 decisions, 1 rules |  |
| ChunkingTests_Conflated_Constants | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_Conflated_Constants.soar | 3 decisions, 7 rules |  |
| ChunkingTests_Conflated_Constants_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_Conflated_Constants_expected.soar | 100 decisions, 1 rules |  |
| ChunkingTests_Constraint_Prop_from_Base_Conds | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_Constraint_Prop_from_Base_Conds.soar | 3 decisions, 7 rules |  |
| ChunkingTests_Constraint_Prop_from_Base_Conds_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_Constraint_Prop_from_Base_Conds_expected.soar | 100 decisions, 1 rules |  |
| ChunkingTests_Constraint_Prop_Simple | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_Constraint_Prop_Simple.soar | 3 decisions, 5 rules |  |
| ChunkingTests_Constraint_Prop_Simple_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_Constraint_Prop_Simple_expected.soar | 100 decisions, 1 rules |  |
| ChunkingTests_Constraint_Ungrounded | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_Constraint_Ungrounded.soar | 4 decisions, 5 rules |  |
| ChunkingTests_Constraint_Ungrounded_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_Constraint_Ungrounded_expected.soar | 100 decisions, 1 rules |  |
| ChunkingTests_Deep_Copy_Identity_Expansion | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_Deep_Copy_Identity_Expansion.soar | 2 decisions, 10 rules |  |
| ChunkingTests_Deep_Copy_Identity_Expansion_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_Deep_Copy_Identity_Expansion_expected.soar | 100 decisions, 4 rules |  |
| ChunkingTests_Disjunction_Merge | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_Disjunction_Merge.soar | 3 decisions, 5 rules |  |
| ChunkingTests_Disjunction_Merge_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_Disjunction_Merge_expected.soar | 100 decisions, 1 rules |  |
| ChunkingTests_Duplicates | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_Duplicates.soar | 4 decisions, 7 rules |  |
| ChunkingTests_Duplicates_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_Duplicates_expected.soar | 100 decisions, 2 rules |  |
| ChunkingTests_Faux_Operator | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_Faux_Operator.soar | 105 decisions, 7 rules |  |
| ChunkingTests_Faux_Operator_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_Faux_Operator_expected.soar | 100 decisions, 3 rules |  |
| ChunkingTests_Faux_Smem_Operator_RHS | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_Faux_Smem_Operator_RHS.soar | 103 decisions, 5 rules |  |
| ChunkingTests_Faux_Smem_Operator_RHS_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_Faux_Smem_Operator_RHS_expected.soar | 101 decisions, 1 rules |  |
| ChunkingTests_Justification_RC_not_Ungrounded_STIs | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_Justification_RC_not_Ungrounded_STIs.soar | 6 decisions, 9 rules |  |
| ChunkingTests_Justification_RC_not_Ungrounded_STIs_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_Justification_RC_not_Ungrounded_STIs_expected.soar | 100 decisions, 1 rules |  |
| ChunkingTests_Justifications_Get_New_Identities | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_Justifications_Get_New_Identities.soar | 2 decisions, 8 rules |  |
| ChunkingTests_Justifications_Get_New_Identities_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_Justifications_Get_New_Identities_expected.soar | 100 decisions, 1 rules |  |
| ChunkingTests_Link_STM_to_LTM | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_Link_STM_to_LTM.soar | 5 decisions, 10 rules |  |
| ChunkingTests_Link_STM_to_LTM_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_Link_STM_to_LTM_expected.soar | 100 decisions, 4 rules |  |
| ChunkingTests_Literalization_of_NC_and_NCC | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_Literalization_of_NC_and_NCC.soar | 3 decisions, 5 rules |  |
| ChunkingTests_Literalization_of_NC_and_NCC_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_Literalization_of_NC_and_NCC_expected.soar | 100 decisions, 1 rules |  |
| ChunkingTests_Literalization_Simple | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_Literalization_Simple.soar | 3 decisions, 5 rules |  |
| ChunkingTests_Literalization_Simple_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_Literalization_Simple_expected.soar | 100 decisions, 1 rules |  |
| ChunkingTests_Literalization_with_BT_Constraints | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_Literalization_with_BT_Constraints.soar | 3 decisions, 6 rules |  |
| ChunkingTests_Literalization_with_BT_Constraints2 | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_Literalization_with_BT_Constraints2.soar | 3 decisions, 8 rules |  |
| ChunkingTests_Literalization_with_BT_Constraints2_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_Literalization_with_BT_Constraints2_expected.soar | 100 decisions, 2 rules |  |
| ChunkingTests_Literalization_with_BT_Constraints_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_Literalization_with_BT_Constraints_expected.soar | 100 decisions, 1 rules |  |
| ChunkingTests_Literalization_with_Constraints | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_Literalization_with_Constraints.soar | 3 decisions, 5 rules |  |
| ChunkingTests_Literalization_with_Constraints_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_Literalization_with_Constraints_expected.soar | 100 decisions, 1 rules |  |
| ChunkingTests_Maintain_Instantiation_Specific_Identity | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_Maintain_Instantiation_Specific_Identity.soar | 2 decisions, 5 rules |  |
| ChunkingTests_Maintain_Instantiation_Specific_Identity_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_Maintain_Instantiation_Specific_Identity_expected.soar | 100 decisions, 1 rules |  |
| ChunkingTests_Max_Chunks | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_Max_Chunks.soar | 101 decisions, 6 rules |  |
| ChunkingTests_Max_Dupes | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_Max_Dupes.soar | 100 decisions, 3 rules |  |
| ChunkingTests_NC_Disjunction | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_NC_Disjunction.soar | 3 decisions, 4 rules |  |
| ChunkingTests_NC_Disjunction_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_NC_Disjunction_expected.soar | 100 decisions, 1 rules |  |
| ChunkingTests_NC_Simple_No_Exist | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_NC_Simple_No_Exist.soar | 3 decisions, 7 rules |  |
| ChunkingTests_NC_Simple_No_Exist_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_NC_Simple_No_Exist_expected.soar | 100 decisions, 1 rules |  |
| ChunkingTests_NC_with_RC_and_Local_Variable | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_NC_with_RC_and_Local_Variable.soar | 3 decisions, 7 rules |  |
| ChunkingTests_NC_with_RC_and_Local_Variable_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_NC_with_RC_and_Local_Variable_expected.soar | 100 decisions, 1 rules |  |
| ChunkingTests_NC_with_Relational_Constraint | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_NC_with_Relational_Constraint.soar | 3 decisions, 7 rules |  |
| ChunkingTests_NC_with_Relational_Constraint_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_NC_with_Relational_Constraint_expected.soar | 100 decisions, 1 rules |  |
| ChunkingTests_NCC_2_Conds_Simple_Literals | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_NCC_2_Conds_Simple_Literals.soar | 3 decisions, 7 rules |  |
| ChunkingTests_NCC_2_Conds_Simple_Literals_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_NCC_2_Conds_Simple_Literals_expected.soar | 100 decisions, 1 rules |  |
| ChunkingTests_NCC_Complex | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_NCC_Complex.soar | 3 decisions, 8 rules |  |
| ChunkingTests_NCC_Complex_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_NCC_Complex_expected.soar | 100 decisions, 1 rules |  |
| ChunkingTests_NCC_from_Backtrace | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_NCC_from_Backtrace.soar | 3 decisions, 7 rules |  |
| ChunkingTests_NCC_from_Backtrace_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_NCC_from_Backtrace_expected.soar | 100 decisions, 1 rules |  |
| ChunkingTests_NCC_Simple_Literals | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_NCC_Simple_Literals.soar | 3 decisions, 7 rules |  |
| ChunkingTests_NCC_Simple_Literals_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_NCC_Simple_Literals_expected.soar | 100 decisions, 1 rules |  |
| ChunkingTests_NCC_with_Relational_Constraint | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_NCC_with_Relational_Constraint.soar | 3 decisions, 7 rules |  |
| ChunkingTests_NCC_with_Relational_Constraint_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_NCC_with_Relational_Constraint_expected.soar | 100 decisions, 1 rules |  |
| ChunkingTests_No_Grounds | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_No_Grounds.soar | 150 decisions, 4 rules |  |
| ChunkingTests_No_Topstate_Match | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_No_Topstate_Match.soar | 2 decisions, 4 rules |  |
| ChunkingTests_No_Topstate_Match_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_No_Topstate_Match_expected.soar | 100 decisions, 1 rules |  |
| ChunkingTests_Opaque_State_Barrier | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_Opaque_State_Barrier.soar | 2 decisions, 6 rules |  |
| ChunkingTests_Opaque_State_Barrier_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_Opaque_State_Barrier_expected.soar | 100 decisions, 1 rules |  |
| ChunkingTests_Operator_Selection_Knowledge | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_Operator_Selection_Knowledge.soar | timeout |  |
| ChunkingTests_Operator_Selection_Knowledge_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_Operator_Selection_Knowledge_expected.soar | 100 decisions, 20 rules |  |
| ChunkingTests_Operator_Selection_Knowledge_Ghost_Operator | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_Operator_Selection_Knowledge_Ghost_Operator.soar | 3 decisions, 9 rules |  |
| ChunkingTests_Operator_Selection_Knowledge_Ghost_Operator_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_Operator_Selection_Knowledge_Ghost_Operator_expected.soar | 100 decisions, 1 rules |  |
| ChunkingTests_Operator_Selection_Knowledge_In_Proposal | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_Operator_Selection_Knowledge_In_Proposal.soar | 100 decisions, 0 rules | invalid chunk settings (lhs-repair, rhs-repair) stop loading in Soar 9.6.5; corrected as V2 |
| ChunkingTests_Operator_Selection_Knowledge_In_Proposal | V2 | — | 6 decisions, 32 rules | corrected V1: chunk lhs-repair / rhs-repair are not Soar 9.6.5 settings; Soar stops loading there (no rules load) |
| ChunkingTests_Operator_Selection_Knowledge_In_Proposal_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_Operator_Selection_Knowledge_In_Proposal_expected.soar | 100 decisions, 2 rules |  |
| ChunkingTests_Promoted_STI | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_Promoted_STI.soar | 2 decisions, 5 rules |  |
| ChunkingTests_Promoted_STI_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_Promoted_STI_expected.soar | 100 decisions, 1 rules |  |
| ChunkingTests_Reorderer_Bad_Conjunction | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_Reorderer_Bad_Conjunction.soar | 2 decisions, 4 rules |  |
| ChunkingTests_Reorderer_Bad_Conjunction_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_Reorderer_Bad_Conjunction_expected.soar | 100 decisions, 1 rules |  |
| ChunkingTests_Repair_NOR_Temporal_Constraint | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_Repair_NOR_Temporal_Constraint.soar | 4 decisions, 9 rules |  |
| ChunkingTests_Repair_NOR_Temporal_Constraint_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_Repair_NOR_Temporal_Constraint_expected.soar | 100 decisions, 3 rules |  |
| ChunkingTests_Repair_Unconnected_RHS_ID | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_Repair_Unconnected_RHS_ID.soar | 3 decisions, 4 rules |  |
| ChunkingTests_Repair_Unconnected_RHS_ID_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_Repair_Unconnected_RHS_ID_expected.soar | 100 decisions, 2 rules |  |
| ChunkingTests_Result_On_Operator | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_Result_On_Operator.soar | 200 decisions, 4 rules |  |
| ChunkingTests_Result_On_Operator_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_Result_On_Operator_expected.soar | 100 decisions, 1 rules |  |
| ChunkingTests_Rete_Bug_Deep_vs_Deep | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_Rete_Bug_Deep_vs_Deep.soar | 3 decisions, 7 rules |  |
| ChunkingTests_Rete_Bug_Deep_vs_Deep_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_Rete_Bug_Deep_vs_Deep_expected.soar | 100 decisions, 1 rules |  |
| ChunkingTests_Rete_Bug_Deep_vs_Top | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_Rete_Bug_Deep_vs_Top.soar | 3 decisions, 7 rules |  |
| ChunkingTests_Rete_Bug_Deep_vs_Top_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_Rete_Bug_Deep_vs_Top_expected.soar | 100 decisions, 1 rules |  |
| ChunkingTests_Rhs_Func_Literalization | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_Rhs_Func_Literalization.soar | 100 decisions, 0 rules | invalid chunk settings (lhs-repair, rhs-repair) stop loading in Soar 9.6.5; corrected as V2 |
| ChunkingTests_Rhs_Func_Literalization | V2 | — | 4 decisions, 10 rules | corrected V1: chunk lhs-repair / rhs-repair are not Soar 9.6.5 settings; Soar stops loading there (no rules load) |
| ChunkingTests_Rhs_Func_Literalization_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_Rhs_Func_Literalization_expected.soar | 100 decisions, 1 rules |  |
| ChunkingTests_RHS_Math | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_RHS_Math.soar | 3 decisions, 5 rules |  |
| ChunkingTests_RHS_Math_Abs | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_RHS_Math_Abs.soar | 2 decisions, 7 rules |  |
| ChunkingTests_RHS_Math_Abs_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_RHS_Math_Abs_expected.soar | 100 decisions, 2 rules |  |
| ChunkingTests_RHS_Math_Children_Force_Learn | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_RHS_Math_Children_Force_Learn.soar | 3 decisions, 8 rules |  |
| ChunkingTests_RHS_Math_Children_Force_Learn_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_RHS_Math_Children_Force_Learn_expected.soar | 100 decisions, 1 rules |  |
| ChunkingTests_RHS_Math_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_RHS_Math_expected.soar | 100 decisions, 1 rules |  |
| ChunkingTests_RHS_Math_Mixed | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_RHS_Math_Mixed.soar | 2 decisions, 8 rules |  |
| ChunkingTests_RHS_Math_Mixed_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_RHS_Math_Mixed_expected.soar | 100 decisions, 4 rules |  |
| ChunkingTests_RHS_Referent_Function | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_RHS_Referent_Function.soar | 102 decisions, 3 rules |  |
| ChunkingTests_RHS_Referent_Function_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_RHS_Referent_Function_expected.soar | 100 decisions, 1 rules |  |
| ChunkingTests_RHS_Unbound_Multivalue | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_RHS_Unbound_Multivalue.soar | 3 decisions, 7 rules |  |
| ChunkingTests_RHS_Unbound_Multivalue_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_RHS_Unbound_Multivalue_expected.soar | 100 decisions, 1 rules |  |
| ChunkingTests_RL_Variablization | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_RL_Variablization.soar | 2 decisions, 7 rules |  |
| ChunkingTests_RL_Variablization_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_RL_Variablization_expected.soar | 100 decisions, 5 rules |  |
| ChunkingTests_Singleton_Element_Types | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_Singleton_Element_Types.soar | 101 decisions, 5 rules |  |
| ChunkingTests_Singleton_Element_Types_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_Singleton_Element_Types_expected.soar | 100 decisions, 8 rules |  |
| ChunkingTests_Singletons | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_Singletons.soar | 2 decisions, 8 rules |  |
| ChunkingTests_Singletons_Architectural | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_Singletons_Architectural.soar | 2 decisions, 1 rules |  |
| ChunkingTests_Singletons_Architectural_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_Singletons_Architectural_expected.soar | 100 decisions, 1 rules |  |
| ChunkingTests_Singletons_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_Singletons_expected.soar | 100 decisions, 2 rules |  |
| ChunkingTests_SMem_Chunk_Direct | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_SMem_Chunk_Direct.soar | 5 decisions, 9 rules |  |
| ChunkingTests_SMem_Chunk_Direct_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_SMem_Chunk_Direct_expected.soar | 100 decisions, 1 rules |  |
| ChunkingTests_SMem_Chunked_Query | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_SMem_Chunked_Query.soar | 5 decisions, 12 rules |  |
| ChunkingTests_SMem_Chunked_Query2 | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_SMem_Chunked_Query2.soar | 3 decisions, 6 rules |  |
| ChunkingTests_SMem_Chunked_Query2_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_SMem_Chunked_Query2_expected.soar | 100 decisions, 2 rules |  |
| ChunkingTests_SMem_Chunked_Query_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_SMem_Chunked_Query_expected.soar | 100 decisions, 1 rules |  |
| ChunkingTests_STI_Variablization | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_STI_Variablization.soar | 3 decisions, 7 rules |  |
| ChunkingTests_STI_Variablization_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_STI_Variablization_expected.soar | 100 decisions, 1 rules |  |
| ChunkingTests_STI_Variablization_Same_Type | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_STI_Variablization_Same_Type.soar | 3 decisions, 8 rules |  |
| ChunkingTests_STI_Variablization_Same_Type_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_STI_Variablization_Same_Type_expected.soar | 100 decisions, 1 rules |  |
| ChunkingTests_STI_with_referents | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_STI_with_referents.soar | 1 decisions, 6 rules |  |
| ChunkingTests_STI_with_referents_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_STI_with_referents_expected.soar | 100 decisions, 1 rules |  |
| ChunkingTests_Superstate_Identity_Opaque | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_Superstate_Identity_Opaque.soar | 2 decisions, 9 rules |  |
| ChunkingTests_Superstate_Identity_Opaque_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_Superstate_Identity_Opaque_expected.soar | 100 decisions, 1 rules |  |
| ChunkingTests_Ungrounded_in_BT_Constraint | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_Ungrounded_in_BT_Constraint.soar | 3 decisions, 9 rules |  |
| ChunkingTests_Ungrounded_in_BT_Constraint_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_Ungrounded_in_BT_Constraint_expected.soar | 100 decisions, 2 rules |  |
| ChunkingTests_Ungrounded_Mixed | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_Ungrounded_Mixed.soar | 3 decisions, 8 rules |  |
| ChunkingTests_Ungrounded_Mixed_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_Ungrounded_Mixed_expected.soar | 100 decisions, 1 rules |  |
| ChunkingTests_Ungrounded_Relational_Constraint | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_Ungrounded_Relational_Constraint.soar | 3 decisions, 8 rules |  |
| ChunkingTests_Ungrounded_Relational_Constraint_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_Ungrounded_Relational_Constraint_expected.soar | 100 decisions, 1 rules |  |
| ChunkingTests_Ungrounded_STI_Promotion | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_Ungrounded_STI_Promotion.soar | 3 decisions, 8 rules |  |
| ChunkingTests_Ungrounded_STI_Promotion_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_Ungrounded_STI_Promotion_expected.soar | 100 decisions, 1 rules |  |
| ChunkingTests_Ungrounded_STIs | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_Ungrounded_STIs.soar | 101 decisions, 5 rules |  |
| ChunkingTests_Ungrounded_STIs_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_Ungrounded_STIs_expected.soar | 100 decisions, 1 rules |  |
| ChunkingTests_Unify_Ambiguous_Output | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_Unify_Ambiguous_Output.soar | 101 decisions, 4 rules |  |
| ChunkingTests_Unify_Ambiguous_Output_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_Unify_Ambiguous_Output_expected.soar | 100 decisions, 1 rules |  |
| ChunkingTests_Unify_Children_Results | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_Unify_Children_Results.soar | 6 decisions, 10 rules |  |
| ChunkingTests_Unify_Children_Results_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_Unify_Children_Results_expected.soar | 100 decisions, 1 rules |  |
| ChunkingTests_Unify_through_Two_Traces_Four_Deep | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/ChunkingTests_Unify_through_Two_Traces_Four_Deep.soar | 5 decisions, 10 rules |  |
| ChunkingTests_Unify_through_Two_Traces_Four_Deep_expected | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/expected/ChunkingTests_Unify_through_Two_Traces_Four_Deep_expected.soar | 100 decisions, 3 rules |  |
| chunks-no-paths-not-blocked | V1 | epmem-tutorial.zip: all-test/UCBot/chunks-no-paths-not-blocked.soar | 100 decisions, 7 rules |  |
| clean-house | V1 | epmem-tutorial.zip: Book-robot/OLD2/clean-house.soar | 100 decisions, 103 rules | missing: selection.soar, selection-astar.soar; defaults filled: selection-astar.soar, selection.soar |
| clean-house-8-3-09 | V1 | epmem-tutorial.zip: Book-robot/OLD/clean-house-8-3-09.soar | 300+ decisions, 160 rules | missing: selection.soar, selection-astar.soar; defaults filled: selection-astar.soar, selection.soar |
| clean-house-9-4-09 | V1 | epmem-tutorial.zip: Book-robot/OLD/clean-house-9-4-09.soar | 300+ decisions, 315 rules | missing: selection.soar, selection-astar.soar; defaults filled: selection-astar.soar, selection.soar |
| clean-house-new | V1 | knights-tour.zip: Instruction/old/clean-house/clean-house-new.soar | 100 decisions, 99 rules |  |
| clean-house-new | V2 | knights-tour.zip: Instruction/old/robot3/clean-house-new.soar | 100 decisions, 99 rules |  |
| clean-house-new | V3 | knights-tour.zip: Instruction/old/saw/clean/clean-house/clean-house-new.soar | 100 decisions, 99 rules |  |
| clean-house-new | V4 | knights-tour.zip: Instruction/robot3/clean-house-new.soar | 100 decisions, 0 rules; load error: Failed to open file for reading: clean-house-new_source.soar | missing: clean-house-new_source.soar |
| clean-house-new | V5 | epmem-tutorial.zip: Book-robot/clean-house-new.soar | 300+ decisions, 330 rules |  |
| clean-house-new | V6 | epmem-tutorial.zip: all-test/clean-house-new.soar | 100 decisions, 0 rules |  |
| clean-house-old | V1 | epmem-tutorial.zip: Book-robot/OLD/clean-house-old.soar | 100 decisions, 74 rules; load error: Error changing to Book-robot/clean-house | missing: selection.soar; defaults filled: selection.soar |
| clean-house2 | V1 | epmem-tutorial.zip: Book-robot/OLD2/clean-house2.soar | 100 decisions, 103 rules | missing: selection.soar, selection-astar.soar; defaults filled: selection-astar.soar, selection.soar |
| cleanup-command-links | V1 | arithmetic-smem.zip: john-nlp/cleanup-command-links.soar | 100 decisions, 5 rules |  |
| collect-cubes | V1 | epmem-tutorial.zip: CozmoSoarDemo/collect-cubes.soar | 300+ decisions, 107 rules |  |
| Copy of clean-house2 | V1 | epmem-tutorial.zip: Book-robot/OLD2/Copy of clean-house2.soar | 100 decisions, 0 rules | missing: selection.soar, selection-astar.soar; defaults filled: selection-astar.soar, selection.soar |
| count | V1 | epmem-tutorial.zip: count-task/count.soar | 107 decisions, 24 rules |  |
| count-and-die | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/count-and-die.soar | 300+ decisions, 14 rules |  |
| count-blocks | V1 | epmem-tutorial.zip: Book-robot/OLD/count-blocks.soar<br>epmem-tutorial.zip: all-test/Book-robot/count-blocks.soar | 300+ decisions, 25 rules |  |
| count-epmem | V1 | arithmetic-smem.zip: count-epmem/count-epmem.soar | 300+ decisions, 49 rules | interrupts by design after storing 100 episodes; continue the run for the query phase |
| count-test | V1 | epmem-tutorial.zip: count-test-files/count-test.soar | 164 decisions, 42 rules |  |
| count-test | V2 | 2026-agents-verified.zip: 2026-agents-verified/count-test-files/count-test.soar<br>Water-jugs.zip: count-test-files/count-test.soar | 300+ decisions, 48 rules |  |
| count-test | V3 | RL-unit-test.zip: count-test-files/count-test.soar | 300+ decisions, 42 rules |  |
| counter | V1 | epmem-tutorial.zip: eaters 8.5.2/counter example/counter.soar | 102 decisions, 5 rules |  |
| cozmo | V1 | epmem-tutorial.zip: CozmoSoarDemo/cozmo.soar | 300+ decisions, 93 rules |  |
| cozmo-5save | V1 | epmem-tutorial.zip: CozmoSoarDemo/cozmo-saves/cozmo-5save.soar | 300+ decisions, 8 rules | missing: ../default/simple.soar; defaults filled: simple.soar |
| cozmo-save | V1 | epmem-tutorial.zip: CozmoSoarDemo/cozmo-saves/cozmo-save.soar | 14 decisions, 35 rules |  |
| cozmo-save2 | V1 | epmem-tutorial.zip: CozmoSoarDemo/cozmo-saves/cozmo-save2.soar | 300+ decisions, 53 rules | missing: ../default/simple.soar; defaults filled: simple.soar |
| cozmo-save3 | V1 | epmem-tutorial.zip: CozmoSoarDemo/cozmo-saves/cozmo-save3.soar | 300+ decisions, 48 rules; load error: Production addition failed. | missing: ../default/simple.soar; defaults filled: simple.soar |
| cozmo-save4 | V1 | epmem-tutorial.zip: CozmoSoarDemo/cozmo-saves/cozmo-save4.soar | 300+ decisions, 8 rules | missing: ../default/simple.soar; defaults filled: simple.soar |
| cozmo-save5 | V1 | epmem-tutorial.zip: CozmoSoarDemo/cozmo-saves/cozmo-save5.soar | 100 decisions, 0 rules; load error: Error changing to cozmo | missing: cozmo_source.soar |
| cozmo-save6 | V1 | epmem-tutorial.zip: CozmoSoarDemo/cozmo-saves/cozmo-save6.soar | 300+ decisions, 8 rules | missing: ../default/simple.soar; defaults filled: simple.soar |
| cozmohack | V1 | epmem-tutorial.zip: CozmoSoarDemo/cozmo-saves/cozmohack.soar | 14 decisions, 37 rules; load error: Production addition failed. | missing: ../default/simple.soar; defaults filled: simple.soar |
| cube-stack | V1 | epmem-tutorial.zip: CozmoSoarDemo/productions/cube-stack.soar | 300+ decisions, 31 rules |  |
| debug_proc_learn | V1 | arithmetic-smem.zip: john-nlp/manage-world-state/internal-worlds/debug_proc_learn.soar | 100 decisions, 1 rules |  |
| default | V1 | knights-tour.zip: taxi/taxi/inheritance/taxi/default/default.soar | default library |  |
| dev | V1 | arithmetic-smem.zip: john-nlp/manage-world-state/internal-worlds/dev.soar | 100 decisions, 1 rules |  |
| dev | V2 | arithmetic-smem.zip: john-nlp/manage-world-state/waypoint-maps/dev.soar | 100 decisions, 1 rules |  |
| dice-easy | V1 | epmem-tutorial.zip: Dice Game/IPHONE/Soar Agent/Soar Agent/dice-easy.soar | 101 decisions, 343 rules |  |
| dice-game-bot | V1 | epmem-tutorial.zip: Dice Game/dice-game-bot.soar | 100 decisions, 0 rules; load error: Error changing to dice-game-bot | missing: dice-game-bot_source.soar |
| dice-hard | V1 | epmem-tutorial.zip: Dice Game/IPHONE/Soar Agent/Soar Agent/dice-hard.soar | 101 decisions, 343 rules |  |
| dice-harder | V1 | epmem-tutorial.zip: Dice Game/IPHONE/Soar Agent/Soar Agent/dice-harder.soar | 101 decisions, 343 rules |  |
| dice-hardest | V1 | epmem-tutorial.zip: Dice Game/IPHONE/Soar Agent/Soar Agent/dice-hardest.soar | 101 decisions, 343 rules |  |
| dice-medium | V1 | epmem-tutorial.zip: Dice Game/IPHONE/Soar Agent/Soar Agent/dice-medium.soar | 101 decisions, 343 rules |  |
| dice-model-bot-new | V1 | epmem-tutorial.zip: all-test/dice-model-bot-new.soar | 300+ decisions, 353 rules | missing: selection-epmem.soar; defaults filled: selection-epmem.soar |
| dice-probabilities-true | V1 | epmem-tutorial.zip: Dice Game/dice-probabilities-true.soar | 300+ decisions, 349 rules |  |
| discrete-agent | V1 | epmem-tutorial.zip: all-test/Room-discrete/discrete-agent.soar | 300+ decisions, 35 rules |  |
| eater-bs | V1 | epmem-tutorial.zip: Eater Bootstrap/eater-bs.soar | 100 decisions, 0 rules |  |
| eater-default | V1 | epmem-tutorial.zip: eaters 8.5.2/eater-default.soar | 100 decisions, 4 rules |  |
| eight-puzzle | V1 | knights-tour.zip: RL/eight-puzzle/eight-puzzle.soar | 108 decisions, 83 rules |  |
| eight-puzzle | V2 | epmem-tutorial.zip: EIGHT-PUZZLES/Eight-Puzzle/eight-puzzle.soar | 300+ decisions, 88 rules | missing: selection.soar; defaults filled: selection.soar |
| eight-puzzle | V3 | epmem-tutorial.zip: EIGHT-PUZZLES/eight-puzzle2/eight-puzzle.soar | 29 decisions, 87 rules | missing: selection.soar; defaults filled: selection.soar |
| eight-puzzle | V4 | 2026-agents-verified.zip: 2026-agents-verified/Eight-puzzle/eight-puzzle-orginal/eight-puzzle.soar<br>Water-jugs.zip: Eight-puzzle/eight-puzzle-orginal/eight-puzzle.soar | 29 decisions, 87 rules |  |
| eight-puzzle | V5 | arithmetic.zip: verified/eight-puzzle-xx/eight-puzzle.soar | 29 decisions, 87 rules | missing: selection.soar; defaults filled: selection.soar |
| eight-puzzle-desired-binding | V1 | 2026-agents-verified.zip: 2026-agents-verified/Eight-puzzle/eight-puzzle-desired-binding/eight-puzzle-desired-binding.soar<br>Water-jugs.zip: Eight-puzzle/eight-puzzle-desired-binding/eight-puzzle-desired-binding.soar | 24 decisions, 88 rules |  |
| epmem-tutorial | V1 | epmem-tutorial.zip: epmem-tutorial/epmem-tutorial.soar | 3 decisions, 8 rules |  |
| epmem_unit_common | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/epmem/epmem_unit_common.soar | 211 decisions, 18 rules |  |
| EpMemFunctionalTests_epmem_unit_test_1 | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/epmem/EpMemFunctionalTests_epmem_unit_test_1.soar | 113 decisions, 19 rules |  |
| EpMemFunctionalTests_epmem_unit_test_10 | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/epmem/EpMemFunctionalTests_epmem_unit_test_10.soar | 113 decisions, 19 rules |  |
| EpMemFunctionalTests_epmem_unit_test_11 | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/epmem/EpMemFunctionalTests_epmem_unit_test_11.soar | 113 decisions, 19 rules |  |
| EpMemFunctionalTests_epmem_unit_test_12 | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/epmem/EpMemFunctionalTests_epmem_unit_test_12.soar | 113 decisions, 19 rules |  |
| EpMemFunctionalTests_epmem_unit_test_13 | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/epmem/EpMemFunctionalTests_epmem_unit_test_13.soar | 113 decisions, 19 rules |  |
| EpMemFunctionalTests_epmem_unit_test_14 | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/epmem/EpMemFunctionalTests_epmem_unit_test_14.soar | 113 decisions, 19 rules |  |
| EpMemFunctionalTests_epmem_unit_test_2 | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/epmem/EpMemFunctionalTests_epmem_unit_test_2.soar | 113 decisions, 19 rules |  |
| EpMemFunctionalTests_epmem_unit_test_3 | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/epmem/EpMemFunctionalTests_epmem_unit_test_3.soar | 113 decisions, 19 rules |  |
| EpMemFunctionalTests_epmem_unit_test_4 | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/epmem/EpMemFunctionalTests_epmem_unit_test_4.soar | 113 decisions, 19 rules |  |
| EpMemFunctionalTests_epmem_unit_test_5 | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/epmem/EpMemFunctionalTests_epmem_unit_test_5.soar | 113 decisions, 19 rules |  |
| EpMemFunctionalTests_epmem_unit_test_6 | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/epmem/EpMemFunctionalTests_epmem_unit_test_6.soar | 113 decisions, 19 rules |  |
| EpMemFunctionalTests_epmem_unit_test_7 | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/epmem/EpMemFunctionalTests_epmem_unit_test_7.soar | 113 decisions, 19 rules |  |
| EpMemFunctionalTests_epmem_unit_test_8 | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/epmem/EpMemFunctionalTests_epmem_unit_test_8.soar | 113 decisions, 19 rules |  |
| EpMemFunctionalTests_epmem_unit_test_9 | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/epmem/EpMemFunctionalTests_epmem_unit_test_9.soar | 113 decisions, 19 rules |  |
| EpMemFunctionalTests_hamiltonian | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/epmem/EpMemFunctionalTests_hamiltonian.soar | 2 decisions, 6 rules |  |
| EpMemFunctionalTests_svs | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/epmem/EpMemFunctionalTests_svs.soar | 2 decisions, 6 rules |  |
| EpMemFunctionalTests_svs_hard | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/epmem/EpMemFunctionalTests_svs_hard.soar | 2 decisions, 6 rules |  |
| EpMemFunctionalTests_testAfterEpMem | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/epmem/EpMemFunctionalTests_testAfterEpMem.soar | 12 decisions, 15 rules; load error: *WARNING: Replacing function named failed with halt since this is a unit test but running in a non-unit testing environment. |  |
| EpMemFunctionalTests_testAllNegQueriesEpMem | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/epmem/EpMemFunctionalTests_testAllNegQueriesEpMem.soar | 12 decisions, 14 rules; load error: *WARNING: Replacing function named failed with halt since this is a unit test but running in a non-unit testing environment. |  |
| EpMemFunctionalTests_testBeforeAfterProhibitEpMem | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/epmem/EpMemFunctionalTests_testBeforeAfterProhibitEpMem.soar | 12 decisions, 15 rules; load error: *WARNING: Replacing function named failed with halt since this is a unit test but running in a non-unit testing environment. |  |
| EpMemFunctionalTests_testBeforeEpMem | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/epmem/EpMemFunctionalTests_testBeforeEpMem.soar | 12 decisions, 15 rules; load error: *WARNING: Replacing function named failed with halt since this is a unit test but running in a non-unit testing environment. |  |
| EpMemFunctionalTests_testCountEpMem | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/epmem/EpMemFunctionalTests_testCountEpMem.soar | 300+ decisions, 48 rules |  |
| EpMemFunctionalTests_testCyclicQuery | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/epmem/EpMemFunctionalTests_testCyclicQuery.soar | 4 decisions, 10 rules; load error: *WARNING: Replacing function named failed with halt since this is a unit test but running in a non-unit testing environment. |  |
| EpMemFunctionalTests_testEpMemEncodeOutput_NoWMA | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/epmem/EpMemFunctionalTests_testEpMemEncodeOutput_NoWMA.soar | 4 decisions, 11 rules; load error: *WARNING: Replacing function named failed with halt since this is a unit test but running in a non-unit testing environment. |  |
| EpMemFunctionalTests_testEpMemEncodeOutput_WMA | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/epmem/EpMemFunctionalTests_testEpMemEncodeOutput_WMA.soar | 4 decisions, 11 rules; load error: *WARNING: Replacing function named failed with halt since this is a unit test but running in a non-unit testing environment. |  |
| EpMemFunctionalTests_testEpMemEncodeSelection_NoWMA | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/epmem/EpMemFunctionalTests_testEpMemEncodeSelection_NoWMA.soar | 5 decisions, 11 rules; load error: *WARNING: Replacing function named failed with halt since this is a unit test but running in a non-unit testing environment. |  |
| EpMemFunctionalTests_testEpMemEncodeSelection_WMA | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/epmem/EpMemFunctionalTests_testEpMemEncodeSelection_WMA.soar | 5 decisions, 11 rules; load error: *WARNING: Replacing function named failed with halt since this is a unit test but running in a non-unit testing environment. |  |
| EpMemFunctionalTests_testHamilton | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/epmem/EpMemFunctionalTests_testHamilton.soar | 2 decisions, 6 rules; load error: *WARNING: Replacing function named failed with halt since this is a unit test but running in a non-unit testing environment. |  |
| EpMemFunctionalTests_testKB | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/epmem/EpMemFunctionalTests_testKB.soar | 246 decisions, 46 rules |  |
| EpMemFunctionalTests_testMaxDoublePrecision-Irrational | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/epmem/EpMemFunctionalTests_testMaxDoublePrecision-Irrational.soar | 4 decisions, 12 rules; load error: *WARNING: Replacing function named failed with halt since this is a unit test but running in a non-unit testing environment. |  |
| EpMemFunctionalTests_testMaxDoublePrecisionEpMem | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/epmem/EpMemFunctionalTests_testMaxDoublePrecisionEpMem.soar | 4 decisions, 11 rules; load error: *WARNING: Replacing function named failed with halt since this is a unit test but running in a non-unit testing environment. |  |
| EpMemFunctionalTests_testMultiAgent | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/epmem/EpMemFunctionalTests_testMultiAgent.soar | 3 decisions, 7 rules |  |
| EpMemFunctionalTests_testNegativeEpisode | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/epmem/EpMemFunctionalTests_testNegativeEpisode.soar | 12 decisions, 14 rules; load error: *WARNING: Replacing function named failed with halt since this is a unit test but running in a non-unit testing environment. |  |
| EpMemFunctionalTests_testNonExistingEpisode | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/epmem/EpMemFunctionalTests_testNonExistingEpisode.soar | 12 decisions, 14 rules; load error: *WARNING: Replacing function named failed with halt since this is a unit test but running in a non-unit testing environment. |  |
| EpMemFunctionalTests_testOddEven | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/epmem/EpMemFunctionalTests_testOddEven.soar | 12 decisions, 14 rules; load error: *WARNING: Replacing function named failed with halt since this is a unit test but running in a non-unit testing environment. |  |
| EpMemFunctionalTests_testSimpleFloatEpMem | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/epmem/EpMemFunctionalTests_testSimpleFloatEpMem.soar | 4 decisions, 11 rules; load error: *WARNING: Replacing function named failed with halt since this is a unit test but running in a non-unit testing environment. |  |
| EpMemFunctionalTests_testSingleStoreRetrieve | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/epmem/EpMemFunctionalTests_testSingleStoreRetrieve.soar | 2 decisions, 6 rules |  |
| EpMemFunctionalTests_testSMemEpMemFactorization | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/epmem/EpMemFunctionalTests_testSMemEpMemFactorization.soar | 300+ decisions, 106 rules |  |
| EpMemFunctionalTests_testWMActivation_Balance0 | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/epmem/EpMemFunctionalTests_testWMActivation_Balance0.soar | 5 decisions, 12 rules |  |
| EpMemFunctionalTests_testWMELength_FiveCycle | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/epmem/EpMemFunctionalTests_testWMELength_FiveCycle.soar | 7 decisions, 13 rules; load error: *WARNING: Replacing function named failed with halt since this is a unit test but running in a non-unit testing environment. |  |
| EpMemFunctionalTests_testWMELength_InfiniteCycle | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/epmem/EpMemFunctionalTests_testWMELength_InfiniteCycle.soar | 12 decisions, 12 rules; load error: *WARNING: Replacing function named failed with halt since this is a unit test but running in a non-unit testing environment. |  |
| EpMemFunctionalTests_testWMELength_MultiCycle | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/epmem/EpMemFunctionalTests_testWMELength_MultiCycle.soar | 12 decisions, 14 rules; load error: *WARNING: Replacing function named failed with halt since this is a unit test but running in a non-unit testing environment. |  |
| EpMemFunctionalTests_testWMELength_OneCycle | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/epmem/EpMemFunctionalTests_testWMELength_OneCycle.soar | 4 decisions, 13 rules; load error: *WARNING: Replacing function named failed with halt since this is a unit test but running in a non-unit testing environment. |  |
| EpMemFunctionalTests_testYRemoval | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/epmem/EpMemFunctionalTests_testYRemoval.soar | 9 decisions, 15 rules |  |
| EpMemHamiltonRetrieveTest_testHamilton_retrieve | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/epmem/EpMemHamiltonRetrieveTest_testHamilton_retrieve.soar | 2 decisions, 6 rules |  |
| EpMemHamiltonStoreTests_testHamilton_store | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/epmem/EpMemHamiltonStoreTests_testHamilton_store.soar | 2 decisions, 4 rules |  |
| EpMemSaveToDbTests_store | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/epmem/EpMemSaveToDbTests_store.soar | 2 decisions, 4 rules |  |
| eval_interior-guard | V1 | arithmetic-smem.zip: john-nlp/manage-world-state/internal-worlds/eval_interior-guard.soar | 100 decisions, 1 rules |  |
| eval_interior-guard | V2 | arithmetic-smem.zip: john-nlp/manage-world-state/waypoint-maps/eval_interior-guard.soar | 100 decisions, 1 rules |  |
| eval_rand_move | V1 | arithmetic-smem.zip: john-nlp/manage-world-state/internal-worlds/eval_rand_move.soar | 100 decisions, 1 rules |  |
| eval_rand_move | V2 | arithmetic-smem.zip: john-nlp/manage-world-state/waypoint-maps/eval_rand_move.soar | 100 decisions, 1 rules |  |
| event-comprehension | V1 | epmem-tutorial.zip: event-comprehension-files/event-comprehension.soar | 202 decisions, 24 rules |  |
| f2 | V1 | arithmetic-smem.zip: john-nlp/testing/test-tcl/f2.soar | 100 decisions, 1 rules |  |
| f3 | V1 | arithmetic-smem.zip: john-nlp/testing/test-tcl/f3.soar | 100 decisions, 1 rules |  |
| fifteen-puzzle | V1 | knights-tour.zip: RL/eight-puzzle/fifteen-puzzle.soar | 108 decisions, 83 rules |  |
| fifteen-puzzle | V2 | 2026-agents-verified.zip: 2026-agents-verified/Fifteen-puzzle/fifteen-puzzle.soar<br>Water-jugs.zip: Fifteen-puzzle/fifteen-puzzle.soar | 300+ decisions, 87 rules |  |
| fifteen-puzzle | V3 | RL-unit-test.zip: Fifteen-Puzzle/fifteen-puzzle.soar | 300+ decisions, 87 rules | Differed in learned rules until November 3: soar-lean ignored 'chunk add-osk off  # comment'; matches since. |
| fifteen-puzzle | V4 | arithmetic.zip: verified/fifteen-puzzle/fifteen-puzzle.soar | 300+ decisions, 87 rules | missing: selection.soar; defaults filled: selection.soar |
| flat-all | V1 | knights-tour.zip: taxi/taxi/inheritance/taxi/flat-all/flat-all.soar | 101 decisions, 42 rules |  |
| flat-phase | V1 | knights-tour.zip: taxi/taxi/inheritance/taxi/flat-phase/flat-phase.soar | 101 decisions, 42 rules |  |
| flat-phase-regions | V1 | knights-tour.zip: taxi/taxi/inheritance/taxi/flat-phase-regions/flat-phase-regions.soar | 101 decisions, 45 rules |  |
| flat-smart | V1 | knights-tour.zip: taxi/taxi/inheritance/taxi/flat-smart/flat-smart.soar | 101 decisions, 42 rules |  |
| formulations | V1 | arithmetic-smem.zip: john-nlp/manage-world-state/internal-worlds/formulations.soar | 100 decisions, 1 rules |  |
| formulations | V2 | arithmetic-smem.zip: john-nlp/manage-world-state/waypoint-maps/formulations.soar | 100 decisions, 1 rules |  |
| full_office | V1 | arithmetic-smem.zip: john-nlp/manage-world-state/internal-worlds/full_office.soar | 100 decisions, 1 rules |  |
| full_office | V2 | arithmetic-smem.zip: john-nlp/manage-world-state/waypoint-maps/full_office.soar | 100 decisions, 1 rules |  |
| FunctionalTests_testArithmetic | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/FunctionalTests_testArithmetic.soar | 300+ decisions, 82 rules; load error: ********************WARNING: Replacing function named failed with halt since this is a unit test but running in a non-unit testing environment. |  |
| FunctionalTests_testBlocksWorld | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/FunctionalTests_testBlocksWorld.soar | 300+ decisions, 12 rules |  |
| FunctionalTests_testBlocksWorldLookAhead | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/FunctionalTests_testBlocksWorldLookAhead.soar | 25 decisions, 99 rules |  |
| FunctionalTests_testBlocksWorldOperatorSubgoaling | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/FunctionalTests_testBlocksWorldOperatorSubgoaling.soar | 5 decisions, 16 rules |  |
| FunctionalTests_testCountTest | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/FunctionalTests_testCountTest.soar | 300+ decisions, 42 rules |  |
| FunctionalTests_testEightPuzzle | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/FunctionalTests_testEightPuzzle.soar | 65 decisions, 85 rules |  |
| FunctionalTests_testTowersOfHanoi | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/FunctionalTests_testTowersOfHanoi.soar | 300+ decisions, 18 rules |  |
| FunctionalTests_testTowersOfHanoiFast | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/FunctionalTests_testTowersOfHanoiFast.soar | 300+ decisions, 17 rules |  |
| FunctionalTests_testWaterJug | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/FunctionalTests_testWaterJug.soar | 300+ decisions, 13 rules |  |
| FunctionalTests_testWaterJugHierarchy | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/FunctionalTests_testWaterJugHierarchy.soar | 300+ decisions, 22 rules |  |
| game-agent | V1 | arithmetic-smem.zip: john-nlp/game-scripts/game-agent.soar | 100 decisions, 0 rules; load error: Error changing to /home/jrkirk/rosie2/rosie-project/rosie/test-agents/game/agent/ | missing: /home/jrkirk/rosie2/rosie-project/rosie/test-agents/game/agent/smem_source_game.soar, /home/jrkirk/rosie2/rosie-project/rosie/test-agents/game/agent/source_game.soar |
| game-data-agent | V1 | arithmetic-smem.zip: john-nlp/game-data-agent.soar | 100 decisions, 0 rules; load error: Error changing to /home/jrkirk/rosie2/rosie-project/rosie/agent/init-smem/ | missing: /home/jrkirk/rosie2/rosie-project/rosie/agent/init-smem/init-smem_source.soar, /home/jrkirk/rosie2/rosie-project/rosie/agent/source-tabletop-agent.soar |
| game-data-agent | V2 | arithmetic-smem.zip: john-nlp/game-scripts/game-data-agent.soar | 100 decisions, 1 rules; load error: Error changing to ../init-smem/ | missing: ../init-smem/init-smem_source.soar, ../tabletop_source.soar |
| generalize-task-operator | V1 | arithmetic-smem.zip: john-nlp/generalize-task-operator.soar | 100 decisions, 2 rules |  |
| generated | V1 | epmem-tutorial.zip: all-test/Mummy/old/generated.soar | 300+ decisions, 157 rules | missing: selection.soar; defaults filled: selection.soar |
| graph-search | V1 | knights-tour.zip: Graph Search/graph-search.soar | 100 decisions, 110 rules | missing: selection.soar, selection-astar.soar; defaults filled: selection-astar.soar, selection.soar |
| graph-search | V2 | RL-unit-test.zip: Graph Search/graph-search.soar | 195 decisions, 123 rules |  |
| graph-search | V3 | arithmetic-smem.zip: Graph Search/graph-search.soar | 300+ decisions, 123 rules | missing: selection.soar, selection-astar.soar; defaults filled: selection-astar.soar, selection.soar |
| graph-search-iterative | V1 | knights-tour.zip: Graph Search/graph-search-iterative.soar | 100 decisions, 119 rules | missing: selection.soar, selection-iterative-deepening-general-chunks.soar; defaults filled: selection-iterative-deepening-general-chunks.soar, selection.soar |
| graph-search-iterative | V2 | RL-unit-test.zip: Graph Search/graph-search-iterative.soar | timeout |  |
| graph-search-iterative | V3 | arithmetic-smem.zip: Graph Search/graph-search-iterative.soar | timeout | missing: selection.soar, selection-iterative-deepening-general-chunks.soar; defaults filled: selection-iterative-deepening-general-chunks.soar, selection.soar |
| graph-search-smem | V1 | knights-tour.zip: Graph Search/graph-search-smem.soar<br>arithmetic-smem.zip: Graph Search/graph-search-smem.soar | 107 decisions, 133 rules | Differs from Soar 9.6.5 only in the numbers of semantic-memory objects: Soar numbers the objects of one smem --add clause in pointer order (std::set<ltm_object*>), which changes with the environment (the same files compare equal or not depending on the directory). NOT MODELED (doc/DIFFERENCES.md, Nov 3).; missing: selection.soar, selection-astar.soar; defaults filled: selection-astar.soar, selection.soar |
| graph-search-smem | V2 | RL-unit-test.zip: Graph Search/graph-search-smem.soar | 107 decisions, 133 rules | Differs from Soar 9.6.5 only in the numbers of semantic-memory objects: Soar numbers the objects of one smem --add clause in pointer order (std::set<ltm_object*>), which changes with the environment (the same files compare equal or not depending on the directory). NOT MODELED (doc/DIFFERENCES.md, Nov 3). |
| grasp-ied | V1 | knights-tour.zip: Instruction/robot3/clean-house-new/get-block/pickup-block/grasp-ied.soar | 100 decisions, 2 rules |  |
| hello-world-operator | V1 | epmem-tutorial.zip: eaters 8.5.2/tutorial/hello-world-operator.soar | 1 decisions, 2 rules |  |
| hello-world-operator | V2 | 2026-agents-verified.zip: 2026-agents-verified/hello-world-operator/hello-world-operator.soar<br>Water-jugs.zip: hello-world-operator/hello-world-operator.soar | 1 decisions, 2 rules |  |
| hello-world-rule | V1 | epmem-tutorial.zip: eaters 8.5.2/tutorial/hello-world-rule.soar | 0 decisions, 1 rules |  |
| hello-world-rule | V2 | 2026-agents-verified.zip: 2026-agents-verified/hello-world-rule/hello-world-rule.soar<br>Water-jugs.zip: hello-world-rule/hello-world-rule.soar | 0 decisions, 1 rules |  |
| hrl-full-max | V1 | knights-tour.zip: taxi/taxi/inheritance/taxi/hrl-full-max/hrl-full-max.soar | 101 decisions, 68 rules |  |
| hrl-nav | V1 | knights-tour.zip: taxi/taxi/inheritance/taxi/hrl-nav/hrl-nav.soar | 101 decisions, 50 rules |  |
| hrl-nav-general | V1 | knights-tour.zip: taxi/taxi/inheritance/taxi/hrl-nav-general/hrl-nav-general.soar | 101 decisions, 53 rules |  |
| hrl-nav-max | V1 | knights-tour.zip: taxi/taxi/inheritance/taxi/hrl-nav-max/hrl-nav-max.soar | 101 decisions, 69 rules |  |
| hrl-nav-max-general | V1 | knights-tour.zip: taxi/taxi/inheritance/taxi/hrl-nav-max-general/hrl-nav-max-general.soar | 101 decisions, 72 rules |  |
| init | V1 | arithmetic-smem.zip: john-nlp/testing/test-tcl/init.soar | 100 decisions, 0 rules |  |
| instruct | V1 | epmem-tutorial.zip: all-test/Pyramid/instruct.soar | 300+ decisions, 177 rules |  |
| instruct | V2 | RL-general-state.zip: Pyramid/OLD/Pyramid 5/instruct.soar | 300+ decisions, 113 rules |  |
| instruct | V3 | RL-general-state.zip: Pyramid/OLD/instruct.soar | 300+ decisions, 79 rules |  |
| instruct | V4 | RL-general-state.zip: Pyramid/OLD/pyramid 10/pyramid 10/instruct.soar | 100 decisions, 64 rules | missing closing brace in give-up-on-term1 stops loading; corrected as V10 |
| instruct | V5 | RL-general-state.zip: Pyramid/OLD/pyramid 6/pyramid 6/instruct.soar | 300+ decisions, 115 rules |  |
| instruct | V6 | RL-general-state.zip: Pyramid/OLD/pyramid 8/instruct.soar | 300+ decisions, 119 rules |  |
| instruct | V7 | RL-general-state.zip: Pyramid/OLD/pyramid 8/pyramid 6/instruct.soar | 300+ decisions, 115 rules |  |
| instruct | V8 | RL-general-state.zip: Pyramid/OLD/pyramid 9/pyramid 9/instruct.soar | 300+ decisions, 126 rules |  |
| instruct | V9 | RL-general-state.zip: Pyramid/Pyramid 11/instruct.soar | 300+ decisions, 177 rules |  |
| instruct | V10 | — | 300+ decisions, 128 rules | corrected V4: rule give-up-on-term1 lacks its closing brace; Soar stops loading there (64 rules loaded) |
| instruct-01-03-05 | V1 | RL-general-state.zip: Pyramid/OLD/instruct-01-03-05.soar | 300+ decisions, 66 rules |  |
| interpret-game-state-tower-change | V1 | arithmetic-smem.zip: john-nlp/game-scripts/world-generator/towerVAR/interpret-game-state-tower-change.soar | 100 decisions, 100 rules |  |
| john-nlp | V1 | arithmetic-smem.zip: john-nlp/john-nlp.soar | 101 decisions, 1260 rules; load error: ***************************************************Error: Expected attribute-value test after state/impasse test. Did you forget to add "^type state" or "^superstate nil"? |  |
| Johnbot | V1 | epmem-tutorial.zip: all-test/Johnbot/Johnbot.soar | 100 decisions, 832 rules |  |
| johns-eater | V1 | epmem-tutorial.zip: eaters 8.5.2/johns-eater.soar | 100 decisions, 9 rules |  |
| jump | V1 | epmem-tutorial.zip: eaters 8.5.2/tutorial/jump.soar | 100 decisions, 4 rules |  |
| jump-and-move | V1 | epmem-tutorial.zip: eaters 8.5.2/tutorial/jump-and-move.soar | 100 decisions, 8 rules |  |
| kenken | V1 | 2026-agents-verified.zip: 2026-agents-verified/Kenken/kenken.soar<br>Water-jugs.zip: Kenken/kenken.soar | 300+ decisions, 276 rules | First compared November 3; differed until model fixes of that day (doc/DIFFERENCES.md, November 3 afternoon); matches since. |
| kenken | V2 | RL-general-state.zip: kenken2/kenken.soar | 186 decisions, 86 rules | First compared November 3; differed until model fixes of that day (doc/DIFFERENCES.md, November 3 afternoon); matches since. |
| kitchen | V1 | arithmetic-smem.zip: john-nlp/manage-world-state/internal-worlds/kitchen.soar | 100 decisions, 1 rules |  |
| kitchen | V2 | arithmetic-smem.zip: john-nlp/manage-world-state/waypoint-maps/kitchen.soar | 100 decisions, 1 rules |  |
| kitchen_plus | V1 | arithmetic-smem.zip: john-nlp/manage-world-state/internal-worlds/kitchen_plus.soar | 100 decisions, 1 rules |  |
| kitchen_plus | V2 | arithmetic-smem.zip: john-nlp/manage-world-state/waypoint-maps/kitchen_plus.soar | 100 decisions, 1 rules |  |
| knights | V1 | knights-tour.zip: knights-tour/knights.soar | 300+ decisions, 49 rules |  |
| knights | V2 | RL-general-state.zip: Knights-tour/knights.soar | 300+ decisions, 49 rules |  |
| l1s1_go-to-flag_1 | V1 | epmem-tutorial.zip: all-test/UCBot/UCBot/maps/l1s1_go-to-flag_1.soar | 100 decisions, 1 rules |  |
| l2s1_source_full | V1 | epmem-tutorial.zip: all-test/UCBot/UCBot/maps/l2s1_source_full.soar | 100 decisions, 1 rules |  |
| laird-dudo | V1 | epmem-tutorial.zip: Dice Game/dicegame-0.1.1/agents/laird-dudo.soar | 101 decisions, 26 rules |  |
| left-right | V1 | 2026-agents-verified.zip: 2026-agents-verified/left-right/left-right.soar<br>Water-jugs.zip: left-right/left-right.soar | 2 decisions, 11 rules |  |
| load-8p | V1 | arithmetic-smem.zip: john-nlp/lucia/Grammar/Games/8puzzle/load-8p.soar | 100 decisions, 17 rules |  |
| load-B | V1 | arithmetic-smem.zip: john-nlp/lucia/comprehend/load-B.soar | 100 decisions, 262 rules |  |
| load-map.big | V1 | epmem-tutorial.zip: all-test/UCBot/UCBot/maps/load-map.big.soar | 100 decisions, 1 rules |  |
| load-map.l2s1.0.3.0 | V1 | epmem-tutorial.zip: all-test/UCBot/UCBot/maps/load-map.l2s1.0.3.0.soar | 100 decisions, 1 rules |  |
| load-map.l2t1.0.3.0 | V1 | epmem-tutorial.zip: all-test/UCBot/UCBot/maps/load-map.l2t1.0.3.0.soar | 100 decisions, 1 rules |  |
| load-map.small | V1 | epmem-tutorial.zip: all-test/UCBot/UCBot/maps/load-map.small.soar | 100 decisions, 1 rules |  |
| log | V1 | RL-unit-test.zip: RL-general-state/log.soar | 100 decisions, 42 rules |  |
| lucia_testing | V1 | arithmetic-smem.zip: john-nlp/manage-world-state/internal-worlds/lucia_testing.soar | 100 decisions, 1 rules |  |
| lucia_testing | V2 | arithmetic-smem.zip: john-nlp/manage-world-state/waypoint-maps/lucia_testing.soar | 100 decisions, 1 rules |  |
| mac | V1 | knights-tour.zip: MACS/mac/mac.soar | 300+ decisions, 18 rules |  |
| mac | V2 | knights-tour.zip: RL/mac/mac.soar<br>epmem-tutorial.zip: all-test/mac/mac.soar | 300+ decisions, 18 rules |  |
| mac | V3 | 2026-agents-verified.zip: 2026-agents-verified/MaC/MAC-simple/mac.soar<br>Water-jugs.zip: MaC/MAC-simple/mac.soar | 300+ decisions, 18 rules |  |
| mac | V4 | RL-unit-test.zip: RL-general-state/mac.soar | 100 decisions, 0 rules; load error: Failed to open file for reading: ../RL-general.soar | missing: selection.soar; defaults filled: selection.soar |
| mac | V5 | RL-general-state.zip: RL-general-state/mac.soar | 100 decisions, 0 rules; load error: Failed to open file for reading: ../RL-general.soar | ../RL-general.soar not found (file is RL-General.soar); corrected as V6, which then reaches unfinished code (init-sub-attribute-list) |
| mac | V6 | — | 131 decisions, 136 rules | corrected V5: sources ../RL-general.soar; the file is RL-General.soar (fails on a case-sensitive file system) |
| mac-look-ahead | V1 | 2026-agents-verified.zip: 2026-agents-verified/MaC/MAC-LA/mac-look-ahead.soar<br>Water-jugs.zip: MaC/MAC-LA/mac-look-ahead.soar | 300+ decisions, 100 rules |  |
| mac-lookahead-RL | V1 | knights-tour.zip: RL/mac/mac-lookahead-RL.soar | 300+ decisions, 86 rules |  |
| mac-planning | V1 | knights-tour.zip: MACS/mac-planning/mac-planning.soar | 77 decisions, 92 rules | missing: selection.soar; defaults filled: selection.soar |
| mac-planning | V2 | knights-tour.zip: RL/mac/mac-planning.soar | 108 decisions, 85 rules |  |
| mac-planning | V3 | epmem-tutorial.zip: all-test/mac/mac-planning.soar | 300+ decisions, 83 rules | Learned rules differed until November 3 (rules learned mid-pass fire in the same pass; state tests on root variables); matches since. |
| mac-planning | V4 | arithmetic.zip: verified/mac-planning/mac-planning.soar | crash | crashes Soar 9.6.5 (segmentation fault) at decision 10 of its look-ahead; cause not found (does not crash in a debug build); missing: selection.soar; defaults filled: selection.soar |
| mac-RL | V1 | 2026-agents-verified.zip: 2026-agents-verified/MaC/MAC-RL/mac-RL.soar<br>Water-jugs.zip: MaC/MAC-RL/mac-RL.soar | 100 decisions, 0 rules; load error: Error changing to mac-RL | missing: mac-RL_source.soar |
| mac-substate-RL | V1 | 2026-agents-verified.zip: 2026-agents-verified/MaC/MAC-substate-eval/mac-substate-RL.soar<br>Water-jugs.zip: MaC/MAC-substate-eval/mac-substate-RL.soar | 300+ decisions, 103 rules |  |
| mac1 | V1 | epmem-tutorial.zip: all-test/mac/mac1.soar | 300+ decisions, 17 rules |  |
| mac1-planning | V1 | epmem-tutorial.zip: all-test/mac/mac1-planning.soar | 300+ decisions, 90 rules |  |
| mac1-planning-numeric | V1 | epmem-tutorial.zip: all-test/mac/mac1-planning-numeric.soar | 300+ decisions, 90 rules |  |
| mac2 | V1 | epmem-tutorial.zip: all-test/mac/mac2.soar | 300+ decisions, 18 rules |  |
| mac3-planning | V1 | epmem-tutorial.zip: all-test/mac/mac3-planning.soar | 277 decisions, 94 rules |  |
| monitor | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/towers-of-hanoi-recursive/monitor.soar<br>epmem-tutorial.zip: all-test/towers-of-hanoi/monitor.soar<br>2026-agents-verified.zip: 2026-agents-verified/Towers-of-hanoi/ToH-faster/monitor.soar<br>2026-agents-verified.zip: 2026-agents-verified/Towers-of-hanoi/ToH-no-operators/monitor.soar<br>2026-agents-verified.zip: 2026-agents-verified/Towers-of-hanoi/ToH-recur/monitor.soar<br>2026-agents-verified.zip: 2026-agents-verified/Towers-of-hanoi/monitor.soar<br>Water-jugs.zip: Towers-of-hanoi/ToH-faster/monitor.soar<br>Water-jugs.zip: Towers-of-hanoi/ToH-no-operators/monitor.soar<br>Water-jugs.zip: Towers-of-hanoi/ToH-recur/monitor.soar<br>Water-jugs.zip: Towers-of-hanoi/monitor.soar | 100 decisions, 7 rules |  |
| MOUTBot | V1 | epmem-tutorial.zip: all-test/MOUTBot.soar | 100 decisions, 733 rules |  |
| move | V1 | epmem-tutorial.zip: eaters 8.5.2/tutorial/move.soar | 100 decisions, 5 rules |  |
| move-north | V1 | epmem-tutorial.zip: eaters 8.5.2/tutorial/move-north.soar | 200 decisions, 2 rules |  |
| move-north-2 | V1 | epmem-tutorial.zip: eaters 8.5.2/tutorial/move-north-2.soar | 100 decisions, 3 rules |  |
| move-to-food | V1 | epmem-tutorial.zip: eaters 8.5.2/tutorial/move-to-food.soar | 100 decisions, 3 rules |  |
| move10 | V1 | epmem-tutorial.zip: eaters 8.5.2/move10.soar | 100 decisions, 34 rules |  |
| move12 | V1 | epmem-tutorial.zip: eaters 8.5.2/move12.soar | 100 decisions, 34 rules |  |
| move14 | V1 | epmem-tutorial.zip: eaters 8.5.2/move14.soar | 100 decisions, 34 rules |  |
| move20 | V1 | epmem-tutorial.zip: eaters 8.5.2/move20.soar | 100 decisions, 96 rules |  |
| multiplication | V1 | epmem-tutorial.zip: all-test/Arithmetic/OLD/multiplication.soar | 31 decisions, 41 rules |  |
| mummy | V1 | epmem-tutorial.zip: all-test/Mummy/old/mummy.soar | 100 decisions, 0 rules |  |
| mummy-draw | V1 | epmem-tutorial.zip: all-test/Mummy/mummy-draw.soar | 100 decisions, 7 rules |  |
| mummy-draw-num | V1 | epmem-tutorial.zip: all-test/Mummy/mummy-draw-num.soar | 100 decisions, 7 rules |  |
| mummy-heuristics | V1 | epmem-tutorial.zip: all-test/Mummy/mummy-heuristics.soar | 100 decisions, 1 rules |  |
| mummy-jel | V1 | epmem-tutorial.zip: all-test/Mummy/old/mummy-jel.soar | 100 decisions, 0 rules | missing: selection.soar; defaults filled: selection.soar |
| mummy-monitor | V1 | epmem-tutorial.zip: all-test/Mummy/mummy-monitor.soar | 100 decisions, 8 rules |  |
| mummy2 | V1 | epmem-tutorial.zip: all-test/Mummy/old/mummy2.soar | 100 decisions, 0 rules |  |
| mummy3 | V1 | epmem-tutorial.zip: all-test/Mummy/old/mummy3.soar | 100 decisions, 0 rules | missing: selection.soar, selection-iterative-deepening.soar; defaults filled: selection-iterative-deepening.soar, selection.soar |
| mummymaze1p-horiz qWxtW_lt | V1 | epmem-tutorial.zip: all-test/Mummy/mummymaze1p-horiz qWxtW_lt.soar | 100 decisions, 0 rules; load error: Failed to open file for reading: mummymaze1p-horiz |  |
| mummymaze1p-horiz qWxtW_lt-num | V1 | epmem-tutorial.zip: all-test/Mummy/mummymaze1p-horiz qWxtW_lt-num.soar | 100 decisions, 0 rules; load error: Failed to open file for reading: mummymaze1p-horiz |  |
| mummymaze1p-horiz-2-5-4-5_ | V1 | epmem-tutorial.zip: all-test/Mummy/mummymaze1p-horiz-2-5-4-5_.soar | 100 decisions, 0 rules |  |
| mummymaze1p-horiz.qWxtW_ | V1 | epmem-tutorial.zip: all-test/Mummy/old/mummymaze1p-horiz.qWxtW_.soar | 100 decisions, 0 rules | missing: selection.soar, selection-iterative-deepening.soar; defaults filled: selection-iterative-deepening.soar, selection.soar |
| mummymaze1p-horiz.qWxtW_lt-jx | V1 | epmem-tutorial.zip: all-test/Mummy/old/mummymaze1p-horiz.qWxtW_lt-jx.soar | 100 decisions, 0 rules | missing: selection.soar, selection-iterative-deepening.soar; defaults filled: selection-iterative-deepening.soar, selection.soar |
| mummymaze1p-horiz.qWxtW_lt-orig | V1 | epmem-tutorial.zip: all-test/Mummy/mummymaze1p-horiz.qWxtW_lt-orig.soar | 100 decisions, 0 rules |  |
| mummymaze1p-horiz.qWxtW_lt-orig | V2 | epmem-tutorial.zip: all-test/Mummy/old/mummymaze1p-horiz.qWxtW_lt-orig.soar | 100 decisions, 0 rules | missing: selection.soar, selection-iterative-deepening.soar; defaults filled: selection-iterative-deepening.soar, selection.soar |
| mummymaze1p-horiz.xbiduy | V1 | epmem-tutorial.zip: all-test/Mummy/old/mummymaze1p-horiz.xbiduy.soar | 300+ decisions, 154 rules | missing: selection.soar; defaults filled: selection.soar |
| mummymaze1p-hreform.d9du2o | V1 | epmem-tutorial.zip: all-test/Mummy/mummymaze1p-hreform.d9du2o.soar | 101 decisions, 142 rules | missing: selection-iterative-deepening.soar; defaults filled: selection-iterative-deepening.soar |
| mummymaze1p-hv.d0mkoc | V1 | epmem-tutorial.zip: all-test/Mummy/level8/mummymaze1p-hv.d0mkoc.soar | 249 decisions, 170 rules | missing: selection.soar; defaults filled: selection.soar |
| mummymaze1p-hv.ebd8g3 | V1 | epmem-tutorial.zip: all-test/Mummy/level8/mummymaze1p-hv.ebd8g3.soar | 249 decisions, 170 rules | missing: selection.soar; defaults filled: selection.soar |
| mummymaze1p-hvrope.6ho6jr | V1 | epmem-tutorial.zip: all-test/Mummy/level8/mummymaze1p-hvrope.6ho6jr.soar | 249 decisions, 173 rules | missing: selection.soar; defaults filled: selection.soar |
| mummymaze1p-hvrope.m9buyr | V1 | epmem-tutorial.zip: all-test/Mummy/level8/mummymaze1p-hvrope.m9buyr.soar | 249 decisions, 173 rules | missing: selection.soar; defaults filled: selection.soar |
| mummymaze1p-separate.vcz-sz | V1 | epmem-tutorial.zip: all-test/Mummy/level6/mummymaze1p-separate.vcz-sz.soar | 100 decisions, 74 rules | missing: selection.soar; defaults filled: selection.soar |
| newmummy | V1 | epmem-tutorial.zip: all-test/Mummy/old/newmummy.soar | 100 decisions, 0 rules | missing: selection.soar, selection-iterative-deepening.soar; defaults filled: selection-iterative-deepening.soar, selection.soar |
| newmummy-jel | V1 | epmem-tutorial.zip: all-test/Mummy/old/newmummy-jel.soar | 251 decisions, 192 rules | missing: selection.soar, selection-iterative-deepening.soar; defaults filled: selection-iterative-deepening.soar, selection.soar |
| office4 | V1 | arithmetic-smem.zip: john-nlp/manage-world-state/internal-worlds/office4.soar | 100 decisions, 1 rules |  |
| office4 | V2 | arithmetic-smem.zip: john-nlp/manage-world-state/waypoint-maps/office4.soar | 100 decisions, 1 rules |  |
| operator-subgoaling | V1 | knights-tour.zip: Instruction/default/operator-subgoaling.soar<br>knights-tour.zip: RL/default/operator-subgoaling.soar<br>epmem-tutorial.zip: all-test/default/operator-subgoaling.soar | default library |  |
| operator-subgoaling | V2 | epmem-tutorial.zip: DEFAULTS/default-2019-x/operator-subgoaling.soar<br>epmem-tutorial.zip: DEFAULTS/default-2019/operator-subgoaling.soar | default library |  |
| operator-subgoaling | V3 | epmem-tutorial.zip: Dice Game/IPHONE/Soar Agent/Soar Agent/default/operator-subgoaling.soar<br>epmem-tutorial.zip: current-robots/default/operator-subgoaling.soar<br>arithmetic-smem.zip: john-nlp/default/operator-subgoaling.soar | default library |  |
| operator-subgoaling | V4 | 2026-agents-verified.zip: 2026-agents-verified/default/operator-subgoaling.soar<br>RL-unit-test.zip: default/operator-subgoaling.soar<br>Water-jugs.zip: default/operator-subgoaling.soar<br>RL-general-state.zip: default/operator-subgoaling.soar | default library |  |
| opsub-core | V1 | blocks-world-book-2019.zip: blocks-world-book-2019/opsub-core.soar<br>blocks-world-book-2019-x.zip: blocks-world-book-2019-x/opsub-core.soar<br>blocks-world-book-2019-world.zip: blocks-world-book-2019-world/opsub-core.soar<br>RL-general-state.zip: BLOCKS-WORLD/blocks-world-book-2019-world/opsub-core.soar<br>RL-general-state.zip: BLOCKS-WORLD/blocks-world-book-2019/opsub-core.soar | 300+ decisions, 84 rules | missing: simple.soar, selection.soar; defaults filled: selection.soar, simple.soar |
| parameters | V1 | epmem-tutorial.zip: Book-robot/clean-house/elaborations/parameters.soar | 100 decisions, 1 rules |  |
| partial-s2 | V1 | epmem-tutorial.zip: all-test/UCBot/UCBot/maps/partial-s2.soar | 100 decisions, 1 rules |  |
| pass | V1 | epmem-tutorial.zip: Dice Game/dicegame-0.1.1/agents/pass.soar | 300+ decisions, 2 rules |  |
| patrol | V1 | knights-tour.zip: Instruction/robot3/clean-house-new/patrol.soar | 100 decisions, 2 rules |  |
| player_0 | V1 | knights-tour.zip: taxi/taxi/inheritance/Project/results/blue-rand-sarsa-1/player_0.soar | 100 decisions, 0 rules | missing: hrl-nav.soar |
| player_0 | V2 | knights-tour.zip: taxi/taxi/inheritance/Project/results/blue-rand-sarsa-1g/player_0.soar | 100 decisions, 0 rules | missing: hrl-nav-general.soar |
| player_0 | V3 | knights-tour.zip: taxi/taxi/inheritance/Project/results/blue-rand-sarsa-3/player_0.soar | 100 decisions, 0 rules | missing: hrl-nav.soar |
| player_0 | V4 | knights-tour.zip: taxi/taxi/inheritance/Project/results/blue-rand-sarsa-3g/player_0.soar | 100 decisions, 0 rules | missing: hrl-nav-general.soar |
| player_0 | V5 | knights-tour.zip: taxi/taxi/inheritance/Project/results/blue-rand-sarsa-5/player_0.soar | 100 decisions, 0 rules | missing: hrl-nav.soar |
| player_0 | V6 | knights-tour.zip: taxi/taxi/inheritance/Project/results/blue-rand-sarsa-5g/player_0.soar | 100 decisions, 0 rules | missing: hrl-nav-general.soar |
| player_0 | V7 | knights-tour.zip: taxi/taxi/inheritance/Project/results/blue-rand-sarsa-7/player_0.soar | 100 decisions, 0 rules | missing: hrl-nav.soar |
| player_0 | V8 | knights-tour.zip: taxi/taxi/inheritance/Project/results/blue-rand-sarsa-7g/player_0.soar | 100 decisions, 0 rules | missing: hrl-nav-general.soar |
| player_0 | V9 | knights-tour.zip: taxi/taxi/inheritance/Project/results/blue-sw-sarsa-1/player_0.soar | 100 decisions, 0 rules | missing: hrl-nav.soar |
| player_0 | V10 | knights-tour.zip: taxi/taxi/inheritance/Project/results/blue-sw-sarsa-1g/player_0.soar | 100 decisions, 0 rules | missing: hrl-nav-general.soar |
| player_0 | V11 | knights-tour.zip: taxi/taxi/inheritance/Project/results/blue-sw-sarsa-3/player_0.soar | 100 decisions, 0 rules | missing: hrl-nav.soar |
| player_0 | V12 | knights-tour.zip: taxi/taxi/inheritance/Project/results/blue-sw-sarsa-3g/player_0.soar | 100 decisions, 0 rules | missing: hrl-nav-general.soar |
| player_0 | V13 | knights-tour.zip: taxi/taxi/inheritance/Project/results/blue-sw-sarsa-5/player_0.soar | 100 decisions, 0 rules | missing: hrl-nav.soar |
| player_0 | V14 | knights-tour.zip: taxi/taxi/inheritance/Project/results/blue-sw-sarsa-5g/player_0.soar | 100 decisions, 0 rules | missing: hrl-nav-general.soar |
| player_0 | V15 | knights-tour.zip: taxi/taxi/inheritance/Project/results/blue-sw-sarsa-7/player_0.soar | 100 decisions, 0 rules | missing: hrl-nav.soar |
| player_0 | V16 | knights-tour.zip: taxi/taxi/inheritance/Project/results/blue-sw-sarsa-7g/player_0.soar | 100 decisions, 0 rules | missing: hrl-nav-general.soar |
| player_0 | V17 | knights-tour.zip: taxi/taxi/inheritance/Project/results/full-rand-rand-sarsa-1/player_0.soar | 100 decisions, 0 rules | missing: hrl-nav.soar |
| player_0 | V18 | knights-tour.zip: taxi/taxi/inheritance/Project/results/full-rand-rand-sarsa-1g/player_0.soar | 100 decisions, 0 rules | missing: hrl-nav-general.soar |
| player_0 | V19 | knights-tour.zip: taxi/taxi/inheritance/Project/results/full-rand-rand-sarsa-3/player_0.soar | 100 decisions, 0 rules | missing: hrl-nav.soar |
| player_0 | V20 | knights-tour.zip: taxi/taxi/inheritance/Project/results/full-rand-rand-sarsa-3g/player_0.soar | 100 decisions, 0 rules | missing: hrl-nav-general.soar |
| player_0 | V21 | knights-tour.zip: taxi/taxi/inheritance/Project/results/full-rand-rand-sarsa-5/player_0.soar | 100 decisions, 0 rules | missing: hrl-nav.soar |
| player_0 | V22 | knights-tour.zip: taxi/taxi/inheritance/Project/results/full-rand-rand-sarsa-5g/player_0.soar | 100 decisions, 0 rules | missing: hrl-nav-general.soar |
| player_0 | V23 | knights-tour.zip: taxi/taxi/inheritance/Project/results/full-rand-rand-sarsa-7/player_0.soar | 100 decisions, 0 rules | missing: hrl-nav.soar |
| player_0 | V24 | knights-tour.zip: taxi/taxi/inheritance/Project/results/full-rand-rand-sarsa-7g/player_0.soar | 100 decisions, 0 rules | missing: hrl-nav-general.soar |
| player_0 | V25 | knights-tour.zip: taxi/taxi/inheritance/Project/results/high-decide-full-random-5/player_0.soar | 100 decisions, 0 rules | missing: hrl-full-max.soar |
| player_0 | V26 | knights-tour.zip: taxi/taxi/inheritance/Project/results/high-decide-full-random-5b/player_0.soar | 100 decisions, 0 rules | missing: hrl-full-max.soar |
| player_0 | V27 | knights-tour.zip: taxi/taxi/inheritance/Project/results/high-decide-full-random-5c/player_0.soar | 100 decisions, 0 rules | missing: hrl-full-max.soar |
| player_0 | V28 | knights-tour.zip: taxi/taxi/inheritance/Project/results/high-decide-full-random-5d/player_0.soar | 100 decisions, 0 rules | missing: hrl-full-max.soar |
| player_0 | V29 | knights-tour.zip: taxi/taxi/inheritance/Project/results/high-decide-gp-random-1-20/player_0.soar | 100 decisions, 0 rules | missing: hrl-nav-max.soar |
| player_0 | V30 | knights-tour.zip: taxi/taxi/inheritance/Project/results/high-decide-gp-random-1/player_0.soar | 100 decisions, 0 rules | missing: hrl-nav-max.soar |
| player_0 | V31 | knights-tour.zip: taxi/taxi/inheritance/Project/results/high-decide-gp-random-1g-20/player_0.soar | 100 decisions, 0 rules | missing: hrl-nav-max-general.soar |
| player_0 | V32 | knights-tour.zip: taxi/taxi/inheritance/Project/results/high-decide-gp-random-1g-50/player_0.soar | 100 decisions, 0 rules | missing: hrl-nav-max-general.soar |
| player_0 | V33 | knights-tour.zip: taxi/taxi/inheritance/Project/results/high-decide-gp-random-1g/player_0.soar | 100 decisions, 0 rules | missing: hrl-nav-max-general.soar |
| player_0 | V34 | knights-tour.zip: taxi/taxi/inheritance/Project/results/high-decide-gp-random-3-20/player_0.soar | 100 decisions, 0 rules | missing: hrl-nav-max.soar |
| player_0 | V35 | knights-tour.zip: taxi/taxi/inheritance/Project/results/high-decide-gp-random-3/player_0.soar | 100 decisions, 0 rules | missing: hrl-nav-max.soar |
| player_0 | V36 | knights-tour.zip: taxi/taxi/inheritance/Project/results/high-decide-gp-random-3g-20/player_0.soar | 100 decisions, 0 rules | missing: hrl-nav-max-general.soar |
| player_0 | V37 | knights-tour.zip: taxi/taxi/inheritance/Project/results/high-decide-gp-random-3g-50/player_0.soar | 100 decisions, 0 rules | missing: hrl-nav-max-general.soar |
| player_0 | V38 | knights-tour.zip: taxi/taxi/inheritance/Project/results/high-decide-gp-random-3g/player_0.soar | 100 decisions, 0 rules | missing: hrl-nav-max-general.soar |
| player_0 | V39 | knights-tour.zip: taxi/taxi/inheritance/Project/results/high-decide-gp-random-5-20/player_0.soar | 100 decisions, 0 rules | missing: hrl-nav-max.soar |
| player_0 | V40 | knights-tour.zip: taxi/taxi/inheritance/Project/results/high-decide-gp-random-5/player_0.soar | 100 decisions, 0 rules | missing: hrl-nav-max.soar |
| player_0 | V41 | knights-tour.zip: taxi/taxi/inheritance/Project/results/high-decide-gp-random-5g-20/player_0.soar | 100 decisions, 0 rules | missing: hrl-nav-max-general.soar |
| player_0 | V42 | knights-tour.zip: taxi/taxi/inheritance/Project/results/high-decide-gp-random-5g-50/player_0.soar | 100 decisions, 0 rules | missing: hrl-nav-max-general.soar |
| player_0 | V43 | knights-tour.zip: taxi/taxi/inheritance/Project/results/high-decide-gp-random-5g/player_0.soar | 100 decisions, 0 rules | missing: hrl-nav-max-general.soar |
| player_0 | V44 | knights-tour.zip: taxi/taxi/inheritance/Project/results/high-decide-gp-random-7-20/player_0.soar | 100 decisions, 0 rules | missing: hrl-nav-max.soar |
| player_0 | V45 | knights-tour.zip: taxi/taxi/inheritance/Project/results/high-decide-gp-random-7/player_0.soar | 100 decisions, 0 rules | missing: hrl-nav-max.soar |
| player_0 | V46 | knights-tour.zip: taxi/taxi/inheritance/Project/results/high-decide-gp-random-7g-20/player_0.soar | 100 decisions, 0 rules | missing: hrl-nav-max-general.soar |
| player_0 | V47 | knights-tour.zip: taxi/taxi/inheritance/Project/results/high-decide-gp-random-7g-50/player_0.soar | 100 decisions, 0 rules | missing: hrl-nav-max-general.soar |
| player_0 | V48 | knights-tour.zip: taxi/taxi/inheritance/Project/results/high-decide-gp-random-7g/player_0.soar | 100 decisions, 0 rules | missing: hrl-nav-max-general.soar |
| player_0 | V49 | knights-tour.zip: taxi/taxi/inheritance/Project/results/rand-rand-sarsa-1/player_0.soar | 100 decisions, 0 rules | missing: hrl-nav.soar |
| player_0 | V50 | knights-tour.zip: taxi/taxi/inheritance/Project/results/rand-rand-sarsa-1g/player_0.soar | 100 decisions, 0 rules | missing: hrl-nav-general.soar |
| player_0 | V51 | knights-tour.zip: taxi/taxi/inheritance/Project/results/rand-rand-sarsa-3/player_0.soar | 100 decisions, 0 rules | missing: hrl-nav.soar |
| player_0 | V52 | knights-tour.zip: taxi/taxi/inheritance/Project/results/rand-rand-sarsa-3g/player_0.soar | 100 decisions, 0 rules | missing: hrl-nav-general.soar |
| player_0 | V53 | knights-tour.zip: taxi/taxi/inheritance/Project/results/rand-rand-sarsa-5/player_0.soar | 100 decisions, 0 rules | missing: hrl-nav.soar |
| player_0 | V54 | knights-tour.zip: taxi/taxi/inheritance/Project/results/rand-rand-sarsa-5g/player_0.soar | 100 decisions, 0 rules | missing: hrl-nav-general.soar |
| player_0 | V55 | knights-tour.zip: taxi/taxi/inheritance/Project/results/rand-rand-sarsa-7/player_0.soar | 100 decisions, 0 rules | missing: hrl-nav.soar |
| player_0 | V56 | knights-tour.zip: taxi/taxi/inheritance/Project/results/rand-rand-sarsa-7g/player_0.soar | 100 decisions, 0 rules | missing: hrl-nav-general.soar |
| player_0 | V57 | knights-tour.zip: taxi/taxi/inheritance/Project/results/sanity-g/player_0.soar | 100 decisions, 0 rules | missing: hrl-nav-max-general.soar |
| player_0 | V58 | knights-tour.zip: taxi/taxi/inheritance/Project/results/sanity-nav-g/player_0.soar | 100 decisions, 0 rules | missing: hrl-nav-general.soar |
| player_0 | V59 | knights-tour.zip: taxi/taxi/inheritance/Project/results/sanity-nav/player_0.soar | 100 decisions, 0 rules | missing: hrl-nav.soar |
| player_0 | V60 | knights-tour.zip: taxi/taxi/inheritance/Project/results/sanity-nav5/player_0.soar | 100 decisions, 0 rules | missing: hrl-nav.soar |
| player_0 | V61 | knights-tour.zip: taxi/taxi/inheritance/Project/results/sanity-nav7/player_0.soar | 100 decisions, 0 rules | missing: hrl-nav.soar |
| player_0 | V62 | knights-tour.zip: taxi/taxi/inheritance/Project/results/sanity/player_0.soar | 100 decisions, 0 rules | missing: hrl-nav-max.soar |
| pref-semantics-test | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/FullTests/pref-semantics-test.soar | 34 decisions, 76 rules; load error: ****WARNING: Replacing function named failed with halt since this is a unit test but running in a non-unit testing environment. |  |
| problems-10000 | V1 | epmem-tutorial.zip: Arithmetic-smem/problems-10000.soar<br>RL-general-state.zip: Arithmetic-smem/problems-10000.soar<br>arithmetic-smem.zip: arithmetic-smem/problems-10000.soar | 100 decisions, 1 rules |  |
| problems-3 | V1 | epmem-tutorial.zip: Arithmetic-smem/problems-3.soar<br>arithmetic-smem.zip: arithmetic-smem/problems-3.soar | 100 decisions, 1 rules |  |
| problems-3 | V2 | RL-general-state.zip: Arithmetic-smem/problems-3.soar | 100 decisions, 1 rules |  |
| pyramid | V1 | RL-general-state.zip: Pyramid/OLD/Raw Pyramid Solves/pyramid.soar | 13 decisions, 9 rules |  |
| pyramid-anderson | V1 | RL-general-state.zip: Pyramid/OLD/Raw Pyramid Solves/pyramid-anderson.soar | 5 decisions, 8 rules |  |
| pyramid-hierarchical | V1 | RL-general-state.zip: Pyramid/OLD/Raw Pyramid Solves/pyramid-hierarchical.soar | 22 decisions, 17 rules |  |
| pyramid-jel | V1 | RL-general-state.zip: Pyramid/OLD/Raw Pyramid Solves/pyramid-jel.soar | 13 decisions, 6 rules |  |
| rl-unit | V1 | knights-tour.zip: rl-unit/rl-unit.soar | 25 decisions, 37 rules |  |
| rl-unit | V2 | 2026-agents-verified.zip: 2026-agents-verified/RL-unit-test/rl-unit.soar<br>Water-jugs.zip: RL-unit-test/rl-unit.soar | 25 decisions, 37 rules |  |
| rl-unit | V3 | RL-unit-test.zip: RL-unit-test/rl-unit.soar | 25 decisions, 37 rules |  |
| Robot | V1 | epmem-tutorial.zip: Book-robot/OLD/Robot.soar<br>epmem-tutorial.zip: all-test/Book-robot/Robot.soar | 300+ decisions, 10 rules |  |
| robot-hierarchical-pickup | V1 | epmem-tutorial.zip: Book-robot/OLD/robot-hierarchical-pickup.soar<br>epmem-tutorial.zip: all-test/Book-robot/robot-hierarchical-pickup.soar | 300+ decisions, 25 rules |  |
| robot-move-turn-pickup-block | V1 | epmem-tutorial.zip: Book-robot/OLD/robot-move-turn-pickup-block.soar<br>epmem-tutorial.zip: all-test/Book-robot/robot-move-turn-pickup-block.soar | 300+ decisions, 19 rules |  |
| robot-pickup-block | V1 | epmem-tutorial.zip: Book-robot/OLD/robot-pickup-block.soar<br>epmem-tutorial.zip: all-test/Book-robot/robot-pickup-block.soar | 300+ decisions, 11 rules |  |
| robot-RL | V1 | knights-tour.zip: robot-RL/robot-RL.soar | 101 decisions, 37522 rules |  |
| room-discrete-move-turn-pickup | V1 | epmem-tutorial.zip: all-test/Room-discrete/room-discrete-move-turn-pickup.soar | 100 decisions, 0 rules |  |
| safe | V1 | epmem-tutorial.zip: all-test/Mummy/safe.soar | 100 decisions, 4 rules |  |
| select-mission | V1 | knights-tour.zip: Instruction/robot3/clean-house-new/select-mission.soar | 100 decisions, 5 rules |  |
| selection | V1 | knights-tour.zip: Instruction/default/old/selection.soar<br>RL-unit-test.zip: default/old/selection.soar | default library |  |
| selection | V2 | knights-tour.zip: Instruction/default/selection.soar | default library |  |
| selection | V3 | epmem-tutorial.zip: CozmoSoarDemo/default/selection.soar | default library |  |
| selection | V4 | epmem-tutorial.zip: DEFAULTS/default-2019-x/selection.soar | default library |  |
| selection | V5 | epmem-tutorial.zip: DEFAULTS/default-2019/selection.soar | default library |  |
| selection | V6 | epmem-tutorial.zip: default-9.6.4/selection.soar | default library |  |
| selection | V7 | arithmetic-smem.zip: default-world/selection.soar | default library |  |
| selection | V8 | arithmetic.zip: default/selection.soar | default library |  |
| selection-astar | V1 | knights-tour.zip: Instruction/default/old/selection-astar.soar<br>RL-unit-test.zip: default/old/selection-astar.soar | default library |  |
| selection-astar | V2 | knights-tour.zip: Instruction/default/selection-astar.soar | default library |  |
| selection-astar | V3 | epmem-tutorial.zip: CozmoSoarDemo/default/selection-astar.soar | default library |  |
| selection-astar | V4 | epmem-tutorial.zip: DEFAULTS/default-2019-x/selection-astar.soar<br>epmem-tutorial.zip: DEFAULTS/default-2019/selection-astar.soar<br>2026-agents-verified.zip: 2026-agents-verified/default/selection-astar.soar<br>Water-jugs.zip: default/selection-astar.soar<br>RL-general-state.zip: default/selection-astar.soar | default library |  |
| selection-astar | V5 | epmem-tutorial.zip: default-9.6.4/selection-astar.soar | default library |  |
| selection-astar | V6 | arithmetic.zip: default/selection-astar.soar | default library |  |
| selection-astar-1-11-11 | V1 | RL-unit-test.zip: default/old/selection-astar-1-11-11.soar | default library |  |
| selection-astar-9-6-09 | V1 | knights-tour.zip: Instruction/default/selection-astar-9-6-09.soar<br>RL-unit-test.zip: default/old/selection-astar-9-6-09.soar | default library | missing: selection.soar; defaults filled: selection.soar |
| selection-depth-bounded | V1 | epmem-tutorial.zip: DEFAULTS/default-2019-x/selection-depth-bounded.soar<br>epmem-tutorial.zip: DEFAULTS/default-2019/selection-depth-bounded.soar<br>2026-agents-verified.zip: 2026-agents-verified/default/selection-depth-bounded.soar<br>RL-unit-test.zip: default/selection-depth-bounded.soar<br>Water-jugs.zip: default/selection-depth-bounded.soar<br>RL-general-state.zip: default/selection-depth-bounded.soar | default library |  |
| selection-epmem | V1 | epmem-tutorial.zip: DEFAULTS/default-2019-x/selection-epmem.soar<br>epmem-tutorial.zip: DEFAULTS/default-2019/selection-epmem.soar<br>2026-agents-verified.zip: 2026-agents-verified/default/selection-epmem.soar<br>RL-unit-test.zip: default/selection-epmem.soar<br>Water-jugs.zip: default/selection-epmem.soar<br>RL-general-state.zip: default/selection-epmem.soar | default library |  |
| selection-iterative-deepening | V1 | knights-tour.zip: Instruction/default/Iterative-short-cut-no-chunk/selection-iterative-deepening.soar<br>epmem-tutorial.zip: DEFAULTS/default-2019-x/Iterative-short-cut-no-chunk/selection-iterative-deepening.soar<br>epmem-tutorial.zip: DEFAULTS/default-2019/Iterative-short-cut-no-chunk/selection-iterative-deepening.soar<br>epmem-tutorial.zip: all-test/default/Iterative-short-cut-no-chunk/selection-iterative-deepening.soar<br>2026-agents-verified.zip: 2026-agents-verified/default/Iterative-short-cut-no-chunk/selection-iterative-deepening.soar<br>RL-unit-test.zip: default/Iterative-short-cut-no-chunk/selection-iterative-deepening.soar<br>Water-jugs.zip: default/Iterative-short-cut-no-chunk/selection-iterative-deepening.soar<br>RL-general-state.zip: default/Iterative-short-cut-no-chunk/selection-iterative-deepening.soar | default library |  |
| selection-iterative-deepening | V2 | knights-tour.zip: Instruction/default/selection-iterative-deepening.soar | default library |  |
| selection-iterative-deepening | V3 | knights-tour.zip: Instruction/old/default/selection-iterative-deepening.soar<br>knights-tour.zip: Instruction/old/saw/clean/default/selection-iterative-deepening.soar | default library | missing: selection-iterative-deepening_source.soar |
| selection-iterative-deepening | V4 | knights-tour.zip: RL/default/selection-iterative-deepening.soar | default library |  |
| selection-iterative-deepening | V5 | epmem-tutorial.zip: CozmoSoarDemo/default/selection-iterative-deepening.soar<br>epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/default/selection-iterative-deepening.soar<br>epmem-tutorial.zip: default-9.6.4/selection-iterative-deepening.soar<br>epmem-tutorial.zip: default/selection-iterative-deepening.soar<br>arithmetic.zip: default/selection-iterative-deepening.soar | default library | missing: mummy.soar |
| selection-iterative-deepening | V6 | epmem-tutorial.zip: DEFAULTS/default-2019-x/selection-iterative-deepening.soar<br>epmem-tutorial.zip: DEFAULTS/default-2019/selection-iterative-deepening.soar<br>RL-unit-test.zip: default/selection-iterative-deepening.soar<br>RL-general-state.zip: default/selection-iterative-deepening.soar | default library |  |
| selection-iterative-deepening | V7 | epmem-tutorial.zip: Dice Game/IPHONE/Soar Agent/Soar Agent/default/selection-iterative-deepening.soar | default library |  |
| selection-iterative-deepening | V8 | arithmetic-smem.zip: default-world/selection-iterative-deepening.soar | default library |  |
| selection-iterative-deepening-general-chunks | V1 | epmem-tutorial.zip: DEFAULTS/default-2019-x/selection-iterative-deepening-general-chunks.soar<br>epmem-tutorial.zip: DEFAULTS/default-2019/selection-iterative-deepening-general-chunks.soar<br>2026-agents-verified.zip: 2026-agents-verified/default/selection-iterative-deepening-general-chunks.soar<br>Water-jugs.zip: default/selection-iterative-deepening-general-chunks.soar<br>RL-general-state.zip: default/selection-iterative-deepening-general-chunks.soar | default library |  |
| selection-optimal | V1 | knights-tour.zip: Instruction/default/selection-optimal.soar<br>epmem-tutorial.zip: CozmoSoarDemo/default/selection-optimal.soar<br>epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/Chunking/tests/default/selection-optimal.soar<br>epmem-tutorial.zip: DEFAULTS/default-2019-x/selection-optimal.soar<br>epmem-tutorial.zip: DEFAULTS/default-2019/selection-optimal.soar<br>epmem-tutorial.zip: default-9.6.4/selection-optimal.soar<br>epmem-tutorial.zip: default/selection-optimal.soar<br>2026-agents-verified.zip: 2026-agents-verified/default/selection-optimal.soar<br>RL-unit-test.zip: default/selection-optimal.soar<br>Water-jugs.zip: default/selection-optimal.soar<br>RL-general-state.zip: default/selection-optimal.soar<br>arithmetic.zip: default/selection-optimal.soar | default library |  |
| selection-optimal | V2 | knights-tour.zip: RL/default/selection-optimal.soar | default library |  |
| selection-optimal | V3 | arithmetic-smem.zip: default-world/selection-optimal.soar | default library |  |
| selection-optimal-original | V1 | knights-tour.zip: Instruction/default/selection-optimal-original.soar<br>knights-tour.zip: RL/default/selection-optimal-original.soar<br>epmem-tutorial.zip: DEFAULTS/default-2019-x/selection-optimal-original.soar<br>epmem-tutorial.zip: DEFAULTS/default-2019/selection-optimal-original.soar<br>epmem-tutorial.zip: all-test/default/selection-optimal-original.soar<br>2026-agents-verified.zip: 2026-agents-verified/default/selection-optimal-original.soar<br>RL-unit-test.zip: default/selection-optimal-original.soar<br>Water-jugs.zip: default/selection-optimal-original.soar<br>RL-general-state.zip: default/selection-optimal-original.soar | default library |  |
| selection-RL | V1 | knights-tour.zip: Instruction/default/selection-RL.soar<br>epmem-tutorial.zip: DEFAULTS/default-2019-x/selection-RL.soar<br>epmem-tutorial.zip: DEFAULTS/default-2019/selection-RL.soar<br>2026-agents-verified.zip: 2026-agents-verified/default/selection-RL.soar<br>RL-unit-test.zip: default/selection-RL.soar<br>Water-jugs.zip: default/selection-RL.soar<br>RL-general-state.zip: default/selection-RL.soar | default library |  |
| selection-RL-generation | V1 | RL-unit-test.zip: RL-general-state/selection-RL-generation.soar | default library |  |
| selection-world | V1 | arithmetic-smem.zip: default-world/selection-world.soar | default library |  |
| selection-x | V1 | epmem-tutorial.zip: DEFAULTS/default-2019-x/selection-x.soar | default library |  |
| semantic-errors | V1 | epmem-tutorial.zip: eaters 8.5.2/tutorial/semantic-errors.soar | 100 decisions, 3 rules |  |
| simple | V1 | knights-tour.zip: Instruction/default/simple.soar<br>knights-tour.zip: RL/default/simple.soar | default library |  |
| simple | V2 | epmem-tutorial.zip: DEFAULTS/default-2019-x/simple.soar<br>epmem-tutorial.zip: DEFAULTS/default-2019/simple.soar<br>RL-unit-test.zip: default/simple.soar | default library |  |
| simple | V3 | epmem-tutorial.zip: Dice Game/IPHONE/Soar Agent/Soar Agent/default/simple.soar<br>epmem-tutorial.zip: current-robots/default/simple.soar | default library |  |
| simple | V4 | epmem-tutorial.zip: default-9.6.4/simple.soar<br>epmem-tutorial.zip: default/simple.soar<br>arithmetic.zip: default/simple.soar | default library |  |
| simple | V5 | arithmetic-smem.zip: default-world/simple.soar | default library |  |
| simple-robot-large-room | V1 | epmem-tutorial.zip: current-robots/simple-robot-large-room.soar | 100 decisions, 4 rules |  |
| simple-robot-with-avoidance-line | V1 | epmem-tutorial.zip: current-robots/simple-robot-with-avoidance-line.soar | 300+ decisions, 237 rules |  |
| simple-robot-with-avoidance-patrol-lab | V1 | epmem-tutorial.zip: current-robots/simple-robot-with-avoidance-patrol-lab.soar | 300+ decisions, 237 rules |  |
| simple-robot-with-avoidance-rectangle | V1 | epmem-tutorial.zip: current-robots/simple-robot-with-avoidance-rectangle.soar | 300+ decisions, 237 rules |  |
| simple-robot-with-avoidance-square | V1 | epmem-tutorial.zip: current-robots/simple-robot-with-avoidance-square.soar | 300+ decisions, 237 rules |  |
| simple-robot-with-avoidance-star | V1 | epmem-tutorial.zip: current-robots/simple-robot-with-avoidance-star.soar | 300+ decisions, 235 rules; load error: Production addition failed. | First compared November 3; differed until model fixes of that day (doc/DIFFERENCES.md, November 3 afternoon); matches since. |
| simple-robot-with-avoidance-star-plan | V1 | epmem-tutorial.zip: current-robots/simple-robot-with-avoidance-star-plan.soar | 300+ decisions, 237 rules |  |
| simple_kitchen | V1 | arithmetic-smem.zip: john-nlp/manage-world-state/internal-worlds/simple_kitchen.soar | 100 decisions, 1 rules |  |
| simple_kitchen | V2 | arithmetic-smem.zip: john-nlp/manage-world-state/waypoint-maps/simple_kitchen.soar | 100 decisions, 1 rules |  |
| simple_kitchen_jule | V1 | arithmetic-smem.zip: john-nlp/manage-world-state/internal-worlds/simple_kitchen_jule.soar | 100 decisions, 1 rules |  |
| single_location | V1 | arithmetic-smem.zip: john-nlp/manage-world-state/waypoint-maps/single_location.soar | 100 decisions, 1 rules |  |
| smem | V1 | epmem-tutorial.zip: Eater Bootstrap/smem.soar | 100 decisions, 3 rules |  |
| SMemFunctionalTests_smem-i-support | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/smem/SMemFunctionalTests_smem-i-support.soar | 6 decisions, 8 rules |  |
| SMemFunctionalTests_testBadMathQuery | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/smem/SMemFunctionalTests_testBadMathQuery.soar | 2 decisions, 5 rules |  |
| SMemFunctionalTests_testCueSelection | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/smem/SMemFunctionalTests_testCueSelection.soar | 101 decisions, 2 rules |  |
| SMemFunctionalTests_testFactorization | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/smem/SMemFunctionalTests_testFactorization.soar | 300+ decisions, 104 rules |  |
| SMemFunctionalTests_testGreater | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/smem/SMemFunctionalTests_testGreater.soar | 1 decisions, 3 rules |  |
| SMemFunctionalTests_testGreaterOrEqual | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/smem/SMemFunctionalTests_testGreaterOrEqual.soar | 1 decisions, 3 rules |  |
| SMemFunctionalTests_testLess | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/smem/SMemFunctionalTests_testLess.soar | 1 decisions, 3 rules |  |
| SMemFunctionalTests_testLessNoSolution | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/smem/SMemFunctionalTests_testLessNoSolution.soar | 1 decisions, 3 rules |  |
| SMemFunctionalTests_testLessOrEqual | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/smem/SMemFunctionalTests_testLessOrEqual.soar | 1 decisions, 3 rules |  |
| SMemFunctionalTests_testLessWithNeg | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/smem/SMemFunctionalTests_testLessWithNeg.soar | 1 decisions, 3 rules |  |
| SMemFunctionalTests_testMax | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/smem/SMemFunctionalTests_testMax.soar | 1 decisions, 3 rules |  |
| SMemFunctionalTests_testMaxDoublePrecision | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/smem/SMemFunctionalTests_testMaxDoublePrecision.soar | 5 decisions, 13 rules; load error: *WARNING: Replacing function named failed with halt since this is a unit test but running in a non-unit testing environment. |  |
| SMemFunctionalTests_testMaxDoublePrecision-Irrational | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/smem/SMemFunctionalTests_testMaxDoublePrecision-Irrational.soar | 5 decisions, 14 rules; load error: *WARNING: Replacing function named failed with halt since this is a unit test but running in a non-unit testing environment. |  |
| SMemFunctionalTests_testMaxMixedTypes | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/smem/SMemFunctionalTests_testMaxMixedTypes.soar | 1 decisions, 3 rules |  |
| SMemFunctionalTests_testMaxMultivalued | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/smem/SMemFunctionalTests_testMaxMultivalued.soar | 1 decisions, 3 rules |  |
| SMemFunctionalTests_testMaxNegation | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/smem/SMemFunctionalTests_testMaxNegation.soar | 1 decisions, 3 rules |  |
| SMemFunctionalTests_testMin | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/smem/SMemFunctionalTests_testMin.soar | 1 decisions, 3 rules |  |
| SMemFunctionalTests_testMultiAgent | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/smem/SMemFunctionalTests_testMultiAgent.soar | 4 decisions, 9 rules |  |
| SMemFunctionalTests_testNegQuery | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/smem/SMemFunctionalTests_testNegQuery.soar | 248 decisions, 22 rules |  |
| SMemFunctionalTests_testNegQueryNoHash | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/smem/SMemFunctionalTests_testNegQueryNoHash.soar | 1 decisions, 3 rules |  |
| SMemFunctionalTests_testNegStringFloat | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/smem/SMemFunctionalTests_testNegStringFloat.soar | 5 decisions, 13 rules; load error: *WARNING: Replacing function named failed with halt since this is a unit test but running in a non-unit testing environment. |  |
| SMemFunctionalTests_testSimpleCueBasedRetrieval | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/smem/SMemFunctionalTests_testSimpleCueBasedRetrieval.soar | 1 decisions, 3 rules |  |
| SMemFunctionalTests_testSimpleFloat | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/smem/SMemFunctionalTests_testSimpleFloat.soar | 5 decisions, 13 rules; load error: *WARNING: Replacing function named failed with halt since this is a unit test but running in a non-unit testing environment. |  |
| SMemFunctionalTests_testSimpleNonCueBasedRetrieval | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/smem/SMemFunctionalTests_testSimpleNonCueBasedRetrieval.soar | 2 decisions, 5 rules |  |
| SMemFunctionalTests_testSimpleNonCueBasedRetrieval_ActivationBaseLevel_Incremental | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/smem/SMemFunctionalTests_testSimpleNonCueBasedRetrieval_ActivationBaseLevel_Incremental.soar | 5 decisions, 11 rules |  |
| SMemFunctionalTests_testSimpleNonCueBasedRetrieval_ActivationBaseLevel_Naive | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/smem/SMemFunctionalTests_testSimpleNonCueBasedRetrieval_ActivationBaseLevel_Naive.soar | 5 decisions, 11 rules |  |
| SMemFunctionalTests_testSimpleNonCueBasedRetrieval_ActivationBaseLevel_Stable | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/smem/SMemFunctionalTests_testSimpleNonCueBasedRetrieval_ActivationBaseLevel_Stable.soar | 5 decisions, 11 rules |  |
| SMemFunctionalTests_testSimpleNonCueBasedRetrieval_ActivationFrequency | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/smem/SMemFunctionalTests_testSimpleNonCueBasedRetrieval_ActivationFrequency.soar | 2 decisions, 5 rules |  |
| SMemFunctionalTests_testSimpleNonCueBasedRetrieval_ActivationRecency | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/smem/SMemFunctionalTests_testSimpleNonCueBasedRetrieval_ActivationRecency.soar | 2 decisions, 5 rules |  |
| SMemFunctionalTests_testSimpleNonCueBasedRetrieval_ActivationRecency_WithoutActivateOnQuery | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/smem/SMemFunctionalTests_testSimpleNonCueBasedRetrieval_ActivationRecency_WithoutActivateOnQuery.soar | 2 decisions, 5 rules |  |
| SMemFunctionalTests_testSimpleNonCueBasedRetrievalOfNonExistingLTI | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/smem/SMemFunctionalTests_testSimpleNonCueBasedRetrievalOfNonExistingLTI.soar | 1 decisions, 3 rules |  |
| SMemFunctionalTests_testSimpleStore | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/smem/SMemFunctionalTests_testSimpleStore.soar | 2 decisions, 5 rules |  |
| SMemFunctionalTests_testSimpleStoreGC | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/smem/SMemFunctionalTests_testSimpleStoreGC.soar | 105 decisions, 9 rules |  |
| SMemFunctionalTests_testSimpleStoreMultivaluedAttribute | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/smem/SMemFunctionalTests_testSimpleStoreMultivaluedAttribute.soar | 2 decisions, 5 rules |  |
| SMemFunctionalTests_testSpreadingActivation_AlphabetAgentAllOn | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/smem/SMemFunctionalTests_testSpreadingActivation_AlphabetAgentAllOn.soar | 300+ decisions, 51 rules |  |
| SMemFunctionalTests_testTrivialMathQuery | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/smem/SMemFunctionalTests_testTrivialMathQuery.soar | 2 decisions, 5 rules |  |
| special-case-rules | V1 | arithmetic-smem.zip: john-nlp/special-case-rules.soar | 100 decisions, 1 rules |  |
| subtraction | V1 | epmem-tutorial.zip: all-test/Arithmetic/OLD/subtraction.soar | 30 decisions, 33 rules |  |
| syntax-error | V1 | epmem-tutorial.zip: eaters 8.5.2/tutorial/syntax-error.soar | 100 decisions, 0 rules; load error: No such command: will	/home/claude/cmcsoar/tests/agentlib/lib/syntax-error/V1/syntax-error.soar:9 |  |
| taxi | V1 | knights-tour.zip: taxi/taxi/inheritance/taxi-hrl/taxi.soar | 300+ decisions, 78 rules |  |
| taxi | V2 | knights-tour.zip: taxi/taxi/inheritance/taxi/credit/taxi.soar | 103 decisions, 38 rules |  |
| taxi-hrl | V1 | knights-tour.zip: taxi/taxi/agents/taxi-hrl.soar | 101 decisions, 6907 rules |  |
| taxi-hrl-hybrid | V1 | knights-tour.zip: taxi/taxi/agents/taxi-hrl-hybrid.soar | 100 decisions, 5 rules |  |
| taxi-hrl-oracle | V1 | knights-tour.zip: taxi/taxi/agents/taxi-hrl-oracle.soar | 101 decisions, 20031 rules |  |
| taxi-mapping | V1 | knights-tour.zip: taxi/taxi/agents/taxi-mapping.soar | 103 decisions, 69 rules |  |
| taxi-rl | V1 | knights-tour.zip: taxi/taxi/agents/taxi-rl.soar | 100 decisions, 14 rules | Times out in soar-lean within the comparison's limit (November 3). |
| taxi-rl-oracle | V1 | knights-tour.zip: taxi/taxi/agents/taxi-rl-oracle.soar | 101 decisions, 16031 rules |  |
| temp_chunks | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/temp_chunks.soar | 100 decisions, 4 rules |  |
| test-agent | V1 | epmem-tutorial.zip: CozmoSoarDemo/PySoarLib/example/test-agent.soar | 300+ decisions, 7 rules |  |
| test-agent | V2 | epmem-tutorial.zip: CozmoSoarDemo/productions/test-agent.soar | 300+ decisions, 33 rules |  |
| test1121 | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/FullTests/test1121.soar | 1 decisions, 4 rules |  |
| test_env | V1 | arithmetic-smem.zip: john-nlp/manage-world-state/internal-worlds/test_env.soar | 100 decisions, 1 rules |  |
| test_env | V2 | arithmetic-smem.zip: john-nlp/manage-world-state/waypoint-maps/test_env.soar | 100 decisions, 1 rules |  |
| testCommandToFile-output | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/testCommandToFile-output.soar | 100 decisions, 144 rules |  |
| testcopy | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/FullTests/testcopy.soar | 100 decisions, 3 rules |  |
| testGDSBug1011 | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/FullTests/testGDSBug1011.soar | 8 decisions, 13 rules | First compared November 3; differed until model fixes of that day (doc/DIFFERENCES.md, November 3 afternoon); matches since. |
| testGDSBug1144 | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/FullTests/testGDSBug1144.soar | 7 decisions, 22 rules | First compared November 3; differed until model fixes of that day (doc/DIFFERENCES.md, November 3 afternoon); matches since. |
| testinterrupt | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/FullTests/testinterrupt.soar | 0 decisions, 1 rules |  |
| testIsupported_Smem_Chunk_Crash | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/testIsupported_Smem_Chunk_Crash.soar | 101 decisions, 6 rules |  |
| testLearn | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/FullTests/testLearn.soar | 3 decisions, 7 rules |  |
| testMatchTimeInterrupt | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/FullTests/testMatchTimeInterrupt.soar | 1 decisions, 3 rules; load error: **WARNING: Replacing function named failed with halt since this is a unit test but running in a non-unit testing environment. | Differs: an :interrupt rule stops Soar 9.6.5 when it matches (p_node_left_addition); soar-lean does not model stopping a run other than by halt. NOT MODELED (doc/DIFFERENCES.md, Nov 3). |
| testmulti | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/testmulti.soar | 100 decisions, 3 rules |  |
| testNegated_Operator_Crash | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/testNegated_Operator_Crash.soar | 100 decisions, 2 rules |  |
| testNegatedConjunctiveChunkLoopBug510 | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/FullTests/testNegatedConjunctiveChunkLoopBug510.soar | 3 decisions, 6 rules | Soar 9.6.5 learns 50 rules bottom-up, each adding one more copy of the same negated condition (the loop the test is named for); soar-lean adds a negated condition once and learns 1 (not reproduced) |
| testOp_Augmentation_Crash | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/testOp_Augmentation_Crash.soar | 1 decisions, 4 rules |  |
| testOSupportCopyDestroy | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/FullTests/testOSupportCopyDestroy.soar | 101 decisions, 3 rules |  |
| testoutputleak | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/testoutputleak.soar | 100 decisions, 1 rules |  |
| testPreferenceDeallocation | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/testPreferenceDeallocation.soar | 6 decisions, 13 rules |  |
| testRHSRand | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/testRHSRand.soar | 300+ decisions, 12 rules; load error: **********WARNING: Replacing function named failed with halt since this is a unit test but running in a non-unit testing environment. | First compared November 3; differed until model fixes of that day (doc/DIFFERENCES.md, November 3 afternoon); matches since. |
| testsml | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/FullTests/testsml.soar | 100 decisions, 5 rules |  |
| teststatuscomplete | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/FullTests/teststatuscomplete.soar | 100 decisions, 1 rules |  |
| teststopsoar | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/FullTests/teststopsoar.soar | 2 decisions, 1 rules | (cmd stop-soar): Soar stops after decision 1; soar-lean does not model stop-soar (NOT MODELED) |
| testSVS | V1 | epmem-tutorial.zip: CozmoSoarDemo/soar/SoarUnitTests/FullTests/testSVS.soar | 155 decisions, 42 rules; load error: Spatial Visual System enabled. ***************************WARNING: Replacing function named failed with halt since this is a unit test but running in a non-unit testing environment. | uses SVS (spatial visual system), which soar-lean does not model |
| TicTacToe | V1 | knights-tour.zip: TicTacToe/TicTacToe.soar | 9 decisions, 12 rules |  |
| TicTacToe | V2 | 2026-agents-verified.zip: 2026-agents-verified/TicTacToe/TicTacToe.soar<br>Water-jugs.zip: TicTacToe/TicTacToe.soar | 100 decisions, 6 rules |  |
| tower-of-hanoi-search | V1 | 2026-agents-verified.zip: 2026-agents-verified/Towers-of-hanoi/ToH-search/tower-of-hanoi-search.soar<br>Water-jugs.zip: Towers-of-hanoi/ToH-search/tower-of-hanoi-search.soar | 300+ decisions, 121 rules | First compared November 3; differed until model fixes of that day (doc/DIFFERENCES.md, November 3 afternoon); matches since. |
| towers-of-hanoi | V1 | epmem-tutorial.zip: all-test/towers-of-hanoi/towers-of-hanoi.soar | 300+ decisions, 18 rules |  |
| towers-of-hanoi | V2 | 2026-agents-verified.zip: 2026-agents-verified/Towers-of-hanoi/ToH/towers-of-hanoi.soar<br>Water-jugs.zip: Towers-of-hanoi/ToH/towers-of-hanoi.soar | 300+ decisions, 18 rules |  |
| towers-of-hanoi-fast | V1 | epmem-tutorial.zip: all-test/towers-of-hanoi/towers-of-hanoi-fast.soar | 300+ decisions, 17 rules |  |
| towers-of-hanoi-fast | V2 | 2026-agents-verified.zip: 2026-agents-verified/Towers-of-hanoi/ToH-fast/towers-of-hanoi-fast.soar<br>Water-jugs.zip: Towers-of-hanoi/ToH-fast/towers-of-hanoi-fast.soar | 300+ decisions, 17 rules |  |
| towers-of-hanoi-faster | V1 | epmem-tutorial.zip: all-test/towers-of-hanoi/towers-of-hanoi-faster.soar | 300+ decisions, 12 rules |  |
| towers-of-hanoi-faster | V2 | 2026-agents-verified.zip: 2026-agents-verified/Towers-of-hanoi/ToH-faster/towers-of-hanoi-faster.soar<br>Water-jugs.zip: Towers-of-hanoi/ToH-faster/towers-of-hanoi-faster.soar | 300+ decisions, 12 rules |  |
| towers-of-hanoi-no-ops | V1 | epmem-tutorial.zip: all-test/towers-of-hanoi/towers-of-hanoi-no-ops.soar<br>2026-agents-verified.zip: 2026-agents-verified/Towers-of-hanoi/ToH-no-operators/towers-of-hanoi-no-ops.soar<br>Water-jugs.zip: Towers-of-hanoi/ToH-no-operators/towers-of-hanoi-no-ops.soar | 1 decisions, 9 rules |  |
| towers-of-hanoi-recur | V1 | epmem-tutorial.zip: all-test/towers-of-hanoi/towers-of-hanoi-recur.soar<br>2026-agents-verified.zip: 2026-agents-verified/Towers-of-hanoi/ToH-recur/towers-of-hanoi-recur.soar<br>Water-jugs.zip: Towers-of-hanoi/ToH-recur/towers-of-hanoi-recur.soar | 190 decisions, 18 rules |  |
| towers-of-hanoi-recursive | V1 | epmem-tutorial.zip: all-test/towers-of-hanoi/towers-of-hanoi-recursive.soar | 300+ decisions, 19 rules |  |
| towers-of-hanoi-recursive | V2 | 2026-agents-verified.zip: 2026-agents-verified/Towers-of-hanoi/ToH-recursive/towers-of-hanoi-recursive.soar<br>Water-jugs.zip: Towers-of-hanoi/ToH-recursive/towers-of-hanoi-recursive.soar | 300+ decisions, 19 rules |  |
| UCBot | V1 | epmem-tutorial.zip: all-test/UCBot/UCBot.soar | 300+ decisions, 206 rules |  |
| water-jug | V1 | knights-tour.zip: RL/waterjug/water-jug.soar | 300+ decisions, 20 rules |  |
| water-jug | V2 | epmem-tutorial.zip: all-test/water-jug/water-jug.soar | 300+ decisions, 15 rules |  |
| water-jug | V3 | 2026-agents-verified.zip: 2026-agents-verified/Water-jugs/water-jug/water-jug.soar<br>Water-jugs.zip: Water-jugs/water-jug/water-jug.soar | 300+ decisions, 15 rules |  |
| water-jug-hierarchy | V1 | knights-tour.zip: RL/waterjug/water-jug-hierarchy.soar | 300+ decisions, 25 rules |  |
| water-jug-hierarchy | V2 | epmem-tutorial.zip: all-test/water-jug/water-jug-hierarchy.soar | 300+ decisions, 22 rules |  |
| water-jug-hierarchy | V3 | 2026-agents-verified.zip: 2026-agents-verified/Water-jugs/water-jug-hierarchy/water-jug-hierarchy.soar<br>Water-jugs.zip: Water-jugs/water-jug-hierarchy/water-jug-hierarchy.soar | 300+ decisions, 22 rules |  |
| water-jug-hierarchy | V4 | arithmetic.zip: water-jug-hierarchy/water-jug-hierarchy.soar | 300+ decisions, 22 rules |  |
| water-jug-look-ahead | V1 | knights-tour.zip: RL/waterjug/water-jug-look-ahead.soar | crash | crashes Soar 9.6.5: learned rule with one computed numeric preference (bugs/chunk-computed-numeric-pref.soar) |
| water-jug-look-ahead | V2 | epmem-tutorial.zip: all-test/water-jug/water-jug-look-ahead.soar | 300+ decisions, 90 rules |  |
| water-jug-look-ahead | V3 | 2026-agents-verified.zip: 2026-agents-verified/Water-jugs/water-jug-look-ahead/water-jug-look-ahead.soar<br>Water-jugs.zip: Water-jugs/water-jug-look-ahead/water-jug-look-ahead.soar | 300+ decisions, 96 rules |  |
| water-jug-look-ahead | V4 | arithmetic.zip: water-jug-look-ahead/water-jug-look-ahead.soar | 300+ decisions, 96 rules | missing: selection.soar; defaults filled: selection.soar |
| water-jug-look-ahead-failure-states | V1 | 2026-agents-verified.zip: 2026-agents-verified/Water-jugs/water-jug-look-ahead-failure-states/water-jug-look-ahead-failure-states.soar<br>Water-jugs.zip: Water-jugs/water-jug-look-ahead-failure-states/water-jug-look-ahead-failure-states.soar | 300+ decisions, 98 rules |  |
| water-jug-look-ahead-RL | V1 | 2026-agents-verified.zip: 2026-agents-verified/Water-jugs/water-jug-look-ahead-RL/water-jug-look-ahead-RL.soar<br>Water-jugs.zip: Water-jugs/water-jug-look-ahead-RL/water-jug-look-ahead-RL.soar | 300+ decisions, 98 rules |  |
| water-jug-RL | V1 | 2026-agents-verified.zip: 2026-agents-verified/Water-jugs/water-jug-RL/water-jug-RL.soar<br>Water-jugs.zip: Water-jugs/water-jug-RL/water-jug-RL.soar | 300+ decisions, 66 rules |  |
| water-jug-tie | V1 | knights-tour.zip: RL/waterjug/water-jug-tie.soar<br>epmem-tutorial.zip: all-test/water-jug/water-jug-tie.soar | 300+ decisions, 30 rules |  |
| water-jug-tie | V2 | 2026-agents-verified.zip: 2026-agents-verified/Water-jugs/water-jug-tie/water-jug-tie.soar<br>Water-jugs.zip: Water-jugs/water-jug-tie/water-jug-tie.soar | 100 decisions, 6 rules; load error: Error changing to C:/Users/laird/OneDrive/Soar Agents 9.6.5/2026-agents-in-progress/WATER-JUGS/water-jug-tie/ | missing: {C:\Users\laird\OneDrive\Soar Agents 9.6.5\2026-agents-in-progress\WATER-JUGS\water-jug-tie\water-jug-tie.soar} |
| water-jug-tie | V3 | arithmetic.zip: water-jug-tie/water-jug-tie.soar | 300+ decisions, 30 rules |  |
| water-jug-tie-operator-RL | V1 | knights-tour.zip: RL/waterjug/water-jug-tie-operator-RL.soar | crash | crashes Soar 9.6.5: learned rule with one computed numeric preference (bugs/chunk-computed-numeric-pref.soar) |
| wizards | V1 | epmem-tutorial.zip: all-test/Wizards/wizards.soar | 18 decisions, 29 rules |  |
| wizards | V2 | 2026-agents-verified.zip: 2026-agents-verified/Wizards/wizards/wizards.soar<br>Water-jugs.zip: Wizards/wizards/wizards.soar | 18 decisions, 29 rules |  |
| wizards3 | V1 | 2026-agents-verified.zip: 2026-agents-verified/Wizards/wizards3/wizards3.soar<br>Water-jugs.zip: Wizards/wizards3/wizards3.soar | 100 decisions, 26 rules | missing: {C:\Users\laird\OneDrive\Soar Agents 9.6.5\2026-agents-in-progress\Wizards\wizards3\wizards3.soar} |
