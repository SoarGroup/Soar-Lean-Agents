# Agent library

Every Soar agent John Laird has given for testing, kept as distinct versions for regression
tests of soar-lean against Soar 9.6.5. `tools/agentlib.py` builds and maintains it.

## Layout

- `lib/<name>/V<k>/` — one version of an agent, self-contained: every file Soar loads for it
  (with the folders it uses, as in the zip it came in), its VisualSoar project files, and any
  default-library files it needed that its zip did not include.
- `catalog.json` — for each agent name, its versions:
  - `entry`: the load file inside `V<k>/`;
  - `hash`: SHA-256 of the normalized text of every file Soar loads for it (two copies are the
    same version exactly when these hashes agree);
  - `received`: every place a copy came from (zip, date, path inside the zip), in order;
  - `missing`: files it sources that were not in its zip and could not be filled;
  - `filled_from_default`: Soar default-library files (selection.soar, simple.soar, ...) its
    zip lacked, taken from the newest default folder (2026-agents-verified/default);
  - `library`: true for Soar's default libraries (sourced by agents, not run alone);
  - from running it in Soar 9.6.5 (`agentlib.py measure`; first indifferent choice, srand 0,
    at most 300 decisions): `load_errors`, `productions`, `decisions`, `halts`, or `timeout`
    / `crash`;
  - for a corrected version: `derived_from` (the version it corrects), `fix` (what was wrong),
    `fix_script` (the script in `fixes/` that makes it from that version).
- `fixes/` — the scripts that make corrected versions. A corrected version never replaces the
  received one; it is a new version of the same name.
- `runs/` — one `NAME-V<k>.soar` per version that runs on its own, with `.n` (the decisions it
  took in Soar), for `tools/diff.py`.

## Naming

An agent is a load file that no other file sources. Its name is the file name without
`.soar`; versions are numbered in the order received (zips in the order given, files within a
zip in path order).

## Commands

    python3 -I tools/agentlib.py ingest DIR LABEL DATE [DEFAULT_DIR]   # add an unpacked zip
    python3 -I tools/agentlib.py derive NAME VER FIX_SCRIPT NOTE      # add a corrected version
    python3 -I tools/agentlib.py measure                              # run new versions in Soar
    python3 -I tools/agentlib.py runs                                 # regenerate runs/
    python3 -I tools/agentlib.py note NAME VER TEXT                   # record a diagnosis
    python3 -I tools/agentlib.py report                               # regenerate CATALOG.md

## Comparing with soar-lean

    GROUP=L tools/run_all.sh out.txt                     # all of runs/, one process
    SHARD=0/4 python3 tools/diff.py tests/agentlib/runs --rl --explore --epmem --smem --chunk

With `--explore`, Soar chooses with epsilon-greedy exploration (srand 42) and soar-lean replays its choices,
so agents with random choices compare. A version is compared for its measured decisions, at most 100
(`CMP_CAP`; soar-lean's run time grows faster than linearly in long runs, about 6 s for 50
decisions and 225 s for 200 on BW-Hierarchical). A version without a `.n` (it crashed or timed out in Soar) is skipped, and one whose files
give a load error in Soar is reported as SOURCE-ERROR.

## Versions with notes

`CATALOG.md` (from `agentlib.py report`) lists every version, where each copy came from, how it
ran in Soar, and a note where the version was diagnosed: corrected versions, agents that wait for
input or interrupt by design, unfinished code, and versions that crash Soar 9.6.5 (one cause is
in bugs/chunk-computed-numeric-pref.soar).
