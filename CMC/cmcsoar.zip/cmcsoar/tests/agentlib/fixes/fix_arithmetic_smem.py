"""Make the arithmetic-smem agent work with Soar 9.6 semantic memory, where every retrieval
makes new short-term identifiers, so links between digits (^next, ^previous, ^plus-ten) and
the fields of retrieved facts lead to identifiers with no augmentations. Digits are found by
value among the canonical digits in ^digits instead. Usage: fix_arith.py ARITHMETIC_DIR"""
import sys, os, re
D = sys.argv[1]
if os.path.isdir(os.path.join(D, "arithmetic")): D = os.path.join(D, "arithmetic")
def edit(rel, pairs):
    p = os.path.join(D, rel); t = open(p, encoding='latin-1').read()
    for a, b in pairs:
        if a not in t: raise SystemExit(f'{rel}: pattern not found: {a[:60]!r}')
        t = t.replace(a, b)
    open(p, 'w', encoding='latin-1').write(t)
# 1. the query for digit zero (^depth is not allowed with ^query in 9.6.5: bad command)
p1 = os.path.join(D, 'retrieve-digits.soar'); t1 = open(p1, encoding='latin-1').read()
t1 = t1.replace('(<q> ^problem 0)}', '(<q> ^digit 0)}').replace('(<cmd> ^depth 3\n          ^query <q>)', '(<cmd> ^query <q>)')
open(p1, 'w', encoding='latin-1').write(t1)
# 2. values of each digit's neighbours
open(os.path.join(D, 'elaborations', 'digit-values.soar'), 'w').write('''## Soar 9.6: a retrieved digit's ^next, ^previous and ^plus-ten are new identifiers without
## augmentations, so rules find the neighbouring digits by value among ^digits.
sp {elaborate*digit*values*single-digit
   (state <s> ^superstate nil
              ^digits.digit <d>)
   (<d> ^digit <v>
        ^single-digit true)
-->
   (<d> ^next-value (mod (+ <v> 1) 10)
        ^previous-value (mod (+ <v> 9) 10)
        ^plus-ten-value (+ <v> 10))}

sp {elaborate*digit*values*teen
   (state <s> ^superstate nil
              ^digits.digit <d>)
   (<d> ^digit { <v> > 9 })
-->
   (<d> ^previous-value (- <v> 1))}
''')
edit('elaborations/elaborations_source.soar', [('source _all.soar\n', 'source _all.soar\nsource digit-values.soar\n')])
# 3. counting
edit('process-column/compute-result/add-via-counting/count.soar', [
 ('''              ^sum <cu>)
   (<cd> ^next <p>)
   (<cu> ^next-carry false
         ^next <n>)''', '''              ^sum <cu>
              ^top-state.digits <ds>)
   (<cd> ^next-value <pv>)
   (<cu> ^next-carry false
         ^next-value <nv>)
   (<ds> ^digit <p> ^digit <n>)
   (<p> ^digit <pv>)
   (<n> ^digit <nv>)'''),
 ('''              ^carry false)
   (<cd> ^next <p>)
   (<cu> ^next-carry true
         ^next <n>)''', '''              ^carry false
              ^top-state.digits <ds>)
   (<cd> ^next-value <pv>)
   (<cu> ^next-carry true
         ^next-value <nv>)
   (<ds> ^digit <p> ^digit <n>)
   (<p> ^digit <pv>)
   (<n> ^digit <nv>)''')])
t = 'process-column/compute-result/subtract-via-counting/count.soar'
edit(t, [
 ('''              ^counter <counter>)
   (<counter> ^next <counter-next>)
   (<base> -^previous-borrow true
            ^previous <base-previous>)''', '''              ^counter <counter>
              ^top-state.digits <ds>)
   (<counter> ^next-value <cnv>)
   (<base> -^previous-borrow true
            ^previous-value <bpv>)
   (<ds> ^digit <counter-next> ^digit <base-previous>)
   (<counter-next> ^digit <cnv>)
   (<base-previous> ^digit <bpv>)'''),
 ('''              ^counter <counter>)
   (<counter> ^next <counter-next>)
   (<base> ^previous-borrow true
           ^previous <base-previous>)''', '''              ^counter <counter>
              ^top-state.digits <ds>)
   (<counter> ^next-value <cnv>)
   (<base> ^previous-borrow true
           ^previous-value <bpv>)
   (<ds> ^digit <counter-next> ^digit <base-previous>)
   (<counter-next> ^digit <cnv>)
   (<base-previous> ^digit <bpv>)''')])
edit('process-column/compute-result/add-ten.soar', [('''   (<ss> ^digit1 <d>)
   (<d> ^plus-ten <d10>)''', '''   (<ss> ^digit1 <d>)
   (<s> ^top-state.digits.digit <d10>)
   (<d> ^plus-ten-value <v10>)
   (<d10> ^digit <v10>)''')])
# 4. every stored fact also holds the values of its four fields
def add_values(rel):
    p = os.path.join(D, rel); t = open(p, encoding='latin-1').read()
    out = []
    for rule in re.split(r'(?=^sp \{)', t, flags=re.M):
        if '-->' not in rule or '^store' not in rule: out.append(rule); continue
        lhs, rhs = rule.split('-->', 1)
        vars_ = set()
        def blk(m):
            body = m.group(2)
            fields = re.findall(r'\^(sum|carry-borrow|digit1|digit2)\s+<([\w-]+)>', body)
            for f, v in fields: vars_.add(v)
            vals = ' '.join('^%s-value <%s-v>' % ('carry' if f == 'carry-borrow' else f, v) for f, v in fields)
            return '(%s%s\n         %s)' % (m.group(1), body, vals)
        rhs = re.sub(r'\((<af2?>)((?:\s+\^[\w-]+\s+<[\w-]+>)+)\s*\)', blk, rhs)
        conds = ''.join('\n   (<%s> ^digit <%s-v>)' % (v, v) for v in sorted(vars_))
        lhs = lhs.rstrip()
        lhs = lhs + conds + '\n'
        out.append(lhs + '-->' + rhs)
    open(p, 'w', encoding='latin-1').write(''.join(out))
add_values('process-column/compute-result/add-via-counting/store.soar')
add_values('process-column/compute-result/subtract-via-counting/store.soar')
# 5. a retrieved fact's result and carry are found by value
edit('process-column/compute-result.soar', [
 ('''   (<af> ^sum <sum>
         ^carry-borrow <cb>)
   (<cmd> ^query <smem-q>)''', '''   (<af> ^sum-value <sv>
         ^carry-value <cv>)
   (<cmd> ^query <smem-q>)
   (<s> ^top-state.digits <ds>)
   (<ds> ^digit <sum> ^digit <cb>)
   (<sum> ^digit <sv>)
   (<cb> ^digit <cv>)'''),
 ('''   (<af> ^digit2 <result>
         ^carry-borrow <cb>)
   (<cmd> ^query <smem-q>)''', '''   (<af> ^digit2-value <rv>
         ^carry-value <cv>)
   (<cmd> ^query <smem-q>)
   (<s> ^top-state.digits <ds>)
   (<ds> ^digit <result> ^digit <cb>)
   (<result> ^digit <rv>)
   (<cb> ^digit <cv>)''')])
# 6. print digits, not identifiers, when a problem is made
p = os.path.join(D, 'elaborations/monitor.soar'); t = open(p, encoding='latin-1').read()
t = re.sub(r'\^digit([12]) <n(\d)>', r'^digit\1.digit <n\2>', t)
open(p, 'w', encoding='latin-1').write(t)
print('fixed', D)
# 7. the digit one is the top state's ^one, not zero's ^next (a new identifier in 9.6)
for rel in ['process-column/compute-result/add-via-counting/detect-completion.soar',
            'process-column/compute-result/subtract-via-counting/detect-completion.soar']:
    edit(rel, [('^top-state.zero.next <one>', '^top-state.one <one>')])
print('fixed detect-completion')
# 8. with chunk always, rules learned in retrieve-digits rebuild retrieved digits from conditions
#    on other digits and fire without end; learn everywhere except that substate
p = os.path.join(D, '_firstload.soar'); t = open(p, encoding='latin-1').read()
if re.search(r'^chunk always', t, re.M):
    t = re.sub(r'^chunk always', 'chunk except', t, flags=re.M)
    open(p, 'w', encoding='latin-1').write(t)
    with open(os.path.join(D, 'retrieve-digits', 'elaborations.soar'), 'a', encoding='latin-1') as f:
        f.write('''
## Results of this substate are retrievals from semantic memory: do not learn rules from them
sp {retrieve-digits*elaborate*dont-learn
   (state <s> ^name retrieve-digits)
-->
   (dont-learn <s>)}
''')
    print('chunk except in retrieve-digits')
# 9. chunking does not trace semantic-memory retrievals, so the rules that use a retrieved fact
#    test that it is the fact for this column's digits (else learned rules are overgeneral)
edit('process-column/compute-result.soar', [
 ('''   (<af> ^sum-value <sv>
         ^carry-value <cv>)''', '''   (<af> ^sum-value <sv>
         ^carry-value <cv>
         ^digit1-value <v1>
         ^digit2-value <v2>)
   (<s> ^digit1 <a1> ^digit2 <a2>)
   (<a1> ^digit <v1>)
   (<a2> ^digit <v2>)'''),
 ('''   (<af> ^digit2-value <rv>
         ^carry-value <cv>)''', '''   (<af> ^digit2-value <rv>
         ^carry-value <cv>
         ^digit1-value <v2>
         ^sum-value <v1>)
   (<s> ^digit1 <a1> ^digit2 <a2>)
   (<a1> ^digit <v1>)
   (<a2> ^digit <v2>)''')])
print('cue tests')
