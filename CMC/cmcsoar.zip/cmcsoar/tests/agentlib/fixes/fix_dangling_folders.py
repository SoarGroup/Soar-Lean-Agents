"""VisualSoar projects whose *_source.soar files enter a folder that is not there
(`pushd X` / `source X_source.soar` / `popd`, typically an empty impasse folder nested in
itself, or a `source F` of a file that is not there). Soar 9.6.5 stops all loading at the
failed `pushd`/`source`, so every rule after it is lost. This removes those lines when the
folder or file is missing. Usage: fix_dangling_folders.py AGENT_DIR"""
import sys, os, re

root = sys.argv[1]
fixed = 0
for d, _, fs in os.walk(root):
    for f in fs:
        if not f.endswith('_source.soar'): continue
        p = os.path.join(d, f)
        lines = open(p, encoding='latin-1').read().split('\n')
        out, i, cwd = [], 0, [d]
        while i < len(lines):
            if re.match(r'\s*popd\b', lines[i]) and len(cwd) > 1:
                cwd.pop(); out.append(lines[i]); i += 1; continue
            m = re.match(r'\s*pushd\s+\{?([^}\s]+)\}?\s*$', lines[i])
            if m and os.path.isdir(os.path.join(cwd[-1], m.group(1))):
                cwd.append(os.path.join(cwd[-1], m.group(1))); out.append(lines[i]); i += 1; continue
            if m:
                # skip to the matching popd
                depth, j = 0, i
                while j < len(lines):
                    if re.match(r'\s*pushd\b', lines[j]): depth += 1
                    if re.match(r'\s*popd\b', lines[j]):
                        depth -= 1
                        if depth == 0: break
                    j += 1
                print('removed', os.path.relpath(p, root), lines[i:j + 1])
                i = j + 1; fixed += 1; continue
            m = re.match(r'\s*source\s+\{?([^}\s]+)\}?\s*$', lines[i])
            if m and not os.path.exists(os.path.join(cwd[-1], m.group(1))):
                print('removed', os.path.relpath(p, root), lines[i])
                i += 1; fixed += 1; continue
            out.append(lines[i]); i += 1
        if out != lines:
            open(p, 'w', encoding='latin-1').write('\n'.join(out))
print(fixed, 'dangling entries removed')
if not fixed: sys.exit(1)
