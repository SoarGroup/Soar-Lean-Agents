"""pyramid 10: rule give-up-on-term1 in execute-abstract-solution.soar has no closing brace, so
Soar 9.6.5 stops loading there (64 of the agent's rules load). Adds the brace, as in
pyramid 9. Usage: fix_pyramid10_brace.py AGENT_DIR"""
import sys, os
for d, _, fs in os.walk(sys.argv[1]):
    if 'execute-abstract-solution.soar' in fs:
        p = os.path.join(d, 'execute-abstract-solution.soar')
        t = open(p, encoding='latin-1').read()
        a = '   (<ss> ^<term1> impossible)\n\n\nsp {propose*calculate'
        if a in t:
            open(p, 'w', encoding='latin-1').write(t.replace(a, '   (<ss> ^<term1> impossible)\n}\n\nsp {propose*calculate'))
            print('fixed', p); sys.exit(0)
sys.exit('pattern not found')
