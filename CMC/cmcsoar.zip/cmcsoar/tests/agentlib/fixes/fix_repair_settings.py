"""`chunk lhs-repair` and `chunk rhs-repair` are not settings in Soar 9.6.5 ("Invalid chunking
command"), and Soar stops loading at them, so no rule loads. Comments them out (repair is always
on in 9.6.5). Usage: fix_repair_settings.py AGENT_DIR"""
import sys, os, re
n = 0
for d, _, fs in os.walk(sys.argv[1]):
    for f in fs:
        if not f.endswith('.soar'): continue
        p = os.path.join(d, f); t = open(p, encoding='latin-1').read()
        u = re.sub(r'^(\s*chunk\s+[lr]hs-repair\b.*)$', r'# (not in Soar 9.6.5) \1', t, flags=re.M)
        if u != t:
            open(p, 'w', encoding='latin-1').write(u); n += 1; print('fixed', p)
if not n: sys.exit('nothing to fix')
