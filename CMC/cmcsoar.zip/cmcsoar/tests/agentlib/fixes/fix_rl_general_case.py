"""mac (RL-general-state) sources ../RL-general.soar, but the file is RL-General.soar: the load
fails on a case-sensitive file system. Usage: fix_rl_general_case.py AGENT_DIR"""
import sys, os
p = os.path.join(sys.argv[1], 'mac', '_firstload.soar')
t = open(p, encoding='latin-1').read()
assert 'source ../RL-general.soar' in t
open(p, 'w', encoding='latin-1').write(t.replace('source ../RL-general.soar', 'source ../RL-General.soar'))
print('fixed', p)
