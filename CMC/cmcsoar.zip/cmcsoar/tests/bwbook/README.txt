Blocks-world agents from the Soar book collection (blocks-world-book-2019-world, given by John
Laird on 2 November 2026), in world/, with the default libraries they source from ../../default,
../../default-2019 and ../../default-2019-x (copied from the Soar default folders on hand; the
default folder had no selection-epmem.soar, so it was copied from default-2019).
Run:  python3 tools/diff.py tests/bwbook/world --rl --explore --epmem --chunk
Agents that do not halt run for the decisions in their .n file (200).
Known difference: blocks-world-operator-subgoaling-RL (RL value of a template rule): Soar 9.6.5
builds two template rules whose variables collide (kernel defect 28; the template's variable
table is keyed by identifier pointers and a freed identifier's address is reused), so they never
fire; the model, which does not track addresses, builds them correctly and updates one.
Two agents (opsub-lookahead, opsub-lookahead-hierarchical) contain a malformed production in
elaborations/monitor.soar; Soar stops loading there, and so does soar-lean.
