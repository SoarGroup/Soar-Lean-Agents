40
SOAR_ID 0
ENUMERATION 1 1 state
ENUMERATION 2 1 nil
ENUMERATION 3 1 blocks-world
SOAR_ID 4
ENUMERATION 5 1 move-block
SOAR_ID 6
SOAR_ID 7
SOAR_ID 8
SOAR_ID 9
ENUMERATION 10 3 A B C
ENUMERATION 11 4 A B C table
ENUMERATION 12 1 table
SOAR_ID 13
SOAR_ID 14
SOAR_ID 15
ENUMERATION 16 1 initialize-task
ENUMERATION 17 4 A B C table
ENUMERATION 18 2 block table
SOAR_ID 19
ENUMERATION 20 1 state
ENUMERATION 21 2 blocks-world move-block
ENUMERATION 22 1 no-change
ENUMERATION 23 1 operator
ENUMERATION 24 1 operator-subgoal
ENUMERATION 25 1 none
ENUMERATION 26 1 no-change
ENUMERATION 27 1 t
ENUMERATION 28 2 operator state
SOAR_ID 29
ENUMERATION 30 1 move-blocks
ENUMERATION 31 1 yes
ENUMERATION 32 3 clear inplace-object top-state
ENUMERATION 33 2 desired ontop
ENUMERATION 34 1 object
SOAR_ID 35
SOAR_ID 36
INTEGER_RANGE 37 -2147483648 2147483647
ENUMERATION 38 1 true
ENUMERATION 39 1 true
57
0 achieved 14
0 attribute 28
0 choices 25
0 desired 7
0 impasse 26
0 name 3
0 operator 4
0 operator 15
0 problem-space 29
0 quiescence 27
0 success 7
0 superstate 2
0 superstate 0
0 type 1
0 type 24
4 destination 14
4 moving-block 14
4 name 5
4 preconditions 39
4 preconditions-test-exists 38
6 bottom-block 9
6 top-block 8
7 clear 14
7 ontop 13
8 name 10
9 name 11
9 type 12
13 bottom-block 14
13 top-block 14
14 name 17
14 type 18
15 name 16
19 achieved 14
19 attribute 23
19 desired 7
19 impasse 22
19 name 21
19 operator 4
19 success 7
19 superstate 0
19 top-state 0
19 type 20
19 type 24
19 world 35
29 default-state-copy 31
29 dont-copy 32
29 name 30
29 one-level-attributes 34
29 two-level-attributes 33
35 clear 14
35 inplace-object 14
35 last-moved-block 6
35 move-count 37
35 moving-block 36
35 object 14
35 ontop 6
35 outplace-object 14
