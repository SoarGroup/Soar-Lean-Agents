# Programs exposing differences found by the map review (cluster F1), fixed in the model.
# Each directory is one set; run it with the options given:
#   python3 tools/diff.py tests/mapdiff/rl --rl --explore
#   python3 tools/diff.py tests/mapdiff/smem --smem
#   python3 tools/diff.py tests/mapdiff/epmem --epmem
# smem/smem_cliremove_unknown_attr.soar and smem/smem_cliquery_badlti.soar end with an smem
# command that Soar rejects; tools/diff.py accepts those two errors.
Programs exposing differences found by the line-by-line map review (cluster F2), one per
difference fixed; the first line of each names the Lean definition and the Soar function.
Run each subdirectory with its options:
  python3 tools/diff.py tests/mapdiff/chunk --chunk
  python3 tools/diff.py tests/mapdiff/exe --exe
  python3 tools/diff.py tests/mapdiff/epmem --epmem
Programs found by the line-by-line map review (Lean definition against Soar 9.6.5 function);
each names the definition and the Soar function in its first line.
exe/    python3 tools/diff.py tests/mapdiff/exe --exe        (all match)
