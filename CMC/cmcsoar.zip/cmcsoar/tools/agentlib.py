#!/usr/bin/env python3
"""The library of Soar agents John Laird has given (tests/agentlib).

  agentlib.py ingest SRC_DIR LABEL DATE   add every agent found under SRC_DIR (an unpacked zip)
  agentlib.py runs                        write runs/<name>-V<k>.soar wrappers and .n files
  agentlib.py measure [NAME…]             run each version in Soar 9.6.5; record load errors,
                                          productions, decisions to halt and the options it needs

An agent is an entry file: a .soar file that no other .soar file in the same unpacked zip
sources, outside the folders VisualSoar manages (a folder holding a *_source.soar file, whose
files are reached through it), and outside .svn and __MACOSX. Its content is the text of every
file it loads, in load order (following source, pushd, popd and cd as Soar's command line does),
with line endings normalised. Agents with the same file name and the same content are one
version; the same name with different content gets V1, V2, … in the order received. Each
version is stored self-contained in lib/<name>/V<k>/: the files it loads and its own folder
(VisualSoar project files included), at their paths relative to their common ancestor.
catalog.json records, for each version, its entry path, content hash, and every place it was
received (zip label, date, path inside the zip)."""
import hashlib, json, os, re, shutil, sys

HERE = os.path.dirname(os.path.abspath(__file__))
LIB = os.path.join(HERE, '..', 'tests', 'agentlib')
CAT = os.path.join(LIB, 'catalog.json')
SKIP_DIRS = {'.svn', '__MACOSX', '.git', '.idea'}

def load_cat():
    return json.load(open(CAT)) if os.path.exists(CAT) else {'agents': {}}

def save_cat(c):
    json.dump(c, open(CAT, 'w'), indent=1, sort_keys=True)

def read(p):
    b = open(p, 'rb').read()
    try: t = b.decode('utf-8')
    except UnicodeDecodeError: t = b.decode('latin-1')
    return t.replace('\r\n', '\n').replace('\r', '\n')

def resolve(d, name):
    """A path as Soar would open it, also matching case-insensitively (agents made on Windows
    or macOS)."""
    name = name.strip().strip('"').strip('{}').replace('\\', '/')
    p = os.path.normpath(os.path.join(d, name))
    if os.path.exists(p): return p
    # case-insensitive walk
    parts = os.path.relpath(p, '/').split('/')
    cur = '/'
    for part in parts:
        if part in ('', '.'): continue
        try:
            m = [x for x in os.listdir(cur) if x.lower() == part.lower()]
        except (NotADirectoryError, FileNotFoundError, PermissionError):
            return None
        if not m: return None
        cur = os.path.join(cur, m[0])
    return cur

def trace(entry, limit=400):
    """The files `entry` loads, in order, with any that could not be found."""
    loaded, missing = [], []
    def run(path, depth):
        if depth > 40 or len(loaded) > limit: return
        loaded.append(path)
        d = os.path.dirname(path)
        stack = []
        braces = 0
        for line in read(path).split('\n'):
            s = line.strip()
            if braces == 0 and not s.startswith('#'):
                w = s.split(None, 1)
                if w:
                    cmd, arg = w[0], (w[1] if len(w) > 1 else '')
                    arg = arg.split('#')[0].strip() if not arg.startswith(('"', '{')) else arg
                    if cmd == 'source' and arg:
                        a = arg.split()[-1] if arg.startswith('-') else arg
                        p = resolve(d, a)
                        if p and os.path.isfile(p): run(p, depth + 1)
                        else: missing.append((path, a, os.path.normpath(os.path.join(d, a.strip().strip('"').strip('{}').replace('\\', '/')))))
                    elif cmd == 'pushd' and arg:
                        arg = arg.strip().strip('"').strip('{}')
                        stack.append(d)
                        p = resolve(d, arg)
                        d = p if p else os.path.normpath(os.path.join(d, arg))
                    elif cmd == 'popd' and stack:
                        d = stack.pop()
                    elif cmd == 'cd' and arg:
                        arg = arg.strip().strip('"').strip('{}')
                        p = resolve(d, arg)
                        d = p if p else os.path.normpath(os.path.join(d, arg))
            # brace depth outside |…| strings and comments
            inbar = False
            for i, c in enumerate(line):
                if inbar:
                    if c == '|': inbar = False
                elif c == '|': inbar = True
                elif c == '#' and braces == 0: break
                elif c == '{': braces += 1
                elif c == '}': braces = max(0, braces - 1)
    run(entry, 0)
    return loaded, missing

def soar_files(root):
    out = []
    for dp, dns, fns in os.walk(root):
        dns[:] = [x for x in dns if x not in SKIP_DIRS and not x.startswith('._')]
        for f in fns:
            if f.endswith('.soar') and not f.startswith('._'):
                out.append(os.path.join(dp, f))
    return out

def entries(root):
    files = soar_files(root)
    sourced = set()
    traces = {}
    for f in files:
        ld, ms = trace(f)
        traces[f] = (ld, ms)
        sourced.update(ld[1:])
    managed = set()
    for f in files:
        if f.endswith('_source.soar'): managed.add(os.path.dirname(f))
    res = []
    for f in files:
        if f in sourced: continue
        if os.path.dirname(f) in managed: continue
        txt = read(f)
        if 'sp {' not in txt and 'sp{' not in txt and not re.search(r'^\s*source\s', txt, re.M): continue
        res.append((f, traces[f]))
    return res

def content_hash(loaded):
    h = hashlib.sha256()
    for p in loaded:
        h.update(read(p).encode('utf-8', 'surrogateescape')); h.update(b'\0')
    return h.hexdigest()[:16]

# Soar's default libraries as last received (2026-agents-verified.zip, default/): an agent whose
# zip did not include the default library it sources gets these files, at the place it looks
FALLBACK = None

def fallback_files(expected):
    """For a missing default-library file (simple.soar, selection*.soar, …), the fallback files
    to put at `expected` and around it: (source, destination) pairs."""
    if not FALLBACK: return []
    b = os.path.basename(expected)
    src = os.path.join(FALLBACK, b)
    if not os.path.isfile(src): return []
    pairs = [(src, expected)]
    stem = os.path.splitext(b)[0]
    sub = os.path.join(FALLBACK, stem)
    if os.path.isdir(sub):
        for dp, dns, fns in os.walk(sub):
            dns[:] = [x for x in dns if x not in SKIP_DIRS]
            for f in fns:
                if not f.endswith('~'):
                    q = os.path.join(dp, f)
                    pairs.append((q, os.path.join(os.path.dirname(expected), os.path.relpath(q, FALLBACK))))
    return pairs

def store(entry, loaded, dest, missing=()):
    """Copy the loaded files and the agent's own folder under their common ancestor; default
    library files the agent's zip lacked are filled in from FALLBACK."""
    name = os.path.splitext(os.path.basename(entry))[0]
    own = os.path.join(os.path.dirname(entry), name)
    fills = [pair for m in missing for pair in fallback_files(m[2])]
    paths = set(loaded) | {d for _, d in fills}
    if os.path.isdir(own):
        for dp, dns, fns in os.walk(own):
            dns[:] = [x for x in dns if x not in SKIP_DIRS]
            for f in fns:
                if not f.endswith('~') and not f.startswith('._'):
                    paths.add(os.path.join(dp, f))
    root = os.path.commonpath([os.path.dirname(p) for p in paths])
    filled = {d: s_ for s_, d in fills}
    for p in paths:
        q = os.path.join(dest, os.path.relpath(p, root))
        os.makedirs(os.path.dirname(q), exist_ok=True)
        shutil.copy2(filled.get(p, p), q)
    return os.path.relpath(entry, root), sorted({os.path.relpath(m[2], root) for m in missing if fallback_files(m[2])})

def ingest(src, label, date):
    cat = load_cat()
    added = dup = 0
    for f, (ld, ms) in sorted(entries(src)):
        name = os.path.splitext(os.path.basename(f))[0]
        h = content_hash(ld)
        vers = cat['agents'].setdefault(name, [])
        where = {'zip': label, 'date': date, 'path': os.path.relpath(f, src)}
        hit = next((v for v in vers if v['hash'] == h), None)
        if hit:
            if where not in hit['received']: hit['received'].append(where)
            dup += 1; continue
        k = len(vers) + 1
        dest = os.path.join(LIB, 'lib', name, 'V%d' % k)
        shutil.rmtree(dest, ignore_errors=True)
        rel, filled = store(f, ld, dest, ms)
        vers.append({'version': 'V%d' % k, 'hash': h, 'entry': rel, 'files': len(ld),
                     'missing': [m[1] for m in ms], 'filled_from_default': filled, 'received': [where]})
        added += 1
    save_cat(cat)
    print(f'{label}: {added} new versions, {dup} duplicates; library has '
          f'{sum(len(v) for v in cat["agents"].values())} versions of {len(cat["agents"])} agents')

def derive(name, frm, fixer, note):
    """A corrected version: copy version FRM of NAME, run FIXER (a script given the copy's
    agent folder) on the copy, and record it as a new version derived from FRM."""
    import subprocess
    cat = load_cat()
    vers = cat['agents'][name]
    src = next(v for v in vers if v['version'] == frm)
    k = len(vers) + 1
    dest = os.path.join(LIB, 'lib', name, 'V%d' % k)
    shutil.rmtree(dest, ignore_errors=True)
    shutil.copytree(os.path.join(LIB, 'lib', name, frm), dest)
    entry = os.path.join(dest, src['entry'])
    subprocess.run([sys.executable, '-I', os.path.abspath(fixer), os.path.dirname(entry)], check=True)
    ld, ms = trace(entry)
    vers.append({'version': 'V%d' % k, 'hash': content_hash(ld), 'entry': src['entry'], 'files': len(ld),
                 'missing': [m[1] for m in ms], 'filled_from_default': src.get('filled_from_default', []),
                 'received': [], 'derived_from': frm, 'fix': note,
                 'fix_script': os.path.relpath(os.path.abspath(fixer), LIB)})
    save_cat(cat)
    print(f'{name} V{k}: derived from {frm}')

BIG = 3000
# decisions compared with soar-lean (its time grows faster than linearly on long runs)
CMP_CAP = 100

def runs():
    """runs/NAME-Vk.soar for each version that runs on its own (not a default library), with
    NAME-Vk.n, the decisions it took in Soar, once measured (not when it crashed or timed out)."""
    cat = load_cat()
    for sub in ('runs', 'runs-big'):
        shutil.rmtree(os.path.join(LIB, sub), ignore_errors=True)
        os.makedirs(os.path.join(LIB, sub))
    for name, vers in cat['agents'].items():
        for v in vers:
            n = v.get('decisions')
            if is_library(name, v): continue
            # versions with more than BIG rules (saved RL value tables, mostly) go in runs-big/:
            # soar-lean takes minutes to load them
            R = os.path.join(LIB, 'runs-big' if v.get('productions', 0) > BIG else 'runs')
            tag = f'{name}-{v["version"]}'
            d, e = os.path.split(v['entry'])
            rel = os.path.join('..', 'lib', name, v['version'], d)
            open(os.path.join(R, tag + '.soar'), 'w').write(f'pushd {{{rel}}}\nsource {{{e}}}\npopd\n')
            # diff.py runs a program that has a decision count
            if n: open(os.path.join(R, tag + '.n'), 'w').write(f'{min(n, CMP_CAP)}\n')

LIBRARY_NAMES = re.compile(r'^(selection.*|simple|operator-subgoaling|default|common|ttt-common)$')

def is_library(name, v):
    """Soar's default libraries (selection spaces, simple.soar, …), sourced by agents."""
    paths = [r['path'] for r in v['received']]
    if not paths: return bool(LIBRARY_NAMES.match(name))   # a corrected version
    return bool(LIBRARY_NAMES.match(name)) or all(re.search(r'(^|/)(default|DEFAULTS?)[^/]*/', p) for p in paths)

def measure(names, cap=300, timeout=180):
    """Each version in its own process (an agent can crash Soar or run very slowly)."""
    import subprocess
    cat = load_cat()
    for name, vers in sorted(cat['agents'].items()):
        if names and name not in names: continue
        for v in vers:
            v['library'] = is_library(name, v)
            if v['library']: continue
            if any(k in v for k in ('decisions', 'timeout', 'crash')) and not names: continue
            try:
                r = subprocess.run([sys.executable, '-I', os.path.abspath(__file__), 'measure1', name, v['version'], str(cap)],
                                   capture_output=True, text=True, timeout=timeout)
                res = json.loads(r.stdout.strip().split('\n')[-1]) if r.returncode == 0 and r.stdout.strip() else {'crash': (r.stderr or str(r.returncode))[-300:]}
            except subprocess.TimeoutExpired:
                res = {'timeout': timeout}
            v.update(res)
            print(name, v['version'], res, flush=True)
            save_cat(cat)
    save_cat(cat)

def measure1(name, ver, cap):
    import soar_sml as sml
    cat = load_cat()
    v = next(x for x in cat['agents'][name] if x['version'] == ver)
    k = sml.Kernel.CreateKernelInCurrentThread(True, 0)
    R = os.path.abspath(os.path.join(LIB, 'runs-big' if v.get('productions', 0) > BIG else 'runs'))
    for _ in [0]:
        for v in [v]:
            tag = f'{name}-{v["version"]}'
            a = k.CreateAgent(tag)
            out = []
            a.RegisterForPrintEvent(sml.smlEVENT_PRINT, lambda *x: out.append(x[-1]), None)
            for c in ['decide indifferent-selection --first', 'srand 0']: a.ExecuteCommandLine(c)
            os.chdir(R); a.ExecuteCommandLine('cd ' + R)
            r = a.ExecuteCommandLine('source ' + tag + '.soar')
            os.chdir(R); a.ExecuteCommandLine('cd ' + R)
            err = [l for l in r.split('\n') if ('rror' in l or 'ailed' in l) and 'sourcing' not in l][:3]
            prods = len(re.findall(r'^\S', a.ExecuteCommandLine('print'), re.M))
            a.ExecuteCommandLine('watch 0')
            a.RunSelf(cap)
            st = a.ExecuteCommandLine('stats')
            m = re.search(r'(\d+) decisions', st)
            dc = int(m.group(1)) if m else 0
            print(json.dumps({'load_errors': err, 'productions': prods, 'decisions': min(dc, cap),
                              'halts': dc < cap}))

def report():
    """CATALOG.md: every agent and version, where each copy came from, and how it ran in Soar."""
    cat = load_cat()
    out = ['# Agent library catalog', '',
           'Generated from catalog.json by `python3 -I tools/agentlib.py report`. Soar 9.6.5 run: first',
           'indifferent choice, srand 0, at most 300 decisions ("300+" = still running at the cap).', '']
    nv = sum(len(v) for v in cat['agents'].values())
    out.append(f'{nv} versions of {len(cat["agents"])} agents.')
    out.append('')
    out.append('| Agent | Version | Received (zip: path) | Soar 9.6.5 | Notes |')
    out.append('|---|---|---|---|---|')
    for name in sorted(cat['agents'], key=str.lower):
        for v in cat['agents'][name]:
            rec = '<br>'.join(f"{r['zip']}: {r['path']}" for r in v['received']) or '—'
            if is_library(name, v): run = 'default library'
            elif 'timeout' in v: run = 'timeout'
            elif 'crash' in v: run = 'crash'
            elif 'decisions' in v:
                run = f"{v['decisions']}{'' if v.get('halts') else '+'} decisions, {v.get('productions', '?')} rules"
                if v.get('load_errors'): run += '; load error: ' + v['load_errors'][0].replace('|', '/')
            else: run = 'not run'
            notes = []
            if 'derived_from' in v: notes.append(f"corrected {v['derived_from']}: {v['fix']}")
            if v.get('note'): notes.append(v['note'])
            if v.get('missing'): notes.append('missing: ' + ', '.join(v['missing']))
            if v.get('filled_from_default'): notes.append('defaults filled: ' + ', '.join(os.path.basename(f) for f in v['filled_from_default']))
            out.append(f"| {name} | {v['version']} | {rec} | {run} | {'; '.join(notes).replace('|', '/')} |")
    open(os.path.join(LIB, 'CATALOG.md'), 'w').write('\n'.join(out) + '\n')
    print('wrote CATALOG.md')

if __name__ == '__main__':
    cmd = sys.argv[1]
    if cmd == 'ingest':
        if len(sys.argv) > 5: FALLBACK = sys.argv[5]
        ingest(sys.argv[2], sys.argv[3], sys.argv[4])
    elif cmd == 'runs': runs()
    elif cmd == 'report': report()
    elif cmd == 'note':
        c = load_cat(); v = next(x for x in c['agents'][sys.argv[2]] if x['version'] == sys.argv[3])
        v['note'] = sys.argv[4]; save_cat(c)
    elif cmd == 'derive': derive(sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5])
    elif cmd == 'measure': measure(sys.argv[2:])
    elif cmd == 'measure1': measure1(sys.argv[2], sys.argv[3], int(sys.argv[4]))
