import soar_sml as sml, re, sys, glob, os, subprocess
USE_EXE = True   # every set is run through the soar-lean program
REPLAY = '--replay' in sys.argv
RL = '--rl' in sys.argv
EXPLORE = '--explore' in sys.argv
SMEM = '--smem' in sys.argv
EPMEM = '--epmem' in sys.argv
CHUNK = '--chunk' in sys.argv
ALLWM = '--allwm' in sys.argv   # compare every element, those no state reaches too (print -i (* ^* *))
NOREPLAY = '--noreplay' in sys.argv
if EXPLORE: REPLAY = not NOREPLAY; USE_EXE = True
# the settings Soar is given before the file, passed to the model too
SETTINGS = ["decide indifferent-selection --first", "srand 0"]
if EXPLORE: SETTINGS += ["decide indifferent-selection --epsilon-greedy", "decide indifferent-selection --epsilon 0.3", "srand 42"]
if SMEM or EPMEM or CHUNK: USE_EXE = True
sys.argv = [a for a in sys.argv if a not in ('--exe', '--replay', '--noreplay', '--rl', '--explore', '--smem', '--epmem', '--chunk', '--allwm')]
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import chunkcmp
EXE = os.environ.get('SOAR_LEAN', os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '.lake', 'build', 'bin', 'soar-lean'))
if len(sys.argv) < 2: sys.exit('usage: diff.py DIR [--exe|--replay|--rl --explore|--smem|--epmem]')
os.chdir(sys.argv[1])
k = sml.Kernel.CreateKernelInCurrentThread(True, 0)
# SHARD=i/n runs every n-th program starting at the i-th (0-based), to split a set over processes
_shard = [int(x) for x in os.environ.get('SHARD', '0/1').split('/')]
for _i, f in enumerate(sorted(glob.glob(os.environ.get('ONLY', '') and f"*{os.environ['ONLY']}*.soar" or '*.soar'))):
    if _i % _shard[1] != _shard[0]: continue
    if f.endswith('.pre.soar'): continue
    # a program without a decision count is not compared (in tests/agentlib/runs: one that
    # crashed or timed out in Soar 9.6.5)
    if not os.path.exists(f[:-5] + '.n'): continue
    name=f[:-5]
    # two runs: NAME.pre.soar runs first (NAME.pre.n decisions) in an agent that is then
    # destroyed, leaving its semantic or episodic store in the file at its `--set path`; the
    # main program then runs in a new agent that finds the store there
    PRE = os.path.exists(name+'.pre.soar')
    if PRE:
        npre = open(name+'.pre.n').read().strip()
        dbpaths = set(re.findall(r'(?:--set\s+path|--backup)\s+(\S+)', open(f).read() + open(name+'.pre.soar').read()))
        for p_ in dbpaths:
            if os.path.exists(p_): os.remove(p_)
        pa = k.CreateAgent(name+'-pre')
        if not CHUNK: pa.ExecuteCommandLine("chunk never")
        if RL: pa.ExecuteCommandLine("rl --set learning on")
        for c in SETTINGS: pa.ExecuteCommandLine(c)
        pa.ExecuteCommandLine("source "+name+'.pre.soar')
        pa.ExecuteCommandLine(f"run {npre} -d"); pa.ExecuteCommandLine("run 2 -p")
        k.DestroyAgent(pa)
    a = k.CreateAgent(name)
    out=[]
    a.RegisterForPrintEvent(sml.smlEVENT_PRINT, lambda *args: out.append(args[-1]), None)
    if not CHUNK: a.ExecuteCommandLine("chunk never")
    if RL: a.ExecuteCommandLine("rl --set learning on")
    for c in SETTINGS: a.ExecuteCommandLine(c)
    SETDIR = os.getcwd()
    a.ExecuteCommandLine("cd " + SETDIR)   # a failed popd in an earlier agent must not leak
    r=a.ExecuteCommandLine("source "+f)
    # rules written as :chunk in the sources (in any file sourced), present before the run
    srcChunks = set(x for x in a.ExecuteCommandLine("print --chunks").split() if x.startswith('chunk'))
    os.chdir(SETDIR); a.ExecuteCommandLine("cd " + SETDIR)   # Soar's cd is the process's
    rchk = "\n".join(l for l in r.splitlines() if "Replacing function named" not in l
                     and "Value does not exist on attribute" not in l)
    # errors from smem --remove/--query that the model reproduces (tests/mapdiff/smem); Soar
    # stops sourcing at the error, so these commands must be last in the file
    if "Error: Attribute was not found." in rchk or "Error: LTI was not found." in rchk:
        rchk = "\n".join(l for l in rchk.splitlines() if not any(x in l for x in (
            "Attribute was not found", "LTI was not found", "Error while parsing query",
            "Error parsing clause", "Error while attempting removal", "Error while sourcing file")))
    # a production Soar rejects as malformed is skipped and sourcing goes on; the model skips it too
    if "Production addition failed" in rchk:
        rchk = "\n".join(l for l in rchk.splitlines() if not any(x in l for x in (
            "Production addition failed", "Error while sourcing file", "Expected", "Ignoring production")))
    if "rror" in rchk or "failed" in rchk:
        print("==",name,"SOURCE-ERROR",r.strip()[:200]); k.DestroyAgent(a); continue
    n=open(name+'.n').read().strip()
    import simenv
    drv, inputFile = simenv.load(name, a, int(n))
    a.ExecuteCommandLine("watch 1")
    def attrs(oid):
        txt = a.ExecuteCommandLine(f"print {oid}")
        res = []
        for m in re.finditer(r'\^(\S+) (\|[^|]*\||\S+?)(?=\s|\))', txt):
            at, v = m.group(1), m.group(2)
            if v == '+': continue
            res.append((at.strip('|'), v))
        return res
    def leaf(v):
        if re.match(r'^[A-Z]\d+$', v):
            av = attrs(v)
            nm = [x for (at, x) in av if at == 'name']
            if nm: return nm[0].strip('|')
            cs = sorted(f"{at}={x.strip('|')}" for (at, x) in av if not re.match(r'^[A-Z]\d+$', x))
            return "{" + ",".join(cs) + "}" if cs else "ID"
        return v.strip('|')
    def opsig(oid):
        parts = []
        for at, v in attrs(oid):
            if re.match(r'^[A-Z]\d+$', v):
                v = "{" + ",".join(sorted(f"{a2}={leaf(v2)}" for a2, v2 in attrs(v))) + "}"
            else:
                v = v.strip('|')
            parts.append(f"{at}={v}")
        return ",".join(sorted(parts))
    if REPLAY:
        hints = []
        for step in range(int(n)):
            before = len("".join(out))
            a.ExecuteCommandLine("run 1 -d")
            new = "".join(out)[before:]
            m = re.search(r'(\d+):\s+O: (\S+) \(', new)
            if m: hints.append(f"{m.group(1)} {opsig(m.group(2))}")
            if "halted" in new.lower() or "interrupt" in new.lower(): break
        open(name+'.hints', 'w').write("\n".join(hints))
        # a run that stopped (halt, interrupt, goal stack overflow) is not finished below
        t = "interrupted" if ("halted" in new.lower() or "interrupt" in new.lower()) else ""
    else:
        t=a.ExecuteCommandLine(f"run {n} -d")
    if "interrupted" not in t:
        t+=a.ExecuteCommandLine("run 2 -p")   # finish the last cycle: application and output
    text="".join(out)+t
    # Soar 9.6.5 prints a leftover debug line from the episodic graph match into the trace
    # (`NEW KING (perfect, graph-match): (true, true)`, episodic_memory.cpp)
    text=re.sub(r'NEW KING \([^)]*\): \([^)]*\)', '', text)
    lines=[]
    for L in text.splitlines():
        m=re.match(r'\s*(\d+):\s+O: \S+ \((\S+)\)',L)
        if m: lines.append(f"{m.group(1)}: O: {m.group(2)}")
        elif re.match(r'\s*(\d+):\s+O: [A-Z]\d+(\s*$|\s+Interrupt)',L):
            # an operator without a name
            lines.append(re.sub(r'\s*(\d+):.*', r'\1: O: #', L))
        m=re.match(r'\s*(\d+):\s+==>S: \S+ \((.*)\)',L)
        if m: lines.append(f"{m.group(1)}: ==>S: ({m.group(2)})")
    if drv is not None and drv.rec is not None: drv.rec.close()
    if USE_EXE:
        dbargs = []
        if PRE:
            # the model's stores are its own files, kept in .lean-db
            os.makedirs('.lean-db', exist_ok=True)
            for p_ in dbpaths:
                q_ = os.path.join('.lean-db', p_)
                if os.path.exists(q_): os.remove(q_)
            dbargs = ['--db-dir', '.lean-db']
            rp = subprocess.run([EXE, name+'.pre.soar', '-d', npre, '--settings', ';'.join(SETTINGS)] + dbargs + (['--rl'] if RL else []), capture_output=True, text=True, timeout=int(os.environ.get('LEAN_TIMEOUT', '600')))
            if rp.returncode != 0:
                print("==", name, "LEAN-ERROR (pre)", rp.stderr.strip()[:300]); k.DestroyAgent(a); continue
        try:
          r2 = subprocess.run([EXE, f, '-d', n] + dbargs + [ '--settings', ';'.join(SETTINGS), '--trace-file', name+'.exe.trace', '--wm-file', name+'.exe.wm'] + (['--all-wm'] if ALLWM else []) + (['--hints', name+'.hints'] if REPLAY else []) + (['--rl', '--rl-values', name+'.exe.rl'] if RL else []) + (['--smem-file', name+'.exe.smem'] if SMEM else []) + (['--ep-file', name+'.exe.ep'] if EPMEM else []) + (['--chunks-file', name+'.exe.chunks'] if CHUNK else []) + (['--input', inputFile] if inputFile else []), capture_output=True, text=True, timeout=int(os.environ.get('LEAN_TIMEOUT', '600')))
        except subprocess.TimeoutExpired:
            print("==", name, "LEAN-TIMEOUT"); k.DestroyAgent(a); continue
        if r2.returncode != 0:
            print("==", name, "LEAN-ERROR", r2.stderr.strip()[:300]); k.DestroyAgent(a); continue
        tr, wmf = name+'.exe.trace', name+'.exe.wm'
    # the model logs reaching max-elaborations; Soar prints it as a warning, not in the decision trace
    lean=[re.sub(r'O: #\d+$','O: #',re.sub(r'S\d+ ','',x)) for x in open(tr).read().splitlines() if 'max-elaborations' not in x]
    soar=lines
    # final working memory
    stack=a.ExecuteCommandLine("print --stack")
    sids=re.findall(r'==>S: (S\d+)',stack)
    raw="\n".join(a.ExecuteCommandLine(f"print --internal --depth 100000 {x}") for x in sids)
    if ALLWM: raw += "\n" + a.ExecuteCommandLine("print --internal (* ^* *)")
    # bytes of a Latin-1 source that are not UTF-8 come from Soar as surrogates (\udcXX) and
    # from soar-lean, which reads such a file as Latin-1, as the characters themselves
    raw = re.sub('[\udc80-\udcff]', lambda m: chr(ord(m.group()) - 0xdc00), raw)
    trip=[]; seen=set()
    for L in raw.splitlines():
        m=re.match(r'\((\d+): (\S+) \^(\S+) (.+?)( \+)?\)$',L.strip())
        if m and m.group(1) not in seen:
            # with working-memory activation on, Soar prints the activation as " [x]" (kept
            # with the value, as the model's file does)
            v4 = m.group(4); act = ''
            ma = re.match(r'^(.*) (\[[^\]]*\])$', v4)
            if ma: v4, act = ma.group(1), ' ' + ma.group(2)
            v4 = re.sub(r' \(@\d+\)$', '', v4) + act
            seen.add(m.group(1)); trip.append((m.group(2),m.group(3),v4,bool(m.group(5))))
    skipattr=set()   # the model now creates these structures too
    excl=set(t[2] for t in trip if t[1] in skipattr)
    changed=True
    while changed:
        changed=False
        for t in trip:
            if t[0] in excl and re.match(r'^[A-Z]\d+$',t[2]) and t[2] not in excl:
                excl.add(t[2]); changed=True
    isid=lambda x: bool(re.match(r'^[A-Z]\d+$',x))
    def idv(v):
        m = re.match(r'^[A-Z]\d+( \[[^\]]*\])?$', v)
        return "ID" + (m.group(1) or '') if m else v
    swm=sorted(("ID","ID" if isid(at) else at,idv(v),acc) for (i,at,v,acc) in trip if at not in skipattr and i not in excl)
    lwm=[]
    for L in open(wmf).read().splitlines():
        if not L.strip(): continue
        parts=L.split(' ')
        acc = parts[-1]=='+'
        if acc: parts=parts[:-1]
        i,at,v=parts[0],parts[1],' '.join(parts[2:])
        lwm.append(("ID","ID" if at.startswith('#ID') else at,("ID" + re.sub(r'^\S+', '', v)) if v.startswith('#ID') else v,acc))
    lwm=sorted(lwm)
    rlnote = ""
    rlok = True
    if RL:
        sv = {}
        for L in a.ExecuteCommandLine("print --rl").splitlines():
            # Soar prints: name, update count, value
            m = re.match(r'^(\S+)\s+(?:-?[\d.]+\s+-?[\d.]+\s+)?(-?[\d.]+)\s+(-?[\d.]+)\s*$', L.strip())
            if m: sv[m.group(1)] = (float(m.group(2)), float(m.group(3)))
        lv = {}
        for L in open(name+'.exe.rl').read().splitlines():
            if L.strip():
                nm, c, v = L.rsplit(' ', 2); lv[nm] = (float(c), float(v))
        keys = set(sv) | set(lv)
        bad = [(kk, sv.get(kk), lv.get(kk)) for kk in sorted(keys)
               if kk not in sv or kk not in lv or sv[kk][0] != lv[kk][0]
               or abs(sv[kk][1] - lv[kk][1]) > 1e-5 * max(1, abs(sv[kk][1]))]
        updated = sum(1 for kk in sv if sv[kk][0] > 0)
        nonzero = sum(1 for kk in sv if abs(sv[kk][1]) > 0)
        rlok = not bad
        rlnote = (f", RL: {len(keys)} rules, {updated} updated, {nonzero} nonzero values, "
                  + ("counts and values equal" if rlok else f"{len(bad)} differ: {bad[:5]}"))
    smok = True
    def normnum(v):
        try:
            return repr(round(float(v), 9)) if re.match(r'^-?[\d.]+(e-?\d+)?$', v) and '.' in v else v
        except ValueError:
            return v
    if SMEM:
        sm = set(); sact = {}
        for L in a.ExecuteCommandLine("print @").splitlines():
            L = L.strip()
            m = re.match(r'^\(@(\d+)(.*?)\s*\[([+-][\d.]+)\]\)$', L)
            if not m: continue
            lti = m.group(1); sact[lti] = round(float(m.group(3)), 3)
            body = m.group(2)
            for part in re.split(r'\s\^', ' ' + body)[1:]:
                toks = re.findall(r'\|[^|]*\||\S+', part)
                for v in toks[1:]: sm.add((lti, toks[0], normnum(v)))
        lm = set(); lact = {}
        for L in open(name+'.exe.smem').read().splitlines():
            if not L.strip(): continue
            lti, at, v = L.split(' ', 2)
            if at == 'ACT': lact[lti] = round(float(v), 3)
            else: lm.add((lti, at, normnum(v)))
        # Soar lists only LTIs with augmentations
        lact = {kk: vv for kk, vv in lact.items() if kk in sact}
        # LTI numbers from smem --add depend on memory addresses in Soar 9.6.5 (a set of
        # pointers), so the stores are compared up to renaming of LTIs
        def canon(aug, act):
            ltis = sorted(set(x[0] for x in aug) | set(act))
            lab = {l: '' for l in ltis}
            def val(v, lab):
                return lab.get(v[1:], v) if v.startswith('@') else v
            for _ in range(4):
                lab = {l: str(hash((lab[l], tuple(sorted((at, val(v, lab)) for (x, at, v) in aug if x == l)), act.get(l))))
                       for l in ltis}
            return sorted(lab.values())
        smok = canon(sm, sact) == canon(lm, lact)
        rlnote += f", smem: {len(sact)} LTIs, {len(sm)} augmentations" + ("" if smok else " DIFFER")
        if not smok:
            print("  smem only soar:", sorted(sm - lm)[:10], " only lean:", sorted(lm - sm)[:10])
            print("  act soar:", sact, " lean:", lact)
    epok = True
    if EPMEM:
        def epnum(v):
            try:
                return repr(round(float(v), 9)) if re.match(r'^-?[\d.]+(e-?\d+)?$', v) else v
            except ValueError:
                return v
        def canon_ep(edges):
            # edges: list of (parent, attr, value, isnode); a canonical form up to renaming of nodes
            nodes = set(p for (p, a, v, isn) in edges) | set(v for (p, a, v, isn) in edges if isn)
            lab = {n: ('ROOT' if n == 'ROOT' else '') for n in nodes}
            for _ in range(6):
                lab = {n: str(hash((lab[n], tuple(sorted((a, lab[v] if isn else v) for (p, a, v, isn) in edges if p == n)))))
                       for n in nodes}
            return sorted(lab.values())
        mt = re.search(r'Time:\s+(\d+)', a.ExecuteCommandLine("epmem --stats"))
        stime = int(mt.group(1)) if mt else 1
        sep = {}
        for t in range(1, stime):
            edges = []
            for L in a.ExecuteCommandLine(f"epmem --print {t}").splitlines():
                L = L.strip()
                m = re.match(r'^\((\S+)(.*)\)$', L)
                if not m: continue
                pid = m.group(1); pid = 'ROOT' if pid == '<id0>' else pid
                for part in re.split(r'\s\^', ' ' + m.group(2))[1:]:
                    toks = re.findall(r'\|[^|]*\||\S+', part)
                    for v in toks[1:]:
                        isn = bool(re.match(r'^(<id\d+>|@\d+)$', v))
                        vv = ('ROOT' if v == '<id0>' else v) if isn else epnum(v.strip('|'))
                        edges.append((pid, toks[0].strip('|'), vv, isn))
            sep[t] = edges
        lep = {}
        # name nodes as Soar's epmem --print does: an identifier value is @lti when the edge's
        # interval carries an LTI, else the node; a node is headed @lti if any edge to it does
        eplines = [L.split(' ', 3) for L in open(name+'.exe.ep').read().splitlines() if L.strip()]
        ltiname = {}
        for t, p, at, v in eplines:
            if v.startswith('#') and '@' in v:
                n, l = v[1:].split('@')
                ltiname[(int(t), n)] = '@' + l
        for t, p, at, v in eplines:
            t = int(t)
            pid = 'ROOT' if p == '0' else ltiname.get((t, p), '#' + p)
            isn = v.startswith('#')
            if isn:
                if '@' in v:
                    v = '@' + v.split('@')[1]
                v = 'ROOT' if v == '#0' else v
                lep.setdefault(t, []).append((pid, at.strip('|'), v, isn))
            else:
                # Soar prints string values without quotes, so a value with spaces reads as several
                for part in v.strip('|').split():
                    lep.setdefault(t, []).append((pid, at.strip('|'), epnum(part), isn))
        bad = [t for t in range(1, max(stime, max(lep.keys(), default=0) + 1))
               if canon_ep(sep.get(t, [])) != canon_ep(lep.get(t, []))]
        epok = not bad
        rlnote += f", epmem: {stime - 1} episodes" + ("" if epok else f" DIFFER at {bad[:8]}")
        if bad:
            t = bad[0]
            print("  soar ep", t, sorted(sep.get(t, []))[:40]); print("  lean ep", t, sorted(lep.get(t, []))[:40])
    ckok = True
    if CHUNK:
        names = [x for x in a.ExecuteCommandLine("print --chunks").split() if x.startswith('chunk')]
        # rules written as :chunk in the source are loaded, not learned
        loaded = set(re.findall(r'sp\s*\{\s*(\S+)', open(f).read())) | srcChunks
        names = [x for x in names if x not in loaded]
        # with RL on, a learned RL rule's value is compared through the RL table above (Soar prints
        # the rule with its current value, the model with its initial value)
        rlv = (lambda t: re.sub(r'(\^operator\s+\S+\s*=\s*)-?[\d.]+(e[-+]?\d+)?\s*\)', r'\1 0 )', t)) if RL else (lambda t: t)
        sch = [chunkcmp.canon(rlv(a.ExecuteCommandLine("print " + nm))) for nm in names]
        lch = [chunkcmp.canon(rlv(t)) for t in chunkcmp.split_rules(open(name+'.exe.chunks').read())]
        sb, lb = sorted(b for _, b in sch), sorted(b for _, b in lch)
        # the number after the decision counts rules learned in that decision, in an order that
        # depends on Soar's internal firing order within an elaboration cycle: compared without it
        strip = lambda n: re.sub(r'-\d+$', '', n)
        sn, ln = sorted(strip(n) for n, _ in sch), sorted(strip(n) for n, _ in lch)
        ckok = sb == lb and sn == ln
        rlnote += f", chunks: {len(sch)}" + ("" if ckok else f" DIFFER (lean {len(lch)}" + ("" if sn == ln else ", names") + ("" if sb == lb else ", rules") + ")")
        if not ckok:
            open(name+'.soar.chunks', 'w').write("\n\n".join(a.ExecuteCommandLine("print " + nm) for nm in names))
            print("  names soar:", sn); print("  names lean:", ln)
    ok = lean==soar and lwm==swm and rlok and smok and epok and ckok
    print("==",name, "MATCH" if ok else "DIFF", f"({len(soar)} decisions, {len(swm)} WMEs{rlnote})")
    if lean!=soar:
        print("  soar:",soar); print("  lean:",lean)
    if lwm!=swm:
        from collections import Counter
        cs,cl=Counter(swm),Counter(lwm)
        print("  only soar:",list((cs-cl).elements())); print("  only lean:",list((cl-cs).elements()))
    k.DestroyAgent(a)
