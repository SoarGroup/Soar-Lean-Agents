#!/usr/bin/env python3
"""Programs in which two of Soar's batches of working-memory changes reach the Rete before the
same elaboration cycle: a semantic-memory result (added at the end of the output phase) and
input (added in the next input phase). Observers on each make operators that tie; the one
indifferent-selection --first picks shows the order. Usage: gen_batch.py DIR COUNT SEED"""
import random, sys, os
d, count, seed = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
os.makedirs(d, exist_ok=True)
R = random.Random(seed)
for n in range(count):
    nl = R.randint(2, 4)
    lt = ['(<l%d> ^kind x ^val %d ^tag %d)' % (i, R.randint(1, 3), R.randint(1, 2)) for i in range(nl)]
    ns = R.randint(2, 4)
    K = R.randint(2, 4)           # the cycle whose input phase follows the query
    inp = []
    for i in range(ns):
        inp += ['%d + I2 ^sensor #s%d' % (K, i), '%d + #s%d ^val %d' % (K, i, R.randint(1, 3)), '%d + #s%d ^tag %d' % (K, i, R.randint(1, 2))]
    src = ['smem --enable', 'smem --add {\n   ' + '\n   '.join(lt) + '\n}', '',
           'sp {init\n   (state <s> ^superstate nil -^step)\n-->\n   (<s> ^operator <o> + =)\n   (<o> ^name init)\n}',
           'sp {apply*init\n   (state <s> ^operator.name init)\n-->\n   (<s> ^step 0)\n}']
    # wait operators until cycle K-1, then the query
    src.append('sp {propose*wait\n   (state <s> ^step <n> < %d)\n-->\n   (<s> ^operator <o> + =)\n   (<o> ^name wait ^n <n>)\n}' % (K - 1))
    src.append('sp {apply*wait\n   (state <s> ^operator <o>)\n   (<o> ^name << wait ask >> ^n <n>)\n-->\n   (<s> ^step <n> - ^step (+ <n> 1))\n}')
    src.append('sp {propose*ask\n   (state <s> ^step %d)\n-->\n   (<s> ^operator <o> + =)\n   (<o> ^name ask ^n %d)\n}' % (K - 1, K - 1))
    src.append('sp {apply*ask\n   (state <s> ^operator.name ask ^smem.command <c>)\n-->\n   (<c> ^query <q>)\n   (<q> ^kind x)\n}')
    obs = []
    for i in range(R.randint(2, 4)):
        side = R.choice(['smem', 'input'])
        tagc = R.choice(['', ' ^tag %d' % R.randint(1, 2)])
        if side == 'smem':
            lhs = '(<s> ^step %d ^smem.result.retrieved <r>)\n   (<r> ^val <v>%s)' % (K, tagc)
        else:
            lhs = '(<s> ^step %d ^io.input-link.sensor <r>)\n   (<r> ^val <v>%s)' % (K, tagc)
        obs.append('sp {obs%d\n   %s\n-->\n   (<s> ^operator <p> + =)\n   (<p> ^name pick%d ^v <v>)\n}' % (i, lhs, i))
    # a rule with conditions on both batches
    if R.random() < 0.7:
        obs.append('sp {obsboth\n   (<s> ^step %d ^smem.result.retrieved <a> ^io.input-link.sensor <b>)\n   (<a> ^val <v>)\n   (<b> ^val <v>)\n-->\n   (<s> ^operator <p> + =)\n   (<p> ^name pickboth ^v <v>)\n}' % K)
    R.shuffle(obs)
    src += obs
    src.append('sp {apply*pick\n   (state <s> ^operator <p>)\n   (<p> ^name << pick0 pick1 pick2 pick3 pickboth >> ^v <v>)\n-->\n   (<s> ^picked <v>)\n}')
    src.append('sp {done\n   (state <s> ^picked <v>)\n-->\n   (halt)\n}')
    open('%s/b%03d.soar' % (d, n), 'w').write('\n\n'.join(src) + '\n')
    open('%s/b%03d.n' % (d, n), 'w').write('%d\n' % (K + 5))
    open('%s/b%03d.input' % (d, n), 'w').write('\n'.join(inp) + '\n')
