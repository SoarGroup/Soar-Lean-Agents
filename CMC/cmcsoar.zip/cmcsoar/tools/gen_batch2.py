#!/usr/bin/env python3
"""As gen_batch.py, for the other semantic-memory commands: a retrieve of an identifier retrieved
before (optionally with ^depth 2 over linked memories), whose results enter the Rete as one
batch; observers share condition prefixes, and the operator indifferent-selection --first picks
shows the order. Usage: gen_batch2.py DIR COUNT SEED"""
import random, sys, os
d, count, seed = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
os.makedirs(d, exist_ok=True)
R = random.Random(seed)
for n in range(count):
    nl = R.randint(2, 3)
    names = ['<l%d>' % i for i in range(nl)]
    lt = []
    for i in range(nl):
        link = ' ^next %s' % names[(i + 1) % nl] if R.random() < 0.6 else ''
        lt.append('(%s ^kind x ^val %d ^tag %d%s)' % (names[i], R.randint(1, 3), R.randint(1, 2), link))
    K = R.randint(2, 3)
    depth = R.choice([1, 2])
    src = ['smem --enable', 'smem --add {\n   ' + '\n   '.join(lt) + '\n}', '',
           'sp {init\n   (state <s> ^superstate nil -^step)\n-->\n   (<s> ^operator <o> + =)\n   (<o> ^name init)\n}',
           'sp {apply*init\n   (state <s> ^operator.name init)\n-->\n   (<s> ^step 0)\n}']
    # wait until K-1, query at K-1, keep the result id at K, retrieve it at K+1
    src.append('sp {propose*wait\n   (state <s> ^step <n> < %d)\n-->\n   (<s> ^operator <o> + =)\n   (<o> ^name wait ^n <n>)\n}' % (K - 1))
    src.append('sp {propose*ask\n   (state <s> ^step %d)\n-->\n   (<s> ^operator <o> + =)\n   (<o> ^name ask ^n %d)\n}' % (K - 1, K - 1))
    src.append('sp {apply*ask\n   (state <s> ^operator.name ask ^smem.command <c>)\n-->\n   (<c> ^query <q>)\n   (<q> ^kind x)\n}')
    src.append('sp {propose*keep\n   (state <s> ^step %d ^smem.result.retrieved <x> -^last <y>)\n-->\n   (<s> ^operator <o> + =)\n   (<o> ^name keep ^n %d ^x <x>)\n}' % (K, K))
    src.append('sp {apply*keep\n   (state <s> ^operator <o>)\n   (<o> ^name keep ^x <x>)\n-->\n   (<s> ^last <x>)\n}')
    src.append('sp {propose*ask2\n   (state <s> ^step %d ^last <x>)\n-->\n   (<s> ^operator <o> + =)\n   (<o> ^name ask2 ^n %d ^x <x>)\n}' % (K + 1, K + 1))
    src.append('sp {apply*ask2\n   (state <s> ^operator <o> ^smem.command <c>)\n   (<o> ^name ask2 ^x <x>)\n-->\n   (<c> ^retrieve <x>%s)\n}' % (' ^depth %d' % depth if depth > 1 else ''))
    src.append('sp {apply*clear\n   (state <s> ^operator.name ask2 ^smem.command <c>)\n   (<c> ^{ <> retrieve <> depth <a> } <v>)\n-->\n   (<c> ^<a> <v> -)\n}')
    src.append('sp {apply*step\n   (state <s> ^operator <o> ^step <n>)\n   (<o> ^name << wait ask keep ask2 >> ^n <n>)\n-->\n   (<s> ^step <n> - ^step (+ <n> 1))\n}')
    src.append('sp {apply*waitstep\n   (state <s> ^operator <o> ^step <n>)\n   (<o> ^name wait ^n <n>)\n-->\n   (<s> ^step <n> - ^step (+ <n> 1))\n}')
    obs = []
    top = K + 2
    for i in range(R.randint(2, 4)):
        kind = R.choice(['r', 'r', 'd'] if depth > 1 else ['r'])
        tagc = R.choice(['', ' ^tag %d' % R.randint(1, 2)])
        if kind == 'r':
            lhs = '(<s> ^step %d ^smem.result.retrieved <r>)\n   (<r> ^val <v>%s)' % (top, tagc)
        else:
            lhs = '(<s> ^step %d ^smem.result.depth-retrieved <r>)\n   (<r> ^val <v>%s)' % (top, tagc)
        obs.append('sp {obs%d\n   %s\n-->\n   (<s> ^operator <p> + =)\n   (<p> ^name pick%d ^v <v>)\n}' % (i, lhs, i))
    R.shuffle(obs)
    src += obs
    src.append('sp {apply*pick\n   (state <s> ^operator <p>)\n   (<p> ^name << pick0 pick1 pick2 pick3 >> ^v <v>)\n-->\n   (<s> ^picked <v>)\n}')
    src.append('sp {done\n   (state <s> ^picked <v>)\n-->\n   (halt)\n}')
    open('%s/c%03d.soar' % (d, n), 'w').write('\n\n'.join(src) + '\n')
    open('%s/c%03d.n' % (d, n), 'w').write('%d\n' % (K + 8))
