#!/usr/bin/env python3
"""As gen_batch.py, for episodic memory: a cue-based query whose retrieved episode enters the
Rete as one batch; observers on the retrieved episode share condition prefixes. Usage:
gen_batch3.py DIR COUNT SEED"""
import random, sys, os
d, count, seed = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
os.makedirs(d, exist_ok=True)
R = random.Random(seed)
for n in range(count):
    K = R.randint(3, 4)
    objs = [(R.randint(1, 3), R.randint(1, 2), R.randint(1, 2)) for _ in range(R.randint(2, 3))]
    src = ['epmem --set learning on', '',
           'sp {init\n   (state <s> ^superstate nil -^step)\n-->\n   (<s> ^operator <o> + =)\n   (<o> ^name init)\n}',
           'sp {apply*init\n   (state <s> ^operator.name init)\n-->\n   (<s> ^step 0 ' + ' '.join('^obj <o%d>' % i for i in range(len(objs))) + ')\n   '
           + '\n   '.join('(<o%d> ^val %d ^tag %d ^w %d)' % (i, v, t, w) for i, (v, t, w) in enumerate(objs)) + '\n}',
           'sp {propose*wait\n   (state <s> ^step <n> < %d)\n-->\n   (<s> ^operator <o> + =)\n   (<o> ^name wait ^n <n>)\n}' % (K - 1),
           'sp {propose*ask\n   (state <s> ^step %d)\n-->\n   (<s> ^operator <o> + =)\n   (<o> ^name ask ^n %d)\n}' % (K - 1, K - 1),
           'sp {apply*ask\n   (state <s> ^operator.name ask ^epmem.command <c>)\n-->\n   (<c> ^query <q>)\n   (<q> ^obj <x>)\n   (<x> ^val %d)\n}' % R.randint(1, 3),
           'sp {apply*step\n   (state <s> ^operator <o> ^step <n>)\n   (<o> ^name << wait ask >> ^n <n>)\n-->\n   (<s> ^step <n> - ^step (+ <n> 1))\n}']
    obs = []
    for i in range(R.randint(2, 4)):
        extra = R.choice(['', ' ^tag %d' % R.randint(1, 2), ' ^w <w>', ' ^tag <t> ^w %d' % R.randint(1, 2)])
        obs.append('sp {obs%d\n   (<s> ^step %d ^epmem.result.retrieved.obj <r>)\n   (<r> ^val <v>%s)\n-->\n   (<s> ^operator <p> + =)\n   (<p> ^name pick%d ^v <v>)\n}' % (i, K, extra, i))
    R.shuffle(obs)
    src += obs
    src.append('sp {apply*pick\n   (state <s> ^operator <p>)\n   (<p> ^name << pick0 pick1 pick2 pick3 >> ^v <v>)\n-->\n   (<s> ^picked <v>)\n}')
    src.append('sp {done\n   (state <s> ^picked <v>)\n-->\n   (halt)\n}')
    open('%s/e%03d.soar' % (d, n), 'w').write('\n\n'.join(src) + '\n')
    open('%s/e%03d.n' % (d, n), 'w').write('%d\n' % (K + 6))
