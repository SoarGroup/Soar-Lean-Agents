#!/usr/bin/env python3
"""As gen_batch3.py, for the other memory commands whose results enter the Rete as a batch:
mode e: epmem query, then next or previous or retrieve of an episode number, observers on the
second result; mode s: smem store of a working-memory structure, or prohibit of a retrieved
identifier, then a query whose result shows the effect. Usage: gen_batch4.py e|s DIR COUNT SEED"""
import random, sys, os
mode, d, count, seed = sys.argv[1], sys.argv[2], int(sys.argv[3]), int(sys.argv[4])
os.makedirs(d, exist_ok=True)
R = random.Random(seed)
def common(K, extra_rules):
    return ['sp {init\n   (state <s> ^superstate nil -^step)\n-->\n   (<s> ^operator <o> + =)\n   (<o> ^name init)\n}',
            'sp {propose*wait\n   (state <s> ^step <n> < %d)\n-->\n   (<s> ^operator <o> + =)\n   (<o> ^name wait ^n <n>)\n}' % (K - 1)] + extra_rules
for n in range(count):
    if mode == 'e':
        K = R.randint(4, 5)
        objs = [(R.randint(1, 3), R.randint(1, 2), R.randint(1, 2)) for _ in range(R.randint(2, 3))]
        how = R.choice(['next', 'previous', 'retrieve'])
        src = ['epmem --set learning on', ''] + common(K, [
          'sp {apply*init\n   (state <s> ^operator.name init)\n-->\n   (<s> ^step 0 ' + ' '.join('^obj <o%d>' % i for i in range(len(objs))) + ')\n   '
          + '\n   '.join('(<o%d> ^val %d ^tag %d ^w %d)' % (i, v, t, w) for i, (v, t, w) in enumerate(objs)) + '\n}',
          'sp {propose*ask\n   (state <s> ^step %d)\n-->\n   (<s> ^operator <o> + =)\n   (<o> ^name ask ^n %d)\n}' % (K - 1, K - 1),
          'sp {apply*ask\n   (state <s> ^operator.name ask ^epmem.command <c>)\n-->\n   (<c> ^query <q>)\n   (<q> ^obj <x>)\n   (<x> ^val %d)\n}' % R.randint(1, 3),
          'sp {propose*ask2\n   (state <s> ^step %d ^epmem.result.retrieved)\n-->\n   (<s> ^operator <o> + =)\n   (<o> ^name ask2 ^n %d)\n}' % (K, K),
          'sp {apply*ask2\n   (state <s> ^operator.name ask2 ^epmem.command <c>)\n-->\n   (<c> ^%s %s)\n}' % (how, '2' if how == 'retrieve' else '<c>'),
          'sp {apply*clear\n   (state <s> ^operator.name ask2 ^epmem.command <c>)\n   (<c> ^query <q>)\n-->\n   (<c> ^query <q> -)\n}',
          'sp {apply*step\n   (state <s> ^operator <o> ^step <n>)\n   (<o> ^name << wait ask ask2 >> ^n <n>)\n-->\n   (<s> ^step <n> - ^step (+ <n> 1))\n}'])
        top, pre = K + 1, 'e'
        obs = []
        for i in range(R.randint(2, 4)):
            extra = R.choice(['', ' ^tag %d' % R.randint(1, 2), ' ^w <w>', ' ^tag <t> ^w %d' % R.randint(1, 2)])
            obs.append('sp {obs%d\n   (<s> ^step %d ^epmem.result.retrieved.obj <r>)\n   (<r> ^val <v>%s)\n-->\n   (<s> ^operator <p> + =)\n   (<p> ^name pick%d ^v <v>)\n}' % (i, top, extra, i))
        opt = '--epmem'
    else:
        K = R.randint(3, 4)
        lt = ['(<l%d> ^kind x ^val %d ^tag %d)' % (i, R.randint(1, 3), R.randint(1, 2)) for i in range(R.randint(2, 3))]
        act = R.choice(['store', 'prohibit'])
        if act == 'store':
            first = 'sp {apply*first\n   (state <s> ^operator.name first ^smem.command <c>)\n-->\n   (<c> ^store <n>)\n   (<n> ^kind x ^val %d ^tag %d)\n}' % (R.randint(1, 3), R.randint(1, 2))
        else:
            first = 'sp {apply*first\n   (state <s> ^operator.name first ^smem.command <c> ^smem.result.retrieved <x>)\n-->\n   (<c> ^prohibit <x>)\n}'
        src = ['smem --enable', 'smem --add {\n   ' + '\n   '.join(lt) + '\n}', ''] + common(K, [
          'sp {apply*init\n   (state <s> ^operator.name init)\n-->\n   (<s> ^step 0)\n}',
          'sp {propose*q0\n   (state <s> ^step %d)\n-->\n   (<s> ^operator <o> + =)\n   (<o> ^name q0 ^n %d)\n}' % (K - 1, K - 1),
          'sp {apply*q0\n   (state <s> ^operator.name q0 ^smem.command <c>)\n-->\n   (<c> ^query <q>)\n   (<q> ^kind x)\n}',
          'sp {propose*first\n   (state <s> ^step %d ^smem.result.retrieved)\n-->\n   (<s> ^operator <o> + =)\n   (<o> ^name first ^n %d)\n}' % (K, K),
          first,
          'sp {apply*clear\n   (state <s> ^operator.name first ^smem.command <c>)\n   (<c> ^query <q>)\n-->\n   (<c> ^query <q> -)\n}',
          'sp {propose*q1\n   (state <s> ^step %d ^smem.result.<< success bad-cmd >>)\n-->\n   (<s> ^operator <o> + =)\n   (<o> ^name q1 ^n %d)\n}' % (K + 1, K + 1),
          'sp {apply*q1\n   (state <s> ^operator.name q1 ^smem.command <c>)\n-->\n   (<c> ^query <q>)\n   (<q> ^kind x)\n}',
          'sp {apply*clear1\n   (state <s> ^operator.name q1 ^smem.command <c>)\n   (<c> ^{ <> query <a> } <v>)\n-->\n   (<c> ^<a> <v> -)\n}',
          'sp {apply*step\n   (state <s> ^operator <o> ^step <n>)\n   (<o> ^name << wait q0 first q1 >> ^n <n>)\n-->\n   (<s> ^step <n> - ^step (+ <n> 1))\n}'])
        top = K + 2
        obs = []
        for i in range(R.randint(2, 4)):
            tagc = R.choice(['', ' ^tag %d' % R.randint(1, 2)])
            kw = R.choice(['retrieved', 'retrieved', 'failure'])
            if kw == 'failure':
                obs.append('sp {obs%d\n   (<s> ^step %d ^smem.result.failure <q>)\n-->\n   (<s> ^operator <p> + =)\n   (<p> ^name pick%d ^v 0)\n}' % (i, top, i))
            else:
                obs.append('sp {obs%d\n   (<s> ^step %d ^smem.result.retrieved <r>)\n   (<r> ^val <v>%s)\n-->\n   (<s> ^operator <p> + =)\n   (<p> ^name pick%d ^v <v>)\n}' % (i, top, tagc, i))
        opt = '--smem'
    R.shuffle(obs)
    src += obs
    src.append('sp {apply*pick\n   (state <s> ^operator <p>)\n   (<p> ^name << pick0 pick1 pick2 pick3 >> ^v <v>)\n-->\n   (<s> ^picked <v>)\n}')
    src.append('sp {done\n   (state <s> ^picked <v>)\n-->\n   (halt)\n}')
    open('%s/g%03d.soar' % (d, n), 'w').write('\n\n'.join(src) + '\n')
    open('%s/g%03d.n' % (d, n), 'w').write('%d\n' % (K + 8))
