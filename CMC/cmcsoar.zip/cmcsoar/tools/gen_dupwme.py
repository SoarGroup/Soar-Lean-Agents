#!/usr/bin/env python3
"""Elements with the same triple as an architecture-made element: rules remake the architecture's
elements (type, superstate, impasse, attribute, choices, quiescence, the io links), some only
for a while, in the top state and in substates made by operator ties, and probe rules count the
matches (an element made twice matches twice). Usage: gen_dupwme.py DIR COUNT SEED"""
import random, sys, os
d, count, seed = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
os.makedirs(d, exist_ok=True)
R = random.Random(seed)
TOP = ['(<s> ^type state)', '(<s> ^superstate nil)', '(<s> ^io <io>)']
SUB = ['(<s> ^type state)', '(<s> ^superstate <ss>)', '(<s> ^impasse tie)', '(<s> ^choices multiple)',
       '(<s> ^attribute operator)', '(<s> ^quiescence t)']
for n in range(count):
    K = R.randint(3, 5)
    src = ['sp {init\n   (state <s> ^superstate nil -^step)\n-->\n   (<s> ^step 0)\n}']
    src.append('sp {tick\n   (state <s> ^superstate nil ^step <n> < %d)\n-->\n   (<s> ^step <n> - ^step (+ <n> 1))\n}' % K)
    # a tie among operators makes a substate
    src.append('sp {propose*a\n   (state <s> ^superstate nil ^step %d -^done)\n-->\n   (<s> ^operator <o> +)\n   (<o> ^name a)\n}' % R.randint(1, K))
    src.append('sp {propose*b\n   (state <s> ^superstate nil ^step %d -^done)\n-->\n   (<s> ^operator <o> +)\n   (<o> ^name b)\n}' % R.randint(1, K))
    for i in range(R.randint(1, 3)):
        a = R.choice(TOP)
        if R.random() < 0.5:
            src.append('sp {remake*top%d\n   (state <s> ^superstate nil ^step >= %d)\n-->\n   %s\n}' % (i, R.randint(0, K), a))
        else:
            src.append('sp {remake*top%d\n   (state <s> ^superstate nil ^step {>= %d <= %d})\n-->\n   %s\n}' % (i, 0, R.randint(1, K), a))
    for i in range(R.randint(1, 3)):
        a = R.choice(SUB)
        pre = R.choice(['(state <s> ^superstate <ss> ^impasse tie)', '(state <s> ^superstate <ss> ^impasse tie ^quiescence t)'])
        src.append('sp {remake*sub%d\n   %s\n-->\n   %s\n}' % (i, pre, a))
    for i in range(R.randint(2, 4)):
        t = R.choice(TOP + SUB)
        top = t in TOP
        pre = '(state <s> ^superstate nil)' if top else '(state <s> ^superstate <ss> ^impasse tie)'
        body = t.replace('(<s> ', '(<s> ')
        lhs = pre.rstrip(')') + ' ' + t[len('(<s> '):-1] + ')'
        src.append('sp {probe%d\n   %s\n-->\n   (write |probe%d | (crlf))\n}' % (i, lhs, i))
    open(os.path.join(d, 'dw%03d.soar' % n), 'w').write('\n'.join(src) + '\n')
    open(os.path.join(d, 'dw%03d.n' % n), 'w').write('%d\n' % (K + 4))
