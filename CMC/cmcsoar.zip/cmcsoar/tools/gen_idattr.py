#!/usr/bin/env python3
"""Identifiers used as attributes: objects made by rules appear as an attribute (alone, or also
as a value, or both), their links are removed, and observer rules test them with variable
attributes, negations, preferences on such attributes, operators with identifier attributes and
`deep-copy`, so that garbage collection, matching and preference handling of attribute
identifiers show. Usage: gen_idattr.py DIR COUNT SEED"""
import random, sys, os
d, count, seed = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
os.makedirs(d, exist_ok=True)
R = random.Random(seed)
for n in range(count):
    K = R.randint(4, 6)
    nobj = R.randint(2, 3)
    src = ['sp {init\n   (state <s> ^superstate nil -^step)\n-->\n   (<s> ^operator <o> + =)\n   (<o> ^name init)\n}']
    # the objects: some linked as values (^obj), some only as attributes
    mk = []
    for i in range(nobj):
        how = R.choice(['value', 'attr', 'both', 'self'])
        mk.append('(<o%d> ^id %d ^tag %d)' % (i, i, R.randint(1, 2)))
        if how in ('value', 'both'): mk.append('(<s> ^obj <o%d>)' % i)
        if how in ('attr', 'both'): mk.append('(<s> ^<o%d> %s)' % (i, R.choice(['yes', 'no', 'maybe'])))
        if how == 'self': mk.append('(<s> ^<o%d> <o%d>)' % (i, i))
        if R.random() < 0.3: mk.append('(<o%d> ^<o%d> sub)' % (i, (i + 1) % nobj))
    src.append('sp {apply*init\n   (state <s> ^operator.name init)\n-->\n   (<s> ^step 0)\n   %s\n}' % '\n   '.join(mk))
    src.append('sp {propose*tick\n   (state <s> ^step <n> < %d)\n-->\n   (<s> ^operator <o> + =)\n   (<o> ^name tick ^n <n>)\n}' % K)
    src.append('sp {apply*tick\n   (state <s> ^operator <o> ^step <n>)\n   (<o> ^name tick ^n <n>)\n-->\n   (<s> ^step <n> - ^step (+ <n> 1))\n}')
    for i in range(R.randint(1, 3)):
        st = R.randint(0, K - 1)
        o = R.randrange(nobj)
        kind = R.choice(['rmval', 'rmattr', 'addattr', 'addval', 'rmsub'])
        pre = '(state <s> ^operator <p>)\n   (<p> ^name tick ^n %d)\n   ' % st
        if kind == 'rmval': a = '%s(<s> ^obj <x>)\n   (<x> ^id %d)\n-->\n   (<s> ^obj <x> -)' % (pre, o)
        elif kind == 'rmattr': a = '%s(<s> ^<x> <v>)\n   (<x> ^id %d)\n-->\n   (<s> ^<x> <v> -)' % (pre, o)
        elif kind == 'addattr': a = '%s(<s> ^%s <x>)\n   (<x> ^id %d)\n-->\n   (<s> ^<x> added)' % (pre, R.choice(['obj', '<k>']), o)
        elif kind == 'addval': a = '%s(<s> ^<x> <w>)\n   (<x> ^id %d)\n-->\n   (<s> ^obj <x>)' % (pre, o)
        else: a = '%s(<s> ^<x> <w>)\n   (<x> ^id %d ^<y> sub)\n-->\n   (<x> ^<y> sub -)' % (pre, o)
        src.append('sp {act%d\n   %s\n}' % (i, a))
    obs = []
    for i in range(R.randint(3, 5)):
        k = R.choice(['attr', 'attrsub', 'notattr', 'both', 'vattr', 'cnt', 'opattr', 'copy', 'neq'])
        t = R.randint(0, nobj - 1)
        if k == 'attr': lhs, v = '(<s> ^step %d ^<a> yes)\n   (<a> ^id <v>)' % K, '<v>'
        elif k == 'attrsub': lhs, v = '(<s> ^step %d ^<a> <z>)\n   (<a> ^id <v> ^<b> sub)' % K, '<v>'
        elif k == 'notattr': lhs, v = '(<s> ^step %d ^obj <x>)\n   (<x> ^id <v>)\n   -(<s> ^<x> yes)' % K, '<v>'
        elif k == 'both': lhs, v = '(<s> ^step %d ^obj <x> ^<x> <w>)\n   (<x> ^id <v>)' % K, '<v>'
        elif k == 'vattr': lhs, v = '(<s> ^step %d ^<a> <b>)\n   (<a> ^tag <v>)' % K, '<v>'
        elif k == 'cnt': lhs, v = '(<s> ^step %d ^{ <a> <> <b> } <w>)\n   (<a> ^id <v>)\n   (<s> ^<b> <u>)' % K, '<v>'
        elif k == 'opattr': lhs, v = '(<s> ^step %d ^<a> <w>)\n   (<a> ^id <v> ^tag 1)' % K, '<v>'
        elif k == 'copy': lhs, v = '(<s> ^step %d ^obj <x> -^copy)\n   (<x> ^id <v>)' % K, '<v>'
        else: lhs, v = '(<s> ^step %d ^obj <x> ^<y> <w>)\n   (<x> ^id <v>)\n   (<y> ^id {<> <v>})' % K, '<v>'
        extra = ''
        if k == 'opattr': extra = ' ^<a> marked'
        if k == 'copy': extra = ' ^c (deep-copy <x>)'
        obs.append('sp {obs%d\n   %s\n-->\n   (<s> ^operator <p> + %s)\n   (<p> ^name pick%d ^v %s%s)\n}' % (i, lhs, R.choice(['=', '>', '<', '=']), i, v, extra))
    R.shuffle(obs)
    src += obs
    src.append('sp {apply*pick\n   (state <s> ^operator <p>)\n   (<p> ^name << pick0 pick1 pick2 pick3 pick4 >> ^v <v>)\n-->\n   (<s> ^picked <v>)\n}')
    src.append('sp {done\n   (state <s> ^picked <v>)\n-->\n   (halt)\n}')
    open('%s/t%03d.soar' % (d, n), 'w').write('\n\n'.join(src) + '\n')
    open('%s/t%03d.n' % (d, n), 'w').write('%d\n' % (K + 4))
