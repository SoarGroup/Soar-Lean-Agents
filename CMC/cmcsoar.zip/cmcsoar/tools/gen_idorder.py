#!/usr/bin/env python3
"""Ordering tests between identifiers: objects made by rules in different decisions, under
right-hand-side variables with different first letters (and on attributes with other letters),
are compared with <, >, <= and >= against each other, against states and operators, so that
Soar's order (letter, then number; compare_symbols) shows. Usage: gen_idorder.py DIR COUNT SEED"""
import random, sys, os
d, count, seed = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
os.makedirs(d, exist_ok=True)
R = random.Random(seed)
LET = ['a', 'b', 'k', 'm', 'x', 'z', 'q', 'w', 'e', 'o']
ATT = ['item', 'zed', 'alpha', 'beta', 'obj', 'thing']
OPS = ['<', '>', '<=', '>=']
for n in range(count):
    K = R.randint(3, 5)
    nobj = R.randint(3, 5)
    src = ['sp {init\n   (state <s> ^superstate nil -^step)\n-->\n   (<s> ^operator <o> + =)\n   (<o> ^name init)\n}']
    # objects made at different steps; variable letter and attribute independent
    made = []
    for i in range(nobj):
        step = R.randint(0, K - 1)
        v = R.choice(LET) + ('' if R.random() < 0.7 else str(R.randint(1, 9)))
        att = R.choice(ATT)
        made.append((i, step, v, att))
    for (i, step, v, att) in made:
        src.append('sp {make%d\n   (state <s> ^operator <p>)\n   (<p> ^name tick ^n %d)\n-->\n   (<s> ^%s <%s>)\n   (<%s> ^id %d)\n}' % (i, step, att, v, v, i))
    src.append('sp {propose*tick\n   (state <s> ^step <n> < %d)\n-->\n   (<s> ^operator <o> + =)\n   (<o> ^name tick ^n <n>)\n}' % K)
    src.append('sp {apply*tick\n   (state <s> ^operator <o> ^step <n>)\n   (<o> ^name tick ^n <n>)\n-->\n   (<s> ^step <n> - ^step (+ <n> 1))\n}')
    src.append('sp {apply*init\n   (state <s> ^operator.name init)\n-->\n   (<s> ^step 0 ^me <s>)\n}')
    for i in range(R.randint(4, 7)):
        op = R.choice(OPS)
        i1, i2 = R.sample(range(nobj), 2)
        kind = R.choice(['pair', 'pair', 'state', 'oper', 'neg'])
        if kind == 'pair':
            lhs = '(state <s> ^step %d ^<a1> <x> ^<a2> {<y> %s <x>})\n   (<x> ^id %d)\n   (<y> ^id %d)' % (K, op, i1, i2)
        elif kind == 'state':
            lhs = '(state <s> ^step %d ^<a1> <x> ^me {<m> %s <x>})\n   (<x> ^id %d)' % (K, op, i1)
        elif kind == 'oper':
            lhs = '(state <s> ^step %d ^operator <p> ^<a1> {<x> %s <p>})\n   (<x> ^id %d)' % (K, op, i1)
        else:
            lhs = '(state <s> ^step %d ^<a1> <x>)\n   (<x> ^id %d)\n   -(<s> ^<a2> {<y> %s <x>})' % (K, i1, op)
        src.append('sp {cmp%d\n   %s\n-->\n   (<s> ^cmp%d yes)\n   (write |cmp%d | (crlf))\n}' % (i, lhs, i, i))
    open(os.path.join(d, 'io%03d.soar' % n), 'w').write('\n'.join(src) + '\n')
    open(os.path.join(d, 'io%03d.n' % n), 'w').write('%d\n' % (K + 4))
