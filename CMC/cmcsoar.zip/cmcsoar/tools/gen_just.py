#!/usr/bin/env python3
"""Programs in which a justification is added to Soar's Rete while later matches fire in an
order that depends on the network: the observers share a prefix of conditions with the
justification, and a batch of new objects makes several of them match at once; which one
Soar picks (indifferent-selection --first) shows the order. Usage: gen_just.py DIR COUNT SEED"""
import random, sys, os
d, count, seed = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
os.makedirs(d, exist_ok=True)
R = random.Random(seed)
CONDS = ['(<o> ^t {t})', '(<o> ^u <u>)', '(<o> ^v <v>)', '(<o> ^w {w})', '(<o> ^u {u2})']
def conds(R, k, shared=None):
    pool = [(c.format(t=R.choice([1, 2]), w=R.choice([1, 2]), u2=R.choice([1, 2, 3]))) for c in CONDS]
    if shared:
        pre = shared[:R.randint(1, len(shared))]
    else:
        pre = []
    rest = [c for c in pool if c not in pre]
    R.shuffle(rest)
    return pre + rest[:max(0, k - len(pre))]
for n in range(count):
    J = conds(R, R.randint(2, 3))
    obs = [conds(R, R.randint(2, 4), J) for _ in range(R.randint(2, 4))]
    objs = []
    def obj(nm):
        a = ' '.join('^%s %d' % (k, R.randint(1, 2) if k in 'tw' else R.randint(1, 3)) for k in ('t', 'u', 'v', 'w'))
        return '(<%s> %s)' % (nm, a)
    init = [obj('o%d' % i) for i in range(R.randint(2, 4))]
    added = [obj('n%d' % i) for i in range(R.randint(6, 8))]
    src = ['chunk never', '',
           'sp {init\n   (state <s> ^superstate nil)\n-->\n   (<s> ^topstate <s> ' + ' '.join('^obj <o%d>' % i for i in range(len(init))) + ')\n   ' + '\n   '.join(init) + '\n}',
           'sp {propose*sub\n   (state <s> ^superstate nil -^res <r> -^added yes)\n-->\n   (<s> ^operator <p> +)\n   (<p> ^name sub)\n}',
           'sp {sub*result\n   (state <s> ^superstate <ts>)\n   (<ts> ^operator.name sub ^obj <o>)\n   ' + '\n   '.join(J) + '\n-->\n   (<ts> ^res <o>)\n}',
           'sp {propose*add\n   (state <s> ^superstate nil ^res <r> -^added yes)\n-->\n   (<s> ^operator <p> +)\n   (<p> ^name add)\n}',
           'sp {apply*add\n   (state <s> ^operator.name add)\n-->\n   (<s> ^added yes ' + ' '.join('^obj <n%d>' % i for i in range(len(added))) + ')\n   ' + '\n   '.join(added) + '\n}']
    rules = []
    for i, oc in enumerate(obs):
        rules.append('sp {obs%d\n   (state <s> ^added yes ^obj <o>)\n   ' % i + '\n   '.join(oc) + '\n-->\n   (<s> ^operator <p> + <p> =)\n   (<p> ^name pick%d ^obj <o>)\n}' % i)
    R.shuffle(rules)
    src += rules
    src.append('sp {apply*pick\n   (state <s> ^operator <p>)\n   (<p> ^name << pick0 pick1 pick2 pick3 >> ^obj <o>)\n-->\n   (<s> ^picked <o>)\n}')
    src.append('sp {done\n   (state <s> ^picked <o>)\n-->\n   (halt)\n}')
    open('%s/j%03d.soar' % (d, n), 'w').write('\n\n'.join(src) + '\n')
    open('%s/j%03d.n' % (d, n), 'w').write('12\n')
