#!/usr/bin/env python3
"""Rules with long-term-identifier tests (@+ @- @ !@) whose links change while the elements they
test are in the network: objects made at step 0 are linked later (link-stm-to-ltm, or stored with
smem --store), retrieved memories sit beside them, and observer rules (some sharing condition
prefixes) pick an operator by which tests hold, so the order of matches shows. Usage:
gen_lti.py DIR COUNT SEED"""
import random, sys, os
d, count, seed = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
os.makedirs(d, exist_ok=True)
R = random.Random(seed)
for n in range(count):
    K = R.randint(4, 6)
    nl = R.randint(2, 3)
    mem = ' '.join('(<m%d> ^kind x ^val %d)' % (i, i + 1) for i in range(nl))
    nobj = R.randint(2, 3)
    src = ['smem --enable', 'smem --add { %s }' % mem, '',
           'sp {init\n   (state <s> ^superstate nil -^step)\n-->\n   (<s> ^operator <o> + =)\n   (<o> ^name init)\n}',
           'sp {apply*init\n   (state <s> ^operator.name init)\n-->\n   (<s> ^step 0 %s)\n   %s\n}' % (
               ' '.join('^obj <o%d>' % i for i in range(nobj)),
               '\n   '.join('(<o%d> ^id %d ^tag %d)' % (i, i, R.randint(1, 2)) for i in range(nobj))),
           'sp {propose*tick\n   (state <s> ^step <n> < %d)\n-->\n   (<s> ^operator <o> + =)\n   (<o> ^name tick ^n <n>)\n}' % K,
           'sp {apply*tick\n   (state <s> ^operator <o> ^step <n>)\n   (<o> ^name tick ^n <n>)\n-->\n   (<s> ^step <n> - ^step (+ <n> 1))\n}']
    # actions at chosen steps
    for i in range(R.randint(1, 3)):
        st = R.randint(0, K - 1)
        o = R.randrange(nobj)
        kind = R.choice(['link', 'link', 'store', 'query'])
        if kind == 'link':
            src.append('sp {act%d\n   (state <s> ^operator <p>)\n   (<p> ^name tick ^n %d)\n   (<s> ^obj <x>)\n   (<x> ^id %d)\n-->\n   (link-stm-to-ltm <x> %d)\n}' % (i, st, o, R.randint(1, nl)))
        elif kind == 'store':
            src.append('sp {act%d\n   (state <s> ^operator <p> ^smem.command <c>)\n   (<p> ^name tick ^n %d)\n   (<s> ^obj <x>)\n   (<x> ^id %d)\n-->\n   (<c> ^store <x>)\n}' % (i, st, o))
        else:
            src.append('sp {act%d\n   (state <s> ^operator <p> ^smem.command <c>)\n   (<p> ^name tick ^n %d)\n-->\n   (<c> ^query <q>)\n   (<q> ^kind x ^val %d)\n}' % (i, st, R.randint(1, nl)))
    src.append('sp {clear\n   (state <s> ^operator.name tick ^smem.command <c>)\n   (<c> ^<a> <v>)\n-->\n   (<c> ^<a> <v> -)\n}')
    obs = []
    for i in range(R.randint(3, 5)):
        k = R.choice(['lti', 'nolti', 'num', 'notnum', 'same', 'differ', 'ret', 'retnum'])
        if k == 'lti': lhs = '(<s> ^step %d ^obj { <x> @+ })\n   (<x> ^id <v>)' % K
        elif k == 'nolti': lhs = '(<s> ^step %d ^obj { <x> @- })\n   (<x> ^id <v>)' % K
        elif k == 'num': lhs = '(<s> ^step %d ^obj { <x> @ %d })\n   (<x> ^id <v>)' % (K, R.randint(1, nl))
        elif k == 'notnum': lhs = '(<s> ^step %d ^obj { <x> !@ %d })\n   (<x> ^id <v>)' % (K, R.randint(1, nl))
        elif k == 'same': lhs = '(<s> ^step %d ^obj { <x> @ <r> } ^smem.result.retrieved <r>)\n   (<x> ^id <v>)' % K
        elif k == 'differ': lhs = '(<s> ^step %d ^smem.result.retrieved <r> ^obj { <x> !@ <r> })\n   (<x> ^id <v>)' % K
        elif k == 'ret': lhs = '(<s> ^step %d ^smem.result.retrieved { <r> @+ })\n   (<r> ^val <v>)' % K
        else: lhs = '(<s> ^step %d ^smem.result.retrieved { <r> @ %d })\n   (<r> ^val <v>)' % (K, R.randint(1, nl))
        obs.append('sp {obs%d\n   %s\n-->\n   (<s> ^operator <p> + =)\n   (<p> ^name pick%d ^v <v>)\n}' % (i, lhs, i))
    R.shuffle(obs)
    src += obs
    src.append('sp {apply*pick\n   (state <s> ^operator <p>)\n   (<p> ^name << pick0 pick1 pick2 pick3 pick4 >> ^v <v>)\n-->\n   (<s> ^picked <v> ^lti (@ <p>))\n}')
    src.append('sp {done\n   (state <s> ^picked <v>)\n-->\n   (halt)\n}')
    open('%s/t%03d.soar' % (d, n), 'w').write('\n\n'.join(src) + '\n')
    open('%s/t%03d.n' % (d, n), 'w').write('%d\n' % (K + 4))
