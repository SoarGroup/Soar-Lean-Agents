# World-conventions: draft 0 (8 November 2026)

A new set of Soar programming conventions for programs built on agent-world and its
capacities. It sits alongside the conventions derived from existing Soar programs, which are
kept unchanged for comparison.

## Contents

| Path | What |
|---|---|
| `World-Conventions.xlsx` | The new conventions in English (589 rows) plus Levels, Capacities, Defects (93 + 2), Not carried (86), Library summaries |
| `Soar-Conventions-derived.xlsx` | The derived conventions, unchanged (copy for comparison) |
| `lean/World/Types.lean` | Typed task descriptions: objects, relations, desireds, task operators, MEA proposals, capacities |
| `lean/World/Check.lean` | `check : Task → List (ID × message)`, with `Conventional t := check t = []` (decidable) |
| `lean/World/RulePred.lean` | Conventions as predicates over soar-lean rules (`Soar.Production`) and working memory |
| `lean/World/Compile.lean` | Generator: task description → task rules plus a load file for agent-world and the chosen selection capacity |
| `lean/World/Tasks/BlocksWorld.lean` | Test description (three-block Sussman anomaly), with the theorem `blocksWorld_conventional` |
| `lean/WorldCheck.lean` | `worldcheck --task F / --lib F / --wm F`: lists violations in rule files and working-memory dumps |
| `generated/{id,indiff,sw}/` | Generated Blocks World programs: iterative deepening; indifferent (no look-ahead); selection-world only |
| `extraction/` | The four source extractions (JSON) and the workbook build script |

## Workbook organization

| Level | Rows | Meaning |
|---|---|---|
| L0 Definitional | 117 | Carried over from the derived set. Kept even where agent-world departs from them; the departures are noted on the row. |
| L1 Architectural | 57 | Carried over; same rule as L0 |
| L2 Universal practice | 14 of 17 | Carried over. The other 3 conflict with the world material, e.g. SYN-033: world rules test `^problem-space.name` rather than the state name. |
| L3 / L4 / L5 | 23 / 6 / 12 | Derived rows that the world material supports |
| W Core | 111 | World, objects, relations, desireds and their bookkeeping, task and composite operators, application, substates, flags, output |
| C Capacity | 249 | Rows that hold only when a capacity is loaded |

Capacities, with their row counts:

| Capacity | Rows |
|---|---|
| iterative deepening | 68 |
| selection-world | 66 |
| selection (base) | 49 |
| Thor-specific | 45 |
| grounding | 24 |
| time and future events | 18 |
| attention | 12 |
| look-ahead | 11 |
| verification | 10 |
| goal completion | 9 |
| smem storage | 6 |
| MEA | 4 |
| idle | 3 |

Columns include:
- whether the task must supply the item;
- whether it is Thor-specific;
- checkability;
- the planned Lean form and the Lean that exists now;
- the matching derived ID;
- notes where the documentation and the code differ;
- possible duplicates across sources.

All rows have status "Proposed". Duplicates are flagged but not merged.

## Lean

- **Formalized now:** 40 rows, as types, description checks, rule predicates, WM predicates or generator obligations. The "Lean (done)" column says which. Every convention ID cited in the Lean is a row of the workbook.
- **Checks fire:** handmade bad rule and WM files trigger each predicate.
- **Generated rules:** the Blocks World task rules have 0 violations.
- **Working memory:** WM snapshots taken every 10 decisions of the iterative-deepening run have 0 violations.
- **Libraries checked with the same predicates:**
  - 46 library operator proposals give no `^task-operator` (W-TOP-001, Should).
  - 4 proposals of task operators also give another preference (W-TOP-021).
  - Both are added to Defects.

## Runs: generated Blocks World, Sussman anomaly

The simulated environment marks `perform-action` complete; task rules then apply the effect to the world.

| Capacity | Result |
|---|---|
| none (indifferent task operators) | solved in 3 moves, 14 decisions |
| iterative deepening (agent-world, simple, selection, selection-world, ID) | solved in 3 moves (optimal), 124 decisions |
| selection-world only | no action in 400 decisions. This fits the extraction finding that `^untried-tied-operator` is never created. |

soar-lean against Soar 9.6.5, decision by decision:
- iterative deepening: identical over 200 decisions (agent-world, simple, selection, selection-world, ID, task rules);
- indifferent: identical over 100 decisions.

## Main defects in the libraries

None of these were fixed. The full list is in the Defects sheet.

- **High**
  - **Iterative deepening:** the depth increment never checks the maximum, so the maximum depth is never enforced. Found by reading the rules.
  - **Base selection:** values never come back from look-ahead, and the look-ahead can change the real world. Both seen in Soar.
  - **agent-world:** two operator rules add `^success` to the state.
  - **agent-world:** the count-5 rules test `^desired-count 4`, and counts stop at 6. The Lean check rejects goals of 5 desireds and of more than 6.
  - **agent-world:** `finish-future-event2` points at an unbound future event.
- **selection-world**
  - The evaluated operator is never forced first.
  - A single dead end fails every evaluation.
  - Two successes stay tied.
- **Documentation and code disagree**
  - `^anchored` in the documentation is `^anchored-world` in the code.
  - The documentation says the agent halts on success; the code does not.
  - The documentation says `^desired-source`; the code uses `^desireds-source`.
  - The documentation says relations are copied from the scene into the world; they are not.

## Next steps

- Review the workbook rows and merge the flagged duplicates.
- Formalize more of the C rows: iterative-deepening flags, the selection-world copy set, and time.
- Composite operators (`CompOp`) are typed but not yet generated.
- An environment for soar-lean that writes `^status` on output commands. With it, whole runs can be compared, including external actions.
