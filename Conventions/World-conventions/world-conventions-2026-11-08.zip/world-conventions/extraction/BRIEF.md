# Brief: extract world-convention candidates (John Laird's "world-conventions" for Soar)

Context. John Laird (JL) is defining a new set of Soar programming conventions, "world-conventions",
used by a library called agent-world plus selection/look-ahead libraries ("capacities"). They will be
written in English, then formalized in Lean 4, and used to generate Soar task agents from English task
descriptions. A previous, separate set of conventions was derived from existing Soar programs; it is in
/home/claude/wc/ref/derived-conventions.csv (ID, Level, Kind, Subject, Strength, Convention). Levels there:
L0 Definitional, L1 Architectural, L2 Universal practice, L3 Manual/tutorial guidance, L4 Default rules,
L5 Selection space, L6 Project. Do NOT edit any input files.

Sources (read-only):
- Thor-Soar documentation text: /home/claude/wc/thor.txt (JL says this is the convention text for state,
  desired and operator representations).
- agent-world library: /home/claude/wc/in/dw/default-world/agent-world/ (ignore *.soar~ backup files)
- selection libraries: /home/claude/wc/in/dw/default-world/{selection,selection-world,selection-iterative-deepening}/
- Blocks World example in the new style: /home/claude/wc/in/bw/blocks-world-world/blocks-world-world/blocks-world-simple/
  (known: its problem-space ^name is move-blocks but rules test move-block / moving-block, so it does not run).
- Soar 9.6.5 is installed (python: `from soar_sml import Kernel`) if you need to check behaviour.

Task: read your assigned sources thoroughly and extract every convention (a rule of representation or
of rule-writing that a program using these libraries must or should follow) and every background fact the
library relies on. One idea per item. Be precise and in Soar terms (attribute names, values, which state).
Distinguish what the code actually does from what the doc says; when they differ, record both and flag it.
Also record defects/inconsistencies you find (separate list).

Output: write JSON to the file named in your assignment:
{ "items": [ {
   "convention": "one sentence, imperative or declarative",
   "kind": "convention" | "fact",
   "area": one of "World/state", "Objects", "Relations", "Desireds", "Desireds bookkeeping",
           "Task operators", "Composite operators", "Non-task operators", "Operator application (internal/external)",
           "Substates (general)", "MEA operator subgoaling", "Look-ahead / evaluation", "Selection space",
           "Iterative deepening", "Search control", "Time and future events", "Grounding", "Flags and constants",
           "Output and events", "Chunking/learning", "Naming and files", "Other",
   "strength": "Must" | "Should" | "May",
   "scope": e.g. "top state", "all states", "operator no-change substate", "selection (tie) substate",
            "evaluate-operator substate", "operators", "task rules",
   "rationale": "why, one sentence",
   "if_violated": "what goes wrong, one phrase",
   "example": "short Soar fragment or WM example (optional)",
   "source": "doc section and/or file:rule-name (be specific)",
   "implemented_by": "agent-world/selection rule names that create or rely on it (or empty)",
   "task_must_supply": true/false   (does the TASK program have to write rules/structures for it, or does the library do it?),
   "thor_specific": true/false,
   "checkability": "syntactic" | "static" | "runtime" | "not mechanical",
   "derived_match": "ID(s) from derived-conventions.csv that say the same or conflict, with 'same'/'refines'/'conflicts' , or empty",
   "doc_code_note": "only if doc and code differ" } ],
  "defects": [ {"where": "file:rule", "what": "...", "severity": "high|medium|low"} ],
  "summary": "5-10 lines: how this part works (structures, flow), for the person writing the Lean types" }
Aim for completeness over brevity (typically 40-120 items for a large assignment). Do not invent
conventions that the sources do not support; you may mark an item "Should" when the sources imply it.
Return a 10-line summary when done (counts, main structures, top defects).
