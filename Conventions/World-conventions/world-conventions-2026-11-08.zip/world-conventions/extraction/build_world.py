import json,collections,re,csv,openpyxl
from openpyxl.styles import Font,PatternFill,Alignment
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.utils import get_column_letter
E='/home/claude/wc/extract/'
files=[('A1-core.json','core representations (Thor doc + agent-world)'),('A2-operators.json','operators and agent-world capacities'),
       ('B-selection.json','selection and selection-world'),('C-iterative-deepening.json','selection-iterative-deepening')]
items=[];defects=[];summ={}
for f,lab in files:
    d=json.load(open(E+f)); summ[lab]=d.get('summary','')
    for i in d['items']: i['_f']=f; items.append(i)
    for x in d['defects']: x['_f']=f; defects.append(x)
PFX={'World/state':'WLD','Objects':'OBJ','Relations':'REL','Desireds':'DES','Desireds bookkeeping':'DBK','Task operators':'TOP',
 'Composite operators':'COP','Non-task operators':'NOP','Operator application (internal/external)':'APP','Substates (general)':'SUB',
 'MEA operator subgoaling':'MEA','Look-ahead / evaluation':'LAH','Selection space':'SEL','Iterative deepening':'IDP','Search control':'SCT',
 'Time and future events':'TIM','Grounding':'GRD','Flags and constants':'FLG','Output and events':'OUT','Chunking/learning':'CHK',
 'Naming and files':'NAM','Other':'OTH'}
CAPAREAS={'MEA operator subgoaling':'MEA operator subgoaling','Time and future events':'time and future events','Grounding':'grounding',
 'Look-ahead / evaluation':'look-ahead (agent-world)','Iterative deepening':'iterative deepening','Selection space':'selection'}
def capacity(i):
    f=i['_f']; sc=(i.get('scope') or '').lower(); src=((i.get('source') or '')+' '+(i.get('implemented_by') or '')).lower()
    caps=[]
    if f=='B-selection.json':
        caps.append('selection-world' if 'selection-world only' in sc else 'selection (base)' if 'selection only' in sc else 'selection (base), selection-world')
    elif f=='C-iterative-deepening.json': caps.append('iterative deepening')
    else:
        for k,v in [('force-conflict','verification (force-conflict)'),('goal-completed','goal completion'),('smem','smem storage'),
                    ('find-object','grounding'),('failed-grounding','grounding'),('assume-successful-grounding','grounding'),
                    ('future-event','time and future events'),('skip-wait','idle (wait)'),('dispatch-agent-event','idle (wait)'),
                    ('remove-object','attention (attend/remove)'),('attend','attention (attend/remove)'),('cutoff-search','look-ahead (agent-world)')]:
            if k in src and v not in caps: caps.append(v)
        a=CAPAREAS.get(i['area'])
        if a and a not in caps: caps.insert(0,a)
    if i.get('thor_specific') and 'Thor-specific' not in caps: caps.append('Thor-specific')
    return ', '.join(caps)
# derived
dw=openpyxl.load_workbook('/home/claude/wc/ref/Soar-Conventions-derived.xlsx')['Conventions']
dh=[c.value for c in dw[1]]; drows=[dict(zip(dh,[c.value for c in r])) for r in dw.iter_rows(min_row=2) if r[0].value]
refs=collections.defaultdict(lambda: collections.defaultdict(list))
for n,i in enumerate(items):
    for did,rel in re.findall(r'([A-Z]{2,4}-\d{3})[^;,]*?(same|refines|conflicts)', i.get('derived_match') or ''):
        refs[did][rel].append(n)
# assign IDs
cnt=collections.Counter(); 
order=sorted(range(len(items)), key=lambda n:(list(PFX).index(items[n]['area']) if items[n]['area'] in PFX else 99, n))
for n in order:
    p=PFX.get(items[n]['area'],'OTH'); cnt[p]+=1; items[n]['ID']=f'W-{p}-{cnt[p]:03d}'
for i in items:
    i['Capacity']=capacity(i); i['Level']='C Capacity' if i['Capacity'] and i['Capacity']!='Thor-specific' else 'W Core'
    if i['Capacity']=='Thor-specific': i['Level']='C Capacity'
# duplicate detection
def toks(s): return set(re.findall(r'[\^\w-]+',s.lower()))-{'the','a','an','of','to','is','and','in','on','its','for','with','be','are','that','it','by','as','or'}
T=[toks(i['convention']) for i in items]
for a in range(len(items)):
    best=None
    for b in range(len(items)):
        if a==b or items[a]['_f']==items[b]['_f']: continue
        j=len(T[a]&T[b])/max(1,len(T[a]|T[b]))
        if j>=0.4 and (best is None or j>best[0]): best=(j,b)
    items[a]['dup']=f"{items[best[1]]['ID']} ({best[0]:.2f})" if best else ''
def leanform(i):
    ch=i.get('checkability','')
    if i['kind']=='fact': return 'Library fact: documentation; runtime predicate where checkable' if ch=='runtime' else 'Documentation'
    if i.get('task_must_supply'): return 'DSL type or check (generation)' + ('; rule predicate' if ch in ('syntactic','static') else '; WM predicate' if ch=='runtime' else '')
    return {'syntactic':'Rule predicate (syntactic)','static':'Rule predicate (static)','runtime':'WM predicate (runtime)'}.get(ch,'Documentation')
# carry over
conf={d for d in refs if refs[d]['conflicts']}
carried=[];notc=[]
for r in drows:
    lv=r['Level'][:2]; did=r['ID']; s=refs.get(did,{})
    matched=[items[n]['ID'] for k in ('same','refines') for n in s.get(k,[])] if s else []
    confl=[items[n]['ID'] for n in s.get('conflicts',[])] if s else []
    if confl and lv not in ('L0','L1'): notc.append((r,'Conflicts with '+', '.join(confl))); continue
    if confl: r=dict(r); r['_viol']=confl
    if lv in ('L0','L1','L2'): carried.append((r,matched))
    elif lv in ('L3','L4','L5') and matched: carried.append((r,matched))
    else: notc.append((r,'Not referenced by the world material' if lv!='L6' else 'Project convention of agentgen (classic default rules); superseded'))
LV={'L0':'L0 Definitional','L1':'L1 Architectural','L2':'L2 Universal practice','L3':'L3 Guidance','L4':'L4 Default rules','L5':'L5 Selection space (classic)'}
# ---- workbook
wb=openpyxl.Workbook(); H=Font(bold=True,color='FFFFFF'); HF=PatternFill('solid',fgColor='1E2761'); Y=PatternFill('solid',fgColor='FFF6CC')
def sheet(name,cols,rows,widths,yellow=()):
    ws=wb.create_sheet(name); ws.append(cols)
    for c in ws[1]: c.font=H; c.fill=HF; c.alignment=Alignment(wrap_text=True,vertical='top')
    for r in rows: ws.append(r)
    for k,w in enumerate(widths,1): ws.column_dimensions[get_column_letter(k)].width=w
    for row in ws.iter_rows(min_row=2):
        for c in row:
            c.alignment=Alignment(wrap_text=True,vertical='top')
            if cols[c.column-1] in yellow: c.fill=Y
    ws.freeze_panes='C2'; ws.auto_filter.ref=ws.dimensions
    return ws
LEAN={}
def addL(ids,where):
    for i in ids.split(): LEAN.setdefault(i,[]).append(where)
addL('W-OBJ-002 W-DES-005 W-DES-006 W-DES-009 W-REL-001 W-TOP-004 W-TOP-012 W-TOP-013 W-TOP-015','type (World/Types)')
addL('W-NAM-004 W-OBJ-002 W-REL-002 W-REL-001 W-DES-001 W-DES-004 W-DES-009 W-DES-013 W-SCT-003 W-GRD-008 W-TOP-012 W-NAM-006 W-TOP-013 W-TOP-014 W-TOP-016 W-APP-010 W-TOP-005 W-TOP-010 W-DES-019 W-FLG-014','check (World/Check)')
addL('W-NAM-006 W-TOP-001 W-TOP-013 W-DES-003 W-DES-005 W-APP-010 W-TOP-021 W-TOP-018 W-NAM-004','rule predicate (World/RulePred)')
addL('W-DBK-003 W-DES-003 W-REL-001 W-OBJ-002 W-TOP-013','WM predicate (World/RulePred)')
addL('W-WLD-001 W-WLD-002 W-NAM-001 W-NAM-009 W-NAM-013 W-WLD-014 W-LAH-009 W-FLG-013 W-FLG-014 W-FLG-015 W-DBK-002 W-TOP-010 W-TOP-018 W-APP-010 W-APP-003 W-DES-003','generator (World/Compile)')
COLS=['ID','Level','Capacity','Kind','Area','Strength','Scope','Convention','Rationale','If violated','Example','Source','Implemented by',
      'Task supplies','Thor-specific','Checkability','Lean form (planned)','Lean (done)','Derived match','Doc/code note','Possible duplicate','Origin','Status','Reviewer notes']
rows=[]
for r,m in carried:
    rows.append([r['ID'],LV[r['Level'][:2]],'',r['Kind'],'Carried over: '+(r['Subject'] or ''),r['Strength'],r.get('Scope'),r['Convention'],r.get('Rationale'),
                 r.get('If violated'),r.get('Example'),r.get('Source'),'', '', False, r.get('Checkability'), r.get('Lean form (proposed)'), '',
                 'same ID' + ('; supported by '+', '.join(m) if m else ''), ('World material departs from it: '+', '.join(r['_viol'])+' (kept: L0/L1 hold regardless; see Defects)') if r.get('_viol') else '', '', 'Derived set ('+r['Level']+')','Proposed',None])
for n in order:
    i=items[n]
    rows.append([i['ID'],i['Level'],i['Capacity'],i['kind'],i['area'],i['strength'],i.get('scope'),i['convention'],i.get('rationale'),i.get('if_violated'),
                 i.get('example'),i.get('source'),i.get('implemented_by'),bool(i.get('task_must_supply')),bool(i.get('thor_specific')),i.get('checkability'),
                 leanform(i),'; '.join(LEAN.get(i['ID'],[])),i.get('derived_match'),i.get('doc_code_note'),i['dup'],'World material: '+dict(files)[i['_f']],'Proposed',None])
del wb['Sheet']
rd=wb.create_sheet('README')
for t in ['World-Conventions for Soar programs (draft 0, 8 November 2026)',
 'A new set of conventions for programs built on agent-world and its capacities (selection, selection-world, iterative deepening, MEA operator subgoaling, look-ahead, time and future events, grounding, ...).',
 'The derived conventions (Soar-Conventions.xlsx, from existing Soar programs) are kept unchanged for comparison. Rows carried over from them keep their IDs; new rows have IDs W-<area>-nnn.',
 'Sources: Thor-Soar Agent Documentation (JL, 2025-26); agent-world, selection, selection-world, selection-iterative-deepening (default-world.zip, 8 Nov 2026).',
 'Each row: one convention or library fact. Level = why it holds (L0–L3 carried over; W Core = representation every agent-world program shares; C Capacity = applies when that capacity is loaded, named in Capacity).',
 'Task supplies = TRUE when the task program must write rules or structures for it (otherwise the library provides it).',
 'Possible duplicate = a similar row from another source file (word overlap); to merge in review.',
 'Defects sheet: problems found in the libraries and doc; none were fixed. Not carried sheet: derived conventions left out, with the reason.',
 'Edit the yellow columns (Status, Reviewer notes).']:
    rd.append([t])
rd.column_dimensions['A'].width=150
ws=sheet('World-Conventions',COLS,rows,[13,16,20,10,18,9,16,60,40,28,36,34,30,9,9,12,24,24,22,28,18,26,11,30],yellow=('Status','Reviewer notes'))
ws.add_data_validation(dv:=DataValidation(type='list',formula1='"Proposed,Accepted,Rejected,Revise,Merge"')); dv.add(f'W2:W{len(rows)+50}')
lv=sheet('Levels',['Level','Meaning','Rows','Conventions','Facts'],[],[22,90,8,12,8])
for name,mean in [('L0 Definitional','True by definition of a Soar construct (carried over from the derived set).'),
  ('L1 Architectural','Follows from how Soar operates (carried over).'),('L2 Universal practice','Adopted essentially everywhere (carried over unless it conflicts with the world material).'),
  ('L3 Guidance','Manual/tutorial guidance of the derived set that the world material supports.'),
  ('L4 Default rules','Conventions of simple.soar (still loaded by agent-world programs) that the world material supports.'),
  ('L5 Selection space (classic)','Classic selection-space conventions that the world capacities keep.'),
  ('W Core','The world representation every agent-world program shares: ^world, objects, relations, desireds, task operators, application, substates, flags.'),
  ('C Capacity','Holds when a capacity is loaded (Capacity column): selection, selection-world, iterative deepening, MEA, look-ahead, time, grounding, ...')]:
    k=lv.max_row+1
    lv.append([name,mean,f'=COUNTIF(\'World-Conventions\'!B:B,A{k})',f'=COUNTIFS(\'World-Conventions\'!B:B,A{k},\'World-Conventions\'!D:D,"convention")',f'=COUNTIFS(\'World-Conventions\'!B:B,A{k},\'World-Conventions\'!D:D,"fact")'])
caps=collections.Counter(c.strip() for i in items for c in i['Capacity'].split(',') if c.strip())
sheet('Capacities',['Capacity','Rows','Library'],[[c,n,{'selection (base)':'selection','selection-world':'selection-world','iterative deepening':'selection-iterative-deepening'}.get(c,'agent-world')] for c,n in caps.most_common()],[34,8,30])
sheet('Defects',['ID','Severity','Where','What','Found while extracting'],
      [[f'D-{k+1:03d}',x.get('severity'),x.get('where'),x.get('what'),dict(files)[x['_f']]] for k,x in enumerate(sorted(defects,key=lambda x:['high','medium','low'].index(x.get('severity','low')) if x.get('severity') in ('high','medium','low') else 3))],[8,9,50,100,30])
libf=[('low','agent-world, selection, selection-iterative-deepening (46 rules)','W-TOP-001 (Should): 46 library operator proposals give no ^task-operator (e.g. wait, goal-completed, find-object*, evaluate-operator, the iterative-deepening operators). Found by World.ruleViolations.'),
      ('low','agent-world: force-conflict*external-action, assume-successful-grounding (2), failed-grounding','W-TOP-021 (Should): task-operator proposals that also give another preference. Found by World.ruleViolations.')]
dws=wb['Defects']
for sev,wh,wt in libf: dws.append([f'D-{dws.max_row:03d}',sev,wh,wt,'Lean rule predicates (8 Nov 2026)'])
sheet('Not carried',['ID','Level','Subject','Convention','Reason'],[[r['ID'],r['Level'],r['Subject'],r['Convention'],why] for r,why in notc],[10,24,24,80,50])
sheet('Library summaries',['Part','Summary'],[[k,v] for k,v in summ.items()],[34,150])
sheet('Columns',['Column','Meaning'],[[c,''] for c in COLS],[22,90])
wb.calculation.fullCalcOnLoad=True
wb.save('/home/claude/wc/World-Conventions.xlsx')
print('rows',len(rows),'carried',len(carried),'notcarried',len(notc),'defects',len(defects))
print(collections.Counter(r[1] for r in rows)); print(caps.most_common())
print(collections.Counter(r[1]['Level'][:2] for r in [(0,x[0]) for x in carried]))
print(collections.Counter(why.split(' ')[0] for r,why in notc), collections.Counter(r['Level'][:2] for r,why in notc))
print(sum(1 for i in items if i['dup']))
