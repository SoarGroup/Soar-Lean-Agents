import World.Types
/-!
# World-conventions that a task description must satisfy

`check t` lists every violation as (convention ID, message); a description is conventional
when the list is empty. Each check cites the row of World-Conventions.xlsx it decides. Rows
that the types already guarantee are listed in World/Types.lean.
-/
namespace World

/-- Operator names reserved by agent-world and the selection libraries (W-NAM-006, W-NAM-009). -/
def reservedOps : List String :=
  ["wait", "skip-wait", "dispatch-agent-event-idle", "goal-completed", "clean-up-topstate",
   "initialize-agent-world", "find-object", "find-object-direct", "remove-object", "force-conflict",
   "next-desireds", "evaluate-operator", "cutoff-search", "finish-future-event", "failed-grounding",
   "assume-successful-grounding", "exceed-depth", "achieved-max-depth", "decrement-remaining-operators",
   "increment-current-evaluation-depth", "init-current-evaluation-depth", "init-remaining-operators",
   "remove-evaluation", "all-evaluations-failed", "copy-task-state", "apply-task-operator",
   "evaluate-task-state"]

/-- Attributes the libraries use on states and operators (W-NAM-005). -/
def reservedAttrs : List String :=
  ["world", "io", "flags", "real", "problem-space", "top-state", "external-top-state", "scene",
   "attends", "desireds", "super-desireds", "internal-actions", "success", "failure", "name",
   "task-operator", "action-handle", "super-desired", "argument-count", "pre-conditions-satisfied",
   "duplicate-of", "anchored", "object-handle", "origin-object-handle"]

private def dupes (xs : List String) : List String :=
  (xs.filter fun x => (xs.filter (· == x)).length > 1).eraseDups

private def chk (b : Bool) (id msg : String) : List (String × String) := if b then [] else [(id, msg)]

/-- The handle-level checks of one desireds list against the known handles. -/
def checkItems (where_ : String) (known : List String) (items : List DesiredItem) : List (String × String) :=
  chk (items.length ≤ 6) "W-DES-004"
      s!"{where_}: {items.length} desired; the library counts at most 6" ++
  chk (items.length != 5) "W-DES-004"
      s!"{where_}: 5 desired; the library's count-5 rules test desired-count 4 (Defects sheet), so 5 is not counted correctly" ++
  (items.flatMap fun d => (d.handles.filter (!known.contains ·)).map fun h =>
      ("W-DES-009", s!"{where_}: desired refers to {h}, which is neither an object nor a world-context object"))

/-- The checks on one task-action operator. -/
def checkOp (t : Task) (o : TaskOp) : List (String × String) :=
  let known := o.params ++ t.objects.map (·.handle) ++ ["none"]
  chk (!reservedOps.contains o.name) "W-NAM-006" s!"operator {o.name}: name reserved by agent-world or a selection library" ++
  chk (o.actionHandle != "") "W-TOP-012" s!"operator {o.name}: no action handle" ++
  chk (o.params.length ≤ 3) "W-TOP-013" s!"operator {o.name}: {o.params.length} arguments; the generic external rules handle 0–3" ++
  chk (dupes o.params).isEmpty "W-TOP-013" s!"operator {o.name}: repeated parameter" ++
  (o.paramTypes.filterMap fun (p, _) => if o.params.contains p then none else
      some ("W-TOP-014", s!"operator {o.name}: type given for unknown parameter {p}")) ++
  checkItems s!"operator {o.name} preconditions" known o.pre ++
  ((o.pre ++ o.achieves).flatMap fun d => (d.handles.filter (!known.contains ·)).map fun h =>
      ("W-TOP-014", s!"operator {o.name}: {h} is not a parameter or an object")) ++
  chk (!t.caps.mea || !o.allAchieves.isEmpty) "W-TOP-016"
      s!"operator {o.name}: MEA is on but the operator achieves no desired, so it has no MEA proposal" ++
  (o.mea.flatMap fun m =>
    ((m.item.handles ++ m.binds.flatMap (·.args)).filter (fun h => !(known ++ m.locals).contains h)).map (fun h =>
      ("W-TOP-014", s!"operator {o.name}: MEA proposal names {h}, which is not a parameter, local or object")) ++
    let bound := m.item.handles ++ m.binds.flatMap (·.args) ++ m.fixed.map (·.1)
    (o.params.filter (!bound.contains ·)).map (fun p =>
      ("W-TOP-005", s!"operator {o.name}: MEA proposal for {repr m.item} does not bind parameter {p} to a world object")) ++
    (m.fixed.filter (fun (_, h) => !(t.objects.map (·.handle)).contains h)).map (fun (_, h) =>
      ("W-TOP-014", s!"operator {o.name}: fixed handle {h} is not an object"))) ++
  chk (t.caps.selection == .none || !o.effects.isEmpty) "W-TOP-016"
      s!"operator {o.name}: look-ahead is loaded but the operator has no internal application (effects)" ++
  (o.effects.flatMap fun
    | .setProp p _ _ | .setHolding p => if known.contains p then [] else [("W-APP-010", s!"operator {o.name}: effect on unknown parameter {p}")]
    | .addRel _ ps | .delRel _ ps => (ps.filter (!known.contains ·)).map fun p => ("W-APP-010", s!"operator {o.name}: effect on unknown parameter {p}")
    | .moveRel _ p ps => ((p :: ps).filter (!known.contains ·)).map fun p => ("W-APP-010", s!"operator {o.name}: effect on unknown parameter {p}"))

/-- An item of the goal is achievable when some operator's `achieves` has the same shape: the
same property (any object), relation name and arity, or holding. -/
def DesiredItem.sameShape : DesiredItem → DesiredItem → Bool
  | .prop _ p v, .prop _ p' v' => p == p' && v == v'
  | .rel r as, .rel r' as' => r == r' && as.length == as'.length
  | .holding _, .holding _ => true
  | _, _ => false

/-- Every world-convention violation of a task description. -/
def check (t : Task) : List (String × String) :=
  let handles := t.objects.map (·.handle)
  let known := handles ++ t.goal.context.map (·.handle) ++ ["none"]
  let n := t.goal.items.length
  let allOps := t.ops.map (·.name) ++ t.composites.map (·.name)
  chk (!t.name.isEmpty && !t.space.isEmpty) "W-NAM-004" "the task needs a name and a problem-space name" ++
  chk (dupes handles).isEmpty "W-OBJ-002" s!"object handles must be unique: {dupes handles}" ++
  chk (!handles.contains "none") "W-REL-002" "the handle none is reserved for an empty hand" ++
  (t.relations.flatMap fun r =>
    chk (r.args.all handles.contains) "W-REL-001" s!"relation {r.name}{r.args}: argument is not an object" ++
    chk (!(r.name == "on" || r.name == "in") || r.args.length == 2) "W-REL-001" s!"relation {r.name} must have 2 arguments") ++
  chk (n > 0) "W-DES-001" "the goal has no desired" ++
  checkItems "goal" known t.goal.items ++
  (t.goal.next.zipIdx.flatMap fun (s, k) => checkItems s!"next goal set {k+1}" known s) ++
  (t.goal.disjoint.flatMap fun (a, b) =>
    chk (a < n && b < n && a != b) "W-DES-013" s!"disjunction ({a},{b}) must name two different desired of the goal") ++
  ((t.goal.preferred ++ t.goal.avoid).flatMap fun k =>
    chk (k < n) "W-SCT-003" s!"preferred/avoid index {k} is not a desired of the goal") ++
  chk ((t.goal.preferred ++ t.goal.avoid).isEmpty || t.caps.desiredPrefs) "W-SCT-003"
      "preferred/avoid desireds have no effect unless flags.desired-preferences is true" ++
  (t.goal.context.flatMap fun o =>
    chk (o.props.length ≤ 1) "W-GRD-008" s!"world-context object {o.handle}: at most its class and one feature") ++
  chk (dupes allOps).isEmpty "W-TOP-012" s!"operator names must be unique: {dupes allOps}" ++
  (t.ops.flatMap (checkOp t)) ++
  (if t.caps.mea then
     t.goal.items.flatMap fun d =>
       chk (t.ops.any (·.allAchieves.any d.sameShape) || t.composites.any (·.achieves.any d.sameShape)) "W-TOP-010"
         s!"MEA: no operator achieves a desired of the shape {repr d}"
   else []) ++
  chk (t.caps.selection != .base) "W-DES-019"
      "the base selection library expects ^desired on the task state, not agent-world's ^desireds (W-DES-020); use selection-world" ++
  chk (t.caps.selection != .iterativeDeepening || t.caps.mea || t.caps.iterStep == .tieImpasse) "W-FLG-014"
      "iterative-step operator counts operators applied in MEA substates; without MEA use tie-impasse"

/-- A description follows the conventions this module decides. -/
def Conventional (t : Task) : Prop := check t = []

instance (t : Task) : Decidable (Conventional t) := inferInstanceAs (Decidable (check t = []))

end World
