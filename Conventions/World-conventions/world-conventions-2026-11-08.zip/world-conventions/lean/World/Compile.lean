import World.Check
/-!
# Generating the task rules of an agent-world program

`compile t libDir` gives the files of a Soar program: the task's own rules, which follow the
world-conventions, and a load file that sources agent-world and the selection capacity in the
order the libraries need (W-NAM-001, W-NAM-009, W-NAM-013). The libraries are not regenerated.

What the task supplies, by convention:
* initialization after agent-world's (W-WLD-002): ^name, ^desireds, world objects and relations;
* ^problem-space with ^name and ^agent-world true on the top state, its MEA substates and the
  look-ahead states (W-NAM-004, W-WLD-014, W-LAH-009); ^flags (W-FLG-013..015);
* achievement of relation, holding and object-property desireds on states and of relation
  desireds on operators (W-DBK-002);
* per task-action operator: MEA proposals (W-TOP-010, W-TOP-018) and an internal application
  (W-APP-010); external application is agent-world's (W-APP-003);
* derived properties, and the simulated environment's effects of completed actions.
-/
namespace World

def v (s : String) : String := s!"<{s}>"

/-- The Soar term for a handle or parameter: a parameter's handle variable, or a constant. -/
structure Env where
  params : List String
  hv : String → String := fun p => v ("h-" ++ p)

def Env.term (e : Env) (x : String) : String := if e.params.contains x then e.hv x else x

/-- Conditions that desired `<d>` is the item (handles as terms of `e`). -/
def itemConds (e : Env) (d : String) : DesiredItem → String
  | .prop h p x => s!"({v d} ^object {v (d ++ "-o")})\n   ({v (d ++ "-o")} ^object-handle {e.term h} ^{p} {x.toSoar})"
  | .rel r as =>
    let args := (as.zipIdx.map fun (a, k) => s!"^argument{k+1}.object-handle {e.term a}")
    s!"({v d} ^{r} {v (d ++ "-r")})\n   ({v (d ++ "-r")} {" ".intercalate args})"
  | .holding h => s!"({v d} ^holding-object.object-handle {e.term h})"

/-- Actions that make desired `<d>` the item. -/
def itemMakes (e : Env) (d : String) : DesiredItem → String
  | .prop h p x => s!"({v d} ^object {v (d ++ "-o")})\n   ({v (d ++ "-o")} ^object-handle {e.term h} ^{p} {x.toSoar})"
  | .rel r as =>
    let args := (as.zipIdx.map fun (a, k) => s!"^argument{k+1}.object-handle {e.term a}")
    s!"({v d} ^{r} {v (d ++ "-r")})\n   ({v (d ++ "-r")} {" ".intercalate args})"
  | .holding h => s!"({v d} ^holding-object.object-handle {e.term h})"

/-- A desireds structure `<ds>` made on the right side (W-DES-003: ^desired-count set here). -/
def desiredsMakes (e : Env) (ds : String) (items : List DesiredItem) : String :=
  let ds' := items.zipIdx.map fun (_, k) => v s!"{ds}-d{k+1}"
  s!"({v ds} ^desired-count {items.length}{if items.isEmpty then "" else " ^desired " ++ " ".intercalate ds'})\n   " ++
  "\n   ".intercalate (items.zipIdx.map fun (it, k) => itemMakes e s!"{ds}-d{k+1}" it)

def sp (name body : String) : String := s!"sp \{{name}\n   {body}\n}\n"

/-- Conditions binding parameter variables to anchored-world objects by handle. -/
def bindObjs (t : Task) (o : TaskOp) (ps : List String) (w : String) : String :=
  let ty p := match o.paramTypes.find? (·.1 == p) with | some (_, ty) => s!" ^type {ty}" | none => ""
  s!"({v w} ^anchored-world true ^objects {v "objs"})\n   " ++
  "\n   ".intercalate (ps.map fun p => s!"({v "objs"} ^object {v p})\n   ({v p} ^object-handle {v ("h-" ++ p)}{ty p})") ++
  (if t.objects.isEmpty then "" else "")

/-- Left and right sides of a list of effects over parameter objects in world `<w>`. -/
def effectSides (effs : List Effect) : String × String :=
  let parts := effs.zipIdx.map fun (ef, k) =>
    match ef with
    | .setProp p pr x => (s!"({v p} ^{pr} \{ <> {x.toSoar} {v s!"old{k}"} })", s!"({v p} ^{pr} {v s!"old{k}"} - {x.toSoar})")
    | .moveRel r p qs =>
      let q := qs.headD p
      (s!"({v "w"} ^{r} {v s!"r{k}"})\n   ({v s!"r{k}"} ^argument1 {v p} ^argument2 \{ <> {v q} {v s!"old{k}"} })",
       s!"({v s!"r{k}"} ^argument2 {v s!"old{k}"} - {v q})")
    | .addRel r ps =>
      ("", s!"({v "w"} ^{r} {v s!"r{k}"})\n   ({v s!"r{k}"} ^argument-count {ps.length} " ++
        " ".intercalate (ps.zipIdx.map fun (p, j) => s!"^argument{j+1} {v p}") ++ ")")
    | .delRel r ps =>
      (s!"({v "w"} ^{r} {v s!"r{k}"})\n   ({v s!"r{k}"} " ++ " ".intercalate (ps.zipIdx.map fun (p, j) => s!"^argument{j+1} {v p}") ++ ")",
       s!"({v "w"} ^{r} {v s!"r{k}"} -)")
    | .setHolding p =>
      (s!"({v "w"} ^holding-object {v s!"old{k}"})", s!"({v "w"} ^holding-object {v s!"old{k}"} - {if p == "none" then "none" else v p})")
  ("\n   ".intercalate ((parts.map (·.1)).filter (· != "")), "\n   ".intercalate (parts.map (·.2)))

/-- The initialization operator (W-WLD-001, W-WLD-002). -/
def initRules (t : Task) : String :=
  let e : Env := { params := [], hv := fun p => p }
  let ov (h : String) := v ("obj-" ++ h)
  let objs := t.objects.map fun o =>
    s!"({ov o.handle} ^object-handle {o.handle} ^anchored true ^type {o.type}" ++
      String.join (o.props.map fun (p, x) => s!" ^{p} {x.toSoar}") ++ ")"
  let rels := t.relations.zipIdx.map fun (r, k) =>
    s!"({v "w"} ^{r.name} {v s!"rel{k}"})\n   ({v s!"rel{k}"} ^argument-count {r.args.length} " ++
      " ".intercalate (r.args.zipIdx.map fun (a, j) => s!"^argument{j+1} {ov a}") ++ ")"
  let disj := t.goal.disjoint.map fun (a, b) =>
    s!"({v s!"ds-d{a+1}"} ^disjunction {v s!"ds-d{b+1}"})\n   ({v s!"ds-d{b+1}"} ^disjunction {v s!"ds-d{a+1}"})"
  let marks := t.goal.preferred.map (fun k => s!"({v "ds"} ^preferred-desired {v s!"ds-d{k+1}"})") ++
               t.goal.avoid.map (fun k => s!"({v "ds"} ^avoid-desired {v s!"ds-d{k+1}"})")
  let next := t.goal.next.zipIdx.map fun (items, k) =>
    s!"({v (if k == 0 then "ds" else s!"next{k}")} ^next-desireds {v s!"next{k+1}"})\n   " ++ desiredsMakes e s!"next{k+1}" items
  sp s!"{t.name}*propose*initialize-{t.name}"
    s!"(state <s> ^superstate nil ^world <w> -^name)\n-->\n   (<s> ^operator <o> + >)\n   (<o> ^name initialize-{t.name} ^task-operator false)" ++
  sp s!"{t.name}*apply*initialize-{t.name}"
    (s!"(state <s> ^operator.name initialize-{t.name} ^world <w>)\n   (<w> ^objects <objs>)\n-->\n   (<s> ^name {t.name} ^desireds <ds>)\n   " ++
     s!"(<objs> ^object {" ".intercalate (t.objects.map (ov ·.handle))})\n   " ++
     "\n   ".intercalate (objs ++ rels) ++ "\n   " ++
     (if t.relations.any (·.name == "holding-object") then "" else
       if t.goal.items.any (fun | .holding _ => true | _ => false) then "(<w> ^holding-object none)\n   " else "") ++
     desiredsMakes e "ds" t.goal.items ++
     (if (disj ++ marks ++ next).isEmpty then "" else "\n   " ++ "\n   ".intercalate (disj ++ marks ++ next)) ++
     s!"\n   (log 1 (crlf) |Initialize {t.name}.|)")

/-- Problem spaces (W-NAM-004, W-WLD-014, W-LAH-009) and flags (W-FLG-013..015). -/
def spaceRules (t : Task) : String :=
  let c := t.caps
  let b (x : Bool) := if x then "true" else "false"
  sp s!"{t.name}*elaborate*problem-space"
    s!"(state <s> ^name {t.name})\n-->\n   (<s> ^problem-space <p>)\n   (<p> ^name {t.space} ^agent-world true ^default-state-copy no ^default-operator-copy no ^default-desired-copy no ^dont-copy top-state)" ++
  sp s!"{t.name}*elaborate*problem-space*mea-substate"
    s!"(state <s> ^impasse no-change ^attribute operator ^superstate <ss>)\n   (<ss> ^problem-space.name {t.space} ^operator <so>)\n   (<so> ^task-operator true -^pre-conditions-satisfied true)\n-->\n   (<s> ^problem-space <p>)\n   (<p> ^name {t.space} ^agent-world true)" ++
  sp s!"{t.name}*elaborate*flags"
    (s!"(state <s> ^superstate nil ^name {t.name})\n-->\n   (<s> ^flags <f>)\n   (<f> ^mea-operator-selection {b c.mea} ^desired-preferences {b c.desiredPrefs} " ++
     s!"^gps-desired-ordering {b c.gpsOrdering} ^use-timers {b c.useTimers} ^look-ahead-planning {b (c.selection != .none)} " ++
     s!"^iterative-step {match c.iterStep with | .tieImpasse => "tie-impasse" | .operator => "operator"} " ++
     s!"^init-evaluation-depth {match c.initDepth with | .one => "one" | .unachievedDesireds => "unachieved-desireds"} ^rl false)")

/-- The relations, holding and object properties that desireds use. -/
def usedItems (t : Task) : List DesiredItem :=
  t.goal.items ++ t.goal.next.flatten ++ t.ops.flatMap (fun o => o.pre ++ o.allAchieves) ++
  t.composites.flatMap (fun o => o.pre ++ o.effectDesireds ++ o.achieves)

/-- Achievement of desireds the library does not decide (W-DBK-002, W-DBK-003: each desired is
achieved or unachieved, never both). `where_` is "state" or "operator". -/
def achievedRules (t : Task) : String :=
  let e : Env := { params := [] }
  let relKinds := ((usedItems t).filterMap fun | .rel r as => some (r, as.length) | _ => none).eraseDups
  let propKinds := ((usedItems t).filterMap fun | .prop _ p x => some (p, x) | _ => none).eraseDups
  let hold := (usedItems t).any fun | .holding _ => true | _ => false
  let ctx (op : Bool) := if op then "(state <s> ^operator <op> + ^world <w>)\n   (<op> ^desireds <ds>)" else "(state <s> ^desireds <ds> ^world <w>)"
  let one (nm : String) (op : Bool) (dconds wconds : String) :=
    sp s!"{t.name}*elaborate*{if op then "operator" else "state"}*achieved*{nm}"
      s!"{ctx op}\n   (<ds> ^desired <d>)\n   {dconds}\n   (<w> ^anchored-world true)\n   {wconds}\n-->\n   (<ds> ^achieved <d>)" ++
    sp s!"{t.name}*elaborate*{if op then "operator" else "state"}*unachieved*{nm}"
      s!"{ctx op}\n   (<ds> ^desired <d>)\n   {dconds}\n   (<w> ^anchored-world true)\n  -\{{wconds}}\n-->\n   (<ds> ^unachieved <d>)"
  let rels := relKinds.flatMap fun (r, n) =>
    let hs := (List.range n).map fun j => s!"<h{j+1}>"
    let dc := s!"(<d> ^{r} <dr>)\n   (<dr> " ++ " ".intercalate (hs.zipIdx.map fun (h, j) => s!"^argument{j+1}.object-handle {h}") ++ ")"
    let wc := s!"(<w> ^{r} <wr>)\n    (<wr> " ++ " ".intercalate (hs.zipIdx.map fun (h, j) => s!"^argument{j+1}.object-handle {h}") ++ ")"
    [one r false dc wc, one r true dc wc]
  let props := propKinds.map fun (p, x) =>
    let dc := s!"(<d> ^object <do>)\n   (<do> ^object-handle <h> ^{p} {x.toSoar})"
    let wc := s!"(<w> ^objects.object <ob>)\n    (<ob> ^object-handle <h> ^{p} {x.toSoar})"
    one s!"{p}-{x.toSoar}" false dc wc
  let holds := if !hold then [] else
    let dc := "(<d> ^holding-object.object-handle <h>)"
    let wc := "(<w> ^holding-object <ho>)\n    (<ho> ^object-handle <h>)"
    [one "holding" false dc wc, one "holding" true dc wc,
     sp s!"{t.name}*elaborate*state*achieved*holding-none" s!"{ctx false}\n   (<ds> ^desired <d>)\n   (<d> ^holding-object.object-handle none)\n   (<w> ^anchored-world true ^holding-object none)\n-->\n   (<ds> ^achieved <d>)"]
  let _ := e
  String.join (rels ++ props ++ holds)

/-- Derived properties on every world (real and look-ahead copies). -/
def derivedRules (t : Task) : String :=
  String.join <| t.derived.zipIdx.map fun (d, k) =>
    match d with
    | .always p tys => String.join <| tys.map fun ty =>
      sp s!"{t.name}*elaborate*world*{p}*{ty}" s!"(state <s> ^world <w>)\n   (<w> ^objects.object <ob>)\n   (<ob> ^type {ty})\n-->\n   (<ob> ^{p} true)"
    | .notArg p r j tys => String.join <| tys.map fun ty =>
      sp s!"{t.name}*elaborate*world*{p}*{ty}*{k}" s!"(state <s> ^world <w>)\n   (<w> ^objects.object <ob>)\n   (<ob> ^type {ty})\n  -\{(<w> ^{r} <r>)\n    (<r> ^argument{j} <ob>)}\n-->\n   (<ob> ^{p} true)"

/-- One MEA proposal (W-TOP-010, W-TOP-012, W-TOP-018, W-TOP-021). -/
def meaRule (t : Task) (o : TaskOp) (m : Mea) (k : Nat) : String :=
  let e : Env := { params := o.params ++ m.locals }
  let localConds := m.locals.map fun l => s!"({v l} ^object-handle {v ("h-" ++ l)})"
  let fixedConds := m.fixed.map fun (p, h) => s!"({v p} ^object-handle {h})"
  let bindConds := m.binds.zipIdx.map fun (r, j) =>
    s!"(<w> ^{r.name} {v s!"b{j}"})\n   ({v s!"b{j}"} " ++ " ".intercalate (r.args.zipIdx.map fun (a, i) => s!"^argument{i+1} {v a}") ++ ")"
  let args := o.params.zipIdx.map fun (p, i) => s!"^argument{i+1} {v p}"
  sp s!"{t.name}*propose*{o.name}*mea*{k+1}"
    (s!"(state <s> ^problem-space.name {t.space} ^flags.mea-operator-selection true ^world <w> ^desireds <ds>)\n   " ++
     bindObjs t o o.params "w" ++ "\n   " ++
     (if (fixedConds ++ bindConds ++ localConds).isEmpty then "" else "\n   ".intercalate (fixedConds ++ bindConds ++ localConds) ++ "\n   ") ++
     s!"(<ds> ^desired <sd> ^unachieved <sd>)\n   " ++ itemConds e "sd" m.item ++
     s!"\n-->\n   (<s> ^operator <op> +)\n   (<op> ^name {o.name} ^task-operator true ^action-handle {o.actionHandle} ^super-desired <sd> " ++
     " ".intercalate args ++ s!" ^argument-count {o.params.length} ^desireds <pre>)\n   " ++ desiredsMakes e "pre" o.pre)

/-- The internal application (W-APP-010) and the simulated environment's effect of the
completed external action. -/
def applyRules (t : Task) (o : TaskOp) : String :=
  let (lhs, rhs) := effectSides o.effects
  let argTests := " ".intercalate (o.params.zipIdx.map fun (p, i) => s!"^argument{i+1}.object-handle {v ("h-" ++ p)}")
  let paTests := " ".intercalate (o.params.zipIdx.map fun (p, i) => s!"^argument{i+1} {v ("h-" ++ p)}")
  sp s!"{t.name}*apply*{o.name}*internal"
    (s!"(state <s> ^operator <op> ^internal-actions true ^world <w>)\n   (<op> ^name {o.name} ^pre-conditions-satisfied true {argTests})\n   " ++
     bindObjs t o o.params "w" ++ (if lhs.isEmpty then "" else "\n   " ++ lhs) ++
     s!"\n-->\n   (log 1 (crlf) |Apply {o.name} internal.|)\n   {rhs}") ++
  sp s!"{t.name}*apply*{o.name}*environment-effect"
    (s!":o-support\n   (state <s> ^superstate nil ^world <w> ^io.output-link.perform-action <pa>)\n   (<pa> ^name {o.actionHandle} ^status complete {paTests})\n   " ++
     bindObjs t o o.params "w" ++ (if lhs.isEmpty then "" else "\n   " ++ lhs) ++
     s!"\n-->\n   {rhs}")

def indifferentRule (t : Task) : String :=
  if !t.indifferent then "" else
  sp s!"{t.name}*select*task-operator*indifferent"
    s!"(state <s> ^problem-space.name {t.space} ^operator <o> +)\n   (<o> ^task-operator true)\n-->\n   (<s> ^operator <o> =)"

/-- The library load order for the capacities (W-NAM-001, W-NAM-009, W-NAM-013). -/
def loadLines (t : Task) (libDir : String) : List String :=
  [s!"pushd {libDir}", "source agent-world.soar", "source simple.soar"] ++
  (match t.caps.selection with
   | .none => []
   | .base => ["pushd selection", "source selection_source.soar", "popd"]
   | .world => ["pushd selection", "source selection_source.soar", "popd", "pushd selection-world", "source selection-world_source.soar", "popd"]
   | .iterativeDeepening => ["pushd selection", "source selection_source.soar", "popd", "pushd selection-world", "source selection-world_source.soar", "popd",
                             "pushd selection-iterative-deepening", "source selection-iterative-deepening_source.soar", "popd"]) ++
  ["popd"]

/-- The task rules as one Soar file. -/
def taskRules (t : Task) : String :=
  s!"# {t.name}: task rules generated from its world-conventions description\n\n" ++
  initRules t ++ spaceRules t ++ achievedRules t ++ derivedRules t ++
  String.join (t.ops.flatMap fun o => o.mea.zipIdx.map fun (m, k) => meaRule t o m k) ++
  String.join (t.ops.map (applyRules t)) ++ indifferentRule t

/-- The program: (file, contents). -/
def compile (t : Task) (libDir : String) : List (String × String) :=
  [(s!"{t.name}.soar", "\n".intercalate (loadLines t libDir ++ [s!"source {t.name}-rules.soar"]) ++ "\n"),
   (s!"{t.name}-rules.soar", taskRules t)]

end World
