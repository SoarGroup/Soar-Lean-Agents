import Soar.Syntax
import World.Check
/-!
# World-conventions as predicates over Soar rules and working memory

These statements are about the Soar specification's own syntax (`Soar.Production`) and about
working memory as identifier–attribute–value triples, so they apply to any program: the
agent-world libraries, generated agents and hand-written ones. Each returns its violations as
(convention ID, rule or object, message); `ruleViolations ps = []` is the decidable statement
that the rules follow the conventions checked here.
-/
namespace World
open Soar

/-! ## Reading rules -/

/-- The constant of a one-element test. -/
def constOf : Test → Option String
  | [.const (.str s)] => some s
  | _ => none

def varOf : Test → Option String
  | [.var v] => some v
  | _ => none

def _root_.Soar.Production.posPats (p : Production) : List Pat :=
  p.conds.filterMap fun | .pos q => some q | _ => none

/-- Does the left side test `<id> ^attr const`? -/
def testsConst (p : Production) (id attr val : String) : Bool :=
  p.posPats.any fun q => varOf q.id == some id && constOf q.attr == some attr && constOf q.val == some val

/-- Does the left side test `<id> ^attr <v>` and return the variable? -/
def testsVar (p : Production) (id attr : String) : Option String :=
  p.posPats.findSome? fun q => if varOf q.id == some id && constOf q.attr == some attr then varOf q.val else none

/-- The variables the rule proposes as operators (acceptable preferences). -/
def proposedOps (p : Production) : List String :=
  p.acts.filterMap fun
    | .pref _ (.var o) .acceptable _ _ => some o
    | _ => none

/-- The right-side makes on identifier `x`: (attr, value). -/
def makesOn (p : Production) (x : String) : List (String × RVal) :=
  p.acts.filterMap fun
    | .make i (.sym (.str a)) v => if i == x then some (a, v) else none
    | _ => none

def rvConst : RVal → Option String
  | .sym (.str s) => some s
  | _ => none
def rvInt : RVal → Option Int
  | .sym (.int i) => some i
  | _ => none
def rvVar : RVal → Option String
  | .var v => some v
  | _ => none

/-- A rule is a library rule when it is written with `:default` — the parser does not keep the
flag, so library files are passed separately. -/
abbrev Violation := String × String × String

/-! ## Rule conventions -/

/-- W-NAM-006: a task rule does not propose an operator with a reserved name. -/
def reservedNames (p : Production) : List Violation :=
  (proposedOps p).flatMap fun o =>
    ((makesOn p o).filterMap fun (a, v) => if a == "name" then rvConst v else none).filterMap fun n =>
      if reservedOps.contains n then some ("W-NAM-006", p.name, s!"proposes reserved operator {n}") else none

/-- W-TOP-001: every proposed operator says whether it is a task operator. -/
def taskOperatorFlag (p : Production) : List Violation :=
  (proposedOps p).filterMap fun o =>
    let ms := makesOn p o
    if ms.isEmpty || ms.any (·.1 == "task-operator") then none
    else some ("W-TOP-001", p.name, s!"operator <{o}> has no ^task-operator")

/-- W-TOP-013: ^argument-count equals the number of ^argumentN made on the operator. -/
def argumentCount (p : Production) : List Violation :=
  (proposedOps p).filterMap fun o =>
    let ms := makesOn p o
    match (ms.find? (·.1 == "argument-count")).bind (rvInt ·.2) with
    | none => none
    | some k =>
      let n := (ms.filter fun (a, _) => a.startsWith "argument" && a != "argument-count").length
      if n == k.toNat then none else some ("W-TOP-013", p.name, s!"^argument-count {k} but {n} arguments")

/-- W-DES-003: a desireds made on the right side has ^desired-count equal to its ^desired. -/
def desiredCount (p : Production) : List Violation :=
  let ids := (p.acts.filterMap fun | .make i (.sym (.str "desired-count")) _ => some i | _ => none).eraseDups
  ids.filterMap fun d =>
    let ms := makesOn p d
    match (ms.find? (·.1 == "desired-count")).bind (rvInt ·.2) with
    | none => none
    | some k =>
      let n := (ms.filter (·.1 == "desired")).length
      if n == k.toNat || n == 0 then none else some ("W-DES-003", p.name, s!"^desired-count {k} but {n} ^desired")

/-- W-DES-005, W-DES-006: a desired object made on the right side has one property besides its
handle and bookkeeping attributes. -/
def oneProperty (p : Production) : List Violation :=
  let bk := ["object-handle", "duplicate-of", "anchored", "origin-object-handle"]
  let desireds := (p.acts.filterMap fun | .make _ (.sym (.str "desired")) v => rvVar v | _ => none).eraseDups
  desireds.flatMap fun d =>
    ((makesOn p d).filterMap fun (a, v) => if a == "object" then rvVar v else none).filterMap fun ob =>
      let props := (makesOn p ob).filter fun (a, _) => !bk.contains a
      if props.length ≤ 1 then none else some ("W-DES-005", p.name, s!"desired object has {props.length} properties")

/-- W-APP-010: a rule that applies an operator in look-ahead (tests the state's
^internal-actions true and its selected operator) tests ^pre-conditions-satisfied true. -/
def internalApplyGuard (p : Production) : List Violation :=
  match p.posPats.head? with
  | none => []
  | some q0 =>
    match varOf q0.id with
    | none => []
    | some s =>
      if !testsConst p s "internal-actions" "true" then [] else
      match testsVar p s "operator" with
      | none => []
      | some o =>
        if p.acts.any (fun | .pref .. => true | _ => false) then []   -- a preference rule, not an application
        else if testsConst p o "pre-conditions-satisfied" "true" then []
        else [("W-APP-010", p.name, "internal application without ^pre-conditions-satisfied true")]

/-- W-TOP-021: a task-operator proposal makes only the acceptable preference. -/
def proposalOnlyAcceptable (p : Production) : List Violation :=
  (proposedOps p).filterMap fun o =>
    if !((makesOn p o).any fun (a, v) => a == "task-operator" && rvConst v == some "true") then none
    else if p.acts.any (fun | .pref _ (.var o') k _ _ => o' == o && k != .acceptable | _ => false)
    then some ("W-TOP-021", p.name, "task-operator proposal also gives another preference")
    else none

/-- W-TOP-010, W-TOP-018: an MEA proposal (an operator with ^super-desired <d>) tests
^unachieved <d>, so it retracts when the desired is achieved. -/
def meaTestsUnachieved (p : Production) : List Violation :=
  (proposedOps p).filterMap fun o =>
    match ((makesOn p o).find? (·.1 == "super-desired")).bind (rvVar ·.2) with
    | none => none
    | some d =>
      if p.posPats.any (fun q => constOf q.attr == some "unachieved" && varOf q.val == some d) then none
      else some ("W-TOP-018", p.name, s!"MEA proposal for <{d}> does not test ^unachieved <{d}>")

/-- W-NAM-004: a task-operator proposal tests the problem-space name. -/
def testsProblemSpace (p : Production) : List Violation :=
  if !((proposedOps p).any fun o => (makesOn p o).any fun (a, v) => a == "task-operator" && rvConst v == some "true") then []
  else
    let sp := p.posPats.filterMap fun q => if constOf q.attr == some "problem-space" then varOf q.val else none
    if sp.any (fun v => p.posPats.any fun q => varOf q.id == some v && constOf q.attr == some "name") then []
    else [("W-NAM-004", p.name, "task-operator proposal does not test ^problem-space.name")]

/-- All rule conventions for task rules. -/
def taskRuleChecks : List (Production → List Violation) :=
  [reservedNames, taskOperatorFlag, argumentCount, desiredCount, oneProperty, internalApplyGuard,
   proposalOnlyAcceptable, meaTestsUnachieved, testsProblemSpace]

/-- Library rules are exempt from W-NAM-006 (they define the reserved operators). -/
def libraryRuleChecks : List (Production → List Violation) :=
  [taskOperatorFlag, argumentCount, desiredCount, oneProperty, internalApplyGuard,
   proposalOnlyAcceptable, meaTestsUnachieved]

def ruleViolations (checks : List (Production → List Violation)) (ps : List Production) : List Violation :=
  ps.flatMap fun p => checks.flatMap (· p)

/-! ## Working-memory conventions

Working memory is given as triples of printed symbols (`S1`, `^attr`, value), as Soar and the
specification print it. -/

abbrev Triple := String × String × String

def vals (wm : List Triple) (i a : String) : List String :=
  wm.filterMap fun (i', a', v) => if i' == i && a' == a then some v else none

/-- W-DBK-003: no desired is both achieved and unachieved. -/
def wmAchievedXor (wm : List Triple) : List Violation :=
  wm.filterMap fun (d, a, x) =>
    if a == "achieved" && (vals wm d "unachieved").contains x then
      some ("W-DBK-003", d, s!"{x} is both ^achieved and ^unachieved")
    else none

/-- W-DES-003: ^desired-count equals the number of ^desired. -/
def wmDesiredCount (wm : List Triple) : List Violation :=
  wm.filterMap fun (d, a, k) =>
    if a != "desired-count" then none else
    let n := (vals wm d "desired").length
    if toString n == k then none else some ("W-DES-003", d, s!"^desired-count {k} but {n} ^desired")

/-- W-REL-001: a world's ^on/^in relations have ^argument1 and ^argument2 (and
^argument-count 2 when given). -/
def wmRelations (wm : List Triple) : List Violation :=
  let worlds := (wm.filterMap fun (_, a, w) => if a == "world" then some w else none).eraseDups
  worlds.flatMap fun w =>
    (["on", "in"].flatMap fun r => vals wm w r).filterMap fun rel =>
      let ok := (vals wm rel "argument1").length == 1 && (vals wm rel "argument2").length == 1 &&
                ((vals wm rel "argument-count").all (· == "2"))
      if ok then none else some ("W-REL-001", rel, s!"relation of {w} lacks one ^argument1/^argument2")

/-- W-OBJ-002: object handles are unique within a world's objects. -/
def wmUniqueHandles (wm : List Triple) : List Violation :=
  let sets := (wm.filterMap fun (_, a, o) => if a == "objects" then some o else none).eraseDups
  sets.flatMap fun os =>
    let hs := (vals wm os "object").flatMap fun o => vals wm o "object-handle"
    (hs.filter fun h => (hs.filter (· == h)).length > 1).eraseDups.map fun h =>
      ("W-OBJ-002", os, s!"handle {h} used by two objects")

/-- W-TOP-013: an operator's ^argument-count equals its number of ^argumentN. -/
def wmArgumentCount (wm : List Triple) : List Violation :=
  wm.filterMap fun (o, a, k) =>
    if a != "argument-count" then none else
    if !(vals wm o "name").length.beq 1 then none else
    let n := ((wm.filter fun (i, a', _) => i == o && a'.startsWith "argument" && a' != "argument-count")).length
    if toString n == k then none else some ("W-TOP-013", o, s!"^argument-count {k} but {n} arguments")

def wmViolations (wm : List Triple) : List Violation :=
  wmAchievedXor wm ++ wmDesiredCount wm ++ wmRelations wm ++ wmUniqueHandles wm ++ wmArgumentCount wm

end World
