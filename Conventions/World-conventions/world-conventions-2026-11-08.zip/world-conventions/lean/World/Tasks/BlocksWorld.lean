import World.Compile
/-! A world-conventions description of the three-block Blocks World (Sussman anomaly). -/
namespace World.Tasks
open World

def moveBlock : TaskOp :=
  { name := "move-block", actionHandle := "move-block", params := ["b", "d"],
    paramTypes := [("b", "block")],
    pre := [.prop "b" "clear" (.bool true), .prop "d" "clear" (.bool true)],
    effects := [.moveRel "on" "b" ["d"]],
    mea := [ { item := .rel "on" ["b", "d"] },
             { item := .prop "u" "clear" (.bool true), locals := ["u"], binds := [⟨"on", ["b", "u"]⟩], fixed := [("d", "table")] } ] }

def blocksWorld (sel : Selection := .iterativeDeepening) (indiff : Bool := false) : Task :=
  { name := "blocks-world", space := "blocks-world",
    objects := [⟨"A", "block", []⟩, ⟨"B", "block", []⟩, ⟨"C", "block", []⟩, ⟨"table", "table", []⟩],
    relations := [⟨"on", ["C", "A"]⟩, ⟨"on", ["A", "table"]⟩, ⟨"on", ["B", "table"]⟩],
    goal := { items := [.rel "on" ["A", "B"], .rel "on" ["B", "C"], .rel "on" ["C", "table"]] },
    ops := [moveBlock],
    derived := [.always "clear" ["table"], .notArg "clear" "on" 2 ["block"]],
    caps := { selection := sel },
    indifferent := indiff }

/-- The description follows the world-conventions that `check` decides. -/
theorem blocksWorld_conventional : Conventional (blocksWorld) := by decide

end World.Tasks
