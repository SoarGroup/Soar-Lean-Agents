/-!
# World-conventions: the typed description of a task for agent-world

A task is described by its world (objects with handles and properties, relations between
objects), its goal (desireds), its task-action operators (preconditions as desireds, an action
handle, and internal effects for look-ahead), and the capacities it loads. The types build in
the world-conventions that are true of every well-formed description; `World.check`
(World/Check.lean) states the rest. Convention IDs refer to World-Conventions.xlsx.

Built into the types:
* W-OBJ-002: objects are named by a constant `handle`; desireds, relations and operators refer
  to objects only by handle.
* W-DES-005, W-DES-006: a desired is exactly one property of one object, or one relation, or
  holding one object (`DesiredItem`); it cannot combine several.
* W-DES-009: a relation desired names its arguments by handle.
* W-REL-001: a relation has an ordered argument list; `argument-count` is its length.
* W-TOP-004, W-TOP-012, W-TOP-013: a task-action operator has a name, an action handle, ordered
  arguments (so `argument-count` is their number), and precondition desireds.
* W-TOP-015: preconditions are always a desireds structure (possibly empty).
-/
namespace World

/-- A value of an object property. -/
inductive Val where
  | sym  : String → Val
  | int  : Int → Val
  | bool : Bool → Val
  deriving DecidableEq, Repr, Inhabited

def Val.toSoar : Val → String
  | .sym s => s
  | .int i => toString i
  | .bool b => if b then "true" else "false"

/-- A world object: its handle (W-OBJ-002), its class or type, and its properties. -/
structure Obj where
  handle : String
  type   : String
  props  : List (String × Val) := []
  deriving DecidableEq, Repr, Inhabited

/-- A relation on the world, `^<name>` with `^argument1 … ^argumentN` (W-REL-001). -/
structure Rel where
  name : String
  args : List String          -- object handles
  deriving DecidableEq, Repr, Inhabited

/-- One desired: exactly one thing to achieve (W-DES-005). Arguments are handles or, inside an
operator, parameter names (`Param`). -/
inductive DesiredItem where
  /-- `^desired.object (^object-handle h ^<prop> v)` (W-DES-006). -/
  | prop    : String → String → Val → DesiredItem
  /-- `^desired.<rel> (^argument1.object-handle a ^argument2.object-handle b)` (W-DES-009). -/
  | rel     : String → List String → DesiredItem
  /-- `^desired.holding-object.object-handle h` (`none` for an empty hand). -/
  | holding : String → DesiredItem
  deriving DecidableEq, Repr, Inhabited

def DesiredItem.handles : DesiredItem → List String
  | .prop h _ _ => [h]
  | .rel _ as => as
  | .holding h => if h == "none" then [] else [h]

/-- A desireds structure: conjunctive items (W-DES-001), disjunctive pairs (W-DES-013),
search-control marks (W-SCT-003) and the next goal set (W-DES-014). Indices refer to `items`. -/
structure Desireds where
  items      : List DesiredItem
  disjoint   : List (Nat × Nat) := []
  preferred  : List Nat := []
  avoid      : List Nat := []
  /-- Unknown objects named by a fake handle, constrained here (W-DES-011). -/
  context    : List Obj := []
  /-- The goal sets to pursue after this one, in order (W-DES-014). -/
  next       : List (List DesiredItem) := []
  deriving Repr, Inhabited

/-- An effect of an operator in look-ahead (its internal application, W-APP-010).
Arguments are parameter names. -/
inductive Effect where
  | setProp : String → String → Val → Effect          -- param, property, new value
  | addRel  : String → List String → Effect           -- relation name, params
  | delRel  : String → List String → Effect
  /-- Remove the relation `name(p₁, *)` and add `name(p₁, p₂…)`: move an argument. -/
  | moveRel : String → String → List String → Effect
  | setHolding : String → Effect                      -- param, or "none"
  deriving DecidableEq, Repr, Inhabited

/-- A derived object property, elaborated on every world (real and look-ahead copies). -/
inductive Derived where
  /-- `prop true` on every object of the given types. -/
  | always : String → List String → Derived
  /-- `prop true` on objects of the given types that are not argument `k` (1-based) of any
  relation `rel` in the world (e.g. clear: not argument 2 of any on). -/
  | notArg : String → String → Nat → List String → Derived
  deriving DecidableEq, Repr, Inhabited

/-- One MEA proposal of an operator: the desired it achieves (over parameter names), world
relations that bind the remaining parameters, and parameters fixed to object handles. -/
structure Mea where
  item  : DesiredItem
  /-- Objects the proposal names besides the parameters (bound by `binds`). -/
  locals : List String := []
  binds : List Rel := []
  fixed : List (String × String) := []
  deriving DecidableEq, Repr, Inhabited

/-- Which desired kinds an operator achieves: the MEA link from a desired to the operator that
is proposed for it (W-TOP-010, W-TOP-018). The item uses the operator's parameter names. -/
structure Achieves where
  item : DesiredItem
  deriving DecidableEq, Repr, Inhabited

/-- A task-action operator (TAO, W-TOP-004). Parameters are bound to world objects; the
precondition desireds and effects are written over parameter names. -/
structure TaskOp where
  name         : String
  actionHandle : String
  params       : List String
  /-- Parameter → required object type. -/
  paramTypes   : List (String × String) := []
  pre          : List DesiredItem := []
  effects      : List Effect := []
  /-- The desireds this operator is proposed for (one MEA proposal rule each). -/
  achieves     : List DesiredItem := []
  /-- The MEA proposals (one rule each); `achieves` lists their items. -/
  mea          : List Mea := []
  deriving Repr, Inhabited

def TaskOp.allAchieves (o : TaskOp) : List DesiredItem := o.achieves ++ o.mea.map (·.item)

/-- A composite operator (W-COP-001/W-COP-002): preconditions, and for a complex one the
effect desireds achieved in its implementation substate. -/
structure CompOp where
  name     : String
  params   : List String
  pre      : List DesiredItem
  effectDesireds : List DesiredItem := []
  achieves : List DesiredItem := []
  deriving Repr, Inhabited

/-- The selection library loaded for ties. -/
inductive Selection where
  | none
  | base               -- selection
  | world              -- selection-world
  | iterativeDeepening -- selection-iterative-deepening (needs selection-world)
  deriving DecidableEq, Repr, Inhabited

inductive IterStep where | tieImpasse | operator
  deriving DecidableEq, Repr, Inhabited
inductive InitDepth where | one | unachievedDesireds
  deriving DecidableEq, Repr, Inhabited

/-- The capacities the task loads and the flags they read (W-FLG-*, C rows). -/
structure Capacities where
  selection    : Selection := .iterativeDeepening
  mea          : Bool := true
  desiredPrefs : Bool := false
  gpsOrdering  : Bool := false
  useTimers    : Bool := false
  iterStep     : IterStep := .tieImpasse
  initDepth    : InitDepth := .unachievedDesireds
  deriving Repr, Inhabited

/-- A task for agent-world. -/
structure Task where
  name        : String
  /-- The task's problem-space name (W-NAM-004). -/
  space       : String
  objects     : List Obj
  relations   : List Rel
  goal        : Desireds
  ops         : List TaskOp
  composites  : List CompOp := []
  caps        : Capacities := {}
  derived     : List Derived := []
  /-- Give tied task operators indifferent preferences (random choice) instead of look-ahead. -/
  indifferent : Bool := false
  deriving Repr, Inhabited

end World
