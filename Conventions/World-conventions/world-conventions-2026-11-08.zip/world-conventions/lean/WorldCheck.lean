import World
import Soar.Parse
/-! `worldcheck (--task F | --lib F | --wm F)…`: world-convention violations of rule files
(task rules or library rules) and of working-memory dumps (lines `(id ^attr value …)`). -/
open World Soar

def parseWM (src : String) : List Triple := Id.run do
  let mut out := #[]
  let mut cur := ""
  for line in src.splitOn "\n" do
    let l := (line.trimAscii.toString.dropWhile (· == '(')).toString
    let l := if l.endsWith ")" then (l.dropEnd 1).toString else l
    let ws := (l.splitOn " ").filter (· != "")
    let ws := match ws with
      | w :: rest => if w.startsWith "^" then cur :: w :: rest else w :: rest
      | [] => []
    match ws with
    | id :: rest =>
      cur := id
      let mut attr := ""
      for w in rest do
        if w.startsWith "^" then attr := (w.drop 1).toString
        else if attr != "" && w != "+" then out := out.push (id, attr, w)
    | [] => pure ()
  let mut seen : Std.HashSet Triple := {}
  let mut res := #[]
  for x in out do
    if !seen.contains x then
      seen := seen.insert x
      res := res.push x
  return res.toList

def main (args : List String) : IO UInt32 := do
  let mut total := 0
  for (flag, f) in args.zip (args.drop 1) do
    if !(flag == "--task" || flag == "--lib" || flag == "--wm") then continue
    let src ← IO.FS.readFile f
    let vs ← if flag == "--wm" then pure (wmViolations (parseWM src)) else
      match Parse.parseFile src with
      | .ok ps => pure (ruleViolations (if flag == "--task" then taskRuleChecks else libraryRuleChecks) ps)
      | .error e => do IO.eprintln s!"{f}: {e}"; pure []
    IO.println s!"== {f} ({flag.drop 2}): {vs.length} violations"
    for (cid, w, m) in vs do IO.println s!"{cid}\t{w}\t{m}"
    total := total + vs.length
  return if total == 0 then 0 else 1
