import Agent.DSL
/-!
# Task-level meaning of a description

A small interpreter for the task a description defines, independent of Soar: states are the
objects' attribute values, an operator instance is an operator with objects for its parameters,
and applying it runs the first case whose guard holds. Used before any Soar is generated, to
check that the goal is reachable, how short a solution can be, and that invariants hold in every
reachable state. (These are properties of the task, not of the Soar agents; the generated agents
are compared with the originals separately.)
-/
namespace Agent

/-- An object: its holder attribute and its attribute values (derived ones included). -/
abbrev Obj := List (String × Int)
/-- A state: the objects, in a fixed order. -/
abbrev TState := List Obj

/-- A value parameter is bound in an environment as a pseudo-object with this one attribute. -/
def valAttr : String := "#value"

/-- The pseudo-attribute holding an object's index while expressions are evaluated: a link's value
is the index of the object it points to. -/
def idAttr : String := "#id"

/-- Parameter bindings as seen by expressions: each object with its index (`#id`). -/
def envObjs (env : List (String × (Nat × Obj))) : List (String × Obj) :=
  env.map fun (p, (i, ob)) => (p, ob ++ [(idAttr, (i : Int))])

def Expr.eval (env : List (String × Obj)) : Expr → Int
  | .lit n => n
  | .get o a => ((env.lookup o).bind (·.lookup a)).getD 0
  | .add x y => x.eval env + y.eval env
  | .sub x y => x.eval env - y.eval env
  | .val p => ((env.lookup p).bind (·.lookup valAttr)).getD 0
  | .mul x y => x.eval env * y.eval env
  | .div x y => Int.tdiv (x.eval env) (y.eval env)
  | .obj p => ((env.lookup p).bind (·.lookup idAttr)).getD (-1)

def Atom.eval (env : List (String × Obj)) : Atom → Int
  | .lit n => n
  | .get o a => ((env.lookup o).bind (·.lookup a)).getD 0
  | .val p => ((env.lookup p).bind (·.lookup valAttr)).getD 0
  | .obj p => ((env.lookup p).bind (·.lookup idAttr)).getD (-1)

def Cmp.holds : Cmp → Int → Int → Bool
  | .eq, a, b => a == b | .ne, a, b => a != b | .lt, a, b => a < b
  | .le, a, b => a ≤ b | .gt, a, b => a > b | .ge, a, b => a ≥ b

/-- `env` binds parameter names to object indices and their values; `hold` gives the task state's
single-valued object attributes (attribute ↦ object index); `lk i attr` is the object that object
`i`'s static link `attr` points to. -/
def Guard.satL (env : List (String × (Nat × Obj))) (hold : List (String × Nat))
    (lk : Nat → String → List Nat) (objsOf : String → List Obj) : Guard → Bool
  | .cmp o a op r =>
    let e := envObjs env
    op.holds (((env.lookup o).bind (·.2.lookup a)).getD 0) (r.eval e)
  | .distinct a b => (env.lookup a).map (·.1) != (env.lookup b).map (·.1)
  | .holds attr p => hold.lookup attr == (env.lookup p).map (·.1)
  | .unset attr => (hold.lookup attr).isNone
  | .link a attr b => match env.lookup a, env.lookup b with
    | some (i, ob), some (j, _) => (lk i attr).contains j || ob.lookup attr == some (j : Int)
    | _, _ => false
  | .vcmp e op n => op.holds (e.eval (envObjs env)) n
  | .noneSuch ty cs =>
    let e := envObjs env
    !(objsOf ty).any fun x => cs.all fun (a, op, r) => op.holds ((x.lookup a).getD 0) (r.eval e)

def Guard.satH (env : List (String × (Nat × Obj))) (hold : List (String × Nat)) (g : Guard) : Bool :=
  Guard.satL env hold (fun _ _ => []) (fun _ => []) g

/-- Guards in the abstract task, where every task-state object attribute is unset. -/
def Guard.sat (env : List (String × (Nat × Obj))) (g : Guard) : Bool := Guard.satH env [] g

/-- Recompute derived attributes of every object. -/
def Agent.derived (ag : Agent) (st : TState) : TState :=
  st.map fun ob =>
    let base := ob.filter fun (a, _) => !ag.derive.any (·.attr == a)
    base ++ ag.derive.map fun d => (d.attr, d.val.eval [("self", base)])

/-- Links that operators change (an effect sets them to a parameter's object): kept in the state,
as the index of the object they point to. Other links are static (`linkOf`). -/
def Agent.mutableLinks (ag : Agent) : List String :=
  let cases := ag.ops.flatMap fun o => o.apply ++ match o.impl with | .sub xs => xs.flatMap (·.apply) | _ => []
  (cases.flatMap fun c => c.effects.filterMap fun e => match e.val with | .obj _ => some e.attr | _ => none).eraseDups

def Agent.initial (ag : Agent) : TState :=
  let ml := ag.mutableLinks
  let n0 := ag.init.length
  ag.derived (ag.init.map (·.2) ++ ag.objs.map fun o =>
    o.vals ++ o.links.filterMap fun (a, tgt) =>
      if ml.contains a then (ag.objs.findIdx? (·.name == tgt)).map fun j => (a, ((n0 + j : Nat) : Int)) else none)

/-- The name of object `i`, if it is a named object. -/
def Agent.nameOf (ag : Agent) (i : Nat) : Option String :=
  if i < ag.init.length then none else (ag.objs[i - ag.init.length]?).map (·.name)

/-- Static links: the objects object `i`'s link `attr` points to (named objects only; several for
a multi-valued link such as a cell's neighbours). -/
def Agent.linkOf (ag : Agent) (i : Nat) (attr : String) : List Nat :=
  if i < ag.init.length || ag.mutableLinks.contains attr then [] else
  (((ag.objs[i - ag.init.length]?).map (·.links)).getD []).filterMap fun (a, tgt) =>
    if a == attr then (ag.objs.findIdx? (·.name == tgt)).map (ag.init.length + ·) else none

/-- Parameter assignments: objects (by index) for each parameter in turn. -/
def assignments (st : TState) : List (String × String) → List (List (String × (Nat × Obj)))
  | [] => [[]]
  | (p, _) :: ps =>
    (assignments st ps).flatMap fun rest =>
      (List.range st.length).filterMap fun i => st[i]?.map fun ob => (p, (i, ob)) :: rest

/-- The state attribute holding object `i`: initial objects by position; created objects record
their holder (`#h`, its index among the state attributes). -/
def Agent.holderAt (ag : Agent) (st : TState) (i : Nat) : Option String :=
  let holders := ag.init.map (·.1) ++ ag.objs.map (·.holder)
  if i < holders.length then holders[i]? else
  ((st[i]?).bind (·.lookup "#h")).bind fun k => (ag.schema.stateAttrs[k.toNat]?).map (·.name)

/-- The holder of every object of a state, in order (computed once). -/
def Agent.holdersOf (ag : Agent) (st : TState) : List (Option String) :=
  let holders := ag.init.map (·.1) ++ ag.objs.map (·.holder)
  let n := holders.length
  holders.map some ++ (st.drop n).map fun ob =>
    (ob.lookup "#h").bind fun k => (ag.schema.stateAttrs[k.toNat]?).map (·.name)

/-- Parameter assignments in which each parameter ranges only over the objects of its type (those
held by its type's state attribute). -/
def assignmentsT (ag : Agent) (st : TState) : List (String × String) → List (List (String × (Nat × Obj)))
  | [] => [[]]
  | (p, t) :: ps =>
    let h := (ag.schema.holder? t).map (·.name)
    let hs := ag.holdersOf st
    let mine := ((st.zip hs).zip (List.range st.length)).filterMap fun ((ob, hh), i) =>
      if hh == h then some (i, ob) else none
    (assignmentsT ag st ps).flatMap fun rest => mine.map fun (i, ob) => (p, (i, ob)) :: rest

/-- Value-parameter bindings (pseudo-objects, see `valAttr`) for each combination of values. -/
def valEnvs (o : Operator) : List (List (String × (Nat × Obj))) :=
  if o.vparams.isEmpty then [[]] else
  o.combos.map fun vals => vals.map fun (p, v) => (p, (1000000, [(valAttr, v)]))

/-- The objects of type `t` in a state (those held by `t`'s state attribute). -/
def Agent.objsOf (ag : Agent) (st : TState) (t : String) : List Obj :=
  let h := (ag.schema.holder? t).map (·.name)
  (st.zip (ag.holdersOf st)).filterMap fun (ob, hh) => if hh == h then some ob else none

/-- A case's changes: its effects and the objects it makes, every value read from `st` (before
the change). New objects are appended (their holder recorded as `#h`); effects may link to them. -/
def Agent.applyEffs (ag : Agent) (env : List (String × (Nat × Obj))) (st : TState) (c : Case) : TState :=
  let n := st.length
  let newEnv := (c.creates.zip (List.range c.creates.length)).map fun (no, k) => (no.var, (n + k, ([] : Obj)))
  let env' := env ++ newEnv
  let e := envObjs env'
  let made : List Obj := c.creates.map fun no =>
    no.vals.map (fun (a, v) => (a, v.eval e)) ++
      [("#h", (((ag.schema.stateAttrs.findIdx? (·.name == no.holder)).getD 0 : Nat) : Int))]
  let st1 := st ++ made
  c.effects.foldl (fun s ef =>
    match env'.lookup ef.obj with
    | some (i, _) => s.modify i fun ob => (ob.filter (·.1 != ef.attr)) ++ [(ef.attr, ef.val.eval e)]
    | none => s) st1

/-- The states reachable in one operator application, each with the instance's label. -/
def Agent.succ (ag : Agent) (st : TState) : List (String × TState) :=
  ag.ops.flatMap fun o =>
    ((assignmentsT ag st o.params).flatMap fun env => (valEnvs o).map (env ++ ·)).filterMap fun env =>
      if o.propose.all (Guard.satL env [] ag.linkOf (ag.objsOf st)) &&
          (o.proposeOr.isEmpty || o.proposeOr.any (·.all (Guard.satL env [] ag.linkOf (ag.objsOf st)))) then
        (o.apply.find? fun c => c.guard.all (Guard.satL env [] ag.linkOf (ag.objsOf st))).map fun c =>
          let st' := ag.applyEffs env st c
          (o.name ++ "(" ++ ",".intercalate (env.map fun (_, (i, ob)) =>
              if i == 1000000 then toString ((ob.lookup valAttr).getD 0) else toString i) ++ ")",
           ag.derived st')
      else none

def ObjPat.matches (p : ObjPat) (ob : Obj) : Bool := p.all fun (a, v) => ob.lookup a == some v

def Agent.isGoal (ag : Agent) (st : TState) : Bool :=
  let n0 := ag.init.length
  let idx (nm : String) : Option Nat := (ag.objs.findIdx? (·.name == nm)).map (n0 + ·)
  if !ag.goal.links.isEmpty then
    ag.goal.links.all fun (a, attr, b) => match idx a, idx b with
      | some i, some j => ((st[i]?).bind (·.lookup attr)) == some (j : Int)
      | _, _ => false
  else if !ag.goal.each.isEmpty then
    let os := ag.objsOf st ag.goal.ty
    ag.goal.each.all fun p => os.any p.matches
  else if ag.goal.all then
    let os := ag.objsOf st ag.goal.ty
    !os.isEmpty && os.all ag.goal.vals.matches
  else
  (List.range st.length).any fun i =>
    (st[i]?.map ag.goal.vals.matches).getD false &&
      (ag.goal.name.isNone || ag.nameOf i == ag.goal.name)

/-- The object type of each object position (objects are never created or removed by operators). -/
def Agent.objTypes (ag : Agent) : List String :=
  (ag.init.map (·.1) ++ ag.objs.map (·.holder)).map fun h =>
    match (ag.schema.stateAttrs.find? (·.name == h)).map (·.ty) with
    | some (VType.obj t) => t | _ => ""

/-- A failure state: some object satisfies a failure guard (`Agent.failure`). -/
def Agent.isFailure (ag : Agent) (st : TState) : Bool :=
  (List.range st.length).any fun i =>
    match st[i]?, ag.objTypes[i]? with
    | some ob, some t => ag.failure.any fun f => f.ty == t && f.guard.all (Guard.sat [("self", (i, ob))])
    | _, _ => false

/-- Normal form of a state for duplicate detection: objects with sorted attributes. -/
def norm (st : TState) : List (List (String × Int)) :=
  st.map fun ob => ob.mergeSort (fun a b => a.1 ≤ b.1)

/-- Breadth-first search to depth `n`: a shortest plan to the goal, if one exists within `n`
steps, and the number of distinct states seen. -/
def Agent.bfs (ag : Agent) (n : Nat) : Option (List String) × Nat :=
  let rec go : Nat → List (TState × List String) → List (List (List (String × Int))) →
      Option (List String) × Nat
    | 0, _, seen => (none, seen.length)
    | k + 1, frontier, seen =>
      match frontier.find? (fun (s, _) => ag.isGoal s) with
      | some (_, plan) => (some plan.reverse, seen.length)
      | none =>
        let (next, seen') := frontier.foldl (fun (acc, sn) (s, plan) =>
          (ag.succ s).foldl (fun (acc, sn) (lbl, s') =>
            if sn.contains (norm s') then (acc, sn) else (acc ++ [(s', lbl :: plan)], sn ++ [norm s']))
            (acc, sn)) ([], seen)
        if next.isEmpty then (none, seen'.length) else go k next seen'
  go n [(ag.initial, [])] [norm ag.initial]

/-- The first goal state that breadth-first search to depth `n` reaches, if any (for tasks that
compute something: the state holds the answer). -/
def Agent.bfsGoal (ag : Agent) (n : Nat) : Option TState :=
  let rec go : Nat → List TState → List (List (List (String × Int))) → Option TState
    | 0, _, _ => none
    | k + 1, frontier, seen =>
      match frontier.find? ag.isGoal with
      | some s => some s
      | none =>
        let (next, seen') := frontier.foldl (fun (acc, sn) s =>
          (ag.succ s).foldl (fun (acc, sn) (_, s') =>
            if sn.contains (norm s') then (acc, sn) else (acc ++ [s'], sn ++ [norm s'])) (acc, sn))
          ([], seen)
        if next.isEmpty then none else go k next seen'
  go n [ag.initial] [norm ag.initial]

/-- Breadth-first search to depth `n` in the task where failure states are dead ends (never
entered): a shortest plan that avoids them, and the number of distinct states seen. -/
def Agent.bfsSafe (ag : Agent) (n : Nat) : Option (List String) × Nat :=
  let rec go : Nat → List (TState × List String) → List (List (List (String × Int))) →
      Option (List String) × Nat
    | 0, _, seen => (none, seen.length)
    | k + 1, frontier, seen =>
      match frontier.find? (fun (s, _) => ag.isGoal s) with
      | some (_, plan) => (some plan.reverse, seen.length)
      | none =>
        let (next, seen') := frontier.foldl (fun (acc, sn) (s, plan) =>
          (ag.succ s).foldl (fun (acc, sn) (lbl, s') =>
            if ag.isFailure s' || sn.contains (norm s') then (acc, sn)
            else (acc ++ [(s', lbl :: plan)], sn ++ [norm s']))
            (acc, sn)) ([], seen)
        if next.isEmpty then (none, seen'.length) else go k next seen'
  go n [(ag.initial, [])] [norm ag.initial]

/-- Every reachable state (failure states included) satisfies the whole-state predicate `inv`;
`true` only if the search exhausts the state space within `n` steps. -/
def Agent.invariantS (ag : Agent) (n : Nat) (inv : TState → Bool) : Bool :=
  let rec go : Nat → List TState → List (List (List (String × Int))) → Bool
    | 0, fr, _ => fr.isEmpty
    | k + 1, fr, seen =>
      if !(fr.all inv) then false else
      let (next, seen') := fr.foldl (fun (acc, sn) s =>
        (ag.succ s).foldl (fun (acc, sn) (_, s') =>
          if sn.contains (norm s') then (acc, sn) else (acc ++ [s'], sn ++ [norm s'])) (acc, sn))
        ([], seen)
      if next.isEmpty then true else go k next seen'
  go n [ag.initial] [norm ag.initial]

/-- Every reachable state satisfies `inv`. `true` only if the search exhausts the state space
within `n` steps (otherwise `false`), so the result covers every reachable state. -/
def Agent.invariant (ag : Agent) (n : Nat) (inv : Obj → Bool) : Bool :=
  let rec go : Nat → List TState → List (List (List (String × Int))) → Bool
    | 0, fr, _ => fr.isEmpty
    | k + 1, fr, seen =>
      if !(fr.all (·.all inv)) then false else
      let (next, seen') := fr.foldl (fun (acc, sn) s =>
        (ag.succ s).foldl (fun (acc, sn) (_, s') =>
          if sn.contains (norm s') then (acc, sn) else (acc ++ [s'], sn ++ [norm s'])) (acc, sn))
        ([], seen)
      if next.isEmpty then true else go k next seen'
  go n [ag.initial] [norm ag.initial]


/-- Every task constraint holds in every reachable state; `true` only if the search exhausts the
state space within `n` steps. -/
def Agent.constraintsHold (ag : Agent) (n : Nat) : Bool :=
  let ok (st : TState) : Bool :=
    (List.range st.length).all fun i =>
      match st[i]?, ag.objTypes[i]? with
      | some ob, some t => ag.constraints.all fun c => c.ty != t || c.guard.all (Guard.sat [("self", (i, ob))])
      | _, _ => true
  let rec go : Nat → List TState → List (List (List (String × Int))) → Bool
    | 0, fr, _ => fr.isEmpty
    | k + 1, fr, seen =>
      if !(fr.all ok) then false else
      let (next, seen') := fr.foldl (fun (acc, sn) s =>
        (ag.succ s).foldl (fun (acc, sn) (_, s') =>
          if sn.contains (norm s') then (acc, sn) else (acc ++ [s'], sn ++ [norm s'])) (acc, sn))
        ([], seen)
      if next.isEmpty then true else go k next seen'
  go n [ag.initial] [norm ag.initial]

/-- Apply a case's effects to the objects and to `hold`. -/
def applyCase (ag : Agent) (env : List (String × (Nat × Obj))) (st : TState) (hold : List (String × Nat))
    (c : Case) : TState × List (String × Nat) :=
  let st' := ag.applyEffs env st c
  let hold' := c.stateEffects.foldl (fun h (attr, v) =>
    let h := h.filter (·.1 != attr)
    match v.bind (env.lookup ·) with
    | some (i, _) => h ++ [(attr, i)]
    | none => h) hold
  (ag.derived st', hold')

/-- Run the sub-operators of `o` (bound by `env`) from `st` for at most `k` steps, until `o` is no
longer proposed: exactly one sub-operator instance (with its own parameters) must be proposed at
each step. The final state (with any objects the sub-operators made), or `none`. -/
def Agent.runSub (ag : Agent) (o : Operator) (subs : List SubOp) (env : List (String × (Nat × Obj))) (st : TState) (k : Nat) :
    Option TState :=
  -- substate-local attributes (`local`): a pseudo-object that exists only during the run
  let e0 := envObjs env
  let loc0 : Obj := o.locals.map fun (a, ex) => (a, ex.eval e0)
  let rec run : Nat → TState → List (String × Nat) → Obj → Option TState
    | 0, _, _, _ => none
    | j + 1, s, h, loc =>
      let env' := env.map (fun (p, (i, _)) => (p, (i, (s[i]?).getD []))) ++
        (if o.locals.isEmpty then [] else [("local", (999999, loc))])
      let proposed := o.propose.all (Guard.satH env' h) || o.proposeAlt.any (·.all (Guard.satH env' h))
      if !proposed then (if h.isEmpty then some s else none) else
      -- each sub-operator with each binding of its own parameters
      let cands := subs.flatMap fun x =>
        (assignmentsT ag s x.params).filterMap fun sub =>
          let env'' := env' ++ sub
          let sat := fun (g : Guard) => Guard.satL env'' h ag.linkOf (ag.objsOf s) g
          if x.propose.all sat then some (x, env'') else none
      match cands with
      | [(x, env'')] =>
        let sat := fun (g : Guard) => Guard.satL env'' h ag.linkOf (ag.objsOf s) g
        match x.apply.find? (·.guard.all sat) with
        | some c' =>
          let (s', h') := applyCase ag env'' s h c'
          let e' := envObjs env''
          let loc' := c'.effects.foldl (fun l ef => if ef.obj == "local" then
              (l.filter (·.1 != ef.attr)) ++ [(ef.attr, ef.val.eval e')] else l) loc
          run j s' h' loc'
        | none => none
      | _ => none
  run k st [] loc0

/-- Refinement of operators carried out by sub-operators: from every reachable state of the
abstract task (within `n` steps) and every instance of such an operator that is proposed there,
run its sub-operators (at most `k` steps). The result must equal the operator's own specified
effect, with every task-state object attribute unset again. Objects made by sub-operators are not
part of the specified effect: the comparison is over the objects that existed before. -/
def Agent.refinesSub (ag : Agent) (n k : Nat) : Bool :=
  let reach : List TState :=
    let rec go : Nat → List TState → List TState → List TState
      | 0, _, seen => seen
      | m + 1, fr, seen =>
        let next := fr.flatMap (fun s => (ag.succ s).map (·.2)) |>.filter (fun s => !(seen.any (norm · == norm s)))
        let next := next.foldl (fun acc s => if acc.any (norm · == norm s) then acc else acc ++ [s]) []
        if next.isEmpty then seen else go m next (seen ++ next)
    go n [ag.initial] [ag.initial]
  reach.all fun st => ag.ops.all fun o => match o.impl with
    | .sub subs =>
      (assignments st o.params).all fun env =>
        if !(o.propose.all (Guard.sat env)) then true else
        match o.apply.find? (fun c => c.guard.all (Guard.sat env)) with
        | none => false
        | some c =>
          let (want, _) := applyCase ag env st [] c
          match ag.runSub o subs env st k with
          | some s => norm (s.take want.length) == norm want
          | none => false
    | _ => true

/-- Run the agent concretely: in each state exactly one operator instance must be proposed; an
operator carried out by sub-operators is run through them (at most `k` steps), and its result must
agree with its specified effect on the objects that existed before (objects it makes are added).
The final state when the goal holds (within `n` operators), or `none`. For tasks whose later
operators read objects made by earlier ones (Pyramid's two phases), which the abstract task —
where operators make no objects — cannot show. -/
def Agent.runConcrete (ag : Agent) (n k : Nat) : Option TState :=
  let rec go : Nat → TState → Option TState
    | 0, _ => none
    | m + 1, st =>
      if ag.isGoal st then some st else
      let cands := ag.ops.flatMap fun o =>
        (assignmentsT ag st o.params).filterMap fun env =>
          if o.propose.all (Guard.satL env [] ag.linkOf (ag.objsOf st)) then
            (o.apply.find? (·.guard.all (Guard.satL env [] ag.linkOf (ag.objsOf st)))).map (o, env, ·)
          else none
      match cands with
      | [(o, env, c)] =>
        let (want, _) := applyCase ag env st [] c
        match o.impl with
        | .sub subs =>
          match ag.runSub o subs env st k with
          | some s => if norm (s.take want.length) == norm want then go m (ag.derived s) else none
          | none => none
        | _ => go m want
      | _ => none
  go n ag.initial

/-! ## Following the search-control preferences

For a variant whose preference rules (`Agent.prefs`) leave exactly one operator in every state,
`runPrefs` follows them as Soar's decision procedure would (best restricts the candidates to the
best ones, worst removes the worst ones when others remain) and counts the operators applied until
the goal. `none` when some state leaves several candidates (a random choice) or none. -/

abbrev Env := List (String × (Nat × Obj))

/-- Operator instances applicable in a state, with their bindings and the next state. -/
def Agent.instances (ag : Agent) (st : TState) : List (Operator × Env × TState) :=
  ag.ops.flatMap fun o =>
    ((assignmentsT ag st o.params).flatMap fun env => (valEnvs o).map (env ++ ·)).filterMap fun env =>
      if o.propose.all (Guard.satL env [] ag.linkOf (ag.objsOf st)) &&
          (o.proposeOr.isEmpty || o.proposeOr.any (·.all (Guard.satL env [] ag.linkOf (ag.objsOf st)))) then
        (o.apply.find? fun c => c.guard.all (Guard.satL env [] ag.linkOf (ag.objsOf st))).map fun c =>
          let st' := ag.applyEffs env st c
          (o, env, ag.derived st')
      else none

/-- What a binding denotes: an object (its index) or a value. -/
def bindId (b : Nat × Obj) : Nat × Int := (b.1, (b.2.lookup valAttr).getD 0)

def Agent.prefApplies (ag : Agent) (st : TState) (last : Option (String × Env)) (p : Pref)
    (o : Operator) (env : Env) : Bool :=
  let sat (e : Env) (g : Guard) := Guard.satL e [] ag.linkOf (ag.objsOf st) g
  p.op == o.name &&
  (match p.failure with | none => true | some b => ag.isFailure st == b) &&
  p.guard.all (sat env) &&
  (if p.sameAsLast.isEmpty && p.lastGuard.isEmpty then true else
   match last with
   | none => false
   | some (ln, lenv) =>
     -- the last operator's objects as they are now
     let lenv := lenv.map fun (q, (i, ob)) => (q, (i, if i == 1000000 then ob else (st[i]?).getD ob))
     ln == p.op &&
     p.sameAsLast.all (fun (x, y) => (env.lookup x).map bindId == (lenv.lookup y).map bindId) &&
     p.lastGuard.all (sat (lenv.map fun (q, b) => ("last-" ++ q, b))))

/-- The one operator the preferences leave, if exactly one remains. -/
def Agent.prefChoice (ag : Agent) (st : TState) (last : Option (String × Env)) :
    Option (Operator × Env × TState) :=
  let has (v : HVal) (c : Operator × Env × TState) := ag.prefs.any fun p =>
    !p.inLookahead && p.value == v && ag.prefApplies st last p c.1 c.2.1
  let cands := (ag.instances st).filter (!has .reject ·)
  let bests := cands.filter (has .best)
  let c1 := if bests.isEmpty then cands else bests
  let nonWorst := c1.filter (!has .worst ·)
  match (if nonWorst.isEmpty then c1 else nonWorst) with
  | [c] => some c
  | _ => none

/-- Follow the preferences for at most `n` operators: the number applied when the goal holds. -/
def Agent.runPrefs (ag : Agent) (n : Nat) : Option Nat :=
  let rec go : Nat → TState → Option (String × Env) → Nat → Option Nat
    | 0, _, _, _ => none
    | k + 1, st, last, m =>
      if ag.isGoal st then some m else
      match ag.prefChoice st last with
      | some (o, env, st') => go k st' (some (o.name, env)) (m + 1)
      | none => none
  go n ag.initial none 0

end Agent
