import Agent.DSL
import Agent.Sem
/-!
# Towers of Hanoi — one parameterized description for the family

Derived on 7 November 2026 from the Towers of Hanoi task agents in the agent library, limited to
five disks on three pegs (JL, 7 Nov 2026). The originals use 11 disks (recur V1: 7).

The task: five disks of sizes 1–5 are stacked on peg A, the largest at the bottom; move them all to
peg C, one at a time, never putting a disk on a smaller one.

Methods in the originals:
* iterative (towers-of-hanoi V1/V2, -fast V1/V2, -faster V1/V2): disk 1 moves round the pegs and
  never back to the peg it last left; every other move is the one legal move of another disk. One
  operator is proposed at each step, so the solution takes 2ⁿ − 1 moves with no search. `fast`
  maintains `clear` and `upper-disk` in apply rules instead of elaborating them; `faster` also
  drops the last-disk bookkeeping for disk 1's moves. Variant `towers-of-hanoi`.
-/
namespace Agent.Hanoi

def diskT : String := "disk"
def pegT : String := "peg"
def holdsT : String := "holds"
def controlT : String := "control"

def schema (task : String) : Schema where
  task := task
  stateAttrs := [
    { name := "disk", ty := .obj diskT, multi := true, doc := "The disks, and a base under each peg." },
    { name := "peg", ty := .obj pegT, multi := true, doc := "The three pegs." },
    { name := "holds", ty := .obj holdsT, multi := true, doc := "Where each disk is: one record per disk (and per base)." },
    { name := "control", ty := .obj controlT, multi := true, doc := "The iterative method's memory of the last move." }]
  types := [
    { name := diskT, key := some "size",
      attrs := [
        { name := "name", ty := .sym [], doc := "1–5, base-A, base-B, base-C, ground" },
        { name := "size", ty := .int, doc := "1–5; the bases 6, the ground 7" }] },
    { name := pegT,
      attrs := [{ name := "name", ty := .sym [], doc := "A, B, C" }] },
    { name := holdsT,
      attrs := [
        { name := "name", ty := .sym [], doc := "h1–h5, h-base-A, h-base-B, h-base-C" },
        { name := "disk", ty := .obj diskT, doc := "the disk this record is about (never changes)" },
        { name := "on", ty := .obj pegT, doc := "the peg the disk is on" },
        { name := "above", ty := .obj diskT, doc := "the disk directly below it (a base, for the bottom disk of a peg)" }] },
    { name := controlT,
      attrs := [
        { name := "name", ty := .sym [], doc := "control" },
        { name := "lastsize", ty := .int, doc := "the size of the disk moved last" },
        { name := "lastpeg", ty := .obj pegT, doc := "the peg disk 1 last moved from" }] }]

def g (o a : String) : Expr := .get o a
def eff (o a : String) (v : Expr) : Effect := { obj := o, attr := a, val := v }

/-- The move's legality, shared by the methods: `h` is the record of disk `d` (a real disk) on peg
`src`, with nothing on it; `t` is the record of the upper disk `td` of peg `target` (a base when
the peg is empty), and `td` is larger than `d`. -/
def legal (n : Nat) : List Guard := [
  .link "h" "disk" "d", .link "t" "disk" "td",
  .cmp "d" "size" .le (.lit n),
  .cmp "h" "on" .eq (.obj "src"), .distinct "src" "target",
  .noneSuch holdsT [("above", .eq, .obj "d")],
  .cmp "t" "on" .eq (.obj "target"),
  .noneSuch holdsT [("above", .eq, .obj "td")],
  .cmp "td" "size" .gt (.get "d" "size")]

def moveWrite : List Msg := [.text "Move Disk: ", .val (g "d" "size"), .text " to peg ", .val (g "target" "name")]

/-- The iterative method (towers-of-hanoi V1): after any other disk, move disk 1, not back to the
peg it last left; after disk 1, move the other disk that can move. -/
def moveIterative (n : Nat) : Operator where
  name := "move-disk"
  params := [("h", holdsT), ("d", diskT), ("t", holdsT), ("td", diskT), ("src", pegT), ("target", pegT), ("control", controlT)]
  propose := legal n
  proposeOr := [
    [.cmp "d" "size" .eq (.lit 1), .cmp "control" "lastsize" .ne (.lit 1), .cmp "control" "lastpeg" .ne (.obj "target")],
    [.cmp "d" "size" .gt (.lit 1), .cmp "control" "lastsize" .eq (.lit 1)]]
  apply := [
    { guard := [.cmp "d" "size" .eq (.lit 1)],
      effects := [eff "h" "on" (.obj "target"), eff "h" "above" (.obj "td"), eff "control" "lastsize" (g "d" "size"),
                  eff "control" "lastpeg" (.obj "src")],
      write := moveWrite },
    { guard := [.cmp "d" "size" .gt (.lit 1)],
      effects := [eff "h" "on" (.obj "target"), eff "h" "above" (.obj "td"), eff "control" "lastsize" (g "d" "size")],
      write := moveWrite }]
  doc := "Move a disk with nothing on it onto a larger disk or an empty peg, as the iterative method says."

def pegs : List String := ["A", "B", "C"]

/-- The objects: pegs, the disks and a base per peg (all on the ground), and where they are. -/
def objects (n : Nat) (lastPeg : String) : List Named :=
  pegs.map (fun p => { holder := "peg", name := p, vals := [] }) ++
  (List.range n).map (fun i => { holder := "disk", name := s!"{i+1}", vals := [("size", ((i + 1 : Nat) : Int))] }) ++
  pegs.map (fun p => { holder := "disk", name := s!"base-{p}", vals := [("size", ((n + 1 : Nat) : Int))] }) ++
  [{ holder := "disk", name := "ground", vals := [("size", ((n + 2 : Nat) : Int))] }] ++
  (List.range n).map (fun i =>
    { holder := "holds", name := s!"h{i+1}", vals := [],
      links := [("disk", s!"{i+1}"), ("on", "A"), ("above", if i + 1 == n then "base-A" else s!"{i+2}")] }) ++
  pegs.map (fun p =>
    let ls : List (String × String) := [("disk", "base-" ++ p), ("on", p), ("above", "ground")]
    ({ holder := "holds", name := "h-base-" ++ p, vals := [], links := ls } : Named)) ++
  [{ holder := "control", name := "control", vals := [("lastsize", 2)], links := [("lastpeg", lastPeg)] }]

def assumptions : List Assumption := [
  { id := "A1", text := "The task: five disks on peg A, to be moved to peg C one at a time, never onto a smaller disk (JL, 7 Nov 2026: five disks on three pegs; the originals have 11, recur V1 7)." },
  { id := "A2", text := "Representation: V1's `holds` records, one per disk, on the state, pointing to the disk, the peg it is on, and the disk directly below it (STA-030: a relation changed by operators is explicit on the state with pointers to its arguments). The disk's `on` and `above` change when it moves." },
  { id := "A3", text := "Each peg has a base under it: a disk larger than all the others, which never moves, with its own `holds` record above a ground disk. Moving onto an empty peg is then moving onto its base, so one case covers V1's three apply rules (target clear or not, source clear or not) and its `^clear`/`^upper-disk` elaborations become negated tests (`no record is above the disk`). V1 writes `^above none` for a bottom disk and elaborates `^clear` for an empty peg." },
  { id := "A4", text := "V1's `larger` elaboration (a static relation between disks) is a comparison of sizes." },
  { id := "A5", text := "Iterative method: V1's `^last-disk-moved` (a disk) and `^last-disk1-peg` (a peg) are a control object's `lastsize` (the size of the disk moved last) and `lastpeg`. As in V1 they start as disk 2 and peg B (for an odd number of disks), so disk 1 moves first, to C." },
  { id := "A6", text := "The goal is V1's: every disk on C (as `^desired` links). V1 also lists each disk's desired `above`; with all disks on C and no disk ever on a smaller one, the order follows." }]

def mk (task : String) (n : Nat) (ops : List Operator) (method : Method) : Agent where
  schema := schema task
  init := []
  objs := objects n "B"
  derive := []
  ops := ops
  goal := { ty := holdsT, vals := [], links := (List.range n).map fun i => (s!"h{i+1}", "on", "C") }
  method := method
  assumptions := assumptions

def variants : List (String × Agent × List String) := [
  ("towers-of-hanoi", mk "towers-of-hanoi" 5 [moveIterative 5] .random,
    ["towers-of-hanoi V1, V2", "towers-of-hanoi-fast V1, V2", "towers-of-hanoi-faster V1, V2"])]

def conventionsOk : Bool := variants.all (fun v => check v.2.1 == [])
theorem conventions : conventionsOk = true := by native_decide

/-- The iterative method solves five disks in 31 moves, the minimum. -/
def iterativeCheck : Bool := ((mk "towers-of-hanoi" 5 [moveIterative 5] .random).bfs 40).1.map List.length == some 31

theorem iterative_31 : iterativeCheck = true := by native_decide

end Agent.Hanoi
