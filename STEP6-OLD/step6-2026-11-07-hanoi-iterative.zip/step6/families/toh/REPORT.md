# Towers of Hanoi — step 6 (five disks, three pegs)

Lean: `agentgen/Agent/Families/Hanoi.lean`. JL, 7 Nov 2026: five disks on three pegs. The originals use 11 disks (recur V1: 7). The 6 Nov report, written when the family was skipped, is `REPORT-2026-11-06-skipped.md`.

Originals in the queue and their method:

| Originals | Method | Variant |
|---|---|---|
| towers-of-hanoi V1, V2; -fast V1, V2; -faster V1, V2 | iterative: disk 1 moves round the pegs, never back to the peg it last left; every other move is the one legal move of another disk | `towers-of-hanoi` (done) |
| towers-of-hanoi-recursive V1, V2; -recur V1 | means-ends analysis by operator subgoaling | next |
| tower-of-hanoi-search V1 | look-ahead search | after that |
| towers-of-hanoi-no-ops V1 | no operators: elaborations solve the puzzle in one decision | not replaced (outside the conventions); replaced by `towers-of-hanoi` |

## Variant `towers-of-hanoi`

Representation:
- V1's `holds` records on the state: one per disk, pointing to the disk, its peg (`on`) and the disk directly below it (`above`). This follows STA-030.
- Each peg has a base under it: a disk larger than all the others that never moves, with its own record above a ground disk.
- Moving onto an empty peg is moving onto its base, so one case covers V1's three apply rules and its `^clear`/`^upper-disk` elaborations. "Upper disk" is a negated test: no record is above it.
- A control object holds the size of the disk moved last and the peg disk 1 last left. These are V1's `^last-disk-moved` and `^last-disk1-peg`, starting as disk 2 and peg B.

`move-disk(h, d, t, td, src, target, control)`:
- Proposed when disk d is upper on src and td is upper on target and larger than d, and either:
  - d is disk 1, the last disk moved was not disk 1, and target is not the peg disk 1 last left; or
  - d is not disk 1 and the last disk moved was disk 1.
- Exactly one move is proposed at each step.
- It writes "Move Disk: N to peg P", as V1's monitor does.

Goal: every disk on C (`^desired` links).

New general feature: a message may write a symbolic attribute as it is (here the peg's name). Every other family's output is unchanged.

Assumptions:
- A1: five disks.
- A2: `holds` records.
- A3: the bases.
- A4: `larger` is a size comparison.
- A5: the control object.
- A6: the goal is every disk on C.

Full texts are in the Lean file.

## Results (Soar 9.6.5, seeds 1–3)

The originals were run as five-disk copies, made by `tools/five.py` from the flattened originals. The script drops disks 6–11 and makes disk 5 the bottom; the copies are in `orig5/`. The -fast/-faster monitors are excised in the originals, so the harness adds a print-only monitor for them (`tools/monitor-constants.soar`).

| Agent | Solved | Decisions | Moves | Move sequence |
|---|---|---|---|---|
| `towers-of-hanoi` | 3/3 | 32 | 31 | 1C 2B 1B 3C 1A 2C 1C 4B … (the minimum, 31) |
| towers-of-hanoi V1, V2 | 3/3 | 32 | 31 | identical |
| towers-of-hanoi-fast V1, V2 | 3/3 | 31 | 31 | identical |
| towers-of-hanoi-faster V1, V2 | 3/3 | 31 | 31 | identical |
| towers-of-hanoi-no-ops V1 | 3/3 | 1 | — | no operators |
| towers-of-hanoi-recursive V1, V2 | 3/3 | 47 | 31 | 5C 4B 3C 2B 1C … (goal moves, in subgoal order) |

The -fast/-faster originals take one decision fewer because they have no initialize operator; their initial state is made by an elaboration.

Soar vs soar-lean (`leancmp/`): MATCH (32 decisions to halt, 108 WMEs).

Theorems:
- `conventions`.
- `iterative_31`: the iterative method solves five disks in 31 moves.
