"""Make a 5-disk copy of a flattened 11-disk (or 7-disk) Towers of Hanoi original: in every
production that mentions disks above 5, drop the disks 6.. (their holds, desired and goal-test
clauses and list tokens) and make disk 5 the bottom (`^above none`). Usage: five.py IN OUT"""
import re, sys
src, out = sys.argv[1], sys.argv[2]
text = open(src).read()
BIG = r'(?:6|7|8|9|10|11)'
def fix(p):
    if not re.search(rf'<(?:disk-|h|d){BIG}>', p): return p
    p = re.sub(rf'\^above <disk-{BIG}>', lambda m: '^above none' if m.group(0) == '^above <disk-6>' else m.group(0), p)
    p = p.replace('^disk 5 ^above 6', '^disk 5 ^above none')  # originals with constant disks
    lines = []
    for l in p.split('\n'):
        if re.match(rf'\s*\((?:<disk-|<h|<d){BIG}>', l):
            if l.rstrip().endswith('}'): lines.append('}')
            continue
        l = re.sub(rf'\s*\^[\w-]+ <(?:disk-|h|d){BIG}>', '', l)
        l = re.sub(rf'\s*<(?:disk-|h|d){BIG}>', '', l)
        lines.append(l)
    return '\n'.join(l for l in lines if l.strip() != '' or True)
parts = re.split(r'(?=^sp \{)', text, flags=re.M)
open(out, 'w').write(''.join(fix(p) for p in parts))
