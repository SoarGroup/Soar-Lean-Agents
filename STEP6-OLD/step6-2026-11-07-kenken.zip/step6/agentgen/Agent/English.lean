import Agent.DSL
/-!
# Template English for a description

One fixed sentence form per construct, so the English follows the Lean exactly; an LLM may
smooth it afterwards (blind to any original description), but each sentence here is the
reference. Formal points that fluent prose tends to hide are said explicitly: which attributes
are derived (and so retract), that an operator's changes are simultaneous, and when the agent
stops.
-/
namespace Agent

def Expr.en : Expr → String
  | .lit n => toString n
  | .get o a => s!"{o}.{a}"
  | .add x y => s!"{x.en} + {y.en}"
  | .sub x y => s!"{x.en} − {y.en}"
  | .val p => p
  | .mul x y => s!"({x.en}) × ({y.en})"
  | .div x y => s!"({x.en}) ÷ ({y.en}) (rounded towards zero)"
  | .obj p => p

def Msg.en : Msg → String
  | .text s => s
  | .val e => "⟨" ++ e.en ++ "⟩"

def msgEn (ms : List Msg) : String := "\"" ++ String.join (ms.map Msg.en) ++ "\""

def Cmp.en : Cmp → String
  | .eq => "=" | .ne => "≠" | .lt => "<" | .le => "≤" | .gt => ">" | .ge => "≥" | .lacks => "does not contain"

def Atom.en : Atom → String
  | .lit n => toString n
  | .get o a => s!"{o}.{a}"
  | .val p => p
  | .obj p => p

def Guard.en : Guard → String
  | .cmp o a op r => s!"{o}.{a} {op.en} {r.en}"
  | .distinct a b => s!"{a} and {b} are different objects"
  | .holds attr p => s!"the task state's `{attr}` is {p}"
  | .unset attr => s!"the task state has no `{attr}`"
  | .link a attr b => s!"{a}.{attr} is {b}"
  | .vcmp e op n => s!"{e.en} {op.en} {n}"
  | .noneSuch ty cs => s!"no {ty} has " ++ " and ".intercalate (cs.map fun (a, op, r) => s!"{a} {op.en} {r.en}")
  | .fewer p l ty cs k => s!"fewer than {k} {ty}s that {p}.{l} points to have " ++
      " and ".intercalate (cs.map fun (a, op, r) => s!"{a} {op.en} {r.en}")
  | .linked p l ty cs k => (if k == 0 then s!"no {ty} that {p}.{l} points to" else s!"at least {k} {ty}s that {p}.{l} points to") ++
      " have " ++ " and ".intercalate (cs.map fun (a, op, r) => s!"{a} {op.en} {r.en}")
  | .desired o attr t => s!"the goal has {o}.{attr} = {t}"
  | .flag o attr true => s!"{o} is {attr}"
  | .flag o attr false => s!"{o} is not {attr}"
  | .wants pred o none => s!"the subgoal wants {o} {pred}"
  | .wants pred o (some l) => s!"the subgoal wants {o}.{l} {pred}"

def guardsEn (gs : List Guard) : String :=
  if gs.isEmpty then "always" else " and ".intercalate (gs.map Guard.en)

def ObjPat.en (p : ObjPat) : String :=
  " and ".intercalate (p.map fun (k, v) => s!"{k} {v}")

def StatePat.en (p : StatePat) : String :=
  "; ".intercalate (p.objs.map fun o => s!"a {p.ty} with {ObjPat.en o}")

def VType.en : VType → String
  | .int => "an integer"
  | .sym cs => "one of " ++ ", ".intercalate cs
  | .obj t => s!"a {t}"

def HVal.en : HVal → String
  | .best => "best" | .worst => "worst" | .equal => "neutral (indifferent)" | .reject => "rejected"
  | .better => "better than every other proposed operator"

def english (a : Agent) : String := Id.run do
  let s := a.schema
  let mut out : List String := [s!"# {s.task}", "", "## The task", ""]
  -- schema
  for h in s.stateAttrs do
    out := out ++ [s!"The task state holds {if h.multi then "several values of" else "one value of"} " ++
      s!"`{h.name}`, each {h.ty.en}." ++ (if h.doc.isEmpty then "" else " " ++ h.doc)]
  for t in s.types do
    let base := t.attrs.filter (!·.derived)
    let der := t.attrs.filter (·.derived)
    out := out ++ ["", s!"A {t.name} has " ++ ", ".intercalate (base.map fun d => s!"`{d.name}` ({d.ty.en})") ++ "." ++
      (if t.doc.isEmpty then "" else " " ++ t.doc)]
    for d in der do
      match a.derive.find? (fun x => x.ty == t.name && x.attr == d.name) with
      | some x => out := out ++ [s!"Its `{d.name}` is derived: {x.val.en} (with `self` the {t.name}). " ++
          "It is recomputed whenever those values change and is never set directly."]
      | none => pure ()
  out := out ++ ["", "Initially the task state has:"]
  for (h, vals) in a.init do
    out := out ++ [s!"- a `{h}` with {ObjPat.en vals}"]
  for o in a.objs do
    out := out ++ [s!"- a `{o.holder}` named {o.name} with {ObjPat.en o.vals}" ++
      String.join (o.links.map fun (attr, tgt) => s!"; its `{attr}` is {tgt}")]
  if !a.objs.isEmpty then
    out := out ++ ["Links between objects never change."]
  for f in a.failure do
    out := out ++ ["", s!"**Failure state.** A state is a failure state when some {f.ty} has {guardsEn f.guard} (with `self` the {f.ty})." ++
      (if f.doc.isEmpty then "" else " " ++ f.doc)]
  for c in a.constraints do
    out := out ++ ["", s!"**Constraint (part of the task).** Every {c.ty} always has {guardsEn c.guard} (with `self` the {c.ty}); every operator must preserve this."]
  out := out ++ ["", s!"**Goal.** " ++ (match a.goal.name with
      | some n => s!"The {a.goal.ty} named {n}"
      | none => s!"Some {a.goal.ty}") ++ s!" has {ObjPat.en a.goal.vals}. " ++
    "When the goal holds in the task state, the agent reports success and halts." ++
    (if a.goal.report.isEmpty then "" else s!" Before halting it writes {msgEn a.goal.report} (with `self` the {a.goal.ty}).")]
  -- operators
  out := out ++ ["", "## Operators", "",
    "An operator's changes are made together: every value on the right is read before any change."]
  for o in a.ops do
    let ps := ", ".intercalate (o.params.map (fun (p, t) => s!"{p}: {t}") ++
      o.vparams.map fun (p, vs) => s!"{p} ∈ " ++ "{" ++ ", ".intercalate (vs.map toString) ++ "}")
    out := out ++ ["", s!"**{o.name}({ps}).** Proposed when {guardsEn o.propose}." ++
      (if o.doc.isEmpty then "" else " " ++ o.doc)]
    for alt in o.proposeAlt do
      out := out ++ [s!"- Also proposed (and stays proposed) when {guardsEn alt}."]
    if !o.pre.isEmpty then
      out := out ++ [s!"- It applies only when {guardsEn o.pre} (its preconditions); selected without them, it gets a substate whose goal is " ++
        ", ".intercalate (o.pregoals.map fun (pr, p) => s!"{p} {pr}") ++ "."]
    if !o.proposeOr.isEmpty then
      out := out ++ ["- and when one of these holds: " ++ "; or ".intercalate (o.proposeOr.map guardsEn) ++ "."]
    let caseEn (c : Case) : String :=
      let eff := "; ".intercalate (c.effects.map (fun e => s!"{e.obj}.{e.attr} := {e.val.en}") ++
        c.stateEffects.map fun (attr, v) => match v with
          | some p => s!"the task state's `{attr}` := {p}"
          | none => s!"the task state's `{attr}` is removed")
      let eff := eff ++ String.join (c.each.map fun ea =>
        s!"; for every {ea.var} that {ea.src}.{ea.link} points to: " ++
          "; ".intercalate (ea.effects.map fun e => s!"{e.obj}.{e.attr} := {e.val.en}"))
      let eff := if c.write.isEmpty then eff else
        (if eff.isEmpty then "" else eff ++ "; ") ++ s!"writes {msgEn c.write}"
      if c.guard.isEmpty then s!"Effect: {eff}." else s!"If {guardsEn c.guard}: {eff}."
    for c in o.apply do
      out := out ++ ["- " ++ caseEn c]
    match o.impl with
    | .atomic => pure ()
    | .steps ns => out := out ++ [s!"- Carried out in its own substate by the steps " ++
        ", ".intercalate ns ++ ", in that order; the last step makes the changes above."]
    | .sub xs =>
      out := out ++ ["- Carried out in its own substate by these sub-operators, whose changes to the task state are results; together they must produce the effect above (checked):"]
      for x in xs do
        out := out ++ [s!"  - **{x.name}**: proposed when {guardsEn x.propose}. " ++ " ".intercalate (x.apply.map caseEn)]
  -- selection
  out := out ++ ["", "## Choosing among proposed operators", ""]
  match a.method with
  | .random => out := out ++ ["Any proposed operator may be chosen; the choice is random."]
  | .tieHeuristic hs =>
    out := out ++ ["When several operators are proposed, the agent evaluates each one in a tie " ++
      "substate, from the operator applied last (`none` before the first task operator):"]
    for h in hs do
      out := out ++ [s!"- after {" or ".intercalate h.last}: {" or ".intercalate h.cands} is {h.value.en}"]
    out := out ++ ["Best is chosen over neutral over worst; ties among equals are broken at random."]
  | .lookahead av v dup sc =>
    out := out ++ ["When several operators are proposed, the agent tries each one in an internal " ++
      "copy of the state (look-ahead search, Soar's default selection library) and prefers those " ++
      "that lead to the goal. " ++
      (match dup with
       | .partialFailure => "A state equal to one on the path from the task state is a failure for that path."
       | .failure => "A state equal to one on the path from the task state is a failure (the operator is rejected) for that path."
       | .off => "Returning to an earlier state is not detected.")]
    if !a.failure.isEmpty then
      out := out ++ ["A failure state reached in look-ahead is a failure: the operator leading to it is rejected."]
    match sc with
    | some x => out := out ++ [s!"Each state tried is given the value {x.val.en} of the {x.ty}" ++
        (match x.name with | some n => s!" named {n}" | none => "") ++
        s!" (with `self` that {x.ty}); {if x.higher then "higher" else "lower"} is better."]
    | none => pure ()
    for p in av do
      out := out ++ [s!"- A state with {p.en} is " ++
        (match v with | none => "a (partial) failure." | some x => s!"given the value {x}.")]
  | .rl rs fr gr sc =>
    out := out ++ ["The agent learns by reinforcement which operator to choose, from the operator " ++
      "and the attribute values of its parameter objects. Rewards:"]
    for (p, r) in rs do
      out := out ++ [s!"- {r} for a state with {p.en}"]
    if let some r := fr then out := out ++ [s!"- {r} for a failure state"]
    if let some r := gr then out := out ++ [s!"- {r} when the goal holds"]
    if let some c := sc then out := out ++ [s!"- {Float.ofInt c / 1000} for every move (a cost per move)"]
  if !a.prefs.isEmpty then
    out := out ++ ["", "The agent remembers the last task operator applied (its name and parameters). " ++
      "Search-control preferences:"]
    for p in a.prefs do
      out := out ++ [s!"- **{p.name}**: a proposed {p.op} whose " ++
        ", ".intercalate (p.sameAsLast.map fun (x, y) => s!"{x} equals the last {p.op}'s {y}") ++
        (if p.than.isEmpty then s!" is {p.value.en}" else
          s!" is better than a proposed " ++ " or ".intercalate p.than ++
          (if p.versus.isEmpty then "" else " when " ++ guardsEn p.versus)) ++
        (match p.failure with | some true => " in a failure state" | some false => " outside failure states" | none => "") ++
        "." ++ (if p.doc.isEmpty then "" else " " ++ p.doc)]
  out := out ++ ["", "## Learning", "",
    match a.learning with
    | .none => "None."
    | .chunk ss => "Chunking on (`chunk always`)" ++
        (if ss.isEmpty then "." else s!"; singletons for chunking: {", ".intercalate ss}.")
    | .rl r d => s!"Reinforcement learning on: learning rate {Float.ofNat r / 1000}, discount {Float.ofNat d / 1000}, epsilon-greedy exploration."
    | .chunkRl ss r d => s!"Chunking on (`chunk always`)" ++
        (if ss.isEmpty then "" else s!", singletons {", ".intercalate ss}") ++
        s!"; reinforcement learning on: learning rate {Float.ofNat r / 1000}, discount {Float.ofNat d / 1000}, epsilon-greedy exploration."]
  if !a.assumptions.isEmpty then
    out := out ++ ["", "## Assumptions (added; not in the task description)", ""]
    for x in a.assumptions do
      out := out ++ [s!"- **{x.id}** [{x.status}] {x.text}"]
  if !a.raw.isEmpty then
    out := out ++ ["", "## Outside the conventions (unverified)", ""]
    for r in a.raw do
      out := out ++ [s!"- `{r.file}`: {r.why}"]
  return "\n".intercalate out ++ "\n"

end Agent
