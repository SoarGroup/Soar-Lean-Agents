# blocks-world

## The task

The task state holds several values of `object`, each a object. The blocks and the table.

A object has `name` (one of ), `table` (an integer), `on` (a object).

Initially the task state has:
- a `object` named table with table 1
- a `object` named A with table 0; its `on` is table
- a `object` named B with table 0; its `on` is table
- a `object` named C with table 0; its `on` is A
Links between objects never change.

**Goal.** Some object has . When the goal holds in the task state, the agent reports success and halts.

## Operators

An operator's changes are made together: every value on the right is read before any change.

**move-block(block: object, dest: object).** Proposed when block.table = 0 and no object has on = block and block and dest are different objects and block.on ≠ dest. Move a clear block onto the table or onto another clear block.
- and when one of these holds: dest.table = 1; or dest.table = 0 and no object has on = dest.
- Effect: block.on := dest.

## Choosing among proposed operators

When several operators are proposed, the agent tries each one in an internal copy of the state (look-ahead search, Soar's default selection library) and prefers those that lead to the goal. Returning to an earlier state is not detected.

The agent remembers the last task operator applied (its name and parameters). Search-control preferences:
- **reject-twice**: a proposed move-block whose block equals the last move-block's block is rejected. In look-ahead, do not move the block just moved.

## Learning

Chunking on (`chunk always`).

## Assumptions (added; not in the task description)

- **A1** [open] Representation: one object type for blocks and the table, with `name`, `table` (1 for the table) and a changing link `on`. The originals keep `^ontop` objects (`^top-block`, `^bottom-block`) and `^type block/table`; `move-block` changes an ontop's bottom block, here the moved block's `on` (a changing link, `block.on := dest`).
- **A2** [open] move-block(block, dest): proposed when the block is clear and not already on dest, and dest is the table or another clear block (two proposal rules, disjoint). The originals elaborate `^clear` (blocks with nothing on them, and always the table) and propose from it.
- **A3** [open] Goal: the desired `on` of every block, as `^desired` links to the task's own objects (the originals' desired ontops); success halts at the top state.
- **A5** [open] Simple variants: the originals' P6 (moving a block that is not in place to the table is best) and P7 (moving a block onto the in-place object the goal puts it on is better than every other move, binary preferences); "in place" is a derived flag (elaborated recursively along `on`, as the originals' `^inplace-object`). The originals elaborate success from in-place objects; here the goal is the desired links. blocks-world V2 also has three RL template rules with no reward or RL settings; they are dropped.
- **A6** [open] RL variant (BW-RL V1, V2, blocks-world-RL V2): reward 1 when the goal holds (then halt), Soar's default RL (learning rate 0.3, discount 0.9, epsilon-greedy 0.1), learning over repeated runs (init-soar between). The originals list 5120 RL rules, one for each configuration of the four blocks and each move, all at 0; here one RL template tests the operator and the whole state (`Agent.rlWholeState`: every block's `on`), so Soar makes the same rules, each when its configuration and move first occur.
- **A7** [open] Operator subgoaling with relevant moves (BW-Op-Subgoal-RL V1, blocks-world-operator-subgoaling-RL V2–V4): move-block is proposed only when relevant — at the top state a move the goal asks for, in a subgoal moving a block off something the subgoal wants clear onto a clear object — and chosen at random. The originals also turn RL on with an RL template over the subgoal's operator, the configuration and the move, and rewards (1 at the goal; 1 when a subgoal's blocks are clear); in Soar 9.6.5 every rule instantiated from that template is malformed (its state and its operator are the same identifier: defect 28), so none ever matches and the choice is random. The variant has that behaviour: no RL. Four blocks (V1; V4's rules are V1's; V2/V3 differ in a rule name and one redundant test).
- **A8** [open] Look-ahead with state evaluation (BW-LA-state-eval V1, V2, blocks-world-lookahead-state-evaluation V2, V3; their task rules are identical): a tie is resolved by one-step look-ahead whose state is scored by how much of the goal stack is in place (`Score.levels`: C 0.3, B 0.6, A 1.0, none 0) as an expected value; chunking makes RL rules from the evaluations (`Learning.chunkRl`, Soar's default rate 0.3 and discount 0.9), which RL tunes in later runs, with reward 1 at the goal (`Agent.goalReward`, the originals' reward.soar). The score rules test every block's `on` (`Agent.rlWholeState`), as the originals' `evaluate-state` rules test every `ontop`, so each chunk is for one configuration; the goal gives no `^success` inside the look-ahead (`Agent.lookaheadSuccess := false`): as in the originals, a look-ahead reaching it is valued 1.0, so every evaluation chunk is an RL rule and none is a best preference. The originals score with an `evaluate-state` operator in the evaluation substate (best, so the look-ahead is one step); here an elaboration gives the same expected value. Their `^moveable` excludes a `last-bottom` that nothing sets, so it is `clear`. No duplicate-state detection and no rejection of moving the same block again, as the originals.
- **A9** [open] Hierarchical (BW-Hierarchical V1, V2, blocks-world-hierarchical V2–V5): move-block is carried out by pick-up and put-down in its substate, and those by gripper operators (move the gripper up, above an object, down; close; open) in theirs. The gripper is an object of the task state (position, open, above, holding, empty); the gripper operators change it directly, and close/open pick up and put down the block. The originals write gripper commands to the output-link and simulate the world with o-supported rules on the top state (`apply*…*external`); after close the gripper is above what the block stood on (here: above the block), and the held block keeps its `ontop` (here: `on`) until it is put down. pick-up's and put-down's gripper operators have distinct names here (move-gripper-up-holding, …-above-destination, …-down-holding), the originals use the same names in both substates. Search control: the simple originals' P6/P7. Clear excludes a held block, as the originals.
- **A10** [open] Episodic memory as the look-ahead's action model (blocks-world-epmem V2): a tie is resolved by one-step look-ahead in which move-block is not applied by its rules but recalled (`Agent.epmemModel`). The cue is the copy's configuration with the move selected. A full match is followed by the next episode, whose links are copied into the copy; when nothing matches, the move is valued 2.5 as partial success, above every in-place value, so unexperienced moves are tried. A copy is valued by the blocks in place from the bottom of the goal stack (C 1, B 2, A 3, none 0; higher better). The goal gives no success inside the look-ahead. Moving the block just moved is rejected in look-ahead. Episodic memory records every decision at the selection phase; chunking is off. The originals' update operator is proposed as soon as the next episode is asked for, so it first fires on the query's result (the state before the move) and marks the operator tried before the next episode arrives; here it waits for the next episode. The originals' guard against a match without the operator selected (an interrupt) is not needed: the cue's operator is matched only by a selected operator.
- **A11** [open] Hierarchical RL (blocks-world-HRL V1, run with RL on as its readme says): move-block is proposed as in the originals (a clear block onto the table or onto a block with nothing on it; no gripper condition, so picking up another block does not retract it and lose the substate's reward), chosen at the top state by RL over the whole configuration (as `blocks-world-rl`) with reward 1 at the goal, and carried out in its substate by pick-up (any clear block, when the gripper is empty) and put-down (the held block onto any clear object), chosen by RL (`SubRl`: a template per sub-operator over its parameters and move-block's, by name). The substate's rewards: 1 when move-block's block is on its destination; −1 while the gripper holds another block. The original rewards 1 for the same, and −1 when something is put on the moving block; with no penalty for picking up another block, its runs loop picking up a block and putting it back where it was (no reward either way), and 8 of 10 seeds never solve in 3000 decisions. The gripper is the hierarchical variants' gripper object (only `empty` and `holding` are used); a held block keeps its `on` until it is put down and is not clear. Soar defect 28 applies to the templates after init-soar (runs are in fresh agents carrying the learned rules), and to a substate template that tests `^superstate`: its instances test `(state <s1> ^superstate <s1>)` and never fire, so the substate templates do not test it.
- **A4** [open] Look-ahead variant: the selection library, no duplicate-state detection (the originals have none), chunking on. As in the originals, moving the block just moved is rejected inside look-ahead states only (at the top state it may be the only move).
