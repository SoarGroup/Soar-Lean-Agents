/-!
# Agent DSL v0 — a constrained description of Soar task agents

An agent is described here, not as productions. `Agent/Compile.lean` turns a description into
productions of the Soar specification (`Soar.Production`, Soar/Syntax.lean), and from there into
Soar source. The conventions of the English → Lean → Soar plan (5 November 2026) are built into
the types and into `Agent.check`:

* **Declared state schema.** Every object type and attribute is declared (`Schema`); which
  attributes are multi-valued, which are derived. Nothing else can be written or tested.
* **One operator template.** `Operator`: name, typed parameters, proposal guards, apply cases
  (guard + effects). Only operator application makes persistent changes.
* **Stratified elaborations.** Derived attributes (`Derive`) are computed only from
  non-derived attributes of the same object, so elaboration has a unique fixed point.
* **Restricted preferences.** No preference is written by hand: they come from the selection
  method (`Method`).
* **Sanctioned impasses only.** Operator no-change (`Impl.steps`: an operator carried out in a
  substate) and tie (`Method.tieHeuristic`, `Method.lookahead`). Any other impasse is a bug.
* **Explicit goals.** `Goal` becomes a standard `^desired` structure plus a success rule.
* **Fixed I/O protocol.** Not used by this family (no input or output link); reserved.
* **Escape hatch.** `Agent.raw`: productions written directly, outside the guarantees.

Extensions of 6 November 2026, all optional, so a description that does not use them compiles
exactly as before:

* **Value parameters** (`Operator.vparams`): an operator parameter that is a small integer from a
  declared range, not an object. Each combination of values that satisfies the operator's static
  guards (`Guard.vcmp`, over value parameters only) gets its own proposal rule, with the values
  as constants on the operator; apply rules read them from the operator as variables.
* **Named objects and static relations** (`Agent.objs`): initial objects with a symbolic `^name`
  and links to other named objects (object-valued attributes, never changed by an operator);
  `Guard.link` tests a link. A goal may name its object (`Goal.name`).
* **Failure states** (`Agent.failure`): a state is a failure state when some object satisfies a
  guard; it then has `^failure <desired>` (an elaboration). Look-ahead evaluates such a state as a
  failure (the selection library rejects the operator), RL can reward it (`Method.rl`), and
  preference rules can test it.
* **Search-control preference rules** (`Agent.prefs`): hand-written preferences over the proposed
  operators that compare a candidate with the last task operator applied (kept as `^last-move`, a
  record of its name and parameters), optionally only in (or out of) failure states.
* **Look-ahead options**: duplicates of an ancestor as `failure` instead of partial failure, and a
  numeric state evaluation (`Score`).

General conventions added with them (6 November 2026; one-line rationale each):

* **One failure mark.** Failure states are declared (`Agent.failure`) and marked by one
  elaboration, `^failure <desired>` on any task state; every method uses that mark (look-ahead:
  failure evaluation; RL: reward; preferences: tests). Rationale: one definition of failure, so the
  methods cannot disagree about it. `check`: preferences or rewards that use failure states need
  declared failure states.
* **Failure halts (ELB-014, JL 6 Nov 2026).** A failure state violates a task constraint, but the
  constraint is not built into the proposals (too much knowledge for the agent): moves into it are
  proposed, and entering one at the top state is a task failure and halts (generated with the
  failure mark). Look-ahead: failure evaluation; RL: terminal reward. No recovery (undo) rules.
* **Links.** Object-valued attributes of objects are set at initialization. Most never change
  (static links, e.g. a cell's neighbours); an operator may change a link only by setting it to one
  of its object parameters (`obj p`, e.g. Blocks World's `block.on := obj dest`; `check`). RL
  templates leave links out; duplicate-state tests compare a link by its target's key. Rationale:
  identifiers differ between copies of a state, so comparing them directly makes every copy
  different.
* **Value parameters as constants in proposals.** One proposal rule per combination of values that
  passes the static guards, with the values as constants on the operator; apply rules read them
  from the operator. Rationale: proposals stay in precondition style and every instance is
  distinguishable for preferences, chunking and RL.
* **Last move as a record.** Preferences about the previous operator compare with `^last-move`, a
  record of its name and parameters, changed by the single-valued-attribute convention (one rule
  replaces, one adds the first). Rationale: search control about "undo" needs the parameters, not
  only the name.
* **RL templates are marked.** A rule meant as an RL template is written with `:template`.
  Rationale: without it Soar loads one ordinary RL rule whose single value is shared by every
  match. (Printed by the `agentgen` executable; `Soar.Production.toSoar` omits the flag.)

Extensions of 6 November 2026 for the small families (Hello world, Counting, Pyramid, Graph
search), all optional and additive:

* **Messages** (`Case.write`, `Goal.report`): text and expression values written to the trace
  (Soar `write`) when an operator case is applied, or at the goal before halting (expressions over
  the goal object as `self`, e.g. a computed answer). `check`: references are parameters' integer
  attributes (the goal object's for a report).
* **Multiplication and integer division** (`Expr.mul`, `Expr.div`; Soar `*`, `div`, rounded
  towards zero), e.g. to state the effect of an operator carried out by sub-operators in closed
  form.
* **Typed parameters in the task semantics** (`Sem`): each parameter ranges over objects of its
  type only (before, over all objects; the same for one-type tasks).

General conventions added with them (6 November 2026):

* **Output only from operators.** Messages are written by operator application (`Case.write`) or
  by the halt at the goal (`Goal.report`), never by elaborations. Rationale: elaborations fire
  again whenever their match changes and retract, so an elaboration's output can repeat or come
  at any time (hello-world-rule wrote and halted from one). Should, not must (IO-016, JL 6 Nov
  2026): monitor/trace elaborations that print state changes are allowed (written by hand, as `Raw`).
* **Hierarchical operators keep their identity.** An operator carried out by sub-operators
  (`Impl.sub`) is proposed through a relevance elaboration (`^<op>-relevant <p>`), as operators
  with alternative proposals already were, never by a proposal rule that tests values its
  sub-operators change. Rationale: such a proposal rule retracts and fires again after every
  result, making a new operator and ending (and re-creating) the substate after every step.
  (Generated for `Impl.sub` operators with one object parameter and no value parameters.)

Added for Arithmetic (7 November 2026):

* **Nested sub-operators** (`SubOp.subs`, `SubOp.locals`, `Agent.subLib`): a sub-operator with
  sub-operators of its own is carried out in its own operator no-change substate (no apply rules;
  a high-level operator in VisualSoar, its folder under its parent's). The sub-operators it uses
  are named from the library `Agent.subLib` (recursion allowed). In a nested level, `local` is the
  level's own substate and `up` its parent's; the level ends when its sub-operator is no longer
  proposed. `Sem`: `Agent.runNested` runs each level with its own locals and returns the parent's
  changed locals; `runSub`, `refinesSub` and `runConcrete` use it.
* A sub-operator with sub-operators needs no apply case (`check`).

General convention added with them (7 November 2026, SUB-013, proposed, open for JL):

* **Nested substates reach the task through `^task-state`.** Every substate below the first gets
  `^task-state` (the state whose operator began the hierarchy), copied down from its parent;
  sub-operators read the task through it. A nested sub-operator's results are changes to its
  parent substate's attributes; only first-level sub-operators change the task state. Rationale:
  each level works on its parent's local data, so its results stay local and are removed with the
  parent; `^task-state` reaches task objects at any depth and stays right when the hierarchy
  starts below the top state (look-ahead, operator subgoaling).

Added for the Knight's tour (7 November 2026):

* **Counting linked objects** (`Guard.linked p link ty conds k`): at least `k` objects that `p`'s
  static multi-valued link points to satisfy `conds`; `k = 0`: none does (a negated conjunction).
* **Effects on linked objects** (`Case.each`, `Each`): effects on every object a parameter links to
  (one apply rule per `Each`, matching each linked object).
* **Binary preferences** (`Pref.than`, `Pref.versus`): `o > o2` for proposed operators named in
  `than`, when the `versus` conditions compare the two (the other's parameters are `other-<p>`);
  in `Sem`, a candidate another one is better than is removed (`Agent.prefCands`).
* **Set-valued attributes**: an integer attribute declared `multi` holds a set; effects add or
  remove a value (`Effect.mode`); `Cmp.lacks` tests that a set does not contain a value (a
  negated condition, nested inside negated conjunctions), `eq` that it does. Sets may start empty.

Added for KenKen (7 November 2026): `Guard.fewer` (fewer than k linked objects satisfy the
conditions); `Operator.indifferent` (proposed `=` under a look-ahead method, so only the other
operators tie); `Agent.chunkLocalNegations` (`false`: `chunk allow-local-negations off`); failure
guards compiled in full.

Added for the three wizards (7 November 2026): set-valued links (add / remove effects on links;
link tests, linked counts and flag recursion follow every stored link); `Guard.someSuch`; reject
preferences against another proposed operator (`Pref.than` with `reject`). Derived flags are
recomputed each round from the previous round's (as i-support retracts), so a flag whose grounds
include a negation retracts when they stop holding.

Common-sense knowledge an LLM adds beyond a task description is kept as named
`Assumption`s, separate from what the description states.
-/
namespace Agent

/-! ## Schema -/

/-- The type of an attribute's values. -/
inductive VType where
  | int
  | sym (choices : List String)
  | obj (ty : String)
  deriving DecidableEq, Repr

/-- One declared attribute. `derived` attributes are i-supported and computed by a `Derive`. -/
structure AttrDecl where
  name : String
  ty : VType
  multi : Bool := false
  derived : Bool := false
  doc : String := ""
  deriving DecidableEq, Repr

/-- An object type. `key` names an attribute that identifies an object of this type among its
siblings (used to compare whole states, e.g. for duplicate detection in look-ahead). -/
structure ObjType where
  name : String
  attrs : List AttrDecl
  key : Option String := none
  doc : String := ""
  deriving DecidableEq, Repr

structure Schema where
  /-- The task name, which is also the value of the top state's `^name`. -/
  task : String
  /-- Attributes of the task state. Objects of a type are reached through a multi-valued state
  attribute of that type. -/
  stateAttrs : List AttrDecl
  types : List ObjType
  deriving DecidableEq, Repr

/-! ## Expressions, guards, effects -/

/-- Integer expressions over attributes of named objects (operator parameters, or `self` in a
derivation). -/
inductive Expr where
  | lit (n : Int)
  | get (obj attr : String)
  | add (a b : Expr)
  | sub (a b : Expr)
  /-- the value of a value parameter of the operator -/
  | val (p : String)
  /-- product (Soar `*`) -/
  | mul (a b : Expr)
  /-- integer quotient, rounded towards zero (Soar `div`) -/
  | div (a b : Expr)
  /-- the object bound to parameter `p` (as the new value of a link: `block.on := obj dest`) -/
  | obj (p : String)
  deriving DecidableEq, Repr

/-- A part of a message written to the trace (Soar `write`): text, or the value of an expression. -/
inductive Msg where
  | text (s : String)
  | val (e : Expr)
  deriving DecidableEq, Repr

inductive Cmp where
  | eq | ne | lt | le | gt | ge
  /-- a set-valued attribute (an integer attribute declared `multi`) does not contain the value;
  `eq` on one tests that it contains it -/
  | lacks
  deriving DecidableEq, Repr

/-- The right side of a comparison: Soar conditions can compare with a constant or with another
bound value, not with computed values. -/
inductive Atom where
  | lit (n : Int)
  | get (obj attr : String)
  /-- the value of a value parameter -/
  | val (p : String)
  /-- the object bound to parameter `p` (compare a link with it: `x.on = obj p`) -/
  | obj (p : String)
  deriving DecidableEq, Repr

inductive Guard where
  /-- `obj.attr op atom` -/
  | cmp (obj attr : String) (op : Cmp) (rhs : Atom)
  /-- two parameters denote different objects -/
  | distinct (a b : String)
  /-- the task state's single-valued object attribute `attr` is the object `p` -/
  | holds (attr p : String)
  /-- the task state's attribute `attr` has no value -/
  | unset (attr : String)
  /-- parameter `a`'s object-valued (static) attribute `attr` is the object `b` -/
  | link (a attr b : String)
  /-- an expression over value parameters only, compared with a constant: decided per combination
  of values when the agent is compiled (no Soar condition) -/
  | vcmp (e : Expr) (op : Cmp) (n : Int)
  /-- no object `x` of type `ty` has, for every `(attr, op, atom)`, `x.attr op atom` (atoms refer to
  parameters, not to `x`): a negated conjunction over the task state, e.g. "no smaller disk is on
  the target peg" -/
  | noneSuch (ty : String) (conds : List (String × Cmp × Atom))
  /-- the goal (`^desired`) links `o.attr` to `t` (e.g. block1 is to be on block2) -/
  | desired (o attr t : String)
  /-- the derived flag `attr` (`Agent.flags`) holds (`true`) or not (`false`) for `o` -/
  | flag (o attr : String) (holds : Bool)
  /-- operator subgoaling: the state's `^desired` asks for `pred` of `o` (or of what `o.via` links
  to), e.g. "the desired has block clear" in the substate of an operator whose precondition is
  that the block is clear -/
  | wants (pred o : String) (via : Option String)
  /-- the state's `^desired` does not ask for `pred` of `o` (e.g. Towers of Hanoi: move a disk to a
  peg other than the one the subgoal wants a disk on) -/
  | unwants (pred o : String)
  /-- at least `atLeast` distinct objects (of type `ty`) that parameter `p`'s static, multi-valued
  link `link` points to have, for every `(attr, op, atom)`, `x.attr op atom` (atoms refer to
  parameters); `atLeast = 0`: none does. E.g. the knight's tour: "no unused square a knight's move
  away" (0), "two unused squares a move away with one exit each" (2). -/
  | linked (p link ty : String) (conds : List (String × Cmp × Atom)) (atLeast : Nat)
  /-- fewer than `k` (≥ 1) objects that `p`'s link points to satisfy the conditions (a negated
  conjunction over `k` distinct objects), e.g. KenKen's "a cell with fewer than three candidates" -/
  | fewer (p link ty : String) (conds : List (String × Cmp × Atom)) (k : Nat)
  /-- some object `x` of type `ty` has, for every `(attr, op, atom)`, `x.attr op atom` (the
  positive counterpart of `noneSuch`) -/
  | someSuch (ty : String) (conds : List (String × Cmp × Atom))
  deriving DecidableEq, Repr

/-- `obj.attr := e` (a persistent change, made only when an operator is applied). All effects of
a case are simultaneous: every value on the right is read in the state before any change (Soar
binds right-hand-side values from the match). -/
inductive EffMode where
  /-- replace the value -/
  | set
  /-- add the value to a set-valued attribute -/
  | add
  /-- remove the value from a set-valued attribute -/
  | remove
  deriving DecidableEq, Repr

structure Effect where
  obj : String
  attr : String
  val : Expr
  mode : EffMode := .set
  deriving DecidableEq, Repr

/-- An object made when an operator is applied, held by the task state's multi-valued attribute
`holder`, with integer values computed (like effects) from the state before the change. Effects of
the same case may link existing objects to it (`obj var`). -/
structure NewObj where
  var : String
  holder : String
  vals : List (String × Expr) := []
  deriving DecidableEq, Repr

/-- Effects on every object that parameter `src`'s static, multi-valued link `link` points to, each
bound to `var` in turn (read, like the case's effects, from the state before the change); e.g.
the knight's tour: every square a knight's move from the new square has one exit fewer. -/
structure Each where
  var : String
  src : String
  link : String
  effects : List Effect
  deriving DecidableEq, Repr

/-- One case of an operator's application: when the guard holds, make these changes. -/
structure Case where
  guard : List Guard := []
  effects : List Effect
  /-- objects made by this case (JL, 6 Nov 2026: run-time object creation, for Pyramid A5) -/
  creates : List NewObj := []
  /-- changes to single-valued object attributes of the task state: `(attr, some p)` sets it to
  parameter `p`, `(attr, none)` removes its value -/
  stateEffects : List (String × Option String) := []
  /-- a message written to the trace when the case is applied (Soar `write`; not a change of the
  state) -/
  write : List Msg := []
  /-- effects on every object a parameter links to (`Each`) -/
  each : List Each := []
  /-- objects stored in semantic memory: (long-term type, attribute values); later retrievals can
  find them (Soar: `^smem.command.store`) -/
  store : List (String × List (String × Expr)) := []
  deriving DecidableEq, Repr

/-! ## Operators -/

/-- A retrieval from semantic memory: the object of long-term type `ty` (`Agent.ltm`) whose
attributes equal the cue's values is bound, when the (sub-)operator applies, to `var`, which its
apply effects read like a parameter. In Soar: one apply rule puts the cue on `^smem.command.query`;
in the next decision a second reads `^smem.result.retrieved`, makes the effects and removes the
query. -/
structure Retrieve where
  var : String
  ty : String
  cue : List (String × Expr)
  deriving DecidableEq, Repr

/-- A sub-operator of an operator carried out in its operator no-change substate. It has the
parent's parameters; its guards and effects refer to them and to the task state (the superstate),
so its changes are results. -/
structure SubOp where
  name : String
  /-- the sub-operator's own object parameters (objects of the task state, besides the parent's) -/
  params : List (String × String) := []
  propose : List Guard
  apply : List Case
  /-- nested hierarchy: when non-empty, this sub-operator is itself carried out in its own
  substate by these sub-operators (names in `Agent.subLib`; a sub-operator may name itself or an
  ancestor: recursion); `apply` then only specifies its effect. In its substate, `local` is its
  own substate-local attributes and `up` its parent's. -/
  subs : List String := []
  /-- substate-local integer attributes of its own substate (with `subs`) -/
  locals : List (String × Expr) := []
  /-- a semantic-memory retrieval, bound when it applies -/
  retrieve : Option Retrieve := none
  doc : String := ""
  deriving DecidableEq, Repr

/-- How an operator is carried out. `atomic`: by apply rules in the state where it is selected.
`steps`: in an operator no-change substate, by a fixed sequence of sub-operators; the last step
makes the operator's changes (as results). -/
inductive Impl where
  | atomic
  /-- bookkeeping steps only (markers local to the substate); the last makes the changes -/
  | steps (names : List String)
  /-- real sub-operators that change the task state; together they must produce the operator's
  `apply` effect (checked by `Agent.refinesSub`) -/
  | sub (ops : List SubOp)
  deriving DecidableEq, Repr

structure Operator where
  name : String
  /-- (parameter, object type) -/
  params : List (String × String)
  /-- value parameters: (parameter, the values it ranges over). On the operator in working
  memory as `^parameter value`. -/
  vparams : List (String × List Int) := []
  propose : List Guard
  /-- further, alternative proposal conditions (each a separate proposal rule); they should be
  disjoint from `propose` and from each other -/
  proposeAlt : List (List Guard) := []
  /-- a disjunction added to `propose`: the operator is proposed when `propose` holds and one of
  these does (one proposal rule each; they must be disjoint, e.g. "the destination is the table" /
  "the destination is a clear block"). Atomic operators without value parameters only. -/
  proposeOr : List (List Guard) := []
  apply : List Case
  impl : Impl := .atomic
  /-- preconditions (operator subgoaling, `Agent.subgoaling`): not tested by the proposal (it says
  when the operator is relevant), required by the apply rules; when the operator is selected and
  they do not hold, Soar's operator no-change substate works on them -/
  pre : List Guard := []
  /-- apply-time parameters: objects bound when the operator applies, not when it is proposed, by
  the preconditions (`pre`) and the cases' guards (e.g. Towers of Hanoi's upper disk of the target
  peg, which the moved disk is put on). The proposal (the operator's identity) does not depend on
  them, so a change to them does not retract the operator. Operator subgoaling only. -/
  applyParams : List (String × String) := []
  /-- the preconditions as goals of that substate: `(pred, parameter)` put on its `^desired`
  (e.g. `("clear", "block")`) -/
  pregoals : List (String × String) := []
  /-- for `Impl.sub`: integer attributes local to the operator's substate, with their initial
  values (expressions over the parameters). Sub-operators refer to them as `local.<attr>`; they
  are made by a first sub-operator `init-local` and removed with the substate (JL, 6 Nov 2026:
  count-and-die keeps its count in the substate). -/
  locals : List (String × Expr) := []
  /-- for `Impl.sub`: the specified effect (`apply`) covers the operator's parameters only; its
  sub-operators may change other task objects too (e.g. a borrow that decrements the next column,
  recursively), and refinement compares the parameters' objects only -/
  specOwn : Bool := false
  /-- proposed only at the top state once the goal holds (`Goal.after`), e.g. printing the solution -/
  atGoal : Bool := false
  /-- with a look-ahead method: proposed indifferent (`=`), so that ties among these operators do
  not go to look-ahead (e.g. KenKen's constraint propagation; only guesses are evaluated) -/
  indifferent : Bool := false
  doc : String := ""
  deriving DecidableEq, Repr

/-- A derived attribute: `T.attr := e`, with `e` over `self`. -/
structure Derive where
  ty : String
  attr : String
  val : Expr
  deriving DecidableEq, Repr

/-- An object pattern: attribute values that one object must have. -/
abbrev ObjPat := List (String × Int)

/-- A goal: some object of type `ty` has these attribute values. It becomes a `^desired` structure;
any state of the task with a matching object gets `^success`; at the top state that halts the
agent (a look-ahead copy reaching it only counts as a successful evaluation). -/
structure Goal where
  ty : String
  vals : ObjPat
  /-- the goal object must be this named object (`Agent.objs`) -/
  name : Option String := none
  /-- a message written when the goal holds at the top state, before halting; expressions refer to
  the goal object as `self` (e.g. the answer of a computation) -/
  report : List Msg := []
  /-- every object of type `ty` (not just some) has the values (e.g. every disk on the third peg) -/
  all : Bool := false
  /-- several objects: each pattern is matched by some object of type `ty` (e.g. every tile in its
  cell); `vals` is then unused. Each pattern should include the type's key. -/
  each : List ObjPat := []
  /-- links between named objects that must all hold, `(object, link, target)` (e.g. A on B);
  `vals` is then unused. The `^desired` structure links to the task's own objects. -/
  links : List (String × String × String) := []
  /-- values the goal object must also have before the agent halts at the top state: operators
  marked `atGoal` set them once the goal holds (e.g. print the solved board); look-ahead success
  does not wait for them -/
  after : ObjPat := []
  deriving DecidableEq, Repr

/-- A whole-state pattern: for each listed object pattern, some object of type `ty` matches it. -/
structure StatePat where
  ty : String
  objs : List ObjPat
  deriving DecidableEq, Repr

/-! ## Selection methods -/

inductive HVal where
  | best | worst | equal
  /-- better than every other proposed operator (binary preferences `o > o2`), as the Blocks
  World originals' "move a block onto its desired, in-place destination" -/
  | better
  /-- rejected: never chosen (search control; e.g. the eight puzzle's "do not move the tile just
  moved back") -/
  | reject
  deriving DecidableEq, Repr

/-- A heuristic: when the last operator applied was one of `last` (`none` before the first),
candidates named in `cands` get `value`. -/
structure Heur where
  last : List String
  cands : List String
  value : HVal
  deriving DecidableEq, Repr

/-- How a duplicate of an ancestor is evaluated in look-ahead. -/
inductive FailKind where
  /-- `partial-failure`: the selection library makes the operator worst -/
  | partialFailure
  /-- `failure`: the selection library rejects the operator -/
  | failure
  /-- no duplicate detection (e.g. the eight puzzle, which rejects the inverse move instead) -/
  | off
  deriving DecidableEq, Repr

/-- A look-ahead evaluation by the last move's object (the eight puzzle's): after operator `op`,
+1 if its parameter `obj` now has its desired `attr` (the desired object with the same key), −1
if it had it before (`old`, the attribute's value before the move, is `p.a` for a parameter `p`),
0 otherwise. -/
structure ScoreDelta where
  op : String
  obj : String
  attr : String
  old : String × String
  /-- by links (the goal's `links`): `obj.attr` is a link; +1 if it now points to its desired
  object, −1 if `old.1.attr` pointed to `old.2` (the moved object) and that was desired; targets
  compared by name (the eight puzzle with bindings: the binding the tile moved into, the binding it
  left) -/
  links : Bool := false
  deriving DecidableEq, Repr

/-- A numeric evaluation of look-ahead states: `val` (over `self`) for the object of type `ty`
(the named object `name`, if given); `higher` says whether higher values are better. -/
structure Score where
  ty : String
  name : Option String := none
  val : Expr := .lit 0
  higher : Bool := true
  /-- evaluate by the moved object instead of `val` -/
  delta : Option ScoreDelta := none
  /-- give the evaluation as `^expected-value` (numeric-indifferent preferences: Soar chooses with
  probabilities from the values; what RL rules are later made from) instead of `^numeric-value`
  (compared values: binary preferences) — eight-puzzle V2 -/
  expected : Bool := false
  /-- evaluate by levels (BW-LA-state-eval): named objects of `ty`, highest first, each with a value
  in thousandths; the value is that of the first whose flag `levelFlag` is set (1), 0 when none
  is (blocks in place from the bottom of the goal stack: C 0.3, B 0.6, A 1.0) -/
  levels : List (String × Int) := []
  levelFlag : String := "in-place"
  deriving DecidableEq, Repr

/-- How operators are chosen among the proposed ones. -/
inductive Method where
  /-- uniformly at random (all proposals indifferent) -/
  | random
  /-- tie impasse, resolved in a tie substate by evaluating each tied operator with heuristics:
  `best` becomes best + indifferent preferences, `worst` worst + indifferent, `equal`
  indifferent; Soar then chooses at random among the remaining equals. `check` requires exactly
  one heuristic for each (last operator or `none`, candidate). -/
  | tieHeuristic (hs : List Heur)
  /-- tie impasse, resolved by look-ahead search with Soar's default selection library; states
  equal to an ancestor state are partial failures; states matching `avoid` are partial failures,
  or, with `avoidValue`, get that numeric evaluation -/
  | lookahead (avoid : List StatePat) (avoidValue : Option Int := none)
      (dup : FailKind := .partialFailure) (score : Option Score := none)
  /-- reinforcement learning over operator and parameter-object attributes (RL templates with
  initial value 0), with rewards for states matching patterns, given whenever such a state holds
  (Soar's reward link). Algorithm and exploration are set by `Learning.rl`. A look-ahead variant
  with RL learning (`Learning.chunkRl`) needs no rewards: chunking over numeric evaluations makes
  the RL rules. -/
  | rl (rewards : List (StatePat × Int)) (failureReward : Option Int := none)
      (goalReward : Option Int := none)
      -- stepCost: a reward on every decision, in thousandths (−10 = −0.01 per move)
      (stepCost : Option Int := none)
  deriving DecidableEq, Repr

/-- Learning. -/
inductive Learning where
  | none
  /-- `chunk always`; `singletons` are attributes declared singletons for chunking -/
  | chunk (singletons : List String)
  /-- `rl` on with these parameters (learning rate and discount ×1000) and epsilon-greedy
  exploration -/
  | rl (rate discount : Nat)  -- Soar's default RL algorithm (SARSA); epsilon-greedy, epsilon 0.1
  /-- both -/
  | chunkRl (singletons : List String) (rate discount : Nat)
  deriving DecidableEq, Repr

/-- A task constraint: every object of type `ty` satisfies `guard` (over `self`) in every reachable
state. Part of the task, not a consequence of particular operators: every variant, and any operator
added later, must preserve it. -/
structure Constraint where
  ty : String
  guard : List Guard
  doc : String := ""
  deriving DecidableEq, Repr

/-- An initial object with an identity: `^name name`, attribute values, and links (object-valued
attributes) to other named objects, by name. Links never change. -/
structure Named where
  holder : String
  name : String
  vals : ObjPat
  links : List (String × String) := []
  deriving DecidableEq, Repr

/-- A failure state: some object of type `ty` satisfies `guard` (over `self`). -/
structure Failure where
  ty : String
  guard : List Guard
  doc : String := ""
  deriving DecidableEq, Repr

/-- A search-control preference rule: when the task operator last applied was `op`, a proposed
`op` whose fields equal the last one's as listed (`(candidate field, last field)`, fields being
parameters and value parameters) gets `value` (`best`: `>`, `worst`: `<`, `equal`: `=`).
`failure`: only in failure states (`some true`), only outside them (`some false`), or always. -/
structure Pref where
  name : String
  op : String
  sameAsLast : List (String × String)
  /-- further conditions on the candidate (over its parameters); with `sameAsLast = []` the rule
  does not depend on the last operator -/
  guard : List Guard := []
  /-- conditions on the last operator applied (a `op`): its parameters are named `last-<param>`;
  the rule does not apply before the first operator -/
  lastGuard : List Guard := []
  /-- only inside look-ahead (states whose superstate is evaluating an operator), as the Blocks
  World look-ahead originals' "do not move the same block twice" -/
  inLookahead : Bool := false
  failure : Option Bool := none
  value : HVal
  /-- with `value = better`: better only than proposed operators named here (binary preferences
  `o > o2`, e.g. the knight's tour's "backup is better than a knight move"); `[]`: than every other.
  With `value = reject`: rejected when such an operator is proposed (and `versus` holds), e.g. the
  wizards' "prefer the deeper model" -/
  than : List String := []
  /-- with `than`: conditions comparing the candidate with the other operator, whose parameters are
  named `other-<param>` (e.g. "the move's square has fewer exits than the other move's") -/
  versus : List Guard := []
  doc : String := ""
  deriving DecidableEq, Repr

/-- Common-sense knowledge added to a description, kept separate and reviewable. -/
structure Assumption where
  id : String
  text : String
  /-- `accepted`, `rejected`, `revised`, or `open` -/
  status : String := "open"
  deriving DecidableEq, Repr

/-- A raw production (escape hatch): outside the conventions and their checks. -/
structure Raw where
  file : String
  text : String
  why : String
  deriving DecidableEq, Repr

/-- A derived flag defined recursively along a link (e.g. Blocks World's "in place": the table is;
a block is when it is on what the goal puts it on and that is in place). `attr` (an integer
attribute declared derived; 1 when the flag holds, absent otherwise) holds for `self` when `base`
holds, or when `self.via` is an object `below` that has the flag and `step` holds (guards over
`self` and `below`). Elaboration rules (i-support); tests use `Guard.flag`. -/
structure Flag where
  ty : String
  attr : String
  base : List Guard := []
  /-- the link followed by the recursive rule; `""`: no recursive rule (several `Flag`s with the
  same attribute give alternative base cases, e.g. "clear": the table, or nothing on it) -/
  via : String := ""
  step : List Guard := []
  doc : String := ""
  deriving DecidableEq, Repr

/-- An agent. -/
structure Agent where
  schema : Schema
  /-- initial objects: (state attribute, attribute values) -/
  init : List (String × ObjPat)
  /-- initial objects with names and links (after those of `init`) -/
  objs : List Named := []
  /-- long-term knowledge in semantic memory (`smem --add` at load): (type, attribute values);
  never in working memory, reached only by retrievals (`Retrieve`) -/
  ltm : List (String × ObjPat) := []
  derive : List Derive
  ops : List Operator
  goal : Goal
  constraints : List Constraint := []
  failure : List Failure := []
  prefs : List Pref := []
  method : Method
  learning : Learning := .none
  /-- chunking: `false` sets `chunk allow-local-negations off` (as KenKen V1: chunks over results
  that depend on negated conditions of a large state take too long to build) -/
  chunkLocalNegations : Bool := true
  /-- chunking: `true` sets `chunk bottom-only on` (learn only in the lowest substate). In
  arithmetic-solve-problem, Soar 9.6.5 learns borrow chunks without the relational test between the
  top digit and the incremented bottom digit, which then fire for columns that need no borrow
  (suspected kernel defect 34); learning only at the bottom avoids those chunks -/
  chunkBottomOnly : Bool := false
  /-- RL templates also test the whole state: every named object's links (by the linked object's
  key), so a learned value is for an operator in one configuration (BW-RL's table of 5120 rules,
  one per configuration and move, here instantiated as configurations are met). In a look-ahead,
  the score-level rules test it too, so chunks over the evaluations are for one configuration
  (BW-LA-state-eval's `evaluate-state` rules test every `ontop`). -/
  rlWholeState : Bool := false
  /-- a reward when the goal holds (Soar's reward link), for agents that learn RL rules other than
  by the RL method: a look-ahead whose evaluations chunking turns into RL rules
  (BW-LA-state-eval: reward 1 at the goal). With no reward, RL only discounts those values towards 0. -/
  goalReward : Option Int := none
  /-- whether the goal gives `^success` in look-ahead states too (then the selection library
  evaluates a look-ahead reaching it as success, and chunks make that a best preference). False:
  only at the top state, so a look-ahead state is valued by its score alone (BW-LA-state-eval: the
  goal state's expected value is 1.0, as the other levels, and every chunk is an RL rule). -/
  lookaheadSuccess : Bool := true
  assumptions : List Assumption := []
  raw : List Raw := []
  /-- derived flags defined recursively along links -/
  flags : List Flag := []
  /-- sub-operators used by name from other sub-operators (nested hierarchy) -/
  subLib : List SubOp := []
  /-- operator subgoaling (means-ends analysis): an operator selected without its preconditions
  gets a substate named like the task, sharing the task's objects, whose `^desired` holds the
  operator's `pregoals`; the same operators and preferences work there, and their changes are
  results. When the preconditions hold, the operator applies and the substate ends. -/
  subgoaling : Bool := false
  deriving Repr, DecidableEq

/-! ## The conventions as checks

`check a` lists every violation; a well-formed agent has none. Families state
`theorem … : check a = [] := by decide` for each variant, so a variant that breaks a convention
does not compile. -/

def Schema.type? (s : Schema) (t : String) : Option ObjType := s.types.find? (·.name == t)

def Schema.attr? (s : Schema) (t a : String) : Option AttrDecl :=
  (s.type? t).bind fun ty => ty.attrs.find? (·.name == a)

/-- The state attribute through which objects of type `t` are reached. -/
def Schema.holder? (s : Schema) (t : String) : Option AttrDecl :=
  s.stateAttrs.find? fun d => d.ty == .obj t && d.multi

def Expr.refs : Expr → List (String × String)
  | .lit _ => []
  | .get o a => [(o, a)]
  | .add a b => a.refs ++ b.refs
  | .sub a b => a.refs ++ b.refs
  | .val _ => []
  | .mul a b => a.refs ++ b.refs
  | .div a b => a.refs ++ b.refs
  | .obj _ => []

def Msg.refs : Msg → List (String × String)
  | .text _ => []
  | .val e => e.refs


def Atom.refs : Atom → List (String × String)
  | .lit _ => []
  | .get o a => [(o, a)]
  | .val _ => []
  | .obj _ => []

def Guard.refs : Guard → List (String × String)
  | .cmp _ _ .lacks r => r.refs
  | .cmp o a _ r => (o, a) :: r.refs
  | .distinct _ _ => []
  | .holds _ _ => []
  | .unset _ => []
  | .link _ _ _ => []
  | .vcmp _ _ _ => []
  | .noneSuch _ cs => cs.flatMap fun (_, _, r) => r.refs
  | .linked _ _ _ cs _ => cs.flatMap fun (_, _, r) => r.refs
  | .fewer _ _ _ cs _ => cs.flatMap fun (_, _, r) => r.refs
  | .someSuch _ cs => cs.flatMap fun (_, _, r) => r.refs
  | .desired .. => []
  | .flag .. => []
  | .wants .. => []
  | .unwants .. => []

/-- Value parameters an expression refers to. -/
def Expr.vrefs : Expr → List String
  | .val p => [p]
  | .add a b => a.vrefs ++ b.vrefs
  | .sub a b => a.vrefs ++ b.vrefs
  | .mul a b => a.vrefs ++ b.vrefs
  | .div a b => a.vrefs ++ b.vrefs
  | _ => []

def Msg.vrefs : Msg → List String
  | .text _ => []
  | .val e => e.vrefs

def Atom.vrefs : Atom → List String
  | .val p => [p]
  | _ => []

def Guard.vrefs : Guard → List String
  | .cmp _ _ _ r => r.vrefs
  | .vcmp e _ _ => e.vrefs
  | .noneSuch _ cs => cs.flatMap fun (_, _, r) => r.vrefs
  | .linked _ _ _ cs _ => cs.flatMap fun (_, _, r) => r.vrefs
  | .fewer _ _ _ cs _ => cs.flatMap fun (_, _, r) => r.vrefs
  | .someSuch _ cs => cs.flatMap fun (_, _, r) => r.vrefs
  | _ => []

/-- A guard decided at compile time (over value parameters only). -/
def Guard.isStatic : Guard → Bool
  | .vcmp .. => true
  | _ => false

/-- Every combination of values of the value parameters, in order. -/
def combos : List (String × List Int) → List (List (String × Int))
  | [] => [[]]
  | (p, vs) :: rest => vs.flatMap fun v => (combos rest).map ((p, v) :: ·)

def Expr.evalV (vals : List (String × Int)) : Expr → Int
  | .lit n => n
  | .val p => (vals.lookup p).getD 0
  | .add a b => a.evalV vals + b.evalV vals
  | .sub a b => a.evalV vals - b.evalV vals
  | .mul a b => a.evalV vals * b.evalV vals
  | .div a b => Int.tdiv (a.evalV vals) (b.evalV vals)
  | .get _ _ => 0
  | .obj _ => 0

def Cmp.test : Cmp → Int → Int → Bool
  | .eq, a, b => a == b | .ne, a, b => a != b | .lt, a, b => a < b
  | .le, a, b => a ≤ b | .gt, a, b => a > b | .ge, a, b => a ≥ b | .lacks, a, b => a != b

/-- The combinations of value-parameter values that pass the static guards. -/
def Operator.combos (o : Operator) : List (List (String × Int)) :=
  (Agent.combos o.vparams).filter fun vals =>
    (o.propose.filter Guard.isStatic).all fun g => match g with
      | .vcmp e op n => op.test (e.evalV vals) n
      | _ => true

/-- `(obj, attr)` must name a parameter of `params` and an int attribute of its type. -/
def checkRef (s : Schema) (params : List (String × String)) (ctx : String) (r : String × String) :
    List String :=
  match params.find? (·.1 == r.1) with
  | none => [s!"{ctx}: {r.1} is not a parameter"]
  | some (_, t) =>
    match s.attr? t r.2 with
    | none => [s!"{ctx}: {t} has no attribute {r.2}"]
    | some d => if d.ty == .int then [] else [s!"{ctx}: {t}.{r.2} is not an integer"]

/-- A `noneSuch`/`someSuch` guard: a held type, conditions on its attributes. -/
def checkNoneSuch (s : Schema) (ps : List (String × String)) (ctx ty : String)
    (cs : List (String × Cmp × Atom)) : List String :=
  (if (s.holder? ty).isSome then [] else [s!"{ctx}: no state attribute holds {ty}"]) ++
  (if cs.isEmpty then [s!"{ctx}: a negated test needs at least one condition"] else []) ++
  cs.flatMap fun (a, op, r) =>
    (match s.attr? ty a, r with
     | none, _ => [s!"{ctx}: {ty} has no attribute {a}"]
     | some { ty := .obj t, .. }, .obj p =>
       (if ps.lookup p == some t then [] else [s!"{ctx}: {ty}.{a} links to a {t}; {p} is not one"]) ++
       (if op == .eq || op == .ne then [] else [s!"{ctx}: a link is compared only with = or ≠"])
     | some d, _ => if d.ty == .int then [] else [s!"{ctx}: {ty}.{a} is not an integer"]) ++
    r.refs.flatMap (checkRef s ps ctx)

/-- A `linked`/`fewer` guard: `p.link` points to objects of type `ty`, whose attributes the
conditions compare. -/
def checkLinked (s : Schema) (ps : List (String × String)) (ctx p l ty : String)
    (cs : List (String × Cmp × Atom)) : List String :=
  (match ps.lookup p with
   | some t => match s.attr? t l with
     | some { ty := .obj t2, .. } => if t2 == ty then [] else [s!"{ctx}: {t}.{l} links to a {t2}, not a {ty}"]
     | _ => [s!"{ctx}: {t}.{l} is not a link"]
   | none => [s!"{ctx}: {p} is not a parameter"]) ++
  (if cs.isEmpty then [s!"{ctx}: a linked test needs at least one condition"] else []) ++
  cs.flatMap fun (a, _, r) =>
    (match s.attr? ty a with
     | none => [s!"{ctx}: {ty} has no attribute {a}"]
     | some d => if d.ty == .int then [] else [s!"{ctx}: {ty}.{a} is not an integer"]) ++
    r.refs.flatMap (checkRef s ps ctx)


def checkGuardV (s : Schema) (ps : List (String × String)) (vps : List String) (ctx : String) (g : Guard) :
    List String :=
  (g.vrefs.filterMap fun v => if vps.contains v then none else some s!"{ctx}: {v} is not a value parameter") ++
  match g with
  | .link a attr b =>
    match ps.lookup a, ps.lookup b with
    | some ta, some tb =>
      match s.attr? ta attr with
      | some { ty := .obj t, .. } => if t == tb then [] else [s!"{ctx}: {ta}.{attr} links to a {t}, {b} is a {tb}"]
      | some _ => [s!"{ctx}: {ta}.{attr} is not an object-valued attribute"]
      | none => [s!"{ctx}: {ta} has no attribute {attr}"]
    | _, _ => [s!"{ctx}: link between non-parameters {a}, {b}"]
  | .vcmp e _ _ => if e.refs.isEmpty then [] else [s!"{ctx}: a static guard refers to objects"]
  -- a link compared with an object parameter: `x.on = obj p` / `≠` (same type)
  | .cmp o attr op (.obj p) =>
    match (ps.lookup o).bind (s.attr? · attr), ps.lookup p with
    | some { ty := .obj t, .. }, some tp =>
      (if t == tp then [] else [s!"{ctx}: {o}.{attr} links to a {t}, {p} is a {tp}"]) ++
      (if op == .eq || op == .ne then [] else [s!"{ctx}: a link is compared only with = or ≠"])
    | some _, _ => [s!"{ctx}: {o}.{attr} is not a link"]
    | none, _ => [s!"{ctx}: {o}.{attr} undeclared or {o} not a parameter"]
  | .desired o attr t =>
    match (ps.lookup o).bind (s.attr? · attr), ps.lookup t with
    | some { ty := .obj tt, .. }, some tp => if tt == tp then [] else [s!"{ctx}: {o}.{attr} links to a {tt}, {t} is a {tp}"]
    | _, _ => [s!"{ctx}: desired {o}.{attr} = {t}: not a link between parameters"]
  | .flag o attr _ =>
    match (ps.lookup o).bind (s.attr? · attr) with
    | some { ty := .int, derived := true, .. } => []
    | _ => [s!"{ctx}: {o}.{attr} is not a derived flag"]
  | .wants _ o via =>
    match ps.lookup o, via with
    | some _, none => []
    | some t, some l => match s.attr? t l with
      | some { ty := .obj _, .. } => []
      | _ => [s!"{ctx}: {o}.{l} is not a link"]
    | none, _ => [s!"{ctx}: {o} is not a parameter"]
  | .unwants _ o => if ps.any (·.1 == o) then [] else [s!"{ctx}: {o} is not a parameter"]
  | g => checkGuard0 s ps ctx g
where
  checkGuard0 (s : Schema) (ps : List (String × String)) (ctx : String) (g : Guard) : List String :=
  match g with
  | .distinct a b =>
    (if ps.any (·.1 == a) then [] else [s!"{ctx}: {a} is not a parameter"]) ++
    (if ps.any (·.1 == b) then [] else [s!"{ctx}: {b} is not a parameter"])
  | .holds attr p =>
    match s.stateAttrs.find? (·.name == attr), ps.lookup p with
    | some { ty := .obj t, multi := false, .. }, some t' =>
      if t == t' then [] else [s!"{ctx}: {attr} holds a {t}, {p} is a {t'}"]
    | some _, some _ => [s!"{ctx}: {attr} is not a single-valued object attribute of the state"]
    | none, _ => [s!"{ctx}: no state attribute {attr}"]
    | _, none => [s!"{ctx}: {p} is not a parameter"]
  | .unset attr => if s.stateAttrs.any (·.name == attr) then [] else [s!"{ctx}: no state attribute {attr}"]
  | .noneSuch ty cs => checkNoneSuch s ps ctx ty cs
  | .someSuch ty cs => checkNoneSuch s ps ctx ty cs
  | .fewer p l ty cs k =>
    (if k == 0 then [s!"{ctx}: fewer than 0 is never true"] else []) ++
    checkLinked s ps ctx p l ty cs
  | .linked p l ty cs _ => checkLinked s ps ctx p l ty cs
  | g => g.refs.flatMap (checkRef s ps ctx)

def checkGuard (s : Schema) (ps : List (String × String)) (ctx : String) (g : Guard) : List String :=
  checkGuardV s ps [] ctx g

def checkStateEffects (s : Schema) (ps : List (String × String)) (ctx : String) (c : Case) : List String :=
  c.stateEffects.flatMap fun (attr, v) =>
    checkGuard s ps ctx (match v with | some p => .holds attr p | none => .unset attr)

/-- New objects: a multi-valued object holder, declared integer attributes, values over the
parameters, fresh names. -/
def checkCreates (s : Schema) (ps : List (String × String)) (ctx : String) (c : Case) : List String :=
  c.creates.flatMap fun no =>
    (match s.stateAttrs.find? (·.name == no.holder) with
     | some { ty := .obj t, multi := true, .. } =>
       no.vals.flatMap fun (a, e) =>
         (match s.attr? t a with
          | some d => if d.ty == .int && !d.derived then [] else [s!"{ctx}: new {t}.{a} is not a plain integer"]
          | none => [s!"{ctx}: {t} has no attribute {a}"]) ++
         e.refs.flatMap (checkRef s ps ctx)
     | _ => [s!"{ctx}: {no.holder} is not a multi-valued object attribute of the state"]) ++
    (if ps.any (·.1 == no.var) then [s!"{ctx}: new object {no.var} repeats a parameter name"] else [])

def checkOp (s : Schema) (o : Operator) : List String :=
  let ctx := s!"operator {o.name}"
  let paramErrs := (o.params ++ o.applyParams).flatMap fun (p, t) =>
    match s.type? t, s.holder? t with
    | none, _ => [s!"{ctx}: parameter {p}: no type {t}"]
    | _, none => [s!"{ctx}: parameter {p}: no multi-valued state attribute holds {t}"]
    | _, _ => []
  let vps := o.vparams.map (·.1)
  -- apply-time parameters are bound in the preconditions and apply cases
  let allPs := o.params ++ o.applyParams
  let vparamErrs :=
    (if (o.params.map (·.1) ++ vps).eraseDups.length != o.params.length + vps.length
     then [s!"{ctx}: repeated parameter name"] else []) ++
    (o.vparams.filterMap fun (p, vs) => if vs.isEmpty then some s!"{ctx}: value parameter {p} has no values" else none) ++
    (if !vps.isEmpty && o.combos.isEmpty then [s!"{ctx}: no combination of values passes the static guards"] else []) ++
    (if !o.locals.isEmpty && (match o.impl with | .sub _ => false | _ => true) then
      [s!"{ctx}: substate-local attributes need sub-operators"] else []) ++
    (if !vps.isEmpty && (o.impl != .atomic || !o.proposeAlt.isEmpty) then
      [s!"{ctx}: value parameters need an atomic operator with one proposal"] else []) ++
    ((o.proposeAlt.flatten ++ o.apply.flatMap (·.guard)).filterMap fun g =>
      if g.isStatic then some s!"{ctx}: static guards belong in propose" else none)
  let guardErrs := (o.propose ++ o.proposeAlt.flatten ++ o.proposeOr.flatten ++ o.pre ++ o.apply.flatMap (·.guard)).flatMap (checkGuardV s allPs vps ctx) ++
    (o.pregoals.filterMap fun (_, p) => if allPs.any (·.1 == p) then none else some s!"{ctx}: pregoal on non-parameter {p}") ++
    (if !o.pre.isEmpty && (o.impl != .atomic || !vps.isEmpty) then [s!"{ctx}: preconditions need an atomic operator without value parameters"] else []) ++
    (if !o.proposeOr.isEmpty && (o.impl != .atomic || !vps.isEmpty || !o.proposeAlt.isEmpty) then
      [s!"{ctx}: a proposal disjunction needs an atomic operator without value parameters or alternatives"] else []) ++
    o.apply.flatMap (checkStateEffects s allPs ctx)
  let writeErrs := o.apply.flatMap (·.write) |>.flatMap fun m =>
    -- a message may write a symbolic attribute as it is (e.g. a peg's name)
    (match m with
     | .val (.get ob a) => match allPs.find? (·.1 == ob) with
       | some (_, t) => match s.attr? t a with
         | some d => match d.ty with | .sym _ => [] | _ => checkRef s allPs ctx (ob, a)
         | none => checkRef s allPs ctx (ob, a)
       | none => checkRef s allPs ctx (ob, a)
     | _ => m.refs.flatMap (checkRef s allPs ctx)) ++
    (Msg.vrefs m).filterMap fun v => if vps.contains v then none else some s!"{ctx}: {v} is not a value parameter"
  let effErrs := o.apply.flatMap (·.effects) |>.flatMap fun e =>
    (match e.val with | .obj _ => [] | _ => checkRef s allPs ctx (e.obj, e.attr)) ++
    e.val.refs.flatMap (checkRef s allPs ctx) ++
    (e.val.vrefs.filterMap fun v => if vps.contains v then none else some s!"{ctx}: {v} is not a value parameter") ++
    match (allPs.find? (·.1 == e.obj)).bind (fun (_, t) => s.attr? t e.attr) with
    | some d =>
      (if d.derived then [s!"{ctx}: effect writes derived attribute {e.attr}"] else []) ++
      (match d.ty, e.val with
       | .obj t, .obj p =>
         let made : List (String × String) := o.apply.flatMap fun c => c.creates.filterMap fun no =>
           match (s.stateAttrs.find? (·.name == no.holder)).map (·.ty) with
           | some (VType.obj tt) => some (no.var, tt) | _ => none
         match (allPs ++ made).lookup p with
         | some tp => if tp == t then [] else [s!"{ctx}: {e.obj}.{e.attr} links to a {t}, {p} is a {tp}"]
         | none => [s!"{ctx}: {p} is not an object parameter"]
       | .obj _, _ => [s!"{ctx}: link {e.obj}.{e.attr} must be set to an object parameter (obj p)"]
       | _, .obj _ => [s!"{ctx}: {e.obj}.{e.attr} is not a link"]
       | _, _ => [])
    | none => []
  let effErrs := effErrs ++ o.apply.flatMap (checkCreates s allPs ctx)
  -- effects on linked objects: `var` ranges over what `src`'s link points to
  let eachErrs := o.apply.flatMap (·.each) |>.flatMap fun ea =>
    match (allPs.lookup ea.src).bind (fun t => s.attr? t ea.link) with
    | some { ty := .obj t, .. } =>
      let ps := allPs ++ [(ea.var, t)]
      (if allPs.any (·.1 == ea.var) then [s!"{ctx}: {ea.var} repeats a parameter name"] else []) ++
      ea.effects.flatMap fun e =>
        (if e.obj == ea.var then [] else [s!"{ctx}: an effect on linked objects changes {ea.var} only"]) ++
        checkRef s ps ctx (e.obj, e.attr) ++ e.val.refs.flatMap (checkRef s ps ctx)
    | _ => [s!"{ctx}: {ea.src}.{ea.link} is not a link of a parameter"]
  let effErrs := effErrs ++ eachErrs
  let reserved := ["evaluate-operator", "create-preferences", "initialize-" ++ s.task]
  let nameErr := if reserved.contains o.name then [s!"{ctx}: reserved name"] else []
  let implErr := match o.impl with
    | .atomic => []
    | .steps ns => if ns.isEmpty then [s!"{ctx}: no steps"] else
        if ns.eraseDups.length != ns.length then [s!"{ctx}: repeated step"] else []
    | .sub so =>
      -- `local` (this level's substate attributes) and, in nested sub-operators, `up` (the parent's)
      let isLocal (r : String × String) := (r.1 == "local" && (o.locals.any (·.1 == r.2) || !so.all (·.subs.isEmpty))) || r.1 == "up"
      let checkRef := fun (s : Schema) (ps : List (String × String)) (c : String) (r : String × String) =>
        if isLocal r then [] else Agent.checkRef s ps c r
      let checkGuard := fun (s : Schema) (ps : List (String × String)) (c : String) (g : Guard) =>
        match g with
        -- a link compared with an object parameter: checked as anywhere else
        | .cmp _ _ _ (.obj _) => Agent.checkGuard s ps c g
        | .cmp ob att _ r => checkRef s ps c (ob, att) ++ r.refs.flatMap (checkRef s ps c)
        | g => Agent.checkGuard s ps c g
      (if so.isEmpty then [s!"{ctx}: no sub-operators"] else []) ++
      (o.locals.flatMap fun (_, e) => e.refs.flatMap (Agent.checkRef s allPs s!"{ctx} local")) ++
      (if (so.map (·.name)).eraseDups.length != so.length then [s!"{ctx}: repeated sub-operator"] else []) ++
      so.flatMap fun x =>
        let c := s!"{ctx}/{x.name}"
        -- a retrieval's variable is read by the apply effects like a parameter (its type: a type
        -- of the long-term knowledge, not held by the state)
        let rps : List (String × String) := match x.retrieve with | some r => [(r.var, r.ty)] | none => []
        let ps := allPs ++ x.params ++ rps
        (match x.retrieve with
         | some r => (if s.types.any (·.name == r.ty) then [] else [s!"{c}: no type {r.ty} (retrieve)"]) ++
             r.cue.flatMap (fun (a, e) => (if (s.attr? r.ty a).isSome then [] else [s!"{c}: {r.ty} has no {a} (retrieve cue)"]) ++
               e.refs.flatMap (checkRef s (allPs ++ x.params) c))
         | none => []) ++
        (x.apply.flatMap fun cs => cs.store.flatMap fun (t, vals) =>
          if !(s.types.any (·.name == t)) then [s!"{c}: no type {t} (store)"] else
          vals.flatMap fun (a, e) => (if (s.attr? t a).isSome then [] else [s!"{c}: {t} has no {a} (store)"]) ++
            e.refs.flatMap (checkRef s ps c)) ++
        (x.params.flatMap fun (p, t) =>
          (if (s.holder? t).isSome then [] else [s!"{c}: no state attribute holds {t} ({p})"]) ++
          (if allPs.any (·.1 == p) || p == "local" then [s!"{c}: parameter {p} repeats a name"] else [])) ++
        (x.propose ++ x.apply.flatMap (·.guard)).flatMap (checkGuard s ps c) ++
        x.apply.flatMap (checkStateEffects s ps c) ++
        x.apply.flatMap (checkCreates s ps c) ++
        (x.apply.flatMap (·.effects)).flatMap (fun e =>
          (match e.val with | .obj _ => [] | _ => checkRef s ps c (e.obj, e.attr)) ++
          e.val.refs.flatMap (checkRef s ps c)) ++
        (x.apply.flatMap (·.write)).flatMap (fun m => m.refs.flatMap (checkRef s ps c)) ++
        (if x.apply.isEmpty && x.subs.isEmpty then [s!"{c}: no apply case"] else [])
  let caseErr := if o.apply.isEmpty then [s!"{ctx}: no apply case"] else []
  let altErr := if !o.proposeAlt.isEmpty && allPs.length != 1 then [s!"{ctx}: alternative proposals need exactly one parameter (v0)"] else []
  paramErrs ++ vparamErrs ++ guardErrs ++ writeErrs ++ effErrs ++ nameErr ++ implErr ++ caseErr ++ altErr

def checkDerive (s : Schema) (d : Derive) : List String :=
  let ctx := s!"derive {d.ty}.{d.attr}"
  (match s.attr? d.ty d.attr with
   | none => [s!"{ctx}: undeclared"]
   | some a => if a.derived then [] else [s!"{ctx}: attribute is not declared derived"]) ++
  -- stratified: only non-derived attributes of the same object
  d.val.refs.flatMap fun (o, a) =>
    if o != "self" then [s!"{ctx}: refers to {o}"] else
    match s.attr? d.ty a with
    | none => [s!"{ctx}: {d.ty} has no attribute {a}"]
    | some x => if x.derived then [s!"{ctx}: depends on derived {a} (not stratified)"] else []

def checkObjPat (s : Schema) (t ctx : String) (p : ObjPat) : List String :=
  p.flatMap fun (a, _) =>
    match s.attr? t a with
    | none => [s!"{ctx}: {t} has no attribute {a}"]
    | some d => if d.ty == .int then [] else [s!"{ctx}: {t}.{a} is not an integer"]

def checkStatePat (s : Schema) (ctx : String) (p : StatePat) : List String :=
  (if (s.holder? p.ty).isSome then [] else [s!"{ctx}: no state attribute holds {p.ty}"]) ++
  p.objs.flatMap (checkObjPat s p.ty ctx)

/-- Named objects: holder, values, a declared symbolic `name`, unique names, links to named objects
of the declared type. -/
def checkObjs (a : Agent) : List String :=
  let s := a.schema
  let names := a.objs.map (·.name)
  (if names.eraseDups.length != names.length then ["objects: repeated name"] else []) ++
  a.objs.flatMap fun o =>
    let ctx := s!"object {o.name}"
    match s.stateAttrs.find? (·.name == o.holder) with
    | some { ty := .obj t, multi := true, .. } =>
      checkObjPat s t ctx o.vals ++
      (match s.attr? t "name" with
       | some { ty := .sym _, derived := false, .. } => []
       | _ => [s!"{ctx}: {t} declares no symbolic attribute name"]) ++
      -- every value attribute is given; links are optional (the table is on nothing)
      -- (sets may start empty)
      (((s.type? t).map (fun ty => ty.attrs.filter (fun d => !d.derived && d.name != "name" && !d.multi &&
          !(match d.ty with | .obj _ => true | _ => false) &&
          !o.vals.any (·.1 == d.name) && !o.links.any (·.1 == d.name))
        |>.map fun d => s!"{ctx}: missing {d.name}")).getD []) ++
      (o.links.map (·.1)).eraseDups.flatMap (fun attr =>
        if (o.links.filter (·.1 == attr)).length > 1 && !((s.attr? t attr).map (·.multi)).getD false then
          [s!"{ctx}: several {attr} links, but {t}.{attr} is not multi-valued"] else []) ++
      o.links.flatMap fun (attr, target) =>
        match s.attr? t attr, a.objs.find? (·.name == target) with
        | some { ty := .obj t', .. }, some x =>
          match s.stateAttrs.find? (·.name == x.holder) with
          | some { ty := .obj tx, .. } => if tx == t' then [] else [s!"{ctx}: {attr} links to a {t'}, {target} is a {tx}"]
          | _ => [s!"{ctx}: {target} has no holder"]
        | some _, some _ => [s!"{ctx}: {attr} is not object-valued"]
        | none, _ => [s!"{ctx}: {t} has no attribute {attr}"]
        | _, none => [s!"{ctx}: no object {target}"]
    | _ => [s!"{ctx}: {o.holder} is not a multi-valued object attribute of the state"]

/-- The object type of a named object. -/
def Agent.namedType? (a : Agent) (n : String) : Option String :=
  (a.objs.find? (·.name == n)).bind fun o =>
    match (a.schema.stateAttrs.find? (·.name == o.holder)).map (·.ty) with
    | some (VType.obj t) => some t
    | _ => none

def checkExtras (a : Agent) : List String :=
  let s := a.schema
  let goalName := match a.goal.name with
    | none => []
    | some n => if a.namedType? n == some a.goal.ty then [] else [s!"goal: no {a.goal.ty} named {n}"]
  let failErrs := a.failure.flatMap fun f =>
    if (s.holder? f.ty).isNone then [s!"failure: no state attribute holds {f.ty}"] else
    f.guard.flatMap (checkGuard s [("self", f.ty)] s!"failure on {f.ty}")
  let prefErrs := a.prefs.flatMap fun p =>
    match a.ops.find? (·.name == p.op) with
    | none => [s!"preference {p.name}: no operator {p.op}"]
    | some o =>
      let fields := o.params.map (·.1) ++ o.vparams.map (·.1)
      p.sameAsLast.flatMap fun (x, y) =>
        (if fields.contains x then [] else [s!"preference {p.name}: {x} is not a field of {p.op}"]) ++
        (if fields.contains y then [] else [s!"preference {p.name}: {y} is not a field of {p.op}"]) ++
      p.guard.flatMap (checkGuardV s o.params (o.vparams.map (·.1)) s!"preference {p.name}") ++
      p.lastGuard.flatMap (checkGuardV s (o.params.map fun (q, t) => ("last-" ++ q, t))
        (o.vparams.map ("last-" ++ ·.1)) s!"preference {p.name} (last)") ++
      (p.than.flatMap fun n => if a.ops.any (·.name == n) then [] else [s!"preference {p.name}: no operator {n}"]) ++
      (if !p.than.isEmpty && p.value != .better && p.value != .reject then [s!"preference {p.name}: `than` needs value better or reject"] else []) ++
      (match p.than with
       | [n] => match a.ops.find? (·.name == n) with
         | some o2 => p.versus.flatMap (checkGuardV s (o.params ++ o2.params.map fun (q, t) => ("other-" ++ q, t)) [] s!"preference {p.name} (versus)")
         | none => []
       | _ => if p.versus.isEmpty then [] else [s!"preference {p.name}: `versus` needs exactly one operator in `than`"]) ++
      (if p.sameAsLast.isEmpty && p.guard.isEmpty && p.lastGuard.isEmpty && p.than.isEmpty then [s!"preference {p.name}: no condition"] else [])
  let prefNames := a.prefs.map (·.name)
  let prefDup := if prefNames.eraseDups.length != prefNames.length then ["repeated preference name"] else []
  let failNeeded := if a.prefs.any (·.failure.isSome) && a.failure.isEmpty then
    ["preferences test failure states, but none are declared"] else []
  let scoreErrs := match a.method with
    | .lookahead _ _ _ (some sc) =>
      (if (s.holder? sc.ty).isNone then [s!"score: no state attribute holds {sc.ty}"] else []) ++
      (match sc.name with
       | some n => if a.namedType? n == some sc.ty then [] else [s!"score: no {sc.ty} named {n}"]
       | none => []) ++
      (if sc.val.vrefs.isEmpty then [] else ["score: refers to value parameters"]) ++
      sc.val.refs.flatMap (checkRef s [("self", sc.ty)] "score")
    | _ => []
  let rewardErrs := match a.method with
    | .rl _ (some _) _ _ => if a.failure.isEmpty then ["failure reward, but no failure states are declared"] else []
    | _ => []
  let reportErrs := a.goal.report.flatMap fun m =>
    m.refs.flatMap (checkRef s [("self", a.goal.ty)] "goal report") ++
    (if (Msg.vrefs m).isEmpty then [] else ["goal report: refers to value parameters"])
  checkObjs a ++ goalName ++ reportErrs ++ failErrs ++ prefErrs ++ prefDup ++ failNeeded ++ scoreErrs ++ rewardErrs

def check (a : Agent) : List String :=
  let s := a.schema
  let opNames := a.ops.map (·.name)
  let dupOps := if opNames.eraseDups.length != opNames.length then ["repeated operator name"] else []
  let initErrs := a.init.flatMap fun (attr, vals) =>
    match s.stateAttrs.find? (·.name == attr) with
    | some { ty := .obj t, multi := true, .. } =>
      checkObjPat s t s!"init {attr}" vals ++
      ((s.type? t).map (fun ty => ty.attrs.filter (fun d => !d.derived && !d.multi && !vals.any (·.1 == d.name))
        |>.map fun d => s!"init {attr}: missing {d.name}")).getD []
    | _ => [s!"init: {attr} is not a multi-valued object attribute of the state"]
  let derivedCovered := s.types.flatMap fun t => t.attrs.filter (·.derived) |>.flatMap fun d =>
    if a.derive.any (fun x => x.ty == t.name && x.attr == d.name) ||
       a.flags.any (fun x => x.ty == t.name && x.attr == d.name) then [] else
      [s!"derived {t.name}.{d.name} has no derivation"]
  let ltmErrs := a.ltm.flatMap fun (t, vals) =>
    if !(s.types.any (·.name == t)) then [s!"ltm: no type {t}"] else
    vals.filterMap fun (k, _) => if (s.attr? t k).isSome then none else some s!"ltm: {t} has no {k}"
  let allSubs := (a.ops.flatMap fun o => match o.impl with | .sub xs => xs | _ => []) ++ a.subLib
  let subLibErrs := allSubs.flatMap fun x => x.subs.filterMap fun n =>
    if a.subLib.any (·.name == n) then none else some s!"sub-operator {x.name}: no {n} in the sub-operator library"
  let flagErrs := ltmErrs ++ subLibErrs ++ a.flags.flatMap fun f =>
    let ctx := s!"flag {f.ty}.{f.attr}"
    (match s.attr? f.ty f.attr with
     | some { ty := .int, derived := true, .. } => []
     | _ => [s!"{ctx}: not a derived integer attribute"]) ++
    (if a.derive.any (fun x => x.ty == f.ty && x.attr == f.attr) then [s!"{ctx}: also derived by an expression"] else []) ++
    (if f.via == "" then f.base.flatMap (checkGuard s [("self", f.ty)] ctx) ++
       (if f.step.isEmpty then [] else [s!"{ctx}: a step needs a link"]) else
     match s.attr? f.ty f.via with
     | some { ty := .obj t, .. } =>
       f.base.flatMap (checkGuard s [("self", f.ty)] ctx) ++
       f.step.flatMap (checkGuard s [("self", f.ty), ("below", t)] ctx)
     | _ => [s!"{ctx}: {f.via} is not a link of {f.ty}"])
  let keyErrs := s.types.flatMap fun t => match t.key with
    | some k =>
      (if t.attrs.any (·.name == k) then [] else [s!"{t.name}: key {k} undeclared"]) ++
      -- key values are unique among the initial objects, and no operator changes the key
      (let ks := a.init.filterMap fun (h, vals) =>
          if (s.stateAttrs.find? (·.name == h)).map (·.ty) == some (.obj t.name) then vals.lookup k else none
       if ks.eraseDups.length == ks.length then [] else [s!"{t.name}: key {k} not unique initially"]) ++
      (a.ops.flatMap fun o => o.apply.flatMap (·.effects) |>.filterMap fun e =>
        if e.attr == k && (o.params.lookup e.obj) == some t.name then some s!"operator {o.name} changes key {k}" else none)
    | none => []
  let methodErrs := match a.method with
    | .random => []
    | .tieHeuristic hs =>
      (hs.flatMap fun h => (h.last ++ h.cands).flatMap fun n =>
        if n == "none" || opNames.contains n then [] else [s!"heuristic: no operator {n}"]) ++
      -- the evaluation is total and single-valued: exactly one heuristic for each
      -- (last operator, candidate)
      (("none" :: opNames).flatMap fun l => opNames.flatMap fun c =>
        match (hs.filter fun h => h.last.contains l && h.cands.contains c).length with
        | 1 => []
        | 0 => [s!"heuristic: nothing evaluates {c} after {l}"]
        | _ => [s!"heuristic: several values for {c} after {l}"])
    | .lookahead av _ _ _ => av.flatMap (checkStatePat s "avoid") ++
        (s.types.filter (fun t => (s.holder? t.name).isSome && t.key.isNone)).map
          (fun t => s!"look-ahead needs a key for {t.name}")
    | .rl rs _ _ _ => rs.flatMap (fun (p, _) => checkStatePat s "reward" p)
  let learnErrs := match a.method, a.learning with
    | .rl .., .rl _ _ | .rl .., .chunkRl _ _ _ => []
    | .rl .., _ => ["method rl needs rl learning"]
    | _, _ => []
  let consErrs := a.constraints.flatMap fun c =>
    if (s.type? c.ty).isNone then [s!"constraint: no type {c.ty}"] else
    c.guard.flatMap (checkGuard s [("self", c.ty)] s!"constraint on {c.ty}")
  dupOps ++ consErrs ++ a.ops.flatMap (checkOp s) ++ a.derive.flatMap (checkDerive s) ++ initErrs ++
    derivedCovered ++ flagErrs ++ keyErrs ++ checkObjPat s a.goal.ty "goal" a.goal.vals ++
    (if (s.holder? a.goal.ty).isSome then [] else ["goal: no state attribute holds the type"]) ++
    methodErrs ++ learnErrs ++ checkExtras a

/-! ## Comparing two descriptions (round trip)

Used to compare a description with one re-formalized from its English: which parts differ.
Documentation strings and assumptions are not compared. -/

def Operator.core (o : Operator) : Operator := { o with doc := "" }
def Schema.core (s : Schema) : Schema :=
  { s with stateAttrs := s.stateAttrs.map ({ · with doc := "" }),
           types := s.types.map fun t => { t with doc := "", attrs := t.attrs.map ({ · with doc := "" }) } }

/-- The evaluation a heuristic list gives each (last operator or `none`, candidate): its meaning,
independent of how the entries are grouped or ordered. -/
def heurTable (ops : List String) (hs : List Heur) : List (String × String × Option HVal) :=
  ("none" :: ops).flatMap fun l => ops.map fun c =>
    (l, c, (hs.find? fun h => h.last.contains l && h.cands.contains c).map (·.value))

/-- Methods compared by meaning: tie heuristics by their table. -/
def methodEquiv (ops : List String) : Method → Method → Bool
  | .tieHeuristic h1, .tieHeuristic h2 => heurTable ops h1 == heurTable ops h2
  | m1, m2 => m1 == m2

def diffCore (a b : Agent) : List String :=
  (if a.schema.core == b.schema.core then [] else ["schema"]) ++
  (if a.init == b.init then [] else ["init"]) ++
  (if a.derive == b.derive then [] else ["derive"]) ++
  ((a.ops.zip b.ops).filterMap fun (x, y) => if x.core == y.core then none else some s!"operator {x.name}") ++
  (if a.ops.length == b.ops.length then [] else ["number of operators"]) ++
  (if a.goal == b.goal then [] else ["goal"]) ++
  (if (a.constraints.map fun c => (c.ty, c.guard)) == (b.constraints.map fun c => (c.ty, c.guard)) then [] else ["constraints"]) ++
  (if methodEquiv (a.ops.map (·.name)) a.method b.method then [] else ["method"]) ++
  (if a.learning == b.learning then [] else ["learning"])

end Agent
