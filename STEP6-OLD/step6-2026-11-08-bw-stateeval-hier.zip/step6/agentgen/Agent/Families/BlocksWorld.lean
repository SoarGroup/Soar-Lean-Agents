import Agent.DSL
import Agent.Sem

/-!
# Family: Blocks World

75 originals (step 6, `families/blocks-world`). The task: blocks on a table, each on the table or
on one other block; move a clear block onto the table or onto another clear block until the
desired stacking holds. The methods vary: simple search-control preferences (BW-Simple,
blocks-world-simple), one-step and deeper look-ahead with the selection library (BW-LA,
blocks-world-lookahead, the look-ahead demos), look-ahead with state evaluation and RL (BW-LA-state-
eval), hierarchical operators (move-block carried out by pick-up/put-down with a gripper;
BW-Hierarchical, blocks-world-hierarchical, hierarchical look-ahead), operator subgoaling (means-
ends analysis; BW-Op-Subgoal, blocks-world-operator-subgoaling, ±RL), RL (BW-RL, blocks-world-RL),
hierarchical RL, episodic memory. This file has the task and the variants built so far.

Representation: one object type for the blocks and the table, each with a `name`, `table` (1 for
the table) and a changing link `on` (what it rests on; the table rests on nothing). The originals
keep separate `^ontop` objects (`^top-block`, `^bottom-block`); `move-block` changes the bottom
block, here the moved block's `on`.
-/

namespace Agent.BlocksWorld

def obj : String := "object"

/-- Nothing is on `p`. -/
def clear (p : String) : Guard := .noneSuch obj [("on", .eq, .obj p)]

def clearAttr : AttrDecl where
  name := "clear"
  ty := .int
  derived := true
  doc := "1 when something can be put on it: the table, or a block with nothing on it"

def objAttrs (withClear : Bool) : List AttrDecl :=
  [{ name := "name", ty := .sym [], doc := "the block's name (A, B, …) or table" },
   { name := "table", ty := .int, doc := "1 for the table, 0 for a block" },
   { name := "on", ty := .obj obj, doc := "what it rests on (changes as blocks move; the table has none)" },
   { name := "in-place", ty := .int, derived := true,
     doc := "1 when it is where the goal wants it all the way down (the table always)" }] ++
  (if withClear then [clearAttr] else [])

def schema (task : String) (withClear : Bool := false) : Schema where
  task := task
  stateAttrs := [{ name := "object", ty := .obj obj, multi := true, doc := "The blocks and the table." }]
  types := [{ name := obj, key := some "name", attrs := objAttrs withClear }]

/-- "Clear" (the operator-subgoaling originals' `^clear`): the table, or an object with nothing on it. -/
def clearFlags : List Flag := [
  { ty := obj, attr := "clear", base := [.cmp "self" "table" .eq (.lit 1)], doc := "the table is clear" },
  { ty := obj, attr := "clear", base := [clear "self"], doc := "nothing is on it" }]

/-- "In place" (the originals' `^inplace-object`): the table is; a block is when it is on what the
goal puts it on and that is in place. -/
def inPlace : Flag where
  ty := obj
  attr := "in-place"
  base := [.cmp "self" "table" .eq (.lit 1)]
  via := "on"
  step := [.desired "self" "on" "below"]
  doc := "in place: the table, or on its desired object which is in place"

/-- Move a clear block onto the table or onto another clear block. -/
def moveBlock : Operator where
  name := "move-block"
  params := [("block", obj), ("dest", obj)]
  propose := [
    .cmp "block" "table" .eq (.lit 0),
    clear "block",
    .distinct "block" "dest",
    .cmp "block" "on" .ne (.obj "dest")]
  proposeOr := [
    [.cmp "dest" "table" .eq (.lit 1)],
    [.cmp "dest" "table" .eq (.lit 0), clear "dest"]]
  apply := [{ effects := [{ obj := "block", attr := "on", val := .obj "dest" }] }]
  doc := "Move a clear block onto the table or onto another clear block."

/-- move-block for operator subgoaling (the operator-subgoaling originals): proposed whenever it is
relevant (a block, a different destination it is not already on); its preconditions — the block
and the destination are clear — are what its substate works on. -/
def moveBlockOpSub : Operator where
  name := "move-block"
  params := [("block", obj), ("dest", obj)]
  propose := [.cmp "block" "table" .eq (.lit 0), .distinct "block" "dest", .cmp "block" "on" .ne (.obj "dest")]
  pre := [.flag "block" "clear" true, .flag "dest" "clear" true]
  pregoals := [("clear", "block"), ("clear", "dest")]
  apply := [{ effects := [{ obj := "block", attr := "on", val := .obj "dest" }] }]
  doc := "Move a block onto the table or onto another block; both must be clear."

/-- move-block for operator subgoaling with relevant moves only (BW-Op-Subgoal-RL,
blocks-world-operator-subgoaling-RL): at the top state, a move the goal asks for (a block onto what
the goal puts it on); in a subgoal, moving the block that is on something the subgoal wants clear
onto a clear object. Two proposal rules (disjoint: the first tests the task's goal, which holds
only at the top state; the second the subgoal's). -/
def moveBlockRelevant : Operator :=
  { moveBlockOpSub with
    proposeOr := [
      [.desired "block" "on" "dest"],
      [.wants "clear" "block" (some "on"), .flag "dest" "clear" true]] }

/-- The operator-subgoaling originals' search control (wants: the substate's goals). -/
def opSubControl : List Pref := [
  { name := "avoid-clobbering", op := "move-block", value := .worst, sameAsLast := [],
    guard := [.wants "clear" "dest" none], doc := "Do not put a block on something the subgoal wants clear." },
  { name := "prefer-ontop", op := "move-block", value := .best, sameAsLast := [],
    guard := [.desired "block" "on" "dest"], doc := "Prefer a move the goal asks for." },
  { name := "prefer-clearing", op := "move-block", value := .best, sameAsLast := [],
    guard := [.wants "clear" "block" (some "on")], doc := "Prefer moving the block that is on something the subgoal wants clear." }]

/-- An instance: blocks with what each starts on, and the desired `on` of each block. -/
structure Instance where
  start : List (String × String)
  goal : List (String × String)

/-- The operator-subgoaling originals' instance: A on B, B and C on the table; goal A on B on C. -/
def threeOpSub : Instance := { start := [("A", "B"), ("B", "table"), ("C", "table")],
                               goal := [("A", "B"), ("B", "C"), ("C", "table")] }

/-- The originals' three-block instance: C on A, A and B on the table; goal A on B on C. -/
def three : Instance := { start := [("A", "table"), ("B", "table"), ("C", "A")],
                          goal := [("A", "B"), ("B", "C"), ("C", "table")] }

/-- The originals' five-block instance (BW-Simple, blocks-world-simple): C on A, A and D on the
table, E on D, B on E; goal A on B on C on D on E. -/
def five : Instance := { start := [("A", "table"), ("B", "E"), ("C", "A"), ("D", "table"), ("E", "D")],
                         goal := [("A", "B"), ("B", "C"), ("C", "D"), ("D", "E"), ("E", "table")] }

/-- The RL originals' four-block instance (BW-RL, blocks-world-RL): C on A, A and D on the table,
B on D; goal A on B on C on D on the table. -/
def four : Instance := { start := [("A", "table"), ("B", "D"), ("C", "A"), ("D", "table")],
                         goal := [("A", "B"), ("B", "C"), ("C", "D"), ("D", "table")] }

/-- The search control of the simple originals (P6, P7): moving a block that is not in place
onto the table is best; moving a block onto the in-place object the goal puts it on is better
than any other move. -/
def simpleControl : List Pref := [
  { name := "out-of-place-to-table", op := "move-block", value := .best, sameAsLast := [],
    guard := [.flag "block" "in-place" false, .cmp "dest" "table" .eq (.lit 1)],
    doc := "Move a block that is not in place to the table." },
  { name := "onto-desired-in-place", op := "move-block", value := .better, sameAsLast := [],
    guard := [.flag "dest" "in-place" true, .desired "block" "on" "dest"],
    doc := "Move a block onto what the goal puts it on, when that is in place." }]

/-- BW-LA-state-eval's evaluation of a look-ahead state: by how much of the goal stack is in
place, from the bottom (C 0.3, C and B 0.6, all 1.0; none 0), as an expected value. -/
def stackLevels : Score := { ty := obj, levels := [("A", 1000), ("B", 600), ("C", 300)], expected := true }

/-- The search control of the look-ahead originals: never move the same block twice in a row. -/
def notTwice : List Pref := [
  { name := "reject-twice", op := "move-block", value := .reject, sameAsLast := [("block", "block")],
    inLookahead := true, doc := "In look-ahead, do not move the block just moved." }]

def assumptions : List Assumption := [
  { id := "A1", text := "Representation: one object type for blocks and the table, with `name`, `table` (1 for the table) and a changing link `on`. The originals keep `^ontop` objects (`^top-block`, `^bottom-block`) and `^type block/table`; `move-block` changes an ontop's bottom block, here the moved block's `on` (a changing link, `block.on := dest`)." },
  { id := "A2", text := "move-block(block, dest): proposed when the block is clear and not already on dest, and dest is the table or another clear block (two proposal rules, disjoint). The originals elaborate `^clear` (blocks with nothing on them, and always the table) and propose from it." },
  { id := "A3", text := "Goal: the desired `on` of every block, as `^desired` links to the task's own objects (the originals' desired ontops); success halts at the top state." },
  { id := "A5", text := "Simple variants: the originals' P6 (moving a block that is not in place to the table is best) and P7 (moving a block onto the in-place object the goal puts it on is better than every other move, binary preferences); \"in place\" is a derived flag (elaborated recursively along `on`, as the originals' `^inplace-object`). The originals elaborate success from in-place objects; here the goal is the desired links. blocks-world V2 also has three RL template rules with no reward or RL settings; they are dropped." },
  { id := "A6", text := "RL variant (BW-RL V1, V2, blocks-world-RL V2): reward 1 when the goal holds (then halt), Soar's default RL (learning rate 0.3, discount 0.9, epsilon-greedy 0.1), learning over repeated runs (init-soar between). The originals list 5120 RL rules, one for each configuration of the four blocks and each move, all at 0; here one RL template tests the operator and the whole state (`Agent.rlWholeState`: every block's `on`), so Soar makes the same rules, each when its configuration and move first occur." },
  { id := "A7", text := "Operator subgoaling with relevant moves (BW-Op-Subgoal-RL V1, blocks-world-operator-subgoaling-RL V2–V4): move-block is proposed only when relevant — at the top state a move the goal asks for, in a subgoal moving a block off something the subgoal wants clear onto a clear object — and chosen at random. The originals also turn RL on with an RL template over the subgoal's operator, the configuration and the move, and rewards (1 at the goal; 1 when a subgoal's blocks are clear); in Soar 9.6.5 every rule instantiated from that template is malformed (its state and its operator are the same identifier: defect 28), so none ever matches and the choice is random. The variant has that behaviour: no RL. Four blocks (V1; V4's rules are V1's; V2/V3 differ in a rule name and one redundant test)." },
  { id := "A8", text := "Look-ahead with state evaluation (BW-LA-state-eval V1, V2, blocks-world-lookahead-state-evaluation V2, V3; their task rules are identical): a tie is resolved by one-step look-ahead whose state is scored by how much of the goal stack is in place (`Score.levels`: C 0.3, B 0.6, A 1.0, none 0) as an expected value; chunking makes RL rules from the evaluations (`Learning.chunkRl`, Soar's default rate 0.3 and discount 0.9), which RL tunes in later runs, with reward 1 at the goal (`Agent.goalReward`, the originals' reward.soar). The score rules test every block's `on` (`Agent.rlWholeState`), as the originals' `evaluate-state` rules test every `ontop`, so each chunk is for one configuration; the goal gives no `^success` inside the look-ahead (`Agent.lookaheadSuccess := false`): as in the originals, a look-ahead reaching it is valued 1.0, so every evaluation chunk is an RL rule and none is a best preference. The originals score with an `evaluate-state` operator in the evaluation substate (best, so the look-ahead is one step); here an elaboration gives the same expected value. Their `^moveable` excludes a `last-bottom` that nothing sets, so it is `clear`. No duplicate-state detection and no rejection of moving the same block again, as the originals." },
  { id := "A9", text := "Hierarchical (BW-Hierarchical V1, V2, blocks-world-hierarchical V2–V5): move-block is carried out by pick-up and put-down in its substate, and those by gripper operators (move the gripper up, above an object, down; close; open) in theirs. The gripper is an object of the task state (position, open, above, holding, empty); the gripper operators change it directly, and close/open pick up and put down the block. The originals write gripper commands to the output-link and simulate the world with o-supported rules on the top state (`apply*…*external`); after close the gripper is above what the block stood on (here: above the block), and the held block keeps its `ontop` (here: `on`) until it is put down. pick-up's and put-down's gripper operators have distinct names here (move-gripper-up-holding, …-above-destination, …-down-holding), the originals use the same names in both substates. Search control: the simple originals' P6/P7. Clear excludes a held block, as the originals." },
  { id := "A4", text := "Look-ahead variant: the selection library, no duplicate-state detection (the originals have none), chunking on. As in the originals, moving the block just moved is rejected inside look-ahead states only (at the top state it may be the only move)." }]

def mk (task : String) (inst : Instance) (method : Method) (prefs : List Pref) (learning : Learning)
    (opsub : Bool := false) : Agent where
  schema := schema task opsub
  init := []
  objs := { holder := "object", name := "table", vals := [("table", 1)] } ::
    inst.start.map fun (b, on) => { holder := "object", name := b, vals := [("table", 0)], links := [("on", on)] }
  derive := []
  ops := [if opsub then moveBlockOpSub else moveBlock]
  goal := { ty := obj, vals := [], links := inst.goal.map fun (b, on) => (b, "on", on) }
  constraints := []
  flags := inPlace :: (if opsub then clearFlags else [])
  subgoaling := opsub
  prefs := prefs
  method := method
  learning := learning
  assumptions := assumptions


/-! ## Hierarchical: move-block carried out by pick-up and put-down, and those by gripper operators

BW-Hierarchical V1, V2, blocks-world-hierarchical V2–V5: three levels. The gripper is an object
of the task state (`position` 1 up / 0 down, `open`, `above`, `holding`, `empty`). -/

def gripperT : String := "gripper"

def gripperAttrs : List AttrDecl := [
  { name := "name", ty := .sym [], doc := "gripper" },
  { name := "position", ty := .int, doc := "1 up, 0 down" },
  { name := "open", ty := .int, doc := "1 open, 0 closed" },
  { name := "empty", ty := .int, doc := "1 holding nothing, 0 holding the block `holding`" },
  { name := "above", ty := .obj obj, doc := "what the gripper is above" },
  { name := "holding", ty := .obj obj, doc := "the block held (meaningful when empty = 0)" }]

def hierSchema (task : String) : Schema where
  task := task
  stateAttrs := [{ name := "object", ty := .obj obj, multi := true, doc := "The blocks and the table." },
                 { name := "gripper", ty := .obj gripperT, multi := true, doc := "The gripper." }]
  types := [{ name := obj, key := some "name", attrs := objAttrs true },
            { name := gripperT, key := some "name", attrs := gripperAttrs }]

/-- Clear: the table; or an object with nothing on it that the gripper does not hold. -/
def hierClear : List Flag := [
  { ty := obj, attr := "clear", base := [.cmp "self" "table" .eq (.lit 1)], doc := "the table is clear" },
  { ty := obj, attr := "clear", base := [clear "self", .noneSuch gripperT [("empty", .eq, .lit 0), ("holding", .eq, .obj "self")]],
    doc := "nothing is on it and it is not held" }]

def geff (a : String) (v : Expr) : Effect := { obj := "g", attr := a, val := v }

/-- The gripper operators (the bottom level), in pick-up's and put-down's substates. -/
def gripperSubs : List SubOp := [
  -- pick-up
  { name := "move-gripper-up", propose := [.cmp "g" "position" .eq (.lit 0), .cmp "g" "empty" .eq (.lit 1), .cmp "g" "above" .ne (.obj "block")],
    apply := [{ effects := [geff "position" (.lit 1)] }], doc := "Raise the empty gripper." },
  { name := "move-gripper-above", propose := [.cmp "g" "position" .eq (.lit 1), .cmp "g" "empty" .eq (.lit 1), .cmp "g" "above" .ne (.obj "block")],
    apply := [{ effects := [geff "above" (.obj "block")] }], doc := "Move the empty gripper above the block." },
  { name := "move-gripper-down", propose := [.cmp "g" "position" .eq (.lit 1), .cmp "g" "above" .eq (.obj "block"), .cmp "g" "empty" .eq (.lit 1)],
    apply := [{ effects := [geff "position" (.lit 0)] }], doc := "Lower the gripper onto the block." },
  { name := "close-gripper", propose := [.cmp "g" "position" .eq (.lit 0), .cmp "g" "open" .eq (.lit 1), .cmp "g" "empty" .eq (.lit 1), .cmp "g" "above" .eq (.obj "block")],
    apply := [{ effects := [geff "open" (.lit 0), geff "empty" (.lit 0), geff "holding" (.obj "block")] }],
    doc := "Close the gripper on the block: it holds it." },
  -- put-down
  { name := "move-gripper-up-holding", propose := [.cmp "g" "position" .eq (.lit 0), .cmp "g" "above" .ne (.obj "dest")],
    apply := [{ effects := [geff "position" (.lit 1)] }], doc := "Raise the gripper with the block." },
  { name := "move-gripper-above-destination", propose := [.cmp "g" "position" .eq (.lit 1), .cmp "g" "above" .ne (.obj "dest")],
    apply := [{ effects := [geff "above" (.obj "dest")] }], doc := "Move the gripper above the destination." },
  { name := "move-gripper-down-holding", propose := [.cmp "g" "position" .eq (.lit 1), .cmp "g" "above" .eq (.obj "dest")],
    apply := [{ effects := [geff "position" (.lit 0)] }], doc := "Lower the gripper onto the destination." },
  { name := "open-gripper", propose := [.cmp "g" "position" .eq (.lit 0), .cmp "g" "open" .eq (.lit 0), .cmp "g" "above" .eq (.obj "dest")],
    apply := [{ effects := [geff "open" (.lit 1), geff "empty" (.lit 1), geff "above" (.obj "block"),
                            { obj := "block", attr := "on", val := .obj "dest" }] }],
    doc := "Open the gripper: the block is on the destination." }]

/-- move-block for the hierarchical originals: proposed for a clear block and a clear destination
(the table, or a block nothing is on and the gripper does not hold), when the gripper is empty or
holds this block; carried out by pick-up and put-down. Its effect: the block is on the
destination and the gripper is down above it, open and empty. -/
def moveBlockHier : Operator where
  name := "move-block"
  params := [("block", obj), ("dest", obj), ("g", gripperT)]
  propose := [.cmp "block" "table" .eq (.lit 0), clear "block", .distinct "block" "dest", .cmp "block" "on" .ne (.obj "dest"),
    .flag "dest" "clear" true, .noneSuch gripperT [("empty", .eq, .lit 0), ("holding", .ne, .obj "block")]]
  apply := [{ effects := [{ obj := "block", attr := "on", val := .obj "dest" }, geff "position" (.lit 0), geff "open" (.lit 1),
                          geff "empty" (.lit 1), geff "above" (.obj "block"), geff "holding" (.obj "block")] }]
  impl := .sub [
    { name := "pick-up", propose := [.cmp "g" "empty" .eq (.lit 1), clear "block"], apply := [],
      subs := ["move-gripper-up", "move-gripper-above", "move-gripper-down", "close-gripper"],
      doc := "Pick up the block, with the gripper operators." },
    { name := "put-down", propose := [.cmp "g" "empty" .eq (.lit 0), .cmp "g" "holding" .eq (.obj "block")], apply := [],
      subs := ["move-gripper-up-holding", "move-gripper-above-destination", "move-gripper-down-holding", "open-gripper"],
      doc := "Put the block down on the destination, with the gripper operators." }]
  doc := "Move a clear block onto the table or another clear block, by picking it up and putting it down."

def mkHier (task : String) (inst : Instance) : Agent where
  schema := hierSchema task
  init := []
  objs := ({ holder := "object", name := "table", vals := [("table", 1)] } ::
    inst.start.map fun (b, on) => { holder := "object", name := b, vals := [("table", 0)], links := [("on", on)] }) ++
    [{ holder := "gripper", name := "gripper", vals := [("position", 1), ("open", 1), ("empty", 1)],
       links := [("above", "table"), ("holding", "table")] }]
  derive := []
  ops := [moveBlockHier]
  subLib := gripperSubs
  goal := { ty := obj, vals := [], links := inst.goal.map fun (b, on) => (b, "on", on) }
  constraints := []
  flags := inPlace :: hierClear
  prefs := simpleControl
  method := .random
  learning := .none
  assumptions := assumptions

def variants : List (String × Agent × List String) := [
  ("blocks-world-operator-subgoaling", mk "blocks-world" threeOpSub .random opSubControl .none true,
    ["blocks-world-operator-subgoaling V1, V3, V6", "BW-Op-Subgoal V1", "FunctionalTests_testBlocksWorldOperatorSubgoaling V1"]),
  ("blocks-world-operator-subgoaling-chunk", mk "blocks-world" threeOpSub .random opSubControl (.chunk []) true,
    ["blocks-world-operator-subgoaling V4", "ChunkingDemoTests_Demo_Blocks_World_Operator_Subgoaling V1"]),
  ("blocks-world-simple", mk "blocks-world" five .random simpleControl .none,
    ["BW-Simple V1, V2", "blocks-world-simple V2–V4"]),
  ("blocks-world-simple-3", mk "blocks-world" three .random simpleControl .none,
    ["blocks-world V2, V3"]),
  ("blocks-world-rl", { mk "blocks-world" four (.rl [] none (some 1)) [] (.rl 300 900) with rlWholeState := true },
    ["BW-RL V1, V2", "blocks-world-RL V2"]),
  ("blocks-world-operator-subgoaling-relevant", { mk "blocks-world" four .random [] .none true with ops := [moveBlockRelevant] },
    ["BW-Op-Subgoal-RL V1", "blocks-world-operator-subgoaling-RL V2–V4"]),
  ("blocks-world-look-ahead-state-eval", { mk "blocks-world" three (.lookahead [] none .off (some stackLevels)) [] (.chunkRl [] 300 900) with goalReward := some 1, rlWholeState := true, lookaheadSuccess := false },
    ["BW-LA-state-eval V1, V2", "blocks-world-lookahead-state-evaluation V2, V3"]),
  ("blocks-world-hierarchical", mkHier "blocks-world" three,
    ["BW-Hierarchical V1, V2", "blocks-world-hierarchical V2–V5"]),
  ("blocks-world-look-ahead", mk "blocks-world" three (.lookahead [] none .off) notTwice (.chunk []),
    ["blocks-world-lookahead V1–V4", "BW-LA V1, V2", "BW-LA-X V1", "blocks-world-look-ahead V1, V2",
     "ChunkingDemoTests_Demo_Blocks_World_Look_Ahead V1", "FunctionalTests_testBlocksWorldLookAhead V1"])]

/-- Every variant obeys the conventions. -/
theorem conventions : variants.all (fun v => check v.2.1 == []) = true := by decide

/-- The three-block instance: three moves (C to the table, B onto C, A onto B), no fewer. -/
theorem three_shortest : ((mk "bw" three .random [] .none).bfs 4).1.map List.length = some 3 := by native_decide

/-- The five-block instance: six moves at least (C, B and E must leave their places first). -/
theorem five_shortest : ((mk "bw" five .random [] .none).bfs 7).1.map List.length = some 6 := by native_decide

/-- Operator subgoaling decides every step of its three-block instance: 3 moves (A to the table,
B onto C, A onto B), each choice left unique by the preferences. -/
theorem opsub_three : (mk "bw" threeOpSub .random opSubControl .none true).runOpSub 30 = some 3 := by native_decide

/-- The simple control decides every step of the three-block instance: following it, the goal is
reached in 3 moves with no random choice. -/
theorem simple_three : (mk "bw" three .random simpleControl .none).runPrefs 10 = some 3 := by native_decide



/-- The four-block instance: four moves at least (C to the table, C onto D, B onto C, A onto B). -/
theorem four_shortest : ((mk "bw" four .random [] .none).bfs 5).1.map List.length = some 4 := by native_decide

/-- Hierarchical: from every state reachable in three moves, each proposed move-block's gripper
operators produce exactly its specified effect. -/
theorem hier_refines : (mkHier "blocks-world" three).refinesSub 3 40 = true := by native_decide

end Agent.BlocksWorld
