# Towers of Hanoi — step 6 (five disks, three pegs)

Lean: `agentgen/Agent/Families/Hanoi.lean`. JL, 7 Nov 2026: five disks on three pegs. The originals use 11 disks (recur V1: 7). The 6 Nov report, written when the family was skipped, is `REPORT-2026-11-06-skipped.md`.

Originals in the queue and their method:

| Originals | Method | Variant |
|---|---|---|
| towers-of-hanoi V1, V2; -fast V1, V2; -faster V1, V2 | iterative: disk 1 moves round the pegs, never back to the peg it last left; every other move is the one legal move of another disk | `towers-of-hanoi` (done) |
| towers-of-hanoi-recursive V1, V2; -recur V1 | means-ends analysis by operator subgoaling | `towers-of-hanoi-mea` (done) |
| tower-of-hanoi-search V1 | iterative-deepening look-ahead through a modified selection library | deferred (see below) |
| towers-of-hanoi-no-ops V1 | no operators: elaborations solve the puzzle in one decision | not replaced (outside the conventions); replaced by `towers-of-hanoi` |

## Variant `towers-of-hanoi`

Representation:
- V1's `holds` records on the state: one per disk, pointing to the disk, its peg (`on`) and the disk directly below it (`above`). This follows STA-030.
- Each peg has a base under it: a disk larger than all the others that never moves, with its own record above a ground disk.
- Moving onto an empty peg is moving onto its base, so one case covers V1's three apply rules and its `^clear`/`^upper-disk` elaborations. "Upper disk" is a negated test: no record is above it.
- A control object holds the size of the disk moved last and the peg disk 1 last left. These are V1's `^last-disk-moved` and `^last-disk1-peg`, starting as disk 2 and peg B.

`move-disk(h, d, t, td, src, target, control)`:
- Proposed when disk d is upper on src and td is upper on target and larger than d, and either:
  - d is disk 1, the last disk moved was not disk 1, and target is not the peg disk 1 last left; or
  - d is not disk 1 and the last disk moved was disk 1.
- Exactly one move is proposed at each step.
- It writes "Move Disk: N to peg P", as V1's monitor does.

Goal: every disk on C (`^desired` links).

New general feature: a message may write a symbolic attribute as it is (here the peg's name). Every other family's output is unchanged.

Assumptions:
- A1: five disks.
- A2: `holds` records.
- A3: the bases.
- A4: `larger` is a size comparison.
- A5: the control object.
- A6: the goal is every disk on C.

Full texts are in the Lean file.

## Results (Soar 9.6.5, seeds 1–3)

The originals were run as five-disk copies, made by `tools/five.py` from the flattened originals. The script drops disks 6–11 and makes disk 5 the bottom; the copies are in `orig5/`. The -fast/-faster monitors are excised in the originals, so the harness adds a print-only monitor for them (`tools/monitor-constants.soar`).

| Agent | Solved | Decisions | Moves | Move sequence |
|---|---|---|---|---|
| `towers-of-hanoi` | 3/3 | 32 | 31 | 1C 2B 1B 3C 1A 2C 1C 4B … (the minimum, 31) |
| towers-of-hanoi V1, V2 | 3/3 | 32 | 31 | identical |
| towers-of-hanoi-fast V1, V2 | 3/3 | 31 | 31 | identical |
| towers-of-hanoi-faster V1, V2 | 3/3 | 31 | 31 | identical |
| towers-of-hanoi-no-ops V1 | 3/3 | 1 | — | no operators |
| towers-of-hanoi-recursive V1, V2 | 3/3 | 47 | 31 | 5C 4B 3C 2B 1C … (goal moves, in subgoal order) |

The -fast/-faster originals take one decision fewer because they have no initialize operator; their initial state is made by an elaboration.

Soar vs soar-lean (`leancmp/`): MATCH (32 decisions to halt, 116 WMEs; regenerated after holds records gained `size`).

Theorems:
- `conventions`.
- `iterative_31`: the iterative method solves five disks in 31 moves.

## Variant `towers-of-hanoi-mea` (means-ends analysis)

The originals: `move-disk(disk, peg)` is a goal. It is proposed when relevant and selected even when it cannot apply. Its operator no-change substate wants the disk on the peg, and the operator applies as soon as it can, which ends the substate.

`move-disk(h, d, src, target, hd, dd)`:
- `dd` is the disk the current goal is about, with record `hd`.
- Three proposal rules (`proposeOr`):
  - put-on-peg, at the top state: the largest disk not on its desired peg, to that peg;
  - clear-disk, in a subgoal: the disk directly on the wanted disk, to the peg that is neither its own nor the wanted peg;
  - clear-smaller, in a subgoal: the largest disk on the wanted peg that is smaller than the wanted disk, to the peg that is neither the wanted peg nor the wanted disk's.
- Preconditions, which are not tested in the proposals:
  - d has nothing on it;
  - the upper disk `td` of the target is larger than d.
- `t`/`td` are apply-time parameters, bound when the move applies, so a change to the target's upper disk does not retract the operator.
- The substate's `^desired` holds `^disk d ^peg target`.

New general features:
- **Apply-time parameters** (`Operator.applyParams`): bound by the preconditions and apply cases. In Soar, from the state in the apply rules.
- **`Guard.unwants`**: the subgoal's `^desired` does not ask for `pred` of `o`.
- **Sem:**
  - in an operator-subgoal substate, a test of the task's goal (`Guard.desired`) fails, as it does in Soar, where `^desired` there holds only the subgoal's goals;
  - proposals there see the subgoal's wants.
  - Blocks World's `opsub_three` theorem still holds.
- **Compiler:** the subgoal's `^desired` variable is `<sgd>`; it was `<d>`, which clashed with a parameter named `d`. Blocks World's operator-subgoaling output changed in that variable name only, and its runs are unchanged (5 and 3 decisions, solved).

Assumption A7 (added):
- A record also holds its disk's size, for size comparisons in negated tests.
- Put-on-peg's "largest disk not on its desired peg" is written for this task's goal, every disk on one peg.
- V1's `select*maintain` (the selected operator is best) is not needed, since one operator is proposed in each state.

Results (Soar 9.6.5, seeds 1–3, moves read from the state after every decision with the harness's `--step`):

| Agent | Solved | Decisions | Moves |
|---|---|---|---|
| `towers-of-hanoi-mea` | 3/3 | 47 | 31 |
| towers-of-hanoi-recursive V1, V2 | 3/3 | 47 | 31, identical |
| towers-of-hanoi-recur V1 | 3/3 | 46 | 31, identical (no initialize operator) |

- The 31 moves are the same as the iterative variant's.
- The generated agent's decision trace has the original's structure: the same substates at the same decisions, and the same operator numbers.

Soar vs soar-lean: MATCH (47 decisions, 116 WMEs).

Theorem: `mea_31`. Run with operator subgoaling, with one operator at every choice, means-ends analysis solves five disks in 31 moves.

## Deferred: tower-of-hanoi-search V1

- It looks ahead through `selection-iterative-deepening.soar`, a modified selection library, and stops at the first top-level move (`:interrupt`).
- On five disks it makes no top-level move in 100,000 decisions; on 11 disks it runs out of memory.
- A replacement needs an iterative-deepening look-ahead. The DSL's look-ahead is Soar's default library, as is.
- It is deferred with graph-search-smem, pending JL's confirmation.
