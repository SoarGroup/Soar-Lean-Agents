# arithmetic

## The task

The task state holds several values of `problem`, each a problem. The problem being worked on.
The task state holds several values of `column`, each a column. The columns of the problem (ones first).
The task state holds several values of `digit`, each a digit. The digits 0–9, to choose from at random.
The task state holds several values of `add-fact`, each a add-fact. Addition facts.
The task state holds several values of `sub-fact`, each a sub-fact. Subtraction facts.
The task state holds several values of `inc-fact`, each a inc-fact. Successor facts (n + 1).
The task state holds several values of `ten-fact`, each a ten-fact. Add-ten facts (n + 10).

A problem has `operation` (an integer), `carry` (an integer), `count` (an integer), `pid` (an integer), `digits` (an integer).

A column has `pos` (an integer), `last` (an integer), `digit1` (an integer), `digit2` (an integer), `result` (an integer), `gen1` (an integer), `gen2` (an integer), `done` (an integer).

A digit has `val` (an integer).

A add-fact has `d1` (an integer), `d2` (an integer), `sum` (an integer), `carry` (an integer).

A sub-fact has `d1` (an integer), `d2` (an integer), `diff` (an integer).

A inc-fact has `n` (an integer), `next` (an integer).

A ten-fact has `n` (an integer), `plus10` (an integer).

Initially the task state has:
- a `problem` with operation 2 and carry 0 and count 1 and pid 1 and digits 6
- a `column` with pos 1 and last 0 and digit1 7 and digit2 8 and result 0 and gen1 1 and gen2 1 and done 0
- a `column` with pos 2 and last 0 and digit1 0 and digit2 7 and result 0 and gen1 1 and gen2 1 and done 0
- a `column` with pos 3 and last 1 and digit1 2 and digit2 1 and result 0 and gen1 1 and gen2 1 and done 0
- a `digit` with val 0
- a `digit` with val 1
- a `digit` with val 2
- a `digit` with val 3
- a `digit` with val 4
- a `digit` with val 5
- a `digit` with val 6
- a `digit` with val 7
- a `digit` with val 8
- a `digit` with val 9
- a `add-fact` with d1 0 and d2 0 and sum 0 and carry 0
- a `add-fact` with d1 0 and d2 1 and sum 1 and carry 0
- a `add-fact` with d1 0 and d2 2 and sum 2 and carry 0
- a `add-fact` with d1 0 and d2 3 and sum 3 and carry 0
- a `add-fact` with d1 0 and d2 4 and sum 4 and carry 0
- a `add-fact` with d1 0 and d2 5 and sum 5 and carry 0
- a `add-fact` with d1 0 and d2 6 and sum 6 and carry 0
- a `add-fact` with d1 0 and d2 7 and sum 7 and carry 0
- a `add-fact` with d1 0 and d2 8 and sum 8 and carry 0
- a `add-fact` with d1 0 and d2 9 and sum 9 and carry 0
- a `add-fact` with d1 0 and d2 10 and sum 0 and carry 1
- a `add-fact` with d1 1 and d2 0 and sum 1 and carry 0
- a `add-fact` with d1 1 and d2 1 and sum 2 and carry 0
- a `add-fact` with d1 1 and d2 2 and sum 3 and carry 0
- a `add-fact` with d1 1 and d2 3 and sum 4 and carry 0
- a `add-fact` with d1 1 and d2 4 and sum 5 and carry 0
- a `add-fact` with d1 1 and d2 5 and sum 6 and carry 0
- a `add-fact` with d1 1 and d2 6 and sum 7 and carry 0
- a `add-fact` with d1 1 and d2 7 and sum 8 and carry 0
- a `add-fact` with d1 1 and d2 8 and sum 9 and carry 0
- a `add-fact` with d1 1 and d2 9 and sum 0 and carry 1
- a `add-fact` with d1 1 and d2 10 and sum 1 and carry 1
- a `add-fact` with d1 2 and d2 0 and sum 2 and carry 0
- a `add-fact` with d1 2 and d2 1 and sum 3 and carry 0
- a `add-fact` with d1 2 and d2 2 and sum 4 and carry 0
- a `add-fact` with d1 2 and d2 3 and sum 5 and carry 0
- a `add-fact` with d1 2 and d2 4 and sum 6 and carry 0
- a `add-fact` with d1 2 and d2 5 and sum 7 and carry 0
- a `add-fact` with d1 2 and d2 6 and sum 8 and carry 0
- a `add-fact` with d1 2 and d2 7 and sum 9 and carry 0
- a `add-fact` with d1 2 and d2 8 and sum 0 and carry 1
- a `add-fact` with d1 2 and d2 9 and sum 1 and carry 1
- a `add-fact` with d1 2 and d2 10 and sum 2 and carry 1
- a `add-fact` with d1 3 and d2 0 and sum 3 and carry 0
- a `add-fact` with d1 3 and d2 1 and sum 4 and carry 0
- a `add-fact` with d1 3 and d2 2 and sum 5 and carry 0
- a `add-fact` with d1 3 and d2 3 and sum 6 and carry 0
- a `add-fact` with d1 3 and d2 4 and sum 7 and carry 0
- a `add-fact` with d1 3 and d2 5 and sum 8 and carry 0
- a `add-fact` with d1 3 and d2 6 and sum 9 and carry 0
- a `add-fact` with d1 3 and d2 7 and sum 0 and carry 1
- a `add-fact` with d1 3 and d2 8 and sum 1 and carry 1
- a `add-fact` with d1 3 and d2 9 and sum 2 and carry 1
- a `add-fact` with d1 3 and d2 10 and sum 3 and carry 1
- a `add-fact` with d1 4 and d2 0 and sum 4 and carry 0
- a `add-fact` with d1 4 and d2 1 and sum 5 and carry 0
- a `add-fact` with d1 4 and d2 2 and sum 6 and carry 0
- a `add-fact` with d1 4 and d2 3 and sum 7 and carry 0
- a `add-fact` with d1 4 and d2 4 and sum 8 and carry 0
- a `add-fact` with d1 4 and d2 5 and sum 9 and carry 0
- a `add-fact` with d1 4 and d2 6 and sum 0 and carry 1
- a `add-fact` with d1 4 and d2 7 and sum 1 and carry 1
- a `add-fact` with d1 4 and d2 8 and sum 2 and carry 1
- a `add-fact` with d1 4 and d2 9 and sum 3 and carry 1
- a `add-fact` with d1 4 and d2 10 and sum 4 and carry 1
- a `add-fact` with d1 5 and d2 0 and sum 5 and carry 0
- a `add-fact` with d1 5 and d2 1 and sum 6 and carry 0
- a `add-fact` with d1 5 and d2 2 and sum 7 and carry 0
- a `add-fact` with d1 5 and d2 3 and sum 8 and carry 0
- a `add-fact` with d1 5 and d2 4 and sum 9 and carry 0
- a `add-fact` with d1 5 and d2 5 and sum 0 and carry 1
- a `add-fact` with d1 5 and d2 6 and sum 1 and carry 1
- a `add-fact` with d1 5 and d2 7 and sum 2 and carry 1
- a `add-fact` with d1 5 and d2 8 and sum 3 and carry 1
- a `add-fact` with d1 5 and d2 9 and sum 4 and carry 1
- a `add-fact` with d1 5 and d2 10 and sum 5 and carry 1
- a `add-fact` with d1 6 and d2 0 and sum 6 and carry 0
- a `add-fact` with d1 6 and d2 1 and sum 7 and carry 0
- a `add-fact` with d1 6 and d2 2 and sum 8 and carry 0
- a `add-fact` with d1 6 and d2 3 and sum 9 and carry 0
- a `add-fact` with d1 6 and d2 4 and sum 0 and carry 1
- a `add-fact` with d1 6 and d2 5 and sum 1 and carry 1
- a `add-fact` with d1 6 and d2 6 and sum 2 and carry 1
- a `add-fact` with d1 6 and d2 7 and sum 3 and carry 1
- a `add-fact` with d1 6 and d2 8 and sum 4 and carry 1
- a `add-fact` with d1 6 and d2 9 and sum 5 and carry 1
- a `add-fact` with d1 6 and d2 10 and sum 6 and carry 1
- a `add-fact` with d1 7 and d2 0 and sum 7 and carry 0
- a `add-fact` with d1 7 and d2 1 and sum 8 and carry 0
- a `add-fact` with d1 7 and d2 2 and sum 9 and carry 0
- a `add-fact` with d1 7 and d2 3 and sum 0 and carry 1
- a `add-fact` with d1 7 and d2 4 and sum 1 and carry 1
- a `add-fact` with d1 7 and d2 5 and sum 2 and carry 1
- a `add-fact` with d1 7 and d2 6 and sum 3 and carry 1
- a `add-fact` with d1 7 and d2 7 and sum 4 and carry 1
- a `add-fact` with d1 7 and d2 8 and sum 5 and carry 1
- a `add-fact` with d1 7 and d2 9 and sum 6 and carry 1
- a `add-fact` with d1 7 and d2 10 and sum 7 and carry 1
- a `add-fact` with d1 8 and d2 0 and sum 8 and carry 0
- a `add-fact` with d1 8 and d2 1 and sum 9 and carry 0
- a `add-fact` with d1 8 and d2 2 and sum 0 and carry 1
- a `add-fact` with d1 8 and d2 3 and sum 1 and carry 1
- a `add-fact` with d1 8 and d2 4 and sum 2 and carry 1
- a `add-fact` with d1 8 and d2 5 and sum 3 and carry 1
- a `add-fact` with d1 8 and d2 6 and sum 4 and carry 1
- a `add-fact` with d1 8 and d2 7 and sum 5 and carry 1
- a `add-fact` with d1 8 and d2 8 and sum 6 and carry 1
- a `add-fact` with d1 8 and d2 9 and sum 7 and carry 1
- a `add-fact` with d1 8 and d2 10 and sum 8 and carry 1
- a `add-fact` with d1 9 and d2 0 and sum 9 and carry 0
- a `add-fact` with d1 9 and d2 1 and sum 0 and carry 1
- a `add-fact` with d1 9 and d2 2 and sum 1 and carry 1
- a `add-fact` with d1 9 and d2 3 and sum 2 and carry 1
- a `add-fact` with d1 9 and d2 4 and sum 3 and carry 1
- a `add-fact` with d1 9 and d2 5 and sum 4 and carry 1
- a `add-fact` with d1 9 and d2 6 and sum 5 and carry 1
- a `add-fact` with d1 9 and d2 7 and sum 6 and carry 1
- a `add-fact` with d1 9 and d2 8 and sum 7 and carry 1
- a `add-fact` with d1 9 and d2 9 and sum 8 and carry 1
- a `add-fact` with d1 9 and d2 10 and sum 9 and carry 1
- a `sub-fact` with d1 0 and d2 0 and diff 0
- a `sub-fact` with d1 1 and d2 0 and diff 1
- a `sub-fact` with d1 1 and d2 1 and diff 0
- a `sub-fact` with d1 2 and d2 0 and diff 2
- a `sub-fact` with d1 2 and d2 1 and diff 1
- a `sub-fact` with d1 2 and d2 2 and diff 0
- a `sub-fact` with d1 3 and d2 0 and diff 3
- a `sub-fact` with d1 3 and d2 1 and diff 2
- a `sub-fact` with d1 3 and d2 2 and diff 1
- a `sub-fact` with d1 3 and d2 3 and diff 0
- a `sub-fact` with d1 4 and d2 0 and diff 4
- a `sub-fact` with d1 4 and d2 1 and diff 3
- a `sub-fact` with d1 4 and d2 2 and diff 2
- a `sub-fact` with d1 4 and d2 3 and diff 1
- a `sub-fact` with d1 4 and d2 4 and diff 0
- a `sub-fact` with d1 5 and d2 0 and diff 5
- a `sub-fact` with d1 5 and d2 1 and diff 4
- a `sub-fact` with d1 5 and d2 2 and diff 3
- a `sub-fact` with d1 5 and d2 3 and diff 2
- a `sub-fact` with d1 5 and d2 4 and diff 1
- a `sub-fact` with d1 5 and d2 5 and diff 0
- a `sub-fact` with d1 6 and d2 0 and diff 6
- a `sub-fact` with d1 6 and d2 1 and diff 5
- a `sub-fact` with d1 6 and d2 2 and diff 4
- a `sub-fact` with d1 6 and d2 3 and diff 3
- a `sub-fact` with d1 6 and d2 4 and diff 2
- a `sub-fact` with d1 6 and d2 5 and diff 1
- a `sub-fact` with d1 6 and d2 6 and diff 0
- a `sub-fact` with d1 7 and d2 0 and diff 7
- a `sub-fact` with d1 7 and d2 1 and diff 6
- a `sub-fact` with d1 7 and d2 2 and diff 5
- a `sub-fact` with d1 7 and d2 3 and diff 4
- a `sub-fact` with d1 7 and d2 4 and diff 3
- a `sub-fact` with d1 7 and d2 5 and diff 2
- a `sub-fact` with d1 7 and d2 6 and diff 1
- a `sub-fact` with d1 7 and d2 7 and diff 0
- a `sub-fact` with d1 8 and d2 0 and diff 8
- a `sub-fact` with d1 8 and d2 1 and diff 7
- a `sub-fact` with d1 8 and d2 2 and diff 6
- a `sub-fact` with d1 8 and d2 3 and diff 5
- a `sub-fact` with d1 8 and d2 4 and diff 4
- a `sub-fact` with d1 8 and d2 5 and diff 3
- a `sub-fact` with d1 8 and d2 6 and diff 2
- a `sub-fact` with d1 8 and d2 7 and diff 1
- a `sub-fact` with d1 8 and d2 8 and diff 0
- a `sub-fact` with d1 9 and d2 0 and diff 9
- a `sub-fact` with d1 9 and d2 1 and diff 8
- a `sub-fact` with d1 9 and d2 2 and diff 7
- a `sub-fact` with d1 9 and d2 3 and diff 6
- a `sub-fact` with d1 9 and d2 4 and diff 5
- a `sub-fact` with d1 9 and d2 5 and diff 4
- a `sub-fact` with d1 9 and d2 6 and diff 3
- a `sub-fact` with d1 9 and d2 7 and diff 2
- a `sub-fact` with d1 9 and d2 8 and diff 1
- a `sub-fact` with d1 9 and d2 9 and diff 0
- a `sub-fact` with d1 10 and d2 0 and diff 10
- a `sub-fact` with d1 10 and d2 1 and diff 9
- a `sub-fact` with d1 10 and d2 2 and diff 8
- a `sub-fact` with d1 10 and d2 3 and diff 7
- a `sub-fact` with d1 10 and d2 4 and diff 6
- a `sub-fact` with d1 10 and d2 5 and diff 5
- a `sub-fact` with d1 10 and d2 6 and diff 4
- a `sub-fact` with d1 10 and d2 7 and diff 3
- a `sub-fact` with d1 10 and d2 8 and diff 2
- a `sub-fact` with d1 10 and d2 9 and diff 1
- a `sub-fact` with d1 10 and d2 10 and diff 0
- a `sub-fact` with d1 11 and d2 0 and diff 11
- a `sub-fact` with d1 11 and d2 1 and diff 10
- a `sub-fact` with d1 11 and d2 2 and diff 9
- a `sub-fact` with d1 11 and d2 3 and diff 8
- a `sub-fact` with d1 11 and d2 4 and diff 7
- a `sub-fact` with d1 11 and d2 5 and diff 6
- a `sub-fact` with d1 11 and d2 6 and diff 5
- a `sub-fact` with d1 11 and d2 7 and diff 4
- a `sub-fact` with d1 11 and d2 8 and diff 3
- a `sub-fact` with d1 11 and d2 9 and diff 2
- a `sub-fact` with d1 11 and d2 10 and diff 1
- a `sub-fact` with d1 12 and d2 0 and diff 12
- a `sub-fact` with d1 12 and d2 1 and diff 11
- a `sub-fact` with d1 12 and d2 2 and diff 10
- a `sub-fact` with d1 12 and d2 3 and diff 9
- a `sub-fact` with d1 12 and d2 4 and diff 8
- a `sub-fact` with d1 12 and d2 5 and diff 7
- a `sub-fact` with d1 12 and d2 6 and diff 6
- a `sub-fact` with d1 12 and d2 7 and diff 5
- a `sub-fact` with d1 12 and d2 8 and diff 4
- a `sub-fact` with d1 12 and d2 9 and diff 3
- a `sub-fact` with d1 12 and d2 10 and diff 2
- a `sub-fact` with d1 13 and d2 0 and diff 13
- a `sub-fact` with d1 13 and d2 1 and diff 12
- a `sub-fact` with d1 13 and d2 2 and diff 11
- a `sub-fact` with d1 13 and d2 3 and diff 10
- a `sub-fact` with d1 13 and d2 4 and diff 9
- a `sub-fact` with d1 13 and d2 5 and diff 8
- a `sub-fact` with d1 13 and d2 6 and diff 7
- a `sub-fact` with d1 13 and d2 7 and diff 6
- a `sub-fact` with d1 13 and d2 8 and diff 5
- a `sub-fact` with d1 13 and d2 9 and diff 4
- a `sub-fact` with d1 13 and d2 10 and diff 3
- a `sub-fact` with d1 14 and d2 0 and diff 14
- a `sub-fact` with d1 14 and d2 1 and diff 13
- a `sub-fact` with d1 14 and d2 2 and diff 12
- a `sub-fact` with d1 14 and d2 3 and diff 11
- a `sub-fact` with d1 14 and d2 4 and diff 10
- a `sub-fact` with d1 14 and d2 5 and diff 9
- a `sub-fact` with d1 14 and d2 6 and diff 8
- a `sub-fact` with d1 14 and d2 7 and diff 7
- a `sub-fact` with d1 14 and d2 8 and diff 6
- a `sub-fact` with d1 14 and d2 9 and diff 5
- a `sub-fact` with d1 14 and d2 10 and diff 4
- a `sub-fact` with d1 15 and d2 0 and diff 15
- a `sub-fact` with d1 15 and d2 1 and diff 14
- a `sub-fact` with d1 15 and d2 2 and diff 13
- a `sub-fact` with d1 15 and d2 3 and diff 12
- a `sub-fact` with d1 15 and d2 4 and diff 11
- a `sub-fact` with d1 15 and d2 5 and diff 10
- a `sub-fact` with d1 15 and d2 6 and diff 9
- a `sub-fact` with d1 15 and d2 7 and diff 8
- a `sub-fact` with d1 15 and d2 8 and diff 7
- a `sub-fact` with d1 15 and d2 9 and diff 6
- a `sub-fact` with d1 15 and d2 10 and diff 5
- a `sub-fact` with d1 16 and d2 0 and diff 16
- a `sub-fact` with d1 16 and d2 1 and diff 15
- a `sub-fact` with d1 16 and d2 2 and diff 14
- a `sub-fact` with d1 16 and d2 3 and diff 13
- a `sub-fact` with d1 16 and d2 4 and diff 12
- a `sub-fact` with d1 16 and d2 5 and diff 11
- a `sub-fact` with d1 16 and d2 6 and diff 10
- a `sub-fact` with d1 16 and d2 7 and diff 9
- a `sub-fact` with d1 16 and d2 8 and diff 8
- a `sub-fact` with d1 16 and d2 9 and diff 7
- a `sub-fact` with d1 16 and d2 10 and diff 6
- a `sub-fact` with d1 17 and d2 0 and diff 17
- a `sub-fact` with d1 17 and d2 1 and diff 16
- a `sub-fact` with d1 17 and d2 2 and diff 15
- a `sub-fact` with d1 17 and d2 3 and diff 14
- a `sub-fact` with d1 17 and d2 4 and diff 13
- a `sub-fact` with d1 17 and d2 5 and diff 12
- a `sub-fact` with d1 17 and d2 6 and diff 11
- a `sub-fact` with d1 17 and d2 7 and diff 10
- a `sub-fact` with d1 17 and d2 8 and diff 9
- a `sub-fact` with d1 17 and d2 9 and diff 8
- a `sub-fact` with d1 17 and d2 10 and diff 7
- a `sub-fact` with d1 18 and d2 0 and diff 18
- a `sub-fact` with d1 18 and d2 1 and diff 17
- a `sub-fact` with d1 18 and d2 2 and diff 16
- a `sub-fact` with d1 18 and d2 3 and diff 15
- a `sub-fact` with d1 18 and d2 4 and diff 14
- a `sub-fact` with d1 18 and d2 5 and diff 13
- a `sub-fact` with d1 18 and d2 6 and diff 12
- a `sub-fact` with d1 18 and d2 7 and diff 11
- a `sub-fact` with d1 18 and d2 8 and diff 10
- a `sub-fact` with d1 18 and d2 9 and diff 9
- a `sub-fact` with d1 18 and d2 10 and diff 8
- a `sub-fact` with d1 19 and d2 0 and diff 19
- a `sub-fact` with d1 19 and d2 1 and diff 18
- a `sub-fact` with d1 19 and d2 2 and diff 17
- a `sub-fact` with d1 19 and d2 3 and diff 16
- a `sub-fact` with d1 19 and d2 4 and diff 15
- a `sub-fact` with d1 19 and d2 5 and diff 14
- a `sub-fact` with d1 19 and d2 6 and diff 13
- a `sub-fact` with d1 19 and d2 7 and diff 12
- a `sub-fact` with d1 19 and d2 8 and diff 11
- a `sub-fact` with d1 19 and d2 9 and diff 10
- a `sub-fact` with d1 19 and d2 10 and diff 9
- a `inc-fact` with n 0 and next 1
- a `inc-fact` with n 1 and next 2
- a `inc-fact` with n 2 and next 3
- a `inc-fact` with n 3 and next 4
- a `inc-fact` with n 4 and next 5
- a `inc-fact` with n 5 and next 6
- a `inc-fact` with n 6 and next 7
- a `inc-fact` with n 7 and next 8
- a `inc-fact` with n 8 and next 9
- a `inc-fact` with n 9 and next 10
- a `ten-fact` with n 0 and plus10 10
- a `ten-fact` with n 1 and plus10 11
- a `ten-fact` with n 2 and plus10 12
- a `ten-fact` with n 3 and plus10 13
- a `ten-fact` with n 4 and plus10 14
- a `ten-fact` with n 5 and plus10 15
- a `ten-fact` with n 6 and plus10 16
- a `ten-fact` with n 7 and plus10 17
- a `ten-fact` with n 8 and plus10 18
- a `ten-fact` with n 9 and plus10 19

**Goal.** Some problem has count 0. When the goal holds in the task state, the agent reports success and halts.

## Operators

An operator's changes are made together: every value on the right is read before any change.

**choose-operation(p: problem, k ∈ {1, 2}).** Proposed when p.operation = 0 and p.count > 0. Choose addition or subtraction for the next problem, at random.
- Effect: p.operation := k; p.carry := 0.

**generate-digit1(p: problem, c: column, d: digit).** Proposed when p.operation ≠ 0 and c.gen1 ≠ p.pid. Choose a column's top digit at random.
- and when one of these holds: p.operation = 1; or p.operation = 2 and c.last = 0; or p.operation = 2 and c.last = 1 and d.val > 0.
- Effect: c.digit1 := d.val; c.gen1 := p.pid; p.digits := p.digits + 1.

**generate-digit2(p: problem, c: column, d: digit).** Proposed when p.operation ≠ 0 and c.gen1 = p.pid and c.gen2 ≠ p.pid. Choose a column's bottom digit at random (after its top digit).
- and when one of these holds: p.operation = 1; or p.operation = 2 and c.last = 0; or p.operation = 2 and c.last = 1 and d.val < c.digit1.
- Effect: c.digit2 := d.val; c.gen2 := p.pid; p.digits := p.digits + 1.

**process-column(p: problem, c: column).** Proposed when p.digits = 6 and c.done ≠ p.pid and no column has pos < c.pos and done ≠ p.pid. Work out one column, right to left, in a substate.
- If p.operation = 1: c.result := c.digit1 + c.digit2 + p.carry − ((c.digit1 + c.digit2 + p.carry) ÷ (10) (rounded towards zero)) × (10); p.carry := (c.digit1 + c.digit2 + p.carry) ÷ (10) (rounded towards zero); c.done := p.pid.
- If p.operation = 2: c.result := c.digit1 − c.digit2 − p.carry + ((9 − c.digit1 − c.digit2 − p.carry) ÷ (10) (rounded towards zero)) × (10); p.carry := (9 − c.digit1 − c.digit2 − p.carry) ÷ (10) (rounded towards zero); c.done := p.pid.
- Carried out in its own substate by these sub-operators, whose changes to the task state are results; together they must produce the effect above (checked):
  - **get-digit2**: proposed when local.adj = 0. 
  - **add-digits**: proposed when p.operation = 1 and local.adj = 1 and local.r = -1 and f.d1 = local.d1 and f.d2 = local.d2. Effect: local.r := f.sum; local.cout := f.carry.
  - **borrow**: proposed when p.operation = 2 and local.adj = 1 and local.ten = 0 and local.d1 < local.d2. 
  - **subtract-digits**: proposed when p.operation = 2 and local.adj = 1 and local.r = -1 and f.d1 = local.d1 and f.d2 = local.d2. Effect: local.r := f.diff.
  - **write-result**: proposed when local.r ≠ -1. Effect: c.result := local.r; p.carry := local.cout; c.done := p.pid; writes "column ⟨c.pos⟩ op ⟨p.operation⟩: ⟨c.digit1⟩ ⟨c.digit2⟩ -> ⟨local.r⟩ carry ⟨local.cout⟩".

**finish-problem(p: problem, c1: column, c2: column, c3: column).** Proposed when p.digits = 6 and no column has done ≠ p.pid and c1.pos = 1 and c2.pos = 2 and c3.pos = 3. All columns have answers: write the problem and its answer, count it, and start the next.
- Effect: p.count := p.count − 1; p.pid := p.pid + 1; p.digits := 0; p.operation := 0; writes "problem op ⟨p.operation⟩ top ⟨c3.digit1⟩⟨c2.digit1⟩⟨c1.digit1⟩ bottom ⟨c3.digit2⟩⟨c2.digit2⟩⟨c1.digit2⟩ answer ⟨c3.result⟩⟨c2.result⟩⟨c1.result⟩ carry ⟨p.carry⟩".

## Choosing among proposed operators

Any proposed operator may be chosen; the choice is random.

## Learning

Chunking on (`chunk always`).

## Assumptions (added; not in the task description)

- **A1** [open] The task: generate random n-column addition or subtraction problems (subtraction answers positive), solve each column right to left by retrieving digit facts, count the problems; halt when the count reaches 0 (V5 count 10000 and stop-arithmetic). Variant `arithmetic`: 3 columns, 10000 problems.
- **A2** [open] Problem generation is done by top-level operators chosen at random (choose-operation, generate-digit1, generate-digit2), not in V5's generate-problem substate: a substate whose sub-operators are chosen at random has no specified effect to refine (the problem made is random). Same choices, one fewer decision per problem and no generation chunks.
- **A3** [open] The columns are three fixed objects reused for every problem (`gen1`/`gen2`/`done` hold the number of the problem they belong to), instead of a new linked column structure per problem (V5 generate-operation). The order of columns comes from `pos`.
- **A4** [open] The carry (borrow) into a column is a problem attribute, added to the bottom digit in a nested substate (`get-digit2` → `increment-digit2`). V5 adds a carry to the top digit (`get-digit1` substate) and does subtraction borrows by changing the next column's top digit, recursively (compute-subtraction-borrow-result). Here a borrow adds ten to the top digit in a nested substate (`borrow` → `add-ten`) and passes a borrow of 1 to the next column: the same answers, no recursion through columns.
- **A5** [open] Facts are the task's own objects (add-fact with bottom digit 0–10, sub-fact with top digit 0–19, inc-fact, ten-fact), made at initialization, instead of V5's generate-facts operator. The bottom digit after a carry or borrow can be 10, so the addition and subtraction tables include d2 = 10.
- **A6** [open] Operations are numbers (1 addition, 2 subtraction) and unset values are problem numbers rather than missing attributes. A carry out of the leftmost column is written but not given a new column (V5 new-column).
- **A7** [open] Correctness is checked in Lean (every 2-column problem and a sample of 3-column problems) and by the harness from the problem and answer that finish-problem writes (as V5's finish-problem does), instead of V5's elaborations that recompute the answer and halt on a mismatch.
- **A8** [open] Variants for the remaining originals (JL, 7 Nov 2026, decision 7): arithmetic V4 is V5 rule for rule (its `chunk on` means 'only', so it learns nothing) and is replaced by `arithmetic-v5`; arithmetic-save is a trimmed V6 (first problem fixed, count 3500) and is replaced by `arithmetic`; `arithmetic-solve-problem` is V6 with the column work one substate deeper, under `solve-problem` (10 problems), and learns only at the bottom substate (`chunk bottom-only on`): with Soar's default, a chunk learned from another chunk's firing two substates up loses the borrow test and gives wrong answers (suspected Soar 9.6.5 defect 34, cmcsoar bugs/chunk-from-chunk-loses-constraint.soar); `addition` (35 + 96) and `subtraction` (207 − 178) are the one-problem originals, solved as V6 does, then halt; subtraction also replaces multiplication V1 (its built-in problem; its multiplication branch is unfinished; JL 7 Nov).
