# Blocks World — step 6 (in progress)

Lean: `agentgen/Agent/Families/BlocksWorld.lean`. 75 originals, flattened in `task/`, all run in Soar 9.6.5 (`results/orig`, 10 seeds, cap 2000 decisions; summary in `compare.csv`).

## Stage 1 (6 Nov 2026): changing links, and the look-ahead variant

### New general DSL features
- **Changing links.** An operator may set an object-valued attribute to one of its object parameters (`Expr.obj p`: `block.on := obj dest`); the semantics keeps such links in the state (as the target's index); `check` types them. Static links (e.g. cells' neighbours) are unchanged.
- **Comparing with an object**: `Atom.obj p` (`block.on ≠ obj dest`; inside `noneSuch`: "nothing is on `p`").
- **Goal by links** (`Goal.links`): named objects linked as desired (A on B …); `^desired` links to the task's own objects, and the success test compares the targets by name (look-ahead copies point to copies).
- **Proposal disjunction** (`Operator.proposeOr`): one proposal rule per disjoint alternative ("dest is the table" / "dest is a clear block").
- **Look-ahead-only preferences** (`Pref.inLookahead`), and links are optional on named objects (the table rests on nothing).

### Variant `blocks-world-look-ahead` (3 blocks: C on A, A and B on the table → A on B on C)

Replaces blocks-world-lookahead V1–V4, BW-LA V1/V2, BW-LA-X V1, blocks-world-look-ahead V1/V2, ChunkingDemoTests_Demo_Blocks_World_Look_Ahead V1, FunctionalTests_testBlocksWorldLookAhead V1.

| Agent | Solved (10 seeds) | Median decisions | Chunks |
|---|---|---|---|
| blocks-world-lookahead V1, V3; BW-LA V1, V2; BW-LA-X V1 (book versions) | 4/10 | 2000 (loops) | 9–11 |
| blocks-world-look-ahead V1 / V2 | 6/10 / 10/10 | 51 / 30 | 6 / 5 |
| ChunkingDemo Look_Ahead V1 | 10/10 | 43 | 6 |
| FunctionalTests LookAhead V1 | 10/10 | 51.5 | 0 (chunking off) |
| blocks-world-lookahead V2, V4 | 0/10 | — | (V4 never moves) |
| **generated blocks-world-look-ahead** | **5/10** | — (5 loop to the cap) | 7 |

The generated agent behaves like the book versions: when it does not solve, it loops (chunks lock a cycle, as in M&C). **Why the demo solves 10/10:** its copy of the selection library is edited — `selection*pass-back-success` passes back only `required-success` (the book library also passes back `success`/`partial-success`), and the look-ahead operator is required with all others rejected. Passing back success from a deeper level is exactly what made M&C's look-ahead chunks loop ("success" = goal still reachable). This bears on the M&C chunk question.

Soar 9.6.5 vs soar-lean: MATCH (`leancmp/chunk.out`: 23 decisions, 54 WMEs, 7 chunks).

Theorems: `conventions`; `three_shortest` (3 moves, no fewer).

### Assumptions (A1–A4, in BlocksWorld.lean)
- A1 representation: one object type for blocks and table with `name`, `table` (1 for the table) and a changing link `on`, instead of `^ontop` objects and `^type`.
- A2 move-block(block, dest): two disjoint proposal rules (dest = table / dest = clear block), instead of an elaborated `^clear`.
- A3 goal: desired `on` of every block (`^desired` links), success halts.
- A4 look-ahead: library as is, no duplicate detection, chunking; moving the block just moved is rejected only in look-ahead (as the originals).

## Stage 2 (6–7 Nov 2026): simple control and operator subgoaling

### New general DSL features
- **Recursive derived flags** (`Agent.flags`): a 0/1 attribute elaborated from base cases and along a link (Blocks World's "in place": the table; a block on what the goal puts it on, which is in place). Several `Flag`s with one attribute give alternative base cases ("clear": the table, or nothing on it).
- **Goal-link guard** (`Guard.desired o attr t`): the goal puts `o` on `t` (compared by name, so it also works in look-ahead copies).
- **Flag guard** (`Guard.flag`) and **binary "better than every other" preference** (`HVal.better`, Soar `o > o2`); the semantics applies better before best/worst, as Soar's decision procedure.
- **Operator subgoaling** (`Operator.pre`, `pregoals`, `Agent.subgoaling`, `Guard.wants`): proposals say when an operator is relevant; its preconditions are required only by the apply rules; selected without them, it gets a substate named like the task that shares the task's objects and has the preconditions as `^desired`; preferences can test what the substate wants. `Agent.runOpSub` follows this deterministically (outermost pending operator applies as soon as its preconditions hold).

### Variants

| Variant | Replaces | Original | Generated |
|---|---|---|---|
| blocks-world-simple (5 blocks) | BW-Simple V1/V2, blocks-world-simple V2–V4 | 10/10, 7–8 decisions | 20/20, 6–7 moves, 7–8 decisions |
| blocks-world-simple-3 | blocks-world V2, V3 | 10/10, 4 decisions | 20/20, 3 moves, 4 decisions |
| blocks-world-operator-subgoaling | blocks-world-operator-subgoaling V1, V3, V6; BW-Op-Subgoal V1; FunctionalTests OperatorSubgoaling V1 | 10/10, 5 decisions | 20/20, 5 decisions |
| blocks-world-operator-subgoaling-chunk | blocks-world-operator-subgoaling V4; ChunkingDemo Operator_Subgoaling V1 | 10/10, 5 decisions, 1 chunk | 20/20, 3 decisions, 3 chunks |

All four MATCH soar-lean (`leancmp/plain.out`, `leancmp/chunk.out`). Theorems: `five_shortest` (6 moves), `simple_three` (the simple control decides every step: 3 moves), `opsub_three` (operator subgoaling decides every step: 3 moves).

Harness fix: several originals keep their blocks under `^world` (blocks-world-simple V3/V4, blocks-world-lookahead V2, blocks-world-hierarchical V4, operator-subgoaling V3, RL V3, …); they were scored 0/10 by mistake and are 10/10 (`compare.csv` updated).

### Assumptions added
- A5 simple variants: P6 (best: an out-of-place block to the table) and P7 (better: onto the in-place object the goal puts it on); "in place" as a recursive flag; blocks-world V2's three stray RL template rules dropped.
- A6 operator subgoaling: move-block proposed when relevant (a block, a different destination it is not on); preconditions block clear and destination clear (a "clear" flag: the table, or nothing on it); substate goals `^clear` both; the originals' three preferences (avoid clobbering what the subgoal wants clear: worst; a move the goal asks for: best; moving the block that sits on something the subgoal wants clear: best).

## Still to do in this family
- Look-ahead with state evaluation (+RL), operator subgoaling with RL, RL, hierarchical (pick-up/put-down with a gripper simulated through the output link — needs I/O), hierarchical look-ahead, HRL.
- Not replaced (to confirm): blocks-world-epmem, count-blocks, cube-stack, opsub-core, blocksworld V1–V3, blocks-opsub, the `_expected` chunk files.

## Regenerated 7 Nov 2026 (17:05): operator-subgoal `^desired` variable

The compiler now names the operator subgoal's `^desired` variable `<sgd>`. It was `<d>`, which clashed with Towers of Hanoi's parameter `d`. In the operator-subgoaling variants only that variable name changed. Their runs are unchanged (5 and 3 decisions, solved on seeds 1–3), and soar-lean matches with and without chunking (`leancmp-sgd/`).

## Queue work, 8 Nov 2026: RL and operator subgoaling with relevant moves

### `blocks-world-rl` replaces BW-RL V1, V2 and blocks-world-RL V2

The three originals are the same agent:
- Four blocks: C on A, A and D on the table, B on D. Goal: A on B on C on D on the table.
- Every legal move is proposed.
- Reward 1 at the goal, then halt.
- Soar's default RL, learning over repeated runs.
- 5,120 hand-written RL rules, one per configuration of the four blocks and move, all at 0.

The variant uses one RL template over the operator and the whole state. This is the new `Agent.rlWholeState`: the template also tests every named object's links, here each block's `on`. Soar makes the same rules, each when its configuration and move first occur.

Soar defect 28 (RL template variable map, `init-soar` case) applies here. After `init-soar`, rules instantiated from the template are malformed: distinct variables collapse into one identifier, e.g. `(state <o1> ^on <o1> … ^object <o1>)`, so they never match. With `init-soar` between runs the variant learned more slowly (runs 91–100: 9.2 decisions against V1's 6.8) and made up to 8,021 rules.
- So the harness (`rlharness.py --fresh`) runs each episode in a new agent that sources the RL rules learned so far with their values, renamed `carried*N`. This is the same workaround as the Missionaries & Cannibals harness.
- BW-RL V1 is unaffected because its rules are hand-written, not instantiated.

Results (Soar 9.6.5, 10 seeds; mean decisions per run, initialize and halt included, minimum 6):

| Agent | Runs 1–10 | Runs 21–30 | Runs 51–60 | RL rules |
|---|---|---|---|---|
| BW-RL V1 (`init-soar` between runs) | 90 | 7.7 | 6.5 | 5,120 |
| `blocks-world-rl` (fresh agent per run) | 75 | 7.1 | 6.6 | 814 (mean) |

All runs solved. Soar vs soar-lean (`leancmp-rl/`, `--rl --explore`): MATCH, 30 decisions, 167 RL rules with equal values.

### `blocks-world-operator-subgoaling-relevant` replaces BW-Op-Subgoal-RL V1 and blocks-world-operator-subgoaling-RL V2–V4

The originals are operator subgoaling on the same four blocks. `move-block` is proposed only when relevant:
- at the top state, a move the goal asks for;
- in a subgoal, moving the block that is on something the subgoal wants clear onto a clear object.

All proposals are indifferent.

The originals also turn RL on, with:
- an RL template over the subgoal's operator, the configuration and the move;
- rewards of 1 at the goal, and 1 when a subgoal's two blocks are clear.

Every rule Soar instantiates from that template is malformed (the state and the operator are the same identifier: defect 28), so none matches and the choice is random. The variant reproduces that behaviour, with no RL (assumption A7).

The variant uses `proposeOr` with two rules:
- `.desired "block" "on" "dest"`: holds only at the top state, where `^desired` is the task's goal;
- `.wants "clear" "block" (on)` plus the destination clear.

Results (Soar 9.6.5, seeds 1–20): both solve 20/20.

| Agent | Mean decisions | Median | Range |
|---|---|---|---|
| BW-Op-Subgoal-RL V1 | 12.7 | 11 | 6–25 |
| `blocks-world-operator-subgoaling-relevant` | 7.0 | 7 | 5–9 |

Soar vs soar-lean: MATCH (6 decisions).

Open issue: parallel application in operator subgoaling. When a move in the deepest substate makes several waiting superoperators applicable at once, Soar fires all their apply rules in the same phase.
- In seed 1 of the variant, one decision moved B to the table, then A onto B and C onto B together, so for that phase two blocks were on B. It recovered, and the run ended solved.
- The Lean semantics applies one operator at a time and never reaches such a state.
- The originals cascade the same way: decision 7 of BW-Op-Subgoal-RL V1 moves B to the table and C onto D together. This probably explains part of the difference in decisions.
- A fix would make a superoperator's apply rule wait while its substate has an operator selected, or apply only the innermost.

### blocks-world-operator-subgoaling-lookahead V2: not working, no variant

It has 15 rules: no operator-subgoal rules and no selection library. The two goal moves are proposed without preferences, so an operator tie arises, and state no-change impasses then nest every decision; it never moves a block.

### Fix (JL, 8 Nov 2026: have the compiler prevent it): no parallel application in operator subgoaling

Cause, found in a trace of seed 1 (`watch 5`):
- Soar applies operators level by level, deepest first. After B went to the table at depth 3, the waiting move at depth 2 (C onto B) applied, and then the top-level move (A onto B) applied in the same phase.
- The `clear` flags were elaborated in every state named `blocks-world`. The substates share the task's objects, so B's `^clear 1` had support from several levels, and the support from one level had not yet retracted when the depth-1 apply rule matched.
- A first attempt was an apply-rule test that no substate has an operator selected. It does nothing, because the deeper substate is already gone when the next level applies.

The compiler now elaborates flags and derived attributes only in the task's own states, not in operator-subgoal substates (`-(<s> ^type operator-subgoal)`), when the agent uses operator subgoaling. Each flag then has one support, which retracts before the next level's apply rule is matched. Operators that become applicable together still apply in the same phase when each is still legal; an operator that is no longer legal does not apply.

Results (Soar 9.6.5, seeds 1–20, checked after every decision):

| Variant | Solved | Decisions | Decisions with two blocks on one object |
|---|---|---|---|
| `blocks-world-operator-subgoaling` | 20/20 | 5 | 0 |
| `blocks-world-operator-subgoaling-chunk` | 20/20 | 5 (1 chunk) | 0 |
| `blocks-world-operator-subgoaling-relevant` | 20/20 | mean 14.2, range 7–25 (was 7.0, 5–9) | 0 (was 18) |
| BW-Op-Subgoal-RL V1 | 20/20 | mean 12.7, range 6–25 | — |

The relevant-moves variant is now close to its originals: most of the earlier difference was the illegal parallel moves.

Soar vs soar-lean (`leancmp-flags/`, with chunking): MATCH for all three, and for `towers-of-hanoi-mea`.
