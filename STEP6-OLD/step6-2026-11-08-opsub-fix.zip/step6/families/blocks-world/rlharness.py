"""Blocks World RL harness: for each seed, R runs in one Soar agent with init-soar between them (the
RL rules and their values are kept). Per run: decisions to halt, and whether it ended in success.
Per seed: the run lengths, the number of RL rules, and the moves of the last run."""
import soar_sml as sml, sys, os, re, json, argparse


def run_fresh(path, seed, runs, cap):
    """Each run in a new agent that sources the RL rules learned so far, with their values (Soar
    defect 28: after init-soar, rules instantiated from an RL template are malformed). The carried
    rules are renamed (carried*N) so the template's new instances cannot replace them."""
    lens, oks, saved, nrl = [], [], '', 0
    k = sml.Kernel.CreateKernelInCurrentThread(True, 0)
    for r in range(runs):
        a = k.CreateAgent(f't{r}'); out = []
        a.RegisterForPrintEvent(sml.smlEVENT_PRINT, lambda *x: out.append(x[-1]), None)
        a.ExecuteCommandLine('source ' + os.path.abspath(path))
        if saved:
            f = f'/tmp/_bwrl_{os.getpid()}.soar'; open(f, 'w').write(saved); a.ExecuteCommandLine('source ' + f)
        a.ExecuteCommandLine(f'srand {seed * 1009 + r}'); a.ExecuteCommandLine('watch 0')
        a.ExecuteCommandLine(f'run {cap}')
        d = int(re.search(r'(\d+) decisions', a.ExecuteCommandLine('stats')).group(1))
        lens.append(d); oks.append(d < cap)
        names = [l.split()[0] for l in a.ExecuteCommandLine('print --rl').split('\n') if l.strip()]
        nrl = len(names)
        texts = [a.ExecuteCommandLine('print ' + n) for n in names]
        saved = '\n'.join(re.sub(r'^sp \{\S+', f'sp {{carried*{i}', t.strip(), count=1) for i, t in enumerate(texts))
        k.DestroyAgent(a)
    k.Shutdown()
    return dict(seed=seed, lens=lens, ok=oks, rl_rules=nrl, fresh=True)


def run(path, seed, runs, cap):
    k = sml.Kernel.CreateKernelInCurrentThread(True, 0); a = k.CreateAgent('t'); out = []
    a.RegisterForPrintEvent(sml.smlEVENT_PRINT, lambda *x: out.append(x[-1]), None)
    a.ExecuteCommandLine('source ' + os.path.abspath(path)); a.ExecuteCommandLine(f'srand {seed}')
    a.ExecuteCommandLine('watch 0')
    lens, oks = [], []
    for r in range(runs):
        if r: a.ExecuteCommandLine('init-soar')
        out.clear(); a.ExecuteCommandLine(f'run {cap}')
        st = a.ExecuteCommandLine('stats')
        d = int(re.search(r'(\d+) decisions', st).group(1))
        txt = ''.join(out)
        lens.append(d); oks.append(bool(re.search(r'solved|halt|success|goal', txt, re.I)) and d < cap)
    rl = a.ExecuteCommandLine('print --rl')
    nrl = len([l for l in rl.split('\n') if l.strip()])
    k.Shutdown()
    return dict(seed=seed, lens=lens, ok=oks, rl_rules=nrl)


if __name__ == '__main__':
    p = argparse.ArgumentParser(); p.add_argument('load'); p.add_argument('--seeds', default='1-5')
    p.add_argument('--runs', type=int, default=50); p.add_argument('--cap', type=int, default=2000)
    p.add_argument('--fresh', action='store_true')
    o = p.parse_args(); a, b = map(int, o.seeds.split('-'))
    for s in range(a, b + 1): print(json.dumps((run_fresh if o.fresh else run)(o.load, s, o.runs, o.cap)), flush=True)
