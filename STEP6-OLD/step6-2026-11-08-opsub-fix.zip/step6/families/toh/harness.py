"""Task-level runs of Towers of Hanoi agents in Soar 9.6.5 (soar_sml).

usage: harness.py DIR LOADFILE [--cap N] [--seeds a-b]
Sources the agent, sets srand SEED after loading, runs decision by decision up to the cap (or
until halt), and records: halted, number of top-state move-disk operators selected, whether a
"Success"-like message was printed, the final peg of every disk (read from ^holds objects:
^disk ^on, with disk/peg either identifiers with ^name or constants), whether the final state
has all disks on one peg other than the start peg, and whether any move put a larger disk on a
smaller one (checked on the sequence of states read after each top-level decision)."""
import argparse, json, os, re
import soar_sml as sml

TOP_OP = re.compile(r'^\s*\d+:    O: \S+ \(([^)]+)\)', re.M)

def objs(a):
    t = a.ExecuteCommandLine('print --depth 3 s1')
    d = {}
    for m in re.finditer(r'\((\S+)([^()]*)\)', t):
        for x in re.finditer(r'\^(\S+)\s+([^\s)^]+)', m.group(2)):
            d.setdefault(m.group(1), []).append((x.group(1), x.group(2)))
    return d

def val(d, ident):
    """name of an identifier, or the constant itself"""
    if ident in d:
        n = [v for k, v in d[ident] if k in ('name', 'size')]
        return n[0].strip('|') if n else ident
    return ident.strip('|')

def snapshot(a):
    d = objs(a); s = d.get('S1', [])
    holds = [v for k, v in s if k == 'holds']
    st = {}
    for h in holds:
        o = dict(d.get(h, []))
        if 'disk' in o and 'on' in o:
            st[val(d, o['disk'])] = val(d, o['on'])
    return st

def stacks_ok(prev, cur):
    return True

MONITOR = None
STEP = False

def run(d, load, cap, seed):
    k = sml.Kernel.CreateKernelInCurrentThread(True, 0)
    a = k.CreateAgent('h'); out = []
    a.RegisterForPrintEvent(sml.smlEVENT_PRINT, lambda *x: out.append(x[-1]), None)
    os.chdir(d); a.ExecuteCommandLine('cd ' + d)
    src = a.ExecuteCommandLine('source ' + load)
    if MONITOR: a.ExecuteCommandLine('source ' + MONITOR)
    a.ExecuteCommandLine(f'srand {seed}'); a.ExecuteCommandLine('watch 1')
    start = {k: v for k, v in snapshot(a).items() if not k.startswith('base')}
    n = 0; halted = False; ops = 0; moves = []
    if STEP:
        # one decision at a time: the moves made, read from the state (disk -> peg changes)
        prev = start
        while n < cap:
            out.clear(); r = a.ExecuteCommandLine('run 1 -d'); n += 1
            txt = ''.join(out) + r
            ops += len([m for m in TOP_OP.findall(txt) if 'move' in m or 'doit' in m])
            cur = {k: v for k, v in snapshot(a).items() if not k.startswith('base') and k != 'ground'}
            for dk in sorted(cur, key=lambda x: int(x) if x.isdigit() else 99):
                if prev.get(dk) != cur[dk]: moves.append((dk, cur[dk]))
            prev = cur
            if 'halted' in txt or 'This Agent halted' in txt or 'Soar must halt' in txt:
                halted = True; break
    while n < cap and not STEP:
        out.clear(); r = a.ExecuteCommandLine('run 200 -d'); n += 200
        txt = ''.join(out) + r
        ops += len([m for m in TOP_OP.findall(txt) if 'move' in m or 'doit' in m])
        moves += re.findall(r'Move Disk:\s*(\d+)\s*to peg\s*\|?(\w)', txt, re.I)
        if 'halted' in txt or 'This Agent halted' in txt or 'Soar must halt' in txt:
            halted = True; break
    m = re.search(r'(\d+) decisions', a.ExecuteCommandLine('stats'))
    dec = int(m.group(1)) if m else n
    alltxt = a.ExecuteCommandLine('print --depth 1 s1')
    fin = {k: v for k, v in snapshot(a).items() if not k.startswith('base') and k != 'ground'}  # bases: the generated variant's
    pegs = set(fin.values())
    solved = len(fin) > 0 and len(pegs) == 1 and (not start or pegs != set(start.values()) or not start)
    chunks = len(re.findall(r'^\S', a.ExecuteCommandLine('print --chunks'), re.M))
    k.Shutdown()
    return dict(seed=seed, decisions=dec, halted=halted, top_moves=ops, disks=len(fin),
                final=fin, solved=solved, moves=''.join(f'{x}{y.upper()}' for x, y in moves), chunks=chunks, source_errors='rror' in src)

if __name__ == '__main__':
    p = argparse.ArgumentParser(); p.add_argument('dir'); p.add_argument('load')
    p.add_argument('--monitor'); p.add_argument('--step', action='store_true'); p.add_argument('--cap', type=int, default=20000); p.add_argument('--seeds', default='1-3')
    o = p.parse_args(); d = os.path.abspath(o.dir); MONITOR = os.path.abspath(o.monitor) if o.monitor else None; STEP = o.step; lo, hi = map(int, o.seeds.split('-'))
    for s in range(lo, hi + 1): print(json.dumps(run(d, o.load, o.cap, s)), flush=True)
