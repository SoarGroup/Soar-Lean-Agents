# towers-of-hanoi

## The task

The task state holds several values of `disk`, each a disk. The disks, and a base under each peg.
The task state holds several values of `peg`, each a peg. The three pegs.
The task state holds several values of `holds`, each a holds. Where each disk is: one record per disk (and per base).
The task state holds several values of `control`, each a control. The iterative method's memory of the last move.

A disk has `name` (one of ), `size` (an integer).

A peg has `name` (one of ).

A holds has `name` (one of ), `disk` (a disk), `size` (an integer), `on` (a peg), `above` (a disk).

A control has `name` (one of ), `lastsize` (an integer), `lastpeg` (a peg).

Initially the task state has:
- a `peg` named A with 
- a `peg` named B with 
- a `peg` named C with 
- a `disk` named 1 with size 1
- a `disk` named 2 with size 2
- a `disk` named 3 with size 3
- a `disk` named 4 with size 4
- a `disk` named 5 with size 5
- a `disk` named base-A with size 6
- a `disk` named base-B with size 6
- a `disk` named base-C with size 6
- a `disk` named ground with size 7
- a `holds` named h1 with size 1; its `disk` is 1; its `on` is A; its `above` is 2
- a `holds` named h2 with size 2; its `disk` is 2; its `on` is A; its `above` is 3
- a `holds` named h3 with size 3; its `disk` is 3; its `on` is A; its `above` is 4
- a `holds` named h4 with size 4; its `disk` is 4; its `on` is A; its `above` is 5
- a `holds` named h5 with size 5; its `disk` is 5; its `on` is A; its `above` is base-A
- a `holds` named h-base-A with size 6; its `disk` is base-A; its `on` is A; its `above` is ground
- a `holds` named h-base-B with size 6; its `disk` is base-B; its `on` is B; its `above` is ground
- a `holds` named h-base-C with size 6; its `disk` is base-C; its `on` is C; its `above` is ground
- a `control` named control with lastsize 2; its `lastpeg` is B
Links between objects never change.

**Goal.** Some holds has . When the goal holds in the task state, the agent reports success and halts.

## Operators

An operator's changes are made together: every value on the right is read before any change.

**move-disk(h: holds, d: disk, t: holds, td: disk, src: peg, target: peg, control: control).** Proposed when h.disk is d and t.disk is td and d.size ≤ 5 and h.on = src and src and target are different objects and no holds has above = d and t.on = target and no holds has above = td and td.size > d.size. Move a disk with nothing on it onto a larger disk or an empty peg, as the iterative method says.
- and when one of these holds: d.size = 1 and control.lastsize ≠ 1 and control.lastpeg ≠ target; or d.size > 1 and control.lastsize = 1.
- If d.size = 1: h.on := target; h.above := td; control.lastsize := d.size; control.lastpeg := src; writes "Move Disk: ⟨d.size⟩ to peg ⟨target.name⟩".
- If d.size > 1: h.on := target; h.above := td; control.lastsize := d.size; writes "Move Disk: ⟨d.size⟩ to peg ⟨target.name⟩".

## Choosing among proposed operators

Any proposed operator may be chosen; the choice is random.

## Learning

None.

## Assumptions (added; not in the task description)

- **A1** [open] The task: five disks on peg A, to be moved to peg C one at a time, never onto a smaller disk (JL, 7 Nov 2026: five disks on three pegs; the originals have 11, recur V1 7).
- **A2** [open] Representation: V1's `holds` records, one per disk, on the state, pointing to the disk, the peg it is on, and the disk directly below it (STA-030: a relation changed by operators is explicit on the state with pointers to its arguments). The disk's `on` and `above` change when it moves.
- **A3** [open] Each peg has a base under it: a disk larger than all the others, which never moves, with its own `holds` record above a ground disk. Moving onto an empty peg is then moving onto its base, so one case covers V1's three apply rules (target clear or not, source clear or not) and its `^clear`/`^upper-disk` elaborations become negated tests (`no record is above the disk`). V1 writes `^above none` for a bottom disk and elaborates `^clear` for an empty peg.
- **A4** [open] V1's `larger` elaboration (a static relation between disks) is a comparison of sizes.
- **A5** [open] Iterative method: V1's `^last-disk-moved` (a disk) and `^last-disk1-peg` (a peg) are a control object's `lastsize` (the size of the disk moved last) and `lastpeg`. As in V1 they start as disk 2 and peg B (for an odd number of disks), so disk 1 moves first, to C.
- **A7** [open] Means-ends variant: V1-recursive's three proposals (put-on-peg, clear-disk, clear-smaller) are alternative proposals of one operator, `move-disk`, whose identity is the disk, its peg, the target and the disk of the current goal; its preconditions are not tested when it is proposed (operator subgoaling): the substate's `^desired` asks for the disk on the peg. The upper disk of the target is an apply-time parameter (bound when the move applies), so it does not belong to the operator's identity. A record also holds its disk's size, for the size comparisons in negated tests; V1 compares disks by its `larger` elaboration. Put-on-peg's "largest disk not on its desired peg" is written for this task's goal, every disk on one peg. V1's rule that makes the selected operator best (`select*maintain`) is not needed: one operator is proposed in each state.
- **A6** [open] The goal is V1's: every disk on C (as `^desired` links). V1 also lists each disk's desired `above`; with all disks on C and no disk ever on a smaller one, the order follows.
