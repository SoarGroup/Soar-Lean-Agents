# Phase A: Soar -> English (blind)

You are turning Soar programs into English descriptions. Another person, who will never see the
Soar code, will write a new Soar program from your English alone. Your English is the only thing
that carries the task to them.

## Isolation (strict)
- Read ONLY: /home/claude/blind68/src/<family>/<variant>/ for your assigned variants, and
  /home/claude/blind68/tools/run.py (to run a program and watch it, if you want).
- Do NOT read anything else under /home/claude (no other folders, no README, notes, Lean, English
  or earlier implementations anywhere), and do not search the disk for them. If you see a path to
  such material, do not open it.
- Write ONLY to /home/claude/blind68/english/<family>/<variant>.md.

## What to write, for each variant
A self-contained description for a Soar programmer, in plain English, covering everything that
affects behaviour:
1. The task: the situation, the objects and their properties, the initial state (exact values).
2. The actions: what each does, when it is allowed (all constraints), and its exact effects.
3. The goal, and any failure states; what the agent does when the goal (or a failure) is reached
   (stops, prints something, keeps going).
4. How the agent chooses among actions: random/indifferent choice, preferences or heuristics
   (give every one, with its condition), avoiding states, look-ahead search and how states are
   evaluated (success, failure, numeric values and which is better), reinforcement learning
   (rewards, when given, learning rate, discount, policy, initial values), chunking or other
   learning, substate decomposition of actions (hierarchy), memories (semantic/episodic) used.
5. Any output the agent prints that matters, and any numeric settings (seeds are not needed).
Rules:
- Describe behaviour and knowledge, not the code: no Soar syntax, no rule names, no copying of
  working-memory attribute names as such (domain words are fine).
- Do not leave out task knowledge that the program uses; do not add knowledge it does not have.
- If the program has a bug or does something odd, describe what it actually does and add a short
  'Note' saying so.
- Use the same structure for every variant; a variant may say "as variant X, except ...", but
  each file must still name X's file so the reader can find it.
Run a program with: python3 /home/claude/blind68/tools/run.py <variant dir> <load file> --seeds 1-2 --episodes 1 --cap 2000
(the load file is <variant>.soar in the variant folder).

When done, reply with a one-line summary per variant (variant: one sentence) and any problems.
