# Phase B: English -> Soar (blind)

You are writing new Soar programs from English descriptions. You have never seen the programs the
descriptions came from, and you must not look for them.

## Isolation (strict)
- Read ONLY:
  - /home/claude/blind68/english/<family>/ for your assigned families;
  - /home/claude/blind68/conventions/ and /home/claude/blind68/lib/;
  - /home/claude/blind68/tools/run.py.
- Do NOT read anything else under /home/claude: not blind68/src, blind68/results, blind68 impl
  folders other than your own, and nothing outside blind68 (no READMEs, notes, Lean files, earlier
  agents, examples). Do not search the disk for them. If you happen on such a path, do not open it.
- Write ONLY under /home/claude/blind68/<impl>/<family>/ (your <impl> is given below), plus
  scratch files in /tmp.

## What to produce, for each variant
- Folder /home/claude/blind68/<impl>/<family>/<variant>/ with load file <variant>.soar (sourced
  from that folder) and any rule files it sources. Source libraries by absolute path.
- The program must do what the English says: same task, same knowledge, same selection and
  learning method and parameters, same end condition and printed output. Do not add task
  knowledge the English does not give; where the English is unclear, choose and record the choice.
- Runner protocol: when an episode ends (goal, failure, or the stated end condition), print a
  line containing `TASK-RESULT: success` or `TASK-RESULT: failure`, then (halt). If the English
  says the agent never stops, do not halt; the runner's cap ends the run.
- Test every variant: python3 /home/claude/blind68/tools/run.py <variant dir> <variant>.soar
  --seeds 1-3 --episodes 3 --cap 3000 (it prints JSON per seed; it marks every output-link command
  ^status complete and does nothing else). Fix until it behaves as described; no load errors.
- Write /home/claude/blind68/<impl>/<family>/NOTES.md: per variant, the choices you made where the
  English was open, anything you could not do, and how the tests came out.

## Conventions for your <impl>
<impl> = impl-soar. Use the standard (non-world) Soar conventions in
/home/claude/blind68/conventions/Soar-Conventions--*.csv (or the .xlsx). For look-ahead use
Soar's default selection rules in /home/claude/blind68/lib/soar-default/ (source
selection.soar from that folder). Do not use the world libraries.

When done, reply with one line per variant (variant: works / partly / fails, one reason) and the
main difficulties.
