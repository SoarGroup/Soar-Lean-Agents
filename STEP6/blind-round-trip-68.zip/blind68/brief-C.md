# Phase C: world programs without an external environment

None of the 68 tasks has an external environment. In the first world rebuilds every task operator
issued an output command, the generic runner marked it complete, and a task rule then updated
^world: about 3 decisions per action (select; operator no-change; state no-change), and substates
for every real action. That is an artefact of the test set-up, not something the tasks need.

Library change (in /home/claude/blind68/lib/world2, a copy of lib/world; proposed, not yet JL's):
- A task with no external environment marks its top state `^environment none`.
- agent-world then sets `^internal-actions true` on every state, including the top state, so a
  task operator's internal application rule (the one that tests `^internal-actions true`) applies
  it everywhere, updating ^world as the operator is applied. No output command is sent.
- The external application rules for one argument now also test `^internal-actions false`.

Your job, for each assigned family:
1. Copy /home/claude/blind68/impl-world/<family>/ to /home/claude/blind68/impl-world2/<family>/
   (you may read the impl-world version and its NOTES.md, the English in
   /home/claude/blind68/english/<family>/, the conventions, lib/world2 and tools/run.py; nothing else
   under /home/claude — not src/, not impl-soar/, not results/).
2. Change the copy to use lib/world2 (every path to lib/world becomes lib/world2) and:
   - add a top-state elaboration giving `^environment none`;
   - make sure every task operator has an internal application rule (`^internal-actions true`)
     that makes its full effect on ^world, and that nothing waits for output commands;
   - remove the response-to-completed-command rules, the ^effect-applied marking, and any
     workaround that existed only because of output commands (for example excised command-removal
     rules, reward timing fixes, hierarchy steps that bypassed output); keep everything else;
   - a real action must not need a substate: an operator implemented by an operator subgoal or a
     hierarchy still uses its substate, but plain task operators apply in one decision.
3. Test every variant with python3 /home/claude/blind68/tools/run.py <dir> <variant>.soar --seeds 1-3
   --episodes 3 --cap 3000; check that no output commands are issued and that decisions per real
   action are 1. Behaviour must still match the English (same messages, TASK-RESULT line, halt).
4. Write impl-world2/<family>/NOTES.md: what changed, decisions per action before/after, anything
   that got better or worse (chunking, RL, look-ahead), and any further library problems.

Reply with one line per variant (works / partly / fails; decisions episode 1 before → after) and
the main points.
