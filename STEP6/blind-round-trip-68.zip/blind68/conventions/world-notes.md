# Practical notes for writing agents to the world conventions

These notes are generic (not about any particular task). The conventions themselves are in
World-Conventions--World-Conventions.csv (and the .xlsx); the libraries are in ../lib/world.

## Loading

A program's load file sources, in this order (paths relative to the program's folder; adjust):

    pushd <path to lib/world>
    source agent-world.soar
    source simple.soar
    pushd selection-world
    source selection-world_source.soar
    popd
    pushd selection-iterative-deepening
    source selection-iterative-deepening_source.soar
    popd
    popd
    source <task>-rules.soar

selection-world currently needs selection-iterative-deepening loaded with it (without it, the
evaluate-operator substate gets no operators). Load both whenever look-ahead may be used.

## Shape of a task (see the W-* conventions)

- agent-world proposes initialize-agent-world on the top state while it has no ^name, creating
  ^world (objects, relations), ^flags-free scaffolding, ^top-state etc. The task's own initialize
  operator is proposed after that (test ^world) and gives the top state its ^name, creates the
  world objects (each with ^object-handle and ^anchored true) under ^world.objects, and the goal
  as ^desireds (^desired items + ^desired-count).
- The task supplies ^problem-space (^name, ^agent-world true, copy flags) and ^flags on the top
  state (mea-operator-selection, look-ahead-planning, iterative-step, init-evaluation-depth, ...).
- Achievement of object-property and relation desireds on states is supplied by the task:
  i-supported ^achieved <d> / ^unachieved <d> on the desireds.
- Task operators: ^name, ^task-operator true, ^action-handle, ^super-desired, ^argument1..N,
  ^argument-count, precondition ^desireds (^desired-count 0 if none).
- Each task operator has an internal application rule (tests ^internal-actions true and
  ^pre-conditions-satisfied true; used in look-ahead) and is applied in the real world by
  agent-world's generic rules, which write (output-link ^perform-action (^name <action-handle>
  ^argument1 <handle> ...)).
- Non-task (internal) operators carry ^task-operator false.

## The environment in these runs

The runner (../tools/run.py) is a generic world: it marks every output-link command
^status complete on the next input phase and does nothing else. So the task must model the
world's response itself: a top-state rule that fires when a perform-action command is complete
and updates ^world. Make that rule fire once per command (for example, test and set
^effect-applied true on the command), or it can fire again when the world returns to an
earlier situation.

## Lessons from earlier agents (library behaviour, not task knowledge)

- The look-ahead copies world objects' attributes. A value derived by an elaboration on a world
  object is copied too, and the copy can go stale when the copy's world changes; put derived
  information that can become false on the state instead, or make sure it is monotone.
- Operators are not copied in look-ahead. If look-ahead reaches an operator's precondition
  subgoal (operator no-change with the operator's ^desireds), achievement found in look-ahead can
  appear to satisfy the real operator's preconditions. Avoid precondition subgoals under
  look-ahead, or test the result carefully.
- Iterative deepening counts depth at ties, not at every operator: forced chains of single
  operators are not counted, so "fewest choice points" is not "fewest steps". Rejecting repeated
  situations helps when the shortest plan matters.
- With ^better on the desireds, success is passed up only together with a numeric value.

## Reporting results (required by the runner)

When an episode ends, write a line containing exactly `TASK-RESULT: success` or
`TASK-RESULT: failure`, then (halt).

## Update 9 Nov 2026: tasks with no external environment (lib/world2, proposed)

None of the test tasks has an external environment. With lib/world2, a task marks its top state
`^environment none`; every state then has `^internal-actions true`, and each task operator's
internal application rule updates ^world in the decision the operator is selected. No output
commands, no response rules, no waiting substates. Consequences: `^internal-actions true` no longer
means "imagined state" (look-ahead needs its own flag); messages written by application rules also
print in look-ahead; a rule that records something when an operator applies needs a once-per-
operator guard, because the operator stays selected after its own change.
