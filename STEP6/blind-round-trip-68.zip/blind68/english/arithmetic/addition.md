# addition (arithmetic family)

As variant **arithmetic** (file /home/claude/blind68/english/arithmetic/arithmetic.md), except as
listed below. Read that file first; everything not mentioned here is identical (fact tables,
column-processing substate with its increment / add / borrow / subtract / write-result operators,
chunking, print formats, goal test and halt).

## 1. Task, objects, initial state (differences)

A single, fixed 2-digit addition problem: 35 + 96.

- Problem: operation = 1 (addition, already chosen), carry = 0, count = 1, problem id = 1,
  digits-generated counter = 4 (all digits already present).
- Only **two** columns:
  - position 1 (ones): top 5, bottom 6, result 0, top/bottom "generated for problem id" marks = 1,
    done mark = 0, last flag = 0;
  - position 2 (tens): top 3, bottom 9, result 0, generated marks = 1, done mark = 0, last flag = 1.
- Digit objects 0..9, all four fact tables, and the desired state (count 0) as in the base.

## 2. Actions (differences)

- Choose-operation and the digit generators exist as in the base but never apply: the operation
  is already set and both columns are marked as generated for problem id 1.
- **Process column** fires when the digits-generated counter is **4** (instead of 6); same
  right-to-left rule.
- **Finish problem** requires the counter to be 4 and the two columns (positions 1 and 2) both
  done; effects as in the base.

## 3. Goal

After the one problem is finished, count becomes 0, so the agent prints a newline,
`The problem has been solved.` and halts.

## 4. Control / learning

As the base (chunking on; nothing random actually happens in this variant because the problem is
fixed).

## 5. Output

The problem line has two digits per number:
`problem op 1 top <t2><t1> bottom <b2><b1> answer <r2><r1> carry <final carry>`.

Expected run (exact):
`column 1 op 1: 5 6 -> 1 carry 1column 2 op 1: 3 9 -> 3 carry 1problem op 1 top 35 bottom 96 answer 31 carry 1`
then newline, `The problem has been solved.`, halt. (35 + 96 = 131; the final carry 1 is shown
separately, not as an answer digit.)
