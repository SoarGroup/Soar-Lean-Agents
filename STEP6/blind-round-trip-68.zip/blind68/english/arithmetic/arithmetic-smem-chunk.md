# arithmetic-smem-chunk (arithmetic family)

As variant **arithmetic-smem** (file /home/claude/blind68/english/arithmetic/arithmetic-smem.md),
which itself is described relative to **arithmetic**
(/home/claude/blind68/english/arithmetic/arithmetic.md), except as listed below. Fact tables in
semantic memory (preloaded, identical), the query-then-apply operators, and everything else are
the same.

## 1. Initial state (difference)

Problem count = **10000** (instead of 1000).

## 2. Actions

No differences.

## 3. Goal

After 10000 problems: print newline, `The problem has been solved.`, halt.

## 4. Control / learning (difference)

**Chunking is on in all states** (learn always, with operator-selection chunks enabled), as in
the base arithmetic variant. Rules are learned from the column-processing substates (and their
increment / add-ten sub-substates). Because the facts come from semantic memory rather than from
working-memory objects, the learned rules are specific to the particular digit values seen
(many more rules are learned than in the base: a few hundred over a few thousand decisions).
Once a column situation has been learned, it is solved directly at the top level without the
substate, and its column line is not printed.

## 5. Output

Same formats as the base; column lines appear only for column situations not yet learned.
