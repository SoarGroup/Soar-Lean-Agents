# arithmetic-smem-learn (arithmetic family)

As variant **arithmetic-smem** (file /home/claude/blind68/english/arithmetic/arithmetic-smem.md),
which itself is described relative to **arithmetic**
(/home/claude/blind68/english/arithmetic/arithmetic.md), except as listed below. Chunking stays
off; facts are retrieved from semantic memory with the same query-then-apply operators.

## 1. Initial state (differences)

- Problem count = **2000**.
- Semantic memory is enabled but preloaded ONLY with the increment facts (n 0..9 -> n+1) and the
  plus-ten facts (n 0..9 -> n+10). **No addition or subtraction facts are known at the start**;
  the agent learns them by counting and stores them in semantic memory.

## 2. Actions (differences)

- **Add digits** and **subtract digits** (in the column substate): proposed and query as in
  arithmetic-smem. If the retrieval succeeds, they apply as before. If the retrieval **fails**,
  the query is removed (and not reissued for that selection), the operator cannot apply, and an
  impasse creates a counting substate:

- **Add-digits substate (counting up)**:
  1. Init: running sum = d1 of the column state, counter n = 0, stored = 0.
  2. **Count add** (while n is not equal to d2): sum + 1, n + 1.
  3. **Store add** (when n = d2 and stored = 0): store TWO addition facts in semantic memory:
     (first = d1, second = d2) and the commuted (first = d2, second = d1), both with sum digit =
     sum mod 10 and carry = sum div 10; stored = 1.
  4. **Done add** (stored = 1): in the column state set r = sum mod 10 and carry-out = sum div 10.
     This makes add digits retract and the column continues with write result.

- **Subtract-digits substate (counting down)**:
  1. Init: base = d1 of the column state, n = 0, stored = 0.
  2. **Count sub** (while n is not equal to d2): base - 1, n + 1.
  3. **Store sub** (when n = d2 and stored = 0): store one subtraction fact (first = d1,
     second = d2, difference = base); stored = 1.
  4. **Done sub** (stored = 1): in the column state set r = base.

  Here d1/d2 are the column state's working values (after any increment for an incoming
  carry/borrow and after adding ten), e.g. d1 can be 10..19 and d2 can be 10.

  From then on, the same digit pair (or, for addition, the commuted pair) is answered by a
  successful retrieval instead of counting.

- Increment and add ten work as in arithmetic-smem (their facts are preloaded).

Note: in the store steps, the original numbers and the count are taken by matching ANY
working-memory object that has a first and second number (resp. a running sum / base), not
specifically the column state and the counting state. In practice the only such objects present
are the column state and the counting state, so the facts stored are the correct ones.

## 3. Goal

After 2000 problems: print newline, `The problem has been solved.`, halt.

## 4. Control / learning

Random choices as in the base. Chunking off. Learning happens only through semantic-memory
storage of addition/subtraction facts computed by counting (addition stores both orders).
No RL, no episodic memory.

## 5. Output

Same formats as the base; every column line is printed (answers are always correct). In the
test run, stray `@` characters also appeared in the output around stores; they do not come
from the program's own print actions.
