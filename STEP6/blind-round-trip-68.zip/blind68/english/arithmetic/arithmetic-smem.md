# arithmetic-smem (arithmetic family)

As variant **arithmetic** (file /home/claude/blind68/english/arithmetic/arithmetic.md), except as
listed below. Columns, digits, choose operation, digit generators, process column (right to
left), finish problem, the process-column substate structure, print formats and goal test are the
same. The difference: the four fact tables are NOT in working memory; they are in **semantic
memory** and are retrieved by cue when needed.

## 1. Initial state (differences)

- Problem count = **1000** (instead of 10000).
- The top state has no fact objects. Instead, before the run, semantic memory is enabled and
  preloaded with exactly the same facts as the base tables, each tagged with its kind:
  addition facts (first 0..9, second 0..10 -> sum digit, carry; 110 facts), subtraction facts
  (first 0..19, second 0..min(first,10) -> difference; 165 facts), increment facts
  (n 0..9 -> n+1), plus-ten facts (n 0..9 -> n+10).

## 2. Actions (differences, all inside the column-processing substates)

Each fact-using operator now works in two steps while it stays selected: first it places a
semantic-memory query (once per operator selection), then, when the retrieved fact appears, it
applies the effect and removes the query.

- **Add digits**: proposed when operation 1, adjusted = 1, r = -1 (no test that a fact exists).
  Query: an addition fact with first = d1 and second = d2. On retrieval: r = sum digit,
  carry-out = carry.
- **Subtract digits**: proposed when operation 2, adjusted = 1, r = -1 and d1 >= d2. Query: a
  subtraction fact with first = d1, second = d2. On retrieval: r = difference.
- **Increment** (in the get-bottom-digit sub-substate, always proposed there): query an
  increment fact with n = d2 of the column state; on retrieval d2 = next, adjusted = 1.
- **Add ten** (in the borrow sub-substate, always proposed there): query a plus-ten fact with
  n = d1 of the column state; on retrieval d1 = d1 + 10, ten-added = 1, carry-out = 1.
- Borrow is proposed exactly as in the base (operation 2, adjusted = 1, ten-added = 0, d1 < d2).

No retrieval ever fails because all needed facts are preloaded (there is no failure handling).

## 3. Goal

After 1000 problems: print newline, `The problem has been solved.`, halt.

## 4. Control / learning (difference)

Random choices as in the base. **Chunking is off.** Semantic memory is used only for
retrieval of the preloaded facts (nothing new is stored). No RL, no episodic memory. Because
there is no chunking, every column goes through its substate and prints its column line.

## 5. Output

Same formats as the base; every column line is printed.
