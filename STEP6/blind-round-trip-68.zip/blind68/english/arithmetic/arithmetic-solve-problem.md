# arithmetic-solve-problem (arithmetic family)

As variant **arithmetic** (file /home/claude/blind68/english/arithmetic/arithmetic.md), except as
listed below. Fact tables, digit objects, columns, choose-operation, digit generators,
finish-problem, the column-level substate operators (init local, get bottom digit / increment,
add digits, borrow / add ten, subtract digits, write result), print formats and goal test are the
same.

## 1. Initial state (difference)

Problem count = **10** (instead of 10000). Everything else as the base.

## 2. Actions (difference: an extra level of hierarchy)

- The top level no longer has a process-column operator. Instead it has **Solve problem**:
  allowed when the digits-generated counter is 6 and the leftmost column (position 3) is not yet
  done for the current problem id. It has no direct effect; it impasses into a **solve-problem
  substate** that knows the problem and the three columns.
- Inside the solve-problem substate, the **process column** operator is proposed exactly as in
  the base (rightmost column that is not done for the current problem id, counter = 6). It
  impasses into the process-column substate, which works exactly as in the base (with its own
  get-bottom-digit and borrow sub-substates, so the hierarchy is: solve problem -> process
  column -> increment / add ten).
- When all three columns are done, solve problem retracts and **finish problem** (top level)
  applies as in the base.

## 3. Goal

After 10 problems the count reaches 0: print newline, `The problem has been solved.`, halt.

## 4. Control / learning (difference)

Random choices as in the base. Chunking is on in all states **with bottom-only learning**: rules
are learned only from the lowest substate that currently exists (no rules are learned in a state
while it still has a substate below it). Learned rules let later columns/problems skip substates;
skipped column processing does not print the column line.

## 5. Output

As the base. A typical run prints ten problem lines, some column lines, then
`The problem has been solved.` and halts.
