# arithmetic-v5 (arithmetic family)

As variant **arithmetic** (file /home/claude/blind68/english/arithmetic/arithmetic.md), except as
listed below. The top level (initialisation, choose operation, digit generators, process column,
finish problem), the fact tables, the goal test, chunking and print formats are the same. The
difference is in HOW a column is processed: carries are added to the TOP digit, and subtraction
borrows by actually decrementing the top digit of the column(s) to the left ("crossing out"),
possibly through a chain of zeros, instead of passing a borrow flag along.

## 1. Initial state (difference)

Each column additionally has a **working top digit** (the top digit as it currently stands after
any borrowing), initially 0. Everything else as the base (count 10000).

## 2. Actions (differences)

- **Generate top digit**: as in the base, and it also sets the column's working top digit to the
  chosen value.

### Process-column substate (replaces the base one)

Local values: d1, d2, a "top adjusted" flag, r, carry-out, ten-added flag, "next position"
(column position + 1), and an is-subtraction flag (operation - 1, i.e. 0 for addition, 1 for
subtraction).

a. **Init local**: d1 = the column's WORKING top digit; d2 = column bottom digit; top-adjusted =
   1 - problem carry; r = -1; carry-out = 0; ten-added = 0; next position = column position + 1;
   is-subtraction = operation - 1.

b. **Get top digit** (when top-adjusted = 0, i.e. a carry is coming in; only happens in
   addition). Sub-substate with one operator, **add carry**: look up the addition fact for (d1, 1);
   set d1 = its sum digit, carry-out = its carry, top-adjusted = 1. (So 9 + carry gives d1 = 0
   and carry-out 1.)

c. **Add digits** (operation 1, top-adjusted = 1, r = -1, addition fact for (d1, d2) exists):
   r = sum digit; carry-out = carry-out + the fact's carry. (Carry-out never exceeds 1.)

d. **Subtract digits** (operation 2, r = -1, subtraction fact for (d1, d2) exists, i.e. d1 >= d2):
   r = difference. Carry-out stays 0, so in subtraction the problem carry always stays 0.

e. **Borrow from** (is-subtraction = 1, ten-added = 0, d1 < d2, and there is a column whose
   position equals next position): operator naming that column (the one immediately to the
   left). Its substate (the "lender" state) has local values: d1 = the lender column's ORIGINAL top
   digit, d2 = 1, ten-added = 0, next position = lender position + 1, is-subtraction = 1, r = -1,
   written = 0. Operators in the lender state:
   - **Borrow from** (recursive, same conditions as above but on the lender state's values):
     if the lender's digit is 0 (0 < 1), borrow from the column to ITS left, opening another
     lender substate of the same kind.
   - **Take one**: when r = -1 and a subtraction fact for (d1, 1) exists (d1 >= 1): r = d1 - 1.
   - **Write borrow**: when r is not -1 and written = 0: set the lender column's working top
     digit to r; written = 1.
   - **Add ten up**: when written = 1: look up the plus-ten fact for the state above's d1 and
     replace that d1 with d1 + 10; set that state's ten-added = 1. (The state above is either the
     process-column state or the outer lender state.)
   So with a zero to the left, the inner lender reduces the further-left column by one, the zero
   becomes 10, then 9 is written as its working top digit, and the original column's d1 gets +10.
   After this, subtract digits applies.
   Note: the lender reads the lender column's original top digit, not its working one. Because a
   column is only ever lent from once per problem, the two are equal when it matters, so results
   are correct.

f. **Write result**: as in the base (column result = r, problem carry = carry-out, column done,
   print the column line with the ORIGINAL top and bottom digits).

The leftmost column never needs to borrow, because in subtraction its bottom digit is generated
strictly smaller than its top digit, and it is lent from at most once.

## 3. Goal

As the base (10000 problems, then print `The problem has been solved.` and halt).

## 4. Control / learning

As the base: all random/indifferent; chunking on in all states (with operator-selection
chunks); learned rules skip substates for familiar situations, and skipped columns print no
column line.

## 5. Output

Same formats as the base. In subtraction the column lines always show `carry 0` (borrowing is
done by changing the working top digits, not through the carry). Example lines:
`column 1 op 2: 6 9 -> 7 carry 0column 2 op 2: 5 9 -> 5 carry 0` and
`problem op 2 top 900 bottom 862 answer 038 carry 0`.
