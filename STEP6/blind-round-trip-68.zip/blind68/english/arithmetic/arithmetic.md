# arithmetic (base variant of the arithmetic family)

## 1. Task, objects, initial state

The agent repeatedly makes up and solves 3-digit column-arithmetic problems (addition or
subtraction), the way a schoolchild does it on paper: one column at a time, right to left, using
memorised single-digit fact tables, carrying (addition) and borrowing (subtraction).

Everything lives in the agent's own top state (there is no external world / input-link).
An initialisation operator (proposed only when the top state has no name yet) creates:

- **The problem** with:
  - operation = 0 (0 = not chosen yet, 1 = addition, 2 = subtraction),
  - carry = 0 (the carry/borrow passed from one column to the next),
  - count = 10000 (number of problems still to solve),
  - problem id = 1 (incremented after every problem; used to mark what has been done for the
    current problem),
  - digits-generated counter = 0.
- **Three columns**, positions 1, 2, 3 (1 = ones column, the rightmost; 3 = hundreds, the
  leftmost). Each column has: top digit = 0, bottom digit = 0, result = 0, a "top digit generated
  for problem id" mark = 0, a "bottom digit generated for problem id" mark = 0, a "done for problem
  id" mark = 0, and a "last" flag: 1 for column 3 (the leftmost), 0 for columns 1 and 2.
- **The ten digit objects** with values 0..9 (the pool from which problem digits are picked).
- **Fact tables** (all held as ordinary working-memory objects on the top state):
  - Addition facts: for every first number 0..9 and second number 0..10, the sum digit
    ((a+b) mod 10) and carry ((a+b) div 10). 110 facts. (Second number 10 occurs when an incoming
    carry has been added to a bottom digit 9.)
  - Subtraction facts: for every first number 0..19 and second number 0..10 with first >= second,
    the difference (first - second). 165 facts. No fact exists when first < second.
  - Increment facts: n -> n+1 for n = 0..9.
  - Plus-ten facts: n -> n+10 for n = 0..9.
- **The desired state**: a problem whose count is 0.

## 2. Actions (operators)

Top-level operators (all proposed with an indifferent preference, so ties are broken at random):

1. **Choose operation** (two instances: addition and subtraction). Allowed when the problem's
   operation is 0 and count > 0. Effect: set operation to the chosen value (1 or 2) and set the
   problem carry to 0. Both instances are always proposed together, so each problem is addition
   or subtraction with probability 1/2.

2. **Generate top digit** for a column, choosing a digit object. Allowed when the operation is
   non-zero and that column's top digit has not yet been generated for the current problem id.
   Which digits are allowed:
   - addition: any digit 0..9, in every column;
   - subtraction, non-leftmost column: any digit 0..9;
   - subtraction, leftmost column (the "last" column): only 1..9 (not 0).
   Effect: column top digit = the chosen value; mark the column's top digit as generated for the
   current problem id; digits-generated counter + 1.

3. **Generate bottom digit** for a column, choosing a digit object. Allowed when the operation is
   non-zero, the column's top digit has already been generated for the current problem id, and its
   bottom digit has not. Allowed digits:
   - addition: any 0..9;
   - subtraction, non-leftmost column: any 0..9;
   - subtraction, leftmost column: only digits strictly less than that column's top digit (so the
     answer is always positive and the leftmost column never needs to borrow).
   Effect: column bottom digit = the value; mark as generated for this problem id; counter + 1.

   All generate operators for all columns and all candidate digits compete indifferently, so the
   digits are random (uniform over the allowed choices) and the order in which columns get their
   digits is random too.

4. **Process column** (has a substate, see below). Allowed when the digits-generated counter is 6
   and the column is not yet done for the current problem id, and no column with a smaller position
   is still not done. That is: always the rightmost unfinished column.

5. **Finish problem**. Allowed when the counter is 6 and all three columns are done for the
   current problem id. Effect: count - 1; problem id + 1; digits-generated counter = 0; operation
   = 0. Prints the problem (see 5). The problem carry is NOT reset here (choose-operation resets it).

### Process-column substate (operator no-change impasse)

The substate knows the problem and the column being processed. Its own local values:
working top (d1), working bottom (d2), an "adjusted" flag, result r, carry-out, and a
"ten added" flag. Its operators (all indifferent; at most one is applicable at a time):

a. **Init local** (when the local values do not exist yet): d1 = column top digit, d2 = column
   bottom digit, adjusted = 1 - (problem carry) (i.e. adjusted = 0 when a carry/borrow is coming in
   from the column to the right), r = -1 (no result yet), carry-out = 0, ten-added = 0.

b. **Get bottom digit** (when adjusted = 0). Sub-substate with one operator, **increment**: look
   up the increment fact for d2 and replace d2 with d2 + 1; set adjusted = 1. This is how the
   incoming carry/borrow is applied, for both operations: the bottom digit is increased by one.

c. **Add digits** (operation 1, adjusted = 1, r = -1, and an addition fact exists for (d1, d2)):
   r = the fact's sum digit, carry-out = the fact's carry.

d. **Borrow** (operation 2, adjusted = 1, ten-added = 0, and d1 < d2). Sub-substate with one
   operator, **add ten**: look up the plus-ten fact for d1 and replace d1 with d1 + 10; set
   ten-added = 1 and carry-out = 1 (carry-out here means "a borrow is owed to the next column").

e. **Subtract digits** (operation 2, adjusted = 1, r = -1, and a subtraction fact exists for
   (d1, d2), i.e. d1 >= d2): r = the difference. Carry-out is left as it is (1 if a borrow was
   made, else 0).

f. **Write result** (r is not -1): column result = r; problem carry = carry-out; mark the column
   done for the current problem id; print the column line (see 5). Marking it done makes the
   process-column operator retract, ending the substate.

Net effect per column: addition gives (top + bottom + carry-in) mod 10 with carry-out = the tens
digit; subtraction gives top - (bottom + borrow-in), adding 10 to top first and owing a borrow to
the next column when top < bottom + borrow-in.

## 3. Goal and termination

When the problem count equals the desired count 0, the agent prints a newline then
`The problem has been solved.` and halts. With count 10000 this means after 10000 problems
(far beyond typical decision caps). There are no failure states.

## 4. Control knowledge and learning

- All choices are indifferent/random: the operation, every digit, the order of digit generation.
  Column processing order is forced (right to left), and within a column only one substate
  operator is applicable at a time.
- No look-ahead, no reinforcement learning, no semantic or episodic memory.
- **Chunking is on in all states** (learn always, with operator-selection knowledge chunks also
  enabled). The agent learns rules from its process-column (and get-bottom-digit / borrow)
  substates. Because the fact tables are ordinary working-memory objects, the learned rules are
  general (they test the digit values through the fact objects), so after a few problems most
  columns are solved directly by learned rules in a single step without entering the substate.
  When a column is solved by a learned rule, the column line is not printed (only the substate's
  write-result step prints it); results are unchanged.

## 5. Output

Prints are concatenated without automatic spaces or newlines.

- After each column processed in a substate:
  `column <pos> op <operation>: <original top digit> <original bottom digit> -> <result> carry <carry-out>`
- After each problem:
  `problem op <operation> top <t3><t2><t1> bottom <b3><b2><b1> answer <r3><r2><r1> carry <final problem carry>`
  where the three digits of each number are written run together, hundreds first (e.g.
  `problem op 1 top 983 bottom 237 answer 220 carry 1`, meaning 983+237 = 1220 with the final
  carry shown separately; for subtraction the final carry is always 0).
- At the goal: newline, `The problem has been solved.`, then halt.

No other numeric settings matter.
