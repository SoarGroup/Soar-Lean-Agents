# subtraction (arithmetic family)

As variant **arithmetic** (file /home/claude/blind68/english/arithmetic/arithmetic.md), except as
listed below. Everything not mentioned (three columns, fact tables, all operators, the
column-processing substate, chunking, print formats, goal test and halt) is identical.

## 1. Task, objects, initial state (differences)

A single, fixed 3-digit subtraction problem: 207 - 178.

- Problem: operation = 2 (subtraction, already chosen), carry = 0, count = 1, problem id = 1,
  digits-generated counter = 6.
- Columns (all with result 0, done mark 0, and top/bottom "generated for problem id" marks = 1):
  - position 1 (ones): top 7, bottom 8, last flag 0;
  - position 2 (tens): top 0, bottom 7, last flag 0;
  - position 3 (hundreds): top 2, bottom 1, last flag 1.

## 2. Actions (differences)

None in the rules. Choose-operation and the digit generators never apply (operation set, all
digits marked generated). Columns are processed right to left as in the base; ones and tens
columns each borrow.

## 3. Goal

After the single problem is finished the count is 0: print newline,
`The problem has been solved.`, halt.

## 4. Control / learning

As the base (chunking on).

## 5. Output

Expected run (exact):
`column 1 op 2: 7 8 -> 9 carry 1column 2 op 2: 0 7 -> 2 carry 1column 3 op 2: 2 1 -> 0 carry 0problem op 2 top 207 bottom 178 answer 029 carry 0`
then newline, `The problem has been solved.`, halt.
