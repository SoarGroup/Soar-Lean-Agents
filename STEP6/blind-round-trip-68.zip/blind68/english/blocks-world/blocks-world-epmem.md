# blocks-world-epmem

Based on blocks-world-look-ahead (file: blocks-world-look-ahead.md): same world, initial state,
goal, move action, last-move bookkeeping and "no repeated block" rule, and the same standard Soar
selection-space look-ahead. The difference: inside look-ahead the agent does NOT know what a move
does; it predicts the result from episodic memory of its own past moves, then scores the predicted
state numerically. Chunking is off. Every section is given here.

## 1. Task
Table plus blocks A, B, C (name and table flag each); each block on exactly one object; table has
unlimited room. The first operator (proposed when the top state has no name) names the task
"blocks-world" and builds:

Initial state: A on the table, B on the table, C on A.

Goal: A on B, B on C, C on the table. The goal also states that higher evaluation values are better.

Derived "in place" fact: table always in place; a block is in place if it is on an in-place object
that the goal says it should be on.

"Last move": the state records the last move carried out in it, but NOT for moves that are being
evaluated in look-ahead (so imagined states keep the last move copied from the real state).

## 2. Actions
move-block(block, dest):
- Allowed when `block` is not the table, nothing is on `block`, `dest` differs from `block`,
  `block` is not already on `dest`, and `dest` is the table or a block with nothing on it.
- Proposed without indifference (two or more legal moves produce a tie).
- In the real state: effect is `block` on `dest` (no longer on its old support), and last move set.
- In an imagined (look-ahead) state the move has NO built-in effect. Selecting it causes a substate
  that uses the episodic model (section 4).

## 3. Goal and termination
Only in the real (top) state: when A, B and C are each on their goal object, print a blank line and
`The problem has been solved.` and halt (the default rules also halt). Imagined states never count
as success. Failures inside look-ahead come only from the default rules (constraint failure, see
section 4).

## 4. How the agent chooses
- Episodic memory: on, recording an episode of the real (top) state every decision cycle (stored at
  the selection phase). An episode therefore contains the blocks' positions and, when a real move
  is selected, that move.
- Ties use the standard Soar selection space: each tied move is evaluated on a copy of the state
  (objects copied two levels deep). The standard rule that marks the evaluated move as "tried" when
  it is selected is removed; the model below marks it tried instead.
- Episodic model (in the substate under the imagined move):
  1. Query: retrieve the most recent episode whose state had a move-block operator selected with the
     same block and destination, and the same configuration of objects as the imagined state (all
     objects with their names, table flags, what they are on, and in-place marks). Only a perfect
     (complete structural) match is accepted.
  2. If a perfect match is found: step to the next episode (the one recorded right after that move),
     and for every block whose support (by name) differs there, change the imagined state so that
     block is on the object with that name. Then mark the imagined move as tried.
  3. If there is no perfect match, or the query fails: the move gets the evaluation
     "partial-success" with numeric value 2.5, directly.
- Scoring a predicted state (after step 2):
  - 3 if A is in place (tower complete);
  - 2 if A is not on B and B is in place;
  - 1 if B is not on C and C is in place;
  - 0 if C is not on the table.
  Higher is better; equal values are indifferent. So an unknown move (2.5) beats moves known to give
  2, 1 or 0, and loses only to a move known to complete the tower.
- No repeated block: in an imagined state, a move of the block that was moved last (copied from the
  real state) is rejected; since the evaluated move is also required, this produces a constraint
  failure, i.e. the move is evaluated as a failure and rejected in the real state. Effect: the agent
  never moves the same block twice in a row.
- On a fresh agent no episodes match, so early choices are random among moves that are not of the
  last-moved block; predictions improve as experience accumulates (episodic memory persists across
  re-initialisations).
- Ancestor list kept on every state (unused).
No chunking, no RL, no semantic memory.

## 5. Output and settings
Only output is the solved message (blank line first), then halt. Episodic memory on (trigger every
decision cycle, phase selection). Chunking off.
