# blocks-world-hierarchical-lookahead

Gripper blocks world with a three-level hierarchy, as blocks-world-hierarchical (file:
blocks-world-hierarchical.md), except that at the middle level the agent must choose WHICH block to
pick up and WHERE to put it down, and it makes that choice by look-ahead search using the standard
Soar selection space. Every section is given here.

## 1. Task
Table plus blocks A, B, C (name and table flag each); each block on exactly one object; table has
unlimited room. Gripper named "gripper": position (1 up / 0 down), open (1/0), empty (1/0), above
(an object), holding (an object).

Initial state: A on the table, B on the table, C on A; gripper up, open, empty, above the table,
holding the table (placeholder).

Goal: A on B, B on C, C on the table.

Derived facts (top state, and recomputed in look-ahead copies):
- clear: table always clear; an object is clear if nothing is on it and it is not held by a
  non-empty gripper.
- free: table always free; an object is free if nothing is on it (gripper ignored).
- in place: table; a block on an in-place object that the goal says it should be on.

## 2. Actions
### Top level: move-block(block, dest)
- Proposed (indifferent) when `block` is not the table, nothing is on `block`, `dest` is free,
  `dest` differs from `block`, and `block` is not already on `dest`. (No gripper condition.)
- Carried out in a substate; finished when `block` is on `dest` (proposal stops matching).

### Middle level (move-block substate)
The substate shares the top state's objects and gripper (the same objects, not copies), and has its
own (empty) goal marker.
- pick-up(x): proposed for every block x (not the table) with nothing on it, when the gripper is
  empty.
- put-down(y, d): proposed when the gripper is non-empty and holding y, for every clear object d.
- Both are proposed WITHOUT indifference, so several candidates give a tie (resolved by look-ahead,
  section 4).
- In the real substate they have no direct effect; each is carried out by a bottom-level substate.
  In look-ahead copies they act in one step: pick-up(x) -> gripper not empty, holding x;
  put-down(y, d) -> y on d (no longer on old support), gripper empty.

### Bottom level inside pick-up(x) (indifferent; at most one applies at a time)
- move-gripper-up: down, empty, not above x -> up.
- move-gripper-above: up, empty, not above x -> above x.
- move-gripper-down: up, above x, empty -> down.
- close-gripper: down, open, empty, above x -> closed, not empty, holding x.

### Bottom level inside put-down(y, d)
- move-gripper-up-holding: down, not above d -> up.
- move-gripper-above-destination: up, not above d -> above d.
- move-gripper-down-holding: up, above d -> down.
- open-gripper: down, closed, above d -> open, empty, now above y, and y is on d (no longer on its
  old support). Gripper stays down; "holding" still names y.

## 3. Goal and termination
When A, B and C are each on their goal object (by name), print a blank line then
`The problem has been solved.` and halt (the default rules also halt on this). No failure states in
the real world.

## 4. How the agent chooses
- Top level: indifferent with the blocks-world-simple control rules: a move putting a block onto its
  goal object, when that object is in place, is better than all others; a move putting a
  not-in-place block onto the table is best; otherwise random.
- Middle level: ties among pick-up / put-down candidates go to the standard Soar selection space.
  Each candidate is tried on a copy of the move-block substate (objects and gripper copied two levels
  deep; the task block, task dest and gripper are re-linked to the copies by name; clear, free and
  in-place recomputed in the copy). After the candidate is applied in the copy, the copy is judged:
  - success if the task block is on the task dest;
  - failure if the gripper is non-empty and holding a block other than the task block;
  - failure if the gripper is empty and the task block is not on the task dest.
  If neither holds (the task block has just been picked up), search continues in the copy (its
  put-down candidates tie and are evaluated in turn). Success makes the candidate best; failure
  rejects it. Net effect: pick up the task block, put it on the task dest.
- Bottom level: deterministic by conditions.
- No chunking (off), RL or memories.

## 5. Output and settings
Only output is the solved message (blank line first), then halt. Chunking off.
