# blocks-world-hierarchical

Blocks world with a robot gripper, solved by a three-level operator hierarchy:
move-block (top) -> pick-up / put-down (middle) -> gripper motions (bottom). Top-level control
knowledge is the same as blocks-world-simple (file: blocks-world-simple.md).

## 1. Task
Objects: a table and three blocks A, B, C (each has a name and a table flag, yes only for the
table). Each block is on exactly one object; the table has unlimited room. A gripper (named
"gripper") has:
- position: 1 = up, 0 = down
- open: 1 = open, 0 = closed
- empty: 1 = holding nothing, 0 = holding a block
- above: the object it is positioned over
- holding: an object (only meaningful when empty = 0; it is not cleared when the gripper empties)

The first operator (proposed when the top state has no name) names the task "blocks-world" and
builds:

Initial state:
- A on the table, B on the table, C on A
- gripper: up (1), open (1), empty (1), above the table, holding the table (a placeholder value)

Goal: A on B, B on C, C on the table (tower bottom to top: C, B, A).

Derived facts in the top state:
- clear: the table is always clear; an object is clear if nothing is on it and it is not being held
  by a non-empty gripper.
- in place: the table is in place; a block is in place if what it is on is in place and the goal
  says it should be on that object (by name).
Note that a block that is picked up is still recorded as "on" its old support until it is put down.

## 2. Actions
### Top level: move-block(block, dest)
- Proposed (indifferent) when: `block` is not the table; nothing is on `block`; `dest` is clear;
  `dest` differs from `block`; `block` is not already on `dest`; and the gripper is not holding some
  other block (i.e. NOT (gripper non-empty and holding something other than `block`)).
- It has no direct effect; once selected it is carried out in a substate (below). The move is
  finished when `block` ends up on `dest`; at that moment the proposal stops matching and the
  substate disappears.

### Middle level (substate of move-block; it knows block, dest and the gripper)
- pick-up: proposed when the gripper is empty and nothing is on `block`.
- put-down: proposed when the gripper is non-empty and holding `block`.
Both are carried out in their own substates (bottom level).

### Bottom level, inside pick-up (all indifferent; each has the stated condition and effect)
- move-gripper-up: gripper down, empty, and not above `block` -> gripper up.
- move-gripper-above: gripper up, empty, not above `block` -> gripper above `block`.
- move-gripper-down: gripper up, above `block`, empty -> gripper down.
- close-gripper: gripper down, open, empty, above `block` -> gripper closed, not empty, holding
  `block`. (Then pick-up no longer applies and put-down is proposed.)

### Bottom level, inside put-down
- move-gripper-up-holding: gripper down and not above `dest` -> gripper up.
- move-gripper-above-destination: gripper up and not above `dest` -> gripper above `dest`.
- move-gripper-down-holding: gripper up and above `dest` -> gripper down.
- open-gripper: gripper down, closed, above `dest` -> gripper open, empty, now above `block`
  (the block just placed), and `block` is now on `dest` (no longer on its old support).
  The gripper stays down and its "holding" value still names the block.

## 3. Goal and termination
When A, B and C are each on their goal object (by name), print a blank line then
`The problem has been solved.` and halt. No failure states.

## 4. How the agent chooses
- Top level: move-block choices are indifferent with the same two control rules as
  blocks-world-simple: (a) a move putting a block onto its goal object, when that object is already
  in place, is better than every other move; (b) a move putting a not-in-place block onto the table
  is best. Better-filtering first, then best, then random.
- Middle and bottom levels: everything is indifferent (random), but the conditions make at most one
  operator applicable at a time, so the sequence is deterministic (pick-up: up if needed, over the
  block, down, close; put-down: up, over destination, down, open).
- No look-ahead, RL, chunking (off), or memories.

## 5. Output and settings
Only output is the solved message, then halt. Chunking off.
