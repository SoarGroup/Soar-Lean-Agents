# blocks-world-hrl-3level

Three-level gripper blocks world in which the bottom (gripper-motion) level is learned by
reinforcement learning. The world, top level and middle level are as in blocks-world-hierarchical
(file: blocks-world-hierarchical.md); the bottom level is different. Every section is given.

## 1. Task
Table plus blocks A, B, C (name and table flag each). Gripper named "gripper" with position
(1 up / 0 down), open (1/0), empty (1/0), above (an object), holding (an object).

Initial state: A on the table, B on the table, C on A; gripper up, open, empty, above the table,
holding the table (placeholder).

Goal: A on B, B on C, C on the table.

Derived facts in the top state: clear (table always; otherwise nothing on it and not held by a
non-empty gripper) and in place (table; a block on an in-place object that the goal says it should
be on).

## 2. Actions
### Top level: move-block(block, dest)
As blocks-world-hierarchical: proposed (indifferent) when `block` is not the table, nothing is on
`block`, `dest` is clear, `dest` differs from `block`, `block` is not already on `dest`, and the
gripper is not holding some other block. Carried out in a substate; finished when `block` is on
`dest` (proposal stops matching).

### Middle level (in the move-block substate)
- pick-up: proposed when the gripper is empty and nothing is on the task block.
- put-down: proposed when the gripper is non-empty and holding the task block.
Each is carried out in its own substate.

### Bottom level inside pick-up (all proposed as indifferent whenever their condition holds)
- up: gripper down -> up.
- down: gripper up -> down (anywhere).
- above-block: gripper up and not above the task block -> above the task block.
- close: gripper open -> closed. If at that moment the gripper is down, empty and above the task
  block, it also grasps it: not empty, holding the task block (then pick-up is over). Otherwise it
  just closes on nothing.
- open: gripper closed and empty -> open.

### Bottom level inside put-down
- up-holding: gripper down -> up.
- down-holding: gripper up -> down (anywhere).
- above-dest: gripper up and not above the task dest -> above the task dest.
- release: gripper closed and down ->
  - if above the task dest: gripper open, empty, now above the task block, and the task block is on
    the task dest (no longer on its old support);
  - otherwise: gripper open and empty only; the block stays recorded where it was before it was
    picked up (effectively it drops back), and pick-up is needed again.

## 3. Goal and termination
When A, B and C are each on their goal object (by name), print a blank line then
`The problem has been solved.` and halt. No failure states.

## 4. How the agent chooses
- Top level: indifferent with the blocks-world-simple control rules: a move putting a block onto its
  goal object when that object is in place is better than all others; a move putting a not-in-place
  block on the table is best; otherwise random.
- Middle level: deterministic by conditions (no learning).
- Bottom level: RL, epsilon-greedy (Soar default epsilon 0.1), learning rate 0.3, discount 0.9,
  other RL settings at Soar defaults (on-policy SARSA, no eligibility traces). Every bottom-level
  operator has a Q-value for each combination of: operator name, task block name, task dest name,
  gripper position, gripper open, gripper empty, and name of the object the gripper is above. All
  start at 0.
- Rewards:
  - in pick-up: +1 while the gripper is non-empty and holding the task block; -1 while the gripper is
    closed and empty.
  - in put-down: +1 while the task block is on the task dest and the gripper is empty.
- Values persist across episodes after re-initialisation.
No look-ahead, chunking (off) or memories.

## 5. Output and settings
Only output is the solved message, then halt. RL on (rate 0.3, discount 0.9, epsilon-greedy);
chunking off.
