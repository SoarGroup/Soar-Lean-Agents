# blocks-world-hrl

Two-level hierarchical reinforcement learning version of the gripper blocks world. The world
(objects, gripper, initial state, goal) is the same as blocks-world-hierarchical (file:
blocks-world-hierarchical.md); the action hierarchy and choice method differ. Every section is given.

## 1. Task
Table plus blocks A, B, C (name and table flag each). Gripper named "gripper" with position
(1 up / 0 down), open (1/0), empty (1/0), above (an object), holding (an object).

Initial state: A on the table, B on the table, C on A; gripper up, open, empty, above the table,
holding the table (placeholder).

Goal: A on B, B on C, C on the table.

Derived facts in the top state:
- clear: table always clear; an object is clear if nothing is on it and it is not held by a
  non-empty gripper.
- free: table always free; an object is free if nothing is on it (the gripper is ignored).
- in place: as in the other variants (computed, unused here).

## 2. Actions
### Top level: move-block(block, dest)
- Proposed (indifferent) when `block` is not the table, nothing is on `block`, `dest` is free,
  `dest` differs from `block`, and `block` is not already on `dest`. (No gripper condition.)
- Carried out in a substate. The substate ends when the proposal stops matching (e.g. `block` is on
  `dest`, or something has been put on `block` or on `dest`).

### Lower level (substate of move-block; knows the task block, dest and gripper)
These are primitive; each changes the world in one step.
- pick-up(x): proposed for every block x (not the table) with nothing on it, when the gripper is
  empty. Effect: gripper not empty, holding x. (x stays recorded as on its support.)
- put-down(y, d): proposed when the gripper is non-empty and holding y, for every clear object d
  (table included). Effect: y is on d (no longer on its old support), gripper empty. (Putting y back
  on its current support leaves it there.) Gripper position/open/above are not used or changed.
Note: these lower-level operators may pick up or put down a block other than the task block.

## 3. Goal and termination
When A, B and C are each on their goal object (by name), print a blank line then
`The problem has been solved.` and halt. No failure states.

## 4. How the agent chooses
Reinforcement learning at both levels; all proposals are indifferent and selection is
epsilon-greedy over learned values (Soar default epsilon 0.1). Learning rate 0.3, discount 0.9,
other RL settings at Soar defaults (on-policy SARSA, no eligibility traces). All values start at 0.
- Top level Q-values are indexed by: the move's block name and table flag, dest name and table flag,
  gripper name/position/open/empty, where A, B and C each are (name of the support), and the names
  of what the gripper is above and holding.
  Reward: +1 whenever the tower goal holds (top state).
- Lower level Q-values:
  - pick-up indexed by: name of x, task block name, task dest name, gripper name.
  - put-down indexed by: name of y, name of d, task block name, task dest name, gripper name.
  Rewards in the move-block substate: +1 while the task block is on the task dest; -1 while the
  gripper is non-empty and holding a block other than the task block.
- Values persist across episodes after re-initialisation.
No preferences, look-ahead, chunking (off) or memories.

## 5. Output and settings
Only output is the solved message, then halt. RL on (rate 0.3, discount 0.9, epsilon-greedy);
chunking off.
