# blocks-world-look-ahead-state-eval

Based on blocks-world-look-ahead (file: blocks-world-look-ahead.md): same world, initial state,
goal and move action, same standard Soar selection-space look-ahead and chunking, but with a
one-step numeric state evaluation, reinforcement learning, and no "last move" rule. Every section
is given here.

## 1. Task
Table plus blocks A, B, C (name and table flag each); each block on exactly one object; table has
unlimited room. The first operator (proposed when the top state has no name) names the task
"blocks-world" and builds:

Initial state: A on the table, B on the table, C on A.

Goal: A on B, B on C, C on the table. The goal also states that higher evaluation values are better.

Derived "in place" fact: table always in place; a block is in place if it is on an in-place object
that the goal says it should be on.

## 2. Actions
move-block(block, dest):
- Allowed when `block` is not the table, nothing is on `block`, `dest` differs from `block`,
  `block` is not already on `dest`, and `dest` is the table or a block with nothing on it.
- Effect: `block` on `dest`, no longer on its previous support.
- Proposed without indifference, so two or more legal moves produce a tie.

## 3. Goal and termination
Only in the real (top) state: when A, B and C are each on their goal object, the state is marked
successful, a reward is given (below), the agent prints a blank line and
`The problem has been solved.` and halts. Imagined states never count as success.
No failure states.

## 4. How the agent chooses
- Ties are resolved by the standard Soar selection space (as in blocks-world-look-ahead.md): each
  tied move is tried on a copy of the state. Immediately after the move is applied in the copy, the
  copy is given an expected value (one step of look-ahead; this value always exists, so the search
  never goes deeper):
  - 1.0 if A is in place (the whole tower is built);
  - 0.6 if A is not on B and B is in place (B on C, C on table);
  - 0.3 if B is not on C and C is in place (C on the table);
  - 0 if C is not on the table.
- In the selection space, higher values are better and equal values are indifferent; the expected
  values also become numeric preferences for the tied moves.
- Chunking is always on (with operator-selection knowledge), so these evaluations are learned as
  rules that give numeric preferences directly in later matching situations.
- Reinforcement learning is on: rules that give numeric preferences (the learned ones) are updated by
  RL. Reward +1 in the top state when the goal holds. Learning rate 0.3, discount 0.9,
  epsilon-greedy selection among numerically-valued choices (Soar default epsilon 0.1; other RL
  settings at Soar defaults).
- The program keeps an ancestor list on every state (unused).
No episodic or semantic memory.

## 5. Output and settings
Only output is the solved message (blank line first), then halt. Chunking always on (with
operator-selection knowledge); RL on (rate 0.3, discount 0.9, epsilon-greedy).
