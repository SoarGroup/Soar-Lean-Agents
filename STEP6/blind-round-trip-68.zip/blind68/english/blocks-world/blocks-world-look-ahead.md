# blocks-world-look-ahead

Three-block world with the same move action as blocks-world-simple (file: blocks-world-simple.md),
but choices are made by look-ahead search using Soar's standard default selection/evaluation
knowledge (the "selection" default rules), with chunking on. Every section is given here.

## 1. Task
Table plus blocks A, B, C (each has a name and a table flag, yes only for the table). Each block is
on exactly one object; the table has unlimited room. The first operator (proposed when the top state
has no name) names the task "blocks-world" and builds:

Initial state: A on the table, B on the table, C on A.

Goal: A on B, B on C, C on the table (tower bottom to top: C, B, A).

Derived "in place" fact: table always in place; a block is in place if it is on an in-place object
that the goal says it should be on (computed, not used for choices here).

The state also remembers the last move made in it ("last move": which block was moved and where).
It is set (or replaced) every time a move is carried out in that state.

## 2. Actions
move-block(block, dest):
- Allowed when `block` is not the table, nothing is on `block`, `dest` differs from `block`,
  `block` is not already on `dest`, and `dest` is the table or a block with nothing on it.
- Effect: `block` is on `dest`, no longer on its previous support; the state's "last move" is set
  to this move.
- Moves are proposed WITHOUT any indifference, so whenever two or more are legal Soar reaches a tie.

## 3. Goal and termination
In any blocks-world state (real or imagined), the state is marked successful when A, B and C are each
on their goal object. In the real (top) state this prints a blank line and
`The problem has been solved.` and halts (the default rules also halt on top-level success).
In imagined states, success is reported back to the search as a "success" evaluation.
Failure: an imagined state in which no move can be selected is evaluated as a failure (default
rule), and so is an evaluation where the operator being tried is both required and rejected
(constraint failure).

## 4. How the agent chooses
- Ties are resolved by the standard Soar selection space: each tied move is evaluated in turn by
  making a copy of the current state (state copied by default; the object list is copied two levels
  deep so blocks can be changed independently; the "in place" facts and the ancestor list are not
  copied), applying the move to the copy, and continuing from there. In the copy, further ties lead to
  nested selection spaces, so the search is recursive, depth-first, with random order among
  evaluation candidates. There are no numeric evaluations; only success and failure:
  - success evaluation -> that move becomes best in the state that had the tie;
  - failure evaluation -> that move is rejected there.
- No repeated block (in imagined states only): in a copy state created to evaluate a move, any move
  of the same block that was moved last is rejected. The copy inherits its parent's last move, so:
  (a) right after the agent really moves a block, the evaluation of any move of that same block
  fails (it is required and rejected at once), and (b) along an imagined path the same block is never
  moved twice in a row. An imagined state where every move is rejected is a failure.
- The program also keeps a list of every ancestor state on each state; nothing uses it.
- Chunking is always on, with operator-selection knowledge included, so the results of searches are
  learned as rules (e.g. "in this situation, this move is best / is rejected") and reused later
  without search.
No RL, no episodic/semantic memory.

## 5. Output and settings
Only output is the solved message (blank line first), then halt. Chunking always on, with
operator-selection knowledge added.
