# blocks-world-operator-subgoaling-chunk

Identical to blocks-world-operator-subgoaling (file: blocks-world-operator-subgoaling.md) in task,
initial state (A on B, B on table, C on table), goal (A on B, B on C, C on table), actions,
subgoaling, preferences and output, EXCEPT that learning (chunking) is turned on.

## 1. Task
As in blocks-world-operator-subgoaling.md.

## 2. Actions
As in blocks-world-operator-subgoaling.md (moves proposed without clearness checks; a selected move
whose block or destination is not clear causes a subgoal that shares the real objects and whose goal
is to make both clear; nested recursively).

## 3. Goal and termination
As in blocks-world-operator-subgoaling.md: print a blank line and `The problem has been solved.`,
then halt, when the three-block tower goal holds in the top state.

## 4. How the agent chooses
Same preferences as blocks-world-operator-subgoaling.md (best for goal placement in the top state;
in subgoals best for moving a block off an object to be cleared, worst for putting a block onto an
object to be cleared; otherwise random).

Difference: chunking is on for every subgoal ("always"), and the operator-selection knowledge that
led to choices in the subgoal is included in what is learned. When a subgoal changes the world
(a move made inside it alters the shared objects), Soar learns a rule summarising it: roughly, "when
the top state has selected a move of block X onto D, and some clear block Y sits on X, move Y onto
some other clear object". In later, matching situations this rule makes the clearing move directly,
without entering the subgoal. In the standard run of this task one such rule is learned (when A is
moved off B).

## 5. Output and settings
Only output is the solved message, then halt. Chunking always on, with operator-selection knowledge
added to learned rules.
