# blocks-world-operator-subgoaling-relevant

Based on blocks-world-operator-subgoaling (file: blocks-world-operator-subgoaling.md), with four
blocks, and with the preference rules replaced by restricting WHICH moves are proposed ("only
relevant moves"). Every section is given here.

## 1. Task
Table plus four blocks A, B, C, D (each object has a name and a table flag, yes only for the table).
Each block is on exactly one object; the table has unlimited room. The first operator (proposed when
the top state has no name) names the task "blocks-world" and builds:

Initial state:
- A on the table
- B on D
- C on A
- D on the table

Goal: A on B, B on C, C on D, D on the table (tower bottom to top: D, C, B, A).

Derived facts, computed in the top state only (visible in subgoals because objects are shared):
- clear: table always clear; any object with nothing on it is clear.
- in place: as in the other variants (computed but unused here).

## 2. Actions
move-block(block, dest) — carried out only when `block` is clear and `dest` is clear; effect:
`block` on `dest`, no longer on its previous support. It is proposed (indifferent) only in two cases:
1. Goal-directed: `block` is not the table, `dest` is the object the tower goal says `block` should
   be on (by name), and `block` is not already there. No clearness check. (Only possible in the top
   state, the only state with a tower goal.)
2. Clearing: `block` is not the table, `block` is sitting on an object the current state wants clear,
   `dest` is a clear object different from `block`, and `block` is not already on `dest`. (Only
   possible in subgoals.) Note there is no rule against putting the block onto the other object the
   subgoal wants clear.

If a selected move cannot be carried out, the agent enters a subgoal for it: a blocks-world state
sharing the same objects (so moves there change the real world), whose goal is "make `block` clear
and make `dest` clear". Blocked moves inside a subgoal create deeper subgoals, recursively. When both
objects become clear, the parent's move executes, stops being proposed, and the subgoal disappears.

## 3. Goal and termination
When (in the top state) A, B, C, D are each on their goal object, print a blank line then
`The problem has been solved.` and halt. No failure states.

## 4. How the agent chooses
Random (indifferent) choice among the proposed moves; there are no other preferences. No
look-ahead, RL, chunking (off), or memories.

Note: because clearing moves may put a block onto the other object the subgoal is trying to clear,
the agent can take extra steps, but it still reaches the goal.

## 5. Output and settings
Only output is the solved message, then halt. Chunking off.
