# blocks-world-operator-subgoaling

Same world as blocks-world-simple (file: blocks-world-simple.md) but with three blocks and a
different way of handling blocked moves: a move may be chosen even when it cannot yet be done, and
the agent then sets up a subgoal to clear the way ("operator subgoaling"). Every section is given.

## 1. Task
Table plus three blocks A, B, C (each object has a name and a table flag, yes only for the table).
Each block is on exactly one object; the table has unlimited room. The first operator (proposed when
the top state has no name) names the task "blocks-world" and builds:

Initial state: A on B, B on the table, C on the table.

Goal: A on B, B on C, C on the table (tower bottom to top: C, B, A).

Derived facts, computed in the top state only (they live on the shared block objects, so they are
also visible from the subgoal states described below):
- clear: the table is always clear; any object with nothing on it is clear.
- in place: the table is in place; a block is in place if what it is on is in place and the goal
  says it should be on that object (by name). (Computed but not used by any choice in this variant.)

## 2. Actions
move-block(block, dest):
- Proposed (as indifferent) for every pair where `block` is not the table, `dest` is a different
  object, and `block` is not already on `dest`. Clearness is NOT checked when proposing.
- It can only be carried out when `block` is clear and `dest` is clear. Effect: `block` is on
  `dest`, no longer on its previous support.
- If a selected move cannot be carried out (block or dest not clear), the agent gets stuck on it
  (operator no-change) and enters a subgoal state for that move:
  - The subgoal is also a blocks-world state; it sees the very same objects as its parent (shared,
    not copies), so moves made there change the real world directly.
  - Its goal is "make `block` clear and make `dest` clear" (it has no tower goal).
  - The same move-block proposals (and the same carry-out conditions) apply inside it; a move there
    that is itself blocked creates a deeper subgoal of the same kind, recursively.
  - There is no explicit "subgoal achieved" step: as soon as both objects are clear, the parent's
    selected move becomes executable, it is carried out, it is no longer proposed (block is now on
    dest), and the subgoal disappears.

## 3. Goal and termination
When (in the top state) A, B, C are each on their goal object, print a blank line then
`The problem has been solved.` and halt. Subgoal states never count as reaching the tower goal.
No failure states.

## 4. How the agent chooses
All moves are indifferent, plus these preferences, applied in any blocks-world state (top or
subgoal) where their conditions can match:
- Prefer-goal-placement (best): a move that puts a block onto the object the tower goal says it
  should be on. (Only matches in the top state, which is the only state with a tower goal.)
- Prefer-clearing (best): a move of a block that is sitting on an object the current state wants
  clear. (Only matches in subgoals.)
- Avoid-clobbering (worst): a move whose destination is an object the current state wants clear.
  (Only matches in subgoals.)
Soar semantics: best set first, then worst ones are dropped unless nothing else remains, then a
random choice among the rest.
No look-ahead, RL, chunking (off), or memories.

Example of the resulting behaviour from the initial state: the top state chooses B onto C (goal
placement) although B is covered; in the subgoal (want B and C clear) it moves A (which is on B)
onto the table, because moves onto B or C are worst; then B goes on C; then A goes on B.

## 5. Output and settings
Only output is the solved message, then halt. Chunking off.
