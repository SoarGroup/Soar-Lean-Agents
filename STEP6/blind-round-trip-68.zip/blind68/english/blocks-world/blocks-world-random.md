# blocks-world-random

As blocks-world-simple (file: blocks-world-simple.md) in structure, but with three blocks, a
different start, and NO control knowledge at all. Every section is given here.

## 1. Task
Table plus three blocks A, B, C (each object has a name and a table flag, yes only for the table).
Each block is on exactly one object; the table has unlimited room. The first operator (proposed when
the top state has no name) names the task "blocks-world" and builds:

Initial state: A on the table, B on the table, C on the table.

Goal: A on B, B on C, C on the table (tower bottom to top: C, B, A).

The program also computes the derived "in place" fact (table always in place; a block is in place
if it sits on an in-place object that the goal says it should be on), but nothing uses it.

## 2. Actions
move-block(block, dest):
- Allowed when `block` is not the table, nothing is on `block`, `dest` differs from `block`,
  `block` is not already on `dest`, and `dest` is the table or a block with nothing on it.
- Effect: `block` is on `dest` and no longer on its previous support.

## 3. Goal and termination
When A, B and C are each on their goal object (by name), print a blank line then
`The problem has been solved.` and halt. No failure states.

## 4. How the agent chooses
Purely random: all legal moves are indifferent and one is picked at random each decision. No
preferences, heuristics, look-ahead, RL, chunking (off), memories or substates.

## 5. Output and settings
Only output is the solved message, then halt. Chunking off.
