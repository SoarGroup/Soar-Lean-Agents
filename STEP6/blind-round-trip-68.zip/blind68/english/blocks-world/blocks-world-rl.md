# blocks-world-rl

As blocks-world-simple (file: blocks-world-simple.md) for the world and the move action, but with
four blocks and with choices made by reinforcement learning instead of control rules. Every
section is given here.

## 1. Task
Table plus four blocks A, B, C, D (each object has a name and a table flag, yes only for the table).
Each block is on exactly one object; the table has unlimited room. The first operator (proposed when
the top state has no name) names the task "blocks-world" and builds:

Initial state:
- A on the table
- B on D
- C on A
- D on the table

Goal: A on B, B on C, C on D, D on the table (tower bottom to top: D, C, B, A).

The derived "in place" fact (table always in place; a block is in place if it is on an in-place
object that the goal says it should be on) is computed but not used.

## 2. Actions
move-block(block, dest):
- Allowed when `block` is not the table, nothing is on `block`, `dest` differs from `block`,
  `block` is not already on `dest`, and `dest` is the table or a block with nothing on it.
- Effect: `block` is on `dest` and no longer on its previous support.

## 3. Goal and termination
When A, B, C and D are each on their goal object (by name), the state is marked as successful,
the agent prints a blank line then `The problem has been solved.` and halts. No failure states.

## 4. How the agent chooses
- All legal moves are proposed as indifferent.
- Reinforcement learning (Q-values) chooses among them. Each Q-value is indexed by the full
  situation plus the move: where A, B, C and D currently are (the name of what each is on), the
  moved block's name, and the destination's name (and their table flags). Every value starts at 0;
  entries are created as new situation/move combinations are met.
- Reward: +1 whenever the goal is satisfied (given in the top state when success is detected).
  No other rewards.
- Learning rate 0.3, discount 0.9, epsilon-greedy selection (Soar default epsilon 0.1; other RL
  settings at Soar defaults: on-policy SARSA, no eligibility traces).
- Learned values persist across episodes when the agent is re-initialised.
No other control knowledge, no look-ahead, chunking off, no memories, no substates.

## 5. Output and settings
Only output is the solved message, then halt. RL on (rate 0.3, discount 0.9, epsilon-greedy).
Chunking off.
