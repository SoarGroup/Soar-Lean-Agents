# blocks-world-simple-3

Same as blocks-world-simple (file: blocks-world-simple.md) except for the number of blocks, the
initial state and the goal. Every section is repeated here for completeness.

## 1. Task
A blocks world with a table and three blocks A, B, C. Each object has a name and a table flag (yes
for the table only). Each block rests on exactly one object; the table has unlimited room. The first
operator (proposed when the top state has no name) names the task "blocks-world" and builds:

Initial state:
- A on the table
- B on the table
- C on A

Goal: A on B, B on C, C on the table (tower bottom to top: C, B, A).

Derived "in place": the table is always in place; a block is in place if what it is on is in place
and the goal says the block should be on that object (compared by name).

## 2. Actions
move-block(block, dest):
- Allowed when `block` is not the table, nothing is on `block`, `dest` differs from `block`,
  `block` is not already on `dest`, and `dest` is the table or a block with nothing on it.
- Effect: `block` is on `dest` and no longer on its previous support.

## 3. Goal and termination
When A, B and C are each on their goal object (by name), print a blank line then
`The problem has been solved.` and halt. No failure states.

## 4. How the agent chooses
Moves are indifferent (random among survivors) with two control rules:
- A move putting a block onto its goal object, when that object is already in place, is better than
  every other proposed move.
- A move putting a not-in-place block onto the table is best.
Soar semantics: "better" filtering first, then "best", then random among what is left.
No look-ahead, RL, chunking (off), memories or substates.

## 5. Output and settings
Only output is the solved message, then halt. Chunking off.
