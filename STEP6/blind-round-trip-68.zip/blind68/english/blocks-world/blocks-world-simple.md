# blocks-world-simple

## 1. Task
A classic blocks world with one table and five blocks named A, B, C, D, E. Every object has a name
and a flag saying whether it is the table (table = yes for the table, no for each block). Each block
rests on exactly one other object (the table or another block). The table rests on nothing and has
unlimited room.

The agent's first operator (proposed only when the top state has no name yet) builds the state,
names the task "blocks-world", and creates:

Initial state:
- A on the table
- B on E
- C on A
- D on the table
- E on D

(So there are two towers: table-A-C and table-D-E-B.)

Goal (stored in the state as a list of "block X should be on Y" facts):
- A on B, B on C, C on D, D on E, E on the table
(one tower, bottom to top: E, D, C, B, A).

Derived (continuously recomputed) fact "in place":
- The table is always in place.
- A block is in place if the object it is on is in place AND the goal says this block should be on
  that object. (Comparisons between goal and state are done by object name.)

## 2. Actions
move-block(block, dest): move one block onto another object.
- Allowed when: `block` is a block (not the table); nothing is on `block`; `dest` is a different
  object from `block`; `block` is not already on `dest`; and either `dest` is the table, or `dest`
  is a block with nothing on it.
- Effect: `block` is now on `dest` and no longer on what it was on before.
All currently legal move-block instances are proposed together.

## 3. Goal and termination
The goal is reached when each of the five blocks is on the object (by name) that the goal says.
When reached, the agent prints a blank line and then `The problem has been solved.` and halts.
There are no failure states.

## 4. How the agent chooses
All proposed moves are mutually indifferent (random choice among the survivors), filtered by two
pieces of control knowledge:
- "Build on what is finished": a move that puts a block onto the object the goal wants it on, when
  that destination is already in place, is better than every other proposed move.
- "Clear away the wrong blocks": a move that puts a block that is not in place onto the table is a
  best choice.
Standard Soar preference semantics apply: the "better" comparison is applied first (so if a
build-on-finished move exists it alone survives), then "best" picks among what remains; if neither
applies the choice is random among all legal moves. (Only one build-on-finished move can exist at a
time in this task, so the better preferences never conflict.)
No look-ahead, no reinforcement learning, no chunking (learning is off), no semantic or episodic
memory, no substates.

## 5. Output and settings
Only output: the "The problem has been solved." line (preceded by a newline), then halt.
Learning (chunking) off.
