# Counting: add two digits by counting with successor facts from semantic memory (variant "count-add-smem")

## 1. Task
The state holds an "adder" with: first digit 9, second digit 9, carry 0, done 0 (set by an
initialization operator chosen first, when the top state has no name; it also names the task).
The desired state is: the adder's done flag equals 1.

Semantic memory is preloaded (before running) with ten successor facts, each of kind "succ",
giving a digit symbol and its next digit:
0->1, 1->2, 2->3, 3->4, 4->5, 5->6, 6->7, 7->8, 8->9, 9->0.
The agent has no other arithmetic knowledge; it obtains every successor by retrieving one of these
facts. (Semantic-memory learning is set on.)

## 2. Actions
Top level: "add" (for the adder): proposed while the adder's done flag is 0 (indifferent). It has no
direct effect and is carried out in a substate (operator decomposition). The substate knows the
adder.

The substate keeps local values: a running sum digit, a step counter, a local carry, and a phase
(0 or 1).
- "init local": proposed when there is no running sum digit yet. Effect: running sum digit := the
  adder's first digit (9); step counter := 0; local carry := 0; phase := 0.
- "next sum digit": proposed when phase is 0 and the step counter differs from the adder's second
  digit. Effect, in two steps while it stays selected:
  1. query semantic memory for the fact of kind "succ" whose symbol is the current running sum
     digit;
  2. when the fact is retrieved: running sum digit := that fact's next digit; if the running sum
     digit was 9 before the step (i.e. it wraps to 0), local carry := 1 (otherwise the carry is
     left as it is); phase := 1; remove the query.
- "next step count": proposed when phase is 1. Effect, likewise in two steps:
  1. query semantic memory for the "succ" fact whose symbol is the current step counter;
  2. on retrieval: step counter := its next digit; phase := 0; remove the query.
- "done": proposed when phase is 0 and the step counter equals the adder's second digit. Effect:
  adder's first digit := running sum digit; adder's carry := local carry; adder's done := 1.
So the agent adds the second digit to the first by counting up the first digit once per step,
counting steps until it reaches the second digit, with a carry when the digit wraps past 9.

## 3. Goal
When the adder's done flag equals 1, success: print a new line then
"The problem has been solved." and halt. No failure states.

## 4. How the agent chooses
At each point exactly one operator applies (proposals are indifferent). No search, chunking off,
no RL, no episodic memory. Semantic memory retrieval (query by kind and symbol) is used as
described.

Observed: about 41 decisions; final adder: first digit 8, carry 1, second digit 9, done 1
(i.e. 9 + 9 = 18); then the success message and halt.

## 5. Output and settings
Only the success message. Chunking off; semantic-memory learning on; the ten successor facts
above preloaded into semantic memory.
