# Counting: count to 75000 inside a substate (variant "count-in-substate")

## 1. Task
The state holds one counter with a single value. Initial value: 1 (set by an initialization
operator chosen first, when the top state has no name; it also names the task). Desired: counter
value 75000.

## 2. Actions
Top level: "count to limit" (for the counter): proposed whenever the counter's value is less than
75000 (indifferent). It has no direct effect; it is carried out in a substate (operator
decomposition):

In the substate for "count to limit" (the substate knows which counter it works on):
- "init local": proposed when the substate has no local count yet. Effect: set the local count to
  the counter's current value.
- "increment": proposed when the local count exists and is less than 75000. Effect: local count
  := local count + 1.
- "done": proposed when the local count equals 75000. Effect: write the local count into the top
  counter's value (replacing the old value). This completes "count to limit".
The counter's value is not changed during the incrementing; it is updated once, by "done".

## 3. Goal
When the counter's value equals 75000, success: print a new line then
"The problem has been solved." and halt. No failure states.

## 4. How the agent chooses
At each point only one operator is applicable (proposals are indifferent), so no choice is
needed. No search, chunking off, no RL, no memories.

Observed: 74999 increments in the substate, about 75004 decisions in all, then the success
message and halt; final counter value 75000.

## 5. Output and settings
Only the success message. Chunking off.
