# Counting: count up to 100 (variant "count-up")

## 1. Task
The state holds one counter with a single value. Initial value: 0 (set by an initialization
operator chosen first, when the top state has no name; it also names the task). The desired
state is a counter value of 100.

## 2. Actions
"Count": proposed whenever the counter's value is less than 100. Effect: replace the value with
value + 1.

## 3. Goal
When the counter's value equals the desired value (100), the state is a success: the agent prints
a new line then "The problem has been solved." and halts. No failure states.

## 4. How the agent chooses
Only one action is ever available (marked indifferent), so it is simply selected each decision.
No preferences, search, learning (chunking off), RL, or memories.

Observed: 100 count steps, about 101 decisions in all, then the success message and halt.

## 5. Output and settings
Only the success message. Chunking off.
