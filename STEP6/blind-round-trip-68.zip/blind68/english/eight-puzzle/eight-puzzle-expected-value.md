# Eight puzzle: one-step look-ahead with expected values (variant "eight-puzzle-expected-value")

As variant "eight-puzzle" (file: english/eight-puzzle/eight-puzzle.md), except in how the look-ahead
score is turned into a choice. Task, boards, moves (proposed without indifference, so ties trigger
look-ahead), the reject-last-tile rule, the last-move record, copying, goal test, success message,
halting, and chunking are all the same. Summary:

## 1. Task
3x3 board, cells 11..33 with 4-neighborhood, tiles 0-8 (0 = blank).
Initial:

    2 1 7
    8 6 _
    3 4 5

Desired:

    1 8 7
    2 _ 6
    3 4 5

## 2. Actions
"Move tile": slide a non-blank tile adjacent to the blank into the blank. Reject moving the tile
that was moved last. Last-move record updated after each move.

## 3. Goal
All positions match the desired board: print new line + "The problem has been solved." and halt.
No failure states; no repeated-state detection.

## 4. How the agent chooses
Ties are resolved by one-step look-ahead exactly as in "eight-puzzle", with the same scores
(+1 tile moved into its goal place, -1 tile moved out of its goal place, 0 otherwise; success if
the copy is the goal). The difference: the score is an EXPECTED VALUE, not a comparison value.
Each evaluated move's expected value becomes a numeric-indifferent preference for that move with
that number (no better/worse preferences are made). A goal-reaching move still gets "success" and
hence a best preference.
Once all tied moves carry numbers, the choice among them is made by the default exploration
policy: softmax (Boltzmann) with temperature 25 (the default). With values only in {-1, 0, 1},
this is close to a uniform random choice, with only a slight bias to higher values.
(An expected value found in a deeper look-ahead would be passed up multiplied by 0.9, but the
look-ahead here is only one step deep.)
Chunking always on as in "eight-puzzle". No RL learning, no semantic/episodic memory.

Note: because temperature 25 nearly ignores the score, the agent behaves almost like a random walk
that never immediately undoes a move. Observed: sometimes it solves in under 20 decisions,
sometimes it takes thousands, and sometimes it has not solved within 5000 decisions.

## 5. Output and settings
Only the success message. Chunking always on, including over operator-selection knowledge.
Exploration: softmax, temperature 25 (defaults).
