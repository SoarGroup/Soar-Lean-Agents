# Eight puzzle: one-step look-ahead with a tile-placement score (variant "eight-puzzle")

## 1. Task
A 3x3 sliding-tile puzzle. Cells are named by row and column 11,12,13 / 21,22,23 / 31,32,33, each
neighboring the cells directly above, below, left and right of it (4-neighborhood). Tiles are
numbered 0-8; tile 0 is the blank. The board is a set of nine positions (one per cell), each
holding exactly one tile.

Initial board (set by an initialization operator chosen first, when the top state has no name;
it also names the task; "_" is the blank):

    2 1 7
    8 6 _
    3 4 5

Desired board (the desired state also states that higher numeric evaluations are better):

    1 8 7
    2 _ 6
    3 4 5

## 2. Actions
"Move tile": for every non-blank tile in a cell adjacent to the blank's cell, propose moving that
tile into the blank's cell. Effect: the tile's old position now holds the blank and the blank's old
position holds the tile.

Moves are proposed WITHOUT indifference, so whenever two or more moves remain they tie and the tie
is resolved by look-ahead (section 4).

The agent remembers its last move (which tile it moved, from where to where); this record is
replaced after each move. Rule: reject any proposed move of the same tile that was moved last
(i.e. never immediately undo the previous move). This applies in the real state and in any
look-ahead state that has a last-move record (a fresh look-ahead copy does not inherit the record).

## 3. Goal
Success when every position holds the tile the desired board has there. At the top level: print a
new line then "The problem has been solved." and halt. No failure states are defined. No
repeated-state detection is used.

## 4. How the agent chooses: one-step look-ahead (standard "selection" evaluation scheme)
When moves tie, a selection subgoal evaluates each tied move in turn (in random/indifferent
order). For each one it:
1. Copies the task state: the nine positions are copied as new objects (with their cell and tile),
   while cells and tiles themselves are shared (not copied); the desired board is shared; the last
   move record is not copied. The move is copied so it refers to the copied positions.
2. Applies the move to the copy.
3. Scores the result (the move just tried moved tile T from position P into position X):
   - +1 if X's tile now equals the desired tile for X (the tile moved into its goal place);
   - -1 if T is the desired tile for P (the tile moved out of its goal place);
   - 0 otherwise.
   If the copy is the goal, the move is also evaluated "success".
Because the score is immediate, the look-ahead is exactly one move deep.
Evaluations become preferences for the tied moves:
- success -> best;
- higher score is better than lower score;
- equal scores -> indifferent (random choice).
Then the winner is applied to the real board.

Learning: chunking always on (including over operator-selection knowledge); evaluations become
rules that give the preferences directly next time the same situation arises (so re-running after
re-initialization takes fewer decisions). No RL, no semantic or episodic memory.

Observed: solves the puzzle in every tested seed (about 19-24 decisions on the first run, 6-10
afterwards) and prints the success message.

## 5. Output and settings
Only the success message. Chunking always on, including over operator-selection knowledge.
