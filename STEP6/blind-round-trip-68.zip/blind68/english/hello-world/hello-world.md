# hello-world

## 1. Task
A trivial task. The world contains a single greeting, which has a "written" flag that is 0
(not yet written) at the start. The goal is for the greeting's written flag to be 1.

Initialisation: when the agent starts and the top state has no name yet, a single
initialisation step names the task "hello-world", creates the greeting with written = 0, and
records the desired state (a greeting with written = 1).

## 2. Actions
- **Say hello** (one action, applied to the greeting). Allowed only while the greeting's written
  flag is 0. Effect: sets the written flag to 1 (replacing 0) and prints `Hello World`.

## 3. Goal and termination
Goal: the greeting's written flag equals the desired value 1. When the goal holds, the agent
prints a newline then `The problem has been solved.` and halts. There are no failure states.

## 4. Choice among actions
Only one action is ever available; it is proposed as indifferent (no preferences needed).
No search, no learning (learning/chunking is turned off), no substates, no memories.

## 5. Output and settings
Expected output:
```
Hello World
The problem has been solved.
```
Takes 3 decision cycles (initialise, say hello, halt).
