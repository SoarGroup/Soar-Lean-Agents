# kenken-4-1: KenKen puzzle solver (4x4)

## 1. The task

The agent solves a KenKen puzzle on an N x N grid (N = 4 in this variant). Every cell must receive a value from 1 to N so that each row and each column contains each value exactly once, and so that each cage (a group of cells) satisfies its clue. The puzzle-specific data (cages and their allowed combinations) is listed in the section "Puzzle data for this variant" at the end of this file.

Objects in the state (all created by a single initialization action, see below):

- **Cells**: one per grid square. Each has a row (1..N), a column (1..N), a two-digit code equal to (column x 10 + row) -- e.g. the cell in row 2, column 1 has code 12 -- and a mark, which is 0 when the cell is empty and otherwise the value placed in it. Initially every mark is 0. Each cell owns N candidates.
- **Candidates**: one per (cell, value) pair, i.e. N x N x N in total. Each knows its cell's row, column and code, its value, and whether it is alive (1) or dead (0). Initially all are alive. Each candidate also knows the list of cage combinations it belongs to (possibly none).
- **Combinations** (allowed cage fillings): each is a list of candidates, one per cell of its cage, plus an alive flag (initially alive). The cage clues are not stored; only these combinations are (see the puzzle data section for exactly which combinations exist).
- **Puzzle record**: a count of marked cells (initially 0), a "chosen cell for guessing" slot (initially 0 = none), and a count of rows printed so far (initially 0).
- **Desired state**: the count of marked cells equals N x N (16 here).

## 2. Actions

All actions below except initialization and row printing are available in the main task state and also inside look-ahead copies of it (section 4).

1. **Initialize** -- proposed only when the top state has not yet been initialized. Creates everything in section 1 (all marks 0, all candidates and combinations alive, counts 0, chosen cell none) and names the state as the KenKen task.

2. **Assign** (deduction: place a forced value). Proposed for an empty cell C and one of its alive candidates of value V when ANY of the following holds:
   - (a) V is the only value alive in C (no alive candidate of C has a different value); or
   - (b) no other cell in C's row (any cell with a different code, whether empty or marked) has an alive candidate of value V; or
   - (c) no other cell in C's column has an alive candidate of value V.
   Effect: C's mark becomes V; the marked-cell count goes up by 1; prints `Set cell: <code of C> to <V>`. (It does not itself kill anything; the actions below do that.) Several assign proposals, even two with different values for the same cell, may exist at once; whichever is chosen first is applied, and the others for that cell disappear because the cell is no longer empty.

3. **Cleanup** -- proposed for a marked cell C and an alive candidate of C whose value differs from C's mark. Effect: that candidate becomes dead.

4. **Eliminate** -- proposed for a marked cell C1 with mark V and a different cell C2 in the same row or the same column as C1 (C2 may be empty or marked) that has an alive candidate of value V. Effect: that candidate of C2 becomes dead.

5. **Drop combination** -- proposed for an alive combination that uses a dead candidate. Effect: the combination becomes dead.

6. **Prune** -- proposed for an alive candidate none of whose combinations is alive (this includes candidates that belong to no combination at all). Effect: the candidate becomes dead.

7. **Choose guess cell (two options)** -- proposed for an empty cell that has exactly 2 alive candidates, only while no guess cell is currently chosen. Effect: records that cell's code as the chosen guess cell; prints `Guess cell: <code>`.

8. **Choose guess cell (three options)** -- same, but for an empty cell with exactly 3 alive candidates. Same effect and print. (Cells with 4 or more alive candidates are never chosen for guessing.)

9. **Guess** -- proposed, while a guess cell is chosen, once for each alive candidate of that cell. Effect: the cell's mark becomes that candidate's value; the marked-cell count goes up by 1; the chosen guess cell is reset to none; prints `Guess: <code> is <value>`.

10. **Print row** -- top state only, and only after the goal has been reached at the top (see section 3). Row r is proposed when exactly r-1 rows have been printed, so rows are printed in order 1..N. Effect: prints the marks of row r from column 1 to column N, and sets the printed-row count to r. Output format: `| a | b | ... | z | ` (a vertical bar and space, then each value followed by space, bar, space).

## 3. Goal and failure

- **Goal test (any state of the task):** the marked-cell count equals N x N.
  - In a look-ahead copy: reaching this immediately counts as success for that copy (used by the search, section 4).
  - In the top state: reaching this makes the row-printing actions available; once all N rows are printed, the agent prints a newline followed by `The problem has been solved.` and halts.
- **Failure test (any state of the task):** the state has failed if either (a) some empty cell has no alive candidate, or (b) some marked cell's candidate for its own mark value is dead (i.e. the placed value has been eliminated, meaning a row/column/cage conflict). In a look-ahead copy this is a failure evaluation (section 4). In the top state the agent prints a newline followed by `Failure state: the task has failed.` and halts (in practice this never happens, because only guesses that look-ahead has shown to succeed are made at the top).

## 4. How the agent chooses among actions

- Assign, cleanup, eliminate, drop combination, prune, both choose-guess-cell actions and print row are all marked indifferent: when several are proposed, one is picked at random. There is no priority among the deduction actions.
- Both choose-guess-cell actions get a "worst" preference: they are only selected when no deduction action (assign, cleanup, eliminate, drop combination, prune) is available, i.e. when propagation has stopped.
- When both kinds are available, choosing a two-option cell is preferred over choosing a three-option cell. Among several cells of the same kind the choice is random.
- **Guess actions are NOT marked indifferent.** Since a chosen cell always has at least two alive candidates, the guesses tie, and the agent resolves the tie by **look-ahead search** (standard Soar selection-space evaluation):
  - Each tied guess is evaluated, one at a time in random order, in a copy of the current state (cells, candidates, combinations and the puzzle record are copied deeply; the desired state is shared).
  - In the copy, the guess is applied first, and then the copy continues normal problem solving with all the same actions and preferences: deduction, and if needed choosing a further guess cell and guessing again, which creates a nested tie and nested look-ahead in the same way (recursive depth-first search).
  - Evaluation of a guess: if the copy reaches the goal test, the evaluation is **success**, which gives the guess a "best" preference in the state where the tie occurred (and, when this happens inside a nested look-ahead, the enclosing guess being evaluated is also marked as a partial success, so success propagates upward). If the copy meets the failure test, the evaluation is **failure** and the guess is rejected. If the copy gets stuck with no action available, or if every guess of a nested tie gets rejected, the evaluation is an exhaustion failure and the guess is rejected.
  - As soon as one guess has a success evaluation it is selected (remaining guesses need not be evaluated); if failures reject all but one guess, the remaining one is selected. The selected guess is then actually applied in the state that had the tie, and solving continues there (so the deductions that were made in the look-ahead are made again for real, and their `Set cell` lines are printed again).
  - No numeric evaluations are used; only success / failure.
- **Learning:** chunking is turned on for all states (with operator-selection knowledge allowed in chunks and chunks over local negations disallowed). In practice no rules are learned: in test runs zero chunks were created. No reinforcement learning, no semantic or episodic memory.
- Note: substates also record the chain of their ancestor states, but nothing uses this (and it is excluded from state copying); it can be omitted.

## 5. Output and settings

- Printed messages are written without newlines between them, so they run together on one line: `Set cell: <code> to <v>`, `Guess cell: <code>`, `Guess: <code> is <v>`, then the N row strings, then a newline and `The problem has been solved.` (or a newline and `Failure state: the task has failed.`). Messages from inside look-ahead copies are printed too.
- Cell codes in the output are column digit followed by row digit (code 43 = row 3, column 4).
- No numeric parameters other than N and the puzzle data.


## Puzzle data for this variant

Grid size N = 4 (16 cells, values 1..4). Number of stored allowed combinations (all cages together): 37.

Cages (cells are written rRcC = row R, column C; in printed output this cell's code is the two-digit number C then R):

- Cage 1: r1c1, r1c2 -- difference (larger minus smaller) = 1. 6 allowed combination(s).
  Allowed: (r1c1=1, r1c2=2); (r1c1=2, r1c2=1); (r1c1=2, r1c2=3); (r1c1=3, r1c2=2); (r1c1=3, r1c2=4); (r1c1=4, r1c2=3).
- Cage 2: r1c3, r1c4 -- quotient (larger divided by smaller) = 2. 4 allowed combination(s).
  Allowed: (r1c3=1, r1c4=2); (r1c3=2, r1c4=1); (r1c3=2, r1c4=4); (r1c3=4, r1c4=2).
- Cage 3: r2c1, r2c2 -- difference (larger minus smaller) = 1. 6 allowed combination(s).
  Allowed: (r2c1=1, r2c2=2); (r2c1=2, r2c2=1); (r2c1=2, r2c2=3); (r2c1=3, r2c2=2); (r2c1=3, r2c2=4); (r2c1=4, r2c2=3).
- Cage 4: r2c3, r2c4 -- sum = 5. 4 allowed combination(s).
  Allowed: (r2c3=1, r2c4=4); (r2c3=2, r2c4=3); (r2c3=3, r2c4=2); (r2c3=4, r2c4=1).
- Cage 5: r3c1, r4c1, r4c2 -- product = 8. 6 allowed combination(s).
  Allowed: (r3c1=1, r4c1=2, r4c2=4); (r3c1=1, r4c1=4, r4c2=2); (r3c1=2, r4c1=1, r4c2=4); (r3c1=2, r4c1=4, r4c2=1); (r3c1=4, r4c1=1, r4c2=2); (r3c1=4, r4c1=2, r4c2=1).
- Cage 6: r3c2, r3c3 -- difference (larger minus smaller) = 2. 4 allowed combination(s).
  Allowed: (r3c2=1, r3c3=3); (r3c2=2, r3c3=4); (r3c2=3, r3c3=1); (r3c2=4, r3c3=2).
- Cage 7: r3c4 -- single cell, value must be 2. One allowed combination.
- Cage 8: r4c3, r4c4 -- difference (larger minus smaller) = 1. 6 allowed combination(s).
  Allowed: (r4c3=1, r4c4=2); (r4c3=2, r4c4=1); (r4c3=2, r4c4=3); (r4c3=3, r4c4=2); (r4c3=3, r4c4=4); (r4c3=4, r4c4=3).

The program does not store the arithmetic clue itself. For every cage it stores the explicit list of allowed value combinations, and that list is exactly: every assignment of values 1..N to the cage's cells that satisfies the clue above and gives different values to any two cells of the cage that share a row or a column (cells of the same cage that share neither may repeat a value). Each combination knows which (cell, value) candidates it uses, and each candidate knows which combinations it belongs to. Candidates that belong to no combination at all start alive and are removed by the prune action at the start.

Observed result (run with two seeds): the agent solves the puzzle and prints these rows:

```
| 3 | 4 | 2 | 1 | 
| 2 | 3 | 1 | 4 | 
| 4 | 1 | 3 | 2 | 
| 1 | 2 | 4 | 3 | 
```

Observed: solved by deduction alone (no guess cell chosen, no look-ahead).
