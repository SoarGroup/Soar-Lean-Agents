# kenken-4-4: KenKen puzzle solver (4x4)

This variant is identical in every respect to variant kenken-4-1 (file kenken-4-1.md in this same folder: /home/claude/blind68/english/kenken/kenken-4-1.md) -- the same representation, actions, constraints, preferences, look-ahead search, goal and failure tests, output format and settings -- except for the grid size and the puzzle data below. Read every 'N' in kenken-4-1.md as N = 4: values are 1..4; each cell starts with 4 candidates; the goal is that the count of marked cells reaches 16; the solution is printed as 4 rows of 4 values, and the program halts with success after the 4th row is printed. Nothing else differs.

## Puzzle data for this variant

Grid size N = 4 (16 cells, values 1..4). Number of stored allowed combinations (all cages together): 37.

Cages (cells are written rRcC = row R, column C; in printed output this cell's code is the two-digit number C then R):

- Cage 1: r1c1, r1c2, r2c2, r3c2 -- sum = 9. 12 allowed combination(s).
  Allowed: (r1c1=1, r1c2=3, r2c2=1, r3c2=4); (r1c1=1, r1c2=3, r2c2=4, r3c2=1); (r1c1=1, r1c2=4, r2c2=1, r3c2=3); (r1c1=1, r1c2=4, r2c2=3, r3c2=1); (r1c1=2, r1c2=1, r2c2=2, r3c2=4); (r1c1=2, r1c2=1, r2c2=4, r3c2=2); (r1c1=2, r1c2=4, r2c2=1, r3c2=2); (r1c1=2, r1c2=4, r2c2=2, r3c2=1); (r1c1=3, r1c2=1, r2c2=2, r3c2=3); (r1c1=3, r1c2=1, r2c2=3, r3c2=2); (r1c1=3, r1c2=2, r2c2=1, r3c2=3); (r1c1=3, r1c2=2, r2c2=3, r3c2=1).
- Cage 2: r1c3, r2c3 -- difference (larger minus smaller) = 1. 6 allowed combination(s).
  Allowed: (r1c3=1, r2c3=2); (r1c3=2, r2c3=1); (r1c3=2, r2c3=3); (r1c3=3, r2c3=2); (r1c3=3, r2c3=4); (r1c3=4, r2c3=3).
- Cage 3: r1c4, r2c4 -- quotient (larger divided by smaller) = 2. 4 allowed combination(s).
  Allowed: (r1c4=1, r2c4=2); (r1c4=2, r2c4=1); (r1c4=2, r2c4=4); (r1c4=4, r2c4=2).
- Cage 4: r2c1, r3c1, r4c1 -- sum = 7. 6 allowed combination(s).
  Allowed: (r2c1=1, r3c1=2, r4c1=4); (r2c1=1, r3c1=4, r4c1=2); (r2c1=2, r3c1=1, r4c1=4); (r2c1=2, r3c1=4, r4c1=1); (r2c1=4, r3c1=1, r4c1=2); (r2c1=4, r3c1=2, r4c1=1).
- Cage 5: r3c3, r4c3 -- quotient (larger divided by smaller) = 2. 4 allowed combination(s).
  Allowed: (r3c3=1, r4c3=2); (r3c3=2, r4c3=1); (r3c3=2, r4c3=4); (r3c3=4, r4c3=2).
- Cage 6: r3c4, r4c4 -- difference (larger minus smaller) = 2. 4 allowed combination(s).
  Allowed: (r3c4=1, r4c4=3); (r3c4=2, r4c4=4); (r3c4=3, r4c4=1); (r3c4=4, r4c4=2).
- Cage 7: r4c2 -- single cell, value must be 4. One allowed combination.

The program does not store the arithmetic clue itself. For every cage it stores the explicit list of allowed value combinations, and that list is exactly: every assignment of values 1..N to the cage's cells that satisfies the clue above and gives different values to any two cells of the cage that share a row or a column (cells of the same cage that share neither may repeat a value). Each combination knows which (cell, value) candidates it uses, and each candidate knows which combinations it belongs to. Candidates that belong to no combination at all start alive and are removed by the prune action at the start.

Observed result (run with two seeds): the agent solves the puzzle and prints these rows:

```
| 3 | 1 | 4 | 2 | 
| 1 | 2 | 3 | 4 | 
| 4 | 3 | 2 | 1 | 
| 2 | 4 | 1 | 3 | 
```

Observed: solved by deduction alone (no guess cell chosen, no look-ahead).
