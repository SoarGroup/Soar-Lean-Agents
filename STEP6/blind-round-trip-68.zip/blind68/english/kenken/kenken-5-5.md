# kenken-5-5: KenKen puzzle solver (5x5)

This variant is identical in every respect to variant kenken-4-1 (file kenken-4-1.md in this same folder: /home/claude/blind68/english/kenken/kenken-4-1.md) -- the same representation, actions, constraints, preferences, look-ahead search, goal and failure tests, output format and settings -- except for the grid size and the puzzle data below. Read every 'N' in kenken-4-1.md as N = 5: values are 1..5; each cell starts with 5 candidates; the goal is that the count of marked cells reaches 25; the solution is printed as 5 rows of 5 values, and the program halts with success after the 5th row is printed. Nothing else differs.

## Puzzle data for this variant

Grid size N = 5 (25 cells, values 1..5). Number of stored allowed combinations (all cages together): 70.

Cages (cells are written rRcC = row R, column C; in printed output this cell's code is the two-digit number C then R):

- Cage 1: r1c1, r2c1, r3c1, r3c2 -- product = 180. 4 allowed combination(s).
  Allowed: (r1c1=3, r2c1=4, r3c1=5, r3c2=3); (r1c1=3, r2c1=5, r3c1=4, r3c2=3); (r1c1=4, r2c1=3, r3c1=5, r3c2=3); (r1c1=5, r2c1=3, r3c1=4, r3c2=3).
- Cage 2: r1c2, r1c3 -- difference (larger minus smaller) = 1. 8 allowed combination(s).
  Allowed: (r1c2=1, r1c3=2); (r1c2=2, r1c3=1); (r1c2=2, r1c3=3); (r1c2=3, r1c3=2); (r1c2=3, r1c3=4); (r1c2=4, r1c3=3); (r1c2=4, r1c3=5); (r1c2=5, r1c3=4).
- Cage 3: r1c4, r2c4 -- product = 5. 2 allowed combination(s).
  Allowed: (r1c4=1, r2c4=5); (r1c4=5, r2c4=1).
- Cage 4: r1c5, r2c5 -- quotient (larger divided by smaller) = 2. 4 allowed combination(s).
  Allowed: (r1c5=1, r2c5=2); (r1c5=2, r2c5=1); (r1c5=2, r2c5=4); (r1c5=4, r2c5=2).
- Cage 5: r2c2 -- single cell, value must be 4. One allowed combination.
- Cage 6: r2c3, r3c3 -- product = 5. 2 allowed combination(s).
  Allowed: (r2c3=1, r3c3=5); (r2c3=5, r3c3=1).
- Cage 7: r3c4, r4c3, r4c4 -- sum = 8. 14 allowed combination(s).
- Cage 8: r3c5, r4c5, r5c5 -- sum = 9. 12 allowed combination(s).
  Allowed: (r3c5=1, r4c5=3, r5c5=5); (r3c5=1, r4c5=5, r5c5=3); (r3c5=2, r4c5=3, r5c5=4); (r3c5=2, r4c5=4, r5c5=3); (r3c5=3, r4c5=1, r5c5=5); (r3c5=3, r4c5=2, r5c5=4); (r3c5=3, r4c5=4, r5c5=2); (r3c5=3, r4c5=5, r5c5=1); (r3c5=4, r4c5=2, r5c5=3); (r3c5=4, r4c5=3, r5c5=2); (r3c5=5, r4c5=1, r5c5=3); (r3c5=5, r4c5=3, r5c5=1).
- Cage 9: r4c1 -- single cell, value must be 1. One allowed combination.
- Cage 10: r4c2, r5c1, r5c2 -- sum = 8. 14 allowed combination(s).
- Cage 11: r5c3, r5c4 -- difference (larger minus smaller) = 1. 8 allowed combination(s).
  Allowed: (r5c3=1, r5c4=2); (r5c3=2, r5c4=1); (r5c3=2, r5c4=3); (r5c3=3, r5c4=2); (r5c3=3, r5c4=4); (r5c3=4, r5c4=3); (r5c3=4, r5c4=5); (r5c3=5, r5c4=4).

The program does not store the arithmetic clue itself. For every cage it stores the explicit list of allowed value combinations, and that list is exactly: every assignment of values 1..N to the cage's cells that satisfies the clue above and gives different values to any two cells of the cage that share a row or a column (cells of the same cage that share neither may repeat a value). Each combination knows which (cell, value) candidates it uses, and each candidate knows which combinations it belongs to. Candidates that belong to no combination at all start alive and are removed by the prune action at the start.

Observed result (run with two seeds): the agent solves the puzzle and prints these rows:

```
| 5 | 2 | 3 | 1 | 4 | 
| 3 | 4 | 1 | 5 | 2 | 
| 4 | 3 | 5 | 2 | 1 | 
| 1 | 5 | 2 | 4 | 3 | 
| 2 | 1 | 4 | 3 | 5 | 
```

Observed: solved by deduction alone (no guess cell chosen, no look-ahead).
