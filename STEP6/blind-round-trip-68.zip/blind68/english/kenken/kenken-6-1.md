# kenken-6-1: KenKen puzzle solver (6x6)

This variant is identical in every respect to variant kenken-4-1 (file kenken-4-1.md in this same folder: /home/claude/blind68/english/kenken/kenken-4-1.md) -- the same representation, actions, constraints, preferences, look-ahead search, goal and failure tests, output format and settings -- except for the grid size and the puzzle data below. Read every 'N' in kenken-4-1.md as N = 6: values are 1..6; each cell starts with 6 candidates; the goal is that the count of marked cells reaches 36; the solution is printed as 6 rows of 6 values, and the program halts with success after the 6th row is printed. Nothing else differs.

## Puzzle data for this variant

Grid size N = 6 (36 cells, values 1..6). Number of stored allowed combinations (all cages together): 139.

Cages (cells are written rRcC = row R, column C; in printed output this cell's code is the two-digit number C then R):

- Cage 1: r1c1, r2c1, r3c1 -- sum = 13. 12 allowed combination(s).
  Allowed: (r1c1=2, r2c1=5, r3c1=6); (r1c1=2, r2c1=6, r3c1=5); (r1c1=3, r2c1=4, r3c1=6); (r1c1=3, r2c1=6, r3c1=4); (r1c1=4, r2c1=3, r3c1=6); (r1c1=4, r2c1=6, r3c1=3); (r1c1=5, r2c1=2, r3c1=6); (r1c1=5, r2c1=6, r3c1=2); (r1c1=6, r2c1=2, r3c1=5); (r1c1=6, r2c1=3, r3c1=4); (r1c1=6, r2c1=4, r3c1=3); (r1c1=6, r2c1=5, r3c1=2).
- Cage 2: r1c2, r1c3 -- difference (larger minus smaller) = 3. 6 allowed combination(s).
  Allowed: (r1c2=1, r1c3=4); (r1c2=2, r1c3=5); (r1c2=3, r1c3=6); (r1c2=4, r1c3=1); (r1c2=5, r1c3=2); (r1c2=6, r1c3=3).
- Cage 3: r1c4, r2c4 -- sum = 6. 4 allowed combination(s).
  Allowed: (r1c4=1, r2c4=5); (r1c4=2, r2c4=4); (r1c4=4, r2c4=2); (r1c4=5, r2c4=1).
- Cage 4: r1c5, r1c6 -- quotient (larger divided by smaller) = 3. 4 allowed combination(s).
  Allowed: (r1c5=1, r1c6=3); (r1c5=2, r1c6=6); (r1c5=3, r1c6=1); (r1c5=6, r1c6=2).
- Cage 5: r2c2, r2c3 -- quotient (larger divided by smaller) = 2. 6 allowed combination(s).
  Allowed: (r2c2=1, r2c3=2); (r2c2=2, r2c3=1); (r2c2=2, r2c3=4); (r2c2=3, r2c3=6); (r2c2=4, r2c3=2); (r2c2=6, r2c3=3).
- Cage 6: r2c5, r2c6, r3c5 -- product = 30. 12 allowed combination(s).
  Allowed: (r2c5=1, r2c6=5, r3c5=6); (r2c5=1, r2c6=6, r3c5=5); (r2c5=2, r2c6=3, r3c5=5); (r2c5=2, r2c6=5, r3c5=3); (r2c5=3, r2c6=2, r3c5=5); (r2c5=3, r2c6=5, r3c5=2); (r2c5=5, r2c6=1, r3c5=6); (r2c5=5, r2c6=2, r3c5=3); (r2c5=5, r2c6=3, r3c5=2); (r2c5=5, r2c6=6, r3c5=1); (r2c5=6, r2c6=1, r3c5=5); (r2c5=6, r2c6=5, r3c5=1).
- Cage 7: r3c2, r3c3 -- quotient (larger divided by smaller) = 2. 6 allowed combination(s).
  Allowed: (r3c2=1, r3c3=2); (r3c2=2, r3c3=1); (r3c2=2, r3c3=4); (r3c2=3, r3c3=6); (r3c2=4, r3c3=2); (r3c2=6, r3c3=3).
- Cage 8: r3c4, r4c4 -- sum = 10. 2 allowed combination(s).
  Allowed: (r3c4=4, r4c4=6); (r3c4=6, r4c4=4).
- Cage 9: r3c6, r4c6, r5c6 -- product = 15. 6 allowed combination(s).
  Allowed: (r3c6=1, r4c6=3, r5c6=5); (r3c6=1, r4c6=5, r5c6=3); (r3c6=3, r4c6=1, r5c6=5); (r3c6=3, r4c6=5, r5c6=1); (r3c6=5, r4c6=1, r5c6=3); (r3c6=5, r4c6=3, r5c6=1).
- Cage 10: r4c1, r5c1 -- difference (larger minus smaller) = 1. 10 allowed combination(s).
  Allowed: (r4c1=1, r5c1=2); (r4c1=2, r5c1=1); (r4c1=2, r5c1=3); (r4c1=3, r5c1=2); (r4c1=3, r5c1=4); (r4c1=4, r5c1=3); (r4c1=4, r5c1=5); (r4c1=5, r5c1=4); (r4c1=5, r5c1=6); (r4c1=6, r5c1=5).
- Cage 11: r4c2, r4c3, r5c2 -- product = 60. 12 allowed combination(s).
  Allowed: (r4c2=2, r4c3=5, r5c2=6); (r4c2=2, r4c3=6, r5c2=5); (r4c2=3, r4c3=4, r5c2=5); (r4c2=3, r4c3=5, r5c2=4); (r4c2=4, r4c3=3, r5c2=5); (r4c2=4, r4c3=5, r5c2=3); (r4c2=5, r4c3=2, r5c2=6); (r4c2=5, r4c3=3, r5c2=4); (r4c2=5, r4c3=4, r5c2=3); (r4c2=5, r4c3=6, r5c2=2); (r4c2=6, r4c3=2, r5c2=5); (r4c2=6, r4c3=5, r5c2=2).
- Cage 12: r4c5 -- single cell, value must be 4. One allowed combination.
- Cage 13: r5c3, r5c4, r6c3 -- sum = 9. 20 allowed combination(s).
- Cage 14: r5c5, r6c4, r6c5, r6c6 -- product = 72. 36 allowed combination(s).
- Cage 15: r6c1, r6c2 -- sum = 11. 2 allowed combination(s).
  Allowed: (r6c1=5, r6c2=6); (r6c1=6, r6c2=5).

The program does not store the arithmetic clue itself. For every cage it stores the explicit list of allowed value combinations, and that list is exactly: every assignment of values 1..N to the cage's cells that satisfies the clue above and gives different values to any two cells of the cage that share a row or a column (cells of the same cage that share neither may repeat a value). Each combination knows which (cell, value) candidates it uses, and each candidate knows which combinations it belongs to. Candidates that belong to no combination at all start alive and are removed by the prune action at the start.

Observed result (run with two seeds): the agent solves the puzzle and prints these rows:

```
| 3 | 1 | 4 | 5 | 2 | 6 | 
| 4 | 3 | 6 | 1 | 5 | 2 | 
| 6 | 2 | 1 | 4 | 3 | 5 | 
| 2 | 5 | 3 | 6 | 4 | 1 | 
| 1 | 4 | 5 | 2 | 6 | 3 | 
| 5 | 6 | 2 | 3 | 1 | 4 | 
```

Observed: pure deduction is not enough; the agent chose guess cell(s) ['63'] (codes, varied with the seed) and resolved them with look-ahead.
