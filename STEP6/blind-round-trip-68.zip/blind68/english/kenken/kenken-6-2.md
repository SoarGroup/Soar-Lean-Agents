# kenken-6-2: KenKen puzzle solver (6x6)

This variant is identical in every respect to variant kenken-4-1 (file kenken-4-1.md in this same folder: /home/claude/blind68/english/kenken/kenken-4-1.md) -- the same representation, actions, constraints, preferences, look-ahead search, goal and failure tests, output format and settings -- except for the grid size and the puzzle data below. Read every 'N' in kenken-4-1.md as N = 6: values are 1..6; each cell starts with 6 candidates; the goal is that the count of marked cells reaches 36; the solution is printed as 6 rows of 6 values, and the program halts with success after the 6th row is printed. Nothing else differs.

## Puzzle data for this variant

Grid size N = 6 (36 cells, values 1..6). Number of stored allowed combinations (all cages together): 168.

Cages (cells are written rRcC = row R, column C; in printed output this cell's code is the two-digit number C then R):

- Cage 1: r1c1, r2c1, r3c1 -- product = 20. 6 allowed combination(s).
  Allowed: (r1c1=1, r2c1=4, r3c1=5); (r1c1=1, r2c1=5, r3c1=4); (r1c1=4, r2c1=1, r3c1=5); (r1c1=4, r2c1=5, r3c1=1); (r1c1=5, r2c1=1, r3c1=4); (r1c1=5, r2c1=4, r3c1=1).
- Cage 2: r1c2, r2c2, r2c3, r3c3 -- product = 96. 18 allowed combination(s).
- Cage 3: r1c3, r1c4 -- sum = 7. 6 allowed combination(s).
  Allowed: (r1c3=1, r1c4=6); (r1c3=2, r1c4=5); (r1c3=3, r1c4=4); (r1c3=4, r1c4=3); (r1c3=5, r1c4=2); (r1c3=6, r1c4=1).
- Cage 4: r1c5, r1c6 -- difference (larger minus smaller) = 3. 6 allowed combination(s).
  Allowed: (r1c5=1, r1c6=4); (r1c5=2, r1c6=5); (r1c5=3, r1c6=6); (r1c5=4, r1c6=1); (r1c5=5, r1c6=2); (r1c5=6, r1c6=3).
- Cage 5: r2c4, r2c5 -- quotient (larger divided by smaller) = 2. 6 allowed combination(s).
  Allowed: (r2c4=1, r2c5=2); (r2c4=2, r2c5=1); (r2c4=2, r2c5=4); (r2c4=3, r2c5=6); (r2c4=4, r2c5=2); (r2c4=6, r2c5=3).
- Cage 6: r2c6, r3c6 -- difference (larger minus smaller) = 1. 10 allowed combination(s).
  Allowed: (r2c6=1, r3c6=2); (r2c6=2, r3c6=1); (r2c6=2, r3c6=3); (r2c6=3, r3c6=2); (r2c6=3, r3c6=4); (r2c6=4, r3c6=3); (r2c6=4, r3c6=5); (r2c6=5, r3c6=4); (r2c6=5, r3c6=6); (r2c6=6, r3c6=5).
- Cage 7: r3c2, r4c2 -- difference (larger minus smaller) = 5. 2 allowed combination(s).
  Allowed: (r3c2=1, r4c2=6); (r3c2=6, r4c2=1).
- Cage 8: r3c4, r3c5, r4c5 -- sum = 12. 20 allowed combination(s).
- Cage 9: r4c1 -- single cell, value must be 6. One allowed combination.
- Cage 10: r4c3, r5c3 -- difference (larger minus smaller) = 4. 4 allowed combination(s).
  Allowed: (r4c3=1, r5c3=5); (r4c3=2, r5c3=6); (r4c3=5, r5c3=1); (r4c3=6, r5c3=2).
- Cage 11: r4c4, r5c4 -- difference (larger minus smaller) = 3. 6 allowed combination(s).
  Allowed: (r4c4=1, r5c4=4); (r4c4=2, r5c4=5); (r4c4=3, r5c4=6); (r4c4=4, r5c4=1); (r4c4=5, r5c4=2); (r4c4=6, r5c4=3).
- Cage 12: r4c6, r5c5, r5c6 -- sum = 13. 15 allowed combination(s).
- Cage 13: r5c1, r5c2, r6c1, r6c2 -- product = 60. 52 allowed combination(s).
- Cage 14: r6c3, r6c4 -- difference (larger minus smaller) = 1. 10 allowed combination(s).
  Allowed: (r6c3=1, r6c4=2); (r6c3=2, r6c4=1); (r6c3=2, r6c4=3); (r6c3=3, r6c4=2); (r6c3=3, r6c4=4); (r6c3=4, r6c4=3); (r6c3=4, r6c4=5); (r6c3=5, r6c4=4); (r6c3=5, r6c4=6); (r6c3=6, r6c4=5).
- Cage 15: r6c5, r6c6 -- sum = 7. 6 allowed combination(s).
  Allowed: (r6c5=1, r6c6=6); (r6c5=2, r6c6=5); (r6c5=3, r6c6=4); (r6c5=4, r6c6=3); (r6c5=5, r6c6=2); (r6c5=6, r6c6=1).

The program does not store the arithmetic clue itself. For every cage it stores the explicit list of allowed value combinations, and that list is exactly: every assignment of values 1..N to the cage's cells that satisfies the clue above and gives different values to any two cells of the cage that share a row or a column (cells of the same cage that share neither may repeat a value). Each combination knows which (cell, value) candidates it uses, and each candidate knows which combinations it belongs to. Candidates that belong to no combination at all start alive and are removed by the prune action at the start.

Observed result (run with two seeds): the agent solves the puzzle and prints these rows:

```
| 4 | 3 | 6 | 1 | 2 | 5 | 
| 5 | 4 | 2 | 6 | 3 | 1 | 
| 1 | 6 | 4 | 3 | 5 | 2 | 
| 6 | 1 | 5 | 2 | 4 | 3 | 
| 3 | 2 | 1 | 5 | 6 | 4 | 
| 2 | 5 | 3 | 4 | 1 | 6 | 
```

Observed: pure deduction is not enough; the agent chose guess cell(s) ['34', '35', '43', '44', '45', '54', '64'] (codes, varied with the seed) and resolved them with look-ahead.
