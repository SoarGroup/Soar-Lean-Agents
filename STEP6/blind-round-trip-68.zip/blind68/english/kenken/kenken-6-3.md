# kenken-6-3: KenKen puzzle solver (6x6)

This variant is identical in every respect to variant kenken-4-1 (file kenken-4-1.md in this same folder: /home/claude/blind68/english/kenken/kenken-4-1.md) -- the same representation, actions, constraints, preferences, look-ahead search, goal and failure tests, output format and settings -- except for the grid size and the puzzle data below. Read every 'N' in kenken-4-1.md as N = 6: values are 1..6; each cell starts with 6 candidates; the goal is that the count of marked cells reaches 36; the solution is printed as 6 rows of 6 values, and the program halts with success after the 6th row is printed. Nothing else differs.

## Puzzle data for this variant

Grid size N = 6 (36 cells, values 1..6). Number of stored allowed combinations (all cages together): 158.

Cages (cells are written rRcC = row R, column C; in printed output this cell's code is the two-digit number C then R):

- Cage 1: r1c1, r1c2, r2c1 -- product = 12. 13 allowed combination(s).
- Cage 2: r1c3, r1c4, r2c3 -- sum = 9. 20 allowed combination(s).
- Cage 3: r1c5, r1c6, r2c4, r2c5 -- product = 150. 12 allowed combination(s).
  Allowed: (r1c5=1, r1c6=5, r2c4=5, r2c5=6); (r1c5=1, r1c6=5, r2c4=6, r2c5=5); (r1c5=2, r1c6=5, r2c4=3, r2c5=5); (r1c5=2, r1c6=5, r2c4=5, r2c5=3); (r1c5=3, r1c6=5, r2c4=2, r2c5=5); (r1c5=3, r1c6=5, r2c4=5, r2c5=2); (r1c5=5, r1c6=1, r2c4=5, r2c5=6); (r1c5=5, r1c6=2, r2c4=5, r2c5=3); (r1c5=5, r1c6=3, r2c4=5, r2c5=2); (r1c5=5, r1c6=6, r2c4=5, r2c5=1); (r1c5=6, r1c6=5, r2c4=1, r2c5=5); (r1c5=6, r1c6=5, r2c4=5, r2c5=1).
- Cage 4: r2c2, r3c2 -- quotient (larger divided by smaller) = 2. 6 allowed combination(s).
  Allowed: (r2c2=1, r3c2=2); (r2c2=2, r3c2=1); (r2c2=2, r3c2=4); (r2c2=3, r3c2=6); (r2c2=4, r3c2=2); (r2c2=6, r3c2=3).
- Cage 5: r2c6, r3c6 -- quotient (larger divided by smaller) = 2. 6 allowed combination(s).
  Allowed: (r2c6=1, r3c6=2); (r2c6=2, r3c6=1); (r2c6=2, r3c6=4); (r2c6=3, r3c6=6); (r2c6=4, r3c6=2); (r2c6=6, r3c6=3).
- Cage 6: r3c1, r4c1 -- difference (larger minus smaller) = 2. 8 allowed combination(s).
  Allowed: (r3c1=1, r4c1=3); (r3c1=2, r4c1=4); (r3c1=3, r4c1=1); (r3c1=3, r4c1=5); (r3c1=4, r4c1=2); (r3c1=4, r4c1=6); (r3c1=5, r4c1=3); (r3c1=6, r4c1=4).
- Cage 7: r3c3, r4c3 -- difference (larger minus smaller) = 5. 2 allowed combination(s).
  Allowed: (r3c3=1, r4c3=6); (r3c3=6, r4c3=1).
- Cage 8: r3c4, r3c5 -- difference (larger minus smaller) = 1. 10 allowed combination(s).
  Allowed: (r3c4=1, r3c5=2); (r3c4=2, r3c5=1); (r3c4=2, r3c5=3); (r3c4=3, r3c5=2); (r3c4=3, r3c5=4); (r3c4=4, r3c5=3); (r3c4=4, r3c5=5); (r3c4=5, r3c5=4); (r3c4=5, r3c5=6); (r3c4=6, r3c5=5).
- Cage 9: r4c2 -- single cell, value must be 5. One allowed combination.
- Cage 10: r4c4, r4c5, r4c6 -- sum = 7. 6 allowed combination(s).
  Allowed: (r4c4=1, r4c5=2, r4c6=4); (r4c4=1, r4c5=4, r4c6=2); (r4c4=2, r4c5=1, r4c6=4); (r4c4=2, r4c5=4, r4c6=1); (r4c4=4, r4c5=1, r4c6=2); (r4c4=4, r4c5=2, r4c6=1).
- Cage 11: r5c1, r6c1 -- difference (larger minus smaller) = 3. 6 allowed combination(s).
  Allowed: (r5c1=1, r6c1=4); (r5c1=2, r6c1=5); (r5c1=3, r6c1=6); (r5c1=4, r6c1=1); (r5c1=5, r6c1=2); (r5c1=6, r6c1=3).
- Cage 12: r5c2, r6c2 -- quotient (larger divided by smaller) = 2. 6 allowed combination(s).
  Allowed: (r5c2=1, r6c2=2); (r5c2=2, r6c2=1); (r5c2=2, r6c2=4); (r5c2=3, r6c2=6); (r5c2=4, r6c2=2); (r5c2=6, r6c2=3).
- Cage 13: r5c3, r6c3 -- difference (larger minus smaller) = 1. 10 allowed combination(s).
  Allowed: (r5c3=1, r6c3=2); (r5c3=2, r6c3=1); (r5c3=2, r6c3=3); (r5c3=3, r6c3=2); (r5c3=3, r6c3=4); (r5c3=4, r6c3=3); (r5c3=4, r6c3=5); (r5c3=5, r6c3=4); (r5c3=5, r6c3=6); (r5c3=6, r6c3=5).
- Cage 14: r5c4, r5c5, r5c6, r6c6 -- sum = 11. 48 allowed combination(s).
- Cage 15: r6c4, r6c5 -- quotient (larger divided by smaller) = 3. 4 allowed combination(s).
  Allowed: (r6c4=1, r6c5=3); (r6c4=2, r6c5=6); (r6c4=3, r6c5=1); (r6c4=6, r6c5=2).

The program does not store the arithmetic clue itself. For every cage it stores the explicit list of allowed value combinations, and that list is exactly: every assignment of values 1..N to the cage's cells that satisfies the clue above and gives different values to any two cells of the cage that share a row or a column (cells of the same cage that share neither may repeat a value). Each combination knows which (cell, value) candidates it uses, and each candidate knows which combinations it belongs to. Candidates that belong to no combination at all start alive and are removed by the prune action at the start.

Observed result (run with two seeds): the agent solves the puzzle and prints these rows:

```
| 2 | 1 | 3 | 4 | 6 | 5 | 
| 6 | 4 | 2 | 1 | 5 | 3 | 
| 5 | 2 | 1 | 3 | 4 | 6 | 
| 3 | 5 | 6 | 2 | 1 | 4 | 
| 1 | 6 | 4 | 5 | 3 | 2 | 
| 4 | 3 | 5 | 6 | 2 | 1 | 
```

Observed: pure deduction is not enough; the agent chose guess cell(s) ['15'] (codes, varied with the seed) and resolved them with look-ahead.
