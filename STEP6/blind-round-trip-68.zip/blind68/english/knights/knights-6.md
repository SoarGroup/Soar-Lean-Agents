# knights-6

## 1. Task
Find (count) closed knight's tours on a 6x6 board by depth-first search with backtracking,
starting from a fixed square, until the search space is exhausted or a move budget runs out.

Squares: 36 squares, identified by a two-digit coordinate rc (r = 1..6, c = 1..6; e.g. 11, 23,
66; names b11..b66). Each square knows its knight-move neighbours (the standard up to 8 squares
reachable by a knight's (1,2)/(2,1) jump that stay on the board). Each square also has:
- used flag (1 = currently on the path);
- degree: a dynamic count, initially the number of knight neighbours of the square (2, 3, 4, 6 or
  8). It is decreased by 1 for every neighbour of a square the knight jumps INTO and increased
  by 1 for every neighbour of a square the knight backs out of. (The start square is never
  "jumped into", so its neighbours' degrees are never decreased for it; degree = number of
  neighbours that are free or the start square.)
- original degree: the initial neighbour count (fixed; not used by this variant);
- visit stamp: the stamp of the most recent time the knight entered the square (0 initially);
- previous square: the square the knight came from on the current path (initially itself);
- a set of "tried" marks, each a visit stamp. A mark s on square y means "y has already been
  tried (and failed) as the next square from the square whose current visit stamp is s".

Tour record: current square, first (start) square, depth (number of squares on the path),
total moves (jumps plus backups), frame (a counter used to issue unique visit stamps),
solutions found, a goal flag (1 right after a tour is recorded) and a done flag.

Initial state: start square 23 (row 2, column 3); it is used = 1, visit stamp 1, previous =
itself. All other squares used 0, visit 0, no tried marks. Degrees all at their initial
neighbour counts (none reduced for the start). Tour: at 23, first 23, depth 1, moves 0,
frame 1, solutions 0, goal 0, done 0. Desired: done = 1.
Initialisation is one step when the top state has no name (task name "knights").

## 2. Actions
- **Jump** from current square c to neighbour y: allowed when not done, y is unused, and y
  has no tried mark equal to c's visit stamp. Effects: current := y; y used := 1; y previous := c;
  frame += 1 and y's visit stamp := the new frame; depth += 1; moves += 1; every knight
  neighbour of y has its degree decreased by 1.
- **Back up** from current square c to its previous square p (only when p is not c, i.e. never
  from the start square): allowed when not done and ANY of:
  1. c has no remaining candidate jump (no unused neighbour lacking a tried mark equal to c's
     visit stamp);
  2. the goal flag is 1 (a tour was just recorded at c);
  3. depth < 36 and c has two different unused neighbours whose degree is 1;
  4. c has a neighbour with degree 1 that carries a tried mark equal to c's visit stamp.
  Effects: current := p; c used := 0; c gets a tried mark equal to p's visit stamp; depth -= 1;
  moves += 1; goal := 0; and for every neighbour z of c: z's degree += 1 and any tried mark on z
  equal to c's visit stamp is removed. (c's own visit stamp and previous square are left as is.)
- **Record tour**: allowed when not done, goal flag 0, depth = 36 and the current square is a
  knight neighbour of the start square (closed tour). Effects: solutions += 1; goal := 1;
  prints `Success! <solutions> <coordinate of current square>` (no newline).
- **Exhausted**: allowed when not done, the current square is the start square and it has no
  remaining candidate jump (as in backup condition 1). Effect: done := 1; prints
  `Search complete: <solutions> solutions`.
- **Finish run**: allowed when not done and total moves >= 1,000,000. Effect: done := 1; prints
  `Run over: <solutions> solutions`.

## 3. Goal and termination
Goal: done = 1 (search exhausted or move budget reached). Then print newline,
`The problem has been solved.` and halt. Individual tours are reported but do not stop the
search; after each one the agent backs up and continues.

## 4. Choice among actions
Preferences:
- Finish run is better than any jump, backup or record-tour.
- Record tour is better than any jump or backup.
- Any backup is better than any jump (so the pruning conditions 2-4 override jumping).
- Between two jumps: the one to the square with the smaller current degree is better
  (Warnsdorff heuristic, dynamic degree).
- A jump to a square whose current degree is 1 (and which is not square 23) gets a "best"
  preference.
- Everything else is indifferent (random tie-breaking, e.g. among equal-degree jumps, among
  duplicate backup proposals which all have the same effect, or between exhausted and finish run).
No look-ahead evaluation, no learning (chunking off), no RL, no substates, no memories.

## 5. Output and settings
A stream of `Success! <n> <coord>` messages without separators (e.g.
`Success! 1 31Success! 2 44...`), then `Search complete: N solutions` or (in practice)
`Run over: N solutions` when the move budget of 1,000,000 is reached, then a newline and
`The problem has been solved.` About 2,800 tours are found in the first 200,000 decision cycles; with one seed the full run
hit the budget and ended with `Run over: 11988 solutions` (the search is not exhausted).
Note: the "not square 23" exception on the degree-1 preference has no effect, since square 23 is
the start and is always used.
