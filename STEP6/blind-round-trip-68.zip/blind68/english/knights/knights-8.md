# knights-8

As variant `knights-6` (file `english/knights/knights-6.md`), except for the board size and the
move-ordering knowledge. Full description below.

## 1. Task
Find (count) closed knight's tours on an 8x8 board by depth-first search with backtracking from
a fixed start square, until the search is exhausted or a move budget runs out.

Squares: 64 squares with two-digit coordinates rc (r, c = 1..8; names b11..b88). Each knows its
knight-move neighbours (standard knight jumps that stay on the board). Each square has:
- used flag (1 = on the current path);
- degree: dynamic count, initially the number of knight neighbours (2, 3, 4, 6 or 8); decreased by
  1 for every neighbour of a square the knight jumps INTO, increased by 1 for every neighbour of a
  square the knight backs out of (the start square is never jumped into, so it never reduces its
  neighbours' degrees);
- original degree: the initial neighbour count, fixed (used for move ordering in this variant);
- visit stamp (most recent entry stamp, 0 initially); previous square (initially itself);
- a set of "tried" marks (visit stamps): a mark s on y means y has already been tried and failed
  as the next square from the square whose current visit stamp is s.
Tour record: current square, start square, depth, total moves, frame (stamp counter), solutions,
goal flag, done flag.

Initial state: start square 23 (row 2, column 3): used 1, visit stamp 1, previous itself. All
others: used 0, visit 0, no marks; all degrees at their initial counts. Tour: at 23, first 23,
depth 1, moves 0, frame 1, solutions 0, goal 0, done 0. Desired: done = 1.
Initialisation in one step when the top state has no name (task name "knights").

## 2. Actions
- **Jump** from current c to neighbour y: when not done, y unused and y has no tried mark equal to
  c's visit stamp. Effects: current := y; y used 1; y previous := c; frame += 1, y visit stamp :=
  new frame; depth += 1; moves += 1; each knight neighbour of y: degree -= 1.
- **Back up** from c to its previous square p (p must differ from c, so never from the start):
  when not done and ANY of:
  1. c has no remaining candidate jump;
  2. the goal flag is 1;
  3. depth < 64 and c has two different unused neighbours whose (dynamic) degree is 1.
  (There is no fourth condition in this variant.)
  Effects: current := p; c used 0; c gets a tried mark equal to p's visit stamp; depth -= 1;
  moves += 1; goal := 0; each neighbour z of c: degree += 1 and z's tried mark equal to c's visit
  stamp is removed.
- **Record tour**: when not done, goal 0, depth = 64 and current square is a knight neighbour of
  the start. Effects: solutions += 1; goal := 1; prints `Success! <solutions> <coord>`
  (no newline).
- **Exhausted**: when not done, at the start square with no remaining candidate jump. Effect:
  done := 1; prints `Search complete: <solutions> solutions`.
- **Finish run**: when not done and total moves >= 1,000,000. Effect: done := 1; prints
  `Run over: <solutions> solutions`.

## 3. Goal and termination
Goal: done = 1. Then print newline, `The problem has been solved.` and halt. Tours found along
the way are reported and the search continues by backing up.

## 4. Choice among actions
- Finish run better than any jump, backup, record-tour.
- Record tour better than any jump or backup.
- Any backup better than any jump.
- Between two jumps: the one to the square with the smaller ORIGINAL (static) degree is better.
- No "best" preference for degree-1 squares (unlike knights-6).
- All else indifferent (random tie-breaking).
No look-ahead evaluation, no learning (chunking off), no RL, no substates, no memories.

## 5. Output and settings
`Success! <n> <coord>` messages run together, then `Run over: N solutions` (move budget
1,000,000) or `Search complete: N solutions`, then newline and `The problem has been solved.`
The number of tours found depends on the random tie-breaking (e.g. ~366 in the first 200,000
decisions with one seed, none with another); with one seed the full run ended with
`Run over: 1408 solutions`.
