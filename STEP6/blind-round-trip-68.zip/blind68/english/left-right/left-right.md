# left-right

## 1. Task
A one-step reinforcement-learning task. An agent stands at a location on a line. Initial state:
- agent location = 0
- agent "moved" flag = 0

Initialisation: when the agent starts and the top state has no name, one step names the task
"left-right", creates the agent with the values above, and records the desired state:
moved flag = 1.

## 2. Actions
- **Move** in a direction, with two instances: direction -1 (left) and direction +1 (right).
  Both are allowed only while the agent's location is 0. Effects: location := the direction
  value (-1 or 1), moved := 1 (old values replaced), and prints `Moved: <direction>`
  (i.e. `Moved: -1` or `Moved: 1`).

## 3. Goal and termination
Goal: moved flag = 1 (so the episode ends after exactly one move, whichever direction). When
reached, prints a newline then `The problem has been solved.` and halts. There is no explicit
failure state; moving left is simply the poorly rewarded outcome.

## 4. Choice among actions
- Both move instances are proposed as indifferent; the choice between them is made by
  reinforcement learning.
- Reinforcement learning is on. Each move instance has a learned numeric preference (Q-value),
  initial value 0, keyed on the move's direction together with the agent's current location and
  moved flag (in practice only location 0 / moved 0 ever occurs, so there are effectively two
  values: one for left, one for right).
- Reward: while the agent's location is -1 a reward of -1 is given; while its location is +1 a
  reward of +1 is given. No other rewards.
- Learning rate 0.3, discount rate 0.9. Exploration policy: epsilon-greedy with the
  architecture's default epsilon (0.1). Default RL update rule (SARSA) otherwise.
- No look-ahead search, no chunking (off), no substates, no semantic/episodic memory.
- Over repeated episodes (the environment re-initialises the agent and keeps learned values),
  the agent comes to prefer moving right. After one left move the left value becomes -0.3;
  after one right move the right value becomes +0.3.

## 5. Output and settings
Per episode output: `Moved: 1` or `Moved: -1`, then `The problem has been solved.`
Settings: chunking off; RL on, learning rate 0.3, discount 0.9, epsilon-greedy selection.
