# Missionaries and Cannibals: one-step look-ahead with numeric evaluation (variant "mac-look-ahead-numeric")

As variant "mac-look-ahead" (file: english/missionaries-cannibals/mac-look-ahead.md), except that
look-ahead states also get a numeric score and higher scores are better. Everything else - task,
initial state, moves (proposed without indifference, so ties trigger look-ahead), success and
failure tests, the repeated-state failure inside look-ahead, the look-ahead copying, the
conversion of symbolic evaluations to preferences, chunking, and the printed messages - is as in
"mac-look-ahead". Summary:

## 1. Task
Banks "left" and "right" with missionary count, cannibal count, boat flag, name, link to the
other bank. Start: left 3/3/boat 1, right 0/0/boat 0. Desired: right bank 3 missionaries and 3
cannibals. The desired state also states that higher numeric evaluations are better.

## 2. Actions
"Move boat" with load in {(0,1), (0,2), (1,0), (1,1), (2,0)} from the boat's bank when it holds at
least that many of each; moves load and boat to the other bank. Moves are not indifferent, so
several available moves cause a tie resolved by look-ahead.

## 3. Goal and failure
- Success (right bank 3 and 3): at top level print new line + "The problem has been solved." and
  halt.
- Failure (any bank with missionaries > 0 and < cannibals): at top level print new line +
  "Failure state: the task has failed." and halt.
- Inside look-ahead only: a state whose two banks equal those of the top task state or any
  look-ahead task state above it in the current stack is a failure.

## 4. How the agent chooses
Ties among moves are resolved by evaluating each tied move in a look-ahead copy, as in
"mac-look-ahead". The difference: every look-ahead state, once its tried move has been applied,
receives a numeric score:

  score = (missionaries on the right bank) + (cannibals on the right bank)

Because a score is always available immediately, each evaluation finishes after applying just the
one move (a one-step look-ahead; no deeper search happens). Evaluations become preferences:
- success -> best; failure (unsafe or repeated state) -> reject (these override the score);
- between two evaluated moves with numeric scores, the higher score is better than the lower;
- equal scores -> indifferent (random choice among them).
Chunking (always on, including over selection knowledge) turns these evaluations into rules, so
repeated situations are decided without a tie.

No RL, no semantic/episodic memory, no top-level history.

Observed: solves the problem in every tested seed (about 125-135 decisions in the first run; much
fewer in later runs because of learned rules), printing "The problem has been solved." and
halting.

## 5. Output and settings
Only the two messages above. Chunking always on (including over operator-selection knowledge).
