# Missionaries and Cannibals: look-ahead search with chunking (variant "mac-look-ahead")

## 1. Task
Three missionaries, three cannibals and one boat are on the left bank of a river; everyone must
reach the right bank.

The state holds two banks, "left" and "right". Each bank records its missionary count, cannibal
count, boat flag (1 if the boat is there, else 0), its name, and a link to the other bank.

Initial state (created by an initialization operator, selected first when the top state has no
name yet; it also names the task):
- left: 3 missionaries, 3 cannibals, boat 1
- right: 0 missionaries, 0 cannibals, boat 0
Desired: the right bank holds 3 missionaries and 3 cannibals.

## 2. Actions
"Move boat" with a load (missionaries, cannibals) in {(0,1), (0,2), (1,0), (1,1), (2,0)}. A load is
proposed from the bank that has the boat when that bank holds at least that many missionaries and
at least that many cannibals. No safety filter at proposal time.
Effect: subtract the load from the departure bank, add it to the other bank; departure boat flag
becomes 0, arrival boat flag becomes 1.

Unlike variant "mac", the moves are proposed WITHOUT any indifference between them, so whenever
two or more moves are available the agent cannot choose and falls into a tie, which it resolves by
look-ahead search (section 4).

## 3. Goal and failure
- Success: a bank named "right" has 3 missionaries and 3 cannibals. At the top level: print a new
  line, then "The problem has been solved.", and halt.
- Failure: on either bank, missionaries > 0 and missionaries < cannibals. At the top level: print a
  new line, then "Failure state: the task has failed.", and halt.
- Additional failure used only inside look-ahead (see below): a look-ahead state, after its tried
  move has been applied, whose two banks are identical (same name, missionaries, cannibals and boat
  flag for both banks) to the two banks of any enclosing task state above it - the top task state
  or any look-ahead task state higher up in the current search stack. Such a repeated state is
  marked as failure.
Success and failure inside look-ahead states are not printed and do not halt; they only become
evaluations.

## 4. How the agent chooses: look-ahead search (the standard "selection" evaluation scheme)
When several moves tie, the agent enters a selection subgoal and evaluates each tied move in turn
(the order in which tied moves are evaluated is random/indifferent). To evaluate a move it:
1. Builds a look-ahead copy of the task state: both banks are copied as new objects with all their
   values (missionaries, cannibals, boat, name, and the other-bank link pointing to the copy of the
   other bank). The record of enclosing states is not copied. The desired state is shared. The
   move being evaluated is copied so it refers to the copied banks.
2. Applies that move (and only that move) to the copy.
3. Evaluates the resulting state:
   - success (goal reached) -> the move gets "success";
   - failure (unsafe bank, or a repeat of an enclosing state as described above) -> "failure";
   - otherwise there is no direct evaluation, so the agent continues in the copy: it proposes the
     moves available there; if one move is available it is applied; if several tie, a new nested
     selection subgoal evaluates them recursively in the same way (depth is unbounded).
   - If in a look-ahead state no move is available, or every move there is rejected, the
     evaluated move gets "exhaustion failure".
4. Converts evaluations into preferences for the tied moves:
   - success -> best (choose it);
   - failure or exhaustion failure -> reject;
   - two moves with the same symbolic evaluation -> indifferent;
   - a move whose nested search found success gets "partial success" passed up to the move being
     evaluated one level higher; partial success also becomes a best preference, and full success
     is preferred over partial success.
   (No numeric evaluations exist in this variant.)
Once the preferences decide, the tie resolves and the chosen move is applied to the real state.

Learning: chunking is on for every subgoal (including over operator-selection knowledge). The
evaluations found in look-ahead become rules that give the preferences (best/reject/indifferent)
directly in similar situations later, so later decisions need no search.

No reinforcement learning, no semantic or episodic memory, no numeric heuristic, and no record of
states visited at the top level (repeat detection works only within the current look-ahead stack).

Note: in practice this agent usually does NOT solve the problem. The learned rules carry
"success"/"partial success" conclusions that ignore the history check, and the top-level agent
falls into an endless loop, e.g. reaching left 1 missionary 1 cannibal / right 2 and 2, then
moving two missionaries back and forth forever; it never halts. In 8 tested seeds it solved the
task once (seed-dependent) and looped endlessly in the others. Describe/reproduce the mechanism
above; this looping is the actual behaviour.

## 5. Output and settings
Only the two messages above (printed at the top level only). Chunking always on, including
learning over operator-selection knowledge.
