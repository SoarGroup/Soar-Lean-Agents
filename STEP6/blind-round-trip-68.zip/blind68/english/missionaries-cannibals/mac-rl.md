# Missionaries and Cannibals: reinforcement learning (variant "mac-rl")

As variant "mac" (file: english/missionaries-cannibals/mac.md), except for section 4 (how the agent
chooses). The task, initial state, the five move types and their conditions and effects, the
success test, the failure test, the printed messages, and halting on success or failure are
exactly as in "mac". For completeness:

## 1. Task
Two banks, "left" and "right", each with a missionary count, a cannibal count, a boat flag (1/0),
a name, and a link to the other bank. Start: left 3 missionaries, 3 cannibals, boat 1; right 0, 0,
boat 0. Desired: right bank with 3 missionaries and 3 cannibals. An initialization operator sets
this up first.

## 2. Actions
"Move boat" with a load (missionaries, cannibals) in {(0,1), (0,2), (1,0), (1,1), (2,0)}, proposed
from the bank holding the boat when that bank has at least that many of each. Effect: move the
load to the other bank and move the boat (departure boat 0, arrival boat 1). No safety filter.

## 3. Goal and failure
- Success: the right bank has 3 missionaries and 3 cannibals: print new line +
  "The problem has been solved." and halt.
- Failure: any bank with missionaries > 0 and missionaries < cannibals: print new line +
  "Failure state: the task has failed." and halt.

## 4. How the agent chooses
Moves are proposed as indifferent, and reinforcement learning supplies a numeric value for each
proposed move.
- Value function: one learned value per distinct combination of
  (load missionaries, load cannibals,
   departure bank name, its missionaries, its cannibals, its boat flag,
   arrival bank name, its missionaries, its cannibals, its boat flag),
  i.e. a table keyed on the move and the full current state. Each entry is created on first
  encounter with initial value 0.
- Rewards (on the task state):
  - -0.01 on every decision (a constant step cost that is always present);
  - additionally +1 while the state is a success state;
  - additionally -1 while the state is a failure state.
- Learning: on; learning rate 0.1; discount rate 0.5; the default on-policy SARSA update; no
  eligibility traces.
- Selection policy: epsilon-greedy with epsilon 0.1 (the default epsilon): usually take the move
  with highest value, otherwise a random move.
- No chunking, no look-ahead, no heuristics, no state-avoidance, no semantic or episodic memory.
- Learned values persist across episodes if the agent is re-initialized and run again.

Observed: since a failure ends the episode immediately, episodes are short (2 to 7 decisions) and
in practice end in failure; over a few episodes the agent does not learn to solve the task.

## 5. Output and settings
Only the two messages above. RL learning on, learning rate 0.1, discount 0.5, epsilon-greedy
(epsilon 0.1). Chunking off.
