# Missionaries and Cannibals: random walk (variant "mac")

## 1. Task
Three missionaries, three cannibals and one boat are on the left bank of a river. Everyone must get
to the right bank.

The state holds two banks, "left" and "right". Each bank records how many missionaries are on it,
how many cannibals are on it, whether the boat is there (1 or 0), its name, and a link to the
other bank. The two banks link to each other.

Initial state (set up by an initialization operator, the first thing the agent does, when the
top state has no name yet; it also names the task):
- left bank: 3 missionaries, 3 cannibals, boat 1
- right bank: 0 missionaries, 0 cannibals, boat 0

The desired state is: the right bank holds 3 missionaries and 3 cannibals.

## 2. Actions
One action, "move boat", carrying a group from the bank where the boat is to the other bank.
There are exactly five load types (missionaries, cannibals): (0,1), (0,2), (1,0), (1,1), (2,0).
A load is proposed for the bank that has the boat when that bank holds at least the number of
missionaries and at least the number of cannibals in the load. Nothing else restricts it: unsafe
results are not filtered out at proposal time, and returning to an earlier state is allowed.

Effect: subtract the load from the boat's bank and add it to the other bank; the boat count on the
departure bank becomes 0 and on the arrival bank becomes 1.

## 3. Goal and failure
- Success: some bank named "right" has exactly 3 missionaries and 3 cannibals (matching the
  desired bank's name and both counts). The agent prints a new line then
  "The problem has been solved." and halts.
- Failure: on either bank, the number of missionaries is greater than 0 and less than the number
  of cannibals. The agent prints a new line then "Failure state: the task has failed." and halts.
  (A bank with 0 missionaries is never a failure.)

## 4. How the agent chooses
All proposed moves are mutually indifferent; the agent picks one at random each decision. There
are no heuristics, no state-avoidance, no look-ahead, no reinforcement learning and no learning of
any kind (chunking is off). No semantic or episodic memory is used.

Observed: the random walk almost always reaches a failure state within a few moves and halts
with the failure message.

## 5. Output and settings
Only the two messages above. Chunking off.
