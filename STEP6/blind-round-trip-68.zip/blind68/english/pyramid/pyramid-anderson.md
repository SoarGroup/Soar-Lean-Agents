# pyramid-anderson

Same structure as variant `pyramid` (file `english/pyramid/pyramid.md`); full description below
so this file stands alone.

## 1. Task
Compute the sum of a descending series of integers. One pyramid object with:
- current term = 5
- height = 2 (the series has height + 1 = 3 terms)
- running sum = 0

Initialisation: when the agent starts and the top state has no name, one initialisation step
names the task "pyramid", creates the pyramid with those values, and records the desired state:
pyramid height = -1.

## 2. Actions
- **Add next term** (applied to the pyramid). Allowed whenever height >= 0. Effects (each old
  value replaced): sum := sum + term; term := term - 1; height := height - 1; prints ` + `
  followed by the term just added (old value), no newline.

## 3. Goal and termination
Goal: height = -1. Then print newline, `The answer is <sum>.`, newline,
`The problem has been solved.`, and halt. No failure states.

## 4. Choice among actions
Single action, proposed indifferent; no search, no learning (chunking off), no substates,
no memories.

## 5. Output and settings
Expected output:
```
 + 5 + 4 + 3
The answer is 12.
The problem has been solved.
```
