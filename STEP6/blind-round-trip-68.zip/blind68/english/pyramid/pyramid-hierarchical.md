# pyramid-hierarchical

Same arithmetic task as variant `pyramid` (file `english/pyramid/pyramid.md`), but solved in two
phases, each done as a hierarchical (sub-goal) action. Full description below.

## 1. Task
Compute the sum of a descending series of integers by first writing out the list of terms and
then summing the list. The pyramid object has:
- current term = 10
- height = 6 (so height + 1 = 7 terms will be generated)
- number of terms generated so far = 0
- sum = 0
- summed flag = 0 (becomes 1 when the final sum has been stored)

There is also a list of term records on the top state, initially empty. Each term record has an
index (0, 1, 2, ...) and a value.

Initialisation: when the agent starts and the top state has no name, one step names the task
"pyramid-hierarchical", creates the pyramid as above, and records the desired state:
pyramid summed flag = 1.

## 2. Actions
Top-level actions (both are abstract: they have no direct effect and are carried out in a
sub-goal by the lower-level actions listed under them):

- **Expand pyramid**: allowed while the pyramid's height >= 0. Remains selected as long as that
  holds; it ends automatically when height reaches -1. Inside its sub-goal (which has access to
  the same pyramid object):
  - **Expand next term**: allowed while height >= 0. Effects: adds a new term record to the top
    state with index = current number of terms generated and value = current term; then
    terms generated increases by 1, current term decreases by 1, height decreases by 1
    (each old value replaced); prints
    ` + ` followed by the term value (no newline).

- **Sum terms**: allowed when height = -1 and the summed flag = 0. Inside its sub-goal (which
  has access to the pyramid and to the top state's term records) the sub-goal keeps its own
  local running sum and a "next index" counter:
  - **Initialise local**: allowed when the sub-goal has no local sum yet. Effect: local sum := 0,
    next index := 0.
  - **Add term**: allowed when the local sum exists and there is a term record whose index equals
    next index. Effect: local sum := local sum + that record's value; next index increases by 1.
  - **Final sum**: allowed when the local sum exists and next index equals the pyramid's number
    of terms generated. Effect: pyramid sum := local sum; pyramid summed flag := 1. (This also
    ends the Sum-terms action, because its condition no longer holds.)

## 3. Goal and termination
Goal: pyramid summed flag = 1. Then print newline, `The answer is <pyramid sum>.`, newline,
`The problem has been solved.`, and halt. No failure states.

## 4. Choice among actions
At each level at most one action is applicable at any time (the conditions are mutually
exclusive), and all are proposed as indifferent. Hierarchy: the two top-level actions are
decomposed into sub-goals as described. No search, no learning (chunking off), no memories.

## 5. Output and settings
Terms generated: 10, 9, 8, 7, 6, 5, 4 (indices 0..6). Expected output:
```
 + 10 + 9 + 8 + 7 + 6 + 5 + 4
The answer is 49.
The problem has been solved.
```
