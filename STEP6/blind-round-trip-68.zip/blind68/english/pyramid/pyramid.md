# pyramid

## 1. Task
Compute the sum of a descending arithmetic series ("pyramid" of numbers). The world has one
pyramid object with three numeric properties. Initial values:
- current term = 5
- height (number of terms still to add, minus one) = 10
- running sum = 0

Initialisation: when the agent starts and the top state has no name, one initialisation step
names the task "pyramid", creates the pyramid with the values above, and records the desired
state: pyramid height = -1.

## 2. Actions
- **Add next term** (applied to the pyramid). Allowed whenever the pyramid's height is >= 0.
  Effects (all at once, each old value replaced):
  - sum := sum + current term
  - current term := current term - 1
  - height := height - 1
  - prints ` + ` followed by the term that was just added (the old term value), with no newline.

## 3. Goal and termination
Goal: pyramid height equals -1. When reached, the agent prints a newline, `The answer is <sum>.`,
a newline, `The problem has been solved.`, and halts. No failure states.

## 4. Choice among actions
Only one action exists and at most one instance is proposed at a time; it is marked
indifferent. No search, no learning (chunking off), no substates, no memories.

## 5. Output and settings
The action fires 11 times (height 10 down to 0), adding 5, 4, 3, 2, 1, 0, -1, -2, -3, -4, -5.
Expected output:
```
 + 5 + 4 + 3 + 2 + 1 + 0 + -1 + -2 + -3 + -4 + -5
The answer is 0.
The problem has been solved.
```
Note: because the number of steps (height + 1 = 11) exceeds the starting term, the terms run
past zero into negative numbers and the answer is 0. This is what the program does; reproduce it.
