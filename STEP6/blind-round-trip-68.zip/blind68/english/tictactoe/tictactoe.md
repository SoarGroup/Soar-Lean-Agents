# tictactoe

## 1. Task
A game of tic-tac-toe in which the agent plays both sides, choosing moves at random.
- Board: 9 cells, each with column x (1..3), row y (1..3), a name c<x><y> (c11, c21, c31, c12,
  ..., c33) and a content: 0 = empty, 1 = X, 2 = O. All cells start empty.
- Lines: 8 lines of three cells each: rows 1-3 (cells with the same y), columns 1-3 (same x),
  diagonal1 = (1,1),(2,2),(3,3), diagonal2 = (3,1),(2,2),(1,3).
- Game record: turn = 1 (X moves first), winner = 0 (none), over = 0.

Initialisation: when the agent starts and the top state has no name, one step names the task
"TicTacToe", creates the board, lines and game record as above, and records the desired state:
game over = 1.

## 2. Actions
- **Mark a cell**: one instance per empty cell, allowed while the game is not over. Effect: the
  cell's content := the current turn value (1 for X, 2 for O); turn := 3 - turn (alternates
  1 <-> 2).
- **X wins**: allowed when the game is not over and some line has all three of its cells
  containing X. Effect: over := 1, winner := 1, prints `Side X won.`
- **O wins**: same with O: all three cells of a line contain O. Effect: over := 1, winner := 2,
  prints `Side O won.`
- **Detect draw**: allowed when the game is not over and no cell is empty. Effect: over := 1
  (winner stays 0), prints `Draw.`

## 3. Goal and termination
Goal: game over = 1 (reached by a win for either side or by a draw). When reached, prints a
newline then `The problem has been solved.` and halts.

## 4. Choice among actions
- All actions are proposed as indifferent, so the choice among the empty cells to mark is
  random (uniform) for both X and O; there is no strategy.
- X-wins and O-wins are given a "best" preference, so as soon as a winning line exists the win
  is declared before any further mark (and before a draw is declared if the board is also full).
- No search, no learning (chunking off), no substates, no memories.

## 5. Output
A board monitor prints the board whenever it changes (including once at the start with all
cells blank): a newline, then the following, where each cell shows `X`, `O` or a space and the
rows are y = 1, 2, 3 from top to bottom, columns x = 1, 2, 3 left to right (5 leading spaces):
```
     -------------
     | a | b | c |
     |---|---|---|
     | d | e | f |
     |---|---|---|
     | g | h | i |
     -------------
```
Then the result line (`Side X won.`, `Side O won.` or `Draw.`), then
`The problem has been solved.`
