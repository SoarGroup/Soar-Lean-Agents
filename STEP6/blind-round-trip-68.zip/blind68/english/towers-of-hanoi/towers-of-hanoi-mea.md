# towers-of-hanoi-mea

Same puzzle and world representation as variant `towers-of-hanoi` (file
`english/towers-of-hanoi/towers-of-hanoi.md`), but solved by means-ends analysis with operator
subgoaling instead of the smallest-disk rule. Full description below.

## 1. Task
Towers of Hanoi, 5 disks, pegs A, B, C.
- Disks of sizes 1-5 (named "1".."5"); each peg also has a fixed base disk of size 6 (base-A,
  base-B, base-C) standing on a ground of size 7. Bases/ground never move.
- For every disk (real disks and bases) a position record: which disk, which peg it is on, which
  disk it sits directly on top of. A disk is clear if nothing sits on it.
- Initial: disks 1..5 on peg A stacked 1 on 2 on 3 on 4 on 5 on base-A; base-B on B, base-C on C.
- A control record (last moved size = 2, a last peg = B) is created as in the other variant but
  is never used by this variant.
- Desired state (top level): disks 1-5 all on peg C.

Initialisation: when the agent starts and the top state has no name, one step names the task
"towers-of-hanoi" and creates all of the above.

## 2. Actions
**Move disk** d to a target peg. Each proposed move also carries a "reason disk": the disk whose
goal the move serves (for top-level moves, d itself).

Execution (application) of a selected move happens only if the move is legal right now: d is
clear, and the target peg's top (clear) disk t is larger than d. Effect: d is now on the target,
sitting on t. Prints `Move Disk: <size> to peg <peg name>` with no newline.

If a selected move is NOT legal, nothing happens in the current state, and the agent sets up a
subgoal (an operator no-change sub-state) whose own goal is "get disk d onto the target peg".
The sub-state shares the same disks, pegs and position records (moves made there change the real
world). As soon as the blocked move becomes legal it is executed in the state where it was
selected, and the subgoal disappears. Subgoals nest recursively.

When a move is proposed:
- **Top level (goal = all disks on C):** propose moving disk d to peg C when d is not on C and
  every disk larger than d (among disks 1-5) is already on C. (Legality is not checked when
  proposing.) At most one such move exists at any time: the largest disk not yet on C.
- **Inside a subgoal "get disk X onto peg P"** (X currently on peg Q):
  - (Clear X) If some disk Y sits directly on top of X, propose moving Y to the third peg (the
    peg that is neither Q nor P). Reason disk: X.
  - (Clear the destination) If peg P holds disks smaller than X, take the largest disk Z on P
    that is smaller than X, and propose moving Z to the third peg (neither P nor Q). Reason
    disk: X.
  These are the only proposals in a subgoal; the top-level rule does not apply inside subgoals.

## 3. Goal and termination
Top-level goal: disks 1-5 all on peg C. Then print newline, `The problem has been solved.`, halt.
Subgoals are not "solved" explicitly; they end when the move that created them becomes legal
and executes. No failure states.

## 4. Choice among actions
All proposals are indifferent (random choice if both subgoal proposals are present at once).
Means-ends analysis via operator subgoaling as described is the only control knowledge; no
look-ahead evaluation, no learning (chunking off), no RL, no memories.

## 5. Output
Produces the optimal 31-move solution (same sequence as variant towers-of-hanoi):
1>C 2>B 1>B 3>C 1>A 2>C 1>C 4>B 1>B 2>A 1>A 3>B 1>C 2>B 1>B 5>C 1>A 2>C 1>C 3>A 1>B 2>A 1>A
4>C 1>C 2>B 1>B 3>C 1>A 2>C 1>C
printed as `Move Disk: 1 to peg CMove Disk: 2 to peg B...` then newline,
`The problem has been solved.` (about 48 decision cycles).
