# towers-of-hanoi

## 1. Task
Towers of Hanoi with 5 disks and 3 pegs, solved by the classic "smallest disk cycles" rule
with no search.

Objects:
- Pegs: A, B, C.
- Disks: sizes 1, 2, 3, 4, 5 (named "1".."5"). In addition each peg has a fixed base disk of size
  6 (base-A, base-B, base-C), and all three bases stand on a "ground" of size 7. Bases and
  ground never move; they let "the top of an empty peg" be treated as a size-6 disk.
- For every disk (real disks and bases) there is a position record giving: which disk, which peg
  it is on, and which disk it sits directly on top of.
- A disk is clear when no disk sits directly on top of it. The top of a peg is its clear disk.
- A control record remembering: the size of the last disk moved, and the peg the smallest disk
  (size 1) was last moved FROM.

Initial state: all five disks on peg A, stacked 1 on 2 on 3 on 4 on 5 on base-A (1 on top).
base-B on peg B, base-C on peg C. Control: last moved size = 2, smallest disk's last source
peg = B (these initial values make the first move put disk 1 onto C).

Initialisation: when the agent starts and the top state has no name, one step names the task
"towers-of-hanoi" and creates everything above, plus the desired state: disks 1-5 all on peg C.

## 2. Actions
**Move disk** d from its peg (source) onto the top disk t of a different peg (target). Always
requires: d is a real disk (size 1-5), d is clear, t is clear, t is larger than d, target is
not the source. Two cases, distinguished by the control record:
- Case 1 (move the smallest disk): d has size 1, the last disk moved was NOT size 1, and the
  target is not the peg the smallest disk was last moved from. Effects: d now on target, sitting
  on t; control last-moved size := 1; control smallest-disk last source := this move's source peg.
- Case 2 (move some other disk): d has size 2-5 and the last disk moved WAS size 1. Effects: d
  now on target sitting on t; control last-moved size := d's size (the smallest disk's last
  source is unchanged).
Each move prints `Move Disk: <size> to peg <peg name>` with no newline (so the moves run
together on one line).

## 3. Goal and termination
Goal: disks 1, 2, 3, 4 and 5 are all on peg C (stacking is implied by legality). Then print a
newline and `The problem has been solved.` and halt. No failure states.

## 4. Choice among actions
The two cases alternate strictly (smallest disk, then another disk, then smallest, ...). In each
step exactly one move is legal under these rules, so no preferences are needed; all proposals
are indifferent. No search, no learning (chunking off), no substates, no memories.

## 5. Output
31 moves, the optimal solution:
1>C 2>B 1>B 3>C 1>A 2>C 1>C 4>B 1>B 2>A 1>A 3>B 1>C 2>B 1>B 5>C 1>A 2>C 1>C 3>A 1>B 2>A 1>A
4>C 1>C 2>B 1>B 3>C 1>A 2>C 1>C
printed as `Move Disk: 1 to peg CMove Disk: 2 to peg B...`, then newline,
`The problem has been solved.`
