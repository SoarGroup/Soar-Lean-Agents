# Water jug with a hierarchical fill operator and chunking (variant: water-jug-hierarchy-chunk)

As variant water-jug-hierarchy (file: water-jug-hierarchy.md), except that chunking is turned on.
Everything else is identical: same initial state (volume-3 and volume-5 jugs empty, holding
nothing, desired volume-3 jug with 1), same top-level fill/empty/pour (random, indifferent), same
"fill-relevant" condition for proposing fill (jug not full, or jug full and held), same fill
substate with pick-up / fill-jug / put-down and their conditions and effects, same goal, message
("The problem has been solved.") and halt. No failure states.

## 1. Task
Same as water-jug-hierarchy.md.

## 2. Actions
Same as water-jug-hierarchy.md.

## 3. Goal and failure
Same as water-jug-hierarchy.md.

## 4. How the agent chooses
- Random/indifferent choice among top-level operators, as in water-jug-hierarchy.md.
- Learning: chunking always on, with operator-application (o-support) chunks enabled. The first
  time each sub-step of fill is done in the substate, a rule is learned that performs that step
  directly while the top-level fill(jug) operator is selected:
  - when fill(jug) is selected and nothing is held: hold that jug;
  - when fill(jug) is selected, that jug is held and not full: set its contents to its volume;
  - when fill(jug) is selected, that jug is held and full: stop holding it.
  After these three rules exist, later fills are executed at the top level without entering the
  substate. Learned rules persist across episodes in the same agent.
- No RL, no look-ahead, no semantic/episodic memory.

## 5. Output and settings
- Output: "The problem has been solved." on success, then halt.
- Settings: chunking always, with o-support chunks enabled.
