# Water jug with a hierarchical fill operator (variant: water-jug-hierarchy)

As variant water-jug (file: water-jug.md), except that "fill" is carried out in a substate by
three sub-operators (pick up, fill, put down) and the top state tracks which jug is being held.
Everything else is identical: same initial state, same empty and pour operators (acceptable and
indifferent), same goal, same message and halt, random choice, no learning.

## 1. Task
- Same initialization as water-jug.md: state named "water-jug"; jug of volume 3 contents 0; jug of
  volume 5 contents 0; desired jug volume 3 contents 1. Free space = volume - contents (derived).
- New state property: "holding" — which jug (if any) the agent is currently holding. Initially the
  agent holds nothing.

## 2. Actions
Top level (all acceptable and indifferent; random choice):
- empty(jug), pour(from, to): exactly as in water-jug.md.
- fill(jug): proposed when the jug is "fill-relevant", meaning either
  (a) the jug's free space > 0 (not full), or
  (b) the jug is full (free space <= 0) AND the agent is holding that jug.
  The top-level fill has no direct effect; it is implemented in a substate (operator no-change).
Fill substate (entered when fill(jug) is selected; the substate is named "fill" and knows the jug):
- pick-up: allowed when the agent holds nothing. Effect: the agent now holds the jug (recorded on
  the top state).
- fill-jug: allowed when the jug is not full and the agent holds this jug. Effect: the jug's
  contents become its volume.
- put-down: allowed when the jug is full and the agent holds this jug. Effect: the agent holds
  nothing (the holding record is removed).
  All three are acceptable and indifferent; in practice their conditions make them happen in the
  order pick-up, fill-jug, put-down. After put-down the jug is full and not held, so fill(jug) is
  no longer proposed and the top-level fill ends, removing the substate.

## 3. Goal and failure
Same as water-jug.md: when the volume-3 jug holds 1, print a newline and "The problem has been
solved." and halt. No failure states.

## 4. How the agent chooses
- Random/indifferent choice among all proposed top-level operators, as in water-jug.md. Inside the
  fill substate only one sub-operator is applicable at a time.
- No chunking (learning off), no RL, no look-ahead, no semantic/episodic memory. Hierarchy as above.

## 5. Output and settings
- Output: "The problem has been solved." on success, then halt.
- Settings: chunking never.
