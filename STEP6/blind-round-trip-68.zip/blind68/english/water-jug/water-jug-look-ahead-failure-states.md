# Water jug with look-ahead search and failure states (variant: water-jug-look-ahead-failure-states)

As variant water-jug-look-ahead (file: water-jug-look-ahead.md), except for two extra
"avoid" states during look-ahead. Everything else is identical: same initial state (volume-3 and
volume-5 jugs empty; desired: volume-3 jug holds 1), same problem-space copying description
(jugs copied two levels deep; free space and ancestors not copied), same ancestor list, same
fill/empty/pour operators proposed as acceptable only (so they tie), same goal test and message
("The problem has been solved.") and halt, same duplicate-of-ancestor partial-failure check, same
standard selection-space look-ahead and translation of evaluations into preferences, same
chunking (always, o-support chunks on).

## 1. Task
Same as water-jug-look-ahead.md.

## 2. Actions
Same as water-jug-look-ahead.md.

## 3. Goal and failure
- Goal: as water-jug-look-ahead.md.
- Partial-failure states during look-ahead (each tested only in a simulated state, right after the
  simulated operator has been applied):
  - duplicate of an ancestor state (as in water-jug-look-ahead.md);
  - NEW: both jugs full (volume-3 jug contents 3 and volume-5 jug contents 5);
  - NEW: both jugs empty (volume-3 jug contents 0 and volume-5 jug contents 0).
  A partial failure makes the evaluated candidate "worst" (as in water-jug-look-ahead.md).
- No other failure states; the real (top) state is never marked as failed.

## 4. How the agent chooses
Same look-ahead search and chunking as water-jug-look-ahead.md; the two extra partial-failure
states prune more of the search, so the first episode is shorter and later episodes (with learned
rules) solve in about 5-9 decisions. No RL, no semantic/episodic memory.

## 5. Output and settings
- Output: "The problem has been solved." on success, then halt.
- Settings: chunking always (o-support chunks on); up to 3 jugs and 20 ancestors per state.
- In the runs tried (3 seeds x 3 episodes) every episode was solved.
