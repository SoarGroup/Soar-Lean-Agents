# Water jug with look-ahead search, expected values and RL settings (variant: water-jug-look-ahead-rl)

As variant water-jug-look-ahead (file: water-jug-look-ahead.md), except for the two "avoid" states
below (which give a numeric expected value instead of a symbolic failure) and reinforcement
learning being switched on. Everything else is identical: same initial state (volume-3 and
volume-5 jugs empty; desired: volume-3 jug holds 1), same problem-space copying description (jugs
copied two levels deep; free space and ancestors not copied), same ancestor list, same
fill/empty/pour operators proposed as acceptable only (so they tie), same goal test and message
("The problem has been solved.") and halt, same duplicate-of-ancestor partial-failure check, same
standard selection-space look-ahead, same chunking (always, o-support chunks on).

## 1. Task
Same as water-jug-look-ahead.md.

## 2. Actions
Same as water-jug-look-ahead.md.

## 3. Goal and failure
- Goal: as water-jug-look-ahead.md.
- Duplicate-of-ancestor state in look-ahead -> partial failure (as in water-jug-look-ahead.md).
- NEW: in a simulated state, right after the simulated operator is applied, if both jugs are full
  (contents 3 and 5) or both jugs are empty (contents 0 and 0), the state is given an expected
  value of -1. (A both-empty state is also a duplicate of the initial top state, so it is usually
  a partial failure as well.)

## 4. How the agent chooses
- Look-ahead search as in water-jug-look-ahead.md, with these additions from the standard
  selection space for expected values:
  - an expected value returned from a simulation becomes the candidate's expected value, and it
    is turned into a numeric indifferent preference of that value (-1 here) on the tied operator;
  - an expected value found deeper in a nested look-ahead is passed up to the enclosing candidate
    multiplied by 0.9 (discounted).
- Reinforcement learning: learning on, learning rate 0.1, discount rate 0.5, epsilon-greedy
  selection with Soar's default exploration rate (epsilon 0.1). There are NO reward rules and NO
  hand-written RL value rules; the only RL-updatable rules are the chunks learned from the
  look-ahead that produce numeric preferences, and RL then adjusts their values (with no reward
  they drift toward 0 / toward discounted values of the next choice).
- Learned rules and their values persist across episodes in the same agent.
- No semantic/episodic memory.

## 5. Output and settings
- Output: "The problem has been solved." on success, then halt.
- Settings: chunking always (o-support chunks on); RL on, learning rate 0.1, discount 0.5,
  epsilon-greedy; up to 3 jugs and 20 ancestors per state.

Note: because no reward is ever given, RL only erodes the -1 values learned from look-ahead, and
with epsilon-greedy exploration the agent can wander for a long time. In runs tried, episodes took
from about 7 to over 1400 decisions, and one episode (seed 2, third episode) did not solve within
2000 decisions, oscillating between "both full" and "5-jug full, 3-jug empty" (fill and empty the
3-jug repeatedly).
