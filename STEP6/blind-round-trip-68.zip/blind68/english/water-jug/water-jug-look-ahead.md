# Water jug with look-ahead search (variant: water-jug-look-ahead)

Based on variant water-jug (file: water-jug.md). The task is the same; choices are made by Soar's
standard look-ahead search in the default "selection" problem space, with duplicate-state
detection, and chunking is on.

## 1. Task
- Same initialization as water-jug.md: state named "water-jug"; jug of volume 3 contents 0; jug of
  volume 5 contents 0; desired jug volume 3 contents 1. Free space = volume - contents (derived on
  every water-jug state, including simulated ones).
- The water-jug state also describes its problem space for look-ahead: name water-jug; when
  simulating, copy the state and copy the operator; the jugs are copied two levels deep (each jug
  is duplicated with its volume and contents, so the copy can be changed independently); do not
  copy the derived free space (it is recomputed) or the ancestor list (below).
- Every substate keeps a list of its ancestors: every state above it in the goal stack (the top
  state included). Up to 20 ancestors.

## 2. Actions
- fill(jug) [jug not full], empty(jug) [contents > 0], pour(from, to) [from non-empty, to not full,
  different jugs] with the same effects as water-jug.md (pour: if from's contents exceed to's free
  space, to becomes full and from loses that much; otherwise all of from goes to to and from
  becomes 0).
- Difference: they are proposed as acceptable only (NOT indifferent), so whenever two or more are
  proposed there is a tie impasse. These same operators also run inside simulated states.

## 3. Goal and failure
- Goal test (applies to any state named water-jug, real or simulated): a jug with volume 3 and
  contents 1 marks the state as a success for the desired goal. On the top state, the agent prints
  a newline and "The problem has been solved." and halts.
- Duplicate-state failure (only in a simulated state, right after the simulated operator has been
  applied): if the jug contents of this state are the same as those of any ancestor water-jug
  state (the top state or an enclosing simulated state) — i.e. the volume-3 jug and the volume-5
  jug have the same contents as in that ancestor — the state is marked a partial failure.
- No other failure states.

## 4. How the agent chooses: look-ahead search (standard selection space) plus chunking
- On a tie among task operators, a selection substate is created. For each tied candidate an
  evaluate-operator step is proposed (indifferent; random order). Evaluating a candidate creates a
  substate that is a copy of the state being decided in (jugs duplicated as above, same desired
  goal, same name so all task knowledge applies), in which a copy of the candidate is forced to be
  applied first. Then:
  - If the resulting state satisfies the goal -> the candidate is evaluated "success".
  - If it is a duplicate of an ancestor state -> "partial failure".
  - Otherwise the simulation continues: if only one operator is proposed it is applied; if several
    tie, a nested selection substate evaluates them the same way (recursive depth-first look-ahead,
    no depth limit). If any deeper evaluation is a success (or partial success), the candidate
    being evaluated above gets "partial success".
  - If a simulated state has no proposed operators, or a constraint failure arises, the candidate
    gets "exhaustion failure". If all candidates in a nested tie end up with no value at all, the
    candidate above gets "no value" (worse than any value).
- Evaluations become preferences on the tied operators:
  - success or partial success -> best; success is also better than partial success;
  - partial failure -> worst; candidates with the same symbolic evaluation are indifferent to each
    other; partial failure is better than failure; failure -> reject; exhaustion failure -> reject
    (and exhaustion failures are mutually indifferent).
  So a candidate leading to the goal is chosen; candidates leading to repeated states are
  avoided; among equals the choice is random.
- Chunking: always on, with operator-application chunks enabled. Results of the search (the
  preferences and evaluations) are learned as rules, so later decisions in the same situations are
  made without search. Learned rules persist across episodes in the same agent; once the path is
  learned, later episodes solve in about 7 decisions.
- No RL, no hierarchy beyond the selection/evaluation substates, no semantic/episodic memory.

## 5. Output and settings
- Output: "The problem has been solved." on success, then halt (the standard default top-state
  success rule also halts).
- Settings: chunking always (o-support chunks on); up to 3 jugs and 20 ancestors per state.

Note: the duplicate-state check depends on which states are ancestors at the time, but the learned
rules generalise it away. In some runs (e.g. 1 of 3 random seeds tried) the learned rules drive the
top level into an endless cycle with no further impasses — both empty, fill the 3-jug, pour it into
the 5-jug, fill the 5-jug, empty the 5-jug, repeat (observed, as (3-jug, 5-jug) contents: (0,0) -> (3,0) -> (0,3) -> (0,5) -> (0,0) ...), and the
agent never solves the problem. Other runs solve it in roughly 80-100 decisions.
