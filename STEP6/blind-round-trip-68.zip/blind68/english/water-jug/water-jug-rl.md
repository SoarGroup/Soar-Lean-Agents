# Water jug with reinforcement learning (variant: water-jug-rl)

As variant water-jug (file: water-jug.md), except for reinforcement learning, described below.
Everything else is identical: same initialization (jug of volume 3 and jug of volume 5, both
empty; desired: the volume-3 jug holds 1), same derived free space, same fill / empty / pour
operators with the same conditions and effects (each still proposed as acceptable and indifferent),
same goal test, same "The problem has been solved." message and halt. No failure states, no
chunking, no look-ahead, no hierarchy, no semantic/episodic memory.

## 1. Task
Same as water-jug.md: jug A volume 3 contents 0, jug B volume 5 contents 0, goal jug volume 3
contents 1. Free space = volume - contents.

## 2. Actions
Same as water-jug.md (fill when not full; empty when contents > 0; pour from a non-empty jug into a
different non-full jug, with the two overflow cases).

## 3. Goal and failure
Same as water-jug.md: halt with "The problem has been solved." when the volume-3 jug holds 1.
No failure states.

## 4. How the agent chooses: reinforcement learning
- Q-values (numeric indifferent preferences, learned by RL, all initially 0) are kept for every
  proposed task operator, keyed by:
  - fill: the operator kind plus that jug's volume and current contents;
  - empty: the operator kind plus that jug's volume and current contents;
  - pour: the operator kind plus the source jug's volume and contents and the destination jug's
    volume and contents.
  (One learned value per distinct combination, created on demand the first time it is seen.)
- Rewards (present on the top state's reward channel for as long as the condition holds, and
  collected at each RL update while present):
  - -1 whenever both jugs are empty (volume-3 jug contents 0 and volume-5 jug contents 0); note this
    includes the initial state.
  - +1 whenever the volume-3 jug holds 1 (the goal).
- Learning: on, learning rate 0.1, discount rate 0.5; other RL settings at Soar defaults (on-policy
  SARSA-style updates, no eligibility traces).
- Action selection: epsilon-greedy over the Q-values, with Soar's default exploration rate
  (epsilon 0.1): usually the operator with the highest Q-value, otherwise random among legal ones.
  Because the plain indifferent preferences are still present, ties among equal Q-values are broken
  at random.
- Learning persists across episodes in the same agent (after a reset the agent starts again from
  both jugs empty and keeps its Q-values), so later episodes typically solve in a few steps.

## 5. Output and settings
- Output: "The problem has been solved." on success, then halt.
- Settings: chunking never; RL on, learning rate 0.1, discount 0.5, epsilon-greedy exploration
  (default epsilon).
