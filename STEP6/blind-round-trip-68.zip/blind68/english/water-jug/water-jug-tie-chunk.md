# Water jug with tie-impasse heuristics and chunking (variant: water-jug-tie-chunk)

As variant water-jug-tie (file: water-jug-tie.md), except that chunking is turned on.
Everything else is identical: same initial state (volume-3 jug and volume-5 jug both empty,
desired volume-3 jug with 1, last operator = none), same fill/empty/pour operators proposed as
acceptable only (so they tie), same last-operator memory, same tie substate with the same
heuristic evaluations (last none: all equal; last pour: fill/empty equal, pour worst; last fill or
empty: pour best, fill/empty worst) and the same translation into preferences (equal ->
indifferent; worst -> worst + indifferent; best -> best + indifferent), same goal, message
("The problem has been solved.") and halt. No failure states.

## 1. Task
Same as water-jug-tie.md.

## 2. Actions
Same as water-jug-tie.md.

## 3. Goal and failure
Same as water-jug-tie.md.

## 4. How the agent chooses
- Same tie-substate heuristics as water-jug-tie.md.
- Learning: chunking is always on (learn in every substate), including chunks that apply
  operators (o-supported knowledge allowed in chunks). Each time the tie substate returns a
  preference, a rule is learned that produces that preference directly in the future, generalised
  over the last operator kind and the candidate's kind. In practice five rules are learned:
  last none -> any fill/empty/pour indifferent; last pour -> fill/empty indifferent;
  last pour -> pour worst; last fill-or-empty -> pour best; last fill-or-empty -> fill/empty worst.
  After these are learned no more tie impasses occur; choices are made directly from the learned
  preferences. Learned rules persist across episodes in the same agent.
- No RL, no look-ahead, no hierarchy, no semantic/episodic memory.

## 5. Output and settings
- Output: "The problem has been solved." on success, then halt.
- Settings: chunking always, with operator-application (o-support) chunks enabled.
