# Water jug with tie-impasse heuristics (variant: water-jug-tie)

Based on variant water-jug (file: water-jug.md); differences are in how operators are proposed,
an extra "last operator" memory, and a tie-impasse substate that supplies heuristic preferences.

## 1. Task
- Same initialization as water-jug.md: state named "water-jug"; jug of volume 3 contents 0; jug of
  volume 5 contents 0; desired jug volume 3 contents 1. Free space = volume - contents (derived).
- Additionally the initial state records "last operator = none".

## 2. Actions
- fill(jug) [jug not full], empty(jug) [contents > 0], pour(from, to) [from non-empty, to not full,
  different jugs]: same conditions and effects as water-jug.md (pour: if from's contents exceed
  to's free space, to becomes full and from loses that free-space amount; otherwise all of from goes
  into to and from becomes 0).
- Difference: these operators are proposed as acceptable only (NOT indifferent). So whenever more
  than one is proposed, there is an operator tie impasse; if only one is proposed it is simply
  selected.
- Last-operator memory: whenever a task operator (fill, empty or pour; not initialize) is selected
  on the top state, the state's "last operator" is set to that operator's kind (fill, empty or
  pour), replacing the previous value. It starts as "none".

## 3. Goal and failure
Same as water-jug.md: when the volume-3 jug holds 1, print a newline and "The problem has been
solved." and halt. No failure states.

## 4. How the agent chooses: heuristics computed in a tie substate
- When the task operators tie, a substate is created (recognised as a tie on operators whose
  superstate is the water-jug state). It copies the superstate's last-operator value, and creates
  one evaluation per tied candidate.
- In the substate, an "evaluate" operator is proposed for each evaluation that has no value yet
  (all such evaluate operators are indifferent; random order). Applying it gives the candidate a
  value from these rules (based on the last operator kind and the candidate's kind):
  - last = none: fill, empty and pour candidates are all "equal".
  - last = pour: fill and empty candidates are "equal"; pour candidates are "worst".
  - last = fill or empty: pour candidates are "best"; fill and empty candidates are "worst".
  (In words: avoid two pours in a row; after a fill or empty, pour.)
- Once every candidate has a value, a "create-preferences" operator (preferred over the evaluate
  operators) fires and puts preferences on the tied operators in the superstate:
  - equal -> indifferent;
  - worst -> worst and indifferent;
  - best -> best and indifferent.
  This resolves the tie; the selected candidate is random among the best class (among the
  indifferent ones if no best; among the worst only if all are worst).
- No chunking (learning off), so the substate is re-entered at every tie. No RL, no look-ahead,
  no hierarchy, no semantic/episodic memory.

## 5. Output and settings
- Output: "The problem has been solved." on success, then halt.
- Settings: chunking never.
