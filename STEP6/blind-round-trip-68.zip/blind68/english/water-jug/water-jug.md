# Water jug (base variant: water-jug)

## 1. Task
- The agent's top state represents a water-jug puzzle. It is set up by a first operator,
  "initialize-water-jug", which is the only thing proposed at the start (proposed only on the top
  state, and only while the state has no name yet). Applying it names the state "water-jug" and
  creates:
  - Jug A: capacity (volume) 3, contents 0.
  - Jug B: capacity (volume) 5, contents 0.
  - A desired (goal) description: a jug with volume 3 and contents 1.
- Derived property, recomputed continuously for every jug: free space = volume - contents.
- There is an unlimited water source and drain; no other objects.
- Settings: learning (chunking) is off. The state can hold up to two (several) jugs.

## 2. Actions (all proposed on the water-jug state; each is a separate operator instance per jug or jug pair)
- fill(jug): allowed when the jug's free space > 0 (it is not full). Effect: the jug's contents
  become its volume.
- empty(jug): allowed when the jug's contents > 0. Effect: the jug's contents become 0.
- pour(from, to), with from and to different jugs: allowed when from's contents > 0 and to's free
  space > 0. Effect:
  - if from's contents > to's free space: to becomes full (contents = to's volume) and from's
    contents decrease by to's (old) free space;
  - otherwise (from's contents <= to's free space): to's contents increase by from's contents and
    from's contents become 0.
- All candidate operators are proposed as acceptable and indifferent to each other.

## 3. Goal and failure
- Goal: some jug on the state has the same volume and contents as the desired jug, i.e. the
  3-capacity jug holds exactly 1. When that holds on the top state, the agent prints a new line
  followed by "The problem has been solved." and halts.
- There are no failure states; the agent never gives up.

## 4. How the agent chooses
- Purely random: every proposed operator is indifferent, so each decision picks uniformly at random
  among all currently legal fill/empty/pour operators. No heuristics, no state avoidance, no
  look-ahead, no RL, no chunking, no hierarchy, no semantic or episodic memory.
- Consequently it random-walks through the state space until it happens to reach a state where the
  3-jug contains 1 (typically tens to a few hundred decisions).

## 5. Output and settings
- Only output: "The problem has been solved." (preceded by a newline) on success, then halt.
- Settings: chunking never.
