# wizards

## 1. Task
A "three wise men"-style nested-belief puzzle. Three wizards, numbered 1, 2, 3 (named A, B, C),
each have a spot that is white or black. Each wizard can see the others' spots but not his own.
Common knowledge used by the program: not all three spots are black (if a wizard sees that both
other spots are black, his own must be white). No wizard has announced a guess yet. The agent
reasons from wizard 1's point of view, building nested models ("what wizard 1 thinks wizard 2
thinks wizard 3 knows ..."), assumes values for unknown spots, detects contradictions with the
fact that nobody has guessed, and concludes wizard 1's own colour.

Representation (all of it in the top state):
- **World**: done flag (0 at start), and a count of views created so far (1 at start).
- **Views** (belief contexts). Each has: a numeric id, an owner wizard ("in the view of wizard
  X"), a depth (1 = the top-level view), and (except the first) a parent view.
- **Records**: in each view, one record per wizard (1, 2, 3), holding:
  - mark: what is known about that wizard's spot in this view: 0 unknown, 1 white, 2 black;
  - a "linked to an unknown" flag (0/1) and, if 1, a link to a shared unknown-spot variable;
  - modelled flag (0/1): whether a nested view for this wizard has been created from this view;
  - ascribed guess: 0 = this wizard made no guess, 1 = guessed white, 2 = guessed black;
    a record may also have no ascribed-guess value at all (see below);
  - links to the two other records of the same view (its siblings);
  - a link "down" to the record for the same wizard in a nested (child) view, once one exists.
  A record is the view's **own** record when its wizard is the view's owner.
- **Unknown-spot variables**, each with: value (0 = unassigned, 1 white, 2 black), the set of
  values not yet tried (starts {white, black}), and the id of the view in which a value was
  assumed (0 at start).

Initial state: view 1, owner wizard 1, depth 1. Records in view 1: wizard 1 mark 0 (unknown),
wizard 2 mark 1 (white), wizard 3 mark 1 (white); all with link flag 0, modelled 0, ascribed
guess 0. World: done 0, views 1. Desired: world done = 1. Initialisation happens in one step when
the top state has no name (task name "wizards").

### Derived knowledge (recomputed continuously, not actions)
For every record:
- **white** if: its mark is 1; or it is the own record and both siblings are "blackish"; or its
  down-record is white and that down-record is not contradictory.
- **black** if: its mark is 2; or its down-record is black and not contradictory.
- **blackish** if: it is black, or it is linked to an unknown variable whose value is black.
- **would-guess-white** if: it is the own record and white; or its ascribed guess is 1; or its
  down-record would-guess-white and is not contradictory.
- **would-guess-black** if: own and black; or ascribed guess 2; or down-record would-guess-black
  and not contradictory.
- **contradictory** if: (would-guess-white and ascribed guess is 0) or (would-guess-black and
  ascribed guess is 0) or (would-guess-white and would-guess-black). I.e. this wizard would know
  his colour, yet he did not guess.

## 2. Actions
1. **Own spot unknown**: for an own record with mark 0, not linked, and not derived white or
   black. Effect: create a new unknown variable (value unassigned, untried {white, black},
   assigned-view 0), link the record to it (link flag 1). Prints
   `In the view of wizard <w>, his own spot is unknown.`
2. **Model what a wizard knows**: for a view K and a non-own record W in K that is not yet
   modelled. Effect: create a new view V with id = view count + 1, owner = W's wizard,
   depth = K's depth + 1, parent K; create three records in V (wizards 1, 2, 3), each with
   mark 0, link flag 0, modelled 0, siblings of one another, and NO ascribed-guess value; link
   each record of K down to the record for the same wizard in V; view count += 1; W's modelled
   flag := 1. Prints `In the view of wizard <K's owner>, model what wizard <W's wizard> knows.`
3. **Pass down a mark**: for a record X with non-zero mark whose down-record Y is not own and
   has mark 0. Effect: Y's mark := X's mark. (Others' visible spots carry into the nested view;
   the nested owner's own spot does not.)
4. **Pass down an unknown**: for a record X linked to an unknown variable whose down-record Y is
   not own and not linked. Effect: link Y to the same variable (link flag 1).
5. **Pass down a guess**: for a record X with ascribed guess g whose down-record Y is not own and
   does not already have ascribed guess g. Effect: give Y ascribed guess g. (Own records of nested
   views therefore never get an ascribed guess.)
6. **Assume black**: for a non-own record R in view K linked to a variable that is unassigned and
   still has black untried. Effect: variable value := black, remove black from untried,
   assigned-view := K's id. Prints
   `In the view of wizard <K's owner>, assume wizard <R's wizard>'s spot is black.`
7. **Assume white**: same, but only when black is no longer untried and white is untried.
   Effect: value := white, remove white from untried, assigned-view := K's id. Prints
   `... assume wizard <R's wizard>'s spot is white.`
8. **Complement (contradiction)**: when a record in view K1 is contradictory, and a child view
   K2 of K1 contains a record W2 linked to a variable whose assigned-view is K2 and which still
   has an untried value u. Effect: W2's mark := u, W2 is unlinked from the variable (link flag 0).
   (The variable itself is not changed.) Prints
   `Contradiction in the view of wizard <K1 owner>: in the view of wizard <K2 owner>, wizard <W2's wizard>'s spot must be <u>`
   where u is printed as the number 1 or 2.
9. **Guess white**: for the own record in the depth-1 view, when it would-guess-white and the
   world is not done. Effect: world done := 1. Prints `Wizard <w> guesses his spot is white.`
10. **Guess black**: same with would-guess-black; prints `Wizard <w> guesses his spot is black.`

## 3. Goal and termination
Goal: world done = 1 (after a guess). Then print newline, `The problem has been solved.`, and
halt. There is no explicit failure state (if no action were available the agent would simply
stall).

## 4. Choice among actions
All proposals are indifferent unless the following preferences apply:
- Best: own-spot-unknown; complement; guess white; guess black.
- Worst: model-what-a-wizard-knows; assume black; assume white (the assume actions are worst only
  while the variable is unassigned, which is always when they are proposed).
- Assume black and assume white are each better than any model-what-a-wizard-knows.
- Among model-what-a-wizard-knows candidates:
  - reject a candidate in view K if there is another candidate in a view whose parent is K
    (go deeper first);
  - reject a candidate for wizard w if there is another candidate for a wizard w2 such that no
    view is owned by w2 yet, while some view is already owned by w (prefer wizards not yet modelled).
- Ties are broken at random. The pass-down actions have no preferences (they run before the
  worst actions and after the best ones).
No look-ahead search, no learning (chunking off), no RL, no substates, no memories.

## 5. Output (typical run, 18 decisions; which of wizards 2/3 is modelled first is random)
```
In the view of wizard 1, his own spot is unknown.
In the view of wizard 1, model what wizard 2 knows.
In the view of wizard 2, his own spot is unknown.
In the view of wizard 2, assume wizard 1's spot is black.
In the view of wizard 2, model what wizard 3 knows.
In the view of wizard 3, his own spot is unknown.
In the view of wizard 3, assume wizard 2's spot is black.
Contradiction in the view of wizard 2: in the view of wizard 3, wizard 2's spot must be 1
Contradiction in the view of wizard 1: in the view of wizard 2, wizard 1's spot must be 1
Wizard 1 guesses his spot is white.
The problem has been solved.
```
(with wizards 2 and 3 swapped in the other ordering). The messages are printed without newlines
between them except before the final line.
Reasoning: in view 3, wizard 3 sees two black-ish spots so would know he is white; in view 2 his
record has ascribed guess 0, so it is contradictory, forcing wizard 2's spot to white in view 3;
that makes wizard 2 would-guess-white in view 2 and contradictory in view 1, forcing wizard 1's
spot to white in view 2, which flows up to wizard 1's own record in view 1.
