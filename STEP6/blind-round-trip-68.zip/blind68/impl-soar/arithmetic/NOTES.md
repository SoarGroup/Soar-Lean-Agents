# impl-soar / arithmetic — notes

Written blind from /home/claude/blind68/english/arithmetic/*.md and the Soar conventions only.
I generated the files with a scratch script (/tmp/arithgen/gen.py, not part of the deliverable).
Each variant folder can be loaded on its own. Nothing uses the world libraries. No look-ahead is
used, so selection.soar is not sourced. Each variant has its own elaborations.soar with three
rules in the style of the default rules: ^top-state, and a substate's ^name taken from its
superstate's operator.

## Choices common to all variants

- **Representation.** The top state holds `^name arithmetic ^problem <p> ^digit <g> (x10)
  ^facts <f> ^desired <d>`.
  - The problem holds `^operation ^carry ^count ^id ^generated ^column <c> (x3)`.
  - Each column holds `^position ^top ^bottom ^result ^top-gen ^bottom-gen ^done ^last`.
  - The facts are `^add-fact (^first ^second ^sum ^carry)`, `^sub-fact (^first ^second
    ^difference)`, `^inc-fact (^n ^next)` and `^ten-fact (^n ^plus10)`. They are created by the
    initialize operator's application, which is generated as one large RHS.
  - The desired state is `(<d> ^count 0)`.
- **Proposals.** Every operator is proposed with `+ =`. There is one proposal rule per
  operation and per digit-rule case.
- **Setting values.** A value is set with a single action `(^x <old> - <new>)`. I checked that
  in Soar 9.6 this keeps the WME when old = new. This mattered for chunking:
  - My first version split each update into "changes"/"same" rules.
  - That produced over-general chunks: a chunk lost its dependency on facts that were not tested
    when the value happened to stay the same.
  - About 20% of answers were wrong before I removed the split.
- **Results of a column.** One write-result rule sets the column result, the done mark, the
  problem carry, and prints the column line. The printed line is not in the chunk, so a column
  solved by a learned rule prints nothing (as the English says).
- **End of run.** At the goal the agent prints a newline, `The problem has been solved.`, then
  an extra line `TASK-RESULT: success` (the runner protocol), then `(halt)`. The extra line is
  the only addition to the specified output.
- **Settings.** Chunking is `chunk always` plus `chunk add-osk on` where the English says
  chunking is on.

## Variants

**arithmetic** (base). Count 10000, so every run is ended by the 3000-decision cap (expected).
- Answers verified by a checker on every printed problem line: 0 wrong in 1815 problems
  (20000 decisions), 0 wrong in each seed.
- 6–8 general chunks are learned. After about 3 problems, almost all columns are solved without
  a substate.
- Runner: load OK, 0 errors, no halt (cap), as the English expects.

**addition** (35 + 96, two columns, counter 4).
- Output matches the expected run exactly. It halts with success.
- Episodes 2–3 (after init-soar, chunks kept) solve the problem in 4 decisions and print no
  column lines.

**subtraction** (207 − 178).
- Output matches the expected run exactly (`... answer 029 carry 0`). It halts with success.

**arithmetic-smem** (count 1000; facts in semantic memory, chunking off).
- Facts are preloaded with `smem --add`, each with `^kind add-fact|sub-fact|inc-fact|ten-fact`.
- Each fact operator first places `^query` on its own state's `^smem.command` (only when no
  query exists). The rule that applies the fact tests `^result.success <q>` and the retrieved
  fact, then removes the query.
- Subtract-digits is proposed on d1 >= d2 (no fact test).
- Answers are correct (631 problems checked). Every column prints. The run ends at the cap.

**arithmetic-smem-chunk** (count 10000; smem plus chunking).
- Same rules as smem, with chunking on.
- 260–270 chunks in the first 3000 decisions, rising to about 400 over 3 episodes. Learned
  rules are specific to digit values, as the English predicts.
- 0 wrong in 1604 problems. Column lines appear only for situations not yet learned.

**arithmetic-smem-learn** (count 2000; only the increment and plus-ten facts preloaded).
- **Failed retrieval.** The rule removes the query and records `(<s> ^query-failed <op>)` so the
  query is not reissued for that selection. The operator then has no application, which gives
  a no-change substate.
- **Counting substates** (add-digits and subtract-digits) run init, count, store and done as
  described.
  - Their init operator is gated on the `^query-failed` mark, because Soar also opens a
    (short-lived) substate while a retrieval is pending.
  - Add stores two facts (d1,d2) and (d2,d1), using mod and div on the sum. Subtract stores
    one fact.
- **Deviation:** the English says the store steps match ANY WM object with first/second
  numbers. Soar conditions must be linked to the state, so my store rules read d1/d2 from the
  superstate (the column state). In practice the result is the same, as the English notes.
- Stray `@` characters appear in the output on stores (Soar prints them on smem store). They
  appear only for pairs not yet learned: 238 of 1761 columns.
- 0 wrong in 587 problems. A test with count 5 (in /tmp) halts with
  `The problem has been solved.`

**arithmetic-solve-problem** (count 10; extra level; `chunk bottom-only on`).
- Solve-problem has no application. It is proposed when the counter is 6 and column 3 is not
  done.
- Its substate gets ^problem and ^facts by elaboration and proposes process-column with the
  base rule. Finish-problem stays at the top level.
- All 9 episodes halt with success in 91–157 decisions, with 10–14 chunks. Answers are correct,
  and later problems skip column substates.

**arithmetic-v5** (carry added to the top digit; borrowing by crossing out).
- Columns have `^working-top`, which is also set by generate-top-digit.
- The process-column local values are as described. A carry is applied through a get-top-digit
  substate with an add-carry operator, using the addition fact for (d1, 1).
- One borrow-from proposal serves both the column state and lender states.
- **Addition:** the lender state's local values are created by an `init-lender` operator. The
  English only says "has local values"; I used an operator because d1 and ten-added change
  later.
- The lender reads the lender column's ORIGINAL top, as specified. Its operators are take-one,
  write-borrow and add-ten-up.
- A fixed test of 900 − 862 (scratch copy in /tmp) gives
  `column 1 op 2: 0 2 -> 8 carry 0column 2 op 2: 0 6 -> 3 carry 0problem op 2 top 900 bottom 862 answer 038 carry 0`.
  Column 3 had already been learned by chunking, so it does not print.
- 0 wrong in 1813 random problems. 19–21 chunks. The run ends at the cap (count 10000).

## Things I could not do / open points

- The base, v5, smem, smem-chunk and smem-learn variants have counts (10000/1000/2000) that are
  far beyond the 3000-decision cap. Their goal/halt path was checked only on the fixed variants,
  on solve-problem, and on a reduced-count copy of smem-learn.
- I cannot check that chunk counts match the originals; only their qualitative behaviour (few
  general chunks for the WM-fact variants, hundreds of value-specific chunks for smem-chunk).
