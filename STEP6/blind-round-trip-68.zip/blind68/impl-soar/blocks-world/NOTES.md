# impl-soar / blocks-world — notes

All 14 variants load with no errors. Each folder has `<variant>.soar` (settings plus `source` lines)
and the rule files it sources. Variants that use look-ahead source
`/home/claude/blind68/lib/soar-default/selection.soar` by absolute path. The world libraries are not used.
Tests: `run.py <dir> <variant>.soar --seeds 1-3 --episodes 3 --cap 3000`.

## Choices common to all variants
- **Representation.** The top state has `^name blocks-world`, `^object` for the table and for each block, and `^desired`. Each object has `^name` and `^table yes|no`, and each block has `^on <object>`. The goal is a list of facts `^desired.goal (^block X ^on Y)`, compared by name. Derived `^in-place yes`, `^clear yes` and `^free yes` live on the objects. A move is `(<o> ^name move-block ^moving-block <b> ^destination <d>)`.
- **Initialisation.** The initialization operator `initialize-blocks-world` is proposed when the top state has `^superstate nil -^name`.
- **Goal test.** The goal test elaborates `(<s> ^success <desired>)`. A top-state monitor rule then prints a blank line, `The problem has been solved.`, and a line `TASK-RESULT: success` (required by the runner protocol; the English names only the first line), then halts. Where the selection library is loaded, its `top-goal*halt*success` also halts. No variant has failure states, so `TASK-RESULT: failure` is never printed.
- **Rewards.** Reward is i-supported: `(<rl> ^reward.value v)` on the `^reward-link` of the state named in the English.
- **RL settings** (rl, look-ahead-state-eval, hrl, hrl-3level): `rl --set learning on`, learning-rate 0.3, discount-rate 0.9, `indifferent-selection --epsilon-greedy`, epsilon 0.1. Everything else stays at Soar 9.6 defaults (SARSA, no traces). Q-tables indexed by "situation + move" are `:template` rules with value 0, so entries are created as new combinations are met. The terminal reward is collected at `init-soar` (Soar's terminal update); I checked that values become non-zero.

## Per variant
- **simple** (5 blocks), **simple-3**, **random.** Followed the English directly. Moves are proposed `+ =`. "Build on what is finished" is a binary `>` against every other candidate, and "not-in-place onto the table" is a unary best. random has no control rules, but the in-place facts are still computed. Results: simple 7–8 decisions, simple-3 4, random 9–129. All 27 episodes succeed.
- **rl** (4 blocks). Moves are proposed `+ =` and one RL template supplies the values. The template's conditions are the support name of each of A–D, plus the moved block's name and table flag and the destination's name and table flag. Reward +1 in the top state on success. All episodes succeed, and ~800–1100 RL rules are created per seed.
- **look-ahead.**
  - Setup: no indifference on proposals. The `^problem-space` has default state and operator copy, `^two-level-attributes object`, `^one-level-attributes last-move` (so the copy inherits the parent's last move) and `^dont-copy in-place`. The ancestor list is not copied.
  - Last move: `^last-move (^block name ^destination name)` is created or replaced by the move's application rules.
  - No repeated block: a reject for a move of the last-moved block, only in states with `^duplicate-of`.
  - Ancestor list: `^ancestor` elaborations (unused).
  - Learning: `chunk always`, `chunk add-osk on`.
  - My choices:
    - (a) The success test is written with positive conditions only. A nested-negation version lost its tests on the local copy objects during chunking and gave over-general chunks.
    - (b) Move proposals come in two versions, one testing `-^last-move` and one testing `^last-move <lm>`, so every real move re-proposes all legal moves as new operators. Without this, exhaustion-failure reject justifications, which test only the operator, stayed attached to operators that remained proposed, and blocked correct moves for the rest of the run.
  - Result: **partly.** Seed 1 succeeds (23, then 4, then 4 decisions, using 7 chunks). Seeds 2 and 3 cycle until the cap. Over 12 seeds, about 7 succeed.
  - Cause of the cycles: the default `selection*pass-back-success` turns any deeper success into partial-success, which becomes a best preference. Chunking then learns, for example, "B on C, A on table: move B to table is best" and "all on table: move B onto C is best". These chunks cannot test that the last move was not of the same block, because the no-repeat knowledge acts only through a reject and a constraint failure in the copy. So in the real state they fire in alternation forever. I believe this follows from the described design plus the library, not from a slip in the transcription, but I could not compare with the original.
- **look-ahead-state-eval.**
  - Setup: no last-move rule, and success only at the top state. The desired has `^better higher`.
  - Evaluation: after the move is applied in the copy (tested with `^tried-tied-operator`), the copy gets 1.0 / 0.6 / 0.3 / 0. I give each value as both `^numeric-value` (so that, per the English, higher is better and equal is indifferent) and `^expected-value` (which the library turns into a numeric preference). The value rules are positive, for the same chunking reason as above.
  - Learning: chunks of the expected-value preference are RL rules (8–9 per seed) and are updated by RL.
  - Result: all episodes succeed, with 4–130 decisions, and later episodes are often 4 decisions.
- **operator-subgoaling, operator-subgoaling-chunk.**
  - Setup:
    - Proposals: every move is proposed indifferent, with no clear test.
    - Clear and in-place: computed only in the top state.
    - Blocked moves: a blocked move leads to an operator no-change substate that gets `^name blocks-world`, the parent's `^object` links (shared objects), and `^desired (^clear block ^clear dest)`. These elaborations test the superstate's selected move.
    - Preferences: as in the English. Avoid-clobbering is applied literally, so a move onto the table is also worst when the table is one of the objects to be cleared.
  - My choice: the move application is split into two rules, destination table and destination clear block (the semantics are the same). With a single rule, the chunk learned in the chunk variant was "move Y onto any clear object". It fired for the table and C at once and corrupted the state in later episodes. With the split it is "move Y onto the table", learned once (when A is moved off B) and reused.
  - Results: 5 decisions per episode without chunking. With chunking: 5 decisions, then 3, with exactly 1 chunk, as the English describes.
- **operator-subgoaling-relevant.** The goal-directed and clearing proposals follow the English, with a random choice. All succeed in 6–21 decisions.
- **hierarchical.**
  - Structure: substates are named from the superstate's operator. `^top-state` elaborations are included. The move-block, pick-up and put-down substates get `^moving-block`, `^destination` and `^gripper` from their superstate or operator.
  - Gripper rules: copied from the English. Positions and flags are 1/0, and `^holding` is not cleared on open.
  - Top-level control: the simple-variant rules.
  - Result: 42 decisions, deterministic.
- **hierarchical-lookahead.**
  - Middle level: pick-up(x) and put-down(y, d) are proposed without indifference. In the real move-block state they are carried out by bottom-level substates. In copies (`^duplicate-of`) they act in one step.
  - Copying: the move-block problem-space copies `object` and `gripper` two levels deep and `moving-block destination tower-goal` one level deep, so the library re-links them to the copied objects. I used this library identity mapping instead of a separate by-name re-link; the effect is the same. `^dont-copy clear free in-place`. Clear, free and in-place are recomputed in copies; in-place uses the tower goal through `^tower-goal`.
  - Judging copies: success and failure rules test `^tried-tied-operator` and fire only in copies.
  - Result: all succeed in 72–83 decisions.
- **hrl.**
  - Top level: move-block (dest free, no gripper condition) has an RL template over the listed features. Reward +1 at the goal.
  - Lower level: pick-up(x) and put-down(y, d) are primitives, with templates over the listed names. Rewards are +1 / −1 on the move-block substate's reward-link.
  - put-down to the block's current support only empties the gripper.
  - Result: 8 of 9 episodes succeed. Seed 1, episode 2 hits the 3000 cap while RL is still exploring; I checked that it is not stuck.
- **hrl-3level.**
  - Top level: as hierarchical.
  - Middle level: deterministic; pick-up and put-down are proposed with `+` only, since at most one is ever proposed.
  - Bottom level: up/down/above-block/close/open and up-holding/down-holding/above-dest/release, all indifferent. One RL template, whose state is named pick-up or put-down, covers operator name, task block, task dest, position, open, empty and above name.
  - Close is two application rules: a plain close, plus a grasp when the gripper is down, empty and above the task block. Release has an at-destination rule and an elsewhere rule.
  - Rewards are as described.
  - Result: all succeed in 60–190 decisions.
- **epmem.**
  - Settings and moves: `epmem --set learning on`, trigger dc, phase selection; chunking off. Moves apply only in the real (top) state, and last-move is recorded only there.
  - Library change: `evaluate-operator*elaborate*state*tried-tied-operator` is excised, and so is `...*remove*untried-tied-operator`. This library version splits the standard "tried" marking into these two rules, and with the second one kept, the look-ahead operator lost its proposal on selection and no operator no-change substate could form.
  - Episodic model, in the move-block substate under the imagined move:
    1. Elaborations build a cue mirroring the imagined state: objects with name, table flag, on-links and in-place marks, plus `^operator (^name move-block ^moving-block ^destination)` linked to the cue objects.
    2. An operator issues `^query`.
    3. A perfect match (`^graph-match 1` and `^match-cardinality` equal to `^cue-size`) leads an operator to replace the query with `^next`.
    4. `predict` changes the support of each block whose support differs in the retrieved episode (by name), and adds `^tried-tied-operator` to the imagined state. That state is then scored 3/2/1/0 as `^numeric-value`.
    5. For no perfect match, a failed query, or no next episode, `no-prediction` puts `^partial-success <desired>` and `^numeric-value 2.5` on the imagined state.
  - Behaviour: as in the library, a partial-success becomes a best preference as soon as it arrives, so a tie often ends at the first unknown move evaluated. A move already known to give 3 still wins, through the numeric comparison.
  - Result: all 9 episodes succeed in 100–414 decisions; predictions are used from episode 1 on.

## Summary of test results (seeds 1–3, 3 episodes)
| Variant | Result |
| --- | --- |
| simple, simple-3, random, rl | 9/9 each |
| look-ahead | 3/9 (cycles from over-general chunks, see above) |
| look-ahead-state-eval | 9/9 |
| operator-subgoaling, -chunk, -relevant | 9/9 each |
| hierarchical, hierarchical-lookahead | 9/9 each |
| hrl | 8/9 |
| hrl-3level | 9/9 |
| epmem | 9/9 |

No runtime errors or warnings.
