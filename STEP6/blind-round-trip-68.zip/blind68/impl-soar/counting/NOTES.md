# impl-soar / counting

All variants: initialization operator when the top state has no name; `chunk never`; success rule
at the top state prints "The problem has been solved." then `TASK-RESULT: success` and halts.
No library sourced (substate naming is a task rule testing the superstate operator's name).

## count-up
- `^counter.value` 0, desired `^value 100`. `count` proposed `+ =` while value < 100 (constant from
  the English); goal test compares counter value with the desired value.
- Tests: seeds 1-3 x 3: 101 decisions, success, halts.

## count-in-substate
- Counter value 1, desired 75000. `count-to-limit` (no application rules) -> operator no-change
  substate named count-to-limit with `^counter` elaborated from the superoperator. Local
  `^local-count` (o-supported) via init-local / increment / done; done replaces the counter value.
- Tests: with the requested cap 3000 the run is cut off (it needs ~75004 decisions). With
  --cap 80000, seeds 1-3 x 3: exactly 75004 decisions, success, halts.

## count-add-smem
- smem enabled, `smem --set learning on`, ten facts preloaded with `smem --add`
  (`^kind succ ^symbol d ^next d+1 mod 10`, digits as integers).
- Substate `add`: `^sum ^step ^local-carry ^phase`. next-sum-digit / next-step-count each issue a
  `^query (^kind succ ^symbol x)` on the substate's smem command link, then on `^success`/`^retrieved`
  update the value, flip phase and remove the query. Carry rule: separate application rule that
  fires only when the old sum was 9 and the local carry is 0. While the operator waits for the
  retrieval it stays selected, so an operator no-change substate briefly appears each time (no rules
  there; harmless).
- Tests: seeds 1-3 x 3: 41 decisions, success; final adder first 8, carry 1, second 9, done 1.
