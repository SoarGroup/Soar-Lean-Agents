# impl-soar / eight-puzzle

Generated from one script per board size (/tmp only). Representation: `^binding` objects (positions)
with `^cell` and `^tile`; cells `^name cRC` with `^cell` neighbours (4-neighbourhood); tiles
`^name 0..N`. Desired: `^binding` objects on the same cell and tile objects, plus `^better higher`.
`move-tile` proposed with `+` only (`^tile`, `^tile-binding`, `^blank-binding`); application swaps
the tiles; two application rules keep `^last-move (^tile ^from ^to)` (create / replace); a reject
rule rejects moving the last-moved tile. Success: nested negation (every desired binding present)
-> `^success <d>`; top-level rule prints the messages, the library's top-goal*halt*success halts.
Look-ahead: default selection library, problem space `^two-level-attributes binding`
(bindings copied, cells/tiles/desired shared, last-move not copied), operator copied.
Score after `^tried-tied-operator`: +1 / -1 / 0 as described, computed from the tried operator's
tile and cells. `chunk always`, `chunk add-osk on`.

## eight-puzzle
- Score as `^numeric-value`. Tests seeds 1-5 x 3: all solved; first run 19-24 decisions, later 6-10.

## eight-puzzle-expected-value
- Score as `^expected-value` (library turns it into `= value` numeric-indifferent preferences);
  `indifferent-selection --boltzmann`, temperature 25 (set explicitly, equal to the default).
- Tests: seeds 1-8 first episode: 1 solved (3822 decisions), 7 not solved within 5000; seeds 1-5 x 3
  with cap 5000: 2 of 15 episodes solved (82 and 3822 decisions). Behaviour is the described near
  random walk; I saw no sub-20 solve in these seeds. Learned chunks are numeric-indifferent rules,
  which the runner also counts as RL rules (RL learning is off, so their values never change).

## fifteen-puzzle
- 4x4, task name fifteen-puzzle, same knowledge. Tests seeds 1-3 x 3: never solved, runs to the
  3000 cap moving tiles indefinitely (no halt), as described.
