# hello-world (impl-soar)

## hello-world
Files: hello-world.soar (load), initialize-hello-world.soar, say-hello.soar, elaborations.soar.
Choices:
- Goal detection is an i-supported `^success <desired>` elaboration plus a detect rule that prints
  a newline, `The problem has been solved.`, `TASK-RESULT: success`, and halts (GOL-012/014/016).
- The halt happens in the same decision as say-hello's application, so the runner counts 2 decisions;
  the English says 3 (init, say hello, halt). The difference is only how the halt decision is counted.
Tests (seeds 1-3, 3 episodes, cap 3000): load ok, 0 errors; every episode success in 2 decisions.
Output: `Hello World` / `The problem has been solved.`
