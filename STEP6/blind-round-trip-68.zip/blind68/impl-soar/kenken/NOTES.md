# kenken (impl-soar) -- notes

All 16 variants share one program design. Each variant folder holds:
- `<variant>.soar` -- load file: chunk settings, sources `/home/claude/blind68/lib/soar-default/selection.soar`,
  `kenken-rules.soar`, then `kenken-data.soar`.
- `kenken-rules.soar` -- the same task rules in every variant (problem space, goal/failure tests, assign, cleanup,
  eliminate, drop-combination, prune, choose-guess-cell x2, guess, report-success/failure).
- `kenken-data.soar` -- generated per variant: the initialize operator (all cells, candidates, combinations,
  puzzle record, desired), the print-row proposal/application for N columns, and the report-success proposal (tests N).
`gen-kenken.py` (in this folder) generated the data files from the English puzzle-data sections (it read the rules
master from /tmp, so treat it as a record, not a build script).

## Choices where the English was open (all variants)
- Representation: cells, candidates and combinations are all state-level multi-valued attributes (`^cell`, `^candidate`,
  `^combination`); cells link to their candidates, candidates link to their combinations, and combinations link to their candidates.
  Problem space `^two-level-attributes cell candidate combination puzzle`, so the default selection copy duplicates
  every task object and redirects the links between them. That gives the deep copy the English asks for. The desired state is shared (no desired copy).
- Combination data: where the English lists the "Allowed:" combinations they are used verbatim. Some large cages have no list
  (5-5 cages 7,10; 6-1 cages 13,14; 6-2 cages 2,8,12,13; 6-3 cages 1,2,14; 6-4 cages 2,7,8). For those, the
  combinations were computed from the clue with the stated rule (the clue holds, and cells sharing a row or column differ). Each computed
  count matches the count in the English, and every listed cage matches the computation exactly. Single-cell cages have one combination.
- Goal at top: the top state never gets `^success` (the default top-goal halt would stop before printing). Print-row
  proposals test marked = desired count directly. In look-ahead copies (`^superstate <> nil`) the goal test gives
  `^success <desired>`.
- Failure: an elaboration `^failed true` covers both failure conditions. In copies it becomes `^failure <desired>`. At the top a
  `report-failure` operator (best preference) prints a newline, `Failure state: the task has failed.` and the TASK-RESULT line, then halts.
- Assign has three proposal rules (a/b/c). If more than one condition holds, duplicate indifferent operators exist. This is harmless.
- cleanup, eliminate and prune share one application rule (the candidate becomes dead).
- Choose-guess-cell operators: `+ = <` (indifferent and worst). An extra rule prefers a 2-option operator over a 3-option one.
- Guess has only an acceptable preference, so ties go to the default selection space (success becomes best, failure and exhaustion become reject, and
  partial-success passes back from nested ties).
- Print row: row string `| a | b | ... | z | `, with no newlines between messages, as section 5 says. After the last row: a newline,
  `The problem has been solved.`, a newline, `TASK-RESULT: success`, then halt.
- Chunking: `chunk always`, `chunk add-osk on`, `chunk allow-local-negations off`. No RL, SMem or EpMem.
- The ancestor-chain bookkeeping is omitted, as the English allows. No numeric parameters.

## Test results (run.py, seeds 1-3, 3 episodes, cap 3000)
All 16 variants: load_ok, 0 load errors, 31 user rules, every episode `success` and halted, 0 chunks, 0 runtime errors or warnings.
A separate trace check (seeds 1-3) confirmed that the printed rows equal the solution in the English for every variant and seed.
- Deduction only, no guesses (as observed in the English): 4-1, 4-2, 4-3, 4-4, 4-6, 4-7, 5-1..5-5, 6-4. Decisions: ~95-103 (4x4),
  ~177-191 (5x5), 474 (6-4).
- Guessing with look-ahead (as observed in the English): 4-5 (guess cell 42 or 12 depending on seed; English reports 32/42),
  6-1 (35/55/65; English reports 63), 6-3 (15/16; English reports 15), 6-2 (2-3 nested guess cells, e.g. 35,44,45; English
  reports a set from 34,35,43,44,45,54,64). The English says guess cells vary with the seed. Decisions: 4-5 ~130-150, 6-1 ~410-440,
  6-3 ~500-600, 6-2 ~580-1055 (up to ~7 s wall).
- Not exercised: top-state failure (never happens), and exhaustion-failure from a stuck copy (it did not happen in these runs).
  Both rely on the default selection rules.
