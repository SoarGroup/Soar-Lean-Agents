import re, sys, os, shutil
EN='/home/claude/blind68/english/kenken'
OUT='/home/claude/blind68/impl-soar/kenken'
RULES='/tmp/kkgen/rules.soar'
import itertools, math
NOLIST=[]
def compute(N,cells,desc):
    op,val=re.search(r'(sum|difference|product|quotient)[^=]*= (\d+)',desc).groups(); val=int(val)
    out=[]
    for vs in itertools.product(range(1,N+1),repeat=len(cells)):
        ok=all(not(vs[i]==vs[j] and (cells[i][0]==cells[j][0] or cells[i][1]==cells[j][1])) for i in range(len(cells)) for j in range(i+1,len(cells)))
        if not ok: continue
        if op=='sum': g=sum(vs)==val
        elif op=='product': g=math.prod(vs)==val
        elif op=='difference': g=max(vs)-min(vs)==val
        else: g=max(vs)==val*min(vs)
        if g: out.append(list(zip(cells,vs)))
    return out
def parse(path):
    t=open(path).read().replace('\r','')
    t=t[t.index('## Puzzle data'):]
    N=int(re.search(r'Grid size N = (\d+)',t).group(1))
    total=int(re.search(r'all cages together\): (\d+)',t).group(1))
    cages=[]
    lines=t.split('\n')
    for i,l in enumerate(lines):
        m=re.match(r'- Cage (\d+): (.*?) -- (.*)',l)
        if not m: continue
        cells=[tuple(map(int,x)) for x in re.findall(r'r(\d+)c(\d+)',m.group(2))]
        desc=m.group(3)
        sm=re.search(r'single cell, value must be (\d+)',desc)
        if sm:
            combos=[[(cells[0],int(sm.group(1)))]]
        else:
            nexp=int(re.search(r'(\d+) allowed combination',desc).group(1))
            comp=compute(N,cells,desc)
            al=lines[i+1].strip()
            if al.startswith('Allowed:'):
                combos=[]
                for grp in re.findall(r'\(([^)]*)\)',al):
                    combos.append([((int(r),int(c)),int(v)) for r,c,v in re.findall(r'r(\d+)c(\d+)=(\d+)',grp)])
                assert sorted(map(sorted,combos))==sorted(map(sorted,comp)),(path,m.group(1))
            else:
                combos=comp; NOLIST.append((path.split('/')[-1],m.group(1)))
            assert len(combos)==nexp,(path,m.group(1),len(combos),nexp)
        cages.append(combos)
    assert sum(len(c) for c in cages)==total,(path,total)
    return N,cages
def gen(name,N,cages):
    L=[]
    L.append(f'## {name}: puzzle data (generated from the English puzzle data section)')
    L.append(f'## N = {N}; {sum(len(c) for c in cages)} stored combinations in {len(cages)} cages')
    L.append('')
    L.append('sp {kenken*propose*initialize\n   (state <s> ^superstate nil\n             -^name)\n-->\n   (<s> ^operator <o> +)\n   (<o> ^name initialize-kenken)}\n')
    rhs=['   (<s> ^name kenken ^puzzle <p> ^desired <d>)',
         '   (<p> ^marked 0 ^guess-cell 0 ^rows-printed 0)',
         f'   (<d> ^marked {N*N})']
    # combos per candidate
    cand_combos={}
    cid=0; combo_lines=[]
    for cg in cages:
        for cb in cg:
            cid+=1
            ks=' '.join(f'<k{r}{c}v{v}>' for (r,c),v in cb)
            combo_lines.append(f'   (<s> ^combination <cb{cid}>) (<cb{cid}> ^alive 1 ^candidate {ks})')
            for (r,c),v in cb: cand_combos.setdefault((r,c,v),[]).append(f'<cb{cid}>')
    for r in range(1,N+1):
        for c in range(1,N+1):
            code=c*10+r
            ks=' '.join(f'<k{r}{c}v{v}>' for v in range(1,N+1))
            rhs.append(f'   (<s> ^cell <c{r}{c}>) (<c{r}{c}> ^row {r} ^col {c} ^code {code} ^mark 0 ^candidate {ks})')
            for v in range(1,N+1):
                cbs=cand_combos.get((r,c,v),[])
                extra=(' ^combination '+' '.join(cbs)) if cbs else ''
                rhs.append(f'   (<s> ^candidate <k{r}{c}v{v}>) (<k{r}{c}v{v}> ^row {r} ^col {c} ^code {code} ^value {v} ^alive 1{extra})')
    rhs+=combo_lines
    L.append('sp {kenken*apply*initialize\n   (state <s> ^operator.name initialize-kenken)\n-->\n'+'\n'.join(rhs)+'}\n')
    # print row
    L.append(f'sp {{kenken*propose*print-row\n   (state <s> ^name kenken\n              ^superstate nil\n              ^desired <d>\n              ^puzzle <p>)\n   (<d> ^marked <n>)\n   (<p> ^marked <n>\n        ^rows-printed {{ < {N} <rp> }})\n-->\n   (<s> ^operator <o> + =)\n   (<o> ^name print-row\n        ^row (+ <rp> 1))}}\n')
    conds='\n'.join(f'   (<c{c}> ^row <r> ^col {c} ^mark <m{c}>)' for c in range(1,N+1))
    cells=' '.join(f'<c{c}>' for c in range(1,N+1))
    w=' '.join(f'<m{c}> | \\| |' for c in range(1,N+1))
    L.append(f'sp {{kenken*apply*print-row\n   (state <s> ^operator <o>\n              ^puzzle <p>\n              ^cell {cells})\n   (<o> ^name print-row\n        ^row <r>)\n   (<p> ^rows-printed <rp>)\n{conds}\n-->\n   (<p> ^rows-printed <rp> -\n        ^rows-printed <r>)\n   (write |\\| | {w})}}\n')
    L.append(f'sp {{kenken*propose*report-success\n   (state <s> ^name kenken\n              ^superstate nil\n              ^desired <d>\n              ^puzzle <p>)\n   (<d> ^marked <n>)\n   (<p> ^marked <n>\n        ^rows-printed {N})\n-->\n   (<s> ^operator <o> + =)\n   (<o> ^name report-success)}}\n')
    return '\n'.join(L)
for f in sorted(os.listdir(EN)):
    name=f[:-3]; N,cages=parse(os.path.join(EN,f))
    d=os.path.join(OUT,name); os.makedirs(d,exist_ok=True)
    open(os.path.join(d,'kenken-data.soar'),'w').write(gen(name,N,cages))
    shutil.copy(RULES,os.path.join(d,'kenken-rules.soar'))
    open(os.path.join(d,name+'.soar'),'w').write(f'''## {name}: KenKen solver (N = {N}). Load file.
## Chunking on in all states, operator-selection knowledge in chunks, no chunks over local negations.
chunk always
chunk add-osk on
chunk allow-local-negations off

## Look-ahead: Soar default selection rules
source /home/claude/blind68/lib/soar-default/selection.soar

source kenken-rules.soar
source kenken-data.soar
''')
    print(name,N,sum(len(c) for c in cages))
print('computed (no Allowed list):',NOLIST)
