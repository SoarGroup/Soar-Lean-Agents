# left-right (impl-soar)

## left-right
Files: left-right.soar (settings: chunk never; rl learning on, learning-rate 0.3, discount-rate
0.9; indifferent-selection --epsilon-greedy with the default epsilon 0.1; default SARSA),
initialize-left-right.soar, move.soar, elaborations.soar.
Choices:
- One proposal rule per direction value (OPR-016), each with acceptable + indifferent preference.
- RL rules: generated with gp for direction -1/1 at location 0 / moved 0. The English says the
  Q-values are keyed on direction, location and moved, "in practice only location 0 / moved 0";
  since moves are only proposed at location 0 / moved 0, only these two rules can ever match.
  I first used a :template rule; Soar created duplicate instance rules across init-soar (values
  split between duplicates), so I switched to gp (RL-020).
- Rewards are i-supported elaborations on the reward-link (-1 at location -1, +1 at location 1).
- The final RL update of an episode happens when the runner does init-soar (Soar performs the
  terminal update then); the agent halts in the same decision as the move.
Tests: load ok, 0 errors, 2 RL rules; every episode success in 2 decisions. Checked values: after
one left move the left rule is -0.3, after one right move +0.3 (0.51 after two); over 40 episodes
(seed 2) the agent moved right 38 times, right value ~1.0.
