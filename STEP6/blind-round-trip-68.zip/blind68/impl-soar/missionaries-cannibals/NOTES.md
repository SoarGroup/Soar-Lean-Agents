# impl-soar / missionaries-cannibals

Common representation (all four variants): top state `^name mac`, two banks on the multi-valued
attribute `^bank` (`^name left|right ^missionaries ^cannibals ^boat 1|0 ^other-bank`), desired
`(<d> ^bank <db>) (<db> ^name right ^missionaries 3 ^cannibals 3)`. Initialization operator
`initialize-mac` proposed when the top state has no name. Five proposal rules for `move-boat`
(one per load, load as constants `^missionaries ^cannibals` on the operator plus `^bank` = departure
bank), one general application rule. Success/failure are i-supported elaborations
(`^success <d>` / `^failure <d>`); top-level detection rules print the English message, then a line
`TASK-RESULT: success|failure`, and halt.

## mac
- Choices: proposals `+ =`. Soar 9.6.50's default indifferent-selection policy is softmax; with no
  numeric preferences that is a uniform random choice, so the default policy was kept. `chunk never`.
- Tests (seeds 1-3 x 3 episodes): all 9 episodes end in failure after 2-4 decisions, as described.

## mac-rl
- Choices: proposals `+ =`; value function is one `:template` RL rule keyed on load (m, c),
  departure bank (name, m, c, boat) and arrival bank (name, m, c, boat), value 0 on creation.
  Rewards are three i-supported reward-link elaborations (-0.01 always, +1 on success, -1 on
  failure; summed). Settings: `rl learning on`, learning-rate 0.1, discount-rate 0.5, sarsa,
  eligibility-trace-decay-rate 0, `indifferent-selection --epsilon-greedy`, epsilon 0.1, chunk never.
- Halting on failure happens in the same elaboration as the failure reward, so the terminal reward
  never reaches the last move's value (consistent with "does not learn to solve").
- Tests: seeds 1-3 x 3 episodes: all failures, 2-7 decisions. Extra 10-episode runs: still all
  failures, episodes grow somewhat longer (up to ~100 decisions) as unsafe moves get negative values.
  (The runner's `rl_rules` count includes non-rule lines of `print --rl`; ~190 template instances.)

## mac-look-ahead
- Proposals `+` only (ties). Default selection library (lib/soar-default/selection.soar);
  `chunk always`, `chunk add-osk on`.
- Problem space: `^default-state-copy yes ^default-operator-copy yes ^two-level-attributes bank`
  (banks copied with other-bank remapped to the copies; desired shared; nothing else copied).
- Enclosing-state record: `^superstate-set` elaborated on every task state below the top from the
  task state two levels up (through the selection state) plus that state's set; not copied.
  Duplicate test fires only after `^tried-tied-operator` (after the tried move applied), comparing
  name/missionaries/cannibals/boat of both banks; it marks `^failure <d>`.
- Exhaustion failure, partial success, best/reject/indifferent all come from the library.
- Tests: seeds 1-3: seed 2 solved (92 decisions, then 12 with learned chunks); seeds 1 and 3 loop at
  the top level until the 3000 cap in all episodes (no halt). Seeds 1-8: 4 solved, 4 loop. The
  loop is the described one (learned chunks with success/partial-success conclusions cycle among
  top-level states); the solve rate is higher than the English's "1 in 8", which is seed-dependent.
- Bug fixed during testing: the first version did not propagate the record through the selection
  state, so repeats were never detected and the search hit Soar's goal-depth limit (100) and halted.

## mac-look-ahead-numeric
- As mac-look-ahead plus `^better higher` on the desired and an elaboration giving the look-ahead
  state `^numeric-value (+ right-missionaries right-cannibals)` once `^tried-tied-operator` is
  present (so evaluation finishes after one move). Library rules turn it into better/indifferent
  preferences; success->best and failure->reject override.
- Tests: seeds 1-5: all solved; first episode 125-136 decisions, later episodes 12-57.
