# pyramid (impl-soar)

## pyramid
Files: pyramid.soar, initialize-pyramid.soar, add-next-term.soar, elaborations.soar.
Choices: goal as `^desired.pyramid.height -1` matched against the pyramid; success elaboration +
detect rule (prints answer, solved line, TASK-RESULT, halt).
Tests: load ok, 0 errors; success, 12 decisions per episode. Output exactly
` + 5 + 4 + 3 + 2 + 1 + 0 + -1 + -2 + -3 + -4 + -5` / `The answer is 0.` / solved line.

## pyramid-anderson
Same program with term 5, height 2. Tests: success, 4 decisions; output ` + 5 + 4 + 3`,
`The answer is 12.`

## pyramid-hierarchical
Files: pyramid-hierarchical.soar; elaborations.soar (substate name = superoperator name,
^top-state, sub-goals get ^pyramid from the superstate, goal detection);
initialize-pyramid-hierarchical.soar; expand-pyramid.soar, sum-terms.soar (abstract operators, no
application rules); expand-pyramid/expand-next-term.soar; sum-terms/{elaborations,initialise-local,
add-term,final-sum}.soar.
Choices:
- Expand-pyramid is proposed through a relevance elaboration `^expand-pyramid-relevant true`
  (OPR-017) so the selected operator keeps its identity while expand-next-term changes height; it
  still "ends automatically when height reaches -1" because the elaboration retracts.
- Term records live on the top state as `^term-record` (index, value); the sum-terms sub-goal sees
  them through an elaboration. Local sum and next index are o-supported WMEs on the sub-goal.
- Initialise-local tests the absence of a local sum on the substate (local negation; chunking is
  off so it does not matter for learning).
Tests: load ok, 0 errors; success, 21 decisions (1 init, 1+7 expand, 1+1+7+1 sum, plus substate
creation); output ` + 10 + 9 + 8 + 7 + 6 + 5 + 4`, `The answer is 49.`
