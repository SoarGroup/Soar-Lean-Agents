# tictactoe (impl-soar)

## tictactoe
Files: tictactoe.soar, initialize-tictactoe.soar (9 cells, 8 lines, game record, desired
game.over 1; generated text), monitor.soar, mark-cell.soar, win.soar, detect-draw.soar,
elaborations.soar.
Choices:
- Board monitor: i-supported `^symbol` elaborations per cell (` `, `X`, `O`) plus one monitor rule
  matching all nine symbols; it re-fires whenever any cell changes and once at the start
  (monitor rules are allowed by IO-018). Format as in the English, 5 leading spaces, rows y=1..3.
- Result line (`Side X won.` / `Side O won.` / `Draw.`) is written after a newline because the
  board printout ends without one; then newline + `The problem has been solved.`
- X-wins / O-wins are proposed with acceptable, indifferent and best; mark and draw indifferent.
Tests: load ok, 0 errors; all episodes success (7-11 decisions). Over 30 seeds: 20 X wins,
8 O wins, 2 draws.
