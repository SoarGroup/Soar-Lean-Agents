# towers-of-hanoi (impl-soar)

Shared representation: `^peg` (name A/B/C), `^disk` (name, size; bases size 6), `^ground` (size 7),
position records `^on` (disk, peg, above), `^control` (last-moved-size, smallest-last-source),
`^desired.on` records (disk 1-5 on peg C). Clear = derived `(<s> ^clear <d>)` when no record has
`^above <d>`. Success = every desired on-record is matched by an actual one (nested negation).

## towers-of-hanoi
Files: towers-of-hanoi.soar, initialize-towers-of-hanoi.soar, elaborations.soar, move-disk.soar.
Choices: two proposal rules (case 1 smallest disk, case 2 other disk), one shared application
rule for the move plus one control-update rule per case. All proposals indifferent.
Tests: load ok, 0 errors; success in 32 decisions every episode; the printed sequence is exactly
the 31-move optimal sequence given in the English.

## towers-of-hanoi-mea
Files: towers-of-hanoi-mea.soar, initialize-towers-of-hanoi.soar (same as the other variant,
including the unused control record), elaborations.soar (substate naming, clear, goal),
move-disk.soar (top-level proposal + the legality-guarded application rule used at every level),
move-disk/elaborations.soar (sub-goal shares ^on/^peg/^disk with its superstate; its goal
`^goal-disk`/`^goal-peg` comes from the blocked superoperator), move-disk/propose.soar
(clear-disk and clear-destination proposals).
Choices:
- The application rule is the only test of legality; an illegal selected move simply has no
  matching application rule, so Soar creates an operator no-change sub-state named move-disk.
- Sub-goal moves change the shared position records (results); when the blocked move becomes
  legal its application fires in the state where it was selected and the sub-state goes away.
- Operators carry `^reason-disk` as described; nothing tests it.
Tests: load ok, 0 errors; success in 47 decisions (English: about 48); printed sequence identical
to the 31-move optimal solution.
