# impl-soar / water-jug — notes

Soar 9.6.50 via soar_sml. Each variant folder has `<variant>.soar` (settings + `source` of
local rule files). Only look-ahead variants source the default selection library, by absolute
path `/home/claude/blind68/lib/soar-default/selection.soar`. Every variant prints
"The problem has been solved." then `TASK-RESULT: success` and halts at the top-state goal.
Choices common to all variants:
- Representation (tutorial style): `^jug <j>` with `^volume ^contents`, derived `^free`;
  `^desired.jug` (volume 3, contents 1). fill: `^fill-jug`; empty: `^empty-jug`;
  pour: `^empty-jug` (from) `^fill-jug` (to).
- Goal test compares a state jug with the desired jug (volume and contents), not hard-coded.
- No failure condition exists, so `TASK-RESULT: failure` is never printed; a run that does not
  solve is ended by the runner cap.

Test command: `run.py <abs dir> <variant>.soar --seeds 1-3 --episodes 3 --cap 3000`.
(The runner needs an absolute directory; it chdirs once per seed.) No load errors, no runtime
errors or warnings in any variant. Results below as decisions per episode (seed 1 / 2 / 3).

## water-jug
- `chunk never`; proposals `+ =`; Soar's default indifferent selection (softmax) with only
  plain indifferent preferences = uniform random.
- Tests: all 9 episodes solved; 68–363 decisions.

## water-jug-rl
- Proposals kept `+ =` (as stated). Q-values from three `:template` rules (fill / empty keyed on
  that jug's volume+contents; pour keyed on both jugs' volume+contents), initial value 0.
- Rewards: i-supported `^reward-link.reward.value` -1 (both empty, incl. initial state) and +1
  (goal). `rl --set learning on`, learning-rate 0.1, discount-rate 0.5, other RL defaults
  (sarsa, no traces); `indifferent-selection --epsilon-greedy` (default epsilon 0.1, checked).
- Tests: all solved; first episodes 432 / 81 / 22, later ones 5–52. 46–53 RL rules created.

## water-jug-hierarchy
- `^holding <jug>` on the top state; "holds nothing" = no `^holding` WME (put-down removes it).
- Choice: "fill-relevant" is an elaborated flag `(<jug> ^fill-relevant true)` from two rules
  (not full; full and held), and a single fill proposal tests it. A first version with two
  separate fill proposal rules failed: when the jug became full the not-full proposal retracted
  and the held one created a *new* fill instance, so the original fill was deselected, the
  random choice could pick another operator and the agent stayed holding the jug forever. The
  single flag keeps the same fill instance selected through pick-up / fill-jug / put-down.
- Substate naming: the default library here has no `elaborate*state*name`, so I added one
  (operator no-change substate named after the superstate operator); the fill substate gets
  `^fill-jug` from the superstate operator. Sub-operators `+ =`.
- Tests: all solved; 25–789 decisions.

## water-jug-hierarchy-chunk
- Same files, `chunk always`. Soar 9.6 has no separate "o-support chunks" switch; o-supported
  chunks are learned by default (recorded here as the interpretation).
- Exactly the three described chunks are learned in the first fill (pick-up: fill selected and
  no holding -> hold; fill-jug: held and free > 0 -> contents := volume, old contents removed;
  put-down: held and free <= 0 -> remove holding). Later fills run at the top level.
- Tests: all solved; 3 chunks; 9–293 decisions.

## water-jug-tie
- Proposals `+` only. Initial `^last-operator none`; an application rule on the top state
  replaces it with the selected task operator's name (fires alongside the operator's own
  application).
- Tie substate (`^impasse tie`, superstate named water-jug) named `water-jug-tie` (name not
  given in English); copies last-operator; one `^evaluation` (with `^operator`) per `^item`.
  `evaluate` operators `+ =`; five value rules written so that their conditions are exactly the
  English cases (last none: any; last pour: fill/empty -> equal, pour -> worst; last fill/empty:
  pour -> best, fill/empty -> worst). `create-preferences` proposed when no evaluation lacks a
  value, with `>` over evaluate; it creates `=`, `< =`, `> =` on the superstate operators.
- Tests: all solved; 26–263 decisions; tie substate entered at each tie.

## water-jug-tie-chunk
- Same files, `chunk always` (same o-support remark as above).
- Exactly the five generalised chunks described are learned (last none -> =; last pour &
  fill/empty -> =; last pour & pour -> < =; last fill/empty & pour -> > =; last fill/empty &
  fill/empty -> < =); after that no ties.
- Tests: all solved; 5 chunks; 8–53 decisions.

## water-jug-look-ahead
- Proposals `+` only. Problem space: `^name water-jug ^default-state-copy yes
  ^default-operator-copy yes ^two-level-attributes jug ^dont-copy free ^dont-copy
  superstate-set`.
- Ancestor list `^superstate-set` (superstate, plus the superstate's set); includes selection
  states, but the duplicate test only compares with ancestors named water-jug. The "up to 20
  ancestors / 3 jugs" limits are not a Soar setting; nothing enforces them (not reached).
- Success elaboration `^success <desired>` on any water-jug state; duplicate test (contents of
  the 3- and 5-jug equal an ancestor's, after `^tried-tied-operator`) -> `^partial-failure`.
  Top-state rule prints the message + TASK-RESULT and halts (default top-goal rule also halts).
- `chunk always`.
- Tests: all solved; first episodes 763 / 98 / 76 decisions (307 / 53 / 43 chunks), later
  episodes 7–15. The endless cycle mentioned in the English did not occur in these seeds.

## water-jug-look-ahead-failure-states
- As look-ahead, plus both-full and both-empty partial-failure rules (simulated states only,
  after the tried operator).
- Tests: all solved; first episodes 244 / 109 / 97, later 7–13 decisions.

## water-jug-look-ahead-rl
- As look-ahead, plus both-full / both-empty -> `^expected-value -1` on the simulated state
  (the library converts it to `= -1` and passes it up discounted by 0.9). No reward rules, no
  hand-written RL rules; RL on, rate 0.1, discount 0.5, epsilon-greedy (0.1).
- RL rules arise only as chunks of `selection*evaluation*expected-values` (10–22 per seed), and
  RL updates their values (seen drifting from -1 toward 0).
- Tests: seed 1: 145 / 7 / 17 solved; seed 2: 309 / 1174 solved, third episode NOT solved
  within 3000 decisions; seed 3: 629 / 1449 / 376 solved. This matches the behaviour the English
  reports (long wandering, seed 2 episode 3 unsolved).
