# wizards (impl-soar)

## wizards
Files: wizards.soar, initialize-wizards.soar, derived-knowledge.soar, own-spot-unknown.soar,
model-wizard.soar, pass-down.soar, assume.soar, complement.soar, guess.soar, selection.soar,
elaborations.soar.
Representation: top state ^world (done, views), ^view (id, owner, depth, parent, ^record),
records (view back-link, wizard, mark, linked, unknown link, modelled, optional guess, siblings,
down), ^unknown (value, untried 1/2, assigned-view). Colours 1 white, 2 black.
Choices:
- "Own" is a derived record attribute; white/black/blackish/would-guess-*/contradictory are
  i-supported elaborations exactly as listed (recursion via ^down is stratified by depth).
- Unlinking in complement sets linked 0 and removes the ^unknown link.
- All proposals are indifferent; best = own-spot-unknown, complement, guesses; worst =
  model-wizard and assume-*; assume > model; the two model rejections are reject preferences.
- Messages are written without newlines between them ("printed without newlines between them
  except before the final line"); the English example shows them on separate lines for reading.
- As written, pass-down-unknown can re-link a record just unlinked by complement; in the actual
  run those proposals are never selected because a best operator is always present then. I did
  not add a guard the English does not give.
Tests: load ok, 0 errors; every episode success in exactly 18 decisions; the message sequence
matches the English, with wizard 2 or 3 modelled first depending on the seed.
