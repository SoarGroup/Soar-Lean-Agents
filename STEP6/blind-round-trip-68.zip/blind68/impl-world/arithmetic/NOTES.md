# arithmetic family: impl-world notes

All eight variants are built on agent-world (/home/claude/blind68/lib/world). Each variant folder
holds its own load file `<variant>.soar` and the rule files that it sources.

## Common design (applies to every variant)

- **Libraries.** Each variant loads `agent-world.soar` and `simple.soar` only. No English variant
  asks for search (every choice is indifferent or random), so selection-world and
  selection-iterative-deepening are not loaded. A second reason: selection-world's top-state
  success rule writes `<name> achieved - success` and interrupts, which would add text to the
  exact outputs. lib/soar-default is not used.
- **Initialisation.** agent-world's initialize-agent-world runs first. The task's
  `initialize-arithmetic` (`^task-operator false`) tests `^world` and then sets the top state's
  `^name arithmetic`, `^problem-space` (`^name arithmetic ^agent-world true`), `^flags`
  (`mea-operator-selection false`, `look-ahead-planning false`) and `^desireds`. agent-world keeps
  proposing its own init (+ >) until the top state has a name, so one rule prefers the task init
  over it. Without that rule, decision 2 is a tie.
- **World.** `^world.objects.object` holds the problem (handle `problem`: operation, carry, count,
  problem-id, digits-generated), the columns (`column1..3`: position, top, bottom, result,
  top-generated, bottom-generated, done, last, plus `working-top` in v5) and the ten digit
  objects (`digit0..9`, `^value`). Every object has `^anchored true` and a `^category`. The
  "generated for problem id" and "done for problem id" marks hold the problem id they were set
  for, as the English describes.
- **Fact tables** (WM variants). The fact tables are ordinary WM objects on the top state under
  `^facts` (`add-fact`, `sub-fact`, `inc-fact`, `ten-fact`), created by a second apply rule of
  the init operator (`facts.soar`, generated). They are treated as agent knowledge, not as world
  situation, so they are not under `^world`.
- **Goal.** `^desireds` has `^desired-count 1` and an object-property desired: `problem ^count 0`.
  Task elaborations add `^achieved` and `^unachieved` (W-DBK-002). agent-world then adds
  `^success <desireds>`, and the task operator `report-success` (best, `^task-operator false`)
  writes a newline, `The problem has been solved.`, a newline, `TASK-RESULT: success`, and halts.
  The English has no failure states, so the program never prints a failure line.
- **Task operators.** These are choose-operation, generate-top-digit, generate-bottom-digit,
  process-column (plus solve-problem in that variant) and finish-problem. Each carries
  `^task-operator true`, `^argument1..N`, `^argument-count`, `^super-desired` (the count desired)
  and `^desireds` with `^desired-count 0`. Each is proposed with an indifferent preference (`+ =`).
  - **Proposals are not MEA.** The English gives explicit applicability conditions, so the
    proposals test those conditions directly and do not use MEA (mea-operator-selection is false).
  - **Actions apply internally.** The English says there is no external world. So the operators
    have no `^action-handle`, issue no output-link commands, and their application rules
    (testing `^pre-conditions-satisfied true`) change `^world` directly.
  - **Column substates.** process-column has no application rule and implements itself in an
    operator no-change substate. agent-world copies the operator's `^column` onto that substate,
    which is how the substate knows its column. The substate operators (init-local,
    get-bottom-digit/increment, add-digits, borrow/add-ten, subtract-digits, write-result) keep
    their local values on the substate. They act on the shared `^world`, as the English
    describes.
- **Random choice.** Indifferent selection is used, with no numeric preferences, so each choice
  is uniform among the proposed instances. That covers the operation, every column×digit
  candidate and the order of digit generation. agent-world's `_flags` sets
  `decide indifferent-selection -e`, but the effective policy stays softmax, and with no numeric
  values that is uniform.
- **Chunking** (where the English has it on): `chunk always` and `chunk add-osk on`. The learned
  rules are general because they test the WM fact objects, and they include the `-` removals.
  Columns solved by a learned rule print no column line, as specified.
- **Choices outside the English:**
  - `output agent-logs 1 off` turns off agent-world's `(log 1 ...)` monitor lines
    (`Select <op>: <handle>`), which would otherwise mix into the specified output.
  - `production optimize-attribute add-fact 110 / sub-fact 165 / inc-fact 10 / ten-fact 10` hints
    the condition reorderer. Without it, some learned rules joined fact objects to each other
    before binding the columns, giving up to 1.5M partial matches. v5 then ran at about
    6–28 ms per decision; with the hint it runs at about 0.4 ms. This changes speed only, not
    behaviour.
- **Runner and end condition.** The runner's environment does nothing here because no output
  commands are issued. Count 10000/2000/1000 is far beyond the 3000-decision cap, so those runs
  end at the cap with `result: null`, as the English expects ("far beyond typical decision caps").
  I ran those variants to completion separately (see below).

Checking: a script parsed every `problem op ...` line and recomputed the answer, with the final
carry as the extra leading digit for addition and always 0 for subtraction. **No wrong answer
was found in any variant.**

## Per variant

### arithmetic (base)
- Count 10000, three columns, chunking on.
- Runner: all 9 episodes ran without errors and stopped at the 3000 cap. Each run learned
  8 rules, and episodes 2 and 3 reuse them.
- Full run (srand 1): 10000 problems, 0 wrong, 6 column lines printed in total (8 rules learned
  early on), op1 4908 and op2 5092. It then printed `The problem has been solved.` and
  `TASK-RESULT: success` and halted at 110036 decisions.
- **Works.**

### addition (35 + 96)
- Two columns; counter 4 for process-column and finish-problem; finish requires columns 1 and 2
  done; two-digit problem line.
- Output matches the expected run exactly:
  `column 1 op 1: 5 6 -> 1 carry 1column 2 op 1: 3 9 -> 3 carry 1problem op 1 top 35 bottom 96 answer 31 carry 1`,
  then newline and `The problem has been solved.`, then my `TASK-RESULT: success` line, then halt.
- Runner: success on all 9 episodes (17 decisions, then 6 in later episodes because the learned
  rules skip the substates).
- **Works.**

### subtraction (207 − 178)
- Output matches the expected run exactly, including the borrows in columns 1 and 2 and
  `answer 029 carry 0`.
- Runner: success on all 9 episodes (27 decisions, then 7).
- **Works.**

### arithmetic-solve-problem
- Count 10. The top level has solve-problem instead of process-column: it is proposed when the
  counter is 6 and column 3 is not done. In the solve-problem substate, process-column is
  proposed as in the base, and the process-column substate is the same as the base.
- When column 3 is done, solve-problem retracts and finish-problem applies at the top level.
- `chunk bottom-only on` is added.
- In the solve-problem substate, process-column's `^super-desired` comes from
  `^top-state.desireds`, because the substate's own desireds are agent-world's count-0 copy.
- Runner: success on all 9 episodes (about 150 decisions, then about 95–103). 11–14 rules were
  learned, and every answer was correct for seeds 1–4.
- **Works.**

### arithmetic-v5
- Columns have `^working-top`; generate-top-digit sets it too.
- The process-column substate follows the English:
  - init-local uses the working top, `next-position` and `is-subtraction`.
  - get-top-digit/add-carry uses the add fact (d1, 1).
  - add-digits adds the fact's carry to carry-out.
  - subtract-digits does not test the adjusted flag.
- borrow-from is one recursive proposal for states named process-column or borrow-from. Its
  substate (the lender state) gets its local values from an `init-lender` operator: the lender
  column's ORIGINAL top digit, d2 1, and the rest as listed. The English only says the lender
  state "has local values", so this operator is my choice. The lender state then runs
  take-one, write-borrow (sets the lender column's working top) and add-ten-up (the state above
  gets d1 + 10 and ten-added 1). write-result prints the original digits.
- Runner: 9 episodes, no errors, cap reached (count 10000), 19 rules learned.
- Checked runs: 2722 problems (seed 1) and 722 each for seeds 2–4, all correct. Chains of
  borrows through a zero are handled, both by the substates and by the learned rules.
- **Works.**

### arithmetic-smem
- Count 1000, chunking off. `smem --enable`, then `smem --add` preloads the 110 + 165 + 10 + 10
  facts, each tagged `^kind add-fact|sub-fact|inc-fact|ten-fact`.
- Each fact-using operator works in two steps. Its apply rule places one query per selection
  (marked `^queried <op>` on the state). When `^result.retrieved` appears, a second rule applies
  the effect and removes the query. agent-world's smem clean-up also removes the query; that is
  harmless.
- add-digits and subtract-digits no longer test that a fact exists; subtract-digits tests
  d2 <= d1. Increment and add-ten are always proposed in their substates.
- Because a retrieval arrives one decision after its query, every query shows a one-decision
  operator no-change before the result. Nothing in that substate acts.
- Full run: 1000 problems, 0 wrong, 3000 column lines (all printed), success and halt at
  31567 decisions.
- Runner: 9 episodes, no errors, cap reached.
- **Works.**

### arithmetic-smem-chunk
- The same as arithmetic-smem, with count 10000 and `chunk always` plus `chunk add-osk on`.
- The learned rules are specific to digit values, as the English says: about 264–402 rules in
  3000 decisions.
- Full run: 10000 problems, 0 wrong, 400 column lines printed, 420 rules learned, success and
  halt at 112363 decisions.
- Runner: 9 episodes, no errors, cap reached.
- **Works.**

### arithmetic-smem-learn
- Count 2000, chunking off. Only the inc and plus-ten facts are preloaded.
- When the add/subtract retrieval fails, the query is removed and not reissued (`^queried`), so
  the operator no-change opens a counting substate (`counting.soar`):
  - **add-digits substate:** init-count-add, count-add (sum+1, n+1 with RHS arithmetic),
    store-add, done-add. store-add stores two add facts, (d1, d2) and (d2, d1), with sum digit
    `(mod sum 10)` and carry `(div sum 10)`.
  - **subtract-digits substate:** init-count-sub, count-sub, store-sub (one fact), done-sub.
- Departure: the English says the store steps match any WM object with a first/second number.
  I read d1 and d2 from the superstate (the column state) instead, which gives the same facts.
- Stray `@` characters appear in the output at each store, as the English reports. They come
  from Soar, not from the program's writes.
- Full run: 2000 problems, 0 wrong, success and halt at 64529 decisions. After the early
  problems, the answers come from retrieval and no more counting is needed.
- Runner: 9 episodes, no errors, cap reached. Facts stored in semantic memory persist across
  init-soar.
- **Works.**

## Things I could not do / limitations
- With the runner's cap of 3000 decisions, the variants with count 1000, 2000 or 10000 cannot
  reach their goal. Their runner result is `null` by design. I confirmed completion by running
  them uncapped.
- No world-convention operation is used for the column-level internal operators; they are
  ordinary Soar operators in operator no-change substates.
- The MEA proposals, the external action path and look-ahead are not used, because the English
  has none of them.
