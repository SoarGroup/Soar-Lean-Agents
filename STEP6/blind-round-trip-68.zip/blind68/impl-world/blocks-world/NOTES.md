# impl-world / blocks-world — notes

All 14 variants are built on agent-world, simple.soar, selection-world and
selection-iterative-deepening (ID), loaded by absolute path in the order given in
conventions/world-notes.md. Each folder has `<variant>.soar` (the load file: libraries, excises
with reasons, Soar settings) and `<variant>-rules.soar` (the task). Tests:
`run.py <dir> <variant>.soar --seeds 1-3 --episodes 3 --cap 3000`. Every variant loads with no
errors. No runtime errors or warnings were printed.

## Shared design (all variants)

- **Start-up.** agent-world's initialize-agent-world runs first. Then initialize-blocks-world
  (it tests ^world and -^name, and is made better than initialize-agent-world) gives the top
  state ^name blocks-world, ^flags and ^desireds, and creates the world objects.
- **Representation.** World objects have ^object-handle = ^name (table, A, B, ...), ^table
  yes/no and ^anchored true. "X on Y" is a world ^on relation (argument1 X, argument2 Y,
  argument-count 2). The goal is a ^desireds set with one ^desired.on per block
  (argument handles) and ^desired-count. The task supplies ^achieved/^unachieved.
  agent-world's ^success, together with goal-completed, ends the episode.
- **Derived facts** (in place; clear and free in the gripper variants) are kept on the state
  and computed on every state that is its own top state: the real top state and look-ahead
  states. The goal is read through ^external-top-state. They are not put on world objects,
  because those values would be copied and go stale in look-ahead.
- **Actions** are task-action operators. They have ^action-handle, argument1/2 (world
  objects), ^argument-count, and precondition ^desireds (count 0 unless the English gives
  preconditions). agent-world issues the output command.
- **Environment model.** The runner only marks commands complete, so application rules of the
  issuing operator fire on "command complete". They change the real world and remove the
  command. These rules test ^quiescence t, so they are never chunked. I tried two other ways
  first, and both failed:
  - A top-state rule left the agent in a 1-cycle operator no-change gap after every action,
    and that stopped Soar-RL updates.
  - A separate update-world operator lost the RL credit for the goal reward, and its local
    record caused GDS removals of substates.
- **End of episode.** goal-completed (agent-world, proposed at the real top state on success)
  is made best. Its application prints a blank line, `The problem has been solved.`, and
  `TASK-RESULT: success`, then halts. The selection-world interrupt-on-success rules are
  excised.
- **Selection by look-ahead.** Look-ahead uses the selection-world copy, with ID in operator
  mode and initial depth one. Internal application rules match arguments by handle in the
  copied world, because the evaluated operator is not copied.
- **Library defects found and corrected** (the excises are commented in each load file; the
  replacement rules are in the rules files):
  1. simple.soar's wait and agent-world's wait tie in every state no-change. simple's wait is
     excised.
  2. agent-world's remove-command fires at the top level first (Soar 9.6 waterfall), which
     blocks responses in substates. It is excised.
  3. selection-world `state-no-change*selected*failure...` marks every evaluation of the
     selection as failure. It is excised; ID's initialize-failure-evaluation does this job
     correctly.
  4. ID `apply*initialize-failure-evaluation2/3` have a negated condition that re-binds
     `<evaluation>`, so they also mark the evaluation one level up as failed. Corrected copies
     are in the rules file.
  5. ID operator-mode exceed-depth was learned into chunks, and those chunks returned
     depth-exceeded at every depth. The proposal is replaced by the same rule tested at
     quiescence (W-CHK-007 states this intent).
  6. ID has no rule for a nested selection whose evaluations are all depth-limited.
     simple.soar then broke the tie at random, and the look-ahead ran past the depth bound.
     An added rule (at quiescence) marks the enclosing evaluation depth-exceeded.

  Corrections 3–6 are used only by the look-ahead variants.
- **Not done anywhere.** The "ancestor list" is not implemented. The English says nothing uses
  it.
- **Not world conventions.** RL, chunking and episodic memory have no world convention. They
  use ordinary Soar mechanisms inside the world structure:
  - RL: :template rules give numeric preferences. Rewards go on the reward-link; the top-goal
    reward is agent-world's reward rule, switched on by ^flags.rl.
  - Chunking: `chunk always` and `chunk add-osk on`.
  - Episodic memory: epmem commands from a substate.

## Per variant

**blocks-world-simple** (5 blocks): works.
- Choices: all legal moves are proposed (the non-MEA proposal form), indifferent. The two
  control rules are a better preference and a best preference, reading in-place.
- Tests: 9/9 success, 21–24 decisions; 6 moves plus init, latency and goal-completed.

**blocks-world-simple-3**: works.
- Choices: same rules as simple.
- Tests: 9/9 success, 12 decisions (3 moves).

**blocks-world-random**: works.
- Choices: indifferent legal moves. agent-world sets epsilon-greedy, and with no values it
  ties at random.
- Tests: 9/9 success, 9–429 decisions.

**blocks-world-rl** (4 blocks): works; learning is slow and noisy.
- Choices:
  - A Q template keyed on the support name of A–D, the block and destination names, and their
    table flags.
  - Reward +1 at the top state while the goal holds, from agent-world's reward rule.
  - Soar defaults otherwise.
- Tests:
  - 7/9 success; two episodes reached the 3000-decision cap (random exploration, 3
    decisions per move).
  - I checked that the final move is credited (Q 0 → 0.27 at the halt update).
  - Over 15 episodes, episode length falls only irregularly.

**blocks-world-look-ahead**: works.
- Choices:
  - "Last move" is a ^last-moved attribute on the block object; object attributes are copied
    into look-ahead.
  - "No repeated block": in look-ahead states, moves of the last-moved block are rejected.
  - For the evaluated move itself, the look-ahead state reports ^constraint-failure
    (W-LAH-011), so agent-world rejects it in the tied state ("evaluated as failure and
    rejected").
  - Imagined failure maps to worst, not reject (selection-world semantics).
  - The depth-first unbounded search is replaced by ID (operator mode), as the brief requires.
  - The move proposals also match the last-moved block. This gives moves new identities after
    each move. Without it, a failure→worst preference kept by its justification carried over
    to the next situation and drove the agent into dead ends.
- Tests:
  - 9/9 success; with 12 extra seeds, 45/45 success.
  - Chunks (9–13) are reused: for example 77 → 33 → 12 decisions, where 12 is the optimal
    3 moves with no search.

**blocks-world-look-ahead-state-eval**: works.
- Choices:
  - The one-step value is put on the look-ahead state as both ^expected-value (numeric
    preference) and ^numeric-value. ^better higher is set on the goal.
  - The values test the copied relations positively ("not on X" is tested as "on something
    other than X"). My first version used negations of local structure, and chunking then
    learned overgeneral "= 0 for any move" rules.
  - Imagined states never succeed: achievement is computed only on real states.
  - Chunks with numeric preferences are updated by RL (checked).
- Tests: 9/9 success, 21–138 decisions, 18–38 chunks.

**blocks-world-epmem**: works.
- Choices:
  - Episodes record the top state every decision (phase selection). The top state carries
    ^selected-move while a move is selected, so episodes show selected moves, not just
    proposed ones.
  - In look-ahead the move has no internal application. Its implementation substate builds
    the cue (objects with names and table flags, ^on, in-place marks, selected-move) and
    requires ^graph-match 1. It then steps ^next until some block's support differs; a real
    move takes 2–3 decisions to reach the world. It applies the change and marks the move
    tried, replacing the excised standard rule.
  - No match / failure gives partial-success with 2.5 directly on the evaluation.
  - Scores 3/2/1/0; higher is better.
- Tests:
  - 9/9 success, 108–672 decisions.
  - Predictions from episodic memory occur from episode 1 on.
  - No clear improvement in 3 episodes; that needs many matching episodes.

**blocks-world-operator-subgoaling**: works.
- Choices:
  - Preconditions are object desireds (block clear, destination clear; the table included).
    "clear" is a derived world-object attribute; there is no look-ahead here.
  - Unsatisfied preconditions give agent-world's MEA operator no-change subgoal. It keeps the
    blocks-world problem space and shares the world.
  - The three preferences are as given; avoid-clobbering applies to a table destination too,
    as written.
- Tests: 9/9 success in 13 decisions, matching the English example: B→C, then A→table in the
  subgoal, then B→C, A→B.

**blocks-world-operator-subgoaling-chunk**: partly.
- Same task, preferences and subgoals as operator-subgoaling, with chunking always on (with
  operator-selection knowledge).
- The described chunk ("move Y off X directly") is not learned. Under the world conventions
  the subgoal's move is an external action, whose output command is issued at quiescence, so
  it is not chunked. The world change comes from the environment's response.
- When I let that response be chunked, the chunk had contradictory conditions, and in the
  next episode it undid the world change. So the response is also kept at quiescence.
- Tests: 9/9 success, 13 decisions, 0 chunks.

**blocks-world-operator-subgoaling-relevant** (4 blocks): works.
- Choices: goal-directed moves are MEA proposals on unachieved tower desireds; clearing moves
  are MEA proposals on unachieved "clear" desireds of the subgoal. Random choice, as above.
- Tests: 9/9 success, 19–52 decisions.

**blocks-world-hierarchical**: works.
- Choices:
  - move-block is a complex composite operator with ^effect-desireds (block on destination).
  - pick-up and put-down are composite operators (operator-implementation substates).
  - The gripper motions are task-action operators on the gripper object.
  - The gripper's "above" is a world ^above relation, and "holding" is the world's
    ^holding-object. The table is used as the placeholder.
  - Top-level control rules are as in simple.
- Tests: 9/9 success, 90 decisions each, deterministic.

**blocks-world-hierarchical-lookahead**: works.
- Choices:
  - Middle-level candidates have no indifference, so they tie and are looked ahead.
  - The look-ahead state is named move-block and gets that problem space.
  - Task block and destination are re-linked by handle.
  - pick-up and put-down apply in one step internally.
  - Failure conditions are put on the look-ahead state after the candidate is tried.
  - Success is agent-world's ^success on the copied effect desired. Because agent-world adds
    ^better lower to effect-desireds, success is "better than failure" rather than best.
    Failure is worst, not reject.
- Tests: 9/9 success, 143–157 decisions.

**blocks-world-hrl**: works; RL is noisy.
- Choices:
  - Top-level Q template with the fields listed in the English.
  - Lower-level pick-up and put-down are primitive task-action operators, with their own
    templates.
  - Substate rewards are +1 and −1 as given; the top-level reward comes from agent-world.
- Tests:
  - 7/9 success; seed 1 episodes 2–3 hit the cap.
  - Over 6 seeds × 6 episodes (cap 6000), 35/36 succeeded.

**blocks-world-hrl-3level**: works.
- Choices:
  - Bottom gripper operators are chosen by RL. The template is keyed on operator name, task
    block, destination, position/open/empty, and the name of the object the gripper is above.
  - close and release take the task block or destination as argument2, so the environment
    model can decide grasp or drop.
  - Rewards are as given.
- Tests:
  - 9/9 success (238–530 decisions).
  - 36/36 over 6 seeds × 6 episodes.
  - Bottom Q-values are learned (checked).
