# counting family (impl-world)

All three variants are built on agent-world, simple.soar, selection-world and
selection-iterative-deepening, loaded in the order given in conventions/world-notes.md.

## Choices common to the family
- The counter/adder is a world object (`^world.objects.object`, `^object-handle`, `^anchored true`).
  The goal is a `^desireds` with one object-property desired. The task supplies `^achieved`/`^unachieved`.
  agent-world's count rules give `^success`.
- Every change to the world counter is a task-action operator. It has `^action-handle` and arguments, and it is
  applied externally by agent-world's generic output rules (`perform-action`). The runner only marks commands
  complete, so a task rule models the world's response: it fires once per completed command and updates
  `^world`. Each task action therefore costs about 3 decisions: select, then an operator no-change and a
  state no-change while waiting for the response. Decision counts are higher than the "observed" counts
  in the English for this reason.
- The task's initialization operator is made better than agent-world's initialize-agent-world, which stays
  proposed until the top state has a `^name`. Without this the two would tie.
- The library's top-state messages and interrupts are excised (top-goal*halt*success,
  top-goal*halt*success*desireds-count and top-goal*halt*failure), so that only the English's message is
  printed. The task prints `The problem has been solved.` and `TASK-RESULT: success`, then halts.
- Chunking is off (`chunk never`).
- "Indifferent" proposals use `+ =`.

## count-up
- The task operator `count` (MEA proposal: the counter is below its desired value) has the external action
  `count`. The world response adds 1. An internal application rule exists for look-ahead but is never used.
- Tests (seeds 1-3, 3 episodes, cap 3000): success in every episode, 302 decisions each (100 counts × 3 +
  2 initialization decisions). No load or runtime errors.

## count-in-substate
- `count-to-limit` is a complex composite task operator. It has no action-handle and no internal
  application. It has `^effect-desireds`, which holds the same counter desired. agent-world gives its
  implementation substate `^problem-space.name count-to-limit`, those desireds and `^argument1` (the counter).
- In that substate, `init-local` and `increment` are internal operators (`^task-operator false`) acting on a
  local `^local-count` on the substate. The limit (75000) is read from the substate's desired. `done` is a
  task action `set-value` with argument1 = the counter and argument2 = the number (a constant, passed through
  unchanged by agent-world's argument2*no-handle2 rule). The world response writes the value, which ends the
  substate, and the top state succeeds.
- Tests: with cap 3000 the run ends at the cap without a result, in every seed and episode. This is expected:
  the task needs about 75000 decisions. With cap 80000 (seed 1, 2 episodes): success at 75007 decisions,
  close to the English's ~75004.

## count-add-smem
- smem is enabled with learning on and preloaded with the ten `^kind succ ^symbol d ^next d+1 mod 10` facts.
- `add` is a complex composite task operator (effect desired: adder `^done 1`). In its substate, `init-local`,
  `next-sum-digit` and `next-step-count` are internal operators. Each of the last two works in two steps while
  selected. First a query is placed, once per selection, recorded as `^query-issued <op>` on the state. Then,
  on retrieval, the values are updated and the query is removed. The carry is set when the digit was 9.
  (agent-world's smem clean-up rule also removes queries after a result; both fire in the same wave.)
- `done` is a task action `report-sum` with argument1 = the adder and argument2 = a result structure
  (`^sum-digit ^carry`, no object-handle), which agent-world passes to the output command unchanged. The world
  response reads it and sets the adder's first digit, carry and done.
  - Reason: a response rule that read the values from the substate's selected operator was cut off by Soar's
    waterfall, because agent-world removes the completed command at level 1 first. The values therefore travel
    in the command.
- Tests: success in every seed and episode, 44 decisions each (English: about 41). The final adder is first 8,
  carry 1, done 1 (9 + 9 = 18).
