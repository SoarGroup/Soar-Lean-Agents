# eight-puzzle family (impl-world)

The common knowledge is in each variant's `puzzle-core.soar`, generated from one template for 3x3 or 4x4.
Variant-specific rules are in `<variant>-rules.soar`. Libraries: agent-world, simple.soar, selection-world and
selection-iterative-deepening, in the world-notes order. Chunking: `chunk always` (operator-selection
knowledge is on by default).

## Choices common to the family
- **World and cells.** One world object per position (handle `pos-<row><col>`, `^cell`, `^tile`; tile 0 is
  the blank). Cells are identifiers (`^name <row><col>`, `^neighbor`, 4-neighbourhood) hanging off the
  positions. They are not world objects, so selection-world's copy shares them, as the English says. Tiles
  are constants.
- **Goal.** One object-property desired per position (`^tile`): 9 desireds for the 3x3 board, 16 for 4x4.
  agent-world counts at most 6 desireds, and its `agent-world*elaborate*desired-count*too-many` rule prints
  an ERROR and interrupts for larger desireds. That rule is excised, and the task elaborates `^success` itself
  when every desired is achieved. The task supplies achieved/unachieved as usual.
- **move-tile.** A task-action operator proposed `+` only, so moves tie. Proposed for each non-blank tile in a
  cell adjacent to the blank's cell, while the desireds have `^unachieved-desireds true`.
  - argument1 = the tile's position, argument2 = the blank's position (both with handles); `^tile` names the
    tile. No `^super-desired`.
  - External application goes through agent-world output plus a task rule that models the world's response.
    That rule also replaces the top state's `^last-move` record (tile, from, to). Each real move costs about
    3 decisions.
  - The internal application (look-ahead) swaps the copied positions found by handle and records
    `^last-move` on the look-ahead state. A fresh look-ahead state has no record, so the reject rule does not
    apply there until a move is made.
- **Last-move rule.** Any proposed move of the tile in the state's `^last-move` is rejected.
- **Look-ahead.** The look-ahead state is given the task's `^problem-space`. After the tried move, the task
  elaborates `^score`: +1 if the tile moved into its desired place, -1 if it left its desired place, else 0.
  The score is available at once, so the look-ahead is one step deep. Iterative-deepening depth flags are not
  set.
- **Output.** The library's top-state messages and interrupts are excised. The task prints
  `The problem has been solved.` and `TASK-RESULT: success`, then halts.

## eight-puzzle
- Desireds have `^better higher`; the score is the look-ahead state's `^numeric-value`. selection-world makes
  higher better and equal indifferent.
- Because success with `^better` is ranked only by number, a task rule also gives success evaluations best.
- **Tests (seeds 1-3, 3 episodes, cap 3000):** success in every episode. First run 34-44 decisions; later runs
  17-29, with 11-12 chunks. The English reports 19-24 and 6-10; the difference is the 2 extra decisions per
  real move for the external round trip. No errors.

## eight-puzzle-expected-value
- The score is the look-ahead state's `^expected-value`. selection-world makes it a numeric-indifferent
  preference for the evaluated move; no better/worse preferences are made.
- Selection is softmax with temperature 25. These are set after loading, because agent-world sets
  epsilon-greedy.
- **Choice:** the desireds do NOT carry `^better higher` in this variant. With `^better`, selection-world
  passes success back only together with a numeric value, which this variant does not produce, so a
  goal-reaching move would never get success → best. Without `^better`, success → best works through
  selection-world's own rule.
- **Tests:** 5 of 9 episodes solved (17-30 decisions); the other 4 reached the 3000-decision cap unsolved,
  wandering. This matches "sometimes under 20 decisions, sometimes thousands or not within 5000". The cap of
  3000 decisions is about 1000 moves.

## fifteen-puzzle
- Same as eight-puzzle on the 4x4 board with 16 desireds.
- **Tests:** in every seed and episode the agent wanders until the 3000-decision cap without solving and
  never halts, as the English reports. The trace shows continuing moves, not a stuck impasse. No errors.
