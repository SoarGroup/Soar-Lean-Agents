# impl-world / kenken: notes

All 16 variants use one program design. The variants differ only in puzzle data.

- `common/kenken-rules.soar` holds the shared task rules. `gen.py` copies it into every variant folder as `kenken-rules.soar`.
- `gen.py` reads the "Puzzle data" section of each English file. It computes every allowed cage combination from the clue and the rule that cells sharing a row or column must differ. It then checks the result against the English: every per-cage count, every explicit "Allowed:" list, and the total count all match for all 16 variants. It writes `<variant>/<variant>-data.soar`, which holds the initialization rules (world objects, desireds, flags) and the N-specific print-row application. It also writes `<variant>/<variant>.soar`, the load file.
- The load file sources agent-world, simple.soar, selection-world and selection-iterative-deepening by absolute path, as described in world-notes.md. It sets chunking with `chunk always`, `chunk add-osk on` and `chunk allow-local-negations off`, then sources the rules and the data. It does not use lib/soar-default.

## Design (the same for every variant)

- **World** (`^world.objects.object`): every object has `^object-handle` and `^anchored true`.
  - Cells: `cell-<code>`, with `^row ^column ^code ^mark`.
  - Candidates: `cand-<code>-<v>`, with `^row ^column ^code ^value ^alive 1|0` and `^combination <handle>`, which is multi-valued.
  - Combinations: `comb-<i>`, with `^alive` and `^candidate <handle>`, one for each cell of the cage.
  - Puzzle record: `puzzle`, with `^size ^marked-count ^guess-cell ^rows-printed`.
  - Links between objects are handle constants, not identifiers. selection-world copies objects only one attribute level deep, so identifier links would point back into the original world. Constants copy exactly.
  - No derived values are stored on world objects.
- **Goal**: `^desireds` holds one object desired, `puzzle ^marked-count N*N` (`^desired-count 1`). Task rules on any kenken state supply `^achieved` and `^unachieved`. agent-world then adds `^success`, which is a success evaluation in look-ahead.
- **Failure test**: (a) an empty cell has no alive candidate, or (b) a marked cell's candidate for its own mark is dead. Either one adds `^failure <desireds>` to the state.
  - In look-ahead this gives a failure evaluation.
  - At the top state, the report-failure operator prints the newline, `Failure state: the task has failed.` and `TASK-RESULT: failure`, then halts.
- **Task operators**: assign (three proposal rules for conditions a, b and c), cleanup, eliminate (row and column rules), drop-combination, prune, choose-guess-cell-two, choose-guess-cell-three and guess.
  - Each is a TAO: `^task-operator true ^action-handle ^super-desired ^argumentN ^argument-count`, and `^desireds` with `^desired-count 0`.
  - Each is proposed MEA-style: it tests the problem space, `^flags.mea-operator-selection true`, the unachieved desired and the anchored world.
  - At the top state, agent-world's generic external rules apply them as output-link `perform-action` commands. When the command's `^status complete` arrives, the task's world-response rules make the change in the real world once (`^effect-applied`).
  - In look-ahead (`^internal-actions true`), internal application rules change the copied world. They find their arguments by object-handle.
  - Initialize, print-row, finish and report-failure are non-task operators (`^task-operator false`).
- **Preferences**, as the English gives them:
  - Deduction operators: indifferent (`=`).
  - Choose-guess-cell operators: indifferent and worst. Two-option is better than three-option.
  - Guess: no preference, so the guesses tie and selection-world look-ahead resolves the tie.
- **Printing**:
  - The task prints `Set cell`, `Guess cell` and `Guess` both at the top state (in the world response) and in look-ahead (in the internal application).
  - Messages run together with no newlines, and so do the rows.
  - After the last row it prints a newline, `The problem has been solved.`, a line `TASK-RESULT: success`, then halts.

## Choices made where the English was open (or where the world conventions forced a choice)

1. **Search method.** The English describes plain recursive depth-first look-ahead. The brief asks for selection-world plus iterative deepening, so I used `^flags.iterative-step tie-impasse` and `^flags.init-evaluation-depth one`. Depth is counted only at guess ties, so deduction chains inside a copy are free. With depth 1, a nested guess tie returns depth-exceeded and the next pass goes deeper (maximum 7). In every test run, each tie was decided in the first pass, because all of them had at most one level of guessing.
2. **Failure gives a worst preference, not a reject.** selection-world turns a failure evaluation into a worst preference, where the English says the guess is rejected. In a tie of 2 or 3 guesses the effect is the same: a guess that did not fail (or one marked success) is chosen. A nested tie whose guesses all fail passes failure up through the library's all-evaluations-failed rule.
3. **No deduction after the goal at the top.** Task-operator proposals test that the desired is unachieved, which is the MEA convention. Once the marked-cell count reaches N*N at the top, only print-row (and then finish) is proposed. Leftover cleanup or eliminate steps are not done. The English does not say whether they happen.
4. **Initialization order.** initialize-agent-world stays proposed (`+ >`) until the top state has a `^name`. A compare rule makes initialize-kenken better than it once `^world` exists. Without this rule the two operators tie at start-up.
5. **Look-ahead problem space.** The evaluate-operator state gets `^problem-space` with `^name kenken`, created by a task elaboration (W-LAH-009).
6. **Operator arguments.**
   - assign, guess, cleanup and prune: the candidate.
   - eliminate: the candidate and the marked cell C1.
   - drop-combination: the combination.
   - choose-guess-cell: the cell.
   drop-combination gets one instance for each dead candidate in the combination, and eliminate gets one for each (C1, candidate) pair. Duplicate instances only change the random weights among indifferent operators.
7. **Library output.** The libraries add text the English does not have:
   - agent-world `log` lines (`Select ...`, `Apply ...`).
   - selection-world's top-state success rules print `kenken achieved - success` and `kenken achieved all desireds` and call `(interrupt)`. The runner simply keeps going.
   The task's own messages are written exactly as the English gives them.
8. **Chunking.** It is on as the English specifies. As in the English, 0 chunks were learned in every test episode: the look-ahead results depend on local negations, which are disallowed.
9. **Not implemented:** the "ancestor chain" record on substates, which the English says may be left out.

## Tests

The command was `run.py <variant dir> <variant>.soar --seeds 1-3 --episodes 3 --cap 3000` for all 16 variants. I also ran a separate check of the printed grid against the English's observed solution, for seeds 4-7.

- Every variant loads with 0 errors.
- No runtime errors, no chunks, and every episode halts.
- **4-1 to 4-7, 5-1 to 5-5, 6-2, 6-3, 6-4**: success in all 9 runner episodes, and the printed grid equals the English solution in all checked runs.
  - As the English observes, 4-5, 6-2 and 6-3 choose guess cells and resolve them with look-ahead. 4-5 does one look-ahead. 6-2 chooses 2-3 guess cells. 6-3 chooses 1 here; the English lists several codes, which vary with the seed.
  - The others solve by deduction alone, as in the English.
  - 6-1 to 6-4 take about 1100-1600 decisions and 5-25 s per episode.
- **6-1: partly.** 8 of the 9 runner episodes succeeded; seed 3, episode 2 ended with `Failure state: the task has failed.` / `TASK-RESULT: failure`. On extra single-episode runs it failed 2 of 4 (seeds 4-7) and 4 of 12 (seeds 8-19).
  - The cause is in the method as the English describes it. The goal test is only "marked-cell count = N*N", and nothing gives deduction priority over assignment.
  - After a wrong guess in look-ahead, the random order of indifferent operators can fill the last cells (assign rules b and c) before the cleanup, drop and prune steps that would expose the contradiction have fired. The copy then reaches the goal test and is scored success. For example, a cage requiring 21=3 needs 31=6, yet the copy assigned 31=5 and 21=3 before the combination was dropped.
  - The wrong guess is then made for real. Deduction at the top state goes differently and hits the failure test.
  - I did not change the goal test or the operator preferences, because that would add task knowledge or change the stated method. The English's own runs (two seeds) solved 6-1. That is consistent with a failure rate of about one in three.
