# knights family (impl-world)

## Choices common to all variants (impl-world)
- Built on agent-world + simple.soar (sourced by absolute path from lib/world). selection-world and
  selection-iterative-deepening are NOT loaded: no variant here calls for search or look-ahead.
  lib/soar-default is not used. Chunking off (`chunk never`).
- Task's initialize operator is proposed when the top state has ^world but no ^name (after
  initialize-agent-world), made better than initialize-agent-world, and creates ^name,
  ^problem-space (^name, ^agent-world true), ^flags (^mea-operator-selection true), the world objects
  (^object-handle, ^anchored true) and the goal as top-state ^desireds (^desired-count set).
- Achieved/unachieved for object-property desireds is task-supplied (generic rule pair per task);
  relation desireds (hanoi ^in) have their own pair.
- Every action is a task operator (^task-operator true, ^action-handle, ^argumentN, ^argument-count,
  ^super-desired, precondition ^desireds with ^desired-count 0 unless stated). The library's generic
  external rules write the perform-action command; since the runner only marks commands complete,
  each task has top-state `<task>*world*<action>` rules (:o-support, gated by ^effect-applied) that
  apply the action's effects and print the action's message when the command is complete.
  Consequence: each action takes about 3 decisions (select; operator no-change while waiting;
  state no-change) instead of 1, so decision counts are ~3x the English's.
- Termination: agent-world proposes goal-completed when the top state has ^success; the task adds an
  application rule for goal-completed that prints the final lines plus `TASK-RESULT: success` and
  halts (the library's goal-completed does not halt).
- simple.soar and agent-world both propose `wait` (worst) in a state no-change; the two waits then
  tie. Each task adds a rule making wait operators indifferent.
- `output agent-logs 1 off` hides the library's (log 1 ...) trace lines so printed output matches
  the English.
- Internal (look-ahead) application rules: written for the simple tasks, though never used (no
  look-ahead); omitted where noted.

## Shared representation (generated rules)
- World objects: squares b11..bNN (^coord rc ^used ^degree ^original-degree ^visit ^previous
  ^neighbor* ^tried*) and tour (^current ^first ^depth ^moves ^frame ^solutions ^goal ^done).
  Choice: square-to-square links (neighbor, previous, current, first) are identifiers of world
  objects; command arguments are handles. Desired: tour ^done 1.
- Task operators (MEA on the done desired): jump (argument1 = target square), backup
  (argument1 = current square; one proposal rule per backup condition, so duplicate backups occur
  as in the English), record-tour, exhausted, finish-run (argument1 = tour). Their effects
  (including neighbour degree changes and tried-mark removal) are world-response rules that fire
  together when the command completes. Preferences as in the English (finish-run > record-tour >
  backup > jump, jump ordering by degree, all indifferent).
- Internal (look-ahead) application rules exist only for record-tour/exhausted/finish-run; jump
  and backup have none (no look-ahead is used).
- The 1,000,000-move budget cannot be reached within the 3000-decision cap (about 3 decisions per
  move), so test runs end at the cap without TASK-RESULT, as the English's runs would. The ending
  paths were checked separately on copies in /tmp: start moves at 999,990 gives `Run over: 0
  solutions`, then success and halt; a 4x4 board gives `Search complete: 0 solutions`, then
  success and halt.
- Tours were checked: the ^previous chain at each recorded tour has N*N distinct squares, all
  knight moves, and closes on the start square.

## knights-6
- Dynamic-degree ordering, best for jumps to degree-1 squares (not 23), backup condition 4 present.
- Tests: load ok, no errors; each episode runs to the cap (3000 decisions); seed 1 found 26 tours
  (`Success! 1 35Success! 2 35...`).

## knights-8
- Original-degree ordering, no degree-1 best preference, no backup condition 4.
- Tests: load ok, no errors; runs to the cap; seed 1 found no tour, seed 2 found 12 (the English
  says the count depends on the seed, including none).
