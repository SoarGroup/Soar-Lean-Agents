# left-right (impl-world)

## Choices common to all variants (impl-world)
- Built on agent-world + simple.soar (sourced by absolute path from lib/world). selection-world and
  selection-iterative-deepening are NOT loaded: no variant here calls for search or look-ahead.
  lib/soar-default is not used. Chunking off (`chunk never`).
- Task's initialize operator is proposed when the top state has ^world but no ^name (after
  initialize-agent-world), made better than initialize-agent-world, and creates ^name,
  ^problem-space (^name, ^agent-world true), ^flags (^mea-operator-selection true), the world objects
  (^object-handle, ^anchored true) and the goal as top-state ^desireds (^desired-count set).
- Achieved/unachieved for object-property desireds is task-supplied (generic rule pair per task);
  relation desireds (hanoi ^in) have their own pair.
- Every action is a task operator (^task-operator true, ^action-handle, ^argumentN, ^argument-count,
  ^super-desired, precondition ^desireds with ^desired-count 0 unless stated). The library's generic
  external rules write the perform-action command; since the runner only marks commands complete,
  each task has top-state `<task>*world*<action>` rules (:o-support, gated by ^effect-applied) that
  apply the action's effects and print the action's message when the command is complete.
  Consequence: each action takes about 3 decisions (select; operator no-change while waiting;
  state no-change) instead of 1, so decision counts are ~3x the English's.
- Termination: agent-world proposes goal-completed when the top state has ^success; the task adds an
  application rule for goal-completed that prints the final lines plus `TASK-RESULT: success` and
  halts (the library's goal-completed does not halt).
- simple.soar and agent-world both propose `wait` (worst) in a state no-change; the two waits then
  tie. Each task adds a rule making wait operators indifferent.
- `output agent-logs 1 off` hides the library's (log 1 ...) trace lines so printed output matches
  the English.
- Internal (look-ahead) application rules: written for the simple tasks, though never used (no
  look-ahead); omitted where noted.

## left-right
- World: object agent (^location 0 ^moved 0). Desired: agent ^moved 1. Task operator move with two
  instances (argument1 = agent, argument2 = direction -1 / 1, also ^direction), MEA-proposed while
  location 0, indifferent. World response sets location and moved, prints `Moved: <dir>`.
- RL: `rl --set learning on`, learning-rate 0.3, discount-rate 0.9, epsilon-greedy, epsilon 0.1;
  two RL rules (numeric-indifferent, initial 0) keyed on direction, location 0, moved 0.
- Reward: task rules on the top state's reward-link: -1 while location -1, +1 while location 1.
  Choice: because of the external-action wait the location is already changed for two decision
  cycles before the next selection, which counted the reward twice (Q became -0.57). The reward
  rules therefore also require that no operator is selected on the top state, so the reward is
  counted once; after one left move Q(left) = -0.3, after one right Q(right) = +0.3, after two rights
  0.51, as in the English. agent-world's own RL hook (^flags.rl true) is not used.
- Tests: all episodes success, 6 decisions each, 2 RL rules; values learned as above
  (checked with `print --rl`).
