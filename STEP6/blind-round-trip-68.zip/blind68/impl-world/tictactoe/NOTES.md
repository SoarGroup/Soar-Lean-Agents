# tictactoe (impl-world)

## Choices common to all variants (impl-world)
- Built on agent-world + simple.soar (sourced by absolute path from lib/world). selection-world and
  selection-iterative-deepening are NOT loaded: no variant here calls for search or look-ahead.
  lib/soar-default is not used. Chunking off (`chunk never`).
- Task's initialize operator is proposed when the top state has ^world but no ^name (after
  initialize-agent-world), made better than initialize-agent-world, and creates ^name,
  ^problem-space (^name, ^agent-world true), ^flags (^mea-operator-selection true), the world objects
  (^object-handle, ^anchored true) and the goal as top-state ^desireds (^desired-count set).
- Achieved/unachieved for object-property desireds is task-supplied (generic rule pair per task);
  relation desireds (hanoi ^in) have their own pair.
- Every action is a task operator (^task-operator true, ^action-handle, ^argumentN, ^argument-count,
  ^super-desired, precondition ^desireds with ^desired-count 0 unless stated). The library's generic
  external rules write the perform-action command; since the runner only marks commands complete,
  each task has top-state `<task>*world*<action>` rules (:o-support, gated by ^effect-applied) that
  apply the action's effects and print the action's message when the command is complete.
  Consequence: each action takes about 3 decisions (select; operator no-change while waiting;
  state no-change) instead of 1, so decision counts are ~3x the English's.
- Termination: agent-world proposes goal-completed when the top state has ^success; the task adds an
  application rule for goal-completed that prints the final lines plus `TASK-RESULT: success` and
  halts (the library's goal-completed does not halt).
- simple.soar and agent-world both propose `wait` (worst) in a state no-change; the two waits then
  tie. Each task adds a rule making wait operators indifferent.
- `output agent-logs 1 off` hides the library's (log 1 ...) trace lines so printed output matches
  the English.
- Internal (look-ahead) application rules: written for the simple tasks, though never used (no
  look-ahead); omitted where noted.

## tictactoe
- World objects: game (^turn 1 ^winner 0 ^over 0), cells c11..c33 (^x ^y ^content), lines
  row1-3, col1-3, diagonal1-2 (^cell links to the cell objects). Top-state ^name TicTacToe.
  Desired: game ^over 1.
- Task operators (MEA on the over desired): mark-cell (argument1 = empty cell), x-wins / o-wins
  (argument1 = game, argument2 = winning line; best + indifferent), detect-draw (argument1 = game).
- Board monitor: i-supported per-cell ^display (space, X, O) and a write rule over all nine cells,
  which fires once at the start and whenever a cell changes. Choice: each board is printed as a
  newline then the 7 lines, each ending with a newline, so the result line follows on its own line.
- Tests: all episodes success (21-33 decisions); over seeds 1-12 X won, O won and Draw all occur.
