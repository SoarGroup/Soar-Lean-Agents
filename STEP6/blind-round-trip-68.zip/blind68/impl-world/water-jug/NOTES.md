# water-jug family: impl-world notes

All nine variants are built on agent-world (world conventions) and use `simple.soar`.
Test: `python3 tools/run.py <dir> <variant>.soar --seeds 1-3 --episodes 3 --cap 3000`.
Every variant loads with 0 load errors, and no run has runtime errors or warnings.

## Shared design (all variants)

- **Initialization.** agent-world's `initialize-agent-world` comes first. The task's
  `initialize-water-jug` (`^task-operator false`) follows. It names the state `water-jug` and
  creates `^world.objects.object` jug-a (volume 3) and jug-b (volume 5), both with contents 0,
  `^object-handle` and `^anchored true`. It also creates `^flags` and the goal
  `^desireds` (desired-count 1). The desired is the object jug-a with `^contents 1`.
  - Choice: "a jug with volume 3 and contents 1" is expressed with jug-a's handle, because jug-a
    is the only volume-3 jug.
  - A rule prefers `initialize-water-jug` over `initialize-agent-world`. Without it the two tie,
    because agent-world's proposal (+, >) stays active until the state has a name.
- **Problem space and achievement.** `^problem-space` is `water-jug` with `^agent-world true`.
  Free space is i-supported on the state as `^free-space.{object, amount}`; it is not stored on
  the jug objects, so look-ahead copies cannot hold a stale value. The task supplies
  `^achieved` and `^unachieved` for the desired (W-DBK-002).
- **Task operators.** fill, empty and pour are task-action operators: `^task-operator true`,
  `^action-handle`, `^argument1/2`, `^argument-count`, `^super-desired`, and `^desireds`
  (desired-count 0). They use MEA-style proposals, which test `^flags.mea-operator-selection`
  and `^unachieved <d>`.
  - In the real world, agent-world's generic rules apply them by writing `perform-action` to
    the output-link.
  - The runner only marks commands complete, so o-supported top-state rules model the world's
    response. They fire once per command (`^effect-applied`).
  - Internal application rules (`^internal-actions true`) are used in look-ahead.
- **Goal.** The task operators stop being proposed when the desired is achieved. agent-world's
  `goal-completed` is then selected, and a task rule prints a newline, `The problem has been
  solved.` and `TASK-RESULT: success`, then halts.
- **Output is not only the message.** Library and log lines also print: `log 1` lines such as
  "Select ..." and "Apply ...", "Success (1)", and in look-ahead "Depth: ..." and "water-jug
  achieved - success". No task-only monitor rules were added.
- **Decision counts.** Each real action costs 3 decisions instead of 1:
  1. The operator is selected and the command is written.
  2. An operator no-change occurs while the command is pending.
  3. A state no-change occurs; the o-supported world update fires in that apply phase, after
     the runner marks the command complete.

  So decision counts are about 3 times those in the English.
- **Loaded libraries.** selection-world and iterative deepening are loaded only in the three
  look-ahead variants. In water-jug-tie they would take over the tie substate that the task
  supplies; the other variants have no ties to resolve.

## water-jug

- **What it does.** All task operators are proposed + and =, so every choice is random
  (agent-world sets epsilon-greedy, and no numeric values exist). Chunking is never on.
- **Tests.** 9/9 solved, in 21–2154 decisions.

## water-jug-rl

- **Q-values.** Three `:template` rules supply them, keyed by:
  - fill: (fill, volume, contents);
  - empty: (empty, volume, contents);
  - pour: (pour, from volume/contents, to volume/contents).

  The plain = preferences are kept.
- **Rewards.** Both are i-supported on the top state's reward-link: -1 while both jugs are
  empty, and +1 when the volume-3 jug holds 1. The agent-world reward rule is not used
  (`^flags.rl` is not set).
- **Settings.** `rl` learning on, learning-rate 0.1, discount 0.5, epsilon-greedy with the
  default epsilon. Temporal extension is left on.
- **Effect of the extra decisions.** Because each action spans 3 decisions, the effective
  discount per action is smaller than in the original.
- **Tests.** 9/9 solved; RL rules were updated.
  - Values improve slowly within 3 episodes (seed 3 ep 3: 15 decisions).
  - An extra 10-episode check converged to 16 decisions (the shortest path) by episodes 5–9.

## water-jug-tie

- **What it does.** Proposals are + only.
  - The tie substate is named `water-jug-tie` and copies `^last-operator`.
  - It makes one evaluation per `^item`, and `evaluate` operators (=) add equal / worst / best
    by the stated rules.
  - `create-preferences` (better than evaluate) writes = / <,= / >,= on the superstate's
    operators.
- **Choice: when last-operator changes.** `^last-operator` is updated when the selected task
  operator's command completes, not in the decision in which it is selected. The tie
  preferences test last-operator, so changing it at selection retracted the selected operator's
  preferences while its action was pending, and the tie reopened.
- **Tests.** 9/9 solved, in 36–455 decisions.

## water-jug-tie-chunk

- **Settings.** As water-jug-tie, plus `chunk always` and `chunk add-osk on`. Soar 9.6 has no
  separate switch for o-supported chunks; they are allowed.
- **Chunks.** Exactly the five rules the English describes are learned, in every seed:
  - last none: anything =;
  - last pour: fill/empty =;
  - last pour: pour <,=;
  - last fill|empty: pour >,=;
  - last fill|empty: fill/empty <,=.

  After that there are no more ties.
- **Tests.** 9/9 solved, with 5 chunks each run.

## water-jug-hierarchy

- **Top-level fill.** fill(jug) is a composite operator: no action-handle, desired-count 0.
  agent-world gives it an operator no-change substate named `fill` with
  `^problem-space.name fill` and `^argument1 <jug>`.
- **Holding.** Holding is the world relation `^world.holding-object <jug>`; its absence means
  holding nothing.
- **"fill-relevant".** This is one derived state attribute, from two rules: not full, or full
  and held. Because it is a single attribute, the selected fill operator persists from "not
  full" to "full and held" instead of being re-proposed as a new operator.
- **Choice: sub-operators change the world directly.** pick-up, fill-jug and put-down
  (`^task-operator true`, no action-handle) change the shared world in the fill substate and
  are not sent to the output-link.
  - agent-world's generic output rules test `^quiescence t`, which prevents chunking.
  - The chunk variant requires learned rules that perform these steps, so the same design is
    used in both hierarchy variants.
- **Tests.** 9/9 solved, in 78–2982 decisions. The fill substate always ran pick-up → fill-jug
  → put-down.

## water-jug-hierarchy-chunk

- **Settings.** As water-jug-hierarchy, plus `chunk always` and `add-osk on`.
- **Chunks.** Exactly three o-supported chunks are learned, testing the selected top-level
  fill(jug):
  - nothing held → hold the jug;
  - held and not full → contents := volume;
  - held and full → stop holding.

  Later fills complete in one decision with no substate.
- **Tests.** 9/9 solved, with 3 chunks each.

## water-jug-look-ahead

- **Setup.**
  - Proposals are + only.
  - Flags: `iterative-step tie-impasse`, `init-evaluation-depth one`.
  - Chunking always, with add-osk on.
  - Ancestors are elaborated as `^ancestor`: every water-jug state above, including the top
    state.
- **Duplicate check.** After a simulated operator has been applied (`^task-operator-applied`),
  a simulated state whose two jugs' contents equal those of an ancestor gets
  `^partial-failure`. Selection-world turns this into a worst preference.
  - The check matches both jugs positively. An earlier negated form produced over-general
    chunks ("empty any jug is worst").
- **The problem-space copy description** (two-level objects, dont-copy free-space ancestor) is
  on `^problem-space` as documentation only. selection-world copies the world with its own
  fixed rules.
- **Deviations required by the libraries (recorded):**
  1. The search is iterative deepening (selection-world needs ID), with default maximum depth
     7. The English asks for unbounded depth-first search.
  2. `excise default*select*indifferent-and-worst*tied` (simple.soar). When a nested selection
     ran out of evaluations, this rule made all tied items indifferent and worst before ID's
     `initialize-failure-evaluation` could run. The simulated state then continued with a
     random operator.
  3. **Partial success passed up.** This rule was added because the English describes it and
     the libraries lack it (selection-world passes up only required-success, and ID's pass-back
     is commented out). When a nested selection inside a simulated state has a success or
     partial-success evaluation, the simulated state is marked `^partial-success` for its
     desireds.
  4. **ADDED: visited list in simulations.** Each simulated state records the situations it
     has left (`^visited`), and a return to one is a partial failure. ID limits depth per
     simulated state, not per operator, so a simulated state otherwise cycled forever
     (observed).
  5. **ADDED, switchable (`^flags.avoid-visited-real true`): avoid real repeats.** The real
     situations already left are recorded on the top state, and a simulated state that
     returns to one is a partial failure.
     - Without it, the agent cycled at the top level in every test run, usually
       (0,0)↔(0,5): 0/9 solved for seeds 1–3, and 1/6 for seeds 1–6.
     - The cause is that ID favours the candidate with the fewest choice points, and from
       (0,5) that is "empty jug-b" back to (0,0), which is not an ancestor.
     - The English reports this kind of cycle for some runs.
     - To turn the check off, delete the flag in `water-jug-rules.soar`.
- **Tests (with item 5).** 9/9 solved.
  - First episode: 171–187 decisions.
  - Later episodes: 21 decisions with no search (6 actions × 3 + init + goal).
  - Extra seeds 4–9: 6/6 solved.

## water-jug-look-ahead-failure-states

- **What it does.** As water-jug-look-ahead (including items 1–5 above), plus two extra
  partial failures in simulated states after an operator applies: both full (3,5) and both
  empty (0,0).
- **Tests.** 6/9 solved. Seed 1 cycled (3,0)→(0,3)→(3,3)→(3,0) in all three episodes; extra
  seeds 4–9: 5/6 solved.
  - Cause of the seed 1 cycle: a learned "best" chunk (from partial success) for empty jug-b
    in state (3,x). It fires at (3,3), where pour would solve directly, so no tie arises and
    pour is never evaluated.
  - The chunk is correct about reachability but ignores the visited history.
  - Solved runs: 117–197 decisions first, then 15–27.
  - The English reports 9/9 for the original. **Partly.**

## water-jug-look-ahead-rl

- **What it does.** As water-jug-look-ahead (including items 1–5), with these additions:
  - **Expected value.** A simulated state that is both full or both empty after an operator
    applies gets `^expected-value -1`. selection-world copies it to the evaluation and makes it
    a numeric indifferent preference.
  - **Discounted pass-up.** A task rule (commented out in the libraries) passes an expected
    value found in a nested selection up to the enclosing simulated state, multiplied by 0.9.
  - **RL settings.** RL on, learning-rate 0.1, discount 0.5, epsilon-greedy. There are no
    reward rules and no hand-written RL rules. The RL rules are the learned chunks with numeric
    preferences: 8–13 per seed.
- **Tests.** Seeds 1–3: 9/9 solved, in 121–434 decisions first and 27–54 later.
  - Extra seeds 4–9 (2 episodes each): 3 seeds had episodes that did not finish within 3000
    decisions, and others took 1250–1926.
  - This matches the English's report that the agent can wander for a long time.
