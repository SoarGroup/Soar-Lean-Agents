# wizards (impl-world)

## Choices common to all variants (impl-world)
- Built on agent-world + simple.soar (sourced by absolute path from lib/world). selection-world and
  selection-iterative-deepening are NOT loaded: no variant here calls for search or look-ahead.
  lib/soar-default is not used. Chunking off (`chunk never`).
- Task's initialize operator is proposed when the top state has ^world but no ^name (after
  initialize-agent-world), made better than initialize-agent-world, and creates ^name,
  ^problem-space (^name, ^agent-world true), ^flags (^mea-operator-selection true), the world objects
  (^object-handle, ^anchored true) and the goal as top-state ^desireds (^desired-count set).
- Achieved/unachieved for object-property desireds is task-supplied (generic rule pair per task);
  relation desireds (hanoi ^in) have their own pair.
- Every action is a task operator (^task-operator true, ^action-handle, ^argumentN, ^argument-count,
  ^super-desired, precondition ^desireds with ^desired-count 0 unless stated). The library's generic
  external rules write the perform-action command; since the runner only marks commands complete,
  each task has top-state `<task>*world*<action>` rules (:o-support, gated by ^effect-applied) that
  apply the action's effects and print the action's message when the command is complete.
  Consequence: each action takes about 3 decisions (select; operator no-change while waiting;
  state no-change) instead of 1, so decision counts are ~3x the English's.
- Termination: agent-world proposes goal-completed when the top state has ^success; the task adds an
  application rule for goal-completed that prints the final lines plus `TASK-RESULT: success` and
  halts (the library's goal-completed does not halt).
- simple.soar and agent-world both propose `wait` (worst) in a state no-change; the two waits then
  tie. Each task adds a rule making wait operators indifferent.
- `output agent-logs 1 off` hides the library's (log 1 ...) trace lines so printed output matches
  the English.
- Internal (look-ahead) application rules: written for the simple tasks, though never used (no
  look-ahead); omitted where noted.

## wizards
- World objects: wizards (^done ^views), views (^id ^owner ^depth ^parent), records (^view ^wizard
  ^mark ^linked ^var ^modelled ^guess ^sibling ^down), unknown-spot variables (^value ^untried 1|2
  ^assigned-view). Derived knowledge (own, white, black, blackish, would-guess-white/black,
  contradictory) is i-supported elaborations on the record objects. Desired: wizards ^done 1.
- The ten actions are task operators with argument1 = a record (MEA on the done desired); their
  effects and messages are world-response rules. complement takes W2 (the linked record in the
  child view) as its argument; the value u is the variable's remaining untried value.
- Choices where the English is open: a second model from the same view replaces the records'
  down links (a record has one down link); pass-down-guess replaces a different ascribed guess;
  the complement removes the record's ^var link as well as setting link flag 0.
- Preferences as in the English (best, worst, assume > model, the two model rejects, everything
  indifferent).
- No internal (look-ahead) application rules (no look-ahead is used).
- Tests: all episodes success, 54 decisions; output matches the English's typical run in both
  orderings (seed 1 models wizard 2 first, seeds 2-3 wizard 3 first), messages run together, then a
  newline and `The problem has been solved.`.
