# impl-world2 / blocks-world — notes (Phase C: no external environment)

All 14 variants are copies of impl-world/blocks-world, changed to load lib/world2 and to run
without an external environment. The design, choices and library corrections in
impl-world/blocks-world/NOTES.md still apply, except where this file says otherwise.

Tests: `run.py <dir> <variant>.soar --seeds 1-3 --episodes 3 --cap 3000` for every variant.
- Every variant loads with no errors.
- No runtime errors or warnings.
- Every episode prints `The problem has been solved.` and `TASK-RESULT: success`, then halts:
  126/126 episodes, against 122/126 before.

Output commands and decisions per action were counted from a watch-1 trace of episode 1, seeds 1–3,
with a separate script (not part of the deliverable). "Decisions per action" is the number of
decisions from selecting a primitive task action to the next decision at its level.

## What changed (all variants)

- **Library.** Every path to lib/world became lib/world2.
- **No environment.** A new rule, `blocks-world*elaborate*top-state*environment-none`, gives the
  top state `^environment none`. agent-world then sets `^internal-actions true` on every state,
  including the top state.
- **One application rule per primitive task action.** Each primitive task action now has an
  internal application rule (it tests `^internal-actions true` and
  `^pre-conditions-satisfied true`). The rule makes the action's whole effect on the state's
  ^world in the decision in which the action is selected. These rules replace the
  output-command response rules.
- **Removed:**
  - every `blocks-world*apply*response*...` rule;
  - `blocks-world*apply*response*remove-command`;
  - the excise of agent-world's `apply*operator*remove-command`, with its comment. That rule
    never fires now.
  - There was no ^effect-applied marking in this family.
- **Results.** No variant issues an output command; before, there was one per real action. Every
  real primitive action takes 1 decision; before, it took 3 (select, operator no-change with a
  wait, state no-change).
- **Substates still used where they should be:**
  - MEA precondition subgoals (the operator-subgoaling variants);
  - the composite operators move-block, pick-up and put-down (the hierarchical and hrl variants);
  - the episodic-memory model of move-block in look-ahead (epmem).
- **"Look-ahead only" is now `^real false`.** Rules that had used `^internal-actions true` to mean
  "in look-ahead" now test `^real false`, because every state now has `^internal-actions true`.
  The affected rules:
  - look-ahead and epmem: the "no repeated block" reject rule and its constraint-failure rule;
  - epmem: all the rules of the episodic model;
  - hierarchical-lookahead: the one-step look-ahead applications of pick-up and put-down. In the
    real world, these composite operators must still be carried out by the gripper operators
    in their substates.
- **Constraint-failure messages (library problem 1).** look-ahead and epmem excise agent-world's
  `selection*select*constraint-failure-print-out`. That rule put a say-sentence `send-message` on
  the output-link for each imagined constraint failure: 5 such commands in look-ahead seed 1
  before. The English says the only output is the solved message, and there is no environment to
  say anything to.
- **Unchanged-value guards.** The new application rules never remove and re-add the same WME.
  - The world's ^holding-object is a placeholder that is kept when the gripper empties. So
    pick-up and close-gripper (and close*grasp in hrl-3level) change it in a separate rule, and
    only when it differs.
  - The old response rules did a remove and an add of the same WME in one action. That had not
    shown up as a problem, because the old rules fired once per command.

## Per variant (episode-1 decisions, seeds 1/2/3: before → after)

| variant | result | ep-1 decisions before → after | decisions per real action |
|---|---|---|---|
| simple | works, 9/9 | 21/24/24 → 9/10/10 | 3 → 1 |
| simple-3 | works, 9/9 | 12/12/12 → 6/6/6 | 3 → 1 |
| random | works, 9/9 | 429/27/162 → 145/11/56 | 3 → 1 |
| rl | works, 9/9 (before 7/9) | 3000/528/429 → 1163/178/145 | 3 → 1 |
| look-ahead | works, 9/9 | 77/115/105 → 71/109/99 | 3 → 1 |
| look-ahead-state-eval | works, 9/9 | 39/57/46 → 29/45/36 | 3 → 1 |
| epmem | works, 9/9 | 488/595/108 → 253/917/98 | 3 → 1 (imagined moves: about 4.4 → 4) |
| operator-subgoaling | works, 9/9 | 13 → 7 (all seeds) | 3 → 1 |
| operator-subgoaling-chunk | partly, 9/9 | 13 → 7; episodes 2–3: 13 → 4 | 3 → 1 |
| operator-subgoaling-relevant | works, 9/9 | 52/23/46 → 26/11/22 | 3 → 1 |
| hierarchical | works, 9/9 | 90 → 44 (all seeds) | 3 → 1 (23 gripper actions) |
| hierarchical-lookahead | works, 9/9 | 143/149/154 → 97/103/108 | 3 → 1 |
| hrl | works, 9/9 (before 7/9) | 825/713/175 → 121/545/329 | 3 → 1 |
| hrl-3level | works, 9/9 | 270/306/292 → 128/124/114 | 3 → 1 |

For random, rl, hrl and hrl-3level the decision counts reflect random choices as well as speed.
The same seed makes the same choices: hrl-3level seed 1 makes 71 gripper actions both before and
after. So the saving is about 2 decisions per action.

### Notes by variant

- **operator-subgoaling (all three).**
  - The trace still matches the English: B→C is selected, its preconditions fail, and A→table is
    chosen in the subgoal. When A→table applies, B→C's preconditions hold, and B→C applies in the
    same decision (it stays selected in the top state). Then comes A→B.
  - That gives 7 decisions instead of 13.
- **operator-subgoaling-chunk: partly. Better than before, but with a new problem.**
  - The chunk the English describes is now learned (1 chunk per seed). The subgoal's move now
    changes the shared world directly instead of through an output command at quiescence. In
    episodes 2–3 the clearing move is made without a subgoal: 4 decisions.
  - But the chunk is overgeneral, roughly as the English warns ("move Y onto some other clear
    object"). The destination is any clear object that Y is not on, because the subgoal's choice
    of destination was random among equal best moves.
  - Soar fires every instantiation at once. In episode 2, A gets an ^on to the table and an ^on to
    C in the same phase. Then the chunk fires again, from C to B, and A ends with two ^on
    relations: on the table and on B.
  - The goal test still succeeds, but the world is inconsistent. A fix would need the chunk to
    keep the chosen destination; that is a chunking/selection question, not a world-convention
    one. Left as is.
- **look-ahead.**
  - The last-moved marks are now made by the internal rules in the real world as well. The real
    world and the copies use the same rules.
  - Chunking is unchanged: 10–12 chunks, against 11–13 before. Episodes still fall to the optimal
    6 decisions (3 moves). Over 15 seeds × 3 episodes: 45/45 success, and 7 seeds reach 6
    decisions by episode 2 or 3.
- **look-ahead-state-eval.** Chunk counts are unchanged (29/31/38 cumulative). Fewer decisions,
  because real moves no longer cost 3 decisions.
- **epmem.**
  - The real move has its own application rules (`blocks-world*apply*move-block*real*...`, which
    test `^real true`). In look-ahead, move-block still has no application rule and is
    implemented by the episodic-model substate, as before.
  - Better: a real move is now one recorded episode, so the model reaches the episode after the
    move with fewer ^next steps. An imagined move takes 4 decisions instead of about 4.4. There is
    still no clear improvement over 3 episodes.
- **hierarchical / hierarchical-lookahead.**
  - Gripper actions apply in one decision each. pick-up, put-down and move-block still use their
    substates in the real world.
  - In hierarchical-lookahead, the one-step applications of pick-up/put-down are now restricted to
    look-ahead (`^real false`). Without that, they would have applied pick-up and put-down
    directly in the real world and skipped the gripper level.
- **RL (rl, hrl, hrl-3level).**
  - RL still learns. Credit is still given to the action that achieves a reward, because the
    action is the selected operator when the world changes.
  - There are fewer decisions per action, and so fewer cap failures:
    - rl, 3 seeds × 15 episodes: 44/45 after, against 41/45 before.
    - hrl, 6 seeds × 6 episodes (cap 6000): 36/36, against 35/36 before.
    - hrl-3level: 36/36, as before.
  - The RL "gaps" in rl (states where the selected move has no RL rule) were there before and are
    unchanged. They make the final update small (seed 2: Q 0 → 0.056).

## Library problems found

1. agent-world `selection*select*constraint-failure-print-out` writes a say-sentence
   `send-message` to the output-link even when the top state has `^environment none`. It
   should test for an environment, or use (write) instead. It is excised in look-ahead and
   epmem.
2. Task rules can no longer use `^internal-actions true` to mean "imagined state". With
   `^environment none` it holds on the real top state too, so `^real false` is the test for
   look-ahead. The conventions or world-notes should say so. Any existing task that used
   internal-actions to mean look-ahead changes behaviour silently under world2.
3. A composite operator that has an internal (look-ahead) application rule now has that rule
   fire in the real world too, so its operator-implementation substate is never used. Under
   world2, internal application rules for composite operators must test `^real false`. The
   conventions do not mention this.
4. world-notes.md still describes the response-rule environment model. It needs a section on
   `^environment none`.
