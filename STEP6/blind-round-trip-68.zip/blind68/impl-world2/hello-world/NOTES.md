# hello-world (impl-world2, Phase C)

## Phase C (impl-world2): no external environment, lib/world2

Common to every variant in this family:
- Load file sources lib/world2 instead of lib/world (only path change).
- New top-state elaboration `<task>*elaborate*top-state*environment-none`: (state ^superstate nil)
  --> ^environment none. agent-world (lib/world2) then puts ^internal-actions true on every state,
  so each task operator is applied by its internal application rule (tests ^internal-actions true
  and ^pre-conditions-satisfied true) on the top state, in the decision it is selected. The
  library's external rules (now also testing ^internal-actions false) do not fire: no output
  command is issued (checked: 0 commands on the output-link, seeds 1-3).
- Removed: every `<task>*world*<action>` rule (the response to a completed perform-action command,
  gated by ^effect-applied). Their effects were already in, or have been moved into, the internal
  application rules.
- Messages: the action messages moved from the world-response rules to the top state. Where the
  message only uses values the action does not change, it is a separate top-state rule
  (`*apply*<action>*message`, tests ^superstate nil and the selected operator). Where it prints a
  value the action changes, the write is in the o-supported internal application rule (it fires
  once per application; an i-supported message rule could match again on the new value while the
  operator is still selected). No variant in this family uses look-ahead, so internal applications
  only ever happen in the real world and messages are never printed hypothetically.
- Kept: the wait-indifferent rule (still needed for any state no-change, e.g. hierarchy/MEA cases),
  goal-completed application with TASK-RESULT and halt, `output agent-logs 1 off`, `chunk never`.
- Decisions per real action: before 3 (select; operator no-change while the command was pending;
  state no-change) -> after 1.

## hello-world
- say-hello: internal application sets written 0 -> 1; `Hello World` is printed by the top-state
  message rule `hello-world*apply*say-hello*message`.
- Tests (run.py, seeds 1-3, 3 episodes, cap 3000): load ok, 0 errors, every episode success and
  halt. Decisions episode 1: 6 -> 4 (initialize-agent-world, initialize-hello-world, say-hello,
  goal-completed; the English counts 3 because it has no separate agent-world initialisation).
  Output identical to impl-world (`Hello World` / `The problem has been solved.`).
- Better: no waiting substates. Worse: nothing. Chunking/RL/look-ahead: not used.

---

## Earlier notes (impl-world), kept for reference
Where they mention world-response rules, ^effect-applied, output commands or 3 decisions per action,
they are superseded by the Phase C section above.

### hello-world (impl-world)

## Choices common to all variants (impl-world)
- Built on agent-world + simple.soar (sourced by absolute path from lib/world). selection-world and
  selection-iterative-deepening are NOT loaded: no variant here calls for search or look-ahead.
  lib/soar-default is not used. Chunking off (`chunk never`).
- Task's initialize operator is proposed when the top state has ^world but no ^name (after
  initialize-agent-world), made better than initialize-agent-world, and creates ^name,
  ^problem-space (^name, ^agent-world true), ^flags (^mea-operator-selection true), the world objects
  (^object-handle, ^anchored true) and the goal as top-state ^desireds (^desired-count set).
- Achieved/unachieved for object-property desireds is task-supplied (generic rule pair per task);
  relation desireds (hanoi ^in) have their own pair.
- Every action is a task operator (^task-operator true, ^action-handle, ^argumentN, ^argument-count,
  ^super-desired, precondition ^desireds with ^desired-count 0 unless stated). The library's generic
  external rules write the perform-action command; since the runner only marks commands complete,
  each task has top-state `<task>*world*<action>` rules (:o-support, gated by ^effect-applied) that
  apply the action's effects and print the action's message when the command is complete.
  Consequence: each action takes about 3 decisions (select; operator no-change while waiting;
  state no-change) instead of 1, so decision counts are ~3x the English's.
- Termination: agent-world proposes goal-completed when the top state has ^success; the task adds an
  application rule for goal-completed that prints the final lines plus `TASK-RESULT: success` and
  halts (the library's goal-completed does not halt).
- simple.soar and agent-world both propose `wait` (worst) in a state no-change; the two waits then
  tie. Each task adds a rule making wait operators indifferent.
- `output agent-logs 1 off` hides the library's (log 1 ...) trace lines so printed output matches
  the English.
- Internal (look-ahead) application rules: written for the simple tasks, though never used (no
  look-ahead); omitted where noted.

## hello-world
- World: object `greeting` (^written 0). Desired: greeting ^written 1. Task operator say-hello
  (argument1 = greeting), MEA-proposed on the unachieved desired while written = 0, indifferent.
  The world response sets written 1 and prints `Hello World`.
- Output: `Hello World` / `The problem has been solved.` / `TASK-RESULT: success`.
- Tests (seeds 1-3, 3 episodes): load ok, 0 errors; every episode halts with success in 6 decisions
  (English: 3; the extra 3 are the external-action wait, see above).
