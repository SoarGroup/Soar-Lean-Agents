# impl-world2 / kenken: notes (Phase C, no external environment)

This is a copy of impl-world/kenken, changed to use lib/world2 and to apply task operators internally
at the top state. The design, the puzzle data and the choices in impl-world/kenken/NOTES.md are
unchanged, except for the points below.

## What changed

- `gen.py`: `OUT` is now impl-world2/kenken and `LIB` is lib/world2. All 16 variant folders were regenerated.
  - Every load file now sources lib/world2 (agent-world, simple, selection-world, selection-iterative-deepening).
  - The data files are unchanged apart from the regeneration.
- `common/kenken-rules.soar` (copied into each variant as `kenken-rules.soar`):
  - Added `kenken*elaborate*top-state*environment-none`: `(state <s> ^superstate nil) --> (<s> ^environment none)`.
    lib/world2 then puts `^internal-actions true` on every state, including the top state.
  - Removed the five "world response" rules (`kenken*world-response*assign`, `*guess`, `*kill-candidate`,
    `*drop-combination`, `*choose-guess-cell`). They watched for `perform-action ^status complete`
    on the output-link and marked `^effect-applied`. Both are now gone.
  - Kept the existing internal application rules (assign, guess, kill-candidate for
    cleanup/eliminate/prune, drop-combination, choose-guess-cell). They already make the full effect
    on ^world, including the `Set cell` / `Guess` / `Guess cell` messages, and they now apply at the top state as well.
  - Updated the header comments. Nothing else changed: proposals, preferences, failure test, printing and ending are as before.
- No other workarounds existed only because of output commands, so nothing else was removed.
- `tools/check.py` is new. It runs one episode with `watch 1` and counts:
  - output commands;
  - top-state operator selections and task-operator selections;
  - substate operators, no-change impasses and ties.

## Decisions per action (seed 1, episode 1; before = impl-world, after = impl-world2)

| variant | before | after | real actions | output cmds before → after |
|---|---|---|---|---|
| 4-1 | 283 | 99 | 92 | 92 → 0 |
| 4-2 | 271 | 95 | 88 | 88 → 0 |
| 4-3 | 298 | 104 | 97 | 97 → 0 |
| 4-4 | 283 | 99 | 92 | 92 → 0 |
| 4-5 | 326 | 156 | 85 | 85 → 0 |
| 4-6 | 271 | 95 | 88 | 88 → 0 |
| 4-7 | 280 | 98 | 91 | 91 → 0 |
| 5-1 | 521 | 179 | 171 | 171 → 0 |
| 5-2 | 527 | 181 | 173 | 173 → 0 |
| 5-3 | 524 | 180 | 172 | 172 → 0 |
| 5-4 | 518 | 178 | 170 | 170 → 0 |
| 5-5 | 545 | 187 | 179 | 179 → 0 |
| 6-1 | 1120 | 438 | 341 | 341 → 0 |
| 6-2 | 1524 | 786 | 369 | 369 → 0 |
| 6-3 | 1221 | 501 | 360 | 360 → 0 |
| 6-4 | 1407 | 475 | 466 | 466 → 0 |

- **Before**: 3 decisions per real action: select, operator no-change and state no-change. The world changed when the command came back complete.
- **After**: 1 decision per real action.
  - For the deduction-only variants, decisions = top-state operators exactly. That is the real actions plus 7 non-task operators: 2 initialization, N print-row and finish.
  - For the guess variants (4-5, 6-1, 6-2, 6-3), the extra decisions are look-ahead. That is the operators applied in evaluate-operator copies (also 1 decision each), plus 1 tie and 1 evaluate-operator no-change per guess decision.
  - No substate is created for any real action.

## Tests

`run.py <dir> <variant>.soar --seeds 1-3 --episodes 3 --cap 3000` for all 16 variants:

- 0 load errors, 0 runtime errors, 0 chunks; every episode halts.
- 15 variants: success in 9/9 episodes.
- 6-1: 8/9. Seed 3, episode 2 ends with `Failure state: the task has failed.` / `TASK-RESULT: failure`.
  - The same seed and episode failed in impl-world.
  - The cause is the same method-level issue described in impl-world/kenken/NOTES.md: a wrong guess can reach the goal count in look-ahead before the contradiction is exposed. It is not caused by this change.
- Messages are unchanged. On seed 2, for 4-5 and 6-3, I compared the old and new versions: the guess-cell choice, the guesses, the printed grid, `The problem has been solved.` and `TASK-RESULT: success` are identical.
  - The only text difference is library logging: the top state no longer prints agent-world's `Apply <op>: ... external.` lines. Internal application rules have no log line.
- The runner's wall times (6-x up to about 25 s, with one outlier of 150 s) were measured with 48 processes running in parallel. They are not comparable with the earlier runs.

## Better / worse

- **Better**:
  - About 3x fewer decisions for deduction-only variants.
  - About 2-2.5x fewer for the guess variants.
  - No output-link traffic. 5 task rules fewer.
  - The top state and look-ahead now share one set of application rules, so the two cannot diverge.
- **Chunking**: no change. 0 chunks before and after. Look-ahead results still depend on local negations, which are disallowed.
  - The top-state actions never produced chunks, because the old substates were empty no-change states.
- **RL**: not used by this task.
- **Look-ahead**: no change. The evaluate-operator states already used the same internal rules, and the guess ties and their outcomes are the same.

## Library problems noticed (lib/world2)

1. `apply*operator*external*argument1*turn-on` (external-operator-application.soar) does not test
   `^internal-actions false` (nor `^quiescence t`). A task operator with `^action-handle turn-on`
   and 1 argument would still send an output command under `^environment none`. This does not affect KenKen.
2. `elaborate*problem-space*internal*evaluate-operator` has no `-^top-state.environment none` test. It is
   harmless, because it also gives `true`, but the no-environment rule and this rule now both fire on evaluate-operator states.
3. The library logs `Apply ... external.` for external applications but has no matching log for
   internal applications. With `^environment none`, the trace at log level 1 shows only `Select ...` lines for the top state.
4. selection-world's top-state success rules still print `kenken achieved ...` and call `(interrupt)`
   at the top state (as before). The runner keeps going; a plain `run` stops there.
