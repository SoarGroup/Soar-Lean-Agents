"""Count output commands and decisions per real (top-state task) action for one episode.
usage: python3 check.py DIR LOADFILE SEED [CAP]
Real actions = top-state selections of task operators (assign, cleanup, eliminate,
drop-combination, prune, choose-guess-cell-*, guess)."""
import os, re, sys, json
import soar_sml as S
TASK = {'assign','cleanup','eliminate','drop-combination','prune','choose-guess-cell-two','choose-guess-cell-three','guess'}
d, load, seed = os.path.abspath(sys.argv[1]), sys.argv[2], int(sys.argv[3])
cap = int(sys.argv[4]) if len(sys.argv) > 4 else 3000
k = S.Kernel.CreateKernelInNewThread(0); a = k.CreateAgent('c'); out = []
a.RegisterForPrintEvent(S.smlEVENT_PRINT, lambda m,u,ag,msg: out.append(msg), None)
os.chdir(d); a.ExecuteCommandLine('source ' + load); a.ExecuteCommandLine(f'srand {seed}')
a.ExecuteCommandLine('watch 1')
cmds = 0; halted = False
for _ in range(cap):
    a.RunSelf(1)
    n = a.GetNumberCommands(); cmds += n
    for i in range(n):
        c = a.GetCommand(i)
        if c.GetParameterValue('status') is None: c.AddStatusComplete()
    if n: a.Commit(); a.ClearOutputLinkChanges()
    if a.GetRunState() == S.sml_RUNSTATE_HALTED: halted = True; break
txt = ''.join(out)
dec = int(re.search(r'(\d+) decisions', a.ExecuteCommandLine('stats')).group(1))
top = sub = 0; top_task = 0; impasses = 0
for m in re.finditer(r'^\s*\d+:( +)O: \S+ \(([^)]+)\)', txt, re.M):
    # top-state operators are printed with no indentation after the decision number
    depth = len(m.group(1))
    if depth == 4:
        top += 1
        if m.group(2) in TASK: top_task += 1
    else: sub += 1
impasses = len(re.findall(r'==>S: \S+ \((state no-change|operator no-change)\)', txt))
ties = len(re.findall(r'==>S: \S+ \(operator tie\)', txt))
res = 'success' if 'TASK-RESULT: success' in txt else 'failure' if 'TASK-RESULT: failure' in txt else None
print(json.dumps(dict(seed=seed, result=res, halted=halted, decisions=dec, output_commands=cmds,
      top_ops=top, top_task_actions=top_task, substate_ops=sub, no_change_impasses=impasses, ties=ties,
      dec_per_action=round(dec/max(top_task,1),2))))
k.Shutdown()
