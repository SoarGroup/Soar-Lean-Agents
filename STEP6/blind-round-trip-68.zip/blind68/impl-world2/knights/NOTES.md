# knights (impl-world2, Phase C)

## Phase C (impl-world2): no external environment, lib/world2

Common to every variant in this family:
- Load file sources lib/world2 instead of lib/world (only path change).
- New top-state elaboration `<task>*elaborate*top-state*environment-none`: (state ^superstate nil)
  --> ^environment none. agent-world (lib/world2) then puts ^internal-actions true on every state,
  so each task operator is applied by its internal application rule (tests ^internal-actions true
  and ^pre-conditions-satisfied true) on the top state, in the decision it is selected. The
  library's external rules (now also testing ^internal-actions false) do not fire: no output
  command is issued (checked: 0 commands on the output-link, seeds 1-3).
- Removed: every `<task>*world*<action>` rule (the response to a completed perform-action command,
  gated by ^effect-applied). Their effects were already in, or have been moved into, the internal
  application rules.
- Messages: the action messages moved from the world-response rules to the top state. Where the
  message only uses values the action does not change, it is a separate top-state rule
  (`*apply*<action>*message`, tests ^superstate nil and the selected operator). Where it prints a
  value the action changes, the write is in the o-supported internal application rule (it fires
  once per application; an i-supported message rule could match again on the new value while the
  operator is still selected). No variant in this family uses look-ahead, so internal applications
  only ever happen in the real world and messages are never printed hypothetically.
- Kept: the wait-indifferent rule (still needed for any state no-change, e.g. hierarchy/MEA cases),
  goal-completed application with TASK-RESULT and halt, `output agent-logs 1 off`, `chunk never`.
- Decisions per real action: before 3 (select; operator no-change while the command was pending;
  state no-change) -> after 1.

## knights-6, knights-8
- jump and backup had no internal application rules before (their effects were only in the
  world-response rules). They now have them: `knights*apply*jump*internal` (+ `*neighbour-degree`)
  and `knights*apply*backup*internal` (+ `*neighbour-degree`, `*neighbour-tried`), the same
  effects as the old world rules, firing together in one decision. record-tour, exhausted and
  finish-run keep their existing internal rules; their messages (`Success! <n> <coord>`,
  `Search complete: ...`, `Run over: ...`) are top-state message rules that test the value the
  action changes (goal 0 / done 0), so they cannot match again. Removed the nine
  `knights*world*<action>` rules.
- Tests (run.py): load ok, 0 errors, every episode runs to the 3000-decision cap (as before; the
  1,000,000-move budget cannot be reached). Each decision is now one jump/backup instead of
  ~3, so the search goes about three times as far: tours found in episode 1, before -> after:
  knights-6 seeds 1-3: 26/28/26 -> 69/78/78; knights-8 seeds 1-3: 0/12/0 -> 0/14/0.
  Decisions per action 3 -> 1 (3000 decisions = 3000 operators, 0 substates).
- Checks: recorded tours (first 4, knights-6 seed 1; first 3, knights-8 seed 2) have N*N distinct
  squares joined by knight moves and close on the start square. Ending paths re-checked on copies
  in /tmp: moves starting at 999,990 gives `Run over: 0 solutions`, then success and halt
  (14 decisions); a 4x4 board gives `Search complete: 0 solutions`, then success and halt.

---

## Earlier notes (impl-world), kept for reference
Where they mention world-response rules, ^effect-applied, output commands or 3 decisions per action,
they are superseded by the Phase C section above.

### knights family (impl-world)

## Choices common to all variants (impl-world)
- Built on agent-world + simple.soar (sourced by absolute path from lib/world). selection-world and
  selection-iterative-deepening are NOT loaded: no variant here calls for search or look-ahead.
  lib/soar-default is not used. Chunking off (`chunk never`).
- Task's initialize operator is proposed when the top state has ^world but no ^name (after
  initialize-agent-world), made better than initialize-agent-world, and creates ^name,
  ^problem-space (^name, ^agent-world true), ^flags (^mea-operator-selection true), the world objects
  (^object-handle, ^anchored true) and the goal as top-state ^desireds (^desired-count set).
- Achieved/unachieved for object-property desireds is task-supplied (generic rule pair per task);
  relation desireds (hanoi ^in) have their own pair.
- Every action is a task operator (^task-operator true, ^action-handle, ^argumentN, ^argument-count,
  ^super-desired, precondition ^desireds with ^desired-count 0 unless stated). The library's generic
  external rules write the perform-action command; since the runner only marks commands complete,
  each task has top-state `<task>*world*<action>` rules (:o-support, gated by ^effect-applied) that
  apply the action's effects and print the action's message when the command is complete.
  Consequence: each action takes about 3 decisions (select; operator no-change while waiting;
  state no-change) instead of 1, so decision counts are ~3x the English's.
- Termination: agent-world proposes goal-completed when the top state has ^success; the task adds an
  application rule for goal-completed that prints the final lines plus `TASK-RESULT: success` and
  halts (the library's goal-completed does not halt).
- simple.soar and agent-world both propose `wait` (worst) in a state no-change; the two waits then
  tie. Each task adds a rule making wait operators indifferent.
- `output agent-logs 1 off` hides the library's (log 1 ...) trace lines so printed output matches
  the English.
- Internal (look-ahead) application rules: written for the simple tasks, though never used (no
  look-ahead); omitted where noted.

## Shared representation (generated rules)
- World objects: squares b11..bNN (^coord rc ^used ^degree ^original-degree ^visit ^previous
  ^neighbor* ^tried*) and tour (^current ^first ^depth ^moves ^frame ^solutions ^goal ^done).
  Choice: square-to-square links (neighbor, previous, current, first) are identifiers of world
  objects; command arguments are handles. Desired: tour ^done 1.
- Task operators (MEA on the done desired): jump (argument1 = target square), backup
  (argument1 = current square; one proposal rule per backup condition, so duplicate backups occur
  as in the English), record-tour, exhausted, finish-run (argument1 = tour). Their effects
  (including neighbour degree changes and tried-mark removal) are world-response rules that fire
  together when the command completes. Preferences as in the English (finish-run > record-tour >
  backup > jump, jump ordering by degree, all indifferent).
- Internal (look-ahead) application rules exist only for record-tour/exhausted/finish-run; jump
  and backup have none (no look-ahead is used).
- The 1,000,000-move budget cannot be reached within the 3000-decision cap (about 3 decisions per
  move), so test runs end at the cap without TASK-RESULT, as the English's runs would. The ending
  paths were checked separately on copies in /tmp: start moves at 999,990 gives `Run over: 0
  solutions`, then success and halt; a 4x4 board gives `Search complete: 0 solutions`, then
  success and halt.
- Tours were checked: the ^previous chain at each recorded tour has N*N distinct squares, all
  knight moves, and closes on the start square.

## knights-6
- Dynamic-degree ordering, best for jumps to degree-1 squares (not 23), backup condition 4 present.
- Tests: load ok, no errors; each episode runs to the cap (3000 decisions); seed 1 found 26 tours
  (`Success! 1 35Success! 2 35...`).

## knights-8
- Original-degree ordering, no degree-1 best preference, no backup condition 4.
- Tests: load ok, no errors; runs to the cap; seed 1 found no tour, seed 2 found 12 (the English
  says the count depends on the seed, including none).
