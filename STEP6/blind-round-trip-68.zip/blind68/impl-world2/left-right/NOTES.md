# left-right (impl-world2, Phase C)

## Phase C (impl-world2): no external environment, lib/world2

Common to every variant in this family:
- Load file sources lib/world2 instead of lib/world (only path change).
- New top-state elaboration `<task>*elaborate*top-state*environment-none`: (state ^superstate nil)
  --> ^environment none. agent-world (lib/world2) then puts ^internal-actions true on every state,
  so each task operator is applied by its internal application rule (tests ^internal-actions true
  and ^pre-conditions-satisfied true) on the top state, in the decision it is selected. The
  library's external rules (now also testing ^internal-actions false) do not fire: no output
  command is issued (checked: 0 commands on the output-link, seeds 1-3).
- Removed: every `<task>*world*<action>` rule (the response to a completed perform-action command,
  gated by ^effect-applied). Their effects were already in, or have been moved into, the internal
  application rules.
- Messages: the action messages moved from the world-response rules to the top state. Where the
  message only uses values the action does not change, it is a separate top-state rule
  (`*apply*<action>*message`, tests ^superstate nil and the selected operator). Where it prints a
  value the action changes, the write is in the o-supported internal application rule (it fires
  once per application; an i-supported message rule could match again on the new value while the
  operator is still selected). No variant in this family uses look-ahead, so internal applications
  only ever happen in the real world and messages are never printed hypothetically.
- Kept: the wait-indifferent rule (still needed for any state no-change, e.g. hierarchy/MEA cases),
  goal-completed application with TASK-RESULT and halt, `output agent-logs 1 off`, `chunk never`.
- Decisions per real action: before 3 (select; operator no-change while the command was pending;
  state no-change) -> after 1.

## left-right
- move: internal application sets location and moved; `Moved: <dir>` is printed by the top-state
  message rule `left-right*apply*move*message`.
- Reward timing: the old `-^operator` test on the reward rules (added because the external wait
  counted the reward twice) was removed. It cannot simply go, though: with one-decision actions
  the move is followed directly by goal-completed, which has no Q-value, so Soar-RL carries move's
  update across goal-completed (an RL gap) and adds the reward of both cycles, discounted:
  Q(left) became -0.57 (= 0.3 * (-1 - 0.9)). The reward rules now test
  `-^operator.name goal-completed` instead, so the reward is counted once. Values after this:
  one left move Q(left) = -0.3; one right Q(right) = +0.3; two rights 0.51, as in the English
  (checked with `print --rl`, seed 1, episodes 1-3: left, right, right).
- Tests: load ok, 0 errors, all episodes success; 2 RL rules. Decisions episode 1: 6 -> 4.
  Output identical to impl-world for seeds 1-12.
- Library observation: agent-world's goal-completed (no RL value) creates the RL gap above; any RL
  task whose last action is followed by goal-completed will double-count a state-based reward
  unless the task gates it. A library option (e.g. a Q-value of 0 for goal-completed, or
  terminating the episode before goal-completed is selected) would remove the need for the gate.

---

## Earlier notes (impl-world), kept for reference
Where they mention world-response rules, ^effect-applied, output commands or 3 decisions per action,
they are superseded by the Phase C section above.

### left-right (impl-world)

## Choices common to all variants (impl-world)
- Built on agent-world + simple.soar (sourced by absolute path from lib/world). selection-world and
  selection-iterative-deepening are NOT loaded: no variant here calls for search or look-ahead.
  lib/soar-default is not used. Chunking off (`chunk never`).
- Task's initialize operator is proposed when the top state has ^world but no ^name (after
  initialize-agent-world), made better than initialize-agent-world, and creates ^name,
  ^problem-space (^name, ^agent-world true), ^flags (^mea-operator-selection true), the world objects
  (^object-handle, ^anchored true) and the goal as top-state ^desireds (^desired-count set).
- Achieved/unachieved for object-property desireds is task-supplied (generic rule pair per task);
  relation desireds (hanoi ^in) have their own pair.
- Every action is a task operator (^task-operator true, ^action-handle, ^argumentN, ^argument-count,
  ^super-desired, precondition ^desireds with ^desired-count 0 unless stated). The library's generic
  external rules write the perform-action command; since the runner only marks commands complete,
  each task has top-state `<task>*world*<action>` rules (:o-support, gated by ^effect-applied) that
  apply the action's effects and print the action's message when the command is complete.
  Consequence: each action takes about 3 decisions (select; operator no-change while waiting;
  state no-change) instead of 1, so decision counts are ~3x the English's.
- Termination: agent-world proposes goal-completed when the top state has ^success; the task adds an
  application rule for goal-completed that prints the final lines plus `TASK-RESULT: success` and
  halts (the library's goal-completed does not halt).
- simple.soar and agent-world both propose `wait` (worst) in a state no-change; the two waits then
  tie. Each task adds a rule making wait operators indifferent.
- `output agent-logs 1 off` hides the library's (log 1 ...) trace lines so printed output matches
  the English.
- Internal (look-ahead) application rules: written for the simple tasks, though never used (no
  look-ahead); omitted where noted.

## left-right
- World: object agent (^location 0 ^moved 0). Desired: agent ^moved 1. Task operator move with two
  instances (argument1 = agent, argument2 = direction -1 / 1, also ^direction), MEA-proposed while
  location 0, indifferent. World response sets location and moved, prints `Moved: <dir>`.
- RL: `rl --set learning on`, learning-rate 0.3, discount-rate 0.9, epsilon-greedy, epsilon 0.1;
  two RL rules (numeric-indifferent, initial 0) keyed on direction, location 0, moved 0.
- Reward: task rules on the top state's reward-link: -1 while location -1, +1 while location 1.
  Choice: because of the external-action wait the location is already changed for two decision
  cycles before the next selection, which counted the reward twice (Q became -0.57). The reward
  rules therefore also require that no operator is selected on the top state, so the reward is
  counted once; after one left move Q(left) = -0.3, after one right Q(right) = +0.3, after two rights
  0.51, as in the English. agent-world's own RL hook (^flags.rl true) is not used.
- Tests: all episodes success, 6 decisions each, 2 RL rules; values learned as above
  (checked with `print --rl`).
