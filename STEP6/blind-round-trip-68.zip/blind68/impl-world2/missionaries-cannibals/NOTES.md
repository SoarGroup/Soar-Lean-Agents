# missionaries-cannibals family (impl-world2: no external environment, lib/world2)

Copied from impl-world/missionaries-cannibals and changed to the `^environment none` mechanism of lib/world2.

## What changed (all four variants; the change is in each variant's mac-core.soar)
- Load files source /home/claude/blind68/lib/world2.
- New rule `mac*elaborate*top-state*environment-none` (top state gets `^environment none`). agent-world then gives
  every state `^internal-actions true`, so `mac*apply*move-boat*internal` (already there for look-ahead) now also
  applies real moves at the top state, changing the real banks. No output command is sent (0 in every run).
- Removed `mac*world*move-boat*complete` (the world-response rule) and its `^effect-applied` marking. Comments
  that described the load as "passed to the output command" were updated.
- Nothing else changed: proposals, failure detection, repeated-state failure, selection rules, RL template and
  rewards, chunking settings and messages are as before.

## Decisions per real action: before -> after
Each move-boat at the top state now takes 1 decision (select + apply), with no operator no-change / state
no-change pair. Before it took 3 (and in mac-rl sometimes more, because agent-world's `wait` operator filled
the state no-change).

| variant | episode 1 decisions, seeds 1/2/3, before -> after | later episodes before -> after |
|---|---|---|
| mac | 11/5/11 -> 5/3/5 (failure after 1-3 moves) | 5-11 -> 3-5 |
| mac-rl | 14/5/5 -> 7/3/3 (failure) | 5-29 -> 3-12 |
| mac-look-ahead | 200/196/206 -> 178/174/184 (success) | 35 -> 13 (11 moves + 2 init) |
| mac-look-ahead-numeric | 184/204/202 -> 162/170/168 (success) | 35-93 -> 13-43 |

In the look-ahead variants the remaining decisions in episode 1 are the tie impasses and evaluations, as before.

## Tests (run.py, seeds 1-3, 3 episodes, cap 3000)
- mac: every episode ends in failure after 1-3 moves with the failure message, `TASK-RESULT: failure`, halt.
- mac-rl: every episode ends in failure (up to 10 moves); RL rules are created (28-56 per seed) and negative values
  learned. Not learned in 3 episodes, as the English says.
- mac-look-ahead: success in every episode; 56-70 chunks as before; later episodes solve with the chunks alone.
- mac-look-ahead-numeric: success in every episode; 94-112 chunks as before.
- No load or runtime errors, no output commands.

## Better / worse
- Better: 2 fewer decisions per real move, and no impasse below the top state during real moves. In the
  look-ahead variants the top-level ties are now the only impasses during real moves.
- RL (mac-rl): better aligned. The reward for a move now appears in the decision right after the move is
  selected and applied, instead of after the agent-world `wait` decisions in the substates, so with SARSA the
  value of each move is updated from the next move directly. Episodes reach more distinct situations per
  decision, so more RL rules are made (e.g. seed 1: 10 -> 56 over 3 episodes).
- Chunking: unchanged (same chunk counts per seed); chunks come from look-ahead, which always used internal
  application.
- Observation (not caused by the library, cause not confirmed): in mac-rl, seed 1 and seed 3, some RL template
  rules made in episode 3 (after two init-soar) have contradictory conditions (two different banks or the
  operator and its load collapsed into one variable, e.g. `rl*mac*rl*move-boat*56`), so they can never match.
  Episodes 1-2 make only well-formed rules. This looks like Soar's template variablization after init-soar
  (identifier names reused); it was not seen in impl-world because there almost no rules were made after
  episode 1. Worth checking separately.

## Library notes
- `apply*operator*external*argument1*turn-on` in external-operator-application.soar does not test
  `^internal-actions false` (nor `^quiescence t`), so a task with an action-handle `turn-on` would still send an
  output command under `^environment none` (and also in look-ahead). `turn-on*time` and `argument3*no-handle2`
  test `^internal-actions false` but not quiescence. Not used here.

---------------------------------------------------------------------------------------------------
## Earlier notes (impl-world, before this change; the statements about output commands, world-response rules
## and 3 decisions per move no longer apply)

# missionaries-cannibals family (impl-world)

The common task knowledge is in each variant's `mac-core.soar`, generated identically except for the proposal
preference and `^better`. Variant-specific rules are in `<variant>-rules.soar`. Libraries: agent-world,
simple.soar, selection-world and selection-iterative-deepening, in the world-notes order.

## Choices common to the family
- **World.** Two bank objects with handles `left` and `right`. Each has `^missionaries ^cannibals ^boat`,
  `^bank-name` and `^other-bank`. The other-bank link is the other bank's handle (a constant), not an
  identifier, because selection-world copies object attributes verbatim and an identifier link would point
  back into the original world (see STA-029).
- **Goal.** Two object-property desireds: right `^missionaries 3` and right `^cannibals 3` (desired-count 2).
  The task supplies achieved/unachieved; agent-world's count rules give `^success`.
- **Failure.** On any state with desireds, if some bank has 0 < missionaries < cannibals, the task elaborates
  `^failure <desireds>`. At the top state, success or failure prints the English message plus
  `TASK-RESULT: ...` and halts.
- **move-boat.** A task-action operator with one proposal rule per load (OPR-016).
  - Proposed while the desireds have `^unachieved-desireds true`, from the bank with the boat, when it holds
    at least the load.
  - argument1 = departure bank; argument2 = the load (`^missionaries ^cannibals`, no handle), passed unchanged
    to the output command.
  - No `^super-desired` is given: the move serves both desireds, and one proposal per unachieved desired
    would duplicate the operators.
- **Applying moves.** Real moves go through agent-world's output rules; a task rule models the world's
  response once per completed command, so each real move costs about 3 decisions. Look-ahead moves use the
  internal application rule, which finds the copied banks by handle.
- **Initialization and output.** Initialization is preferred over initialize-agent-world. The library's
  top-state success/failure messages and interrupts are excised.

## mac
- Moves are proposed `+ =`. Selection is agent-world's epsilon-greedy over indifferent candidates, which is
  uniform here because there are no numeric preferences. Chunking is off.
- **Tests (seeds 1-3, 3 episodes, cap 3000):** every episode ends in failure after 5-11 decisions (1-3
  moves), with the failure message, `TASK-RESULT: failure` and a halt. This matches "almost always reaches a
  failure state within a few moves". No errors.

## mac-rl
- Moves are proposed `+ =`.
- An RL `:template` rule makes one value per (load m, load c, departure name/m/c/boat, arrival name/m/c/boat),
  initially 0. The departure boat flag is written as the constant 1, the only value a proposed move can have.
  Without this, the template instantiated spurious entries when the world changed in the same wave.
- Rewards on the top state's reward-link (Soar sums them): -0.01 always, +1 while `^success`, -1 while
  `^failure`.
- Settings: `rl` learning on, rate 0.1, discount 0.5, SARSA, eligibility-trace-decay-rate 0; epsilon-greedy,
  epsilon 0.1. Chunking off. Values persist across init-soar.
- agent-world's own `^flags.rl` reward rule is not used (no `^flags.rl`).
- **Tests:** every episode ends in failure after 5-29 decisions. RL rules are created, and negative values
  (including the -1 failure reward) are learned. The task is not learned in 3 episodes, as the English says.

## mac-look-ahead
- Moves are proposed `+` only, so ties go to selection-world look-ahead.
- **Look-ahead state.** The task gives it `^problem-space` (name mac) so that proposals and look-ahead-operator
  detection work there. The evaluated (original, uncopied) tied operator is required by selection-world and
  applied internally to the copied world.
- **Repeated-state failure** (look-ahead only). Each evaluate-operator state collects
  `^ancestor-world` = the world of its tied state plus that state's ancestor-worlds, so it covers the top
  state and the look-ahead states above it in the current stack. After its tried move
  (`^tried-tied-operator`), a state whose two banks equal (name, m, c, boat) those of any ancestor world gets
  `^failure`.
- **Preferences.** selection-world maps failure to worst; the English says reject. A task selection rule
  therefore turns failure and exhaustion-failure evaluations into reject for the tied operator. Success
  becomes best and equal symbolic values become indifferent (selection-world).
- **Partial success.** selection-world/ID do not pass partial-success up from nested selections. A nested
  success shows up because the nested tie resolves inside the look-ahead state, which then reaches its own
  `^success`.
- **Depth.** The English says depth is unbounded, so iterative deepening's depth flags (`iterative-step`,
  `init-evaluation-depth`) are deliberately not set. The ID library is loaded, as the conventions require, but
  no depth limit applies. Chunking: `chunk always` (operator-selection knowledge is on by default).
- **Tests:** success in every seed and episode. First episode 196-206 decisions (56-70 chunks); later
  episodes 35 decisions using the chunks.
- **Behaviour difference:** the English reports that the original usually loops forever at the top level
  because of overgeneral learned success/partial-success rules. This build does not reproduce that loop. Its
  chunks from repeated-state failures test the ancestor world, and the world libraries have no partial-success
  pass-back, so the learned rules are not overgeneral in that way.
- Result: partly faithful. The mechanism is as described; the observed looping is not reproduced.

## mac-look-ahead-numeric
- Same as mac-look-ahead, plus `^better higher` on the desireds.
- Each evaluate-operator state, after its tried move, gets `^numeric-value` = right missionaries + right
  cannibals. The evaluation therefore ends after one move (one-step look-ahead).
- Failure (unsafe or repeated) is rejected by the task rule, overriding the score.
- With `^better`, selection-world ranks successes only by number, so a task rule also gives success
  evaluations best, as the English says. Higher is better and equal is indifferent (selection-world).
- **Tests:** success in every seed and episode. First run 184-204 decisions (English 125-135; the external
  round trips add 2 decisions per real move). Later runs 35-93 decisions, with 94-112 chunks.
