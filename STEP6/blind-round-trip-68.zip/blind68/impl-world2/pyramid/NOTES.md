# pyramid (impl-world2, Phase C)

## Phase C (impl-world2): no external environment, lib/world2

Common to every variant in this family:
- Load file sources lib/world2 instead of lib/world (only path change).
- New top-state elaboration `<task>*elaborate*top-state*environment-none`: (state ^superstate nil)
  --> ^environment none. agent-world (lib/world2) then puts ^internal-actions true on every state,
  so each task operator is applied by its internal application rule (tests ^internal-actions true
  and ^pre-conditions-satisfied true) on the top state, in the decision it is selected. The
  library's external rules (now also testing ^internal-actions false) do not fire: no output
  command is issued (checked: 0 commands on the output-link, seeds 1-3).
- Removed: every `<task>*world*<action>` rule (the response to a completed perform-action command,
  gated by ^effect-applied). Their effects were already in, or have been moved into, the internal
  application rules.
- Messages: the action messages moved from the world-response rules to the top state. Where the
  message only uses values the action does not change, it is a separate top-state rule
  (`*apply*<action>*message`, tests ^superstate nil and the selected operator). Where it prints a
  value the action changes, the write is in the o-supported internal application rule (it fires
  once per application; an i-supported message rule could match again on the new value while the
  operator is still selected). No variant in this family uses look-ahead, so internal applications
  only ever happen in the real world and messages are never printed hypothetically.
- Kept: the wait-indifferent rule (still needed for any state no-change, e.g. hierarchy/MEA cases),
  goal-completed application with TASK-RESULT and halt, `output agent-logs 1 off`, `chunk never`.
- Decisions per real action: before 3 (select; operator no-change while the command was pending;
  state no-change) -> after 1.

## pyramid, pyramid-anderson
- add-next-term: internal application (sum += term, term -= 1, height -= 1) also writes
  ` + <term>` (the term changes, so the write is in the o-supported rule). Removed
  `pyramid*world*add-next-term`.
- Tests: all episodes success, same output. Decisions episode 1: pyramid 36 -> 14,
  pyramid-anderson 12 -> 6.

## pyramid-hierarchical
- expand-next-term: internal application (creates the term object, counters) also writes
  ` + <term>`. final-sum: internal application sets sum and summed. Removed
  `pyramid-hierarchical*world*expand-next-term` and `pyramid-hierarchical*world*final-sum`.
- The two composite operators (expand-pyramid, sum-terms) still use their implementation
  substates (2 operator no-change substates per episode); inside them every operator applies in
  one decision. The ^expandable elaboration (keeps expand-pyramid selected while the height
  changes) is task design, not an output workaround, so it is kept.
- Tests: all episodes success, ` + 10 ... + 4`, answer 49. Decisions episode 1: 39 -> 23.

---

## Earlier notes (impl-world), kept for reference
Where they mention world-response rules, ^effect-applied, output commands or 3 decisions per action,
they are superseded by the Phase C section above.

### pyramid family (impl-world)

## Choices common to all variants (impl-world)
- Built on agent-world + simple.soar (sourced by absolute path from lib/world). selection-world and
  selection-iterative-deepening are NOT loaded: no variant here calls for search or look-ahead.
  lib/soar-default is not used. Chunking off (`chunk never`).
- Task's initialize operator is proposed when the top state has ^world but no ^name (after
  initialize-agent-world), made better than initialize-agent-world, and creates ^name,
  ^problem-space (^name, ^agent-world true), ^flags (^mea-operator-selection true), the world objects
  (^object-handle, ^anchored true) and the goal as top-state ^desireds (^desired-count set).
- Achieved/unachieved for object-property desireds is task-supplied (generic rule pair per task);
  relation desireds (hanoi ^in) have their own pair.
- Every action is a task operator (^task-operator true, ^action-handle, ^argumentN, ^argument-count,
  ^super-desired, precondition ^desireds with ^desired-count 0 unless stated). The library's generic
  external rules write the perform-action command; since the runner only marks commands complete,
  each task has top-state `<task>*world*<action>` rules (:o-support, gated by ^effect-applied) that
  apply the action's effects and print the action's message when the command is complete.
  Consequence: each action takes about 3 decisions (select; operator no-change while waiting;
  state no-change) instead of 1, so decision counts are ~3x the English's.
- Termination: agent-world proposes goal-completed when the top state has ^success; the task adds an
  application rule for goal-completed that prints the final lines plus `TASK-RESULT: success` and
  halts (the library's goal-completed does not halt).
- simple.soar and agent-world both propose `wait` (worst) in a state no-change; the two waits then
  tie. Each task adds a rule making wait operators indifferent.
- `output agent-logs 1 off` hides the library's (log 1 ...) trace lines so printed output matches
  the English.
- Internal (look-ahead) application rules: written for the simple tasks, though never used (no
  look-ahead); omitted where noted.

## pyramid, pyramid-anderson
- World: object `pyramid` (^term ^height ^sum); pyramid: 5/10/0, pyramid-anderson: 5/2/0.
  Desired: pyramid ^height -1. Task operator add-next-term (argument1 = pyramid), MEA-proposed on
  the unachieved desired while height >= 0, indifferent. World response: sum += term, term -= 1,
  height -= 1, prints ` + <old term>`. goal-completed prints newline, `The answer is <sum>.`,
  newline, `The problem has been solved.`.
- Tests: all episodes success. pyramid prints ` + 5 + 4 ... + -5`, answer 0, 36 decisions;
  pyramid-anderson ` + 5 + 4 + 3`, answer 12, 12 decisions.

## pyramid-hierarchical
- World: object pyramid (^term 10 ^height 6 ^generated 0 ^sum 0 ^summed 0). Choice: the term records
  ("on the top state" in the English) are kept in ^world as objects (handle term-<i>, ^index ^value),
  since the world holds the task situation.
- Goal: pyramid ^summed 1. The two top-level actions are complex composite task operators (cCTO):
  expand-pyramid (^effect-desireds pyramid ^height -1) and sum-terms (^effect-desireds pyramid
  ^summed 1); agent-world turns the effect-desireds into the implementation substate's ^desireds.
- To keep expand-pyramid selected while height changes (English: it remains selected), its proposal
  tests a state elaboration ^expandable <pyramid> (held while height >= 0) instead of the height WME.
- expand-pyramid substate: task operator expand-next-term (creates the term object; counters; prints).
- sum-terms substate: initialise-local and add-term are internal operators (^task-operator false)
  that change the substate's own ^local-sum/^next-index (not the world); final-sum is a task
  operator (argument1 = pyramid, argument2 = local sum, a constant) whose world response sets sum
  and summed.
- Tests: all episodes success, ` + 10 + 9 + 8 + 7 + 6 + 5 + 4`, answer 49, 39 decisions.
