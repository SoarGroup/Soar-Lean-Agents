# towers-of-hanoi (impl-world2, Phase C)

## Phase C (impl-world2): no external environment, lib/world2

Common to every variant in this family:
- Load file sources lib/world2 instead of lib/world (only path change).
- New top-state elaboration `<task>*elaborate*top-state*environment-none`: (state ^superstate nil)
  --> ^environment none. agent-world (lib/world2) then puts ^internal-actions true on every state,
  so each task operator is applied by its internal application rule (tests ^internal-actions true
  and ^pre-conditions-satisfied true) on the top state, in the decision it is selected. The
  library's external rules (now also testing ^internal-actions false) do not fire: no output
  command is issued (checked: 0 commands on the output-link, seeds 1-3).
- Removed: every `<task>*world*<action>` rule (the response to a completed perform-action command,
  gated by ^effect-applied). Their effects were already in, or have been moved into, the internal
  application rules.
- Messages: the action messages moved from the world-response rules to the top state. Where the
  message only uses values the action does not change, it is a separate top-state rule
  (`*apply*<action>*message`, tests ^superstate nil and the selected operator). Where it prints a
  value the action changes, the write is in the o-supported internal application rule (it fires
  once per application; an i-supported message rule could match again on the new value while the
  operator is still selected). No variant in this family uses look-ahead, so internal applications
  only ever happen in the real world and messages are never printed hypothetically.
- Kept: the wait-indifferent rule (still needed for any state no-change, e.g. hierarchy/MEA cases),
  goal-completed application with TASK-RESULT and halt, `output agent-logs 1 off`, `chunk never`.
- Decisions per real action: before 3 (select; operator no-change while the command was pending;
  state no-change) -> after 1.

## towers-of-hanoi
- move-disk: the existing internal rules (`*apply*move-disk*internal`, `...*control*smallest`,
  `...*control*other`) make the full effect (on/in relations and the control record). Removed:
  `towers-of-hanoi*world*move-disk` and its two control-record companions. `Move Disk: <size> to
  peg <peg>` is printed by the top-state rule `towers-of-hanoi*apply*move-disk*message`.
- Tests: all episodes success, same 31-move sequence. Decisions episode 1: 96 -> 34 (31 moves +
  2 initialisations + goal-completed).

## towers-of-hanoi-mea
- move-disk: internal rule applies it in whatever state it is selected (top state or an MEA
  operator no-change substate; both share the real ^world). Removed `towers-of-hanoi*world*move-disk`.
  The message rule (`towers-of-hanoi*apply*move-disk*message`) tests ^internal-actions true rather
  than ^superstate nil, because moves are made inside MEA substates too.
- The MEA operator subgoals are kept (they are the method, not a wait): 26 operator no-change
  substates, as before, but no state no-change substates any more. A move selected in a substate
  applies in its decision; when that makes the blocked superstate move legal, the blocked move is
  applied in the same decision (its ^pre-conditions-satisfied appears and its internal rule fires
  for the operator still selected above) and the substate goes away. So the two moves print in
  one decision (e.g. `Move Disk: 1 to peg CMove Disk: 2 to peg B`), matching the English
  ("as soon as the blocked move becomes legal it is executed").
- Tests: all episodes success, same 31-move sequence. Decisions episode 1: 122 -> 60 (English
  about 48; the rest is the operator no-change per blocked move plus initialisation).

---

## Earlier notes (impl-world), kept for reference
Where they mention world-response rules, ^effect-applied, output commands or 3 decisions per action,
they are superseded by the Phase C section above.

### towers-of-hanoi family (impl-world)

## Choices common to all variants (impl-world)
- Built on agent-world + simple.soar (sourced by absolute path from lib/world). selection-world and
  selection-iterative-deepening are NOT loaded: no variant here calls for search or look-ahead.
  lib/soar-default is not used. Chunking off (`chunk never`).
- Task's initialize operator is proposed when the top state has ^world but no ^name (after
  initialize-agent-world), made better than initialize-agent-world, and creates ^name,
  ^problem-space (^name, ^agent-world true), ^flags (^mea-operator-selection true), the world objects
  (^object-handle, ^anchored true) and the goal as top-state ^desireds (^desired-count set).
- Achieved/unachieved for object-property desireds is task-supplied (generic rule pair per task);
  relation desireds (hanoi ^in) have their own pair.
- Every action is a task operator (^task-operator true, ^action-handle, ^argumentN, ^argument-count,
  ^super-desired, precondition ^desireds with ^desired-count 0 unless stated). The library's generic
  external rules write the perform-action command; since the runner only marks commands complete,
  each task has top-state `<task>*world*<action>` rules (:o-support, gated by ^effect-applied) that
  apply the action's effects and print the action's message when the command is complete.
  Consequence: each action takes about 3 decisions (select; operator no-change while waiting;
  state no-change) instead of 1, so decision counts are ~3x the English's.
- Termination: agent-world proposes goal-completed when the top state has ^success; the task adds an
  application rule for goal-completed that prints the final lines plus `TASK-RESULT: success` and
  halts (the library's goal-completed does not halt).
- simple.soar and agent-world both propose `wait` (worst) in a state no-change; the two waits then
  tie. Each task adds a rule making wait operators indifferent.
- `output agent-logs 1 off` hides the library's (log 1 ...) trace lines so printed output matches
  the English.
- Internal (look-ahead) application rules: written for the simple tasks, though never used (no
  look-ahead); omitted where noted.

## Shared representation
- World objects: pegs A B C (^type peg), disk-1..disk-5 (^size), base-A/B/C (^size 6), ground
  (^size 7), control (^last-moved-size 2 ^smallest-last-source B). Position records are the world
  relations ^on (argument1 disk, argument2 disk below) and ^in (argument1 disk, argument2 peg).
- Goal: five relation desireds ^in (disk-k, C), desired-count 5. Achievement rules for ^in desireds.
- Task operator move-disk (argument1 = disk, argument2 = target peg). The world response puts the
  disk on the target peg's clear disk and prints `Move Disk: <size> to peg <peg>`.

## towers-of-hanoi
- Proposals are the two cases of the smallest-disk rule (control object). Choice: these are not
  MEA proposals (a move does not serve one particular desired), so they carry no ^super-desired and
  test only that the top desireds still have an unachieved desired (W-TOP-019 allows a non-MEA
  proposal). Control-record updates are separate world-response rules by disk size.
- Tests: all episodes success, the 31-move optimal sequence, 96 decisions.

## towers-of-hanoi-mea
- MEA with agent-world operator subgoaling. Legality is a derived i-supported disk property
  ^movable-to <peg> (disk clear and the peg's top disk larger). Each move's precondition ^desireds is
  one desired (disk ^movable-to target); an illegal selected move gets agent-world's operator
  no-change substate whose desireds duplicate that precondition, which stands for "get disk d onto
  the target peg". The task gives MEA substates the task's problem space (W-MEA-006).
- Top-level proposal: for the unachieved (disk in C) desired whose disk has every larger disk 1-5
  on C. Subgoal proposals (clear X; clear the destination) as in the English, with ^reason-disk.
- When the blocked move's precondition holds, agent-world's generic external rule issues it in the
  state where it was selected and the subgoal disappears. Control object created, unused.
- Tests: all episodes success, the same 31-move sequence, 122 decisions (English ~48).
