# water-jug family: impl-world2 notes (no external environment)

Copied from `impl-world/water-jug` (see its NOTES.md for the design, which is unchanged except as
listed here). All nine variants load `lib/world2`.
Test: `python3 tools/run.py <dir> <variant>.soar --seeds 1-3 --episodes 3 --cap 3000`, plus a
per-decision check (outside the tree) that counts output commands and, for every top-level
fill / empty / pour instance, the decisions in which it is the selected top-state operator.
0 load errors, 0 runtime errors, 0 warnings in every run.

## What changed

1. **lib/world -> lib/world2** in every load file.
2. **`water-jug*elaborate*environment*none`** (all variants, `water-jug-rules.soar`): the top
   state gets `^environment none`, so agent-world gives every state, the top state included,
   `^internal-actions true`.
3. **Removed** (all variants): the four o-supported "world's response" rules
   (`water-jug*world*{fill,empty,pour*overflow,pour*all}*complete`) and with them every
   `^effect-applied` test and mark. The existing internal application rules
   (`water-jug*apply*{fill,empty,pour*...}*internal`) now apply the real actions as well; they
   were already complete (they make the full world change). Header comments updated.
4. **tie, tie-chunk: last-operator.** The workaround that set `^last-operator` when the command
   completed is gone. `water-jug*apply*task-operator*last-operator` now fires on the selected
   task operator in its own apply phase. That is safe because every task operator's proposal
   retracts once it has applied, so the change cannot reopen a tie for that operator.
5. **look-ahead, look-ahead-failure-states, look-ahead-rl: visited lists.**
   - The real-situation record (`^flags.avoid-visited-real`) used to fire on a completed command.
     It now fires when a task operator is applied on the top state:
     `water-jug*world*record-visited*operator` and `water-jug*world*record-visited`.
   - Both rules are guarded by `^recorded-operator <o>`. The selected operator stays selected for
     the rest of the apply phase, when the jugs already hold the new contents. Without the guard,
     the new situation was recorded too.
   - Repeats are still not added. A first version that allowed repeats made failure-states seed 1
     (which cycles) slow to a crawl: ancestor-visited matches and chunk instantiations grew with
     the list, and the run did not finish 3000 decisions in 10 minutes.
   - The simulation-only record rule `water-jug*apply*record-visited` now tests
     `^superstate <> nil`. Otherwise it would also fire on the top state (now
     `^internal-actions true`) and fill the top state's `^visited` even with the switch off.
6. **hierarchy, hierarchy-chunk:**
   - pick-up / fill-jug / put-down already changed the world directly. That was a workaround
     around the output rules' `^quiescence t`.
   - Their application rules now test `^internal-actions true`, like every other task
     operator's internal application rule. The comment was rewritten.
   - The learned chunks now carry `^internal-actions true` (from `^environment none`). There are
     still exactly 3 chunks.

Nothing else was changed. Messages, the TASK-RESULT line and the halt are unchanged
("The problem has been solved." / "TASK-RESULT: success").

## Results (seeds 1-3, 3 episodes; decisions, run.py count)

No output commands were issued in any run. The per-decision check found 1 decision per real
action for fill / empty / pour in all variants, including inside look-ahead and tie variants. The
exception is the hierarchy's composite fill, which still uses its substate:
- hierarchy: 5 decisions, both before and after;
- hierarchy-chunk: 1 decision once the chunks exist.

Before, every task operator took 3 decisions (hierarchy empty/pour: 3).

| variant | result | seed 1 ep 1 before -> after | all episodes |
|---|---|---|---|
| water-jug | works | 276 -> 94 | 9/9 solved, 16-720 |
| water-jug-rl | works | 36 -> 14 | 9/9, 7-445 |
| water-jug-tie | works | 70 -> 54 | 9/9, 28-347 |
| water-jug-tie-chunk | works | 99 -> 45 | 9/9, 7-46; 5 chunks, the same five rules |
| water-jug-hierarchy | works | 293 -> 213 | 9/9, 58-2046 |
| water-jug-hierarchy-chunk | works | 161 -> 81 | 9/9, 22-790; 3 chunks |
| water-jug-look-ahead | works | 187 -> 175 | 9/9; first 159-175, later 9 (was 21) |
| water-jug-look-ahead-failure-states | partly (as before) | 3000 (cycle) -> 3000 (cycle) | 6/9: seed 1 still cycles (3,0)->(0,3)->(3,3); seeds 2-3: 109/181 first, then 7/11 |
| water-jug-look-ahead-rl | works | 121 -> 77 | 9/9; first 77-206, later 12-36; 8-13 RL rules |

## Better / worse

- **Behaviour is identical action for action.** With the same seed, every variant takes the same
  sequence of real actions as before; only the bookkeeping decisions disappear. For example, for
  a run with n actions:
  - water-jug: 3n+3 -> n+3 decisions;
  - look-ahead: the search costs the same, and each real action saves 2 decisions.

  Extra checks:
  - RL over 10 episodes: same action counts per episode; seed 3 converges to the 4-action
    solution, 7 decisions (was 15).
  - failure-states seeds 4-9: same outcomes (seed 4 cycles); later episodes 7-11 decisions
    (were 15-27).
- **RL:** the extra bookkeeping decisions did not change what was learned in this task: the same
  choices were made and the same rules were learned. The NOTES' remark that "the effective
  discount per action is smaller" therefore did not matter here. It no longer applies at all,
  because one action is one decision.
- **Chunking:** unchanged results. tie-chunk learns the same 5 rules. hierarchy-chunk learns the
  same 3, now conditioned on `^internal-actions true`. look-ahead chunk counts are the same as
  before (26/31/26; 35/25/46; 27-52).
- **Look-ahead:** no change in search; only the real steps are cheaper.
- **Nothing got worse,** apart from the visited-list guard that the one-decision application
  needs (item 5).

## Library observations (lib/world2)

1. The internal application rules of a task now also set `^task-operator-applied true` on the
   top state. It is o-supported and never removed. That is harmless here, because only the
   simulated-state checks test it. But any rule or library code that reads it as "a simulated
   operator has applied" would now also match the real top state. The library might want to
   remove it or give it a name specific to look-ahead.
2. Rules that record something "when the operator is applied" see the operator still selected
   after its own world change, in later waves of the same apply phase. Before, the real top state
   avoided this by keying on the command (`^effect-applied`). Now every such task rule needs its
   own once-per-operator guard, as look-ahead rules already did. This is worth a line in the
   conventions.
3. The brief says that only the one-argument external rules test `^internal-actions false`. In
   lib/world2, every external application rule and both report rules test it.
   - When I first read the file during this work, `apply*operator*external*argument1*turn-on`
     lacked the test. It had the test by the end, so the file was edited while I worked.
   - The water-jug runs above were not affected, because water-jug has no turn-on.
4. For real actions, the log line now reads "Apply fill: jug-a internal." It is a log-1 line, not
   one of the task's messages.
