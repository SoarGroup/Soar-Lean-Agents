"""Collect run results into rows: one per (impl, family, variant)."""
import json, os, re, glob, statistics as st
B = '/home/claude/blind68'
IMPLS = [('Original', 'src', 'results/baseline'), ('Standard', 'impl-soar', 'results/impl-soar'), ('World', 'impl-world', 'results/impl-world'), ('World-NoEnv', 'impl-world2', 'results/impl-world2')]
variants = [tuple(x) for x in json.load(open(f'{B}/variants.json'))]

def excised(d):
    n = 0
    for f in glob.glob(d + '/**/*.soar', recursive=True):
        for line in open(f, errors='replace'):
            l = line.split('#')[0].strip()
            if l.startswith('excise'):
                n += max(1, len(l.split()) - 1)
    return n

def files_and_lines(d, impl):
    files = [f for f in glob.glob(d + '/**/*.soar', recursive=True) if '/default/' not in f]
    return len(files), sum(sum(1 for _ in open(f, errors='replace')) for f in files)

def collect():
    rows, raw = [], []
    for impl, root, res in IMPLS:
        for fam, v in variants:
            d = f'{B}/{root}/{fam}/{v}'
            p = f'{B}/{res}/{fam}--{v}.jsonl'
            r = dict(impl=impl, family=fam, variant=v, present=os.path.isdir(d))
            seeds = []
            if os.path.exists(p):
                for line in open(p):
                    try: seeds.append(json.loads(line))
                    except Exception: pass
            r['seeds_run'] = len(seeds)
            if seeds:
                s0 = seeds[0]
                r['user_rules'] = s0.get('user_rules'); r['library_rules'] = s0.get('default_rules')
                r['load_errors'] = max(s.get('load_errors', 0) for s in seeds)
                r['rl_rules'] = round(st.mean(s.get('rl_rules', 0) for s in seeds), 1)
                for k, idx in (('ep1', 0), ('ep3', -1)):
                    eps = [s['episodes'][idx] for s in seeds if s.get('episodes')]
                    if not eps: continue
                    r[f'{k}_success'] = sum(e['result'] == 'success' for e in eps)
                    r[f'{k}_failure'] = sum(e['result'] == 'failure' for e in eps)
                    r[f'{k}_halted'] = sum(e['halted'] for e in eps)
                    r[f'{k}_decisions'] = round(st.mean(e['decisions'] for e in eps), 1)
                    r[f'{k}_cpu_s'] = round(st.mean((e['kernel_cpu_s'] or 0) for e in eps), 4)
                    r[f'{k}_wall_s'] = round(st.mean(e['wall_s'] for e in eps), 3)
                    r[f'{k}_chunks'] = round(st.mean((e['chunks'] or 0) for e in eps), 1)
                r['runtime_errors'] = sum(e['runtime_errors'] for s in seeds for e in s['episodes'])
                r['warnings'] = sum(e['warnings'] for s in seeds for e in s['episodes'])
                r['episodes'] = len(seeds[0].get('episodes', []))
                for s in seeds:
                    for i, e in enumerate(s['episodes']):
                        raw.append(dict(impl=impl, family=fam, variant=v, seed=s['seed'], episode=i + 1, **e))
            if r['present']:
                r['excised_library_rules'] = excised(d)
                r['source_files'], r['source_lines'] = files_and_lines(d, impl)
            rows.append(r)
    return rows, raw

if __name__ == '__main__':
    rows, raw = collect()
    json.dump(dict(rows=rows, raw=raw), open(f'{B}/results/collected.json', 'w'), indent=0)
    print(len(rows), len(raw))
