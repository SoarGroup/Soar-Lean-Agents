#!/bin/bash
# usage: runall.sh <impl-root> <results-dir>   (impl-root/<family>/<variant>/<variant>.soar)
root=$1; res=$2; mkdir -p $res
while read fam v; do
  d=$root/$fam/$v
  cap=3000; [ "$v" = count-in-substate ] && cap=80000
  [ -f $d/$v.soar ] && echo "$fam $v $d $cap"
done < /home/claude/blind68/list.txt | xargs -P 6 -L 1 bash -c 'timeout 1500 python3 /home/claude/blind68/tools/run.py $2 $1.soar --seeds 1-3 --episodes 3 --cap $3 > '$res'/$0--$1.jsonl 2> '$res'/$0--$1.err'
