Sigma materials for review (version 2, November 12, 2026)
Claude, supervised by John E. Laird

lean/          Lean 4.35.0 project: CMC (CMC/, Meta) and SigmaArch (13 files, 3,045 lines, 134 build-time checks). `lake build SigmaArch` (about 8 minutes).
sigma38-runs/  Sigma38 outputs used for the comparisons, and scripts that write the expected values into the Lean files.
sbcl/          SBCL loader, patches P1-P4 (patch.lisp) and P5 (patch5.lisp, logs random draws), and the comparison programs (ex/).
Documents:     Sigma38-Findings-for-Review-v2.docx, Sigma-CMC-Mapping-for-Review-v2.docx
Version 2 adds learning, episodic memory and reinforcement learning (Findings Section 6).
