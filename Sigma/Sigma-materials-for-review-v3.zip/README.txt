Sigma materials for review (version 3, November 16, 2026)
Claude, supervised by John E. Laird

lean/          Lean 4.35.0 project: CMC (CMC/, Meta) and SigmaArch (13 files, 3,045 lines, 134 build-time checks). `lake build SigmaArch` (about 8 minutes).
sigma38-runs/  Sigma38 outputs used for the comparisons, and scripts that write the expected values into the Lean files.
               lispworks/: Paul Rosenbloom's LispWorks traces of (test-eight-puzzle) and (ultimatum-soft), and compare_lispworks.py, which compares them with the SBCL runs.
sbcl/          SBCL loader, patches P1-P4 (patch.lisp) and P5 (patch5.lisp, logs random draws), and the comparison programs (ex/).
Documents:     Sigma38-Findings-for-Review-v3.docx, Sigma-CMC-Mapping-for-Review-v3.docx

Version 3 adds:
- Paul Rosenbloom's answers (Findings Section 10, Mapping Section 6) and John Laird's decisions of November 16, 2026 (Mapping Section 6.3).
- The LispWorks comparison: the Eight Puzzle and the soft ultimatum game match the SBCL runs, so patches P1-P4 change no result on them.
- The USC licence notice (2-clause BSD) at the top of patch.lisp and patch5.lisp, which contain modified copies of Sigma38 functions.
- Comments only in lean/SigmaArch/Conform.lean and Adapt.lean, recording the review and the decisions. No definition, theorem or check changed; not rebuilt.

Version 2 added learning, episodic memory and reinforcement learning (Findings Section 6).
