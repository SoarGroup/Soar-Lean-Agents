import SigmaArch.Learn
/-!
# Reinforcement learning in Sigma38 (`rl-grid8`)

The release's one-dimensional grid for reinforcement learning (`tests.lisp`, `init-rl-grid8`,
`test-rl-mb`), compared with Sigma38 decision by decision.
-/

namespace SigmaArch.RL

/-! ## The value backup (finding R1)

`backup-projected` and `backup-q` put the value `0.95 * (p + r)` into a function over utility
values, where `p` is the projected utility of the next location and `r` its reward. Sigma38 was
run on two small programs with learning off (`ex-bk.lisp`); the function sent to the action is
read from its `trace-affine` output. -/
namespace BackupTest

def prog : Prog :=
  { preds := [ { name := "Proj", args := [⟨"value", 10, .unique⟩], world := .openWorld },
               { name := "Rew", args := [⟨"value", 10, .unique⟩], world := .openWorld },
               { name := "Out", args := [⟨"value", 10, .unique⟩], world := .openWorld } ]
    conds := [ { name := "bk",
                 conds := [⟨"Rew", [.var "r"], false⟩, ⟨"Proj", [.var "p"], false⟩]
                 actions := [⟨"Out", [.const 0], false⟩],
                 spreads := [(0, "p", "r", 19 / 20)] } ] }

def msg (pf rf : List (Tup × Val)) : List Val :=
  let A : Assump := { wm := fun _ => Fn.const 0,
                      ltm := fun n => if n == "Proj" then some (Fn.ofRows pf)
                                     else if n == "Rew" then some (Fn.ofRows rf) else none }
  match elaborate prog A 20 with
  | some ms => ((ms.headD ⟨[], []⟩).acts.headD ⟨[]⟩).tbl.map (·.2)
  | none => []

def agrees (a b : List Val) : Bool :=
  a.length == b.length && (a.zip b).all fun (x, y) => near x y (1 / 1000000)

/- One value each: p = 3 and r = 2 give 5, scaled to the region [4.275, 5.225). -/
#guard agrees (msg [([3], 1)] [([2], 1)]) [0, 0, 0, 0, 0.2249999, 0.7249999, 0, 0, 0, 0]
/- Two values each: the offset is the smallest maximal r for each p. -/
#guard agrees (msg [([3], 1/2), ([5], 1/2)] [([0], 1/4), ([2], 3/4)])
  [0, 0, 0, 0, 0.084374964, 0.27187496, 0.12187511, 0.234375, 0, 0]

end BackupTest

/-! ## The grid (`rl-grid8`, model-based, learning by gradient descent)

A line of 8 locations; the agent starts at location 1, may go left or right, and the trial
halts at location 4. The reward is 9 at location 4 and 0 elsewhere, perceived at the current
location before each decision. The utility of a location (`Projected`) and of an operator at
a location (`Q`) are distributions over 10 utility values, backed up with discount 0.95 and
learned by gradient descent; the transition function is given and not learned.
Operators: left = 0, right = 1. -/

def v (x : String) : Term := .var x
def k (n : Nat) : Term := .const n

def preds : List Pred :=
  [ { name := "State", args := [⟨"state", 1, .universal⟩], world := .closedWorld },
    { name := "Location", args := [⟨"state", 1, .universal⟩, ⟨"x", 8, .unique⟩],
      world := .closedWorld, sel := some .argmax },
    { name := "Selected", args := [⟨"state", 1, .universal⟩, ⟨"operator", 2, .unique⟩],
      world := .closedWorld, sel := some .boltzmann },
    { name := "Projected", args := [⟨"x", 8, .universal⟩, ⟨"value", 10, .unique⟩],
      world := .openWorld },
    { name := "ProjectedNext", args := [⟨"x", 8, .universal⟩, ⟨"value", 10, .unique⟩],
      world := .openWorld },
    { name := "Reward", args := [⟨"x", 8, .universal⟩, ⟨"value", 10, .unique⟩],
      world := .openWorld },
    { name := "Q", args := [⟨"x", 8, .universal⟩, ⟨"operator", 2, .universal⟩,
                            ⟨"value", 10, .unique⟩], world := .openWorld },
    { name := "LocationNext", args := [⟨"state", 1, .universal⟩, ⟨"x", 8, .unique⟩],
      world := .openWorld },
    { name := "Trans", args := [⟨"x", 8, .universal⟩, ⟨"operator", 2, .universal⟩,
                                ⟨"next", 8, .unique⟩], world := .openWorld },
    { name := "Halt", args := [], world := .closedWorld } ]

def st : Pat := ⟨"State", [v "s"], false⟩
def loc : Pat := ⟨"Location", [v "s", v "x"], false⟩
def sel (o : Term) : Pat := ⟨"Selected", [v "s", o], false⟩
def locNext : Pat := ⟨"LocationNext", [v "s", v "nx"], false⟩

def conds : List Conditional :=
  [ { name := "q-c", conds := [st, loc], condacts := [⟨"Q", [v "x", v "o", v "q"], false⟩] },
    { name := "select-operator"
      conds := [st, loc, ⟨"Q", [v "x", v "o", v "q"], false⟩]
      actions := [sel (v "o")], filters := [("q", 0, 1 / 10)], sumVars := ["q"] },
    { name := "transition"
      conds := [st, loc, sel (v "o")]
      condacts := [locNext, ⟨"Trans", [v "x", v "o", v "nx"], false⟩] },
    { name := "backup-projected"
      conds := [st, loc, sel (v "o"), locNext, ⟨"Reward", [v "nx", v "r"], false⟩,
                ⟨"ProjectedNext", [v "nx", v "p"], false⟩]
      actions := [⟨"Projected", [v "x", k 0], false⟩]
      spreads := [(0, "p", "r", 19 / 20)], sumVars := ["nx"] },
    { name := "backup-q"
      conds := [st, loc, sel (v "o"), locNext, ⟨"Reward", [v "nx", v "r"], false⟩,
                ⟨"ProjectedNext", [v "nx", v "p"], false⟩]
      actions := [⟨"Q", [v "x", v "o", k 0], false⟩]
      spreads := [(0, "p", "r", 19 / 20)], sumVars := ["nx"] },
    { name := "move-left"
      conds := [st, sel (k 0), loc]
      actions := [⟨"Location", [v "s", .off "x" (-1)], false⟩] },
    { name := "move-right"
      conds := [st, sel (k 1), loc]
      actions := [⟨"Location", [v "s", .off "x" 1], false⟩] },
    { name := "no-zero"
      conds := [st, ⟨"Location", [v "s", k 1], false⟩]
      actions := [⟨"Selected", [v "s", k 0], true⟩] },
    { name := "no-seven"
      conds := [st, ⟨"Location", [v "s", k 6], false⟩]
      actions := [⟨"Selected", [v "s", k 1], true⟩] },
    { name := "halt"
      conds := [⟨"Location", [k 0, k 4], false⟩]
      actions := [⟨"Halt", [], false⟩] } ]

def prog : Prog := { preds := preds, conds := conds }

/-- The functions as first given (`init-rl-grid8`); 0.1 where nothing is said. -/
def fQ : Fn := fun t => match t with
  | [x, o, val] =>
    if (x == 0 || x == 1) && o == 0 then (if val == 0 then 1 else 0)
    else if (x == 6 || x == 7) && o == 1 then (if val == 0 then 1 else 0)
    else 1 / 10
  | _ => 0
def fProj : Fn := fun t => match t with
  | [x, val] => if x == 0 || x == 4 || x == 7 then (if val == 0 then 1 else 0) else 1 / 10
  | _ => 0
def fRew : Fn := fun t => match t with
  | [x, val] => if x == 0 || x == 7 then (if val == 0 then 1 else 0) else 1 / 10
  | _ => 0
def fTrans : Fn := fun t => match t with
  | [x, o, nx] =>
    let target := if o == 0 then (if x == 0 then 0 else x - 1) else (if x == 7 then 7 else x + 1)
    if nx == target then 1 else 0
  | _ => 0

def tQ : Tab := Tab.ofFn [8, 2, 10] fQ
def tProj : Tab := Tab.ofFn [8, 10] fProj
def tRew : Tab := Tab.ofFn [8, 10] fRew
def tTrans : Tab := Tab.ofFn [8, 2, 8] fTrans

def sys : Sys :=
  { P := prog
    ltm := fun n => if n == "Q" then some tQ.fn else if n == "Projected" then some tProj.fn
      else if n == "Reward" then some tRew.fn else if n == "Trans" then some tTrans.fn else none
    detectImpasses := false
    alias := [("ProjectedNext", "Projected")] }

def learned : List String := ["Q", "Projected", "Reward"]

def rewards : List Nat := [0, 0, 0, 0, 9, 0, 0, 0]

def wm0 (start : Nat) : String → Fn := fun pn =>
  if pn == "State" then Fn.ofRows [([0], 1)]
  else if pn == "Location" then Fn.ofRows [([0, start], 1)]
  else fun _ => 0

def curLoc (cs : CogState) : Nat :=
  ((List.range 8).find? fun x => 0 < cs.wm "Location" [0, x]).getD 0

/-- The reward perceived before a decision: 1 for the reward of the current location and 0 for
the other utilities there, 0.1 everywhere else (`assign-reward`). -/
def pbAt (cs : CogState) : String → Option Fn := fun n =>
  if n == "Reward" then
    let cl := curLoc cs
    some fun t => match t with
      | [x, val] => if x == cl then (if val == rewards.getD cl 0 then 1 else 0) else 1 / 10
      | _ => 0
  else none

def step (temp draw : Val) (s : LState) : LState :=
  cycleLearn { sys with boltz := (temp, draw) } {} learned (pbAt s.cog) 0 s

/-- One trial: start state, then decisions until `Halt` is positive. -/
def trial (temp : Val) (draws : List Val) (s : LState) : List LState :=
  let rec go : List Val → LState → List LState
    | [], _ => []
    | d :: ds, s =>
      if s.cog.halted sys then []
      else let s' := step temp d s; s' :: go ds s'
  go draws s

def init0 (start : Nat) : LState := { cog := { wm := wm0 start }, ltm := [] }

def d1 : List Val := [0.62944734, 0.81158376, 0.2539736, 0.8267517, 0.2647184, 0.19508076,
  0.55699635, 0.093762994, 0.91501355, 0.929777, 0.31522608]

def run1 : List LState := trial 0.28853902 d1 (init0 1)

def show1 (s : LState) : String :=
  s!"loc={curLoc s.cog} sel={(List.range 2).map fun o => s.cog.wm "Selected" [0, o]} halt={s.cog.halted sys}"

#eval run1.map show1
end SigmaArch.RL
