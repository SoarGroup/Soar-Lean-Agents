; This file contains modified copies of functions from the Sigma38 release (Sigma cognitive
; architecture, University of Southern California). They are redistributed under the
; release's licence, whose notice follows. Modifications by Claude, supervised by John E. Laird,
; November 12, 2026; each change is described where it is made.
;
; Copyright 2009-2014 University of Southern California. All rights reserved.
;
; Redistribution and use in source and binary forms, with or without modification, are
; permitted provided that the following conditions are met:
; 
;    1. Redistributions of source code must retain the above copyright notice, this list of
;       conditions and the following disclaimer.
; 
;    2. Redistributions in binary form must reproduce the above copyright notice, this list
;       of conditions and the following disclaimer in the documentation and/or other materials
;       provided with the distribution.
; 
; THIS SOFTWARE IS PROVIDED BY UNIVERSITY OF SOUTHERN CALIFORNIA ``AS IS'' AND ANY EXPRESS OR IMPLIED
; WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
; FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UNIVERSITY OF SOUTHERN CALIFORNIA OR
; CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
; CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
; SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
; ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING7
; NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
; ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
; 
; The views and conclusions contained in the software and documentation are those of the
; authors and should not be interpreted as representing official policies, either expressed
; or implied, of University of Southern California.

(in-package :sigma)
;; PATCH 5: random draws of probability matching / Boltzmann selection come from (sigma-draw): a supplied list *draws* first, else (random 1.0); every draw is logged in *draw-log*.
(defvar *draws* nil)
(defvar *draw-log* nil)
(defun sigma-draw () (let ((r (if *draws* (pop *draws*) (random 1.0)))) (push r *draw-log*) r))
(defun prob-match-plm (p d &optional transform)
  (let* ((rank (plm-rank p))
         rarray sizev sizev-1 size np rarrayn sizeln sizen
         integrals; Cumulative integrals by summary region
         rands ; Random numbers by summary region
         rintegral ; Integral of region
         discrete ; Whether dimension d is discrete
         r ; Region
         temp-sum ii ii0
        bp bpoint brand
        destructive-normalize
        )
    (setq discrete (stype-discrete (svariable-type (aref (plm-variables p) d))))
    (when trace-summarize
      (format trace-stream "~&~%PROBABILITY MATCHING")
      (format trace-stream "~&~%P: ") (print-plm p symbolic-trace trace-stream)
      (format trace-stream "~&~%DIMENSION: ~S" d)
      )
    (setq bp p)
    ; Convert incoming PLM to a normalized Boltzmann form (where functions are divided by temperature and exponentiated)
    (when (eq transform #'boltzmann-function)
      (setq bp (transform-plm transform p))
      (when trace-summarize
        (format trace-stream "~&~%BOLTZMANN TRANSFORM: ") (print-plm bp symbolic-trace trace-stream)
        )
      (when trace-summarize
        (format trace-stream "~&~%NORMALIZED BOLTZMANN TRANSFORM: ") (print-plm bp symbolic-trace trace-stream)
        )
      (setq destructive-normalize t)
      )
    (setq bp (normalize-plm bp d destructive-normalize))
    ; Initialize what would normally be done in LET, but needed to wait until bp was defined to be safe
    (setq rarray (plm-array bp))
    (setq sizev (dimension-sizes-v bp))
    (setq sizev-1 (vector-1 sizev))
    (setq size (array-total-size rarray))
    (setq np (init-summarize-plm bp d))
    (setq rarrayn (plm-array np))
    (setq sizeln (dimension-sizes np))
    (setq sizen (array-total-size rarrayn))
    (setq integrals (make-array sizeln :initial-element 0))
    (setq rands (make-array sizeln))
    ; Set random numbers by summary regions
    (dotimes (i sizen)
      (setf (row-major-aref rands i) (sigma-draw))
      )
    ; Traverse regions of original PLM, determining probability matching points
    (setq ii (make-list rank :initial-element 0))
    (dotimes (i size)
      (setf r (row-major-aref rarray i))
      (setq rintegral (aref (integral-region r (list d)) 0)) ; Constant in region's integration along d
      ; Zero index along d
      (setq ii0 (copy-seq ii))
      (setf (nth d ii0) 0)
      (when (and (not (aref (region-maximals (apply #'aref rarrayn ii0)) d)) (> rintegral 0)) ; Haven't already found point for region and there is a positive integral over the region
        (setq temp-sum (+ rintegral (apply #'aref integrals ii0))) ; Add integral to running total
        (setq brand (apply #'aref rands ii0))
        (when (< brand temp-sum) ; Random number is less than cumulative integral after region
          (setq bpoint (+ (region-min r d) (* (/ (- brand (apply #'aref integrals ii0)) rintegral) (region-span r d))))
          (setf (aref (region-maximals (apply #'aref rarrayn ii0)) d) (list (if discrete (discrete-point bpoint) (continuous-point bpoint))))
          )
        (setf (apply #'aref integrals ii0) temp-sum)
        )
      (setq ii (next-index-list ii sizev-1 rank))
      )
    ; Copy integrals to region-constants of summary regions (exact values don't matter, but zero versus positive does)
    (dotimes (i sizen)
      (setf (region-constant (row-major-aref rarrayn i)) (row-major-aref integrals i))
      )
    ; Set selection dimension inactive
    (setf (aref (plm-active np) d) nil)
    (when (plm-piecewise-constant p)
      (setf (plm-piecewise-constant np) t)
      )
    np)
  )
