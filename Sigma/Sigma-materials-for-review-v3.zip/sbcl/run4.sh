#!/bin/sh
# usage: run4.sh name file form
cd /home/claude/sigma/work
sbcl --noinform --non-interactive --load boot.lisp --load $2 --eval '(in-package :sigma)' --eval "$3" > runs/$1.txt 2>&1
