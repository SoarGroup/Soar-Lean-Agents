#!/bin/sh
# usage: run5.sh name file form   (boot-rl: patches P1-P5)
cd /home/claude/sigma/work
sbcl --noinform --non-interactive --load boot-rl.lisp --load $2 --eval '(in-package :sigma)' --eval "$3" > runs/$1.txt 2>&1
