"""Compare Paul Rosenbloom's LispWorks traces (November 16, 2026) with the SBCL runs.
Usage: python3 compare_lispworks.py   (run from sigma38-runs/lispworks)"""
import re, pathlib
here = pathlib.Path(__file__).parent
def rtf_text(p): return re.sub(r'\\\n', '\n', p.read_text())
# Eight Puzzle: selected operator and board after each decision
lw = rtf_text(here / 'Test-Eight-Puzzle_Trace.rtf')
lw_dec = {}
for n, body in re.findall(r'<<< Decision (\d+) >>>(.*?)(?=<<< Decision|\Z)', lw, re.S):
    sel = re.search(r'SELECTED-WM-FN\] Function: *(\d*)', body).group(1)
    rows = re.findall(r'\[\d-\d>\s+(\d)\s+(\d)\s+(\d)', body)[:3]
    lw_dec[int(n)] = (int(sel) if sel else None, [[int(x) for x in r] for r in rows])
sb = (here.parent / 'ex-ep8.txt').read_text()
parts = re.split(r'<<< Decision (\d+) >>>', sb)
ok = True
for k in range(1, len(parts), 2):
    n, body = int(parts[k]), parts[k + 1]
    op = re.search(r'op0=(\S+)', body).group(1)
    sel = None if op == 'NIL' else int(op)
    seg = body[body.rfind('WM function for predicate BOARD'):]
    blocks = re.split(r'\n\[(\d)-\d>\n', seg)[1:]
    B = [[None] * 3 for _ in range(3)]
    for y, blk in zip(blocks[0::2], blocks[1::2]):
        for line in blk.split('\n'):
            m = re.match(r'\s*\[(\d)\]\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)', line)
            if m:
                for x in range(3):
                    if float(m.group(2 + x)) == 1: B[int(y)][x] = int(m.group(1))
    same = (sel, B) == lw_dec[n]
    ok &= same
    print(f'Eight Puzzle decision {n}: selected {sel}, board {B}: {"match" if same else "DIFFERS"}')
print('Messages: LispWorks', re.search(r'Total messages: (\d+)', lw).group(1), 'SBCL', re.search(r'Total messages: (\d+)', sb).group(1))
# Soft ultimatum: every printed number
def nums(t):
    t = t[t.find('WM for OPERATOR-B-E'):]
    t = t.replace('0.52.472623000e-35.5277920000e-42.79614750000e-4', '0.5 2.472623e-3 5.527792e-4 2.7961475e-4')  # SBCL prints this row without spaces
    return [float(x) for x in re.findall(r'(?<![\w\[:])\d+\.\d+(?:[eE]-?\d+)?', t)]
lw_u, sb_u = rtf_text(here / 'Soft-Ultimatum_Trace.rtf'), (here.parent / 'ultimatum-soft.txt').read_text()
a, b = nums(lw_u), nums(sb_u)[:len(nums(lw_u))]  # the SBCL file prints OFFER once more, then times
print('Soft ultimatum:', len(a), 'values; largest relative difference', max(abs(x - y) / abs(x) for x, y in zip(a, b)))
print('Messages: LispWorks', re.search(r'Total messages: (\d+)', lw_u).group(1), 'SBCL', re.search(r'Total messages: (\d+)', sb_u).group(1))
