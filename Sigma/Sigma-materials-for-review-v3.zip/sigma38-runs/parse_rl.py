import re,sys,json
def parse(path):
    t=open(path).read()
    decs=re.split(r'=== after decision \d+ \(temperature [^)]*\)\n',t)[1:]
    # runs/rl1 format: "=== functions after decision"? handle both
    return decs
def tables(block):
    out={}
    # Q
    q=block.split('Predicate function for predicate Q:')[1].split('Predicate function for predicate PROJECTED:')[0]
    Q={}
    for op,body in re.findall(r'\[(LEFT|RIGHT)\]\n(.*?)(?=\n\s*\[RIGHT\]|\Z)',q,re.S):
        rows=[l.split() for l in body.strip().split('\n') if l.strip().startswith('[') and len(l.split())>=9]
        rows=[r for r in rows if re.match(r'\[\d+\]$',r[0])]
        Q[op]=[[float(x) for x in r[1:9]] for r in rows]
    out['Q']=[Q['LEFT' if o==0 else 'RIGHT'][v][x] for x in range(8) for o in range(2) for v in range(10)]
    for name,key,nxt in (('P','PROJECTED','REWARD'),('R','REWARD',None)):
        b=block.split('Predicate function for predicate %s:'%key)[1]
        if nxt: b=b.split('Predicate function for predicate %s:'%nxt)[0]
        rows=[l.split() for l in b.split('\n') if re.match(r'\s*\[\d+\]\s+\S',l) and len(l.split())>=9]
        out[name]=[[float(x) for x in r[1:9]] for r in rows][:10]
        out[name]=[out[name][v][x] for x in range(8) for v in range(10)]
    return out
if __name__=='__main__':
    t=open(sys.argv[1]).read()
    blocks=re.split(r'=== (?:functions )?after decision \d+ \(temperature [^)]*\)\n',t)[1:]
    res=[tables(b) for b in blocks]
    json.dump(res,open(sys.argv[2],'w'))
    print(len(res),[len(r['Q']) for r in res][:3],[len(r['P']) for r in res][:3])
