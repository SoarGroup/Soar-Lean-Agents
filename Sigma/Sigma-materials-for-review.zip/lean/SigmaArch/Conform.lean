import CMC.Meta
import SigmaArch.EightPuzzle
import SigmaArch.Examples
/-!
# Sigma and the Common Model of Cognition

This file maps the state of the Sigma specification onto the working memory of the CMC with
metacognition (`CMC.Meta`) and records where Sigma keeps the CMC's commitments and where it
departs from them. General facts are theorems; facts about particular programs are checks
(`#guard`) on the programs of `Examples.lean` and `EightPuzzle.lean`, which agree with the
Sigma38 release. It does not build a `CMC.Meta.Arch` instance: departures 1 to 3 below show
that Sigma does not fit `Arch.select` and `WFProc` as stated.

Mapping (OPEN: every line is a proposal, for review by Paul Rosenbloom and the CMC authors)
* a working-memory element is a tuple of a predicate with a positive functional value; the
  tuple is the CMC relation and the functional value is its one kind of numeric metadata;
* closed-world predicates other than `Impasse`, `Selected` included → the region;
* the `Impasse` predicate → the procedural process data (`CMC.Meta`: "conceptually, the
  substate is the procedural process buffer");
* predicates with perceptual input → the content of the perception buffer;
* there is one long-term memory, the conditionals and their functions. Retrieval from it is
  message passing inside the elaboration phase, so the cue and result parts of the declarative
  buffer are empty, as are the motor command and every other process part.

Findings for the CMC
1. Conditions are not blind to numeric metadata: the functional values are what conditionals
   compute with (`CMC.Base` marks this OPEN for Sigma). With values restricted to 0 and 1 the
   computation is symbolic.
2. Elaboration makes persistent changes to working memory without a selected operator: every
   closed-world predicate keeps the results of actions. The CMC allows one deliberate act per
   cycle; `CMC.Proc` (adopted for Soar) adds automatic processing whose results are retracted
   when their conditions no longer hold, which is not what Sigma does.
3. A cycle makes one selection for each state, for each agent, and for each selecting
   predicate (the Eight Puzzle's board has nine). Selection of an operator is serial per state
   (`selectedFn_atMostOne`).
4. Selection failure is reported, as the CMC with metacognition requires: tie, none and
   no-change impasses are the CMC's tie, no-candidates and no-progress reasons
   (`ImpType.toSelFail`). Sigma has no conflict impasse. Reporting can be turned off
   (`cycle_no_levels_when_off`).
5. Declarative retrieval is not a separate step and its results are not held in working
   memory: the posterior of an open-world predicate exists only during the cycle
   (`cycle_open_world_unchanged`), although it determines that cycle's selection.
6. Not formalized here, so not assessed: learning (the CMC's composition, reinforcement
   learning, declarative creation and tuning), episodic recording, forgetting, and time.
-/

namespace SigmaArch.Conform
open CMC.Meta

/-- The CMC signature of the Sigma specification: one long-term memory, perception and motor
each as one module, and three metadata kinds of which only the first is used. -/
@[reducible] def σG : Sig where
  Sym := String
  Val := Rat
  PMod := Unit
  MMod := Unit
  DMem := Unit
  Input := Unit
  PLearn := Unit
  MLearn := Unit
  Output := Unit
  MK := Fin 3
  utilityK := 0
  frequencyK := 1
  recencyK := 2
  epi := ()

/-- The tuples of a predicate with a positive value, as CMC elements. The functional value is
metadata kind 0. -/
def encPred (p : Pred) (f : Fn) : List (Elem σG) :=
  (tuples p.dom).filterMap fun t =>
    if 0 < f t then
      some ⟨⟨p.name, t.map toString⟩, fun k => if k = 0 then some (f t) else none⟩
    else none

/-- The CMC working memory of a Sigma state. `perceived` names the predicates that have
perceptual input. -/
def enc (S : Sys) (perceived : List String) (st : CogState) : WM σG
  | .region =>
    (S.P.preds.filter fun p =>
      p.world == .closedWorld && p.name != S.impName && !perceived.contains p.name).flatMap
      fun p => encPred p (st.wm p.name)
  | .procProcess =>
    (S.P.preds.filter fun p => p.name == S.impName).flatMap fun p => encPred p (st.wm p.name)
  | .percept () .content =>
    (S.P.preds.filter fun p => perceived.contains p.name).flatMap fun p => encPred p (st.wm p.name)
  | _ => []

/-- **Departure: no retrieval cue is held in working memory.** -/
theorem cue_empty (S : Sys) (pv : List String) (st : CogState) : enc S pv st (.decl () .cue) = [] := rfl

/-- **Departure: no retrieval result is held in working memory.** The CMC's protection of
retrieval results holds trivially, as it does for Soar's core without semantic memory. -/
theorem result_empty (S : Sys) (pv : List String) (st : CogState) :
    enc S pv st (.decl () .result) = [] := rfl

/-- **Departure: no motor command is held in a motor buffer** (output is read from working
memory; the specification has no motor module). -/
theorem motor_command_empty (S : Sys) (pv : List String) (st : CogState) :
    enc S pv st (.motor () .command) = [] := rfl

/-! ## Selection failure (finding 4) -/

/-- Sigma's impasse types as the CMC's reasons for selection failure. -/
def ImpType.toSelFail : ImpType → SelFail
  | .tie => .tie
  | .noneT => .noCandidates
  | .noChange => .noProgress

/-- **Kept: each impasse type is a distinct CMC reason.** -/
theorem toSelFail_injective (a b : ImpType) (h : ImpType.toSelFail a = ImpType.toSelFail b) :
    a = b := by
  cases a <;> cases b <;> simp [ImpType.toSelFail] at h <;> rfl

/-- **Sigma has no conflict impasse.** -/
theorem no_conflict (a : ImpType) : ImpType.toSelFail a ≠ .conflict := by
  cases a <;> simp [ImpType.toSelFail]

theorem activeLevels_nil (n : Nat) : activeLevels [] n = min n 1 := by
  have h : ((List.range n).takeWhile fun s => hasImpasseAt [] (s + 1)) = [] := by
    cases hn : List.range n with
    | nil => rfl
    | cons a l => simp [List.takeWhile, hasImpasseAt]
  simp [activeLevels, h]

/-- **With impasse detection off no metalevel is added**: a quiescent cycle leaves at most
one level. Reporting of selection failure is therefore optional in Sigma. -/
theorem cycle_no_levels_when_off (S : Sys) (pb : String → Option Fn) (rng : Nat) (st : CogState)
    (hoff : S.detectImpasses = false) (hq : (cycle S pb rng st).quiescent = true) :
    (cycle S pb rng st).state.levels ≤ 1 := by
  unfold cycle at hq ⊢
  cases hm : elaborate S.P { wm := st.wm, ltm := S.ltm, pb := pb } S.fuel with
  | none => simp [hm] at hq
  | some ms =>
    simp only [hm, hoff]
    simp [activeLevels_nil]
    omega

/-! ## Seriality of operator selection (finding 3) -/

/-- At most one tuple with a positive value for each choice of the first `nu` arguments. -/
def AtMostOne (nu : Nat) (f : Fn) : Prop :=
  ∀ t t' : Tup, 0 < f t → 0 < f t' → t.take nu = t'.take nu → t = t'

theorem AtMostOne.mono {nu : Nat} {f g : Fn} (h : AtMostOne nu f)
    (hg : ∀ t, 0 < g t → 0 < f t) : AtMostOne nu g :=
  fun t t' ht ht' e => h t t' (hg t ht) (hg t' ht') e

/-- **Kept: one operator per state.** The new function of a selecting predicate has at most
one selected element for each tuple of its universal arguments, provided the old one did.
This is the CMC's serial selection (Table 1, A.4), per state and per agent. -/
theorem selectedFn_atMostOne (p : Pred) (tbl : SelTable) (old : Fn)
    (hold : AtMostOne p.uArgs.length old) :
    AtMostOne p.uArgs.length (selectedFn p tbl old) := by
  intro t t' ht ht' e
  unfold selectedFn at ht ht'
  simp only [← e] at ht'
  cases hl : tbl.lookup (t.take p.uArgs.length) with
  | none =>
    simp only [hl] at ht ht'
    exact hold t t' ht ht' e
  | some r =>
    cases r with
    | chosen q =>
      simp only [hl] at ht ht'
      have h1 : q = t.drop p.uArgs.length := by
        by_cases hq : (q == t.drop p.uArgs.length) = true
        · exact eq_of_beq hq
        · simp [hq] at ht
      have h2 : q = t'.drop p.uArgs.length := by
        by_cases hq : (q == t'.drop p.uArgs.length) = true
        · exact eq_of_beq hq
        · simp [hq] at ht'
      calc t = t.take p.uArgs.length ++ t.drop p.uArgs.length := (List.take_append_drop _ _).symm
        _ = t'.take p.uArgs.length ++ t'.drop p.uArgs.length := by rw [e, ← h1, ← h2]
        _ = t' := List.take_append_drop _ _
    | noneImp =>
      simp only [hl] at ht ht'
      exact hold t t' ht ht' e
    | tieImp bs =>
      simp only [hl] at ht ht'
      exact hold t t' ht ht' e

/-! ## Retrieval inside the cycle (finding 5) -/

/-- **Departure: the posterior of an open-world predicate is not kept.** A cycle leaves the
working-memory function of an open-world predicate as it was (for a predicate without a state
argument that is not the impasse predicate). What elaboration computed for it, such as the
concept retrieved for a perceived color, is used within the cycle and then gone. -/
theorem cycle_open_world_unchanged (S : Sys) (pb : String → Option Fn) (rng : Nat) (st : CogState)
    (p : Pred) (hp : S.P.pred? p.name = some p) (hw : p.world = .openWorld)
    (hs : p.args.findIdx? (·.name == "state") = none) (hi : (p.name == S.impName) = false) :
    (cycle S pb rng st).state.wm p.name = st.wm p.name := by
  unfold cycle
  cases hm : elaborate S.P { wm := st.wm, ltm := S.ltm, pb := pb } S.fuel with
  | none => simp [hm]
  | some ms =>
    simp only [hm]
    simp [clearInactive, hp, hw, hs, hi]

/-! ## Checks on particular programs -/

open SigmaArch.Examples in
/-- **Finding 1: conditions are not blind to the functional values.** Two working memories
with the same tuples of `Above` (the same symbolic content under the mapping) and different
values give different results from the same conditional: with values 1 the transitive rule
adds `Above(o1, o3)` with value 1, with values 1/2 it adds it with value 1/4. -/
def halfWM : String → Fn := fun _ => Fn.ofRows [([0, 1], 1/2), ([1, 2], 1/2)]
open SigmaArch.Examples in
def fullWM : String → Fn := fun _ => Fn.ofRows [([0, 1], 1), ([1, 2], 1)]
open SigmaArch.Examples in
def relsOf (wm : String → Fn) : List (String × List String) :=
  (enc { P := aboveP } [] { wm := wm } .region).map fun e => (e.rel.pred, e.rel.args)
#guard relsOf halfWM == relsOf fullWM
open SigmaArch.Examples in
#guard (cycle { P := aboveP } (fun _ => none) 0 { wm := fullWM }).state.wm "Above" [0, 2] == 1
open SigmaArch.Examples in
#guard (cycle { P := aboveP } (fun _ => none) 0 { wm := halfWM }).state.wm "Above" [0, 2] == 1/4

/- The same holds for selection: the same two proposals with different values select
different operators. -/
def propP (a b : Val) : Prog :=
  { preds := [ { name := "Selected", args := [⟨"state", 1, .universal⟩, ⟨"operator", 2, .unique⟩],
                 world := .closedWorld, sel := some .argmax } ]
    conds := [ { name := "p0", actions := [⟨"Selected", [.const 0, .const 0], false⟩], fn := fun _ => a },
               { name := "p1", actions := [⟨"Selected", [.const 0, .const 1], false⟩], fn := fun _ => b } ] }
#guard (cycle { P := propP (3/4) (1/4), detectImpasses := false } (fun _ => none) 0 { wm := fun _ => Fn.const 0 }).state.wm "Selected" [0, 0] == 1
#guard (cycle { P := propP (1/4) (3/4), detectImpasses := false } (fun _ => none) 0 { wm := fun _ => Fn.const 0 }).state.wm "Selected" [0, 1] == 1

open SigmaArch.Examples in
/- **Finding 2: elaboration changes working memory persistently without an operator.** The
transitive rule's additions are in working memory after the cycle, the program has no
`Selected` predicate at all, and they stay after the facts they were derived from are
removed. -/
#guard aboveR.state.wm "Above" [0, 2] == 1
open SigmaArch.Examples in
#guard (cycle { P := aboveP } (fun _ => none) 0
          { wm := fun pn => if pn == "Above" then Fn.ofRows [([0, 2], 1)] else Fn.const 0 }).state.wm "Above" [0, 2] == 1

open SigmaArch.EightPuzzle in
/- **Finding 3: several selections in one cycle.** In decision 2 of the Eight Puzzle two cells
of the board change, each by its own selection among nine tiles, and an operator is chosen
for `Selected` in the same decision (and then removed, finding E2). -/
#guard ((runB.getD 0 ⟨[], []⟩).board, (runB.getD 1 ⟨[], []⟩).board)
  == ([[1, 2, 3], [8, 4, 5], [7, 0, 6]], [[1, 2, 3], [8, 4, 5], [7, 6, 0]])

open SigmaArch.Examples in
/- **Finding 4: the impasse is the procedural process data.** After the cycle with no color
evidence the tie is in the CMC's procedural process area and nothing is in the region. -/
#guard (enc classSys ["Color"] noEvidenceR.state .procProcess).length == 4
open SigmaArch.Examples in
#guard (enc classSys ["Color"] noEvidenceR.state .region).length == 0

open SigmaArch.Examples in
/- **Finding 5: retrieval happens inside the cycle.** With silver perceived, the walker is
selected in the same cycle, so the concept was retrieved and used; after the cycle `Concept`
has no element in working memory, and the selected operator is the only content of the
region. -/
#guard silverR.state.wm "Selected" [0, 0] == 1
open SigmaArch.Examples in
#guard (tuples (classP.dom "Concept")).all fun t => silverR.state.wm "Concept" t == 0
open SigmaArch.Examples in
#guard ((enc classSys ["Color"] silverR.state .region).map fun e => (e.rel.pred, e.rel.args))
  == [("Selected", ["0", "0"])]

end SigmaArch.Conform
