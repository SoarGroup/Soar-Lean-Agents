(in-package :sigma)
;; Spec: selectAmong examples. Propose operators 0..2 with given weights at state 0.
(defun ex-sel-init (weights &optional (impasses t))
  (init)
  (init-operators 'symbols '(a b c) impasses)
  (conditional 'propose
               :actions '((selected (state 0) (operator (o))))
               :function-variable-names '(o)
               :function (loop for w in weights for i from 0 collect (list w (if impasses i (nth i '(a b c)))))))
(defun ex-sel-run (weights n &optional (impasses t) (dec 1))
  "Runs n independent fresh systems for dec decisions; returns list of (operator-after-each-decision . bottom-state)"
  (loop repeat n collect
        (progn (ex-sel-init weights impasses)
               (let (ops)
                 (dotimes (i dec)
                   (d 1)
                   (push (operator-in-state 0) ops))
                 (cons (reverse ops) bottom-state)))))
