;; PATCH 1 (SBCL only; the Sigma source is not edited).
;; sort-slice-list-array in graph-compilation.lisp calls (sort list ...) and discards the result,
;; relying on the destructive sort leaving the original list head in place (true in CLISP and
;; LispWorks). In SBCL the original cons can land in the middle of the sorted list, so slices
;; are lost and never indexed. The result is stored back.
(in-package :sigma)
(defun sort-slice-list-array (sla)
  (dotimes (i (length sla))
    (setf (aref sla i) (sort-slice-list (aref sla i))))
  sla)

;; PATCH 2: summarize-plm - make-array default element is 0 in SBCL (NIL in LispWorks/CLISP); only change is :initial-element nil
(defun summarize-plm (p din region-op combine-op &optional region-argument vector) 
  (let* ((ds (if (consp din) din (list din)))
         (np (init-summarize-plm p ds))
         (rarray (plm-array p))
         (rarrayn (plm-array np))
         (rank (plm-rank p))
         (sizev (dimension-sizes-v p))
         (sizev-1 (vector-1 sizev))
         (size (array-total-size rarray))
         (sizeln (dimension-sizes np))
         (sizen (array-total-size rarrayn))
         (summaries (make-array sizeln :initial-element nil))
         r ; Region
         rsummary ; Region integral
         ii ii0
         (piecewise-constant (plm-piecewise-constant p))
         )
    (when trace-summarize
      (format trace-stream "~&~%~S" region-op)
      (format trace-stream "~&~%P: ") (print-plm p symbolic-trace trace-stream)
      (format trace-stream "~&~%~S DIMENSION(S): ~S" region-op ds)
      )
    ; Compute the summazation over the regions in the PLM as function vectors in the variable (vector) summaries
    (setq ii (make-list rank :initial-element 0))
    (dotimes (i size)
      ; Zero the index along ds
      (setq ii0 (copy-seq ii))
      (dolist (d ds)
        (setf (nth d ii0) 0)
        )
      (setf r (row-major-aref rarray i))
      (setq rsummary (summarize-region r ds region-op region-argument piecewise-constant vector)) 
      (setf (apply #'aref summaries ii0) (if (apply #'aref summaries ii0) (apply combine-op rsummary (list (apply #'aref summaries ii0) piecewise-constant)) rsummary))
      (setq ii (next-index-list ii sizev-1 rank))
      )
    ; Assign functions to new regions
    (dotimes (i sizen)
      (assign-function (row-major-aref summaries i) (row-major-aref rarrayn i) piecewise-constant)
      )
    ; Make summarised dimensions inactive
    (dolist (d ds)
      (setf (aref (plm-active np) d) nil)
      )
    (when trace-summarize
      (format trace-stream "~&~%~S RESULT: " region-op) (print-plm np symbolic-trace trace-stream)
      )
    (when (plm-piecewise-constant p)
      (setf (plm-piecewise-constant np) t)
      )
    np)
  )


;; PATCH 3/4: maximize-plm-like (line 1378) and expected-value (line 1715) in graph-runtime.lisp: only change :initial-element nil
(defun maximize-plm (p d &optional omit-maximals prev-max-ds)
  (let* ((np (init-summarize-plm p d))
         (rarray (plm-array p))
         (rarrayn (plm-array np))
         (rank (plm-rank p))
         (sizev (dimension-sizes-v p))
         (sizev-1 (vector-1 sizev))
         (size (array-total-size rarray))
         (sizeln (dimension-sizes np))
         (sizen (array-total-size rarrayn))
         (maximums (make-array sizeln :initial-element nil)) ; Stores maximums as function vectors
         (extents (make-array sizeln :initial-element 0))
         r ; Region
         rmaximum ; Region maximum
         ii ii0
         (piecewise-constant (plm-piecewise-constant p))
         rms ; Region maximals
         )
    (when trace-summarize
      (format trace-stream "~&~%MAX")
      (format trace-stream "~&~%P: ") (print-plm p t trace-stream)
      (format trace-stream "~&~%MAX DIMENSION: ~S" d)
      )
    ; Compute the maximization over the regions in the PLM as function vectors in the variable (vector) maximums
    (setq ii (make-list rank :initial-element 0))
    (dotimes (i size)
      (setf r (row-major-aref rarray i))
      (setq rmaximum (maximize-region r d piecewise-constant))
      ; Zero the index along d
      (setq ii0 (copy-seq ii))
      (setf (nth d ii0) 0)
      ; Maximize region
      (setf (apply #'aref maximums ii0) (if (apply #'aref maximums ii0)
                                            (maximum-region r rmaximum (apply #'aref maximums ii0) d (apply #'aref rarrayn ii0) extents ii0 omit-maximals prev-max-ds piecewise-constant)
                                         (progn
                                           (unless omit-maximals
                                             (setq rms (region-maximals (apply #'aref rarrayn ii0)))
                                             ; Copy maximals for previous maximized dimensions
                                             (dolist (md prev-max-ds)
                                               (setf (aref rms md) (aref (region-maximals r) md))
                                               )
                                            ; Set dimension's maximal element to that of the region
                                           (setf (aref rms d)
                                                 (list (maximal-elements-region r d)))
                                           )
                                         rmaximum)))
      (setq ii (next-index-list ii sizev-1 rank))
      )
    ; Assign functions to new regions
    (dotimes (i sizen)
      (assign-function (row-major-aref maximums i) (row-major-aref rarrayn i) piecewise-constant)
      )
    (setf (aref (plm-active np) d) nil)
    (when trace-summarize
      (format trace-stream "~&~%MAX RESULT: ") (print-plm np t trace-stream)
      )
    (when (plm-piecewise-constant p)
      (setf (plm-piecewise-constant np) t)
      )
    np)
  )

(defun expected-value-plm (p &optional d assign-maximals)
  (let* ((rarray (plm-array p))
         (rank (plm-rank p))
         (sizev (dimension-sizes-v p))
         (sizev-1 (vector-1 sizev))
         (size (array-total-size rarray))
         (np (init-summarize-plm p d))
         (rarrayn (plm-array np))
         (sizeln (dimension-sizes np))
         (sizen (array-total-size rarrayn))
         (expecteds (make-array sizeln :initial-element nil))
         r nr ; Regions
         rexpected ; Region integral
         ii ii0 ; Index list
         )
    (unless d (setq d (car (unique-dimensions p))))
    ; Error message if dimension is non-numeric
    (unless (stype-numeric (svariable-type (aref (plm-variables p) d))) ; When dimension not numeric
      (pplm p)
      (error "Attempt to compute expected value along non-numeric dimension ~S of PLM."
             (svariable-name (aref (plm-variables p) d))
             )
      )
    (when trace-summarize
      (format trace-stream "~&~%EXPECTED VALUE")
      (format trace-stream "~&~%P: ") (print-plm p symbolic-trace trace-stream)
      (format trace-stream "~&~%EXPECTED VALUE DIMENSION: ~S" d)
      )
    ; Compute the expected value over the regions in the PLM as function vectors in the variable (vector) expecteds
    (setq ii (make-list rank :initial-element 0))
    (dotimes (i size)
      ; Set the dth index to 0
      (setq ii0 (copy-seq ii))
      (setf (nth d ii0) 0)
      (setf r (row-major-aref rarray i))
      (setq rexpected (expected-value-region r d))
      (setf (apply #'aref expecteds ii0) (if (apply #'aref expecteds ii0) (apply #'vector-sum rexpected (list (apply #'aref expecteds ii0))) rexpected))
      (setq ii (next-index-list ii sizev-1 rank))
      )
    ; Assign functions to new regionsh (and maximals if not omitted)
    (dotimes (i sizen)
      (setq nr (row-major-aref rarrayn i))
      (assign-function (row-major-aref expecteds i) nr)
      ; Set up the maximals with the expected point
      (when assign-maximals
        (setf (aref (region-maximals nr) d) (list (expected-element-region nr)))
        )
      )
    ; Make summarised dimension inactive
    (setf (aref (plm-active np) d) nil)
    (when trace-summarize
      (format trace-stream "~&~%EXPECTED VALUE RESULT: ") (print-plm np symbolic-trace trace-stream)
      )
    (when (plm-piecewise-constant p)
      (setf (plm-piecewise-constant np) t)
      )
    np)
  )

