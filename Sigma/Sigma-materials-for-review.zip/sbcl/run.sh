#!/bin/sh
# usage: run.sh name form
cd /home/claude/sigma/work
sbcl --noinform --non-interactive --load boot.lisp --eval '(in-package :sigma)' --eval "$2" > runs/$1.txt 2>&1
