/-! Shared utilities for the CMC files. -/
namespace CMC

/-- Point update of a function (core Lean has no `Function.update`). -/
def upd {α β : Type} [DecidableEq α] (f : α → β) (a : α) (v : β) : α → β :=
  fun x => if x = a then v else f x

theorem upd_same {α β : Type} [DecidableEq α] (f : α → β) (a : α) (v : β) :
    upd f a v a = v := by simp [upd]

theorem upd_other {α β : Type} [DecidableEq α] (f : α → β) (a : α) (v : β) {x : α}
    (h : x ≠ a) : upd f a v x = f x := by simp [upd, h]

/-- Point updates at distinct places commute. -/
theorem upd_comm {α β : Type} [DecidableEq α] (f : α → β) {a₁ a₂ : α} (v₁ v₂ : β)
    (h : a₁ ≠ a₂) : upd (upd f a₁ v₁) a₂ v₂ = upd (upd f a₂ v₂) a₁ v₁ := by
  funext x
  by_cases h₁ : x = a₁ <;> by_cases h₂ : x = a₂ <;> simp_all [upd]

end CMC
