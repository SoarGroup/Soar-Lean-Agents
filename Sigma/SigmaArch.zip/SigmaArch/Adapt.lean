import SigmaArch.Elab
/-!
# The adaptation phase and the cognitive cycle ([RDU16] §4.2, §4.3, §5.3)

"The second major phase (Section 4.2) is largely non-monotonic, making choices and persistent
changes to memories based on the quiescent distributions engendered by the elaboration phase."
NOT FORMALIZED here: goals, affect, learning (gradient descent on LTM functions), surprise
and attention ([RDU16] §4.2.2–4.2.6), and the Boltzmann, expected-value and
probability-matching selection modes.
-/

namespace SigmaArch

/-- Outcome of selecting among the values of one unique argument. -/
inductive SelRes (α : Type)
  | chosen (c : α)
  | noneImp
  | tieImp (cs : List α)

def maxVal {α : Type} (cs : List (α × Val)) : Val := cs.foldl (fun m r => vmax m r.2) 0

def bests {α : Type} (cs : List (α × Val)) : List α :=
  let m := maxVal cs
  (cs.filter fun r => r.2 == m).map (·.1)

/-- Operator selection ([RDU16] §4.2.1): "No operator is selected if none of them has a
positive value, as a positive value acts much like an acceptable preference in Soar. No
element is also selected if there are multiple elements with the same maximum positive value,
but where this maximum value is less than 1. (A value of 1 is roughly equivalent to a best
preference in Soar. So a random selection is made if there are multiple elements with a
value of 1.)" The first case is a none impasse and the second a tie impasse. `rng` supplies
the random choice. Retention of an existing choice is applied beforehand (`applyRetention`). -/
def selectAmong {α : Type} [Inhabited α] (rng : Nat) (cs : List (α × Val)) : SelRes α :=
  let m := maxVal cs
  if m ≤ 0 then .noneImp
  else
    match bests cs with
    | [c] => .chosen c
    | bs => if m == 1 then .chosen (bs[rng % bs.length]!) else .tieImp bs

/-- Retention of an existing choice: "if the existing choice is among the best proposed it is
retained, otherwise one of the best is chosen at random … This default retention of an
existing best choice is implemented in the graph itself by multiplying the existing assumption
by a small discount factor (.01) before combining it disjunctively … with the actions"
([RDU16] §5.3).
SETTLED by running Sigma38 (2026-11-12): the discounted working-memory value (Sigma's
`wm-discount-factor`, 0.01) is combined with the proposals by probabilistic-or, like any other
action (finding E1). A selected operator proposed at 0.1 is reported at 0.109 (Eight Puzzle,
findings E4, E5), and one at 0.6364 at 0.64. An earlier reading of the 0.64 as an additive
bonus divided by 1.01 is withdrawn: it predicts 0.1089 for the first case. -/
def retention : Val := 1 / 100

/-- Combine the discounted existing choice with the proposals. Consequences found in Sigma38:
a selected operator with no remaining proposals still has a positive value, so it stays
selected (no none impasse); a selected operator outside a tied set does not prevent the
tie. At value 1 the combination changes nothing; the existing choice is then kept by
`selectRetaining`. -/
def applyRetention {α : Type} [BEq α] (old : Option α) (cs : List (α × Val)) :
    List (α × Val) :=
  cs.map fun (c, v) => if old == some c then (c, probOr v retention) else (c, v)

/-- Selection with an existing choice: the existing choice is kept when it is among the
maxima (Sigma38 `change-wm-selection`: "Add best positive value (retaining existing value if
still maximal)"); otherwise `selectAmong` decides. The caller reports a kept choice as a
no-change impasse. -/
def selectRetaining {α : Type} [BEq α] [Inhabited α] (rng : Nat) (old : Option α)
    (cs : List (α × Val)) : SelRes α :=
  let cs' := applyRetention old cs
  match old with
  | some o => if 0 < maxVal cs' && (bests cs').contains o then .chosen o else selectAmong rng cs'
  | none => selectAmong rng cs'

theorem selectAmong_none {α : Type} [Inhabited α] (rng : Nat)
    (cs : List (α × Val)) (h : maxVal cs ≤ 0) : selectAmong rng cs = .noneImp := by
  simp [selectAmong, h]

/-- A unique best value above 0 is chosen (no impasse). -/
theorem selectAmong_unique {α : Type} [Inhabited α] (rng : Nat)
    (cs : List (α × Val)) (c : α) (hpos : ¬ maxVal cs ≤ 0) (hb : bests cs = [c]) :
    selectAmong rng cs = .chosen c := by
  simp [selectAmong, hpos, hb]

/-- The tie impasse happens only when the maximum is positive and not 1. -/
theorem selectAmong_tie {α : Type} [Inhabited α] (rng : Nat)
    (cs : List (α × Val)) (bs : List α) (h : selectAmong rng cs = .tieImp bs) :
    ¬ maxVal cs ≤ 0 ∧ ¬ (maxVal cs == 1) = true := by
  unfold selectAmong at h
  by_cases h0 : maxVal cs ≤ 0
  · simp [h0] at h
  · refine ⟨h0, ?_⟩
    intro h1
    simp only [h0, ite_false] at h
    split at h
    · simp at h
    · simp only [h1, ite_true] at h
      simp at h

/-- Impasse types, in the order Sigma38 numbers them (finding I4): a tie impasse, a none
impasse, and "when an operator remains selected for more than one cycle (a no-change
impasse)" ([RDU16] §4.2.1). -/
inductive ImpType | tie | noneT | noChange
  deriving DecidableEq, Repr

def ImpType.idx : ImpType → Nat
  | .tie => 0
  | .noneT => 1
  | .noChange => 2

/-- Result of the selection for each tuple of universal arguments. -/
abbrev SelTable := List (Tup × SelRes Tup)

def Pred.uArgs (p : Pred) : List Arg := p.args.filter (·.uniq == .universal)
def Pred.qArgs (p : Pred) : List Arg := p.args.filter (·.uniq == .unique)

/-- What is proposed for selection at tuple `t` of predicate `p`: the combined actions,
multiplied by condacts and inverted negated actions, with no assumption factor
([RDU16] §5.4.1, the second WMVN of a selecting predicate). -/
def proposalAt (P : Prog) (ms : Msgs) (p : Pred) (t : Tup) : Val :=
  let c := contribs P ms p.name none
  let comb : Val := if c.pos.isEmpty then 0 else p.combine (c.pos.map (· t))
  comb * vprod (c.cds.map (· t)) * vprod (c.neg.map fun f => inv (f t))

/-- Whether a tuple of universal arguments belongs to an active state. Only active states
make decisions (finding I2: Sigma38 adds one metalevel per decision). -/
def activeU (p : Pred) (levels : Nat) (u : Tup) : Bool :=
  match p.uArgs.findIdx? (·.name == "state") with
  | some i => (u[i]?.getD 0) < levels
  | none => true

/-- Selection for every combination of the universal arguments of an active state, which are
the decisions per state or per agent ([RDU16] §4.2.1: "When multiple agents are to be run
simultaneously, this WM function also includes an Agent variable, with independent decisions
then being made for each of the agents represented"). The previously selected value `old` is
read from the latched working memory and receives the retention bonus.
SIMPLIFIED: a selecting predicate lists its universal arguments before its unique ones. -/
def selectionTable (P : Prog) (A : Assump) (ms : Msgs) (p : Pred) (rng : Nat) (levels : Nat)
    (detect : Bool := true) : SelTable :=
  let ud := p.uArgs.map (·.size)
  let qd := p.qArgs.map (·.size)
  ((tuples ud).filter (activeU p levels)).map fun u =>
    let old := (tuples qd).find? fun q => 0 < A.wm p.name (u ++ q)
    let cs := (tuples qd).map fun q => (q, proposalAt P ms p (u ++ q))
    let r := selectRetaining rng old cs
    (u, match r with
        | .tieImp bs => if detect then r else .chosen (bs[rng % bs.length]!)
        | _ => r)

/-- The states at which a selecting predicate other than `Selected` changed its value in this
decision. Observed in Sigma38 (2026-11-12, Eight Puzzle, finding E2; `change-wm` in
`deciding.lisp`: "Wipe out any operator for a state which has a unique predicate change"):
when an operator's action changes such a predicate at a state, the operator selected at that
state is removed, the one chosen in the same decision included, so the next decision starts
with no operator. This is how an operator ends without a no-change impasse. -/
def changedStates (P : Prog) (A : Assump) (selName : String)
    (tables : List (String × SelTable)) : List Nat :=
  tables.flatMap fun (pn, tbl) =>
    match P.pred? pn with
    | none => []
    | some p =>
      if pn == selName then []
      else match p.uArgs.findIdx? (·.name == "state") with
        | none => []
        | some i =>
          let qd := p.qArgs.map (·.size)
          tbl.filterMap fun (u, r) =>
            let old := (tuples qd).find? fun q => 0 < A.wm pn (u ++ q)
            match r with
            | .chosen q => if old == some q then none else some (u[i]?.getD 0)
            | _ => none

/-- The new working-memory function of a selecting predicate: value 1 for the selected
element and 0 elsewhere. SETTLED by running Sigma38 (finding §5.2): when no element is selected
(a tie or none impasse) the previous value is kept, so after an earlier selection a later tie
leaves the previous operator in `Selected`; with no earlier selection it is empty. -/
def selectedFn (p : Pred) (tbl : SelTable) (oldWm : Fn) : Fn := fun t =>
  let nu := p.uArgs.length
  match tbl.lookup (t.take nu) with
  | some (.chosen q) => if q == t.drop nu then 1 else 0
  | _ => oldWm t

/-- The impasse predicate, `Impasse(state:state operator:operator type:impasse!)`
([RDU16] §4.4.3), as a function over (state, operator, type).
SETTLED by running Sigma38 (findings I1, §5.2): an impasse at state `s` is recorded at the
new substate `s + 1`; a tie records each tied operator; a no-change records the retained
operator; a none impasse records every operator. The selecting predicate must have `state` as
its only universal argument. -/
def impasseRows (qTuples : List Tup) (tbl : SelTable) (old : Tup → Option Tup) :
    List (Tup × Val) :=
  tbl.flatMap fun (u, r) =>
    let s := u.headD 0 + 1
    match r with
    | .noneImp => qTuples.map fun q => ([s] ++ q ++ [ImpType.noneT.idx], 1)
    | .tieImp bs => bs.map fun q => ([s] ++ q ++ [ImpType.tie.idx], 1)
    | .chosen q => if old u == some q then [([s] ++ q ++ [ImpType.noChange.idx], 1)] else []

def hasImpasseAt (rows : List (Tup × Val)) (s : Nat) : Bool :=
  rows.any fun r => r.1.head? == some s

/-- Number of active states (metalevels): state 0 always, and state k+1 when an impasse was
recorded at it, for each of the states 0..k in turn. "reflection and new metalevels are
initiated when an impasse occurs in processing at some level that makes progress at that
level impossible" and "extending or contracting the hierarchy of metalevel states"
([RDU16] §4.3, §5.3). Only active states decide, so a cycle adds at most one level, as
Sigma38 does (finding I2).
CHOICE: when the impasse of a state ends, the working memory of the states above is cleared
(`clearInactive`; the run showed 'Removing state 1').
DIFFERENCE (finding I3, not copied): Sigma38 keeps adding a state at each decision while a
none impasse lasts, without recording impasses beyond state 2, which looks like a defect.
Here a none impasse is recorded like the others, so levels grow one per cycle up to the
limit of the State type. -/
def activeLevels (rows : List (Tup × Val)) (maxStates : Nat) : Nat :=
  min maxStates (((List.range maxStates).takeWhile fun s => hasImpasseAt rows (s + 1)).length + 1)

/-- Zero the functions at states that are no longer active, for predicates with a `state`
argument. -/
def clearInactive (P : Prog) (levels : Nat) (wm : String → Fn) : String → Fn := fun pn =>
  match P.pred? pn with
  | none => wm pn
  | some p =>
    match p.args.findIdx? (·.name == "state") with
    | none => wm pn
    | some i => fun t => if (t[i]?.getD 0) < levels then wm pn t else 0

/-- The cognitive-system configuration. -/
structure Sys where
  P : Prog
  ltm : String → Option Fn := fun _ => none
  fuel : Nat := 20
  /-- Name of the selection predicate (architecturally distinguished, `Selected`). -/
  selName : String := "Selected"
  /-- Name of the impasse predicate. -/
  impName : String := "Impasse"
  /-- Name of the halting predicate: "reserved names such as Halt …" (Reference Sheet). -/
  haltName : String := "Halt"
  /-- Whether impasses are detected (the third argument of Sigma's `init-operators`). With
  detection off no impasse is recorded and no metalevel is added. Observed in Sigma38
  (2026-11-12, finding E3): with detection off, a tie below 1 selects one of the tied
  operators (not always the first; finding E3) and an operator with no remaining proposals stays
  selected. The tied operator is taken with the cycle's random number. -/
  detectImpasses : Bool := true

structure CogState where
  wm : String → Fn
  levels : Nat := 1

structure CycleResult where
  state : CogState
  quiescent : Bool
  msgs : Msgs
  tables : List (String × SelTable)

/-- One cognitive cycle: input (the perceptual functions `pb`), one elaboration phase, one
adaptation phase, and output (read from the resulting working memory).
"a single cognitive cycle – comprised of input and output plus one elaboration phase and one
adaptation phase" ([RDU16] §4.3).
CHOICE: if elaboration does not reach quiescence within `fuel` rounds the cycle leaves the
state unchanged and reports `quiescent = false`. -/
def cycle (S : Sys) (pb : String → Option Fn) (rng : Nat) (st : CogState) : CycleResult :=
  let A : Assump := { wm := st.wm, ltm := S.ltm, pb := pb }
  match elaborate S.P A S.fuel with
  | none => { state := st, quiescent := false, msgs := [], tables := [] }
  | some ms =>
    let tables := (S.P.preds.filter (·.sel.isSome)).map fun p =>
      (p.name, selectionTable S.P A ms p rng st.levels S.detectImpasses)
    let wiped := changedStates S.P A S.selName tables
    -- tables for the closed-world predicates that make no selection, built once
    let closedTabs : List (String × Tab) :=
      (S.P.preds.filter fun p => p.world == .closedWorld && p.sel.isNone).map fun p =>
        (p.name, wmvnTab S.P A ms p)
    let wm1 : String → Fn := fun pn =>
      match S.P.pred? pn with
      | none => st.wm pn
      | some p =>
        if p.world != .closedWorld then st.wm pn
        else if p.sel.isSome then
          let f := selectedFn p ((tables.lookup pn).getD []) (st.wm pn)
          if pn == S.selName then fun t => if wiped.contains (t.headD 0) then 0 else f t
          else f
        else ((closedTabs.lookup pn).map Tab.fn).getD (fun _ => 0)
    let selTbl := (tables.lookup S.selName).getD []
    let qTuples := match S.P.pred? S.selName with
      | none => []
      | some p => tuples (p.qArgs.map (·.size))
    -- the operator of a state changed in this decision is wiped before impasses are detected
    let oldSel : Tup → Option Tup := fun u =>
      if wiped.contains (u.headD 0) then none
      else qTuples.find? fun q => 0 < st.wm S.selName (u ++ q)
    let rows := if S.detectImpasses then impasseRows qTuples selTbl oldSel else []
    let nStates := (S.P.pred? S.selName).map (fun p => (p.uArgs.headD ⟨"", 1, .universal⟩).size) |>.getD 1
    let levels := activeLevels rows nStates
    let impTab : Tab := Tab.ofFn (S.P.dom S.impName) (Fn.ofRows rows)
    let wm2 : String → Fn := fun pn => if pn == S.impName then impTab.fn else wm1 pn
    { state := { wm := clearInactive S.P levels wm2, levels := levels }
      quiescent := true, msgs := ms, tables := tables }

/-- A cycle whose elaboration does not reach quiescence leaves the state unchanged. -/
theorem cycle_state_of_not_quiescent (S : Sys) (pb : String → Option Fn) (rng : Nat)
    (st : CogState)
    (h : elaborate S.P { wm := st.wm, ltm := S.ltm, pb := pb } S.fuel = none) :
    (cycle S pb rng st).state = st ∧ (cycle S pb rng st).quiescent = false := by
  simp [cycle, h]

/-- When a cycle reports quiescence, its messages are a fixed point of a round: the
elaboration phase finished because "no more updates are available" ([RDU16] §4). -/
theorem cycle_msgs_quiescent (S : Sys) (pb : String → Option Fn) (rng : Nat) (st : CogState)
    (h : (cycle S pb rng st).quiescent = true) :
    Quiescent S.P { wm := st.wm, ltm := S.ltm, pb := pb } (cycle S pb rng st).msgs = true := by
  unfold cycle at h ⊢
  cases hm : elaborate S.P { wm := st.wm, ltm := S.ltm, pb := pb } S.fuel with
  | none => simp [hm] at h
  | some ms =>
    simp only [hm]
    exact elaborate_quiescent _ _ _ _ hm

def CogState.halted (S : Sys) (st : CogState) : Bool :=
  (tuples (S.P.dom S.haltName)).any fun t => 0 < st.wm S.haltName t

/-- Run cycles until `Halt` is positive or `n` cycles are done; returns the states after each
cycle. `pbAt` gives the perceptual input of each cycle and `rngAt` its random number. -/
def run (S : Sys) (pbAt : Nat → String → Option Fn) (rngAt : Nat → Nat) :
    Nat → Nat → CogState → List CogState
  | 0, _, _ => []
  | n + 1, k, st =>
    if st.halted S then []
    else
      let r := cycle S (pbAt k) (rngAt k) st
      r.state :: run S pbAt rngAt n (k + 1) r.state

end SigmaArch
