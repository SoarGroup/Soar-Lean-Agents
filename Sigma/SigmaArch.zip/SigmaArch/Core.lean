/-!
# Sigma (cognitive layer) in Lean 4 — values, functions and their algebra

Source: [RDU16] Rosenbloom, P. S., Demski, A., & Ustun, V. (2016). The Sigma Cognitive
Architecture and System: Towards Functionally Elegant Grand Unification. *Journal of
Artificial General Intelligence* 7(1), 1–103. Sections are cited as §4.4 etc.

Conventions (as in `CMC/` and `Soar/`)
* Every definition quotes or cites the passage it formalizes.
* `CHOICE:` an interpretation the paper does not force.
* `OPEN:` something the paper leaves unresolved or says is in flux.
* `SIMPLIFIED:` a deliberate restriction of what the paper describes.
* `NOT FORMALIZED:` something the paper describes that is left out.

STATUS: specified from the paper only. It has not been checked against the Sigma38 Lisp
system, which was not available (the release is on Bitbucket and nobody currently has a
running copy). Nothing here is claimed to reproduce Sigma's behaviour.

SIMPLIFIED (global): Sigma's functions are piecewise linear over discrete and continuous
variables ([RDU16] §4.1.1, §4.4.2). Here every variable has a finite discrete domain
`{0, …, n-1}` and a function is an exact rational for each tuple of values. Symbolic types
are discrete types, as in the paper ("symbolic variables treated the same as discrete ones",
§5.3). Continuous types, linear regions, convolution, affine transforms and distributed
vectors are NOT FORMALIZED.
-/

namespace SigmaArch

/-- A functional value. Exact rationals, so no floating-point behaviour is modelled. -/
abbrev Val := Rat

/-- A tuple of argument values, one per argument, each an index into that argument's domain. -/
abbrev Tup := List Nat

/-- A function over a tuple of discrete variables. Unspecified regions are 0 by default in
the language ([RDU16] §4.4.2: "all other regions being assigned by default a constant
function of 0"). -/
abbrev Fn := Tup → Val

def vmax (a b : Val) : Val := if a ≤ b then b else a

/-- Sum of a list of values. -/
def vsum (l : List Val) : Val := l.foldl (· + ·) 0

/-- Product of a list of values (1 for the empty list). -/
def vprod (l : List Val) : Val := l.foldl (· * ·) 1

/-- Maximum of a list of values (0 for the empty list; values are nonnegative). -/
def vmaxL (l : List Val) : Val := l.foldl vmax 0

/-- Probabilistic-or approximation: "P(A ∨ B) = P(A) + P(B) − P(A)P(B)" ([RDU16] Eq. 6). -/
def probOr (a b : Val) : Val := a + b - a * b

/-- "incoming messages are first scaled uniformly to a maximum value of 1 whenever their
maximum value exceeds this" ([RDU16] footnote 4). -/
def scaleToOne (l : List Val) : List Val :=
  let m := vmaxL l
  if 1 < m then l.map (· / m) else l

/-- Disjunctive combination by probabilistic-or, with the footnote-4 scaling. -/
def vprobOrL (l : List Val) : Val := (scaleToOne l).foldl probOr 0

/-- Inversion used for negation: "inverting a function f yields a function max(1 − f, 0).
True (1) becomes false (0) and vice versa … functional values greater than 1 are treated as
if they are 1" ([RDU16] §4.4.4). -/
def inv (v : Val) : Val := vmax (1 - v) 0

def indexed {α : Type} (l : List α) : List (Nat × α) := (List.range l.length).zip l

/-- All tuples over domains of the given sizes. -/
def tuples : List Nat → List Tup
  | [] => [[]]
  | n :: ns => (List.range n).flatMap fun v => (tuples ns).map (v :: ·)

namespace Fn

def const (v : Val) : Fn := fun _ => v

/-- A function given as regions, each a tuple with a value; later rows override earlier ones
and everything else is 0 ([RDU16] §4.4.2: "If two regions overlap, the one specified last
(re)defines the overlapping portion"). -/
def ofRows (rows : List (Tup × Val)) : Fn := fun t =>
  match rows.reverse.find? (fun r => r.1 == t) with
  | some r => r.2
  | none => 0

/-- Equality of two functions over the tuples of a domain. -/
def eqOn (dom : List Nat) (f g : Fn) : Bool := (tuples dom).all fun t => f t == g t

end Fn

/-- A function stored as a table of values over its domain. It is data, so it is computed
once when built; a closure that returned a table would be rebuilt at every read, because
Lean compiles a function-valued definition as a function of one more argument. -/
structure Tab where
  tbl : List (Tup × Val)

namespace Tab

def ofFn (dom : List Nat) (f : Fn) : Tab := ⟨(tuples dom).map fun t => (t, f t)⟩

def const (dom : List Nat) (v : Val) : Tab := ofFn dom (fun _ => v)

def fn (t : Tab) : Fn := fun x => (t.tbl.lookup x).getD 0

end Tab

/-- Round down to 18 decimal places (keeps the rationals that follow an exponential small). -/
def round18 (x : Val) : Val := ((x * 1000000000000000000).floor : Int) / 1000000000000000000

/-- `e^x` for `0 ≤ x ≤ 10` as a rational: the Taylor series to 80 terms, rounded down to 18
places. APPROXIMATION: values are exact rationals everywhere else in this specification; the
exponential is the one function that is not rational. The truncation error at `x = 10` is
below `10^80 / 80!`, about `10^-39`, and the rounding error is below `10^-18` (not proved). -/
def expR (x : Val) : Val :=
  let step := fun (acc : Val × Val) (n : Nat) =>
    let term := acc.2 * x / (n + 1 : Nat)
    (acc.1 + term, term)
  round18 ((List.range 80).foldl step (1, 1)).1

/-- Whether two values agree to within `tol`. -/
def near (a b tol : Val) : Bool := (if a ≤ b then b - a else a - b) ≤ tol

/-! Checked by evaluation (`decide` does not reduce rational arithmetic). -/
#guard inv 0 == 1
#guard inv 1 == 0
#guard inv 2 == 0
#guard inv (1/4) == 3/4
#guard near (expR 1) (2718281828459045235 / 1000000000000000000) (1 / 100000000000000000)
#guard expR 0 == 1

end SigmaArch
