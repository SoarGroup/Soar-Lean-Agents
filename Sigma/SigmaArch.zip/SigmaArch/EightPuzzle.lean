import SigmaArch.Adapt
/-!
# The Eight Puzzle of Sigma38, compared with Sigma38 decision by decision

The program is `ep8i` from `tests.lisp` in the Sigma38 release ("A program for the Eight
Puzzle based on a 2D board. No subgoaling"), with each of the three start positions the
release provides (`ep7e2`, which the regression test `test-eight-puzzle` uses, `ep7e` and
`ep7e3`). Each was run in Sigma38 under SBCL 2.2.9 on 2026-11-12 with `trace-wm-changes` on.
The values in the checks below were generated from those traces by a script
(`gen_ep_checks.py`), not typed in. The checks are `#guard`s, so `lake build` fails if the
specification stops agreeing with the recorded runs.

Differences between this transcription and the Sigma program:
* Sigma's `dimension` type is continuous over [0, 3) and every piece of evidence covers a
  unit interval; here `x` and `y` are discrete with values 0, 1, 2. An offset of 1 then moves
  from one unit interval to the next in both.
* Sigma's `state` type has 100 values; with impasse detection off only state 0 is used, and
  the state type here has that one value.
* Sigma's built-in `state` predicate is written as an ordinary closed-world predicate that
  holds for state 0.
Episodic learning is off in the run, as in the regression test.
-/

namespace SigmaArch.EightPuzzle

def v (x : String) : Term := .var x
def k (n : Nat) : Term := .const n

def boardArgs : List Arg :=
  [⟨"state", 1, .universal⟩, ⟨"x", 3, .universal⟩, ⟨"y", 3, .universal⟩, ⟨"tile", 9, .unique⟩]

/-- Tile `t` at (x, y) with the blank at (x + dx, y + dy). -/
def tileAndBlank (dx dy : Int) : List Pat :=
  [ ⟨"Board", [v "s", v "x", v "y", v "t"], false⟩,
    ⟨"Board", [v "s", .off "x" dx, .off "y" dy, k 0], false⟩ ]

/-- `left-acceptable` and its three companions: propose moving the tile with value 0.1. -/
def acceptable (name : String) (dx dy : Int) : Conditional :=
  { name := name
    conds := ⟨"State", [v "s"], false⟩ :: tileAndBlank dx dy
    actions := [⟨"Selected", [v "s", v "t"], false⟩]
    fn := fun _ => 1/10 }

/-- `move-left` and its companions: with the tile's operator selected, put the blank where
the tile is and the tile where the blank is. -/
def move (name : String) (dx dy : Int) : Conditional :=
  { name := name
    conds := [⟨"State", [v "s"], false⟩, ⟨"Selected", [v "s", v "t"], false⟩] ++ tileAndBlank dx dy
    actions := [ ⟨"Board", [v "s", v "x", v "y", k 0], false⟩,
                 ⟨"Board", [v "s", .off "x" dx, .off "y" dy, v "t"], false⟩ ] }

/-- `goal-left-best` and its companions: value 1 for a move that puts a tile in its goal
location. -/
def goalBest (name : String) (dx dy : Int) : Conditional :=
  { name := name
    conds := ⟨"State", [v "s"], false⟩ :: tileAndBlank dx dy
      ++ [⟨"Goal", [v "s", .off "x" dx, .off "y" dy, v "t"], false⟩]
    actions := [⟨"Selected", [v "s", v "t"], false⟩] }

/-- `goal-reject`: "Reject an operator that moves a tile from its desired location". -/
def goalReject : Conditional :=
  { name := "goal-reject"
    conds := [ ⟨"State", [v "s"], false⟩, ⟨"Goal", [v "s", v "x", v "y", v "t"], false⟩,
               ⟨"Board", [v "s", v "x", v "y", v "t"], false⟩ ]
    actions := [⟨"Selected", [v "s", v "t"], true⟩] }

/-- `goal-test`: every tile 1..8 is where the goal has it. -/
def goalTest : Conditional :=
  { name := "goal-test"
    conds := ⟨"State", [v "s"], false⟩ ::
      (List.range 8).flatMap fun i =>
        let n := i + 1
        [ ⟨"Board", [v "s", v s!"x{n}", v s!"y{n}", k n], false⟩,
          ⟨"Goal", [v "s", v s!"x{n}", v s!"y{n}", k n], false⟩ ]
    actions := [⟨"Success", [v "s"], false⟩] }

def halt : Conditional :=
  { name := "halt", conds := [⟨"Success", [k 0], false⟩], actions := [⟨"Halt", [], false⟩] }

def prog : Prog :=
  { preds :=
      [ { name := "State", args := [⟨"state", 1, .universal⟩], world := .closedWorld },
        { name := "Board", args := boardArgs, world := .closedWorld, sel := some .argmax },
        { name := "Goal", args := boardArgs, world := .closedWorld, sel := some .argmax },
        { name := "Success", args := [⟨"state", 1, .universal⟩], world := .closedWorld },
        { name := "Halt", args := [], world := .closedWorld },
        { name := "Selected", args := [⟨"state", 1, .universal⟩, ⟨"operator", 9, .unique⟩],
          world := .closedWorld, sel := some .argmax } ]
    conds :=
      [ acceptable "left-acceptable" (-1) 0, acceptable "right-acceptable" 1 0,
        acceptable "up-acceptable" 0 (-1), acceptable "down-acceptable" 0 1,
        move "move-left" (-1) 0, move "move-right" 1 0, move "move-up" 0 (-1),
        move "move-down" 0 1,
        goalBest "goal-left-best" (-1) 0, goalBest "goal-right-best" 1 0,
        goalBest "goal-up-best" 0 (-1), goalBest "goal-down-best" 0 1,
        goalReject, goalTest, halt ] }

/-- Impasse detection is off, as in the Sigma program (`init-operators 'type 'tile`). -/
def sys : Sys := { P := prog, detectImpasses := false }

/-- A board as rows of tiles, top row first: `rows[y][x]`. -/
def boardRows (rows : List (List Nat)) : List (Tup × Val) :=
  (indexed rows).flatMap fun (y, r) => (indexed r).map fun (x, t) => ([0, x, y, t], (1 : Val))

def goalBoard : List (List Nat) := [[1, 2, 3], [8, 0, 4], [7, 6, 5]]

/-- The evidence: a start board, the goal, and state 0. -/
def wm0 (start : List (List Nat)) : String → Fn := fun pn =>
  if pn == "Board" then Fn.ofRows (boardRows start)
  else if pn == "Goal" then Fn.ofRows (boardRows goalBoard)
  else if pn == "State" then Fn.ofRows [([0], 1)]
  else Fn.const 0

/-- The state after a cycle, stored as data: the working memory of each predicate is
tabulated so that later cycles and the checks read tables. `proposals` is what the decision
had before it for `Selected` at state 0: the combined actions after rejections, with the
discounted value of the operator selected before the decision (Sigma38's `Change message`
for SELECTED). -/
structure Snap where
  tabs : List (String × Tab)
  proposals : List (Nat × Val)

def Snap.wm (s : Snap) : String → Fn := fun pn => ((s.tabs.lookup pn).map Tab.fn).getD (Fn.const 0)

def Snap.selected (s : Snap) : Option Nat := (List.range 9).find? fun o => 0 < s.wm "Selected" [0, o]

def snapOf (prev : Snap) (r : CycleResult) : Snap :=
  { tabs := prog.preds.map fun p => (p.name, Tab.ofFn p.dom (r.state.wm p.name))
    proposals := match prog.pred? "Selected" with
      | some p =>
        (applyRetention prev.selected
          ((List.range 9).map fun o => (o, proposalAt prog r.msgs p [0, o]))).filter (·.2 != 0)
      | none => [] }

/-- Run until `Halt`, one cycle per random number supplied. -/
def runSnaps : List Nat → Snap → List Snap
  | [], _ => []
  | rng :: rest, s =>
    let st : CogState := { wm := s.wm }
    if st.halted sys then []
    else
      let s' := snapOf s (cycle sys (fun _ => none) rng st)
      s' :: runSnaps rest s'

def runFrom (start : List (List Nat)) (rngs : List Nat) : List Snap :=
  runSnaps rngs
    { tabs := prog.preds.map fun p => (p.name, Tab.ofFn p.dom (wm0 start p.name)), proposals := [] }

def Snap.board (s : Snap) : List (List Nat) :=
  (List.range 3).map fun y => (List.range 3).map fun x =>
    ((List.range 9).find? fun t => 0 < s.wm "Board" [0, x, y, t]).getD 99

def Snap.success (s : Snap) : Bool := 0 < s.wm "Success" [0]
def Snap.halt (s : Snap) : Bool := 0 < s.wm "Halt" []

/-! ## Sigma38's runs, decision by decision

For each start position the checks compare, after every decision: the operator in `Selected`,
the nine cells of the board, the values proposed for `Selected`, and `Success` and `Halt`.

An operator is selected in one decision; its move changes the board in the next, and that
change removes the operator, so the decision after a move ends with none (finding E2). In the
decision that applies the move the operator is still proposed and carries the discounted
working-memory value: 0.1 becomes 0.109 (finding E5).

Where several operators are tied below 1, Sigma38 (impasse detection off) takes one of them,
not always the first (finding E3). The random number given for each decision is the index of
the operator Sigma38 took among the tied ones, in tile order; it is 0 where there is no tie.
The comparison is therefore: given Sigma38's choice at each tie, everything else agrees.
In the third position no move reaches a goal location and the program wanders; Sigma38 was
stopped after 12 decisions. -/

/-! ### Start position [[1, 2, 3], [8, 4, 5], [7, 0, 6]] (`ex-ep8.txt`, 7 decisions) -/
def runB : List Snap := runFrom [[1, 2, 3], [8, 4, 5], [7, 0, 6]] [0, 0, 0, 0, 0, 0, 0]
#guard runB.length == 7
#guard runB.map (·.selected) == [some 6, none, some 5, none, some 4, none, none]
#guard runB.map (·.board) ==
  [[[1, 2, 3], [8, 4, 5], [7, 0, 6]],
   [[1, 2, 3], [8, 4, 5], [7, 6, 0]],
   [[1, 2, 3], [8, 4, 5], [7, 6, 0]],
   [[1, 2, 3], [8, 4, 0], [7, 6, 5]],
   [[1, 2, 3], [8, 4, 0], [7, 6, 5]],
   [[1, 2, 3], [8, 0, 4], [7, 6, 5]],
   [[1, 2, 3], [8, 0, 4], [7, 6, 5]]]
#guard runB.map (·.proposals) ==
  [[(4, 1/10), (6, 1)],
   [(4, 1/10), (6, 1)],
   [(5, 1)],
   [(5, 1)],
   [(4, 1)],
   [(4, 1)],
   []]
#guard runB.map (·.success) == [false, false, false, false, false, false, true]
#guard runB.map (·.halt) == [false, false, false, false, false, false, true]

/-! ### Start position [[1, 2, 3], [8, 0, 5], [7, 4, 6]] (`ex-ep8-a.txt`, 9 decisions) -/
def runA : List Snap := runFrom [[1, 2, 3], [8, 0, 5], [7, 4, 6]] [0, 0, 0, 0, 0, 0, 0, 0, 0]
#guard runA.length == 9
#guard runA.map (·.selected) == [some 4, none, some 6, none, some 5, none, some 4, none, none]
#guard runA.map (·.board) ==
  [[[1, 2, 3], [8, 0, 5], [7, 4, 6]],
   [[1, 2, 3], [8, 4, 5], [7, 0, 6]],
   [[1, 2, 3], [8, 4, 5], [7, 0, 6]],
   [[1, 2, 3], [8, 4, 5], [7, 6, 0]],
   [[1, 2, 3], [8, 4, 5], [7, 6, 0]],
   [[1, 2, 3], [8, 4, 0], [7, 6, 5]],
   [[1, 2, 3], [8, 4, 0], [7, 6, 5]],
   [[1, 2, 3], [8, 0, 4], [7, 6, 5]],
   [[1, 2, 3], [8, 0, 4], [7, 6, 5]]]
#guard runA.map (·.proposals) ==
  [[(4, 1/10), (5, 1/10)],
   [(4, 109/1000), (5, 1/10)],
   [(4, 1/10), (6, 1)],
   [(4, 1/10), (6, 1)],
   [(5, 1)],
   [(5, 1)],
   [(4, 1)],
   [(4, 1)],
   []]
#guard runA.map (·.success) == [false, false, false, false, false, false, false, false, true]
#guard runA.map (·.halt) == [false, false, false, false, false, false, false, false, true]

/-! ### Start position [[1, 2, 3], [6, 7, 0], [5, 4, 8]] (`ex-ep8-c.txt`, 12 decisions) -/
def runC : List Snap := runFrom [[1, 2, 3], [6, 7, 0], [5, 4, 8]] [0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 1, 0]
#guard runC.length == 12
#guard runC.map (·.selected) == [some 7, none, some 4, none, some 5, none, some 6, none, some 6, none, some 6, none]
#guard runC.map (·.board) ==
  [[[1, 2, 3], [6, 7, 0], [5, 4, 8]],
   [[1, 2, 3], [6, 0, 7], [5, 4, 8]],
   [[1, 2, 3], [6, 0, 7], [5, 4, 8]],
   [[1, 2, 3], [6, 4, 7], [5, 0, 8]],
   [[1, 2, 3], [6, 4, 7], [5, 0, 8]],
   [[1, 2, 3], [6, 4, 7], [0, 5, 8]],
   [[1, 2, 3], [6, 4, 7], [0, 5, 8]],
   [[1, 2, 3], [0, 4, 7], [6, 5, 8]],
   [[1, 2, 3], [0, 4, 7], [6, 5, 8]],
   [[1, 2, 3], [6, 4, 7], [0, 5, 8]],
   [[1, 2, 3], [6, 4, 7], [0, 5, 8]],
   [[1, 2, 3], [0, 4, 7], [6, 5, 8]]]
#guard runC.map (·.proposals) ==
  [[(7, 1/10), (8, 1/10)],
   [(7, 109/1000), (8, 1/10)],
   [(4, 1/10), (6, 1/10), (7, 1/10)],
   [(4, 109/1000), (6, 1/10), (7, 1/10)],
   [(4, 1/10), (5, 1/10), (8, 1/10)],
   [(4, 1/10), (5, 109/1000), (8, 1/10)],
   [(5, 1/10), (6, 1/10)],
   [(5, 1/10), (6, 109/1000)],
   [(4, 1/10), (6, 1/10)],
   [(4, 1/10), (6, 109/1000)],
   [(5, 1/10), (6, 1/10)],
   [(5, 1/10), (6, 109/1000)]]
#guard runC.map (·.success) == [false, false, false, false, false, false, false, false, false, false, false, false]
#guard runC.map (·.halt) == [false, false, false, false, false, false, false, false, false, false, false, false]


/- The goal never changes. -/
#guard ((runA ++ runB ++ runC).all fun s => (List.range 3).all fun y => (List.range 3).all fun x =>
  0 < s.wm "Goal" [0, x, y, (goalBoard.getD y []).getD x 99])

end SigmaArch.EightPuzzle
