import SigmaArch.Lang
/-!
# The elaboration phase: summary-product graph solution to quiescence
([RDU16] §4.1, §5.2, §5.4)

"the elaboration phase updates distributions over variables, in parallel (at least logically)
and repeatedly, until quiescence is reached: that is, until no more updates are available. It
does not, however, either make choices or learn." (§4)

SIMPLIFIED: the factor graph, Rete-style alpha and beta networks and lazy message generation
are not modelled. What is modelled is their meaning: the messages a conditional sends to each
of its action and condact patterns, and what a predicate's working-memory variable node
(WMVN) computes from its inputs. Messages are computed simultaneously from the previous
round and the process stops when no message changes.
OPEN: for loopy graphs the paper's results may depend on message order ([RDU16] §5.2.1 gives
laziness and link deactivation as optimizations only). This model uses synchronous rounds.
-/

namespace SigmaArch

def assignments : List (String × Nat) → List Env
  | [] => [[]]
  | (x, n) :: vs => (List.range n).flatMap fun v => (assignments vs).map fun σ => (x, v) :: σ

/-- The assumptions in the graph during one elaboration: the latched working memory (WMFN),
the long-term-memory functions (LTMFN) and the perceptual functions (PBFN), "assumption
nodes … whose output can't change during the solution to the graph" ([RDU16] §5.2.1). -/
structure Assump where
  wm : String → Fn
  ltm : String → Option Fn := fun _ => none
  pb : String → Option Fn := fun _ => none

/-- The messages one conditional currently sends to working memory: one per action pattern
and one per condact pattern. -/
structure CMsgs where
  acts : List Tab
  cds : List Tab

abbrev Msgs := List CMsgs

/-- What arrives at a predicate's WMVN from conditionals. -/
structure Contrib where
  pos : List Fn
  neg : List Fn
  cds : List Fn

/-- Gather the messages to predicate `pn`. `excl = some (ci, j)` leaves out condact `j` of
conditional `ci`: in a factor graph a variable node's message to a factor leaves out what
that factor sent it. -/
def contribs (P : Prog) (ms : Msgs) (pn : String) (excl : Option (Nat × Nat)) : Contrib :=
  ((indexed P.conds).zip ms).foldl
    (fun acc ((ci, c), cm) =>
      let acts := (c.actions.zip cm.acts).filter fun (a, _) => a.pred == pn
      let cds := (indexed (c.condacts.zip cm.cds)).filter fun (j, (a, _)) =>
        a.pred == pn && excl != some (ci, j)
      { pos := acc.pos ++ ((acts.filter fun (a, _) => !a.neg).map (·.2.fn)),
        neg := acc.neg ++ ((acts.filter fun (a, _) => a.neg).map (·.2.fn)),
        cds := acc.cds ++ (cds.map fun (_, (_, f)) => f.fn) })
    { pos := [], neg := [], cds := [] }

/-- The value at the WMVN of predicate `p` for tuple `t`: the product of the messages that
arrive there. [RDU16] §4.4.4 and §5.4: "Actions are combined … disjunctively" with the
current WM assumption treated as one more action when the predicate is latched; "multiple
condacts combine via product"; "Negated actions … the inverted function is combined with the
positive actions via product, so that regions are deleted if they are positively mentioned in
any such negated action"; "If non-vector positive actions exist along with either condacts or
negated actions for the same predicate, the positive actions are first combined
disjunctively, with the result then multiplied in with the condacts and negated actions."
Perceptual and long-term-memory functions enter as further factors.
SETTLED by running Sigma38 (2026-11-12): an open-world predicate none of whose actions fires
is not masked; its value is its perceptual and long-term-memory input ("perceived value x with
an action that never fires: posterior stays x"). Here an open-world predicate contributes its
actions only if at least one of its positive action messages is nonzero somewhere. -/
def assembleAt (P : Prog) (A : Assump) (ms : Msgs) (p : Pred) (excl : Option (Nat × Nat))
    (t : Tup) : Val :=
  let c := contribs P ms p.name excl
  let fires := p.world == .closedWorld || c.pos.any fun f => (tuples p.dom).any fun t' => f t' != 0
  let actVals := (if p.latched then [A.wm p.name t] else []) ++ (if fires then c.pos.map (· t) else [])
  let comb : Val := if actVals.isEmpty then 1 else p.combine actVals
  let direct : Val := ((A.pb p.name).map (· t)).getD 1 * ((A.ltm p.name).map (· t)).getD 1
  direct * comb * vprod (c.cds.map (· t)) * vprod (c.neg.map fun f => inv (f t))

/-- Values that share the universal arguments of `t` form one distribution over the unique
arguments. -/
def Pred.univProj (p : Pred) (t : Tup) : List Nat :=
  ((p.args.zip t).filter fun (a, _) => a.uniq == .universal).map (·.2)

/-- Open-world unique predicates are normalized over their unique arguments before conditions
and condacts read them. Observed in Sigma38 (2026-11-12, finding N1): with silver evidence the
message to `Selected` is 0.636 for the walker and 0.182 for the table, which are 7/40 and 1/20
divided by their sum 0.275; with uniform evidence each of four concepts is 0.25 and the result
is a tie impasse.
CHOICE: the run shows the normalized value at the end of elaboration; where in message passing
the normalization happens is not observable. Here it is applied wherever a pattern reads the
predicate, including condact reads that leave out their own message. -/
def Pred.normalizes (p : Pred) : Bool := p.world == .openWorld && p.isUnique

/-- The function a condition or condact reads from a predicate. For a predicate that makes a
selection there are two working-memory variable nodes: "an extra WMVN is added to distinguish
what is being proposed for selection during graph modification versus what is considered valid
during graph solution" ([RDU16] §5.4.1). Patterns read the valid one, which is the latched
assumption. -/
def readFn (P : Prog) (A : Assump) (ms : Msgs) (excl : Option (Nat × Nat)) (pn : String) : Fn :=
  match P.pred? pn with
  | none => fun _ => 0
  | some p =>
    if p.sel.isSome then A.wm pn
    else if p.normalizes then
      let norm : Fn → Fn := fun f t =>
        let v := f t
        let z := vsum (((tuples p.dom).filter fun t' => p.univProj t' == p.univProj t).map f)
        if z == 0 then v else v / z
      let n1 := norm (assembleAt P A ms p excl)
      -- SETTLED by running Sigma38 (2026-11-12, ultimatum-soft, finding U1): an exponential
      -- predicate is normalized, transformed by e^(10 v) (`exponentiate-constant-times10-
      -- function` in graph-runtime.lisp) and normalized again. Acceptance weights 0.182 and
      -- 0.045 give 0.8 and 0.2, then 0.99753 and 0.00247.
      if p.exponential then norm (fun t => expR (10 * n1 t)) else n1
    else assembleAt P A ms p excl

def factorVal (reads : String → Fn) (σ : Env) (pat : Pat) : Val :=
  let v := match evalTerms σ pat.terms with
    | some t => reads pat.pred t
    | none => 0
  if pat.neg then inv v else v

/-- The value of the conditional's body for one assignment of its variables: the product of
its conditions, its condacts other than `skip`, and its function. "each factor node in the
beta network … embodies a constant function of 1 over the union of the variables on its
links. As incoming messages are multiplied times this function, the constraints from their
variable bindings affect outgoing messages, with across-pattern variable-equality checks
implicitly occurring when multiple uses of the same variable jointly constrain the same
dimension." ([RDU16] §5.4.2) -/
def Conditional.body (c : Conditional) (reads : String → Fn) (cdReads : Nat → String → Fn)
    (skip : Option Nat) (σ : Env) : Val :=
  vprod (c.conds.map fun p => factorVal reads σ p)
    * vprod ((indexed c.condacts).filterMap fun (j, p) =>
        if skip == some j then none else some (factorVal (cdReads j) σ p))
    * c.fnVal σ

/-- The message for tuple `t` of a pattern: the body summarized onto the pattern's variables.
"If an incoming variable isn't required in an outgoing message, the variable is summarized
out" ([RDU16] §5.4.2), by sum for `sumVars` and then by max for the rest (see `Conditional`). -/
def Conditional.summarize (c : Conditional) (P : Prog) (asg : List Env) (pat : Pat) (t : Tup)
    (body : Env → Val) : Val :=
  let vs := c.vars P
  let sel := asg.filter fun σ => evalTerms σ pat.terms == some t
  let maxVars := (vs.map (·.1)).filter fun x => !c.sumVars.contains x
  let key := fun (σ : Env) => maxVars.map fun x => (List.lookup x σ).getD 0
  let keys := (sel.map key).eraseDups
  vmaxL (keys.map fun k => vsum ((sel.filter fun σ => key σ == k).map body))

/-- Whether a pattern's constants and offsets allow tuple `t` at all. A condact constrains
only the region its pattern names: outside it the message is 1, not 0.
SETTLED by running Sigma38 (2026-11-12, ultimatum-soft, finding U2): a condact on
`Offer(agent:a …)` leaves agent b's distribution uniform (0.25 each). -/
def Pat.covers (P : Prog) (pat : Pat) (t : Tup) : Bool :=
  match P.pred? pat.pred with
  | none => false
  | some p =>
    ((pat.terms.zip p.args).zip t).all fun ((tm, a), x) =>
      match tm with
      | .const c => x == c
      | .var _ => true
      | .off _ d => 0 ≤ (x : Int) - d && (x : Int) - d < a.size

/-- The values every pattern reads from each predicate, tabulated once per round. -/
def readTabs (P : Prog) (A : Assump) (ms : Msgs) : List (String × Tab) :=
  P.preds.map fun p => (p.name, Tab.ofFn p.dom (readFn P A ms none p.name))

def readsOf (rt : List (String × Tab)) : String → Fn :=
  fun pn => ((rt.lookup pn).map Tab.fn).getD (fun _ => 0)

def cdReadsOf (P : Prog) (A : Assump) (ms : Msgs) (ci : Nat) (c : Conditional)
    (reads : String → Fn) : Nat → String → Fn :=
  let cdRt : List (Nat × (String × Tab)) := (indexed c.condacts).map fun (j, a) =>
    (j, (a.pred, Tab.ofFn (P.dom a.pred) (readFn P A ms (some (ci, j)) a.pred)))
  fun j pn =>
    match cdRt.lookup j with
    | some (an, f) => if an == pn then f.fn else reads pn
    | none => reads pn

/-- The messages one conditional sends given the current messages, by the definition:
every assignment of the conditional's variables is enumerated. Conditions read the WMVNs
(their link direction toward the predicate's assumption is deactivated); an action sends
toward working memory; a condact does both, reading the WMVN without its own previous message
and skipping its own factor in the body. This is the specification; `condMsgs` computes the
same messages without enumerating assignments whose value is 0. -/
def condMsgsSpec (P : Prog) (A : Assump) (ms : Msgs) (reads : String → Fn) (ci : Nat)
    (c : Conditional) : CMsgs :=
  let asg := assignments (c.vars P)
  let cdReads := cdReadsOf P A ms ci c reads
  { acts := c.actions.map fun a => Tab.ofFn (P.dom a.pred) fun t =>
      c.summarize P asg a t (c.body reads (fun _ => reads) none)
    cds := (indexed c.condacts).map fun (i, a) => Tab.ofFn (P.dom a.pred) fun t =>
      if a.covers P t then c.summarize P asg a t (c.body reads cdReads (some i)) else 1 }

/-- The assignments of the conditional's variables whose body value is not 0, each with that
value. Patterns are joined in the order written; an assignment is dropped as soon as one
factor is 0. Functional values are nonnegative, so the dropped assignments add nothing to a
sum and cannot be a maximum: summarizing over these gives the same messages as
`condMsgsSpec` (checked on the examples in `Examples.lean`; not proved). The Eight Puzzle's
goal test has 16 variables over 3 values, about 43 million assignments, of which one or none
has a nonzero value. -/
def Conditional.sols (c : Conditional) (P : Prog) (reads : String → Fn)
    (cdReads : Nat → String → Fn) (skip : Option Nat) : List (Env × Val) :=
  let fresh (σ : Env) (vs : List (String × Nat)) : List (String × Nat) :=
    vs.foldl (fun acc (x, n) =>
      if σ.any (·.1 == x) || acc.any (·.1 == x) then acc else acc ++ [(x, n)]) []
  let pats : List (Pat × (String → Fn)) :=
    c.conds.map (fun p => (p, reads))
      ++ (indexed c.condacts).filterMap fun (j, p) =>
          if skip == some j then none else some (p, cdReads j)
  let joined := pats.foldl
    (fun (acc : List (Env × Val)) (pr : Pat × (String → Fn)) =>
      acc.flatMap fun (σ, v) =>
        (assignments (fresh σ (patVars P pr.1))).filterMap fun τ =>
          let σ' := σ ++ τ
          let w := factorVal pr.2 σ' pr.1
          if w == 0 then none else some (σ', v * w))
    [([], 1)]
  joined.flatMap fun (σ, v) =>
    (assignments (fresh σ (c.vars P))).filterMap fun τ =>
      let σ' := σ ++ τ
      let w := v * c.fnVal σ'
      if w == 0 then none else some (σ', w)

/-- Summarize the nonzero assignments onto pattern `pat` at tuple `t` (as `summarize`). -/
def Conditional.summarizeSols (c : Conditional) (P : Prog) (sols : List (Env × Val))
    (pat : Pat) (t : Tup) : Val :=
  let sel := sols.filter fun s => evalTerms s.1 pat.terms == some t
  let maxVars := ((c.vars P).map (·.1)).filter fun x => !c.sumVars.contains x
  let key := fun (σ : Env) => maxVars.map fun x => (List.lookup x σ).getD 0
  let keys := (sel.map fun s => key s.1).eraseDups
  vmaxL (keys.map fun k => vsum ((sel.filter fun s => key s.1 == k).map (·.2)))

/-- The messages one conditional sends given the current messages (see `condMsgsSpec`). -/
def condMsgs (P : Prog) (A : Assump) (ms : Msgs) (reads : String → Fn) (ci : Nat)
    (c : Conditional) : CMsgs :=
  let cdReads := cdReadsOf P A ms ci c reads
  let actSols := c.sols P reads (fun _ => reads) none
  { acts := c.actions.map fun a => Tab.ofFn (P.dom a.pred) fun t =>
      c.summarizeSols P actSols a t
    cds := (indexed c.condacts).map fun (i, a) =>
      let s := c.sols P reads cdReads (some i)
      Tab.ofFn (P.dom a.pred) fun t => if a.covers P t then c.summarizeSols P s a t else 1 }

/-- One synchronous round of message passing. -/
def stepMsgs (P : Prog) (A : Assump) (ms : Msgs) : Msgs :=
  let reads := readsOf (readTabs P A ms)
  (indexed P.conds).map fun (ci, c) => condMsgs P A ms reads ci c

/-- The same round by the defining enumeration. -/
def stepMsgsSpec (P : Prog) (A : Assump) (ms : Msgs) : Msgs :=
  let reads := readsOf (readTabs P A ms)
  (indexed P.conds).map fun (ci, c) => condMsgsSpec P A ms reads ci c

/-- Initial messages: "all messages start on the first cycle with a constant value of 1, with
two exceptions: messages arriving at action-combination nodes, which are initialized to 0 …
and messages from assumption nodes, which are initialized to the function stored in the
node." ([RDU16] §5.2.1) Action messages start at 0 and condact messages at 1; assumptions
enter through `assembleAt`.
CHOICE: a condition therefore sees, in the first round, each predicate as its assumptions
alone, so chains of conditionals are followed one link per round. -/
def initMsgs (P : Prog) : Msgs :=
  P.conds.map fun c =>
    { acts := c.actions.map fun a => Tab.const (P.dom a.pred) 0,
      cds := c.condacts.map fun a => Tab.const (P.dom a.pred) 1 }

def msgsEq (P : Prog) (a b : Msgs) : Bool :=
  (P.conds.zip (a.zip b)).all fun (_, (m, m')) =>
    (m.acts.zip m'.acts).all (fun (f, g) => f.tbl == g.tbl)
    && (m.cds.zip m'.cds).all (fun (f, g) => f.tbl == g.tbl)

def elaborateAux (P : Prog) (A : Assump) : Nat → Msgs → Option Msgs
  | 0, _ => none
  | n + 1, ms =>
    let ms' := stepMsgs P A ms
    if msgsEq P ms ms' then some ms else elaborateAux P A n ms'

/-- Run to quiescence: `some ms` when no message changes within `fuel` rounds. -/
def elaborate (P : Prog) (A : Assump) (fuel : Nat) : Option Msgs :=
  elaborateAux P A fuel (initMsgs P)

/-- A quiescent message set is a fixed point of a round. -/
def Quiescent (P : Prog) (A : Assump) (ms : Msgs) : Bool := msgsEq P ms (stepMsgs P A ms)

theorem elaborateAux_quiescent (P : Prog) (A : Assump) :
    ∀ (n : Nat) (ms ms' : Msgs), elaborateAux P A n ms = some ms' → Quiescent P A ms' = true := by
  intro n
  induction n with
  | zero => intro ms ms' h; simp [elaborateAux] at h
  | succ n ih =>
    intro ms ms' h
    simp only [elaborateAux] at h
    split at h
    · rename_i hq
      simp at h
      subst h
      exact hq
    · exact ih _ _ h

/-- "Elaboration" returns only quiescent message sets. -/
theorem elaborate_quiescent (P : Prog) (A : Assump) (fuel : Nat) (ms : Msgs)
    (h : elaborate P A fuel = some ms) : Quiescent P A ms = true :=
  elaborateAux_quiescent P A fuel _ ms h

/-- The quiescent value of predicate `pn` at WMVN, for a predicate that makes no selection. -/
def wmvnTab (P : Prog) (A : Assump) (ms : Msgs) (p : Pred) : Tab :=
  Tab.ofFn p.dom (assembleAt P A ms p none)

end SigmaArch
