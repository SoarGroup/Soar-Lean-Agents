import SigmaArch.Learn
/-!
# Episodic learning and retrieval, compared with Sigma38

With episodic learning on (`(learn '(:e))`), Sigma38 generates, for each closed-world state
predicate that makes a selection, a set of predicates and conditionals (`init-predicate-em`
in `learning.lisp`). This file writes that set out for one predicate, `Concept(value)`, and
compares it with Sigma38:

* `TCLearn(time, value)`: the episodic function, one distribution over the value for each
  time, learned by the ordinary gradient-descent update with learning rate 0.2. Its
  conditional has conditions on `Time` and `Concept` and a condact on `TCLearn`.
* `TCSelect` and `TCRetrieve`: the same function, not learned through these predicates.
* `ConceptNext`: the value perceived in the current decision, the cue.
* `TimeEpisodic(time)`: which past time matches the cue. Its function is the temporal prior.
  The selection conditional has a condition on the cue and condacts on `TimeEpisodic` and
  `TCSelect`.
* `ConceptEpisodic(value)`: what is retrieved. The retrieval conditional has a condition on
  `TimeEpisodic` and condacts on `ConceptEpisodic` and `TCRetrieve`; it takes the maximum
  over time (Sigma's `:map t`).

How the comparison was made, and its limits:
* Sigma38's time type has 999,999 values (the constant `max-time`). The specification stores
  a function as a table over all tuples, so Sigma38 was rebuilt for this comparison with
  that one constant changed to 12. Nothing else was changed. The values compared are those
  of the 12-value system; the mechanism is the release's.
* Two runs are compared: one with the temporal prior held fixed (`do-not-learn`), and one
  with Sigma38's default, in which the prior is learned too (second part of this file).
* Two things Sigma38 does before each decision are supplied by hand here: `Time` is set to
  the decision count, and `Concept`, a closed-world perceived predicate, holds the value
  perceived in the previous decision. NOT FORMALIZED as mechanisms.
* The `State` argument is omitted (one state).

Sigma38 (so modified) was run for six decisions on 2026-11-12, perceiving walker, table, dog,
walker, table, table. The expected values below were generated from its trace by
`gen_epi_checks.py` and are compared to within 10^-5.

SETTLED by the run (finding P1): the value perceived in decision d is recorded at time d+1,
during decision d+1, when it is the content of working memory; each time's distribution is
updated once, from uniform to 0.7333 for the recorded value and 0.1333 for the others.
Retrieval in a decision uses the function as it was before that decision's update.
-/

namespace SigmaArch.Episodic

def nT : Nat := 12
def v (x : String) : Term := .var x

def fnPred (n : String) : Pred :=
  { name := n, args := [⟨"time", nT, .universal⟩, ⟨"value", 3, .unique⟩], world := .openWorld }

def prog : Prog :=
  { preds :=
      [ { name := "Time", args := [⟨"value", nT, .unique⟩], world := .closedWorld, sel := some .argmax },
        { name := "Concept", args := [⟨"value", 3, .unique⟩], world := .closedWorld, sel := some .argmax },
        { name := "ConceptNext", args := [⟨"value", 3, .unique⟩], world := .openWorld },
        { name := "TimeEpisodic", args := [⟨"value", nT, .unique⟩], world := .openWorld },
        { name := "ConceptEpisodic", args := [⟨"value", 3, .unique⟩], world := .openWorld },
        fnPred "TCLearn", fnPred "TCSelect", fnPred "TCRetrieve" ]
    conds :=
      [ { name := "learn",
          conds := [⟨"Time", [v "t"], false⟩, ⟨"Concept", [v "c"], false⟩],
          condacts := [⟨"TCLearn", [v "t", v "c"], false⟩] },
        { name := "select",
          conds := [⟨"ConceptNext", [v "c"], false⟩],
          condacts := [⟨"TimeEpisodic", [v "t"], false⟩, ⟨"TCSelect", [v "t", v "c"], false⟩],
          sumVars := ["c", "t"] },
        -- the maximum over time: no variable is summed
        { name := "retrieve",
          conds := [⟨"TimeEpisodic", [v "t"], false⟩],
          condacts := [⟨"ConceptEpisodic", [v "c"], false⟩, ⟨"TCRetrieve", [v "t", v "c"], false⟩] } ] }

/-- The temporal prior Sigma38 starts with: twice the weight on time 0 (13 parts in all). -/
def timePrior : Fn := fun t => if t == [0] then 2/13 else 1/13

/-- The system for one decision: the three function predicates share the learned function. -/
def sysOf (fnTab : Option Tab) (prior : Fn := timePrior) : Sys :=
  let f : Fn := match fnTab with
    | some t => t.fn
    | none => fun _ => 1/3
  { P := prog
    ltm := fun n =>
      if n == "TCLearn" || n == "TCSelect" || n == "TCRetrieve" then some f
      else if n == "TimeEpisodic" then some prior
      else none
    detectImpasses := false }

structure Step where
  fnTab : Tab
  timePost : List Val
  retrieved : List Val
  count : Nat
  /-- The temporal prior after this decision, and the number of updates by each of the two
  predicates that share it. -/
  prior : Tab := Tab.ofFn [nT] timePrior
  cE : Nat := 0
  cT : Nat := 0

/-- Decision `d` (from 1): `prev` is the value perceived in the previous decision, `cue` the
value perceived now. Returns the function after learning and the two posteriors from this
decision's elaboration. -/
def decide (d : Nat) (prev : Option Nat) (cue : Nat) (fnTab : Option Tab) (count : Nat)
    (learnPrior : Bool := false) (prior : Tab := Tab.ofFn [nT] timePrior) (cE cT : Nat := 0) : Step :=
  let S := sysOf fnTab prior.fn
  let wm : String → Fn := fun n =>
    if n == "Time" then Fn.ofRows [([d], 1)]
    else if n == "Concept" then (match prev with | some p => Fn.ofRows [([p], 1)] | none => Fn.const 0)
    else Fn.const 0
  let pb : String → Option Fn := fun n =>
    if n == "ConceptNext" then some (Fn.ofRows [([cue], 1)]) else none
  let A : Assump := { wm := wm, ltm := S.ltm, pb := pb }
  let ms := (elaborate prog A S.fuel).getD []
  let post := fun (pn : String) (k : Nat) =>
    let t := Tab.ofFn [k] (readFn prog A ms none pn)
    (List.range k).map fun i => t.fn [i]
  let s' := cycleLearn S { rate := 1/5 } ["TCLearn"] pb 0
    { cog := { wm := wm }, ltm := (match fnTab with | some t => [("TCLearn", t)] | none => []),
      counts := [("TCLearn", count)] }
  -- The temporal prior is one function shared by `TimeEpisodic` and `Time`. Sigma38 updates
  -- it twice in a decision (finding P2, from the learning trace): first from what arrives
  -- at `TimeEpisodic`, which is how well each time matches the cue, at rate 0.0002; then from
  -- the current time, at rate 0.00000002.
  let (p1, ch1) :=
    if learnPrior then
      match prog.pred? "TimeEpisodic" with
      | some p => learnTable { rate := 1/5000 } cE [nT] (fun _ => true) timePrior prior.fn
                    (gradientAt prog A ms p)
      | none => (prior, false)
    else (prior, false)
  let (p2, ch2) :=
    if learnPrior then
      learnTable { rate := 1/50000000 } cT [nT] (fun _ => true) timePrior p1.fn (wm "Time")
    else (p1, false)
  { fnTab := (s'.ltm.lookup "TCLearn").getD (Tab.ofFn [nT, 3] fun _ => 1/3)
    timePost := post "TimeEpisodic" nT
    retrieved := post "ConceptEpisodic" 3
    count := (s'.counts.lookup "TCLearn").getD count
    prior := p2, cE := if ch1 then cE + 1 else cE, cT := if ch2 then cT + 1 else cT }

def runAll : List Nat → Nat → Option Nat → Option Tab → Nat → List Step
  | [], _, _, _, _ => []
  | c :: cs, d, prev, ft, k =>
    let s := decide d prev c ft k
    s :: runAll cs (d + 1) (some c) (some s.fnTab) s.count

/-- The same run with the temporal prior learned. -/
def runAllL : List Nat → Nat → Option Nat → Option Step → List Step
  | [], _, _, _ => []
  | c :: cs, d, prev, st =>
    let s := match st with
      | some o => decide d prev c (some o.fnTab) o.count true o.prior o.cE o.cT
      | none => decide d prev c none 0 true
    s :: runAllL cs (d + 1) (some c) (some s)

def perceived : List Nat := [0, 1, 2, 0, 1, 1]

/-- Sigma38's episodic function after each decision: 12 times by 3 values. -/
def expFn : List (List Val) :=
  [[0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334],
   [0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.73333335, 0.13333334, 0.13333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334],
   [0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.73333335, 0.13333334, 0.13333334, 0.13333334, 0.73333335, 0.13333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334],
   [0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.73333335, 0.13333334, 0.13333334, 0.13333334, 0.73333335, 0.13333334, 0.13333334, 0.13333334, 0.73333335, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334],
   [0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.73333335, 0.13333334, 0.13333334, 0.13333334, 0.73333335, 0.13333334, 0.13333334, 0.13333334, 0.73333335, 0.73333335, 0.13333334, 0.13333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334],
   [0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.73333335, 0.13333334, 0.13333334, 0.13333334, 0.73333335, 0.13333334, 0.13333334, 0.13333334, 0.73333335, 0.73333335, 0.13333334, 0.13333334, 0.13333334, 0.73333335, 0.13333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334]]

/-- Sigma38's posterior over time (which past time matches the cue) in each decision. -/
def expTime : List (List Val) :=
  [[0.15384616, 0.07692308, 0.07692308, 0.07692308, 0.07692308, 0.07692308, 0.07692308, 0.07692308, 0.07692308, 0.07692308, 0.07692308, 0.07692308],
   [0.15384616, 0.07692308, 0.07692308, 0.07692308, 0.07692308, 0.07692308, 0.07692308, 0.07692308, 0.07692308, 0.07692308, 0.07692308, 0.07692308],
   [0.16129032, 0.08064516, 0.032258064, 0.08064516, 0.08064516, 0.08064516, 0.08064516, 0.08064516, 0.08064516, 0.08064516, 0.08064516, 0.08064516],
   [0.14705881, 0.07352941, 0.1617647, 0.029411765, 0.07352941, 0.07352941, 0.07352941, 0.07352941, 0.07352941, 0.07352941, 0.07352941, 0.07352941],
   [0.15384614, 0.07692307, 0.03076923, 0.16923076, 0.03076923, 0.07692307, 0.07692307, 0.07692307, 0.07692307, 0.07692307, 0.07692307, 0.07692307],
   [0.16129032, 0.08064516, 0.032258064, 0.17741935, 0.032258064, 0.032258064, 0.08064516, 0.08064516, 0.08064516, 0.08064516, 0.08064516, 0.08064516]]

/-- Sigma38's retrieved value distribution in each decision. -/
def expRetrieved : List (List Val) :=
  [[0.3333333, 0.3333333, 0.3333333],
   [0.3333333, 0.3333333, 0.3333333],
   [0.33333334, 0.33333334, 0.33333334],
   [0.54751134, 0.22624435, 0.22624435],
   [0.22624435, 0.54751134, 0.22624435],
   [0.22624433, 0.5475113, 0.22624433]]

def trace : List Step := runAll perceived 1 none none 0

def close (a b : List Val) : Bool :=
  a.length == b.length && (a.zip b).all fun (x, y) => near x y (1 / 100000)

/-- All comparisons with Sigma38, on one evaluation of the run:
* six decisions;
* the episodic function after each decision;
* the posterior over time in each decision;
* what is retrieved in each decision;
* decision 4, where walker is perceived again: it was recorded at time 2, which becomes the
  most likely time (11/68), and walker is retrieved with 121/221;
* at the end, a recorded time slice is 11/15, 2/15, 2/15 and an unrecorded one is still
  uniform: nothing recorded is changed later. -/
def allAgree : Bool :=
  let tr := trace
  tr.length == 6
  && ((tr.map fun s => (tuples [nT, 3]).map s.fnTab.fn).zip expFn).all (fun (a, b) => close a b)
  && ((tr.map (·.timePost)).zip expTime).all (fun (a, b) => close a b)
  && ((tr.map (·.retrieved)).zip expRetrieved).all (fun (a, b) => close a b)
  && (tr[3]?.map fun s => s.timePost.getD 2 0) == some (11/68)
  && (tr[3]?.map fun s => s.retrieved) == some [121/221, 50/221, 50/221]
  && (tr[5]?.map fun s => (List.range 3).map fun c => s.fnTab.fn [2, c]) == some [11/15, 2/15, 2/15]
  && (tr[5]?.map fun s => (List.range 3).map fun c => s.fnTab.fn [9, c]) == some [1/3, 1/3, 1/3]

#guard allAgree

/-! ## With the temporal prior learned (Sigma38's default)

Sigma38's values are single-precision, and the second of the two updates changes the prior
by about 0.0000002, which is at the limit of that precision; the comparison to within 10^-5
therefore tests the first update (changes of about 0.0001) and not the second. -/

/-- Sigma38's episodic function after each decision: 12 times by 3 values. -/
def expFnL : List (List Val) :=
  [[0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334],
   [0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.73333335, 0.13333334, 0.13333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334],
   [0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.73333335, 0.13333334, 0.13333334, 0.13333334, 0.73333335, 0.13333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334],
   [0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.73333335, 0.13333334, 0.13333334, 0.13333334, 0.73333335, 0.13333334, 0.13333334, 0.13333334, 0.73333335, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334],
   [0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.73333335, 0.13333334, 0.13333334, 0.13333334, 0.73333335, 0.13333334, 0.13333334, 0.13333334, 0.73333335, 0.73333335, 0.13333334, 0.13333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334],
   [0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.73333335, 0.13333334, 0.13333334, 0.13333334, 0.73333335, 0.13333334, 0.13333334, 0.13333334, 0.73333335, 0.73333335, 0.13333334, 0.13333334, 0.13333334, 0.73333335, 0.13333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334, 0.33333334]]

/-- Sigma38's posterior over time (which past time matches the cue) in each decision. -/
def expTimeL : List (List Val) :=
  [[0.15384616, 0.07692308, 0.07692308, 0.07692308, 0.07692308, 0.07692308, 0.07692308, 0.07692308, 0.07692308, 0.07692308, 0.07692308, 0.07692308],
   [0.15384574, 0.07692312, 0.07692312, 0.07692312, 0.07692312, 0.07692312, 0.07692312, 0.07692312, 0.07692312, 0.07692312, 0.07692312, 0.07692312],
   [0.16129032, 0.0806454, 0.03225816, 0.08064513, 0.08064513, 0.08064513, 0.08064513, 0.08064513, 0.08064513, 0.08064513, 0.08064513, 0.08064513],
   [0.14708912, 0.07354978, 0.16154492, 0.029419912, 0.07354953, 0.07354953, 0.07354953, 0.07354953, 0.07354953, 0.07354953, 0.07354953, 0.07354953],
   [0.15387776, 0.07693955, 0.030817285, 0.16901457, 0.030775819, 0.076939285, 0.076939285, 0.076939285, 0.076939285, 0.076939285, 0.076939285, 0.076939285],
   [0.16125205, 0.080626704, 0.032243814, 0.17766774, 0.032200363, 0.032250684, 0.080626436, 0.080626436, 0.080626436, 0.080626436, 0.080626436, 0.080626436]]

/-- Sigma38's retrieved value distribution in each decision. -/
def expRetrievedL : List (List Val) :=
  [[0.3333333, 0.3333333, 0.3333333],
   [0.33333334, 0.33333334, 0.33333334],
   [0.33333334, 0.33333334, 0.33333334],
   [0.54712343, 0.2264383, 0.2264383],
   [0.22642815, 0.54714364, 0.22642815],
   [0.22604166, 0.5479166, 0.22604166]]

/-- Sigma38's temporal prior after each decision. -/
def expPrior : List (List Val) :=
  [[0.15384614, 0.07692332, 0.07692306, 0.07692306, 0.07692306, 0.07692306, 0.07692306, 0.07692306, 0.07692306, 0.07692306, 0.07692306, 0.07692306],
   [0.15384613, 0.076923296, 0.076923296, 0.076923035, 0.076923035, 0.076923035, 0.076923035, 0.076923035, 0.076923035, 0.076923035, 0.076923035, 0.076923035],
   [0.1538566, 0.07693376, 0.07680795, 0.07693376, 0.076933496, 0.076933496, 0.076933496, 0.076933496, 0.076933496, 0.076933496, 0.076933496, 0.076933496],
   [0.15384702, 0.076924175, 0.07702781, 0.07680945, 0.076924175, 0.076923914, 0.076923914, 0.076923914, 0.076923914, 0.076923914, 0.076923914, 0.076923914],
   [0.153847, 0.076924145, 0.07690776, 0.07704947, 0.076804124, 0.076924145, 0.076923884, 0.076923884, 0.076923884, 0.076923884, 0.076923884, 0.076923884],
   [0.15385747, 0.07693461, 0.07679245, 0.077311486, 0.07668881, 0.07680883, 0.07693461, 0.07693435, 0.07693435, 0.07693435, 0.07693435, 0.07693435]]

def traceL : List Step := runAllL perceived 1 none none

/-- Agreement with Sigma38 when the temporal prior is learned: the episodic function, the
prior after each decision, the posterior over time and what is retrieved. The prior of a
time falls when that time's record matches the cue badly: after decision 3 (cue dog, walker
recorded at time 2) the prior of time 2 is below that of its neighbours. -/
def allAgreeL : Bool :=
  let tr := traceL
  tr.length == 6
  && ((tr.map fun s => (tuples [nT, 3]).map s.fnTab.fn).zip expFnL).all (fun (a, b) => close a b)
  && ((tr.map fun s => (List.range nT).map fun t => s.prior.fn [t]).zip expPrior).all (fun (a, b) => close a b)
  && ((tr.map (·.timePost)).zip expTimeL).all (fun (a, b) => close a b)
  && ((tr.map (·.retrieved)).zip expRetrievedL).all (fun (a, b) => close a b)
  && (tr[2]?.map fun s => Decidable.decide (s.prior.fn [2] < s.prior.fn [1])) == some true

#guard allAgreeL


end SigmaArch.Episodic
