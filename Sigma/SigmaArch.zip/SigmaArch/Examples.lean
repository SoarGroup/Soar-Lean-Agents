import SigmaArch.Adapt
/-!
# Examples from [RDU16], checked by evaluation

Each example is a program from the paper run through `cycle`. The checks are `#guard`s, so
`lake build` fails if the specification stops giving these results. They show that the
specification does what the paper's text says for these cases; they are not comparisons
with Sigma's output.
-/

namespace SigmaArch.Examples

/-- Transitive rule over `Above(first:object second:object)` (Figures 16(a) and 31(a)):
"Given Above(first:o1 second:o2), Above(first:o2 second:o3), Above(first:o4 second:o5) and
Above(first:o5 second:o6) in the WM function, the conditional suggests that
Above(first:o1 second:o3) and Above(first:o4 second:o6) be added." ([RDU16] §4.4.4)
Objects o1..o6 are indices 0..5. -/
def aboveP : Prog :=
  { preds := [{ name := "Above", args := [⟨"first", 6, .universal⟩, ⟨"second", 6, .universal⟩],
                world := .closedWorld }]
    conds := [{ name := "Transitive-Above",
                conds := [⟨"Above", [.var "a", .var "b"], false⟩,
                          ⟨"Above", [.var "b", .var "c"], false⟩],
                actions := [⟨"Above", [.var "a", .var "c"], false⟩] }] }

def aboveWM : String → Fn := fun _ =>
  Fn.ofRows [([0, 1], 1), ([1, 2], 1), ([3, 4], 1), ([4, 5], 1)]

def aboveR := cycle { P := aboveP } (fun _ => none) 0 { wm := aboveWM }

#guard aboveR.quiescent
#guard aboveR.state.wm "Above" [0, 2] == 1
#guard aboveR.state.wm "Above" [3, 5] == 1
#guard aboveR.state.wm "Above" [0, 1] == 1     -- the existing elements are retained
#guard aboveR.state.wm "Above" [0, 3] == 0     -- nothing else is added
#guard aboveR.state.wm "Above" [0, 5] == 0

/-- Chaining within one elaboration: a longer chain closes completely in one cycle,
because actions feed the conditions in later rounds of the same elaboration phase. -/
def chainWM : String → Fn := fun _ => Fn.ofRows [([0, 1], 1), ([1, 2], 1), ([2, 3], 1)]
def chainR := cycle { P := aboveP } (fun _ => none) 0 { wm := chainWM }
#guard chainR.state.wm "Above" [0, 3] == 1
#guard chainR.state.wm "Above" [3, 0] == 0

/-- A reduced version of the classification scenario (Figures 7, 16(b), 31(b), 32):
objects: one; categories walker, table, dog, human (0..3); colors silver, brown, white
(0..2). A condact pair with a conditional function gives the likelihood of the color given
the concept; the concept has a uniform prior in long-term memory; a rule selects the concept
as the operator. "The entire classification scenario – from perception through
classification, selection, and action – occurs reactively … within a single cognitive cycle."
Numbers are ours. -/
def classP : Prog :=
  { preds :=
      [ { name := "Concept", args := [⟨"object", 1, .universal⟩, ⟨"value", 4, .unique⟩],
          world := .openWorld },
        { name := "Color", args := [⟨"object", 1, .universal⟩, ⟨"value", 3, .unique⟩],
          world := .openWorld },
        { name := "Selected", args := [⟨"state", 3, .universal⟩, ⟨"operator", 4, .unique⟩],
          world := .closedWorld, sel := some .argmax },
        { name := "Impasse",
          args := [⟨"state", 3, .universal⟩, ⟨"operator", 4, .universal⟩,
                   ⟨"type", 3, .unique⟩],
          world := .closedWorld } ]
    conds :=
      [ { name := "Concept-Color",
          condacts := [⟨"Concept", [.var "o", .var "c"], false⟩,
                       ⟨"Color", [.var "o", .var "k"], false⟩],
          fnVars := ["c", "k"],
          fn := fun t => match t with
            | [0, 0] => 7/10 | [0, 1] => 2/10 | [0, 2] => 1/10
            | [1, 0] => 2/10 | [1, 1] => 5/10 | [1, 2] => 3/10
            | [2, 0] => 1/10 | [2, 1] => 6/10 | [2, 2] => 3/10
            | [3, 0] => 1/10 | [3, 1] => 4/10 | [3, 2] => 5/10
            | _ => 0,
          sumVars := ["k"] },
        { name := "Select-Concept-as-Operator",
          conds := [⟨"Concept", [.const 0, .var "c"], false⟩],
          actions := [⟨"Selected", [.const 0, .var "c"], false⟩] } ] }

def classSys : Sys :=
  { P := classP, ltm := fun p => if p == "Concept" then some (fun _ => 1/4) else none }

def noWM : String → Fn := fun _ => Fn.const 0

def colorPB (rows : List (Tup × Val)) : String → Option Fn :=
  fun p => if p == "Color" then some (Fn.ofRows rows) else none

/-- Evidence: the object is silver. The walker is the most likely concept and is selected.
Open-world unique predicates are normalized before patterns read them (finding N1), so the
message to the Selected action is the normalized posterior: the unnormalized weights are
prior 1/4 times the likelihood of silver (7/40 and 1/20), and their sum is 11/40. -/
def silverR := cycle classSys (colorPB [([0, 0], 1)]) 0 { wm := noWM }
#guard silverR.quiescent
#guard silverR.state.wm "Selected" [0, 0] == 1
#guard silverR.state.wm "Selected" [0, 1] == 0
#guard silverR.state.levels == 1
#guard ((silverR.msgs.getD 1 ⟨[], []⟩).acts.getD 0 ⟨[]⟩).fn [0, 0] == 7/11
#guard ((silverR.msgs.getD 1 ⟨[], []⟩).acts.getD 0 ⟨[]⟩).fn [0, 1] == 2/11

/-- A second cycle with no color evidence: every concept has weight 1/4. The walker was
selected and receives the retention bonus, so it stays selected and the cycle reports a
no-change impasse recorded at state 1 (finding §5.2: retention at any value). -/
def uniformPB := colorPB [([0, 0], 1), ([0, 1], 1), ([0, 2], 1)]
def retainedR := cycle classSys uniformPB 0 silverR.state
#guard retainedR.state.wm "Selected" [0, 0] == 1
#guard retainedR.state.wm "Impasse" [1, 0, 2] == 1
#guard retainedR.state.levels == 2

/-- No color evidence from the start: every concept has the same posterior weight (1/4 each,
all below 1), so there are several equal maxima below 1 and the result is a tie impasse at
state 0. It is recorded at state 1, the new substate, for each tied operator (finding I1), and
the cycle adds that one level (finding I2). Nothing was selected before, so `Selected` stays
empty. -/
def noEvidenceR := cycle classSys uniformPB 0 { wm := noWM }
#guard noEvidenceR.state.levels == 2
#guard noEvidenceR.state.wm "Selected" [0, 0] == 0
#guard noEvidenceR.state.wm "Impasse" [1, 2, 0] == 1      -- tie impasse, the dog is tied
#guard noEvidenceR.state.wm "Impasse" [1, 0, 1] == 0
/-- This program has no knowledge for the metalevel, so in the next cycle nothing is selected
at state 1 either and a none impasse is recorded at state 2 for every operator; impasses keep
nesting, one level per cycle, up to the limit of the state type (here 3 states). In Sigma38
the number of states keeps growing in this situation without further records (finding I3,
apparently a defect, not copied). -/
def noEvidence2 := cycle classSys uniformPB 0 noEvidenceR.state
#guard noEvidence2.state.levels == 3
#guard noEvidence2.state.wm "Impasse" [2, 3, 1] == 1
#guard noEvidence2.state.wm "Impasse" [1, 2, 0] == 1

/-- Contradictory evidence (no value positive): a none impasse at state 0, recorded at state 1
for every operator (finding §5.2). -/
def noneR := cycle classSys (colorPB []) 0 { wm := noWM }
#guard noneR.state.levels == 2
#guard noneR.state.wm "Impasse" [1, 0, 1] == 1
#guard noneR.state.wm "Impasse" [1, 3, 1] == 1

/- Selection rules, directly ([RDU16] §4.2.1). -/
#guard (match selectAmong 0 [(0, 1/2), (1, 1/4)] with | .chosen 0 => true | _ => false)
#guard (match selectAmong 0 [(0, 1/2), (1, 1/2)] with | .tieImp _ => true | _ => false)
#guard (match selectAmong 0 [(0, 0), (1, 0)] with | .noneImp => true | _ => false)
#guard (match selectAmong 0 [(0, 1), (1, 1), (2, 1/2)] with | .chosen 0 => true | _ => false)
#guard (match selectAmong 1 [(0, 1), (1, 1), (2, 1/2)] with | .chosen 1 => true | _ => false)
/- Retention (Sigma38, §5.2): a best choice that is already selected is kept whatever the
random number; at a tie below 1 the existing choice is kept (no-change, not a tie); a selected
operator outside the tied set does not prevent the tie; an operator with no proposals left
stays selected instead of giving a none impasse. -/
#guard (match selectRetaining 0 (some 1) [(0, 1), (1, 1)] with
  | .chosen 1 => true | _ => false)
#guard (match selectRetaining 0 (some 2) [(0, 1), (1, 1)] with
  | .chosen 0 => true | _ => false)
#guard (match selectRetaining 0 (some 1) [(0, 1/2), (1, 1/2)] with
  | .chosen 1 => true | _ => false)
#guard (match selectRetaining 0 (some 2) [(0, 1/2), (1, 1/2), (2, 1/4)] with
  | .tieImp _ => true | _ => false)
#guard (match selectRetaining 0 (some 1) [(0, 0), (1, 0)] with
  | .chosen 1 => true | _ => false)

/-- A no-change impasse: an operator that is still selected at the next adaptation phase.
Rule: always propose operator 0 with weight 1/2. The impasse is recorded at state 1. -/
def stuckP : Prog :=
  { preds :=
      [ { name := "Selected", args := [⟨"state", 2, .universal⟩, ⟨"operator", 2, .unique⟩],
          world := .closedWorld, sel := some .argmax },
        { name := "Impasse",
          args := [⟨"state", 2, .universal⟩, ⟨"operator", 2, .universal⟩,
                   ⟨"type", 3, .unique⟩],
          world := .closedWorld } ]
    conds :=
      [ { name := "Propose-0",
          actions := [⟨"Selected", [.const 0, .const 0], false⟩],
          fnVars := [], fn := fun _ => 1/2 } ] }

def stuckS : Sys := { P := stuckP }
def stuck1 := cycle stuckS (fun _ => none) 0 { wm := noWM }
def stuck2 := cycle stuckS (fun _ => none) 0 stuck1.state
#guard stuck1.state.wm "Selected" [0, 0] == 1
#guard stuck1.state.levels == 1       -- first selection: no impasse
#guard stuck2.state.levels == 2       -- same operator at the next phase: no-change impasse
#guard stuck2.state.wm "Impasse" [1, 0, 2] == 1

/-- An open-world predicate with an action that never fires is not masked (finding §5.2):
the perceived value stays. Here `Trig` is empty, so the action on `Color` never fires. -/
def maskP : Prog :=
  { preds :=
      [ { name := "Trig", args := [⟨"a", 1, .universal⟩], world := .closedWorld },
        { name := "Color", args := [⟨"object", 1, .universal⟩, ⟨"value", 3, .unique⟩],
          world := .openWorld } ]
    conds :=
      [ { name := "Never",
          conds := [⟨"Trig", [.const 0], false⟩],
          actions := [⟨"Color", [.const 0, .const 1], false⟩] } ] }
def maskA : Assump := { wm := noWM, pb := colorPB [([0, 0], 1)] }
def maskMs : Msgs := (elaborate maskP maskA 10).getD []
#guard (elaborate maskP maskA 10).isSome
#guard readFn maskP maskA maskMs none "Color" [0, 0] == 1
#guard readFn maskP maskA maskMs none "Color" [0, 1] == 0

/-! ## The two ways of computing a round agree

`stepMsgs` joins patterns and drops assignments whose value is 0; `stepMsgsSpec` enumerates
every assignment. They are compared on the programs above, from the initial messages and from
the quiescent ones. -/
def roundsAgree (P : Prog) (A : Assump) : Bool :=
  let m0 := initMsgs P
  let m1 := stepMsgs P A m0
  let mq := (elaborate P A 20).getD m0
  msgsEq P (stepMsgs P A m0) (stepMsgsSpec P A m0)
    && msgsEq P (stepMsgs P A m1) (stepMsgsSpec P A m1)
    && msgsEq P (stepMsgs P A mq) (stepMsgsSpec P A mq)

#guard roundsAgree aboveP { wm := aboveWM }
#guard roundsAgree aboveP { wm := chainWM }
#guard roundsAgree classP { wm := noWM, ltm := classSys.ltm, pb := colorPB [([0, 0], 1)] }
#guard roundsAgree classP { wm := noWM, ltm := classSys.ltm, pb := uniformPB }
#guard roundsAgree classP { wm := silverR.state.wm, ltm := classSys.ltm, pb := uniformPB }
#guard roundsAgree stuckP { wm := noWM }
#guard roundsAgree maskP maskA

/-! ## Offsets, combination of proposals, and selection without impasse detection -/

/-- `Next(i)` holds one place to the right of every place where `Cell(i)` holds: the action's
argument is `i + 1`. Position 3 has no place to its right, and a condition with offset −1 at
position 0 matches nothing. -/
def offP : Prog :=
  { preds := [ { name := "Cell", args := [⟨"i", 4, .universal⟩], world := .closedWorld },
               { name := "Next", args := [⟨"i", 4, .universal⟩], world := .closedWorld },
               { name := "Prev", args := [⟨"i", 4, .universal⟩], world := .closedWorld } ]
    conds := [ { name := "shift-right", conds := [⟨"Cell", [.var "i"], false⟩],
                 actions := [⟨"Next", [.off "i" 1], false⟩] },
               { name := "has-left", conds := [⟨"Cell", [.var "i"], false⟩,
                                                ⟨"Cell", [.off "i" (-1)], false⟩],
                 actions := [⟨"Prev", [.var "i"], false⟩] } ] }
def offWM : String → Fn := fun pn => if pn == "Cell" then Fn.ofRows [([0], 1), ([1], 1), ([3], 1)] else Fn.const 0
def offR := cycle { P := offP } (fun _ => none) 0 { wm := offWM }
#guard (List.range 4).map (fun i => offR.state.wm "Next" [i]) == [0, 1, 1, 0]
#guard (List.range 4).map (fun i => offR.state.wm "Prev" [i]) == [0, 1, 0, 0]
#guard roundsAgree offP { wm := offWM }

/-- Two proposals for one operator combine by probabilistic-or (finding E1; Sigma38 gives
0.55, 0.51 and 0.91 for the pairs below, and selects the third operator). -/
def combP : Prog :=
  { preds := [ { name := "Selected", args := [⟨"state", 1, .universal⟩, ⟨"operator", 3, .unique⟩],
                 world := .closedWorld, sel := some .argmax } ]
    conds := [(0, 1/10), (0, 1/2), (1, 3/10), (1, 3/10), (2, 7/10), (2, 7/10)].map fun (o, w) =>
      ({ name := "p", actions := [⟨"Selected", [.const 0, .const o], false⟩], fn := fun _ => w } : Conditional) }
def combR := cycle { P := combP, detectImpasses := false } (fun _ => none) 0 { wm := noWM }
#guard (match combP.pred? "Selected" with
  | some p => (List.range 3).map (fun o => proposalAt combP combR.msgs p [0, o]) == [11/20, 51/100, 91/100]
  | none => false)
#guard combR.state.wm "Selected" [0, 2] == 1

/-- With impasse detection off (finding E3): a tie below 1 selects one of the tied operators
and no level is added; an operator with no remaining proposals stays selected. Sigma38
selected the first of the two tied operators in eight runs. -/
def tieOffP (ws : List Val) : Prog :=
  { preds := [ { name := "Selected", args := [⟨"state", 2, .universal⟩, ⟨"operator", 3, .unique⟩],
                 world := .closedWorld, sel := some .argmax } ]
    conds := (indexed ws).map fun (o, w) =>
      ({ name := "p", actions := [⟨"Selected", [.const 0, .const o], false⟩], fn := fun _ => w } : Conditional) }
def tieOff1 := cycle { P := tieOffP [1/2, 1/2, 1/10], detectImpasses := false } (fun _ => none) 0 { wm := noWM }
def tieOff2 := cycle { P := tieOffP [1/5, 1/5, 3/5], detectImpasses := false } (fun _ => none) 0 tieOff1.state
def tieOff3 := cycle { P := tieOffP [0, 0, 0], detectImpasses := false } (fun _ => none) 0 tieOff2.state
#guard tieOff1.state.wm "Selected" [0, 0] == 1 && tieOff1.state.levels == 1
#guard tieOff2.state.wm "Selected" [0, 2] == 1 && tieOff2.state.wm "Selected" [0, 0] == 0
#guard tieOff3.state.wm "Selected" [0, 2] == 1 && tieOff3.state.levels == 1

end SigmaArch.Examples
