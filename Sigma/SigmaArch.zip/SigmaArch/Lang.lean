import SigmaArch.Core
/-!
# Sigma cognitive language: predicates, patterns, conditionals ([RDU16] §4.4)
-/

namespace SigmaArch

/-- "Universal arguments are like variables in rule systems, where any or all of the elements
in the variable's domain may be valid. Unique arguments are like random variables in
probabilistic systems, where a distribution is provided over all of the elements of the
variable's domain but only a single value is actually correct." ([RDU16] §4.4.3) -/
inductive Uniq | universal | unique
  deriving DecidableEq, Repr

/-- "whether they are open world or closed world, and thus whether unspecified regions in
their functions are assumed to be unknown … or false" ([RDU16] §4.4.3). -/
inductive World | openWorld | closedWorld
  deriving DecidableEq, Repr

/-- Selection annotations on a unique argument: `!` argmax, `$` expected value, `=`
probability matching ([RDU16] §4.4.3); Boltzmann selection is a variant of matching.
SIMPLIFIED: only `argmax` is given semantics (`Adapt.lean`). -/
inductive SelMode | argmax | expected | matching | boltzmann
  deriving DecidableEq, Repr

structure Arg where
  name : String
  size : Nat
  uniq : Uniq := .universal

/-- A predicate: "Predicates specify relations among sets of typed arguments."
`normalized` and `vector` select how actions are combined ([RDU16] §4.4.4). -/
structure Pred where
  name : String
  args : List Arg
  world : World
  sel : Option SelMode := none
  /-- SETTLED by running Sigma38 (2026-11-12, finding E1): predicates are normalized unless
  declared otherwise (`:no-normalize`), so the default is `true`; two proposals of 0.1 and
  0.5 for one operator of `Selected` combine to 0.55. -/
  normalized : Bool := true
  vector : Bool := false
  /-- Sigma's `^` argument (`:exponential t`): patterns read the predicate's distribution
  transformed exponentially (`Elab.readFn`). -/
  exponential : Bool := false

namespace Pred

def dom (p : Pred) : List Nat := p.args.map (·.size)

/-- "Any predicate that has at least one unique argument … is itself considered unique." -/
def isUnique (p : Pred) : Bool := p.args.any (·.uniq == .unique)

/-- Whether the working-memory assumption is kept across cycles as one more action.
[RDU16] §5.4.1: "If the predicate's entire distribution is not replaced each cycle – as, for
example, with the Selected predicate – then the direct path from the WMFN to the WMVN is
converted into an indirect path through a disjunctive action-combination factor node … In
effect, the current WM assumption is treated simply as another action."
SETTLED by running Sigma38 (2026-11-12, `Sigma-Run-Findings.docx` §5.2): every closed-world
predicate is latched, unique ones with `!` included. The results of actions persist after
the trigger is retracted; every unique argument in Sigma carries a selection mode, so the
earlier exception for unique predicates without selection has no counterpart. -/
def latched (p : Pred) : Bool := p.world == .closedWorld

/-- Action combination ([RDU16] §4.4.4): "max is … used in action combination for non-vector
universal predicates. For unique predicates with normalized functions, actions are combined
via … probabilistic-or … Actions are combined via summation for both non-normalized unique
predicates and vector predicates." -/
def combine (p : Pred) (vals : List Val) : Val :=
  if p.vector then vsum vals
  else if p.isUnique then (if p.normalized then vprobOrL vals else vsum vals)
  else vmaxL vals

end Pred

/-- A pattern term. A constant restricts to one value; a variable "implies a value of 1
across the argument's whole domain" ([RDU16] §4.4.4). `off x d` is a variable with an
offset, the only affine transform given semantics: the argument's value is `x + d`
(Sigma's `(x (x -1))`; in the Eight Puzzle of Sigma38 the tile at `x` with the blank at
`(x -1)` has the blank on its left). A value outside the argument's domain matches nothing.
SIMPLIFIED: filters, scaling, `:explicit`, not-equal tests and reuse of a variable inside
one pattern are NOT FORMALIZED. -/
inductive Term
  | const (v : Nat)
  | var (x : String)
  | off (x : String) (d : Int)

/-- A predicate pattern: "it only includes the predicate's name and arguments, and argument
types are replaced by constants … or variables". `neg` marks a negated pattern. -/
structure Pat where
  pred : String
  terms : List Term
  neg : Bool := false

abbrev Env := List (String × Nat)

/-- The value of a term; `none` when an offset takes it below 0. -/
def evalTerm (σ : Env) : Term → Option Nat
  | .const v => some v
  | .var x => some ((List.lookup x σ).getD 0)
  | .off x d =>
    let v : Int := ((List.lookup x σ).getD 0 : Nat) + d
    if v < 0 then none else some v.toNat

def evalTerms (σ : Env) (ts : List Term) : Option Tup := ts.mapM (evalTerm σ)

/-- A conditional: "Conditionals structure long-term memory in terms of interactions among
predicate patterns – that is, conditions, actions and condacts … – plus optional functions."
`fn` is a conditional function with the variables it is defined over (default constant 1,
the "equivalent of a best preference", Figure 35).

`sumVars` lists the variables summarized out by sum; all others are summarized out by max.
[RDU16] §4.4.4: "In the cognitive architecture, all universal variables are summarized out
via max. Unique variables are typically summarized out by sum/integration".
CHOICE: the list is given explicitly. The paper does not say how a variable's mode follows
from the predicates it occurs in.
CHOICE: sums are taken first, then the max over the remaining variables. The two do not
commute and the paper states no order. -/
structure Conditional where
  name : String
  conds : List Pat := []
  condacts : List Pat := []
  actions : List Pat := []
  fnVars : List String := []
  fn : Tup → Val := fun _ => 1
  sumVars : List String := []
  /-- The function variables the function is normalized over (Sigma's `:normal`); used when
  the function is learned (`Learn.lean`). -/
  normal : List String := []

def Conditional.fnVal (c : Conditional) (σ : Env) : Val :=
  c.fn (c.fnVars.map fun x => (List.lookup x σ).getD 0)

/-- A cognitive program: predicates and conditionals. -/
structure Prog where
  preds : List Pred
  conds : List Conditional

namespace Prog

def pred? (P : Prog) (n : String) : Option Pred := P.preds.find? (·.name == n)

def dom (P : Prog) (n : String) : List Nat :=
  match P.pred? n with
  | some p => p.dom
  | none => []

end Prog

/-- Variables of a pattern with the size of the argument each occurs in. -/
def patVars (P : Prog) (pat : Pat) : List (String × Nat) :=
  match P.pred? pat.pred with
  | none => []
  | some p => (pat.terms.zip p.args).filterMap fun (t, a) =>
      match t with
      | .var x => some (x, a.size)
      | .off x _ => some (x, a.size)
      | .const _ => none

/-- All variables of a conditional (first occurrence fixes the size). -/
def Conditional.vars (c : Conditional) (P : Prog) : List (String × Nat) :=
  ((c.conds ++ c.condacts ++ c.actions).flatMap (patVars P)).foldl
    (fun acc (x, n) => if acc.any (·.1 == x) then acc else acc ++ [(x, n)]) []

end SigmaArch
