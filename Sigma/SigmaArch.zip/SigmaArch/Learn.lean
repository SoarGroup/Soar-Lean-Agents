import SigmaArch.Adapt
/-!
# Learning: gradient descent on long-term-memory functions ([RDU16] §4.2.4, §5.3)

"Learning – that is, changes to long-term memory – occurs in Sigma via a process of gradient
descent over its functions … it does not acquire or modify the more complex structures that
are also found in LTM. Sigma is currently unable to learn new structures, including anything
corresponding to Soar's chunking mechanism." ([RDU16] §4.2.4)

For a function with standard normalization the paper gives (Eq. 3 and 4)

    g'(v) = g(v) / ∫ f(v) g(v) dv
    f_new(v) = f(v) + scale(λ (g'(v) − average(g'(v))))

where `g` is the gradient, "messages arriving at the factor nodes that store the LTM
functions", `λ` the learning rate, and `scale` caps the update "if its maximum is above a
threshold".

SETTLED by running Sigma38 (2026-11-12, `simple-gdl` with `trace-gdl`, finding G1): the steps
are exactly these, in this order, with learning rate 0.05 and maximum increment 1 by default;
the integral and the average are taken over the predicate's unique arguments, separately for
each tuple of its universal arguments.

Formalized: the update of a predicate's function from one decision's gradient, with the cap
on the update and with smoothing, and the same for a conditional's function. NOT FORMALIZED: vector functions
(Eq. 5), learning rates per function, the exponential-product gradient, non-adaptive and
divisive variants selected by Sigma's parameters, episodic learning, and the learning
switches of Sigma's `learn` command.
-/

namespace SigmaArch

structure LearnParams where
  /-- Sigma38 `learning-rate`, default 0.05. -/
  rate : Val := 1 / 20
  /-- Sigma38 `max-gdl-increment`, default 1. -/
  maxInc : Val := 1
  /-- Sigma38 `adaptive-smoothing`, default on: the threshold is 0.1 / (c + span), where
  `span` is the number of values of the unique arguments and `c` is 1 plus the number of
  earlier updates of the function (Sigma38 starts its change counter at 1). With it off the
  threshold is `smoothing-parameter`, default 0.000001. -/
  adaptive : Bool := true
  smoothing : Val := 1 / 1000000

/-- The gradient for predicate `p`'s function: what arrives at its function from the rest of
the graph, which is the value at the predicate's working memory without the function itself.
CHOICE: the gradient is read at quiescence, from the same messages the decision uses. -/
def gradientAt (P : Prog) (A : Assump) (ms : Msgs) (p : Pred) : Fn :=
  assembleAt P { A with ltm := fun n => if n == p.name then none else A.ltm n } ms p none

/-- One gradient-descent update of a function over the tuples that share universal
arguments `u` (Eq. 3 and 4), before smoothing. The values are unchanged when the gradient
has no overlap with the function. Returns the values and whether the gradient is nonzero
anywhere in the group. -/
def learnGroup (lp : LearnParams) (ts : List Tup) (f g : Fn) : List (Tup × Val) × Bool :=
  let z := vsum (ts.map fun t => f t * g t)
  if z == 0 || ts.isEmpty then (ts.map fun t => (t, f t), ts.any fun t => g t != 0)
  else
    let g' := ts.map fun t => g t / z
    let avg := vsum g' / (ts.length : Nat)
    let upd := g'.map fun x => lp.rate * (x - avg)
    let m := vmaxL upd
    let upd := if lp.maxInc < m then upd.map (· * lp.maxInc / m) else upd
    ((ts.zip upd).map fun (t, u) => (t, f t + u), true)

/-- Smoothing and renormalization of one group ("smoothing – that is, small increases to
parts of the updated function that ensure no element is below a specified threshold",
[RDU16] §4.2.4). SETTLED by running Sigma38 (2026-11-12, finding G2, `update-via-gradient`,
`smooth-plm`, `subtractive-normalize-plm`): values below the threshold are raised to it; the
excess of the sum over 1 is then subtracted in equal shares from the values above the
threshold; if a value is then below a tenth of the threshold, values are raised again and the
group is divided by its sum. -/
def smoothGroup (smooth : Val) (doSmooth : Bool) (vs : List (Tup × Val)) : List (Tup × Val) :=
  let raised := if doSmooth then vs.map fun (t, x) => (t, if x < smooth then smooth else x) else vs
  let sum := vsum (raised.map (·.2))
  let above := (raised.filter fun r => smooth < r.2).length
  let sub : Val := if above == 0 then 0 else (sum - 1) / (above : Nat)
  let normed := raised.map fun (t, x) => (t, if smooth < x then x - sub else x)
  let mn := normed.foldl (fun m r => if r.2 < m then r.2 else m) 1
  if mn < smooth / 10 then
    let again := normed.map fun (t, x) => (t, if x < smooth then smooth else x)
    let s2 := vsum (again.map (·.2))
    if s2 == 0 then again else again.map fun (t, x) => (t, x / s2)
  else normed

/-- Set to 0 every value at a tuple where `base` is 0. -/
def restrictZeros (base : Fn) (l : List (Tup × Val)) : List (Tup × Val) :=
  l.map fun r => (r.1, if base r.1 == 0 then 0 else r.2)

theorem mem_restrictZeros_zero (base : Fn) (l : List (Tup × Val)) (e : Tup × Val)
    (he : e ∈ restrictZeros base l) (hz : (base e.1 == 0) = true) : e.2 = 0 := by
  unfold restrictZeros at he
  rw [List.mem_map] at he
  obtain ⟨r, _, rfl⟩ := he
  simp only at hz ⊢
  simp [hz]

/-- The update of every group, before smoothing. `isNormal i` says whether argument `i` is one
the function is normalized over; the other arguments index separate distributions. -/
def learnRaw (lp : LearnParams) (dom : List Nat) (isNormal : Nat → Bool) (f g : Fn) :
    List (List (Tup × Val) × Bool) :=
  let proj := fun (t : Tup) => ((indexed t).filter fun (i, _) => !isNormal i).map (·.2)
  let groups := ((tuples dom).map proj).eraseDups
  groups.map fun u => learnGroup lp ((tuples dom).filter fun t => proj t == u) f g

/-- Smoothing and renormalization of all groups. `count` is the number of earlier updates
of this function. -/
def smoothAll (lp : LearnParams) (count : Nat) (dom : List Nat) (isNormal : Nat → Bool)
    (raw : List (List (Tup × Val) × Bool)) : List (Tup × Val) :=
  let span := ((indexed dom).filter fun (i, _) => isNormal i).foldl (fun a r => a * r.2) 1
  let smooth : Val := if lp.adaptive then (1 / 10) / ((count + 1 + span : Nat) : Val) else lp.smoothing
  let mn := (raw.flatMap (·.1)).foldl (fun m r => if r.2 < m then r.2 else m) 1
  raw.flatMap fun r => smoothGroup smooth (mn < smooth) r.1

/-- The updated function over domain `dom`, as a table, and whether it changed.
SETTLED by running Sigma38 (finding G4): when the gradient is nonzero anywhere, every group
is smoothed and renormalized, and then "constrained by original zeros": a value that was 0
in the function as first given (`base`) is 0 again. Learning cannot make a zero positive, and
a function with such zeros does not sum to 1 afterward. -/
def learnTable (lp : LearnParams) (count : Nat) (dom : List Nat) (isNormal : Nat → Bool)
    (base f g : Fn) : Tab × Bool :=
  if (learnRaw lp dom isNormal f g).any (·.2) then
    (⟨restrictZeros base (smoothAll lp count dom isNormal (learnRaw lp dom isNormal f g))⟩, true)
  else (⟨(learnRaw lp dom isNormal f g).flatMap (·.1)⟩, false)

/-- The updated function of predicate `p`: normalized over its unique arguments. `base` is
the function as first given. -/
def learnPred (lp : LearnParams) (count : Nat) (p : Pred) (base f g : Fn) : Tab × Bool :=
  learnTable lp count p.dom (fun i => (p.args[i]?.map (·.uniq == .unique)).getD false) base f g

/-- The domain of a conditional's function: the sizes of its function variables. -/
def Conditional.fnDom (c : Conditional) (P : Prog) : List Nat :=
  c.fnVars.map fun x => ((c.vars P).lookup x).getD 1

/-- The gradient for a conditional's function: what the conditional's patterns send to it,
which is the body without the function, summarized onto the function's variables. Each
condact is read without the conditional's own message to it.
SETTLED by running Sigma38 (2026-11-12, finding G3): a conditional function with `:normal`
is updated by the same steps as a predicate function, separately for each value of its other
variables. -/
def condGradient (P : Prog) (A : Assump) (ms : Msgs) (ci : Nat) (c : Conditional) : Fn :=
  let reads := readsOf (readTabs P A ms)
  let c1 : Conditional := { c with fn := fun _ => 1, fnVars := [] }
  let sols := c1.sols P reads (cdReadsOf P A ms ci c reads) none
  let maxVars := ((c.vars P).map (·.1)).filter fun x => !c.sumVars.contains x
  let key := fun (σ : Env) => maxVars.map fun x => (List.lookup x σ).getD 0
  fun x =>
    let sel := sols.filter fun s => c.fnVars.map (fun v => (List.lookup v s.1).getD 0) == x
    let keys := (sel.map fun s => key s.1).eraseDups
    vmaxL (keys.map fun k => vsum ((sel.filter fun s => key s.1 == k).map (·.2)))

/-- A state with learned long-term-memory functions. -/
structure LState where
  cog : CogState
  ltm : List (String × Tab)
  /-- Number of updates made so far to each learned function. -/
  counts : List (String × Nat) := []
  /-- Learned conditional functions, by conditional name, with their update counts. -/
  cfn : List (String × Tab) := []
  ccounts : List (String × Nat) := []

def LState.ltmFn (s : LState) (base : String → Option Fn) : String → Option Fn := fun n =>
  match s.ltm.lookup n with
  | some t => some t.fn
  | none => base n

/-- One cognitive cycle followed by learning for the predicates named in `learned`:
"adaptation … making choices and persistent changes to memories based on the quiescent
distributions engendered by the elaboration phase" ([RDU16] §4.2). -/
def cycleLearn (S : Sys) (lp : LearnParams) (learned : List String) (pb : String → Option Fn)
    (rng : Nat) (s : LState) (learnedConds : List String := []) : LState :=
  let withLearned : Conditional → Conditional := fun c =>
    match s.cfn.lookup c.name with
    | some t => { c with fn := t.fn }
    | none => c
  let P' : Prog := { S.P with conds := S.P.conds.map withLearned }
  let S' : Sys := { S with P := P', ltm := s.ltmFn S.ltm }
  let r := cycle S' pb rng s.cog
  if !r.quiescent then s
  else
    let A : Assump := { wm := s.cog.wm, ltm := S'.ltm, pb := pb }
    let new := learned.filterMap fun n =>
      match S.P.pred? n, S'.ltm n with
      | some p, some f =>
        let c := (s.counts.lookup n).getD 0
        let (t, ch) := learnPred lp c p ((S.ltm n).getD f) f (gradientAt S.P A r.msgs p)
        some (n, t, if ch then c + 1 else c)
      | _, _ => none
    let newC := (indexed P'.conds).filterMap fun (ci, c) =>
      if learnedConds.contains c.name then
        let k := (s.ccounts.lookup c.name).getD 0
        let (t, ch) := learnTable lp k (c.fnDom P')
          (fun i => (c.fnVars[i]?.map c.normal.contains).getD false)
          (((S.P.conds.find? fun c0 => c0.name == c.name).map (·.fn)).getD c.fn) c.fn
          (condGradient P' A r.msgs ci c)
        some (c.name, t, if ch then k + 1 else k)
      else none
    { cog := r.state
      ltm := new.map (fun e => (e.1, e.2.1)) ++ s.ltm.filter fun e => !learned.contains e.1
      counts := new.map (fun e => (e.1, e.2.2)) ++ s.counts.filter fun e => !learned.contains e.1
      cfn := newC.map (fun e => (e.1, e.2.1)) ++ s.cfn.filter fun e => !learnedConds.contains e.1
      ccounts := newC.map (fun e => (e.1, e.2.2)) ++ s.ccounts.filter fun e => !learnedConds.contains e.1 }

/-! ## Sigma38's simplest learning test (`simple-gdl`, three values)

A predicate `Concept(value)` with a uniform function and a perceived value each decision.
Sigma38 was run with learning rate 0.05 and the perceived values 0, 1, 0, 2, 0, 0, 1, 0; the
function it printed after each decision is compared to within 10^-6. -/
namespace GdlTest

def prog : Prog :=
  { preds := [ { name := "Concept", args := [⟨"value", 3, .unique⟩], world := .openWorld } ]
    conds := [ { name := "concept", condacts := [⟨"Concept", [.var "c"], false⟩] } ] }

def sys : Sys := { P := prog, ltm := fun n => if n == "Concept" then some (fun _ => 1/3) else none }

def step (s : LState) (obs : Nat) : LState :=
  cycleLearn sys {} ["Concept"] (fun n => if n == "Concept" then some (Fn.ofRows [([obs], 1)]) else none) 0 s

def runObs : List Nat → LState → List LState
  | [], _ => []
  | o :: os, s => let s' := step s o; s' :: runObs os s'

def trace : List LState := runObs [0, 1, 0, 2, 0, 0, 1, 0] { cog := { wm := fun _ => Fn.const 0 }, ltm := [] }

def fnAfter (i : Nat) : List Val :=
  match (trace.getD (i - 1) { cog := { wm := fun _ => Fn.const 0 }, ltm := [] }).ltm.lookup "Concept" with
  | some t => (List.range 3).map fun v => t.fn [v]
  | none => []

def agrees (i : Nat) (e : List Val) : Bool :=
  let f := fnAfter i
  f.length == 3 && (f.zip e).all fun (a, b) => near a b (1 / 1000000)

#guard fnAfter 1 == [13/30, 17/60, 17/60]          -- exactly, from 1/3 + 0.05 (3 − 1)
#guard agrees 1 [0.43333334, 0.28333333, 0.28333333]
#guard agrees 2 [0.3745098, 0.40098038, 0.2245098]
#guard agrees 3 [0.46351504, 0.35647777, 0.18000719]
#guard agrees 4 [0.37092617, 0.2638889, 0.365185]
#guard agrees 5 [0.46079132, 0.21895632, 0.32025242]
#guard agrees 6 [0.53313065, 0.18278666, 0.28408277]
#guard agrees 7 [0.44194967, 0.3651486, 0.19290179]
#guard agrees 8 [0.517373, 0.32743692, 0.15519011]
/- The function stays a distribution. -/
#guard (List.range 8).all fun i => vsum (fnAfter (i + 1)) == 1

end GdlTest
/-! ## The same test with a sequence that triggers the cap and smoothing

Twelve observations of value 0, then 1, 0, 0, 2 (generated from Sigma38's trace). At the
13th decision the update exceeds the maximum increment and is scaled down, a value goes
negative and is raised to the threshold 0.1 / 16, and the excess is subtracted from the other
two (finding G2). -/
namespace SmoothTest
open GdlTest

def obs : List Nat := [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 2]
def expected : List (List Val) :=
  [[0.43333334, 0.28333333, 0.28333333],
   [0.5102564, 0.2448718, 0.2448718],
   [0.57558304, 0.21220848, 0.21220848],
   [0.63349533, 0.18325233, 0.18325233],
   [0.6861135, 0.15694328, 0.15694328],
   [0.7346963, 0.13265187, 0.13265187],
   [0.78006655, 0.109966755, 0.109966755],
   [0.82279795, 0.08860105, 0.08860105],
   [0.8633101, 0.068344966, 0.068344966],
   [0.90192115, 0.049039423, 0.049039423],
   [0.9388793, 0.03056035, 0.03056035],
   [0.97438264, 0.01280869, 0.01280869],
   [0.22766197, 0.76608807, 0.00625],
   [0.3376577, 0.6564599, 0.005882353],
   [0.4118606, 0.58258384, 0.0055555557],
   [0.005263158, 0.035882592, 0.95885426]]
def trace : List LState := runObs obs { cog := { wm := fun _ => Fn.const 0 }, ltm := [] }
def fnOf (s : LState) : List Val :=
  match s.ltm.lookup "Concept" with
  | some t => (List.range 3).map fun v => t.fn [v]
  | none => []
#guard trace.length == 16
#guard ((trace.map fnOf).zip expected).all fun (f, e) =>
  f.length == 3 && (f.zip e).all fun (a, b) => near a b (1 / 100000)
/- Decision 13 exactly: the smoothed value is 1/160. -/
#guard ((trace[12]?.map fnOf).map fun f => f.getD 2 0) == some (1 / 160)
#guard trace.all fun s => vsum (fnOf s) == 1

end SmoothTest

/-! ## Learning a conditional function (finding G3)

A conditional over a perceived context (two values) and a perceived value (three values)
whose function is normalized over the value: it learns the distribution of the value for each
context. Sigma38 was run with eight (context, value) pairs; its function after each decision
(generated from the trace) is compared to within 10^-5. -/
namespace CondFnTest

def prog : Prog :=
  { preds := [ { name := "Context", args := [⟨"c", 2, .unique⟩], world := .openWorld },
               { name := "Concept", args := [⟨"value", 3, .unique⟩], world := .openWorld } ]
    conds := [ { name := "cond-prior",
                 condacts := [⟨"Context", [.var "c"], false⟩, ⟨"Concept", [.var "v"], false⟩],
                 fnVars := ["c", "v"], fn := fun _ => 1/3, sumVars := ["c", "v"], normal := ["v"] } ] }

def obs : List (List Nat) := [[0, 0], [1, 2], [0, 0], [0, 1], [1, 2], [1, 0], [0, 0], [1, 1]]
def expected : List (List Val) :=
  [[0.43333334, 0.28333333, 0.28333333, 0.33333334, 0.33333334, 0.33333334],
   [0.43333334, 0.28333333, 0.28333333, 0.28333333, 0.28333333, 0.43333334],
   [0.5102564, 0.2448718, 0.2448718, 0.28333333, 0.28333333, 0.43333334],
   [0.44219357, 0.38099748, 0.17680895, 0.28333333, 0.28333333, 0.43333334],
   [0.44219357, 0.38099748, 0.17680895, 0.2448718, 0.2448718, 0.5102564],
   [0.44219357, 0.38099748, 0.17680895, 0.38099748, 0.17680895, 0.44219357],
   [0.5175753, 0.3433066, 0.13911806, 0.38099748, 0.17680895, 0.44219357],
   [0.5175753, 0.3433066, 0.13911806, 0.28673378, 0.36533636, 0.34792987]]

def runObs : List (List Nat) → LState → List LState
  | [], _ => []
  | o :: os, s =>
    let pb : String → Option Fn := fun n =>
      if n == "Context" then some (Fn.ofRows [([o.getD 0 0], 1)])
      else if n == "Concept" then some (Fn.ofRows [([o.getD 1 0], 1)]) else none
    let s' := cycleLearn { P := prog } {} [] pb 0 s ["cond-prior"]
    s' :: runObs os s'

def trace : List LState := runObs obs { cog := { wm := fun _ => Fn.const 0 }, ltm := [] }
def fnOf (s : LState) : List Val :=
  match s.cfn.lookup "cond-prior" with
  | some t => (tuples [2, 3]).map t.fn
  | none => []
#guard trace.length == 8
#guard ((trace.map fnOf).zip expected).all fun (f, e) =>
  f.length == 6 && (f.zip e).all fun (a, b) => near a b (1 / 100000)
/- After the first pair (context p, value 0): only context p's distribution has changed. -/
#guard (trace[0]?.map fnOf) == some [13/30, 17/60, 17/60, 1/3, 1/3, 1/3]

end CondFnTest

/-! ## A function that starts with a zero (finding G4)

The function starts as 0.5, 0.5, 0. Sigma38 never makes the third value positive, even when
that value is the one perceived; perceiving it still moves the other two, through smoothing
and renormalization. Expected values are generated from Sigma38's trace. -/
namespace ZeroTest

def sys : Sys :=
  { P := GdlTest.prog
    ltm := fun n => if n == "Concept" then some (Fn.ofRows [([0], 1/2), ([1], 1/2)]) else none }
def obs : List Nat := [0, 0, 2, 2, 1]
def expected : List (List Val) :=
  [[0.5375, 0.43750003, 0],
   [0.5865116, 0.3934884, 0],
   [0.5881783, 0.39515507, 0],
   [0.5893687, 0.39634553, 0],
   [0.5271853, 0.4603147, 0]]
def runObs : List Nat → LState → List LState
  | [], _ => []
  | o :: os, s =>
    let s' := cycleLearn sys {} ["Concept"]
      (fun n => if n == "Concept" then some (Fn.ofRows [([o], 1)]) else none) 0 s
    s' :: runObs os s'
def trace : List LState := runObs obs { cog := { wm := fun _ => Fn.const 0 }, ltm := [] }
#guard trace.length == 5
#guard ((trace.map SmoothTest.fnOf).zip expected).all fun (f, e) =>
  f.length == 3 && (f.zip e).all fun (a, b) => near a b (1 / 100000)
#guard trace.all fun s => (SmoothTest.fnOf s).getD 2 1 == 0

end ZeroTest

end SigmaArch
