import SigmaArch.Learn
/-!
# Naive-Bayes concept learning, compared with Sigma38

Sigma38's supervised concept learner (`define-data-set` and `setup-gd` in `learning.lisp`) on
the release's balloon data (`adult+stretch.data.txt`): four attributes (color, size, act,
age) and the category `inflated`, two values each. The category has a prior function and
each attribute a likelihood function given the category; all start uniform and are learned
by gradient descent, one instance per decision. Sigma38 was run for 20 decisions under SBCL
on 2026-11-12. The instances and the expected functions below were generated from its trace
by `gen_nb_checks.py`; each of the five functions is compared after every decision to within
10^-5 (Sigma38 computes in single precision).

Values are indexed in the order of Sigma's type definitions: yellow, purple; large, small;
stretch, dip; adult, child; t, f.
-/

namespace SigmaArch.LearnNB

def atts : List String := ["Color", "Size", "Act", "Age"]

def prog : Prog :=
  { preds :=
      atts.map (fun a => ({ name := a, args := [⟨"v", 2, .unique⟩], world := .openWorld } : Pred))
      ++ [ { name := "Inflated", args := [⟨"c", 2, .unique⟩], world := .openWorld } ]
      ++ atts.map fun a =>
          ({ name := "Inflated" ++ a, args := [⟨"c", 2, .universal⟩, ⟨"v", 2, .unique⟩],
             world := .openWorld } : Pred)
    conds := atts.map fun a =>
      ({ name := "likelihood-" ++ a,
         condacts := [ ⟨"Inflated", [.var "c"], false⟩, ⟨a, [.var "a"], false⟩,
                       ⟨"Inflated" ++ a, [.var "c", .var "a"], false⟩ ],
         sumVars := ["c", "a"] } : Conditional) }

def learned : List String := "Inflated" :: atts.map ("Inflated" ++ ·)

/-- Every learned function starts uniform (Sigma's `:function 1`, normalized). -/
def sys : Sys := { P := prog, ltm := fun n => if learned.contains n then some (fun _ => 1/2) else none }

/-- Perception of one instance: the four attribute values and the category. -/
def perceive (inst : List Nat) : String → Option Fn := fun n =>
  match (atts ++ ["Inflated"]).findIdx? (· == n) with
  | some i => some (Fn.ofRows [([inst.getD i 0], 1)])
  | none => none

def runInst : List (List Nat) → LState → List LState
  | [], _ => []
  | i :: is, s => let s' := cycleLearn sys {} learned (perceive i) 0 s; s' :: runInst is s'

def instances : List (List Nat) :=
  [[0, 1, 0, 0, 0],
   [0, 1, 0, 0, 0],
   [0, 1, 0, 1, 1],
   [0, 1, 1, 0, 1],
   [0, 1, 1, 1, 1],
   [0, 0, 0, 0, 0],
   [0, 0, 0, 0, 0],
   [0, 0, 0, 1, 1],
   [0, 0, 1, 0, 1],
   [0, 0, 1, 1, 1],
   [1, 1, 0, 0, 0],
   [1, 1, 0, 0, 0],
   [1, 1, 0, 1, 1],
   [1, 1, 1, 0, 1],
   [1, 1, 1, 1, 1],
   [1, 0, 0, 0, 0],
   [1, 0, 0, 0, 0],
   [1, 0, 0, 1, 1],
   [1, 0, 1, 0, 1],
   [1, 0, 1, 1, 1]]

/-- Sigma38's functions after each decision, in the order Inflated, InflatedColor, InflatedSize, InflatedAct, InflatedAge. -/
def expected : List (List (List Val)) :=
  [[[0.55, 0.45], [0.55, 0.45, 0.5, 0.5], [0.45, 0.55, 0.5, 0.5], [0.55, 0.45, 0.5, 0.5], [0.55, 0.45, 0.5, 0.5]],
   [[0.5954546, 0.40454543], [0.5954546, 0.40454546, 0.5, 0.5], [0.40454546, 0.5954546, 0.5, 0.5], [0.5954546, 0.40454546, 0.5, 0.5], [0.5954546, 0.40454546, 0.5, 0.5]],
   [[0.53365684, 0.4663432], [0.5954546, 0.40454546, 0.55, 0.45], [0.40454546, 0.5954546, 0.45, 0.55], [0.5954546, 0.40454546, 0.55, 0.45], [0.5954546, 0.40454546, 0.45, 0.55]],
   [[0.48004824, 0.51995176], [0.5954546, 0.40454546, 0.5954546, 0.40454546], [0.40454546, 0.5954546, 0.40454546, 0.5954546], [0.5954546, 0.40454546, 0.49444446, 0.50555557], [0.5954546, 0.40454546, 0.50555557, 0.49444446]],
   [[0.43196684, 0.56803316], [0.5954546, 0.40454546, 0.6374393, 0.36256072], [0.40454546, 0.5954546, 0.36256072, 0.6374393], [0.5954546, 0.40454546, 0.4449939, 0.55500615], [0.5954546, 0.40454546, 0.45499378, 0.5450063]],
   [[0.48984164, 0.51015836], [0.6374393, 0.36256072, 0.6374393, 0.36256072], [0.4663432, 0.53365684, 0.36256072, 0.6374393], [0.6374393, 0.36256072, 0.4449939, 0.55500615], [0.6374393, 0.36256072, 0.45499378, 0.5450063]],
   [[0.54087853, 0.45912147], [0.67665875, 0.3233413, 0.6374393, 0.36256072], [0.51995176, 0.48004824, 0.36256072, 0.6374393], [0.67665875, 0.3233413, 0.4449939, 0.55500615], [0.67665875, 0.3233413, 0.45499378, 0.5450063]],
   [[0.4864267, 0.5135733], [0.67665875, 0.3233413, 0.67665875, 0.3233413], [0.51995176, 0.48004824, 0.43151468, 0.5684853], [0.67665875, 0.3233413, 0.50117445, 0.4988256], [0.67665875, 0.3233413, 0.40912277, 0.5908773]],
   [[0.43774816, 0.5622518], [0.67665875, 0.3233413, 0.713605, 0.28639507], [0.51995176, 0.48004824, 0.48945013, 0.51054984], [0.67665875, 0.3233413, 0.4510567, 0.5489433], [0.67665875, 0.3233413, 0.47022906, 0.5297709]],
   [[0.3932841, 0.60671586], [0.67665875, 0.3233413, 0.74863833, 0.25136164], [0.51995176, 0.48004824, 0.5405279, 0.45947212], [0.67665875, 0.3233413, 0.40551466, 0.59448534], [0.67665875, 0.3233413, 0.42303887, 0.57696116]],
   [[0.4568514, 0.5431486], [0.59934103, 0.40065894, 0.74863833, 0.25136164], [0.46787366, 0.5321263, 0.5405279, 0.45947212], [0.713605, 0.28639507, 0.40551466, 0.59448534], [0.713605, 0.28639507, 0.42303887, 0.57696116]],
   [[0.5115738, 0.48842618], [0.5369438, 0.46305618, 0.74863833, 0.25136164], [0.42089233, 0.57910764, 0.5405279, 0.45947212], [0.74863833, 0.25136164, 0.40551466, 0.59448534], [0.74863833, 0.25136164, 0.42303887, 0.57696116]],
   [[0.460389, 0.539611], [0.5369438, 0.46305618, 0.64918005, 0.35081995], [0.42089233, 0.57910764, 0.4861176, 0.5138824], [0.74863833, 0.25136164, 0.46716473, 0.5328353], [0.74863833, 0.25136164, 0.3797084, 0.62029165]],
   [[0.4140593, 0.58594066], [0.5369438, 0.46305618, 0.5779184, 0.4220816], [0.42089233, 0.57910764, 0.43746835, 0.56253165], [0.74863833, 0.25136164, 0.42024592, 0.5797541], [0.74863833, 0.25136164, 0.44554842, 0.55445164]],
   [[0.37139288, 0.6286071], [0.5369438, 0.46305618, 0.51868814, 0.48131186], [0.42089233, 0.57910764, 0.3930264, 0.6069736], [0.74863833, 0.25136164, 0.3771242, 0.62287587], [0.74863833, 0.25136164, 0.4004588, 0.59954125]],
   [[0.43870705, 0.56129295], [0.48295465, 0.5170453, 0.51868814, 0.48131186], [0.48028997, 0.51971006, 0.3930264, 0.6069736], [0.7820323, 0.21796767, 0.3771242, 0.62287587], [0.7820323, 0.21796767, 0.4004588, 0.59954125]],
   [[0.4956927, 0.5043073], [0.434603, 0.565397, 0.51868814, 0.48131186], [0.53234184, 0.46765816, 0.3930264, 0.6069736], [0.8140003, 0.18599969, 0.3771242, 0.62287587], [0.8140003, 0.18599969, 0.4004588, 0.59954125]],
   [[0.44611976, 0.5538803], [0.434603, 0.565397, 0.46674678, 0.53325325], [0.53234184, 0.46765816, 0.45663536, 0.54336464], [0.8140003, 0.18599969, 0.44341534, 0.5565847], [0.8140003, 0.18599969, 0.3587602, 0.64123976]],
   [[0.40098363, 0.59901637], [0.434603, 0.565397, 0.41986474, 0.5801353], [0.53234184, 0.46765816, 0.51138365, 0.48861638], [0.8140003, 0.18599969, 0.3984985, 0.60150146], [0.8140003, 0.18599969, 0.42844465, 0.5715554]],
   [[0.35924855, 0.6407515], [0.434603, 0.565397, 0.37677136, 0.62322867], [0.53234184, 0.46765816, 0.5602706, 0.4397294], [0.8140003, 0.18599969, 0.35693586, 0.64306414], [0.8140003, 0.18599969, 0.38470435, 0.61529565]]]

def trace : List LState := runInst instances { cog := { wm := fun _ => Fn.const 0 }, ltm := [] }

/-- The learned functions after a decision, in the order of `expected`. -/
def fns (s : LState) : List (List Val) :=
  learned.map fun n =>
    match s.ltm.lookup n, prog.pred? n with
    | some t, some p => (tuples p.dom).map t.fn
    | _, _ => []

def agreeAt (i : Nat) : Bool :=
  match trace[i]?, expected[i]? with
  | some s, some e =>
    let f := fns s
    f.length == e.length && (f.zip e).all fun (a, b) =>
      a.length == b.length && (a.zip b).all fun (x, y) => near x y (1 / 100000)
  | _, _ => false

#guard trace.length == 20 && expected.length == 20
/- All five functions agree with Sigma38 after each of the 20 decisions. -/
#guard (List.range 20).all agreeAt
/- After the first instance (yellow, small, stretch, adult, inflated) exactly. -/
#guard (trace[0]?.map fns) == some [[11/20, 9/20], [11/20, 9/20, 1/2, 1/2], [9/20, 11/20, 1/2, 1/2],
                                    [11/20, 9/20, 1/2, 1/2], [11/20, 9/20, 1/2, 1/2]]
/- Every learned function stays a distribution over its unique argument. -/
#guard trace.all fun s => (fns s).all fun f =>
  if f.length == 2 then vsum f == 1 else vsum (f.take 2) == 1 && vsum (f.drop 2) == 1

end SigmaArch.LearnNB
