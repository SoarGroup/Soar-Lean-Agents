import SigmaArch.Adapt
/-!
# The soft ultimatum game of Sigma38, compared with Sigma38's posteriors

The program is `ultimatum-soft` (`ultimatum-softv4.lisp` in the Sigma38 release, regression
test `test-ultimatum-soft`). Agent A offers agent B a quantity 0..3 of 3 units; B accepts or
rejects; the reward for holding 0..3 units is 0.1, 0.4, 0.7, 1. The program has no operators
and makes no decision: it is one elaboration phase, and its result is the posterior
distribution of A's offer. It was run in Sigma38 under SBCL 2.2.9 on 2026-11-12; the expected
values below are the posteriors Sigma38 printed (single-precision floats, 8 digits), compared
to within 10^-6.

Booleans are false = 0, true = 1; agents are a = 0, b = 1.
-/

namespace SigmaArch.UltimatumSoft

def v (x : String) : Term := .var x
def k (n : Nat) : Term := .const n

def reward : Tup → Val
  | [_, 0] => 1/10 | [_, 1] => 4/10 | [_, 2] => 7/10 | [_, 3] => 1
  | _ => 0

def prog : Prog :=
  { preds :=
      [ { name := "Offer", args := [⟨"agent", 2, .universal⟩, ⟨"quantity", 4, .unique⟩], world := .openWorld },
        { name := "Money", args := [⟨"agent", 2, .universal⟩, ⟨"quantity", 4, .unique⟩], world := .openWorld },
        { name := "OperatorA", args := [⟨"quantity", 4, .universal⟩], world := .openWorld },
        { name := "OperatorB", args := [⟨"offer", 4, .universal⟩, ⟨"acceptance", 2, .universal⟩],
          world := .openWorld },
        { name := "OperatorBE", args := [⟨"offer", 4, .universal⟩, ⟨"acceptance", 2, .unique⟩],
          world := .openWorld, exponential := true } ]
    conds :=
      [ { name := "transition-a",
          conds := [⟨"Offer", [k 0, v "offer"], false⟩],
          condacts := [⟨"OperatorA", [v "offer"], false⟩] },
        -- B's money if B accepts is the offer; if B rejects it is 0
        { name := "transition-b-b",
          conds := [⟨"Money", [k 1, v "moneyb"], false⟩],
          condacts := [⟨"OperatorB", [v "offer", v "choice"], false⟩],
          fnVars := ["choice", "offer", "moneyb"],
          fn := fun t => match t with
            | [1, o, m] => if o == m then 1 else 0
            | [0, _, 0] => 1
            | _ => 0,
          sumVars := ["moneyb"] },
        { name := "exponentiate",
          conds := [⟨"OperatorB", [v "offer", v "choice"], false⟩],
          actions := [⟨"OperatorBE", [v "offer", v "choice"], false⟩] },
        -- A's money if B accepts is 3 minus the offer; if B rejects it is 0
        { name := "transition-a-b",
          conds := [⟨"Money", [k 0, v "moneya"], false⟩,
                    ⟨"OperatorBE", [v "offer", v "choice"], false⟩],
          condacts := [⟨"Offer", [k 0, v "offer"], false⟩],
          fnVars := ["choice", "offer", "moneya"],
          fn := fun t => match t with
            | [1, o, m] => if o + m == 3 then 1 else 0
            | [0, _, 0] => 1
            | _ => 0,
          sumVars := ["moneya", "choice"] },
        { name := "reward",
          condacts := [⟨"Money", [v "a", v "n"], false⟩],
          fnVars := ["a", "n"], fn := reward } ] }

def A0 : Assump := { wm := fun _ => Fn.const 0 }
def ms : Msgs := (elaborate prog A0 20).getD []
#guard (elaborate prog A0 20).isSome

/-- The posterior of a predicate as patterns read it, tabulated. -/
def post (pn : String) : Tab := Tab.ofFn (prog.dom pn) (readFn prog A0 ms none pn)

def tol : Val := 1 / 1000000
def agree (pn : String) (rows : List (Tup × Val)) : Bool :=
  let t := post pn
  rows.all fun (x, e) => near (t.fn x) e tol

/- Sigma38: `WM for MONEY … Normalized Posterior`, the same for both agents. -/
#guard agree "Money" [([0, 0], 0.045454547), ([0, 1], 0.18181819), ([0, 2], 0.3181818), ([0, 3], 0.45454544),
                       ([1, 0], 0.045454547), ([1, 3], 0.45454544)]
/- `OPERATOR-B`: B's value of accepting (true) or rejecting (false) each offer. -/
#guard agree "OperatorB" [([0, 0], 0.045454547), ([1, 0], 0.045454547), ([3, 0], 0.045454547),
                           ([0, 1], 0.045454547), ([1, 1], 0.18181819), ([2, 1], 0.3181818), ([3, 1], 0.45454544)]
/- `OPERATOR-B-E`, "Normalized Posterior (e^10v)": B's choice made nearly deterministic. -/
#guard agree "OperatorBE" [([0, 0], 0.5), ([0, 1], 0.5),
                            ([1, 1], 0.99752736), ([2, 1], 0.9994472), ([3, 1], 0.99972034),
                            ([1, 0], 2.472623e-3), ([2, 0], 5.527792e-4), ([3, 0], 2.7961475e-4)]
/- `OFFER` for agent A, the result the regression test prints: offering 1 is best. Agent B's
offer has no input and is uniform. -/
#guard agree "Offer" [([0, 0], 0.31458223), ([0, 1], 0.3995288), ([0, 2], 0.22869222), ([0, 3], 0.05719677),
                       ([1, 0], 0.25), ([1, 3], 0.25)]
/- `OPERATOR-A` carries the same distribution. -/
#guard agree "OperatorA" [([0], 0.31458223), ([1], 0.3995288), ([2], 0.22869222), ([3], 0.05719677)]

end SigmaArch.UltimatumSoft
