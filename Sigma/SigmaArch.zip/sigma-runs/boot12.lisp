(require :asdf)
(pushnew #p"/home/claude/sigma/work/src12/" asdf:*central-registry*)
(setf *compile-verbose* nil *compile-print* nil)
(handler-bind ((warning #'muffle-warning)
               (sb-ext:defconstant-uneql (lambda (c) (declare (ignore c)) (invoke-restart 'continue))))
  (dolist (f '("packages" "sigma" "templates" "graph-compilation" "graph-runtime" "deciding" "learning"
               "appraisal" "printCLI" "debugging-tools" "ultimatum-softv4" "ultimatum-forwardv16"
               "shift-reduce-dependency" "tests" "regressionCLI"))
    (load (format nil "/home/claude/sigma/work/fasl12/~a.fasl" f))))

(load "/home/claude/sigma/work/patch.lisp")
(in-package :sigma)
