# Generates the Lean checks of SigmaArch/EightPuzzle.lean from Sigma38 trace files.
import re,sys
from fractions import Fraction
def parse(f):
    txt=open(f).read().split('<<< Decision ')[1:]
    out=[]
    for blk in txt:
        sel=re.search(r'op0=(\S+)',blk).group(1)
        b=re.search(r'BOARD WM After Changes: (.*)',blk).group(1)
        g=[[9]*3 for _ in range(3)]
        for x,y,t in re.findall(r'WM-X\(DIMENSION\)\[(\d) \d> WM-Y\(DIMENSION\)\[(\d) \d> WM-TILE\(TILE\)\[(\d)\]',b): g[int(y)][int(x)]=int(t)
        m2=re.search(r'SELECTED WM before updating via actions:[^\n]*\n+Change message: ([^\n]*)',blk); c=m2.group(1) if m2 else ''
        pr={}
        for v,lo,hi in re.findall(r'\(([\d.]+): WM-STATE\(STATE\)\[0\] WM-OPERATOR\(TILE\)\[(\d)(?:\]| (\d)>)',c):
            for t in range(int(lo), int(hi) if hi else int(lo)+1): pr[t]=Fraction(v)
        out.append(dict(sel=None if sel=='NIL' else int(sel), board=g, props=sorted(pr.items()),
                        succ='SUCCESS WM After Changes' in blk, halt='HALT WM After Changes' in blk))
    return out
def lv(fr): return str(fr.numerator) if fr.denominator==1 else f"{fr.numerator}/{fr.denominator}"
def lean(name, f, start):
    ds=parse(f); rng=[]
    for d in ds:
        r=0
        if d['props'] and d['sel'] is not None:
            m=max(v for _,v in d['props']); tied=[t for t,v in d['props'] if v==m]
            if d['sel'] in tied: r=tied.index(d['sel'])
        rng.append(r)
    L=[]
    L.append(f"/-! ### Start position {start} (`{f.split('/')[-1]}`, {len(ds)} decisions) -/")
    L.append(f"def {name} : List Snap := runFrom {start} {rng}")
    L.append(f"#guard {name}.length == {len(ds)}")
    L.append(f"#guard {name}.map (·.selected) == [" + ", ".join("none" if d['sel'] is None else f"some {d['sel']}" for d in ds) + "]")
    L.append(f"#guard {name}.map (·.board) ==\n  [" + ",\n   ".join(str(d['board']) for d in ds) + "]")
    L.append(f"#guard {name}.map (·.proposals) ==\n  [" + ",\n   ".join("[" + ", ".join(f"({t}, {lv(v)})" for t,v in d['props']) + "]" for d in ds) + "]")
    L.append(f"#guard {name}.map (·.success) == [" + ", ".join(str(d['succ']).lower() for d in ds) + "]")
    L.append(f"#guard {name}.map (·.halt) == [" + ", ".join(str(d['halt']).lower() for d in ds) + "]")
    return "\n".join(L)+"\n"
R='/home/claude/sigma/out/sigma-runs/'
print(lean('runB', R+'ex-ep8.txt', '[[1, 2, 3], [8, 4, 5], [7, 0, 6]]'))
print(lean('runA', R+'ex-ep8-a.txt', '[[1, 2, 3], [8, 0, 5], [7, 4, 6]]'))
print(lean('runC', R+'ex-ep8-c.txt', '[[1, 2, 3], [6, 7, 0], [5, 4, 8]]'))
