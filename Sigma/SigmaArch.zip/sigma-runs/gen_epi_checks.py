# Generates the expected values of SigmaArch/Episodic.lean from the Sigma38 (max-time 12) trace.
import re,sys
syms=['WALKER','TABLE','DOG']; NT=12
def idx(dimname, spec, closed):
    # returns list of indices
    if spec=='*': return list(range(NT if dimname in('TIME','VALUE_T') else 3))
    parts=spec.split()
    if parts[0] in syms:
        a=syms.index(parts[0]); b=syms.index(parts[-1]); return list(range(a,b+1))
    a=int(parts[0])
    if len(parts)==1: return [a]
    return list(range(a,int(parts[1])))
def parse(line, dims):  # dims: list of ('TIME'|'VALUE', size)
    import itertools
    arr={}
    for m in re.finditer(r'\(([\d.e-]+): ((?:WM-\w+\(\w+\)\[[^\]>]*[\]>] ?)+)\)',line):
        ds=re.findall(r'WM-(\w+)\((\w+)\)\[([^\]>]*)([\]>])',m.group(2))
        if any(d[0]=='STATE' and d[2].strip().startswith('1') for d in ds): continue
        ds=[d for d in ds if d[0]!='STATE']
        ranges=[]
        for (nm,ty,spec,cl),(want,size) in zip(ds,dims):
            spec=spec.strip()
            if spec=='*': ranges.append(range(size))
            else:
                p=spec.split()
                if p[0] in syms: ranges.append(range(syms.index(p[0]),syms.index(p[-1])+1))
                elif len(p)==1: ranges.append([int(p[0])])
                else: ranges.append(range(int(p[0]),int(p[1])))
        for t in itertools.product(*ranges): arr[t]=m.group(1)
    return arr
txt=open('/home/claude/sigma/out/sigma-runs/ex-epi2.txt').read()
cues=[];fns=[];tposts=[];cposts=[]
for blk in txt.split('<<< Decision ')[1:]:
    L={l.split(':')[0]:l for l in blk.split('\n') if l.startswith('POST')}
    c=parse(L['POST concept*next'],[('VALUE',3)]); cues.append([k[0] for k,v in c.items() if float(v)>0.5][0])
    f=parse(L['POST fn'],[('TIME',NT),('VALUE',3)]); fns.append([f[(t,v)] for t in range(NT) for v in range(3)])
    tp=parse(L['POST time*episodic'],[('TIME',NT)]); tposts.append([tp[(t,)] for t in range(NT)])
    cp=parse(L['POST concept*episodic'],[('VALUE',3)]); cposts.append([cp[(v,)] for v in range(3)])
def lst(rows): return "[" + ",\n   ".join("["+", ".join(r)+"]" for r in rows) + "]"
out=f"def perceived : List Nat := {cues}\n\n"
out+="/-- Sigma38's episodic function after each decision: 12 times by 3 values. -/\ndef expFn : List (List Val) :=\n  "+lst(fns)+"\n\n"
out+="/-- Sigma38's posterior over time (which past time matches the cue) in each decision. -/\ndef expTime : List (List Val) :=\n  "+lst(tposts)+"\n\n"
out+="/-- Sigma38's retrieved value distribution in each decision. -/\ndef expRetrieved : List (List Val) :=\n  "+lst(cposts)+"\n"
open('/tmp/epidata.lean','w').write(out)
print(cues, tposts[3], cposts[3])
