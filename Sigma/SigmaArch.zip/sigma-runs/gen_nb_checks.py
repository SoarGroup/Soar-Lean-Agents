# Generates the checks of SigmaArch/LearnNB.lean from the Sigma38 trace of naive-Bayes learning.
import re
from fractions import Fraction
txt=open('/home/claude/sigma/out/sigma-runs/ex-nb.txt').read().split('<<< Decision ')[1:]
vals={'COLOR':['YELLOW','PURPLE'],'SIZE':['LARGE','SMALL'],'ACT':['STRETCH','DIP'],'AGE':['ADULT','CHILD'],'INFLATED':['T','F']}
atts=['COLOR','SIZE','ACT','AGE']
insts=[];exp=[]
for blk in txt:
    m=re.search(r'\*\*\* Instance: (.*)',blk)
    d=dict(x.split(':') for x in m.group(1).split())
    insts.append([vals[a].index(d[a]) for a in atts]+[vals['INFLATED'].index(d['INFLATED'])])
    row={}
    for line in blk.split('\n'):
        mm=re.match(r'(INFLATED(?:-(\w+))?): (.*)',line)
        if not mm: continue
        att=mm.group(2)
        if att is None:
            f=[None,None]
            for v,c in re.findall(r'\(([\d.e-]+): WM-INFLATED\(INFLATED\)\[(\w+|\*>)\]?\)',mm.group(3)):
                for i in ([0,1] if c=='*>' else [vals['INFLATED'].index(c)]): f[i]=v
            row['Inflated']=f
        else:
            f=[[None,None],[None,None]]
            for v,c,a in re.findall(r'\(([\d.e-]+): WM-INFLATED\(INFLATED\)\[(\w+\]|\*>) WM-\w+\(\w+\)\[(\w+\]|\*>)\)',mm.group(3)):
                cs=[0,1] if c=='*>' else [vals['INFLATED'].index(c[:-1])]
                as_=[0,1] if a=='*>' else [vals[att].index(a[:-1])]
                for i in cs:
                    for j in as_: f[i][j]=v
            row['Inflated'+att.capitalize()]=[f[0][0],f[0][1],f[1][0],f[1][1]]
    exp.append(row)
names=['Inflated']+['Inflated'+a.capitalize() for a in atts]
out=[]
out.append("def instances : List (List Nat) :=\n  ["+",\n   ".join(str(i) for i in insts)+"]\n")
out.append("/-- Sigma38's functions after each decision, in the order "+", ".join(names)+". -/")
out.append("def expected : List (List (List Val)) :=\n  ["+",\n   ".join("["+", ".join("["+", ".join(x for x in r[n])+"]" for n in names)+"]" for r in exp)+"]\n")
open('/tmp/nbdata.lean','w').write("\n".join(out))
print(len(insts), exp[0], exp[3])
