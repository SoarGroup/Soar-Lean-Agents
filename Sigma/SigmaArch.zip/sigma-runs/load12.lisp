;; Loader for Sigma38 under SBCL, following the CLISP component list in sigma.asd.
(require :asdf)
;; Sources are compiled to /home/claude/sigma/work/fasl; the release directory is not written.
(setf *compile-verbose* nil *compile-print* nil)
(pushnew #p"/home/claude/sigma/work/src12/" asdf:*central-registry*)
(defparameter *src* #p"/home/claude/sigma/work/src12/")
(defparameter *fasl* #p"/home/claude/sigma/work/fasl12/")
(defparameter *files* '("packages" "sigma" "templates" "graph-compilation" "graph-runtime" "deciding" "learning"
  "appraisal" "printCLI" "debugging-tools" "ultimatum-softv4" "ultimatum-forwardv16"
  "shift-reduce-dependency" "tests" "regressionCLI"))
(dolist (f *files*)
  (let* ((src (merge-pathnames (concatenate 'string f ".lisp") *src*))
         (out (merge-pathnames (concatenate 'string f ".fasl") *fasl*)))
    (format t "~&;;; ~a~%" f)
    (handler-bind ((warning #'muffle-warning)
                 (sb-ext:defconstant-uneql (lambda (c) (declare (ignore c)) (invoke-restart 'continue))))
      (multiple-value-bind (fasl warn fail) (compile-file src :output-file out)
        (format t ";;; compiled ~a warnings=~a failure=~a~%" f warn fail)
        (when fasl (load fasl))))))
