#!/bin/sh
cd /home/claude/sigma/work
sbcl --noinform --non-interactive --load boot12.lisp --eval '(in-package :sigma)' --eval "(load \"/home/claude/sigma/work/ex/$2\")" --eval "$3" > runs/$1.txt 2>&1
