import soar_sml as S, sys, re, os
d=os.getcwd()
k=S.Kernel.CreateKernelInNewThread(0)
for v in sys.argv[2:]:
    a=k.CreateAgent(v); out=[]
    a.RegisterForPrintEvent(S.smlEVENT_PRINT, lambda m,u,ag,msg: out.append(msg), None)
    a.ExecuteCommandLine('pushd ../../../../../Soar/soar-library'); r=a.ExecuteCommandLine('source soar-library.soar'); a.ExecuteCommandLine('popd')
    r2=a.ExecuteCommandLine('source '+v+'.soar')
    if 'rror' in r+r2: print('LOAD', (r+r2)[-800:])
    a.ExecuteCommandLine('trace 1')
    a.ExecuteCommandLine('run %s'%sys.argv[1])
    txt=''.join(out)
    cols=re.findall(r'TRACE set-color (\w+)',txt)
    ops=re.findall(r'O: O\d+ \(([\w-]+)\)',txt)
    st=a.ExecuteCommandLine('stats'); dec=re.search(r'(\d+) decisions',st).group(1)
    ends=[l.strip() for l in txt.splitlines() if re.search(r'success|achieved|completed|Implementation|ERROR|halt|interrupt|failed',l,re.I) and 'Success (' not in l]
    print(v, 'decisions',dec,'colors',' '.join(cols))
    print('   ops:',' '.join(o for o in ops if o not in ('wait',)))
    print('   ends:',ends[:6])
    print('   wm:',a.ExecuteCommandLine('print s1 -d 1').replace('\n',' ')[:400])
    k.DestroyAgent(a)
k.Shutdown()
