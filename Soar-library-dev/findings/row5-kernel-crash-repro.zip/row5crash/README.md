# Row 5 reproducer: kernel crash with look-ahead and means-ends subgoaling (24 Nov 2026)

The gen3 held-out blocks-world agent (means-ends operator subgoaling; look-ahead with iterative-step tie-impasse),
without its search-control.soar. Edit the pushd line of blocks-world-no-search-control.soar to a soar-library folder, then:

    python3 step.py blocks-world-no-search-control.soar 3

Library v2.45: segmentation fault in the kernel (elaborate_gds) at decision 34 on seeds 1-3; v2.46: seed 3.
Cause: selection-world*apply*world*local-version kept ^versioned-operator <op> on the look-ahead world after the
operator's means-ends substate was removed. Fixed in the v2.47 candidate (^version-tag on the operator, ^versioned-tag
on the world). The trace goes to trace.txt.
