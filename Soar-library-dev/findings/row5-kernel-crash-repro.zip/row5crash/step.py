import soar_sml as S, sys
f=sys.argv[1]; seed=int(sys.argv[2]); extra=sys.argv[3:]
k=S.Kernel.CreateKernelInCurrentThread(); a=k.CreateAgent('a')
log=open('trace.txt','w')
a.RegisterForPrintEvent(S.smlEVENT_PRINT, lambda m,u,ag,msg: (log.write(msg), log.flush()), None)
print(a.ExecuteCommandLine('source '+f)[-200:])
for c in extra: print(c, a.ExecuteCommandLine(c)[:200])
a.ExecuteCommandLine('srand %d'%seed); a.ExecuteCommandLine('watch 1')
for i in range(400):
    log.write('\n#DEC %d\n'%i); log.flush()
    a.RunSelf(1)
    for j in range(a.GetNumberCommands()):
        c=a.GetCommand(j)
        if c.GetParameterValue('status') is None: c.AddStatusComplete()
    a.Commit()
print('finished without crash')
