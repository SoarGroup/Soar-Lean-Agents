# Reproduction for to-do row 5 (look-ahead copy shares the tied operator's preconditions)

Blocks world (A on B, B and C on the table; goal A on B on C on the table) by operator subgoaling, generated
from Family/Families (blocks-world-operator-subgoaling) with its indifferent rule left out, so ties among moves go
to look-ahead. Place it as Tasks/Families/blocks-world/world-lean/precond-lookahead (the loader's relative path),
or load the library first and source the other files. `probe.soar` writes a line whenever a selected look-ahead
copy shares ^desireds with its original and that structure has an ^achieved.

- Library v2.46: 6 probe lines in 29 decisions; at decision 27 the look-ahead moves B onto C with A still on B
  (B's precondition "clear" was marked achieved on the real operator by an earlier look-ahead) and reports success.
- Library v2.47 candidate (copy gets its own ^desireds): no probe lines; every look-ahead move is legal; solves in
  572 decisions (seed 1). The extra search: a success found for move B onto C at depth 2 did not end the iterative
  deepening (to-do row 50).
