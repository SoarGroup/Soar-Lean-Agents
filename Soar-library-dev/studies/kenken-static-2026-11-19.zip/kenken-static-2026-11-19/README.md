# KenKen ^static layout study (19 Nov 2026)

- `programs/fam__kenken-*-static`: the 16 KenKen world programs of test set v1.37 rewritten by `staticize.py`. Put them beside the originals in `testset/programs` to run them.
- `staticize.py`: the rewrite tool (also in Soar-library-dev/tools/staticize).
- `compare.py`: runs every puzzle in both layouts, seeds 1-3, with the test set's runner (`runs/*.json` are the 96 results).
- `grid.py`: checks that every run succeeds and that the final grids agree and are Latin squares.
- `KenKen-static-layout-results.md`: the results.

Paths in compare.py and grid.py are those of the cloud workspace; change TS and LIB to run them elsewhere.
