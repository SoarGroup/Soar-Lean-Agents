import json,subprocess,os,sys,glob
TS='/home/claude/ts/testset'; LIB='/home/claude/lib243/soar-library'; OUT='/home/claude/kk/runs'
os.makedirs(OUT,exist_ok=True)
seeds=[int(x) for x in sys.argv[1].split(',')]
for seed in seeds:
  for d in sorted(glob.glob(TS+'/programs/fam__kenken-?-?')):
    v=os.path.basename(d).split('kenken-')[1]
    for layout in ('flat','static'):
        f=f'{OUT}/{v}-{layout}-{seed}.json'
        if os.path.exists(f): continue
        wd=d if layout=='flat' else d+'-static'
        spec=dict(id=f'{v}-{layout}-s{seed}',workdir=wd,commands=[f'pushd "{LIB}"','source soar-library.soar','popd',f'source kenken-{v}__test.soar'],seed=seed,cap=3000,mode='env-complete',watch=1)
        p=f'/tmp/spec-{v}-{layout}-{seed}.json'; json.dump(spec,open(p,'w'))
        out=subprocess.run([sys.executable,TS+'/tools/runner.py',p],capture_output=True,text=True,timeout=900).stdout
        r=json.loads(out.split('@@RESULT@@')[1]); r.update(variant=v,layout=layout)
        json.dump(r,open(f,'w'))
