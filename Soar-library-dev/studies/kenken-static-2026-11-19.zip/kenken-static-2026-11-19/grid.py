import soar_sml as S, sys, os, re
LIB='/home/claude/lib243/soar-library'; TS='/home/claude/ts/testset/programs'
def wmes(a,pat):
    attr=re.search(r'\^(\S+)',pat).group(1)
    return [t for t in re.findall(r'\(\d+: (\S+) \^(\S+) (\S+)\)', a.ExecuteCommandLine(f'print -i {pat}')) if t[1]==attr]
for v in sys.argv[1].split(','):
  grids={}; okall=True
  for lay in ('flat','static'):
    for seed in (1,2,3):
        os.chdir(f'{TS}/fam__kenken-{v}'+('-static' if lay=='static' else ''))
        k=S.Kernel.CreateKernelInNewThread(0);a=k.CreateAgent('t')
        out=[];a.RegisterForPrintEvent(S.smlEVENT_PRINT,lambda m,u,ag,msg:out.append(msg),None)
        for c in [f'pushd {LIB}','source soar-library.soar','popd',f'source kenken-{v}__test.soar']: a.ExecuteCommandLine(c)
        a.ExecuteCommandLine('watch 0'); a.ExecuteCommandLine(f'srand {seed}'); a.ExecuteCommandLine('run 5000')
        okall &= 'achieved - success' in ''.join(out)
        world=wmes(a,'(s1 ^world *)')[0][2]; objs=wmes(a,f'({world} ^objects *)')[0][2]
        ob={x[2] for x in wmes(a,f'({objs} ^object *)')}
        mark={i:val for i,_,val in wmes(a,'(* ^mark *)') if i in ob}
        st={i:val for i,_,val in wmes(a,'(* ^static *)') if i in ob}
        coord={i:val for i,_,val in wmes(a,'(* ^coord *)')}
        g={}
        for o,m in mark.items():
            c=coord.get(st.get(o,o)) or coord.get(o)
            g[c]=m
        grids[(lay,seed)]=tuple(sorted(g.items()))
        k.Shutdown()
  n=int(v[0]); G=dict(grids[('flat',1)])
  rows=[[G[f'{r}{c}'] for c in range(1,n+1)] for r in range(1,n+1)] if len(G)==n*n else []
  latin=bool(rows) and all(sorted(map(int,r))==list(range(1,n+1)) for r in rows) and all(sorted(map(int,c))==list(range(1,n+1)) for c in zip(*rows))
  print(v,'success in all 6 runs:',okall,'| identical final grid in all 6:',len(set(grids.values()))==1,'| complete Latin square:',latin,flush=True)
