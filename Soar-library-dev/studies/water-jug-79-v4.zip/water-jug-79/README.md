# Water jug, 7- and 9-gallon jugs, 3 gallons in the 7-gallon jug (14 Nov 2026)

Task: jugs of 7 and 9, both empty; fill, empty, pour; goal: the 7-jug holds 3. Shortest solution: 8 operators (BFS; Lean proves it for
the Lean description: `shortest`, `none_shorter`, `constraints_hold`, `conventions` all pass in `lake build`).

All runs: Soar 9.6.6 (kernel 9.6.50), seeds 1 to 5. Success = the top state reaches 7-jug = 3 and the agent halts. Every run's path is
replayed independently (monitor rule on the top state; each step checked as a legal fill, empty or pour from (0,0)).

## Versions

| | What | Library |
|---|---|---|
| A | Hand-written originals, numbers only changed (3→7, 5→9, goal 1→3). A1 = water-jug-look-ahead V3 (path duplicate test); A3 = water-jug-look-ahead-failure-states V1 (duplicate test + full-jugs and empty-jugs states as failures) | Their own bundled default selection library; `chunk always` as written |
| B | Generated to the world conventions (gen_waterjug79.py: agent-world, selection-world, iterative deepening, depth limit 12) | soar-library v2.25 |
| D | The Lean description of C compiled to the world conventions (world_backend.py) | soar-library v2.25 |
| C | English description + common-sense assumptions → Lean → Soar (agentgen). C1 = water-jug-look-ahead, C3 = water-jug-look-ahead-failure-states. Duplicate test = assumption A6 | Default selection library; `chunk always` as generated |

"No duplicate test" variants (A2, A4, B2, C2, C4, D2, D4) are ablations: the one duplicate rule removed (B: flag `^avoid-repeated-states` off).

## Results (5 seeds each; v4, all rerun on 14 Nov 2026; B and D on library v2.25)

Caps: 10,000 decisions for A and C, 30,000 for B and D. Medians are over all 5 runs, so a variant that never solves shows its cap or halt point. Kernel time is Soar's "Kernel CPU Time" and depends on the machine. A and C use their own default selection library, so the library version does not affect them.

| Variant | Learning | Solved | Operators (optimum 8) | Median decisions | Median chunks | Median kernel s | Median firings |
|---|---|---|---|---|---|---|---|
| A1 original look-ahead, duplicate test | chunk always | 3 | 10, 10, 8 | 374 | 55 | 0.10 | 7,206 |
| A2 original, no duplicate test | chunk always | 0 | | 200 (halt, goal stack 100) | 0 | 0.02 | 7,615 |
| A3 original failure-states | chunk always | 5 | 24, 10, 10, 10, 8 | 214 | 111 | 0.04 | 3,977 |
| A4 original failure-states, no duplicate test | chunk always | 0 | | 262 (halt) | 10 | 0.04 | 9,062 |
| B1 world conventions, duplicate detection | off | 5 | 8, 8, 8, 8, 8 | 17,878 | 0 | 6.17 | 582,147 |
| B2 world conventions, no duplicate detection | off | 0 | | 30,000 (cap) | 0 | 5.98 | 699,852 |
| B3 world conventions, failure states + duplicate detection | off | 5 | 8, 8, 8, 8, 8 | 801 | 0 | 0.14 | 20,413 |
| B1 with chunking | chunk always | 5 | 24, 8, 8, 10, 8 | 3,657 | 103 | 1.11 | 111,001 |
| B2 with chunking | chunk always | 0 of 2 tried | | process killed after about 15 s | | | |
| B3 with chunking | chunk always | 5 | 8, 8, 8, 8, 8 | 460 | 62 | 0.10 | 12,664 |
| C1 English+Lean look-ahead, duplicate test | chunk always | 1 | 16 | 10,000 (cap) | 181 | 0.47 | 99,905 |
| C2 English+Lean, no duplicate test | chunk always | 0 | | 200 (halt) | 0 | 0.03 | 7,266 |
| C3 English+Lean failure-states | chunk always | 5 | 8, 10, 10, 10, 28 | 290 | 145 | 0.04 | 4,947 |
| C4 English+Lean failure-states, no duplicate test | chunk always | 0 | | 262 (halt) | 10 | 0.03 | 8,502 |
| D1 English+Lean on world conventions, duplicate detection | off | 5 | 8, 8, 8, 8, 8 | 17,280 | 0 | 6.08 | 586,447 |
| D2 English+Lean on world conventions, no duplicate detection | off | 0 | | 30,000 (cap) | 0 | 5.82 | 700,113 |
| D3 English+Lean on world conventions, failure states + duplicate detection | off | 5 | 8, 8, 8, 8, 8 | 834 | 0 | 0.16 | 21,279 |
| D4 English+Lean on world conventions, failure states, no duplicate detection | off | 5 | 8, 8, 8, 8, 8 | 12,125 | 0 | 2.58 | 313,570 |
| D1 with chunking | chunk always | 5 | 8, 8, 10, 10, 8 | 3,078 | 97 | 1.07 | 86,565 |
| D2 with chunking | chunk always | 0 of 2 tried | | process killed after about 15 s | | | |
| D3 with chunking | chunk always | 5 | 8, 8, 8, 8, 8 | 496 | 66 | 0.12 | 13,742 |
| D4 with chunking | chunk always | 5 | 8, 8, 8, 8, 8 | 1,443 | 133 | 0.37 | 32,213 |
| B1 on library v2.24, for comparison | off | 5 | 24, 24, 10, 8, 10 | 9,341 | 0 | 3.42 | 314,369 |
| D1 on library v2.24, for comparison | off | 5 | 26, 8, 10, 10, 8 | 13,486 | 0 | 5.96 | 458,488 |

Library v2.25 corrects `selection-world*apply*initialize-failure-evaluation2` (FINDING-early-failure-propagation.md). B1 and D1 are now optimal on every seed and cost more decisions. B2, B3, D2, D3, D4 are unchanged from v2.24.

## Chunking on the world-convention agents (new in v4)

The chunking rows use the same rule files with `chunk always` added (`*-chunk-rules.soar`). This is the first run of these libraries with learning on.
- With failure-state knowledge (B3, D3, D4) chunking keeps every run optimal and cuts decisions: 801 to 460, 834 to 496, 12,125 to 1,443.
- With duplicate detection only (B1, D1) chunking cuts decisions about five times but 4 of 10 runs are no longer optimal (24 or 10 operators). Not diagnosed.
- Without repeated-state rejection and without failure states (B2, D2) the process was killed by the system after about 15 s on both seeds tried (exit code 137). The cause was not confirmed.
- B3 and D3 with chunking (460 and 496 decisions, always 8 operators) are within about a factor of two of the classic A3 and C3 (214 and 290), which are not always optimal.

## D: the English-derived version on the world conventions (new in v3)

Chain: English description plus accepted assumptions A1 to A8, then the Lean description (`WaterJug.lean`, conventions and constraint checks pass), then `agentgen water-jug-desc` (new export of the description itself: objects, derivations, operators with guards and effects, goal, avoided states, in `wj-desc.json`), then `world_backend.py`, which writes world-convention rules with `wg.py`. D1/D2 come from the description `water-jug-look-ahead`, D3/D4 from `water-jug-look-ahead-failure-states`.

- The back-end is new Python and is not verified in Lean. It supports what this family needs (see its header).
- Repeated-state rejection follows the generated B agents (result label on the operator, `history ^visited`), not assumption A6 literally: A6 counts the states on the look-ahead path; `visited` also keeps every state the agent has really been in.
- The avoided states of the description (both full, both empty) are rejected by result label and do not depend on the repeated-state flag, so D4 keeps them with the flag off. B has no such variant.
- D and B differ in rule text (D binds both jugs by handle in every rule) but behave alike: D3 and B3 are both optimal on every seed at about 800 decisions.

## Why B did worse than A

1. A bug in the generated agent (fixed in v2). It derived `^free` on each jug and did not list it under `^dont-copy-object-attribute`, so every look-ahead world held a stale copy beside the recomputed value: duplicate and illegal proposals, 26 evaluations at depth 3 against 14 after the fix. B1 went from 1 of 5 to 5 of 5.
   Correction to v2 of this package: its rule files had the fix, but its generator (`gen_waterjug79.py`, `wg.py`) did not emit it. In v3 the generator takes `derived=[...]`, emits the list, and `check_derived.py` stops generation when a derived object attribute is not listed. The same omission was in the test set's generated water jug (3/5) and arithmetic tasks; fixed in test set v1.21.
2. A library rule that marked an operator as failed too early (FINDING-early-failure-propagation.md). It explained every non-optimal B1 and D1 run without learning. Corrected in library v2.25: both agents return 8 operators on all 5 seeds, at a higher median cost (17,878 and 17,280 decisions). The correction costs other tasks: artists-3 no longer finishes within its test cap.
3. No learning. A's low decision counts come with 55 to 111 chunks; B and D rebuild the search at every step. With chunking on, B3 falls from 801 to 460 decisions.
4. What remains with failure-state knowledge (B3 against A3): about 4 times the decisions (801 against 214) and kernel time (0.15 s against 0.04 s), and about 25 production firings per decision against about 17. Which part is the missing learning and which is library overhead was not separated.

Still untested: B and D with `^optimize true ^cost-metric unit`.

## Readings and limits

- Duplicate detection decides success in every family. Without it the default-library look-ahead recurses until Soar halts at goal stack depth 100; the world library (depth limit 12) searches until the cap.
- With duplicate detection alone (path test) the originals solve 3 of 5 (A1); the extra full/empty failure states (A3, C3) make them solve 5 of 5. The Lean-derived C3 behaves like the original A3 (both 5 of 5, one long outlier each: 24 and 28 operators); C1 behaves worse than A1, and its wandering depends on learning: with `chunk never`, C1 seeds 2 and 3 stall after 6 and 13 operators instead.
- B and D without failure-state knowledge are slow at this size (median 9,000 to 13,000 decisions): nested look-ahead to depth 8 before the first move, with no learning.
- D4 solves where A4 and C4 halt: the world library's depth limit keeps the search finite without a duplicate test once the two avoided states are known.
- Version A is the original code run on the bundled default selection library, not on the new library; it is the baseline.
- Version B's "adapted to the new conventions" is the generated world-convention agent (gen_waterjug.py, itself derived from the STEP6 look-ahead variant), not a hand rewrite.
- The Lean build used the local cmcsoar copy of 12 Nov (only `Soar.Syntax` is imported). The 14 Nov "speed1" version could not be reached (the CMC folder is not connected to this session; access was denied). The blind round-trip theorem was not re-run for 7/9 and its module was left out of the build. No soar-lean comparison was run.
- Decision counts for the originals include chunk-learning runs as written; seeds set after loading.
