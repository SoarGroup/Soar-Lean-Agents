import subprocess, json, sys, concurrent.futures as cf, os
SB = '/home/claude/soar966/x/SoarSuite_9.6.6-bigbugfixrelease-Multiplatform/bin/linux_x86-64'
ENV = dict(os.environ, SOAR_BIN=SB)
O = '/tmp/wj79/orig'; G = '/tmp/wj79/gen79'; GN = '/tmp/wj79/gen79nd'
fsd = 'Water-jugs/water-jug-look-ahead-failure-states'; lad = 'Water-jugs/water-jug-look-ahead'
V = {  # name: (kind, dir, load)
 'A1 original look-ahead (path duplicate test)': ('n', f'{O}/A-v3/{lad}', 'water-jug-look-ahead.soar'),
 'A2 original look-ahead, no duplicate test': ('n', f'{O}/A-v3-nodup/{lad}', 'water-jug-look-ahead.soar'),
 'A3 original failure-states (duplicate + full/empty states)': ('n', f'{O}/A-fs/{fsd}', 'water-jug-look-ahead-failure-states.soar'),
 'A4 original failure-states, no duplicate test': ('n', f'{O}/A-fs-nodup/{fsd}', 'water-jug-look-ahead-failure-states.soar'),
 'B1 world conventions, v2.24, duplicate detection': ('b', 'water-jug79-dup-rules.soar', ''),
 'B3 world conventions, failure-states pruning, v2.24': ('b', 'water-jug79-dup-fs-rules.soar', ''),
 'B2 world conventions, v2.24, no duplicate detection': ('b', 'water-jug79-nodup-rules.soar', ''),
 'D1 English+Lean on world conventions, v2.24, duplicate detection': ('b', 'water-jug-look-ahead-world-dup-rules.soar', ''),
 'D2 English+Lean on world conventions, v2.24, no duplicate detection': ('b', 'water-jug-look-ahead-world-nodup-rules.soar', ''),
 'D3 English+Lean on world conventions, v2.24, failure states + duplicate detection': ('b', 'water-jug-look-ahead-failure-states-world-dup-rules.soar', ''),
 'D4 English+Lean on world conventions, v2.24, failure states, no duplicate detection': ('b', 'water-jug-look-ahead-failure-states-world-nodup-rules.soar', ''),
 'C1 English+Lean look-ahead (A6 duplicate test)': ('n', f'{G}/water-jug-look-ahead', 'water-jug-look-ahead.soar'),
 'C2 English+Lean look-ahead, no duplicate test': ('n', f'{GN}/water-jug-look-ahead', 'water-jug-look-ahead.soar'),
 'C3 English+Lean failure-states (duplicate + full/empty)': ('n', f'{G}/water-jug-look-ahead-failure-states', 'water-jug-look-ahead-failure-states.soar'),
 'C4 English+Lean failure-states, no duplicate test': ('n', f'{GN}/water-jug-look-ahead-failure-states', 'water-jug-look-ahead-failure-states.soar'),
}
V.update({
 'E1 B1 with chunking': ('b', 'water-jug79-dup-chunk-rules.soar', ''),
 'E2 B2 with chunking': ('b', 'water-jug79-nodup-chunk-rules.soar', ''),
 'E3 B3 with chunking': ('b', 'water-jug79-dup-fs-chunk-rules.soar', ''),
 'F1 D1 with chunking': ('b', 'water-jug-look-ahead-world-dup-chunk-rules.soar', ''),
 'F2 D2 with chunking': ('b', 'water-jug-look-ahead-world-nodup-chunk-rules.soar', ''),
 'F3 D3 with chunking': ('b', 'water-jug-look-ahead-failure-states-world-dup-chunk-rules.soar', ''),
 'F4 D4 with chunking': ('b', 'water-jug-look-ahead-failure-states-world-nodup-chunk-rules.soar', ''),
})
CAP = int(os.environ.get('CAP', 10000)); TO = int(os.environ.get('TO', 150)); SEEDS = [int(x) for x in os.environ.get('SEEDS', '1,2,3,4,5').split(',')]
LIB = os.environ.get('LIB', '/home/claude/soar-library-dev')
def job(a):
    name, seed = a; k, x, y = V[name]
    cmd = (['python3', 'wj79_run.py', x, y, str(seed), str(CAP)] if k == 'n' else ['python3', 'wj79_b.py', LIB, x, str(seed), str(CAP)])
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=TO, env=ENV, cwd='/home/claude/worldgen')
        l = [z for z in r.stdout.splitlines() if z.startswith('{')]
        return dict(name=name, seed=seed, **(json.loads(l[-1]) if l else dict(error=r.stderr[-200:])))
    except subprocess.TimeoutExpired: return dict(name=name, seed=seed, timeout=True)
ONLY = os.environ.get('ONLY','').split('|') if os.environ.get('ONLY') else None
jobs = [(n, s) for n in V for s in SEEDS if not ONLY or any(n.startswith(o) for o in ONLY)]
out = []
with cf.ThreadPoolExecutor(int(os.environ.get('W', 3))) as ex:
    for r in ex.map(job, jobs):
        out.append(r); print(r['name'][:12], r['seed'], {k: v for k, v in r.items() if k in ('decisions', 'halted', 'steps', 'goal', 'legal', 'timeout', 'error')}, flush=True)
json.dump(out, open(os.environ.get('OUT', '/tmp/wj79/results.json'), 'w'))
