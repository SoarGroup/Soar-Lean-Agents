"""World-convention 7/9 water jug on a library. usage: wj79_b.py LIB RULES SEED CAP"""
import sys, json, signal
sys.path.insert(0, '/home/claude/worldgen')
import play
lib, rules, seed, cap = sys.argv[1], sys.argv[2], int(sys.argv[3]), int(sys.argv[4])
def step(st, name, a1, a2):
    c = dict(st); V = {'jug7': 7, 'jug9': 9}
    if name == 'fill': assert c[a1] < V[a1]; c[a1] = V[a1]
    elif name == 'empty': assert c[a1] > 0; c[a1] = 0
    elif name == 'pour':
        assert a1 != a2 and c[a1] > 0 and c[a2] < V[a2]
        m = min(c[a1], V[a2] - c[a2]); c[a1] -= m; c[a2] += m
    else: raise ValueError(name)
    return c
r = play.play(rules, seed, cap, lib=lib)
st = {'jug7': 0, 'jug9': 0}; path = [(0, 0)]; legal = True
try:
    for n, a1, a2 in r['actions']:
        st = step(st, n, a1, a2); path.append((st['jug7'], st['jug9']))
except AssertionError: legal = False
print(json.dumps(dict(stats=r['stats'], decisions=r['decisions'], halted=r['success'] or r['decisions'] < cap, steps=len(r['actions']), goal=st['jug7'] == 3, legal=legal, path=path[:40], success_flag=r['success'])))
