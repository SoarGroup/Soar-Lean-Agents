"""Run a (non-world) water-jug agent for 7/9 jugs, goal 3 in the 7-jug, and check the path of the top state.
usage: wj79_run.py DIR LOADFILE SEED CAP [chunk-off]  -> prints JSON"""
import sys, os, json, re, collections
sys.path.insert(0,'/home/claude/worldgen')
B = os.environ.get('SOAR_BIN', '/home/claude/soar966/x/SoarSuite_9.6.6-bigbugfixrelease-Multiplatform/bin/linux_x86-64')
sys.path[:0] = [B, '/home/claude/soar-test/shim']
import soar_sml as S
MON = '''sp {zz*monitor*top
   (state <s> ^superstate nil ^jug <a> <b>)
   (<a> ^volume 7 ^contents <ca>)
   (<b> ^volume 9 ^contents <cb>)
-->
   (write (crlf) |@@S | <ca> | | <cb>)}
'''
def legal(p, q):
    a, b = p; moves = {(7, b), (a, 9), (0, b), (a, 0)}
    t = min(a, 9 - b); moves.add((a - t, b + t)); t = min(b, 7 - a); moves.add((a + t, b - t))
    return q in moves and q != p
def run(d, load, seed, cap, chunk=True):
    k = S.Kernel.CreateKernelInNewThread(); a = k.CreateAgent('a'); out = []
    a.RegisterForPrintEvent(S.smlEVENT_PRINT, lambda mid, ud, ag, msg: out.append(msg), None)
    os.chdir(d)
    errs = []
    for c in ['source ' + load]:
        r = a.ExecuteCommandLine(c)
    a.ExecuteCommandLine('watch 0')
    if not chunk: a.ExecuteCommandLine('chunk never')
    a.ExecuteCommandLine('sp {' + MON[4:].rstrip()[:-0 or None] if False else MON)
    a.ExecuteCommandLine(f'srand {seed}')
    r = a.RunSelf(cap)
    n = a.GetDecisionCycleCounter()
    halted = 'halted' in r or n < cap
    import wj79_stats; st = wj79_stats.parse(a.ExecuteCommandLine('stats'))
    txt = ''.join(out); k.Shutdown()
    states = [tuple(map(int, l.split()[1:3])) for l in txt.splitlines() if l.startswith('@@S ')]
    return dict(stats=st, decisions=n, halted=halted, states=states, text_tail=txt[-200:])
def judge(r):
    st = r['states']
    # collapse consecutive duplicates (re-fired monitor with no change)
    path = [st[0]] if st else []
    for s in st[1:]:
        if s != path[-1]: path.append(s)
    legal_ok = all(legal(path[i], path[i + 1]) for i in range(len(path) - 1))
    goal = bool(path) and path[-1][0] == 3
    return dict(stats=r.get('stats'), decisions=r['decisions'], halted=r['halted'], steps=len(path) - 1, goal=goal, legal=legal_ok, start0=(path[0] == (0, 0)) if path else None,
                reached_goal_at=next((i for i, s in enumerate(path) if s[0] == 3), None), path=path[:40])
if __name__ == '__main__':
    d, load, seed, cap = sys.argv[1], sys.argv[2], int(sys.argv[3]), int(sys.argv[4])
    r = run(d, load, seed, cap, 'chunk-off' not in sys.argv)
    print(json.dumps(judge(r)))
