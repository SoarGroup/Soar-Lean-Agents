import re
def parse(t):
    g=lambda p:(re.search(p,t) or [None,None])[1]
    return dict(chunks=int(g(r'\((?:\d+) default, (?:\d+) user, (\d+) chunks') or 0),
                kernel_s=float(g(r'Kernel CPU Time:\s+([\d.]+)') or 0),
                firings=int(g(r'(\d+) production firings') or 0))
