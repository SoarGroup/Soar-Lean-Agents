import sys, wg
LAYOUT = sys.argv[1] if len(sys.argv) > 1 else 'flat'
P1 = (56, 39, 1)   # top, bottom, operation (1 add)
P2 = (83, 47, 2)   # operation 2 subtract, with a borrow in the ones column
DESC = """## Arithmetic (trimmed), written to the world conventions (agent-world, selection-world).
## Trimmed from the STEP6 arithmetic family: two fixed two-column problems, 56 + 39 and 83 - 47, solved right to left
## by looking up digit facts. Random problem generation, learning and substates are dropped (JL, 13 Nov 2026).
## Operators keep their names and effects: process-column (one column, using add-fact / sub-fact; a borrow adds ten to the
## top digit via a derived ^top10 and passes a borrow of 1 on) and finish-problem (write the answer, count the problem).
## World: session (^current problem number, ^remaining), problems p1 p2 (^pid ^operation ^carry ^done), columns
## <problem>c1 <problem>c2 (^pid ^pos ^digit1 ^digit2 ^result ^done), and fact objects add-<d1>-<d2>, sub-<d1>-<d2>.
## Derived on a column: ^adj2 = digit2 + carry, ^top10 = digit1 + 10.
## Goal: one desired, session ^remaining 0. Selection (no look-ahead): exactly one operator is proposed at a time.
"""
t = wg.Task('arithmetic', DESC, layout=LAYOUT, static=['type', 'pid', 'operation', 'pos', 'digit1', 'digit2', 'd1', 'd2', 'sum', 'cout', 'diff'], strategy='selection', derived=['adj2', 'top10'])
t.objects.append(('session', {'type': 'session', 'current': 1, 'remaining': 2}, []))
for pid, (top, bot, op) in ((1, P1), (2, P2)):
    t.objects.append((f'p{pid}', {'type': 'problem', 'pid': pid, 'operation': op, 'carry': 0, 'done': 0}, []))
    for pos in (1, 2):
        dg = lambda n, p: (n // 10 if p == 2 else n % 10)
        t.objects.append((f'p{pid}c{pos}', {'type': 'column', 'pid': pid, 'pos': pos, 'digit1': dg(top, pos), 'digit2': dg(bot, pos), 'result': -1, 'done': 0}, []))
for d1 in range(10):
    for d2 in range(11):
        s = d1 + d2
        t.objects.append((f'add-{d1}-{d2}', {'type': 'add-fact', 'd1': d1, 'd2': d2, 'sum': s % 10, 'cout': s // 10}, []))
for d1 in range(20):
    for d2 in range(11):
        if d1 - d2 >= 0:
            t.objects.append((f'sub-{d1}-{d2}', {'type': 'sub-fact', 'd1': d1, 'd2': d2, 'diff': d1 - d2}, []))
t.desired.append(('session', {'remaining': 0}))
for a in ('current', 'remaining', 'carry', 'done', 'result'): t.check_mutable(a)
A = t.lhs_attr
t.add(f'''
## Derived on a column: digit2 plus the carry (borrow) in, and the top digit plus ten.
sp {{arithmetic*elaborate*world*column*adjusted
   (state <s> ^world <w>)
   (<w> ^objects.object <p> <c>)
   (<p> {A('type','problem')} {A('pid','<pid>')} ^carry <k>)
   (<c> {A('type','column')} {A('pid','<pid>')} {A('digit1','<d1>')} {A('digit2','<d2>')})
-->
   (<c> ^adj2 (+ <d2> <k>) ^top10 (+ <d1> 10))
}}
''')
t.add(t.achievement())
# situations: (name, operation, fact type, fact lhs, effect rhs)
cases = [
  ('add', 1, f'(<f> {A("type","add-fact")} {A("d1","<d1>")} {A("d2","<a2>")} {A("sum","<r>")} {A("cout","<co>")})', '^adj2 <a2> ^digit1 <d1>'),
  ('sub', 2, f'(<f> {A("type","sub-fact")} {A("d1","<d1>")} {A("d2","<a2>")} {A("diff","<r>")})', '^adj2 { <= <d1> <a2> } ^digit1 <d1>'),
  ('sub-borrow', 2, f'(<f> {A("type","sub-fact")} {A("d1","<t10>")} {A("d2","<a2>")} {A("diff","<r>")})', '^adj2 { > <d1> <a2> } ^digit1 <d1> ^top10 <t10>'),
]
def situation(op, ccond):
    return f'''   (<ses> {A('type','session')} ^current <pid>)
   (<p> {A('type','problem')} {A('pid','<pid>')} {A('operation',op)} ^carry <k>)
   (<c> {A('type','column')} {A('pid','<pid>')} ^done 0 {A('pos','<pos>')} ^result <r0> {ccond.replace('^adj2','^adj2').replace('^digit1 <d1>','^digit1 <d1>')})'''
for name, op, flhs, ccond in cases:
    # derived attrs ^adj2/^top10 are not static
    c_cond = ccond.replace('^digit1 <d1>', A('digit1', '<d1>'))
    co = '<co>' if name == 'add' else ('0' if name == 'sub' else '1')
    sit = situation(op, c_cond)
    nogap = f'''   -{{(<objs> ^object <c2>)
     (<c2> {A('type','column')} {A('pid','<pid>')} ^done 0 {A('pos','{ < <pos> }')})}}'''
    t.add(t.propose(f'process-column*process-column-{name}', f'''   (<objs> ^object <ses> <p> <c> <f>)
{sit}
{nogap}
   {flhs}''', ['<p>', '<c>']))
    rhs = f'''(<c> ^result <r0> - <r> ^done 0 - 1)
   (<p> ^carry <k> - {co})'''
    t.add(f'''
sp {{arithmetic*apply*process-column-{name}*internal
   (state <s> ^operator <op> ^internal-actions true ^world <w>)
   (<op> ^task-operator true ^name process-column ^pre-conditions-satisfied true ^argument1.object-handle <ph> ^argument2.object-handle <ch>)
   (<w> ^anchored-world true ^objects <objs>)
   (<objs> ^object <ses> <p> <c> <f>)
   (<p> ^object-handle <ph> {A('operation',op)} {A('pid','<pid>')} ^carry <k>)
   (<c> ^object-handle <ch> ^done 0 ^result <r0> {A('pid','<pid>')} {c_cond})
   {flhs}
-->
   (log 1 (crlf) |Apply process-column {name} internal.|)
   {rhs}
}}

sp {{arithmetic*apply*process-column-{name}*environment-effect
   :o-support
   (state <s> ^superstate nil ^world <w> ^io.output-link.perform-action <pa>)
   (<pa> ^name process-column ^status complete ^argument1 <ph> ^argument2 <ch> -^effect-applied true)
   (<w> ^anchored-world true ^objects <objs>)
   (<objs> ^object <ses> <p> <c> <f>)
   (<p> ^object-handle <ph> {A('operation',op)} {A('pid','<pid>')} ^carry <k>)
   (<c> ^object-handle <ch> ^done 0 ^result <r0> {A('pid','<pid>')} {c_cond})
   {flhs}
-->
   {rhs}
   (<pa> ^effect-applied true)
}}
''')
t.add(t.propose('finish-problem*finish-problem', f'''   (<objs> ^object <ses> <p>)
   (<ses> {A('type','session')} ^current <pid>)
   (<p> {A('type','problem')} {A('pid','<pid>')} ^done 0)
   -{{(<objs> ^object <c2>)
     (<c2> {A('type','column')} {A('pid','<pid>')} ^done 0)}}''', ['<p>']))
fin_lhs = f'''   (<w> ^anchored-world true ^objects <objs>)
   (<objs> ^object <ses> <p> <c1> <c2>)
   (<ses> ^current <pid> ^remaining <rem>)
   (<p> ^object-handle <ph> {A('operation','<op>')} {A('pid','<pid>')} ^done 0 ^carry <k>)
   (<c1> {A('type','column')} {A('pid','<pid>')} {A('pos','1')} {A('digit1','<t1>')} {A('digit2','<b1>')} ^result <r1>)
   (<c2> {A('type','column')} {A('pid','<pid>')} {A('pos','2')} {A('digit1','<t2>')} {A('digit2','<b2>')} ^result <r2>)'''
fin_rhs = '''(<p> ^done 0 - 1 ^answer (+ (* 10 <r2>) <r1>))
   (<ses> ^current <pid> - (+ <pid> 1) ^remaining <rem> - (- <rem> 1))'''
fin_write = '''(write |problem op | <op> | top | <t2> <t1> | bottom | <b2> <b1> | answer | <r2> <r1> | carry | <k> (crlf))'''
t.add(f'''
sp {{arithmetic*apply*finish-problem*internal
   (state <s> ^operator <op0> ^internal-actions true ^world <w>)
   (<op0> ^task-operator true ^name finish-problem ^pre-conditions-satisfied true ^argument1.object-handle <ph>)
{fin_lhs}
-->
   {fin_rhs}
}}

sp {{arithmetic*apply*finish-problem*environment-effect
   :o-support
   (state <s> ^superstate nil ^world <w> ^io.output-link.perform-action <pa>)
   (<pa> ^name finish-problem ^status complete ^argument1 <ph> -^effect-applied true)
{fin_lhs}
-->
   {fin_rhs}
   {fin_write}
   (<pa> ^effect-applied true)
}}
''')
open(f'arithmetic-rules{"-static" if LAYOUT=="static" else ""}.soar', 'w').write(t.text())
