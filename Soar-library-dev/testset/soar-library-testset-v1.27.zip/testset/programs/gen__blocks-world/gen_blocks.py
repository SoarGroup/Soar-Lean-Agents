import sys, wg
LAYOUT = sys.argv[1] if len(sys.argv) > 1 else 'flat'
DESC = """## Blocks world (look-ahead variant), written to the world conventions (agent-world, selection-world,
## selection-iterative-deepening). Operator and search-control rule follow the STEP6 blocks-world-look-ahead variant.
##
## Description: blocks A, B, C and a table. C is on A; A and B are on the table. Goal: A on B, B on C, C on the table.
## A block that is clear (nothing on it) can be moved onto the table or onto another clear block.
## World: objects table (^type table), A B C (^type block), memory (^type memory, ^last-block <handle>).
## Relations (canonical shape, one relation object per fact): (<w> ^on <r>) with <r> ^argument1 <block> ^argument2 <support>,
## and (<w> ^clear <r>) with <r> ^argument1 <object> (the table is always clear), maintained by move-block (not derived by
## negation; see FINDING-chunking-overgeneral.md) and declared ^copy-relation clear.
## Goal: three desireds, each a relation: (<d> ^on <r>) with <r> ^argument1.object-handle, ^argument2.object-handle.
## Task operator: move-block (^argument1 = block, ^argument2 = destination). Effect: the block's on-relation points to the destination.
## Search control: in look-ahead states only, a move of the block moved last is rejected (STEP6 reject-twice).
"""
t = wg.Task('blocks-world', DESC, layout=LAYOUT, static=['type'], strategy='iterative-deepening')
t.objects.append(('table', {'type': 'table'}, []))
for b in 'ABC': t.objects.append((b, {'type': 'block'}, []))
t.objects.append(('memory', {'type': 'memory', 'last-block': 'none'}, []))
for blk, sup in (('A', 'table'), ('B', 'table'), ('C', 'A')):
    t.init_extra += [f'(<w> ^on <r-{blk}>)', f'(<r-{blk}> ^argument1 <o-{blk}> ^argument2 <o-{sup}>)']
for blk, sup in (('A', 'B'), ('B', 'C'), ('C', 'table')): t.desired.append(('rel', 'on', blk, sup))
t.check_mutable('last-block')
t.copy_relations = ['clear']
# initial clear relations: the table, B and C (C is on A)
for h in ('table', 'B', 'C'):
    t.init_extra += [f'(<w> ^clear <c-{h}>)', f'(<c-{h}> ^argument1 <o-{h}>)']
A = t.lhs_attr
t.add(t.achievement_relation(2))
t.add(t.propose('move-block*move-block-to-table', f'''   (<objs> ^object <b> <d>)
   (<b> {A('type','block')} ^object-handle <bh>)
   (<d> {A('type','table')})
   (<w> ^clear <cb>)
   (<cb> ^argument1 <b>)
   (<w> ^on <r>)
   (<r> ^argument1 <b> ^argument2 {{ <> <d> }})''', ['<b>', '<d>']))
t.add(t.propose('move-block*move-block-to-block', f'''   (<objs> ^object <b> <d>)
   (<b> {A('type','block')} ^object-handle <bh>)
   (<d> {A('type','block')} ^object-handle {{ <> <bh> <dh> }})
   (<w> ^clear <cb> <cd>)
   (<cb> ^argument1 <b>)
   (<cd> ^argument1 <d>)
   (<w> ^on <r>)
   (<r> ^argument1 <b> ^argument2 {{ <> <d> }})''', ['<b>', '<d>']))
t.add('''
## Search control (STEP6 reject-twice): in a look-ahead state, do not move the block moved last.
sp {blocks-world*reject*move-block*moved-last
   (state <s> ^problem-space.name blocks-world ^internal-actions true ^operator <op> + ^world <w>)
   (<w> ^objects.object <m>)
   (<m> ^type memory ^last-block <h>)
   (<op> ^task-operator true ^name move-block ^argument1.object-handle <h>)
-->
   (<s> ^operator <op> -)
}
'''.replace('^type memory', A('type', 'memory')))
base = f'''   (<w> ^anchored-world true ^objects <objs>)
   (<objs> ^object <b> <d> <m>)
   (<b> ^object-handle <bh>)
   (<d> ^object-handle <dh>)
   (<m> {A('type','memory')} ^last-block <lb>)
   (<w> ^on <r>)
   (<r> ^argument1 <b> ^argument2 <old>)'''
# clear is maintained: a block destination loses its clear, a block that was the old support gains one (the table stays clear).
CASES = {
 'onto-block-from-block': (f"""   (<d> {A('type','block')})
   (<old> {A('type','block')})
   (<w> ^clear <cd>)
   (<cd> ^argument1 <d>)""", """   (<w> ^clear <cd> - <nc>)
   (<nc> ^argument1 <old>)"""),
 'onto-block-from-table': (f"""   (<d> {A('type','block')})
   (<old> {A('type','table')})
   (<w> ^clear <cd>)
   (<cd> ^argument1 <d>)""", """   (<w> ^clear <cd> -)"""),
 'onto-table-from-block': (f"""   (<d> {A('type','table')})
   (<old> {A('type','block')})""", """   (<w> ^clear <nc>)
   (<nc> ^argument1 <old>)"""),
}
for case, (extra, crhs) in CASES.items():
    cond = base + '\n' + extra
    rhs = f'''(<r> ^argument2 <old> - <d>)
{crhs}
   (<m> ^last-block <lb> - <bh>)'''
    t.add(f'''
sp {{blocks-world*apply*move-block*internal*{case}
   (state <s> ^operator <op> ^internal-actions true ^world <w>)
   (<op> ^task-operator true ^name move-block ^pre-conditions-satisfied true ^argument1.object-handle <bh> ^argument2.object-handle <dh>)
{cond}
-->
   (log 1 (crlf) |Apply move-block internal.|)
   {rhs}
}}

sp {{blocks-world*apply*move-block*environment-effect*{case}
   :o-support
   (state <s> ^superstate nil ^world <w> ^io.output-link.perform-action <pa>)
   (<pa> ^name move-block ^status complete ^argument1 <bh> ^argument2 <dh> -^effect-applied true)
{cond}
-->
   {rhs}
   (<pa> ^effect-applied true)
   (write |Move block | <bh> | onto | <dh> (crlf))
}}
''')
open(f'blocks-world-rules{"-static" if LAYOUT=="static" else ""}.soar', 'w').write(t.text())
