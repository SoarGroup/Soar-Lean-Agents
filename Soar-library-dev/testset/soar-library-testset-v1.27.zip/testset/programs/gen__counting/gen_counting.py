import sys, wg
LAYOUT = sys.argv[1] if len(sys.argv) > 1 else 'flat'
DESC = """## Counting (count-up), written to the world conventions (agent-world, selection-world).
## Description: a counter starts at 0 and is increased by one until it reaches 100; then the agent halts.
## Constraint: the counter stays between 0 and 100.
## World: object counter (^type counter, ^value). Goal: one desired, counter ^value 100.
## Task operator: count (^argument1 = counter), proposed while ^value < 100. Effect: ^value := ^value + 1.
## Operator and effect follow the STEP6 count-up variant; only state access and the goal test follow the world conventions.
"""
t = wg.Task('counting', DESC, layout=LAYOUT, static=['type'], strategy='selection')
t.objects.append(('counter', {'type': 'counter', 'value': 0}, []))
t.desired.append(('counter', {'value': 100}))
t.add(t.achievement())
t.add(t.propose('count', f'''   (<objs> ^object <c>)
   (<c> ^object-handle <ch> {t.lhs_attr('type','counter')} ^value {{ < 100 <v> }})''', ['<c>'], attrs='^new-value (+ <v> 1)'))
t.add('''
## Internal application (look-ahead).
sp {counting*apply*count*internal
   (state <s> ^operator <op> ^internal-actions true ^world <w>)
   (<op> ^task-operator true ^name count ^pre-conditions-satisfied true ^argument1.object-handle <ch>)
   (<w> ^anchored-world true ^objects.object <c>)
   (<c> ^object-handle <ch> ^value <v>)
-->
   (log 1 (crlf) |Apply count internal.|)
   (<c> ^value <v> - (+ <v> 1))
}

## Effect of a completed external command on the real world (once per command).
sp {counting*apply*count*environment-effect
   :o-support
   (state <s> ^superstate nil ^world <w> ^io.output-link.perform-action <pa>)
   (<pa> ^name count ^status complete ^argument1 <ch> -^effect-applied true)
   (<w> ^anchored-world true ^objects.object <c>)
   (<c> ^object-handle <ch> ^value <v>)
-->
   (<c> ^value <v> - (+ <v> 1))
   (<pa> ^effect-applied true)
}
''')
t.check_mutable('value')
open(f'counting-rules{"-static" if LAYOUT=="static" else ""}.soar', 'w').write(t.text())
