import sys, wg
import os
LAYOUT = sys.argv[1] if len(sys.argv) > 1 else 'flat'
N = int(os.environ.get('HANOI_DISCS', '2'))
DESC = """## Towers of Hanoi (2 discs by default, HANOI_DISCS to change; 3 discs needs a 7-move look-ahead, too slow with the library's depth limit of 7), written to the world conventions (agent-world, selection-world,
## selection-iterative-deepening).
##
## Description: pegs P1, P2, P3 and discs D1 (smallest) .. DN (largest). All discs start stacked on P1 (largest at the bottom).
## Goal: the same stack on P3 (2 discs: 3 moves). A disc that is clear (nothing on it) can be moved onto a clear peg or onto a clear larger disc.
## World: objects P1 P2 P3 (^type peg), D1..DN (^type disc ^size 1..N), memory (^type memory, ^last-disc <handle>).
## Relations (canonical shape): (<w> ^on <r>) with <r> ^argument1 <disc> ^argument2 <peg-or-disc>; (<w> ^clear <r>) with <r> ^argument1 <object>.
## clear is maintained by move-disc (not derived by negation; see FINDING-chunking-overgeneral.md) and declared ^copy-relation clear.
## Goal: one relation desired per disc: largest on P3, each other disc on the next larger one.
## Task operator: move-disc (^argument1 = disc, ^argument2 = destination). Effect: the disc's on-relation points to the destination.
## Search control (look-ahead only): do not move the disc moved last (an immediate repeat is never useful).
"""
t = wg.Task('hanoi', DESC, layout=LAYOUT, static=['type', 'size'], strategy='iterative-deepening')
for p in ('P1', 'P2', 'P3'): t.objects.append((p, {'type': 'peg'}, []))
for i in range(1, N + 1): t.objects.append((f'D{i}', {'type': 'disc', 'size': i}, []))
t.objects.append(('memory', {'type': 'memory', 'last-disc': 'none'}, []))
for d, sup in [(f'D{N}', 'P1')] + [(f'D{i}', f'D{i+1}') for i in range(N - 1, 0, -1)]:
    t.init_extra += [f'(<w> ^on <r-{d}>)', f'(<r-{d}> ^argument1 <o-{d}> ^argument2 <o-{sup}>)']
for d, sup in [(f'D{N}', 'P3')] + [(f'D{i}', f'D{i+1}') for i in range(N - 1, 0, -1)]: t.desired.append(('rel', 'on', d, sup))
t.check_mutable('last-disc')
t.copy_relations = ['clear']
# initial clear relations: the top disc and the two empty pegs
for h in ('D1', 'P2', 'P3'):
    t.init_extra += [f'(<w> ^clear <c-{h}>)', f'(<c-{h}> ^argument1 <o-{h}>)']
A = t.lhs_attr
t.add(t.achievement_relation(2))
t.add(t.propose('move-disc*move-disc-to-peg', f'''   (<objs> ^object <b> <d>)
   (<b> {A('type','disc')} ^object-handle <bh>)
   (<d> {A('type','peg')})
   (<w> ^clear <cb> <cd>)
   (<cb> ^argument1 <b>)
   (<cd> ^argument1 <d>)
   (<w> ^on <r>)
   (<r> ^argument1 <b> ^argument2 {{ <> <d> }})''', ['<b>', '<d>']))
t.add(t.propose('move-disc*move-disc-to-disc', f'''   (<objs> ^object <b> <d>)
   (<b> {A('type','disc')} {A('size','<bs>')} ^object-handle <bh>)
   (<d> {A('type','disc')} {A('size','{ > <bs> }')})
   (<w> ^clear <cb> <cd>)
   (<cb> ^argument1 <b>)
   (<cd> ^argument1 <d>)
   (<w> ^on <r>)
   (<r> ^argument1 <b> ^argument2 {{ <> <d> }})''', ['<b>', '<d>']))
t.add('''
## Search control: in a look-ahead state, do not move the disc moved last.
sp {hanoi*reject*move-disc*moved-last
   (state <s> ^problem-space.name hanoi ^internal-actions true ^operator <op> + ^world <w>)
   (<w> ^objects.object <m>)
   (<m> ^type memory ^last-disc <h>)
   (<op> ^task-operator true ^name move-disc ^argument1.object-handle <h>)
-->
   (<s> ^operator <op> -)
}
'''.replace('^type memory', A('type', 'memory')))
cond = f'''   (<w> ^anchored-world true ^objects <objs>)
   (<objs> ^object <b> <d> <m>)
   (<b> ^object-handle <bh>)
   (<d> ^object-handle <dh>)
   (<m> {A('type','memory')} ^last-disc <lb>)
   (<w> ^on <r> ^clear <cd>)
   (<r> ^argument1 <b> ^argument2 <old>)
   (<cd> ^argument1 <d>)'''
rhs = '''(<r> ^argument2 <old> - <d>)
   (<w> ^clear <cd> - <nc>)
   (<nc> ^argument1 <old>)
   (<m> ^last-disc <lb> - <bh>)'''
t.add(f'''
sp {{hanoi*apply*move-disc*internal
   (state <s> ^operator <op> ^internal-actions true ^world <w>)
   (<op> ^task-operator true ^name move-disc ^pre-conditions-satisfied true ^argument1.object-handle <bh> ^argument2.object-handle <dh>)
{cond}
-->
   (log 1 (crlf) |Apply move-disc internal.|)
   {rhs}
}}

sp {{hanoi*apply*move-disc*environment-effect
   :o-support
   (state <s> ^superstate nil ^world <w> ^io.output-link.perform-action <pa>)
   (<pa> ^name move-disc ^status complete ^argument1 <bh> ^argument2 <dh> -^effect-applied true)
{cond}
-->
   {rhs}
   (<pa> ^effect-applied true)
   (write |Move disc | <bh> | onto | <dh> (crlf))
}}
''')
open(f'hanoi-rules{"-static" if LAYOUT=="static" else ""}.soar', 'w').write(t.text())
