#!/usr/bin/env python3
"""Soar library regression tests.
usage: run_tests.py [--libs DIR] [--only SUBSTR] [--kind K] [--variant embedded|current] [--update OUT.json] [--timeout S] [--soar-bin DIR]
 --libs DIR   root holding soar-library.soar (the restructured tree) ; substituted for {LIB} in world tests.
              Without --libs the world 'current' variant tests are skipped (the 'embedded' ones use libraries copied into the program).
 --update F   write observed fingerprints to F (use to re-baseline after an intended change).
Exit code 0 = all compared tests match expected fingerprints."""
import sys, os, json, subprocess, tempfile, concurrent.futures as cf
HERE = os.path.dirname(os.path.abspath(__file__))
def arg(n, d=None): return sys.argv[sys.argv.index(n)+1] if n in sys.argv else d
B = arg('--soar-bin', os.environ.get('SOAR_BIN', '/home/claude/soar966/x/SoarSuite_9.6.6-bigbugfixrelease-Multiplatform/bin/linux_x86-64'))
ENV = dict(os.environ, PYTHONPATH=B+os.pathsep+os.path.join(HERE,'tools','shim'), LD_LIBRARY_PATH=B)
M = json.load(open(os.path.join(HERE, 'manifest.json'))); FIELDS = M['fields']
libs = arg('--libs'); only = arg('--only'); kind = arg('--kind'); variant = arg('--variant'); to = int(arg('--timeout', 120))
def run(t):
    spec = dict(id=t['id'], workdir=os.path.join(HERE, t['workdir']), commands=[c.replace('{LIB}', libs or '') for c in t['commands']],
                seed=t['seed'], cap=t['cap'], mode=t['mode'])
    fd, p = tempfile.mkstemp(suffix='.json'); os.write(fd, json.dumps(spec).encode()); os.close(fd)
    try:
        r = subprocess.run([sys.executable, '-I', os.path.join(HERE,'tools','runner.py'), p], capture_output=True, text=True, timeout=to, env=ENV)
        for l in r.stdout.splitlines():
            if l.startswith('@@RESULT@@'): return json.loads(l[10:])
        return {'error': 'crash rc=%s' % r.returncode}
    except subprocess.TimeoutExpired: return {'error': 'timeout'}
    finally: os.unlink(p)
sel = [t for t in M['tests'] if (not only or only in t['id']) and (not kind or t['kind'] == kind) and (not variant or t.get('variant') == variant)]
skipped = [t for t in sel if '{LIB}' in ' '.join(t['commands']) and not libs]
sel = [t for t in sel if t not in skipped]
obs = {}; bad = 0
with cf.ThreadPoolExecutor(2) as ex:
    for t, r in zip(sel, ex.map(run, sel)):
        got = {k: r.get(k) for k in FIELDS}; obs[t['id']] = got
        diffs = [k for k in FIELDS if got[k] != t['expected'][k]] if 'error' not in r else [r['error']]
        if r.get('load_errors'): diffs.append('load_errors')
        print(('PASS ' if not diffs else 'FAIL ') + t['id'] + ('' if not diffs else '  ' + ','.join(diffs))); bad += bool(diffs)
print('\n%d run, %d failed, %d skipped (need --libs)' % (len(sel), bad, len(skipped)))
if arg('--update'): json.dump(obs, open(arg('--update'), 'w'), indent=1)
sys.exit(1 if bad else 0)
