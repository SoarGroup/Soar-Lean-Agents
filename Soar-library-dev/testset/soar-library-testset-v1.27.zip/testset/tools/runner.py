#!/usr/bin/env python3
"""Run one Soar program once and print a JSON fingerprint.
usage: runner.py SPEC.json   where SPEC = {id, workdir, commands:[...], seed, cap, watch:1}
Commands are Soar CLI commands run with cwd=workdir (e.g. 'source mac.soar', 'pushd /abs/lib')."""
import sys, os, re, json, hashlib, time
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'shim'))
import soar_sml as S

def h(s): return hashlib.md5(s.encode()).hexdigest()[:12]

def main():
    spec = json.load(open(sys.argv[1]))
    os.chdir(spec['workdir'])
    res = dict(id=spec['id'], seed=spec.get('seed', 1), cap=spec['cap'])
    k = S.Kernel.CreateKernelInNewThread(0)
    a = k.CreateAgent('t')
    out = []
    a.RegisterForPrintEvent(S.smlEVENT_PRINT, lambda mid, ud, ag, msg: out.append(msg), None)
    load_text = []
    try:
        a.ExecuteCommandLine('output agent-logs 1 off')
        for c in spec['commands']:
            load_text.append(a.ExecuteCommandLine(c))
        loaded = '\n'.join(load_text) + ''.join(out)
        res['load_errors'] = [l.strip()[:160] for l in loaded.splitlines()
                              if re.search(r'\bError\b|Unable to open|Could not|failed|No such file', l) and 'ERROR' not in l[:0]][:6]
        n_load_out = len(out)
        a.ExecuteCommandLine('watch 0')
        if spec.get('watch', 1):
            a.ExecuteCommandLine('watch 1')
        a.ExecuteCommandLine('srand %s' % res['seed'])
        t0 = time.time()
        if spec.get('mode') == 'env-complete':
            acts = []; res['success_step'] = None
            for step in range(spec['cap']):
                a.RunSelf(1)
                for i in range(a.GetNumberCommands()):
                    c = a.GetCommand(i)
                    if c.GetCommandName() == 'perform-action' and c.GetParameterValue('status') is None:
                        acts.append('%s %s %s' % (c.GetParameterValue('name'), c.GetParameterValue('argument1'), c.GetParameterValue('argument2')))
                        c.AddStatusComplete()
                a.Commit(); a.ClearOutputLinkChanges()
                if 'success' in a.ExecuteCommandLine('print (s1 ^success *)'):
                    res['success_step'] = step + 1; break
            res['actions'] = len(acts); res['actions_hash'] = h('\n'.join(acts))
        else:
            a.ExecuteCommandLine('run %d' % spec['cap'])
        res['wall'] = round(time.time() - t0, 2)
        st = a.ExecuteCommandLine('stats')
        g = lambda p: (re.search(p, st).groups() if re.search(p, st) else None)
        m = g(r'(\d+) productions \((\d+) default, (\d+) user, (\d+) chunks\)')
        res['productions'] = dict(default=int(m[1]), user=int(m[2]), chunks=int(m[3])) if m else None
        for key, p in [('decisions', r'(\d+) decisions'), ('elab_cycles', r'(\d+) elaboration cycles'),
                       ('firings', r'(\d+) production firings'), ('wme_changes', r'(\d+) wme changes')]:
            mm = g(p); res[key] = int(mm[0]) if mm else None
        res['halted'] = res['decisions'] is not None and res['decisions'] < spec['cap'] if spec.get('mode') != 'env-complete' else res.get('success_step') is not None
        txt = ''.join(out[n_load_out:])
        ops, subst, other = [], 0, []
        for line in txt.splitlines():
            mo = re.match(r'\s*\d+:\s+O:\s+\S+\s+\((.*)\)\s*$', line)
            if mo: ops.append(mo.group(1)); continue
            if re.match(r'\s*\d+:\s+=>?S:', line) or re.match(r'\s*=>S:', line): subst += 1; continue
            if re.match(r'\s*\d+:\s+[A-Z]:', line) or re.match(r'\s*=>', line): continue
            if line.strip(): other.append(line.rstrip())
        res['operators_selected'] = len(ops)
        res['distinct_operator_names'] = len(set(ops))
        res['operator_trace_hash'] = h('\n'.join(ops))
        res['substates_created'] = subst
        res['output_lines'] = len(other)
        res['output_hash'] = h('\n'.join(other))
        res['output_tail'] = [l[:100] for l in other[-3:]]
        names = a.ExecuteCommandLine('print -u -n')
        res['user_rule_names_hash'] = h('\n'.join(sorted(names.split())))
        res['user_rule_names_loaded'] = len(names.split())
        res['rule_names'] = sorted(names.split())
    except Exception as e:
        res['exception'] = repr(e)[:200]
    try: k.Shutdown()
    except Exception: pass
    print('@@RESULT@@' + json.dumps(res))

if __name__ == '__main__': main()
