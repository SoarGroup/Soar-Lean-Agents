import sys
sys.path.insert(0,"/home/claude/soar966/x/SoarSuite_9.6.6-bigbugfixrelease-Multiplatform/bin/linux_x86-64")
from Python_sml_ClientInterface import *
import Python_sml_ClientInterface as _m
sys.modules[__name__].__dict__.update({k:getattr(_m,k) for k in dir(_m) if not k.startswith("__")})
