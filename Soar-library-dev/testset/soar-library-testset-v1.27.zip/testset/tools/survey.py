#!/usr/bin/env python3
"""Run a manifest of specs (list of dicts) in subprocesses, 2 at a time, with timeout. usage: survey.py MANIFEST.json OUT.jsonl [--timeout S]"""
import sys, os, json, subprocess, tempfile, concurrent.futures as cf
HERE = os.path.dirname(os.path.abspath(__file__))
B = '/home/claude/soar966/x/SoarSuite_9.6.6-bigbugfixrelease-Multiplatform/bin/linux_x86-64'
ENV = dict(os.environ, PYTHONPATH=B, LD_LIBRARY_PATH=B)
def one(spec, timeout):
    fd, p = tempfile.mkstemp(suffix='.json'); os.write(fd, json.dumps(spec).encode()); os.close(fd)
    try:
        r = subprocess.run([sys.executable, '-I', os.path.join(HERE, 'runner.py'), p], capture_output=True, text=True, timeout=timeout, env=ENV)
        for l in r.stdout.splitlines():
            if l.startswith('@@RESULT@@'):
                d = json.loads(l[10:]); d['status'] = 'ok'; return d
        return dict(id=spec['id'], seed=spec.get('seed'), status='crash', rc=r.returncode, err=(r.stderr or r.stdout)[-300:])
    except subprocess.TimeoutExpired:
        return dict(id=spec['id'], seed=spec.get('seed'), status='timeout', timeout=timeout)
    finally: os.unlink(p)
if __name__ == '__main__':
    man = json.load(open(sys.argv[1])); out = sys.argv[2]
    timeout = int(sys.argv[sys.argv.index('--timeout') + 1]) if '--timeout' in sys.argv else 90
    with open(out, 'w') as f, cf.ThreadPoolExecutor(2) as ex:
        for d in ex.map(lambda s: one(s, timeout), man):
            f.write(json.dumps(d) + '\n'); f.flush()
