"""Build the reorganized library tree from the old tree using the move manifest.
Usage: python3 build.py OUTDIR   (OUTDIR is created fresh)"""
import os, sys, json, csv, shutil, uuid, collections, re, hashlib
from chunker import segment
from soarparse import parse_header, match_brace
import manifest_spec as S
import make_manifest as M

ADD_DEFAULT=(os.environ.get("ADD_DEFAULT","1")=="1")
LIB_ORDER=['soar-base','selection-world','agent-world','object-world']     # library loader
THOR_ORDER=['thor-soar','thor-tasks']
IMPASSE_NAMES={'Operator_Tie','Operator_Constraint-Failure','State_No-Change','Operator_Conflict'}
NOT_OPERATOR={'elaborations','all','strategies','events','settings','from-agent-world','docs','from-thor','first-success','iterative-deepening','optimal','_flags'}

def add_default(text):
    b=text.find('{'); e=match_brace(text,b); body=text[b+1:e]
    n,o,r=parse_header(body)
    if ':default' in o: return text,False
    assert body.endswith(r)
    k=b+1+len(body)-len(r)
    ins=':default\n' if not text[k-1:k]=='\n' else ':default\n'
    # place on its own line after the name/doc, before the first condition
    return text[:k]+ins+text[k:].lstrip(' \t') if False else (text[:k].rstrip(' \t')+('\n' if not text[:k].endswith('\n') else '')+'    :default\n'+text[k:].lstrip(' \t')) ,True

def main(out):
    if os.path.exists(out): shutil.rmtree(out)
    os.makedirs(out)
    entries,files=M.plan()
    ebykey={(e['src'],e['line']):e for e in entries}
    dest_text=collections.defaultdict(list)       # (proj,path) -> list of text pieces
    prov=[]; stats=collections.Counter()
    for p in sorted(__import__('glob').glob(S.ROOT+'/**/*.soar',recursive=True)):
        rel=p[len(S.ROOT)+1:]
        f=[x for x in files if x['src']==rel][0]
        if f['action'] not in ('FILE',): continue
        txt=open(p,errors='replace').read(); segs=segment(txt)
        line=1; pending=''; last=None
        for s in segs:
            e=ebykey.get((rel,line)); n=s['text'].count('\n')
            if s['kind']=='text': pending+=s['text']
            elif s['kind']=='crule': pending=pending if pending.strip() else ''
            elif s['kind']=='cmd' and s['name'] in('source','pushd','popd'): pass
            else:
                if e is None or e['action'].startswith('REMOVE'):
                    if pending.strip(): pass      # keep header comments for the next active segment
                    else: pending=''
                else:
                    key=(e['dest_project'],e['dest_path']); t=s['text']
                    if s['kind']=='rule' and ADD_DEFAULT:
                        t,ch=add_default(t); stats['default_added']+=ch; stats['default_already']+=(not ch)
                    dest_text[key].append(pending+t); pending=''; last=key
                    if s['kind']=='rule': prov.append((rel,e['line'] if e else line,e['name'],key[0],key[1],e['action']))
            line+=n
        if pending.strip() and last: dest_text[last].append(pending)
    # write files
    for (proj,path),pieces in dest_text.items():
        fp=os.path.join(out,proj,path); os.makedirs(os.path.dirname(fp),exist_ok=True)
        open(fp,'w').write(''.join(pieces))
    for f in files:
        if f['action']=='VERBATIM':
            fp=os.path.join(out,f['dest']); os.makedirs(os.path.dirname(fp),exist_ok=True); shutil.copy(os.path.join(S.ROOT,f['src']),fp)
    import patches
    applied=[]
    for f,old,new,pid,desc in patches.PATCHES:
        fp=os.path.join(out,f); t=open(fp).read()
        assert t.count(old)==1,(pid,'old text not found exactly once')
        open(fp,'w').write(t.replace(old,new)); applied.append((pid,f,desc))
    nsub=0
    for dp,dn,fn in os.walk(out):
        if '/docs' in dp or '/tools' in dp or '/datamaps' in dp: continue
        for fx in fn:
            if not fx.endswith('.soar') or fx.endswith('_source.soar') or fx.startswith('_readme'): continue
            fp=os.path.join(dp,fx); t=open(fp).read(); t2,k=patches.apply_text_subs(t)
            if k: open(fp,'w').write(t2); nsub+=k
    applied.append((patches.TEXT_SUBS_ID,'(all rule files, %d substitutions)'%nsub,patches.TEXT_SUBS_DESC))
    for f,pid,desc,_r in patches.REMOVE_FILES:
        os.remove(os.path.join(out,f)); applied.append((pid,f+' (deleted)',desc))
    for f,rname,pid,desc in patches.REMOVE_RULES:
        fp=os.path.join(out,f); t=open(fp).read(); segs=segment(t); pos=0; done=False; res=[]
        for s in segs:
            if s['kind']=='rule' and s['name']==rname and not done:
                done=True
                # drop the comment lines directly above the rule
                lines=''.join(res).split('\n')
                while len(lines)>1 and lines[-2].strip().startswith('#'): lines.pop(-2)
                res=['\n'.join(lines)]
                continue
            res.append(s['text'])
        assert done,(pid,rname,'not found')
        open(fp,'w').write(''.join(res)); applied.append((pid,f+' (rule '+rname+' deleted)',desc))
    import newfiles
    for rel,txt in newfiles.NEW_FILES.items():
        fp=os.path.join(out,rel); os.makedirs(os.path.dirname(fp),exist_ok=True); open(fp,'w').write(txt)
    applied.append(('P-007','(new files: '+', '.join(newfiles.NEW_FILES)+')','Flags convention: per-project _flags files with defaults, a generic ^flag-override copy rule in agent-world, ^flags created once on the top state by agent-world. Tasks and Thor set flags through ^flag-override.'))
    import cleanup
    cleanup.main(out)
    applied.append(('P-008','(all library rule files)','Cleanup: rule names conform to <project>*<phase>*<topic>, rules grouped elaborate/propose/compare/apply, a comment on every file and rule, blank lines collapsed. Old to new names are in rule-renames.csv.'))
    with open(os.path.join(out,'PATCHES.txt'),'w') as fh:
        fh.write('Content fixes applied after the move (see patches.py):\n'+''.join(f'{p}  {f}\n    {d}\n' for p,f,d in applied))
    # docs
    for f in files:
        if f['action']=='DOC':
            dp,_=M.file_dest(f['src']); name=f['src'].replace('/','__')
            fp=os.path.join(out,dp,'docs',name); os.makedirs(os.path.dirname(fp),exist_ok=True)
            shutil.copy(os.path.join(S.ROOT,f['src']),fp)
    # old high-level names (dirs that had a sibling .soar in the old tree)
    old_hl=set()
    for dp_,dn,fn in os.walk(S.ROOT):
        for d in dn:
            if '~' in d: continue
            if d+'.soar' in fn: old_hl.add(d)
    projects=sorted({k[0] for k in dest_text})
    # stubs + loaders
    for proj in projects:
        base=os.path.join(out,proj)
        for dp_,dn,fn in sorted(os.walk(base)):
            if os.path.basename(dp_)=='docs': continue
            for d in dn:
                if d=='docs' or d in NOT_OPERATOR: continue
                if (d in old_hl or d in IMPASSE_NAMES or d.startswith('Impasse__')) and not os.path.exists(os.path.join(dp_,d+'.soar')):
                    open(os.path.join(dp_,d+'.soar'),'w').write(f'# {d}: operator/impasse file (rules for the {d} context). Generated stub.\n')
        write_loaders(out,proj)
    write_top(out,projects)
    # provenance
    with open(os.path.join(out,'build-provenance.csv'),'w',newline='') as fh:
        w=csv.writer(fh); w.writerow(['source_file','line','rule','dest_project','dest_path','action']); w.writerows(prov)
    json.dump(dict(stats=stats,projects=projects),open(os.path.join(out,'build-stats.json'),'w'),default=int)
    import readmes, datamaps
    datamaps.main(out)                         # merged datamap (needs the rule files)
    readmes.main(out)                          # uses the datamap ownership
    for p in projects: write_loaders(out,p)    # sources _readme.soar first
    datamaps.main(out,True)                    # reassemble so the layouts include _readme.soar
    os.makedirs(os.path.join(out,'tools'),exist_ok=True)
    for f in ('datamaps.py','chunker.py','soarparse.py'): shutil.copy(os.path.join(os.path.dirname(os.path.abspath(__file__)),f),os.path.join(out,'tools',f))
    print(dict(stats),projects)

def dir_order(names):
    return sorted(names,key=lambda x:(not x.startswith('_'),x))

def write_loaders(out,proj):
    base=os.path.join(out,proj)
    # custom: strategies / events handling
    def gen(d,rel):
        files=[f for f in os.listdir(d) if f.endswith('.soar') and not f.endswith('_source.soar')]
        dirs=[x for x in os.listdir(d) if os.path.isdir(os.path.join(d,x)) and x!='docs']
        for x in dirs: gen(os.path.join(d,x),rel+'/'+x if rel else x)
        name=os.path.basename(d) if rel else proj
        L=[f'# {name}_source.soar  -- generated by build.py; edit freely']
        dset=set(dirs)
        for f in dir_order(files):
            if f[:-5] in dset: continue           # operator file sourced right before its folder
            L.append(f'source {f}')
        special={}
        for x in dir_order(dirs):
            if x+'.soar' in files: L.append(f'source {x}.soar')
            line=[f'pushd {x}',f'source {x}_source.soar','popd']
            if proj=='agent-world' and not rel and x=='events':
                L.append('# events (future-event, wait, skip-wait, dispatch): comment out to run without the time/event machinery')
            if proj=='selection-world' and rel=='strategies':
                continue
            L+=line
        if proj=='selection-world' and rel=='strategies':
            L=[f'# strategies: source exactly one of first-success / optimal, plus a depth strategy',
               'pushd iterative-deepening','source iterative-deepening_source.soar','popd',
               'pushd first-success','source first-success_source.soar','popd',
               '# alternative to first-success (untested): selection prefers the shallowest success',
               '# pushd optimal','# source optimal_source.soar','# popd']
        open(os.path.join(d,(name if rel else proj)+'_source.soar'),'w').write('\n'.join(L)+'\n')
    gen(base,'')
    open(os.path.join(out,proj+'.soar'),'w').write(f'pushd {proj}\nsource {proj}_source.soar\npopd\n')

def write_top(out,projects):
    def loader(name,order,header):
        L=[header]
        for p in order:
            if p in projects: L.append(f'source {p}.soar')
        open(os.path.join(out,name),'w').write('\n'.join(L)+'\n')
    loader('soar-library.soar',LIB_ORDER,'# Library projects, in load order. Source this file from the directory it is in (pushd first).')
    loader('thor.soar',THOR_ORDER,'# Thor-Soar and its tasks. Requires the library (soar-library.soar) loaded first.')

if __name__=='__main__': main(sys.argv[1])
