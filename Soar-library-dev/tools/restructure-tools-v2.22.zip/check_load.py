import sys,os
sys.path.insert(0,'/home/claude/soar-test/shim'); sys.path.insert(0,'/home/claude/soar966/x/SoarSuite_9.6.6-bigbugfixrelease-Multiplatform/bin/linux_x86-64')
import soar_sml as sml
k=sml.Kernel.CreateKernelInCurrentThread(True) if hasattr(sml,'Kernel') else None
a=k.CreateAgent('a')
lib=sys.argv[1]
out=[]
for c in ['pushd "%s"'%lib,'source soar-library.soar','source thor.soar','popd']:
    out.append(a.ExecuteCommandLine(c))
txt='\n'.join(out)
open('/tmp/dups.out','w').write(txt)
print(len(txt)); print(txt[-1500:])
