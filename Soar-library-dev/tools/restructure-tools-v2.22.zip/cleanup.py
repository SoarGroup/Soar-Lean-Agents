"""Cleanup pass for the library projects (run by build.py after the content patches, before loaders/datamaps).

For every rule file of the library projects (soar-base, selection-world, agent-world, object-world):
  1. Rule names conform to  <project>*<phase>*<topic>[*<detail>]   phase = elaborate | propose | compare | apply
     (phase is derived from the rule body; stray prefixes are replaced by the project name).
  2. Rules inside a file are grouped in the order elaborate, propose, compare (evaluate/compare), apply;
     order inside a group is kept.
  3. Every file starts with a short '##' comment; every rule is preceded by a short '##' comment.
  4. Runs of blank lines are collapsed; one blank line separates rules; no trailing blanks.
Thor projects get steps 3 and 4 only (no rename, no regrouping) until the Thor review.
Writes rule-renames.csv and cleanup-report.txt to the output root.
"""
import os, re, csv, collections
from chunker import segment
from soarparse import strip_comments, parse_header, match_brace

LIB=['soar-base','selection-world','agent-world','object-world']
THOR=['thor-soar','thor-tasks']
PHASES=['elaborate','propose','compare','apply']
PHASE_WORDS={'elaborate','elaborates','elabrate','elaboration','elaborations','propose','compare','apply'}
STRAY={'selection','world-agent','top-goal','task','default','top','top-ps','top-state','state-no-change','evaluate-operator',
       'failure-evaluation','evaluation','smem','store-scene','goal-completed','operator','prefer','elaborate-substate'}
TYPOS={'evalaution':'evaluation','failue':'failure','elabrate':'elaborate'}
VERB={'elaborate':'Elaborate','propose':'Propose','compare':'Compare/prefer','apply':'Apply'}

def classify(name,opts,body):
    b=strip_comments(body); k=b.find('-->')
    lhs,rhs=(b[:k],b[k+3:]) if k>=0 else (b,'')
    prop=re.search(r'\^operator\s+<[^>]+>\s*\+',rhs) is not None
    rhs_op=re.search(r'\^operator\s+<[^>]+>\s*[<>=!~@&-]',rhs) is not None or re.search(r'\^operator\s+<[^>]+>\s*\n?\s*(?:[<>=!~@-])',rhs) is not None
    lhs_sel=re.search(r'(?<![-\w])\^operator(?:\.|\s+<[^>]+>(?!\s*[+<>=!~@&]))',lhs.replace('-^operator',' ')) is not None
    if re.search(r'\((?:interrupt|halt)\)',rhs) and not prop: return 'apply'
    if prop: return 'propose'
    if rhs_op: return 'compare'
    if lhs_sel and ':i-support' not in opts: return 'apply'
    return 'elaborate'

def new_name(old,proj,phase):
    toks=[t.lower().replace('_','-') for t in old.split('*')]
    toks=[re.sub(r'-{2,}','-',t).strip('-') for t in toks]
    toks=[TYPOS.get(t,t) for t in toks]
    PROJ={'soar-base','selection-world','agent-world','object-world','thor-soar','world-agent'}
    while toks and toks[0] in PROJ: toks=toks[1:]
    # drop a phase word in the first two positions; keep stray context words as topic
    for i in range(min(2,len(toks))):
        if toks[i] in PHASE_WORDS: toks.pop(i); break
    while len(toks)>1 and toks[0] in PROJ: toks=toks[1:]
    if toks and toks[0].startswith('impasse-'): toks[0]=toks[0][len('impasse-'):]
    if not toks: toks=[phase]
    return '*'.join([proj,phase]+toks)

def describe(old,phase,opts,body):
    """one-line structural comment"""
    b=strip_comments(body); k=b.find('-->'); lhs,rhs=(b[:k],b[k+3:]) if k>=0 else (b,'')
    opn=re.search(r'\^name\s+([\w-]+)',rhs) or re.search(r'\^operator\.name\s+([\w-]+)',lhs) or re.search(r'\^name\s+([\w-]+)',lhs)
    attrs=[]
    for a in re.findall(r'\^([\w-]+)',rhs):
        if a not in attrs and a not in('operator','name'): attrs.append(a)
    topic=' '.join(t for t in old.split('*') if t.lower() not in PHASE_WORDS|{'agent-world','selection-world','object-world','thor-soar'}).replace('_',' ')
    topic=re.sub(r'\s+',' ',topic).strip()
    on=opn.group(1) if opn else None
    if phase=='propose': s='Propose '+(on or topic)
    elif phase=='apply': s='Apply '+(on or topic)+(' (o-support)' if ':o-support' in opts else '')
    elif phase=='compare': s='Preference for '+topic
    else: s='Elaborate '+topic
    if attrs and phase in('elaborate','apply'): s+=' -> sets '+', '.join(attrs[:3])+(' ...' if len(attrs)>3 else '')
    return s.rstrip()+'.'

def keep_prose(block):
    """keep human comment lines that are prose (not banners, commented-out code, or old rule names)"""
    keep=[]
    for l in block:
        t=l.strip().lstrip('#').strip()
        if not t or re.match(r'^[#=\-*\s]+$',l.strip()): continue
        if re.match(r'^[A-Z]\.\s',t) or '*' in t or re.match(r'^[\d.]+\s',t): continue
        if re.search(r'[()<>^{}]',t) and not re.search(r'[a-z]{3,}\s+[a-z]{3,}',t): continue    # code-like
        keep.append('## '+t)
    return keep[:2]

def collapse(lines):
    out=[]; blank=False
    for l in lines:
        if not l.strip():
            if out and not blank: out.append(''); blank=True
        else: out.append(l.rstrip()); blank=False
    while out and not out[-1].strip(): out.pop()
    return out

def tidy(text):
    out=[]
    for i,l in enumerate(text.split('\n')):
        l=l.strip() if i==0 else l.rstrip()
        if not l.strip(): continue
        if i>0 and l[0] in '(-^' and not l.startswith('-->'): l='   '+l
        out.append(l)
    return out

def process_file(path,proj,rename,report,renames,used):
    txt=open(path,errors='replace').read(); segs=segment(txt)
    rules=[]; header=[]; pending=[]; others=[]
    seen_rule=False
    for s in segs:
        if s['kind']=='text':
            pending+=s['text'].split('\n')[:-1] if s['text'].endswith('\n') else s['text'].split('\n')
        elif s['kind']=='rule':
            seen_rule=True; rules.append((pending,s)); pending=[]
        elif s['kind']=='crule': pending=[]
        else:   # command (rare in rule files)
            others.append(s['text'].rstrip('\n'))
    trailing=pending
    if not rules: return None
    hdr_lines=[]
    # leading comment block before the first rule that is separated by a blank line is a file header candidate
    first=rules[0][0]
    out_rules=[]
    for pend,s in rules:
        text=s['text'].rstrip('\n')
        b=text.find('{'); e=match_brace(text,b); body=text[b+1:e]
        name,opts,rest=parse_header(body)
        phase=classify(name,opts,body)
        if rename:
            nn=new_name(name,proj,phase)
            base=nn; i=2
            while nn in used: nn=f'{base}*{i}'; i+=1
            used.add(nn)
            if nn!=name:
                text=text[:b+1]+body.replace(name,nn,1)+text[e:]
                body=text[b+1:e]
            renames.append((path,name,nn,phase))
        else: nn=name
        # block comment immediately above the rule (last contiguous comment lines)
        blk=[]
        k=len(pend)
        while k>0 and pend[k-1].strip().startswith('#'): blk.insert(0,pend[k-1]); k-=1
        desc=describe(name,phase,opts,body)
        cm=['## '+desc]+keep_prose(blk)
        out_rules.append((phase,cm,tidy(text)))
    if rename:
        out_rules.sort(key=lambda r:PHASES.index(r[0]))
    lines=[]
    rel=os.path.relpath(path)
    phs=collections.Counter(r[0] for r in out_rules)
    fn=os.path.basename(path)
    title='## %s -- %s: %s.'%(fn,proj,', '.join('%d %s'%(phs[p],{'elaborate':'elaboration','propose':'proposal','compare':'compare','apply':'application'}[p]+('s' if phs[p]!=1 else '')) for p in PHASES if phs[p]))
    lines.append(title); lines.append('')
    if others: lines+=others+['']
    last=None
    for phase,cm,body in out_rules:
        if rename and phase!=last and len(set(r[0] for r in out_rules))>1:
            lines.append('## ---- %s ----'%{'elaborate':'elaborations','propose':'operator proposal','compare':'evaluate / compare','apply':'operator application'}[phase]); lines.append('')
        last=phase
        lines+=cm+body+['']
    open(path,'w').write('\n'.join(collapse(lines))+'\n')
    return True

def main(out):
    renames=[]; report=[]; used=set()
    # Thor first collects names so that library renames never collide with them
    for proj in THOR:
        for dp,dn,fn in os.walk(os.path.join(out,proj)):
            for f in fn:
                p=os.path.join(dp,f)
                if f.endswith('.soar') and not f.endswith('_source.soar') and not f.startswith('_readme') and '/docs' not in dp:
                    for s in segment(open(p,errors='replace').read()):
                        if s['kind']=='rule': used.add(s['name'])
    thor_used=set(used); alt_used={}     # alternative strategies are never loaded together, so they may reuse names
    for proj in LIB:
        base=os.path.join(out,proj)
        if not os.path.isdir(base): continue
        for dp,dn,fn in sorted(os.walk(base)):
            if '/docs' in dp: continue
            for f in sorted(fn):
                p=os.path.join(dp,f)
                if not f.endswith('.soar') or f.endswith('_source.soar') or f.startswith('_readme'): continue
                alt='optimal' if '/strategies/optimal/' in p else None
                process_file(p,proj,True,report,renames,alt_used.setdefault(alt,set(thor_used)) if alt else used)
    for proj in THOR:
        base=os.path.join(out,proj)
        if not os.path.isdir(base): continue
        for dp,dn,fn in sorted(os.walk(base)):
            if '/docs' in dp: continue
            for f in sorted(fn):
                p=os.path.join(dp,f)
                if not f.endswith('.soar') or f.endswith('_source.soar') or f.startswith('_readme'): continue
                process_file(p,proj,False,report,[],set())
    with open(os.path.join(out,'rule-renames.csv'),'w',newline='') as fh:
        w=csv.writer(fh); w.writerow(['file','old_name','new_name','phase'])
        for p,o,n,ph in renames: w.writerow([os.path.relpath(p,out),o,n,ph])
    W={'elaborate','elaboration','elaborations','elabrate','propose','compare','apply'}; M={'elaboration':'elaborate','elaborations':'elaborate','elabrate':'elaborate'}
    dis=[]
    for p,o,n,ph in renames:
        h=[M.get(a,a) for a in o.lower().split('*')[:2] if a in W]
        if h and h[0]!=ph: dis.append((o,h[0],ph,os.path.relpath(p,out)))
    c=collections.Counter(r[3] for r in renames)
    with open(os.path.join(out,'cleanup-report.txt'),'w') as fh:
        fh.write('Library rules renamed/classified: %d (%s)\n'%(len(renames),', '.join('%s %d'%(k,c[k]) for k in PHASES)))
        fh.write('Phase is derived from the rule body: propose = adds an operator with +; compare = other operator preferences;\n  apply = tests the selected operator (o-support) or halts; elaborate = everything else.\n')
        fh.write('Rules whose old name used a different phase word than the body shows (%d), old name / name phase / body phase / file:\n'%len(dis))
        for o,a,b,f in dis: fh.write('  %s  %s -> %s  %s\n'%(o,a,b,f))
    return renames
