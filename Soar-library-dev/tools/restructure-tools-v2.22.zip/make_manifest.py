import glob, os, json, csv, collections, re, sys
from chunker import segment
import manifest_spec as S

def file_dest(rel):
    proj_old=S.project_of(rel); sp=S.strip_proj(rel)
    if rel=='default-world/simple.soar': dp,dpath='soar-base','simple.soar'
    elif rel in S.SETTINGS_FILES: dp,dpath='soar-base',S.SETTINGS_FILES[rel]
    elif S.any_re(S.OBJECT_WORLD_FILES,rel): dp,dpath='object-world',sp
    elif S.any_re(S.EVENTS_FILES,rel): dp,dpath='agent-world','events/'+sp
    elif S.any_re(S.THOR_TASKS_FILES,rel): dp,dpath='thor-tasks',sp
    elif S.any_re(S.THOR_OBJECT_WORLD_CANDIDATES,rel) and S.MOVE_CANDIDATES_TO_OBJECT_WORLD: dp,dpath='object-world','from-thor/'+sp
    elif proj_old in S.SELECTION_STRATEGY_DIRS: dp,dpath='selection-world',S.SELECTION_STRATEGY_DIRS[proj_old]+sp
    else: dp,dpath=proj_old,sp
    return dp,dpath

def plan():
    vm=S.vocab_moves()
    shadow={(f,n.split('@')[0]):(n.split('@')[1] if '@' in n else None,why) for f,n,why in S.SHADOWED}
    entries=[]   # one per segment: dict(src, kind, name, line, dest_project, dest_path, action, note)
    files=[]
    for p in sorted(glob.glob(S.ROOT+'/**/*.soar',recursive=True)):
        rel=p[len(S.ROOT)+1:]
        txt=open(p,errors='replace').read(); segs=segment(txt)
        if S.is_backup(rel):
            files.append(dict(src=rel,action='DROP-backup',dest='',note='backup/unsourced')); continue
        if rel in S.VERBATIM:
            dp,dpath=file_dest(rel); files.append(dict(src=rel,action='VERBATIM',dest=f'{dp}/{dpath}',note='copied unchanged')); continue
        if rel.endswith('.soar') and (rel in ('default-world/agent-world.soar','default-world/selection-world.soar','default-world/selection-optimal.soar','default-world/selection-iterative-deepening.soar','thor-soar.soar')):
            files.append(dict(src=rel,action='REGEN',dest='',note='project loader regenerated')); continue
        if S.is_structural_stub(rel,segs):
            files.append(dict(src=rel,action='REGEN',dest='',note='loader/hierarchy stub regenerated')); continue
        proj_old=S.project_of(rel); sp=S.strip_proj(rel); line=1; dests=collections.Counter()
        dp,dpath=file_dest(rel)
        cand = S.any_re(S.THOR_OBJECT_WORLD_CANDIDATES,rel)
        nonempty_active=False
        for s in segs:
            if s['kind']=='crule':
                entries.append(dict(src=rel,kind='crule',name=s['name'],line=line,dest_project='',dest_path='',action='REMOVE-commented-out',note='commented-out rule')); 
            elif s['kind']=='rule':
                nm=s['name']; key=(rel,nm)
                sh=shadow.get(key)
                if sh and (sh[0] is None or int(sh[0])==line):
                    entries.append(dict(src=rel,kind='rule',name=nm,line=line,dest_project='',dest_path='',action='REMOVE-shadowed',note=sh[1])); 
                elif proj_old=='selection-world' and nm in S.FIRST_SUCCESS_RULES:
                    entries.append(dict(src=rel,kind='rule',name=nm,line=line,dest_project='selection-world',dest_path=S.FIRST_SUCCESS_PATH,action='MOVE-rule',note='strategy first-success (alternative: strategies/optimal)')); nonempty_active=True
                elif key in vm and rel.startswith('default-world/agent-world/') and rel not in S.VOCAB_KEEP_FILES:
                    flat=sp.replace('/','__')
                    note='domain vocabulary (review)' if True else ''
                    entries.append(dict(src=rel,kind='rule',name=nm,line=line,dest_project='thor-soar',dest_path='from-agent-world/'+flat,action='MOVE-rule',note=note)); nonempty_active=True
                else:
                    entries.append(dict(src=rel,kind='rule',name=nm,line=line,dest_project=dp,dest_path=dpath,action='MOVE' if (dp,dpath)!=(proj_old,sp) else 'KEEP',note='candidate: object-world (kept in thor-soar pending review)' if cand and not S.MOVE_CANDIDATES_TO_OBJECT_WORLD else '')); nonempty_active=True
            elif s['kind']=='cmd' and s['name'] not in ('source','pushd','popd'):
                entries.append(dict(src=rel,kind='cmd',name=s['name'],line=line,dest_project=dp,dest_path=dpath,action='MOVE' if (dp,dpath)!=(proj_old,sp) else 'KEEP',note='')); nonempty_active=True
            line+=s['text'].count('\n')
        if not nonempty_active:
            files.append(dict(src=rel,action='DOC' if any(l.strip() for s in segs if s['kind']=='text' for l in s['text'].splitlines()) else 'DROP-empty',dest='',note='no active content left (comments only / only commented-out rules)'))
        else:
            files.append(dict(src=rel,action='FILE',dest=f'{dp}/{dpath}',note=''))
    return entries,files

if __name__=='__main__':
    entries,files=plan()
    act=collections.Counter((e['action']) for e in entries if e['kind'] in('rule','crule'))
    print(act)
    rules=[e for e in entries if e['kind']=='rule']
    print('active rules',len(rules),'expected 1337')
    out=sys.argv[1] if len(sys.argv)>1 else '.'
    os.makedirs(out,exist_ok=True)
    with open(out+'/manifest-rules.csv','w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=['src','kind','name','line','action','dest_project','dest_path','note']); w.writeheader()
        for e in entries: w.writerow(e)
    json.dump(dict(entries=entries,files=files),open(out+'/manifest.json','w'),indent=1)
    # per-destination summary
    dest=collections.defaultdict(collections.Counter)
    for e in rules:
        if e['dest_project']: dest[e['dest_project']][e['dest_path']]+=1
    for pj,c in dest.items(): print(pj,sum(c.values()),'rules in',len(c),'files')
