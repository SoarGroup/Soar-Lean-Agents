"""New library files written by build.py (path under the new tree -> text). All rules are :default.
Flags convention: each project owns the flags it reads and gives each a default here. A task or personal file overrides a flag by creating
(<s> ^flag-override <o>) (<o> ^<flag> <value>) on the top state; one generic rule copies the override into ^flags. Tasks do not create ^flags."""

def _default(project, flag, value, note):
    return f'''
## {note}
sp {{{project}*elaborate*flags*default*{flag}
   :default
   (state <s> ^superstate nil
              ^flags <f>
             -^flag-override.{flag} <any>)
-->
   (<f> ^{flag} {value})
}}
'''

def _file(title, project, flags):
    return f'''## {title}
## Defaults for the flags that {project} rules read. Override from a task or personal file with
##   (<s> ^flag-override <o>)  (<o> ^<flag> <value>)
## Flags live on the top state and are not changed in substates (agent-world copies the pointer down).
''' + ''.join(_default(project, f, v, n) for f, v, n in flags)

NEW_FILES = {
 'agent-world/_flags.soar': '''## agent-world flags
## The flags convention. Each project owns the flags it reads and sets their defaults in its own _flags file; a task or personal
## file overrides a flag by creating, on the top state,
##   (<s> ^flag-override <o>)  (<o> ^<flag> <value>)
## and the generic rule below copies each override into ^flags. Tasks do not create ^flags themselves.
## Flags live on the top state and are not changed in substates (elaborate*substate*flags copies the pointer down).

sp {agent-world*elaborate*top-state*flags
   :default
   (state <s> ^superstate nil)
-->
   (<s> ^flags <f>)
}

sp {agent-world*elaborate*flags*override
   :default
   (state <s> ^superstate nil
              ^flags <f>
              ^flag-override.<flag> <value>)
-->
   (<f> ^<flag> <value>)
}
''' + ''.join(_default('agent-world', f, v, n) for f, v, n in [
   ('desired-preferences', 'false', 'true: uses the desired preferences in operator desireds (search control).'),
   ('gps-desired-ordering', 'false', 'true: preferences rank desireds, like the table of connections in GPS.'),
   ('rl', 'false', 'true: reinforcement learning (reward elaboration).'),
   ('use-timers', 'false', 'true: iterative deepening also stops on elapsed time.'),
   ('smem-store', 'false', 'true: store class structures in smem when a desired is achieved.'),
   ('explore', 'false', 'true: explore the room for objects.')]),
 'selection-world/_flags.soar': _file('selection-world flags', 'selection-world', [
   ('verify', 'false', 'true: verify look-ahead evaluations (maximum depth 10).'),
   ('guardrails', 'false', 'true: guardrail checks in look-ahead.'),
   ('hierarchical-properties', 'false', 'true is problematic: reachable desireds are always achieved in look-ahead.')]),
 'selection-world/strategies/iterative-deepening/_flags.soar': _file('iterative-deepening flags', 'selection-world', [
   ('iterative-step', 'operator', 'operator: an iterative step is a task operator; tie-impasse: it is a tie impasse.'),
   ('init-evaluation-depth', 'one', 'one: start at depth 1; unachieved-desireds: start at the number of unachieved desireds.')]),
}
