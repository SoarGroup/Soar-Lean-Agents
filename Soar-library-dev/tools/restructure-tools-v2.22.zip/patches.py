"""Content fixes applied by build.py after the move (so the move stays pure and every fix is listed).
Each patch: (file under the new tree, exact old text, new text, id, description). The build fails if old text is not found exactly once."""
PATCHES=[
 ('agent-world/elaborations/achieved-desireds.soar',
  '^achieved <desired1> { < <desired> <desired2> } { < <desired2> < <desired1> <desired3> })',
  '^achieved <desired1> { < <desired1> <desired2> } { < <desired2> < <desired1> <desired3> })',
  'P-001','agent-world*elaborate*desired-count3*achieved-3 tested the unbound variable <desired> instead of <desired1>, so it matched with only two achieved desireds and reported success early (Blocks World false success).')
 ,('thor-soar/elaborations/flags-initialization.soar',
  '(<flags> ^attend-all false                 # All objects in the scene are attended and populate the world. True is not recommended.\n            ',
  '(<flags> ',
  'P-002','Removed the attend-all flag from the Thor flag initialization (P-003 deletes its only rule).')
 ,('selection-world/Operator_Tie/evaluate-operator/elaborations.soar',
  '## No need to copy as will never be destroyed or modified. Can use original',
  "## Copy any relation the task declares: (<problem-space> ^copy-relation <name>) on the task's problem space.\n## (P-004) Relations are copied by name; on, above, in are always copied by the rules above. Do not declare derived relations\n## (those the task elaborates on the world in every state): they are recomputed in the look-ahead world and a copy would go stale.\nsp {evaluate-operator*elaborate*default-state-copy-relation*declared\n   :default\n   (state <s> ^deep-copy-world true\n              ^world <new-world>\n              ^superstate.operator.super-problem-space.copy-relation <relation>)\n   (<new-world> ^duplicate-of <old-world>\n                ^objects.object <on-new> <object-new>)\n   (<on-new> ^object-handle <location-handle>)\n   (<object-new> ^object-handle <object-handle>)\n   (<old-world> ^<relation> <relation-object>)\n   (<relation-object> ^argument2 <cl-object>\n                      ^argument1 <object-value>)\n   (<cl-object> ^object-handle <location-handle>)\n   (<object-value> ^object-handle <object-handle>)\n-->\n   (<new-world> ^<relation> <new-relation-object>)\n   (<new-relation-object> ^duplicate-of <relation-object>\n                          ^argument2 <on-new>\n                          ^argument1 <object-new>)\n}\n\n## No need to copy as will never be destroyed or modified. Can use original",
  'P-004','Look-ahead world copies: relations the task declares with ^copy-relation on its problem space are copied (on/above/in are still always copied). Replaces per-task copy rules.'),
 ('agent-world/Impasse__Operator_Tie/evaluate-operator/elaborations.soar',
  '^{ << on in controlled-by above >> <relation> } <value>)',
  '^<relation> <value>)',
  'P-005','Look-ahead desireds: any relation-shaped desired value (argument1.object-handle and argument2.object-handle) is copied, not only on/in/controlled-by/above.')
 ,('thor-soar/elaborations/flags-initialization.soar',
  '   (<s> ^flags <flags>)\n   (<flags> ^forget-unattended false',
  '   (<s> ^flag-override <flags>)\n   (<flags> ^forget-unattended false',
  'P-007','Thor flag initialization now creates ^flag-override (copied into ^flags by agent-world) instead of ^flags itself.')
 ,('thor-soar/elaborations/flags-initialization.soar',
  "            ^look-ahead-planning true         # Whether use look-ahead-planning (selection space) or random selection. Not kept up to date. Always true.\n",
  '',
  'P-009','Retired the look-ahead-planning flag (always true): removed from the Thor flag initialization.')
 ,('thor-soar/elaborations/flags-initialization.soar',
  "^forget-unattended false          # If something is unattended, forget it. Haven't tested true much.\n            ",
  '',
  'P-010','Retired the forget-unattended flag (always false): removed from the Thor flag initialization.')
]

# Files deleted after the move: (file under the new tree, id, description, rule names removed)
REMOVE_FILES=[
 ('object-world/elaborations/attend-all.soar','P-003',
  'Removed the attend-all flag: its only rule (agent-world*elaborate*state*attend*all-object, which attended every input-link object when ^flags.attend-all was true) is deleted. No rule tested the flag false.',
  ['agent-world*elaborate*state*attend*all-object']),
 ('thor-soar/elaborations/random-operator-selection.soar','P-009',
  'Retired the look-ahead-planning flag (always true): the only rule that tested it false (thor-soar*select*operator, random operator selection) is deleted. No library rule tested the flag.',
  ['thor-soar*select*operator']),
 ('object-world/remove-object.soar','P-010',
  'Retired the forget-unattended flag (always false): the remove-object operator was proposed only when it was true, so its proposal, preference and three application rules are deleted.',
  ['agent-world*propose*remove-object','agent-world*compare*remove-object','apply*remove-object','apply*remove-object*in','apply*remove-object*in*argument2']),
 ('thor-soar/from-agent-world/remove-object.soar','P-010',
  'Retired the forget-unattended flag: the Thor proposal of remove-object (agent-world*propose*remove-object*not-desired*hack) tested it true and is deleted.',
  ['agent-world*propose*remove-object*not-desired*hack']),
]

# Flags removed from the libraries (their rules/initialization are removed by the patches above); filtered from datamaps and readmes.
REMOVED_FLAGS=['attend-all','look-ahead-planning','forget-unattended','use-timers']

# Rules added by patches (verify.py expects them as the only gained rules).
import re as _re2, newfiles as _nf
ADDED_RULES=['evaluate-operator*elaborate*default-state-copy-relation*declared']+[m for t in _nf.NEW_FILES.values() for m in _re2.findall(r'sp \{([^\s}]+)',t)]
# Thor flag initialization creates ^flag-override instead of ^flags (P-007 flags convention).

# Text substitutions applied to every rule file after the move (regex, replacement, id, description). The agent-world problem-space
# attribute is deprecated: every task now has the world structure, so rules no longer test it and tasks no longer set it.
import re as _re
TEXT_SUBS=[
 (r'(\(<problem-space> )\^agent-world true\s+', r'\1'),
 (r'\s*\^problem-space\.agent-world true', ''),
 (r'\s*\^agent-world true', ''),
]
TEXT_SUBS_ID='P-006'
TEXT_SUBS_DESC='Deprecated ^problem-space.agent-world: rules no longer test it (31 rules), Thor no longer sets it. All tasks use the agent-world structure.'
def apply_text_subs(t):
    n=0
    for rx,rep in TEXT_SUBS:
        t,k=_re.subn(rx,rep,t); n+=k
    return t,n

# Single rules deleted after the move: (file, rule name as in that file before the cleanup, id, description).
# Both are exact duplicates that Soar already ignores when loading (the load log says "Ignoring ... because it is a duplicate of ..."),
# so deleting them cannot change behavior.
REMOVE_RULES=[
 ('agent-world/elaborations/_all.soar','elaborate*substate*top-state','P-011',
  'Duplicate of soar-base elaborate*state*top-state (same body); Soar ignored it. Deleted.'),
 ('thor-soar/elaborations/mobile.soar','elaborations*elaborate*state*mobile*true2','P-011',
  'Duplicate of elaborations*elaborate*state*mobile*true1 (same body); Soar ignored it. Deleted.'),
]
