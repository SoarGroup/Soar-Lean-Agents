import os, json, csv, collections, re
from chunker import segment
BASELINE='/home/claude/out-gh/step0/lint-baseline-step0.json'
LAYERS=['soar-base','selection-world','agent-world','object-world','thor-soar','thor-tasks']
PURPOSE={
 'soar-base':'Architecture settings and the simple default productions that every other project relies on. No task, selection or world knowledge.',
 'selection-world':'Operator selection by look-ahead. When operators tie, an evaluation substate applies each candidate (in a copy of the state) and compares the outcomes; the project supplies the evaluation machinery and the strategies that decide how deep and how to prefer outcomes. Task independent: it only needs ^desireds on the state and task operators marked ^task-operator.',
 'agent-world':'The desired-state machinery. A task creates a ^world and ^desireds; this project detects when desireds are achieved, proposes/applies the generic operators around them (output to an environment or internal application), halts on success, and supports look-ahead by copying the world into substates. Optionally also time and future events (events/).',
 'object-world':'Objects in the world. Finding and grounding objects named by handle (find-object, find-object-direct), anchoring, removing objects, scene/world context and storing objects in semantic memory. Used by tasks that have an object-handle world; the desired-state machinery does not need it.',
 'thor-soar':'The Thor-Soar kitchen agent for AI2-THOR: its operators (go-to, pick up/put, open/close, cook, clean, slice ...), scene and anchor memory handling, exploration and room scanning, Thor vocabulary and Thor-specific settings (epmem, svs, rl, chunking). Needs the external environment; cannot be run stand-alone.',
 'thor-tasks':'The Thor task definitions: for each named task, the ^desireds that define it (single action, double action with/without ordering, temporal, sequences, disjunctive).'}
REQUIRES={'soar-base':[], 'selection-world':['soar-base'], 'agent-world':['soar-base','selection-world'],
 'object-world':['soar-base','selection-world','agent-world'],'thor-soar':['soar-base','selection-world','agent-world','object-world'],'thor-tasks':['thor-soar']}
DESC={
 'soar-base':{'simple.soar':'Simple default productions for Soar 9 (substate io pointer, top-state elaborations, no-change handling, conflict rejection).','settings/agent-world-settings.soar':'Commands, not rules: production optimize-attribute hints, limits (max-elaborations, goal depth), aliases, srand, wma.'},
 'selection-world':{
  'strategies/iterative-deepening/_flags.soar':'Defaults for the iterative-deepening flags (iterative-step, init-evaluation-depth).',
  '_flags.soar':'Defaults for the flags the selection rules read (verify, guardrails, hierarchical-properties).',
  'elaborations/top-state.soar':'Halting the top-level goal with success or failure (top-goal*halt*...), including the desireds-count test.',
  'Operator_Tie/elaborations.soar':'Selection problem space: creating evaluation operators for tied operators, comparing evaluations (success > partial success > ...), turning evaluations into preferences.',
  'Operator_Tie/evaluate-operator.soar':'The evaluate-operator operator: proposed per tied operator, creates the evaluation when selected.',
  'Operator_Tie/evaluate-operator/elaborations.soar':'Evaluation substate: copies the state, desireds and world into the substate, applies the evaluated operator, detects success/failure and reports it.',
  'Operator_Tie/evaluate-operator/task-operator.soar':'Applying the task operator being evaluated inside the evaluation substate.',
  'Operator_Tie/Impasse__State_No-Change/elaborations.soar':'Conflict rejection in the selection space (default*select*reject*conflict).',
  'strategies/':'Strategies for how look-ahead proceeds and how outcomes are preferred (see below).',
  'strategies/iterative-deepening/':'Iterative-deepening look-ahead: evaluate to depth 1, 2, ... up to ^max-evaluation-depth, counting remaining operators and failures. Default.',
  'strategies/first-success/':'Default outcome preference (3 rules): the first success is as good as any other.',
  'strategies/optimal/':'Alternative to first-success (untested): prefer the shallowest success and make selection wait for all evaluations.'},
 'agent-world':{
  '_flags.soar':'Flags convention: creates ^flags, copies ^flag-override values into it, and gives defaults to the flags agent-world reads.',
  'initialize-agent-world.soar':'Operator that creates the ^world structure and agent-world state; a task\'s own initialize-<task> operator follows it.',
  'external-operator-application.soar':'Turns a selected task operator into an output-link perform-action command and records completion. Contains Thor-specific action cases; to be redesigned (action table).',
  'force-conflict.soar':'Proposes a force-conflict operator at the top state so a constraint failure surfaces as an operator conflict; selecting it means something went wrong.',
  'goal-completed.soar':'Marks the task achieved, logs it, reports success on the output link in testing mode, interrupts on a no-change wait when desireds come from elaborations.',
  'goal-completed/clean-up-topstate.soar':'Removes desireds and learning events and marks the segment satisfied when desireds come from language.',
  'generic-operator/elaborations.soar':'Elaborates an operator-implementation substate with the super-operator attributes, including the name.',
  'generic-operator/failure.soar':'Failure handling for generic operators.',
  'Impasse__Operator_Conflict/elaborations.soar':'Operator conflict impasse handling.',
  'Impasse__Operator_Tie/elaborations.soar':'Tie impasse: forcing ties among agent-world operators, constraint-failure handling.',
  'Impasse__Operator_Tie/evaluate-operator.soar':'Agent-world additions to the evaluate-operator operator.',
  'Impasse__Operator_Tie/evaluate-operator/elaborations.soar':'Adapters between agent-world operators and selection-world evaluation (what to copy, how achievement is passed back).',
  'Impasse__Operator_Tie/evaluate-operator/cutoff-search.soar':'Search cutoff in evaluation (noted in the source as not very helpful).',
  'elaborations/_all.soar':'Elaborations for many states and substates, for example the pointer from a substate to the top state.',
  'elaborations/achieved-desireds.soar':'Detects when each desired (object properties, relations, disjunctions, abstract properties) is achieved in the world and maintains ^achieved/^unachieved.',
  'elaborations/achieved-desired-operators.soar':'The same for desireds attached to operators (^desireds on a task operator).',
  'elaborations/internal-actions.soar':'Tasks with no external environment: all operators are applied internally.',
  'elaborations/monitor-operator.soar':'Trace output for operator arguments.',
  'elaborations/output.soar':'Copies the actions structure to the output link.',
  'elaborations/problem-space.soar':'Problem-space name and agent-world flag elaborations.',
  'elaborations/reward.soar':'Reward elaborations (not updated).',
  'elaborations/search-control.soar':'Search-control preferences among operators.',
  'elaborations/super-desireds.soar':'Copies super-desireds down into substates.',
  'elaborations/time.soar':'Time elaboration.',
  'events/':'Optional time and event machinery: scheduled future events, waiting, skipping ahead and dispatching agent events. Comment the events line out of agent-world_source.soar to run without it.'},
 'object-world':{
  '_flags.soar':'Defaults for the flags object-world reads.',
  'find-object.soar':'Proposes finding an object that a desired needs but that is not grounded yet (known handle, unknown location).',
  'find-object-direct.soar':'Grounds objects by handle/class directly, including the objects of a relation, selecting as soon as the information is available.',
  'find-object/assume-successful-grounding.soar':'In look-ahead, assumes a find-object succeeds.',
  'Impasse__Operator_Tie/evaluate-operator/failed-grounding.soar':'In look-ahead, fails an evaluation when grounding fails.',
  'remove-object.soar':'Removes objects that are no longer wanted from the world.',
  'elaborations/world-context.soar':'World context: classes used to define objects in desireds.',
  'elaborations/world-from-scene.soar':'Builds world objects from the scene.',
  'elaborations/smem.soar':'Cleans up after semantic-memory retrievals.',
  'elaborations/smem-store-in.soar':'Stores in-relations in semantic memory.','elaborations/smem-store-object.soar':'Stores objects in semantic memory.','elaborations/smem-store-scene.soar':'Stores scenes in semantic memory.'},
 'thor-tasks':{
  'elaborations/desireds.soar':'Task desireds by task name (one-step and general tasks).',
  'elaborations/desireds-single.soar':'Single-action tasks; none use fixed object handles; alphabetic by operator name.',
  'elaborations/desireds-double-no-seq.soar':'Two-action tasks without ordering.','elaborations/desireds-double-seq.soar':'Two-action tasks with ordering.',
  'elaborations/desireds-double-temporal.soar':'Two-action tasks with temporal constraints.','elaborations/desireds-sequence.soar':'Longer action sequences.',
  'elaborations/desireds-disjunctive.soar':'Tasks with disjunctive desireds.'}}
THOR_GROUPS=[(r'anchor-.*','Anchoring objects from memory and the scene (epmem/smem retrieval, existing objects, object and relation classes)'),
 (r'(scene-creation|scene-update|init-scene-smem|search-smem|smem-copy-.*|update-scene-smem-object-visible|svs-extract.*|_smem-object-adds)','Scene creation and update, scene semantic memory, svs extraction'),
 (r'explore-.*|scan-room.*|search-closed-receptacles|visit-all-objects|wander','Exploration, room scanning and searching'),
 (r'go-to.*|look.*|drive|turn|turn-\d+','Movement and perception operators'),
 (r'(break|clean|cook|dirty|empty|fill|close|open|put|slice|toast|make|egg|finish|turn)-.*|discard|get-object|store|toast','Object manipulation operators (open/close, put in/on, cook, clean, slice, fill, break ...)'),
 (r'(create-object-state-desired|next-desireds|report-task-complete|initialize-thor-soar|remove-.*|find-object)','Task and desired handling, initialization, cleanup'),
 (r'external-operator-application','Thor external action application and action times')]
def rcount(p): return sum(s['kind']=='rule' for s in segment(open(p,errors='replace').read()))
def main(out):
    b=json.load(open(BASELINE)); idx={(r['file'],r['line']):r for r in b['rule_index']}
    reads=collections.defaultdict(set); writes=collections.defaultdict(set)
    for row in csv.DictReader(open(os.path.join(out,'build-provenance.csv'))):
        r=idx.get((row['source_file'],int(row['line'])))
        if r: reads[row['dest_project']]|=set(r['flags_read']); writes[row['dest_project']]|=set(r['flags_written'])
    import patches
    for k in list(reads): reads[k]-=set(patches.REMOVED_FLAGS)
    for k in list(writes): writes[k]-=set(patches.REMOVED_FLAGS)
    dm=json.load(open(os.path.join(out,'datamaps','library-datamap.json'))); V={v['id']:v for v in dm['vertices']}
    for li,proj in enumerate(LAYERS):
        base=os.path.join(out,proj)
        if not os.path.isdir(base): continue
        top=sorted({e['name'] for e in V[dm['rootId']]['outEdges'] if e.get('layer')==li})
        files=[]
        for dp,dn,fn in sorted(os.walk(base)):
            if '/docs' in dp or os.path.basename(dp)=='docs': continue
            for f in sorted(fn):
                if f.endswith('_source.soar') or f=='_readme.soar' or not f.endswith('.soar'): continue
                n=rcount(os.path.join(dp,f))
                if n: files.append((os.path.relpath(os.path.join(dp,f),base),n))
        L=[f'# {proj}','#']
        L+=['# '+x for x in re.findall(r'.{1,110}(?:\s|$)',PURPOSE[proj])]
        L+=['#','# Requires: '+(', '.join(REQUIRES[proj]) or 'nothing')+'.','# Loaded by: '+('soar-library.soar' if proj in('soar-base','selection-world','agent-world','object-world') else 'thor.soar'),'#','# Contents (rules per file)']
        d=DESC.get(proj,{})
        if proj=='thor-soar':
            used=set()
            for pat,label in THOR_GROUPS:
                m=[(f,n) for f,n in files if f not in used and re.fullmatch(pat,os.path.basename(f)[:-5]) and 'elaborations/' not in f and not f.startswith('from-agent-world')]
                if m: L.append(f'#   {sum(n for f,n in m):4d}  {label}: '+', '.join(os.path.basename(f)[:-5] for f,n in m)); used|={f for f,n in m}
            for key,label in (('elaborations/','elaborations/: Thor state vocabulary (properties such as accessible, reachable, holding), achieved-desireds, search control, flags initialization, svs, world-from-scene'),('Impasse__Operator_Tie','Impasse__Operator_Tie/: Thor tie handling and constraint-failure detection'),('from-agent-world/','from-agent-world/: rules moved out of agent-world because they mention Thor vocabulary (to be reviewed)')):
                m=[(f,n) for f,n in files if f.startswith(key) and f not in used]
                if m: L.append(f'#   {sum(n for f,n in m):4d}  {label}'); used|={f for f,n in m}
            rest=[(f,n) for f,n in files if f not in used]
            if rest: L.append(f'#   {sum(n for f,n in rest):4d}  other: '+', '.join(f for f,n in rest))
        else:
            grouped=collections.defaultdict(int)
            for f,n in files:
                key=next((k for k in d if k.endswith('/') and f.startswith(k)),None)
                if key: grouped[key]+=n
                else: L.append(f'#   {n:4d}  {f}'+(': '+d[f] if f in d else ''))
            for k,n in grouped.items(): L.append(f'#   {n:4d}  {k}: {d[k]}')
        if proj=='selection-world':
            L+=['#','# Strategies: strategies/strategies_source.soar sources iterative-deepening and first-success. To try the','# alternative, comment first-success out and the optimal lines in (never both: they define the same rules).']
        if proj=='agent-world': L+=['#','# Events: events/ is sourced by agent-world_source.soar behind a comment; remove it to run without time/events.']
        if proj=='soar-base': L+=['#','# Settings are commands, so they cannot carry :default and are not rules.']
        if proj=='thor-soar': L+=['#','# _firstload.soar sources ../../agent/thor-soar-semantic-memory.soar, which is not part of this tree (as before).','# Thor-specific flags and architecture settings live in _flags/ (epmem, svs, rl, chunking, decay).']
        L+=['#','# Datamap','#   %s.vsa.json holds this project\'s state attributes plus those of the projects it requires.'%proj,
            '#   Top-state attributes owned by this project: '+(', '.join('^'+t for t in top) if top else '(none)'),
            '#   Single source: datamaps/library-datamap.json (each edge tagged with its owning project). Regenerate the','#   project files with: python3 tools/datamaps.py <this-directory> --assemble','#',
            '# Flags read: '+(', '.join(sorted(reads[proj])) or '(none recorded)'),'# Flags written: '+(', '.join(sorted(writes[proj])) or '(none recorded)'),
            '# Hooks: not yet defined (see the refactoring proposal, Section 4); this file will list them.',
            '# Conventions: every rule is :default; no rule name is defined twice among the sourced files; do not excise rules to override them.','# Notes: docs/ holds comment-only notes from the old projects (not sourced).','','# generated by build.py']
        open(os.path.join(base,'_readme.soar'),'w').write('\n'.join(L)+'\n')
if __name__=='__main__':
    import sys; main(sys.argv[1])
