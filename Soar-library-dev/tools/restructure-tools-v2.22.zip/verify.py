import os, re, sys, glob, json, collections
from chunker import segment
import manifest_spec as S
def norm(t):
    t=re.sub(r':default','',t); return re.sub(r'\s+',' ',t).strip()
def rules_of(root,pat):
    res=[]
    for p in glob.glob(root+pat,recursive=True):
        if '~' in p or '/docs/' in p: continue
        for s in segment(open(p,errors='replace').read()):
            if s['kind']=='rule': res.append((s['name'],norm(s['text']),p))
    return res
def simulate(out,loader):
    visited=set(); missing=[]
    def run(path,cwd):
        stack=[cwd]
        for line in open(path):
            l=line.strip()
            if not l or l.startswith('#'): continue
            parts=l.split(None,1)
            if parts[0]=='pushd': stack.append(os.path.normpath(os.path.join(stack[-1],parts[1].strip('"'))))
            elif parts[0]=='popd': stack.pop()
            elif parts[0]=='source':
                f=os.path.normpath(os.path.join(stack[-1],parts[1].strip('"')))
                if os.path.exists(f): visited.add(f); run(f,stack[-1])
                else: missing.append((path,parts[1]))
    for ld in loader: run(os.path.join(out,ld),out)
    return visited,missing
def main(out):
    import patches
    old=rules_of(S.ROOT,'/**/*.soar'); new=rules_of(out,'/**/*.soar')
    for f,o,n,pid,d in patches.PATCHES: old=[(a,norm(b).replace(norm(o),norm(n)) ,c) for a,b,c in old]
    old=[(a,norm(patches.apply_text_subs(b)[0]),c) for a,b,c in old]
    import csv
    rm=os.path.join(out,'rule-renames.csv')
    if os.path.exists(rm):
        mp={r['old_name']:r['new_name'] for r in csv.DictReader(open(rm))}
        def ren(a,b):
            n=mp.get(a,a); return n,b.replace(a,n,1)
        old=[ren(a,b)+(c,) for a,b,c in old]
        patches.ADDED_RULES=set(mp.get(x,x) for x in patches.ADDED_RULES)
    ok=True
    removed={(n) for f,n,w in S.SHADOWED}|{n for *_,rs in patches.REMOVE_FILES for n in rs}
    oc=collections.Counter((n,b) for n,b,p in old); nc=collections.Counter((n,b) for n,b,p in new)
    lost=oc-nc; gained=nc-oc
    print('old active rules',len(old),'new',len(new),'| lost (expected 4 shadowed):',sum(lost.values()),'| gained:',sum(gained.values()))
    for (n,b),c in lost.items(): print('   lost',n)
    for (n,b),c in gained.items():
        if n in patches.ADDED_RULES: print('   added by patch',n)
        else: print('   GAINED',n); ok=False
    names=collections.Counter(n for n,b,p in new); d=[n for n,c in names.items() if c>1]
    print('duplicate names in new tree:',len(d),d[:5])
    vis,missing=simulate(out,['soar-library.soar','thor.soar'])
    allf={p for p in glob.glob(out+'/**/*.soar',recursive=True) if '/docs/' not in p and p.count('/')>=0}
    top={os.path.join(out,x) for x in ('soar-library.soar','thor.soar')}|{p for p in allf if os.path.dirname(p)==out}
    sn=collections.Counter()
    for p in vis:
        for x in segment(open(p,errors='replace').read()):
            if x['kind']=='rule': sn[x['name']]+=1
    print('rules reachable from the loaders:',sum(sn.values()),'| duplicate names among them:',[n for n,c in sn.items() if c>1])
    unsourced=sorted(p[len(out)+1:] for p in allf-vis-top)
    print('sourced files',len(vis),'| unsourced',len(unsourced),unsourced[:8],'| missing sourced files',missing)
    return ok and not [n for n,c in sn.items() if c>1]
if __name__=='__main__': sys.exit(0 if main(sys.argv[1]) else 1)
