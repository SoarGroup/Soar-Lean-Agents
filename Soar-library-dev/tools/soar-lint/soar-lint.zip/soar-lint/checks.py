import os, re, collections, json
from soar_lint import norm_sig, attrs_of, flag_use, ps_gate, read_datamap

def top(c,n=15): return [list(x) for x in c.most_common(n)]

def all_checks(cfg,root,rules,commented,cmds,files_all,loaded,problems):
    names=[p['name'] for p in cfg['projects']]; layer={p['name']:p['layer'] for p in cfg['projects']}
    libs=set(cfg['library_projects'])
    abs_loaded={pr:[os.path.relpath(f,root) for f in fs] for pr,fs in loaded.items()}
    file_idx={pr:{f:i for i,f in enumerate(fs)} for pr,fs in abs_loaded.items()}
    order={n:i for i,n in enumerate(names)}
    for r in rules:
        r['loaded']=r['file'] in file_idx[r['project']]
        r['load_key']=(order[r['project']], file_idx[r['project']].get(r['file'],10**6), r['line'])
        r['sig']=norm_sig(r)
        r['default']=':default' in r['opts']
        from soar_lint import bound_vars
        fv=bound_vars(r['lhs']+' '+r['rhs'],'flags')
        r['flags_read']=sorted(flag_use(r['lhs'],fv)); r['flags_written']=sorted(flag_use(r['rhs'],fv))
        r['gate']=sorted(ps_gate(r['lhs']))
        r['attrs']=sorted(attrs_of(r['lhs']+' '+r['rhs']))
        r['prefix']=r['name'].split('*')[0]
    rep=dict(summary={},details={})
    S=rep['summary']; D=rep['details']
    # --- 1 inventory
    inv={}
    for n in names:
        rs=[r for r in rules if r['project']==n]
        cm=[c for c in commented if c['project']==n]
        fl=files_all.get(n,[]); fl=[os.path.relpath(f,root) if os.path.isabs(f) else f for f in fl]
        with_rules=set(r['file'] for r in rs)
        unsourced=[f for f in fl if f not in file_idx[n]]
        inv[n]=dict(active_rules=len(rs),generator_rules_gp=sum(1 for r in rs if r['kind']=='gp'),default_rules=sum(r['default'] for r in rs),commented_rules=len(cm),
                    soar_files=len(fl),files_with_rules=len(with_rules),
                    unsourced_files=len(unsourced),unsourced_files_with_rules=sorted(f for f in unsourced if f in with_rules),
                    rules_in_unsourced_files=sum(1 for r in rs if not r['loaded']))
    S['inventory']={n:{k:v for k,v in d.items() if isinstance(v,int)} for n,d in inv.items()}
    S['inventory_total']=dict(active_rules=len(rules),commented_rules=len(commented))
    D['inventory']=inv
    D['unsourced_files']={n:sorted(f for f in [os.path.relpath(x,root) if os.path.isabs(x) else x for x in files_all.get(n,[])] if f not in file_idx[n]) for n in names}
    D['backup_files']=sorted(files_all.get('__backup__',[]))+sorted(set(os.path.dirname(f) for fs in files_all.values() for f in [os.path.relpath(x,root) if os.path.isabs(x) else x for x in fs] if os.path.dirname(f).endswith('~')))
    S['backup_files']=len(D['backup_files'])
    D['sourcing_problems']=problems; S['sourcing_problems']=len(problems)
    # files sourced more than once
    dup_src=[]
    for pr,fs in abs_loaded.items():
        for f,c in collections.Counter(fs).items():
            if c>1: dup_src.append(dict(project=pr,file=f,times=c))
    D['files_sourced_twice']=dup_src; S['files_sourced_twice']=len(dup_src)
    # --- 2 same-name
    g=collections.defaultdict(list)
    for r in rules: g[r['name']].append(r)
    same=[]
    for nm,l in g.items():
        if len(l)<2: continue
        ld=[x for x in l if x['loaded']]
        win=max(ld,key=lambda x:x['load_key']) if ld else None
        scope='same-file' if len({x['file'] for x in l})==1 else ('same-project' if len({x['project'] for x in l})==1 else 'cross-project')
        same.append(dict(name=nm,scope=scope,identical=len({x['sig'] for x in l})==1,
            defs=[dict(project=x['project'],file=x['file'],line=x['line'],loaded=x['loaded'],default=x['default']) for x in sorted(l,key=lambda x:x['load_key'])],
            winner=(win['project']+':'+win['file']) if win else None))
    same.sort(key=lambda d:(d['scope'],d['name']))
    D['same_name_rules']=same
    S['same_name']=dict(total=len(same),**{k:sum(1 for d in same if d['scope']==k) for k in ('same-file','same-project','cross-project')},
                        identical_bodies=sum(1 for d in same if d['identical']))
    # --- 3 excise
    ex=[]
    defined={r['name']:r['project'] for r in rules}
    for c in cmds:
        if c['cmd']=='excise':
            tgt=c['args'].split()[0] if c['args'] else ''
            ex.append(dict(project=c['project'],file=c['file'],line=c['line'],target=tgt,commented=bool(c.get('commented')),target_defined_in=defined.get(tgt)))
    for c in commented: pass
    D['excise']=ex; S['excise']=dict(active=sum(1 for e in ex if not e['commented']),commented=sum(1 for e in ex if e['commented']))
    # --- 4 prefixes
    pre={}
    for n in names:
        c=collections.Counter(r['prefix'] for r in rules if r['project']==n); pre[n]=top(c,12)
    D['prefix_histogram']=pre
    cross=[dict(project=r['project'],file=r['file'],name=r['name']) for r in rules if r['prefix'] in names and r['prefix']!=r['project']]
    # also treat 'agent-world'/'thor-soar'/'selection' prefixes as ownership: selection-* projects use 'selection'
    owner={'agent-world':'agent-world','thor-soar':'thor-soar'}
    cross=[dict(project=r['project'],file=r['file'],name=r['name'],prefix=r['prefix']) for r in rules if r['prefix'] in owner and owner[r['prefix']]!=r['project']]
    D['prefix_cross_project']=cross; S['prefix_cross_project']=len(cross)
    S['prefix_distinct']={n:len({r['prefix'] for r in rules if r['project']==n}) for n in names}
    # --- 5 flags
    fl=collections.defaultdict(lambda:dict(read=collections.Counter(),written=collections.Counter(),written_files=collections.Counter()))
    for r in rules:
        for f in r['flags_read']: fl[f]['read'][r['project']]+=1
        for f in r['flags_written']: fl[f]['written'][r['project']]+=1; fl[f]['written_files'][r['file']]+=1
    fr=[]
    for f,d in sorted(fl.items()):
        rl=[layer[p] for p in d['read']]; wl=[layer[p] for p in d['written']]
        issue=[]
        if d['read'] and not d['written']: issue.append('read-never-initialized')
        if d['written'] and not d['read']: issue.append('initialized-never-read')
        if d['read'] and d['written'] and min(rl)<min(wl): issue.append('read-below-initializer')
        fr.append(dict(flag=f,read=dict(d['read']),read_total=sum(d['read'].values()),written=dict(d['written']),written_files=dict(d['written_files']),issues=issue))
    D['flags']=fr
    S['flags']=dict(distinct=len(fr),read_never_initialized=sum('read-never-initialized' in x['issues'] for x in fr),
        initialized_never_read=sum('initialized-never-read' in x['issues'] for x in fr),read_below_initializer=sum('read-below-initializer' in x['issues'] for x in fr))
    # --- 6 gating
    gate={}
    for n in names:
        rs=[r for r in rules if r['project']==n]; c=collections.Counter()
        for r in rs:
            for x in r['gate']: c[x]+=1
        gate[n]=dict(rules=len(rs),with_problem_space_test=sum(1 for r in rs if r['gate']),mention_problem_space=sum(1 for r in rs if 'problem-space' in r['lhs']+r['rhs']),gates=top(c,8))
    D['gating']=gate; S['gating']={n:dict(rules=v['rules'],with_problem_space_test=v['with_problem_space_test'],mention_problem_space=v['mention_problem_space']) for n,v in gate.items()}
    # --- 7 vocabulary in libraries
    def hits(txt,words):
        return sorted(w for w in words if re.search(r'(?<![A-Za-z0-9_])'+re.escape(w)+r'(?![A-Za-z0-9_])',txt))
    voc={}; vocx={}
    for r in rules:
        if r['project'] not in libs: continue
        h=hits(r['name']+' '+r['lhs']+' '+r['rhs'],cfg['domain_vocabulary'])
        if h: voc.setdefault(r['project'],[]).append(dict(name=r['name'],file=r['file'],words=h))
        else:
            hx=hits(r['lhs']+' '+r['rhs'],cfg['domain_vocabulary_extended'])
            if hx: vocx.setdefault(r['project'],[]).append(dict(name=r['name'],file=r['file'],words=hx))
    D['domain_vocabulary_hits']=voc; D['domain_vocabulary_weak_hits']=vocx
    S['domain_vocabulary']={n:len(voc.get(n,[])) for n in libs}
    S['domain_vocabulary_weak']={n:len(vocx.get(n,[])) for n in libs}
    # --- 8 exact duplicates (different names)
    gs=collections.defaultdict(list)
    for r in rules: gs[r['sig']].append(r)
    dups=[]
    for s,l in gs.items():
        if len({x['name'] for x in l})>1:
            dups.append(dict(rules=[dict(project=x['project'],file=x['file'],name=x['name']) for x in l]))
    D['identical_bodies_different_names']=dups; S['identical_bodies_different_names']=len(dups)
    # --- 9 architecture settings & other top-level commands
    st=collections.defaultdict(list)
    for c in cmds:
        if c['cmd'] in ('source','pushd','popd') or c.get('commented'): continue
        st[c['project']].append(dict(cmd=c['cmd'],args=c['args'][:80],file=c['file'],line=c['line']))
    D['top_level_commands']=st; S['top_level_commands']={n:len(v) for n,v in st.items()}
    # --- 10 datamaps
    dms={}
    for p in cfg['projects']:
        if not p['datamap']: dms[p['name']]=None; continue
        dms[p['name']]=read_datamap(os.path.join(root,p['datamap']))
    used={n:set() for n in names}
    for r in rules: used[r['project']]|=set(r['attrs'])
    dm_out={}
    for n in names:
        d=dms[n]
        if d is None: dm_out[n]=dict(format=None); continue
        dm_out[n]=dict(format=d['format'],vertices=d['vertices'],reachable=d['reachable'],unreachable=d['unreachable'],attribute_names=len(d['names']))
    D['datamaps']=dm_out
    S['datamaps']={n:{k:v for k,v in d.items() if isinstance(v,int)} for n,d in dm_out.items()}
    lowerdecl={}
    for n in names:
        s=set()
        for m in names:
            if layer[m]<=layer[n] and dms[m]: s|=dms[m]['names']
        lowerdecl[n]=s
    upperdecl={n:set().union(*[dms[m]['names'] for m in names if layer[m]>layer[n] and dms[m]]) if any(layer[m]>layer[n] and dms[m] for m in names) else set() for n in names}
    ud={}
    for n in names:
        u=used[n]; und=sorted(a for a in u if a not in lowerdecl[n])
        up=[a for a in und if a in upperdecl[n]]
        none=[a for a in und if a not in upperdecl[n]]
        ud[n]=dict(attributes_used=len(u),declared_in_own_or_lower=len(u)-len(und),
                   used_declared_only_in_higher_layer=up,used_declared_nowhere=none)
    D['datamap_vs_rules']=ud
    S['datamap_vs_rules']={n:dict(used=v['attributes_used'],upward=len(v['used_declared_only_in_higher_layer']),undeclared=len(v['used_declared_nowhere'])) for n,v in ud.items()}
    allused=set().union(*used.values())
    unused={n:sorted(dms[n]['names_reachable']-allused) for n in names if dms[n]}
    D['declared_never_used_anywhere']=unused; S['declared_never_used']={n:len(v) for n,v in unused.items()}
    # drift: attribute names in a library datamap missing from thor datamap
    th=dms['thor-soar']['names'] if dms['thor-soar'] else set()
    drift={n:sorted(dms[n]['names']-th) for n in names if dms[n] and n!='thor-soar'}
    D['datamap_names_missing_in_thor']=drift; S['datamap_names_missing_in_thor']={n:len(v) for n,v in drift.items()}
    # --- commented-out rules
    active_names={r['name'] for r in rules}
    cm={}
    for n in names:
        cs=[x for x in commented if x['project']==n]
        byfile=collections.Counter(x['file'] for x in cs)
        cm[n]=dict(total=len(cs),with_active_same_name=sum(1 for x in cs if x['name'] in active_names),
                   without_active_same_name=sum(1 for x in cs if x['name'] not in active_names),top_files=top(byfile,5))
    D['commented_rules']=cm
    S['commented_rules']={n:dict(total=v['total'],without_active_same_name=v['without_active_same_name']) for n,v in cm.items()}
    # --- rule index
    rep['rule_index']=[dict(id=r['project']+'|'+r['file']+'|'+r['name']+'|'+str(r['line']),project=r['project'],file=r['file'],line=r['line'],name=r['name'],
                           default=r['default'],loaded=r['loaded'],gate=r['gate'],flags_read=r['flags_read'],flags_written=r['flags_written'],sig=r['sig']) for r in rules]
    rep['_rules']=None
    return rep
