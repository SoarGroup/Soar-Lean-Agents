import json
def tbl(rows,head):
    out=['| '+' | '.join(head)+' |','|'+'|'.join('---' for _ in head)+'|']
    for r in rows: out.append('| '+' | '.join(str(x) for x in r)+' |')
    return '\n'.join(out)
def write_md(rep,path):
    S=rep['summary']; D=rep['details']; L=[]
    L.append('# soar_lint report\n')
    L.append('Static reading of the .soar and datamap files only. Commented-out rules are not counted as active. Load order assumed: simple, selection-world, selection-optimal, selection-iterative-deepening, agent-world, thor-soar.\n')
    L.append('## 1. Inventory\n')
    rows=[]
    for n,v in D['inventory'].items(): rows.append([n,v['active_rules'],v['default_rules'],v['commented_rules'],v['soar_files'],v['files_with_rules'],v['unsourced_files']])
    rows.append(['**total**',S['inventory_total']['active_rules'],'',S['inventory_total']['commented_rules'],'','',''])
    L.append(tbl(rows,['project','active rules',':default','commented-out rules','.soar files','files with rules','unsourced files'])+'\n')
    L.append('Backup (~) files and directories: %d. Sourcing problems: %d. Generator productions (gp, each expands to several rules at load time): %d (thor-soar/elaborations/random-operator-selection.soar).\n'%(S['backup_files'],S['sourcing_problems'],sum(v['generator_rules_gp'] for v in D['inventory'].values())))
    for p in D['sourcing_problems']: L.append('- %s: `%s` sourced from `%s` does not exist in the zip\n'%(p['kind'],p['file'],p.get('sourced_from')))
    L.append('## 2. Rules defined more than once (same name)\n')
    rows=[[d['scope'],'`'+d['name']+'`','; '.join('%s:%s:%d'%(x['project'],x['file'].split('/')[-1],x['line']) for x in d['defs']),d['winner'].split(':')[0] if d['winner'] else '',('yes' if d['identical'] else 'no')] for d in D['same_name_rules']]
    L.append(tbl(rows,['scope','rule','definitions (project:file:line, in load order)','last loaded (wins)','bodies identical'])+'\n')
    L.append('## 3. excise commands\n')
    L.append(tbl([[e['project'],e['file'].split('/')[-1],e['line'],'`'+e['target']+'`','commented' if e['commented'] else 'ACTIVE',e['target_defined_in'] or 'not defined anywhere'] for e in D['excise']],['project','file','line','target','state','target defined in'])+'\n')
    L.append('## 4. Rule-name prefixes\n')
    L.append('Rules whose name starts with another project\'s prefix:\n')
    L.append(tbl([[c['project'],c['prefix'],'`'+c['name']+'`'] for c in D['prefix_cross_project']],['in project','prefix','rule'])+'\n')
    L.append('Distinct first name elements per project: '+', '.join('%s %d'%(k,v) for k,v in S['prefix_distinct'].items())+'\n')
    L.append('## 5. Flags (^flags.*)\n')
    rows=[]
    for f in D['flags']:
        rows.append([f['flag'],', '.join('%s %d'%(k,v) for k,v in f['read'].items()) or '-',', '.join('%s %d'%(k,v) for k,v in f['written'].items()) or '-',', '.join(f['issues'])])
    L.append(tbl(rows,['flag','read by (rules)','set by (rules)','issues'])+'\n')
    L.append('## 6. Problem-space gating\n')
    L.append(tbl([[n,v['rules'],v['with_problem_space_test'],v['mention_problem_space'],'; '.join('%s %d'%(g,c) for g,c in v['gates'][:4])] for n,v in D['gating'].items()],['project','rules','test a problem-space attribute','mention problem-space','most common gates'])+'\n')
    L.append('## 7. Domain vocabulary in library projects\n')
    L.append('Words: turn-on, turn-off, go-to, accessible, reachable, visible, sliced, cook-state, cookable, broken, egg, coffee, toast, cook-microwave, scan-room, thor-world (whole-word match in rule name or body).\n')
    for n,v in D['domain_vocabulary_hits'].items():
        L.append('**%s: %d rules**\n'%(n,len(v)))
        L.append(tbl([[r['file'].split('/')[-1],'`'+r['name']+'`',', '.join(r['words'])] for r in v],['file','rule','words'])+'\n')
    L.append('## 8. Identical rule bodies under different names\n')
    for d in D['identical_bodies_different_names']: L.append('- '+'; '.join('%s `%s`'%(x['project'],x['name']) for x in d['rules'])+'\n')
    L.append('## 9. Commented-out rules\n')
    L.append(tbl([[n,v['total'],v['without_active_same_name'],'; '.join('%s %d'%(f.split('/')[-1],c) for f,c in v['top_files'][:3])] for n,v in D['commented_rules'].items()],['project','commented-out','with no active rule of the same name','files with most'])+'\n')
    L.append('## 10. Top-level commands other than source/pushd/popd (settings in the loaded files)\n')
    for n,v in D['top_level_commands'].items():
        import collections
        c=collections.Counter(x['cmd'] for x in v); L.append('- **%s**: '%n+', '.join('%s %d'%(k,x) for k,x in c.most_common())+'\n')
    L.append('## 11. Datamaps against rules (attribute names only)\n')
    L.append(tbl([[n,d.get('format') or 'none',d.get('vertices',''),d.get('unreachable','') if d.get('unreachable') is not None else 'n/a'] for n,d in D['datamaps'].items()],['project','datamap format','vertices','unreachable from any state root'])+'\n')
    rows=[[n,v['attributes_used'],len(v['used_declared_only_in_higher_layer']),len(v['used_declared_nowhere'])] for n,v in D['datamap_vs_rules'].items()]
    L.append(tbl(rows,['project','attribute names used by its rules','declared only by a higher layer','declared nowhere'])+'\n')
    L.append(tbl([[n,len(v)] for n,v in D['declared_never_used_anywhere'].items()],['project','attribute names declared (reachable) but used by no rule in any project'])+'\n')
    L.append(tbl([[n,len(v),', '.join(v[:8])] for n,v in D['datamap_names_missing_in_thor'].items()],['library datamap','attribute names missing from thor-soar datamap','examples'])+'\n')
    open(path,'w').write('\n'.join(L))
