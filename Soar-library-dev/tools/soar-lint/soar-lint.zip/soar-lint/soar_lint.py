#!/usr/bin/env python3
"""soar_lint: static structure check for the Soar library stack + Thor-Soar. Step 0 of the refactoring.
Usage: soar_lint.py [--config config.json] [--out DIR] [--root DIR]
       soar_lint.py --compare old.json new.json
"""
import os, re, sys, json, hashlib, collections, argparse
from soarparse import parse_file, analyze_rule, strip_comments

VAR=re.compile(r'<[\w*-]+>')
def norm_sig(r):
    t=(' '.join(r['opts'])+' '+r['lhs']+' --> '+r['rhs'])
    m={}
    def sub(x):
        return m.setdefault(x.group(0),'<v%d>'%(len(m)+1))
    t=VAR.sub(sub,t)
    t=re.sub(r'\s+',' ',t).strip()
    return hashlib.md5(t.encode()).hexdigest()

def attrs_of(text):
    """attribute names used (dotted paths split), excluding variables"""
    out=set()
    text=re.sub(r'\|[^|]*\|','',text)   # drop |quoted strings|
    for m in re.finditer(r'-?\^([^\s()]+)',text):
        for a in m.group(1).split('.'):
            a=a.strip('{}')
            if a and not a.startswith('<') and not a.startswith('>') and a!='#':
                out.add(a)
    return out

def var_attrs(text,var):
    """attributes tested/created on identifier variable var, in (<var> ^a v ^b w) groups"""
    out=set()
    for m in re.finditer(r'\(\s*'+re.escape(var)+r'\s([^()]*(?:\([^()]*\)[^()]*)*)\)',text):
        for a in re.finditer(r'-?\^([^\s()]+)',m.group(1)):
            out.add(a.group(1).split('.')[0])
    return out

def bound_vars(text,attr):
    return set('<%s>'%m.group(1) for m in re.finditer(r'\^'+re.escape(attr)+r'\s+<([\w*-]+)>',text))

def flag_use(side,vars_=None):
    """set of flag names mentioned in this side (lhs or rhs) of a rule.
    vars_: variables bound to ^flags anywhere in the rule (so (<flags> ^x v) on the RHS counts
    even when ^flags <flags> was matched on the LHS)."""
    f=set()
    for m in re.finditer(r'\^flags\.([\w*-]+)',side): f.add(m.group(1))
    for v in (vars_ if vars_ is not None else bound_vars(side,'flags')): f|=var_attrs(side,v)
    return f

def ps_gate(lhs):
    """problem-space gate descriptors tested in LHS"""
    g=set()
    for m in re.finditer(r'\^problem-space\.name\s+([^\s)]+)',lhs): g.add('name='+m.group(1))
    for m in re.finditer(r'\^problem-space\.([\w*-]+)',lhs):
        if m.group(1)!='name': g.add(m.group(1))
    for v in bound_vars(lhs,'problem-space'):
        for m in re.finditer(r'\(\s*'+re.escape(v)+r'\s[^()]*?\^name\s+([^\s)]+)',lhs): g.add('name='+m.group(1))
        for a in var_attrs(lhs,v):
            if a!='name': g.add(a)
    return g

def load_config(path):
    return json.load(open(path))

def sourcing(cfg,root):
    """follow loaders; return per-project ordered list of sourced files, plus problems"""
    loaded={}; problems=[]; order={}
    def walk(path,cwd,proj,seq,stack):
        if not os.path.exists(path):
            problems.append(dict(kind='missing-file',project=proj,file=os.path.relpath(path,root),sourced_from=stack[-2] and os.path.relpath(stack[-2],root) if len(stack)>1 else None)); return
        seq.append(path)
        cwd=[cwd]
        for c in parse_file(path)['commands']:
            if c['commented']: continue
            a=c['args'].split()
            if c['cmd']=='pushd' and a: cwd.append(os.path.join(cwd[-1],a[0]))
            elif c['cmd']=='popd' and len(cwd)>1: cwd.pop()
            elif c['cmd']=='source' and a:
                p=os.path.normpath(os.path.join(cwd[-1],a[0]))
                if p in stack: problems.append(dict(kind='source-cycle',project=proj,file=os.path.relpath(p,root))); continue
                walk(p,cwd[-1],proj,seq,stack+[p])
    for pr in cfg['projects']:
        seq=[]
        if pr['loader']:
            lp=os.path.join(root,pr['loader']); walk(lp,os.path.dirname(lp),pr['name'],seq,[lp])
        else:
            for f in pr['files']: seq.append(os.path.join(root,f))
        loaded[pr['name']]=seq
    return loaded,problems

def project_of(cfg,root,path):
    rel=os.path.relpath(path,root)
    for pr in cfg['projects']:
        if pr['loader']:
            d=os.path.splitext(pr['loader'])[0]
            if rel.startswith(d+os.sep) or rel==pr['loader']: return pr['name']
        else:
            if rel in pr['files']: return pr['name']
    return None

def read_datamap(path):
    """return dict(names=set of attribute names, reach_stats, edges=[(src,name,dst)], vertices) from .vsa.json or .dm"""
    if path.endswith('.json'):
        d=json.load(open(path)); dm=d['datamap']; V={v['id']:v for v in dm['vertices']}
        def nodes(n):
            yield n
            for c in n.get('children',[]): yield from nodes(c)
        roots=[dm['rootId']]+[n['dmId'] for n in nodes(d['layout']) if 'dmId' in n]
        reach=set(); st=list(roots)
        while st:
            x=st.pop()
            if x in reach: continue
            reach.add(x); st+=[e['toId'] for e in V[x].get('outEdges',[])]
        names=set(e['name'] for v in V.values() for e in v.get('outEdges',[]))
        names_reach=set(e['name'] for x in reach for e in V[x].get('outEdges',[]))
        return dict(format='vsa.json',names=names,names_reachable=names_reach,vertices=len(V),reachable=len(reach),unreachable=len(V)-len(reach),V=V,roots=roots)
    names=set(); nv=0
    for l in open(path):
        t=l.split()
        if len(t)==3 and t[0].isdigit() and t[2].isdigit(): names.add(t[1])
        elif t and t[0] in ('SOAR_ID','ENUMERATION','STRING','INTEGER','FLOAT','INTEGER_RANGE','FLOAT_RANGE'): nv+=1
    return dict(format='dm',names=names,names_reachable=names,vertices=nv,reachable=None,unreachable=None)

def build(cfg,root):
    P={p['name']:p for p in cfg['projects']}
    rules=[]; commented=[]; cmds=[]; files_all=collections.defaultdict(list)
    for dp,dn,fn in os.walk(root):
        for f in sorted(fn):
            p=os.path.join(dp,f)
            if f.endswith('.soar~') : files_all['__backup__'].append(os.path.relpath(p,root)); continue
            if not f.endswith('.soar'): continue
            pr=project_of(cfg,root,p)
            if pr is None: files_all['__unassigned__'].append(os.path.relpath(p,root)); continue
            files_all[pr].append(p)
            r=parse_file(p)
            for x in r['rules']:
                x['project']=pr; x['file']=os.path.relpath(p,root); analyze_rule(x); rules.append(x)
            for x in r['commented_rules']: x['project']=pr; x['file']=os.path.relpath(p,root); commented.append(x)
            for x in r['commands']: x['project']=pr; x['file']=os.path.relpath(p,root); cmds.append(x)
    return rules,commented,cmds,files_all

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--config',default=os.path.join(os.path.dirname(__file__),'config.json'))
    ap.add_argument('--root'); ap.add_argument('--out',default='.')
    ap.add_argument('--compare',nargs=2)
    a=ap.parse_args()
    if a.compare: return compare(*a.compare)
    cfg=load_config(a.config); root=a.root or cfg['root']
    rep=run(cfg,root)
    os.makedirs(a.out,exist_ok=True)
    json.dump(rep,open(os.path.join(a.out,'lint-report.json'),'w'),indent=1,sort_keys=True)
    from report import write_md
    write_md(rep,os.path.join(a.out,'lint-report.md'))
    print('wrote',a.out)

def run(cfg,root):
    from checks import all_checks
    rules,commented,cmds,files_all=build(cfg,root)
    loaded,problems=sourcing(cfg,root)
    return all_checks(cfg,root,rules,commented,cmds,files_all,loaded,problems)

def compare(a,b):
    A=json.load(open(a)); B=json.load(open(b))
    def flat(d,pre=''):
        for k,v in d.items():
            if isinstance(v,dict): yield from flat(v,pre+k+'.')
            elif isinstance(v,(int,float)) and not isinstance(v,bool): yield pre+k,v
    fa=dict(flat(A.get('summary',{}))); fb=dict(flat(B.get('summary',{})))
    for k in sorted(set(fa)|set(fb)):
        if fa.get(k)!=fb.get(k): print('%-60s %s -> %s'%(k,fa.get(k),fb.get(k)))
    ra={r['id'] for r in A.get('rule_index',[])}; rb={r['id'] for r in B.get('rule_index',[])}
    print('rules removed',len(ra-rb),'added',len(rb-ra))

if __name__=='__main__': main()
