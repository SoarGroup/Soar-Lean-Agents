# World-convention task generators (draft)

wg.py: shared generator (initialize operator, problem space with only name + agent-world, flags on the top state, achievement rules, proposal template). `LAYOUT` flat | static (static properties under ^static; the generator refuses to emit a rule that writes a static attribute).
gen_counting.py, gen_waterjug.py: task generators (`python3 gen_X.py [flat|static]`). Operators follow the STEP6 variants; state access and goal tests follow the world conventions.
play.py runs a task against the stub environment and returns the actions; check_waterjug.py replays them independently and compares with a BFS optimum.
try.py: quick fingerprint run (env-complete mode).

Results (Soar 9.6.6): counting halts with success at 302 decisions in both layouts (identical firings). water-jug: seeds 1-5 all valid, goal reached, 4 actions = BFS optimum, 443-771 decisions, identical in both layouts.
Water jug uses ^flags.avoid-repeated-states true (the original look-ahead variant has the duplicate rule).

gen_arithmetic.py / check_arithmetic.py: two fixed problems (56 + 39, 83 - 47 with a borrow) solved by process-column / finish-problem with fact-object lookup; both layouts: seeds 1-3 give answers 95 and 36, 21 decisions, 6 actions.

gen_blocks.py: blocks world (look-ahead variant, canonical relation objects: on, derived clear, desired relations).
play.py picks the library from env WLIB (default /tmp/s0/zip/default-world = thor-soar.vsa.zip's default-world).

## Library version finding (13 Nov 2026)
The default-world in thor-soar.vsa.zip and the lib/ copy inside the 8 Nov world programs (mc, wizards, artists, zebra; "with the D-005 fix") differ in about 25 files.
- blocks world: never makes a move on the thor-zip default-world (nested look-ahead does not terminate); on the 8 Nov lib: 3 moves (optimal), 998 decisions.
- water jug (avoid-repeated-states true): thor-zip lib: optimal 4 moves, seeds 1-5; 8 Nov lib: 6-7 moves for seeds 1-3, no move in 5000 decisions for seeds 4-5.
- arithmetic: 21 decisions on the thor-zip lib; on the 8 Nov lib seeds 1-2 give 32 decisions, seed 3 405 decisions and duplicated answer lines (not diagnosed).
- counting: same on both.

## v18 (15 Nov 2026): literal object handles
`wg.Task(..., literal_handles=True)` (the default) writes every LHS object-handle test as `^object-handle $ <h>` (World-Conventions-Spec-v6, W-CHK-011), except inside negated conditions (Soar 9.6.50 reports "bad test type in hash_test" there); it never puts $ inside a { ... } test with a relational test (that crashes Soar 9.6.50). Reason: chunks otherwise variablize handles with no inequality and can fire for another object (Hanoi, FINDING-chunking-overgeneral.md). All generated *rules*.soar files in this folder were updated in place.
