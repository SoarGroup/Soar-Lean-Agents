import sys, re
sys.path.insert(0, '/home/claude/worldgen'); import play
rules = sys.argv[1]; bad = 0
for seed in (1, 2, 3):
    r = play.play(rules, seed)
    probs = re.findall(r'problem op (\d) top (\d+) bottom (\d+) answer (\d+) carry (\d)', r['out'])
    ok = r['success'] and len(probs) == 2
    for op, top, bot, ans, carry in probs:
        exp = int(top) + int(bot) if op == '1' else int(top) - int(bot)
        ok = ok and int(ans) == exp and int(carry) == (1 if (op == '1' and int(top) + int(bot) >= 100) else 0)
    acts = [a[0] for a in r['actions']]
    ok = ok and acts == ['process-column', 'process-column', 'finish-problem', 'process-column', 'process-column', 'finish-problem']
    print(f'seed {seed}: ok={ok} problems={probs} actions={len(acts)} decisions={r["decisions"]}'); bad += not ok
sys.exit(bad)
