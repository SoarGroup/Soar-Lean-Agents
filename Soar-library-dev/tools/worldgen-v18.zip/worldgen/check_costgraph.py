"""Independent check for the cost graph: replay the actions the agent sent, verify they form a valid path from S to G, and compare
the cost and operator count with Dijkstra / BFS optima. usage: check_costgraph.py LIB [seed ...]"""
import sys, os, heapq, collections, play
_A = [('S','G',10), ('S','A',1), ('A','B',1), ('B','G',1), ('S','C',2), ('C','G',9)]
_B = [('S','A',1), ('A','B',1), ('B','G',1), ('S','C',2), ('C','G',9), ('S','E',4), ('E','G',2)]
_D = _B + [('C','E',0), ('E','C',0)]
_C = _B + [('A','S',1), ('B','A',1), ('C','S',1), ('E','S',1)]
if os.environ.get('GRAPH') == 'r':
    import rgraph; _R = rgraph.edges()
else: _R = None
EDGES = {f'E{i}': e for i, e in enumerate(_R or {'b': _B, 'c': _C, 'd': _D}.get(os.environ.get('GRAPH'), _A), 1)}
def optima():
    out = collections.defaultdict(list)
    for h, (a, b, c) in EDGES.items(): out[a].append((b, c))
    d = {'S': 0}; pq = [(0, 'S')]
    while pq:
        c, n = heapq.heappop(pq)
        if c > d[n]: continue
        for b, w in out[n]:
            if c + w < d.get(b, 1e9): d[b] = c + w; heapq.heappush(pq, (c + w, b))
    q = collections.deque([('S', 0)]); seen = {'S'}; ops = None
    while q:
        n, k = q.popleft()
        if n == 'G': ops = k; break
        for b, _ in out[n]:
            if b not in seen: seen.add(b); q.append((b, k + 1))
    return d['G'], ops
def check(acts):
    at, cost = 'S', 0
    for name, eh, _ in acts:
        a, b, c = EDGES[eh]
        if name != 'go' or a != at: return dict(valid=False)
        at, cost = b, cost + c
    return dict(valid=at == 'G', cost=cost, operators=len(acts))
if __name__ == '__main__':
    lib = sys.argv[1]; seeds = [int(x) for x in sys.argv[2:]] or [1, 2, 3]
    oc, oo = optima(); print('optimal cost', oc, 'fewest operators', oo)
    for layout in ('costgraph-rules.soar', 'costgraph-rules-static.soar'):
        for s in seeds:
            r = play.play(layout, s, 3000, lib=lib); c = check(r['actions'])
            print(layout, 'seed', s, c, 'decisions', r['decisions'], 'optimal-cost' if c.get('cost') == oc else 'not-cost-optimal')
