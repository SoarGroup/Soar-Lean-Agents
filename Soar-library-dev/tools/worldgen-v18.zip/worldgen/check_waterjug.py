import sys, json, collections, subprocess, os
sys.path.insert(0, '/home/claude/worldgen')
import play
rules = sys.argv[1]
def step(st, name, a1, a2):
    c = dict(st); V = {'jug3': 3, 'jug5': 5}
    if name == 'fill': assert c[a1] < V[a1]; c[a1] = V[a1]
    elif name == 'empty': assert c[a1] > 0; c[a1] = 0
    elif name == 'pour':
        assert a1 != a2 and c[a1] > 0 and c[a2] < V[a2]
        m = min(c[a1], V[a2] - c[a2]); c[a1] -= m; c[a2] += m
    else: raise ValueError(name)
    return c
def bfs():
    s0 = (0, 0); q = collections.deque([(s0, 0)]); seen = {s0}
    while q:
        (a, b), d = q.popleft()
        if a == 1: return d
        for na, nb in [(3, b), (a, 5), (0, b), (a, 0)] + [((a - min(a, 5 - b)), b + min(a, 5 - b)), (a + min(b, 3 - a), b - min(b, 3 - a))]:
            if (na, nb) not in seen: seen.add((na, nb)); q.append(((na, nb), d + 1))
opt = bfs()
for seed in (1, 2, 3, 4, 5):
    r = play.play(rules, seed)
    st = {'jug3': 0, 'jug5': 0}
    try:
        for n, a1, a2 in r['actions']: st = step(st, n, a1, a2)
        valid = True
    except AssertionError: valid = False
    print(f'seed {seed}: success={r["success"]} valid_moves={valid} final={st} goal={st["jug3"]==1} actions={len(r["actions"])} optimal={opt} decisions={r["decisions"]}')
