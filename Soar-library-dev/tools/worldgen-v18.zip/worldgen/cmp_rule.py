"""Compare the library with the lower-bound rule (dev) and without (nolb) on random graphs and scheduling instances. usage: cmp_rule.py LIB TAG"""
import sys, os, subprocess, json, signal
sys.path.insert(0, '/home/claude/worldgen')
import play, rgraph, check_costgraph as C, importlib, sched_model as SM, sched_check as SC
lib, tag = sys.argv[1], sys.argv[2]; out = []
class TO(Exception): pass
def alarm(*a): raise TO()
signal.signal(signal.SIGALRM, alarm)
def run(rules, seed, cap, checkfn):
    signal.alarm(100)
    try:
        r = play.play(rules, seed, cap, lib=lib); signal.alarm(0); c = checkfn(r['actions']); return c.get('cost') if r['success'] and c.get('valid') else None, r['decisions']
    except TO: return None, None
# random graphs
for n, seeds in ((7, range(1, 9)), (8, range(1, 7)), (9, range(1, 5))):
    for sd in seeds:
        os.environ['RG'] = f'{sd}:{n}'; os.environ['GRAPH'] = 'r'; importlib.reload(rgraph); importlib.reload(C); opt = rgraph.exact_h()['S']
        for cfg, env in (('opt', {'OPT': 'true'}), ('opt+h', {'OPT': 'true', 'H': '1'})):
            e = dict(os.environ); e.update(env); subprocess.run(['python3', 'gen_costgraph.py', 'flat', 'unit', 'r'], env=e, check=True)
            f = f'costgraph-r{sd}x{n}-unit-opt' + ('-h' if 'H' in env else '') + '-rules.soar'
            cost, dec = run(f, 1, 8000, C.check); out.append(dict(kind='graph', n=n, seed=sd, cfg=cfg, opt=opt, cost=cost, dec=dec))
# scheduling
os.environ.pop('GRAPH', None)
for n, seeds in ((3, range(1, 9)),):
    for sd in seeds:
        os.environ['SCHED'] = f'{sd}:{n}'; J = SM.jobs(); opt = SM.optimum(J)
        e = dict(os.environ); e['OPT'] = 'true'; subprocess.run(['python3', 'gen_sched.py', 'flat', 'time'], env=e, check=True)
        cost, dec = run(f'sched-s{sd}x{n}-time-opt-rules.soar', 1, 12000, lambda a: SC.check(a, J)); out.append(dict(kind='sched', n=n, seed=sd, cfg='opt', opt=opt, cost=cost, dec=dec))
json.dump(out, open(f'cmp_rule_{tag}.json', 'w'))
import collections
b = collections.defaultdict(lambda: [0, 0, 0, 0])
for r in out:
    k = b[(r['kind'], r['cfg'])]; k[0] += 1
    if r['cost'] is None: k[3] += 1
    elif r['cost'] == r['opt']: k[1] += 1
    else: k[2] += 1
for k, v in sorted(b.items()): print(tag, k, 'runs', v[0], 'optimal', v[1], 'suboptimal', v[2], 'unfinished', v[3])
