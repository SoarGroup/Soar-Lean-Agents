import sys, os, wg
HEUR = os.environ.get('H') == '1'   # admissible ^estimated-remaining-cost (true remaining cost to G)
QUANT = os.environ.get('Q')   # ^cost-quantum: the cost cap rises by this amount per iteration (instead of IDA*)
NET = os.environ.get('NET')   # net value: the task supplies ^state-value 10 and ^better higher; the value is the cost weight
WGT = os.environ.get('W')   # ^heuristic-weight (weighted bound)
ASP = os.environ.get('ASP')   # ^aspiration (cost level)
PROG = os.environ.get('PROG') == '1'   # progress-bounded termination: the task supplies ^progress-score (3 - remaining cost to G)
ITER = os.environ.get('ITER') == 'cost'   # iterative-step cost (IDA*-style cost-cap iteration)
OPT = os.environ.get('OPT') == 'true'   # selection-world ^optimize flag (cost bounds and dominance)
LAYOUT = sys.argv[1] if len(sys.argv) > 1 else 'flat'
METRIC = sys.argv[2] if len(sys.argv) > 2 else 'none'      # cost-metric flag: none | unit | time
GRAPH = sys.argv[3] if len(sys.argv) > 3 else 'a'          # a: S>G direct edge present; b: two-operator routes only
# Edge list (from, to, cost). Fewest operators: S->G (1 operator, cost 10). Cheapest: S->A->B->G (3 operators, cost 3).
EDGES = [('S','G',10), ('S','A',1), ('A','B',1), ('B','G',1), ('S','C',2), ('C','G',9)]
if GRAPH in ('b', 'c', 'd'):   # no direct edge. Two-operator routes: via C cost 11, via E cost 6. Three-operator route S>A>B>G cost 3 is the cheapest.
    EDGES = [('S','A',1), ('A','B',1), ('B','G',1), ('S','C',2), ('C','G',9), ('S','E',4), ('E','G',2)]
if GRAPH == 'd':   # graph b plus a zero-cost cycle C<>E (needs the zero-cost minimum to terminate)
    EDGES = EDGES + [('C','E',0), ('E','C',0)]
if GRAPH == 'r':   # random weighted graph, RG=seed:n (see rgraph.py); optimum from Dijkstra
    import rgraph; EDGES = rgraph.edges()
if GRAPH == 'c':   # graph b plus back edges (cycles): branches never run out, so depth-exceeded evaluations remain at every depth
    EDGES = EDGES + [('A','S',1), ('B','A',1), ('C','S',1), ('E','S',1)]
DESC = """## Cost graph, written to the world conventions (agent-world, selection-world, selection-iterative-deepening).
## Description: a traveler moves along directed edges from S to G. The path with the fewest operators is not the cheapest path.
## World: node objects S A B C G (^type node); edge objects (^type edge ^from ^to ^cost); traveler (^type traveler ^at <node>).
## Edges: S>G 10, S>A 1, A>B 1, B>G 1, S>C 2, C>G 9. Fewest operators: S>G (1 operator, cost 10). Cheapest: S>A>B>G (3 operators, cost 3).
## Task operator: go (^argument1 = edge), proposed when the traveler is at the edge's ^from node; ^step-cost = the edge cost. Effect: traveler ^at := ^to.
## Goal: one desired, traveler ^at G.
"""
t = wg.Task('costgraph', DESC, layout=LAYOUT, static=['type', 'from', 'to', 'cost'], strategy='iterative-deepening')
for n in sorted({e[0] for e in EDGES} | {e[1] for e in EDGES}): t.objects.append((n, {'type': 'node'}, []))
t.extra_flags = ('' if METRIC == 'none' else f' ^cost-metric {METRIC}') + (' ^optimize true' if OPT else '') + (' ^iterative-step cost' if ITER else '') + (f' ^cost-quantum {QUANT}' if QUANT else '') + (f' ^cost-weight {NET}' if NET else '') + (f' ^heuristic-weight {WGT}' if WGT else '') + (f' ^min-step-cost {os.environ["MSC"]}' if os.environ.get('MSC') else '') + (f' ^aspiration {ASP}' if ASP else '') + (' ^termination progress ^progress-score task' if PROG else '')
t.objects.append(('T', {'type': 'traveler', 'at': 'S'}, []))
for i, (a, b, c) in enumerate(EDGES, 1): t.objects.append((f'E{i}', {'type': 'edge', 'from': a, 'to': b, 'cost': c}, []))
t.desired.append(('T', {'at': 'G'}))
t.check_mutable('at')
A = t.lhs_attr
t.add(t.achievement())
t.add(t.propose('go', f'''   (<objs> ^object <tr> <e>)
   (<tr> {A('type','traveler')} ^at <from>)
   (<e> {A('type','edge')} {A('from','<from>')} {A('cost','<c>')})''', ['<e>'], attrs='^step-cost <c>'))
TIME_LHS = f'\n   (<w> ^time <tm>)\n   (<e> {A("cost","<c>")})' if METRIC == 'time' else ''
TIME_RHS = '\n   (<w> ^time <tm> - (+ <tm> <c>))' if METRIC == 'time' else ''
cond = f'''   (<w> ^anchored-world true ^objects <objs>)
   (<objs> ^object <tr> <e>)
   (<tr> {A('type','traveler')} ^object-handle <th> ^at <from>)
   (<e> ^object-handle <eh> {A('type','edge')} {A('from','<from>')} {A('to','<to>')})'''
t.add(f'''
sp {{costgraph*apply*go*internal
   (state <s> ^operator <op> ^internal-actions true ^world <w>)
   (<op> ^task-operator true ^name go ^pre-conditions-satisfied true ^argument1.object-handle <eh>)
{cond}{TIME_LHS}
-->
   (log 1 (crlf) |Apply go internal.|)
   (<tr> ^at <from> - <to>){TIME_RHS}
}}

sp {{costgraph*apply*go*environment-effect
   :o-support
   (state <s> ^superstate nil ^world <w> ^io.output-link.perform-action <pa>)
   (<pa> ^name go ^status complete ^argument1 <eh> -^effect-applied true)
{cond}
-->
   (<tr> ^at <from> - <to>)
   (<pa> ^effect-applied true)
   (write |Go along edge | <eh> (crlf))
}}
''')
if NET:
    t.add('''
sp {costgraph*elaborate*evaluate-operator*state-value
   (state <s> ^name evaluate-operator)
-->
   (<s> ^state-value 10)}

sp {costgraph*elaborate*desireds*better*higher
   (state <s> ^superstate nil ^desireds <d>)
-->
   (<d> ^better higher)}
''')
if PROG:
    P = {'S': 0, 'A': 1, 'B': 2, 'C': -6, 'E': 1, 'G': 3}
    for n, v in P.items():
        t.add(f'''
sp {{costgraph*elaborate*state*progress-score*{n}
   (state <s> ^world <w>)
   (<w> ^anchored-world true ^objects <objs>)
   (<objs> ^object <tr>)
   (<tr> {A('type','traveler')} ^at {n})
-->
   (<s> ^progress-score {v})}}
''')
if HEUR:
    H = {'S': 3, 'A': 2, 'B': 1, 'C': 9, 'E': 2, 'G': 0} if GRAPH != 'a' else {'S': 3, 'A': 2, 'B': 1, 'C': 9, 'G': 0}
    if GRAPH == 'r': H = rgraph.h_admissible()
    for n, h in H.items():
        t.add(f'''
sp {{costgraph*elaborate*world*estimated-remaining-cost*{n}
   (state <s> ^world <w>)
   (<w> ^anchored-world true ^objects <objs>)
   (<objs> ^object <tr>)
   (<tr> {A('type','traveler')} ^at {n})
-->
   (<w> ^estimated-remaining-cost {h})}}
''')
suffix = ('' if GRAPH == 'a' else '-' + GRAPH + (os.environ['RG'].replace(':', 'x') if GRAPH == 'r' else '')) + ('' if METRIC == 'none' else '-' + METRIC) + ('-opt' if OPT else '') + ('-cap' if ITER else '') + ('-h' if HEUR else '') + (f'-q{QUANT}' if QUANT else '') + (f'-net{NET}' if NET else '') + (f'-w{WGT}' if WGT else '') + (f'-asp{ASP}' if ASP else '') + ('-prog' if PROG else '')
open(f'costgraph{suffix}-rules{"-static" if LAYOUT=="static" else ""}.soar', 'w').write(t.text())
