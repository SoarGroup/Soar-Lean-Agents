import sys, wg
LAYOUT = sys.argv[1] if len(sys.argv) > 1 else 'flat'
DESC = """## Eight Puzzle (look-ahead), written to the world conventions (agent-world, selection-world,
## selection-iterative-deepening).
##
## Description: a 3x3 board with tiles T1..T8 and a blank. A tile adjacent to the blank can slide into it.
## Goal:  1 2 3 / 4 5 6 / 7 8 _  (_ = blank). The start is EP_STEPS moves from the goal (default 3: 1 2 3 / 4 8 5 / 7 _ 6; 4 is the heavier instance, about 4000 decisions).
## World: objects cells c11..c33 (^type cell), tiles T1..T8 (^type tile), blank (^type blank), memory (^type memory, ^last-tile).
## Relations (canonical shape): (<w> ^at <r>) with <r> ^argument1 <tile-or-blank> ^argument2 <cell>;
## (<w> ^adjacent <r>) with <r> ^argument1 <cell> ^argument2 <cell> (both directions, constant).
## Goal: desireds for tiles T3..T8 only (agent-world counts at most 6 desireds). With T3..T8 in place, T1 and T2 can only be
## in place too (swapping two tiles is unreachable by parity), so this is the full Eight Puzzle goal.
## Task operator: move-tile (^argument1 = tile, ^argument2 = the blank's cell). Effect: tile and blank exchange cells.
## Search control (look-ahead only): do not move the tile moved last (that would undo the move).
"""
t = wg.Task('eight-puzzle', DESC, layout=LAYOUT, static=['type'], strategy='iterative-deepening')
cells = [f'cell-{r}-{c}' for r in (1, 2, 3) for c in (1, 2, 3)]
for c in cells: t.objects.append((c, {'type': 'cell'}, []))
for i in range(1, 9): t.objects.append((f'T{i}', {'type': 'tile'}, []))
t.objects.append(('blank', {'type': 'blank'}, []))
t.objects.append(('memory', {'type': 'memory', 'last-tile': 'none'}, []))
import os
STEPS=int(os.environ.get('EP_STEPS','3'))
start = {'T1': 'cell-1-1', 'T2': 'cell-1-2', 'T3': 'cell-1-3', 'T4': 'cell-2-1', 'T8': 'cell-2-2', 'T5': 'cell-2-3', 'blank': 'cell-3-1', 'T7': 'cell-3-2', 'T6': 'cell-3-3'}
starts = {
 1: {'T1':'cell-1-1','T2':'cell-1-2','T3':'cell-1-3','T4':'cell-2-1','T5':'cell-2-2','blank':'cell-2-3','T7':'cell-3-1','T8':'cell-3-2','T6':'cell-3-3'},
 2: {'T1':'cell-1-1','T2':'cell-1-2','T3':'cell-1-3','T4':'cell-2-1','blank':'cell-2-2','T5':'cell-2-3','T7':'cell-3-1','T8':'cell-3-2','T6':'cell-3-3'},
 3: {'T1':'cell-1-1','T2':'cell-1-2','T3':'cell-1-3','T4':'cell-2-1','T8':'cell-2-2','T5':'cell-2-3','T7':'cell-3-1','blank':'cell-3-2','T6':'cell-3-3'}}
if STEPS in starts: start = starts[STEPS]
goal = {'T1': 'cell-1-1', 'T2': 'cell-1-2', 'T3': 'cell-1-3', 'T4': 'cell-2-1', 'T5': 'cell-2-2', 'T6': 'cell-2-3', 'T7': 'cell-3-1', 'T8': 'cell-3-2'}
for o, c in start.items():
    t.init_extra += [f'(<w> ^at <at-{o}>)', f'(<at-{o}> ^argument1 <o-{o}> ^argument2 <o-{c}>)']
k = 0
for r in (1, 2, 3):
    for c in (1, 2, 3):
        for dr, dc in ((0, 1), (1, 0), (0, -1), (-1, 0)):
            r2, c2 = r + dr, c + dc
            if 1 <= r2 <= 3 and 1 <= c2 <= 3:
                k += 1
                t.init_extra += [f'(<w> ^adjacent <adj{k}>)', f'(<adj{k}> ^argument1 <o-cell-{r}-{c}> ^argument2 <o-cell-{r2}-{c2}>)']
for tile in ('T3', 'T4', 'T5', 'T6', 'T7', 'T8'): t.desired.append(('rel', 'at', tile, goal[tile]))
t.check_mutable('last-tile')
A = t.lhs_attr
t.add(t.achievement_relation(2))
t.copy_relations = ['at', 'adjacent']   # declared on the problem space; the library copies them into look-ahead (P-004, P-005)
t.add(t.propose('move-tile*move-tile-into-blank', f'''   (<objs> ^object <t> <bl>)
   (<t> {A('type','tile')} ^object-handle <th>)
   (<bl> {A('type','blank')})
   (<w> ^at <rt> <rb>)
   (<rt> ^argument1 <t> ^argument2 <c1>)
   (<rb> ^argument1 <bl> ^argument2 <c2>)
   (<w> ^adjacent <adj>)
   (<adj> ^argument1 <c1> ^argument2 <c2>)''', ['<t>', '<c2>']))
t.add('''
## Search control: in a look-ahead state, do not move the tile moved last.
sp {eight-puzzle*reject*move-tile*moved-last
   (state <s> ^problem-space.name eight-puzzle ^internal-actions true ^operator <op> + ^world <w>)
   (<w> ^objects.object <m>)
   (<m> ^type memory ^last-tile <h>)
   (<op> ^task-operator true ^name move-tile ^argument1.object-handle <h>)
-->
   (<s> ^operator <op> -)
}
'''.replace('^type memory', A('type', 'memory')))
cond = f'''   (<w> ^anchored-world true ^objects <objs>)
   (<objs> ^object <t> <c2> <m> <bl>)
   (<t> ^object-handle <th>)
   (<c2> ^object-handle <ch>)
   (<m> {A('type','memory')} ^last-tile <lb>)
   (<bl> {A('type','blank')})
   (<w> ^at <rt> <rb>)
   (<rt> ^argument1 <t> ^argument2 <c1>)
   (<rb> ^argument1 <bl> ^argument2 <c2>)'''
rhs = '''(<rt> ^argument2 <c1> - <c2>)
   (<rb> ^argument2 <c2> - <c1>)
   (<m> ^last-tile <lb> - <th>)'''
t.add(f'''
sp {{eight-puzzle*apply*move-tile*internal
   (state <s> ^operator <op> ^internal-actions true ^world <w>)
   (<op> ^task-operator true ^name move-tile ^pre-conditions-satisfied true ^argument1.object-handle <th> ^argument2.object-handle <ch>)
{cond}
-->
   (log 1 (crlf) |Apply move-tile internal.|)
   {rhs}
}}

sp {{eight-puzzle*apply*move-tile*environment-effect
   :o-support
   (state <s> ^superstate nil ^world <w> ^io.output-link.perform-action <pa>)
   (<pa> ^name move-tile ^status complete ^argument1 <th> ^argument2 <ch> -^effect-applied true)
{cond}
-->
   {rhs}
   (<pa> ^effect-applied true)
   (write |Move tile | <th> | into | <ch> (crlf))
}}
''')
open(f'eight-puzzle-rules{"-static" if LAYOUT=="static" else ""}.soar', 'w').write(t.text())
