"""Scheduling task with unattended jobs, for cost-metric time. usage: SCHED=seed:n [OPT=true] [ITER=cost] python3 gen_sched.py flat time
Each job has ^hands (hands-on time, the clock advances) and ^unattended (runs on its own afterwards, then the job is done). Goal: every job done.
Look-ahead models the clock: start J advances ^time by hands; a job with unattended > 0 becomes running with ^finish; wait-for J moves the clock to J's finish.
In the real world a started job is done at once (the environment completes it), so the real world never has running jobs. The cost is the clock when the goal holds.
The job set is random and deterministic (sched_model.jobs); the optimum is found by enumerating the start orders (sched_check.py)."""
import sys, os, wg, sched_model
OPT = os.environ.get('OPT') == 'true'; ITER = os.environ.get('ITER') == 'cost'; LAYOUT = sys.argv[1] if len(sys.argv) > 1 else 'flat'
METRIC = sys.argv[2] if len(sys.argv) > 2 else 'time'
JOBS = sched_model.jobs()
DESC = "## Scheduling with unattended jobs: " + '; '.join(f'J{i}: hands {h}, unattended {u}' for i, (h, u) in enumerate(JOBS, 1)) + """.
## Description: start every job; starting a job takes its hands-on time, then it runs unattended and finishes by itself. Start order decides the finish time.
## World: job objects (^type job ^hands ^unattended ^status todo|running|done ^finish). Task operators: start (^argument1 = job), wait-for (^argument1 = running job; look-ahead only).
## Goal: every job ^status done. Cost: the look-ahead clock (cost-metric time).
"""
t = wg.Task('sched', DESC, layout=LAYOUT, static=['type', 'hands', 'unattended'], strategy='iterative-deepening')
t.extra_flags = f' ^cost-metric {METRIC}' + (' ^optimize true' if OPT else '') + (' ^iterative-step cost' if ITER else '')
for i, (h, u) in enumerate(JOBS, 1):
    t.objects.append((f'J{i}', {'type': 'job', 'hands': h, 'unattended': u, 'status': 'todo'}, []))
    t.desired.append((f'J{i}', {'status': 'done'}))
t.check_mutable('status'); t.check_mutable('finish')
A = t.lhs_attr
t.add(t.achievement())
t.add(t.propose('start', f'''   (<objs> ^object <j>)
   (<j> {A('type','job')} ^status todo)''', ['<j>']))
t.add(t.propose('wait-for', f'''   (<objs> ^object <j>)
   (<j> {A('type','job')} ^status running)''', ['<j>']))
jc = f'''   (<w> ^anchored-world true ^objects <objs> ^time <tm>)
   (<objs> ^object <j>)'''
t.add(f'''
sp {{sched*apply*start*internal*unattended
   (state <s> ^operator <op> ^internal-actions true ^world <w>)
   (<op> ^task-operator true ^name start ^pre-conditions-satisfied true ^argument1.object-handle <jh>)
{jc}
   (<j> ^object-handle <jh> {A('hands','<h>')} {A('unattended','{ > 0 <u> }')} ^status todo)
-->
   (<w> ^time <tm> - (+ <tm> <h>))
   (<j> ^status todo - running ^finish (+ (+ <tm> <h>) <u>))}}

sp {{sched*apply*start*internal*hands-only
   (state <s> ^operator <op> ^internal-actions true ^world <w>)
   (<op> ^task-operator true ^name start ^pre-conditions-satisfied true ^argument1.object-handle <jh>)
{jc}
   (<j> ^object-handle <jh> {A('hands','<h>')} {A('unattended','0')} ^status todo)
-->
   (<w> ^time <tm> - (+ <tm> <h>))
   (<j> ^status todo - done)}}

sp {{sched*apply*wait-for*internal
   (state <s> ^operator <op> ^internal-actions true ^world <w>)
   (<op> ^task-operator true ^name wait-for ^pre-conditions-satisfied true ^argument1.object-handle <jh>)
{jc}
   (<j> ^object-handle <jh> ^status running ^finish {{ > <tm> <f> }})
-->
   (<w> ^time <tm> - <f>)}}

sp {{sched*apply*complete*by-time
   :o-support
   (state <s> ^internal-actions true ^world <w>)
   (<w> ^anchored-world true ^time <tm> ^objects.object <j>)
   (<j> ^status running ^finish <= <tm>)
-->
   (<j> ^status running - done)}}

sp {{sched*apply*start*environment-effect
   :o-support
   (state <s> ^superstate nil ^world <w> ^io.output-link.perform-action <pa>)
   (<pa> ^name start ^status complete ^argument1 <jh> -^effect-applied true)
   (<w> ^objects.object <j>)
   (<j> ^object-handle <jh> ^status todo)
-->
   (<j> ^status todo - done)
   (<pa> ^effect-applied true)
   (write |Start job | <jh> (crlf))}}
''')
suffix = f'-s{os.environ["SCHED"].replace(":", "x")}-{METRIC}' + ('-opt' if OPT else '') + ('-cap' if ITER else '')
open(f'sched{suffix}-rules.soar', 'w').write(t.text())
