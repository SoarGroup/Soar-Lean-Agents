import sys, wg
LAYOUT = sys.argv[1] if len(sys.argv) > 1 else 'flat'
DESC = """## Water jug (look-ahead variant), written to the world conventions (agent-world, selection-world,
## selection-iterative-deepening). Operators, constraint and duplicate-state rule follow the STEP6
## water-jug-look-ahead variant; state access and goal test follow the world conventions.
##
## Description: a 7-litre and a 9-litre jug, both empty. Operators: fill a jug from the source, empty a jug
## onto the ground, pour one jug into the other until the first is empty or the second is full. Get exactly
## 3 litres in the 7-litre jug. Contents stay between 0 and the jug's volume.
## World: objects jug7 and jug9 (^type jug, ^volume, ^contents, derived ^free = volume - contents) and
## history (^type history, ^visited <contents3>-<contents5>*).
## Goal: one desired, jug7 ^contents 3.
## Task operators: fill, empty (^argument1 = jug), pour (^argument1 = from, ^argument2 = to).
## With ^flags.avoid-repeated-states true a move that returns to a visited contents pair is rejected
## (the original look-ahead variant rejects a state equal to one on its path).
"""
t = wg.Task('water-jug', DESC, layout=LAYOUT, static=['type', 'volume'], strategy='iterative-deepening', derived=['free'])
import os
t.extra_flags = (' ^avoid-repeated-states true' if os.environ.get('DUP','1')=='1' else '') + (' ^cost-metric unit ^optimize true' if os.environ.get('OPT')=='1' else '') + os.environ.get('EXTRA','')
t.objects.append(('jug7', {'type': 'jug', 'volume': 7, 'contents': 0}, []))
t.objects.append(('jug9', {'type': 'jug', 'volume': 9, 'contents': 0}, []))
t.objects.append(('history', {'type': 'history', 'visited': '|0-0|'}, []))
t.desired.append(('jug7', {'contents': 3}))
t.check_mutable('contents')
A = t.lhs_attr
t.add(f'''
## Derived: room left in a jug.
sp {{water-jug*elaborate*world*free
   (state <s> ^world <w>)
   (<w> ^objects.object <j>)
   (<j> {A('type','jug')} {A('volume','<v>')} ^contents <c>)
-->
   (<j> ^free (- <v> <c>))
}}
''')
t.add(t.achievement())
H = {'jug7': 0, 'jug9': 1}
def label(new):  # new: {handle: expr}
    return f'(concat {new["jug7"]} |-| {new["jug9"]})'
def effects():
    """yield (opname, X, Y, case, lhs conditions for <x>,<y>, argcount, new-contents dict, rhs lines)"""
    for X, Y in (('jug7', 'jug9'), ('jug9', 'jug7')):
        yield dict(op='fill', X=X, Y=Y, case='', n=1,
                   cx=f'(<x> ^object-handle {X} {A("volume","<vx>")} ^free {{ > 0 }} ^contents <cx>)', cy=f'(<y> ^object-handle {Y} ^contents <cy>)',
                   new={X: '<vx>', Y: '<cy>'}, rhs=['(<x> ^contents <cx> - <vx>)'])
        yield dict(op='empty', X=X, Y=Y, case='', n=1,
                   cx=f'(<x> ^object-handle {X} ^contents {{ > 0 <cx> }})', cy=f'(<y> ^object-handle {Y} ^contents <cy>)',
                   new={X: '0', Y: '<cy>'}, rhs=['(<x> ^contents <cx> - 0)'])
        yield dict(op='pour', X=X, Y=Y, case='-overflow', n=2,
                   cy=f'(<y> ^object-handle {Y} {A("volume","<vy>")} ^free {{ > 0 <fy> }} ^contents <cy>)',
                   cx=f'(<x> ^object-handle {X} ^contents {{ > <fy> <cx> }})',
                   new={X: '(- <cx> <fy>)', Y: '<vy>'}, rhs=['(<x> ^contents <cx> - (- <cx> <fy>))', '(<y> ^contents <cy> - <vy>)'])
        yield dict(op='pour', X=X, Y=Y, case='-fits', n=2,
                   cy=f'(<y> ^object-handle {Y} ^free {{ > 0 <fy> }} ^contents <cy>)',
                   cx=f'(<x> ^object-handle {X} ^contents {{ > 0 <= <fy> <cx> }})',
                   new={X: '0', Y: '(+ <cy> <cx>)'}, rhs=['(<x> ^contents <cx> - 0)', '(<y> ^contents <cy> - (+ <cy> <cx>))'])
for e in effects():
    X, Y = e['X'], e['Y']
    nm = f"{e['op']}-{X}" + (f"-{Y}" if e['n'] == 2 else '') + e['case']
    lab = label(e['new'])
    args = ['<x>'] + (['<y>'] if e['n'] == 2 else [])
    # proposal (cy first so variables are bound before comparisons)
    t.add(t.propose(f'{e["op"]}*{nm}', f'''   (<objs> ^object <x> <y>)
   {e['cy']}
   {e['cx']}''', args, attrs=f'^result {lab}'))
    # internal application: re-test the same situation through the operator's arguments
    argt = f'^argument1.object-handle {X}' + (f' ^argument2.object-handle {Y}' if e['n'] == 2 else '')
    cond = f'''   (<w> ^anchored-world true ^objects <objs>)
   (<objs> ^object <x> <y> <hist>)
   {e['cy']}
   {e['cx']}
   (<hist> ^type history)'''.replace('(<hist> ^type history)', f'(<hist> {A("type","history")})')
    rhs = '\n   '.join(e['rhs']) + f'\n   (<hist> ^visited {lab})'
    t.add(f'''
sp {{water-jug*apply*{nm}*internal
   (state <s> ^operator <op> ^internal-actions true ^world <w>)
   (<op> ^task-operator true ^name {e['op']} ^pre-conditions-satisfied true {argt})
{cond}
-->
   (log 1 (crlf) |Apply {nm} internal.|)
   {rhs}
}}

sp {{water-jug*apply*{nm}*environment-effect
   :o-support
   (state <s> ^superstate nil ^world <w> ^io.output-link.perform-action <pa>)
   (<pa> ^name {e['op']} ^status complete ^argument1 {X}{(' ^argument2 ' + Y) if e['n']==2 else ''} -^effect-applied true)
{cond}
-->
   {rhs}
   (<pa> ^effect-applied true)
   (write |Perform {nm}| (crlf))
}}
''')
t.add(f'''
## Reject a move that returns to a visited contents pair (only with ^flags.avoid-repeated-states true).
sp {{water-jug*reject*repeated-state
   (state <s> ^problem-space.name water-jug ^flags.avoid-repeated-states true ^operator <op> + ^world <w>)
   (<w> ^anchored-world true ^objects.object <h>)
   (<h> {A('type','history')} ^visited <l>)
   (<op> ^task-operator true ^result <l>)
-->
   (<s> ^operator <op> -)
}}
''')

if os.environ.get('FS')=='1':
    t.add(f'''
## Failure states of the original failure-states variant: both jugs full, both jugs empty (the start). A move that produces one is rejected
## (only with ^flags.avoid-repeated-states true).
sp {{water-jug*reject*failure-state
   (state <s> ^problem-space.name water-jug ^flags.avoid-repeated-states true ^operator <op> +)
   (<op> ^task-operator true ^result << |7-9| |0-0| >>)
-->
   (<s> ^operator <op> -)
}}
''')
open(f'water-jug79-{"dup" if os.environ.get("DUP","1")=="1" else "nodup"}{"-opt" if os.environ.get("OPT")=="1" else ""}{os.environ.get("TAG","")}-rules.soar', 'w').write(t.text())
