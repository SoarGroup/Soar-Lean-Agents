"""P5 for the cost-graph family: run the candidate configurations on a graph and report which return the Dijkstra optimum, cheapest in decisions first.
usage: RG=seed:n METRIC=unit|time p5_costgraph.py"""
import os, sys, subprocess, signal
sys.path[:0] = ['/home/claude/worldgen', '/home/claude/worldgen']
os.environ['GRAPH'] = 'r'
import play, rgraph, check_costgraph as C, probe_graph as P
sd, n = os.environ['RG'].split(':'); MET = os.environ.get('METRIC', 'unit'); lib = os.environ.get('WLIB', '/home/claude/soar-library-dev')
CFG = {'depth': {}, 'depth+opt': {'OPT': 'true'}, 'cap': {'ITER': 'cost'}, 'cap+h': {'ITER': 'cost', 'H': '1'}, 'depth+opt+h': {'OPT': 'true', 'H': '1'}}
runs = {}
for name, env in CFG.items():
    e = dict(os.environ); e.update(env); subprocess.run(['python3', 'gen_costgraph.py', 'flat', MET, 'r'], env=e, check=True, cwd='/home/claude/worldgen')
    rules = f'costgraph-r{sd}x{n}-{MET}' + ('-opt' if 'OPT' in env else '') + ('-cap' if 'ITER' in env else '') + ('-h' if 'H' in env else '') + '-rules.soar'
    r = play.play(rules, 1, 6000, lib=lib); c = C.check(r['actions'])
    runs[name] = dict(cost=c.get('cost', 1e9), decisions=r['decisions'], done=bool(r['success']) and c.get('valid', False))
print(runs); print(P.p5_compare(runs, rgraph.exact_h()['S']))
