"""Run a world task agent and collect the actions it sends to the (stub) environment.
usage: play.py RULES [seed] [cap] -> prints JSON {actions:[[name,a1,a2]], decisions, success}"""
import sys, os, json
B = '/home/claude/soar966/x/SoarSuite_9.6.6-bigbugfixrelease-Multiplatform/bin/linux_x86-64'
sys.path[:0] = [B, '/home/claude/soar-test/shim']
import soar_sml as S
def play(rules, seed=1, cap=5000, lib=os.environ.get('WLIB','/tmp/s0/zip/default-world'), workdir='/home/claude/worldgen'):
    k = S.Kernel.CreateKernelInNewThread(); a = k.CreateAgent('a'); out = []
    a.RegisterForPrintEvent(S.smlEVENT_PRINT, lambda mid, ud, ag, msg: out.append(msg), None)
    os.chdir(workdir)
    cmds = ([f'pushd "{lib}"', 'source soar-library.soar', 'popd', 'source ' + rules] if os.path.exists(os.path.join(lib,'soar-library.soar')) else
            [f'pushd "{lib}"', 'source agent-world.soar', 'source simple.soar', 'pushd selection-world', 'source selection-world_source.soar', 'popd',
             'pushd selection-iterative-deepening', 'source selection-iterative-deepening_source.soar', 'popd', 'popd', 'source ' + rules])
    for c in cmds:
        r = a.ExecuteCommandLine(c)
    a.ExecuteCommandLine('watch 0'); a.ExecuteCommandLine(f'srand {seed}')
    acts = []; ok = False
    for step in range(cap):
        a.RunSelf(1)
        for i in range(a.GetNumberCommands()):
            c = a.GetCommand(i)
            if c.GetCommandName() == 'perform-action' and c.GetParameterValue('status') is None:
                acts.append([c.GetParameterValue('name'), c.GetParameterValue('argument1'), c.GetParameterValue('argument2')]); c.AddStatusComplete()
        a.Commit(); a.ClearOutputLinkChanges()
        if 'success' in a.ExecuteCommandLine('print (s1 ^success *)'): ok = True; break
    import wj79_stats; stats = wj79_stats.parse(a.ExecuteCommandLine('stats'))
    k.Shutdown()
    return dict(stats=stats, actions=acts, decisions=step + 1, success=ok, out=''.join(out))
if __name__ == '__main__':
    r = play(sys.argv[1], int(sys.argv[2]) if len(sys.argv) > 2 else 1, int(sys.argv[3]) if len(sys.argv) > 3 else 5000)
    r.pop('out'); print(json.dumps(r))
