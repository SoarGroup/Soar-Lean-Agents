"""Random weighted digraph for the cost-graph family. RG=seed:n (n nodes including S and G). Deterministic.
edges(): list of (from, to, cost). A random chain S>..>G guarantees a route; extra random edges (including back edges) are added; costs 1..9.
exact_h(): exact remaining cost to G per node (reverse Dijkstra). h_admissible(): floor(0.7 * exact), so it is admissible but not perfect."""
import os, random, heapq, collections
def spec():
    s = os.environ.get('RG', '1:8').split(':'); return int(s[0]), int(s[1])
def edges():
    seed, n = spec(); r = random.Random(seed)
    mid = [f'N{i}' for i in range(1, n - 1)]; r.shuffle(mid)
    chain = ['S'] + mid[:r.randint(1, len(mid))] + ['G']
    E = {}
    for a, b in zip(chain, chain[1:]): E[(a, b)] = r.randint(1, 9)
    nodes = ['S'] + mid + ['G']
    for _ in range(int(1.6 * n)):
        a, b = r.sample(nodes, 2)
        if a != 'G' and (a, b) not in E and (a, b) != ('S', 'G'): E[(a, b)] = r.randint(1, 9)
    return [(a, b, c) for (a, b), c in E.items()]
def exact_h(E=None):
    E = E or edges(); rev = collections.defaultdict(list)
    for a, b, c in E: rev[b].append((a, c))
    d = {'G': 0}; pq = [(0, 'G')]
    while pq:
        c, n = heapq.heappop(pq)
        if c > d[n]: continue
        for a, w in rev[n]:
            if c + w < d.get(a, 1e9): d[a] = c + w; heapq.heappush(pq, (c + w, a))
    return d
def h_admissible(E=None):
    d = exact_h(E); return {n: int(0.7 * v) for n, v in d.items()}
if __name__ == '__main__':
    E = edges(); d = exact_h(E); print(E); print('optimum', d['S'])
