import sys, check_costgraph as C, play
lib = sys.argv[1]; rules = sys.argv[2]; seeds = [int(x) for x in sys.argv[3:]] or [1]
import importlib
for s in seeds:
    r = play.play(rules, s, 4000, lib=lib); c = C.check(r['actions']); print(rules, 'seed', s, c, 'decisions', r['decisions'], 'success', r['success'])
    if '-v' in sys.argv: print(r['out'][-1500:])
