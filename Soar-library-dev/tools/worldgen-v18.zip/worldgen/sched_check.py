"""usage: used by sweep_sched.py. check(actions, J): the start order the agent sent -> valid?, makespan."""
import sched_model as M
def check(actions, J=None):
    J = J or M.jobs(); order = []
    for name, jh, _ in actions:
        if name != 'start' or not jh.startswith('J') or int(jh[1:]) - 1 in order: return dict(valid=False)
        order.append(int(jh[1:]) - 1)
    return dict(valid=len(order) == len(J), cost=M.makespan(order, J), order=order)
