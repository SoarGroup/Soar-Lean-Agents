"""Random job sets for the scheduling task and the independent optimum. SCHED=seed:n. hands 1..4, unattended 0..8 (about a third are hands-only)."""
import os, random, itertools
def spec(): s = os.environ.get('SCHED', '1:3').split(':'); return int(s[0]), int(s[1])
def jobs():
    seed, n = spec(); r = random.Random(seed)
    return [(r.randint(1, 4), 0 if r.random() < 0.34 else r.randint(1, 8)) for _ in range(n)]
def makespan(order, J):
    t = 0; fin = 0
    for j in order:
        h, u = J[j]; t += h; fin = max(fin, t + u)
    return max(t, fin)
def optimum(J=None):
    J = J or jobs(); return min(makespan(p, J) for p in itertools.permutations(range(len(J))))
def fewest_operators_best(J=None):
    """the best makespan among orders needing the fewest operators (starts plus the waits a plan needs)"""
    J = J or jobs(); return None
