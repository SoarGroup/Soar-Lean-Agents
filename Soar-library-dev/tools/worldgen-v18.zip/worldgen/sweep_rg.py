"""Sweep random weighted graphs over search configurations. usage: sweep_rg.py N SEEDS... ; prints a table and writes sweep_rg.json."""
import sys, os, subprocess, json, time, signal
sys.path.insert(0, '/home/claude/worldgen')
import play, rgraph, check_costgraph as C
n = int(sys.argv[1]); seeds = [int(x) for x in sys.argv[2:]]
MET = os.environ.get('METRIC', 'unit'); MODE = os.environ.get('MODE', 'cost')
CFG = {'depth': {}, 'depth+opt': {'OPT': 'true'}, 'cap': {'ITER': 'cost'}, 'cap+h': {'ITER': 'cost', 'H': '1'}, 'depth+opt+h': {'OPT': 'true', 'H': '1'}}
if MODE == 'net': CFG = {'net-depth': {'NET': '1'}, 'net-depth+h': {'NET': '1', 'H': '1'}, 'net-cap': {'NET': '1', 'ITER': 'cost'}}
lib = '/home/claude/soar-library-dev'; res = []
class TO(Exception): pass
def alarm(*a): raise TO()
signal.signal(signal.SIGALRM, alarm)
for sd in seeds:
    os.environ['RG'] = f'{sd}:{n}'; os.environ['GRAPH'] = 'r'
    import importlib; importlib.reload(rgraph); importlib.reload(C)
    opt = rgraph.exact_h()['S']
    for name, env in CFG.items():
        e = dict(os.environ); e.update(env)
        subprocess.run(['python3', 'gen_costgraph.py', 'flat', MET, 'r'], env=e, check=True)
        suffix = f'-r{sd}x{n}-{MET}' + ('-opt' if env.get('OPT') else '') + ('-cap' if env.get('ITER') else '') + ('-h' if env.get('H') else '') + ('-net' + env['NET'] if env.get('NET') else '')
        rules = f'costgraph{suffix}-rules.soar'
        t = time.time(); signal.alarm(120)
        try:
            r = play.play(rules, 1, 6000, lib=lib); signal.alarm(0)
            c = C.check(r['actions']); row = dict(seed=sd, n=n, cfg=name, opt=opt, cost=c.get('cost'), valid=c.get('valid'), decisions=r['decisions'], done=r['success'], sec=round(time.time() - t, 1))
        except TO:
            row = dict(seed=sd, n=n, cfg=name, opt=opt, cost=None, valid=None, decisions=None, done=False, sec=120)
        res.append(row); print(row, flush=True)
json.dump(res, open(f'sweep_rg_{MODE}{MET}_{n}.json', 'w'))
