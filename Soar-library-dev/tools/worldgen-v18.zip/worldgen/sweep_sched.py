"""Sweep the scheduling task. usage: sweep_sched.py N SEEDS... ; writes sweep_sched_N.json"""
import sys, os, subprocess, json, time, signal
sys.path.insert(0, '/home/claude/worldgen')
import play, sched_check as C, sched_model as M
n = int(sys.argv[1]); seeds = [int(x) for x in sys.argv[2:]]; lib = os.environ.get('WLIB', '/home/claude/soar-library-dev')
CFG = {'depth': {}, 'depth+opt': {'OPT': 'true'}, 'cap': {'ITER': 'cost'}, 'cap+opt': {'ITER': 'cost', 'OPT': 'true'}}
class TO(Exception): pass
def alarm(*a): raise TO()
signal.signal(signal.SIGALRM, alarm); res = []
for sd in seeds:
    os.environ['SCHED'] = f'{sd}:{n}'; J = M.jobs(); opt = M.optimum(J)
    for name, env in CFG.items():
        e = dict(os.environ); e.update(env); subprocess.run(['python3', 'gen_sched.py', 'flat', 'time'], env=e, check=True)
        rules = f'sched-s{sd}x{n}-time' + ('-opt' if 'OPT' in env else '') + ('-cap' if 'ITER' in env else '') + '-rules.soar'
        t = time.time(); signal.alarm(150)
        try:
            r = play.play(rules, 1, 12000, lib=lib); signal.alarm(0); c = C.check(r['actions'], J)
            row = dict(seed=sd, n=n, cfg=name, opt=opt, cost=c.get('cost'), valid=c.get('valid'), decisions=r['decisions'], done=bool(r['success']) and c.get('valid', False), sec=round(time.time() - t, 1), jobs=J)
        except TO:
            row = dict(seed=sd, n=n, cfg=name, opt=opt, cost=None, valid=None, decisions=None, done=False, sec=150, jobs=J)
        res.append(row); print({k: v for k, v in row.items() if k != 'jobs'}, flush=True)
json.dump(res, open(f'sweep_sched_{n}.json', 'w'))
