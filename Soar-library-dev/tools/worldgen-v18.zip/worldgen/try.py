import json,sys,subprocess
# usage: try.py rulesfile mode seed cap [libs]
rules,mode,seed,cap=sys.argv[1:5]; lib=sys.argv[5] if len(sys.argv)>5 else '/tmp/s0/zip/default-world'
spec=dict(id='try',workdir='/home/claude/worldgen',seed=int(seed),cap=int(cap),mode=mode,commands=[f'pushd "{lib}"','source agent-world.soar','source simple.soar','pushd selection-world','source selection-world_source.soar','popd','pushd selection-iterative-deepening','source selection-iterative-deepening_source.soar','popd','popd',f'source {rules}'])
open('/tmp/try-spec.json','w').write(json.dumps(spec))
import os
B='/home/claude/soar966/x/SoarSuite_9.6.6-bigbugfixrelease-Multiplatform/bin/linux_x86-64'
env=dict(os.environ,PYTHONPATH=B+':/home/claude/soar-test/shim',LD_LIBRARY_PATH=B)
r=subprocess.run([sys.executable,'-I','/home/claude/soar-test/runner.py','/tmp/try-spec.json'],capture_output=True,text=True,env=env,timeout=300)
for l in r.stdout.splitlines():
    if l.startswith('@@RESULT@@'):
        d=json.loads(l[10:]); print({k:d.get(k) for k in ('load_errors','decisions','halted','firings','operators_selected','distinct_operator_names','output_lines')}); print('\n'.join(d.get('output_tail',[]))); print(d.get('productions'))
        break
else: print(r.stdout[-1500:], r.stderr[-800:])
