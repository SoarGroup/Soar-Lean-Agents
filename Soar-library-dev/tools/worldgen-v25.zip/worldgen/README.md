# World-convention task generators (draft)

wg.py: shared generator (initialize operator, problem space with only name + agent-world, flags on the top state, achievement rules, proposal template). `LAYOUT` flat | static (static properties under ^static; the generator refuses to emit a rule that writes a static attribute).
gen_counting.py, gen_waterjug.py: task generators (`python3 gen_X.py [flat|static]`). Operators follow the STEP6 variants; state access and goal tests follow the world conventions.
play.py runs a task against the stub environment and returns the actions; check_waterjug.py replays them independently and compares with a BFS optimum.
try.py: quick fingerprint run (env-complete mode).

Results (Soar 9.6.6): counting halts with success at 302 decisions in both layouts (identical firings). water-jug: seeds 1-5 all valid, goal reached, 4 actions = BFS optimum, 443-771 decisions, identical in both layouts.
Water jug uses ^flags.avoid-repeated-states true (the original look-ahead variant has the duplicate rule).

gen_arithmetic.py / check_arithmetic.py: two fixed problems (56 + 39, 83 - 47 with a borrow) solved by process-column / finish-problem with fact-object lookup; both layouts: seeds 1-3 give answers 95 and 36, 21 decisions, 6 actions.

gen_blocks.py: blocks world (look-ahead variant, canonical relation objects: on, derived clear, desired relations).
play.py picks the library from env WLIB (default /tmp/s0/zip/default-world = thor-soar.vsa.zip's default-world).

## Library version finding (13 Nov 2026)
The default-world in thor-soar.vsa.zip and the lib/ copy inside the 8 Nov world programs (mc, wizards, artists, zebra; "with the D-005 fix") differ in about 25 files.
- blocks world: never makes a move on the thor-zip default-world (nested look-ahead does not terminate); on the 8 Nov lib: 3 moves (optimal), 998 decisions.
- water jug (avoid-repeated-states true): thor-zip lib: optimal 4 moves, seeds 1-5; 8 Nov lib: 6-7 moves for seeds 1-3, no move in 5000 decisions for seeds 4-5.
- arithmetic: 21 decisions on the thor-zip lib; on the 8 Nov lib seeds 1-2 give 32 decisions, seed 3 405 decisions and duplicated answer lines (not diagnosed).
- counting: same on both.

## v20 (17 Nov 2026): duplicate-proposal fix
Proposal templates test `^unachieved-desireds true` instead of `^unachieved <any-unachieved>` (one operator per unachieved desired before, which could tie or conflict). Same plans; far fewer decisions in look-ahead tasks. All *-rules.soar files updated.

## v18 (15 Nov 2026): literal object handles
`wg.Task(..., literal_handles=True)` (the default) writes every LHS object-handle test as `^object-handle $ <h>` (World-Conventions-Spec-v6, W-CHK-011), except inside negated conditions (Soar 9.6.50 reports "bad test type in hash_test" there); it never puts $ inside a { ... } test with a relational test (that crashes Soar 9.6.50). Reason: chunks otherwise variablize handles with no inequality and can fire for another object (Hanoi, FINDING-chunking-overgeneral.md). All generated *rules*.soar files in this folder were updated in place.

## v21 (18 Nov 2026): conventions decided on 18 Nov
`convpass.py` is a final pass over every generated rule text (`wg.Task.text()` calls it), applying the conventions of World-Conventions-v6 / Soar-Conventions as reviewed on 18 Nov 2026 (level-based IDs):
- L3-005: every rule tests, in its first condition, the name of its state or of its problem space. World and desired elaborations, internal operator applications and environment-effect rules now test `^problem-space.name <task>`; an operator application tests the problem space its proposal tests. Exceptions: initialization, the problem-space elaborations (including the one for an operator no-change substate), and rules that only pass structure from a superstate into every substate (`(state <s> ^superstate.<attr> <x>)`).
- L3-012: a rule group (rules for the same operator or purpose) without an English comment gets one, built from the rule's name, problem space and the attributes it changes.
- L3-039 / L3-083: with `rl=True` the pass also removes indifferent preferences from proposals (used by the families tools for RL variants).
The pass is idempotent. The three *-rules.soar files here were passed through it. Checked with test set v1.37: all 198 generated tests keep their decisions, operator traces, outputs and halting; elaboration cycles (195 tests), firings (49) and WME changes (18) moved and were re-baselined.

## v22 (18 Nov 2026, evening): comment detection fixed
v21 shipped an earlier copy of `convpass.py` in which a comment followed by blank lines counted as the comment of the next rule, so a file header could stand in for the first rule group's comment. v22 has the final copy (the one in `soarlean-agentgen-2026-11-18b.zip` and `families-v6-tools.zip`, and the one test set v1.37 was made with): a group's comment must end on the line just before its first rule. The three *-rules.soar files were passed through it again (comments only). Rules and behaviour are otherwise unchanged from v21.

## v23 (24 Nov 2026): phases and loops, output form, flags comment (library v2.47)
`wg.py` and `world_backend.py` are the copies in `SoarLean/worldgen` (byte-identical with `Tasks/From-English/rosie-teaching/tools/wg.py`).
- Phases and loops (World-Conventions L8-026 to L8-030): `wg.Task.phases`, `loop_start`, `termination`, `repeat_count`.
- Declared output form (L10-018): `wg.Task.output` or the environment variable `WG_OUTPUT`.
- `wg.Task.flags_comment`: a comment above the flags rule. `gen_blocks.py` sets it to the note on how its search setting was measured, which the test set's blocks-world rules had carried since it was added by hand; `blocks-world-rules.soar` here now has it too.
Without these fields every generator writes what it wrote before: all gen_*.py outputs (flat and static) equal the test set's stored rules byte for byte.

## v24 (25 Nov 2026)
wg.py of SoarLean-2026-11-25d-release.zip: `Task.text()` leaves out redundant object tests (World-Conventions L3-104,
`drop_redundant_object_tests`) and opens the rules, after the header, with matching hints (L11-009, `match_hints`:
`production optimize-attribute` for `object` and every attribute the rules add to `<w>`, sized from the initialize rule).
`wg.finish` does both for generators that write rules without `Task` (the English-world gen.py files). The three stored
rules files were regenerated; the test set's generated programs carry the same change (test set v1.41).

## v25 (27 Nov 2026)
wg.py, convpass.py and the new static_pass.py of SoarLean-2026-11-27-release.zip, for library v2.48.
- `convpass.no_precondition_form` (World-Conventions L9-011): an operator with no preconditions is proposed with
  `^pre-conditions-satisfied true` in place of an empty `^desireds` structure (skipped when a rule tests the operator's
  `^desireds`).
- `static_pass.mark_static` (L7-028, L7-017 to L7-024): called by `wg` after the rules are written. Objects no rule other
  than the initialize rule changes get `^static true`; relations no operator changes whose arguments are all static are
  declared with `^share-relation`; with look-ahead, a type with at least 3 constant properties no rule writes keeps them
  under `^fixed` (criteria in L7-022, including the 27 Nov criterion on non-constant attribute tests).
The three stored rules files were regenerated (static marks and L9-011); the test set's generated programs carry the
same change (test set v1.42). No gen_*.py output meets the `^fixed` criteria.
