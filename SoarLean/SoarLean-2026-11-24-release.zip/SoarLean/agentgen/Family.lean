import Family.Prod
import Family.Task
import Family.Families.Arithmetic
import Family.Families.BlocksWorld
import Family.Families.Counting
import Family.Families.EightPuzzle
import Family.Families.HelloWorld
import Family.Families.Kenken
import Family.Families.Knights
import Family.Families.LeftRight
import Family.Families.MissionariesCannibals
import Family.Families.Pyramid
import Family.Families.Tictactoe
import Family.Families.TowersOfHanoi
import Family.Families.WaterJug
import Family.Families.Wizards

namespace Fam
/-- Every family's variants. -/
def allVariants : List Variant :=
  Families.Arithmetic.variants
  ++ Families.BlocksWorld.variants
  ++ Families.Counting.variants
  ++ Families.EightPuzzle.variants
  ++ Families.HelloWorld.variants
  ++ Families.Kenken.variants
  ++ Families.Knights.variants
  ++ Families.LeftRight.variants
  ++ Families.MissionariesCannibals.variants
  ++ Families.Pyramid.variants
  ++ Families.Tictactoe.variants
  ++ Families.TowersOfHanoi.variants
  ++ Families.WaterJug.variants
  ++ Families.Wizards.variants
end Fam
