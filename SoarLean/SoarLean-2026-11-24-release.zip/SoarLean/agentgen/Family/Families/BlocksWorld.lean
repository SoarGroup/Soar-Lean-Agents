import Family.Task
set_option maxHeartbeats 0
set_option maxRecDepth 100000
/-!
# blocks-world: world-convention agents of the blocks-world family

Typed description migrated on 19 November 2026 from the world-v6 agents (Tasks/Families/blocks-world/world-v6),
which were written from the original programs. Task-level parts are `Task` fields; family knowledge is typed
productions, defined once and shared by the variants that use them.

Written 19 November 2026 by Claude, supervised by John E. Laird.
-/
namespace Fam.Families.BlocksWorld
open Fam

def r_blocks_world_elaborate_in_place_table : Prod :=
  { name := "blocks-world*elaborate*in-place*table",
    doc := ["Derived (dont-copy): the table is in place; a block is in place when it is on what its desired names and that", "is in place."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "blocks-world"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "objects", .sym "object"], vals := [.var "t"] }],
        .pos false (.var "t") [{ path := [.sym "type"], vals := [.sym "table"] }]],
    acts := [.make (.var "t") [([.sym "in-place"], [{ val := .sym "true" }])]] }

def r_blocks_world_elaborate_in_place_block : Prod :=
  { name := "blocks-world*elaborate*in-place*block",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "blocks-world"] }, { path := [.sym "desireds", .sym "desired", .sym "on"], vals := [.var "dr"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "dr") [{ path := [.sym "argument1", .sym "object-handle"], vals := [.lit (.var "bh")] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.lit (.var "uh")] }],
        .pos false (.var "w") [{ path := [.sym "objects", .sym "object"], vals := [.var "b", .var "u"] }, { path := [.sym "on"], vals := [.var "on"] }],
        .pos false (.var "b") [{ path := [.sym "object-handle"], vals := [.lit (.var "bh")] }],
        .pos false (.var "u") [{ path := [.sym "object-handle"], vals := [.lit (.var "uh")] }, { path := [.sym "in-place"], vals := [.sym "true"] }],
        .pos false (.var "on") [{ path := [.sym "argument1"], vals := [.var "b"] }, { path := [.sym "argument2"], vals := [.var "u"] }]],
    acts := [.make (.var "b") [([.sym "in-place"], [{ val := .sym "true" }])]] }

def r_blocks_world_propose_move_block : Prod :=
  { name := "blocks-world*propose*move-block",
    doc := ["move-block <block> <dest> (composite, W-COP-002): a free block, when the gripper holds nothing else, onto a", "free destination that is not held.  Effect: the block is on the destination.  As in the original, one", "proposal covers both the free and the held block, so the operator stays selected throughout."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "blocks-world"] }, { path := [.sym "flags", .sym "mea-operator-selection"], vals := [.sym "true"] }, { path := [.sym "desireds", .sym "unachieved-desireds"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "b", .conj [.cmp "<>" (.var "b"), .var "d"], .var "g"] }, { path := [.sym "on"], vals := [.var "on"] }],
        .pos false (.var "b") [{ path := [.sym "type"], vals := [.sym "block"] }, { path := [.sym "free"], vals := [.sym "true"] }, { path := [.sym "object-handle"], vals := [.lit (.var "bh")] }],
        .pos false (.var "d") [{ path := [.sym "free"], vals := [.sym "true"] }, { path := [.sym "object-handle"], vals := [.lit (.var "dh")] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "gripper"] }],
        .ncc [.pos false (.var "g") [{ path := [.sym "empty"], vals := [.int (0)] }, { path := [.sym "holding"], vals := [.cmp "<>" (.var "bh")] }]],
        .ncc [.pos false (.var "g") [{ path := [.sym "empty"], vals := [.int (0)] }, { path := [.sym "holding"], vals := [.var "dh"] }]],
        .pos false (.var "on") [{ path := [.sym "argument1"], vals := [.var "b"] }, { path := [.sym "argument2"], vals := [.cmp "<>" (.var "d")] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "move-block" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "argument1"], [{ val := .var "b" }]), ([.sym "argument2"], [{ val := .var "d" }]), ([.sym "argument-count"], [{ val := .int (2) }]), ([.sym "desireds"], [{ val := .var "pre" }]), ([.sym "effect-desireds"], [{ val := .var "ed" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (0) }])],
        .make (.var "ed") [([.sym "desired-count"], [{ val := .int (1) }]), ([.sym "desired"], [{ val := .var "e1" }])],
        .make (.var "e1") [([.sym "on"], [{ val := .var "e1r" }])],
        .make (.var "e1r") [([.sym "argument1"], [{ val := .var "e1a" }]), ([.sym "argument2"], [{ val := .var "e1b" }])],
        .make (.var "e1a") [([.sym "object-handle"], [{ val := .var "bh" }])],
        .make (.var "e1b") [([.sym "object-handle"], [{ val := .var "dh" }])]] }

def r_blocks_world_propose_pick_up : Prod :=
  { name := "blocks-world*propose*pick-up",
    doc := ["In move-block's implementation substate (problem space move-block, ^argument1 block, ^argument2 dest):", "pick-up when the gripper is empty and the block is free; put-down when the gripper holds the block."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "move-block"] }, { path := [.sym "argument1"], vals := [.var "b"] }, { path := [.sym "argument2"], vals := [.var "d"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "b") [{ path := [.sym "free"], vals := [.sym "true"] }, { path := [.sym "object-handle"], vals := [.var "bh"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "g"] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "gripper"] }, { path := [.sym "empty"], vals := [.int (1)] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+ =" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "pick-up" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "argument1"], [{ val := .var "b" }]), ([.sym "argument2"], [{ val := .var "d" }]), ([.sym "argument-count"], [{ val := .int (2) }]), ([.sym "desireds"], [{ val := .var "pre" }]), ([.sym "effect-desireds"], [{ val := .var "ed" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (0) }])],
        .make (.var "ed") [([.sym "desired-count"], [{ val := .int (2) }]), ([.sym "desired"], [{ val := .var "e1" }, { val := .var "e2" }])],
        .make (.var "e1") [([.sym "object"], [{ val := .var "e1o" }])],
        .make (.var "e1o") [([.sym "object-handle"], [{ val := .sym "gripper" }]), ([.sym "empty"], [{ val := .int (0) }])],
        .make (.var "e2") [([.sym "object"], [{ val := .var "e2o" }])],
        .make (.var "e2o") [([.sym "object-handle"], [{ val := .sym "gripper" }]), ([.sym "holding"], [{ val := .var "bh" }])]] }

def r_blocks_world_propose_put_down : Prod :=
  { name := "blocks-world*propose*put-down",
    doc := ["Propose put-down in problem space move-block when its conditions below hold."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "move-block"] }, { path := [.sym "argument1"], vals := [.var "b"] }, { path := [.sym "argument2"], vals := [.var "d"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "b") [{ path := [.sym "object-handle"], vals := [.lit (.var "bh")] }],
        .pos false (.var "d") [{ path := [.sym "object-handle"], vals := [.var "dh"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "g"] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "gripper"] }, { path := [.sym "empty"], vals := [.int (0)] }, { path := [.sym "holding"], vals := [.lit (.var "bh")] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+ =" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "put-down" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "argument1"], [{ val := .var "b" }]), ([.sym "argument2"], [{ val := .var "d" }]), ([.sym "argument-count"], [{ val := .int (2) }]), ([.sym "desireds"], [{ val := .var "pre" }]), ([.sym "effect-desireds"], [{ val := .var "ed" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (0) }])],
        .make (.var "ed") [([.sym "desired-count"], [{ val := .int (2) }]), ([.sym "desired"], [{ val := .var "e1" }, { val := .var "e2" }])],
        .make (.var "e1") [([.sym "on"], [{ val := .var "e1r" }])],
        .make (.var "e1r") [([.sym "argument1"], [{ val := .var "e1a" }]), ([.sym "argument2"], [{ val := .var "e1b" }])],
        .make (.var "e1a") [([.sym "object-handle"], [{ val := .var "bh" }])],
        .make (.var "e1b") [([.sym "object-handle"], [{ val := .var "dh" }])],
        .make (.var "e2") [([.sym "object"], [{ val := .var "e2o" }])],
        .make (.var "e2o") [([.sym "object-handle"], [{ val := .sym "gripper" }]), ([.sym "empty"], [{ val := .int (1) }])]] }

def r_blocks_world_compare_out_of_place_to_table : Prod :=
  { name := "blocks-world*compare*out-of-place-to-table",
    doc := ["Search control of the original: a block that is not in place goes to the table (best) ..."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "blocks-world"] }, { path := [.sym "operator"], vals := [.var "o", .sym "+"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "move-block"] }, { path := [.sym "argument1"], vals := [.var "b"] }, { path := [.sym "argument2", .sym "type"], vals := [.sym "table"] }],
        .pos false (.var "b") [{ path := [.sym "in-place"], vals := [.sym "true"], neg := true }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := ">" }])]] }

def r_blocks_world_compare_onto_desired_in_place : Prod :=
  { name := "blocks-world*compare*onto-desired-in-place",
    doc := ["... and a move onto the block's desired destination, when that is in place, is better than any other."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "blocks-world"] }, { path := [.sym "operator"], vals := [.var "o", .sym "+"] }, { path := [.sym "operator"], vals := [.conj [.cmp "<>" (.var "o"), .var "o2"], .sym "+"] }, { path := [.sym "desireds", .sym "desired", .sym "on"], vals := [.var "dr"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "move-block"] }, { path := [.sym "argument1", .sym "object-handle"], vals := [.var "bh"] }, { path := [.sym "argument2"], vals := [.var "d"] }],
        .pos false (.var "d") [{ path := [.sym "object-handle"], vals := [.var "dh"] }, { path := [.sym "in-place"], vals := [.sym "true"] }],
        .pos false (.var "dr") [{ path := [.sym "argument1", .sym "object-handle"], vals := [.var "bh"] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.var "dh"] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "> <o2>" }])]] }

def r_blocks_world_propose_move_gripper_above : Prod :=
  { name := "blocks-world*propose*move-gripper-above",
    doc := ["Propose move-gripper-above in problem space pick-up when its conditions below hold."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "pick-up"] }, { path := [.sym "argument1"], vals := [.var "b"] }, { path := [.sym "argument2"], vals := [.var "d"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "b") [{ path := [.sym "object-handle"], vals := [.lit (.var "bh")] }],
        .pos false (.var "d") [{ path := [.sym "object-handle"], vals := [.lit (.var "dh")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "g"] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "gripper"] }, { path := [.sym "position"], vals := [.int (1)] }, { path := [.sym "empty"], vals := [.int (1)] }, { path := [.sym "above"], vals := [.conj [.cmp "<>" (.var "bh"), .var "ab"]] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+ =" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "move-gripper-above" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "action-handle"], [{ val := .sym "move-gripper-above" }]), ([.sym "argument1"], [{ val := .var "b" }]), ([.sym "argument2"], [{ val := .var "d" }]), ([.sym "argument-count"], [{ val := .int (2) }]), ([.sym "desireds"], [{ val := .var "pre" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (0) }])]] }

def r_blocks_world_apply_move_gripper_above_internal : Prod :=
  { name := "blocks-world*apply*move-gripper-above*internal",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "pick-up"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "internal-actions"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "move-gripper-above"] }, { path := [.sym "pre-conditions-satisfied"], vals := [.sym "true"] }, { path := [.sym "argument1", .sym "object-handle"], vals := [.lit (.var "bh")] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.lit (.var "dh")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "g"] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "gripper"] }, { path := [.sym "position"], vals := [.int (1)] }, { path := [.sym "empty"], vals := [.int (1)] }, { path := [.sym "above"], vals := [.conj [.cmp "<>" (.var "bh"), .var "ab"]] }]],
    acts := [.call "log" [.int (1), .fn "crlf" [], .str "Move gripper above ", .var "bh"],
        .make (.var "g") [([.sym "above"], [{ val := .var "ab", pref := "-" }, { val := .var "bh" }])]] }

def r_blocks_world_propose_move_gripper_down : Prod :=
  { name := "blocks-world*propose*move-gripper-down",
    doc := ["Propose move-gripper-down in problem space pick-up when its conditions below hold."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "pick-up"] }, { path := [.sym "argument1"], vals := [.var "b"] }, { path := [.sym "argument2"], vals := [.var "d"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "b") [{ path := [.sym "object-handle"], vals := [.lit (.var "bh")] }],
        .pos false (.var "d") [{ path := [.sym "object-handle"], vals := [.lit (.var "dh")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "g"] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "gripper"] }, { path := [.sym "position"], vals := [.int (1)] }, { path := [.sym "empty"], vals := [.int (1)] }, { path := [.sym "above"], vals := [.lit (.var "bh")] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+ =" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "move-gripper-down" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "action-handle"], [{ val := .sym "move-gripper-down" }]), ([.sym "argument1"], [{ val := .var "b" }]), ([.sym "argument2"], [{ val := .var "d" }]), ([.sym "argument-count"], [{ val := .int (2) }]), ([.sym "desireds"], [{ val := .var "pre" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (0) }])]] }

def r_blocks_world_apply_move_gripper_down_internal : Prod :=
  { name := "blocks-world*apply*move-gripper-down*internal",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "pick-up"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "internal-actions"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "move-gripper-down"] }, { path := [.sym "pre-conditions-satisfied"], vals := [.sym "true"] }, { path := [.sym "argument1", .sym "object-handle"], vals := [.lit (.var "bh")] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.lit (.var "dh")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "g"] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "gripper"] }, { path := [.sym "position"], vals := [.int (1)] }, { path := [.sym "empty"], vals := [.int (1)] }, { path := [.sym "above"], vals := [.lit (.var "bh")] }]],
    acts := [.call "log" [.int (1), .fn "crlf" [], .str "Move gripper down"],
        .make (.var "g") [([.sym "position"], [{ val := .int (1), pref := "-" }, { val := .int (0) }])]] }

def r_blocks_world_propose_close_gripper : Prod :=
  { name := "blocks-world*propose*close-gripper",
    doc := ["Propose close-gripper in problem space pick-up when its conditions below hold."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "pick-up"] }, { path := [.sym "argument1"], vals := [.var "b"] }, { path := [.sym "argument2"], vals := [.var "d"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "b") [{ path := [.sym "object-handle"], vals := [.lit (.var "bh")] }],
        .pos false (.var "d") [{ path := [.sym "object-handle"], vals := [.lit (.var "dh")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "g"] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "gripper"] }, { path := [.sym "position"], vals := [.int (0)] }, { path := [.sym "open"], vals := [.int (1)] }, { path := [.sym "empty"], vals := [.int (1)] }, { path := [.sym "above"], vals := [.lit (.var "bh")] }, { path := [.sym "holding"], vals := [.var "hd"] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+ =" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "close-gripper" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "action-handle"], [{ val := .sym "close-gripper" }]), ([.sym "argument1"], [{ val := .var "b" }]), ([.sym "argument2"], [{ val := .var "d" }]), ([.sym "argument-count"], [{ val := .int (2) }]), ([.sym "desireds"], [{ val := .var "pre" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (0) }])]] }

def r_blocks_world_apply_close_gripper_internal : Prod :=
  { name := "blocks-world*apply*close-gripper*internal",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "pick-up"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "internal-actions"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "close-gripper"] }, { path := [.sym "pre-conditions-satisfied"], vals := [.sym "true"] }, { path := [.sym "argument1", .sym "object-handle"], vals := [.lit (.var "bh")] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.lit (.var "dh")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "g"] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "gripper"] }, { path := [.sym "position"], vals := [.int (0)] }, { path := [.sym "open"], vals := [.int (1)] }, { path := [.sym "empty"], vals := [.int (1)] }, { path := [.sym "above"], vals := [.lit (.var "bh")] }, { path := [.sym "holding"], vals := [.var "hd"] }]],
    acts := [.call "log" [.int (1), .fn "crlf" [], .str "Close gripper on ", .var "bh"],
        .make (.var "g") [([.sym "open"], [{ val := .int (1), pref := "-" }, { val := .int (0) }]), ([.sym "empty"], [{ val := .int (1), pref := "-" }, { val := .int (0) }]), ([.sym "holding"], [{ val := .var "hd", pref := "-" }, { val := .var "bh" }])]] }

def r_blocks_world_propose_move_gripper_up : Prod :=
  { name := "blocks-world*propose*move-gripper-up",
    doc := ["Propose move-gripper-up in problem space pick-up when its conditions below hold."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "pick-up"] }, { path := [.sym "argument1"], vals := [.var "b"] }, { path := [.sym "argument2"], vals := [.var "d"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "b") [{ path := [.sym "object-handle"], vals := [.lit (.var "bh")] }],
        .pos false (.var "d") [{ path := [.sym "object-handle"], vals := [.lit (.var "dh")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "g"] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "gripper"] }, { path := [.sym "position"], vals := [.int (0)] }, { path := [.sym "empty"], vals := [.int (1)] }, { path := [.sym "above"], vals := [.cmp "<>" (.var "bh")] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+ =" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "move-gripper-up" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "action-handle"], [{ val := .sym "move-gripper-up" }]), ([.sym "argument1"], [{ val := .var "b" }]), ([.sym "argument2"], [{ val := .var "d" }]), ([.sym "argument-count"], [{ val := .int (2) }]), ([.sym "desireds"], [{ val := .var "pre" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (0) }])]] }

def r_blocks_world_apply_move_gripper_up_internal : Prod :=
  { name := "blocks-world*apply*move-gripper-up*internal",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "pick-up"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "internal-actions"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "move-gripper-up"] }, { path := [.sym "pre-conditions-satisfied"], vals := [.sym "true"] }, { path := [.sym "argument1", .sym "object-handle"], vals := [.lit (.var "bh")] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.lit (.var "dh")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "g"] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "gripper"] }, { path := [.sym "position"], vals := [.int (0)] }, { path := [.sym "empty"], vals := [.int (1)] }, { path := [.sym "above"], vals := [.cmp "<>" (.var "bh")] }]],
    acts := [.call "log" [.int (1), .fn "crlf" [], .str "Move gripper up"],
        .make (.var "g") [([.sym "position"], [{ val := .int (0), pref := "-" }, { val := .int (1) }])]] }

def r_blocks_world_propose_move_gripper_up_holding : Prod :=
  { name := "blocks-world*propose*move-gripper-up-holding",
    doc := ["Propose move-gripper-up-holding in problem space put-down when its conditions below hold."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "put-down"] }, { path := [.sym "argument1"], vals := [.var "b"] }, { path := [.sym "argument2"], vals := [.var "d"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "b") [{ path := [.sym "object-handle"], vals := [.lit (.var "bh")] }],
        .pos false (.var "d") [{ path := [.sym "object-handle"], vals := [.lit (.var "dh")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "g"] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "gripper"] }, { path := [.sym "position"], vals := [.int (0)] }, { path := [.sym "above"], vals := [.cmp "<>" (.var "dh")] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+ =" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "move-gripper-up-holding" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "action-handle"], [{ val := .sym "move-gripper-up-holding" }]), ([.sym "argument1"], [{ val := .var "b" }]), ([.sym "argument2"], [{ val := .var "d" }]), ([.sym "argument-count"], [{ val := .int (2) }]), ([.sym "desireds"], [{ val := .var "pre" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (0) }])]] }

def r_blocks_world_apply_move_gripper_up_holding_internal : Prod :=
  { name := "blocks-world*apply*move-gripper-up-holding*internal",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "put-down"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "internal-actions"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "move-gripper-up-holding"] }, { path := [.sym "pre-conditions-satisfied"], vals := [.sym "true"] }, { path := [.sym "argument1", .sym "object-handle"], vals := [.lit (.var "bh")] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.lit (.var "dh")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "g"] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "gripper"] }, { path := [.sym "position"], vals := [.int (0)] }, { path := [.sym "above"], vals := [.cmp "<>" (.var "dh")] }]],
    acts := [.call "log" [.int (1), .fn "crlf" [], .str "Move gripper up (holding)"],
        .make (.var "g") [([.sym "position"], [{ val := .int (0), pref := "-" }, { val := .int (1) }])]] }

def r_blocks_world_propose_move_gripper_above_destination : Prod :=
  { name := "blocks-world*propose*move-gripper-above-destination",
    doc := ["Propose move-gripper-above-destination in problem space put-down when its conditions below hold."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "put-down"] }, { path := [.sym "argument1"], vals := [.var "b"] }, { path := [.sym "argument2"], vals := [.var "d"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "b") [{ path := [.sym "object-handle"], vals := [.lit (.var "bh")] }],
        .pos false (.var "d") [{ path := [.sym "object-handle"], vals := [.lit (.var "dh")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "g"] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "gripper"] }, { path := [.sym "position"], vals := [.int (1)] }, { path := [.sym "above"], vals := [.conj [.cmp "<>" (.var "dh"), .var "ab"]] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+ =" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "move-gripper-above-destination" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "action-handle"], [{ val := .sym "move-gripper-above-destination" }]), ([.sym "argument1"], [{ val := .var "b" }]), ([.sym "argument2"], [{ val := .var "d" }]), ([.sym "argument-count"], [{ val := .int (2) }]), ([.sym "desireds"], [{ val := .var "pre" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (0) }])]] }

def r_blocks_world_apply_move_gripper_above_destination_internal : Prod :=
  { name := "blocks-world*apply*move-gripper-above-destination*internal",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "put-down"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "internal-actions"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "move-gripper-above-destination"] }, { path := [.sym "pre-conditions-satisfied"], vals := [.sym "true"] }, { path := [.sym "argument1", .sym "object-handle"], vals := [.lit (.var "bh")] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.lit (.var "dh")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "g"] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "gripper"] }, { path := [.sym "position"], vals := [.int (1)] }, { path := [.sym "above"], vals := [.conj [.cmp "<>" (.var "dh"), .var "ab"]] }]],
    acts := [.call "log" [.int (1), .fn "crlf" [], .str "Move gripper above destination ", .var "dh"],
        .make (.var "g") [([.sym "above"], [{ val := .var "ab", pref := "-" }, { val := .var "dh" }])]] }

def r_blocks_world_propose_move_gripper_down_holding : Prod :=
  { name := "blocks-world*propose*move-gripper-down-holding",
    doc := ["Propose move-gripper-down-holding in problem space put-down when its conditions below hold."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "put-down"] }, { path := [.sym "argument1"], vals := [.var "b"] }, { path := [.sym "argument2"], vals := [.var "d"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "b") [{ path := [.sym "object-handle"], vals := [.lit (.var "bh")] }],
        .pos false (.var "d") [{ path := [.sym "object-handle"], vals := [.lit (.var "dh")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "g"] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "gripper"] }, { path := [.sym "position"], vals := [.int (1)] }, { path := [.sym "above"], vals := [.lit (.var "dh")] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+ =" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "move-gripper-down-holding" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "action-handle"], [{ val := .sym "move-gripper-down-holding" }]), ([.sym "argument1"], [{ val := .var "b" }]), ([.sym "argument2"], [{ val := .var "d" }]), ([.sym "argument-count"], [{ val := .int (2) }]), ([.sym "desireds"], [{ val := .var "pre" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (0) }])]] }

def r_blocks_world_apply_move_gripper_down_holding_internal : Prod :=
  { name := "blocks-world*apply*move-gripper-down-holding*internal",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "put-down"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "internal-actions"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "move-gripper-down-holding"] }, { path := [.sym "pre-conditions-satisfied"], vals := [.sym "true"] }, { path := [.sym "argument1", .sym "object-handle"], vals := [.lit (.var "bh")] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.lit (.var "dh")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "g"] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "gripper"] }, { path := [.sym "position"], vals := [.int (1)] }, { path := [.sym "above"], vals := [.lit (.var "dh")] }]],
    acts := [.call "log" [.int (1), .fn "crlf" [], .str "Move gripper down (holding)"],
        .make (.var "g") [([.sym "position"], [{ val := .int (1), pref := "-" }, { val := .int (0) }])]] }

def r_blocks_world_propose_open_gripper : Prod :=
  { name := "blocks-world*propose*open-gripper",
    doc := ["Propose open-gripper in problem space put-down when its conditions below hold."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "put-down"] }, { path := [.sym "argument1"], vals := [.var "b"] }, { path := [.sym "argument2"], vals := [.var "d"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "b") [{ path := [.sym "object-handle"], vals := [.lit (.var "bh")] }],
        .pos false (.var "d") [{ path := [.sym "object-handle"], vals := [.lit (.var "dh")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "g"] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "gripper"] }, { path := [.sym "position"], vals := [.int (0)] }, { path := [.sym "open"], vals := [.int (0)] }, { path := [.sym "above"], vals := [.lit (.var "dh")] }, { path := [.sym "empty"], vals := [.var "e"] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+ =" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "open-gripper" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "action-handle"], [{ val := .sym "open-gripper" }]), ([.sym "argument1"], [{ val := .var "b" }]), ([.sym "argument2"], [{ val := .var "d" }]), ([.sym "argument-count"], [{ val := .int (2) }]), ([.sym "desireds"], [{ val := .var "pre" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (0) }])]] }

def r_blocks_world_apply_open_gripper_internal : Prod :=
  { name := "blocks-world*apply*open-gripper*internal",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "put-down"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "internal-actions"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "open-gripper"] }, { path := [.sym "pre-conditions-satisfied"], vals := [.sym "true"] }, { path := [.sym "argument1", .sym "object-handle"], vals := [.lit (.var "bh")] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.lit (.var "dh")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "g"] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "gripper"] }, { path := [.sym "position"], vals := [.int (0)] }, { path := [.sym "open"], vals := [.int (0)] }, { path := [.sym "above"], vals := [.lit (.var "dh")] }, { path := [.sym "empty"], vals := [.var "e"] }]],
    acts := [.call "log" [.int (1), .fn "crlf" [], .str "Open gripper: ", .var "bh", .str " on ", .var "dh"],
        .make (.var "g") [([.sym "open"], [{ val := .int (0), pref := "-" }, { val := .int (1) }]), ([.sym "empty"], [{ val := .var "e", pref := "-" }, { val := .int (1) }]), ([.sym "above"], [{ val := .var "dh", pref := "-" }, { val := .var "bh" }])]] }

def r_blocks_world_apply_open_gripper_internal_on : Prod :=
  { name := "blocks-world*apply*open-gripper*internal*on",
    doc := ["The block now rests on the destination: on moves, and free is maintained (the old support becomes free, a", "block destination stops being free)."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "put-down"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "internal-actions"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "open-gripper"] }, { path := [.sym "pre-conditions-satisfied"], vals := [.sym "true"] }, { path := [.sym "argument1", .sym "object-handle"], vals := [.lit (.var "bh")] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.lit (.var "dh")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "b", .var "d", .var "g"] }, { path := [.sym "on"], vals := [.var "on"] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "gripper"] }, { path := [.sym "above"], vals := [.lit (.var "dh")] }, { path := [.sym "position"], vals := [.int (0)] }, { path := [.sym "open"], vals := [.int (0)] }],
        .pos false (.var "b") [{ path := [.sym "object-handle"], vals := [.lit (.var "bh")] }],
        .pos false (.var "d") [{ path := [.sym "object-handle"], vals := [.lit (.var "dh")] }],
        .pos false (.var "on") [{ path := [.sym "argument1"], vals := [.var "b"] }, { path := [.sym "argument2"], vals := [.var "old"] }]],
    acts := [.make (.var "on") [([.sym "argument2"], [{ val := .var "old", pref := "-" }, { val := .var "d" }])]] }

def r_blocks_world_apply_open_gripper_internal_free_old : Prod :=
  { name := "blocks-world*apply*open-gripper*internal*free-old",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "put-down"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "internal-actions"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "open-gripper"] }, { path := [.sym "pre-conditions-satisfied"], vals := [.sym "true"] }, { path := [.sym "argument1", .sym "object-handle"], vals := [.lit (.var "bh")] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.lit (.var "dh")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "b", .var "g"] }, { path := [.sym "on"], vals := [.var "on"] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "gripper"] }, { path := [.sym "above"], vals := [.lit (.var "dh")] }, { path := [.sym "position"], vals := [.int (0)] }, { path := [.sym "open"], vals := [.int (0)] }],
        .pos false (.var "b") [{ path := [.sym "object-handle"], vals := [.lit (.var "bh")] }],
        .pos false (.var "on") [{ path := [.sym "argument1"], vals := [.var "b"] }, { path := [.sym "argument2"], vals := [.var "old"] }],
        .pos false (.var "old") [{ path := [.sym "type"], vals := [.sym "block"] }, { path := [.sym "free"], vals := [.sym "false"] }]],
    acts := [.make (.var "old") [([.sym "free"], [{ val := .sym "false", pref := "-" }, { val := .sym "true" }])]] }

def r_blocks_world_apply_open_gripper_internal_cover_dest : Prod :=
  { name := "blocks-world*apply*open-gripper*internal*cover-dest",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "put-down"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "internal-actions"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "open-gripper"] }, { path := [.sym "pre-conditions-satisfied"], vals := [.sym "true"] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.lit (.var "dh")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "d", .var "g"] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "gripper"] }, { path := [.sym "above"], vals := [.lit (.var "dh")] }, { path := [.sym "position"], vals := [.int (0)] }, { path := [.sym "open"], vals := [.int (0)] }],
        .pos false (.var "d") [{ path := [.sym "object-handle"], vals := [.lit (.var "dh")] }, { path := [.sym "type"], vals := [.sym "block"] }, { path := [.sym "free"], vals := [.sym "true"] }]],
    acts := [.make (.var "d") [([.sym "free"], [{ val := .sym "true", pref := "-" }, { val := .sym "false" }])]] }

def r_blocks_world_propose_move_block_2 : Prod :=
  { name := "blocks-world*propose*move-block",
    doc := ["move-block <block> <dest> (composite): a free block onto a free destination.  Effect: the block on dest."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "blocks-world"] }, { path := [.sym "flags", .sym "mea-operator-selection"], vals := [.sym "true"] }, { path := [.sym "desireds", .sym "unachieved-desireds"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "b", .conj [.cmp "<>" (.var "b"), .var "d"]] }, { path := [.sym "on"], vals := [.var "on"] }],
        .pos false (.var "b") [{ path := [.sym "type"], vals := [.sym "block"] }, { path := [.sym "free"], vals := [.sym "true"] }, { path := [.sym "object-handle"], vals := [.lit (.var "bh")] }],
        .pos false (.var "d") [{ path := [.sym "free"], vals := [.sym "true"] }, { path := [.sym "object-handle"], vals := [.lit (.var "dh")] }],
        .pos false (.var "on") [{ path := [.sym "argument1"], vals := [.var "b"] }, { path := [.sym "argument2"], vals := [.cmp "<>" (.var "d")] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "move-block" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "argument1"], [{ val := .var "b" }]), ([.sym "argument2"], [{ val := .var "d" }]), ([.sym "argument-count"], [{ val := .int (2) }]), ([.sym "desireds"], [{ val := .var "pre" }]), ([.sym "effect-desireds"], [{ val := .var "ed" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (0) }])],
        .make (.var "ed") [([.sym "desired-count"], [{ val := .int (1) }]), ([.sym "desired"], [{ val := .var "e1" }])],
        .make (.var "e1") [([.sym "on"], [{ val := .var "e1r" }])],
        .make (.var "e1r") [([.sym "argument1"], [{ val := .var "e1a" }]), ([.sym "argument2"], [{ val := .var "e1b" }])],
        .make (.var "e1a") [([.sym "object-handle"], [{ val := .var "bh" }])],
        .make (.var "e1b") [([.sym "object-handle"], [{ val := .var "dh" }])]] }

def r_blocks_world_propose_pick_up_2 : Prod :=
  { name := "blocks-world*propose*pick-up",
    doc := ["In move-block's substate: pick-up <x> of any free block when the gripper is empty; put-down <y> <d> of the", "held block onto any free object that is not held (task-action operators; RL chooses)."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "move-block"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "x", .var "g"] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "gripper"] }, { path := [.sym "empty"], vals := [.int (1)] }],
        .pos false (.var "x") [{ path := [.sym "type"], vals := [.sym "block"] }, { path := [.sym "free"], vals := [.sym "true"] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "pick-up" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "action-handle"], [{ val := .sym "pick-up" }]), ([.sym "argument1"], [{ val := .var "x" }]), ([.sym "argument-count"], [{ val := .int (1) }]), ([.sym "desireds"], [{ val := .var "pre" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (0) }])]] }

def r_blocks_world_apply_pick_up_internal : Prod :=
  { name := "blocks-world*apply*pick-up*internal",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "move-block"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "internal-actions"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "pick-up"] }, { path := [.sym "pre-conditions-satisfied"], vals := [.sym "true"] }, { path := [.sym "argument1", .sym "object-handle"], vals := [.lit (.var "xh")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "g"] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "gripper"] }, { path := [.sym "empty"], vals := [.int (1)] }, { path := [.sym "holding"], vals := [.var "hd"] }]],
    acts := [.call "log" [.int (1), .fn "crlf" [], .str "Pick up ", .var "xh"],
        .make (.var "g") [([.sym "empty"], [{ val := .int (1), pref := "-" }, { val := .int (0) }]), ([.sym "holding"], [{ val := .var "hd", pref := "-" }, { val := .var "xh" }])]] }

def r_blocks_world_propose_put_down_2 : Prod :=
  { name := "blocks-world*propose*put-down",
    doc := ["Propose put-down in problem space move-block when its conditions below hold."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "move-block"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "y", .conj [.cmp "<>" (.var "y"), .var "d"], .var "g"] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "gripper"] }, { path := [.sym "empty"], vals := [.int (0)] }, { path := [.sym "holding"], vals := [.var "yh"] }],
        .pos false (.var "y") [{ path := [.sym "object-handle"], vals := [.lit (.var "yh")] }],
        .pos false (.var "d") [{ path := [.sym "free"], vals := [.sym "true"] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "put-down" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "action-handle"], [{ val := .sym "put-down" }]), ([.sym "argument1"], [{ val := .var "y" }]), ([.sym "argument2"], [{ val := .var "d" }]), ([.sym "argument-count"], [{ val := .int (2) }]), ([.sym "desireds"], [{ val := .var "pre" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (0) }])]] }

def r_blocks_world_apply_put_down_internal : Prod :=
  { name := "blocks-world*apply*put-down*internal",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "move-block"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "internal-actions"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "put-down"] }, { path := [.sym "pre-conditions-satisfied"], vals := [.sym "true"] }, { path := [.sym "argument1", .sym "object-handle"], vals := [.lit (.var "yh")] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.lit (.var "dh")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "g", .var "y", .var "d"] }, { path := [.sym "on"], vals := [.var "on"] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "gripper"] }, { path := [.sym "empty"], vals := [.int (0)] }],
        .pos false (.var "y") [{ path := [.sym "object-handle"], vals := [.lit (.var "yh")] }],
        .pos false (.var "d") [{ path := [.sym "object-handle"], vals := [.lit (.var "dh")] }],
        .pos false (.var "on") [{ path := [.sym "argument1"], vals := [.var "y"] }, { path := [.sym "argument2"], vals := [.var "old"] }]],
    acts := [.call "log" [.int (1), .fn "crlf" [], .str "Put down ", .var "yh", .str " on ", .var "dh"],
        .make (.var "g") [([.sym "empty"], [{ val := .int (0), pref := "-" }, { val := .int (1) }])],
        .make (.var "on") [([.sym "argument2"], [{ val := .var "old", pref := "-" }, { val := .var "d" }])]] }

def r_blocks_world_apply_put_down_internal_free_old : Prod :=
  { name := "blocks-world*apply*put-down*internal*free-old",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "move-block"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "internal-actions"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "put-down"] }, { path := [.sym "pre-conditions-satisfied"], vals := [.sym "true"] }, { path := [.sym "argument1", .sym "object-handle"], vals := [.lit (.var "yh")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "y"] }, { path := [.sym "on"], vals := [.var "on"] }],
        .pos false (.var "y") [{ path := [.sym "object-handle"], vals := [.lit (.var "yh")] }],
        .pos false (.var "on") [{ path := [.sym "argument1"], vals := [.var "y"] }, { path := [.sym "argument2"], vals := [.var "old"] }],
        .pos false (.var "old") [{ path := [.sym "type"], vals := [.sym "block"] }, { path := [.sym "free"], vals := [.sym "false"] }]],
    acts := [.make (.var "old") [([.sym "free"], [{ val := .sym "false", pref := "-" }, { val := .sym "true" }])]] }

def r_blocks_world_apply_put_down_internal_cover_dest : Prod :=
  { name := "blocks-world*apply*put-down*internal*cover-dest",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "move-block"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "internal-actions"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "put-down"] }, { path := [.sym "pre-conditions-satisfied"], vals := [.sym "true"] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.lit (.var "dh")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "d"] }],
        .pos false (.var "d") [{ path := [.sym "object-handle"], vals := [.lit (.var "dh")] }, { path := [.sym "type"], vals := [.sym "block"] }, { path := [.sym "free"], vals := [.sym "true"] }]],
    acts := [.make (.var "d") [([.sym "free"], [{ val := .sym "true", pref := "-" }, { val := .sym "false" }])]] }

def r_blocks_world_elaborate_problem_space_move_block_look_ahead : Prod :=
  { name := "blocks-world*elaborate*problem-space*move-block*look-ahead",
    doc := ["Look-ahead inside move-block: the evaluation state gets the move-block problem space (W-LAH-026, W-FLG-003)."],
    conds := [.pos true (.var "s") [{ path := [.sym "name"], vals := [.sym "evaluate-operator"] }, { path := [.sym "superstate", .sym "superstate", .sym "problem-space", .sym "name"], vals := [.sym "move-block"] }]],
    acts := [.make (.var "s") [([.sym "problem-space"], [{ val := .var "p" }])],
        .make (.var "p") [([.sym "name"], [{ val := .sym "move-block" }])]] }

def r_blocks_world_elaborate_look_ahead_failure_wrong_block : Prod :=
  { name := "blocks-world*elaborate*look-ahead*failure*wrong-block",
    doc := ["Failure (original move-block*evaluate*failure*1, *2): after a tried operator, a block other than the move's", "is held, or the gripper is empty and the move's block is not on its destination."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "move-block"] }, { path := [.sym "tried-tied-operator"], vals := [.var "any"] }, { path := [.sym "desireds"], vals := [.var "ds"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "ds") [{ path := [.sym "desired", .sym "on", .sym "argument1", .sym "object-handle"], vals := [.var "bh"] }],
        .pos false (.var "w") [{ path := [.sym "objects", .sym "object"], vals := [.var "g"] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "gripper"] }, { path := [.sym "empty"], vals := [.int (0)] }, { path := [.sym "holding"], vals := [.cmp "<>" (.var "bh")] }]],
    acts := [.make (.var "s") [([.sym "failure"], [{ val := .var "ds" }])]] }

def r_blocks_world_elaborate_look_ahead_failure_misplaced : Prod :=
  { name := "blocks-world*elaborate*look-ahead*failure*misplaced",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "move-block"] }, { path := [.sym "tried-tied-operator"], vals := [.var "any"] }, { path := [.sym "desireds"], vals := [.var "ds"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "ds") [{ path := [.sym "desired", .sym "on"], vals := [.var "dr"] }],
        .pos false (.var "dr") [{ path := [.sym "argument1", .sym "object-handle"], vals := [.lit (.var "bh")] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.var "dh"] }],
        .pos false (.var "w") [{ path := [.sym "objects", .sym "object"], vals := [.var "g", .var "b"] }, { path := [.sym "on"], vals := [.var "on"] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "gripper"] }, { path := [.sym "empty"], vals := [.int (1)] }],
        .pos false (.var "b") [{ path := [.sym "object-handle"], vals := [.lit (.var "bh")] }],
        .pos false (.var "on") [{ path := [.sym "argument1"], vals := [.var "b"] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.cmp "<>" (.var "dh")] }]],
    acts := [.make (.var "s") [([.sym "failure"], [{ val := .var "ds" }])]] }

def r_blocks_world_rl_move_block : Prod :=
  { name := "blocks-world*rl*move-block",
    doc := ["RL templates (RL-007): move-block over the whole situation; pick-up and put-down over the move's block and", "destination and their own arguments."],
    flags := [":template"],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "blocks-world"] }, { path := [.sym "operator"], vals := [.var "o", .sym "+"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "move-block"] }, { path := [.sym "argument1", .sym "object-handle"], vals := [.var "bh"] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.var "dh"] }],
        .pos false (.var "w") [{ path := [.sym "on"], vals := [.var "ra", .var "rb", .var "rc"] }, { path := [.sym "objects", .sym "object"], vals := [.var "g"] }],
        .pos false (.var "ra") [{ path := [.sym "argument1", .sym "object-handle"], vals := [.sym "A"] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.var "ua"] }],
        .pos false (.var "rb") [{ path := [.sym "argument1", .sym "object-handle"], vals := [.sym "B"] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.var "ub"] }],
        .pos false (.var "rc") [{ path := [.sym "argument1", .sym "object-handle"], vals := [.sym "C"] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.var "uc"] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "gripper"] }, { path := [.sym "position"], vals := [.var "p"] }, { path := [.sym "open"], vals := [.var "op"] }, { path := [.sym "empty"], vals := [.var "e"] }, { path := [.sym "above"], vals := [.var "ab"] }, { path := [.sym "holding"], vals := [.var "hd"] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "= 0" }])]] }

def r_blocks_world_rl_pick_up : Prod :=
  { name := "blocks-world*rl*pick-up",
    doc := ["RL rule template for pick up in problem space move-block: one numeric-indifferent value per state-operator pair."],
    flags := [":template"],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "move-block"] }, { path := [.sym "operator"], vals := [.var "o", .sym "+"] }, { path := [.sym "argument1", .sym "object-handle"], vals := [.var "bh"] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.var "dh"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "pick-up"] }, { path := [.sym "argument1", .sym "object-handle"], vals := [.var "xh"] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "= 0" }])]] }

def r_blocks_world_rl_put_down : Prod :=
  { name := "blocks-world*rl*put-down",
    doc := ["RL rule template for put down in problem space move-block: one numeric-indifferent value per state-operator pair."],
    flags := [":template"],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "move-block"] }, { path := [.sym "operator"], vals := [.var "o", .sym "+"] }, { path := [.sym "argument1", .sym "object-handle"], vals := [.var "bh"] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.var "dh"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "put-down"] }, { path := [.sym "argument1", .sym "object-handle"], vals := [.var "yh"] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.var "ph"] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "= 0" }])]] }

def r_blocks_world_elaborate_reward_move_block_done : Prod :=
  { name := "blocks-world*elaborate*reward*move-block*done",
    doc := ["Rewards in move-block: +1 when its block is on its destination, -1 when another block is held.  The +1 on", "success at the top comes from agent-world with ^flags.rl true (W-CHK-001)."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "move-block"] }, { path := [.sym "reward-link"], vals := [.var "rl"] }, { path := [.sym "argument1"], vals := [.var "b"] }, { path := [.sym "argument2"], vals := [.var "d"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "on"], vals := [.var "on"] }],
        .pos false (.var "on") [{ path := [.sym "argument1"], vals := [.var "b"] }, { path := [.sym "argument2"], vals := [.var "d"] }]],
    acts := [.make (.var "rl") [([.sym "reward"], [{ val := .var "r" }])],
        .make (.var "r") [([.sym "value"], [{ val := .int (1) }])]] }

def r_blocks_world_elaborate_reward_move_block_wrong_block : Prod :=
  { name := "blocks-world*elaborate*reward*move-block*wrong-block",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "move-block"] }, { path := [.sym "reward-link"], vals := [.var "rl"] }, { path := [.sym "argument1", .sym "object-handle"], vals := [.var "bh"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "objects", .sym "object"], vals := [.var "g"] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "gripper"] }, { path := [.sym "empty"], vals := [.int (0)] }, { path := [.sym "holding"], vals := [.cmp "<>" (.var "bh")] }]],
    acts := [.make (.var "rl") [([.sym "reward"], [{ val := .var "r" }])],
        .make (.var "r") [([.sym "value"], [{ val := .int (-1) }])]] }

def r_blocks_world_propose_pick_up_3 : Prod :=
  { name := "blocks-world*propose*pick-up",
    doc := ["In move-block's implementation substate (problem space move-block, ^argument1 block, ^argument2 dest):", "pick-up when the gripper is empty and the block is free; put-down when the gripper holds the block."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "move-block"] }, { path := [.sym "argument1"], vals := [.var "b"] }, { path := [.sym "argument2"], vals := [.var "d"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "b") [{ path := [.sym "free"], vals := [.sym "true"] }, { path := [.sym "object-handle"], vals := [.var "bh"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "g"] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "gripper"] }, { path := [.sym "empty"], vals := [.int (1)] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "pick-up" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "argument1"], [{ val := .var "b" }]), ([.sym "argument2"], [{ val := .var "d" }]), ([.sym "argument-count"], [{ val := .int (2) }]), ([.sym "desireds"], [{ val := .var "pre" }]), ([.sym "effect-desireds"], [{ val := .var "ed" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (0) }])],
        .make (.var "ed") [([.sym "desired-count"], [{ val := .int (2) }]), ([.sym "desired"], [{ val := .var "e1" }, { val := .var "e2" }])],
        .make (.var "e1") [([.sym "object"], [{ val := .var "e1o" }])],
        .make (.var "e1o") [([.sym "object-handle"], [{ val := .sym "gripper" }]), ([.sym "empty"], [{ val := .int (0) }])],
        .make (.var "e2") [([.sym "object"], [{ val := .var "e2o" }])],
        .make (.var "e2o") [([.sym "object-handle"], [{ val := .sym "gripper" }]), ([.sym "holding"], [{ val := .var "bh" }])]] }

def r_blocks_world_propose_put_down_3 : Prod :=
  { name := "blocks-world*propose*put-down",
    doc := ["Propose put-down in problem space move-block when its conditions below hold."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "move-block"] }, { path := [.sym "argument1"], vals := [.var "b"] }, { path := [.sym "argument2"], vals := [.var "d"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "b") [{ path := [.sym "object-handle"], vals := [.lit (.var "bh")] }],
        .pos false (.var "d") [{ path := [.sym "object-handle"], vals := [.var "dh"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "g"] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "gripper"] }, { path := [.sym "empty"], vals := [.int (0)] }, { path := [.sym "holding"], vals := [.lit (.var "bh")] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "put-down" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "argument1"], [{ val := .var "b" }]), ([.sym "argument2"], [{ val := .var "d" }]), ([.sym "argument-count"], [{ val := .int (2) }]), ([.sym "desireds"], [{ val := .var "pre" }]), ([.sym "effect-desireds"], [{ val := .var "ed" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (0) }])],
        .make (.var "ed") [([.sym "desired-count"], [{ val := .int (2) }]), ([.sym "desired"], [{ val := .var "e1" }, { val := .var "e2" }])],
        .make (.var "e1") [([.sym "on"], [{ val := .var "e1r" }])],
        .make (.var "e1r") [([.sym "argument1"], [{ val := .var "e1a" }]), ([.sym "argument2"], [{ val := .var "e1b" }])],
        .make (.var "e1a") [([.sym "object-handle"], [{ val := .var "bh" }])],
        .make (.var "e1b") [([.sym "object-handle"], [{ val := .var "dh" }])],
        .make (.var "e2") [([.sym "object"], [{ val := .var "e2o" }])],
        .make (.var "e2o") [([.sym "object-handle"], [{ val := .sym "gripper" }]), ([.sym "empty"], [{ val := .int (1) }])]] }

def r_blocks_world_compare_substate_operator_indifferent : Prod :=
  { name := "blocks-world*compare*substate-operator*indifferent",
    doc := ["Search control in problem space move-block/pick-up/put-down: substate operator indifferent (preference)."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.disj [.sym "move-block", .sym "pick-up", .sym "put-down"]] }, { path := [.sym "operator"], vals := [.var "o", .sym "+"] }],
        .pos false (.var "o") [{ path := [.sym "task-operator"], vals := [.sym "true"] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "=" }])]] }

def r_blocks_world_propose_above_block : Prod :=
  { name := "blocks-world*propose*above-block",
    doc := ["Propose above-block in problem space pick-up when its conditions below hold."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "pick-up"] }, { path := [.sym "argument1"], vals := [.var "b"] }, { path := [.sym "argument2"], vals := [.var "d"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "b") [{ path := [.sym "object-handle"], vals := [.lit (.var "bh")] }],
        .pos false (.var "d") [{ path := [.sym "object-handle"], vals := [.lit (.var "dh")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "g"] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "gripper"] }, { path := [.sym "position"], vals := [.int (1)] }, { path := [.sym "above"], vals := [.conj [.cmp "<>" (.var "bh"), .var "ab"]] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "above-block" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "action-handle"], [{ val := .sym "above-block" }]), ([.sym "argument1"], [{ val := .var "b" }]), ([.sym "argument2"], [{ val := .var "d" }]), ([.sym "argument-count"], [{ val := .int (2) }]), ([.sym "desireds"], [{ val := .var "pre" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (0) }])]] }

def r_blocks_world_apply_above_block_internal : Prod :=
  { name := "blocks-world*apply*above-block*internal",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "pick-up"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "internal-actions"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "above-block"] }, { path := [.sym "pre-conditions-satisfied"], vals := [.sym "true"] }, { path := [.sym "argument1", .sym "object-handle"], vals := [.lit (.var "bh")] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.lit (.var "dh")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "g"] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "gripper"] }, { path := [.sym "position"], vals := [.int (1)] }, { path := [.sym "above"], vals := [.conj [.cmp "<>" (.var "bh"), .var "ab"]] }]],
    acts := [.call "log" [.int (1), .fn "crlf" [], .str "Above block"],
        .make (.var "g") [([.sym "above"], [{ val := .var "ab", pref := "-" }, { val := .var "bh" }])]] }

def r_blocks_world_propose_down : Prod :=
  { name := "blocks-world*propose*down",
    doc := ["Propose down in problem space pick-up when its conditions below hold."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "pick-up"] }, { path := [.sym "argument1"], vals := [.var "b"] }, { path := [.sym "argument2"], vals := [.var "d"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "b") [{ path := [.sym "object-handle"], vals := [.lit (.var "bh")] }],
        .pos false (.var "d") [{ path := [.sym "object-handle"], vals := [.lit (.var "dh")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "g"] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "gripper"] }, { path := [.sym "position"], vals := [.int (1)] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "down" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "action-handle"], [{ val := .sym "down" }]), ([.sym "argument1"], [{ val := .var "b" }]), ([.sym "argument2"], [{ val := .var "d" }]), ([.sym "argument-count"], [{ val := .int (2) }]), ([.sym "desireds"], [{ val := .var "pre" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (0) }])]] }

def r_blocks_world_apply_down_internal : Prod :=
  { name := "blocks-world*apply*down*internal",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "pick-up"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "internal-actions"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "down"] }, { path := [.sym "pre-conditions-satisfied"], vals := [.sym "true"] }, { path := [.sym "argument1", .sym "object-handle"], vals := [.lit (.var "bh")] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.lit (.var "dh")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "g"] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "gripper"] }, { path := [.sym "position"], vals := [.int (1)] }]],
    acts := [.call "log" [.int (1), .fn "crlf" [], .str "Down"],
        .make (.var "g") [([.sym "position"], [{ val := .int (1), pref := "-" }, { val := .int (0) }])]] }

def r_blocks_world_propose_up : Prod :=
  { name := "blocks-world*propose*up",
    doc := ["Propose up in problem space pick-up when its conditions below hold."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "pick-up"] }, { path := [.sym "argument1"], vals := [.var "b"] }, { path := [.sym "argument2"], vals := [.var "d"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "b") [{ path := [.sym "object-handle"], vals := [.lit (.var "bh")] }],
        .pos false (.var "d") [{ path := [.sym "object-handle"], vals := [.lit (.var "dh")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "g"] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "gripper"] }, { path := [.sym "position"], vals := [.int (0)] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "up" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "action-handle"], [{ val := .sym "up" }]), ([.sym "argument1"], [{ val := .var "b" }]), ([.sym "argument2"], [{ val := .var "d" }]), ([.sym "argument-count"], [{ val := .int (2) }]), ([.sym "desireds"], [{ val := .var "pre" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (0) }])]] }

def r_blocks_world_apply_up_internal : Prod :=
  { name := "blocks-world*apply*up*internal",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "pick-up"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "internal-actions"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "up"] }, { path := [.sym "pre-conditions-satisfied"], vals := [.sym "true"] }, { path := [.sym "argument1", .sym "object-handle"], vals := [.lit (.var "bh")] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.lit (.var "dh")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "g"] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "gripper"] }, { path := [.sym "position"], vals := [.int (0)] }]],
    acts := [.call "log" [.int (1), .fn "crlf" [], .str "Up"],
        .make (.var "g") [([.sym "position"], [{ val := .int (0), pref := "-" }, { val := .int (1) }])]] }

def r_blocks_world_propose_open : Prod :=
  { name := "blocks-world*propose*open",
    doc := ["Propose open in problem space pick-up when its conditions below hold."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "pick-up"] }, { path := [.sym "argument1"], vals := [.var "b"] }, { path := [.sym "argument2"], vals := [.var "d"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "b") [{ path := [.sym "object-handle"], vals := [.lit (.var "bh")] }],
        .pos false (.var "d") [{ path := [.sym "object-handle"], vals := [.lit (.var "dh")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "g"] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "gripper"] }, { path := [.sym "open"], vals := [.int (0)] }, { path := [.sym "empty"], vals := [.int (1)] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "open" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "action-handle"], [{ val := .sym "open" }]), ([.sym "argument1"], [{ val := .var "b" }]), ([.sym "argument2"], [{ val := .var "d" }]), ([.sym "argument-count"], [{ val := .int (2) }]), ([.sym "desireds"], [{ val := .var "pre" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (0) }])]] }

def r_blocks_world_apply_open_internal : Prod :=
  { name := "blocks-world*apply*open*internal",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "pick-up"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "internal-actions"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "open"] }, { path := [.sym "pre-conditions-satisfied"], vals := [.sym "true"] }, { path := [.sym "argument1", .sym "object-handle"], vals := [.lit (.var "bh")] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.lit (.var "dh")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "g"] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "gripper"] }, { path := [.sym "open"], vals := [.int (0)] }, { path := [.sym "empty"], vals := [.int (1)] }]],
    acts := [.call "log" [.int (1), .fn "crlf" [], .str "Open"],
        .make (.var "g") [([.sym "open"], [{ val := .int (0), pref := "-" }, { val := .int (1) }])]] }

def r_blocks_world_propose_close : Prod :=
  { name := "blocks-world*propose*close",
    doc := ["close: grasps the block when the gripper is down above it (case 1); otherwise it only closes (cases 2, 3)."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "pick-up"] }, { path := [.sym "argument1"], vals := [.var "b"] }, { path := [.sym "argument2"], vals := [.var "d"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "g"] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "gripper"] }, { path := [.sym "open"], vals := [.int (1)] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "close" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "action-handle"], [{ val := .sym "close" }]), ([.sym "argument1"], [{ val := .var "b" }]), ([.sym "argument2"], [{ val := .var "d" }]), ([.sym "argument-count"], [{ val := .int (2) }]), ([.sym "desireds"], [{ val := .var "pre" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (0) }])]] }

def r_blocks_world_apply_close_internal_grasp : Prod :=
  { name := "blocks-world*apply*close*internal*grasp",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "pick-up"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "internal-actions"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "close"] }, { path := [.sym "pre-conditions-satisfied"], vals := [.sym "true"] }, { path := [.sym "argument1", .sym "object-handle"], vals := [.lit (.var "bh")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "g"] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "gripper"] }, { path := [.sym "open"], vals := [.int (1)] }, { path := [.sym "empty"], vals := [.int (1)] }, { path := [.sym "position"], vals := [.int (0)] }, { path := [.sym "above"], vals := [.lit (.var "bh")] }, { path := [.sym "holding"], vals := [.var "hd"] }]],
    acts := [.call "log" [.int (1), .fn "crlf" [], .str "Close on ", .var "bh"],
        .make (.var "g") [([.sym "open"], [{ val := .int (1), pref := "-" }, { val := .int (0) }]), ([.sym "empty"], [{ val := .int (1), pref := "-" }, { val := .int (0) }]), ([.sym "holding"], [{ val := .var "hd", pref := "-" }, { val := .var "bh" }])]] }

def r_blocks_world_apply_close_internal_empty : Prod :=
  { name := "blocks-world*apply*close*internal*empty",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "pick-up"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "internal-actions"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "close"] }, { path := [.sym "pre-conditions-satisfied"], vals := [.sym "true"] }, { path := [.sym "argument1", .sym "object-handle"], vals := [.lit (.var "bh")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "g"] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "gripper"] }, { path := [.sym "open"], vals := [.int (1)] }],
        .ncc [.pos false (.var "g") [{ path := [.sym "empty"], vals := [.int (1)] }, { path := [.sym "position"], vals := [.int (0)] }, { path := [.sym "above"], vals := [.var "bh"] }]]],
    acts := [.call "log" [.int (1), .fn "crlf" [], .str "Close"],
        .make (.var "g") [([.sym "open"], [{ val := .int (1), pref := "-" }, { val := .int (0) }])]] }

def r_blocks_world_elaborate_reward_pick_up_held : Prod :=
  { name := "blocks-world*elaborate*reward*pick-up*held",
    doc := ["Rewards (RL-002, i-supported): +1 when the block is held, -1 when the gripper is closed on nothing."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "pick-up"] }, { path := [.sym "reward-link"], vals := [.var "rl"] }, { path := [.sym "argument1", .sym "object-handle"], vals := [.var "bh"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "g"] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "gripper"] }, { path := [.sym "empty"], vals := [.int (0)] }, { path := [.sym "holding"], vals := [.var "bh"] }]],
    acts := [.make (.var "rl") [([.sym "reward"], [{ val := .var "r" }])],
        .make (.var "r") [([.sym "value"], [{ val := .int (1) }])]] }

def r_blocks_world_elaborate_reward_pick_up_closed_empty : Prod :=
  { name := "blocks-world*elaborate*reward*pick-up*closed-empty",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "pick-up"] }, { path := [.sym "reward-link"], vals := [.var "rl"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "g"] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "gripper"] }, { path := [.sym "open"], vals := [.int (0)] }, { path := [.sym "empty"], vals := [.int (1)] }]],
    acts := [.make (.var "rl") [([.sym "reward"], [{ val := .var "r" }])],
        .make (.var "r") [([.sym "value"], [{ val := .int (-1) }])]] }

def r_blocks_world_propose_up_holding : Prod :=
  { name := "blocks-world*propose*up-holding",
    doc := ["Propose up-holding in problem space put-down when its conditions below hold."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "put-down"] }, { path := [.sym "argument1"], vals := [.var "b"] }, { path := [.sym "argument2"], vals := [.var "d"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "b") [{ path := [.sym "object-handle"], vals := [.lit (.var "bh")] }],
        .pos false (.var "d") [{ path := [.sym "object-handle"], vals := [.lit (.var "dh")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "g"] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "gripper"] }, { path := [.sym "position"], vals := [.int (0)] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "up-holding" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "action-handle"], [{ val := .sym "up-holding" }]), ([.sym "argument1"], [{ val := .var "b" }]), ([.sym "argument2"], [{ val := .var "d" }]), ([.sym "argument-count"], [{ val := .int (2) }]), ([.sym "desireds"], [{ val := .var "pre" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (0) }])]] }

def r_blocks_world_apply_up_holding_internal : Prod :=
  { name := "blocks-world*apply*up-holding*internal",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "put-down"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "internal-actions"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "up-holding"] }, { path := [.sym "pre-conditions-satisfied"], vals := [.sym "true"] }, { path := [.sym "argument1", .sym "object-handle"], vals := [.lit (.var "bh")] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.lit (.var "dh")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "g"] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "gripper"] }, { path := [.sym "position"], vals := [.int (0)] }]],
    acts := [.call "log" [.int (1), .fn "crlf" [], .str "Up (holding)"],
        .make (.var "g") [([.sym "position"], [{ val := .int (0), pref := "-" }, { val := .int (1) }])]] }

def r_blocks_world_propose_above_dest : Prod :=
  { name := "blocks-world*propose*above-dest",
    doc := ["Propose above-dest in problem space put-down when its conditions below hold."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "put-down"] }, { path := [.sym "argument1"], vals := [.var "b"] }, { path := [.sym "argument2"], vals := [.var "d"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "b") [{ path := [.sym "object-handle"], vals := [.lit (.var "bh")] }],
        .pos false (.var "d") [{ path := [.sym "object-handle"], vals := [.lit (.var "dh")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "g"] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "gripper"] }, { path := [.sym "position"], vals := [.int (1)] }, { path := [.sym "above"], vals := [.conj [.cmp "<>" (.var "dh"), .var "ab"]] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "above-dest" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "action-handle"], [{ val := .sym "above-dest" }]), ([.sym "argument1"], [{ val := .var "b" }]), ([.sym "argument2"], [{ val := .var "d" }]), ([.sym "argument-count"], [{ val := .int (2) }]), ([.sym "desireds"], [{ val := .var "pre" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (0) }])]] }

def r_blocks_world_apply_above_dest_internal : Prod :=
  { name := "blocks-world*apply*above-dest*internal",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "put-down"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "internal-actions"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "above-dest"] }, { path := [.sym "pre-conditions-satisfied"], vals := [.sym "true"] }, { path := [.sym "argument1", .sym "object-handle"], vals := [.lit (.var "bh")] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.lit (.var "dh")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "g"] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "gripper"] }, { path := [.sym "position"], vals := [.int (1)] }, { path := [.sym "above"], vals := [.conj [.cmp "<>" (.var "dh"), .var "ab"]] }]],
    acts := [.call "log" [.int (1), .fn "crlf" [], .str "Above destination"],
        .make (.var "g") [([.sym "above"], [{ val := .var "ab", pref := "-" }, { val := .var "dh" }])]] }

def r_blocks_world_propose_down_holding : Prod :=
  { name := "blocks-world*propose*down-holding",
    doc := ["Propose down-holding in problem space put-down when its conditions below hold."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "put-down"] }, { path := [.sym "argument1"], vals := [.var "b"] }, { path := [.sym "argument2"], vals := [.var "d"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "b") [{ path := [.sym "object-handle"], vals := [.lit (.var "bh")] }],
        .pos false (.var "d") [{ path := [.sym "object-handle"], vals := [.lit (.var "dh")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "g"] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "gripper"] }, { path := [.sym "position"], vals := [.int (1)] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "down-holding" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "action-handle"], [{ val := .sym "down-holding" }]), ([.sym "argument1"], [{ val := .var "b" }]), ([.sym "argument2"], [{ val := .var "d" }]), ([.sym "argument-count"], [{ val := .int (2) }]), ([.sym "desireds"], [{ val := .var "pre" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (0) }])]] }

def r_blocks_world_apply_down_holding_internal : Prod :=
  { name := "blocks-world*apply*down-holding*internal",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "put-down"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "internal-actions"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "down-holding"] }, { path := [.sym "pre-conditions-satisfied"], vals := [.sym "true"] }, { path := [.sym "argument1", .sym "object-handle"], vals := [.lit (.var "bh")] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.lit (.var "dh")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "g"] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "gripper"] }, { path := [.sym "position"], vals := [.int (1)] }]],
    acts := [.call "log" [.int (1), .fn "crlf" [], .str "Down (holding)"],
        .make (.var "g") [([.sym "position"], [{ val := .int (1), pref := "-" }, { val := .int (0) }])]] }

def r_blocks_world_propose_release : Prod :=
  { name := "blocks-world*propose*release",
    doc := ["release: over the destination the block is put there (case 1); elsewhere the gripper just opens (case 2)."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "put-down"] }, { path := [.sym "argument1"], vals := [.var "b"] }, { path := [.sym "argument2"], vals := [.var "d"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "g"] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "gripper"] }, { path := [.sym "open"], vals := [.int (0)] }, { path := [.sym "position"], vals := [.int (0)] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "release" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "action-handle"], [{ val := .sym "release" }]), ([.sym "argument1"], [{ val := .var "b" }]), ([.sym "argument2"], [{ val := .var "d" }]), ([.sym "argument-count"], [{ val := .int (2) }]), ([.sym "desireds"], [{ val := .var "pre" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (0) }])]] }

def r_blocks_world_apply_release_internal_gripper : Prod :=
  { name := "blocks-world*apply*release*internal*gripper",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "put-down"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "internal-actions"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "release"] }, { path := [.sym "pre-conditions-satisfied"], vals := [.sym "true"] }, { path := [.sym "argument1", .sym "object-handle"], vals := [.lit (.var "bh")] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.lit (.var "dh")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "g"] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "gripper"] }, { path := [.sym "open"], vals := [.int (0)] }, { path := [.sym "empty"], vals := [.var "e"] }, { path := [.sym "above"], vals := [.var "ab"] }]],
    acts := [.call "log" [.int (1), .fn "crlf" [], .str "Release"],
        .make (.var "g") [([.sym "open"], [{ val := .int (0), pref := "-" }, { val := .int (1) }]), ([.sym "empty"], [{ val := .var "e", pref := "-" }, { val := .int (1) }])]] }

def r_blocks_world_apply_release_internal_above : Prod :=
  { name := "blocks-world*apply*release*internal*above",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "put-down"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "internal-actions"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "release"] }, { path := [.sym "pre-conditions-satisfied"], vals := [.sym "true"] }, { path := [.sym "argument1", .sym "object-handle"], vals := [.lit (.var "bh")] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.lit (.var "dh")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "g"] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "gripper"] }, { path := [.sym "open"], vals := [.int (0)] }, { path := [.sym "above"], vals := [.lit (.var "dh")] }]],
    acts := [.make (.var "g") [([.sym "above"], [{ val := .var "dh", pref := "-" }, { val := .var "bh" }])]] }

def r_blocks_world_elaborate_reward_put_down : Prod :=
  { name := "blocks-world*elaborate*reward*put-down",
    doc := ["Elaborate reward put down in problem space put-down: adds ^reward, ^value."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "put-down"] }, { path := [.sym "reward-link"], vals := [.var "rl"] }, { path := [.sym "argument1"], vals := [.var "b"] }, { path := [.sym "argument2"], vals := [.var "d"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "g"] }, { path := [.sym "on"], vals := [.var "on"] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "gripper"] }, { path := [.sym "empty"], vals := [.int (1)] }],
        .pos false (.var "on") [{ path := [.sym "argument1"], vals := [.var "b"] }, { path := [.sym "argument2"], vals := [.var "d"] }]],
    acts := [.make (.var "rl") [([.sym "reward"], [{ val := .var "r" }])],
        .make (.var "r") [([.sym "value"], [{ val := .int (1) }])]] }

def r_blocks_world_apply_release_internal_on : Prod :=
  { name := "blocks-world*apply*release*internal*on",
    doc := ["The block now rests on the destination: on moves, and free is maintained (the old support becomes free, a", "block destination stops being free)."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "put-down"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "internal-actions"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "release"] }, { path := [.sym "pre-conditions-satisfied"], vals := [.sym "true"] }, { path := [.sym "argument1", .sym "object-handle"], vals := [.lit (.var "bh")] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.lit (.var "dh")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "b", .var "d", .var "g"] }, { path := [.sym "on"], vals := [.var "on"] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "gripper"] }, { path := [.sym "above"], vals := [.lit (.var "dh")] }, { path := [.sym "open"], vals := [.int (0)] }],
        .pos false (.var "b") [{ path := [.sym "object-handle"], vals := [.lit (.var "bh")] }],
        .pos false (.var "d") [{ path := [.sym "object-handle"], vals := [.lit (.var "dh")] }],
        .pos false (.var "on") [{ path := [.sym "argument1"], vals := [.var "b"] }, { path := [.sym "argument2"], vals := [.var "old"] }]],
    acts := [.make (.var "on") [([.sym "argument2"], [{ val := .var "old", pref := "-" }, { val := .var "d" }])]] }

def r_blocks_world_apply_release_internal_free_old : Prod :=
  { name := "blocks-world*apply*release*internal*free-old",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "put-down"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "internal-actions"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "release"] }, { path := [.sym "pre-conditions-satisfied"], vals := [.sym "true"] }, { path := [.sym "argument1", .sym "object-handle"], vals := [.lit (.var "bh")] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.lit (.var "dh")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "b", .var "g"] }, { path := [.sym "on"], vals := [.var "on"] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "gripper"] }, { path := [.sym "above"], vals := [.lit (.var "dh")] }, { path := [.sym "open"], vals := [.int (0)] }],
        .pos false (.var "b") [{ path := [.sym "object-handle"], vals := [.lit (.var "bh")] }],
        .pos false (.var "on") [{ path := [.sym "argument1"], vals := [.var "b"] }, { path := [.sym "argument2"], vals := [.var "old"] }],
        .pos false (.var "old") [{ path := [.sym "type"], vals := [.sym "block"] }, { path := [.sym "free"], vals := [.sym "false"] }]],
    acts := [.make (.var "old") [([.sym "free"], [{ val := .sym "false", pref := "-" }, { val := .sym "true" }])]] }

def r_blocks_world_apply_release_internal_cover_dest : Prod :=
  { name := "blocks-world*apply*release*internal*cover-dest",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "put-down"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "internal-actions"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "release"] }, { path := [.sym "pre-conditions-satisfied"], vals := [.sym "true"] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.lit (.var "dh")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "d", .var "g"] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "gripper"] }, { path := [.sym "above"], vals := [.lit (.var "dh")] }, { path := [.sym "open"], vals := [.int (0)] }],
        .pos false (.var "d") [{ path := [.sym "object-handle"], vals := [.lit (.var "dh")] }, { path := [.sym "type"], vals := [.sym "block"] }, { path := [.sym "free"], vals := [.sym "true"] }]],
    acts := [.make (.var "d") [([.sym "free"], [{ val := .sym "true", pref := "-" }, { val := .sym "false" }])]] }

def r_blocks_world_rl_pick_up_2 : Prod :=
  { name := "blocks-world*rl*pick-up",
    doc := ["RL template (RL-007; the original's gp rules) over the gripper's state, in pick-up."],
    flags := [":template"],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "pick-up"] }, { path := [.sym "operator"], vals := [.var "o", .sym "+"] }, { path := [.sym "argument1", .sym "object-handle"], vals := [.var "bh"] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.var "dh"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.conj [.disj [.sym "above-block", .sym "down", .sym "up", .sym "open", .sym "close"], .var "n"]] }],
        .pos false (.var "w") [{ path := [.sym "objects", .sym "object"], vals := [.var "g"] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "gripper"] }, { path := [.sym "position"], vals := [.var "p"] }, { path := [.sym "open"], vals := [.var "op"] }, { path := [.sym "empty"], vals := [.var "e"] }, { path := [.sym "above"], vals := [.var "ab"] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "= 0" }])]] }

def r_blocks_world_rl_put_down_2 : Prod :=
  { name := "blocks-world*rl*put-down",
    doc := ["RL template (RL-007; the original's gp rules) over the gripper's state, in put-down."],
    flags := [":template"],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "put-down"] }, { path := [.sym "operator"], vals := [.var "o", .sym "+"] }, { path := [.sym "argument1", .sym "object-handle"], vals := [.var "bh"] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.var "dh"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.conj [.disj [.sym "up-holding", .sym "above-dest", .sym "down-holding", .sym "release"], .var "n"]] }],
        .pos false (.var "w") [{ path := [.sym "objects", .sym "object"], vals := [.var "g"] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "gripper"] }, { path := [.sym "position"], vals := [.var "p"] }, { path := [.sym "open"], vals := [.var "op"] }, { path := [.sym "empty"], vals := [.var "e"] }, { path := [.sym "above"], vals := [.var "ab"] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "= 0" }])]] }

def r_blocks_world_propose_move_block_3 : Prod :=
  { name := "blocks-world*propose*move-block",
    doc := ["move-block <block> <dest>: a clear block onto the table or onto another clear block it is not already on."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "blocks-world"] }, { path := [.sym "flags", .sym "mea-operator-selection"], vals := [.sym "true"] }, { path := [.sym "desireds", .sym "unachieved-desireds"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "b", .conj [.cmp "<>" (.var "b"), .var "d"]] }, { path := [.sym "on"], vals := [.var "on"] }],
        .pos false (.var "b") [{ path := [.sym "type"], vals := [.sym "block"] }, { path := [.sym "clear"], vals := [.sym "true"] }],
        .pos false (.var "d") [{ path := [.sym "clear"], vals := [.sym "true"] }],
        .pos false (.var "on") [{ path := [.sym "argument1"], vals := [.var "b"] }, { path := [.sym "argument2"], vals := [.cmp "<>" (.var "d")] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "move-block" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "action-handle"], [{ val := .sym "move-block" }]), ([.sym "argument1"], [{ val := .var "b" }]), ([.sym "argument2"], [{ val := .var "d" }]), ([.sym "argument-count"], [{ val := .int (2) }]), ([.sym "desireds"], [{ val := .var "pre" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (0) }])]] }

def r_blocks_world_apply_move_block_internal : Prod :=
  { name := "blocks-world*apply*move-block*internal",
    doc := ["move-block <block> <dest>: the block's on relation moves to <dest>; clear is maintained: what the block was", "on becomes clear, a block destination stops being clear (the table stays clear)."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "blocks-world"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "internal-actions"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "move-block"] }, { path := [.sym "pre-conditions-satisfied"], vals := [.sym "true"] }, { path := [.sym "argument1", .sym "object-handle"], vals := [.lit (.var "bh")] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.lit (.var "dh")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "b", .var "d"] }, { path := [.sym "on"], vals := [.var "on"] }],
        .pos false (.var "b") [{ path := [.sym "object-handle"], vals := [.lit (.var "bh")] }],
        .pos false (.var "d") [{ path := [.sym "object-handle"], vals := [.lit (.var "dh")] }],
        .pos false (.var "on") [{ path := [.sym "argument1"], vals := [.var "b"] }, { path := [.sym "argument2"], vals := [.var "old"] }]],
    acts := [.call "log" [.int (1), .fn "crlf" [], .str "Move block ", .var "bh", .str " to ", .var "dh"],
        .make (.var "on") [([.sym "argument2"], [{ val := .var "old", pref := "-" }, { val := .var "d" }])]] }

def r_blocks_world_apply_move_block_internal_clear_source : Prod :=
  { name := "blocks-world*apply*move-block*internal*clear-source",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "blocks-world"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "internal-actions"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "move-block"] }, { path := [.sym "pre-conditions-satisfied"], vals := [.sym "true"] }, { path := [.sym "argument1", .sym "object-handle"], vals := [.lit (.var "bh")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "b"] }, { path := [.sym "on"], vals := [.var "on"] }],
        .pos false (.var "b") [{ path := [.sym "object-handle"], vals := [.lit (.var "bh")] }],
        .pos false (.var "on") [{ path := [.sym "argument1"], vals := [.var "b"] }, { path := [.sym "argument2"], vals := [.var "old"] }],
        .pos false (.var "old") [{ path := [.sym "type"], vals := [.sym "block"] }, { path := [.sym "clear"], vals := [.sym "false"] }]],
    acts := [.make (.var "old") [([.sym "clear"], [{ val := .sym "false", pref := "-" }, { val := .sym "true" }])]] }

def r_blocks_world_apply_move_block_internal_cover_dest : Prod :=
  { name := "blocks-world*apply*move-block*internal*cover-dest",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "blocks-world"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "internal-actions"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "move-block"] }, { path := [.sym "pre-conditions-satisfied"], vals := [.sym "true"] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.lit (.var "dh")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "d"] }],
        .pos false (.var "d") [{ path := [.sym "object-handle"], vals := [.lit (.var "dh")] }, { path := [.sym "type"], vals := [.sym "block"] }, { path := [.sym "clear"], vals := [.sym "true"] }]],
    acts := [.make (.var "d") [([.sym "clear"], [{ val := .sym "true", pref := "-" }, { val := .sym "false" }])]] }

def r_blocks_world_apply_move_block_internal_last_block : Prod :=
  { name := "blocks-world*apply*move-block*internal*last-block",
    doc := ["The block moved last (memory object, spec section 2); in look-ahead it is not moved again (original", "blocks-world*select*reject-twice, which applies only under evaluate-operator)."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "blocks-world"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "internal-actions"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "move-block"] }, { path := [.sym "pre-conditions-satisfied"], vals := [.sym "true"] }, { path := [.sym "argument1", .sym "object-handle"], vals := [.lit (.var "bh")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "m"] }],
        .pos false (.var "m") [{ path := [.sym "type"], vals := [.sym "memory"] }, { path := [.sym "last-block"], vals := [.var "l"] }]],
    acts := [.make (.var "m") [([.sym "last-block"], [{ val := .var "l", pref := "-" }, { val := .var "bh" }])]] }

def r_blocks_world_compare_move_block_reject_twice : Prod :=
  { name := "blocks-world*compare*move-block*reject-twice",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "blocks-world"] }, { path := [.sym "tried-tied-operator"], vals := [.var "any"] }, { path := [.sym "operator"], vals := [.var "o", .sym "+"] }, { path := [.sym "world", .sym "objects", .sym "object"], vals := [.var "m"] }],
        .pos false (.var "m") [{ path := [.sym "type"], vals := [.sym "memory"] }, { path := [.sym "last-block"], vals := [.var "bh"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "move-block"] }, { path := [.sym "argument1", .sym "object-handle"], vals := [.lit (.var "bh")] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "-" }])]] }

/-- Tests on where every block is (as in the original state-evaluation rules). They put the evaluated operator's
    own change (the moved block's new ^on relation) into the chunk, so a chunk learned for one move does not fire
    for others (World-Conventions L3-103, 21 Nov 2026). -/
def allOnConds : List Cond :=
  [.pos false (.var "w") [{ path := [.sym "on"], vals := [.var "all-a", .var "all-b", .var "all-c"] }],
   .pos false (.var "all-a") [{ path := [.sym "argument1", .sym "object-handle"], vals := [.sym "A"] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.var "all-a-on"] }],
   .pos false (.var "all-b") [{ path := [.sym "argument1", .sym "object-handle"], vals := [.sym "B"] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.var "all-b-on"] }],
   .pos false (.var "all-c") [{ path := [.sym "argument1", .sym "object-handle"], vals := [.sym "C"] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.var "all-c-on"] }]]

def r_blocks_world_elaborate_look_ahead_level_A : Prod :=
  { name := "blocks-world*elaborate*look-ahead*level-A",
    doc := ["Expected value of a look-ahead state (W-LAH-009): 1 when A is in place, 0.6 when B is (and A not on B),", "0.3 when C is (and B not on C), 0 when C is not on the table (original state-evaluation rules). Each rule also", "tests where every block is, so chunks include the evaluated move (L3-103)."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "blocks-world"] }, { path := [.sym "tried-tied-operator"], vals := [.var "any"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "objects", .sym "object"], vals := [.var "a"] }],
        .pos false (.var "a") [{ path := [.sym "object-handle"], vals := [.lit (.sym "A")] }, { path := [.sym "in-place"], vals := [.sym "true"] }]] ++ allOnConds,
    acts := [.make (.var "s") [([.sym "expected-value"], [{ val := .int (1) }])]] }

def r_blocks_world_elaborate_look_ahead_level_B : Prod :=
  { name := "blocks-world*elaborate*look-ahead*level-B",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "blocks-world"] }, { path := [.sym "tried-tied-operator"], vals := [.var "any"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "objects", .sym "object"], vals := [.var "b"] }, { path := [.sym "on"], vals := [.var "ra"] }],
        .pos false (.var "b") [{ path := [.sym "object-handle"], vals := [.lit (.sym "B")] }, { path := [.sym "in-place"], vals := [.sym "true"] }],
        .pos false (.var "ra") [{ path := [.sym "argument1", .sym "object-handle"], vals := [.sym "A"] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.cmp "<>" (.sym "B")] }]] ++ allOnConds,
    acts := [.make (.var "s") [([.sym "expected-value"], [{ val := .flt "0.6" }])]] }

def r_blocks_world_elaborate_look_ahead_level_C : Prod :=
  { name := "blocks-world*elaborate*look-ahead*level-C",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "blocks-world"] }, { path := [.sym "tried-tied-operator"], vals := [.var "any"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "objects", .sym "object"], vals := [.var "c"] }, { path := [.sym "on"], vals := [.var "rb"] }],
        .pos false (.var "c") [{ path := [.sym "object-handle"], vals := [.lit (.sym "C")] }, { path := [.sym "in-place"], vals := [.sym "true"] }],
        .pos false (.var "rb") [{ path := [.sym "argument1", .sym "object-handle"], vals := [.sym "B"] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.cmp "<>" (.sym "C")] }]] ++ allOnConds,
    acts := [.make (.var "s") [([.sym "expected-value"], [{ val := .flt "0.3" }])]] }

def r_blocks_world_elaborate_look_ahead_level_none : Prod :=
  { name := "blocks-world*elaborate*look-ahead*level-none",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "blocks-world"] }, { path := [.sym "tried-tied-operator"], vals := [.var "any"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "on"], vals := [.var "rc"] }],
        .pos false (.var "rc") [{ path := [.sym "argument1", .sym "object-handle"], vals := [.sym "C"] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.cmp "<>" (.sym "table")] }]] ++ allOnConds,
    acts := [.make (.var "s") [([.sym "expected-value"], [{ val := .int (0) }])]] }

def r_blocks_world_propose_move_block_4 : Prod :=
  { name := "blocks-world*propose*move-block",
    doc := ["move-block <block> <dest>: any block onto any other object it is not on.  Preconditions (^desireds): the block", "and the destination are clear; when they are not, the operator no-change substate gets them as its desireds", "(W-MEA-002, W-MEA-003)."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "blocks-world"] }, { path := [.sym "flags", .sym "mea-operator-selection"], vals := [.sym "true"] }, { path := [.sym "desireds", .sym "unachieved-desireds"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "b", .conj [.cmp "<>" (.var "b"), .var "d"]] }, { path := [.sym "on"], vals := [.var "on"] }],
        .pos false (.var "b") [{ path := [.sym "type"], vals := [.sym "block"] }, { path := [.sym "object-handle"], vals := [.lit (.var "bh")] }],
        .pos false (.var "d") [{ path := [.sym "object-handle"], vals := [.lit (.var "dh")] }],
        .pos false (.var "on") [{ path := [.sym "argument1"], vals := [.var "b"] }, { path := [.sym "argument2"], vals := [.cmp "<>" (.var "d")] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "move-block" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "action-handle"], [{ val := .sym "move-block" }]), ([.sym "argument1"], [{ val := .var "b" }]), ([.sym "argument2"], [{ val := .var "d" }]), ([.sym "argument-count"], [{ val := .int (2) }]), ([.sym "desireds"], [{ val := .var "pre" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (2) }]), ([.sym "desired"], [{ val := .var "p1" }, { val := .var "p2" }])],
        .make (.var "p1") [([.sym "object"], [{ val := .var "p1o" }])],
        .make (.var "p1o") [([.sym "object-handle"], [{ val := .var "bh" }]), ([.sym "clear"], [{ val := .sym "true" }])],
        .make (.var "p2") [([.sym "object"], [{ val := .var "p2o" }])],
        .make (.var "p2o") [([.sym "object-handle"], [{ val := .var "dh" }]), ([.sym "clear"], [{ val := .sym "true" }])]] }

def r_blocks_world_compare_avoid_clobbering : Prod :=
  { name := "blocks-world*compare*avoid-clobbering",
    doc := ["Search control of the original: avoid covering an object the state wants clear (worst); prefer a move that", "achieves a desired on (best) and a move that clears an object the state wants clear (best)."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "blocks-world"] }, { path := [.sym "operator"], vals := [.var "o", .sym "+"] }, { path := [.sym "desireds", .sym "desired", .sym "object"], vals := [.var "do"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "move-block"] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.var "dh"] }],
        .pos false (.var "do") [{ path := [.sym "object-handle"], vals := [.var "dh"] }, { path := [.sym "clear"], vals := [.sym "true"] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "<" }])]] }

def r_blocks_world_compare_prefer_ontop : Prod :=
  { name := "blocks-world*compare*prefer-ontop",
    doc := ["Search control in problem space blocks-world: prefer ontop (best)."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "blocks-world"] }, { path := [.sym "operator"], vals := [.var "o", .sym "+"] }, { path := [.sym "desireds", .sym "desired", .sym "on"], vals := [.var "dr"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "move-block"] }, { path := [.sym "argument1", .sym "object-handle"], vals := [.var "bh"] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.var "dh"] }],
        .pos false (.var "dr") [{ path := [.sym "argument1", .sym "object-handle"], vals := [.var "bh"] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.var "dh"] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := ">" }])]] }

def r_blocks_world_compare_prefer_clearing : Prod :=
  { name := "blocks-world*compare*prefer-clearing",
    doc := ["Search control in problem space blocks-world: prefer clearing (best)."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "blocks-world"] }, { path := [.sym "operator"], vals := [.var "o", .sym "+"] }, { path := [.sym "desireds", .sym "desired", .sym "object"], vals := [.var "do"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "move-block"] }, { path := [.sym "argument1"], vals := [.var "b"] }],
        .pos false (.var "w") [{ path := [.sym "on"], vals := [.var "on"] }],
        .pos false (.var "on") [{ path := [.sym "argument1"], vals := [.var "b"] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.var "uh"] }],
        .pos false (.var "do") [{ path := [.sym "object-handle"], vals := [.var "uh"] }, { path := [.sym "clear"], vals := [.sym "true"] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := ">" }])]] }

def r_blocks_world_propose_move_block_onto_desired : Prod :=
  { name := "blocks-world*propose*move-block*onto-desired",
    doc := ["move-block <block> <dest>: any block onto any other object it is not on.  Preconditions (^desireds): the block", "and the destination are clear; when they are not, the operator no-change substate gets them as its desireds", "(W-MEA-002, W-MEA-003)."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "blocks-world"] }, { path := [.sym "flags", .sym "mea-operator-selection"], vals := [.sym "true"] }, { path := [.sym "desireds", .sym "unachieved-desireds"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "b", .conj [.cmp "<>" (.var "b"), .var "d"]] }, { path := [.sym "on"], vals := [.var "on"] }],
        .pos false (.var "b") [{ path := [.sym "type"], vals := [.sym "block"] }, { path := [.sym "object-handle"], vals := [.lit (.var "bh")] }],
        .pos false (.var "d") [{ path := [.sym "object-handle"], vals := [.lit (.var "dh")] }],
        .pos false (.var "on") [{ path := [.sym "argument1"], vals := [.var "b"] }, { path := [.sym "argument2"], vals := [.cmp "<>" (.var "d")] }],
        .pos false (.var "s") [{ path := [.sym "desireds", .sym "desired", .sym "on"], vals := [.var "dr"] }],
        .pos false (.var "dr") [{ path := [.sym "argument1", .sym "object-handle"], vals := [.var "bh"] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.var "dh"] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "move-block" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "action-handle"], [{ val := .sym "move-block" }]), ([.sym "argument1"], [{ val := .var "b" }]), ([.sym "argument2"], [{ val := .var "d" }]), ([.sym "argument-count"], [{ val := .int (2) }]), ([.sym "desireds"], [{ val := .var "pre" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (2) }]), ([.sym "desired"], [{ val := .var "p1" }, { val := .var "p2" }])],
        .make (.var "p1") [([.sym "object"], [{ val := .var "p1o" }])],
        .make (.var "p1o") [([.sym "object-handle"], [{ val := .var "bh" }]), ([.sym "clear"], [{ val := .sym "true" }])],
        .make (.var "p2") [([.sym "object"], [{ val := .var "p2o" }])],
        .make (.var "p2o") [([.sym "object-handle"], [{ val := .var "dh" }]), ([.sym "clear"], [{ val := .sym "true" }])]] }

def r_blocks_world_propose_move_block_clearing : Prod :=
  { name := "blocks-world*propose*move-block*clearing",
    doc := ["move-block <block> <dest>: any block onto any other object it is not on.  Preconditions (^desireds): the block", "and the destination are clear; when they are not, the operator no-change substate gets them as its desireds", "(W-MEA-002, W-MEA-003)."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "blocks-world"] }, { path := [.sym "flags", .sym "mea-operator-selection"], vals := [.sym "true"] }, { path := [.sym "desireds", .sym "unachieved-desireds"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "b", .conj [.cmp "<>" (.var "b"), .var "d"]] }, { path := [.sym "on"], vals := [.var "on"] }],
        .pos false (.var "b") [{ path := [.sym "type"], vals := [.sym "block"] }, { path := [.sym "object-handle"], vals := [.lit (.var "bh")] }],
        .pos false (.var "d") [{ path := [.sym "object-handle"], vals := [.lit (.var "dh")] }],
        .pos false (.var "on") [{ path := [.sym "argument1"], vals := [.var "b"] }, { path := [.sym "argument2"], vals := [.cmp "<>" (.var "d")] }],
        .pos false (.var "s") [{ path := [.sym "desireds", .sym "desired", .sym "object"], vals := [.var "do"] }],
        .pos false (.var "on") [{ path := [.sym "argument2", .sym "object-handle"], vals := [.var "uh"] }],
        .pos false (.var "do") [{ path := [.sym "object-handle"], vals := [.var "uh"] }, { path := [.sym "clear"], vals := [.sym "true"] }],
        .pos false (.var "d") [{ path := [.sym "clear"], vals := [.sym "true"] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "move-block" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "action-handle"], [{ val := .sym "move-block" }]), ([.sym "argument1"], [{ val := .var "b" }]), ([.sym "argument2"], [{ val := .var "d" }]), ([.sym "argument-count"], [{ val := .int (2) }]), ([.sym "desireds"], [{ val := .var "pre" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (2) }]), ([.sym "desired"], [{ val := .var "p1" }, { val := .var "p2" }])],
        .make (.var "p1") [([.sym "object"], [{ val := .var "p1o" }])],
        .make (.var "p1o") [([.sym "object-handle"], [{ val := .var "bh" }]), ([.sym "clear"], [{ val := .sym "true" }])],
        .make (.var "p2") [([.sym "object"], [{ val := .var "p2o" }])],
        .make (.var "p2o") [([.sym "object-handle"], [{ val := .var "dh" }]), ([.sym "clear"], [{ val := .sym "true" }])]] }

def r_blocks_world_rl_move_block_2 : Prod :=
  { name := "blocks-world*rl*move-block",
    doc := ["RL template (RL-007) over the move and what each block is on; the reward of 1 on success comes from", "agent-world with ^flags.rl true (W-CHK-001), replacing the original's reward rule."],
    flags := [":template"],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "blocks-world"] }, { path := [.sym "operator"], vals := [.var "o", .sym "+"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "move-block"] }, { path := [.sym "argument1", .sym "object-handle"], vals := [.var "bh"] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.var "dh"] }],
        .pos false (.var "w") [{ path := [.sym "on"], vals := [.var "ra", .var "rb", .var "rc", .var "rd"] }],
        .pos false (.var "ra") [{ path := [.sym "argument1", .sym "object-handle"], vals := [.sym "A"] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.var "ua"] }],
        .pos false (.var "rb") [{ path := [.sym "argument1", .sym "object-handle"], vals := [.sym "B"] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.var "ub"] }],
        .pos false (.var "rc") [{ path := [.sym "argument1", .sym "object-handle"], vals := [.sym "C"] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.var "uc"] }],
        .pos false (.var "rd") [{ path := [.sym "argument1", .sym "object-handle"], vals := [.sym "D"] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.var "ud"] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "= 0" }])]] }

def v_blocks_world_hierarchical : Variant :=
  { family := "blocks-world", name := "blocks-world-hierarchical",
    about := ["Blocks world (3 blocks) with a gripper: move-block, then pick-up and put-down, then the gripper actions, each level a composite operator."],
    firstload := ["chunk never"],
    task := { name := "blocks-world", psExtra := [([.sym "dont-copy-object-attribute"], [{ val := .sym "in-place" }])], flags := [("mea-operator-selection", .sym "true")], environmentNone := true,
              initBody := [.make (.var "objs") [([.sym "object"], [{ val := .var "table" }, { val := .var "A" }, { val := .var "B" }, { val := .var "C" }, { val := .var "grip" }])],
      .make (.var "table") [([.sym "object-handle"], [{ val := .sym "table" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "table" }]), ([.sym "free"], [{ val := .sym "true" }])],
      .make (.var "A") [([.sym "object-handle"], [{ val := .sym "A" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "block" }]), ([.sym "free"], [{ val := .sym "false" }])],
      .make (.var "B") [([.sym "object-handle"], [{ val := .sym "B" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "block" }]), ([.sym "free"], [{ val := .sym "true" }])],
      .make (.var "C") [([.sym "object-handle"], [{ val := .sym "C" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "block" }]), ([.sym "free"], [{ val := .sym "true" }])],
      .make (.var "w") [([.sym "on"], [{ val := .var "on0" }])],
      .make (.var "on0") [([.sym "argument1"], [{ val := .var "A" }]), ([.sym "argument2"], [{ val := .var "table" }])],
      .make (.var "w") [([.sym "on"], [{ val := .var "on1" }])],
      .make (.var "on1") [([.sym "argument1"], [{ val := .var "B" }]), ([.sym "argument2"], [{ val := .var "table" }])],
      .make (.var "w") [([.sym "on"], [{ val := .var "on2" }])],
      .make (.var "on2") [([.sym "argument1"], [{ val := .var "C" }]), ([.sym "argument2"], [{ val := .var "A" }])],
      .make (.var "ds") [([.sym "desired-count"], [{ val := .int (3) }]), ([.sym "desired"], [{ val := .var "gA" }, { val := .var "gB" }, { val := .var "gC" }])],
      .make (.var "gA") [([.sym "on"], [{ val := .var "grA" }])],
      .make (.var "grA") [([.sym "argument1"], [{ val := .var "gaA" }]), ([.sym "argument2"], [{ val := .var "gbA" }])],
      .make (.var "gaA") [([.sym "object-handle"], [{ val := .sym "A" }])],
      .make (.var "gbA") [([.sym "object-handle"], [{ val := .sym "B" }])],
      .make (.var "gB") [([.sym "on"], [{ val := .var "grB" }])],
      .make (.var "grB") [([.sym "argument1"], [{ val := .var "gaB" }]), ([.sym "argument2"], [{ val := .var "gbB" }])],
      .make (.var "gaB") [([.sym "object-handle"], [{ val := .sym "B" }])],
      .make (.var "gbB") [([.sym "object-handle"], [{ val := .sym "C" }])],
      .make (.var "gC") [([.sym "on"], [{ val := .var "grC" }])],
      .make (.var "grC") [([.sym "argument1"], [{ val := .var "gaC" }]), ([.sym "argument2"], [{ val := .var "gbC" }])],
      .make (.var "gaC") [([.sym "object-handle"], [{ val := .sym "C" }])],
      .make (.var "gbC") [([.sym "object-handle"], [{ val := .sym "table" }])],
      .make (.var "grip") [([.sym "object-handle"], [{ val := .sym "gripper" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "gripper" }]), ([.sym "position"], [{ val := .int (1) }]), ([.sym "open"], [{ val := .int (1) }]), ([.sym "empty"], [{ val := .int (1) }]), ([.sym "above"], [{ val := .sym "table" }]), ([.sym "holding"], [{ val := .sym "table" }])]],
              initFile := none, initOpExtra := [], achieve := [.relationState, .objectState], achieveSpaces := [], indifferent := some "the original makes its operators indifferent apart from the top-level preferences", indifferentExcept := [], ancestors := false },
    files := [("elaborations.soar", [.ps, .achieve .relationState, .achieve .objectState, .p r_blocks_world_elaborate_in_place_table, .p r_blocks_world_elaborate_in_place_block]),
              ("initialize-blocks-world.soar", [.init]),
              ("move-block.soar", [.p r_blocks_world_propose_move_block, .p r_blocks_world_propose_pick_up, .p r_blocks_world_propose_put_down]),
              ("search-control.soar", [.p r_blocks_world_compare_out_of_place_to_table, .p r_blocks_world_compare_onto_desired_in_place, .indifferent]),
              ("pick-up.soar", [.p r_blocks_world_propose_move_gripper_above, .p r_blocks_world_apply_move_gripper_above_internal, .p r_blocks_world_propose_move_gripper_down, .p r_blocks_world_apply_move_gripper_down_internal, .p r_blocks_world_propose_close_gripper, .p r_blocks_world_apply_close_gripper_internal, .p r_blocks_world_propose_move_gripper_up, .p r_blocks_world_apply_move_gripper_up_internal]),
              ("put-down.soar", [.p r_blocks_world_propose_move_gripper_up_holding, .p r_blocks_world_apply_move_gripper_up_holding_internal, .p r_blocks_world_propose_move_gripper_above_destination, .p r_blocks_world_apply_move_gripper_above_destination_internal, .p r_blocks_world_propose_move_gripper_down_holding, .p r_blocks_world_apply_move_gripper_down_holding_internal, .p r_blocks_world_propose_open_gripper, .p r_blocks_world_apply_open_gripper_internal, .p r_blocks_world_apply_open_gripper_internal_on, .p r_blocks_world_apply_open_gripper_internal_free_old, .p r_blocks_world_apply_open_gripper_internal_cover_dest])] }

def v_blocks_world_hierarchical_lookahead : Variant :=
  { family := "blocks-world", name := "blocks-world-hierarchical-lookahead",
    about := ["Blocks world (3 blocks), two levels: inside move-block, pick-up and put-down of any block tie and look-ahead chooses (success: the block on its destination; failure: the wrong block held, or the gripper empty with the block elsewhere)."],
    firstload := ["chunk never"],
    task := { name := "blocks-world", psExtra := [([.sym "dont-copy-object-attribute"], [{ val := .sym "in-place" }])], flags := [("mea-operator-selection", .sym "true")], environmentNone := true,
              initBody := [.make (.var "objs") [([.sym "object"], [{ val := .var "table" }, { val := .var "A" }, { val := .var "B" }, { val := .var "C" }, { val := .var "grip" }])],
      .make (.var "table") [([.sym "object-handle"], [{ val := .sym "table" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "table" }]), ([.sym "free"], [{ val := .sym "true" }])],
      .make (.var "A") [([.sym "object-handle"], [{ val := .sym "A" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "block" }]), ([.sym "free"], [{ val := .sym "false" }])],
      .make (.var "B") [([.sym "object-handle"], [{ val := .sym "B" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "block" }]), ([.sym "free"], [{ val := .sym "true" }])],
      .make (.var "C") [([.sym "object-handle"], [{ val := .sym "C" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "block" }]), ([.sym "free"], [{ val := .sym "true" }])],
      .make (.var "w") [([.sym "on"], [{ val := .var "on0" }])],
      .make (.var "on0") [([.sym "argument1"], [{ val := .var "A" }]), ([.sym "argument2"], [{ val := .var "table" }])],
      .make (.var "w") [([.sym "on"], [{ val := .var "on1" }])],
      .make (.var "on1") [([.sym "argument1"], [{ val := .var "B" }]), ([.sym "argument2"], [{ val := .var "table" }])],
      .make (.var "w") [([.sym "on"], [{ val := .var "on2" }])],
      .make (.var "on2") [([.sym "argument1"], [{ val := .var "C" }]), ([.sym "argument2"], [{ val := .var "A" }])],
      .make (.var "ds") [([.sym "desired-count"], [{ val := .int (3) }]), ([.sym "desired"], [{ val := .var "gA" }, { val := .var "gB" }, { val := .var "gC" }])],
      .make (.var "gA") [([.sym "on"], [{ val := .var "grA" }])],
      .make (.var "grA") [([.sym "argument1"], [{ val := .var "gaA" }]), ([.sym "argument2"], [{ val := .var "gbA" }])],
      .make (.var "gaA") [([.sym "object-handle"], [{ val := .sym "A" }])],
      .make (.var "gbA") [([.sym "object-handle"], [{ val := .sym "B" }])],
      .make (.var "gB") [([.sym "on"], [{ val := .var "grB" }])],
      .make (.var "grB") [([.sym "argument1"], [{ val := .var "gaB" }]), ([.sym "argument2"], [{ val := .var "gbB" }])],
      .make (.var "gaB") [([.sym "object-handle"], [{ val := .sym "B" }])],
      .make (.var "gbB") [([.sym "object-handle"], [{ val := .sym "C" }])],
      .make (.var "gC") [([.sym "on"], [{ val := .var "grC" }])],
      .make (.var "grC") [([.sym "argument1"], [{ val := .var "gaC" }]), ([.sym "argument2"], [{ val := .var "gbC" }])],
      .make (.var "gaC") [([.sym "object-handle"], [{ val := .sym "C" }])],
      .make (.var "gbC") [([.sym "object-handle"], [{ val := .sym "table" }])],
      .make (.var "grip") [([.sym "object-handle"], [{ val := .sym "gripper" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "gripper" }]), ([.sym "position"], [{ val := .int (1) }]), ([.sym "open"], [{ val := .int (1) }]), ([.sym "empty"], [{ val := .int (1) }]), ([.sym "above"], [{ val := .sym "table" }]), ([.sym "holding"], [{ val := .sym "table" }])]],
              initFile := none, initOpExtra := [], achieve := [.relationState], achieveSpaces := ["move-block"], indifferent := some "the original makes its top-level moves indifferent apart from the preferences above", indifferentExcept := [], ancestors := false },
    files := [("elaborations.soar", [.ps, .achieve .relationState, .p r_blocks_world_elaborate_in_place_table, .p r_blocks_world_elaborate_in_place_block]),
              ("initialize-blocks-world.soar", [.init]),
              ("move-block.soar", [.p r_blocks_world_propose_move_block_2, .p r_blocks_world_propose_pick_up_2, .p r_blocks_world_apply_pick_up_internal, .p r_blocks_world_propose_put_down_2, .p r_blocks_world_apply_put_down_internal, .p r_blocks_world_apply_put_down_internal_free_old, .p r_blocks_world_apply_put_down_internal_cover_dest]),
              ("search-control.soar", [.p r_blocks_world_compare_out_of_place_to_table, .p r_blocks_world_compare_onto_desired_in_place, .indifferent]),
              ("look-ahead.soar", [.p r_blocks_world_elaborate_problem_space_move_block_look_ahead, .p r_blocks_world_elaborate_look_ahead_failure_wrong_block, .p r_blocks_world_elaborate_look_ahead_failure_misplaced])] }

def v_blocks_world_hrl : Variant :=
  { family := "blocks-world", name := "blocks-world-hrl",
    about := ["Blocks world (3 blocks), two levels: move-block chooses pick-up and put-down of any block by RL; rewards in move-block and on success."],
    firstload := ["chunk never", "rl --set learning on", "rl --set learning-rate 0.300000", "rl --set discount-rate 0.900000", "indifferent-selection --epsilon-greedy"],
    task := { name := "blocks-world", psExtra := [], flags := [("mea-operator-selection", .sym "true"), ("rl", .sym "true")], environmentNone := true,
              initBody := [.make (.var "objs") [([.sym "object"], [{ val := .var "table" }, { val := .var "A" }, { val := .var "B" }, { val := .var "C" }, { val := .var "grip" }])],
      .make (.var "table") [([.sym "object-handle"], [{ val := .sym "table" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "table" }]), ([.sym "free"], [{ val := .sym "true" }])],
      .make (.var "A") [([.sym "object-handle"], [{ val := .sym "A" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "block" }]), ([.sym "free"], [{ val := .sym "false" }])],
      .make (.var "B") [([.sym "object-handle"], [{ val := .sym "B" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "block" }]), ([.sym "free"], [{ val := .sym "true" }])],
      .make (.var "C") [([.sym "object-handle"], [{ val := .sym "C" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "block" }]), ([.sym "free"], [{ val := .sym "true" }])],
      .make (.var "w") [([.sym "on"], [{ val := .var "on0" }])],
      .make (.var "on0") [([.sym "argument1"], [{ val := .var "A" }]), ([.sym "argument2"], [{ val := .var "table" }])],
      .make (.var "w") [([.sym "on"], [{ val := .var "on1" }])],
      .make (.var "on1") [([.sym "argument1"], [{ val := .var "B" }]), ([.sym "argument2"], [{ val := .var "table" }])],
      .make (.var "w") [([.sym "on"], [{ val := .var "on2" }])],
      .make (.var "on2") [([.sym "argument1"], [{ val := .var "C" }]), ([.sym "argument2"], [{ val := .var "A" }])],
      .make (.var "ds") [([.sym "desired-count"], [{ val := .int (3) }]), ([.sym "desired"], [{ val := .var "gA" }, { val := .var "gB" }, { val := .var "gC" }])],
      .make (.var "gA") [([.sym "on"], [{ val := .var "grA" }])],
      .make (.var "grA") [([.sym "argument1"], [{ val := .var "gaA" }]), ([.sym "argument2"], [{ val := .var "gbA" }])],
      .make (.var "gaA") [([.sym "object-handle"], [{ val := .sym "A" }])],
      .make (.var "gbA") [([.sym "object-handle"], [{ val := .sym "B" }])],
      .make (.var "gB") [([.sym "on"], [{ val := .var "grB" }])],
      .make (.var "grB") [([.sym "argument1"], [{ val := .var "gaB" }]), ([.sym "argument2"], [{ val := .var "gbB" }])],
      .make (.var "gaB") [([.sym "object-handle"], [{ val := .sym "B" }])],
      .make (.var "gbB") [([.sym "object-handle"], [{ val := .sym "C" }])],
      .make (.var "gC") [([.sym "on"], [{ val := .var "grC" }])],
      .make (.var "grC") [([.sym "argument1"], [{ val := .var "gaC" }]), ([.sym "argument2"], [{ val := .var "gbC" }])],
      .make (.var "gaC") [([.sym "object-handle"], [{ val := .sym "C" }])],
      .make (.var "gbC") [([.sym "object-handle"], [{ val := .sym "table" }])],
      .make (.var "grip") [([.sym "object-handle"], [{ val := .sym "gripper" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "gripper" }]), ([.sym "position"], [{ val := .int (1) }]), ([.sym "open"], [{ val := .int (1) }]), ([.sym "empty"], [{ val := .int (1) }]), ([.sym "above"], [{ val := .sym "table" }]), ([.sym "holding"], [{ val := .sym "table" }])]],
              initFile := none, initOpExtra := [], achieve := [.relationState], achieveSpaces := [], indifferent := some "the original chooses by RL values among indifferent operators", indifferentExcept := [], ancestors := false },
    files := [("elaborations.soar", [.ps, .achieve .relationState]),
              ("initialize-blocks-world.soar", [.init]),
              ("move-block.soar", [.p r_blocks_world_propose_move_block_2, .p r_blocks_world_propose_pick_up_2, .p r_blocks_world_apply_pick_up_internal, .p r_blocks_world_propose_put_down_2, .p r_blocks_world_apply_put_down_internal, .p r_blocks_world_apply_put_down_internal_free_old, .p r_blocks_world_apply_put_down_internal_cover_dest]),
              ("rl.soar", [.p r_blocks_world_rl_move_block, .p r_blocks_world_rl_pick_up, .p r_blocks_world_rl_put_down, .p r_blocks_world_elaborate_reward_move_block_done, .p r_blocks_world_elaborate_reward_move_block_wrong_block]),
              ("search-control.soar", [.indifferent])] }

def v_blocks_world_hrl_3level : Variant :=
  { family := "blocks-world", name := "blocks-world-hrl-3level",
    about := ["Blocks world (3 blocks) with a gripper, three levels, and hierarchical reinforcement learning of the gripper actions (rewards in pick-up and put-down)."],
    firstload := ["chunk never", "rl --set learning on", "rl --set learning-rate 0.300000", "rl --set discount-rate 0.900000", "indifferent-selection --epsilon-greedy"],
    task := { name := "blocks-world", psExtra := [([.sym "dont-copy-object-attribute"], [{ val := .sym "in-place" }])], flags := [("mea-operator-selection", .sym "true")], environmentNone := true,
              initBody := [.make (.var "objs") [([.sym "object"], [{ val := .var "table" }, { val := .var "A" }, { val := .var "B" }, { val := .var "C" }, { val := .var "grip" }])],
      .make (.var "table") [([.sym "object-handle"], [{ val := .sym "table" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "table" }]), ([.sym "free"], [{ val := .sym "true" }])],
      .make (.var "A") [([.sym "object-handle"], [{ val := .sym "A" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "block" }]), ([.sym "free"], [{ val := .sym "false" }])],
      .make (.var "B") [([.sym "object-handle"], [{ val := .sym "B" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "block" }]), ([.sym "free"], [{ val := .sym "true" }])],
      .make (.var "C") [([.sym "object-handle"], [{ val := .sym "C" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "block" }]), ([.sym "free"], [{ val := .sym "true" }])],
      .make (.var "w") [([.sym "on"], [{ val := .var "on0" }])],
      .make (.var "on0") [([.sym "argument1"], [{ val := .var "A" }]), ([.sym "argument2"], [{ val := .var "table" }])],
      .make (.var "w") [([.sym "on"], [{ val := .var "on1" }])],
      .make (.var "on1") [([.sym "argument1"], [{ val := .var "B" }]), ([.sym "argument2"], [{ val := .var "table" }])],
      .make (.var "w") [([.sym "on"], [{ val := .var "on2" }])],
      .make (.var "on2") [([.sym "argument1"], [{ val := .var "C" }]), ([.sym "argument2"], [{ val := .var "A" }])],
      .make (.var "ds") [([.sym "desired-count"], [{ val := .int (3) }]), ([.sym "desired"], [{ val := .var "gA" }, { val := .var "gB" }, { val := .var "gC" }])],
      .make (.var "gA") [([.sym "on"], [{ val := .var "grA" }])],
      .make (.var "grA") [([.sym "argument1"], [{ val := .var "gaA" }]), ([.sym "argument2"], [{ val := .var "gbA" }])],
      .make (.var "gaA") [([.sym "object-handle"], [{ val := .sym "A" }])],
      .make (.var "gbA") [([.sym "object-handle"], [{ val := .sym "B" }])],
      .make (.var "gB") [([.sym "on"], [{ val := .var "grB" }])],
      .make (.var "grB") [([.sym "argument1"], [{ val := .var "gaB" }]), ([.sym "argument2"], [{ val := .var "gbB" }])],
      .make (.var "gaB") [([.sym "object-handle"], [{ val := .sym "B" }])],
      .make (.var "gbB") [([.sym "object-handle"], [{ val := .sym "C" }])],
      .make (.var "gC") [([.sym "on"], [{ val := .var "grC" }])],
      .make (.var "grC") [([.sym "argument1"], [{ val := .var "gaC" }]), ([.sym "argument2"], [{ val := .var "gbC" }])],
      .make (.var "gaC") [([.sym "object-handle"], [{ val := .sym "C" }])],
      .make (.var "gbC") [([.sym "object-handle"], [{ val := .sym "table" }])],
      .make (.var "grip") [([.sym "object-handle"], [{ val := .sym "gripper" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "gripper" }]), ([.sym "position"], [{ val := .int (1) }]), ([.sym "open"], [{ val := .int (1) }]), ([.sym "empty"], [{ val := .int (1) }]), ([.sym "above"], [{ val := .sym "table" }]), ([.sym "holding"], [{ val := .sym "table" }])]],
              initFile := none, initOpExtra := [], achieve := [.relationState, .objectState], achieveSpaces := [], indifferent := some "the original makes its operators indifferent (RL values decide)", indifferentExcept := [], ancestors := false },
    files := [("elaborations.soar", [.ps, .achieve .relationState, .achieve .objectState, .p r_blocks_world_elaborate_in_place_table, .p r_blocks_world_elaborate_in_place_block]),
              ("initialize-blocks-world.soar", [.init]),
              ("move-block.soar", [.p r_blocks_world_propose_move_block, .p r_blocks_world_propose_pick_up_3, .p r_blocks_world_propose_put_down_3]),
              ("search-control.soar", [.p r_blocks_world_compare_out_of_place_to_table, .p r_blocks_world_compare_onto_desired_in_place, .indifferent, .p r_blocks_world_compare_substate_operator_indifferent]),
              ("pick-up.soar", [.p r_blocks_world_propose_above_block, .p r_blocks_world_apply_above_block_internal, .p r_blocks_world_propose_down, .p r_blocks_world_apply_down_internal, .p r_blocks_world_propose_up, .p r_blocks_world_apply_up_internal, .p r_blocks_world_propose_open, .p r_blocks_world_apply_open_internal, .p r_blocks_world_propose_close, .p r_blocks_world_apply_close_internal_grasp, .p r_blocks_world_apply_close_internal_empty, .p r_blocks_world_elaborate_reward_pick_up_held, .p r_blocks_world_elaborate_reward_pick_up_closed_empty]),
              ("put-down.soar", [.p r_blocks_world_propose_up_holding, .p r_blocks_world_apply_up_holding_internal, .p r_blocks_world_propose_above_dest, .p r_blocks_world_apply_above_dest_internal, .p r_blocks_world_propose_down_holding, .p r_blocks_world_apply_down_holding_internal, .p r_blocks_world_propose_release, .p r_blocks_world_apply_release_internal_gripper, .p r_blocks_world_apply_release_internal_above, .p r_blocks_world_elaborate_reward_put_down, .p r_blocks_world_apply_release_internal_on, .p r_blocks_world_apply_release_internal_free_old, .p r_blocks_world_apply_release_internal_cover_dest]),
              ("rl.soar", [.p r_blocks_world_rl_pick_up_2, .p r_blocks_world_rl_put_down_2])] }

def v_blocks_world_look_ahead : Variant :=
  { family := "blocks-world", name := "blocks-world-look-ahead",
    about := ["Blocks world (3 blocks) by look-ahead; in look-ahead the block moved last is not moved again."],
    firstload := ["chunk always", "chunk add-osk on"],
    task := { name := "blocks-world", psExtra := [], flags := [("mea-operator-selection", .sym "true")], environmentNone := true,
              initBody := [.make (.var "objs") [([.sym "object"], [{ val := .var "table" }, { val := .var "A" }, { val := .var "B" }, { val := .var "C" }, { val := .var "mem" }])],
      .make (.var "table") [([.sym "object-handle"], [{ val := .sym "table" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "table" }]), ([.sym "clear"], [{ val := .sym "true" }])],
      .make (.var "A") [([.sym "object-handle"], [{ val := .sym "A" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "block" }]), ([.sym "clear"], [{ val := .sym "false" }])],
      .make (.var "B") [([.sym "object-handle"], [{ val := .sym "B" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "block" }]), ([.sym "clear"], [{ val := .sym "true" }])],
      .make (.var "C") [([.sym "object-handle"], [{ val := .sym "C" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "block" }]), ([.sym "clear"], [{ val := .sym "true" }])],
      .make (.var "w") [([.sym "on"], [{ val := .var "on0" }])],
      .make (.var "on0") [([.sym "argument1"], [{ val := .var "A" }]), ([.sym "argument2"], [{ val := .var "table" }])],
      .make (.var "w") [([.sym "on"], [{ val := .var "on1" }])],
      .make (.var "on1") [([.sym "argument1"], [{ val := .var "B" }]), ([.sym "argument2"], [{ val := .var "table" }])],
      .make (.var "w") [([.sym "on"], [{ val := .var "on2" }])],
      .make (.var "on2") [([.sym "argument1"], [{ val := .var "C" }]), ([.sym "argument2"], [{ val := .var "A" }])],
      .make (.var "ds") [([.sym "desired-count"], [{ val := .int (3) }]), ([.sym "desired"], [{ val := .var "gA" }, { val := .var "gB" }, { val := .var "gC" }])],
      .make (.var "gA") [([.sym "on"], [{ val := .var "grA" }])],
      .make (.var "grA") [([.sym "argument1"], [{ val := .var "gaA" }]), ([.sym "argument2"], [{ val := .var "gbA" }])],
      .make (.var "gaA") [([.sym "object-handle"], [{ val := .sym "A" }])],
      .make (.var "gbA") [([.sym "object-handle"], [{ val := .sym "B" }])],
      .make (.var "gB") [([.sym "on"], [{ val := .var "grB" }])],
      .make (.var "grB") [([.sym "argument1"], [{ val := .var "gaB" }]), ([.sym "argument2"], [{ val := .var "gbB" }])],
      .make (.var "gaB") [([.sym "object-handle"], [{ val := .sym "B" }])],
      .make (.var "gbB") [([.sym "object-handle"], [{ val := .sym "C" }])],
      .make (.var "gC") [([.sym "on"], [{ val := .var "grC" }])],
      .make (.var "grC") [([.sym "argument1"], [{ val := .var "gaC" }]), ([.sym "argument2"], [{ val := .var "gbC" }])],
      .make (.var "gaC") [([.sym "object-handle"], [{ val := .sym "C" }])],
      .make (.var "gbC") [([.sym "object-handle"], [{ val := .sym "table" }])],
      .make (.var "mem") [([.sym "object-handle"], [{ val := .sym "memory" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "memory" }]), ([.sym "last-block"], [{ val := .sym "none" }])]],
              initFile := none, initOpExtra := [], achieve := [.relationState], achieveSpaces := [], indifferent := none, indifferentExcept := [], ancestors := false },
    files := [("elaborations.soar", [.ps, .achieve .relationState]),
              ("initialize-blocks-world.soar", [.init]),
              ("move-block.soar", [.p r_blocks_world_propose_move_block_3, .p r_blocks_world_apply_move_block_internal, .p r_blocks_world_apply_move_block_internal_clear_source, .p r_blocks_world_apply_move_block_internal_cover_dest, .p r_blocks_world_apply_move_block_internal_last_block, .p r_blocks_world_compare_move_block_reject_twice])] }

def v_blocks_world_look_ahead_state_eval : Variant :=
  { family := "blocks-world", name := "blocks-world-look-ahead-state-eval",
    about := ["Blocks world (3 blocks) by look-ahead; look-ahead states get expected values by how much of the tower is in place; RL on."],
    firstload := ["chunk always", "chunk add-osk on", "rl --set learning on", "rl --set learning-rate 0.300000", "rl --set discount-rate 0.900000", "indifferent-selection --epsilon-greedy"],
    task := { name := "blocks-world", psExtra := [([.sym "dont-copy-object-attribute"], [{ val := .sym "in-place" }])], flags := [("mea-operator-selection", .sym "true"), ("rl", .sym "true")], environmentNone := true,
              initBody := [.make (.var "objs") [([.sym "object"], [{ val := .var "table" }, { val := .var "A" }, { val := .var "B" }, { val := .var "C" }])],
      .make (.var "table") [([.sym "object-handle"], [{ val := .sym "table" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "table" }]), ([.sym "clear"], [{ val := .sym "true" }])],
      .make (.var "A") [([.sym "object-handle"], [{ val := .sym "A" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "block" }]), ([.sym "clear"], [{ val := .sym "false" }])],
      .make (.var "B") [([.sym "object-handle"], [{ val := .sym "B" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "block" }]), ([.sym "clear"], [{ val := .sym "true" }])],
      .make (.var "C") [([.sym "object-handle"], [{ val := .sym "C" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "block" }]), ([.sym "clear"], [{ val := .sym "true" }])],
      .make (.var "w") [([.sym "on"], [{ val := .var "on0" }])],
      .make (.var "on0") [([.sym "argument1"], [{ val := .var "A" }]), ([.sym "argument2"], [{ val := .var "table" }])],
      .make (.var "w") [([.sym "on"], [{ val := .var "on1" }])],
      .make (.var "on1") [([.sym "argument1"], [{ val := .var "B" }]), ([.sym "argument2"], [{ val := .var "table" }])],
      .make (.var "w") [([.sym "on"], [{ val := .var "on2" }])],
      .make (.var "on2") [([.sym "argument1"], [{ val := .var "C" }]), ([.sym "argument2"], [{ val := .var "A" }])],
      .make (.var "ds") [([.sym "desired-count"], [{ val := .int (3) }]), ([.sym "desired"], [{ val := .var "gA" }, { val := .var "gB" }, { val := .var "gC" }])],
      .make (.var "gA") [([.sym "on"], [{ val := .var "grA" }])],
      .make (.var "grA") [([.sym "argument1"], [{ val := .var "gaA" }]), ([.sym "argument2"], [{ val := .var "gbA" }])],
      .make (.var "gaA") [([.sym "object-handle"], [{ val := .sym "A" }])],
      .make (.var "gbA") [([.sym "object-handle"], [{ val := .sym "B" }])],
      .make (.var "gB") [([.sym "on"], [{ val := .var "grB" }])],
      .make (.var "grB") [([.sym "argument1"], [{ val := .var "gaB" }]), ([.sym "argument2"], [{ val := .var "gbB" }])],
      .make (.var "gaB") [([.sym "object-handle"], [{ val := .sym "B" }])],
      .make (.var "gbB") [([.sym "object-handle"], [{ val := .sym "C" }])],
      .make (.var "gC") [([.sym "on"], [{ val := .var "grC" }])],
      .make (.var "grC") [([.sym "argument1"], [{ val := .var "gaC" }]), ([.sym "argument2"], [{ val := .var "gbC" }])],
      .make (.var "gaC") [([.sym "object-handle"], [{ val := .sym "C" }])],
      .make (.var "gbC") [([.sym "object-handle"], [{ val := .sym "table" }])]],
              initFile := none, initOpExtra := [], achieve := [.relationState], achieveSpaces := [], indifferent := none, indifferentExcept := [], ancestors := false },
    files := [("elaborations.soar", [.ps, .achieve .relationState, .p r_blocks_world_elaborate_in_place_table, .p r_blocks_world_elaborate_in_place_block]),
              ("initialize-blocks-world.soar", [.init]),
              ("move-block.soar", [.p r_blocks_world_propose_move_block_3, .p r_blocks_world_apply_move_block_internal, .p r_blocks_world_apply_move_block_internal_clear_source, .p r_blocks_world_apply_move_block_internal_cover_dest]),
              ("state-evaluation.soar", [.p r_blocks_world_elaborate_look_ahead_level_A, .p r_blocks_world_elaborate_look_ahead_level_B, .p r_blocks_world_elaborate_look_ahead_level_C, .p r_blocks_world_elaborate_look_ahead_level_none])] }

def v_blocks_world_operator_subgoaling : Variant :=
  { family := "blocks-world", name := "blocks-world-operator-subgoaling",
    about := ["Blocks world (3 blocks) by operator subgoaling: any move may be selected; when its block or destination is not clear, the substate clears them."],
    firstload := ["chunk never"],
    task := { name := "blocks-world", psExtra := [], flags := [("mea-operator-selection", .sym "true")], environmentNone := true,
              initBody := [.make (.var "objs") [([.sym "object"], [{ val := .var "table" }, { val := .var "A" }, { val := .var "B" }, { val := .var "C" }])],
      .make (.var "table") [([.sym "object-handle"], [{ val := .sym "table" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "table" }]), ([.sym "clear"], [{ val := .sym "true" }])],
      .make (.var "A") [([.sym "object-handle"], [{ val := .sym "A" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "block" }]), ([.sym "clear"], [{ val := .sym "true" }])],
      .make (.var "B") [([.sym "object-handle"], [{ val := .sym "B" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "block" }]), ([.sym "clear"], [{ val := .sym "false" }])],
      .make (.var "C") [([.sym "object-handle"], [{ val := .sym "C" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "block" }]), ([.sym "clear"], [{ val := .sym "true" }])],
      .make (.var "w") [([.sym "on"], [{ val := .var "on0" }])],
      .make (.var "on0") [([.sym "argument1"], [{ val := .var "A" }]), ([.sym "argument2"], [{ val := .var "B" }])],
      .make (.var "w") [([.sym "on"], [{ val := .var "on1" }])],
      .make (.var "on1") [([.sym "argument1"], [{ val := .var "B" }]), ([.sym "argument2"], [{ val := .var "table" }])],
      .make (.var "w") [([.sym "on"], [{ val := .var "on2" }])],
      .make (.var "on2") [([.sym "argument1"], [{ val := .var "C" }]), ([.sym "argument2"], [{ val := .var "table" }])],
      .make (.var "ds") [([.sym "desired-count"], [{ val := .int (3) }]), ([.sym "desired"], [{ val := .var "gA" }, { val := .var "gB" }, { val := .var "gC" }])],
      .make (.var "gA") [([.sym "on"], [{ val := .var "grA" }])],
      .make (.var "grA") [([.sym "argument1"], [{ val := .var "gaA" }]), ([.sym "argument2"], [{ val := .var "gbA" }])],
      .make (.var "gaA") [([.sym "object-handle"], [{ val := .sym "A" }])],
      .make (.var "gbA") [([.sym "object-handle"], [{ val := .sym "B" }])],
      .make (.var "gB") [([.sym "on"], [{ val := .var "grB" }])],
      .make (.var "grB") [([.sym "argument1"], [{ val := .var "gaB" }]), ([.sym "argument2"], [{ val := .var "gbB" }])],
      .make (.var "gaB") [([.sym "object-handle"], [{ val := .sym "B" }])],
      .make (.var "gbB") [([.sym "object-handle"], [{ val := .sym "C" }])],
      .make (.var "gC") [([.sym "on"], [{ val := .var "grC" }])],
      .make (.var "grC") [([.sym "argument1"], [{ val := .var "gaC" }]), ([.sym "argument2"], [{ val := .var "gbC" }])],
      .make (.var "gaC") [([.sym "object-handle"], [{ val := .sym "C" }])],
      .make (.var "gbC") [([.sym "object-handle"], [{ val := .sym "table" }])]],
              initFile := none, initOpExtra := [], achieve := [.relationState, .objectOperator, .objectState], achieveSpaces := [], indifferent := some "the original selects among its task operators at random", indifferentExcept := [], ancestors := false },
    files := [("elaborations.soar", [.ps, .achieve .relationState, .achieve .objectOperator, .achieve .objectState]),
              ("initialize-blocks-world.soar", [.init]),
              ("move-block.soar", [.p r_blocks_world_propose_move_block_4, .p r_blocks_world_apply_move_block_internal, .p r_blocks_world_apply_move_block_internal_clear_source, .p r_blocks_world_apply_move_block_internal_cover_dest, .p r_blocks_world_compare_avoid_clobbering, .p r_blocks_world_compare_prefer_ontop, .p r_blocks_world_compare_prefer_clearing]),
              ("search-control.soar", [.indifferent])] }

def v_blocks_world_operator_subgoaling_chunk : Variant :=
  { family := "blocks-world", name := "blocks-world-operator-subgoaling-chunk",
    about := ["Blocks world (3 blocks) by operator subgoaling: any move may be selected; when its block or destination is not clear, the substate clears them."],
    firstload := ["chunk always", "chunk add-osk on"],
    task := { name := "blocks-world", psExtra := [], flags := [("mea-operator-selection", .sym "true")], environmentNone := true,
              initBody := [.make (.var "objs") [([.sym "object"], [{ val := .var "table" }, { val := .var "A" }, { val := .var "B" }, { val := .var "C" }])],
      .make (.var "table") [([.sym "object-handle"], [{ val := .sym "table" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "table" }]), ([.sym "clear"], [{ val := .sym "true" }])],
      .make (.var "A") [([.sym "object-handle"], [{ val := .sym "A" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "block" }]), ([.sym "clear"], [{ val := .sym "true" }])],
      .make (.var "B") [([.sym "object-handle"], [{ val := .sym "B" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "block" }]), ([.sym "clear"], [{ val := .sym "false" }])],
      .make (.var "C") [([.sym "object-handle"], [{ val := .sym "C" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "block" }]), ([.sym "clear"], [{ val := .sym "true" }])],
      .make (.var "w") [([.sym "on"], [{ val := .var "on0" }])],
      .make (.var "on0") [([.sym "argument1"], [{ val := .var "A" }]), ([.sym "argument2"], [{ val := .var "B" }])],
      .make (.var "w") [([.sym "on"], [{ val := .var "on1" }])],
      .make (.var "on1") [([.sym "argument1"], [{ val := .var "B" }]), ([.sym "argument2"], [{ val := .var "table" }])],
      .make (.var "w") [([.sym "on"], [{ val := .var "on2" }])],
      .make (.var "on2") [([.sym "argument1"], [{ val := .var "C" }]), ([.sym "argument2"], [{ val := .var "table" }])],
      .make (.var "ds") [([.sym "desired-count"], [{ val := .int (3) }]), ([.sym "desired"], [{ val := .var "gA" }, { val := .var "gB" }, { val := .var "gC" }])],
      .make (.var "gA") [([.sym "on"], [{ val := .var "grA" }])],
      .make (.var "grA") [([.sym "argument1"], [{ val := .var "gaA" }]), ([.sym "argument2"], [{ val := .var "gbA" }])],
      .make (.var "gaA") [([.sym "object-handle"], [{ val := .sym "A" }])],
      .make (.var "gbA") [([.sym "object-handle"], [{ val := .sym "B" }])],
      .make (.var "gB") [([.sym "on"], [{ val := .var "grB" }])],
      .make (.var "grB") [([.sym "argument1"], [{ val := .var "gaB" }]), ([.sym "argument2"], [{ val := .var "gbB" }])],
      .make (.var "gaB") [([.sym "object-handle"], [{ val := .sym "B" }])],
      .make (.var "gbB") [([.sym "object-handle"], [{ val := .sym "C" }])],
      .make (.var "gC") [([.sym "on"], [{ val := .var "grC" }])],
      .make (.var "grC") [([.sym "argument1"], [{ val := .var "gaC" }]), ([.sym "argument2"], [{ val := .var "gbC" }])],
      .make (.var "gaC") [([.sym "object-handle"], [{ val := .sym "C" }])],
      .make (.var "gbC") [([.sym "object-handle"], [{ val := .sym "table" }])]],
              initFile := none, initOpExtra := [], achieve := [.relationState, .objectOperator, .objectState], achieveSpaces := [], indifferent := some "the original selects among its task operators at random", indifferentExcept := [], ancestors := false },
    files := [("elaborations.soar", [.ps, .achieve .relationState, .achieve .objectOperator, .achieve .objectState]),
              ("initialize-blocks-world.soar", [.init]),
              ("move-block.soar", [.p r_blocks_world_propose_move_block_4, .p r_blocks_world_apply_move_block_internal, .p r_blocks_world_apply_move_block_internal_clear_source, .p r_blocks_world_apply_move_block_internal_cover_dest, .p r_blocks_world_compare_avoid_clobbering, .p r_blocks_world_compare_prefer_ontop, .p r_blocks_world_compare_prefer_clearing]),
              ("search-control.soar", [.indifferent])] }

def v_blocks_world_operator_subgoaling_relevant : Variant :=
  { family := "blocks-world", name := "blocks-world-operator-subgoaling-relevant",
    about := ["Blocks world (3 blocks) by operator subgoaling, proposing only relevant moves: onto a block's desired destination, or clearing a block that must be clear."],
    firstload := ["chunk never"],
    task := { name := "blocks-world", psExtra := [], flags := [("mea-operator-selection", .sym "true")], environmentNone := true,
              initBody := [.make (.var "objs") [([.sym "object"], [{ val := .var "table" }, { val := .var "A" }, { val := .var "B" }, { val := .var "C" }])],
      .make (.var "table") [([.sym "object-handle"], [{ val := .sym "table" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "table" }]), ([.sym "clear"], [{ val := .sym "true" }])],
      .make (.var "A") [([.sym "object-handle"], [{ val := .sym "A" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "block" }]), ([.sym "clear"], [{ val := .sym "true" }])],
      .make (.var "B") [([.sym "object-handle"], [{ val := .sym "B" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "block" }]), ([.sym "clear"], [{ val := .sym "false" }])],
      .make (.var "C") [([.sym "object-handle"], [{ val := .sym "C" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "block" }]), ([.sym "clear"], [{ val := .sym "true" }])],
      .make (.var "w") [([.sym "on"], [{ val := .var "on0" }])],
      .make (.var "on0") [([.sym "argument1"], [{ val := .var "A" }]), ([.sym "argument2"], [{ val := .var "B" }])],
      .make (.var "w") [([.sym "on"], [{ val := .var "on1" }])],
      .make (.var "on1") [([.sym "argument1"], [{ val := .var "B" }]), ([.sym "argument2"], [{ val := .var "table" }])],
      .make (.var "w") [([.sym "on"], [{ val := .var "on2" }])],
      .make (.var "on2") [([.sym "argument1"], [{ val := .var "C" }]), ([.sym "argument2"], [{ val := .var "table" }])],
      .make (.var "ds") [([.sym "desired-count"], [{ val := .int (3) }]), ([.sym "desired"], [{ val := .var "gA" }, { val := .var "gB" }, { val := .var "gC" }])],
      .make (.var "gA") [([.sym "on"], [{ val := .var "grA" }])],
      .make (.var "grA") [([.sym "argument1"], [{ val := .var "gaA" }]), ([.sym "argument2"], [{ val := .var "gbA" }])],
      .make (.var "gaA") [([.sym "object-handle"], [{ val := .sym "A" }])],
      .make (.var "gbA") [([.sym "object-handle"], [{ val := .sym "B" }])],
      .make (.var "gB") [([.sym "on"], [{ val := .var "grB" }])],
      .make (.var "grB") [([.sym "argument1"], [{ val := .var "gaB" }]), ([.sym "argument2"], [{ val := .var "gbB" }])],
      .make (.var "gaB") [([.sym "object-handle"], [{ val := .sym "B" }])],
      .make (.var "gbB") [([.sym "object-handle"], [{ val := .sym "C" }])],
      .make (.var "gC") [([.sym "on"], [{ val := .var "grC" }])],
      .make (.var "grC") [([.sym "argument1"], [{ val := .var "gaC" }]), ([.sym "argument2"], [{ val := .var "gbC" }])],
      .make (.var "gaC") [([.sym "object-handle"], [{ val := .sym "C" }])],
      .make (.var "gbC") [([.sym "object-handle"], [{ val := .sym "table" }])]],
              initFile := none, initOpExtra := [], achieve := [.relationState, .objectOperator, .objectState], achieveSpaces := [], indifferent := some "the original selects among its task operators at random", indifferentExcept := [], ancestors := false },
    files := [("elaborations.soar", [.ps, .achieve .relationState, .achieve .objectOperator, .achieve .objectState]),
              ("initialize-blocks-world.soar", [.init]),
              ("move-block.soar", [.p r_blocks_world_propose_move_block_onto_desired, .p r_blocks_world_propose_move_block_clearing, .p r_blocks_world_apply_move_block_internal, .p r_blocks_world_apply_move_block_internal_clear_source, .p r_blocks_world_apply_move_block_internal_cover_dest]),
              ("search-control.soar", [.indifferent])] }

def v_blocks_world_random : Variant :=
  { family := "blocks-world", name := "blocks-world-random",
    about := ["Blocks world (3 blocks, all on the table): random legal moves until the tower is built."],
    firstload := ["chunk never"],
    task := { name := "blocks-world", psExtra := [], flags := [("mea-operator-selection", .sym "true")], environmentNone := true,
              initBody := [.make (.var "objs") [([.sym "object"], [{ val := .var "table" }, { val := .var "A" }, { val := .var "B" }, { val := .var "C" }])],
      .make (.var "table") [([.sym "object-handle"], [{ val := .sym "table" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "table" }]), ([.sym "clear"], [{ val := .sym "true" }])],
      .make (.var "A") [([.sym "object-handle"], [{ val := .sym "A" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "block" }]), ([.sym "clear"], [{ val := .sym "true" }])],
      .make (.var "B") [([.sym "object-handle"], [{ val := .sym "B" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "block" }]), ([.sym "clear"], [{ val := .sym "true" }])],
      .make (.var "C") [([.sym "object-handle"], [{ val := .sym "C" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "block" }]), ([.sym "clear"], [{ val := .sym "true" }])],
      .make (.var "w") [([.sym "on"], [{ val := .var "on0" }])],
      .make (.var "on0") [([.sym "argument1"], [{ val := .var "A" }]), ([.sym "argument2"], [{ val := .var "table" }])],
      .make (.var "w") [([.sym "on"], [{ val := .var "on1" }])],
      .make (.var "on1") [([.sym "argument1"], [{ val := .var "B" }]), ([.sym "argument2"], [{ val := .var "table" }])],
      .make (.var "w") [([.sym "on"], [{ val := .var "on2" }])],
      .make (.var "on2") [([.sym "argument1"], [{ val := .var "C" }]), ([.sym "argument2"], [{ val := .var "table" }])],
      .make (.var "ds") [([.sym "desired-count"], [{ val := .int (3) }]), ([.sym "desired"], [{ val := .var "gA" }, { val := .var "gB" }, { val := .var "gC" }])],
      .make (.var "gA") [([.sym "on"], [{ val := .var "grA" }])],
      .make (.var "grA") [([.sym "argument1"], [{ val := .var "gaA" }]), ([.sym "argument2"], [{ val := .var "gbA" }])],
      .make (.var "gaA") [([.sym "object-handle"], [{ val := .sym "A" }])],
      .make (.var "gbA") [([.sym "object-handle"], [{ val := .sym "B" }])],
      .make (.var "gB") [([.sym "on"], [{ val := .var "grB" }])],
      .make (.var "grB") [([.sym "argument1"], [{ val := .var "gaB" }]), ([.sym "argument2"], [{ val := .var "gbB" }])],
      .make (.var "gaB") [([.sym "object-handle"], [{ val := .sym "B" }])],
      .make (.var "gbB") [([.sym "object-handle"], [{ val := .sym "C" }])],
      .make (.var "gC") [([.sym "on"], [{ val := .var "grC" }])],
      .make (.var "grC") [([.sym "argument1"], [{ val := .var "gaC" }]), ([.sym "argument2"], [{ val := .var "gbC" }])],
      .make (.var "gaC") [([.sym "object-handle"], [{ val := .sym "C" }])],
      .make (.var "gbC") [([.sym "object-handle"], [{ val := .sym "table" }])]],
              initFile := none, initOpExtra := [], achieve := [.relationState], achieveSpaces := [], indifferent := some "the original selects among its task operators at random", indifferentExcept := [], ancestors := false },
    files := [("elaborations.soar", [.ps, .achieve .relationState]),
              ("initialize-blocks-world.soar", [.init]),
              ("move-block.soar", [.p r_blocks_world_propose_move_block_3, .p r_blocks_world_apply_move_block_internal, .p r_blocks_world_apply_move_block_internal_clear_source, .p r_blocks_world_apply_move_block_internal_cover_dest]),
              ("search-control.soar", [.indifferent])] }

def v_blocks_world_rl : Variant :=
  { family := "blocks-world", name := "blocks-world-rl",
    about := ["Blocks world (4 blocks) with reinforcement learning over the positions of all blocks; reward 1 on success."],
    firstload := ["chunk never", "rl --set learning on", "rl --set learning-rate 0.300000", "rl --set discount-rate 0.900000", "indifferent-selection --epsilon-greedy"],
    task := { name := "blocks-world", psExtra := [], flags := [("mea-operator-selection", .sym "true"), ("rl", .sym "true")], environmentNone := true,
              initBody := [.make (.var "objs") [([.sym "object"], [{ val := .var "table" }, { val := .var "A" }, { val := .var "B" }, { val := .var "C" }, { val := .var "D" }])],
      .make (.var "table") [([.sym "object-handle"], [{ val := .sym "table" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "table" }]), ([.sym "clear"], [{ val := .sym "true" }])],
      .make (.var "A") [([.sym "object-handle"], [{ val := .sym "A" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "block" }]), ([.sym "clear"], [{ val := .sym "false" }])],
      .make (.var "B") [([.sym "object-handle"], [{ val := .sym "B" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "block" }]), ([.sym "clear"], [{ val := .sym "true" }])],
      .make (.var "C") [([.sym "object-handle"], [{ val := .sym "C" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "block" }]), ([.sym "clear"], [{ val := .sym "true" }])],
      .make (.var "D") [([.sym "object-handle"], [{ val := .sym "D" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "block" }]), ([.sym "clear"], [{ val := .sym "false" }])],
      .make (.var "w") [([.sym "on"], [{ val := .var "on0" }])],
      .make (.var "on0") [([.sym "argument1"], [{ val := .var "A" }]), ([.sym "argument2"], [{ val := .var "table" }])],
      .make (.var "w") [([.sym "on"], [{ val := .var "on1" }])],
      .make (.var "on1") [([.sym "argument1"], [{ val := .var "B" }]), ([.sym "argument2"], [{ val := .var "D" }])],
      .make (.var "w") [([.sym "on"], [{ val := .var "on2" }])],
      .make (.var "on2") [([.sym "argument1"], [{ val := .var "C" }]), ([.sym "argument2"], [{ val := .var "A" }])],
      .make (.var "w") [([.sym "on"], [{ val := .var "on3" }])],
      .make (.var "on3") [([.sym "argument1"], [{ val := .var "D" }]), ([.sym "argument2"], [{ val := .var "table" }])],
      .make (.var "ds") [([.sym "desired-count"], [{ val := .int (4) }]), ([.sym "desired"], [{ val := .var "gA" }, { val := .var "gB" }, { val := .var "gC" }, { val := .var "gD" }])],
      .make (.var "gA") [([.sym "on"], [{ val := .var "grA" }])],
      .make (.var "grA") [([.sym "argument1"], [{ val := .var "gaA" }]), ([.sym "argument2"], [{ val := .var "gbA" }])],
      .make (.var "gaA") [([.sym "object-handle"], [{ val := .sym "A" }])],
      .make (.var "gbA") [([.sym "object-handle"], [{ val := .sym "B" }])],
      .make (.var "gB") [([.sym "on"], [{ val := .var "grB" }])],
      .make (.var "grB") [([.sym "argument1"], [{ val := .var "gaB" }]), ([.sym "argument2"], [{ val := .var "gbB" }])],
      .make (.var "gaB") [([.sym "object-handle"], [{ val := .sym "B" }])],
      .make (.var "gbB") [([.sym "object-handle"], [{ val := .sym "C" }])],
      .make (.var "gC") [([.sym "on"], [{ val := .var "grC" }])],
      .make (.var "grC") [([.sym "argument1"], [{ val := .var "gaC" }]), ([.sym "argument2"], [{ val := .var "gbC" }])],
      .make (.var "gaC") [([.sym "object-handle"], [{ val := .sym "C" }])],
      .make (.var "gbC") [([.sym "object-handle"], [{ val := .sym "D" }])],
      .make (.var "gD") [([.sym "on"], [{ val := .var "grD" }])],
      .make (.var "grD") [([.sym "argument1"], [{ val := .var "gaD" }]), ([.sym "argument2"], [{ val := .var "gbD" }])],
      .make (.var "gaD") [([.sym "object-handle"], [{ val := .sym "D" }])],
      .make (.var "gbD") [([.sym "object-handle"], [{ val := .sym "table" }])]],
              initFile := none, initOpExtra := [], achieve := [.relationState], achieveSpaces := [], indifferent := some "the original chooses by RL values among indifferent operators", indifferentExcept := [], ancestors := false },
    files := [("elaborations.soar", [.ps, .achieve .relationState]),
              ("initialize-blocks-world.soar", [.init]),
              ("move-block.soar", [.p r_blocks_world_propose_move_block_3, .p r_blocks_world_apply_move_block_internal, .p r_blocks_world_apply_move_block_internal_clear_source, .p r_blocks_world_apply_move_block_internal_cover_dest]),
              ("rl.soar", [.p r_blocks_world_rl_move_block_2]),
              ("search-control.soar", [.indifferent])] }

def v_blocks_world_simple : Variant :=
  { family := "blocks-world", name := "blocks-world-simple",
    about := ["Blocks world (5 blocks): out-of-place blocks to the table, then build the goal tower."],
    firstload := ["chunk never"],
    task := { name := "blocks-world", psExtra := [([.sym "dont-copy-object-attribute"], [{ val := .sym "in-place" }])], flags := [("mea-operator-selection", .sym "true")], environmentNone := true,
              initBody := [.make (.var "objs") [([.sym "object"], [{ val := .var "table" }, { val := .var "A" }, { val := .var "B" }, { val := .var "C" }, { val := .var "D" }, { val := .var "E" }])],
      .make (.var "table") [([.sym "object-handle"], [{ val := .sym "table" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "table" }]), ([.sym "clear"], [{ val := .sym "true" }])],
      .make (.var "A") [([.sym "object-handle"], [{ val := .sym "A" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "block" }]), ([.sym "clear"], [{ val := .sym "false" }])],
      .make (.var "B") [([.sym "object-handle"], [{ val := .sym "B" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "block" }]), ([.sym "clear"], [{ val := .sym "true" }])],
      .make (.var "C") [([.sym "object-handle"], [{ val := .sym "C" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "block" }]), ([.sym "clear"], [{ val := .sym "true" }])],
      .make (.var "D") [([.sym "object-handle"], [{ val := .sym "D" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "block" }]), ([.sym "clear"], [{ val := .sym "false" }])],
      .make (.var "E") [([.sym "object-handle"], [{ val := .sym "E" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "block" }]), ([.sym "clear"], [{ val := .sym "false" }])],
      .make (.var "w") [([.sym "on"], [{ val := .var "on0" }])],
      .make (.var "on0") [([.sym "argument1"], [{ val := .var "A" }]), ([.sym "argument2"], [{ val := .var "table" }])],
      .make (.var "w") [([.sym "on"], [{ val := .var "on1" }])],
      .make (.var "on1") [([.sym "argument1"], [{ val := .var "B" }]), ([.sym "argument2"], [{ val := .var "E" }])],
      .make (.var "w") [([.sym "on"], [{ val := .var "on2" }])],
      .make (.var "on2") [([.sym "argument1"], [{ val := .var "C" }]), ([.sym "argument2"], [{ val := .var "A" }])],
      .make (.var "w") [([.sym "on"], [{ val := .var "on3" }])],
      .make (.var "on3") [([.sym "argument1"], [{ val := .var "D" }]), ([.sym "argument2"], [{ val := .var "table" }])],
      .make (.var "w") [([.sym "on"], [{ val := .var "on4" }])],
      .make (.var "on4") [([.sym "argument1"], [{ val := .var "E" }]), ([.sym "argument2"], [{ val := .var "D" }])],
      .make (.var "ds") [([.sym "desired-count"], [{ val := .int (5) }]), ([.sym "desired"], [{ val := .var "gA" }, { val := .var "gB" }, { val := .var "gC" }, { val := .var "gD" }, { val := .var "gE" }])],
      .make (.var "gA") [([.sym "on"], [{ val := .var "grA" }])],
      .make (.var "grA") [([.sym "argument1"], [{ val := .var "gaA" }]), ([.sym "argument2"], [{ val := .var "gbA" }])],
      .make (.var "gaA") [([.sym "object-handle"], [{ val := .sym "A" }])],
      .make (.var "gbA") [([.sym "object-handle"], [{ val := .sym "B" }])],
      .make (.var "gB") [([.sym "on"], [{ val := .var "grB" }])],
      .make (.var "grB") [([.sym "argument1"], [{ val := .var "gaB" }]), ([.sym "argument2"], [{ val := .var "gbB" }])],
      .make (.var "gaB") [([.sym "object-handle"], [{ val := .sym "B" }])],
      .make (.var "gbB") [([.sym "object-handle"], [{ val := .sym "C" }])],
      .make (.var "gC") [([.sym "on"], [{ val := .var "grC" }])],
      .make (.var "grC") [([.sym "argument1"], [{ val := .var "gaC" }]), ([.sym "argument2"], [{ val := .var "gbC" }])],
      .make (.var "gaC") [([.sym "object-handle"], [{ val := .sym "C" }])],
      .make (.var "gbC") [([.sym "object-handle"], [{ val := .sym "D" }])],
      .make (.var "gD") [([.sym "on"], [{ val := .var "grD" }])],
      .make (.var "grD") [([.sym "argument1"], [{ val := .var "gaD" }]), ([.sym "argument2"], [{ val := .var "gbD" }])],
      .make (.var "gaD") [([.sym "object-handle"], [{ val := .sym "D" }])],
      .make (.var "gbD") [([.sym "object-handle"], [{ val := .sym "E" }])],
      .make (.var "gE") [([.sym "on"], [{ val := .var "grE" }])],
      .make (.var "grE") [([.sym "argument1"], [{ val := .var "gaE" }]), ([.sym "argument2"], [{ val := .var "gbE" }])],
      .make (.var "gaE") [([.sym "object-handle"], [{ val := .sym "E" }])],
      .make (.var "gbE") [([.sym "object-handle"], [{ val := .sym "table" }])]],
              initFile := none, initOpExtra := [], achieve := [.relationState], achieveSpaces := [], indifferent := some "the original makes its moves indifferent apart from the preferences above", indifferentExcept := [], ancestors := false },
    files := [("elaborations.soar", [.ps, .achieve .relationState, .p r_blocks_world_elaborate_in_place_table, .p r_blocks_world_elaborate_in_place_block]),
              ("initialize-blocks-world.soar", [.init]),
              ("move-block.soar", [.p r_blocks_world_propose_move_block_3, .p r_blocks_world_apply_move_block_internal, .p r_blocks_world_apply_move_block_internal_clear_source, .p r_blocks_world_apply_move_block_internal_cover_dest]),
              ("search-control.soar", [.p r_blocks_world_compare_out_of_place_to_table, .p r_blocks_world_compare_onto_desired_in_place, .indifferent])] }

def v_blocks_world_simple_3 : Variant :=
  { family := "blocks-world", name := "blocks-world-simple-3",
    about := ["Blocks world (3 blocks): out-of-place blocks to the table, then build the goal tower."],
    firstload := ["chunk never"],
    task := { name := "blocks-world", psExtra := [([.sym "dont-copy-object-attribute"], [{ val := .sym "in-place" }])], flags := [("mea-operator-selection", .sym "true")], environmentNone := true,
              initBody := [.make (.var "objs") [([.sym "object"], [{ val := .var "table" }, { val := .var "A" }, { val := .var "B" }, { val := .var "C" }])],
      .make (.var "table") [([.sym "object-handle"], [{ val := .sym "table" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "table" }]), ([.sym "clear"], [{ val := .sym "true" }])],
      .make (.var "A") [([.sym "object-handle"], [{ val := .sym "A" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "block" }]), ([.sym "clear"], [{ val := .sym "false" }])],
      .make (.var "B") [([.sym "object-handle"], [{ val := .sym "B" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "block" }]), ([.sym "clear"], [{ val := .sym "true" }])],
      .make (.var "C") [([.sym "object-handle"], [{ val := .sym "C" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "block" }]), ([.sym "clear"], [{ val := .sym "true" }])],
      .make (.var "w") [([.sym "on"], [{ val := .var "on0" }])],
      .make (.var "on0") [([.sym "argument1"], [{ val := .var "A" }]), ([.sym "argument2"], [{ val := .var "table" }])],
      .make (.var "w") [([.sym "on"], [{ val := .var "on1" }])],
      .make (.var "on1") [([.sym "argument1"], [{ val := .var "B" }]), ([.sym "argument2"], [{ val := .var "table" }])],
      .make (.var "w") [([.sym "on"], [{ val := .var "on2" }])],
      .make (.var "on2") [([.sym "argument1"], [{ val := .var "C" }]), ([.sym "argument2"], [{ val := .var "A" }])],
      .make (.var "ds") [([.sym "desired-count"], [{ val := .int (3) }]), ([.sym "desired"], [{ val := .var "gA" }, { val := .var "gB" }, { val := .var "gC" }])],
      .make (.var "gA") [([.sym "on"], [{ val := .var "grA" }])],
      .make (.var "grA") [([.sym "argument1"], [{ val := .var "gaA" }]), ([.sym "argument2"], [{ val := .var "gbA" }])],
      .make (.var "gaA") [([.sym "object-handle"], [{ val := .sym "A" }])],
      .make (.var "gbA") [([.sym "object-handle"], [{ val := .sym "B" }])],
      .make (.var "gB") [([.sym "on"], [{ val := .var "grB" }])],
      .make (.var "grB") [([.sym "argument1"], [{ val := .var "gaB" }]), ([.sym "argument2"], [{ val := .var "gbB" }])],
      .make (.var "gaB") [([.sym "object-handle"], [{ val := .sym "B" }])],
      .make (.var "gbB") [([.sym "object-handle"], [{ val := .sym "C" }])],
      .make (.var "gC") [([.sym "on"], [{ val := .var "grC" }])],
      .make (.var "grC") [([.sym "argument1"], [{ val := .var "gaC" }]), ([.sym "argument2"], [{ val := .var "gbC" }])],
      .make (.var "gaC") [([.sym "object-handle"], [{ val := .sym "C" }])],
      .make (.var "gbC") [([.sym "object-handle"], [{ val := .sym "table" }])]],
              initFile := none, initOpExtra := [], achieve := [.relationState], achieveSpaces := [], indifferent := some "the original makes its moves indifferent apart from the preferences above", indifferentExcept := [], ancestors := false },
    files := [("elaborations.soar", [.ps, .achieve .relationState, .p r_blocks_world_elaborate_in_place_table, .p r_blocks_world_elaborate_in_place_block]),
              ("initialize-blocks-world.soar", [.init]),
              ("move-block.soar", [.p r_blocks_world_propose_move_block_3, .p r_blocks_world_apply_move_block_internal, .p r_blocks_world_apply_move_block_internal_clear_source, .p r_blocks_world_apply_move_block_internal_cover_dest]),
              ("search-control.soar", [.p r_blocks_world_compare_out_of_place_to_table, .p r_blocks_world_compare_onto_desired_in_place, .indifferent])] }

def variants : List Variant := [v_blocks_world_hierarchical, v_blocks_world_hierarchical_lookahead, v_blocks_world_hrl, v_blocks_world_hrl_3level, v_blocks_world_look_ahead, v_blocks_world_look_ahead_state_eval, v_blocks_world_operator_subgoaling, v_blocks_world_operator_subgoaling_chunk, v_blocks_world_operator_subgoaling_relevant, v_blocks_world_random, v_blocks_world_rl, v_blocks_world_simple, v_blocks_world_simple_3]

end Fam.Families.BlocksWorld
