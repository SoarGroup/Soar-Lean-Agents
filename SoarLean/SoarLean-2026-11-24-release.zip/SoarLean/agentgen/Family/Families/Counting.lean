import Family.Task
set_option maxHeartbeats 0
set_option maxRecDepth 100000
/-!
# counting: world-convention agents of the counting family

Typed description migrated on 19 November 2026 from the world-v6 agents (Tasks/Families/counting/world-v6),
which were written from the original programs. Task-level parts are `Task` fields; family knowledge is typed
productions, defined once and shared by the variants that use them.

Written 19 November 2026 by Claude, supervised by John E. Laird.
-/
namespace Fam.Families.Counting
open Fam

def r_count_add_smem_propose_add : Prod :=
  { name := "count-add-smem*propose*add",
    doc := ["add <adder> (composite, W-COP-002): effect: adder done 1.  Its substate (problem space add) counts", "digit1 up digit2 times with successor facts from semantic memory (SMM-016: commands created by", "operator applications; agent-world removes a query once it has a result, W-OTH-003)."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "count-add-smem"] }, { path := [.sym "flags", .sym "mea-operator-selection"], vals := [.sym "true"] }, { path := [.sym "desireds", .sym "unachieved-desireds"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "ad"] }],
        .pos false (.var "ad") [{ path := [.sym "type"], vals := [.sym "adder"] }, { path := [.sym "done"], vals := [.int (0)] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "add" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "argument1"], [{ val := .var "ad" }]), ([.sym "argument-count"], [{ val := .int (1) }]), ([.sym "desireds"], [{ val := .var "pre" }]), ([.sym "effect-desireds"], [{ val := .var "ed" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (0) }])],
        .make (.var "ed") [([.sym "desired-count"], [{ val := .int (1) }]), ([.sym "desired"], [{ val := .var "e1" }])],
        .make (.var "e1") [([.sym "object"], [{ val := .var "e1o" }])],
        .make (.var "e1o") [([.sym "object-handle"], [{ val := .sym "adder" }]), ([.sym "done"], [{ val := .int (1) }])]] }

def r_count_add_smem_propose_init_local : Prod :=
  { name := "count-add-smem*propose*init-local",
    doc := ["Propose init-local in problem space add when its conditions below hold."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "add"] }, { path := [.sym "argument1"], vals := [.var "ad"] }, { path := [.sym "d1"], vals := [], neg := true }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+ >" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "init-local" }]), ([.sym "task-operator"], [{ val := .sym "false" }])]] }

def r_count_add_smem_apply_init_local : Prod :=
  { name := "count-add-smem*apply*init-local",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "add"] }, { path := [.sym "operator", .sym "name"], vals := [.sym "init-local"] }, { path := [.sym "argument1"], vals := [.var "ad"] }],
        .pos false (.var "ad") [{ path := [.sym "digit1"], vals := [.var "d1"] }]],
    acts := [.call "log" [.int (1), .fn "crlf" [], .str "Apply init-local: ", .var "d1"],
        .make (.var "s") [([.sym "d1"], [{ val := .var "d1" }]), ([.sym "d3"], [{ val := .int (0) }]), ([.sym "carry"], [{ val := .int (0) }]), ([.sym "phase"], [{ val := .int (0) }])]] }

def r_count_add_smem_propose_next_digit1 : Prod :=
  { name := "count-add-smem*propose*next-digit1",
    doc := ["next-digit1: d1 := successor(d1) (carry when d1 was 9)."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "add"] }, { path := [.sym "argument1"], vals := [.var "ad"] }, { path := [.sym "phase"], vals := [.int (0)] }, { path := [.sym "d3"], vals := [.conj [.cmp "<>" (.var "d2")]] }],
        .pos false (.var "ad") [{ path := [.sym "digit2"], vals := [.var "d2"] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+ =" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "next-digit1" }]), ([.sym "task-operator"], [{ val := .sym "false" }])]] }

def r_count_add_smem_apply_next_digit1_query : Prod :=
  { name := "count-add-smem*apply*next-digit1*query",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "add"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "d1"], vals := [.var "d1"] }, { path := [.sym "smem", .sym "command"], vals := [.var "c"] }, { path := [.sym "queried"], vals := [.var "o"], neg := true }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "next-digit1"] }]],
    acts := [.make (.var "s") [([.sym "queried"], [{ val := .var "o" }])],
        .make (.var "c") [([.sym "query"], [{ val := .var "q" }])],
        .make (.var "q") [([.sym "kind"], [{ val := .sym "succ" }]), ([.sym "symbol"], [{ val := .var "d1" }])]] }

def r_count_add_smem_apply_next_digit1 : Prod :=
  { name := "count-add-smem*apply*next-digit1",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "add"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "d1"], vals := [.var "d1"] }, { path := [.sym "carry"], vals := [.var "cy"] }, { path := [.sym "phase"], vals := [.int (0)] }, { path := [.sym "queried"], vals := [.var "o"] }, { path := [.sym "smem", .sym "result", .sym "retrieved"], vals := [.var "f"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "next-digit1"] }],
        .pos false (.var "f") [{ path := [.sym "kind"], vals := [.sym "succ"] }, { path := [.sym "symbol"], vals := [.var "d1"] }, { path := [.sym "next"], vals := [.var "n"] }]],
    acts := [.call "log" [.int (1), .fn "crlf" [], .str "Apply next-digit1: ", .var "n"],
        .make (.var "s") [([.sym "d1"], [{ val := .var "d1", pref := "-" }, { val := .var "n" }]), ([.sym "phase"], [{ val := .int (0), pref := "-" }, { val := .int (1) }])]] }

def r_count_add_smem_apply_next_digit1_carry : Prod :=
  { name := "count-add-smem*apply*next-digit1*carry",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "add"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "d1"], vals := [.int (9)] }, { path := [.sym "carry"], vals := [.int (0)] }, { path := [.sym "phase"], vals := [.int (0)] }, { path := [.sym "queried"], vals := [.var "o"] }, { path := [.sym "smem", .sym "result", .sym "retrieved"], vals := [.var "f"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "next-digit1"] }],
        .pos false (.var "f") [{ path := [.sym "kind"], vals := [.sym "succ"] }, { path := [.sym "symbol"], vals := [.int (9)] }]],
    acts := [.make (.var "s") [([.sym "carry"], [{ val := .int (0), pref := "-" }, { val := .int (1) }])]] }

def r_count_add_smem_propose_next_digit3 : Prod :=
  { name := "count-add-smem*propose*next-digit3",
    doc := ["next-digit3: d3 := successor(d3)."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "add"] }, { path := [.sym "phase"], vals := [.int (1)] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+ =" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "next-digit3" }]), ([.sym "task-operator"], [{ val := .sym "false" }])]] }

def r_count_add_smem_apply_next_digit3_query : Prod :=
  { name := "count-add-smem*apply*next-digit3*query",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "add"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "d3"], vals := [.var "d3"] }, { path := [.sym "smem", .sym "command"], vals := [.var "c"] }, { path := [.sym "queried"], vals := [.var "o"], neg := true }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "next-digit3"] }]],
    acts := [.make (.var "s") [([.sym "queried"], [{ val := .var "o" }])],
        .make (.var "c") [([.sym "query"], [{ val := .var "q" }])],
        .make (.var "q") [([.sym "kind"], [{ val := .sym "succ" }]), ([.sym "symbol"], [{ val := .var "d3" }])]] }

def r_count_add_smem_apply_next_digit3 : Prod :=
  { name := "count-add-smem*apply*next-digit3",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "add"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "d3"], vals := [.var "d3"] }, { path := [.sym "phase"], vals := [.int (1)] }, { path := [.sym "queried"], vals := [.var "o"] }, { path := [.sym "smem", .sym "result", .sym "retrieved"], vals := [.var "f"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "next-digit3"] }],
        .pos false (.var "f") [{ path := [.sym "kind"], vals := [.sym "succ"] }, { path := [.sym "symbol"], vals := [.var "d3"] }, { path := [.sym "next"], vals := [.var "n"] }]],
    acts := [.call "log" [.int (1), .fn "crlf" [], .str "Apply next-digit3: ", .var "n"],
        .make (.var "s") [([.sym "d3"], [{ val := .var "d3", pref := "-" }, { val := .var "n" }]), ([.sym "phase"], [{ val := .int (1), pref := "-" }, { val := .int (0) }])]] }

def r_count_add_smem_propose_done : Prod :=
  { name := "count-add-smem*propose*done",
    doc := ["done <adder>: write the sum digit and carry to the adder (task-action operator)."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "add"] }, { path := [.sym "argument1"], vals := [.var "ad"] }, { path := [.sym "phase"], vals := [.int (0)] }, { path := [.sym "d3"], vals := [.var "d2"] }],
        .pos false (.var "ad") [{ path := [.sym "digit2"], vals := [.var "d2"] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+ =" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "done" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "action-handle"], [{ val := .sym "done" }]), ([.sym "argument1"], [{ val := .var "ad" }]), ([.sym "argument-count"], [{ val := .int (1) }]), ([.sym "desireds"], [{ val := .var "pre" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (0) }])]] }

def r_count_add_smem_apply_done_internal : Prod :=
  { name := "count-add-smem*apply*done*internal",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "add"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "internal-actions"], vals := [.sym "true"] }, { path := [.sym "d1"], vals := [.var "d1"] }, { path := [.sym "carry"], vals := [.var "cy"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "done"] }, { path := [.sym "pre-conditions-satisfied"], vals := [.sym "true"] }, { path := [.sym "argument1", .sym "object-handle"], vals := [.lit (.var "h")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "ad"] }],
        .pos false (.var "ad") [{ path := [.sym "object-handle"], vals := [.lit (.var "h")] }, { path := [.sym "digit1"], vals := [.var "od1"] }, { path := [.sym "carry"], vals := [.var "ocy"] }, { path := [.sym "done"], vals := [.int (0)] }]],
    acts := [.call "log" [.int (1), .fn "crlf" [], .str "Apply done: digit1 ", .var "d1", .str " carry ", .var "cy"],
        .make (.var "ad") [([.sym "digit1"], [{ val := .var "od1", pref := "-" }, { val := .var "d1" }]), ([.sym "carry"], [{ val := .var "ocy", pref := "-" }, { val := .var "cy" }]), ([.sym "done"], [{ val := .int (0), pref := "-" }, { val := .int (1) }])]] }

def r_count_in_substate_propose_count_to_limit : Prod :=
  { name := "count-in-substate*propose*count-to-limit",
    doc := ["count-to-limit <counter> (composite, W-COP-002): effect: the counter is 75000.  It counts in a local", "count on its implementation substate (problem space count-to-limit, W-COP-007), then writes the result."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "count-in-substate"] }, { path := [.sym "flags", .sym "mea-operator-selection"], vals := [.sym "true"] }, { path := [.sym "desireds", .sym "unachieved-desireds"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "c"] }],
        .pos false (.var "c") [{ path := [.sym "type"], vals := [.sym "counter"] }, { path := [.sym "value"], vals := [.cmp "<" (.int (75000))] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "count-to-limit" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "argument1"], [{ val := .var "c" }]), ([.sym "argument-count"], [{ val := .int (1) }]), ([.sym "desireds"], [{ val := .var "pre" }]), ([.sym "effect-desireds"], [{ val := .var "ed" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (0) }])],
        .make (.var "ed") [([.sym "desired-count"], [{ val := .int (1) }]), ([.sym "desired"], [{ val := .var "e1" }])],
        .make (.var "e1") [([.sym "object"], [{ val := .var "e1o" }])],
        .make (.var "e1o") [([.sym "object-handle"], [{ val := .sym "counter" }]), ([.sym "value"], [{ val := .int (75000) }])]] }

def r_count_in_substate_propose_init_local : Prod :=
  { name := "count-in-substate*propose*init-local",
    doc := ["init-local: copy the counter's value to the substate's local count (internal operator, W-NOP-001)."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "count-to-limit"] }, { path := [.sym "argument1"], vals := [.var "c"] }, { path := [.sym "count"], vals := [], neg := true }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+ >" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "init-local" }]), ([.sym "task-operator"], [{ val := .sym "false" }])]] }

def r_count_in_substate_apply_init_local : Prod :=
  { name := "count-in-substate*apply*init-local",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "count-to-limit"] }, { path := [.sym "operator", .sym "name"], vals := [.sym "init-local"] }, { path := [.sym "argument1"], vals := [.var "c"] }],
        .pos false (.var "c") [{ path := [.sym "value"], vals := [.var "v"] }]],
    acts := [.call "log" [.int (1), .fn "crlf" [], .str "Apply init-local: ", .var "v"],
        .make (.var "s") [([.sym "count"], [{ val := .var "v" }])]] }

def r_count_in_substate_propose_increment : Prod :=
  { name := "count-in-substate*propose*increment",
    doc := ["increment: local count + 1 while below 75000 (internal operator)."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "count-to-limit"] }, { path := [.sym "count"], vals := [.cmp "<" (.int (75000))] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+ =" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "increment" }]), ([.sym "task-operator"], [{ val := .sym "false" }])]] }

def r_count_in_substate_apply_increment : Prod :=
  { name := "count-in-substate*apply*increment",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "count-to-limit"] }, { path := [.sym "operator", .sym "name"], vals := [.sym "increment"] }, { path := [.sym "count"], vals := [.var "n"] }]],
    acts := [.call "log" [.int (2), .fn "crlf" [], .str "Apply increment: ", .var "n"],
        .make (.var "s") [([.sym "count"], [{ val := .var "n", pref := "-" }, { val := .fn "+" [.var "n", .int (1)] }])]] }

def r_count_in_substate_propose_done : Prod :=
  { name := "count-in-substate*propose*done",
    doc := ["done <counter>: write the local count to the counter (task-action operator, internal application)."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "count-to-limit"] }, { path := [.sym "count"], vals := [.int (75000)] }, { path := [.sym "argument1"], vals := [.var "c"] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+ =" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "done" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "action-handle"], [{ val := .sym "done" }]), ([.sym "argument1"], [{ val := .var "c" }]), ([.sym "argument-count"], [{ val := .int (1) }]), ([.sym "desireds"], [{ val := .var "pre" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (0) }])]] }

def r_count_in_substate_apply_done_internal : Prod :=
  { name := "count-in-substate*apply*done*internal",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "count-to-limit"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "internal-actions"], vals := [.sym "true"] }, { path := [.sym "count"], vals := [.var "n"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "done"] }, { path := [.sym "pre-conditions-satisfied"], vals := [.sym "true"] }, { path := [.sym "argument1", .sym "object-handle"], vals := [.lit (.var "h")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "c"] }],
        .pos false (.var "c") [{ path := [.sym "object-handle"], vals := [.lit (.var "h")] }, { path := [.sym "value"], vals := [.var "v"] }]],
    acts := [.call "log" [.int (1), .fn "crlf" [], .str "Apply done: ", .var "n"],
        .make (.var "c") [([.sym "value"], [{ val := .var "v", pref := "-" }, { val := .var "n" }])]] }

def r_count_up_propose_count : Prod :=
  { name := "count-up*propose*count",
    doc := ["count <counter>: add 1 while the value is below 100."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "count-up"] }, { path := [.sym "flags", .sym "mea-operator-selection"], vals := [.sym "true"] }, { path := [.sym "desireds", .sym "unachieved-desireds"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "c"] }],
        .pos false (.var "c") [{ path := [.sym "type"], vals := [.sym "counter"] }, { path := [.sym "value"], vals := [.cmp "<" (.int (100))] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "count" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "action-handle"], [{ val := .sym "count" }]), ([.sym "argument1"], [{ val := .var "c" }]), ([.sym "argument-count"], [{ val := .int (1) }]), ([.sym "desireds"], [{ val := .var "pre" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (0) }])]] }

def r_count_up_apply_count_internal : Prod :=
  { name := "count-up*apply*count*internal",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "count-up"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "internal-actions"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "count"] }, { path := [.sym "pre-conditions-satisfied"], vals := [.sym "true"] }, { path := [.sym "argument1", .sym "object-handle"], vals := [.lit (.var "h")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "c"] }],
        .pos false (.var "c") [{ path := [.sym "object-handle"], vals := [.lit (.var "h")] }, { path := [.sym "value"], vals := [.var "v"] }]],
    acts := [.call "log" [.int (1), .fn "crlf" [], .str "Apply count: ", .var "v"],
        .make (.var "c") [([.sym "value"], [{ val := .var "v", pref := "-" }, { val := .fn "+" [.var "v", .int (1)] }])]] }

def v_count_add_smem : Variant :=
  { family := "counting", name := "count-add-smem",
    about := ["Add digit2 to digit1 (9 + 9) by counting with successor facts retrieved from semantic memory."],
    firstload := ["chunk never", "smem --set learning on", "smem --add {", "   (<l0> ^kind succ ^|symbol| 0 ^|next| 1)", "   (<l1> ^kind succ ^|symbol| 1 ^|next| 2)", "   (<l2> ^kind succ ^|symbol| 2 ^|next| 3)", "   (<l3> ^kind succ ^|symbol| 3 ^|next| 4)", "   (<l4> ^kind succ ^|symbol| 4 ^|next| 5)", "   (<l5> ^kind succ ^|symbol| 5 ^|next| 6)", "   (<l6> ^kind succ ^|symbol| 6 ^|next| 7)", "   (<l7> ^kind succ ^|symbol| 7 ^|next| 8)", "   (<l8> ^kind succ ^|symbol| 8 ^|next| 9)", "   (<l9> ^kind succ ^|symbol| 9 ^|next| 0)", "}"],
    task := { name := "count-add-smem", psExtra := [], flags := [("mea-operator-selection", .sym "true")], environmentNone := true,
              initBody := [.make (.var "objs") [([.sym "object"], [{ val := .var "ad" }])],
      .make (.var "ad") [([.sym "object-handle"], [{ val := .sym "adder" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "adder" }]), ([.sym "digit1"], [{ val := .int (9) }]), ([.sym "digit2"], [{ val := .int (9) }]), ([.sym "carry"], [{ val := .int (0) }]), ([.sym "done"], [{ val := .int (0) }])],
      .make (.var "ds") [([.sym "desired-count"], [{ val := .int (1) }]), ([.sym "desired"], [{ val := .var "d1" }])],
      .make (.var "d1") [([.sym "object"], [{ val := .var "d1o" }])],
      .make (.var "d1o") [([.sym "object-handle"], [{ val := .sym "adder" }]), ([.sym "done"], [{ val := .int (1) }])]],
              initFile := none, initOpExtra := [], achieve := [.objectState], achieveSpaces := [], indifferent := none, indifferentExcept := [], ancestors := false },
    files := [("elaborations.soar", [.ps, .achieve .objectState]),
              ("initialize-count-add-smem.soar", [.init]),
              ("add.soar", [.p r_count_add_smem_propose_add, .p r_count_add_smem_propose_init_local, .p r_count_add_smem_apply_init_local, .p r_count_add_smem_propose_next_digit1, .p r_count_add_smem_apply_next_digit1_query, .p r_count_add_smem_apply_next_digit1, .p r_count_add_smem_apply_next_digit1_carry, .p r_count_add_smem_propose_next_digit3, .p r_count_add_smem_apply_next_digit3_query, .p r_count_add_smem_apply_next_digit3, .p r_count_add_smem_propose_done, .p r_count_add_smem_apply_done_internal])] }

def v_count_in_substate : Variant :=
  { family := "counting", name := "count-in-substate",
    about := ["Count from 1 to 75000 in the substate of one composite operator (count-to-limit)."],
    firstload := ["chunk never"],
    task := { name := "count-in-substate", psExtra := [], flags := [("mea-operator-selection", .sym "true")], environmentNone := true,
              initBody := [.make (.var "objs") [([.sym "object"], [{ val := .var "c" }])],
      .make (.var "c") [([.sym "object-handle"], [{ val := .sym "counter" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "counter" }]), ([.sym "value"], [{ val := .int (1) }])],
      .make (.var "ds") [([.sym "desired-count"], [{ val := .int (1) }]), ([.sym "desired"], [{ val := .var "d1" }])],
      .make (.var "d1") [([.sym "object"], [{ val := .var "d1o" }])],
      .make (.var "d1o") [([.sym "object-handle"], [{ val := .sym "counter" }]), ([.sym "value"], [{ val := .int (75000) }])]],
              initFile := none, initOpExtra := [], achieve := [.objectState], achieveSpaces := [], indifferent := none, indifferentExcept := [], ancestors := false },
    files := [("elaborations.soar", [.ps, .achieve .objectState]),
              ("initialize-count-in-substate.soar", [.init]),
              ("count-to-limit.soar", [.p r_count_in_substate_propose_count_to_limit, .p r_count_in_substate_propose_init_local, .p r_count_in_substate_apply_init_local, .p r_count_in_substate_propose_increment, .p r_count_in_substate_apply_increment, .p r_count_in_substate_propose_done, .p r_count_in_substate_apply_done_internal])] }

def v_count_up : Variant :=
  { family := "counting", name := "count-up",
    about := ["Count a counter from 0 to 100, one step per operator."],
    firstload := ["chunk never"],
    task := { name := "count-up", psExtra := [], flags := [("mea-operator-selection", .sym "true")], environmentNone := true,
              initBody := [.make (.var "objs") [([.sym "object"], [{ val := .var "c" }])],
      .make (.var "c") [([.sym "object-handle"], [{ val := .sym "counter" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "counter" }]), ([.sym "value"], [{ val := .int (0) }])],
      .make (.var "ds") [([.sym "desired-count"], [{ val := .int (1) }]), ([.sym "desired"], [{ val := .var "d1" }])],
      .make (.var "d1") [([.sym "object"], [{ val := .var "d1o" }])],
      .make (.var "d1o") [([.sym "object-handle"], [{ val := .sym "counter" }]), ([.sym "value"], [{ val := .int (100) }])]],
              initFile := none, initOpExtra := [], achieve := [.objectState], achieveSpaces := [], indifferent := none, indifferentExcept := [], ancestors := false },
    files := [("elaborations.soar", [.ps, .achieve .objectState]),
              ("initialize-count-up.soar", [.init]),
              ("count.soar", [.p r_count_up_propose_count, .p r_count_up_apply_count_internal])] }

def variants : List Variant := [v_count_add_smem, v_count_in_substate, v_count_up]

end Fam.Families.Counting
