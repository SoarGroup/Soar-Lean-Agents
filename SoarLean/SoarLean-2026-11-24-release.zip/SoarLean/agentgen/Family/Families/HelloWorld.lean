import Family.Task
set_option maxHeartbeats 0
set_option maxRecDepth 100000
/-!
# hello-world: world-convention agents of the hello-world family

Typed description migrated on 19 November 2026 from the world-v6 agents (Tasks/Families/hello-world/world-v6),
which were written from the original programs. Task-level parts are `Task` fields; family knowledge is typed
productions, defined once and shared by the variants that use them.

Written 19 November 2026 by Claude, supervised by John E. Laird.
-/
namespace Fam.Families.HelloWorld
open Fam

def r_hello_world_propose_hello_world : Prod :=
  { name := "hello-world*propose*hello-world",
    doc := ["hello-world <greeting>: write the greeting when it has not been written."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "hello-world"] }, { path := [.sym "flags", .sym "mea-operator-selection"], vals := [.sym "true"] }, { path := [.sym "desireds", .sym "unachieved-desireds"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "g"] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "greeting"] }, { path := [.sym "written"], vals := [.int (0)] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "hello-world" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "action-handle"], [{ val := .sym "hello-world" }]), ([.sym "argument1"], [{ val := .var "g" }]), ([.sym "argument-count"], [{ val := .int (1) }]), ([.sym "desireds"], [{ val := .var "pre" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (0) }])]] }

def r_hello_world_apply_hello_world_internal : Prod :=
  { name := "hello-world*apply*hello-world*internal",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "hello-world"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "internal-actions"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "hello-world"] }, { path := [.sym "pre-conditions-satisfied"], vals := [.sym "true"] }, { path := [.sym "argument1", .sym "object-handle"], vals := [.lit (.var "h")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "g"] }],
        .pos false (.var "g") [{ path := [.sym "object-handle"], vals := [.lit (.var "h")] }, { path := [.sym "written"], vals := [.var "old"] }]],
    acts := [.call "log" [.int (1), .fn "crlf" [], .str "Apply hello-world: ", .var "h"],
        .call "write" [.fn "crlf" [], .str "Hello World"],
        .make (.var "g") [([.sym "written"], [{ val := .var "old", pref := "-" }, { val := .int (1) }])]] }

def v_hello_world : Variant :=
  { family := "hello-world", name := "hello-world",
    about := ["Hello world: write a greeting once."],
    firstload := ["chunk never"],
    task := { name := "hello-world", psExtra := [], flags := [("mea-operator-selection", .sym "true")], environmentNone := true,
              initBody := [.make (.var "objs") [([.sym "object"], [{ val := .var "g" }])],
      .make (.var "g") [([.sym "object-handle"], [{ val := .sym "greeting" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "greeting" }]), ([.sym "written"], [{ val := .int (0) }])],
      .make (.var "ds") [([.sym "desired-count"], [{ val := .int (1) }]), ([.sym "desired"], [{ val := .var "d1" }])],
      .make (.var "d1") [([.sym "object"], [{ val := .var "d1o" }])],
      .make (.var "d1o") [([.sym "object-handle"], [{ val := .sym "greeting" }]), ([.sym "written"], [{ val := .int (1) }])]],
              initFile := none, initOpExtra := [], achieve := [.objectState], achieveSpaces := [], indifferent := none, indifferentExcept := [], ancestors := false },
    files := [("elaborations.soar", [.ps, .achieve .objectState]),
              ("initialize-hello-world.soar", [.init]),
              ("hello-world-operator.soar", [.p r_hello_world_propose_hello_world, .p r_hello_world_apply_hello_world_internal])] }

def variants : List Variant := [v_hello_world]

end Fam.Families.HelloWorld
