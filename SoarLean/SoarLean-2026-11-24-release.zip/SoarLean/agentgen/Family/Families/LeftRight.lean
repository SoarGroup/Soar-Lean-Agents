import Family.Task
set_option maxHeartbeats 0
set_option maxRecDepth 100000
/-!
# left-right: world-convention agents of the left-right family

Typed description migrated on 19 November 2026 from the world-v6 agents (Tasks/Families/left-right/world-v6),
which were written from the original programs. Task-level parts are `Task` fields; family knowledge is typed
productions, defined once and shared by the variants that use them.

Written 19 November 2026 by Claude, supervised by John E. Laird.
-/
namespace Fam.Families.LeftRight
open Fam

def r_left_right_propose_move : Prod :=
  { name := "left-right*propose*move",
    doc := ["move <agent> <direction>: from location 0, one step left (-1) or right (1).  The direction is a", "non-object parameter (W-APP-004)."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "left-right"] }, { path := [.sym "flags", .sym "mea-operator-selection"], vals := [.sym "true"] }, { path := [.sym "desireds", .sym "unachieved-desireds"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "ag"] }],
        .pos false (.var "ag") [{ path := [.sym "type"], vals := [.sym "agent"] }, { path := [.sym "location"], vals := [.int (0)] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "l", pref := "+" }]), ([.sym "operator"], [{ val := .var "r", pref := "+" }])],
        .make (.var "l") [([.sym "name"], [{ val := .sym "move" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "action-handle"], [{ val := .sym "move" }]), ([.sym "argument1"], [{ val := .var "ag" }]), ([.sym "argument2"], [{ val := .int (-1) }]), ([.sym "argument-count"], [{ val := .int (2) }]), ([.sym "desireds"], [{ val := .var "lp" }])],
        .make (.var "lp") [([.sym "desired-count"], [{ val := .int (0) }])],
        .make (.var "r") [([.sym "name"], [{ val := .sym "move" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "action-handle"], [{ val := .sym "move" }]), ([.sym "argument1"], [{ val := .var "ag" }]), ([.sym "argument2"], [{ val := .int (1) }]), ([.sym "argument-count"], [{ val := .int (2) }]), ([.sym "desireds"], [{ val := .var "rp" }])],
        .make (.var "rp") [([.sym "desired-count"], [{ val := .int (0) }])]] }

def r_left_right_apply_move_internal : Prod :=
  { name := "left-right*apply*move*internal",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "left-right"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "internal-actions"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "move"] }, { path := [.sym "pre-conditions-satisfied"], vals := [.sym "true"] }, { path := [.sym "argument1", .sym "object-handle"], vals := [.lit (.var "h")] }, { path := [.sym "argument2"], vals := [.var "dir"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "ag"] }],
        .pos false (.var "ag") [{ path := [.sym "object-handle"], vals := [.lit (.var "h")] }, { path := [.sym "location"], vals := [.var "l"] }, { path := [.sym "moved"], vals := [.var "m"] }]],
    acts := [.call "log" [.int (1), .fn "crlf" [], .str "Moved: ", .var "dir"],
        .make (.var "ag") [([.sym "location"], [{ val := .var "l", pref := "-" }, { val := .var "dir" }]), ([.sym "moved"], [{ val := .var "m", pref := "-" }, { val := .int (1) }])]] }

def r_left_right_rl_move : Prod :=
  { name := "left-right*rl*move",
    doc := ["RL template (RL-007) over the move direction and the agent's state."],
    flags := [":template"],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "left-right"] }, { path := [.sym "operator"], vals := [.var "o", .sym "+"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "move"] }, { path := [.sym "argument2"], vals := [.var "dir"] }, { path := [.sym "argument1"], vals := [.var "ag"] }],
        .pos false (.var "ag") [{ path := [.sym "location"], vals := [.var "l"] }, { path := [.sym "moved"], vals := [.var "m"] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "= 0" }])]] }

def r_left_right_elaborate_reward_left : Prod :=
  { name := "left-right*elaborate*reward*left",
    doc := ["Rewards (RL-002, RL-008 i-supported): -1 at location -1, +1 at location 1."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "left-right"] }, { path := [.sym "reward-link"], vals := [.var "r"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "ag"] }],
        .pos false (.var "ag") [{ path := [.sym "type"], vals := [.sym "agent"] }, { path := [.sym "location"], vals := [.int (-1)] }]],
    acts := [.make (.var "r") [([.sym "reward"], [{ val := .var "rw" }])],
        .make (.var "rw") [([.sym "value"], [{ val := .int (-1) }])]] }

def r_left_right_elaborate_reward_right : Prod :=
  { name := "left-right*elaborate*reward*right",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "left-right"] }, { path := [.sym "reward-link"], vals := [.var "r"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "ag"] }],
        .pos false (.var "ag") [{ path := [.sym "type"], vals := [.sym "agent"] }, { path := [.sym "location"], vals := [.int (1)] }]],
    acts := [.make (.var "r") [([.sym "reward"], [{ val := .var "rw" }])],
        .make (.var "rw") [([.sym "value"], [{ val := .int (1) }])]] }

def v_left_right : Variant :=
  { family := "left-right", name := "left-right",
    about := ["Left-right: one move, left (-1, reward -1) or right (1, reward 1); RL learns which."],
    firstload := ["chunk never", "rl --set learning on", "rl --set learning-rate 0.300000", "rl --set discount-rate 0.900000", "indifferent-selection --epsilon-greedy"],
    task := { name := "left-right", psExtra := [], flags := [("mea-operator-selection", .sym "true")], environmentNone := true,
              initBody := [.make (.var "objs") [([.sym "object"], [{ val := .var "ag" }])],
      .make (.var "ag") [([.sym "object-handle"], [{ val := .sym "agent" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "agent" }]), ([.sym "location"], [{ val := .int (0) }]), ([.sym "moved"], [{ val := .int (0) }])],
      .make (.var "ds") [([.sym "desired-count"], [{ val := .int (1) }]), ([.sym "desired"], [{ val := .var "d1" }])],
      .make (.var "d1") [([.sym "object"], [{ val := .var "d1o" }])],
      .make (.var "d1o") [([.sym "object-handle"], [{ val := .sym "agent" }]), ([.sym "moved"], [{ val := .int (1) }])]],
              initFile := none, initOpExtra := [], achieve := [.objectState], achieveSpaces := [], indifferent := some "the original chooses by RL values among indifferent operators", indifferentExcept := [], ancestors := false },
    files := [("elaborations.soar", [.ps, .achieve .objectState]),
              ("initialize-left-right.soar", [.init]),
              ("move.soar", [.p r_left_right_propose_move, .p r_left_right_apply_move_internal]),
              ("rl.soar", [.p r_left_right_rl_move, .p r_left_right_elaborate_reward_left, .p r_left_right_elaborate_reward_right]),
              ("search-control.soar", [.indifferent])] }

def variants : List Variant := [v_left_right]

end Fam.Families.LeftRight
