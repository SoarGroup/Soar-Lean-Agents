import Family.Task
set_option maxHeartbeats 0
set_option maxRecDepth 100000
/-!
# missionaries-cannibals: world-convention agents of the missionaries-cannibals family

Typed description migrated on 19 November 2026 from the world-v6 agents (Tasks/Families/missionaries-cannibals/world-v6),
which were written from the original programs. Task-level parts are `Task` fields; family knowledge is typed
productions, defined once and shared by the variants that use them.

Written 19 November 2026 by Claude, supervised by John E. Laird.
-/
namespace Fam.Families.MissionariesCannibals
open Fam

def r_mac_elaborate_failure_outnumbered : Prod :=
  { name := "mac*elaborate*failure*outnumbered",
    doc := ["Failure: on some bank the missionaries (if any) are outnumbered (W-DES-001: ^failure <desireds>).", "At the top state the library reports the failure and interrupts (W-DES-017)."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "mac"] }, { path := [.sym "desireds"], vals := [.var "ds"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "b"] }],
        .pos false (.var "b") [{ path := [.sym "type"], vals := [.sym "bank"] }, { path := [.sym "cannibals"], vals := [.var "c"] }, { path := [.sym "missionaries"], vals := [.conj [.cmp ">" (.int (0)), .cmp "<" (.var "c")]] }]],
    acts := [.make (.var "s") [([.sym "failure"], [{ val := .var "ds" }])]] }

def r_mac_propose_move_boat_m0_c1 : Prod :=
  { name := "mac*propose*move-boat*m0*c1",
    doc := ["move-boat <from> <to> carrying 0 missionaries and 1 cannibals: the boat is at <from>, which has them."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "mac"] }, { path := [.sym "flags", .sym "mea-operator-selection"], vals := [.sym "true"] }, { path := [.sym "desireds", .sym "unachieved-desireds"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "from", .var "to"] }],
        .pos false (.var "from") [{ path := [.sym "type"], vals := [.sym "bank"] }, { path := [.sym "boat"], vals := [.int (1)] }, { path := [.sym "other-bank"], vals := [.var "th"] }, { path := [.sym "missionaries"], vals := [.cmp ">=" (.int (0))] }, { path := [.sym "cannibals"], vals := [.cmp ">=" (.int (1))] }],
        .pos false (.var "to") [{ path := [.sym "object-handle"], vals := [.lit (.var "th")] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "move-boat" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "action-handle"], [{ val := .sym "move-boat" }]), ([.sym "argument1"], [{ val := .var "from" }]), ([.sym "argument2"], [{ val := .var "to" }]), ([.sym "argument-count"], [{ val := .int (2) }]), ([.sym "missionaries"], [{ val := .int (0) }]), ([.sym "cannibals"], [{ val := .int (1) }]), ([.sym "desireds"], [{ val := .var "pre" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (0) }])]] }

def r_mac_propose_move_boat_m0_c2 : Prod :=
  { name := "mac*propose*move-boat*m0*c2",
    doc := ["move-boat <from> <to> carrying 0 missionaries and 2 cannibals: the boat is at <from>, which has them."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "mac"] }, { path := [.sym "flags", .sym "mea-operator-selection"], vals := [.sym "true"] }, { path := [.sym "desireds", .sym "unachieved-desireds"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "from", .var "to"] }],
        .pos false (.var "from") [{ path := [.sym "type"], vals := [.sym "bank"] }, { path := [.sym "boat"], vals := [.int (1)] }, { path := [.sym "other-bank"], vals := [.var "th"] }, { path := [.sym "missionaries"], vals := [.cmp ">=" (.int (0))] }, { path := [.sym "cannibals"], vals := [.cmp ">=" (.int (2))] }],
        .pos false (.var "to") [{ path := [.sym "object-handle"], vals := [.lit (.var "th")] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "move-boat" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "action-handle"], [{ val := .sym "move-boat" }]), ([.sym "argument1"], [{ val := .var "from" }]), ([.sym "argument2"], [{ val := .var "to" }]), ([.sym "argument-count"], [{ val := .int (2) }]), ([.sym "missionaries"], [{ val := .int (0) }]), ([.sym "cannibals"], [{ val := .int (2) }]), ([.sym "desireds"], [{ val := .var "pre" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (0) }])]] }

def r_mac_propose_move_boat_m1_c0 : Prod :=
  { name := "mac*propose*move-boat*m1*c0",
    doc := ["move-boat <from> <to> carrying 1 missionaries and 0 cannibals: the boat is at <from>, which has them."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "mac"] }, { path := [.sym "flags", .sym "mea-operator-selection"], vals := [.sym "true"] }, { path := [.sym "desireds", .sym "unachieved-desireds"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "from", .var "to"] }],
        .pos false (.var "from") [{ path := [.sym "type"], vals := [.sym "bank"] }, { path := [.sym "boat"], vals := [.int (1)] }, { path := [.sym "other-bank"], vals := [.var "th"] }, { path := [.sym "missionaries"], vals := [.cmp ">=" (.int (1))] }, { path := [.sym "cannibals"], vals := [.cmp ">=" (.int (0))] }],
        .pos false (.var "to") [{ path := [.sym "object-handle"], vals := [.lit (.var "th")] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "move-boat" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "action-handle"], [{ val := .sym "move-boat" }]), ([.sym "argument1"], [{ val := .var "from" }]), ([.sym "argument2"], [{ val := .var "to" }]), ([.sym "argument-count"], [{ val := .int (2) }]), ([.sym "missionaries"], [{ val := .int (1) }]), ([.sym "cannibals"], [{ val := .int (0) }]), ([.sym "desireds"], [{ val := .var "pre" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (0) }])]] }

def r_mac_propose_move_boat_m1_c1 : Prod :=
  { name := "mac*propose*move-boat*m1*c1",
    doc := ["move-boat <from> <to> carrying 1 missionaries and 1 cannibals: the boat is at <from>, which has them."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "mac"] }, { path := [.sym "flags", .sym "mea-operator-selection"], vals := [.sym "true"] }, { path := [.sym "desireds", .sym "unachieved-desireds"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "from", .var "to"] }],
        .pos false (.var "from") [{ path := [.sym "type"], vals := [.sym "bank"] }, { path := [.sym "boat"], vals := [.int (1)] }, { path := [.sym "other-bank"], vals := [.var "th"] }, { path := [.sym "missionaries"], vals := [.cmp ">=" (.int (1))] }, { path := [.sym "cannibals"], vals := [.cmp ">=" (.int (1))] }],
        .pos false (.var "to") [{ path := [.sym "object-handle"], vals := [.lit (.var "th")] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "move-boat" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "action-handle"], [{ val := .sym "move-boat" }]), ([.sym "argument1"], [{ val := .var "from" }]), ([.sym "argument2"], [{ val := .var "to" }]), ([.sym "argument-count"], [{ val := .int (2) }]), ([.sym "missionaries"], [{ val := .int (1) }]), ([.sym "cannibals"], [{ val := .int (1) }]), ([.sym "desireds"], [{ val := .var "pre" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (0) }])]] }

def r_mac_propose_move_boat_m2_c0 : Prod :=
  { name := "mac*propose*move-boat*m2*c0",
    doc := ["move-boat <from> <to> carrying 2 missionaries and 0 cannibals: the boat is at <from>, which has them."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "mac"] }, { path := [.sym "flags", .sym "mea-operator-selection"], vals := [.sym "true"] }, { path := [.sym "desireds", .sym "unachieved-desireds"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "from", .var "to"] }],
        .pos false (.var "from") [{ path := [.sym "type"], vals := [.sym "bank"] }, { path := [.sym "boat"], vals := [.int (1)] }, { path := [.sym "other-bank"], vals := [.var "th"] }, { path := [.sym "missionaries"], vals := [.cmp ">=" (.int (2))] }, { path := [.sym "cannibals"], vals := [.cmp ">=" (.int (0))] }],
        .pos false (.var "to") [{ path := [.sym "object-handle"], vals := [.lit (.var "th")] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "move-boat" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "action-handle"], [{ val := .sym "move-boat" }]), ([.sym "argument1"], [{ val := .var "from" }]), ([.sym "argument2"], [{ val := .var "to" }]), ([.sym "argument-count"], [{ val := .int (2) }]), ([.sym "missionaries"], [{ val := .int (2) }]), ([.sym "cannibals"], [{ val := .int (0) }]), ([.sym "desireds"], [{ val := .var "pre" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (0) }])]] }

def r_mac_apply_move_boat_internal : Prod :=
  { name := "mac*apply*move-boat*internal",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "mac"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "internal-actions"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "move-boat"] }, { path := [.sym "pre-conditions-satisfied"], vals := [.sym "true"] }, { path := [.sym "argument1", .sym "object-handle"], vals := [.lit (.var "fh")] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.lit (.var "th")] }, { path := [.sym "missionaries"], vals := [.var "m"] }, { path := [.sym "cannibals"], vals := [.var "c"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "from", .var "to"] }],
        .pos false (.var "from") [{ path := [.sym "object-handle"], vals := [.lit (.var "fh")] }, { path := [.sym "missionaries"], vals := [.var "fm"] }, { path := [.sym "cannibals"], vals := [.var "fc"] }, { path := [.sym "boat"], vals := [.var "fb"] }],
        .pos false (.var "to") [{ path := [.sym "object-handle"], vals := [.lit (.var "th")] }, { path := [.sym "missionaries"], vals := [.var "tm"] }, { path := [.sym "cannibals"], vals := [.var "tc"] }, { path := [.sym "boat"], vals := [.var "tb"] }]],
    acts := [.call "log" [.int (1), .fn "crlf" [], .str "Move boat ", .var "fh", .str " -> ", .var "th", .str ": ", .var "m", .str " M, ", .var "c", .str " C"],
        .make (.var "from") [([.sym "missionaries"], [{ val := .var "fm", pref := "-" }, { val := .fn "-" [.var "fm", .var "m"] }]), ([.sym "cannibals"], [{ val := .var "fc", pref := "-" }, { val := .fn "-" [.var "fc", .var "c"] }]), ([.sym "boat"], [{ val := .var "fb", pref := "-" }, { val := .int (0) }])],
        .make (.var "to") [([.sym "missionaries"], [{ val := .var "tm", pref := "-" }, { val := .fn "+" [.var "tm", .var "m"] }]), ([.sym "cannibals"], [{ val := .var "tc", pref := "-" }, { val := .fn "+" [.var "tc", .var "c"] }]), ([.sym "boat"], [{ val := .var "tb", pref := "-" }, { val := .int (1) }])]] }

def r_mac_elaborate_look_ahead_duplicate : Prod :=
  { name := "mac*elaborate*look-ahead*duplicate",
    doc := ["Look-ahead: a state equal to an ancestor task state (both banks) is a failure (original", "mac*evaluate*state*failure*duplicate)."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "mac"] }, { path := [.sym "tried-tied-operator"], vals := [.var "any"] }, { path := [.sym "desireds"], vals := [.var "ds"] }, { path := [.sym "world"], vals := [.var "w"] }, { path := [.sym "ancestor-world"], vals := [.var "aw"] }],
        .pos false (.var "w") [{ path := [.sym "objects", .sym "object"], vals := [.var "l", .var "r"] }],
        .pos false (.var "l") [{ path := [.sym "object-handle"], vals := [.lit (.sym "left")] }, { path := [.sym "missionaries"], vals := [.var "lm"] }, { path := [.sym "cannibals"], vals := [.var "lc"] }, { path := [.sym "boat"], vals := [.var "lb"] }],
        .pos false (.var "r") [{ path := [.sym "object-handle"], vals := [.lit (.sym "right")] }, { path := [.sym "missionaries"], vals := [.var "rm"] }, { path := [.sym "cannibals"], vals := [.var "rc"] }],
        .pos false (.var "aw") [{ path := [.sym "objects", .sym "object"], vals := [.var "al", .var "ar"] }],
        .pos false (.var "al") [{ path := [.sym "object-handle"], vals := [.lit (.sym "left")] }, { path := [.sym "missionaries"], vals := [.var "lm"] }, { path := [.sym "cannibals"], vals := [.var "lc"] }, { path := [.sym "boat"], vals := [.var "lb"] }],
        .pos false (.var "ar") [{ path := [.sym "object-handle"], vals := [.lit (.sym "right")] }, { path := [.sym "missionaries"], vals := [.var "rm"] }, { path := [.sym "cannibals"], vals := [.var "rc"] }]],
    acts := [.make (.var "s") [([.sym "failure"], [{ val := .var "ds" }])]] }

def r_mac_elaborate_look_ahead_numeric_value : Prod :=
  { name := "mac*elaborate*look-ahead*numeric-value",
    doc := ["Numeric evaluation of a look-ahead state (W-LAH-006): the number of people on the right bank;", "the goal set declares ^better higher (W-DES-018)."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "mac"] }, { path := [.sym "tried-tied-operator"], vals := [.var "any"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "objects", .sym "object"], vals := [.var "r"] }],
        .pos false (.var "r") [{ path := [.sym "object-handle"], vals := [.lit (.sym "right")] }, { path := [.sym "missionaries"], vals := [.var "m"] }, { path := [.sym "cannibals"], vals := [.var "c"] }]],
    acts := [.make (.var "s") [([.sym "numeric-value"], [{ val := .fn "+" [.var "m", .var "c"] }])]] }

def r_mac_rl_move_boat : Prod :=
  { name := "mac*rl*move-boat",
    doc := ["RL template over the move and both banks (RL-007; STA-029: other-bank, which never changes, left out)."],
    flags := [":template"],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "mac"] }, { path := [.sym "operator"], vals := [.var "o", .sym "+"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "move-boat"] }, { path := [.sym "argument1"], vals := [.var "from"] }, { path := [.sym "argument2"], vals := [.var "to"] }, { path := [.sym "missionaries"], vals := [.var "m"] }, { path := [.sym "cannibals"], vals := [.var "c"] }],
        .pos false (.var "from") [{ path := [.sym "object-handle"], vals := [.var "fh"] }, { path := [.sym "missionaries"], vals := [.var "fm"] }, { path := [.sym "cannibals"], vals := [.var "fc"] }, { path := [.sym "boat"], vals := [.var "fb"] }],
        .pos false (.var "to") [{ path := [.sym "object-handle"], vals := [.var "th"] }, { path := [.sym "missionaries"], vals := [.var "tm"] }, { path := [.sym "cannibals"], vals := [.var "tc"] }, { path := [.sym "boat"], vals := [.var "tb"] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "= 0" }])]] }

def r_mac_elaborate_reward_failure : Prod :=
  { name := "mac*elaborate*reward*failure",
    doc := ["Elaborate reward failure in problem space mac: adds ^reward, ^value."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "mac"] }, { path := [.sym "reward-link"], vals := [.var "r"] }, { path := [.sym "failure"], vals := [.var "any"] }]],
    acts := [.make (.var "r") [([.sym "reward"], [{ val := .var "rw" }])],
        .make (.var "rw") [([.sym "value"], [{ val := .int (-1) }])]] }

def r_mac_elaborate_reward_success : Prod :=
  { name := "mac*elaborate*reward*success",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "mac"] }, { path := [.sym "reward-link"], vals := [.var "r"] }, { path := [.sym "success"], vals := [.var "any"] }]],
    acts := [.make (.var "r") [([.sym "reward"], [{ val := .var "rw" }])],
        .make (.var "rw") [([.sym "value"], [{ val := .int (1) }])]] }

def r_mac_elaborate_reward_step : Prod :=
  { name := "mac*elaborate*reward*step",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "mac"] }, { path := [.sym "reward-link"], vals := [.var "r"] }]],
    acts := [.make (.var "r") [([.sym "reward"], [{ val := .var "rw" }])],
        .make (.var "rw") [([.sym "value"], [{ val := .flt "-0.01" }])]] }

def v_mac : Variant :=
  { family := "missionaries-cannibals", name := "mac",
    about := ["Missionaries and cannibals (3 and 3), random choice of crossings; an outnumbered bank is a failure."],
    firstload := ["chunk never"],
    task := { name := "mac", psExtra := [], flags := [("mea-operator-selection", .sym "true")], environmentNone := true,
              initBody := [.make (.var "objs") [([.sym "object"], [{ val := .var "l" }, { val := .var "r" }])],
      .make (.var "l") [([.sym "object-handle"], [{ val := .sym "left" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "bank" }]), ([.sym "missionaries"], [{ val := .int (3) }]), ([.sym "cannibals"], [{ val := .int (3) }]), ([.sym "boat"], [{ val := .int (1) }]), ([.sym "other-bank"], [{ val := .sym "right" }])],
      .make (.var "r") [([.sym "object-handle"], [{ val := .sym "right" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "bank" }]), ([.sym "missionaries"], [{ val := .int (0) }]), ([.sym "cannibals"], [{ val := .int (0) }]), ([.sym "boat"], [{ val := .int (0) }]), ([.sym "other-bank"], [{ val := .sym "left" }])],
      .make (.var "ds") [([.sym "desired-count"], [{ val := .int (2) }]), ([.sym "desired"], [{ val := .var "d1" }, { val := .var "d2" }])],
      .make (.var "d1") [([.sym "object"], [{ val := .var "d1o" }])],
      .make (.var "d1o") [([.sym "object-handle"], [{ val := .sym "right" }]), ([.sym "missionaries"], [{ val := .int (3) }])],
      .make (.var "d2") [([.sym "object"], [{ val := .var "d2o" }])],
      .make (.var "d2o") [([.sym "object-handle"], [{ val := .sym "right" }]), ([.sym "cannibals"], [{ val := .int (3) }])]],
              initFile := none, initOpExtra := [], achieve := [.objectState], achieveSpaces := [], indifferent := some "the original selects among its task operators at random", indifferentExcept := [], ancestors := false },
    files := [("elaborations.soar", [.ps, .achieve .objectState, .p r_mac_elaborate_failure_outnumbered]),
              ("initialize-mac.soar", [.init]),
              ("move-boat.soar", [.p r_mac_propose_move_boat_m0_c1, .p r_mac_propose_move_boat_m0_c2, .p r_mac_propose_move_boat_m1_c0, .p r_mac_propose_move_boat_m1_c1, .p r_mac_propose_move_boat_m2_c0, .p r_mac_apply_move_boat_internal]),
              ("search-control.soar", [.indifferent])] }

def v_mac_look_ahead : Variant :=
  { family := "missionaries-cannibals", name := "mac-look-ahead",
    about := ["Missionaries and cannibals by look-ahead; repeated states and outnumbered banks are failures."],
    firstload := ["chunk always", "chunk add-osk on"],
    task := { name := "mac", psExtra := [], flags := [("mea-operator-selection", .sym "true")], environmentNone := true,
              initBody := [.make (.var "objs") [([.sym "object"], [{ val := .var "l" }, { val := .var "r" }])],
      .make (.var "l") [([.sym "object-handle"], [{ val := .sym "left" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "bank" }]), ([.sym "missionaries"], [{ val := .int (3) }]), ([.sym "cannibals"], [{ val := .int (3) }]), ([.sym "boat"], [{ val := .int (1) }]), ([.sym "other-bank"], [{ val := .sym "right" }])],
      .make (.var "r") [([.sym "object-handle"], [{ val := .sym "right" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "bank" }]), ([.sym "missionaries"], [{ val := .int (0) }]), ([.sym "cannibals"], [{ val := .int (0) }]), ([.sym "boat"], [{ val := .int (0) }]), ([.sym "other-bank"], [{ val := .sym "left" }])],
      .make (.var "ds") [([.sym "desired-count"], [{ val := .int (2) }]), ([.sym "desired"], [{ val := .var "d1" }, { val := .var "d2" }])],
      .make (.var "d1") [([.sym "object"], [{ val := .var "d1o" }])],
      .make (.var "d1o") [([.sym "object-handle"], [{ val := .sym "right" }]), ([.sym "missionaries"], [{ val := .int (3) }])],
      .make (.var "d2") [([.sym "object"], [{ val := .var "d2o" }])],
      .make (.var "d2o") [([.sym "object-handle"], [{ val := .sym "right" }]), ([.sym "cannibals"], [{ val := .int (3) }])]],
              initFile := none, initOpExtra := [], achieve := [.objectState], achieveSpaces := [], indifferent := none, indifferentExcept := [], ancestors := true },
    files := [("elaborations.soar", [.ps, .achieve .objectState, .p r_mac_elaborate_failure_outnumbered, .ancestors]),
              ("initialize-mac.soar", [.init]),
              ("move-boat.soar", [.p r_mac_propose_move_boat_m0_c1, .p r_mac_propose_move_boat_m0_c2, .p r_mac_propose_move_boat_m1_c0, .p r_mac_propose_move_boat_m1_c1, .p r_mac_propose_move_boat_m2_c0, .p r_mac_apply_move_boat_internal]),
              ("state-evaluation.soar", [.p r_mac_elaborate_look_ahead_duplicate])] }

def v_mac_look_ahead_numeric : Variant :=
  { family := "missionaries-cannibals", name := "mac-look-ahead-numeric",
    about := ["Missionaries and cannibals by look-ahead with a numeric evaluation: people on the right bank (higher is better)."],
    firstload := ["chunk always", "chunk add-osk on"],
    task := { name := "mac", psExtra := [], flags := [("mea-operator-selection", .sym "true")], environmentNone := true,
              initBody := [.make (.var "objs") [([.sym "object"], [{ val := .var "l" }, { val := .var "r" }])],
      .make (.var "l") [([.sym "object-handle"], [{ val := .sym "left" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "bank" }]), ([.sym "missionaries"], [{ val := .int (3) }]), ([.sym "cannibals"], [{ val := .int (3) }]), ([.sym "boat"], [{ val := .int (1) }]), ([.sym "other-bank"], [{ val := .sym "right" }])],
      .make (.var "r") [([.sym "object-handle"], [{ val := .sym "right" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "bank" }]), ([.sym "missionaries"], [{ val := .int (0) }]), ([.sym "cannibals"], [{ val := .int (0) }]), ([.sym "boat"], [{ val := .int (0) }]), ([.sym "other-bank"], [{ val := .sym "left" }])],
      .make (.var "ds") [([.sym "desired-count"], [{ val := .int (2) }]), ([.sym "desired"], [{ val := .var "d1" }, { val := .var "d2" }]), ([.sym "better"], [{ val := .sym "higher" }])],
      .make (.var "d1") [([.sym "object"], [{ val := .var "d1o" }])],
      .make (.var "d1o") [([.sym "object-handle"], [{ val := .sym "right" }]), ([.sym "missionaries"], [{ val := .int (3) }])],
      .make (.var "d2") [([.sym "object"], [{ val := .var "d2o" }])],
      .make (.var "d2o") [([.sym "object-handle"], [{ val := .sym "right" }]), ([.sym "cannibals"], [{ val := .int (3) }])]],
              initFile := none, initOpExtra := [], achieve := [.objectState], achieveSpaces := [], indifferent := none, indifferentExcept := [], ancestors := true },
    files := [("elaborations.soar", [.ps, .achieve .objectState, .p r_mac_elaborate_failure_outnumbered, .ancestors]),
              ("initialize-mac.soar", [.init]),
              ("move-boat.soar", [.p r_mac_propose_move_boat_m0_c1, .p r_mac_propose_move_boat_m0_c2, .p r_mac_propose_move_boat_m1_c0, .p r_mac_propose_move_boat_m1_c1, .p r_mac_propose_move_boat_m2_c0, .p r_mac_apply_move_boat_internal]),
              ("state-evaluation.soar", [.p r_mac_elaborate_look_ahead_duplicate, .p r_mac_elaborate_look_ahead_numeric_value])] }

def v_mac_rl : Variant :=
  { family := "missionaries-cannibals", name := "mac-rl",
    about := ["Missionaries and cannibals with RL over both banks (templates); reward -1 failure, +1 success, -0.01 per step."],
    firstload := ["chunk never", "rl --set learning on", "rl --set learning-rate 0.100000", "rl --set discount-rate 0.500000", "indifferent-selection --epsilon-greedy"],
    task := { name := "mac", psExtra := [], flags := [("mea-operator-selection", .sym "true")], environmentNone := true,
              initBody := [.make (.var "objs") [([.sym "object"], [{ val := .var "l" }, { val := .var "r" }])],
      .make (.var "l") [([.sym "object-handle"], [{ val := .sym "left" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "bank" }]), ([.sym "missionaries"], [{ val := .int (3) }]), ([.sym "cannibals"], [{ val := .int (3) }]), ([.sym "boat"], [{ val := .int (1) }]), ([.sym "other-bank"], [{ val := .sym "right" }])],
      .make (.var "r") [([.sym "object-handle"], [{ val := .sym "right" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "bank" }]), ([.sym "missionaries"], [{ val := .int (0) }]), ([.sym "cannibals"], [{ val := .int (0) }]), ([.sym "boat"], [{ val := .int (0) }]), ([.sym "other-bank"], [{ val := .sym "left" }])],
      .make (.var "ds") [([.sym "desired-count"], [{ val := .int (2) }]), ([.sym "desired"], [{ val := .var "d1" }, { val := .var "d2" }])],
      .make (.var "d1") [([.sym "object"], [{ val := .var "d1o" }])],
      .make (.var "d1o") [([.sym "object-handle"], [{ val := .sym "right" }]), ([.sym "missionaries"], [{ val := .int (3) }])],
      .make (.var "d2") [([.sym "object"], [{ val := .var "d2o" }])],
      .make (.var "d2o") [([.sym "object-handle"], [{ val := .sym "right" }]), ([.sym "cannibals"], [{ val := .int (3) }])]],
              initFile := none, initOpExtra := [], achieve := [.objectState], achieveSpaces := [], indifferent := some "the original chooses by RL values among indifferent operators", indifferentExcept := [], ancestors := false },
    files := [("elaborations.soar", [.ps, .achieve .objectState, .p r_mac_elaborate_failure_outnumbered]),
              ("initialize-mac.soar", [.init]),
              ("move-boat.soar", [.p r_mac_propose_move_boat_m0_c1, .p r_mac_propose_move_boat_m0_c2, .p r_mac_propose_move_boat_m1_c0, .p r_mac_propose_move_boat_m1_c1, .p r_mac_propose_move_boat_m2_c0, .p r_mac_apply_move_boat_internal]),
              ("rl.soar", [.p r_mac_rl_move_boat, .p r_mac_elaborate_reward_failure, .p r_mac_elaborate_reward_success, .p r_mac_elaborate_reward_step]),
              ("search-control.soar", [.indifferent])] }

def variants : List Variant := [v_mac, v_mac_look_ahead, v_mac_look_ahead_numeric, v_mac_rl]

end Fam.Families.MissionariesCannibals
