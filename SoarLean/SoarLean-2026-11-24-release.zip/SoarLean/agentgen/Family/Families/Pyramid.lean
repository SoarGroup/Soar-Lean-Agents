import Family.Task
set_option maxHeartbeats 0
set_option maxRecDepth 100000
/-!
# pyramid: world-convention agents of the pyramid family

Typed description migrated on 19 November 2026 from the world-v6 agents (Tasks/Families/pyramid/world-v6),
which were written from the original programs. Task-level parts are `Task` fields; family knowledge is typed
productions, defined once and shared by the variants that use them.

Written 19 November 2026 by Claude, supervised by John E. Laird.
-/
namespace Fam.Families.Pyramid
open Fam

def r_pyramid_propose_add_next_term : Prod :=
  { name := "pyramid*propose*add-next-term",
    doc := ["add-next-term <pyramid>: sum := sum + term; term := term - 1; height := height - 1."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "pyramid"] }, { path := [.sym "flags", .sym "mea-operator-selection"], vals := [.sym "true"] }, { path := [.sym "desireds", .sym "unachieved-desireds"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "py"] }],
        .pos false (.var "py") [{ path := [.sym "type"], vals := [.sym "pyramid"] }, { path := [.sym "height"], vals := [.cmp ">=" (.int (0))] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "add-next-term" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "action-handle"], [{ val := .sym "add-next-term" }]), ([.sym "argument1"], [{ val := .var "py" }]), ([.sym "argument-count"], [{ val := .int (1) }]), ([.sym "desireds"], [{ val := .var "pre" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (0) }])]] }

def r_pyramid_apply_add_next_term_internal : Prod :=
  { name := "pyramid*apply*add-next-term*internal",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "pyramid"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "internal-actions"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "add-next-term"] }, { path := [.sym "pre-conditions-satisfied"], vals := [.sym "true"] }, { path := [.sym "argument1", .sym "object-handle"], vals := [.lit (.var "h")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "py"] }],
        .pos false (.var "py") [{ path := [.sym "object-handle"], vals := [.lit (.var "h")] }, { path := [.sym "sum"], vals := [.var "sum"] }, { path := [.sym "term"], vals := [.var "t"] }, { path := [.sym "height"], vals := [.var "ht"] }]],
    acts := [.call "log" [.int (1), .fn "crlf" [], .str " + ", .var "t"],
        .make (.var "py") [([.sym "sum"], [{ val := .var "sum", pref := "-" }, { val := .fn "+" [.var "sum", .var "t"] }]), ([.sym "term"], [{ val := .var "t", pref := "-" }, { val := .fn "-" [.var "t", .int (1)] }]), ([.sym "height"], [{ val := .var "ht", pref := "-" }, { val := .fn "-" [.var "ht", .int (1)] }])]] }

def r_pyramid_elaborate_answer : Prod :=
  { name := "pyramid*elaborate*answer",
    doc := ["Report the answer when the goal is reached (a monitoring rule)."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "pyramid"] }, { path := [.sym "superstate"], vals := [.sym "nil"] }, { path := [.sym "success"], vals := [.var "ds"] }, { path := [.sym "desireds"], vals := [.var "ds"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "py"] }],
        .pos false (.var "py") [{ path := [.sym "type"], vals := [.sym "pyramid"] }, { path := [.sym "sum"], vals := [.var "sum"] }]],
    acts := [.call "write" [.fn "crlf" [], .str "The answer is ", .var "sum", .str "."]] }

def r_pyramid_elaborate_expand_pyramid_relevant : Prod :=
  { name := "pyramid*elaborate*expand-pyramid-relevant",
    doc := ["expand-pyramid <pyramid> (composite, W-COP-002): effect: height -1 (every term written).", "As in the original, relevance is a state elaboration, so the operator persists while height changes."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "pyramid"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "py"] }],
        .pos false (.var "py") [{ path := [.sym "type"], vals := [.sym "pyramid"] }, { path := [.sym "height"], vals := [.cmp ">=" (.int (0))] }]],
    acts := [.make (.var "s") [([.sym "expand-pyramid-relevant"], [{ val := .var "py" }])]] }

def r_pyramid_propose_expand_pyramid : Prod :=
  { name := "pyramid*propose*expand-pyramid",
    doc := ["Propose expand-pyramid in problem space pyramid when its conditions below hold."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "pyramid"] }, { path := [.sym "flags", .sym "mea-operator-selection"], vals := [.sym "true"] }, { path := [.sym "desireds", .sym "unachieved-desireds"], vals := [.sym "true"] }, { path := [.sym "expand-pyramid-relevant"], vals := [.var "py"] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "expand-pyramid" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "argument1"], [{ val := .var "py" }]), ([.sym "argument-count"], [{ val := .int (1) }]), ([.sym "desireds"], [{ val := .var "pre" }]), ([.sym "effect-desireds"], [{ val := .var "ed" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (0) }])],
        .make (.var "ed") [([.sym "desired-count"], [{ val := .int (1) }]), ([.sym "desired"], [{ val := .var "e1" }])],
        .make (.var "e1") [([.sym "object"], [{ val := .var "e1o" }])],
        .make (.var "e1o") [([.sym "object-handle"], [{ val := .sym "pyramid" }]), ([.sym "height"], [{ val := .int (-1) }])]] }

def r_pyramid_propose_expand_next_term : Prod :=
  { name := "pyramid*propose*expand-next-term",
    doc := ["expand-next-term: a new term object (handle term-<index>) in the world; term, height and the count move on."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "expand-pyramid"] }, { path := [.sym "argument1"], vals := [.var "py"] }],
        .pos false (.var "py") [{ path := [.sym "height"], vals := [.cmp ">=" (.int (0))] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+ =" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "expand-next-term" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "action-handle"], [{ val := .sym "expand-next-term" }]), ([.sym "argument1"], [{ val := .var "py" }]), ([.sym "argument-count"], [{ val := .int (1) }]), ([.sym "desireds"], [{ val := .var "pre" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (0) }])]] }

def r_pyramid_apply_expand_next_term_internal : Prod :=
  { name := "pyramid*apply*expand-next-term*internal",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "expand-pyramid"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "internal-actions"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "expand-next-term"] }, { path := [.sym "pre-conditions-satisfied"], vals := [.sym "true"] }, { path := [.sym "argument1", .sym "object-handle"], vals := [.lit (.var "h")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects"], vals := [.var "objs"] }],
        .pos false (.var "objs") [{ path := [.sym "object"], vals := [.var "py"] }],
        .pos false (.var "py") [{ path := [.sym "object-handle"], vals := [.lit (.var "h")] }, { path := [.sym "terms"], vals := [.var "n"] }, { path := [.sym "term"], vals := [.var "t"] }, { path := [.sym "height"], vals := [.var "ht"] }]],
    acts := [.call "log" [.int (1), .fn "crlf" [], .str " + ", .var "t"],
        .make (.var "objs") [([.sym "object"], [{ val := .var "new" }])],
        .make (.var "new") [([.sym "object-handle"], [{ val := .fn "concat" [.sym "term-", .var "n"] }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "term" }]), ([.sym "index"], [{ val := .var "n" }]), ([.sym "value"], [{ val := .var "t" }])],
        .make (.var "py") [([.sym "terms"], [{ val := .var "n", pref := "-" }, { val := .fn "+" [.var "n", .int (1)] }]), ([.sym "term"], [{ val := .var "t", pref := "-" }, { val := .fn "-" [.var "t", .int (1)] }]), ([.sym "height"], [{ val := .var "ht", pref := "-" }, { val := .fn "-" [.var "ht", .int (1)] }])]] }

def r_pyramid_propose_sum_terms : Prod :=
  { name := "pyramid*propose*sum-terms",
    doc := ["sum-terms <pyramid> (composite): when every term is written; effect: summed 1."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "pyramid"] }, { path := [.sym "flags", .sym "mea-operator-selection"], vals := [.sym "true"] }, { path := [.sym "desireds", .sym "unachieved-desireds"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "py"] }],
        .pos false (.var "py") [{ path := [.sym "type"], vals := [.sym "pyramid"] }, { path := [.sym "height"], vals := [.int (-1)] }, { path := [.sym "summed"], vals := [.int (0)] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "sum-terms" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "argument1"], [{ val := .var "py" }]), ([.sym "argument-count"], [{ val := .int (1) }]), ([.sym "desireds"], [{ val := .var "pre" }]), ([.sym "effect-desireds"], [{ val := .var "ed" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (0) }])],
        .make (.var "ed") [([.sym "desired-count"], [{ val := .int (1) }]), ([.sym "desired"], [{ val := .var "e1" }])],
        .make (.var "e1") [([.sym "object"], [{ val := .var "e1o" }])],
        .make (.var "e1o") [([.sym "object-handle"], [{ val := .sym "pyramid" }]), ([.sym "summed"], [{ val := .int (1) }])]] }

def r_pyramid_propose_init_local : Prod :=
  { name := "pyramid*propose*init-local",
    doc := ["init-local, add-term: a running sum and the next index on the substate (internal operators, W-NOP-001)."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "sum-terms"] }, { path := [.sym "sum"], vals := [], neg := true }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+ >" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "init-local" }]), ([.sym "task-operator"], [{ val := .sym "false" }])]] }

def r_pyramid_apply_init_local : Prod :=
  { name := "pyramid*apply*init-local",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "sum-terms"] }, { path := [.sym "operator", .sym "name"], vals := [.sym "init-local"] }]],
    acts := [.call "log" [.int (1), .fn "crlf" [], .str "Apply init-local."],
        .make (.var "s") [([.sym "sum"], [{ val := .int (0) }]), ([.sym "next"], [{ val := .int (0) }])]] }

def r_pyramid_propose_add_term : Prod :=
  { name := "pyramid*propose*add-term",
    doc := ["Propose add-term in problem space sum-terms when its conditions below hold."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "sum-terms"] }, { path := [.sym "sum"], vals := [.var "any"] }, { path := [.sym "next"], vals := [.var "i"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "t"] }],
        .pos false (.var "t") [{ path := [.sym "type"], vals := [.sym "term"] }, { path := [.sym "index"], vals := [.var "i"] }, { path := [.sym "value"], vals := [.var "v"] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+ =" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "add-term" }]), ([.sym "task-operator"], [{ val := .sym "false" }]), ([.sym "term-value"], [{ val := .var "v" }])]] }

def r_pyramid_apply_add_term : Prod :=
  { name := "pyramid*apply*add-term",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "sum-terms"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "sum"], vals := [.var "sum"] }, { path := [.sym "next"], vals := [.var "i"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "add-term"] }, { path := [.sym "term-value"], vals := [.var "v"] }]],
    acts := [.call "log" [.int (1), .fn "crlf" [], .str "Apply add-term: ", .var "v"],
        .make (.var "s") [([.sym "sum"], [{ val := .var "sum", pref := "-" }, { val := .fn "+" [.var "sum", .var "v"] }]), ([.sym "next"], [{ val := .var "i", pref := "-" }, { val := .fn "+" [.var "i", .int (1)] }])]] }

def r_pyramid_propose_final_sum : Prod :=
  { name := "pyramid*propose*final-sum",
    doc := ["final-sum <pyramid>: write the sum to the pyramid (task-action operator)."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "sum-terms"] }, { path := [.sym "argument1"], vals := [.var "py"] }, { path := [.sym "sum"], vals := [.var "any"] }, { path := [.sym "next"], vals := [.var "n"] }],
        .pos false (.var "py") [{ path := [.sym "terms"], vals := [.var "n"] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+ =" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "final-sum" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "action-handle"], [{ val := .sym "final-sum" }]), ([.sym "argument1"], [{ val := .var "py" }]), ([.sym "argument-count"], [{ val := .int (1) }]), ([.sym "desireds"], [{ val := .var "pre" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (0) }])]] }

def r_pyramid_apply_final_sum_internal : Prod :=
  { name := "pyramid*apply*final-sum*internal",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "sum-terms"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "internal-actions"], vals := [.sym "true"] }, { path := [.sym "sum"], vals := [.var "sum"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "final-sum"] }, { path := [.sym "pre-conditions-satisfied"], vals := [.sym "true"] }, { path := [.sym "argument1", .sym "object-handle"], vals := [.lit (.var "h")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "py"] }],
        .pos false (.var "py") [{ path := [.sym "object-handle"], vals := [.lit (.var "h")] }, { path := [.sym "sum"], vals := [.var "old"] }, { path := [.sym "summed"], vals := [.var "sd"] }]],
    acts := [.call "log" [.int (1), .fn "crlf" [], .str "Apply final-sum: ", .var "sum"],
        .make (.var "py") [([.sym "sum"], [{ val := .var "old", pref := "-" }, { val := .var "sum" }]), ([.sym "summed"], [{ val := .var "sd", pref := "-" }, { val := .int (1) }])]] }

def v_pyramid : Variant :=
  { family := "pyramid", name := "pyramid",
    about := ["Pyramid sum: add the terms 5, 4, 3, ... (11 terms, height 10) one at a time."],
    firstload := ["chunk never"],
    task := { name := "pyramid", psExtra := [], flags := [("mea-operator-selection", .sym "true")], environmentNone := true,
              initBody := [.make (.var "objs") [([.sym "object"], [{ val := .var "py" }])],
      .make (.var "py") [([.sym "object-handle"], [{ val := .sym "pyramid" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "pyramid" }]), ([.sym "term"], [{ val := .int (5) }]), ([.sym "height"], [{ val := .int (10) }]), ([.sym "sum"], [{ val := .int (0) }])],
      .make (.var "ds") [([.sym "desired-count"], [{ val := .int (1) }]), ([.sym "desired"], [{ val := .var "d1" }])],
      .make (.var "d1") [([.sym "object"], [{ val := .var "d1o" }])],
      .make (.var "d1o") [([.sym "object-handle"], [{ val := .sym "pyramid" }]), ([.sym "height"], [{ val := .int (-1) }])]],
              initFile := none, initOpExtra := [], achieve := [.objectState], achieveSpaces := [], indifferent := none, indifferentExcept := [], ancestors := false },
    files := [("elaborations.soar", [.ps, .achieve .objectState]),
              ("initialize-pyramid.soar", [.init]),
              ("add-next-term.soar", [.p r_pyramid_propose_add_next_term, .p r_pyramid_apply_add_next_term_internal, .p r_pyramid_elaborate_answer])] }

def v_pyramid_anderson : Variant :=
  { family := "pyramid", name := "pyramid-anderson",
    about := ["Pyramid sum: add the terms 5, 4, 3, ... (3 terms, height 2) one at a time."],
    firstload := ["chunk never"],
    task := { name := "pyramid", psExtra := [], flags := [("mea-operator-selection", .sym "true")], environmentNone := true,
              initBody := [.make (.var "objs") [([.sym "object"], [{ val := .var "py" }])],
      .make (.var "py") [([.sym "object-handle"], [{ val := .sym "pyramid" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "pyramid" }]), ([.sym "term"], [{ val := .int (5) }]), ([.sym "height"], [{ val := .int (2) }]), ([.sym "sum"], [{ val := .int (0) }])],
      .make (.var "ds") [([.sym "desired-count"], [{ val := .int (1) }]), ([.sym "desired"], [{ val := .var "d1" }])],
      .make (.var "d1") [([.sym "object"], [{ val := .var "d1o" }])],
      .make (.var "d1o") [([.sym "object-handle"], [{ val := .sym "pyramid" }]), ([.sym "height"], [{ val := .int (-1) }])]],
              initFile := none, initOpExtra := [], achieve := [.objectState], achieveSpaces := [], indifferent := none, indifferentExcept := [], ancestors := false },
    files := [("elaborations.soar", [.ps, .achieve .objectState]),
              ("initialize-pyramid.soar", [.init]),
              ("add-next-term.soar", [.p r_pyramid_propose_add_next_term, .p r_pyramid_apply_add_next_term_internal, .p r_pyramid_elaborate_answer])] }

def v_pyramid_hierarchical : Variant :=
  { family := "pyramid", name := "pyramid-hierarchical",
    about := ["Pyramid sum in two composite steps: expand-pyramid writes the terms 10, 9, ... (7 terms) as world objects; sum-terms adds them."],
    firstload := ["chunk never"],
    task := { name := "pyramid", psExtra := [], flags := [("mea-operator-selection", .sym "true")], environmentNone := true,
              initBody := [.make (.var "objs") [([.sym "object"], [{ val := .var "py" }])],
      .make (.var "py") [([.sym "object-handle"], [{ val := .sym "pyramid" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "pyramid" }]), ([.sym "term"], [{ val := .int (10) }]), ([.sym "height"], [{ val := .int (6) }]), ([.sym "terms"], [{ val := .int (0) }]), ([.sym "sum"], [{ val := .int (0) }]), ([.sym "summed"], [{ val := .int (0) }])],
      .make (.var "ds") [([.sym "desired-count"], [{ val := .int (1) }]), ([.sym "desired"], [{ val := .var "d1" }])],
      .make (.var "d1") [([.sym "object"], [{ val := .var "d1o" }])],
      .make (.var "d1o") [([.sym "object-handle"], [{ val := .sym "pyramid" }]), ([.sym "summed"], [{ val := .int (1) }])]],
              initFile := none, initOpExtra := [], achieve := [.objectState], achieveSpaces := [], indifferent := none, indifferentExcept := [], ancestors := false },
    files := [("elaborations.soar", [.ps, .achieve .objectState]),
              ("initialize-pyramid.soar", [.init]),
              ("expand-pyramid.soar", [.p r_pyramid_elaborate_expand_pyramid_relevant, .p r_pyramid_propose_expand_pyramid, .p r_pyramid_propose_expand_next_term, .p r_pyramid_apply_expand_next_term_internal]),
              ("sum-terms.soar", [.p r_pyramid_propose_sum_terms, .p r_pyramid_propose_init_local, .p r_pyramid_apply_init_local, .p r_pyramid_propose_add_term, .p r_pyramid_apply_add_term, .p r_pyramid_propose_final_sum, .p r_pyramid_apply_final_sum_internal, .p r_pyramid_elaborate_answer])] }

def variants : List Variant := [v_pyramid, v_pyramid_anderson, v_pyramid_hierarchical]

end Fam.Families.Pyramid
