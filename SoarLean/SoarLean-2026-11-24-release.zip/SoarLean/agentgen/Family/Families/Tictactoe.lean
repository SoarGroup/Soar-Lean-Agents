import Family.Task
set_option maxHeartbeats 0
set_option maxRecDepth 100000
/-!
# tictactoe: world-convention agents of the tictactoe family

Typed description migrated on 19 November 2026 from the world-v6 agents (Tasks/Families/tictactoe/world-v6),
which were written from the original programs. Task-level parts are `Task` fields; family knowledge is typed
productions, defined once and shared by the variants that use them.

Written 19 November 2026 by Claude, supervised by John E. Laird.
-/
namespace Fam.Families.Tictactoe
open Fam

def r_tictactoe_propose_mark : Prod :=
  { name := "tictactoe*propose*mark",
    doc := ["Cells and lines are world objects; in-line relations say which cells make up each line (W-REL-001).", "mark <cell>: the side to move marks an empty cell (content 1 = X, 2 = O)."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "tictactoe"] }, { path := [.sym "flags", .sym "mea-operator-selection"], vals := [.sym "true"] }, { path := [.sym "desireds", .sym "unachieved-desireds"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "g"] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "game"] }, { path := [.sym "over"], vals := [.int (0)] }],
        .pos false (.var "w") [{ path := [.sym "objects", .sym "object"], vals := [.var "c"] }],
        .pos false (.var "c") [{ path := [.sym "type"], vals := [.sym "cell"] }, { path := [.sym "content"], vals := [.int (0)] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "mark" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "action-handle"], [{ val := .sym "mark" }]), ([.sym "argument1"], [{ val := .var "c" }]), ([.sym "argument-count"], [{ val := .int (1) }]), ([.sym "desireds"], [{ val := .var "pre" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (0) }])]] }

def r_tictactoe_apply_mark_internal : Prod :=
  { name := "tictactoe*apply*mark*internal",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "tictactoe"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "internal-actions"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "mark"] }, { path := [.sym "pre-conditions-satisfied"], vals := [.sym "true"] }, { path := [.sym "argument1", .sym "object-handle"], vals := [.lit (.var "ch")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "c", .var "g"] }],
        .pos false (.var "c") [{ path := [.sym "object-handle"], vals := [.lit (.var "ch")] }, { path := [.sym "content"], vals := [.var "old"] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "game"] }, { path := [.sym "turn"], vals := [.var "t"] }]],
    acts := [.call "log" [.int (1), .fn "crlf" [], .str "Mark ", .var "ch", .str " by ", .var "t"],
        .make (.var "c") [([.sym "content"], [{ val := .var "old", pref := "-" }, { val := .var "t" }])],
        .make (.var "g") [([.sym "turn"], [{ val := .var "t", pref := "-" }, { val := .fn "-" [.int (3), .var "t"] }])]] }

def r_tictactoe_propose_x_wins : Prod :=
  { name := "tictactoe*propose*x-wins",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "tictactoe"] }, { path := [.sym "flags", .sym "mea-operator-selection"], vals := [.sym "true"] }, { path := [.sym "desireds", .sym "unachieved-desireds"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "g"] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "game"] }, { path := [.sym "over"], vals := [.int (0)] }],
        .pos false (.var "w") [{ path := [.sym "objects", .sym "object"], vals := [.var "l"] }, { path := [.sym "in-line"], vals := [.var "r1", .conj [.cmp "<>" (.var "r1"), .var "r2"], .conj [.cmp "<>" (.var "r1"), .cmp "<>" (.var "r2"), .var "r3"]] }],
        .pos false (.var "l") [{ path := [.sym "type"], vals := [.sym "line"] }],
        .pos false (.var "r1") [{ path := [.sym "argument1"], vals := [.var "c1"] }, { path := [.sym "argument2"], vals := [.var "l"] }],
        .pos false (.var "r2") [{ path := [.sym "argument1"], vals := [.conj [.cmp "<>" (.var "c1"), .var "c2"]] }, { path := [.sym "argument2"], vals := [.var "l"] }],
        .pos false (.var "r3") [{ path := [.sym "argument1"], vals := [.conj [.cmp "<>" (.var "c1"), .cmp "<>" (.var "c2"), .var "c3"]] }, { path := [.sym "argument2"], vals := [.var "l"] }],
        .pos false (.var "c1") [{ path := [.sym "content"], vals := [.int (1)] }],
        .pos false (.var "c2") [{ path := [.sym "content"], vals := [.int (1)] }],
        .pos false (.var "c3") [{ path := [.sym "content"], vals := [.int (1)] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "x-wins" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "action-handle"], [{ val := .sym "x-wins" }]), ([.sym "argument1"], [{ val := .var "l" }]), ([.sym "argument-count"], [{ val := .int (1) }]), ([.sym "desireds"], [{ val := .var "pre" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (0) }])]] }

def r_tictactoe_apply_x_wins_internal : Prod :=
  { name := "tictactoe*apply*x-wins*internal",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "tictactoe"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "internal-actions"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "x-wins"] }, { path := [.sym "pre-conditions-satisfied"], vals := [.sym "true"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "g"] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "game"] }, { path := [.sym "over"], vals := [.var "ov"] }, { path := [.sym "winner"], vals := [.var "wn"] }]],
    acts := [.call "log" [.int (1), .fn "crlf" [], .str "Side X won."],
        .make (.var "g") [([.sym "over"], [{ val := .var "ov", pref := "-" }, { val := .int (1) }]), ([.sym "winner"], [{ val := .var "wn", pref := "-" }, { val := .int (1) }])]] }

def r_tictactoe_compare_x_wins_best : Prod :=
  { name := "tictactoe*compare*x-wins*best",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "tictactoe"] }, { path := [.sym "operator"], vals := [.var "o", .sym "+"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "x-wins"] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := ">" }])]] }

def r_tictactoe_propose_o_wins : Prod :=
  { name := "tictactoe*propose*o-wins",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "tictactoe"] }, { path := [.sym "flags", .sym "mea-operator-selection"], vals := [.sym "true"] }, { path := [.sym "desireds", .sym "unachieved-desireds"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "g"] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "game"] }, { path := [.sym "over"], vals := [.int (0)] }],
        .pos false (.var "w") [{ path := [.sym "objects", .sym "object"], vals := [.var "l"] }, { path := [.sym "in-line"], vals := [.var "r1", .conj [.cmp "<>" (.var "r1"), .var "r2"], .conj [.cmp "<>" (.var "r1"), .cmp "<>" (.var "r2"), .var "r3"]] }],
        .pos false (.var "l") [{ path := [.sym "type"], vals := [.sym "line"] }],
        .pos false (.var "r1") [{ path := [.sym "argument1"], vals := [.var "c1"] }, { path := [.sym "argument2"], vals := [.var "l"] }],
        .pos false (.var "r2") [{ path := [.sym "argument1"], vals := [.conj [.cmp "<>" (.var "c1"), .var "c2"]] }, { path := [.sym "argument2"], vals := [.var "l"] }],
        .pos false (.var "r3") [{ path := [.sym "argument1"], vals := [.conj [.cmp "<>" (.var "c1"), .cmp "<>" (.var "c2"), .var "c3"]] }, { path := [.sym "argument2"], vals := [.var "l"] }],
        .pos false (.var "c1") [{ path := [.sym "content"], vals := [.int (2)] }],
        .pos false (.var "c2") [{ path := [.sym "content"], vals := [.int (2)] }],
        .pos false (.var "c3") [{ path := [.sym "content"], vals := [.int (2)] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "o-wins" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "action-handle"], [{ val := .sym "o-wins" }]), ([.sym "argument1"], [{ val := .var "l" }]), ([.sym "argument-count"], [{ val := .int (1) }]), ([.sym "desireds"], [{ val := .var "pre" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (0) }])]] }

def r_tictactoe_apply_o_wins_internal : Prod :=
  { name := "tictactoe*apply*o-wins*internal",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "tictactoe"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "internal-actions"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "o-wins"] }, { path := [.sym "pre-conditions-satisfied"], vals := [.sym "true"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "g"] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "game"] }, { path := [.sym "over"], vals := [.var "ov"] }, { path := [.sym "winner"], vals := [.var "wn"] }]],
    acts := [.call "log" [.int (1), .fn "crlf" [], .str "Side O won."],
        .make (.var "g") [([.sym "over"], [{ val := .var "ov", pref := "-" }, { val := .int (1) }]), ([.sym "winner"], [{ val := .var "wn", pref := "-" }, { val := .int (2) }])]] }

def r_tictactoe_compare_o_wins_best : Prod :=
  { name := "tictactoe*compare*o-wins*best",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "tictactoe"] }, { path := [.sym "operator"], vals := [.var "o", .sym "+"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "o-wins"] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := ">" }])]] }

def r_tictactoe_propose_detect_draw : Prod :=
  { name := "tictactoe*propose*detect-draw",
    doc := ["detect-draw <game>: no empty cell left."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "tictactoe"] }, { path := [.sym "flags", .sym "mea-operator-selection"], vals := [.sym "true"] }, { path := [.sym "desireds", .sym "unachieved-desireds"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "g"] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "game"] }, { path := [.sym "over"], vals := [.int (0)] }],
        .ncc [.pos false (.var "w") [{ path := [.sym "objects", .sym "object"], vals := [.var "c"] }], .pos false (.var "c") [{ path := [.sym "type"], vals := [.sym "cell"] }, { path := [.sym "content"], vals := [.int (0)] }]]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "detect-draw" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "action-handle"], [{ val := .sym "detect-draw" }]), ([.sym "argument1"], [{ val := .var "g" }]), ([.sym "argument-count"], [{ val := .int (1) }]), ([.sym "desireds"], [{ val := .var "pre" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (0) }])]] }

def r_tictactoe_apply_detect_draw_internal : Prod :=
  { name := "tictactoe*apply*detect-draw*internal",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "tictactoe"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "internal-actions"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "detect-draw"] }, { path := [.sym "pre-conditions-satisfied"], vals := [.sym "true"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "g"] }],
        .pos false (.var "g") [{ path := [.sym "type"], vals := [.sym "game"] }, { path := [.sym "over"], vals := [.var "ov"] }]],
    acts := [.call "log" [.int (1), .fn "crlf" [], .str "Draw."],
        .make (.var "g") [([.sym "over"], [{ val := .var "ov", pref := "-" }, { val := .int (1) }])]] }

def v_tictactoe : Variant :=
  { family := "tictactoe", name := "tictactoe",
    about := ["Tic-tac-toe: X and O take turns marking a random empty cell until one side has a line or the board is full."],
    firstload := ["chunk never"],
    task := { name := "tictactoe", psExtra := [], flags := [("mea-operator-selection", .sym "true")], environmentNone := true,
              initBody := [.make (.var "objs") [([.sym "object"], [{ val := .var "game" }, { val := .var "c11" }, { val := .var "c21" }, { val := .var "c31" }, { val := .var "c12" }, { val := .var "c22" }, { val := .var "c32" }, { val := .var "c13" }, { val := .var "c23" }, { val := .var "c33" }, { val := .var "row1" }, { val := .var "row2" }, { val := .var "row3" }, { val := .var "column1" }, { val := .var "column2" }, { val := .var "column3" }, { val := .var "diagonal1" }, { val := .var "diagonal2" }])],
      .make (.var "c11") [([.sym "object-handle"], [{ val := .sym "c11" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "cell" }]), ([.sym "xy"], [{ val := .int (11) }]), ([.sym "x"], [{ val := .int (1) }]), ([.sym "y"], [{ val := .int (1) }]), ([.sym "content"], [{ val := .int (0) }])],
      .make (.var "c21") [([.sym "object-handle"], [{ val := .sym "c21" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "cell" }]), ([.sym "xy"], [{ val := .int (21) }]), ([.sym "x"], [{ val := .int (2) }]), ([.sym "y"], [{ val := .int (1) }]), ([.sym "content"], [{ val := .int (0) }])],
      .make (.var "c31") [([.sym "object-handle"], [{ val := .sym "c31" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "cell" }]), ([.sym "xy"], [{ val := .int (31) }]), ([.sym "x"], [{ val := .int (3) }]), ([.sym "y"], [{ val := .int (1) }]), ([.sym "content"], [{ val := .int (0) }])],
      .make (.var "c12") [([.sym "object-handle"], [{ val := .sym "c12" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "cell" }]), ([.sym "xy"], [{ val := .int (12) }]), ([.sym "x"], [{ val := .int (1) }]), ([.sym "y"], [{ val := .int (2) }]), ([.sym "content"], [{ val := .int (0) }])],
      .make (.var "c22") [([.sym "object-handle"], [{ val := .sym "c22" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "cell" }]), ([.sym "xy"], [{ val := .int (22) }]), ([.sym "x"], [{ val := .int (2) }]), ([.sym "y"], [{ val := .int (2) }]), ([.sym "content"], [{ val := .int (0) }])],
      .make (.var "c32") [([.sym "object-handle"], [{ val := .sym "c32" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "cell" }]), ([.sym "xy"], [{ val := .int (32) }]), ([.sym "x"], [{ val := .int (3) }]), ([.sym "y"], [{ val := .int (2) }]), ([.sym "content"], [{ val := .int (0) }])],
      .make (.var "c13") [([.sym "object-handle"], [{ val := .sym "c13" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "cell" }]), ([.sym "xy"], [{ val := .int (13) }]), ([.sym "x"], [{ val := .int (1) }]), ([.sym "y"], [{ val := .int (3) }]), ([.sym "content"], [{ val := .int (0) }])],
      .make (.var "c23") [([.sym "object-handle"], [{ val := .sym "c23" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "cell" }]), ([.sym "xy"], [{ val := .int (23) }]), ([.sym "x"], [{ val := .int (2) }]), ([.sym "y"], [{ val := .int (3) }]), ([.sym "content"], [{ val := .int (0) }])],
      .make (.var "c33") [([.sym "object-handle"], [{ val := .sym "c33" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "cell" }]), ([.sym "xy"], [{ val := .int (33) }]), ([.sym "x"], [{ val := .int (3) }]), ([.sym "y"], [{ val := .int (3) }]), ([.sym "content"], [{ val := .int (0) }])],
      .make (.var "row1") [([.sym "object-handle"], [{ val := .sym "row1" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "line" }])],
      .make (.var "w") [([.sym "in-line"], [{ val := .var "r1" }])],
      .make (.var "r1") [([.sym "argument1"], [{ val := .var "c11" }]), ([.sym "argument2"], [{ val := .var "row1" }])],
      .make (.var "w") [([.sym "in-line"], [{ val := .var "r2" }])],
      .make (.var "r2") [([.sym "argument1"], [{ val := .var "c21" }]), ([.sym "argument2"], [{ val := .var "row1" }])],
      .make (.var "w") [([.sym "in-line"], [{ val := .var "r3" }])],
      .make (.var "r3") [([.sym "argument1"], [{ val := .var "c31" }]), ([.sym "argument2"], [{ val := .var "row1" }])],
      .make (.var "row2") [([.sym "object-handle"], [{ val := .sym "row2" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "line" }])],
      .make (.var "w") [([.sym "in-line"], [{ val := .var "r4" }])],
      .make (.var "r4") [([.sym "argument1"], [{ val := .var "c12" }]), ([.sym "argument2"], [{ val := .var "row2" }])],
      .make (.var "w") [([.sym "in-line"], [{ val := .var "r5" }])],
      .make (.var "r5") [([.sym "argument1"], [{ val := .var "c22" }]), ([.sym "argument2"], [{ val := .var "row2" }])],
      .make (.var "w") [([.sym "in-line"], [{ val := .var "r6" }])],
      .make (.var "r6") [([.sym "argument1"], [{ val := .var "c32" }]), ([.sym "argument2"], [{ val := .var "row2" }])],
      .make (.var "row3") [([.sym "object-handle"], [{ val := .sym "row3" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "line" }])],
      .make (.var "w") [([.sym "in-line"], [{ val := .var "r7" }])],
      .make (.var "r7") [([.sym "argument1"], [{ val := .var "c13" }]), ([.sym "argument2"], [{ val := .var "row3" }])],
      .make (.var "w") [([.sym "in-line"], [{ val := .var "r8" }])],
      .make (.var "r8") [([.sym "argument1"], [{ val := .var "c23" }]), ([.sym "argument2"], [{ val := .var "row3" }])],
      .make (.var "w") [([.sym "in-line"], [{ val := .var "r9" }])],
      .make (.var "r9") [([.sym "argument1"], [{ val := .var "c33" }]), ([.sym "argument2"], [{ val := .var "row3" }])],
      .make (.var "column1") [([.sym "object-handle"], [{ val := .sym "column1" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "line" }])],
      .make (.var "w") [([.sym "in-line"], [{ val := .var "r10" }])],
      .make (.var "r10") [([.sym "argument1"], [{ val := .var "c11" }]), ([.sym "argument2"], [{ val := .var "column1" }])],
      .make (.var "w") [([.sym "in-line"], [{ val := .var "r11" }])],
      .make (.var "r11") [([.sym "argument1"], [{ val := .var "c12" }]), ([.sym "argument2"], [{ val := .var "column1" }])],
      .make (.var "w") [([.sym "in-line"], [{ val := .var "r12" }])],
      .make (.var "r12") [([.sym "argument1"], [{ val := .var "c13" }]), ([.sym "argument2"], [{ val := .var "column1" }])],
      .make (.var "column2") [([.sym "object-handle"], [{ val := .sym "column2" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "line" }])],
      .make (.var "w") [([.sym "in-line"], [{ val := .var "r13" }])],
      .make (.var "r13") [([.sym "argument1"], [{ val := .var "c21" }]), ([.sym "argument2"], [{ val := .var "column2" }])],
      .make (.var "w") [([.sym "in-line"], [{ val := .var "r14" }])],
      .make (.var "r14") [([.sym "argument1"], [{ val := .var "c22" }]), ([.sym "argument2"], [{ val := .var "column2" }])],
      .make (.var "w") [([.sym "in-line"], [{ val := .var "r15" }])],
      .make (.var "r15") [([.sym "argument1"], [{ val := .var "c23" }]), ([.sym "argument2"], [{ val := .var "column2" }])],
      .make (.var "column3") [([.sym "object-handle"], [{ val := .sym "column3" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "line" }])],
      .make (.var "w") [([.sym "in-line"], [{ val := .var "r16" }])],
      .make (.var "r16") [([.sym "argument1"], [{ val := .var "c31" }]), ([.sym "argument2"], [{ val := .var "column3" }])],
      .make (.var "w") [([.sym "in-line"], [{ val := .var "r17" }])],
      .make (.var "r17") [([.sym "argument1"], [{ val := .var "c32" }]), ([.sym "argument2"], [{ val := .var "column3" }])],
      .make (.var "w") [([.sym "in-line"], [{ val := .var "r18" }])],
      .make (.var "r18") [([.sym "argument1"], [{ val := .var "c33" }]), ([.sym "argument2"], [{ val := .var "column3" }])],
      .make (.var "diagonal1") [([.sym "object-handle"], [{ val := .sym "diagonal1" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "line" }])],
      .make (.var "w") [([.sym "in-line"], [{ val := .var "r19" }])],
      .make (.var "r19") [([.sym "argument1"], [{ val := .var "c11" }]), ([.sym "argument2"], [{ val := .var "diagonal1" }])],
      .make (.var "w") [([.sym "in-line"], [{ val := .var "r20" }])],
      .make (.var "r20") [([.sym "argument1"], [{ val := .var "c22" }]), ([.sym "argument2"], [{ val := .var "diagonal1" }])],
      .make (.var "w") [([.sym "in-line"], [{ val := .var "r21" }])],
      .make (.var "r21") [([.sym "argument1"], [{ val := .var "c33" }]), ([.sym "argument2"], [{ val := .var "diagonal1" }])],
      .make (.var "diagonal2") [([.sym "object-handle"], [{ val := .sym "diagonal2" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "line" }])],
      .make (.var "w") [([.sym "in-line"], [{ val := .var "r22" }])],
      .make (.var "r22") [([.sym "argument1"], [{ val := .var "c31" }]), ([.sym "argument2"], [{ val := .var "diagonal2" }])],
      .make (.var "w") [([.sym "in-line"], [{ val := .var "r23" }])],
      .make (.var "r23") [([.sym "argument1"], [{ val := .var "c22" }]), ([.sym "argument2"], [{ val := .var "diagonal2" }])],
      .make (.var "w") [([.sym "in-line"], [{ val := .var "r24" }])],
      .make (.var "r24") [([.sym "argument1"], [{ val := .var "c13" }]), ([.sym "argument2"], [{ val := .var "diagonal2" }])],
      .make (.var "game") [([.sym "object-handle"], [{ val := .sym "game" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "game" }]), ([.sym "turn"], [{ val := .int (1) }]), ([.sym "winner"], [{ val := .int (0) }]), ([.sym "over"], [{ val := .int (0) }])],
      .make (.var "ds") [([.sym "desired-count"], [{ val := .int (1) }]), ([.sym "desired"], [{ val := .var "d1" }])],
      .make (.var "d1") [([.sym "object"], [{ val := .var "d1o" }])],
      .make (.var "d1o") [([.sym "object-handle"], [{ val := .sym "game" }]), ([.sym "over"], [{ val := .int (1) }])]],
              initFile := none, initOpExtra := [], achieve := [.objectState], achieveSpaces := [], indifferent := some "the original selects among its task operators at random", indifferentExcept := [], ancestors := false },
    files := [("elaborations.soar", [.ps, .achieve .objectState]),
              ("initialize-tictactoe.soar", [.init]),
              ("mark.soar", [.p r_tictactoe_propose_mark, .p r_tictactoe_apply_mark_internal]),
              ("wins.soar", [.p r_tictactoe_propose_x_wins, .p r_tictactoe_apply_x_wins_internal, .p r_tictactoe_compare_x_wins_best, .p r_tictactoe_propose_o_wins, .p r_tictactoe_apply_o_wins_internal, .p r_tictactoe_compare_o_wins_best, .p r_tictactoe_propose_detect_draw, .p r_tictactoe_apply_detect_draw_internal]),
              ("search-control.soar", [.indifferent])] }

def variants : List Variant := [v_tictactoe]

end Fam.Families.Tictactoe
