import Family.Task
set_option maxHeartbeats 0
set_option maxRecDepth 100000
/-!
# towers-of-hanoi: world-convention agents of the towers-of-hanoi family

Typed description migrated on 19 November 2026 from the world-v6 agents (Tasks/Families/towers-of-hanoi/world-v6),
which were written from the original programs. Task-level parts are `Task` fields; family knowledge is typed
productions, defined once and shared by the variants that use them.

Written 19 November 2026 by Claude, supervised by John E. Laird.
-/
namespace Fam.Families.TowersOfHanoi
open Fam

def r_towers_of_hanoi_propose_move_disc_smallest : Prod :=
  { name := "towers-of-hanoi*propose*move-disc*smallest",
    doc := ["Smallest disc (size 1): moved when the last move was not of disc 1, to a peg it did not just leave."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "towers-of-hanoi"] }, { path := [.sym "flags", .sym "mea-operator-selection"], vals := [.sym "true"] }, { path := [.sym "desireds", .sym "unachieved-desireds"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "d", .var "t", .var "p", .var "m"] }],
        .pos false (.var "d") [{ path := [.sym "type"], vals := [.sym "disc"] }, { path := [.sym "size"], vals := [.int (1)] }],
        .pos false (.var "m") [{ path := [.sym "type"], vals := [.sym "memory"] }, { path := [.sym "lastsize"], vals := [.cmp "<>" (.int (1))] }, { path := [.sym "lastpeg"], vals := [.conj [.cmp "<>" (.var "ph")]] }],
        .pos false (.var "p") [{ path := [.sym "type"], vals := [.sym "peg"] }, { path := [.sym "object-handle"], vals := [.var "ph"] }],
        .pos false (.var "w") [{ path := [.sym "clear"], vals := [.var "cd", .var "ct"] }, { path := [.sym "on"], vals := [.var "ondp", .var "ontp"] }],
        .pos false (.var "cd") [{ path := [.sym "argument1"], vals := [.var "d"] }],
        .pos false (.var "ct") [{ path := [.sym "argument1"], vals := [.var "t"] }],
        .pos false (.var "ondp") [{ path := [.sym "argument1"], vals := [.var "d"] }, { path := [.sym "argument2"], vals := [.cmp "<>" (.var "p")] }],
        .pos false (.var "ontp") [{ path := [.sym "argument1"], vals := [.var "t"] }, { path := [.sym "argument2"], vals := [.var "p"] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "move-disc" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "action-handle"], [{ val := .sym "move-disc" }]), ([.sym "argument1"], [{ val := .var "d" }]), ([.sym "argument2"], [{ val := .var "t" }]), ([.sym "argument3"], [{ val := .var "p" }]), ([.sym "argument-count"], [{ val := .int (3) }]), ([.sym "desireds"], [{ val := .var "pre" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (0) }])]] }

def r_towers_of_hanoi_propose_move_disc_other : Prod :=
  { name := "towers-of-hanoi*propose*move-disc*other",
    doc := ["Any other clear disc (size 2 or more) after disc 1 moved: onto a clear larger disc or base on another peg."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "towers-of-hanoi"] }, { path := [.sym "flags", .sym "mea-operator-selection"], vals := [.sym "true"] }, { path := [.sym "desireds", .sym "unachieved-desireds"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "d", .var "t", .var "p", .var "m"] }],
        .pos false (.var "d") [{ path := [.sym "type"], vals := [.sym "disc"] }, { path := [.sym "size"], vals := [.conj [.cmp ">" (.int (1)), .var "size"]] }],
        .pos false (.var "t") [{ path := [.sym "size"], vals := [.cmp ">" (.var "size")] }],
        .pos false (.var "m") [{ path := [.sym "type"], vals := [.sym "memory"] }, { path := [.sym "lastsize"], vals := [.int (1)] }],
        .pos false (.var "p") [{ path := [.sym "type"], vals := [.sym "peg"] }],
        .pos false (.var "w") [{ path := [.sym "clear"], vals := [.var "cd", .var "ct"] }, { path := [.sym "on"], vals := [.var "ondp", .var "ontp"] }],
        .pos false (.var "cd") [{ path := [.sym "argument1"], vals := [.var "d"] }],
        .pos false (.var "ct") [{ path := [.sym "argument1"], vals := [.var "t"] }],
        .pos false (.var "ondp") [{ path := [.sym "argument1"], vals := [.var "d"] }, { path := [.sym "argument2"], vals := [.cmp "<>" (.var "p")] }],
        .pos false (.var "ontp") [{ path := [.sym "argument1"], vals := [.var "t"] }, { path := [.sym "argument2"], vals := [.var "p"] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "move-disc" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "action-handle"], [{ val := .sym "move-disc" }]), ([.sym "argument1"], [{ val := .var "d" }]), ([.sym "argument2"], [{ val := .var "t" }]), ([.sym "argument3"], [{ val := .var "p" }]), ([.sym "argument-count"], [{ val := .int (3) }]), ([.sym "desireds"], [{ val := .var "pre" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (0) }])]] }

def r_towers_of_hanoi_apply_move_disc_control_smallest : Prod :=
  { name := "towers-of-hanoi*apply*move-disc*control*smallest",
    doc := ["Control memory: size of the disc moved last, and (for disc 1) the peg it left."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "towers-of-hanoi"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "internal-actions"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "move-disc"] }, { path := [.sym "pre-conditions-satisfied"], vals := [.sym "true"] }, { path := [.sym "argument1"], vals := [.var "d"] }],
        .pos false (.var "d") [{ path := [.sym "size"], vals := [.int (1)] }, { path := [.sym "object-handle"], vals := [.lit (.var "dh")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "m", .var "d2"] }, { path := [.sym "on"], vals := [.var "on"] }],
        .pos false (.var "d2") [{ path := [.sym "object-handle"], vals := [.lit (.var "dh")] }],
        .pos false (.var "on") [{ path := [.sym "argument1"], vals := [.var "d2"] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.var "from"] }],
        .pos false (.var "m") [{ path := [.sym "type"], vals := [.sym "memory"] }, { path := [.sym "lastsize"], vals := [.var "ls"] }, { path := [.sym "lastpeg"], vals := [.var "lp"] }]],
    acts := [.make (.var "m") [([.sym "lastsize"], [{ val := .var "ls", pref := "-" }, { val := .int (1) }]), ([.sym "lastpeg"], [{ val := .var "lp", pref := "-" }, { val := .var "from" }])]] }

def r_towers_of_hanoi_apply_move_disc_control_other : Prod :=
  { name := "towers-of-hanoi*apply*move-disc*control*other",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "towers-of-hanoi"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "internal-actions"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "move-disc"] }, { path := [.sym "pre-conditions-satisfied"], vals := [.sym "true"] }, { path := [.sym "argument1"], vals := [.var "d"] }],
        .pos false (.var "d") [{ path := [.sym "size"], vals := [.conj [.cmp ">" (.int (1)), .var "size"]] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "m"] }],
        .pos false (.var "m") [{ path := [.sym "type"], vals := [.sym "memory"] }, { path := [.sym "lastsize"], vals := [.var "ls"] }]],
    acts := [.make (.var "m") [([.sym "lastsize"], [{ val := .var "ls", pref := "-" }, { val := .var "size" }])]] }

def r_towers_of_hanoi_apply_move_disc_internal : Prod :=
  { name := "towers-of-hanoi*apply*move-disc*internal",
    doc := ["move-disc <disc> <onto> <peg>: the disc leaves what it was on and rests on <onto> (a disc or a peg's base)", "on <peg>.  on, above and clear are maintained here (spec section 3)."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "towers-of-hanoi"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "internal-actions"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "move-disc"] }, { path := [.sym "pre-conditions-satisfied"], vals := [.sym "true"] }, { path := [.sym "argument1", .sym "object-handle"], vals := [.lit (.var "dh")] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.lit (.var "th")] }, { path := [.sym "argument3", .sym "object-handle"], vals := [.lit (.var "ph")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "d", .var "t", .var "p"] }],
        .pos false (.var "d") [{ path := [.sym "object-handle"], vals := [.lit (.var "dh")] }, { path := [.sym "size"], vals := [.var "size"] }],
        .pos false (.var "t") [{ path := [.sym "object-handle"], vals := [.lit (.var "th")] }],
        .pos false (.var "p") [{ path := [.sym "object-handle"], vals := [.lit (.var "ph")] }],
        .pos false (.var "w") [{ path := [.sym "on"], vals := [.var "on"] }, { path := [.sym "above"], vals := [.var "ab"] }, { path := [.sym "clear"], vals := [.var "ct"] }],
        .pos false (.var "on") [{ path := [.sym "argument1"], vals := [.var "d"] }, { path := [.sym "argument2"], vals := [.var "oldp"] }],
        .pos false (.var "ab") [{ path := [.sym "argument1"], vals := [.var "d"] }, { path := [.sym "argument2"], vals := [.var "oldbelow"] }],
        .pos false (.var "ct") [{ path := [.sym "argument1"], vals := [.var "t"] }]],
    acts := [.call "log" [.int (1), .fn "crlf" [], .str "Move disc ", .var "size", .str " to peg ", .var "ph"],
        .make (.var "on") [([.sym "argument2"], [{ val := .var "oldp", pref := "-" }, { val := .var "p" }])],
        .make (.var "ab") [([.sym "argument2"], [{ val := .var "oldbelow", pref := "-" }, { val := .var "t" }])],
        .make (.var "w") [([.sym "clear"], [{ val := .var "ct", pref := "-" }, { val := .var "nc" }])],
        .make (.var "nc") [([.sym "argument1"], [{ val := .var "oldbelow" }])]] }

def r_towers_of_hanoi_propose_move_disc_mea : Prod :=
  { name := "towers-of-hanoi*propose*move-disc*mea",
    doc := ["Means-ends proposal (W-TOP-009): for an unachieved desired \"disc D on peg P\" whose disc is the largest one", "not yet in place in this desireds, move D onto P.  Preconditions (^desireds): every smaller disc is on", "the third peg; they are added by the operator elaboration below.  When they do not hold, the operator", "no-change substate gets them as its desireds (W-MEA-002, W-MEA-003): operator subgoaling."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "towers-of-hanoi"] }, { path := [.sym "flags", .sym "mea-operator-selection"], vals := [.sym "true"] }, { path := [.sym "desireds"], vals := [.var "ds"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "ds") [{ path := [.sym "desired"], vals := [.var "g"] }, { path := [.sym "unachieved"], vals := [.var "g"] }],
        .pos false (.var "g") [{ path := [.sym "on"], vals := [.var "gr"] }],
        .pos false (.var "gr") [{ path := [.sym "argument1", .sym "object-handle"], vals := [.lit (.var "dh")] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.lit (.var "ph")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "d", .var "p"] }],
        .pos false (.var "d") [{ path := [.sym "object-handle"], vals := [.lit (.var "dh")] }, { path := [.sym "size"], vals := [.var "size"] }],
        .pos false (.var "p") [{ path := [.sym "object-handle"], vals := [.lit (.var "ph")] }, { path := [.sym "type"], vals := [.sym "peg"] }],
        .ncc [.pos false (.var "ds") [{ path := [.sym "unachieved"], vals := [.var "g2"] }], .pos false (.var "g2") [{ path := [.sym "on", .sym "argument1", .sym "object-handle"], vals := [.var "h2"] }], .pos false (.var "w") [{ path := [.sym "objects", .sym "object"], vals := [.var "d2"] }], .pos false (.var "d2") [{ path := [.sym "object-handle"], vals := [.var "h2"] }, { path := [.sym "size"], vals := [.cmp ">" (.var "size")] }]]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "move-disc" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "action-handle"], [{ val := .sym "move-disc" }]), ([.sym "super-desired"], [{ val := .var "g" }]), ([.sym "argument1"], [{ val := .var "d" }]), ([.sym "argument3"], [{ val := .var "p" }]), ([.sym "argument-count"], [{ val := .int (3) }]), ([.sym "desireds"], [{ val := .var "pre" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .fn "-" [.var "size", .int (1)] }])]] }

def r_towers_of_hanoi_elaborate_move_disc_aux_peg : Prod :=
  { name := "towers-of-hanoi*elaborate*move-disc*aux-peg",
    doc := ["The third peg: neither the disc's current peg nor the target."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "towers-of-hanoi"] }, { path := [.sym "operator"], vals := [.var "o", .sym "+"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "move-disc"] }, { path := [.sym "argument1"], vals := [.var "d"] }, { path := [.sym "argument3"], vals := [.var "p"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "on"], vals := [.var "on"] }],
        .pos false (.var "on") [{ path := [.sym "argument1"], vals := [.var "d"] }, { path := [.sym "argument2"], vals := [.conj [.cmp "<>" (.var "p"), .var "from"]] }],
        .pos false (.var "w") [{ path := [.sym "objects", .sym "object"], vals := [.conj [.cmp "<>" (.var "p"), .cmp "<>" (.var "from"), .var "z"]] }],
        .pos false (.var "z") [{ path := [.sym "type"], vals := [.sym "peg"] }]],
    acts := [.make (.var "o") [([.sym "aux-peg"], [{ val := .var "z" }])]] }

def r_towers_of_hanoi_elaborate_move_disc_preconditions : Prod :=
  { name := "towers-of-hanoi*elaborate*move-disc*preconditions",
    doc := ["Precondition desireds of move-disc: each smaller disc on the auxiliary peg."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "towers-of-hanoi"] }, { path := [.sym "operator"], vals := [.var "o", .sym "+"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "move-disc"] }, { path := [.sym "argument1"], vals := [.var "d"] }, { path := [.sym "aux-peg"], vals := [.var "z"] }, { path := [.sym "desireds"], vals := [.var "pre"] }],
        .pos false (.var "d") [{ path := [.sym "size"], vals := [.var "size"] }],
        .pos false (.var "z") [{ path := [.sym "object-handle"], vals := [.var "zh"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "d2"] }],
        .pos false (.var "d2") [{ path := [.sym "type"], vals := [.sym "disc"] }, { path := [.sym "size"], vals := [.cmp "<" (.var "size")] }, { path := [.sym "object-handle"], vals := [.var "h2"] }]],
    acts := [.make (.var "pre") [([.sym "desired"], [{ val := .var "pd" }])],
        .make (.var "pd") [([.sym "on"], [{ val := .var "pr" }])],
        .make (.var "pr") [([.sym "argument1"], [{ val := .var "pa1" }]), ([.sym "argument2"], [{ val := .var "pa2" }])],
        .make (.var "pa1") [([.sym "object-handle"], [{ val := .var "h2" }])],
        .make (.var "pa2") [([.sym "object-handle"], [{ val := .var "zh" }])]] }

def r_towers_of_hanoi_elaborate_move_disc_destination : Prod :=
  { name := "towers-of-hanoi*elaborate*move-disc*destination",
    doc := ["Destination: the clear object on the target peg (argument2)."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "towers-of-hanoi"] }, { path := [.sym "operator"], vals := [.var "o", .sym "+"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "move-disc"] }, { path := [.sym "argument3"], vals := [.var "p"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "clear"], vals := [.var "ct"] }, { path := [.sym "on"], vals := [.var "ont"] }],
        .pos false (.var "ct") [{ path := [.sym "argument1"], vals := [.var "t"] }],
        .pos false (.var "ont") [{ path := [.sym "argument1"], vals := [.var "t"] }, { path := [.sym "argument2"], vals := [.var "p"] }]],
    acts := [.make (.var "o") [([.sym "argument2"], [{ val := .var "t" }])]] }

def r_towers_of_hanoi_compare_move_disc_indifferent : Prod :=
  { name := "towers-of-hanoi*compare*move-disc*indifferent",
    doc := ["Precondition desireds may name the disc's own peg as target when the disc is already there; such a move", "is never proposed (the desired is achieved).  The original moves the largest misplaced disc first."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "towers-of-hanoi"] }, { path := [.sym "operator"], vals := [.var "o", .sym "+"] }],
        .pos false (.var "o") [{ path := [.sym "task-operator"], vals := [.sym "true"] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "=" }])]] }

def v_towers_of_hanoi : Variant :=
  { family := "towers-of-hanoi", name := "towers-of-hanoi",
    about := ["Towers of Hanoi, 3 discs, A to C, by the cyclic algorithm: the smallest disc moves on every other step, never back to the peg it came from."],
    firstload := ["chunk never"],
    task := { name := "towers-of-hanoi", psExtra := [], flags := [("mea-operator-selection", .sym "true")], environmentNone := true,
              initBody := [.make (.var "objs") [([.sym "object"], [{ val := .var "pa" }, { val := .var "pb" }, { val := .var "pc" }, { val := .var "d1" }, { val := .var "d2" }, { val := .var "d3" }, { val := .var "ba" }, { val := .var "bb" }, { val := .var "bc" }, { val := .var "m" }])],
      .make (.var "pa") [([.sym "object-handle"], [{ val := .sym "A" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "peg" }])],
      .make (.var "ba") [([.sym "object-handle"], [{ val := .sym "base-A" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "base" }]), ([.sym "size"], [{ val := .int (6) }])],
      .make (.var "pb") [([.sym "object-handle"], [{ val := .sym "B" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "peg" }])],
      .make (.var "bb") [([.sym "object-handle"], [{ val := .sym "base-B" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "base" }]), ([.sym "size"], [{ val := .int (6) }])],
      .make (.var "pc") [([.sym "object-handle"], [{ val := .sym "C" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "peg" }])],
      .make (.var "bc") [([.sym "object-handle"], [{ val := .sym "base-C" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "base" }]), ([.sym "size"], [{ val := .int (6) }])],
      .make (.var "d1") [([.sym "object-handle"], [{ val := .sym "d1" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "disc" }]), ([.sym "size"], [{ val := .int (1) }])],
      .make (.var "d2") [([.sym "object-handle"], [{ val := .sym "d2" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "disc" }]), ([.sym "size"], [{ val := .int (2) }])],
      .make (.var "d3") [([.sym "object-handle"], [{ val := .sym "d3" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "disc" }]), ([.sym "size"], [{ val := .int (3) }])],
      .make (.var "m") [([.sym "object-handle"], [{ val := .sym "control" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "memory" }]), ([.sym "lastsize"], [{ val := .int (2) }]), ([.sym "lastpeg"], [{ val := .sym "B" }])],
      .make (.var "w") [([.sym "on"], [{ val := .var "on1" }])],
      .make (.var "on1") [([.sym "argument1"], [{ val := .var "d1" }]), ([.sym "argument2"], [{ val := .var "pa" }])],
      .make (.var "w") [([.sym "above"], [{ val := .var "ab1" }])],
      .make (.var "ab1") [([.sym "argument1"], [{ val := .var "d1" }]), ([.sym "argument2"], [{ val := .var "d2" }])],
      .make (.var "w") [([.sym "on"], [{ val := .var "on2" }])],
      .make (.var "on2") [([.sym "argument1"], [{ val := .var "d2" }]), ([.sym "argument2"], [{ val := .var "pa" }])],
      .make (.var "w") [([.sym "above"], [{ val := .var "ab2" }])],
      .make (.var "ab2") [([.sym "argument1"], [{ val := .var "d2" }]), ([.sym "argument2"], [{ val := .var "d3" }])],
      .make (.var "w") [([.sym "on"], [{ val := .var "on3" }])],
      .make (.var "on3") [([.sym "argument1"], [{ val := .var "d3" }]), ([.sym "argument2"], [{ val := .var "pa" }])],
      .make (.var "w") [([.sym "above"], [{ val := .var "ab3" }])],
      .make (.var "ab3") [([.sym "argument1"], [{ val := .var "d3" }]), ([.sym "argument2"], [{ val := .var "ba" }])],
      .make (.var "w") [([.sym "on"], [{ val := .var "onba" }])],
      .make (.var "onba") [([.sym "argument1"], [{ val := .var "ba" }]), ([.sym "argument2"], [{ val := .var "pa" }])],
      .make (.var "w") [([.sym "on"], [{ val := .var "onbb" }])],
      .make (.var "onbb") [([.sym "argument1"], [{ val := .var "bb" }]), ([.sym "argument2"], [{ val := .var "pb" }])],
      .make (.var "w") [([.sym "on"], [{ val := .var "onbc" }])],
      .make (.var "onbc") [([.sym "argument1"], [{ val := .var "bc" }]), ([.sym "argument2"], [{ val := .var "pc" }])],
      .make (.var "w") [([.sym "clear"], [{ val := .var "c1" }, { val := .var "cb" }, { val := .var "cc" }])],
      .make (.var "c1") [([.sym "argument1"], [{ val := .var "d1" }])],
      .make (.var "cb") [([.sym "argument1"], [{ val := .var "bb" }])],
      .make (.var "cc") [([.sym "argument1"], [{ val := .var "bc" }])],
      .make (.var "ds") [([.sym "desired-count"], [{ val := .int (3) }]), ([.sym "desired"], [{ val := .var "g1" }, { val := .var "g2" }, { val := .var "g3" }])],
      .make (.var "g1") [([.sym "on"], [{ val := .var "gr1" }])],
      .make (.var "gr1") [([.sym "argument1"], [{ val := .var "ga1" }]), ([.sym "argument2"], [{ val := .var "gb1" }])],
      .make (.var "ga1") [([.sym "object-handle"], [{ val := .sym "d1" }])],
      .make (.var "gb1") [([.sym "object-handle"], [{ val := .sym "C" }])],
      .make (.var "g2") [([.sym "on"], [{ val := .var "gr2" }])],
      .make (.var "gr2") [([.sym "argument1"], [{ val := .var "ga2" }]), ([.sym "argument2"], [{ val := .var "gb2" }])],
      .make (.var "ga2") [([.sym "object-handle"], [{ val := .sym "d2" }])],
      .make (.var "gb2") [([.sym "object-handle"], [{ val := .sym "C" }])],
      .make (.var "g3") [([.sym "on"], [{ val := .var "gr3" }])],
      .make (.var "gr3") [([.sym "argument1"], [{ val := .var "ga3" }]), ([.sym "argument2"], [{ val := .var "gb3" }])],
      .make (.var "ga3") [([.sym "object-handle"], [{ val := .sym "d3" }])],
      .make (.var "gb3") [([.sym "object-handle"], [{ val := .sym "C" }])]],
              initFile := none, initOpExtra := [], achieve := [.relationState], achieveSpaces := [], indifferent := some "the original makes its proposals indifferent (in this algorithm only one move is ever proposed)", indifferentExcept := [], ancestors := false },
    files := [("elaborations.soar", [.ps, .achieve .relationState]),
              ("initialize-towers-of-hanoi.soar", [.init]),
              ("move-disc.soar", [.p r_towers_of_hanoi_propose_move_disc_smallest, .p r_towers_of_hanoi_propose_move_disc_other, .p r_towers_of_hanoi_apply_move_disc_control_smallest, .p r_towers_of_hanoi_apply_move_disc_control_other, .p r_towers_of_hanoi_apply_move_disc_internal]),
              ("search-control.soar", [.indifferent])] }

def v_towers_of_hanoi_mea : Variant :=
  { family := "towers-of-hanoi", name := "towers-of-hanoi-mea",
    about := ["Towers of Hanoi, 3 discs, A to C, by means-ends analysis: to move disc k to a peg, the smaller discs must first be on the third peg (operator subgoaling)."],
    firstload := ["chunk never"],
    task := { name := "towers-of-hanoi", psExtra := [], flags := [("mea-operator-selection", .sym "true")], environmentNone := true,
              initBody := [.make (.var "objs") [([.sym "object"], [{ val := .var "pa" }, { val := .var "pb" }, { val := .var "pc" }, { val := .var "d1" }, { val := .var "d2" }, { val := .var "d3" }, { val := .var "ba" }, { val := .var "bb" }, { val := .var "bc" }])],
      .make (.var "pa") [([.sym "object-handle"], [{ val := .sym "A" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "peg" }])],
      .make (.var "ba") [([.sym "object-handle"], [{ val := .sym "base-A" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "base" }]), ([.sym "size"], [{ val := .int (6) }])],
      .make (.var "pb") [([.sym "object-handle"], [{ val := .sym "B" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "peg" }])],
      .make (.var "bb") [([.sym "object-handle"], [{ val := .sym "base-B" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "base" }]), ([.sym "size"], [{ val := .int (6) }])],
      .make (.var "pc") [([.sym "object-handle"], [{ val := .sym "C" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "peg" }])],
      .make (.var "bc") [([.sym "object-handle"], [{ val := .sym "base-C" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "base" }]), ([.sym "size"], [{ val := .int (6) }])],
      .make (.var "d1") [([.sym "object-handle"], [{ val := .sym "d1" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "disc" }]), ([.sym "size"], [{ val := .int (1) }])],
      .make (.var "d2") [([.sym "object-handle"], [{ val := .sym "d2" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "disc" }]), ([.sym "size"], [{ val := .int (2) }])],
      .make (.var "d3") [([.sym "object-handle"], [{ val := .sym "d3" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "disc" }]), ([.sym "size"], [{ val := .int (3) }])],
      .make (.var "w") [([.sym "on"], [{ val := .var "on1" }])],
      .make (.var "on1") [([.sym "argument1"], [{ val := .var "d1" }]), ([.sym "argument2"], [{ val := .var "pa" }])],
      .make (.var "w") [([.sym "above"], [{ val := .var "ab1" }])],
      .make (.var "ab1") [([.sym "argument1"], [{ val := .var "d1" }]), ([.sym "argument2"], [{ val := .var "d2" }])],
      .make (.var "w") [([.sym "on"], [{ val := .var "on2" }])],
      .make (.var "on2") [([.sym "argument1"], [{ val := .var "d2" }]), ([.sym "argument2"], [{ val := .var "pa" }])],
      .make (.var "w") [([.sym "above"], [{ val := .var "ab2" }])],
      .make (.var "ab2") [([.sym "argument1"], [{ val := .var "d2" }]), ([.sym "argument2"], [{ val := .var "d3" }])],
      .make (.var "w") [([.sym "on"], [{ val := .var "on3" }])],
      .make (.var "on3") [([.sym "argument1"], [{ val := .var "d3" }]), ([.sym "argument2"], [{ val := .var "pa" }])],
      .make (.var "w") [([.sym "above"], [{ val := .var "ab3" }])],
      .make (.var "ab3") [([.sym "argument1"], [{ val := .var "d3" }]), ([.sym "argument2"], [{ val := .var "ba" }])],
      .make (.var "w") [([.sym "on"], [{ val := .var "onba" }])],
      .make (.var "onba") [([.sym "argument1"], [{ val := .var "ba" }]), ([.sym "argument2"], [{ val := .var "pa" }])],
      .make (.var "w") [([.sym "on"], [{ val := .var "onbb" }])],
      .make (.var "onbb") [([.sym "argument1"], [{ val := .var "bb" }]), ([.sym "argument2"], [{ val := .var "pb" }])],
      .make (.var "w") [([.sym "on"], [{ val := .var "onbc" }])],
      .make (.var "onbc") [([.sym "argument1"], [{ val := .var "bc" }]), ([.sym "argument2"], [{ val := .var "pc" }])],
      .make (.var "w") [([.sym "clear"], [{ val := .var "c1" }, { val := .var "cb" }, { val := .var "cc" }])],
      .make (.var "c1") [([.sym "argument1"], [{ val := .var "d1" }])],
      .make (.var "cb") [([.sym "argument1"], [{ val := .var "bb" }])],
      .make (.var "cc") [([.sym "argument1"], [{ val := .var "bc" }])],
      .make (.var "ds") [([.sym "desired-count"], [{ val := .int (3) }]), ([.sym "desired"], [{ val := .var "g1" }, { val := .var "g2" }, { val := .var "g3" }])],
      .make (.var "g1") [([.sym "on"], [{ val := .var "gr1" }])],
      .make (.var "gr1") [([.sym "argument1"], [{ val := .var "ga1" }]), ([.sym "argument2"], [{ val := .var "gb1" }])],
      .make (.var "ga1") [([.sym "object-handle"], [{ val := .sym "d1" }])],
      .make (.var "gb1") [([.sym "object-handle"], [{ val := .sym "C" }])],
      .make (.var "g2") [([.sym "on"], [{ val := .var "gr2" }])],
      .make (.var "gr2") [([.sym "argument1"], [{ val := .var "ga2" }]), ([.sym "argument2"], [{ val := .var "gb2" }])],
      .make (.var "ga2") [([.sym "object-handle"], [{ val := .sym "d2" }])],
      .make (.var "gb2") [([.sym "object-handle"], [{ val := .sym "C" }])],
      .make (.var "g3") [([.sym "on"], [{ val := .var "gr3" }])],
      .make (.var "gr3") [([.sym "argument1"], [{ val := .var "ga3" }]), ([.sym "argument2"], [{ val := .var "gb3" }])],
      .make (.var "ga3") [([.sym "object-handle"], [{ val := .sym "d3" }])],
      .make (.var "gb3") [([.sym "object-handle"], [{ val := .sym "C" }])]],
              initFile := none, initOpExtra := [], achieve := [.relationOperator, .relationState], achieveSpaces := [], indifferent := none, indifferentExcept := [], ancestors := false },
    files := [("elaborations.soar", [.ps, .achieve .relationOperator, .achieve .relationState]),
              ("initialize-towers-of-hanoi.soar", [.init]),
              ("move-disc.soar", [.p r_towers_of_hanoi_propose_move_disc_mea, .p r_towers_of_hanoi_elaborate_move_disc_aux_peg, .p r_towers_of_hanoi_elaborate_move_disc_preconditions, .p r_towers_of_hanoi_elaborate_move_disc_destination, .p r_towers_of_hanoi_apply_move_disc_internal, .p r_towers_of_hanoi_compare_move_disc_indifferent])] }

def variants : List Variant := [v_towers_of_hanoi, v_towers_of_hanoi_mea]

end Fam.Families.TowersOfHanoi
