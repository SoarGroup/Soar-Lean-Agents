import Family.Task
set_option maxHeartbeats 0
set_option maxRecDepth 100000
/-!
# water-jug: world-convention agents of the water-jug family

Typed description migrated on 19 November 2026 from the world-v6 agents (Tasks/Families/water-jug/world-v6),
which were written from the original programs. Task-level parts are `Task` fields; family knowledge is typed
productions, defined once and shared by the variants that use them.

Written 19 November 2026 by Claude, supervised by John E. Laird.
-/
namespace Fam.Families.WaterJug
open Fam

def r_water_jug_elaborate_jug_free : Prod :=
  { name := "water-jug*elaborate*jug*free",
    doc := ["Derived object attribute: room left in a jug.  i-supported, so listed as ^dont-copy-object-attribute", "on the problem space (W-SEL-009)."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "water-jug"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "objects", .sym "object"], vals := [.var "j"] }],
        .pos false (.var "j") [{ path := [.sym "type"], vals := [.sym "jug"] }, { path := [.sym "volume"], vals := [.var "v"] }, { path := [.sym "contents"], vals := [.var "c"] }]],
    acts := [.make (.var "j") [([.sym "free"], [{ val := .fn "-" [.var "v", .var "c"] }])]] }

def r_water_jug_propose_fill : Prod :=
  { name := "water-jug*propose*fill",
    doc := ["fill <jug>: legal when the jug is not full."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "water-jug"] }, { path := [.sym "flags", .sym "mea-operator-selection"], vals := [.sym "true"] }, { path := [.sym "desireds", .sym "unachieved-desireds"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "j"] }],
        .pos false (.var "j") [{ path := [.sym "type"], vals := [.sym "jug"] }, { path := [.sym "free"], vals := [.cmp ">" (.int (0))] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "fill" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "action-handle"], [{ val := .sym "fill" }]), ([.sym "argument1"], [{ val := .var "j" }]), ([.sym "argument-count"], [{ val := .int (1) }]), ([.sym "desireds"], [{ val := .var "pre" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (0) }])]] }

def r_water_jug_apply_fill_internal : Prod :=
  { name := "water-jug*apply*fill*internal",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "water-jug"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "internal-actions"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "fill"] }, { path := [.sym "pre-conditions-satisfied"], vals := [.sym "true"] }, { path := [.sym "argument1", .sym "object-handle"], vals := [.lit (.var "h")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "j"] }],
        .pos false (.var "j") [{ path := [.sym "object-handle"], vals := [.lit (.var "h")] }, { path := [.sym "volume"], vals := [.var "v"] }, { path := [.sym "contents"], vals := [.var "c"] }]],
    acts := [.call "log" [.int (1), .fn "crlf" [], .str "Apply fill: ", .var "h"],
        .make (.var "j") [([.sym "contents"], [{ val := .var "c", pref := "-" }, { val := .var "v" }])]] }

def r_water_jug_propose_empty : Prod :=
  { name := "water-jug*propose*empty",
    doc := ["empty <jug>: legal when the jug has contents."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "water-jug"] }, { path := [.sym "flags", .sym "mea-operator-selection"], vals := [.sym "true"] }, { path := [.sym "desireds", .sym "unachieved-desireds"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "j"] }],
        .pos false (.var "j") [{ path := [.sym "type"], vals := [.sym "jug"] }, { path := [.sym "contents"], vals := [.cmp ">" (.int (0))] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "empty" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "action-handle"], [{ val := .sym "empty" }]), ([.sym "argument1"], [{ val := .var "j" }]), ([.sym "argument-count"], [{ val := .int (1) }]), ([.sym "desireds"], [{ val := .var "pre" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (0) }])]] }

def r_water_jug_apply_empty_internal : Prod :=
  { name := "water-jug*apply*empty*internal",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "water-jug"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "internal-actions"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "empty"] }, { path := [.sym "pre-conditions-satisfied"], vals := [.sym "true"] }, { path := [.sym "argument1", .sym "object-handle"], vals := [.lit (.var "h")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "j"] }],
        .pos false (.var "j") [{ path := [.sym "object-handle"], vals := [.lit (.var "h")] }, { path := [.sym "contents"], vals := [.var "c"] }]],
    acts := [.call "log" [.int (1), .fn "crlf" [], .str "Apply empty: ", .var "h"],
        .make (.var "j") [([.sym "contents"], [{ val := .var "c", pref := "-" }, { val := .int (0) }])]] }

def r_water_jug_propose_pour : Prod :=
  { name := "water-jug*propose*pour",
    doc := ["pour <from> <to>: legal when <from> has contents and <to> is not full."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "water-jug"] }, { path := [.sym "flags", .sym "mea-operator-selection"], vals := [.sym "true"] }, { path := [.sym "desireds", .sym "unachieved-desireds"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "from", .conj [.cmp "<>" (.var "from"), .var "to"]] }],
        .pos false (.var "from") [{ path := [.sym "type"], vals := [.sym "jug"] }, { path := [.sym "contents"], vals := [.cmp ">" (.int (0))] }],
        .pos false (.var "to") [{ path := [.sym "type"], vals := [.sym "jug"] }, { path := [.sym "free"], vals := [.cmp ">" (.int (0))] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "pour" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "action-handle"], [{ val := .sym "pour" }]), ([.sym "argument1"], [{ val := .var "from" }]), ([.sym "argument2"], [{ val := .var "to" }]), ([.sym "argument-count"], [{ val := .int (2) }]), ([.sym "desireds"], [{ val := .var "pre" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (0) }])]] }

def r_water_jug_apply_pour_internal_overflow : Prod :=
  { name := "water-jug*apply*pour*internal*overflow",
    doc := ["<from> holds more than <to> can take: <to> becomes full."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "water-jug"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "internal-actions"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "pour"] }, { path := [.sym "pre-conditions-satisfied"], vals := [.sym "true"] }, { path := [.sym "argument1", .sym "object-handle"], vals := [.lit (.var "fh")] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.lit (.var "th")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "from", .var "to"] }],
        .pos false (.var "from") [{ path := [.sym "object-handle"], vals := [.lit (.var "fh")] }, { path := [.sym "contents"], vals := [.var "fc"] }],
        .pos false (.var "to") [{ path := [.sym "object-handle"], vals := [.lit (.var "th")] }, { path := [.sym "contents"], vals := [.var "tc"] }, { path := [.sym "volume"], vals := [.var "tv"] }, { path := [.sym "free"], vals := [.conj [.cmp "<" (.var "fc"), .var "tf"]] }]],
    acts := [.call "log" [.int (1), .fn "crlf" [], .str "Apply pour: ", .var "fh", .str " -> ", .var "th"],
        .make (.var "from") [([.sym "contents"], [{ val := .var "fc", pref := "-" }, { val := .fn "-" [.var "fc", .var "tf"] }])],
        .make (.var "to") [([.sym "contents"], [{ val := .var "tc", pref := "-" }, { val := .var "tv" }])]] }

def r_water_jug_apply_pour_internal_fits : Prod :=
  { name := "water-jug*apply*pour*internal*fits",
    doc := ["<to> can take everything in <from>: <from> becomes empty."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "water-jug"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "internal-actions"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "pour"] }, { path := [.sym "pre-conditions-satisfied"], vals := [.sym "true"] }, { path := [.sym "argument1", .sym "object-handle"], vals := [.lit (.var "fh")] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.lit (.var "th")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "from", .var "to"] }],
        .pos false (.var "from") [{ path := [.sym "object-handle"], vals := [.lit (.var "fh")] }, { path := [.sym "contents"], vals := [.var "fc"] }],
        .pos false (.var "to") [{ path := [.sym "object-handle"], vals := [.lit (.var "th")] }, { path := [.sym "contents"], vals := [.var "tc"] }, { path := [.sym "free"], vals := [.cmp ">=" (.var "fc")] }]],
    acts := [.call "log" [.int (1), .fn "crlf" [], .str "Apply pour: ", .var "fh", .str " -> ", .var "th"],
        .make (.var "from") [([.sym "contents"], [{ val := .var "fc", pref := "-" }, { val := .int (0) }])],
        .make (.var "to") [([.sym "contents"], [{ val := .var "tc", pref := "-" }, { val := .fn "+" [.var "tc", .var "fc"] }])]] }

def r_water_jug_elaborate_fill_relevant_not_full : Prod :=
  { name := "water-jug*elaborate*fill-relevant*not-full",
    doc := ["fill <jug> (composite, W-COP-002) is relevant when the jug is not full, or full and still held.  As in the", "original, both cases support one state WME, so the fill operator stays selected from pick-up to put-down.", "Effect: the jug is full and the hand is empty.  No application rule: the proposal retracts once the", "effect holds (W-COP-003, W-COP-005)."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "water-jug"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "j"] }],
        .pos false (.var "j") [{ path := [.sym "type"], vals := [.sym "jug"] }, { path := [.sym "free"], vals := [.cmp ">" (.int (0))] }]],
    acts := [.make (.var "s") [([.sym "fill-relevant"], [{ val := .var "j" }])]] }

def r_water_jug_elaborate_fill_relevant_held : Prod :=
  { name := "water-jug*elaborate*fill-relevant*held",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "water-jug"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "j", .var "hand"] }],
        .pos false (.var "j") [{ path := [.sym "type"], vals := [.sym "jug"] }, { path := [.sym "free"], vals := [.cmp "<=" (.int (0))] }, { path := [.sym "object-handle"], vals := [.lit (.var "h")] }],
        .pos false (.var "hand") [{ path := [.sym "type"], vals := [.sym "hand"] }, { path := [.sym "holding"], vals := [.lit (.var "h")] }]],
    acts := [.make (.var "s") [([.sym "fill-relevant"], [{ val := .var "j" }])]] }

def r_water_jug_propose_fill_2 : Prod :=
  { name := "water-jug*propose*fill",
    doc := ["Propose fill in problem space water-jug when its conditions below hold."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "water-jug"] }, { path := [.sym "flags", .sym "mea-operator-selection"], vals := [.sym "true"] }, { path := [.sym "desireds", .sym "unachieved-desireds"], vals := [.sym "true"] }, { path := [.sym "fill-relevant"], vals := [.var "j"] }],
        .pos false (.var "j") [{ path := [.sym "object-handle"], vals := [.lit (.var "h")] }, { path := [.sym "volume"], vals := [.var "v"] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "fill" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "argument1"], [{ val := .var "j" }]), ([.sym "argument-count"], [{ val := .int (1) }]), ([.sym "desireds"], [{ val := .var "pre" }]), ([.sym "effect-desireds"], [{ val := .var "ed" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (0) }])],
        .make (.var "ed") [([.sym "desired-count"], [{ val := .int (2) }]), ([.sym "desired"], [{ val := .var "e1" }, { val := .var "e2" }])],
        .make (.var "e1") [([.sym "object"], [{ val := .var "e1o" }])],
        .make (.var "e1o") [([.sym "object-handle"], [{ val := .var "h" }]), ([.sym "contents"], [{ val := .var "v" }])],
        .make (.var "e2") [([.sym "object"], [{ val := .var "e2o" }])],
        .make (.var "e2o") [([.sym "object-handle"], [{ val := .sym "hand" }]), ([.sym "holding"], [{ val := .sym "none" }])]] }

def r_water_jug_propose_pick_up : Prod :=
  { name := "water-jug*propose*pick-up",
    doc := ["Implementation substate of fill (^problem-space.name fill, ^argument1 = the jug; W-COP-007, W-SUB-005)."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "fill"] }, { path := [.sym "argument1"], vals := [.var "j"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "j") [{ path := [.sym "object-handle"], vals := [.lit (.var "h")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "hand"] }],
        .pos false (.var "hand") [{ path := [.sym "type"], vals := [.sym "hand"] }, { path := [.sym "holding"], vals := [.sym "none"] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "pick-up" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "action-handle"], [{ val := .sym "pick-up" }]), ([.sym "argument1"], [{ val := .var "j" }]), ([.sym "argument-count"], [{ val := .int (1) }]), ([.sym "desireds"], [{ val := .var "pre" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (0) }])]] }

def r_water_jug_apply_pick_up_internal : Prod :=
  { name := "water-jug*apply*pick-up*internal",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "fill"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "internal-actions"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "pick-up"] }, { path := [.sym "pre-conditions-satisfied"], vals := [.sym "true"] }, { path := [.sym "argument1", .sym "object-handle"], vals := [.lit (.var "h")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "hand"] }],
        .pos false (.var "hand") [{ path := [.sym "type"], vals := [.sym "hand"] }, { path := [.sym "holding"], vals := [.sym "none"] }]],
    acts := [.call "log" [.int (1), .fn "crlf" [], .str "Apply pick-up: ", .var "h"],
        .make (.var "hand") [([.sym "holding"], [{ val := .sym "none", pref := "-" }, { val := .var "h" }])]] }

def r_water_jug_propose_fill_jug : Prod :=
  { name := "water-jug*propose*fill-jug",
    doc := ["Propose fill-jug in problem space fill when its conditions below hold."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "fill"] }, { path := [.sym "argument1"], vals := [.var "j"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "j") [{ path := [.sym "object-handle"], vals := [.lit (.var "h")] }, { path := [.sym "free"], vals := [.cmp ">" (.int (0))] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "hand"] }],
        .pos false (.var "hand") [{ path := [.sym "type"], vals := [.sym "hand"] }, { path := [.sym "holding"], vals := [.lit (.var "h")] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "fill-jug" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "action-handle"], [{ val := .sym "fill-jug" }]), ([.sym "argument1"], [{ val := .var "j" }]), ([.sym "argument-count"], [{ val := .int (1) }]), ([.sym "desireds"], [{ val := .var "pre" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (0) }])]] }

def r_water_jug_apply_fill_jug_internal : Prod :=
  { name := "water-jug*apply*fill-jug*internal",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "fill"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "internal-actions"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "fill-jug"] }, { path := [.sym "pre-conditions-satisfied"], vals := [.sym "true"] }, { path := [.sym "argument1", .sym "object-handle"], vals := [.lit (.var "h")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "j"] }],
        .pos false (.var "j") [{ path := [.sym "object-handle"], vals := [.lit (.var "h")] }, { path := [.sym "volume"], vals := [.var "v"] }, { path := [.sym "contents"], vals := [.var "c"] }]],
    acts := [.call "log" [.int (1), .fn "crlf" [], .str "Apply fill-jug: ", .var "h"],
        .make (.var "j") [([.sym "contents"], [{ val := .var "c", pref := "-" }, { val := .var "v" }])]] }

def r_water_jug_propose_put_down : Prod :=
  { name := "water-jug*propose*put-down",
    doc := ["Propose put-down in problem space fill when its conditions below hold."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "fill"] }, { path := [.sym "argument1"], vals := [.var "j"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "j") [{ path := [.sym "object-handle"], vals := [.lit (.var "h")] }, { path := [.sym "free"], vals := [.cmp "<=" (.int (0))] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "hand"] }],
        .pos false (.var "hand") [{ path := [.sym "type"], vals := [.sym "hand"] }, { path := [.sym "holding"], vals := [.lit (.var "h")] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "put-down" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "action-handle"], [{ val := .sym "put-down" }]), ([.sym "argument1"], [{ val := .var "j" }]), ([.sym "argument-count"], [{ val := .int (1) }]), ([.sym "desireds"], [{ val := .var "pre" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (0) }])]] }

def r_water_jug_apply_put_down_internal : Prod :=
  { name := "water-jug*apply*put-down*internal",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "fill"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "internal-actions"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "put-down"] }, { path := [.sym "pre-conditions-satisfied"], vals := [.sym "true"] }, { path := [.sym "argument1", .sym "object-handle"], vals := [.lit (.var "h")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "hand"] }],
        .pos false (.var "hand") [{ path := [.sym "type"], vals := [.sym "hand"] }, { path := [.sym "holding"], vals := [.lit (.var "h")] }]],
    acts := [.call "log" [.int (1), .fn "crlf" [], .str "Apply put-down: ", .var "h"],
        .make (.var "hand") [([.sym "holding"], [{ val := .var "h", pref := "-" }, { val := .sym "none" }])]] }

def r_water_jug_compare_fill_implementation_indifferent : Prod :=
  { name := "water-jug*compare*fill-implementation*indifferent",
    doc := ["The original makes the implementation operators indifferent (only one is ever proposed)."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "fill"] }, { path := [.sym "operator"], vals := [.var "o", .sym "+"] }],
        .pos false (.var "o") [{ path := [.sym "task-operator"], vals := [.sym "true"] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "=" }])]] }

def r_water_jug_elaborate_look_ahead_duplicate : Prod :=
  { name := "water-jug*elaborate*look-ahead*duplicate",
    doc := ["Look-ahead: a state whose jug contents equal those of an ancestor task state is a partial failure", "(original: water-jug*evaluate*state*failure*duplicate; W-DES-001 outcome on the state's own desireds)."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "water-jug"] }, { path := [.sym "tried-tied-operator"], vals := [.var "any"] }, { path := [.sym "desireds"], vals := [.var "ds"] }, { path := [.sym "world"], vals := [.var "w"] }, { path := [.sym "ancestor-world"], vals := [.var "aw"] }],
        .pos false (.var "w") [{ path := [.sym "objects", .sym "object"], vals := [.var "a3", .var "a5"] }],
        .pos false (.var "a3") [{ path := [.sym "object-handle"], vals := [.lit (.sym "jug3")] }, { path := [.sym "contents"], vals := [.var "c3"] }],
        .pos false (.var "a5") [{ path := [.sym "object-handle"], vals := [.lit (.sym "jug5")] }, { path := [.sym "contents"], vals := [.var "c5"] }],
        .pos false (.var "aw") [{ path := [.sym "objects", .sym "object"], vals := [.var "b3", .var "b5"] }],
        .pos false (.var "b3") [{ path := [.sym "object-handle"], vals := [.lit (.sym "jug3")] }, { path := [.sym "contents"], vals := [.var "c3"] }],
        .pos false (.var "b5") [{ path := [.sym "object-handle"], vals := [.lit (.sym "jug5")] }, { path := [.sym "contents"], vals := [.var "c5"] }]],
    acts := [.make (.var "s") [([.sym "partial-failure"], [{ val := .var "ds" }])]] }

def r_water_jug_elaborate_look_ahead_avoid_1 : Prod :=
  { name := "water-jug*elaborate*look-ahead*avoid*1",
    doc := ["Look-ahead: jug contents 3-5 is a known dead end (original: water-jug*evaluate*state*avoid*1)."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "water-jug"] }, { path := [.sym "tried-tied-operator"], vals := [.var "any"] }, { path := [.sym "desireds"], vals := [.var "ds"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "objects", .sym "object"], vals := [.var "a3", .var "a5"] }],
        .pos false (.var "a3") [{ path := [.sym "object-handle"], vals := [.lit (.sym "jug3")] }, { path := [.sym "contents"], vals := [.int (3)] }],
        .pos false (.var "a5") [{ path := [.sym "object-handle"], vals := [.lit (.sym "jug5")] }, { path := [.sym "contents"], vals := [.int (5)] }]],
    acts := [.make (.var "s") [([.sym "partial-failure"], [{ val := .var "ds" }])]] }

def r_water_jug_elaborate_look_ahead_avoid_2 : Prod :=
  { name := "water-jug*elaborate*look-ahead*avoid*2",
    doc := ["Look-ahead: jug contents 0-0 is a known dead end (original: water-jug*evaluate*state*avoid*2)."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "water-jug"] }, { path := [.sym "tried-tied-operator"], vals := [.var "any"] }, { path := [.sym "desireds"], vals := [.var "ds"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "objects", .sym "object"], vals := [.var "a3", .var "a5"] }],
        .pos false (.var "a3") [{ path := [.sym "object-handle"], vals := [.lit (.sym "jug3")] }, { path := [.sym "contents"], vals := [.int (0)] }],
        .pos false (.var "a5") [{ path := [.sym "object-handle"], vals := [.lit (.sym "jug5")] }, { path := [.sym "contents"], vals := [.int (0)] }]],
    acts := [.make (.var "s") [([.sym "partial-failure"], [{ val := .var "ds" }])]] }

def r_water_jug_elaborate_look_ahead_avoid_1_2 : Prod :=
  { name := "water-jug*elaborate*look-ahead*avoid*1",
    doc := ["Look-ahead: jug contents 3-5 is a known dead end (original: water-jug*evaluate*state*avoid*1)."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "water-jug"] }, { path := [.sym "tried-tied-operator"], vals := [.var "any"] }, { path := [.sym "desireds"], vals := [.var "ds"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "objects", .sym "object"], vals := [.var "a3", .var "a5"] }],
        .pos false (.var "a3") [{ path := [.sym "object-handle"], vals := [.lit (.sym "jug3")] }, { path := [.sym "contents"], vals := [.int (3)] }],
        .pos false (.var "a5") [{ path := [.sym "object-handle"], vals := [.lit (.sym "jug5")] }, { path := [.sym "contents"], vals := [.int (5)] }]],
    acts := [.make (.var "s") [([.sym "expected-value"], [{ val := .int (-1) }])]] }

def r_water_jug_elaborate_look_ahead_avoid_2_2 : Prod :=
  { name := "water-jug*elaborate*look-ahead*avoid*2",
    doc := ["Look-ahead: jug contents 0-0 is a known dead end (original: water-jug*evaluate*state*avoid*2)."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "water-jug"] }, { path := [.sym "tried-tied-operator"], vals := [.var "any"] }, { path := [.sym "desireds"], vals := [.var "ds"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "objects", .sym "object"], vals := [.var "a3", .var "a5"] }],
        .pos false (.var "a3") [{ path := [.sym "object-handle"], vals := [.lit (.sym "jug3")] }, { path := [.sym "contents"], vals := [.int (0)] }],
        .pos false (.var "a5") [{ path := [.sym "object-handle"], vals := [.lit (.sym "jug5")] }, { path := [.sym "contents"], vals := [.int (0)] }]],
    acts := [.make (.var "s") [([.sym "expected-value"], [{ val := .int (-1) }])]] }

def r_water_jug_rl_fill : Prod :=
  { name := "water-jug*rl*fill",
    doc := ["RL template (RL-007): Q-value of fill for the jug's volume and contents."],
    flags := [":template"],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "water-jug"] }, { path := [.sym "operator"], vals := [.var "o", .sym "+"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "fill"] }, { path := [.sym "argument1"], vals := [.var "j"] }],
        .pos false (.var "j") [{ path := [.sym "volume"], vals := [.var "v"] }, { path := [.sym "contents"], vals := [.var "c"] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "= 0" }])]] }

def r_water_jug_rl_empty : Prod :=
  { name := "water-jug*rl*empty",
    doc := ["RL template (RL-007): Q-value of empty for the jug's volume and contents."],
    flags := [":template"],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "water-jug"] }, { path := [.sym "operator"], vals := [.var "o", .sym "+"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "empty"] }, { path := [.sym "argument1"], vals := [.var "j"] }],
        .pos false (.var "j") [{ path := [.sym "volume"], vals := [.var "v"] }, { path := [.sym "contents"], vals := [.var "c"] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "= 0" }])]] }

def r_water_jug_rl_pour : Prod :=
  { name := "water-jug*rl*pour",
    doc := ["RL rule template for pour in problem space water-jug: one numeric-indifferent value per state-operator pair."],
    flags := [":template"],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "water-jug"] }, { path := [.sym "operator"], vals := [.var "o", .sym "+"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "pour"] }, { path := [.sym "argument1"], vals := [.var "from"] }, { path := [.sym "argument2"], vals := [.var "to"] }],
        .pos false (.var "from") [{ path := [.sym "volume"], vals := [.var "fv"] }, { path := [.sym "contents"], vals := [.var "fc"] }],
        .pos false (.var "to") [{ path := [.sym "volume"], vals := [.var "tv"] }, { path := [.sym "contents"], vals := [.var "tc"] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "= 0" }])]] }

def r_water_jug_elaborate_reward_both_empty : Prod :=
  { name := "water-jug*elaborate*reward*both-empty",
    doc := ["Reward -1 when both jugs are empty (original water-jug*reward*1).  The +1 reward for reaching the goal", "comes from agent-world with ^flags.rl true (W-CHK-001), replacing the original's water-jug*reward*2."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "water-jug"] }, { path := [.sym "reward-link"], vals := [.var "r"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "a3", .var "a5"] }],
        .pos false (.var "a3") [{ path := [.sym "object-handle"], vals := [.lit (.sym "jug3")] }, { path := [.sym "contents"], vals := [.int (0)] }],
        .pos false (.var "a5") [{ path := [.sym "object-handle"], vals := [.lit (.sym "jug5")] }, { path := [.sym "contents"], vals := [.int (0)] }]],
    acts := [.make (.var "r") [([.sym "reward"], [{ val := .var "rw" }])],
        .make (.var "rw") [([.sym "value"], [{ val := .int (-1) }])]] }

def r_water_jug_apply_task_operator_record_last : Prod :=
  { name := "water-jug*apply*task-operator*record-last",
    doc := ["The last task operator applied is kept on a memory object in the world (spec section 2: mutable", "bookkeeping lives on a world object)."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "water-jug"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "task-operator"], vals := [.sym "true"] }, { path := [.sym "pre-conditions-satisfied"], vals := [.sym "true"] }, { path := [.sym "name"], vals := [.var "n"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "m"] }],
        .pos false (.var "m") [{ path := [.sym "type"], vals := [.sym "memory"] }, { path := [.sym "last-operator"], vals := [.conj [.cmp "<>" (.var "n"), .var "l"]] }]],
    acts := [.make (.var "m") [([.sym "last-operator"], [{ val := .var "l", pref := "-" }, { val := .var "n" }])]] }

def r_water_jug_compare_first_move_indifferent : Prod :=
  { name := "water-jug*compare*first-move*indifferent",
    doc := ["Original tie heuristics (Impasse__Operator_Tie, evaluate-operator h1 to h5), as preferences:", "h1: nothing done yet: all operators equal."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "water-jug"] }, { path := [.sym "operator"], vals := [.var "o", .sym "+"] }, { path := [.sym "world", .sym "objects", .sym "object"], vals := [.var "m"] }],
        .pos false (.var "m") [{ path := [.sym "type"], vals := [.sym "memory"] }, { path := [.sym "last-operator"], vals := [.sym "none"] }],
        .pos false (.var "o") [{ path := [.sym "task-operator"], vals := [.sym "true"] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "=" }])]] }

def r_water_jug_compare_after_pour : Prod :=
  { name := "water-jug*compare*after-pour",
    doc := ["h2, h3: after pour, fill and empty are equal and pour is worst."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "water-jug"] }, { path := [.sym "operator"], vals := [.var "o", .sym "+"] }, { path := [.sym "world", .sym "objects", .sym "object"], vals := [.var "m"] }],
        .pos false (.var "m") [{ path := [.sym "type"], vals := [.sym "memory"] }, { path := [.sym "last-operator"], vals := [.sym "pour"] }],
        .pos false (.var "o") [{ path := [.sym "task-operator"], vals := [.sym "true"] }, { path := [.sym "name"], vals := [.var "n"] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "=" }])]] }

def r_water_jug_compare_after_pour_pour_worst : Prod :=
  { name := "water-jug*compare*after-pour*pour-worst",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "water-jug"] }, { path := [.sym "operator"], vals := [.var "o", .sym "+"] }, { path := [.sym "world", .sym "objects", .sym "object"], vals := [.var "m"] }],
        .pos false (.var "m") [{ path := [.sym "type"], vals := [.sym "memory"] }, { path := [.sym "last-operator"], vals := [.sym "pour"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "pour"] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "<" }])]] }

def r_water_jug_compare_after_fill_empty : Prod :=
  { name := "water-jug*compare*after-fill-empty",
    doc := ["h4, h5: after fill or empty, pour is best and fill and empty are worst."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "water-jug"] }, { path := [.sym "operator"], vals := [.var "o", .sym "+"] }, { path := [.sym "world", .sym "objects", .sym "object"], vals := [.var "m"] }],
        .pos false (.var "m") [{ path := [.sym "type"], vals := [.sym "memory"] }, { path := [.sym "last-operator"], vals := [.disj [.sym "fill", .sym "empty"]] }],
        .pos false (.var "o") [{ path := [.sym "task-operator"], vals := [.sym "true"] }, { path := [.sym "name"], vals := [.var "n"] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "=" }])]] }

def r_water_jug_compare_after_fill_empty_pour_best : Prod :=
  { name := "water-jug*compare*after-fill-empty*pour-best",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "water-jug"] }, { path := [.sym "operator"], vals := [.var "o", .sym "+"] }, { path := [.sym "world", .sym "objects", .sym "object"], vals := [.var "m"] }],
        .pos false (.var "m") [{ path := [.sym "type"], vals := [.sym "memory"] }, { path := [.sym "last-operator"], vals := [.disj [.sym "fill", .sym "empty"]] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "pour"] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := ">" }])]] }

def r_water_jug_compare_after_fill_empty_fill_empty_worst : Prod :=
  { name := "water-jug*compare*after-fill-empty*fill-empty-worst",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "water-jug"] }, { path := [.sym "operator"], vals := [.var "o", .sym "+"] }, { path := [.sym "world", .sym "objects", .sym "object"], vals := [.var "m"] }],
        .pos false (.var "m") [{ path := [.sym "type"], vals := [.sym "memory"] }, { path := [.sym "last-operator"], vals := [.disj [.sym "fill", .sym "empty"]] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.disj [.sym "fill", .sym "empty"]] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "<" }])]] }

def v_water_jug : Variant :=
  { family := "water-jug", name := "water-jug",
    about := ["Water jug: 3 and 5 litre jugs, empty; get 1 litre in the 3-litre jug. Random choice of moves."],
    firstload := ["chunk never"],
    task := { name := "water-jug", psExtra := [([.sym "dont-copy-object-attribute"], [{ val := .sym "free" }])], flags := [("mea-operator-selection", .sym "true")], environmentNone := true,
              initBody := [.make (.var "objs") [([.sym "object"], [{ val := .var "j3" }, { val := .var "j5" }])],
      .make (.var "j3") [([.sym "object-handle"], [{ val := .sym "jug3" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "jug" }]), ([.sym "volume"], [{ val := .int (3) }]), ([.sym "contents"], [{ val := .int (0) }])],
      .make (.var "j5") [([.sym "object-handle"], [{ val := .sym "jug5" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "jug" }]), ([.sym "volume"], [{ val := .int (5) }]), ([.sym "contents"], [{ val := .int (0) }])],
      .make (.var "ds") [([.sym "desired-count"], [{ val := .int (1) }]), ([.sym "desired"], [{ val := .var "d1" }])],
      .make (.var "d1") [([.sym "object"], [{ val := .var "d1o" }])],
      .make (.var "d1o") [([.sym "object-handle"], [{ val := .sym "jug3" }]), ([.sym "contents"], [{ val := .int (1) }])]],
              initFile := none, initOpExtra := [], achieve := [.objectState], achieveSpaces := [], indifferent := some "the original selects among its task operators at random", indifferentExcept := [], ancestors := false },
    files := [("elaborations.soar", [.ps, .p r_water_jug_elaborate_jug_free, .achieve .objectState]),
              ("initialize-water-jug.soar", [.init]),
              ("fill.soar", [.p r_water_jug_propose_fill, .p r_water_jug_apply_fill_internal]),
              ("empty.soar", [.p r_water_jug_propose_empty, .p r_water_jug_apply_empty_internal]),
              ("pour.soar", [.p r_water_jug_propose_pour, .p r_water_jug_apply_pour_internal_overflow, .p r_water_jug_apply_pour_internal_fits]),
              ("search-control.soar", [.indifferent])] }

def v_water_jug_hierarchy : Variant :=
  { family := "water-jug", name := "water-jug-hierarchy",
    about := ["Water jug with fill as a composite operator (pick-up, fill-jug, put-down in a substate). Random choice of moves."],
    firstload := ["chunk never"],
    task := { name := "water-jug", psExtra := [([.sym "dont-copy-object-attribute"], [{ val := .sym "free" }])], flags := [("mea-operator-selection", .sym "true")], environmentNone := true,
              initBody := [.make (.var "objs") [([.sym "object"], [{ val := .var "j3" }, { val := .var "j5" }, { val := .var "hand" }])],
      .make (.var "hand") [([.sym "object-handle"], [{ val := .sym "hand" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "hand" }]), ([.sym "holding"], [{ val := .sym "none" }])],
      .make (.var "j3") [([.sym "object-handle"], [{ val := .sym "jug3" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "jug" }]), ([.sym "volume"], [{ val := .int (3) }]), ([.sym "contents"], [{ val := .int (0) }])],
      .make (.var "j5") [([.sym "object-handle"], [{ val := .sym "jug5" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "jug" }]), ([.sym "volume"], [{ val := .int (5) }]), ([.sym "contents"], [{ val := .int (0) }])],
      .make (.var "ds") [([.sym "desired-count"], [{ val := .int (1) }]), ([.sym "desired"], [{ val := .var "d1" }])],
      .make (.var "d1") [([.sym "object"], [{ val := .var "d1o" }])],
      .make (.var "d1o") [([.sym "object-handle"], [{ val := .sym "jug3" }]), ([.sym "contents"], [{ val := .int (1) }])]],
              initFile := none, initOpExtra := [], achieve := [.objectState], achieveSpaces := [], indifferent := some "the original selects among its task operators at random", indifferentExcept := [], ancestors := false },
    files := [("elaborations.soar", [.ps, .p r_water_jug_elaborate_jug_free, .achieve .objectState]),
              ("initialize-water-jug.soar", [.init]),
              ("empty.soar", [.p r_water_jug_propose_empty, .p r_water_jug_apply_empty_internal]),
              ("pour.soar", [.p r_water_jug_propose_pour, .p r_water_jug_apply_pour_internal_overflow, .p r_water_jug_apply_pour_internal_fits]),
              ("fill.soar", [.p r_water_jug_elaborate_fill_relevant_not_full, .p r_water_jug_elaborate_fill_relevant_held, .p r_water_jug_propose_fill_2, .p r_water_jug_propose_pick_up, .p r_water_jug_apply_pick_up_internal, .p r_water_jug_propose_fill_jug, .p r_water_jug_apply_fill_jug_internal, .p r_water_jug_propose_put_down, .p r_water_jug_apply_put_down_internal, .p r_water_jug_compare_fill_implementation_indifferent]),
              ("search-control.soar", [.indifferent])] }

def v_water_jug_hierarchy_chunk : Variant :=
  { family := "water-jug", name := "water-jug-hierarchy-chunk",
    about := ["Water jug with fill as a composite operator (pick-up, fill-jug, put-down in a substate). Random choice of moves."],
    firstload := ["chunk always", "chunk add-osk on"],
    task := { name := "water-jug", psExtra := [([.sym "dont-copy-object-attribute"], [{ val := .sym "free" }])], flags := [("mea-operator-selection", .sym "true")], environmentNone := true,
              initBody := [.make (.var "objs") [([.sym "object"], [{ val := .var "j3" }, { val := .var "j5" }, { val := .var "hand" }])],
      .make (.var "hand") [([.sym "object-handle"], [{ val := .sym "hand" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "hand" }]), ([.sym "holding"], [{ val := .sym "none" }])],
      .make (.var "j3") [([.sym "object-handle"], [{ val := .sym "jug3" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "jug" }]), ([.sym "volume"], [{ val := .int (3) }]), ([.sym "contents"], [{ val := .int (0) }])],
      .make (.var "j5") [([.sym "object-handle"], [{ val := .sym "jug5" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "jug" }]), ([.sym "volume"], [{ val := .int (5) }]), ([.sym "contents"], [{ val := .int (0) }])],
      .make (.var "ds") [([.sym "desired-count"], [{ val := .int (1) }]), ([.sym "desired"], [{ val := .var "d1" }])],
      .make (.var "d1") [([.sym "object"], [{ val := .var "d1o" }])],
      .make (.var "d1o") [([.sym "object-handle"], [{ val := .sym "jug3" }]), ([.sym "contents"], [{ val := .int (1) }])]],
              initFile := none, initOpExtra := [], achieve := [.objectState], achieveSpaces := [], indifferent := some "the original selects among its task operators at random", indifferentExcept := [], ancestors := false },
    files := [("elaborations.soar", [.ps, .p r_water_jug_elaborate_jug_free, .achieve .objectState]),
              ("initialize-water-jug.soar", [.init]),
              ("empty.soar", [.p r_water_jug_propose_empty, .p r_water_jug_apply_empty_internal]),
              ("pour.soar", [.p r_water_jug_propose_pour, .p r_water_jug_apply_pour_internal_overflow, .p r_water_jug_apply_pour_internal_fits]),
              ("fill.soar", [.p r_water_jug_elaborate_fill_relevant_not_full, .p r_water_jug_elaborate_fill_relevant_held, .p r_water_jug_propose_fill_2, .p r_water_jug_propose_pick_up, .p r_water_jug_apply_pick_up_internal, .p r_water_jug_propose_fill_jug, .p r_water_jug_apply_fill_jug_internal, .p r_water_jug_propose_put_down, .p r_water_jug_apply_put_down_internal, .p r_water_jug_compare_fill_implementation_indifferent]),
              ("search-control.soar", [.indifferent])] }

def v_water_jug_look_ahead : Variant :=
  { family := "water-jug", name := "water-jug-look-ahead",
    about := ["Water jug solved by look-ahead; a state that repeats an ancestor is a partial failure."],
    firstload := ["chunk always", "chunk add-osk on"],
    task := { name := "water-jug", psExtra := [([.sym "dont-copy-object-attribute"], [{ val := .sym "free" }])], flags := [("mea-operator-selection", .sym "true")], environmentNone := true,
              initBody := [.make (.var "objs") [([.sym "object"], [{ val := .var "j3" }, { val := .var "j5" }])],
      .make (.var "j3") [([.sym "object-handle"], [{ val := .sym "jug3" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "jug" }]), ([.sym "volume"], [{ val := .int (3) }]), ([.sym "contents"], [{ val := .int (0) }])],
      .make (.var "j5") [([.sym "object-handle"], [{ val := .sym "jug5" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "jug" }]), ([.sym "volume"], [{ val := .int (5) }]), ([.sym "contents"], [{ val := .int (0) }])],
      .make (.var "ds") [([.sym "desired-count"], [{ val := .int (1) }]), ([.sym "desired"], [{ val := .var "d1" }])],
      .make (.var "d1") [([.sym "object"], [{ val := .var "d1o" }])],
      .make (.var "d1o") [([.sym "object-handle"], [{ val := .sym "jug3" }]), ([.sym "contents"], [{ val := .int (1) }])]],
              initFile := none, initOpExtra := [], achieve := [.objectState], achieveSpaces := [], indifferent := none, indifferentExcept := [], ancestors := true },
    files := [("elaborations.soar", [.ps, .p r_water_jug_elaborate_jug_free, .achieve .objectState, .ancestors]),
              ("initialize-water-jug.soar", [.init]),
              ("fill.soar", [.p r_water_jug_propose_fill, .p r_water_jug_apply_fill_internal]),
              ("empty.soar", [.p r_water_jug_propose_empty, .p r_water_jug_apply_empty_internal]),
              ("pour.soar", [.p r_water_jug_propose_pour, .p r_water_jug_apply_pour_internal_overflow, .p r_water_jug_apply_pour_internal_fits]),
              ("state-evaluation.soar", [.p r_water_jug_elaborate_look_ahead_duplicate])] }

def v_water_jug_look_ahead_failure_states : Variant :=
  { family := "water-jug", name := "water-jug-look-ahead-failure-states",
    about := ["Water jug by look-ahead, plus known dead-end states (3-5, 0-0) as partial failures."],
    firstload := ["chunk always", "chunk add-osk on"],
    task := { name := "water-jug", psExtra := [([.sym "dont-copy-object-attribute"], [{ val := .sym "free" }])], flags := [("mea-operator-selection", .sym "true")], environmentNone := true,
              initBody := [.make (.var "objs") [([.sym "object"], [{ val := .var "j3" }, { val := .var "j5" }])],
      .make (.var "j3") [([.sym "object-handle"], [{ val := .sym "jug3" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "jug" }]), ([.sym "volume"], [{ val := .int (3) }]), ([.sym "contents"], [{ val := .int (0) }])],
      .make (.var "j5") [([.sym "object-handle"], [{ val := .sym "jug5" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "jug" }]), ([.sym "volume"], [{ val := .int (5) }]), ([.sym "contents"], [{ val := .int (0) }])],
      .make (.var "ds") [([.sym "desired-count"], [{ val := .int (1) }]), ([.sym "desired"], [{ val := .var "d1" }])],
      .make (.var "d1") [([.sym "object"], [{ val := .var "d1o" }])],
      .make (.var "d1o") [([.sym "object-handle"], [{ val := .sym "jug3" }]), ([.sym "contents"], [{ val := .int (1) }])]],
              initFile := none, initOpExtra := [], achieve := [.objectState], achieveSpaces := [], indifferent := none, indifferentExcept := [], ancestors := true },
    files := [("elaborations.soar", [.ps, .p r_water_jug_elaborate_jug_free, .achieve .objectState, .ancestors]),
              ("initialize-water-jug.soar", [.init]),
              ("fill.soar", [.p r_water_jug_propose_fill, .p r_water_jug_apply_fill_internal]),
              ("empty.soar", [.p r_water_jug_propose_empty, .p r_water_jug_apply_empty_internal]),
              ("pour.soar", [.p r_water_jug_propose_pour, .p r_water_jug_apply_pour_internal_overflow, .p r_water_jug_apply_pour_internal_fits]),
              ("state-evaluation.soar", [.p r_water_jug_elaborate_look_ahead_duplicate, .p r_water_jug_elaborate_look_ahead_avoid_1, .p r_water_jug_elaborate_look_ahead_avoid_2])] }

def v_water_jug_look_ahead_rl : Variant :=
  { family := "water-jug", name := "water-jug-look-ahead-rl",
    about := ["Water jug by look-ahead with RL; dead-end states (3-5, 0-0) get expected value -1."],
    firstload := ["chunk always", "chunk add-osk on", "rl --set learning on", "rl --set learning-rate 0.100000", "rl --set discount-rate 0.500000", "indifferent-selection --epsilon-greedy"],
    task := { name := "water-jug", psExtra := [([.sym "dont-copy-object-attribute"], [{ val := .sym "free" }])], flags := [("mea-operator-selection", .sym "true")], environmentNone := true,
              initBody := [.make (.var "objs") [([.sym "object"], [{ val := .var "j3" }, { val := .var "j5" }])],
      .make (.var "j3") [([.sym "object-handle"], [{ val := .sym "jug3" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "jug" }]), ([.sym "volume"], [{ val := .int (3) }]), ([.sym "contents"], [{ val := .int (0) }])],
      .make (.var "j5") [([.sym "object-handle"], [{ val := .sym "jug5" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "jug" }]), ([.sym "volume"], [{ val := .int (5) }]), ([.sym "contents"], [{ val := .int (0) }])],
      .make (.var "ds") [([.sym "desired-count"], [{ val := .int (1) }]), ([.sym "desired"], [{ val := .var "d1" }])],
      .make (.var "d1") [([.sym "object"], [{ val := .var "d1o" }])],
      .make (.var "d1o") [([.sym "object-handle"], [{ val := .sym "jug3" }]), ([.sym "contents"], [{ val := .int (1) }])]],
              initFile := none, initOpExtra := [], achieve := [.objectState], achieveSpaces := [], indifferent := none, indifferentExcept := [], ancestors := true },
    files := [("elaborations.soar", [.ps, .p r_water_jug_elaborate_jug_free, .achieve .objectState, .ancestors]),
              ("initialize-water-jug.soar", [.init]),
              ("fill.soar", [.p r_water_jug_propose_fill, .p r_water_jug_apply_fill_internal]),
              ("empty.soar", [.p r_water_jug_propose_empty, .p r_water_jug_apply_empty_internal]),
              ("pour.soar", [.p r_water_jug_propose_pour, .p r_water_jug_apply_pour_internal_overflow, .p r_water_jug_apply_pour_internal_fits]),
              ("state-evaluation.soar", [.p r_water_jug_elaborate_look_ahead_duplicate, .p r_water_jug_elaborate_look_ahead_avoid_1_2, .p r_water_jug_elaborate_look_ahead_avoid_2_2])] }

def v_water_jug_rl : Variant :=
  { family := "water-jug", name := "water-jug-rl",
    about := ["Water jug with reinforcement learning over jug contents (templates), random exploration."],
    firstload := ["chunk never", "rl --set learning on", "rl --set learning-rate 0.100000", "rl --set discount-rate 0.500000", "indifferent-selection --epsilon-greedy"],
    task := { name := "water-jug", psExtra := [([.sym "dont-copy-object-attribute"], [{ val := .sym "free" }])], flags := [("mea-operator-selection", .sym "true"), ("rl", .sym "true")], environmentNone := true,
              initBody := [.make (.var "objs") [([.sym "object"], [{ val := .var "j3" }, { val := .var "j5" }])],
      .make (.var "j3") [([.sym "object-handle"], [{ val := .sym "jug3" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "jug" }]), ([.sym "volume"], [{ val := .int (3) }]), ([.sym "contents"], [{ val := .int (0) }])],
      .make (.var "j5") [([.sym "object-handle"], [{ val := .sym "jug5" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "jug" }]), ([.sym "volume"], [{ val := .int (5) }]), ([.sym "contents"], [{ val := .int (0) }])],
      .make (.var "ds") [([.sym "desired-count"], [{ val := .int (1) }]), ([.sym "desired"], [{ val := .var "d1" }])],
      .make (.var "d1") [([.sym "object"], [{ val := .var "d1o" }])],
      .make (.var "d1o") [([.sym "object-handle"], [{ val := .sym "jug3" }]), ([.sym "contents"], [{ val := .int (1) }])]],
              initFile := none, initOpExtra := [], achieve := [.objectState], achieveSpaces := [], indifferent := some "the original selects among its task operators by RL values among indifferent operators", indifferentExcept := [], ancestors := false },
    files := [("elaborations.soar", [.ps, .p r_water_jug_elaborate_jug_free, .achieve .objectState]),
              ("initialize-water-jug.soar", [.init]),
              ("fill.soar", [.p r_water_jug_propose_fill, .p r_water_jug_apply_fill_internal]),
              ("empty.soar", [.p r_water_jug_propose_empty, .p r_water_jug_apply_empty_internal]),
              ("pour.soar", [.p r_water_jug_propose_pour, .p r_water_jug_apply_pour_internal_overflow, .p r_water_jug_apply_pour_internal_fits]),
              ("rl.soar", [.p r_water_jug_rl_fill, .p r_water_jug_rl_empty, .p r_water_jug_rl_pour, .p r_water_jug_elaborate_reward_both_empty]),
              ("search-control.soar", [.indifferent])] }

def v_water_jug_tie : Variant :=
  { family := "water-jug", name := "water-jug-tie",
    about := ["Water jug; moves chosen by the original tie heuristics on the last operator (alternate pour with fill/empty)."],
    firstload := ["chunk never"],
    task := { name := "water-jug", psExtra := [([.sym "dont-copy-object-attribute"], [{ val := .sym "free" }])], flags := [("mea-operator-selection", .sym "true")], environmentNone := true,
              initBody := [.make (.var "objs") [([.sym "object"], [{ val := .var "j3" }, { val := .var "j5" }, { val := .var "m" }])],
      .make (.var "m") [([.sym "object-handle"], [{ val := .sym "memory" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "memory" }]), ([.sym "last-operator"], [{ val := .sym "none" }])],
      .make (.var "j3") [([.sym "object-handle"], [{ val := .sym "jug3" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "jug" }]), ([.sym "volume"], [{ val := .int (3) }]), ([.sym "contents"], [{ val := .int (0) }])],
      .make (.var "j5") [([.sym "object-handle"], [{ val := .sym "jug5" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "jug" }]), ([.sym "volume"], [{ val := .int (5) }]), ([.sym "contents"], [{ val := .int (0) }])],
      .make (.var "ds") [([.sym "desired-count"], [{ val := .int (1) }]), ([.sym "desired"], [{ val := .var "d1" }])],
      .make (.var "d1") [([.sym "object"], [{ val := .var "d1o" }])],
      .make (.var "d1o") [([.sym "object-handle"], [{ val := .sym "jug3" }]), ([.sym "contents"], [{ val := .int (1) }])]],
              initFile := none, initOpExtra := [], achieve := [.objectState], achieveSpaces := [], indifferent := none, indifferentExcept := [], ancestors := false },
    files := [("elaborations.soar", [.ps, .p r_water_jug_elaborate_jug_free, .achieve .objectState, .p r_water_jug_apply_task_operator_record_last]),
              ("initialize-water-jug.soar", [.init]),
              ("fill.soar", [.p r_water_jug_propose_fill, .p r_water_jug_apply_fill_internal]),
              ("empty.soar", [.p r_water_jug_propose_empty, .p r_water_jug_apply_empty_internal]),
              ("pour.soar", [.p r_water_jug_propose_pour, .p r_water_jug_apply_pour_internal_overflow, .p r_water_jug_apply_pour_internal_fits]),
              ("search-control.soar", [.p r_water_jug_compare_first_move_indifferent, .p r_water_jug_compare_after_pour, .p r_water_jug_compare_after_pour_pour_worst, .p r_water_jug_compare_after_fill_empty, .p r_water_jug_compare_after_fill_empty_pour_best, .p r_water_jug_compare_after_fill_empty_fill_empty_worst])] }

def v_water_jug_tie_chunk : Variant :=
  { family := "water-jug", name := "water-jug-tie-chunk",
    about := ["Water jug; moves chosen by the original tie heuristics on the last operator (alternate pour with fill/empty)."],
    firstload := ["chunk always", "chunk add-osk on"],
    task := { name := "water-jug", psExtra := [([.sym "dont-copy-object-attribute"], [{ val := .sym "free" }])], flags := [("mea-operator-selection", .sym "true")], environmentNone := true,
              initBody := [.make (.var "objs") [([.sym "object"], [{ val := .var "j3" }, { val := .var "j5" }, { val := .var "m" }])],
      .make (.var "m") [([.sym "object-handle"], [{ val := .sym "memory" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "memory" }]), ([.sym "last-operator"], [{ val := .sym "none" }])],
      .make (.var "j3") [([.sym "object-handle"], [{ val := .sym "jug3" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "jug" }]), ([.sym "volume"], [{ val := .int (3) }]), ([.sym "contents"], [{ val := .int (0) }])],
      .make (.var "j5") [([.sym "object-handle"], [{ val := .sym "jug5" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "jug" }]), ([.sym "volume"], [{ val := .int (5) }]), ([.sym "contents"], [{ val := .int (0) }])],
      .make (.var "ds") [([.sym "desired-count"], [{ val := .int (1) }]), ([.sym "desired"], [{ val := .var "d1" }])],
      .make (.var "d1") [([.sym "object"], [{ val := .var "d1o" }])],
      .make (.var "d1o") [([.sym "object-handle"], [{ val := .sym "jug3" }]), ([.sym "contents"], [{ val := .int (1) }])]],
              initFile := none, initOpExtra := [], achieve := [.objectState], achieveSpaces := [], indifferent := none, indifferentExcept := [], ancestors := false },
    files := [("elaborations.soar", [.ps, .p r_water_jug_elaborate_jug_free, .achieve .objectState, .p r_water_jug_apply_task_operator_record_last]),
              ("initialize-water-jug.soar", [.init]),
              ("fill.soar", [.p r_water_jug_propose_fill, .p r_water_jug_apply_fill_internal]),
              ("empty.soar", [.p r_water_jug_propose_empty, .p r_water_jug_apply_empty_internal]),
              ("pour.soar", [.p r_water_jug_propose_pour, .p r_water_jug_apply_pour_internal_overflow, .p r_water_jug_apply_pour_internal_fits]),
              ("search-control.soar", [.p r_water_jug_compare_first_move_indifferent, .p r_water_jug_compare_after_pour, .p r_water_jug_compare_after_pour_pour_worst, .p r_water_jug_compare_after_fill_empty, .p r_water_jug_compare_after_fill_empty_pour_best, .p r_water_jug_compare_after_fill_empty_fill_empty_worst])] }

def variants : List Variant := [v_water_jug, v_water_jug_hierarchy, v_water_jug_hierarchy_chunk, v_water_jug_look_ahead, v_water_jug_look_ahead_failure_states, v_water_jug_look_ahead_rl, v_water_jug_rl, v_water_jug_tie, v_water_jug_tie_chunk]

end Fam.Families.WaterJug
