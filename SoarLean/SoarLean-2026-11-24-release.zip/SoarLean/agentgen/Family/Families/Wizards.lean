import Family.Task
set_option maxHeartbeats 0
set_option maxRecDepth 100000
/-!
# wizards: world-convention agents of the wizards family

Typed description migrated on 19 November 2026 from the world-v6 agents (Tasks/Families/wizards/world-v6),
which were written from the original programs. Task-level parts are `Task` fields; family knowledge is typed
productions, defined once and shared by the variants that use them.

Written 19 November 2026 by Claude, supervised by John E. Laird.
-/
namespace Fam.Families.Wizards
open Fam

def r_wizards_elaborate_record_own : Prod :=
  { name := "wizards*elaborate*record*own",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "wizards"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "r"] }],
        .pos false (.var "r") [{ path := [.sym "type"], vals := [.sym "record"] }, { path := [.sym "wiz"], vals := [.var "wz"] }, { path := [.sym "view"], vals := [.var "vh"] }],
        .pos false (.var "w") [{ path := [.sym "objects", .sym "object"], vals := [.var "v"] }],
        .pos false (.var "v") [{ path := [.sym "object-handle"], vals := [.lit (.var "vh")] }, { path := [.sym "owner"], vals := [.var "wz"] }]],
    acts := [.make (.var "r") [([.sym "own"], [{ val := .int (1) }])]] }

def r_wizards_elaborate_record_white_mark : Prod :=
  { name := "wizards*elaborate*record*white*mark",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "wizards"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "r"] }],
        .pos false (.var "r") [{ path := [.sym "type"], vals := [.sym "record"] }, { path := [.sym "mark"], vals := [.int (1)] }]],
    acts := [.make (.var "r") [([.sym "white"], [{ val := .int (1) }])]] }

def r_wizards_elaborate_record_white_two_blackish_sibs : Prod :=
  { name := "wizards*elaborate*record*white*two-blackish-sibs",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "wizards"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "r"] }],
        .pos false (.var "r") [{ path := [.sym "type"], vals := [.sym "record"] }, { path := [.sym "own"], vals := [.int (1)] }],
        .pos false (.var "w") [{ path := [.sym "sib"], vals := [.var "x1", .conj [.cmp "<>" (.var "x1"), .var "x2"]] }],
        .pos false (.var "x1") [{ path := [.sym "argument1"], vals := [.var "r"] }, { path := [.sym "argument2"], vals := [.var "b1"] }],
        .pos false (.var "x2") [{ path := [.sym "argument1"], vals := [.var "r"] }, { path := [.sym "argument2"], vals := [.conj [.cmp "<>" (.var "b1"), .var "b2"]] }],
        .pos false (.var "b1") [{ path := [.sym "blackish"], vals := [.int (1)] }],
        .pos false (.var "b2") [{ path := [.sym "blackish"], vals := [.int (1)] }]],
    acts := [.make (.var "r") [([.sym "white"], [{ val := .int (1) }])]] }

def r_wizards_elaborate_record_white_via_sub : Prod :=
  { name := "wizards*elaborate*record*white*via-sub",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "wizards"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "r"] }],
        .pos false (.var "w") [{ path := [.sym "sub"], vals := [.var "sr"] }],
        .pos false (.var "sr") [{ path := [.sym "argument1"], vals := [.var "r"] }, { path := [.sym "argument2"], vals := [.var "b"] }],
        .pos false (.var "b") [{ path := [.sym "white"], vals := [.int (1)] }, { path := [.sym "contra"], vals := [.int (1)], neg := true }]],
    acts := [.make (.var "r") [([.sym "white"], [{ val := .int (1) }])]] }

def r_wizards_elaborate_record_black_mark : Prod :=
  { name := "wizards*elaborate*record*black*mark",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "wizards"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "r"] }],
        .pos false (.var "r") [{ path := [.sym "type"], vals := [.sym "record"] }, { path := [.sym "mark"], vals := [.int (2)] }]],
    acts := [.make (.var "r") [([.sym "black"], [{ val := .int (1) }])]] }

def r_wizards_elaborate_record_black_via_sub : Prod :=
  { name := "wizards*elaborate*record*black*via-sub",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "wizards"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "r"] }],
        .pos false (.var "w") [{ path := [.sym "sub"], vals := [.var "sr"] }],
        .pos false (.var "sr") [{ path := [.sym "argument1"], vals := [.var "r"] }, { path := [.sym "argument2"], vals := [.var "b"] }],
        .pos false (.var "b") [{ path := [.sym "black"], vals := [.int (1)] }, { path := [.sym "contra"], vals := [.int (1)], neg := true }]],
    acts := [.make (.var "r") [([.sym "black"], [{ val := .int (1) }])]] }

def r_wizards_elaborate_record_blackish_black : Prod :=
  { name := "wizards*elaborate*record*blackish*black",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "wizards"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "r"] }],
        .pos false (.var "r") [{ path := [.sym "type"], vals := [.sym "record"] }, { path := [.sym "black"], vals := [.int (1)] }]],
    acts := [.make (.var "r") [([.sym "blackish"], [{ val := .int (1) }])]] }

def r_wizards_elaborate_record_blackish_assumed : Prod :=
  { name := "wizards*elaborate*record*blackish*assumed",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "wizards"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "r"] }],
        .pos false (.var "r") [{ path := [.sym "type"], vals := [.sym "record"] }, { path := [.sym "mv"], vals := [.conj [.cmp "<>" (.sym "none"), .var "mh"]] }],
        .pos false (.var "w") [{ path := [.sym "objects", .sym "object"], vals := [.var "m"] }],
        .pos false (.var "m") [{ path := [.sym "object-handle"], vals := [.lit (.var "mh")] }, { path := [.sym "value"], vals := [.int (2)] }]],
    acts := [.make (.var "r") [([.sym "blackish"], [{ val := .int (1) }])]] }

def r_wizards_elaborate_record_gwhite_own : Prod :=
  { name := "wizards*elaborate*record*gwhite*own",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "wizards"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "r"] }],
        .pos false (.var "r") [{ path := [.sym "type"], vals := [.sym "record"] }, { path := [.sym "own"], vals := [.int (1)] }, { path := [.sym "white"], vals := [.int (1)] }]],
    acts := [.make (.var "r") [([.sym "gwhite"], [{ val := .int (1) }])]] }

def r_wizards_elaborate_record_gwhite_guess : Prod :=
  { name := "wizards*elaborate*record*gwhite*guess",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "wizards"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "r"] }],
        .pos false (.var "r") [{ path := [.sym "type"], vals := [.sym "record"] }, { path := [.sym "aguess"], vals := [.int (1)] }]],
    acts := [.make (.var "r") [([.sym "gwhite"], [{ val := .int (1) }])]] }

def r_wizards_elaborate_record_gwhite_via_sub : Prod :=
  { name := "wizards*elaborate*record*gwhite*via-sub",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "wizards"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "r"] }],
        .pos false (.var "w") [{ path := [.sym "sub"], vals := [.var "sr"] }],
        .pos false (.var "sr") [{ path := [.sym "argument1"], vals := [.var "r"] }, { path := [.sym "argument2"], vals := [.var "b"] }],
        .pos false (.var "b") [{ path := [.sym "gwhite"], vals := [.int (1)] }, { path := [.sym "contra"], vals := [.int (1)], neg := true }]],
    acts := [.make (.var "r") [([.sym "gwhite"], [{ val := .int (1) }])]] }

def r_wizards_elaborate_record_gblack_own : Prod :=
  { name := "wizards*elaborate*record*gblack*own",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "wizards"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "r"] }],
        .pos false (.var "r") [{ path := [.sym "type"], vals := [.sym "record"] }, { path := [.sym "own"], vals := [.int (1)] }, { path := [.sym "black"], vals := [.int (1)] }]],
    acts := [.make (.var "r") [([.sym "gblack"], [{ val := .int (1) }])]] }

def r_wizards_elaborate_record_gblack_guess : Prod :=
  { name := "wizards*elaborate*record*gblack*guess",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "wizards"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "r"] }],
        .pos false (.var "r") [{ path := [.sym "type"], vals := [.sym "record"] }, { path := [.sym "aguess"], vals := [.int (2)] }]],
    acts := [.make (.var "r") [([.sym "gblack"], [{ val := .int (1) }])]] }

def r_wizards_elaborate_record_gblack_via_sub : Prod :=
  { name := "wizards*elaborate*record*gblack*via-sub",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "wizards"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "r"] }],
        .pos false (.var "w") [{ path := [.sym "sub"], vals := [.var "sr"] }],
        .pos false (.var "sr") [{ path := [.sym "argument1"], vals := [.var "r"] }, { path := [.sym "argument2"], vals := [.var "b"] }],
        .pos false (.var "b") [{ path := [.sym "gblack"], vals := [.int (1)] }, { path := [.sym "contra"], vals := [.int (1)], neg := true }]],
    acts := [.make (.var "r") [([.sym "gblack"], [{ val := .int (1) }])]] }

def r_wizards_elaborate_record_contra_white_unguessed : Prod :=
  { name := "wizards*elaborate*record*contra*white-unguessed",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "wizards"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "r"] }],
        .pos false (.var "r") [{ path := [.sym "type"], vals := [.sym "record"] }, { path := [.sym "gwhite"], vals := [.int (1)] }, { path := [.sym "aguess"], vals := [.int (0)] }]],
    acts := [.make (.var "r") [([.sym "contra"], [{ val := .int (1) }])]] }

def r_wizards_elaborate_record_contra_black_unguessed : Prod :=
  { name := "wizards*elaborate*record*contra*black-unguessed",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "wizards"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "r"] }],
        .pos false (.var "r") [{ path := [.sym "type"], vals := [.sym "record"] }, { path := [.sym "gblack"], vals := [.int (1)] }, { path := [.sym "aguess"], vals := [.int (0)] }]],
    acts := [.make (.var "r") [([.sym "contra"], [{ val := .int (1) }])]] }

def r_wizards_elaborate_record_contra_both : Prod :=
  { name := "wizards*elaborate*record*contra*both",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "wizards"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "r"] }],
        .pos false (.var "r") [{ path := [.sym "type"], vals := [.sym "record"] }, { path := [.sym "gwhite"], vals := [.int (1)] }, { path := [.sym "gblack"], vals := [.int (1)] }]],
    acts := [.make (.var "r") [([.sym "contra"], [{ val := .int (1) }])]] }

def r_wizards_propose_ascribe_guess_gv_0 : Prod :=
  { name := "wizards*propose*ascribe-guess*gv-0",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "wizards"] }, { path := [.sym "flags", .sym "mea-operator-selection"], vals := [.sym "true"] }, { path := [.sym "desireds", .sym "unachieved-desireds"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }],
        .pos false (.var "w") [{ path := [.sym "sub"], vals := [.var "sr"] }, { path := [.sym "objects", .sym "object"], vals := [.var "x1", .var "x2"] }],
        .pos false (.var "sr") [{ path := [.sym "argument1"], vals := [.var "x1"] }, { path := [.sym "argument2"], vals := [.var "x2"] }],
        .pos false (.var "x1") [{ path := [.sym "aguess"], vals := [.int (0)] }],
        .pos false (.var "x2") [{ path := [.sym "own"], vals := [.int (1)], neg := true }, { path := [.sym "aguess"], vals := [.int (0)], neg := true }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "ascribe-guess" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "action-handle"], [{ val := .sym "ascribe-guess" }]), ([.sym "argument1"], [{ val := .var "x1" }]), ([.sym "argument2"], [{ val := .var "x2" }]), ([.sym "argument-count"], [{ val := .int (2) }]), ([.sym "desireds"], [{ val := .var "pre" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (0) }])],
        .make (.var "o") [([.sym "gv"], [{ val := .int (0) }])]] }

def r_wizards_propose_ascribe_guess_gv_1 : Prod :=
  { name := "wizards*propose*ascribe-guess*gv-1",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "wizards"] }, { path := [.sym "flags", .sym "mea-operator-selection"], vals := [.sym "true"] }, { path := [.sym "desireds", .sym "unachieved-desireds"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }],
        .pos false (.var "w") [{ path := [.sym "sub"], vals := [.var "sr"] }, { path := [.sym "objects", .sym "object"], vals := [.var "x1", .var "x2"] }],
        .pos false (.var "sr") [{ path := [.sym "argument1"], vals := [.var "x1"] }, { path := [.sym "argument2"], vals := [.var "x2"] }],
        .pos false (.var "x1") [{ path := [.sym "aguess"], vals := [.int (1)] }],
        .pos false (.var "x2") [{ path := [.sym "own"], vals := [.int (1)], neg := true }, { path := [.sym "aguess"], vals := [.int (1)], neg := true }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "ascribe-guess" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "action-handle"], [{ val := .sym "ascribe-guess" }]), ([.sym "argument1"], [{ val := .var "x1" }]), ([.sym "argument2"], [{ val := .var "x2" }]), ([.sym "argument-count"], [{ val := .int (2) }]), ([.sym "desireds"], [{ val := .var "pre" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (0) }])],
        .make (.var "o") [([.sym "gv"], [{ val := .int (1) }])]] }

def r_wizards_propose_ascribe_guess_gv_2 : Prod :=
  { name := "wizards*propose*ascribe-guess*gv-2",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "wizards"] }, { path := [.sym "flags", .sym "mea-operator-selection"], vals := [.sym "true"] }, { path := [.sym "desireds", .sym "unachieved-desireds"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }],
        .pos false (.var "w") [{ path := [.sym "sub"], vals := [.var "sr"] }, { path := [.sym "objects", .sym "object"], vals := [.var "x1", .var "x2"] }],
        .pos false (.var "sr") [{ path := [.sym "argument1"], vals := [.var "x1"] }, { path := [.sym "argument2"], vals := [.var "x2"] }],
        .pos false (.var "x1") [{ path := [.sym "aguess"], vals := [.int (2)] }],
        .pos false (.var "x2") [{ path := [.sym "own"], vals := [.int (1)], neg := true }, { path := [.sym "aguess"], vals := [.int (2)], neg := true }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "ascribe-guess" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "action-handle"], [{ val := .sym "ascribe-guess" }]), ([.sym "argument1"], [{ val := .var "x1" }]), ([.sym "argument2"], [{ val := .var "x2" }]), ([.sym "argument-count"], [{ val := .int (2) }]), ([.sym "desireds"], [{ val := .var "pre" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (0) }])],
        .make (.var "o") [([.sym "gv"], [{ val := .int (2) }])]] }

def r_wizards_apply_ascribe_guess_internal : Prod :=
  { name := "wizards*apply*ascribe-guess*internal",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "wizards"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "internal-actions"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "ascribe-guess"] }, { path := [.sym "pre-conditions-satisfied"], vals := [.sym "true"] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.lit (.var "h")] }, { path := [.sym "gv"], vals := [.var "gv"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "x2"] }],
        .pos false (.var "x2") [{ path := [.sym "object-handle"], vals := [.lit (.var "h")] }]],
    acts := [.call "log" [.int (1), .fn "crlf" [], .str "Ascribe guess ", .var "gv", .str " to ", .var "h"],
        .make (.var "x2") [([.sym "aguess"], [{ val := .var "gv" }])]] }

def r_wizards_propose_ascribe_mark : Prod :=
  { name := "wizards*propose*ascribe-mark",
    doc := ["ascribe-mark <x1> <x2>: a known mark passes to the record below."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "wizards"] }, { path := [.sym "flags", .sym "mea-operator-selection"], vals := [.sym "true"] }, { path := [.sym "desireds", .sym "unachieved-desireds"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }],
        .pos false (.var "w") [{ path := [.sym "sub"], vals := [.var "sr"] }, { path := [.sym "objects", .sym "object"], vals := [.var "x1", .var "x2"] }],
        .pos false (.var "sr") [{ path := [.sym "argument1"], vals := [.var "x1"] }, { path := [.sym "argument2"], vals := [.var "x2"] }],
        .pos false (.var "x1") [{ path := [.sym "mark"], vals := [.cmp "<>" (.int (0))] }],
        .pos false (.var "x2") [{ path := [.sym "own"], vals := [.int (1)], neg := true }, { path := [.sym "mark"], vals := [.int (0)] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "ascribe-mark" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "action-handle"], [{ val := .sym "ascribe-mark" }]), ([.sym "argument1"], [{ val := .var "x1" }]), ([.sym "argument2"], [{ val := .var "x2" }]), ([.sym "argument-count"], [{ val := .int (2) }]), ([.sym "desireds"], [{ val := .var "pre" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (0) }])]] }

def r_wizards_apply_ascribe_mark_internal : Prod :=
  { name := "wizards*apply*ascribe-mark*internal",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "wizards"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "internal-actions"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "ascribe-mark"] }, { path := [.sym "pre-conditions-satisfied"], vals := [.sym "true"] }, { path := [.sym "argument1", .sym "object-handle"], vals := [.lit (.var "h1")] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.lit (.var "h2")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "x1", .var "x2"] }],
        .pos false (.var "x1") [{ path := [.sym "object-handle"], vals := [.lit (.var "h1")] }, { path := [.sym "mark"], vals := [.var "m1"] }],
        .pos false (.var "x2") [{ path := [.sym "object-handle"], vals := [.lit (.var "h2")] }, { path := [.sym "mark"], vals := [.var "m2"] }]],
    acts := [.call "log" [.int (1), .fn "crlf" [], .str "Ascribe mark ", .var "m1", .str " to ", .var "h2"],
        .make (.var "x2") [([.sym "mark"], [{ val := .var "m2", pref := "-" }, { val := .var "m1" }])]] }

def r_wizards_propose_ascribe_unknown : Prod :=
  { name := "wizards*propose*ascribe-unknown",
    doc := ["ascribe-unknown <x1> <x2>: an unknown mark (a mark variable) passes to the record below."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "wizards"] }, { path := [.sym "flags", .sym "mea-operator-selection"], vals := [.sym "true"] }, { path := [.sym "desireds", .sym "unachieved-desireds"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }],
        .pos false (.var "w") [{ path := [.sym "sub"], vals := [.var "sr"] }, { path := [.sym "objects", .sym "object"], vals := [.var "x1", .var "x2"] }],
        .pos false (.var "sr") [{ path := [.sym "argument1"], vals := [.var "x1"] }, { path := [.sym "argument2"], vals := [.var "x2"] }],
        .pos false (.var "x1") [{ path := [.sym "mv"], vals := [.cmp "<>" (.sym "none")] }],
        .pos false (.var "x2") [{ path := [.sym "own"], vals := [.int (1)], neg := true }, { path := [.sym "var"], vals := [.int (0)] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "ascribe-unknown" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "action-handle"], [{ val := .sym "ascribe-unknown" }]), ([.sym "argument1"], [{ val := .var "x1" }]), ([.sym "argument2"], [{ val := .var "x2" }]), ([.sym "argument-count"], [{ val := .int (2) }]), ([.sym "desireds"], [{ val := .var "pre" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (0) }])]] }

def r_wizards_apply_ascribe_unknown_internal : Prod :=
  { name := "wizards*apply*ascribe-unknown*internal",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "wizards"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "internal-actions"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "ascribe-unknown"] }, { path := [.sym "pre-conditions-satisfied"], vals := [.sym "true"] }, { path := [.sym "argument1", .sym "object-handle"], vals := [.lit (.var "h1")] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.lit (.var "h2")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "x1", .var "x2"] }],
        .pos false (.var "x1") [{ path := [.sym "object-handle"], vals := [.lit (.var "h1")] }, { path := [.sym "mv"], vals := [.var "mh"] }],
        .pos false (.var "x2") [{ path := [.sym "object-handle"], vals := [.lit (.var "h2")] }, { path := [.sym "mv"], vals := [.var "old"] }, { path := [.sym "var"], vals := [.var "v"] }]],
    acts := [.call "log" [.int (1), .fn "crlf" [], .str "Ascribe unknown ", .var "mh", .str " to ", .var "h2"],
        .make (.var "x2") [([.sym "mv"], [{ val := .var "old", pref := "-" }, { val := .var "mh" }]), ([.sym "var"], [{ val := .var "v", pref := "-" }, { val := .int (1) }])]] }

def r_wizards_propose_assume_black : Prod :=
  { name := "wizards*propose*assume-black",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "wizards"] }, { path := [.sym "flags", .sym "mea-operator-selection"], vals := [.sym "true"] }, { path := [.sym "desireds", .sym "unachieved-desireds"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }],
        .pos false (.var "w") [{ path := [.sym "objects", .sym "object"], vals := [.var "r", .var "v", .var "m"] }],
        .pos false (.var "r") [{ path := [.sym "type"], vals := [.sym "record"] }, { path := [.sym "own"], vals := [.int (1)], neg := true }, { path := [.sym "view"], vals := [.var "vh"] }, { path := [.sym "mv"], vals := [.var "mh"] }],
        .pos false (.var "v") [{ path := [.sym "object-handle"], vals := [.lit (.var "vh")] }],
        .pos false (.var "m") [{ path := [.sym "object-handle"], vals := [.lit (.var "mh")] }, { path := [.sym "value"], vals := [.int (0)] }, { path := [.sym "untried"], vals := [.int (2)] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "assume-black" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "action-handle"], [{ val := .sym "assume-black" }]), ([.sym "argument1"], [{ val := .var "r" }]), ([.sym "argument2"], [{ val := .var "v" }]), ([.sym "argument3"], [{ val := .var "m" }]), ([.sym "argument-count"], [{ val := .int (3) }]), ([.sym "desireds"], [{ val := .var "pre" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (0) }])]] }

def r_wizards_apply_assume_black_internal : Prod :=
  { name := "wizards*apply*assume-black*internal",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "wizards"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "internal-actions"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "assume-black"] }, { path := [.sym "pre-conditions-satisfied"], vals := [.sym "true"] }, { path := [.sym "argument1", .sym "object-handle"], vals := [.lit (.var "rh")] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.lit (.var "vh")] }, { path := [.sym "argument3", .sym "object-handle"], vals := [.lit (.var "mh")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "r", .var "v", .var "m"] }],
        .pos false (.var "r") [{ path := [.sym "object-handle"], vals := [.lit (.var "rh")] }, { path := [.sym "wiz"], vals := [.var "wz"] }],
        .pos false (.var "v") [{ path := [.sym "object-handle"], vals := [.lit (.var "vh")] }, { path := [.sym "vid"], vals := [.var "vid"] }, { path := [.sym "owner"], vals := [.var "ow"] }],
        .pos false (.var "m") [{ path := [.sym "object-handle"], vals := [.lit (.var "mh")] }, { path := [.sym "value"], vals := [.var "val"] }, { path := [.sym "assigned"], vals := [.var "as"] }]],
    acts := [.call "log" [.int (1), .fn "crlf" [], .str "In the view of wizard ", .var "ow", .str ", assume wizard ", .var "wz", .str "'s spot is black."],
        .make (.var "m") [([.sym "value"], [{ val := .var "val", pref := "-" }, { val := .int (2) }]), ([.sym "untried"], [{ val := .int (2), pref := "-" }]), ([.sym "assigned"], [{ val := .var "as", pref := "-" }, { val := .var "vid" }])]] }

def r_wizards_propose_assume_white : Prod :=
  { name := "wizards*propose*assume-white",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "wizards"] }, { path := [.sym "flags", .sym "mea-operator-selection"], vals := [.sym "true"] }, { path := [.sym "desireds", .sym "unachieved-desireds"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }],
        .pos false (.var "w") [{ path := [.sym "objects", .sym "object"], vals := [.var "r", .var "v", .var "m"] }],
        .pos false (.var "r") [{ path := [.sym "type"], vals := [.sym "record"] }, { path := [.sym "own"], vals := [.int (1)], neg := true }, { path := [.sym "view"], vals := [.var "vh"] }, { path := [.sym "mv"], vals := [.var "mh"] }],
        .pos false (.var "v") [{ path := [.sym "object-handle"], vals := [.lit (.var "vh")] }],
        .pos false (.var "m") [{ path := [.sym "object-handle"], vals := [.lit (.var "mh")] }, { path := [.sym "value"], vals := [.int (0)] }, { path := [.sym "untried"], vals := [.int (1)] }, { path := [.sym "untried"], vals := [.int (2)], neg := true }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "assume-white" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "action-handle"], [{ val := .sym "assume-white" }]), ([.sym "argument1"], [{ val := .var "r" }]), ([.sym "argument2"], [{ val := .var "v" }]), ([.sym "argument3"], [{ val := .var "m" }]), ([.sym "argument-count"], [{ val := .int (3) }]), ([.sym "desireds"], [{ val := .var "pre" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (0) }])]] }

def r_wizards_apply_assume_white_internal : Prod :=
  { name := "wizards*apply*assume-white*internal",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "wizards"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "internal-actions"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "assume-white"] }, { path := [.sym "pre-conditions-satisfied"], vals := [.sym "true"] }, { path := [.sym "argument1", .sym "object-handle"], vals := [.lit (.var "rh")] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.lit (.var "vh")] }, { path := [.sym "argument3", .sym "object-handle"], vals := [.lit (.var "mh")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "r", .var "v", .var "m"] }],
        .pos false (.var "r") [{ path := [.sym "object-handle"], vals := [.lit (.var "rh")] }, { path := [.sym "wiz"], vals := [.var "wz"] }],
        .pos false (.var "v") [{ path := [.sym "object-handle"], vals := [.lit (.var "vh")] }, { path := [.sym "vid"], vals := [.var "vid"] }, { path := [.sym "owner"], vals := [.var "ow"] }],
        .pos false (.var "m") [{ path := [.sym "object-handle"], vals := [.lit (.var "mh")] }, { path := [.sym "value"], vals := [.var "val"] }, { path := [.sym "assigned"], vals := [.var "as"] }]],
    acts := [.call "log" [.int (1), .fn "crlf" [], .str "In the view of wizard ", .var "ow", .str ", assume wizard ", .var "wz", .str "'s spot is white."],
        .make (.var "m") [([.sym "value"], [{ val := .var "val", pref := "-" }, { val := .int (1) }]), ([.sym "untried"], [{ val := .int (1), pref := "-" }]), ([.sym "assigned"], [{ val := .var "as", pref := "-" }, { val := .var "vid" }])]] }

def r_wizards_propose_complement_u_1 : Prod :=
  { name := "wizards*propose*complement*u-1",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "wizards"] }, { path := [.sym "flags", .sym "mea-operator-selection"], vals := [.sym "true"] }, { path := [.sym "desireds", .sym "unachieved-desireds"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }],
        .pos false (.var "w") [{ path := [.sym "objects", .sym "object"], vals := [.var "w1", .var "k1", .var "k2", .var "w2", .var "m"] }],
        .pos false (.var "w1") [{ path := [.sym "type"], vals := [.sym "record"] }, { path := [.sym "contra"], vals := [.int (1)] }, { path := [.sym "view"], vals := [.var "k1h"] }],
        .pos false (.var "k1") [{ path := [.sym "object-handle"], vals := [.lit (.var "k1h")] }],
        .pos false (.var "k2") [{ path := [.sym "type"], vals := [.sym "view"] }, { path := [.sym "parent"], vals := [.var "k1h"] }, { path := [.sym "object-handle"], vals := [.var "k2h"] }, { path := [.sym "vid"], vals := [.var "vid2"] }],
        .pos false (.var "w2") [{ path := [.sym "type"], vals := [.sym "record"] }, { path := [.sym "view"], vals := [.var "k2h"] }, { path := [.sym "mv"], vals := [.var "mh"] }],
        .pos false (.var "m") [{ path := [.sym "object-handle"], vals := [.lit (.var "mh")] }, { path := [.sym "assigned"], vals := [.var "vid2"] }, { path := [.sym "untried"], vals := [.int (1)] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "complement" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "action-handle"], [{ val := .sym "complement" }]), ([.sym "argument1"], [{ val := .var "w2" }]), ([.sym "argument2"], [{ val := .var "k1" }]), ([.sym "argument3"], [{ val := .var "k2" }]), ([.sym "argument-count"], [{ val := .int (3) }]), ([.sym "desireds"], [{ val := .var "pre" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (0) }])],
        .make (.var "o") [([.sym "u"], [{ val := .int (1) }])]] }

def r_wizards_propose_complement_u_2 : Prod :=
  { name := "wizards*propose*complement*u-2",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "wizards"] }, { path := [.sym "flags", .sym "mea-operator-selection"], vals := [.sym "true"] }, { path := [.sym "desireds", .sym "unachieved-desireds"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }],
        .pos false (.var "w") [{ path := [.sym "objects", .sym "object"], vals := [.var "w1", .var "k1", .var "k2", .var "w2", .var "m"] }],
        .pos false (.var "w1") [{ path := [.sym "type"], vals := [.sym "record"] }, { path := [.sym "contra"], vals := [.int (1)] }, { path := [.sym "view"], vals := [.var "k1h"] }],
        .pos false (.var "k1") [{ path := [.sym "object-handle"], vals := [.lit (.var "k1h")] }],
        .pos false (.var "k2") [{ path := [.sym "type"], vals := [.sym "view"] }, { path := [.sym "parent"], vals := [.var "k1h"] }, { path := [.sym "object-handle"], vals := [.var "k2h"] }, { path := [.sym "vid"], vals := [.var "vid2"] }],
        .pos false (.var "w2") [{ path := [.sym "type"], vals := [.sym "record"] }, { path := [.sym "view"], vals := [.var "k2h"] }, { path := [.sym "mv"], vals := [.var "mh"] }],
        .pos false (.var "m") [{ path := [.sym "object-handle"], vals := [.lit (.var "mh")] }, { path := [.sym "assigned"], vals := [.var "vid2"] }, { path := [.sym "untried"], vals := [.int (2)] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "complement" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "action-handle"], [{ val := .sym "complement" }]), ([.sym "argument1"], [{ val := .var "w2" }]), ([.sym "argument2"], [{ val := .var "k1" }]), ([.sym "argument3"], [{ val := .var "k2" }]), ([.sym "argument-count"], [{ val := .int (3) }]), ([.sym "desireds"], [{ val := .var "pre" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (0) }])],
        .make (.var "o") [([.sym "u"], [{ val := .int (2) }])]] }

def r_wizards_apply_complement_internal : Prod :=
  { name := "wizards*apply*complement*internal",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "wizards"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "internal-actions"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "complement"] }, { path := [.sym "pre-conditions-satisfied"], vals := [.sym "true"] }, { path := [.sym "argument1", .sym "object-handle"], vals := [.lit (.var "h2")] }, { path := [.sym "argument2", .sym "owner"], vals := [.var "o1"] }, { path := [.sym "argument3", .sym "owner"], vals := [.var "o2"] }, { path := [.sym "u"], vals := [.var "u"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "w2"] }],
        .pos false (.var "w2") [{ path := [.sym "object-handle"], vals := [.lit (.var "h2")] }, { path := [.sym "mark"], vals := [.var "mk"] }, { path := [.sym "mv"], vals := [.var "mh"] }, { path := [.sym "var"], vals := [.var "v"] }, { path := [.sym "wiz"], vals := [.var "wz"] }]],
    acts := [.call "log" [.int (1), .fn "crlf" [], .str "Contradiction in the view of wizard ", .var "o1", .str ": in the view of wizard ", .var "o2", .str ", wizard ", .var "wz", .str "'s spot must be ", .var "u"],
        .make (.var "w2") [([.sym "mark"], [{ val := .var "mk", pref := "-" }, { val := .var "u" }]), ([.sym "mv"], [{ val := .var "mh", pref := "-" }, { val := .sym "none" }]), ([.sym "var"], [{ val := .var "v", pref := "-" }, { val := .int (0) }])]] }

def r_wizards_propose_consider_knows : Prod :=
  { name := "wizards*propose*consider-knows",
    doc := ["consider-knows <record> in view k: model, in a new view, what that wizard knows: a new view and three", "new records (one per wizard), siblings of each other and below the three records of view k."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "wizards"] }, { path := [.sym "flags", .sym "mea-operator-selection"], vals := [.sym "true"] }, { path := [.sym "desireds", .sym "unachieved-desireds"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "r", .var "k", .var "a1", .var "a2", .var "a3"] }],
        .pos false (.var "r") [{ path := [.sym "type"], vals := [.sym "record"] }, { path := [.sym "own"], vals := [.int (1)], neg := true }, { path := [.sym "modeled"], vals := [.int (0)] }, { path := [.sym "view"], vals := [.var "kh"] }],
        .pos false (.var "k") [{ path := [.sym "object-handle"], vals := [.lit (.var "kh")] }],
        .pos false (.var "a1") [{ path := [.sym "type"], vals := [.sym "record"] }, { path := [.sym "view"], vals := [.var "kh"] }, { path := [.sym "wiz"], vals := [.int (1)] }],
        .pos false (.var "a2") [{ path := [.sym "type"], vals := [.sym "record"] }, { path := [.sym "view"], vals := [.var "kh"] }, { path := [.sym "wiz"], vals := [.int (2)] }],
        .pos false (.var "a3") [{ path := [.sym "type"], vals := [.sym "record"] }, { path := [.sym "view"], vals := [.var "kh"] }, { path := [.sym "wiz"], vals := [.int (3)] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "consider-knows" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "action-handle"], [{ val := .sym "consider-knows" }]), ([.sym "argument1"], [{ val := .var "r" }]), ([.sym "argument2"], [{ val := .var "k" }]), ([.sym "argument-count"], [{ val := .int (2) }]), ([.sym "desireds"], [{ val := .var "pre" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (0) }])]] }

def r_wizards_apply_consider_knows_internal : Prod :=
  { name := "wizards*apply*consider-knows*internal",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "wizards"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "internal-actions"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "consider-knows"] }, { path := [.sym "pre-conditions-satisfied"], vals := [.sym "true"] }, { path := [.sym "argument1", .sym "object-handle"], vals := [.lit (.var "rh")] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.lit (.var "kh")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects"], vals := [.var "objs"] }],
        .pos false (.var "objs") [{ path := [.sym "object"], vals := [.var "pz", .var "r", .var "k", .var "a1", .var "a2", .var "a3"] }],
        .pos false (.var "pz") [{ path := [.sym "type"], vals := [.sym "puzzle"] }, { path := [.sym "nviews"], vals := [.var "n"] }],
        .pos false (.var "r") [{ path := [.sym "object-handle"], vals := [.lit (.var "rh")] }, { path := [.sym "modeled"], vals := [.var "md"] }, { path := [.sym "wiz"], vals := [.var "wz"] }],
        .pos false (.var "k") [{ path := [.sym "object-handle"], vals := [.lit (.var "kh")] }, { path := [.sym "owner"], vals := [.var "ow"] }, { path := [.sym "depth"], vals := [.var "dp"] }],
        .pos false (.var "a1") [{ path := [.sym "type"], vals := [.sym "record"] }, { path := [.sym "view"], vals := [.lit (.var "kh")] }, { path := [.sym "wiz"], vals := [.int (1)] }],
        .pos false (.var "a2") [{ path := [.sym "type"], vals := [.sym "record"] }, { path := [.sym "view"], vals := [.lit (.var "kh")] }, { path := [.sym "wiz"], vals := [.int (2)] }],
        .pos false (.var "a3") [{ path := [.sym "type"], vals := [.sym "record"] }, { path := [.sym "view"], vals := [.lit (.var "kh")] }, { path := [.sym "wiz"], vals := [.int (3)] }]],
    acts := [.call "log" [.int (1), .fn "crlf" [], .str "In the view of wizard ", .var "ow", .str ", model what wizard ", .var "wz", .str " knows."],
        .make (.var "pz") [([.sym "nviews"], [{ val := .var "n", pref := "-" }, { val := .fn "+" [.var "n", .int (1)] }])],
        .make (.var "r") [([.sym "modeled"], [{ val := .var "md", pref := "-" }, { val := .int (1) }])],
        .make (.var "objs") [([.sym "object"], [{ val := .var "v" }, { val := .var "r1" }, { val := .var "r2" }, { val := .var "r3" }])],
        .make (.var "v") [([.sym "object-handle"], [{ val := .fn "concat" [.sym "view-", .fn "+" [.var "n", .int (1)]] }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "view" }]), ([.sym "vid"], [{ val := .fn "+" [.var "n", .int (1)] }]), ([.sym "owner"], [{ val := .var "wz" }]), ([.sym "depth"], [{ val := .fn "+" [.var "dp", .int (1)] }]), ([.sym "parent"], [{ val := .var "kh" }])],
        .make (.var "r1") [([.sym "object-handle"], [{ val := .fn "concat" [.sym "rec-", .fn "+" [.var "n", .int (1)], .int (-1)] }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "record" }]), ([.sym "wiz"], [{ val := .int (1) }]), ([.sym "mark"], [{ val := .int (0) }]), ([.sym "var"], [{ val := .int (0) }]), ([.sym "modeled"], [{ val := .int (0) }]), ([.sym "view"], [{ val := .fn "concat" [.sym "view-", .fn "+" [.var "n", .int (1)]] }]), ([.sym "mv"], [{ val := .sym "none" }])],
        .make (.var "r2") [([.sym "object-handle"], [{ val := .fn "concat" [.sym "rec-", .fn "+" [.var "n", .int (1)], .int (-2)] }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "record" }]), ([.sym "wiz"], [{ val := .int (2) }]), ([.sym "mark"], [{ val := .int (0) }]), ([.sym "var"], [{ val := .int (0) }]), ([.sym "modeled"], [{ val := .int (0) }]), ([.sym "view"], [{ val := .fn "concat" [.sym "view-", .fn "+" [.var "n", .int (1)]] }]), ([.sym "mv"], [{ val := .sym "none" }])],
        .make (.var "r3") [([.sym "object-handle"], [{ val := .fn "concat" [.sym "rec-", .fn "+" [.var "n", .int (1)], .int (-3)] }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "record" }]), ([.sym "wiz"], [{ val := .int (3) }]), ([.sym "mark"], [{ val := .int (0) }]), ([.sym "var"], [{ val := .int (0) }]), ([.sym "modeled"], [{ val := .int (0) }]), ([.sym "view"], [{ val := .fn "concat" [.sym "view-", .fn "+" [.var "n", .int (1)]] }]), ([.sym "mv"], [{ val := .sym "none" }])],
        .make (.var "w") [([.sym "sib"], [{ val := .var "s1" }, { val := .var "s2" }, { val := .var "s3" }, { val := .var "s4" }, { val := .var "s5" }, { val := .var "s6" }]), ([.sym "sub"], [{ val := .var "u1" }, { val := .var "u2" }, { val := .var "u3" }])],
        .make (.var "s1") [([.sym "argument1"], [{ val := .var "r1" }]), ([.sym "argument2"], [{ val := .var "r2" }])],
        .make (.var "s2") [([.sym "argument1"], [{ val := .var "r1" }]), ([.sym "argument2"], [{ val := .var "r3" }])],
        .make (.var "s3") [([.sym "argument1"], [{ val := .var "r2" }]), ([.sym "argument2"], [{ val := .var "r1" }])],
        .make (.var "s4") [([.sym "argument1"], [{ val := .var "r2" }]), ([.sym "argument2"], [{ val := .var "r3" }])],
        .make (.var "s5") [([.sym "argument1"], [{ val := .var "r3" }]), ([.sym "argument2"], [{ val := .var "r1" }])],
        .make (.var "s6") [([.sym "argument1"], [{ val := .var "r3" }]), ([.sym "argument2"], [{ val := .var "r2" }])],
        .make (.var "u1") [([.sym "argument1"], [{ val := .var "a1" }]), ([.sym "argument2"], [{ val := .var "r1" }])],
        .make (.var "u2") [([.sym "argument1"], [{ val := .var "a2" }]), ([.sym "argument2"], [{ val := .var "r2" }])],
        .make (.var "u3") [([.sym "argument1"], [{ val := .var "a3" }]), ([.sym "argument2"], [{ val := .var "r3" }])]] }

def r_wizards_propose_self_unknown : Prod :=
  { name := "wizards*propose*self-unknown",
    doc := ["self-unknown <record>: a wizard's own spot, neither known white nor black: a new mark variable."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "wizards"] }, { path := [.sym "flags", .sym "mea-operator-selection"], vals := [.sym "true"] }, { path := [.sym "desireds", .sym "unachieved-desireds"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "r"] }],
        .pos false (.var "r") [{ path := [.sym "type"], vals := [.sym "record"] }, { path := [.sym "own"], vals := [.int (1)] }, { path := [.sym "white"], vals := [.int (1)], neg := true }, { path := [.sym "black"], vals := [.int (1)], neg := true }, { path := [.sym "mark"], vals := [.int (0)] }, { path := [.sym "var"], vals := [.int (0)] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "self-unknown" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "action-handle"], [{ val := .sym "self-unknown" }]), ([.sym "argument1"], [{ val := .var "r" }]), ([.sym "argument-count"], [{ val := .int (1) }]), ([.sym "desireds"], [{ val := .var "pre" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (0) }])]] }

def r_wizards_apply_self_unknown_internal : Prod :=
  { name := "wizards*apply*self-unknown*internal",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "wizards"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "internal-actions"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "self-unknown"] }, { path := [.sym "pre-conditions-satisfied"], vals := [.sym "true"] }, { path := [.sym "argument1", .sym "object-handle"], vals := [.lit (.var "rh")] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects"], vals := [.var "objs"] }],
        .pos false (.var "objs") [{ path := [.sym "object"], vals := [.var "r"] }],
        .pos false (.var "r") [{ path := [.sym "object-handle"], vals := [.lit (.var "rh")] }, { path := [.sym "var"], vals := [.var "v"] }, { path := [.sym "mv"], vals := [.var "old"] }, { path := [.sym "wiz"], vals := [.var "wz"] }]],
    acts := [.call "log" [.int (1), .fn "crlf" [], .str "In the view of wizard ", .var "wz", .str ", his own spot is unknown."],
        .make (.var "objs") [([.sym "object"], [{ val := .var "m" }])],
        .make (.var "m") [([.sym "object-handle"], [{ val := .fn "concat" [.sym "mv-", .var "rh"] }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "markvar" }]), ([.sym "value"], [{ val := .int (0) }]), ([.sym "assigned"], [{ val := .int (0) }]), ([.sym "untried"], [{ val := .int (1) }, { val := .int (2) }])],
        .make (.var "r") [([.sym "mv"], [{ val := .var "old", pref := "-" }, { val := .fn "concat" [.sym "mv-", .var "rh"] }]), ([.sym "var"], [{ val := .var "v", pref := "-" }, { val := .int (1) }])]] }

def r_wizards_propose_guess_black : Prod :=
  { name := "wizards*propose*guess-black",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "wizards"] }, { path := [.sym "flags", .sym "mea-operator-selection"], vals := [.sym "true"] }, { path := [.sym "desireds", .sym "unachieved-desireds"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }],
        .pos false (.var "w") [{ path := [.sym "objects", .sym "object"], vals := [.var "pz", .var "r", .var "k"] }],
        .pos false (.var "pz") [{ path := [.sym "type"], vals := [.sym "puzzle"] }, { path := [.sym "done"], vals := [.int (0)] }],
        .pos false (.var "r") [{ path := [.sym "type"], vals := [.sym "record"] }, { path := [.sym "own"], vals := [.int (1)] }, { path := [.sym "gblack"], vals := [.int (1)] }, { path := [.sym "view"], vals := [.var "kh"] }],
        .pos false (.var "k") [{ path := [.sym "object-handle"], vals := [.lit (.var "kh")] }, { path := [.sym "depth"], vals := [.int (1)] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "guess-black" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "action-handle"], [{ val := .sym "guess-black" }]), ([.sym "argument1"], [{ val := .var "r" }]), ([.sym "argument-count"], [{ val := .int (1) }]), ([.sym "desireds"], [{ val := .var "pre" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (0) }])]] }

def r_wizards_apply_guess_black_internal : Prod :=
  { name := "wizards*apply*guess-black*internal",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "wizards"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "internal-actions"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "guess-black"] }, { path := [.sym "pre-conditions-satisfied"], vals := [.sym "true"] }, { path := [.sym "argument1", .sym "wiz"], vals := [.var "wz"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "pz"] }],
        .pos false (.var "pz") [{ path := [.sym "type"], vals := [.sym "puzzle"] }, { path := [.sym "done"], vals := [.var "d"] }]],
    acts := [.call "log" [.int (1), .fn "crlf" [], .str "Wizard ", .var "wz", .str " guesses his spot is black."],
        .make (.var "pz") [([.sym "done"], [{ val := .var "d", pref := "-" }, { val := .int (1) }])]] }

def r_wizards_propose_guess_white : Prod :=
  { name := "wizards*propose*guess-white",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "wizards"] }, { path := [.sym "flags", .sym "mea-operator-selection"], vals := [.sym "true"] }, { path := [.sym "desireds", .sym "unachieved-desireds"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }],
        .pos false (.var "w") [{ path := [.sym "objects", .sym "object"], vals := [.var "pz", .var "r", .var "k"] }],
        .pos false (.var "pz") [{ path := [.sym "type"], vals := [.sym "puzzle"] }, { path := [.sym "done"], vals := [.int (0)] }],
        .pos false (.var "r") [{ path := [.sym "type"], vals := [.sym "record"] }, { path := [.sym "own"], vals := [.int (1)] }, { path := [.sym "gwhite"], vals := [.int (1)] }, { path := [.sym "view"], vals := [.var "kh"] }],
        .pos false (.var "k") [{ path := [.sym "object-handle"], vals := [.lit (.var "kh")] }, { path := [.sym "depth"], vals := [.int (1)] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "+" }])],
        .make (.var "o") [([.sym "name"], [{ val := .sym "guess-white" }]), ([.sym "task-operator"], [{ val := .sym "true" }]), ([.sym "action-handle"], [{ val := .sym "guess-white" }]), ([.sym "argument1"], [{ val := .var "r" }]), ([.sym "argument-count"], [{ val := .int (1) }]), ([.sym "desireds"], [{ val := .var "pre" }])],
        .make (.var "pre") [([.sym "desired-count"], [{ val := .int (0) }])]] }

def r_wizards_apply_guess_white_internal : Prod :=
  { name := "wizards*apply*guess-white*internal",
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "wizards"] }, { path := [.sym "operator"], vals := [.var "o"] }, { path := [.sym "internal-actions"], vals := [.sym "true"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "guess-white"] }, { path := [.sym "pre-conditions-satisfied"], vals := [.sym "true"] }, { path := [.sym "argument1", .sym "wiz"], vals := [.var "wz"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "pz"] }],
        .pos false (.var "pz") [{ path := [.sym "type"], vals := [.sym "puzzle"] }, { path := [.sym "done"], vals := [.var "d"] }]],
    acts := [.call "log" [.int (1), .fn "crlf" [], .str "Wizard ", .var "wz", .str " guesses his spot is white."],
        .make (.var "pz") [([.sym "done"], [{ val := .var "d", pref := "-" }, { val := .int (1) }])]] }

def r_wizards_compare_self_unknown_first : Prod :=
  { name := "wizards*compare*self-unknown-first",
    doc := ["Search control of the original (preferences.soar), as evaluation rules in the task state."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "wizards"] }, { path := [.sym "operator"], vals := [.var "o", .sym "+"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "self-unknown"] }, { path := [.sym "argument1", .sym "var"], vals := [.int (0)] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := ">" }])]] }

def r_wizards_compare_complement_first : Prod :=
  { name := "wizards*compare*complement-first",
    doc := ["Search control in problem space wizards: complement first (best)."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "wizards"] }, { path := [.sym "operator"], vals := [.var "o", .sym "+"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "complement"] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := ">" }])]] }

def r_wizards_compare_guess_first : Prod :=
  { name := "wizards*compare*guess-first",
    doc := ["Search control in problem space wizards: guess first (best)."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "wizards"] }, { path := [.sym "operator"], vals := [.var "o", .sym "+"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.disj [.sym "guess-white", .sym "guess-black"]] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := ">" }])]] }

def r_wizards_compare_consider_last : Prod :=
  { name := "wizards*compare*consider-last",
    doc := ["Search control in problem space wizards: consider last (worst)."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "wizards"] }, { path := [.sym "operator"], vals := [.var "o", .sym "+"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "consider-knows"] }, { path := [.sym "argument1", .sym "modeled"], vals := [.int (0)] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "<" }])]] }

def r_wizards_compare_assume_late : Prod :=
  { name := "wizards*compare*assume-late",
    doc := ["Search control in problem space wizards: assume late (worst)."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "wizards"] }, { path := [.sym "operator"], vals := [.var "o", .sym "+"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.disj [.sym "assume-black", .sym "assume-white"]] }, { path := [.sym "argument3", .sym "value"], vals := [.int (0)] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "<" }])]] }

def r_wizards_compare_assume_before_consider : Prod :=
  { name := "wizards*compare*assume-before-consider",
    doc := ["Search control in problem space wizards: assume before consider (preference)."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "wizards"] }, { path := [.sym "operator"], vals := [.var "o", .sym "+"] }, { path := [.sym "operator"], vals := [.conj [.cmp "<>" (.var "o"), .var "o2"], .sym "+"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.disj [.sym "assume-black", .sym "assume-white"]] }],
        .pos false (.var "o2") [{ path := [.sym "name"], vals := [.sym "consider-knows"] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "> <o2>" }])]] }

def r_wizards_compare_prefer_deeper : Prod :=
  { name := "wizards*compare*prefer-deeper",
    doc := ["Prefer the deepest view: reject consider-knows in view k when another works in a child view of k."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "wizards"] }, { path := [.sym "operator"], vals := [.var "o", .sym "+"] }, { path := [.sym "operator"], vals := [.conj [.cmp "<>" (.var "o"), .var "o2"], .sym "+"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "consider-knows"] }, { path := [.sym "argument2", .sym "object-handle"], vals := [.var "kh"] }],
        .pos false (.var "o2") [{ path := [.sym "name"], vals := [.sym "consider-knows"] }, { path := [.sym "argument2", .sym "parent"], vals := [.var "kh"] }]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "-" }])]] }

def r_wizards_compare_prefer_new_names : Prod :=
  { name := "wizards*compare*prefer-new-names",
    doc := ["Prefer modelling a wizard who has no view yet."],
    conds := [.pos true (.var "s") [{ path := [.sym "problem-space", .sym "name"], vals := [.sym "wizards"] }, { path := [.sym "operator"], vals := [.var "o", .sym "+"] }, { path := [.sym "operator"], vals := [.conj [.cmp "<>" (.var "o"), .var "o2"], .sym "+"] }, { path := [.sym "world"], vals := [.var "w"] }],
        .pos false (.var "o") [{ path := [.sym "name"], vals := [.sym "consider-knows"] }, { path := [.sym "argument1", .sym "wiz"], vals := [.var "wz"] }],
        .pos false (.var "o2") [{ path := [.sym "name"], vals := [.sym "consider-knows"] }, { path := [.sym "argument1", .sym "wiz"], vals := [.var "wz2"] }],
        .pos false (.var "w") [{ path := [.sym "anchored-world"], vals := [.sym "true"] }, { path := [.sym "objects", .sym "object"], vals := [.var "v"] }],
        .pos false (.var "v") [{ path := [.sym "type"], vals := [.sym "view"] }, { path := [.sym "owner"], vals := [.var "wz"] }],
        .ncc [.pos false (.var "w") [{ path := [.sym "objects", .sym "object"], vals := [.var "v2"] }], .pos false (.var "v2") [{ path := [.sym "type"], vals := [.sym "view"] }, { path := [.sym "owner"], vals := [.var "wz2"] }]]],
    acts := [.make (.var "s") [([.sym "operator"], [{ val := .var "o", pref := "-" }])]] }

def v_wizards : Variant :=
  { family := "wizards", name := "wizards",
    about := ["Three wizards: A sees B and C marked white and must say his own colour; nested models of what each wizard knows."],
    firstload := ["chunk never"],
    task := { name := "wizards", psExtra := [([.sym "dont-copy-object-attribute"], [{ val := .sym "own" }]), ([.sym "dont-copy-object-attribute"], [{ val := .sym "white" }]), ([.sym "dont-copy-object-attribute"], [{ val := .sym "black" }]), ([.sym "dont-copy-object-attribute"], [{ val := .sym "blackish" }]), ([.sym "dont-copy-object-attribute"], [{ val := .sym "gwhite" }]), ([.sym "dont-copy-object-attribute"], [{ val := .sym "gblack" }]), ([.sym "dont-copy-object-attribute"], [{ val := .sym "contra" }])], flags := [("mea-operator-selection", .sym "true")], environmentNone := true,
              initBody := [.make (.var "objs") [([.sym "object"], [{ val := .var "pz" }, { val := .var "v1" }, { val := .var "ra" }, { val := .var "rb" }, { val := .var "rc" }])],
      .make (.var "pz") [([.sym "object-handle"], [{ val := .sym "puzzle" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "puzzle" }]), ([.sym "done"], [{ val := .int (0) }]), ([.sym "nviews"], [{ val := .int (1) }])],
      .make (.var "v1") [([.sym "object-handle"], [{ val := .sym "view-1" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "view" }]), ([.sym "vid"], [{ val := .int (1) }]), ([.sym "owner"], [{ val := .int (1) }]), ([.sym "depth"], [{ val := .int (1) }]), ([.sym "parent"], [{ val := .sym "none" }])],
      .make (.var "ra") [([.sym "object-handle"], [{ val := .sym "A" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "record" }]), ([.sym "wiz"], [{ val := .int (1) }]), ([.sym "mark"], [{ val := .int (0) }]), ([.sym "var"], [{ val := .int (0) }]), ([.sym "modeled"], [{ val := .int (0) }]), ([.sym "aguess"], [{ val := .int (0) }]), ([.sym "view"], [{ val := .sym "view-1" }]), ([.sym "mv"], [{ val := .sym "none" }])],
      .make (.var "rb") [([.sym "object-handle"], [{ val := .sym "B" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "record" }]), ([.sym "wiz"], [{ val := .int (2) }]), ([.sym "mark"], [{ val := .int (1) }]), ([.sym "var"], [{ val := .int (0) }]), ([.sym "modeled"], [{ val := .int (0) }]), ([.sym "aguess"], [{ val := .int (0) }]), ([.sym "view"], [{ val := .sym "view-1" }]), ([.sym "mv"], [{ val := .sym "none" }])],
      .make (.var "rc") [([.sym "object-handle"], [{ val := .sym "C" }]), ([.sym "anchored"], [{ val := .sym "true" }]), ([.sym "type"], [{ val := .sym "record" }]), ([.sym "wiz"], [{ val := .int (3) }]), ([.sym "mark"], [{ val := .int (1) }]), ([.sym "var"], [{ val := .int (0) }]), ([.sym "modeled"], [{ val := .int (0) }]), ([.sym "aguess"], [{ val := .int (0) }]), ([.sym "view"], [{ val := .sym "view-1" }]), ([.sym "mv"], [{ val := .sym "none" }])],
      .make (.var "w") [([.sym "sib"], [{ val := .var "s1" }, { val := .var "s2" }, { val := .var "s3" }, { val := .var "s4" }, { val := .var "s5" }, { val := .var "s6" }])],
      .make (.var "s1") [([.sym "argument1"], [{ val := .var "ra" }]), ([.sym "argument2"], [{ val := .var "rb" }])],
      .make (.var "s2") [([.sym "argument1"], [{ val := .var "ra" }]), ([.sym "argument2"], [{ val := .var "rc" }])],
      .make (.var "s3") [([.sym "argument1"], [{ val := .var "rb" }]), ([.sym "argument2"], [{ val := .var "ra" }])],
      .make (.var "s4") [([.sym "argument1"], [{ val := .var "rb" }]), ([.sym "argument2"], [{ val := .var "rc" }])],
      .make (.var "s5") [([.sym "argument1"], [{ val := .var "rc" }]), ([.sym "argument2"], [{ val := .var "ra" }])],
      .make (.var "s6") [([.sym "argument1"], [{ val := .var "rc" }]), ([.sym "argument2"], [{ val := .var "rb" }])],
      .make (.var "ds") [([.sym "desired-count"], [{ val := .int (1) }]), ([.sym "desired"], [{ val := .var "d1" }])],
      .make (.var "d1") [([.sym "object"], [{ val := .var "d1o" }])],
      .make (.var "d1o") [([.sym "object-handle"], [{ val := .sym "puzzle" }]), ([.sym "done"], [{ val := .int (1) }])]],
              initFile := none, initOpExtra := [], achieve := [.objectState], achieveSpaces := [], indifferent := some "n problem space wizards: task operator indifferent (preference).", indifferentExcept := [], ancestors := false },
    files := [("elaborations.soar", [.ps, .achieve .objectState]),
              ("initialize-wizards.soar", [.init]),
              ("derived.soar", [.p r_wizards_elaborate_record_own, .p r_wizards_elaborate_record_white_mark, .p r_wizards_elaborate_record_white_two_blackish_sibs, .p r_wizards_elaborate_record_white_via_sub, .p r_wizards_elaborate_record_black_mark, .p r_wizards_elaborate_record_black_via_sub, .p r_wizards_elaborate_record_blackish_black, .p r_wizards_elaborate_record_blackish_assumed, .p r_wizards_elaborate_record_gwhite_own, .p r_wizards_elaborate_record_gwhite_guess, .p r_wizards_elaborate_record_gwhite_via_sub, .p r_wizards_elaborate_record_gblack_own, .p r_wizards_elaborate_record_gblack_guess, .p r_wizards_elaborate_record_gblack_via_sub, .p r_wizards_elaborate_record_contra_white_unguessed, .p r_wizards_elaborate_record_contra_black_unguessed, .p r_wizards_elaborate_record_contra_both]),
              ("ascribe.soar", [.p r_wizards_propose_ascribe_guess_gv_0, .p r_wizards_propose_ascribe_guess_gv_1, .p r_wizards_propose_ascribe_guess_gv_2, .p r_wizards_apply_ascribe_guess_internal, .p r_wizards_propose_ascribe_mark, .p r_wizards_apply_ascribe_mark_internal, .p r_wizards_propose_ascribe_unknown, .p r_wizards_apply_ascribe_unknown_internal]),
              ("assume.soar", [.p r_wizards_propose_assume_black, .p r_wizards_apply_assume_black_internal, .p r_wizards_propose_assume_white, .p r_wizards_apply_assume_white_internal]),
              ("complement.soar", [.p r_wizards_propose_complement_u_1, .p r_wizards_propose_complement_u_2, .p r_wizards_apply_complement_internal, .p r_wizards_propose_consider_knows, .p r_wizards_apply_consider_knows_internal, .p r_wizards_propose_self_unknown, .p r_wizards_apply_self_unknown_internal]),
              ("guess.soar", [.p r_wizards_propose_guess_black, .p r_wizards_apply_guess_black_internal, .p r_wizards_propose_guess_white, .p r_wizards_apply_guess_white_internal]),
              ("search-control.soar", [.p r_wizards_compare_self_unknown_first, .p r_wizards_compare_complement_first, .p r_wizards_compare_guess_first, .p r_wizards_compare_consider_last, .p r_wizards_compare_assume_late, .p r_wizards_compare_assume_before_consider, .p r_wizards_compare_prefer_deeper, .p r_wizards_compare_prefer_new_names, .indifferent])] }

def variants : List Variant := [v_wizards]

end Fam.Families.Wizards
