/-!
# Family.Prod: typed Soar productions for world-convention agents

The lower layer of the family description language (Family/Task.lean is the upper layer). A production
is a typed value, not text: conditions are identifier tests with attribute paths and value tests,
actions are WME creations with preferences and right-hand-side function calls. `Prod.toSoar` prints
Soar source. Typed productions can be checked in Lean (Family/Check.lean) before they are written.

Written 19 November 2026 by Claude, supervised by John E. Laird.
-/
namespace Fam

private def dropR (s : String) (k : Nat) : String := String.ofList (s.toList.take (s.length - k))
private def dropL (s : String) (k : Nat) : String := String.ofList (s.toList.drop k)
private def spaces (k : Nat) : String := String.ofList (List.replicate k ' ')

/-- A test on a value (or on an attribute name). -/
inductive VT where
  | sym  : String → VT            -- a constant symbol, printed as is (quote with |..| inside the string if needed)
  | int  : Int → VT
  | flt  : String → VT            -- a float constant, kept as written
  | var  : String → VT            -- <v>
  | cmp  : String → VT → VT       -- `<> x`, `< x`, `>= x`, `<=> x`
  | conj : List VT → VT           -- { t1 t2 ... }
  | disj : List VT → VT           -- << a b c >>
  | lit  : VT → VT                -- `$ t`: chunking keeps the matched constant
  deriving Repr, Inhabited, BEq

partial def VT.toSoar : VT → String
  | .sym s => s
  | .int i => toString i
  | .flt s => s
  | .var v => s!"<{v}>"
  | .cmp op t => s!"{op} {t.toSoar}"
  | .conj ts => "{ " ++ " ".intercalate (ts.map VT.toSoar) ++ " }"
  | .disj ts => "<< " ++ " ".intercalate (ts.map VT.toSoar) ++ " >>"
  | .lit t => s!"$ {t.toSoar}"

/-- One attribute test in a condition: `^a.b.c v1 v2`, or `-^a v` when negated. -/
structure AV where
  path : List VT
  vals : List VT := []
  neg  : Bool := false
  deriving Repr, Inhabited, BEq

def AV.toSoar (a : AV) : String :=
  let p := ".".intercalate (a.path.map VT.toSoar)
  let v := if a.vals.isEmpty then "" else " " ++ " ".intercalate (a.vals.map VT.toSoar)
  (if a.neg then "-" else "") ++ "^" ++ p ++ v

/-- A condition element. -/
inductive Cond where
  /-- `(state <s> ...)` when `isState`, else `(<id> ...)`. -/
  | pos : (isState : Bool) → VT → List AV → Cond
  /-- A negated condition `-(...)`. -/
  | neg : Cond → Cond
  /-- A negated conjunction `-{ ... }`. -/
  | ncc : List Cond → Cond
  deriving Repr, Inhabited, BEq

partial def Cond.toSoar (ind : String) : Cond → String
  | .pos st id avs =>
    let head := (if st then "(state " else "(") ++ id.toSoar
    let pad := spaces (head.length + 1)
    match avs with
    | [] => head ++ ")"
    | a :: rest => ind ++ head ++ " " ++ a.toSoar ++ String.join (rest.map (fun x => "\n" ++ ind ++ pad ++ x.toSoar)) ++ ")"
  | .neg c => let s := c.toSoar ind; dropR ind 1 ++ "-" ++ dropL s ind.length
  | .ncc cs =>
    let inner := cs.map (fun c => c.toSoar (ind ++ " "))
    match inner with
    | [] => ind ++ "-{}"
    | f :: rest => dropR ind 1 ++ "-{" ++ dropL f (ind.length + 1) ++ String.join (rest.map ("\n" ++ ·)) ++ "}"

/-- A right-hand-side value. -/
inductive RV where
  | sym  : String → RV
  | int  : Int → RV
  | flt  : String → RV
  | var  : String → RV
  | str  : String → RV             -- |text|
  | fn   : String → List RV → RV   -- (name args): (+ <a> 1), (crlf)
  deriving Repr, Inhabited, BEq

partial def RV.toSoar : RV → String
  | .sym s => s
  | .int i => toString i
  | .flt s => s
  | .var v => s!"<{v}>"
  | .str s => "|" ++ s ++ "|"
  | .fn n args => "(" ++ " ".intercalate (n :: args.map RV.toSoar) ++ ")"

/-- A value with an optional preference (`+`, `-`, `=`, `>`, `<`, `!`, `~`, `@`, `= 0.5`, `> <o2>`). -/
structure PV where
  val  : RV
  pref : String := ""
  deriving Repr, Inhabited, BEq

def PV.toSoar (p : PV) : String := p.val.toSoar ++ (if p.pref = "" then "" else " " ++ p.pref)

/-- An action. -/
inductive Act where
  /-- `(<id> ^a v1 v2 ^b v3 ...)`: attribute (possibly a variable or dotted path) and its values. -/
  | make : RV → List (List RV × List PV) → Act
  /-- A stand-alone function call: `(log 1 (crlf) |text|)`, `(halt)`, `(force-learn <s>)`. -/
  | call : String → List RV → Act
  deriving Repr, Inhabited, BEq

def Act.toSoar : Act → String
  | .make id avs =>
    let head := "(" ++ id.toSoar
    let pad := spaces (head.length + 1)
    let one := fun (p : List RV × List PV) => "^" ++ ".".intercalate (p.1.map RV.toSoar) ++ " " ++ " ".intercalate (p.2.map PV.toSoar)
    match avs with
    | [] => "   " ++ head ++ ")"
    | a :: rest => "   " ++ head ++ " " ++ one a ++ String.join (rest.map (fun x => "\n   " ++ pad ++ one x)) ++ ")"
  | .call n args => "   (" ++ " ".intercalate (n :: args.map RV.toSoar) ++ ")"

/-- A production. `doc` lines are written as `##` comments before it. -/
structure Prod where
  name  : String
  doc   : List String := []
  flags : List String := []         -- :o-support, :i-support, :default, :chunk, :template
  conds : List Cond
  acts  : List Act
  deriving Repr, Inhabited, BEq

def Prod.toSoar (p : Prod) : String :=
  let docs := String.join (p.doc.map (fun l => "## " ++ l ++ "\n"))
  let fl := String.join (p.flags.map (fun f => "   " ++ f ++ "\n"))
  docs ++ "sp {" ++ p.name ++ "\n" ++ fl ++
  "\n".intercalate (p.conds.map (·.toSoar "   ")) ++ "\n-->\n" ++
  "\n".intercalate (p.acts.map Act.toSoar) ++ "\n}\n"

/-! Short constructors used by the descriptions. -/
def v (s : String) : VT := .var s
def c (s : String) : VT := .sym s
def n (i : Int) : VT := .int i
def ne (t : VT) : VT := .cmp "<>" t
def lt (t : VT) : VT := .cmp "<" t
def gt (t : VT) : VT := .cmp ">" t
def le (t : VT) : VT := .cmp "<=" t
def ge (t : VT) : VT := .cmp ">=" t
def lit (t : VT) : VT := .lit t
/-- `^a.b v...` with symbol path steps. -/
def at_ (p : String) (vs : List VT) : AV := { path := (p.splitOn ".").map VT.sym, vals := vs }
def nat_ (p : String) (vs : List VT) : AV := { path := (p.splitOn ".").map VT.sym, vals := vs, neg := true }
def st (avs : List AV) : Cond := .pos true (.var "s") avs
def id_ (x : String) (avs : List AV) : Cond := .pos false (.var x) avs
def rv (s : String) : RV := .var s
def rs (s : String) : RV := .sym s
def ri (i : Int) : RV := .int i
def mkw (x : String) (avs : List (String × List PV)) : Act := .make (.var x) (avs.map fun (a, vs) => ((a.splitOn ".").map RV.sym, vs))
def pv (r : RV) : PV := { val := r }
def pvp (r : RV) (p : String) : PV := { val := r, pref := p }
def log1 (parts : List RV) : Act := .call "log" (.int 1 :: .fn "crlf" [] :: parts)

end Fam
