import Family.Prod
/-!
# Family.Task: task-level constructs of a world-convention agent

The upper layer of the family description language. A `Task` states, at the level of the world
conventions, what every world-convention agent has: its problem space (with the derived attributes
that look-ahead must not copy), its initialization (world objects, relations, desireds, flag
overrides), how its desireds are judged achieved, and its default search control. `Task.prods`
compiles these into typed productions (Family.Prod). Family-specific knowledge (operators, derived
attributes, evaluation) is added as typed productions in the family's description.

Conventions (World-Conventions-v6, level IDs of 18 Nov 2026): L7-008 problem space; L7-010
initialize-<task>; L8-018 to L8-020 task-supplied achieved/unachieved; L14-026 do-not-copy list;
L9-001 ^task-operator; L3-005 problem-space test in the first condition.

Written 19 November 2026 by Claude, supervised by John E. Laird.
-/
namespace Fam

/-- How a variant's desireds are judged (task-supplied, L8-018). -/
inductive Achieve where
  | objectState        -- object-property desireds of states
  | objectOperator     -- object-property desireds of proposed operators (their preconditions)
  | relationState      -- two-argument relation desireds of states
  | relationOperator   -- relation desireds of proposed operators
  deriving Repr, Inhabited, BEq, DecidableEq

structure Task where
  /-- The task (and problem-space) name. -/
  name : String
  /-- Extra attributes of the problem space, e.g. `^dont-copy-object-attribute free` (L14-026). -/
  psExtra : List (List RV × List PV) := []
  /-- Flag overrides set at initialization (`^flag-override`, L6-003). -/
  flags : List (String × RV) := []
  /-- `^environment none` (no external environment, L7-011). -/
  environmentNone : Bool := true
  /-- Actions of initialize-<task> after the state's name, desireds and flags: world objects,
  relations and desireds (they may use <s>, <w>, <objs>, <ds>). -/
  initBody : List Act := []
  /-- File of the initialization rules. -/
  initFile : Option String := none
  /-- Extra attributes on the initialize operator. -/
  initOpExtra : List (List RV × List PV) := []
  achieve : List Achieve := [.objectState]
  /-- Further problem spaces whose states judge the desireds the same way (tested with << >>). -/
  achieveSpaces : List String := []
  /-- Task operators are made indifferent by a separate evaluation rule. -/
  indifferent : Option String := none
  /-- Task operators left out of the indifferent rule (tested with ^name <> ...). -/
  indifferentExcept : List String := []
  /-- Ancestor-world elaborations (repeated-state detection in look-ahead). -/
  ancestors : Bool := false
  deriving Repr, Inhabited

namespace Task
variable (t : Task)

private def s := VT.var "s"

def problemSpace : List Prod :=
  let p := (Act.make (.var "p") ((([RV.sym "name"], [pv (rs t.name)])) :: t.psExtra))
  [ { name := s!"{t.name}*elaborate*problem-space",
      doc := [s!"Problem space of the task state and of look-ahead states (both have ^name {t.name}); L7-008, L15-003."],
      conds := [st [at_ "name" [c t.name]]],
      acts := [mkw "s" [("problem-space", [pv (rv "p")])], p] },
    { name := s!"{t.name}*elaborate*problem-space*mea-substate",
      doc := ["The same problem space on a means-ends (MEA) substate of a task operator; L17-001."],
      conds := [st [at_ "impasse" [c "no-change"], at_ "attribute" [c "operator"], at_ "superstate" [v "ss"]],
                id_ "ss" [at_ "problem-space.name" [c t.name], at_ "operator" [v "so"]],
                id_ "so" [at_ "task-operator" [c "true"], nat_ "pre-conditions-satisfied" [c "true"]]],
      acts := [mkw "s" [("problem-space", [pv (rv "p")])], p] } ]

def initProds : List Prod :=
  let nm := s!"initialize-{t.name}"
  let first := Act.make (.var "s") ((([RV.sym "name"], [pv (rs t.name)])) ::
      ((if t.environmentNone then [([RV.sym "environment"], [pv (rs "none")])] else []) ++
       [([RV.sym "desireds"], [pv (rv "ds")])]))
  let fl : List Act := if t.flags.isEmpty then [] else
      [mkw "s" [("flag-override", [pv (rv "f")])],
       .make (.var "f") (t.flags.map fun (k, x) => ([RV.sym k], [pv x]))]
  [ { name := s!"{t.name}*propose*{nm}",
      doc := [s!"{nm} (L7-010, L7-011, L6-003): world objects, relations, desireds and flag overrides."],
      conds := [st [at_ "superstate" [c "nil"], at_ "world" [v "w"], nat_ "name" []]],
      acts := [mkw "s" [("operator", [pvp (rv "o") "+ >"])],
               .make (.var "o") ((([RV.sym "name"], [pv (rs nm)])) :: (([RV.sym "task-operator"], [pv (rs "false")])) :: t.initOpExtra)] },
    { name := s!"{t.name}*apply*{nm}",
      conds := [st [at_ "operator.name" [c nm], at_ "world" [v "w"]], id_ "w" [at_ "objects" [v "objs"]]],
      acts := [first] ++ fl ++ t.initBody ++ [log1 [.str s!"Initialize {t.name}."]] } ]

private def psTest : VT := if t.achieveSpaces.isEmpty then c t.name else .disj ((t.name :: t.achieveSpaces).map VT.sym)

private def objTest : AV :=
  { path := [.conj [ne (c "object-handle"), ne (c "anchored"), ne (c "duplicate-of"), ne (c "origin-object-handle"), v "a"]], vals := [v "v"] }

def achieveProds : Achieve → List Prod
  | .objectState =>
    [ { name := s!"{t.name}*elaborate*desired*achieved*object-property",
        doc := ["Object-property desireds: achieved when an anchored world object with the handle has the value (L8-018)."],
        conds := [st [at_ "problem-space.name" [psTest t], at_ "desireds" [v "ds"], at_ "world" [v "w"]], id_ "ds" [at_ "desired" [v "d"]], id_ "d" [at_ "object" [v "do"]],
                  id_ "do" [at_ "object-handle" [lit (v "h")], objTest],
                  id_ "w" [at_ "anchored-world" [c "true"], at_ "objects.object" [v "ob"]],
                  id_ "ob" [at_ "object-handle" [lit (v "h")], { path := [v "a"], vals := [v "v"] }]],
        acts := [mkw "ds" [("achieved", [pv (rv "d")])]] },
      { name := s!"{t.name}*elaborate*desired*unachieved*object-property",
        doc := ["... and unachieved otherwise (a positive WME, L8-020; no $ inside the negation)."],
        conds := [st [at_ "problem-space.name" [psTest t], at_ "desireds" [v "ds"], at_ "world" [v "w"]], id_ "ds" [at_ "desired" [v "d"]], id_ "d" [at_ "object" [v "do"]],
                  id_ "do" [at_ "object-handle" [lit (v "h")], objTest],
                  id_ "w" [at_ "anchored-world" [c "true"]],
                  .ncc [id_ "w" [at_ "objects.object" [v "ob"]], id_ "ob" [at_ "object-handle" [v "h"], { path := [v "a"], vals := [v "v"] }]]],
        acts := [mkw "ds" [("unachieved", [pv (rv "d")])]] } ]
  | .objectOperator =>
    [ { name := s!"{t.name}*elaborate*operator-desired*achieved*object-property",
        doc := ["Object-property desireds of a proposed operator (its preconditions; L9-006)."],
        conds := [st [at_ "problem-space.name" [psTest t], at_ "operator" [v "op", c "+"], at_ "world" [v "w"]], id_ "op" [at_ "desireds" [v "ds"]], id_ "ds" [at_ "desired" [v "d"]],
                  id_ "d" [at_ "object" [v "do"]], id_ "do" [at_ "object-handle" [lit (v "h")], objTest],
                  id_ "w" [at_ "anchored-world" [c "true"], at_ "objects.object" [v "ob"]],
                  id_ "ob" [at_ "object-handle" [lit (v "h")], { path := [v "a"], vals := [v "v"] }]],
        acts := [mkw "ds" [("achieved", [pv (rv "d")])]] },
      { name := s!"{t.name}*elaborate*operator-desired*unachieved*object-property",
        conds := [st [at_ "problem-space.name" [psTest t], at_ "operator" [v "op", c "+"], at_ "world" [v "w"]], id_ "op" [at_ "desireds" [v "ds"]], id_ "ds" [at_ "desired" [v "d"]],
                  id_ "d" [at_ "object" [v "do"]], id_ "do" [at_ "object-handle" [lit (v "h")], objTest],
                  id_ "w" [at_ "anchored-world" [c "true"]],
                  .ncc [id_ "w" [at_ "objects.object" [v "ob"]], id_ "ob" [at_ "object-handle" [v "h"], { path := [v "a"], vals := [v "v"] }]]],
        acts := [mkw "ds" [("unachieved", [pv (rv "d")])]] } ]
  | .relationState => relProds "desireds" "desired" []
  | .relationOperator => relProds "operator-desired" "operator-desired" [at_ "operator" [v "op", c "+"]]
where
  relProds (kind _k2 : String) (opTest : List AV) : List Prod :=
    let head : List Cond := if opTest.isEmpty then [st [at_ "problem-space.name" [psTest t], at_ "desireds" [v "ds"], at_ "world" [v "w"]]]
      else [st ([at_ "problem-space.name" [psTest t]] ++ opTest ++ [at_ "world" [v "w"]]), id_ "op" [at_ "desireds" [v "ds"]]]
    let args := fun (litH : Bool) => [at_ "argument1.object-handle" [if litH then lit (v "h1") else v "h1"],
                                      at_ "argument2.object-handle" [if litH then lit (v "h2") else v "h2"]]
    let nmk := if opTest.isEmpty then "desired" else "operator-desired"
    [ { name := s!"{t.name}*elaborate*{nmk}*achieved*relation",
        doc := ["Relation desireds (two arguments): achieved when the world has the relation between those handles (L8-018)."],
        conds := head ++ [id_ "ds" [at_ "desired" [v "d"]], id_ "d" [{ path := [v "rel"], vals := [v "dr"] }], id_ "dr" (args true),
                  id_ "w" [at_ "anchored-world" [c "true"], { path := [v "rel"], vals := [v "wr"] }], id_ "wr" (args true)],
        acts := [mkw "ds" [("achieved", [pv (rv "d")])]] },
      { name := s!"{t.name}*elaborate*{nmk}*unachieved*relation",
        conds := head ++ [id_ "ds" [at_ "desired" [v "d"]], id_ "d" [{ path := [v "rel"], vals := [v "dr"] }], id_ "dr" (args true),
                  id_ "w" [at_ "anchored-world" [c "true"]],
                  .ncc [id_ "w" [{ path := [v "rel"], vals := [v "wr"] }], id_ "wr" (args false)]],
        acts := [mkw "ds" [("unachieved", [pv (rv "d")])]] } ]

def indifferentProds : List Prod :=
  match t.indifferent with
  | none => []
  | some why =>
    [ { name := s!"{t.name}*compare*task-operator*indifferent",
        doc := [s!"Search control: {why}, so task operators are made indifferent here",
                "(an evaluation rule; proposals create only the acceptable preference, L9-004)."],
        conds := [st [at_ "problem-space.name" [c t.name], at_ "operator" [v "o", c "+"]], id_ "o" ([at_ "task-operator" [c "true"]] ++ t.indifferentExcept.map (fun x => at_ "name" [ne (c x)]))],
        acts := [mkw "s" [("operator", [pvp (rv "o") "="])]] } ]

def ancestorProds : List Prod :=
  if !t.ancestors then [] else
    [ { name := s!"{t.name}*elaborate*ancestor*superstate",
        doc := ["Ancestors of a state that have the task's problem space (used for repeated-state detection in look-ahead)."],
        conds := [st [at_ "superstate" [v "ss"]], id_ "ss" [at_ "problem-space.name" [c t.name], at_ "world" [v "aw"]],
                  id_ "aw" [at_ "anchored-world" [c "true"]]],
        acts := [mkw "s" [("ancestor-world", [pv (rv "aw")])]] },
      { name := s!"{t.name}*elaborate*ancestor*inherit",
        conds := [st [at_ "superstate.ancestor-world" [v "aw"]]],
        acts := [mkw "s" [("ancestor-world", [pv (rv "aw")])]] } ]

end Task

/-- A variant: a task with family knowledge, written as files of productions. A file's entries are
the task-level constructs it holds (`.ps`, `.init`, ...) and typed productions (`.p`). -/
inductive Item where
  | ps | init | achieve (a : Achieve) | indifferent | ancestors
  | p (x : Prod)
  deriving Repr, Inhabited

structure Variant where
  family : String
  name : String
  task : Task
  about : List String := []
  firstload : List String := []
  files : List (String × List Item)
  deriving Repr, Inhabited

def Variant.render (vr : Variant) : List (String × String) :=
  let t := vr.task
  let item : Item → List Prod
    | .ps => t.problemSpace | .init => t.initProds | .achieve a => t.achieveProds a
    | .indifferent => t.indifferentProds | .ancestors => t.ancestorProds | .p x => [x]
  vr.files.map fun (f, items) => (f, "\n".intercalate ((items.map item).foldr (· ++ ·) [] |>.map Prod.toSoar))

end Fam
