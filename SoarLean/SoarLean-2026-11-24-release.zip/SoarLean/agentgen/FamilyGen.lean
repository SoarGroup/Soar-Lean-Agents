import Family
/-!
familygen: write the world-convention family agents from their Lean descriptions (Family/Families).

usage: familygen OUTDIR [FAMILY ...]
Writes OUTDIR/<family>/world-lean/<variant>/: <variant>.soar (load file), _firstload.soar and the
rule files. The load file loads the shared library from ../../../../../Soar/soar-library.
Written 19 November 2026 by Claude, supervised by John E. Laird.
-/
open Fam

def loadFile (vr : Variant) : String :=
  let lines := [s!"## {vr.name}: world-lean version, generated through Lean (agentgen Family/Families) on 19 Nov 2026."] ++
    vr.about.map ("## " ++ ·) ++
    ["## Loads the shared Soar library from Soar/soar-library; the path assumes this folder is",
     "## Tasks/Families/<family>/world-lean/<variant>.",
     "pushd \"../../../../../Soar/soar-library\"", "source soar-library.soar", "popd", "source _firstload.soar"] ++
    vr.files.map (fun (f, _) => s!"source {f}")
  "\n".intercalate lines ++ "\n"

def main (args : List String) : IO UInt32 := do
  match args with
  | [] => IO.eprintln "usage: familygen OUTDIR [FAMILY ...]"; return 1
  | out :: fams =>
    let mut n := 0
    for vr in allVariants do
      if fams.isEmpty || fams.contains vr.family then
        let dir : System.FilePath := out ++ "/" ++ vr.family ++ "/world-lean/" ++ vr.name
        IO.FS.createDirAll dir
        IO.FS.writeFile (dir / s!"{vr.name}.soar") (loadFile vr)
        IO.FS.writeFile (dir / "_firstload.soar") ("\n".intercalate ("## Soar settings (from the original program)" :: vr.firstload) ++ "\n")
        for (f, txt) in vr.render do
          IO.FS.writeFile (dir / f) txt
        n := n + 1
    IO.println s!"familygen: wrote {n} variants"
    return 0
