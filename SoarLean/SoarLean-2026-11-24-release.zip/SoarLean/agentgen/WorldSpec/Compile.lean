import WorldSpec.Sem
/-!
# Path A: compiling a WorldSpec task to world-convention Soar rules, in Lean

The rule shapes are those of tools/wg.py (worldgen v19) and the Rosie pilot generators, so the
rules load with the shared library (Soar/soar-library) unchanged. Path B (worldgen/spec_backend.py)
writes the same text from the JSON export; the two outputs are compared byte for byte.

Emission scheme (shared with path B):
* An object variable `x` is `<x>`, declared by `(<objs> ^object <x>)` when it first occurs outside a
  relation; a constant handle `h` is `<k-h>`, declared with `(<k-h> ^object-handle h)`.
* `has x p c v`: `(<x> ^p c v)`; with a property `y.q` on the right, `(<y> ^q <y-q>)` first.
* `rel r [a₁ … aₙ]`: `(<w> ^r <rK>)` and `(<rK> ^argument1 a₁ … ^argumentn aₙ)`.
* `distinct x y`: `(<objs> ^object { <> <x> <y> })` (identifier inequality; no handle test).
* `lacks` and `none` are negations: they may define a maintained relation (evaluated in Lean for the
  initial world) but are refused in any compiled condition (W-CHK-009).
* A universal goal is expanded over the objects of its type in the initial world (positive tests).
* Object-handle tests on variables carry `$` (W-CHK-011).
-/
namespace WorldSpec

def v (x : String) : String := s!"<{x}>"
def kv (h : String) : String := s!"<k-{h}>"

/-- Compilation of one condition list: the lines, the variables declared so far and a counter. -/
structure CState where
  lines : Array String := #[]
  objs  : List String := []      -- variables declared as world objects (or bound)
  consts : List String := []     -- constant handles declared
  vals  : List String := []      -- value variables <y-q> declared
  rels  : List (String × List String × String) := []   -- relation conditions written: name, argument terms, variable
  n     : Nat := 0
  deriving Inhabited

abbrev CM := StateT CState (Except String)

def emit (l : String) : CM Unit := modify fun s => { s with lines := s.lines.push l }

def fresh (pfx : String) : CM String := do
  let s ← get; set { s with n := s.n + 1 }; pure s!"<{pfx}{s.n + 1}>"

def declObj (x : String) : CM Unit := do
  if !(← get).objs.contains x then
    emit s!"   (<objs> ^object {v x})"
    modify fun s => { s with objs := s.objs ++ [x] }

def markBound (x : String) : CM Unit := modify fun s =>
  if s.objs.contains x then s else { s with objs := s.objs ++ [x] }

def argTerm : Arg → CM String
  | .var x => pure (v x)
  | .h h => do
    if !(← get).consts.contains h then
      emit s!"   (<objs> ^object {kv h})"
      emit s!"   ({kv h} ^object-handle {h})"
      modify fun s => { s with consts := s.consts ++ [h] }
    pure (kv h)

def valVar (y q : String) : CM String := do
  let name := s!"<{y}-{q}>"
  if !(← get).vals.contains name then
    declObj y
    emit s!"   ({v y} ^{q} {name})"
    modify fun s => { s with vals := s.vals ++ [name] }
  pure name

def rhsTerm : Rhs → CM String
  | .val x => pure x.toSoar
  | .prop y q => valVar y q
  | .plus r1 r2 => do
    let a ← rhsTerm r1
    let b ← rhsTerm r2
    pure s!"(+ {a} {b})"

/-- The conditions for a relation tuple; a tuple already tested in this rule reuses its variable. -/
def relConds (r : String) (args : List Arg) (pfx : String) : CM String := do
  let ts ← args.mapM argTerm
  match (← get).rels.find? (fun (n, a, _) => n == r && a == ts) with
  | some (_, _, rv) => return rv
  | none => pure ()
  let rv ← fresh pfx
  emit s!"   (<w> ^{r} {rv})"
  let parts := (ts.zipIdx).map fun (t, k) => s!"^argument{k+1} {t}"
  emit s!"   ({rv} {" ".intercalate parts})"
  modify fun s => { s with rels := s.rels ++ [(r, ts, rv)] }
  for a in args do
    match a with
    | .var x => markBound x
    | _ => pure ()
  pure rv

partial def atomConds : Atom → CM Unit
  | .obj x t => do
    declObj x
    match t with
    | some ty => emit s!"   ({v x} ^type {ty})"
    | none => pure ()
  | .has x p c r => do
    if r.isArith then throw s!"cannot compile arithmetic in a condition ({x}.{p}): compute it in an effect"
    let rt ← rhsTerm r
    declObj x
    emit s!"   ({v x} ^{p} {c.toSoar}{rt})"
  | .rel r args => do let _ ← relConds r args "r"
  | .distinct x y => do
    declObj x
    if (← get).objs.contains y then
      emit s!"   (<objs> ^object \{ <> {v x} {v y} })"
    else
      emit s!"   (<objs> ^object \{ <> {v x} {v y} })"
      modify fun s => { s with objs := s.objs ++ [y] }
  | .lacks x p => do
    -- only in a derived relation's definition (checked by Task.wellFormed, W-CHK-009)
    declObj x
    emit s!"   -({v x} ^{p})"
  | .none as => do
    -- a negated conjunction: the inner conditions are written inside -{ ... }; names bound inside stay inside
    let outer ← get
    set { outer with lines := #[] }
    for a in as do atomConds a
    let inner ← get
    set { outer with n := inner.n }
    emit ("  -{" ++ (String.intercalate "\n" (inner.lines.toList.map fun l => (l.drop 1).toString)) ++ "}")

def runCM (s0 : CState) (m : CM Unit) : Except String CState := (m.run s0).map (·.2)

def sp (name : String) (lhs : Array String) (rhs : List String) (comment : String := "") : String :=
  let c := if comment == "" then "" else s!"\n## {comment}\n"
  c ++ s!"sp \{{name}\n" ++ "\n".intercalate lhs.toList ++ "\n-->\n" ++ "\n".intercalate rhs ++ "\n}\n"

def stmtNote (ns : List Nat) : String :=
  if ns.isEmpty then "" else " (statement" ++ (if ns.length > 1 then "s " else " ") ++ ", ".intercalate (ns.map toString) ++ ")"

/-! ## Fixed parts: initialization, problem space, flags, achievement (as tools/wg.py) -/

def objLine (o : Obj) : String :=
  let props := ([("type", Val.sym o.type)] ++ o.props).map fun (a, x) => s!"^{a} {x.toSoar}"
  s!"   ({kv o.handle} ^object-handle {o.handle} ^anchored true {" ".intercalate props})"

/-- One desireds structure: a single desired, ^<attr> true on the task object. -/
def desiredBlock (var pre attr : String) : String :=
  s!"   ({var} ^desired-count 1 ^desired <{pre}>)\n   (<{pre}> ^object <{pre}-o>)\n   (<{pre}-o> ^object-handle task ^{attr} true)\n"

/-- The initial desireds (World-Conventions L8-026 to L8-029): the goal, or the chain of phases with its loop,
termination desireds and repeat count. -/
def desiredsLines (t : Task) : String :=
  if t.phases.isEmpty then desiredBlock "<ds>" "d1" "goal-met" else
  let names := t.phases.zipIdx.map fun (_, k) => if k == 0 then "<ds>" else s!"<ph{k+1}>"
  let body := String.join <| (t.phases.zip names).zipIdx.map fun ((p, var), k) =>
    let nxt := match names[k+1]? with
      | some n => some n
      | none => t.loopStart.bind (names[·]?)
    desiredBlock var s!"p{k+1}d1" s!"{p.name}-met" ++
      (match nxt with | some n => s!"   ({var} ^next-desireds {n})\n" | none => "")
  let loop := match t.loopStart.bind (names[·]?) with | some n => s!"   ({n} ^loop-start true)\n" | none => ""
  let term := match t.termination with
    | some p => "   (<s> ^termination-desireds <tds>)\n" ++ desiredBlock "<tds>" "td1" s!"{p.name}-met"
    | none => ""
  let rc := match t.repeatCount with | some c => s!"   (<s> ^repeat-count {c})\n" | none => ""
  body ++ loop ++ term ++ rc

def initRules (t : Task) (st : State) : String :=
  let n := t.name
  let objs := " ".intercalate (st.objs.map (kv ·.handle))
  let rels := (st.rels.zipIdx).flatMap fun ((r, hs), k) =>
    [s!"   (<w> ^{r} <rel-{k+1}>)",
     s!"   (<rel-{k+1}> " ++ " ".intercalate ((hs.zipIdx).map fun (h, i) => s!"^argument{i+1} {kv h}") ++ ")"]
  s!"
## Propose initialize-{n} when its conditions below hold.
sp \{{n}*propose*initialize-{n}
   (state <s> ^superstate nil ^world <w> -^name)
-->
   (<s> ^operator <o> + >)
   (<o> ^name initialize-{n} ^task-operator false)
}

sp \{{n}*apply*initialize-{n}
   (state <s> ^operator.name initialize-{n} ^world <w>)
   (<w> ^objects <objs>)
-->
   (<s> ^name {n} ^desireds <ds>)
   (<objs> ^object {objs})
" ++ "\n".intercalate (st.objs.map objLine) ++ "\n" ++ desiredsLines t ++ "\n".intercalate rels ++ s!"
   (log 1 (crlf) |Initialize {n}.|)
}
"

def libraryCopied : List String := ["on", "above", "in"]

def Task.relNames (t : Task) (st : State) : List String :=
  let fromEff := t.ops.flatMap fun o => o.effects.filterMap fun e => match e with
    | .add r _ => some r | .each _ (.add r _) => some r | _ => none
  (st.rels.map (·.1) ++ t.maintained.map (·.name) ++ fromEff).foldl
    (fun acc r => if acc.contains r || libraryCopied.contains r then acc else acc ++ [r]) []

def Task.derivedAttrs (t : Task) : List String :=
  ["goal-met"] ++ t.phases.map (·.name ++ "-met") ++ (t.termination.map (·.name ++ "-met")).toList ++ t.sums.map (·.attr)

/-- Repeated-situation control (`Task.repeatControl`). The current look-ahead world is compared with each
ancestor world directly (no derived situation label: a label is i-supported and lags the effects by one
elaboration wave, so a fresh application would match its parent's label). -/
def repeatRules (t : Task) (_st : State) : String :=
  match t.repeatControl with
  | none => ""
  | some rc =>
    let n := t.name
    let tys := " ".intercalate rc.types
    s!"
## ---- Search control (stated in the description, not taught): a look-ahead state that returns to a situation on
## its look-ahead path fails, and the library rejects it. Situation: where each {" / ".intercalate rc.types} is ({rc.rel}).
sp \{{n}*elaborate*ancestor-world*parent
   (state <s> ^name evaluate-operator ^superstate.superstate.world <aw>)
-->
   (<s> ^ancestor-world <aw>)
}

sp \{{n}*elaborate*ancestor-world*inherited
   (state <s> ^name evaluate-operator ^superstate.superstate.ancestor-world <aw>)
-->
   (<s> ^ancestor-world <aw>)
}

sp \{{n}*elaborate*failure*repeated-situation
   (state <s> ^name evaluate-operator ^look-ahead-operator <o> ^ancestor-world <aw> ^desireds <ds> ^world <w>)
   (<w> ^anchored-world true ^versioned-operator <o>)
  -\{(<w> ^{rc.rel} <r>)
    (<r> ^argument1 <x> ^argument2 <p>)
    (<x> ^type << {tys} >> ^object-handle <h>)
    (<p> ^object-handle <ph>)
    (<aw> ^{rc.rel} <ar>)
    (<ar> ^argument1 <ax> ^argument2 <ap>)
    (<ax> ^object-handle <h>)
    (<ap> ^object-handle <> <ph>)}
-->
   (<s> ^failure <ds>)
}
"

def spaceRules (t : Task) (st : State) : String :=
  let n := t.name
  let dc := String.join (t.derivedAttrs.map (" ^dont-copy-object-attribute " ++ ·))
  let cr := String.join ((t.relNames st).map (" ^copy-relation " ++ ·))
  let fl := String.join (t.flags.map fun (f, x) => s!" ^{f} {x}")
  -- One English comment per rule group (L3-012), worded as convpass.describe words it, so that path A and path B match.
  let srt := fun (l : List String) => (l.eraseDups.mergeSort (fun a b => decide (a ≤ b))).take 4
  let adds := fun (l : List String) => ", ".intercalate (l.map ("^" ++ ·))
  let psAttrs := srt ((if (t.relNames st).isEmpty then [] else ["copy-relation"]) ++ ["dont-copy-object-attribute", "problem-space"])
  let flAttrs := srt (["flag-override", "mea-operator-selection"] ++ t.flags.map (·.1))
  s!"
## Elaborate problem space: adds {adds psAttrs}.
sp \{{n}*elaborate*problem-space
   (state <s> ^name {n})
-->
   (<s> ^problem-space <p>)
   (<p> ^name {n}{cr}{dc})
}

sp \{{n}*elaborate*problem-space*mea-substate
   (state <s> ^impasse no-change ^attribute operator ^superstate <ss>)
   (<ss> ^problem-space.name {n} ^operator <so>)
   (<so> ^task-operator true -^pre-conditions-satisfied true)
-->
   (<s> ^problem-space <p>)
   (<p> ^name {n}{dc})
}

## Elaborate flags: adds {adds flAttrs}.
sp \{{n}*elaborate*flags
   (state <s> ^superstate nil ^name {n})
-->
   (<s> ^flag-override <f>)
   (<f> ^mea-operator-selection true{fl})
}
"

def achievementRules (n : String) : String := s!"
## Achievement of object-property desireds (supplied by the task).
sp \{{n}*elaborate*state*achieved*object-property
   (state <s> ^problem-space.name {n} ^desireds <ds> ^world <w>)
   (<ds> ^desired <d>)
   (<d> ^object <do>)
   (<do> ^object-handle <h> ^\{ <> object-handle <a> } <v>)
   (<w> ^anchored-world true ^objects.object <ob>)
   (<ob> ^object-handle <h> ^<a> <v>)
-->
   (<ds> ^achieved <d>)
}

sp \{{n}*elaborate*state*unachieved*object-property
   (state <s> ^problem-space.name {n} ^desireds <ds> ^world <w>)
   (<ds> ^desired <d>)
   (<d> ^object <do>)
   (<do> ^object-handle <h> ^\{ <> object-handle <a> } <v>)
   (<w> ^anchored-world true)
  -\{(<w> ^objects.object <ob>)
    (<ob> ^object-handle <h> ^<a> <v>)}
-->
   (<ds> ^unachieved <d>)
}
"

/-! ## Operators -/

def proposeRule (t : Task) (o : Op) : Except String String := do
  let (cost, s) ← (do
    for (x, ty) in o.params do
      atomConds (.obj x ty)
    for a in o.pre do atomConds a
    match o.stepCost with
    | some r =>
      if r.isArith then throw s!"{o.name}: arithmetic in a step cost"
      let rt ← rhsTerm r
      pure s!" ^step-cost {rt}"
    | none => pure "" : CM String).run {}
  let lhs := #[s!"   (state <s> ^problem-space.name {t.name} ^flags.mea-operator-selection true ^world <w> ^desireds <ds>)",
               "   (<w> ^anchored-world true ^objects <objs>)"] ++ s.lines ++ #["   (<ds> ^unachieved-desireds true)"]
  let args := " ".intercalate ((o.params.zipIdx).map fun ((x, _), k) => s!"^argument{k+1} {v x}")
  pure <| sp s!"{t.name}*propose*{o.name}" lhs
    ["   (<s> ^operator <op> +)",
     s!"   (<op> ^name {o.name} ^task-operator true{if o.monotonic then " ^monotonic true" else ""} ^action-handle {o.name} {args} ^argument-count {o.params.length}{cost} ^desireds <pre>)",
     "   (<pre> ^desired-count 0)"] s!"Operator {o.name}{stmtNote o.stmts}."

/-- The actions of one effect; conditions it needs (relation objects, old values) are emitted. -/
def effActs : Eff → CM (List String)
  | .set x p r => do
    let rt ← rhsTerm r
    pure [s!"   ({v x} ^{p} {rt})"]
  | .update x p r => do
    let old ← valVar x p
    let rt ← rhsTerm r
    pure [s!"   ({v x} ^{p} {old} - {rt})"]
  | .add r args => do
    let ts ← args.mapM argTerm
    let s ← get
    set { s with n := s.n + 1 }
    let nv := s!"<new-{s.n + 1}>"
    pure [s!"   (<w> ^{r} {nv})",
      s!"   ({nv} " ++ " ".intercalate ((ts.zipIdx).map fun (t, k) => s!"^argument{k+1} {t}") ++ ")"]
  | .del r args => do
    let rv ← relConds r args "e"
    pure [s!"   (<w> ^{r} {rv} -)"]
  | .change r args pos to => do
    let rv ← relConds r args "e"
    let old ← argTerm (args.getD (pos - 1) (.h "none"))
    let nw ← argTerm to
    pure [s!"   ({rv} ^argument{pos} {old} - {nw})"]
  | .each _ _ => pure []   -- an apply rule of its own (eachBodies)

/-- The conditions shared by an operator's effect rules: its parameters and its binding condition. -/
def baseConds (o : Op) : CM Unit := do
  for (x, _) in o.params do
    emit s!"   (<objs> ^object {v x})"
    emit s!"   ({v x} ^object-handle $ <{x}-h>)"
    markBound x
  for a in o.bind do atomConds a

/-- Conditions and actions of an operator's effects (shared by the look-ahead and real-world rules). -/
def effectBody (o : Op) : Except String (CState × List String) := do
  let (acts, s) ← (do
    baseConds o
    let mut acts : List String := []
    for e in o.effects do acts := acts ++ (← effActs e)
    pure acts : CM (List String)).run {}
  pure (s, acts)

/-- One body per `each` effect: the shared conditions, the each-atoms, and the inner effect. -/
def eachBodies (o : Op) : Except String (List (CState × List String)) :=
  (o.effects.filterMap fun e => match e with | .each as inner => some (as, inner) | _ => none).mapM fun (as, inner) => do
    let (acts, s) ← (do
      baseConds o
      for a in as do atomConds a
      effActs inner : CM (List String)).run {}
    pure (s, acts)

def sayTerm : Say → CM String
  | .text s => pure s!"|{s}|"
  | .handle x => pure s!"<{x}-h>"
  | .prop x p => valVar x p

/-- The output-link command a completed `o` appears as, in the task's output form (World-Conventions L10-018):
the attribute under the output-link and the command's conditions. -/
def commandConds (t : Task) (o : Op) : String × String :=
  let f := t.output.getD {}
  let attrs := f.arguments
  let argP := " ".intercalate ((o.params.zipIdx).map fun ((x, _), k) => s!"^{attrs.getD k s!"argument{k+1}"} <{x}-h>")
  match f.command with
  | some c => (c, s!"   (<pa> ^{f.nameAttribute} {o.name} ^status {f.applied} {argP} -^effect-applied true)")
  | none   => (o.name, s!"   (<pa> ^status {f.applied} {argP} -^effect-applied true)")

/-- The environment's output map (World-Conventions L10-018), when the task declares an output form. -/
def outputMapRule (t : Task) : String :=
  match t.output with
  | none => ""
  | some f =>
    let cmd := match f.command with
      | some c => [s!"        ^command {c}", s!"        ^name-attribute {f.nameAttribute}"]
      | none => ["        ^command-is-action-handle true"]
    let args := (f.arguments.zipIdx).map fun (a, k) => s!"        ^argument{k+1} {a}"
    let st := [s!"        ^done-status {" ".intercalate f.done}", s!"        ^success-status {" ".intercalate f.success}",
               s!"        ^error-status {" ".intercalate f.error})"]
    let body := cmd ++ args ++ st
    sp s!"{t.name}*elaborate*environment-output-map"
      #[s!"   (state <s> ^problem-space.name {t.name} ^superstate nil)"]
      (["   (<s> ^environment-output-map <m>)", s!"   (<m> {String.ofList ((body.headD "").toList.dropWhile (· == ' '))}"] ++ body.tail)
      "How the environment takes actions on the output-link (World-Conventions L10-018)."

def applyRules (t : Task) (o : Op) : Except String String := do
  let (s, acts) ← effectBody o
  let argH := " ".intercalate ((o.params.zipIdx).map fun ((x, _), k) => s!"^argument{k+1}.object-handle $ <{x}-h>")
  let lhsI := #[s!"   (state <s> ^problem-space.name {t.name} ^operator <op> ^internal-actions true ^world <w>)",
                s!"   (<op> ^task-operator true ^name {o.name} ^pre-conditions-satisfied true {argH})",
                "   (<w> ^anchored-world true ^objects <objs>)"] ++ s.lines
  let internal := sp s!"{t.name}*apply*{o.name}*internal" lhsI acts s!"Effect of {o.name} (look-ahead)."
  -- the real world: the same effects once the command completes; the report line
  let (sayTs, s2) ← (o.report.mapM sayTerm).run s
  let (cmdC, paC) := commandConds t o
  let lhsE := #["   :o-support",
                s!"   (state <s> ^problem-space.name {t.name} ^superstate nil ^world <w> ^io.output-link.{cmdC} <pa>)",
                paC,
                "   (<w> ^anchored-world true ^objects <objs>)"] ++ s2.lines
  let write := if sayTs.isEmpty then [] else [s!"   (write {" ".intercalate sayTs} (crlf))"]
  let env := sp s!"{t.name}*apply*{o.name}*environment-effect" lhsE
    (acts ++ ["   (<pa> ^effect-applied true)"] ++ write) s!"Effect of a completed {o.name} command on the real world (once per command)."
  let mut eachOut := ""
  for ((se, ae), k) in (← eachBodies o).zipIdx do
    let lhsIe := #[s!"   (state <s> ^problem-space.name {t.name} ^operator <op> ^internal-actions true ^world <w>)",
                   s!"   (<op> ^task-operator true ^name {o.name} ^pre-conditions-satisfied true {argH})",
                   "   (<w> ^anchored-world true ^objects <objs>)"] ++ se.lines
    let lhsEe := #["   :o-support",
                   s!"   (state <s> ^problem-space.name {t.name} ^superstate nil ^world <w> ^io.output-link.{cmdC} <pa>)",
                   paC,
                   "   (<w> ^anchored-world true ^objects <objs>)"] ++ se.lines
    eachOut := eachOut ++ sp s!"{t.name}*apply*{o.name}*internal*each{k+1}" lhsIe ae s!"Effect of {o.name} on every match (look-ahead)." ++
      sp s!"{t.name}*apply*{o.name}*environment-effect*each{k+1}" lhsEe ae s!"Effect of a completed {o.name} command on every match (real world)."
  pure (internal ++ env ++ eachOut)

/-! ## Sums, losing conditions and the goal -/

def sumRules (t : Task) (st : State) : Except String String := do
  let mut out := ""
  for sd in t.sums do
    let owners := st.objs.filter (·.type == sd.ownerType)
    let mut sizes : List Nat := []
    for o in owners do
      let k := (st.rels.filter fun (n, a) => n == sd.rel && a.head? == some o.handle).length
      match o.prop? "size" with
      | some (.int z) => if z != k then throw s!"{o.handle}: size {z} but {k} members"
      | _ => throw s!"{o.handle}: a sum owner needs ^size"
      if !sizes.contains k then sizes := sizes ++ [k]
    for k in sizes.mergeSort do
      let ms := (List.range k).map (· + 1)
      let rs := " ".intercalate (ms.map (s!"<r{·}>"))
      let conds := ms.flatMap fun i =>
        let prev := (List.range (i - 1)).map fun j => s!"<> <m{j+1}> "
        let mterm := if i == 1 then "<m1>" else "{ " ++ String.join prev ++ s!"<m{i}> }"
        [s!"   (<r{i}> ^argument1 <g> ^argument2 {mterm})", s!"   (<m{i}> ^{sd.prop} <v{i}>)"]
      let lhs := #[s!"   (state <s> ^problem-space.name {t.name} ^world <w>)",
                   s!"   (<w> ^anchored-world true ^objects.object <g> ^{sd.rel} {rs})",
                   s!"   (<g> ^type {sd.ownerType} ^size {k})"] ++ conds.toArray
      out := out ++ sp s!"{t.name}*elaborate*{sd.ownerType}*{sd.attr}*{k}" lhs
        [s!"   (<g> ^{sd.attr} (+ " ++ " ".intercalate (ms.map (s!"<v{·}>")) ++ "))"]
        s!"{sd.attr} of a {sd.ownerType} of {k}, once every member has {sd.prop} (derived; not copied into look-ahead worlds)."
  pure out

/-- Rename the variables of a body for one instance of a universal condition. -/
def renameArg (f : String → Arg) : Arg → Arg
  | .var x => f x
  | a => a

def renameAtom (f : String → Arg) (g : String → String) : Atom → Atom
  | .obj x t => .obj (g x) t
  | .has x p c r => .has (g x) p c (match r with | .prop y q => .prop (g y) q | r => r)
  | .rel r as => .rel r (as.map (renameArg f))
  | .distinct x y => .distinct (g x) (g y)
  | a => a

def condAtoms (st : State) : Cond → Except String (List Atom)
  | .ex as => pure as
  | .all fa => do
    if !fa.filter.isEmpty then throw "a universal condition with a filter is not compiled yet"
    let outerVars := fa.outer.flatMap fun a => match a with
      | .obj x _ => [x] | .has x _ _ _ => [x] | .rel _ as => as.filterMap (fun a => match a with | .var x => some x | _ => none)
      | _ => []
    let inst := (st.objs.filter (·.type == fa.type)).flatMap fun o =>
      let g := fun (x : String) => if x == fa.var then s!"{fa.var}-{o.handle}" else if outerVars.contains x then x else s!"{x}-{o.handle}"
      let f := fun (x : String) => Arg.var (g x)
      [Atom.has (g fa.var) "object-handle" .eq (.val (.sym o.handle))] ++ fa.body.map (renameAtom f g)
    pure (fa.outer ++ inst)

def failureRule (t : Task) (st : State) (f : Failure) : Except String String := do
  let as ← condAtoms st f.cond
  let s ← runCM {} (as.forM atomConds)
  pure <| sp s!"{t.name}*elaborate*failure*{f.name}"
    (#[s!"   (state <s> ^problem-space.name {t.name} ^desireds <ds> ^world <w>)", "   (<w> ^anchored-world true ^objects <objs>)"] ++ s.lines)
    ["   (<s> ^failure <ds>)"] s!"Losing condition {f.name}{stmtNote f.stmts}."

def goalRule (t : Task) (st : State) : Except String String := do
  let as ← condAtoms st t.goal
  let s ← runCM {} (([Atom.obj "task" (some "task")] ++ as).forM atomConds)
  pure <| sp s!"{t.name}*elaborate*goal"
    (#[s!"   (state <s> ^problem-space.name {t.name} ^world <w>)", "   (<w> ^anchored-world true ^objects <objs>)"] ++ s.lines)
    ["   (<task> ^goal-met true)"] s!"Goal{stmtNote t.goalStmts}: ^goal-met true on the task object."

/-- A phase or the termination condition (World-Conventions L8-026, L8-028): ^<name>-met on the task object. -/
def phaseRule (t : Task) (st : State) (p : Phase) (kind : String) : Except String String := do
  let as ← condAtoms st p.cond
  let s ← runCM {} (([Atom.obj "task" (some "task")] ++ as).forM atomConds)
  pure <| sp s!"{t.name}*elaborate*{kind}*{p.name}"
    (#[s!"   (state <s> ^problem-space.name {t.name} ^world <w>)", "   (<w> ^anchored-world true ^objects <objs>)"] ++ s.lines)
    [s!"   (<task> ^{p.name}-met true)"] s!"{if kind == "phase" then "Phase" else "Termination"} {p.name}{stmtNote p.stmts}: ^{p.name}-met true on the task object."

/-- The goal rule, or one rule per phase and one for the termination condition. -/
def goalRules (t : Task) (st : State) : Except String String := do
  if t.phases.isEmpty then goalRule t st else
  let mut out := ""
  for p in t.phases do out := out ++ (← phaseRule t st p "phase")
  match t.termination with
  | some p => pure (out ++ (← phaseRule t st p "termination"))
  | none => pure out

/-- With termination desireds the task's achievement rules also mark them (World-Conventions L8-028). -/
def achievementFor (t : Task) : String :=
  if t.termination.isSome then
    (achievementRules t.name).replace "^desireds <ds> ^world <w>" "^<< desireds termination-desireds >> <ds> ^world <w>"
  else achievementRules t.name

def header (t : Task) : String :=
  let st := t.statements.map fun (k, s) => s!"##  {k}. {s}"
  let asm := t.assumptions.map fun a => s!"##   {a.id}: {a.text}"
  s!"## {t.title}: generated by rosiegen (WorldSpec, path A: Lean) from the instructor statements.\n##\n" ++
  "## Instructor statements used (numbers as in english-input.txt):\n" ++ "\n".intercalate st ++
  "\n##\n## Assumption ledger:\n" ++ "\n".intercalate asm ++ "\n"

/-- A derived relation: an i-supported elaboration on the world (its definition may use negation). -/
def derivedRule (t : Task) (d : Derived) : Except String String := do
  let s ← runCM {} (do for a in d.defn do atomConds a)
  let args := " ".intercalate ((d.vars.zipIdx).map fun (x, k) => s!"^argument{k+1} {v x}")
  pure <| sp s!"{t.name}*elaborate*derived*{d.name}"
    (#[s!"   (state <s> ^problem-space.name {t.name} ^world <w>)", "   (<w> ^anchored-world true ^objects <objs>)"] ++ s.lines)
    [s!"   (<w> ^{d.name} <dr>)", s!"   (<dr> {args})"]
    s!"Derived relation {d.name}{stmtNote d.stmts}: recomputed in every world, never copied into look-ahead."

/-- An evaluation-order mark (World-Conventions L15-026): an elaboration of the proposed operator. -/
def evalMarkRule (t : Task) (m : EvalMark) : Except String String := do
  let some o := t.ops.find? (·.name == m.op) | throw s!"evaluation mark {m.name}: no operator {m.op}"
  if m.cond.any Atom.negated then throw s!"evaluation mark {m.name}: negated condition"
  let s ← runCM {} (do
    for (x, _) in o.params do markBound x
    for a in m.cond do atomConds a)
  let args := " ".intercalate ((o.params.zipIdx).map fun ((x, _), k) => s!"^argument{k+1} {v x}")
  let which := if m.first then "first" else "last"
  let item := if m.item.isEmpty then "" else s!" {m.item} [evaluation]"
  pure <| sp s!"{t.name}*elaborate*{o.name}*evaluate-{which}*{m.name}"
    (#[s!"   (state <s> ^problem-space.name {t.name} ^operator <op> + ^world <w>)",
       "   (<w> ^anchored-world true ^objects <objs>)",
       s!"   (<op> ^task-operator true ^name {o.name} {args})"] ++ s.lines)
    [s!"   (<op> ^evaluate-{which} true)"]
    s!"Search control{item}{stmtNote m.stmts}: evaluate {o.name} {which} when {m.name} (World-Conventions L15-026; only the order of evaluation changes)."

/-- Learning off (World-Conventions L5-021): appended after the rules, so it overrides the library's chunk only. -/
def learningBlock (t : Task) : String :=
  if t.learning then "" else
    "\n## Learning is off for this agent: the English statement says \"Learning: do not learn from look-ahead\"" ++
    " (World-Conventions L5-021).\n" ++
    (if t.learningReason.isEmpty then "" else s!"## Reason given: {t.learningReason}\n") ++ "chunk never\n"

/-- The task rules for a world (path A). -/
def compile (t : Task) (wf : WorldFile) : Except String String := do
  let st := t.initial wf
  let mut out := header t ++ initRules t st ++ outputMapRule t ++ spaceRules t st ++ achievementFor t
  for o in t.ops do
    out := out ++ (← proposeRule t o) ++ (← applyRules t o)
  out := out ++ (← sumRules t st)
  for m in t.evalMarks do out := out ++ (← evalMarkRule t m)
  for d in t.derived do out := out ++ (← derivedRule t d)
  for f in t.failures do out := out ++ (← failureRule t st f)
  out := out ++ (← goalRules t st)
  out := out ++ repeatRules t st
  pure (out ++ learningBlock t)

end WorldSpec
