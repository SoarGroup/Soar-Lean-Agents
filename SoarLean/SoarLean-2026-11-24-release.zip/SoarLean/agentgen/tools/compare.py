import os,sys,glob,re
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import soar2lean as S
A,B=sys.argv[1],sys.argv[2]
tot=0;same=0;diffs=[]
for vd in sorted(glob.glob(A+'/*/world-v6/*')):
    fam,var=vd.split('/')[-3],vd.split('/')[-1]
    gd=f'{B}/{fam}/world-lean/{var}'
    def rules(d):
        lf=open(f'{d}/{var}.soar').read()
        order=[m for m in re.findall(r'source (\S+)',lf) if m!='_firstload.soar' and os.path.exists(f'{d}/{m}')]
        out=[]
        for f in order:
            for doc,t in S.split_rules(open(f'{d}/{f}').read()): out.append((f,tuple(S.tokens(t))))
        fl=[l for l in open(f'{d}/_firstload.soar').read().split('\n') if l.strip() and not l.startswith('##')]
        return out,fl,order
    ra,fa,oa=rules(vd); rb,fb,ob=rules(gd)
    tot+=1
    if ra==rb and fa==fb and oa==ob: same+=1
    else:
        n=sum(1 for x,y in zip(ra,rb) if x!=y)+abs(len(ra)-len(rb))
        diffs.append((fam,var,len(ra),len(rb),n,fa==fb,oa==ob))
        if len(diffs)<=3:
            for x,y in zip(ra,rb):
                if x!=y: print('A',' '.join(x[1])[:600]);print('B',' '.join(y[1])[:600]);print();break
print(f'{same}/{tot} variants token-identical'); [print(d) for d in diffs]
