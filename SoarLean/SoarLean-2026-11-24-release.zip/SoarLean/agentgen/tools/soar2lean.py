#!/usr/bin/env python3
"""soar2lean.py: parse Soar productions (the subset used by world-convention agents) into typed values
and print them as Lean terms of Family.Prod (Fam.Prod). Also: tokenize Soar text for equality checks.

Written 19 November 2026 by Claude, supervised by John E. Laird."""
import re, sys, json

PREFS = set('+ - = < > ! ~ @ &'.split())
CMPS = {'<>', '<', '>', '<=', '>=', '<=>', '='}


def strip_comments(text):
    out, i, n = [], 0, len(text)
    while i < n:
        c = text[i]
        if c == '|':
            j = i + 1
            while text[j] != '|':
                j += 2 if text[j] == '\\' else 1
            out.append(text[i:j + 1]); i = j + 1
        elif c == '#':
            while i < n and text[i] != '\n': i += 1
        else:
            out.append(c); i += 1
    return ''.join(out)


TOK = re.compile(r'\|(?:\\.|[^|\\])*\||<<|>>|-->|<=>|<>|<=|>=|-\{|-\^|[(){}^,]|<[^\s<>()]+>|[^\s(){}^,|]+')


def tokens(text):
    return TOK.findall(strip_comments(text))


def split_rules(text):
    """Yield (doc_lines, rule_text) for each sp {...}."""
    lines = text.split('\n')
    doc = []
    i = 0
    src = text
    pos = 0
    for m in re.finditer(r'^[ \t]*sp\s*\{', src, re.M):
        pass
    # character scan
    i, n = 0, len(src)
    pending_doc = []
    linestart = 0
    while i < n:
        ws = len(src[i:]) - len(src[i:].lstrip(' \t'))
        if re.match(r'sp\s*\{', src[i + ws:i + ws + 6] or ''):
            i += ws
            # doc: contiguous ## lines before
            before = src[:i].rstrip('\n').split('\n')
            d = []
            for l in reversed(before):
                if l.lstrip().startswith('##'): d.insert(0, l.lstrip()[2:].strip())
                else: break
            j = src.index('{', i) + 1; depth = 1
            while depth:
                ch = src[j]
                if ch == '|':
                    k = j + 1
                    while src[k] != '|': k += 2 if src[k] == '\\' else 1
                    j = k + 1; continue
                if ch == '#':
                    j = src.index('\n', j); continue
                if ch == '{': depth += 1
                elif ch == '}': depth -= 1
                j += 1
            yield d, src[i:j]
            i = j
        else:
            k = src.find('\n', i)
            if k < 0: break
            i = k + 1


class P:
    def __init__(s, toks): s.t, s.i = toks, 0
    def peek(s, k=0): return s.t[s.i + k] if s.i + k < len(s.t) else None
    def nxt(s): x = s.t[s.i]; s.i += 1; return x
    def eat(s, x):
        assert s.peek() == x, (x, s.peek(), s.t[max(0, s.i - 8):s.i + 8]); s.i += 1


def isvar(t): return t is not None and len(t) > 2 and t[0] == '<' and t[-1] == '>' and t not in ('<<', '>>', '<>', '<=', '>=', '<=>')


def const(t):
    if re.fullmatch(r'-?\d+', t): return ('int', int(t))
    if re.fullmatch(r'-?\d*\.\d+(e-?\d+)?', t): return ('flt', t)
    return ('sym', t)


def p_single(p):
    t = p.peek()
    if t == '$':
        p.nxt(); return ('lit', p_single(p))
    if t == '{':
        p.nxt(); ts = []
        while p.peek() != '}': ts.append(p_single(p))
        p.nxt(); return ('conj', ts)
    if t == '<<':
        p.nxt(); ts = []
        while p.peek() != '>>': ts.append(p_single(p))
        p.nxt(); return ('disj', ts)
    if t in CMPS and not isvar(t):
        p.nxt(); return ('cmp', t, p_single(p))
    p.nxt()
    if isvar(t): return ('var', t[1:-1])
    return const(t)


def p_cond(p):
    t = p.peek()
    if t == '-{':
        p.nxt(); cs = []
        while p.peek() != '}': cs.append(p_cond(p))
        p.nxt(); return ('ncc', cs)
    if t == '-' and p.peek(1) == '(':
        p.nxt(); return ('neg', p_cond(p))
    p.eat('(')
    isst = False
    if p.peek() == 'state': p.nxt(); isst = True
    idt = p_single(p)
    avs = []
    while p.peek() != ')':
        neg = False
        if p.peek() == '-^': p.nxt(); neg = True
        else: p.eat('^')
        path = [p_single(p)]
        while p.peek() is not None and p.peek().startswith('.') and False: pass
        # dotted path: tokenizer keeps a.b.c as one token for symbols; split it
        if path[0][0] == 'sym' and '.' in path[0][1] and not re.fullmatch(r'-?\d*\.\d+', path[0][1]):
            path = [('sym', x) if not isvar(x) else ('var', x[1:-1]) for x in path[0][1].split('.')]
        vals = []
        while p.peek() not in (')', '^', '-^'):
            vals.append(p_single(p))
            if p.peek() == '+': p.nxt(); vals.append(('sym', '+'))
        avs.append((path, vals, neg))
    p.eat(')')
    return ('pos', isst, idt, avs)


def p_rv(p):
    t = p.nxt()
    if t == '(':
        name = p.nxt(); args = []
        while p.peek() != ')': args.append(p_rv(p))
        p.nxt(); return ('fn', name, args)
    if t.startswith('|'): return ('str', t[1:-1])
    if isvar(t): return ('var', t[1:-1])
    return const(t)


def p_act(p):
    p.eat('(')
    if not isvar(p.peek()):
        name = p.nxt(); args = []
        while p.peek() != ')': args.append(p_rv(p))
        p.nxt(); return ('call', name, args)
    idv = p_rv(p)
    groups = []
    while p.peek() != ')':
        p.eat('^')
        a = p.nxt()
        path = [('var', x[1:-1]) if isvar(x) else const(x) for x in re.split(r'\.(?![^<]*>)', a)] if not isvar(a) else [('var', a[1:-1])]
        if a.startswith('<') and '.' in a and a.endswith('>') is False:
            path = [('var', x[1:-1]) if isvar(x) else const(x) for x in a.split('.')]
        vals = []
        while p.peek() not in (')', '^'):
            val = p_rv(p)
            pref = []
            while p.peek() in PREFS or p.peek() == ',':
                x = p.nxt(); pref.append(x)
                if x in ('=', '>', '<') and p.peek() is not None and (isvar(p.peek()) or re.fullmatch(r'-?\d*\.?\d+', p.peek())):
                    # binary preference operand, unless the next token starts a new value list item
                    pref.append(p.nxt())
            vals.append((val, ' '.join(pref).replace(' ,', ',')))
        groups.append((path, vals))
    p.eat(')')
    return ('make', idv, groups)


def parse_rule(text):
    toks = tokens(text)
    p = P(toks)
    p.eat('sp'); p.eat('{')
    name = p.nxt()
    flags = []
    while p.peek().startswith(':'): flags.append(p.nxt())
    conds = []
    while p.peek() != '-->': conds.append(p_cond(p))
    p.eat('-->')
    acts = []
    while p.peek() != '}': acts.append(p_act(p))
    return {'name': name, 'flags': flags, 'conds': conds, 'acts': acts}


# ---------------- Lean printing

def ls(s):
    return '"' + s.replace('\\', '\\\\').replace('"', '\\"') + '"'


def L_vt(t):
    k = t[0]
    if k == 'sym': return f'.sym {ls(t[1])}'
    if k == 'int': return f'.int ({t[1]})'
    if k == 'flt': return f'.flt {ls(t[1])}'
    if k == 'var': return f'.var {ls(t[1])}'
    if k == 'cmp': return f'.cmp {ls(t[1])} ({L_vt(t[2])})'
    if k in ('conj', 'disj'): return f'.{k} [' + ', '.join(L_vt(x) for x in t[1]) + ']'
    if k == 'lit': return f'.lit ({L_vt(t[1])})'
    raise ValueError(t)


def L_cond(c):
    if c[0] == 'ncc': return '.ncc [' + ', '.join(L_cond(x) for x in c[1]) + ']'
    if c[0] == 'neg': return f'.neg ({L_cond(c[1])})'
    _, isst, idt, avs = c
    av = ', '.join('{ path := [' + ', '.join(L_vt(x) for x in path) + '], vals := [' + ', '.join(L_vt(x) for x in vals) + ']' + (', neg := true' if neg else '') + ' }' for path, vals, neg in avs)
    return f'.pos {"true" if isst else "false"} ({L_vt(idt)}) [{av}]'


def L_rv(r):
    k = r[0]
    if k in ('sym', 'flt', 'var', 'str'): return f'.{k} {ls(r[1])}'
    if k == 'int': return f'.int ({r[1]})'
    if k == 'fn': return f'.fn {ls(r[1])} [' + ', '.join(L_rv(x) for x in r[2]) + ']'
    raise ValueError(r)


def L_act(a):
    if a[0] == 'call': return f'.call {ls(a[1])} [' + ', '.join(L_rv(x) for x in a[2]) + ']'
    _, idv, groups = a
    g = ', '.join('([' + ', '.join(L_rv(x) for x in path) + '], [' + ', '.join('{ val := ' + L_rv(v) + (', pref := ' + ls(pf) if pf else '') + ' }' for v, pf in vals) + '])' for path, vals in groups)
    return f'.make ({L_rv(idv)}) [{g}]'


def L_prod(r, doc, indent='  '):
    parts = [f'name := {ls(r["name"])}']
    if doc: parts.append('doc := [' + ', '.join(ls(d) for d in doc) + ']')
    if r['flags']: parts.append('flags := [' + ', '.join(ls(f) for f in r['flags']) + ']')
    parts.append('conds := [' + (',\n' + indent + '    ').join(L_cond(c) for c in r['conds']) + ']')
    parts.append('acts := [' + (',\n' + indent + '    ').join(L_act(a) for a in r['acts']) + ']')
    return '{ ' + (',\n' + indent).join(parts) + ' }'


if __name__ == '__main__':
    src = open(sys.argv[1]).read()
    for d, t in split_rules(src):
        r = parse_rule(t)
        print(L_prod(r, d)); print()
