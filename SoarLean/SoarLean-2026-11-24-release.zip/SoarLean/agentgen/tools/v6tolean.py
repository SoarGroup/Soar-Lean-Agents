#!/usr/bin/env python3
"""v6tolean.py: write the Lean family descriptions (agentgen/Family/Families/<Family>.lean) from the
world-v6 agents (one-time migration). Task-level parts (problem space, initialization, achievement,
indifference, ancestors) become Task fields and Items; every other rule becomes a typed production
(Fam.Prod), defined once per family when variants share it.

usage: v6tolean.py WORLD_V6_FAMILIES_DIR LEAN_OUT_DIR
Written 19 November 2026 by Claude, supervised by John E. Laird."""
import os, sys, re, glob, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import soar2lean as S

SRC, OUT = sys.argv[1], sys.argv[2]


def camel(s): return ''.join(w.capitalize() for w in re.split(r'[-_]', s))


def leanid(s): return 'r_' + re.sub(r'[^A-Za-z0-9]', '_', s)


def toks(text): return S.tokens(text)


def load_variant(path):
    var = os.path.basename(path)
    lf = open(os.path.join(path, var + '.soar')).read().split('\n')
    about = [l[3:] for l in lf if l.startswith('## ')][1:]
    about = [a for a in about if not a.startswith('Loads the shared') and not a.startswith('Tasks/Families/')]
    order = [m.group(1) for l in lf for m in [re.match(r'source (\S+)', l)] if m and m.group(1) != '_firstload.soar' and os.path.exists(os.path.join(path, m.group(1)))]
    fl = open(os.path.join(path, '_firstload.soar')).read().split('\n')
    fl = [l for l in fl if l.strip() and not l.startswith('## Soar settings (from the original')]
    files = []
    for f in order:
        src = open(os.path.join(path, f)).read()
        rules = [(d, t, S.parse_rule(t)) for d, t in S.split_rules(src)]
        files.append((f, rules))
    return var, about, fl, files


def rv_from(r):
    return S.L_rv(r)


def main():
    os.makedirs(OUT, exist_ok=True)
    fams = sorted(os.listdir(SRC))
    report = {}
    for fam in fams:
        vdir = os.path.join(SRC, fam, 'world-v6')
        if not os.path.isdir(vdir): continue
        variants = [load_variant(p) for p in sorted(glob.glob(vdir + '/*')) if os.path.isdir(p)]
        shared = {}      # key (name, tokens) -> lean id
        defs = []
        vtexts = []
        stats = {'task_level_rules': 0, 'typed_rules': 0}
        for var, about, fl, files in variants:
            task = {'name': None, 'psExtra': '[]', 'flags': '[]', 'env': 'true', 'initBody': '[]', 'initFile': 'none',
                    'initOpExtra': '[]', 'achieveSpaces': '[]', 'achieve': [], 'indifferent': 'none', 'indifferentExcept': '[]', 'ancestors': 'false'}
            # task name from the problem-space rule
            for f, rules in files:
                for d, t, r in rules:
                    m = re.match(r'(.+)\*elaborate\*problem-space$', r['name'])
                    if m: task['name'] = m.group(1)
            T = task['name']
            items_by_file = []
            for f, rules in files:
                items = []
                i = 0
                while i < len(rules):
                    d, t, r = rules[i]; nm = r['name']
                    if T and nm == f'{T}*elaborate*problem-space':
                        pact = [a for a in r['acts'] if a[0] == 'make' and a[1] == ('var', 'p')][0]
                        extra = [g for g in pact[2] if g[0] != [('sym', 'name')]]
                        task['psExtra'] = '[' + ', '.join('([' + ', '.join(S.L_rv(x) for x in path) + '], [' + ', '.join('{ val := ' + S.L_rv(v) + (', pref := ' + S.ls(pf) if pf else '') + ' }' for v, pf in vals) + '])' for path, vals in extra) + ']'
                        items.append('.ps'); stats['task_level_rules'] += 1
                        if i + 1 < len(rules) and rules[i + 1][2]['name'] == f'{T}*elaborate*problem-space*mea-substate':
                            i += 1; stats['task_level_rules'] += 1
                        i += 1; continue
                    if T and nm == f'{T}*propose*initialize-{T}':
                        opact = [a for a in r['acts'] if a[0] == 'make' and a[1] == ('var', 'o')][0]
                        extra = [g for g in opact[2] if g[0] not in ([('sym', 'name')], [('sym', 'task-operator')])]
                        task['initOpExtra'] = '[' + ', '.join('([' + ', '.join(S.L_rv(x) for x in path) + '], [' + ', '.join('{ val := ' + S.L_rv(v) + (', pref := ' + S.ls(pf) if pf else '') + ' }' for v, pf in vals) + '])' for path, vals in extra) + ']'
                        ap = rules[i + 1][2]; assert ap['name'] == f'{T}*apply*initialize-{T}', ap['name']
                        acts = ap['acts']
                        first = acts[0]; assert first[1] == ('var', 's')
                        task['env'] = 'true' if any(g[0] == [('sym', 'environment')] for g in first[2]) else 'false'
                        rest = acts[1:-1]
                        assert acts[-1][0] == 'call' and acts[-1][1] == 'log', acts[-1]
                        if rest and rest[0][0] == 'make' and rest[0][1] == ('var', 's') and rest[0][2][0][0] == [('sym', 'flag-override')]:
                            fa = rest[1]
                            task['flags'] = '[' + ', '.join('(' + S.ls(path[0][1]) + ', ' + S.L_rv(vals[0][0]) + ')' for path, vals in fa[2]) + ']'
                            rest = rest[2:]
                        task['initBody'] = '[' + ',\n      '.join(S.L_act(a) for a in rest) + ']'
                        task['initFile'] = f'some {S.ls(f)}' if f != f'initialize-{T}.soar' else 'none'
                        items.append('.init'); stats['task_level_rules'] += 2
                        i += 2; continue
                    m = re.match(re.escape(T or '#') + r'\*elaborate\*(desired|operator-desired)\*achieved\*(object-property|relation)$', nm)
                    if m and i + 1 < len(rules) and rules[i + 1][2]['name'] == nm.replace('*achieved*', '*unachieved*'):
                        k = ('object' if m.group(2) == 'object-property' else 'relation') + ('State' if m.group(1) == 'desired' else 'Operator')
                        pst = [av for av in r['conds'][0][3] if av[0] == [('sym', 'problem-space.name')] or av[0] == [('sym', 'problem-space'), ('sym', 'name')]]
                        if pst and pst[0][1][0][0] == 'disj':
                            task['achieveSpaces'] = '[' + ', '.join(S.ls(x[1]) for x in pst[0][1][0][1] if x[1] != T) + ']'
                        items.append(f'.achieve .{k}'); stats['task_level_rules'] += 2
                        i += 2; continue
                    if T and nm == f'{T}*compare*task-operator*indifferent':
                        why = d[0][len('Search control: '):].rsplit(', so task operators', 1)[0] if d else ''
                        task['indifferent'] = 'some ' + S.ls(why)
                        ex = [av[1][0][2][1] for av in r['conds'][1][3] if av[0] == [('sym', 'name')] and av[1][0][0] == 'cmp']
                        if ex: task['indifferentExcept'] = '[' + ', '.join(S.ls(x) for x in ex) + ']'
                        items.append('.indifferent'); stats['task_level_rules'] += 1
                        i += 1; continue
                    if T and nm == f'{T}*elaborate*ancestor*superstate' and i + 1 < len(rules) and rules[i + 1][2]['name'] == f'{T}*elaborate*ancestor*inherit':
                        task['ancestors'] = 'true'; items.append('.ancestors'); stats['task_level_rules'] += 2
                        i += 2; continue
                    key = (nm, tuple(toks(t)))
                    if key not in shared:
                        base = leanid(nm); lid = base; k = 2
                        while lid in [x[0] for x in defs]: lid = f'{base}_{k}'; k += 1
                        shared[key] = lid
                        defs.append((lid, S.L_prod(r, d, '    ')))
                    items.append(f'.p {shared[key]}'); stats['typed_rules'] += 1
                    i += 1
                items_by_file.append((f, items))
            achieves = []
            for f, its in items_by_file:
                for it in its:
                    if it.startswith('.achieve'): achieves.append(it.split()[1])
            vt = ['  { family := ' + S.ls(fam) + ', name := ' + S.ls(var) + ',',
                  '    about := [' + ', '.join(S.ls(a) for a in about) + '],',
                  '    firstload := [' + ', '.join(S.ls(a) for a in fl) + '],',
                  '    task := { name := ' + S.ls(T) + ', psExtra := ' + task['psExtra'] + ', flags := ' + task['flags'] +
                  ', environmentNone := ' + task['env'] + ',\n              initBody := ' + task['initBody'] +
                  ',\n              initFile := ' + task['initFile'] + ', initOpExtra := ' + task['initOpExtra'] +
                  ', achieve := [' + ', '.join(achieves) + '], achieveSpaces := ' + task['achieveSpaces'] + ', indifferent := ' + task['indifferent'] + ', indifferentExcept := ' + task['indifferentExcept'] + ', ancestors := ' + task['ancestors'] + ' },',
                  '    files := [' + ',\n              '.join('(' + S.ls(f) + ', [' + ', '.join(its) + '])' for f, its in items_by_file) + '] }']
            vtexts.append((var, '\n'.join(vt)))
        mod = camel(fam)
        body = [f'import Family.Task', 'set_option maxHeartbeats 0', 'set_option maxRecDepth 100000', '/-!', f'# {fam}: world-convention agents of the {fam} family', '',
                'Typed description migrated on 19 November 2026 from the world-v6 agents (Tasks/Families/' + fam + '/world-v6),',
                'which were written from the original programs. Task-level parts are `Task` fields; family knowledge is typed',
                'productions, defined once and shared by the variants that use them.', '',
                'Written 19 November 2026 by Claude, supervised by John E. Laird.', '-/', f'namespace Fam.Families.{mod}', 'open Fam', '']
        for lid, txt in defs:
            body.append(f'def {lid} : Prod :=\n  {txt}\n')
        for var, vt in vtexts:
            body.append('def v_' + re.sub(r'[^A-Za-z0-9]', '_', var) + ' : Variant :=\n' + vt.replace('  { family', '  { family', 1) + '\n')
        body.append('def variants : List Variant := [' + ', '.join('v_' + re.sub(r'[^A-Za-z0-9]', '_', var) for var, _ in vtexts) + ']\n')
        body.append(f'end Fam.Families.{mod}\n')
        open(os.path.join(OUT, mod + '.lean'), 'w').write('\n'.join(body))
        report[fam] = dict(stats, variants=len(variants), shared_defs=len(defs))
    print(json.dumps(report, indent=1))


main()
