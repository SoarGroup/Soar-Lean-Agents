"""Path B: world-convention Soar rules from a WorldSpec description exported by Lean (rosiegen json).

usage: python3 spec_backend.py DESC.json OUT.soar

The description is typed and checked in Lean (agentgen/WorldSpec); its initial world arrives evaluated
(objects and relation tuples, maintained relations included). This back end follows the emission scheme
written down in agentgen/WorldSpec/Compile.lean (path A), so the two outputs can be compared byte for byte:

* an object variable x is <x>, declared by (<objs> ^object <x>) when it first occurs outside a relation;
  a constant handle h is <k-h>, declared with (<k-h> ^object-handle h);
* has x p c v: (<x> ^p c v); a property y.q on the right is bound first as (<y> ^q <y-q>);
* rel r [a1 .. an]: (<w> ^r <rK>) and (<rK> ^argument1 a1 .. ^argumentn an); a tuple already tested in the
  rule reuses its variable;
* distinct x y: (<objs> ^object { <> <x> <y> });
* lacks and none are negations: refused in compiled conditions (W-CHK-009);
* a universal goal is expanded over the objects of its type in the initial world;
* object-handle tests on variables carry $ (W-CHK-011)."""
import json, sys

LIB_COPIED = ('on', 'above', 'in')
CMP = {'eq': '', 'ne': '<> ', 'lt': '< ', 'le': '<= ', 'gt': '> ', 'ge': '>= '}


def val(x):
    if 'sym' in x: return x['sym']
    if 'int' in x: return str(x['int'])
    return 'true' if x['bool'] else 'false'


def v(x): return f'<{x}>'
def kv(h): return f'<k-{h}>'


class CS:
    """The state of compiling one rule's conditions."""
    def __init__(s):
        s.lines, s.objs, s.consts, s.vals, s.rels, s.n = [], [], [], [], [], 0

    def emit(s, l): s.lines.append(l)

    def fresh(s, pfx):
        s.n += 1
        return f'<{pfx}{s.n}>'

    def decl_obj(s, x):
        if x not in s.objs:
            s.emit(f'   (<objs> ^object {v(x)})')
            s.objs.append(x)

    def mark_bound(s, x):
        if x not in s.objs: s.objs.append(x)

    def arg(s, a):
        if 'var' in a: return v(a['var'])
        h = a['h']
        if h not in s.consts:
            s.emit(f'   (<objs> ^object {kv(h)})')
            s.emit(f'   ({kv(h)} ^object-handle {h})')
            s.consts.append(h)
        return kv(h)

    def val_var(s, y, q):
        name = f'<{y}-{q}>'
        if name not in s.vals:
            s.decl_obj(y)
            s.emit(f'   ({v(y)} ^{q} {name})')
            s.vals.append(name)
        return name

    def rhs(s, r):
        if 'val' in r: return val(r['val'])
        if 'plus' in r:
            a, b = (s.rhs(x) for x in r['plus'])
            return f'(+ {a} {b})'
        y, q = r['prop']
        return s.val_var(y, q)

    def rel(s, r, args, pfx):
        ts = [s.arg(a) for a in args]
        for (n, a, rv) in s.rels:
            if n == r and a == ts: return rv
        rv = s.fresh(pfx)
        s.emit(f'   (<w> ^{r} {rv})')
        s.emit(f'   ({rv} ' + ' '.join(f'^argument{k} {t}' for k, t in enumerate(ts, 1)) + ')')
        for a in args:
            if 'var' in a: s.mark_bound(a['var'])
        s.rels.append((r, ts, rv))
        return rv

    def atom(s, a):
        if 'obj' in a:
            s.decl_obj(a['obj'])
            if a['type'] is not None: s.emit(f"   ({v(a['obj'])} ^type {a['type']})")
        elif 'has' in a:
            if 'plus' in a['rhs']: raise ValueError(f"cannot compile arithmetic in a condition ({a['has']}.{a['prop']})")
            rt = s.rhs(a['rhs'])
            s.decl_obj(a['has'])
            s.emit(f"   ({v(a['has'])} ^{a['prop']} {CMP[a['cmp']]}{rt})")
        elif 'rel' in a:
            s.rel(a['rel'], a['args'], 'r')
        elif 'distinct' in a:
            x, y = a['distinct']
            s.decl_obj(x)
            s.emit(f'   (<objs> ^object {{ <> {v(x)} {v(y)} }})')
            if y not in s.objs: s.objs.append(y)
        elif 'lacks' in a:
            # only in a derived relation's definition (checked by Task.wellFormed in Lean, W-CHK-009)
            x, p = a['lacks']
            s.decl_obj(x)
            s.emit(f'   -({v(x)} ^{p})')
        elif 'none' in a:
            # a negated conjunction: inner conditions inside -{ ... }; names bound inside stay inside
            saved = (list(s.lines), list(s.objs), list(s.consts), list(s.vals), list(s.rels))
            s.lines = []
            for b in a['none']: s.atom(b)
            inner = s.lines
            s.lines, s.objs, s.consts, s.vals, s.rels = saved
            s.emit('  -{' + '\n'.join(l[1:] for l in inner) + '}')
        else:
            raise ValueError(f'unknown atom {a}')


def sp(name, lhs, rhs, comment=''):
    c = f'\n## {comment}\n' if comment else ''
    return c + f'sp {{{name}\n' + '\n'.join(lhs) + '\n-->\n' + '\n'.join(rhs) + '\n}\n'


def stmt_note(ns):
    if not ns: return ''
    return ' (statement' + ('s ' if len(ns) > 1 else ' ') + ', '.join(map(str, ns)) + ')'


def header(d):
    st = [f'##  {k}. {s}' for k, s in d['statements']]
    asm = [f"##   {a['id']}: {a['text']}" for a in d['assumptions']]
    return (f"## {d['title']}: generated by spec_backend.py (WorldSpec, path B: Lean description, Python rules) from the instructor statements.\n##\n"
            '## Instructor statements used (numbers as in english-input.txt):\n' + '\n'.join(st) +
            '\n##\n## Assumption ledger:\n' + '\n'.join(asm) + '\n')


def obj_line(o):
    props = [f"^type {o['type']}"] + [f'^{p} {val(x)}' for p, x in o['props']]
    return f"   ({kv(o['handle'])} ^object-handle {o['handle']} ^anchored true {' '.join(props)})"


def desired_block(var, pre, attr):
    """One desireds structure: a single desired, ^<attr> true on the task object (Compile.lean desiredBlock)."""
    return f'   ({var} ^desired-count 1 ^desired <{pre}>)\n   (<{pre}> ^object <{pre}-o>)\n   (<{pre}-o> ^object-handle task ^{attr} true)\n'


def desireds_lines(d):
    """The initial desireds (World-Conventions L8-026 to L8-029; Compile.lean desiredsLines)."""
    phases = d.get('phases') or []
    if not phases: return desired_block('<ds>', 'd1', 'goal-met')
    names = ['<ds>' if k == 0 else f'<ph{k + 1}>' for k in range(len(phases))]
    ls_ = d.get('loopStart')
    out = ''
    for k, (p, var) in enumerate(zip(phases, names)):
        nxt = names[k + 1] if k + 1 < len(names) else (names[ls_] if ls_ is not None and ls_ < len(names) else None)
        out += desired_block(var, f'p{k + 1}d1', p['name'] + '-met') + (f'   ({var} ^next-desireds {nxt})\n' if nxt else '')
    if ls_ is not None and ls_ < len(names): out += f'   ({names[ls_]} ^loop-start true)\n'
    if d.get('termination'):
        out += '   (<s> ^termination-desireds <tds>)\n' + desired_block('<tds>', 'td1', d['termination']['name'] + '-met')
    if d.get('repeatCount') is not None: out += f"   (<s> ^repeat-count {d['repeatCount']})\n"
    return out


def init_rules(d):
    n = d['name']
    objs = ' '.join(kv(o['handle']) for o in d['objects'])
    rels = []
    for k, (r, hs) in enumerate(d['relations'], 1):
        rels.append(f'   (<w> ^{r} <rel-{k}>)')
        rels.append(f'   (<rel-{k}> ' + ' '.join(f'^argument{i} {kv(h)}' for i, h in enumerate(hs, 1)) + ')')
    return (f'''
sp {{{n}*propose*initialize-{n}
   (state <s> ^superstate nil ^world <w> -^name)
-->
   (<s> ^operator <o> + >)
   (<o> ^name initialize-{n} ^task-operator false)
}}

sp {{{n}*apply*initialize-{n}
   (state <s> ^operator.name initialize-{n} ^world <w>)
   (<w> ^objects <objs>)
-->
   (<s> ^name {n} ^desireds <ds>)
   (<objs> ^object {objs})
''' + '\n'.join(obj_line(o) for o in d['objects']) + '\n' + desireds_lines(d) + '\n'.join(rels) + f'''
   (log 1 (crlf) |Initialize {n}.|)
}}
''')


def rel_names(d):
    eff = [e['add'] if 'add' in e else e['eff']['add'] for o in d['ops'] for e in o['effects']
           if 'add' in e or ('each' in e and 'add' in e['eff'])]   # in operator and effect order, as Compile.lean
    out = []
    for r in [r for r, _ in d['relations']] + [m['name'] for m in d['maintained']] + eff:
        if r not in out and r not in LIB_COPIED: out.append(r)
    return out


def space_rules(d):
    n = d['name']
    dc = ''.join(' ^dont-copy-object-attribute ' + a for a in ['goal-met'] + [p['name'] + '-met' for p in d.get('phases') or []]
                 + ([d['termination']['name'] + '-met'] if d.get('termination') else []) + [s['attr'] for s in d['sums']])
    cr = ''.join(' ^copy-relation ' + r for r in rel_names(d))
    fl = ''.join(f' ^{f} {x}' for f, x in d['flags'])
    return f'''
sp {{{n}*elaborate*problem-space
   (state <s> ^name {n})
-->
   (<s> ^problem-space <p>)
   (<p> ^name {n}{cr}{dc})
}}

sp {{{n}*elaborate*problem-space*mea-substate
   (state <s> ^impasse no-change ^attribute operator ^superstate <ss>)
   (<ss> ^problem-space.name {n} ^operator <so>)
   (<so> ^task-operator true -^pre-conditions-satisfied true)
-->
   (<s> ^problem-space <p>)
   (<p> ^name {n}{dc})
}}

sp {{{n}*elaborate*flags
   (state <s> ^superstate nil ^name {n})
-->
   (<s> ^flag-override <f>)
   (<f> ^mea-operator-selection true{fl})
}}
'''


def achievement_rules(n):
    return f'''
## Achievement of object-property desireds (supplied by the task).
sp {{{n}*elaborate*state*achieved*object-property
   (state <s> ^desireds <ds> ^world <w>)
   (<ds> ^desired <d>)
   (<d> ^object <do>)
   (<do> ^object-handle <h> ^{{ <> object-handle <a> }} <v>)
   (<w> ^anchored-world true ^objects.object <ob>)
   (<ob> ^object-handle <h> ^<a> <v>)
-->
   (<ds> ^achieved <d>)
}}

sp {{{n}*elaborate*state*unachieved*object-property
   (state <s> ^desireds <ds> ^world <w>)
   (<ds> ^desired <d>)
   (<d> ^object <do>)
   (<do> ^object-handle <h> ^{{ <> object-handle <a> }} <v>)
   (<w> ^anchored-world true)
  -{{(<w> ^objects.object <ob>)
    (<ob> ^object-handle <h> ^<a> <v>)}}
-->
   (<ds> ^unachieved <d>)
}}
'''


def propose_rule(d, o):
    s = CS()
    for x, ty in o['params']: s.atom({'obj': x, 'type': ty})
    for a in o['pre']: s.atom(a)
    cost = ''
    if o.get('stepCost') is not None:
        if 'plus' in o['stepCost']: raise ValueError(f"{o['name']}: arithmetic in a step cost")
        cost = f" ^step-cost {s.rhs(o['stepCost'])}"
    lhs = [f"   (state <s> ^problem-space.name {d['name']} ^flags.mea-operator-selection true ^world <w> ^desireds <ds>)",
           '   (<w> ^anchored-world true ^objects <objs>)'] + s.lines + ['   (<ds> ^unachieved-desireds true)']
    args = ' '.join(f'^argument{k} {v(x)}' for k, (x, _) in enumerate(o['params'], 1))
    return sp(f"{d['name']}*propose*{o['name']}", lhs,
              ['   (<s> ^operator <op> +)',
               f"   (<op> ^name {o['name']} ^task-operator true{' ^monotonic true' if o.get('monotonic') else ''} ^action-handle {o['name']} {args} ^argument-count {len(o['params'])}{cost} ^desireds <pre>)",
               '   (<pre> ^desired-count 0)'], f"Operator {o['name']}{stmt_note(o['stmts'])}.")


def eff_acts(s, e):
    """The actions of one effect; the conditions it needs are emitted on s."""
    if 'set' in e:
        return [f"   ({v(e['set'])} ^{e['prop']} {s.rhs(e['rhs'])})"]
    if 'update' in e:
        old = s.val_var(e['update'], e['prop'])
        rt = s.rhs(e['rhs'])
        return [f"   ({v(e['update'])} ^{e['prop']} {old} - {rt})"]
    if 'add' in e:
        ts = [s.arg(a) for a in e['args']]
        s.n += 1
        nv = f'<new-{s.n}>'
        return [f"   (<w> ^{e['add']} {nv})", f'   ({nv} ' + ' '.join(f'^argument{k} {t}' for k, t in enumerate(ts, 1)) + ')']
    if 'del' in e:
        rv = s.rel(e['del'], e['args'], 'e')
        return [f"   (<w> ^{e['del']} {rv} -)"]
    if 'change' in e:
        rv = s.rel(e['change'], e['args'], 'e')
        pos, args = e['pos'], e['args']
        old = s.arg(args[pos - 1] if pos - 1 < len(args) else {'h': 'none'})
        nw = s.arg(e['to'])
        return [f'   ({rv} ^argument{pos} {old} - {nw})']
    return []   # each: an apply rule of its own (each_bodies)


def base_conds(s, o):
    for x, _ in o['params']:
        s.emit(f'   (<objs> ^object {v(x)})')
        s.emit(f'   ({v(x)} ^object-handle $ <{x}-h>)')
        s.mark_bound(x)
    for a in o['bind']: s.atom(a)


def effect_body(o):
    s = CS()
    base_conds(s, o)
    acts = []
    for e in o['effects']: acts += eff_acts(s, e)
    return s, acts


def each_bodies(o):
    out = []
    for e in o['effects']:
        if 'each' not in e: continue
        s = CS()
        base_conds(s, o)
        for a in e['each']: s.atom(a)
        out.append((s, eff_acts(s, e['eff'])))
    return out


def say(s, p):
    if 'text' in p: return f"|{p['text']}|"
    if 'handle' in p: return f"<{p['handle']}-h>"
    x, q = p['prop']
    return s.val_var(x, q)


DEFAULT_OUTPUT = {'command': 'perform-action', 'nameAttribute': 'name', 'arguments': ['argument1', 'argument2', 'argument3'],
                  'done': ['interrupted', 'complete', 'success'], 'success': ['success'], 'error': ['error', 'failure'],
                  'applied': 'complete'}


def command_conds(d, o):
    """The output-link command a completed operator appears as, in the task's output form (World-Conventions L10-018)."""
    f = dict(DEFAULT_OUTPUT, **(d.get('output') or {}))
    attrs = f['arguments']
    arg_p = ' '.join(f"^{attrs[k] if k < len(attrs) else f'argument{k + 1}'} <{x}-h>" for k, (x, _) in enumerate(o['params']))
    if f.get('command'):
        return f['command'], f"   (<pa> ^{f['nameAttribute']} {o['name']} ^status {f['applied']} {arg_p} -^effect-applied true)"
    return o['name'], f"   (<pa> ^status {f['applied']} {arg_p} -^effect-applied true)"


def output_map_rule(d):
    """The environment's output map (World-Conventions L10-018), when the task declares an output form."""
    if not d.get('output'): return ''
    f = dict(DEFAULT_OUTPUT, **d['output'])
    body = ([f"        ^command {f['command']}", f"        ^name-attribute {f['nameAttribute']}"] if f.get('command')
            else ['        ^command-is-action-handle true'])
    body += [f'        ^argument{k} {a}' for k, a in enumerate(f['arguments'], 1)]
    body += [f"        ^done-status {' '.join(f['done'])}", f"        ^success-status {' '.join(f['success'])}",
             f"        ^error-status {' '.join(f['error'])})"]
    return sp(f"{d['name']}*elaborate*environment-output-map",
              [f"   (state <s> ^problem-space.name {d['name']} ^superstate nil)"],
              ['   (<s> ^environment-output-map <m>)', f'   (<m> {body[0].lstrip()}'] + body[1:],
              'How the environment takes actions on the output-link (World-Conventions L10-018).')


def apply_rules(d, o):
    s, acts = effect_body(o)
    n, on = d['name'], o['name']
    arg_h = ' '.join(f'^argument{k}.object-handle $ <{x}-h>' for k, (x, _) in enumerate(o['params'], 1))
    lhs_i = ['   (state <s> ^operator <op> ^internal-actions true ^world <w>)',
             f'   (<op> ^task-operator true ^name {on} ^pre-conditions-satisfied true {arg_h})',
             '   (<w> ^anchored-world true ^objects <objs>)'] + list(s.lines)
    internal = sp(f'{n}*apply*{on}*internal', lhs_i, acts, f'Effect of {on} (look-ahead).')
    say_ts = [say(s, p) for p in o['report']]
    cmd_c, pa_c = command_conds(d, o)
    lhs_e = ['   :o-support',
             f'   (state <s> ^superstate nil ^world <w> ^io.output-link.{cmd_c} <pa>)',
             pa_c,
             '   (<w> ^anchored-world true ^objects <objs>)'] + s.lines
    write = [f"   (write {' '.join(say_ts)} (crlf))"] if say_ts else []
    env = sp(f'{n}*apply*{on}*environment-effect', lhs_e, acts + ['   (<pa> ^effect-applied true)'] + write,
             f'Effect of a completed {on} command on the real world (once per command).')
    each_out = ''
    for k, (se, ae) in enumerate(each_bodies(o), 1):
        lhs_ie = lhs_i[:3] + list(se.lines)
        lhs_ee = lhs_e[:4] + list(se.lines)
        each_out += sp(f'{n}*apply*{on}*internal*each{k}', lhs_ie, ae, f'Effect of {on} on every match (look-ahead).')
        each_out += sp(f'{n}*apply*{on}*environment-effect*each{k}', lhs_ee, ae, f'Effect of a completed {on} command on every match (real world).')
    return internal + env + each_out


def sum_rules(d):
    out = ''
    for sd in d['sums']:
        sizes = []
        for o in d['objects']:
            if o['type'] != sd['ownerType']: continue
            k = sum(1 for r, hs in d['relations'] if r == sd['rel'] and hs[0] == o['handle'])
            props = dict((p, x) for p, x in o['props'])
            if 'size' not in props or 'int' not in props['size']:
                raise ValueError(f"{o['handle']}: a sum owner needs ^size")
            if props['size']['int'] != k: raise ValueError(f"{o['handle']}: size {props['size']['int']} but {k} members")
            if k not in sizes: sizes.append(k)
        for k in sorted(sizes):
            ms = range(1, k + 1)
            conds = []
            for i in ms:
                mterm = '<m1>' if i == 1 else '{ ' + ''.join(f'<> <m{j}> ' for j in range(1, i)) + f'<m{i}> }}'
                conds += [f'   (<r{i}> ^argument1 <g> ^argument2 {mterm})', f"   (<m{i}> ^{sd['prop']} <v{i}>)"]
            lhs = ['   (state <s> ^world <w>)',
                   f"   (<w> ^anchored-world true ^objects.object <g> ^{sd['rel']} {' '.join(f'<r{i}>' for i in ms)})",
                   f"   (<g> ^type {sd['ownerType']} ^size {k})"] + conds
            out += sp(f"{d['name']}*elaborate*{sd['ownerType']}*{sd['attr']}*{k}", lhs,
                      [f"   (<g> ^{sd['attr']} (+ " + ' '.join(f'<v{i}>' for i in ms) + '))'],
                      f"{sd['attr']} of a {sd['ownerType']} of {k}, once every member has {sd['prop']} (derived; not copied into look-ahead worlds).")
    return out


def rename(a, g):
    if 'obj' in a: return {**a, 'obj': g(a['obj'])}
    if 'has' in a:
        r = a['rhs']
        if 'prop' in r: r = {'prop': [g(r['prop'][0]), r['prop'][1]]}
        return {**a, 'has': g(a['has']), 'rhs': r}
    if 'rel' in a: return {**a, 'args': [{'var': g(x['var'])} if 'var' in x else x for x in a['args']]}
    if 'distinct' in a: return {'distinct': [g(x) for x in a['distinct']]}
    return a


def cond_atoms(d, c):
    if 'ex' in c: return c['ex']
    fa = c['all']
    if fa['filter']: raise ValueError('a universal condition with a filter is not compiled yet')
    outer_vars = []
    for a in fa['outer']:
        if 'obj' in a: outer_vars.append(a['obj'])
        elif 'has' in a: outer_vars.append(a['has'])
        elif 'rel' in a: outer_vars += [x['var'] for x in a['args'] if 'var' in x]
    inst = []
    for o in d['objects']:
        if o['type'] != fa['type']: continue
        h = o['handle']
        g = (lambda h: lambda x: f"{fa['var']}-{h}" if x == fa['var'] else (x if x in outer_vars else f'{x}-{h}'))(h)
        inst.append({'has': g(fa['var']), 'prop': 'object-handle', 'cmp': 'eq', 'rhs': {'val': {'sym': h}}})
        inst += [rename(a, g) for a in fa['body']]
    return fa['outer'] + inst


def eval_mark_rule(d, m):
    """An evaluation-order mark (World-Conventions L15-026): an elaboration of the proposed operator."""
    ops = [o for o in d['ops'] if o['name'] == m['op']]
    if not ops: raise ValueError(f"evaluation mark {m['name']}: no operator {m['op']}")
    o = ops[0]
    if any('lacks' in a or 'none' in a for a in m['cond']): raise ValueError(f"evaluation mark {m['name']}: negated condition")
    s = CS()
    for x, _ in o['params']: s.mark_bound(x)
    for a in m['cond']: s.atom(a)
    args = ' '.join(f'^argument{k} {v(x)}' for k, (x, _) in enumerate(o['params'], 1))
    which = m['mark']
    item = f" {m['item']} [evaluation]" if m.get('item') else ''
    return sp(f"{d['name']}*elaborate*{o['name']}*evaluate-{which}*{m['name']}",
              [f"   (state <s> ^problem-space.name {d['name']} ^operator <op> + ^world <w>)",
               '   (<w> ^anchored-world true ^objects <objs>)',
               f"   (<op> ^task-operator true ^name {o['name']} {args})"] + s.lines,
              [f'   (<op> ^evaluate-{which} true)'],
              f"Search control{item}{stmt_note(m.get('stmts', []))}: evaluate {o['name']} {which} when {m['name']} (World-Conventions L15-026; only the order of evaluation changes).")


def failure_rule(d, f):
    s = CS()
    for a in cond_atoms(d, f['cond']): s.atom(a)
    return sp(f"{d['name']}*elaborate*failure*{f['name']}",
              ['   (state <s> ^desireds <ds> ^world <w>)', '   (<w> ^anchored-world true ^objects <objs>)'] + s.lines,
              ['   (<s> ^failure <ds>)'], f"Losing condition {f['name']}{stmt_note(f['stmts'])}.")


def goal_rule(d):
    s = CS()
    for a in [{'obj': 'task', 'type': 'task'}] + cond_atoms(d, d['goal']): s.atom(a)
    return sp(f"{d['name']}*elaborate*goal",
              ['   (state <s> ^world <w>)', '   (<w> ^anchored-world true ^objects <objs>)'] + s.lines,
              ['   (<task> ^goal-met true)'], f"Goal{stmt_note(d['goalStmts'])}: ^goal-met true on the task object.")


def phase_rule(d, p, kind):
    """A phase or the termination condition (World-Conventions L8-026, L8-028; Compile.lean phaseRule)."""
    s = CS()
    for a in [{'obj': 'task', 'type': 'task'}] + cond_atoms(d, p['cond']): s.atom(a)
    return sp(f"{d['name']}*elaborate*{kind}*{p['name']}",
              ['   (state <s> ^world <w>)', '   (<w> ^anchored-world true ^objects <objs>)'] + s.lines,
              [f"   (<task> ^{p['name']}-met true)"],
              f"{'Phase' if kind == 'phase' else 'Termination'} {p['name']}{stmt_note(p['stmts'])}: ^{p['name']}-met true on the task object.")


def goal_rules(d):
    """The goal rule, or one rule per phase and one for the termination condition (Compile.lean goalRules)."""
    if not d.get('phases'): return goal_rule(d)
    return ''.join(phase_rule(d, p, 'phase') for p in d['phases']) + (phase_rule(d, d['termination'], 'termination') if d.get('termination') else '')


def achievement_for(d):
    """With termination desireds the task's achievement rules also mark them (World-Conventions L8-028)."""
    a = achievement_rules(d['name'])
    return a.replace('^desireds <ds> ^world <w>', '^<< desireds termination-desireds >> <ds> ^world <w>') if d.get('termination') else a


def repeat_rules(d):
    """Repeated-situation control (WorldSpec Task.repeatControl): stated in the description, not taught.
    The current look-ahead world is compared with each ancestor world directly (no derived label, which lags by a wave)."""
    rc = d.get('repeatControl')
    if not rc: return ''
    n, rl, tys = d['name'], rc['rel'], ' '.join(rc['types'])
    return f"""
## ---- Search control (stated in the description, not taught): a look-ahead state that returns to a situation on
## its look-ahead path fails, and the library rejects it. Situation: where each {' / '.join(rc['types'])} is ({rl}).
sp {{{n}*elaborate*ancestor-world*parent
   (state <s> ^name evaluate-operator ^superstate.superstate.world <aw>)
-->
   (<s> ^ancestor-world <aw>)
}}

sp {{{n}*elaborate*ancestor-world*inherited
   (state <s> ^name evaluate-operator ^superstate.superstate.ancestor-world <aw>)
-->
   (<s> ^ancestor-world <aw>)
}}

sp {{{n}*elaborate*failure*repeated-situation
   (state <s> ^name evaluate-operator ^look-ahead-operator <o> ^ancestor-world <aw> ^desireds <ds> ^world <w>)
   (<w> ^anchored-world true ^versioned-operator <o>)
  -{{(<w> ^{rl} <r>)
    (<r> ^argument1 <x> ^argument2 <p>)
    (<x> ^type << {tys} >> ^object-handle <h>)
    (<p> ^object-handle <ph>)
    (<aw> ^{rl} <ar>)
    (<ar> ^argument1 <ax> ^argument2 <ap>)
    (<ax> ^object-handle <h>)
    (<ap> ^object-handle <> <ph>)}}
-->
   (<s> ^failure <ds>)
}}
"""


def derived_rule(d, dr):
    s = CS()
    for a in dr['defn']: s.atom(a)
    args = ' '.join(f'^argument{k} {v(x)}' for k, x in enumerate(dr['vars'], 1))
    return sp(f"{d['name']}*elaborate*derived*{dr['name']}",
              ['   (state <s> ^world <w>)', '   (<w> ^anchored-world true ^objects <objs>)'] + s.lines,
              [f"   (<w> ^{dr['name']} <dr>)", f'   (<dr> {args})'],
              f"Derived relation {dr['name']}{stmt_note(dr['stmts'])}: recomputed in every world, never copied into look-ahead.")


# Reserved variable names (the same check as WorldSpec/Check.lean, Var.badName and Task.vars): a description
# variable may not be a name the generated rules use themselves, contain '-' (generated names such as <k-...>,
# <new-...>), or have the form r<digits> or e<digits>.
RESERVED_VARS = ['s', 'w', 'objs', 'ds', 'op', 'pre', 'pa', 'task', 'any-unachieved', 'dr']

def bad_var(x):
    return (x in RESERVED_VARS or '-' in x or x == '' or
            (x[0] in 're' and len(x) > 1 and x[1:].isdigit()))

def _rhs_vars(r):
    if 'prop' in r: return [r['prop'][0]]
    if 'plus' in r: return _rhs_vars(r['plus'][0]) + _rhs_vars(r['plus'][1])
    return []

def _arg_vars(args): return [a['var'] for a in args if 'var' in a]

def _atom_vars(a):
    if 'obj' in a: return [a['obj']]
    if 'has' in a: return [a['has']] + _rhs_vars(a['rhs'])
    if 'rel' in a: return _arg_vars(a['args'])
    if 'distinct' in a: return list(a['distinct'])
    if 'lacks' in a: return [a['lacks'][0]]
    return []   # none: its variables are local (as in Lean)

def _eff_vars(e):
    if 'set' in e: return [e['set']] + _rhs_vars(e['rhs'])
    if 'update' in e: return [e['update']] + _rhs_vars(e['rhs'])
    if 'add' in e or 'del' in e: return _arg_vars(e['args'])
    if 'change' in e: return _arg_vars(e['args']) + _rhs_vars(e['to'])
    if 'each' in e:
        bound = [x for a in e['each'] for x in _atom_vars(a)]
        return [x for x in _eff_vars(e['eff']) if x not in bound]
    return []

def _cond_atoms(c):
    if 'ex' in c: return c['ex']
    fa = c['all']; return fa['outer'] + fa['filter'] + fa['body']

def task_vars(d):
    vs = []
    for o in d['ops']:
        vs += [p[0] for p in o['params']]
        vs += [x for a in o['pre'] + o['bind'] for x in _atom_vars(a)]
        vs += [x for e in o['effects'] for x in _eff_vars(e)]
        if 'stepCost' in o: vs += _rhs_vars(o['stepCost'])
        vs += [x for e in o['effects'] if 'each' in e for a in e['each'] for x in _atom_vars(a)]
    for f in d['failures']: vs += [x for a in _cond_atoms(f['cond']) for x in _atom_vars(a)]
    vs += [x for a in _cond_atoms(d['goal']) for x in _atom_vars(a)]
    if 'all' in d['goal']: vs.append(d['goal']['all']['var'])
    for dr in d.get('derived', []): vs += dr['vars'] + [x for a in dr['defn'] for x in _atom_vars(a)]
    for m in d.get('evalMarks', []): vs += [x for a in m['cond'] for x in _atom_vars(a)]
    return vs

def check_vars(d):
    bad = sorted(set(x for x in task_vars(d) if bad_var(x)))
    if bad:
        raise SystemExit('spec_backend: description variables with names the back ends reserve or generate: ' +
                         ', '.join(bad) + ' (rename them; WorldSpec/Check.lean Var.badName)')


def compile_task(d):
    assert d.get('format') == 'worldspec-1', d.get('format')
    check_vars(d)
    out = header(d) + init_rules(d) + output_map_rule(d) + space_rules(d) + achievement_for(d)
    for o in d['ops']: out += propose_rule(d, o) + apply_rules(d, o)
    out += sum_rules(d)
    for m in d.get('evalMarks', []): out += eval_mark_rule(d, m)
    for dr in d.get('derived', []): out += derived_rule(d, dr)
    for f in d['failures']: out += failure_rule(d, f)
    import convpass   # 18 Nov 2026 conventions: problem-space test (L3-005), group comments (L3-012)
    return convpass.apply(out + goal_rules(d) + repeat_rules(d)) + learning_block(d)


def learning_block(d):
    """Learning off (World-Conventions L5-021): appended after the rules, so it overrides the library's chunk only."""
    lr = d.get('learning')
    if not lr:
        return ''
    return ('\n## Learning is off for this agent: the English statement says "Learning: do not learn from look-ahead"'
            ' (World-Conventions L5-021).\n' + (f"## Reason given: {lr['reason']}\n" if lr.get('reason') else '') + 'chunk never\n')


if __name__ == '__main__':
    d = json.load(open(sys.argv[1]))
    open(sys.argv[2], 'w').write(compile_task(d))
    print('wrote', sys.argv[2])
