import Family.Prod
/-!
# Family.Task: task-level constructs of a world-convention agent

The upper layer of the family description language. A `Task` states, at the level of the world
conventions, what every world-convention agent has: its problem space (with the derived attributes
that look-ahead must not copy), its initialization (world objects, relations, desireds, flag
overrides), how its desireds are judged achieved, and its default search control. `Task.prods`
compiles these into typed productions (Family.Prod). Family-specific knowledge (operators, derived
attributes, evaluation) is added as typed productions in the family's description.

Conventions (World-Conventions-v6, level IDs of 18 Nov 2026): L7-008 problem space; L7-010
initialize-<task>; L8-018 to L8-020 task-supplied achieved/unachieved; L14-026 do-not-copy list;
L9-001 ^task-operator; L3-005 problem-space test in the first condition.

Written 19 November 2026 by Claude, supervised by John E. Laird.
-/
namespace Fam

/-- How a variant's desireds are judged (task-supplied, L8-018). -/
inductive Achieve where
  | objectState        -- object-property desireds of states
  | objectOperator     -- object-property desireds of proposed operators (their preconditions)
  | relationState      -- two-argument relation desireds of states
  | relationOperator   -- relation desireds of proposed operators
  deriving Repr, Inhabited, BEq, DecidableEq

structure Task where
  /-- The task (and problem-space) name. -/
  name : String
  /-- Extra attributes of the problem space, e.g. `^dont-copy-object-attribute free` (L14-026). -/
  psExtra : List (List RV × List PV) := []
  /-- Flag overrides set at initialization (`^flag-override`, L6-003). -/
  flags : List (String × RV) := []
  /-- `^environment none` (no external environment, L7-011). -/
  environmentNone : Bool := true
  /-- Actions of initialize-<task> after the state's name, desireds and flags: world objects,
  relations and desireds (they may use <s>, <w>, <objs>, <ds>). -/
  initBody : List Act := []
  /-- File of the initialization rules. -/
  initFile : Option String := none
  /-- Extra attributes on the initialize operator. -/
  initOpExtra : List (List RV × List PV) := []
  achieve : List Achieve := [.objectState]
  /-- Further problem spaces whose states judge the desireds the same way (tested with << >>). -/
  achieveSpaces : List String := []
  /-- Task operators are made indifferent by a separate evaluation rule. -/
  indifferent : Option String := none
  /-- Task operators left out of the indifferent rule (tested with ^name <> ...). -/
  indifferentExcept : List String := []
  /-- Ancestor-world elaborations (repeated-state detection in look-ahead). -/
  ancestors : Bool := false
  deriving Repr, Inhabited

namespace Task
variable (t : Task)

private def s := VT.var "s"

def problemSpace : List Prod :=
  let p := (Act.make (.var "p") ((([RV.sym "name"], [pv (rs t.name)])) :: t.psExtra))
  [ { name := s!"{t.name}*elaborate*problem-space",
      doc := [s!"Problem space of the task state and of look-ahead states (both have ^name {t.name}); L7-008, L15-003."],
      conds := [st [at_ "name" [c t.name]]],
      acts := [mkw "s" [("problem-space", [pv (rv "p")])], p] },
    { name := s!"{t.name}*elaborate*problem-space*mea-substate",
      doc := ["The same problem space on a means-ends (MEA) substate of a task operator; L17-001."],
      conds := [st [at_ "impasse" [c "no-change"], at_ "attribute" [c "operator"], at_ "superstate" [v "ss"]],
                id_ "ss" [at_ "problem-space.name" [c t.name], at_ "operator" [v "so"]],
                id_ "so" [at_ "task-operator" [c "true"], nat_ "pre-conditions-satisfied" [c "true"]]],
      acts := [mkw "s" [("problem-space", [pv (rv "p")])], p] } ]

def initProds : List Prod :=
  let nm := s!"initialize-{t.name}"
  let first := Act.make (.var "s") ((([RV.sym "name"], [pv (rs t.name)])) ::
      ((if t.environmentNone then [([RV.sym "environment"], [pv (rs "none")])] else []) ++
       [([RV.sym "desireds"], [pv (rv "ds")])]))
  let fl : List Act := if t.flags.isEmpty then [] else
      [mkw "s" [("flag-override", [pv (rv "f")])],
       .make (.var "f") (t.flags.map fun (k, x) => ([RV.sym k], [pv x]))]
  [ { name := s!"{t.name}*propose*{nm}",
      doc := [s!"{nm} (L7-010, L7-011, L6-003): world objects, relations, desireds and flag overrides."],
      conds := [st [at_ "superstate" [c "nil"], at_ "world" [v "w"], nat_ "name" []]],
      acts := [mkw "s" [("operator", [pvp (rv "o") "+ >"])],
               .make (.var "o") ((([RV.sym "name"], [pv (rs nm)])) :: (([RV.sym "task-operator"], [pv (rs "false")])) :: t.initOpExtra)] },
    { name := s!"{t.name}*apply*{nm}",
      conds := [st [at_ "operator.name" [c nm], at_ "world" [v "w"]], id_ "w" [at_ "objects" [v "objs"]]],
      acts := [first] ++ fl ++ t.initBody ++ [log1 [.str s!"Initialize {t.name}."]] } ]

private def psTest : VT := if t.achieveSpaces.isEmpty then c t.name else .disj ((t.name :: t.achieveSpaces).map VT.sym)

private def objTest : AV :=
  { path := [.conj [ne (c "object-handle"), ne (c "anchored"), ne (c "duplicate-of"), ne (c "origin-object-handle"), v "a"]], vals := [v "v"] }

def achieveProds : Achieve → List Prod
  | .objectState =>
    [ { name := s!"{t.name}*elaborate*desired*achieved*object-property",
        doc := ["Object-property desireds: achieved when an anchored world object with the handle has the value (L8-018)."],
        conds := [st [at_ "problem-space.name" [psTest t], at_ "desireds" [v "ds"], at_ "world" [v "w"]], id_ "ds" [at_ "desired" [v "d"]], id_ "d" [at_ "object" [v "do"]],
                  id_ "do" [at_ "object-handle" [lit (v "h")], objTest],
                  id_ "w" [at_ "anchored-world" [c "true"], at_ "objects.object" [v "ob"]],
                  id_ "ob" [at_ "object-handle" [lit (v "h")], { path := [v "a"], vals := [v "v"] }]],
        acts := [mkw "ds" [("achieved", [pv (rv "d")])]] },
      { name := s!"{t.name}*elaborate*desired*unachieved*object-property",
        doc := ["... and unachieved otherwise (a positive WME, L8-020; no $ inside the negation)."],
        conds := [st [at_ "problem-space.name" [psTest t], at_ "desireds" [v "ds"], at_ "world" [v "w"]], id_ "ds" [at_ "desired" [v "d"]], id_ "d" [at_ "object" [v "do"]],
                  id_ "do" [at_ "object-handle" [lit (v "h")], objTest],
                  id_ "w" [at_ "anchored-world" [c "true"]],
                  .ncc [id_ "w" [at_ "objects.object" [v "ob"]], id_ "ob" [at_ "object-handle" [v "h"], { path := [v "a"], vals := [v "v"] }]]],
        acts := [mkw "ds" [("unachieved", [pv (rv "d")])]] } ]
  | .objectOperator =>
    [ { name := s!"{t.name}*elaborate*operator-desired*achieved*object-property",
        doc := ["Object-property desireds of a proposed operator (its preconditions; L9-006)."],
        conds := [st [at_ "problem-space.name" [psTest t], at_ "operator" [v "op", c "+"], at_ "world" [v "w"]], id_ "op" [at_ "desireds" [v "ds"]], id_ "ds" [at_ "desired" [v "d"]],
                  id_ "d" [at_ "object" [v "do"]], id_ "do" [at_ "object-handle" [lit (v "h")], objTest],
                  id_ "w" [at_ "anchored-world" [c "true"], at_ "objects.object" [v "ob"]],
                  id_ "ob" [at_ "object-handle" [lit (v "h")], { path := [v "a"], vals := [v "v"] }]],
        acts := [mkw "ds" [("achieved", [pv (rv "d")])]] },
      { name := s!"{t.name}*elaborate*operator-desired*unachieved*object-property",
        conds := [st [at_ "problem-space.name" [psTest t], at_ "operator" [v "op", c "+"], at_ "world" [v "w"]], id_ "op" [at_ "desireds" [v "ds"]], id_ "ds" [at_ "desired" [v "d"]],
                  id_ "d" [at_ "object" [v "do"]], id_ "do" [at_ "object-handle" [lit (v "h")], objTest],
                  id_ "w" [at_ "anchored-world" [c "true"]],
                  .ncc [id_ "w" [at_ "objects.object" [v "ob"]], id_ "ob" [at_ "object-handle" [v "h"], { path := [v "a"], vals := [v "v"] }]]],
        acts := [mkw "ds" [("unachieved", [pv (rv "d")])]] } ]
  | .relationState => relProds "desireds" "desired" []
  | .relationOperator => relProds "operator-desired" "operator-desired" [at_ "operator" [v "op", c "+"]]
where
  relProds (kind _k2 : String) (opTest : List AV) : List Prod :=
    let head : List Cond := if opTest.isEmpty then [st [at_ "problem-space.name" [psTest t], at_ "desireds" [v "ds"], at_ "world" [v "w"]]]
      else [st ([at_ "problem-space.name" [psTest t]] ++ opTest ++ [at_ "world" [v "w"]]), id_ "op" [at_ "desireds" [v "ds"]]]
    let args := fun (litH : Bool) => [at_ "argument1.object-handle" [if litH then lit (v "h1") else v "h1"],
                                      at_ "argument2.object-handle" [if litH then lit (v "h2") else v "h2"]]
    let nmk := if opTest.isEmpty then "desired" else "operator-desired"
    [ { name := s!"{t.name}*elaborate*{nmk}*achieved*relation",
        doc := ["Relation desireds (two arguments): achieved when the world has the relation between those handles (L8-018)."],
        conds := head ++ [id_ "ds" [at_ "desired" [v "d"]], id_ "d" [{ path := [v "rel"], vals := [v "dr"] }], id_ "dr" (args true),
                  id_ "w" [at_ "anchored-world" [c "true"], { path := [v "rel"], vals := [v "wr"] }], id_ "wr" (args true)],
        acts := [mkw "ds" [("achieved", [pv (rv "d")])]] },
      { name := s!"{t.name}*elaborate*{nmk}*unachieved*relation",
        conds := head ++ [id_ "ds" [at_ "desired" [v "d"]], id_ "d" [{ path := [v "rel"], vals := [v "dr"] }], id_ "dr" (args true),
                  id_ "w" [at_ "anchored-world" [c "true"]],
                  .ncc [id_ "w" [{ path := [v "rel"], vals := [v "wr"] }], id_ "wr" (args false)]],
        acts := [mkw "ds" [("unachieved", [pv (rv "d")])]] } ]

def indifferentProds : List Prod :=
  match t.indifferent with
  | none => []
  | some why =>
    [ { name := s!"{t.name}*compare*task-operator*indifferent",
        doc := [s!"Search control: {why}, so task operators are made indifferent here",
                "(an evaluation rule; proposals create only the acceptable preference, L9-004)."],
        conds := [st [at_ "problem-space.name" [c t.name], at_ "operator" [v "o", c "+"]], id_ "o" ([at_ "task-operator" [c "true"]] ++ t.indifferentExcept.map (fun x => at_ "name" [ne (c x)]))],
        acts := [mkw "s" [("operator", [pvp (rv "o") "="])]] } ]

def ancestorProds : List Prod :=
  if !t.ancestors then [] else
    [ { name := s!"{t.name}*elaborate*ancestor*superstate",
        doc := ["Ancestors of a state that have the task's problem space (used for repeated-state detection in look-ahead)."],
        conds := [st [at_ "superstate" [v "ss"]], id_ "ss" [at_ "problem-space.name" [c t.name], at_ "world" [v "aw"]],
                  id_ "aw" [at_ "anchored-world" [c "true"]]],
        acts := [mkw "s" [("ancestor-world", [pv (rv "aw")])]] },
      { name := s!"{t.name}*elaborate*ancestor*inherit",
        conds := [st [at_ "superstate.ancestor-world" [v "aw"]]],
        acts := [mkw "s" [("ancestor-world", [pv (rv "aw")])]] } ]

end Task

/-- Variables that a positive condition of `cs` binds as an argument (`^argument1`, `^argument2`, ...) of a relation
object `<r>` that another positive condition binds as `(<w> ^rel <r>)`. -/
def relArgVars (cs : List Cond) (w : String) : List String :=
  let relObjs := cs.flatMap fun
    | .pos _ (.var y) avs => if y != w then [] else avs.flatMap fun a =>
        if a.neg then [] else match a.path with
          | [.sym at_] => if at_ == "objects" then [] else a.vals.filterMap fun | .var r => some r | _ => none
          | _ => []
    | _ => []
  cs.flatMap fun
    | .pos _ (.var r) avs => if !relObjs.contains r then [] else avs.flatMap fun a =>
        if a.neg then [] else match a.path with
          | [.sym at_] => if at_.startsWith "argument" then a.vals.filterMap fun | .var x => some x | _ => none else []
          | _ => []
    | _ => []

/-- World-Conventions L3-104: a test `(<w> ^objects.object <x>)` is left out when `<x>` is also bound as an argument of
a relation `(<w> ^rel <r>) (<r> ^argumentN <x>)` in the same rule. The library copies relations into look-ahead worlds
through the copy map, so a relation's arguments are always objects of its world and the test adds nothing to what the
rule matches; it only offers the reorderer a join of the world's objects with each other (kenken drop-tuple,
392 x 392 objects). Top-level positive conditions only. -/
def Prod.dropRedundantObjectTests (p : Prod) : Prod :=
  let worlds := p.conds.flatMap fun
    | .pos _ (.var w) avs => if avs.any (fun a => !a.neg && a.path == [.sym "objects", .sym "object"]) then [w] else []
    | _ => []
  let conds := p.conds.filterMap fun c => match c with
    | .pos st (.var w) avs =>
      if !worlds.contains w then some c else
      let red := relArgVars p.conds w
      let avs' := avs.filterMap fun a =>
        if a.neg || a.path != [.sym "objects", .sym "object"] then some a else
        let vals := a.vals.filter fun x => match x with | .var v => !red.contains v | _ => true
        if vals.isEmpty then none else some { a with vals := vals }
      if avs'.isEmpty then none else some (.pos st (.var w) avs')
    | _ => some c
  { p with conds := conds }


/-! ## Static objects and shared relations (World-Conventions L7-028, candidate 26 Nov 2026)

The same analysis as worldgen/static_pass.py, on typed productions instead of text. An object of the initial world is
static when no production other than the initialize rule writes or removes an attribute on an object of its type (a
write on an object variable whose type the production does not test, and cannot take from an operator argument or a
constant handle, makes nothing static); the task object is never static. A relation of the initial world is shared
when no other production adds or removes it on a world or changes one of its relation objects, the library does not
copy it itself (on, above, in), and every argument of every initial tuple is a static object. -/

/-- One attribute test or action: identifier, attribute, value (variables as `<v>`; `none` for a test or a value
that binds nothing, such as a comparison or a function). -/
structure Tri where
  id : String
  attr : String
  val : Option String
  deriving Repr, Inhabited, BEq

private def vtName : VT → Option String
  | .sym s => some s | .int i => some (toString i) | .flt s => some s | .var x => some s!"<{x}>"
  | _ => none

private partial def vtVars : VT → List String
  | .var x => [s!"<{x}>"] | .cmp _ t => vtVars t | .conj ts => ts.flatMap vtVars | .lit t => vtVars t
  | _ => []

/-- The value a test binds, as static_pass.triples reads it. -/
private partial def vtVal : VT → Option String
  | .conj ts => (ts.flatMap vtVars).getLast?
  | .disj _ => none
  | .cmp _ _ => none
  | .lit t => vtVal t
  | t => vtName t

private def rvVal : RV → Option String
  | .sym s => some s | .int i => some (toString i) | .flt s => some s | .var x => some s!"<{x}>"
  | .str s => some ("|" ++ s ++ "|") | .fn _ _ => none

/-- A dotted path from `id`: intermediate identifiers get fresh names from `tag`. -/
private def pathTris (id : String) (path : List String) (vals : List (Option String)) (tag : String) : List Tri :=
  let rec go (cur : String) (k : Nat) : List String → List Tri
    | [] => []
    | [a] => vals.map fun x => { id := cur, attr := a, val := x }
    | a :: rest => let nv := s!"<#{tag}.{k}>"; { id := cur, attr := a, val := some nv } :: go nv (k + 1) rest
  go id 0 path

/-- Triples of the positive conditions of a production (negated conditions and attribute tests bind nothing). -/
def condTris (cs : List Cond) : List Tri :=
  (cs.zipIdx).flatMap fun (cnd, ci) => match cnd with
    | .pos _ (.var x) avs => (avs.zipIdx).flatMap fun (a, ai) =>
        if a.neg then [] else
        match a.path.mapM vtName with
        | some path => pathTris s!"<{x}>" path (a.vals.map vtVal) s!"c{ci}.{ai}"
        | none => []
    | _ => []

/-- Triples of the actions of a production. -/
def actTris (acts : List Act) : List Tri :=
  (acts.zipIdx).flatMap fun (act, ki) => match act with
    | .make (.var x) avs => (avs.zipIdx).flatMap fun ((p, vs), ai) =>
        match p.mapM rvVal with
        | some path => pathTris s!"<{x}>" path (vs.map (rvVal ·.val)) s!"a{ki}.{ai}"
        | none => []
    | _ => []

def notRelations : List String :=
  ["objects", "anchored-world", "real", "duplicate-of", "copy-map", "stamp", "parent-stamp", "local-version",
   "versioned-tag", "versioned-operator", "look-ahead-steps", "parent-steps", "room-name", "anchored",
   "counted-operator", "applied-count"]

private def isArg (a : String) : Bool := a.startsWith "argument" && (a.drop 8).all Char.isDigit && a.length > 8
private def isVarName (x : String) : Bool := x.startsWith "<"

/-- Properties a type must have under `^fixed` (World-Conventions L7-022, measured 26 Nov 2026). -/
def fixedMin : Nat := 3
/-- Library attributes stay flat. -/
def libFlat : List String := ["object-handle", "type", "anchored", "static", "fixed"]

/-- Drop names until every type that has a name has it fixed and has at least `fixedMin` of the kept names. -/
def fixedIter (types : List String) (propsOf : String → List String) (isFixed : String → String → Bool) :
    List String → Nat → List String
  | names, 0 => names
  | names, k + 1 =>
    let keep := names.filter fun p => types.all fun ty => !(propsOf ty).contains p || isFixed ty p
    let keep := keep.filter fun p => types.all fun ty =>
      !(propsOf ty).contains p || ((propsOf ty).filter keep.contains).length ≥ fixedMin
    if keep == names then names else fixedIter types propsOf isFixed keep k

/-- Triples of all conditions, negated ones included (negated attribute tests bind nothing), as static_pass reads a
whole left-hand side. -/
partial def condTrisAll (cs : List Cond) : List Tri :=
  condTris cs ++ cs.flatMap fun cnd => match cnd with
    | .neg c => condTrisAll [c]
    | .ncc cs' => condTrisAll cs'
    | _ => []

/-- The variable-identifier condition groups of a condition, negated ones included (state groups left out). -/
partial def condGroups : Cond → List (String × List AV)
  | .pos false (.var x) avs => [(s!"<{x}>", avs)]
  | .pos _ _ _ => []
  | .neg c => condGroups c
  | .ncc cs => cs.flatMap condGroups

private def vtConst : VT → Bool
  | .sym _ => true | .int _ => true | .flt _ => true | _ => false

private partial def attrVars : VT → List String
  | .var x => [s!"<{x}>"] | .conj ts => ts.flatMap attrVars | .cmp _ t => attrVars t | .lit t => attrVars t | _ => []

/-- Identifiers reached through these attributes are not objects of the world. -/
def notObjectAttrs : List String :=
  ["operator", "world", "desireds", "desired", "achieved", "unachieved", "superstate", "io", "input-link",
   "output-link", "problem-space", "objects", "top-state", "super-desireds", "flags"]

/-- Types whose properties a production tests through an attribute that is not a constant (`^<a>`, `^<< a b >>`,
`^{ ... }`; World-Conventions L7-022; static_pass._varattr_types): such a test does not see a property moved under
`^fixed`, so those types keep every property flat. When the tested object's type is not known, nothing is fixed, except
on a desired object, or when each attribute variable is bound by an attribute test on a desired object. Returns
(blocked types, block all). -/
def varAttrTypes (prods : List Prod) : List String × Bool :=
  prods.foldl (fun (acc : List String × Bool) p =>
    if acc.2 || (p.name.splitOn "*apply*initialize-").length > 1 then acc else
    let lt := condTrisAll p.conds
    let typesOf := fun (x : String) => lt.filterMap fun t =>
      if t.id == x && t.attr == "type" then t.val.filter (!isVarName ·) else none
    let dids := lt.filterMap fun t => if ["desired", "achieved", "unachieved"].contains t.attr then t.val else none
    let dobj := lt.filterMap fun t => if dids.contains t.id && t.attr == "object" then t.val else none
    let notobj := lt.filterMap (fun t => if notObjectAttrs.contains t.attr then t.val else none) ++
      lt.filterMap (fun t => if ["name", "task-operator", "superstate", "problem-space"].contains t.attr then some t.id else none)
    let groups := p.conds.flatMap condGroups
    let nonConst := fun (avs : List AV) => avs.any fun a => a.path.any (!vtConst ·)
    let avarsOf := fun (avs : List AV) => avs.flatMap fun a => a.path.flatMap attrVars
    let dvars := (groups.filter (dobj.contains ·.1)).flatMap (avarsOf ·.2)
    groups.foldl (fun (acc : List String × Bool) (x, avs) =>
      if acc.2 || dobj.contains x || notobj.contains x || !nonConst avs then acc else
      let ts := typesOf x
      if !ts.isEmpty then (acc.1 ++ ts, false) else
      let av := avarsOf avs
      let disj := avs.any fun a => a.path.any fun v => match v with | .disj _ => true | _ => false
      if disj || av.isEmpty || !av.all dvars.contains then (acc.1, true) else acc) acc) ([], false)

/-- Static objects (their variables in the initialize rule), shared relations and fixed properties of a list of
productions. -/
def staticInfo (prods : List Prod) : List String × List String × List String :=
  let isInit := fun (p : Prod) => (p.name.splitOn "*apply*initialize-").length > 1 &&
    (actTris p.acts).any (·.attr == "object") && (actTris p.acts).any (·.attr == "object-handle")
  match prods.find? isInit with
  | none => ([], [], [])
  | some ip =>
  let tr := actTris ip.acts
  let il := condTris ip.conds
  let objsets := il.filterMap fun t => if t.attr == "objects" then t.val else none
  let objs := tr.filterMap fun t => if objsets.contains t.id && t.attr == "object" then t.val.filter isVarName else none
  let handleOf := fun (x : String) => (tr.find? fun t => t.id == x && t.attr == "object-handle").bind (·.val)
  let typeOf := fun (x : String) => (tr.find? fun t => t.id == x && t.attr == "type").bind (·.val)
  let lw := il.filterMap fun t => if t.attr == "world" then t.val else none
  let relTuples : List (String × List String) := tr.filterMap fun t =>
    if lw.contains t.id && !notRelations.contains t.attr then
      match t.val with
      | some r => if isVarName r then some (t.attr, tr.filterMap fun t2 => if t2.id == r && isArg t2.attr then t2.val else none) else none
      | none => none
    else none
  let htype : List (String × String) := objs.filterMap fun x => match handleOf x, typeOf x with
    | some h, some ty => some (h, ty) | _, _ => none
  -- operator argument types, from the proposals
  let argtype : List ((String × String) × List String) := prods.flatMap fun p =>
    let lt := condTris p.conds; let rt := actTris p.acts
    let tyOf := fun (x : String) => lt.filterMap fun t => if t.id == x && t.attr == "type" then t.val.filter (!isVarName ·) else none
    rt.flatMap fun t => if t.attr != "name" then [] else match t.val with
      | some n => if isVarName n then [] else rt.filterMap fun t2 =>
          if t2.id == t.id && isArg t2.attr then
            let ts := match t2.val with | some x => tyOf x | none => []
            some ((n, t2.attr), if ts.isEmpty then ["?"] else ts)
          else none
      | none => []
  let argTypes := fun (k : String × String) => (argtype.filter (·.1 == k)).flatMap (·.2)
  let res := prods.foldl (fun (acc : List String × Bool × List String × List (String × String)) p =>
    if p.name == ip.name then acc else
    let (mutable, untyped, written, wattr) := acc
    let lt := condTris p.conds
    let objv0 := lt.filterMap fun t => if t.attr == "object" || isArg t.attr then t.val else none
    let worldv := lt.filterMap fun t => if t.attr == "world" then t.val else none
    let relv : List (String × String) := lt.filterMap fun t =>
      if worldv.contains t.id && !notRelations.contains t.attr then t.val.map (·, t.attr) else none
    let types0 : List (String × List String) := lt.filterMap fun t =>
      if t.attr == "type" then (t.val.filter (!isVarName ·)).map fun ty => (t.id, [ty]) else none
    let typesOf := fun (tys : List (String × List String)) (x : String) => (tys.filter (·.1 == x)).flatMap (·.2)
    -- objects found by a constant handle
    let byHandle : List (String × List String) := lt.filterMap fun t =>
      if t.attr == "object-handle" then match t.val with
        | some h => if isVarName h || (typesOf types0 t.id).length > 0 then none
                    else (htype.find? (·.1 == h)).map fun (_, ty) => (t.id, [ty])
        | none => none
      else none
    let types1 := types0 ++ byHandle
    -- objects found by the handle of an operator's (or a command's) argument
    let hvar := fun (h : String) => (lt.filter fun t => t.attr == "object-handle" && t.val == some h).getLast?.map (·.id)
    let names : List (String × String) := lt.filterMap fun t =>
      if t.attr == "name" then (t.val.filter (!isVarName ·)).map (t.id, ·) else none
    let nameOf := fun (o : String) => (names.filter (·.1 == o)).getLast?.map (·.2)
    let byArg : List (String × List String) := lt.foldl (fun (got : List (String × List String)) t =>
      match nameOf t.id, t.val with
      | some n, some y =>
        if !isArg t.attr then got else
        let hs := y :: lt.filterMap fun t2 => if t2.id == y && t2.attr == "object-handle" then t2.val else none
        hs.foldl (fun got h => match hvar h with
          | some x =>
            let at_ := argTypes (n, t.attr)
            if x != y && (typesOf (types1 ++ got) x).isEmpty && !at_.isEmpty && !at_.contains "?" then got ++ [(x, at_)] else got
          | none => got) got
      | _, _ => got) []
    let types := types1 ++ byArg
    let objv := objv0 ++ byHandle.map (·.1) ++ byArg.map (·.1)
    let rt := actTris p.acts
    -- objects a production adds to an object set (their properties count as written, for ^fixed)
    let objsv := (lt ++ rt).filterMap fun t => if t.attr == "objects" then t.val else none
    let newobj := rt.filterMap fun t =>
      if objsv.contains t.id && t.attr == "object" then t.val.filter fun x => isVarName x && !objv.contains x else none
    rt.foldl (fun (mutable, untyped, written, wattr) t =>
      let (mutable, untyped, wattr) :=
        if objv.contains t.id && t.attr != "duplicate-of" then
          let ts := typesOf types t.id
          if ts.isEmpty then (mutable, true, wattr) else (mutable ++ ts, untyped, wattr ++ ts.map (·, t.attr))
        else (mutable, untyped, wattr)
      let (mutable, untyped, wattr) :=
        if newobj.contains t.id then
          let nt := rt.filterMap fun t2 => if t2.id == t.id && t2.attr == "type" then t2.val.filter (!isVarName ·) else none
          if nt.isEmpty then (mutable, true, wattr) else (mutable ++ nt, untyped, wattr ++ nt.map (·, t.attr))
        else (mutable, untyped, wattr)
      let written := if worldv.contains t.id && !notRelations.contains t.attr then written ++ [t.attr] else written
      let written := match relv.find? (·.1 == t.id) with | some (_, r) => written ++ [r] | none => written
      (mutable, untyped, written, wattr)) (mutable, untyped, written, wattr)) ([], false, [], [])
  let (mutable, untyped, written, wattr) := res
  if untyped then ([], [], []) else
  let staticVars := objs.filter fun x => match typeOf x, handleOf x with
    | some ty, some _ => !mutable.contains ty && ty != "task"
    | none, some _ => !mutable.contains "" && true
    | _, none => false
  let rels := relTuples.foldl (fun acc (r, _) => if acc.contains r then acc else acc ++ [r]) []
  let shared := rels.filter fun r => !written.contains r && !["on", "above", "in"].contains r &&
    (relTuples.filter (·.1 == r)).all fun (_, args) => args.all staticVars.contains
  -- Fixed properties (World-Conventions L7-022, 26 Nov 2026; static_pass._fixed_props)
  let types := (objs.filterMap typeOf).eraseDups
  let propsOf := fun (ty : String) => (((objs.filter (typeOf · == some ty)).flatMap fun x =>
      tr.filter fun t => t.id == x && !libFlat.contains t.attr).map (·.attr)).eraseDups
  let constant := fun (ty p : String) => (objs.filter (typeOf · == some ty)).all fun x =>
      (tr.filter fun t => t.id == x && t.attr == p).all fun t => match t.val with
        | some v => !isVarName v | none => false
  let dattrs := prods.flatMap fun p =>
    let rt := actTris p.acts
    let ids := rt.filterMap fun t => if t.attr == "desired" then t.val else none
    let dobj := rt.filterMap fun t => if ids.contains t.id && t.attr == "object" then t.val else none
    rt.filterMap fun t => if dobj.contains t.id then some t.attr else none
  let (vblocked, vall) := varAttrTypes prods
  let ok := fun (ty : String) => mutable.contains ty && ty != "task" && !vblocked.contains ty
  let isFixed := fun (ty p : String) => ok ty && !wattr.contains (ty, p) && constant ty p && !dattrs.contains p
  let cand := (types.flatMap fun ty => (propsOf ty).filter (isFixed ty)).eraseDups
  let fixedNames := if vall then [] else fixedIter types propsOf isFixed cand (cand.length + 1)
  (staticVars, shared, fixedNames)

/-- Look-ahead is possible unless every task operator is applied without a tie (static_pass.has_lookahead): all
task-operator proposals are monotonic, or every proposed task operator gets an indifferent preference from a production
that tests the operator by a constant name or by no name at all (a `^name <>` exclusion covers nothing). -/
def hasLookahead (prods : List Prod) : Bool :=
  let opPrefs := fun (p : Prod) => p.acts.flatMap fun a => match a with
    | .make _ avs => avs.flatMap fun (path, vs) => if path == [.sym "operator"] then vs else []
    | _ => []
  let props := prods.filter fun p => (actTris p.acts).any (fun t => t.attr == "task-operator" && t.val == some "true") &&
    (opPrefs p).any fun x => x.pref == "+" && (match x.val with | .var _ => true | _ => false)
  if props.isEmpty then true else
  if props.all (fun p => (actTris p.acts).any fun t => t.attr == "monotonic" && t.val == some "true") then false else
  let names := props.flatMap fun p => (actTris p.acts).filterMap fun t =>
    if t.attr == "name" then t.val.filter (!isVarName ·) else none
  let (covered, every) := prods.foldl (fun (acc : List String × Bool) p =>
    (opPrefs p).foldl (fun (covered, every) x => match x.val with
      | .var o =>
        if !x.pref.startsWith "=" then (covered, every) else
        let lt := condTris p.conds
        let ns := lt.filterMap fun t => if t.id == s!"<{o}>" && t.attr == "name" then some t.val else none
        let excl := p.conds.any fun cnd => match cnd with
          | .pos _ (.var y) avs => y == o && avs.any fun a => !a.neg && a.path == [.sym "name"] &&
              a.vals.any fun vt => match vt with | .cmp "<>" _ => true | _ => false
          | _ => false
        if excl then (covered, every) else
        if ns.isEmpty then (covered, true) else (covered ++ ns.filterMap fun n => n.filter (!isVarName ·), every)
      | _ => (covered, every)) acc) ([], false)
  !(every || names.all covered.contains)

/-- Fixed properties under `^fixed` (World-Conventions L7-022, 26 Nov 2026; static_pass._fixed_text): the
initialize rule's object groups move them to a `^fixed` group; every other production's tests of them on an object
variable, or through `^argumentN` / `^object`, become `^fixed.<p>`. -/
def markFixed (names : List String) (prods : List Prod) : List Prod :=
  let isInit := fun (p : Prod) => (p.name.splitOn "*apply*initialize-").length > 1 &&
    (actTris p.acts).any (·.attr == "object-handle")
  let objtypes := (prods.filter isInit).flatMap fun p => (actTris p.acts).filterMap fun t =>
    if t.attr == "type" then t.val else none
  let one := fun (p : List VT) => match p with | [.sym a] => names.contains a | _ => false
  let initAct : Act → List Act
    | .make (.var x) avs =>
      if !avs.any (fun (path, _) => path == [.sym "object-handle"]) then [.make (.var x) avs] else
      let isFx := fun (path : List RV) => match path with | [.sym a] => names.contains a | _ => false
      let fx := avs.filter (isFx ·.1)
      if fx.isEmpty then [.make (.var x) avs] else
      [.make (.var x) (avs.filter (!isFx ·.1) ++ [([.sym "fixed"], [{ val := .var (x ++ "-fx") }])]),
       .make (.var (x ++ "-fx")) fx]
    | a => [a]
  let dotted := fun (path : List VT) =>
    match path.reverse with
    | .sym last :: .sym prev :: _ =>
      if names.contains last && (prev == "object" || isArg prev) then path.dropLast ++ [.sym "fixed", .sym last] else path
    | _ => path
  prods.map fun p =>
    if isInit p then { p with acts := p.acts.flatMap initAct } else
    let ta := condTrisAll p.conds
    let objv := ta.filterMap (fun t => if t.attr == "object" || isArg t.attr then t.val.filter isVarName else none) ++
      ta.filterMap (fun t => if t.attr == "object-handle" || (t.attr == "type" && (t.val.map objtypes.contains).getD false)
        then some t.id else none)
    let rec fixC : Cond → Cond
      | .pos st (.var x) avs => .pos st (.var x) (avs.map fun a =>
          if objv.contains s!"<{x}>" && one a.path then { a with path := [.sym "fixed"] ++ a.path }
          else { a with path := dotted a.path })
      | .pos st id avs => .pos st id (avs.map fun a => { a with path := dotted a.path })
      | .neg c => .neg (fixC c)
      | .ncc cs => .ncc (cs.map fixC)
    { p with conds := p.conds.map fixC }

/-- Apply the marks: `^static true` on the static objects in the initialize rule, `^share-relation` for each shared
relation (in place of `^copy-relation`, or added to the problem-space rule). -/
def markStatic (taskName : String) (prods : List Prod) : List Prod :=
  let (sv, shared, fx) := staticInfo prods
  let prods := if fx.isEmpty || !hasLookahead prods then prods else markFixed fx prods
  if sv.isEmpty then prods else
  let isInit := fun (p : Prod) => (p.name.splitOn "*apply*initialize-").length > 1
  let declared := prods.any fun p => (actTris p.acts).any fun t => t.attr == "copy-relation" && (t.val.map shared.contains).getD false
  let fixAct : Act → Act
    | .make id avs => .make id (avs.flatMap fun (path, vs) =>
        if path == [.sym "copy-relation"] then
          let (sh, cp) := vs.partition fun x => match x.val with | .sym r => shared.contains r | _ => false
          (if cp.isEmpty then [] else [(path, cp)]) ++ (if sh.isEmpty then [] else [([.sym "share-relation"], sh)])
        else [(path, vs)])
    | a => a
  prods.map fun p =>
    let p := { p with acts := p.acts.map fixAct }
    let p := if !isInit p then p else { p with acts := p.acts.map fun
      | .make (.var x) avs => if sv.contains s!"<{x}>" then .make (.var x) (avs ++ [([.sym "static"], [pv (rs "true")])]) else .make (.var x) avs
      | a => a }
    if declared || shared.isEmpty || p.name != s!"{taskName}*elaborate*problem-space" then p else
    { p with acts := p.acts.map fun
      | .make (.var "p") avs => .make (.var "p") (avs ++ [([.sym "share-relation"], shared.map fun r => pv (rs r))])
      | a => a }

/-- A variant: a task with family knowledge, written as files of productions. A file's entries are
the task-level constructs it holds (`.ps`, `.init`, ...) and typed productions (`.p`). -/
inductive Item where
  | ps | init | achieve (a : Achieve) | indifferent | ancestors
  | p (x : Prod)
  deriving Repr, Inhabited

structure Variant where
  family : String
  name : String
  task : Task
  about : List String := []
  firstload : List String := []
  files : List (String × List Item)
  deriving Repr, Inhabited

/-- True when some production's conditions test `^desireds` (or a path through it) on anything but a state; a
state's own `^desireds` is the task's (convpass.tests_operator_desireds). -/
partial def testsOperatorDesireds (prods : List Prod) : Bool :=
  let isD := fun (v : VT) => match v with
    | .sym a => a == "desireds" || a.startsWith "desireds-"
    | _ => false
  let rec onCond : Cond → Bool
    | .pos st _ avs => avs.any fun a => if st then (a.path.drop 1).any isD else a.path.any isD
    | .neg c => onCond c
    | .ncc cs => cs.any onCond
  prods.any fun p => p.conds.any onCond

/-- L9-011 (27 Nov 2026; convpass.no_precondition_form): in a proposal, `^desireds <pre>` whose structure
is only `(<pre> ^desired-count 0)` becomes `^pre-conditions-satisfied true`. -/
def noPreconditionForm (p : Prod) : Prod :=
  if (p.name.splitOn "*")[1]? != some "propose" then p else
  let txt := p.toSoar
  let empties := p.acts.filterMap fun a => match a with
    | .make (.var pre) [([.sym "desired-count"], [{ val := .int 0, pref := "" }])] =>
      if (txt.splitOn s!"<{pre}>").length == 3 then some pre else none
    | _ => none
  let isRef := fun (pre : String) (path : List RV) (vs : List PV) =>
    path == [.sym "desireds"] && vs == [{ val := .var pre }]
  let empties := empties.filter fun pre => p.acts.any fun a => match a with
    | .make _ avs => avs.any fun (path, vs) => isRef pre path vs
    | _ => false
  if empties.isEmpty then p else
  { p with acts := p.acts.filterMap fun a => match a with
      | .make (.var x) avs =>
        if empties.contains x && avs.length == 1 then none else
        some (.make (.var x) (avs.map fun (path, vs) =>
          if empties.any (isRef · path vs) then ([.sym "pre-conditions-satisfied"], [{ val := .sym "true" }]) else (path, vs)))
      | a => some a }

def Variant.render (vr : Variant) : List (String × String) :=
  let t := vr.task
  let item : Item → List Prod
    | .ps => t.problemSpace | .init => t.initProds | .achieve a => t.achieveProds a
    | .indifferent => t.indifferentProds | .ancestors => t.ancestorProds | .p x => [x]
  -- static marks (L7-028 candidate) from all of the variant's productions, after L3-104
  let all := vr.files.flatMap fun (_, items) => (items.map item).foldr (· ++ ·) [] |>.map (·.dropRedundantObjectTests)
  let marked := markStatic t.name all
  let marked := if testsOperatorDesireds marked then marked else marked.map noPreconditionForm
  let rec take (ps : List Prod) : List (String × List Item) → List (String × String)
    | [] => []
    | (f, items) :: rest =>
      let n := ((items.map item).foldr (· ++ ·) []).length
      (f, "\n".intercalate ((ps.take n).map (·.toSoar))) :: take (ps.drop n) rest
  take marked vr.files

/-- Attributes an action adds to identifier `<x>` with their number of values (single-symbol attribute paths;
removals, `-`, are left out). -/
def Act.adds (x : String) : Act → List (String × Nat)
  | .make (.var y) avs => if y != x then [] else avs.filterMap fun (p, vs) =>
      match p with
      | [.sym a] => if vs.any (·.pref == "-") then none else some (a, vs.length)
      | _ => none
  | _ => []

/-- Matching hints for learned rules (World-Conventions L11-009, L3-095), as WorldSpec's `matchHints`:
`production optimize-attribute` for `object` (the objects made at initialization) and for every attribute a rule
adds to the world `<w>` (its number of values at initialization, at least 2). familygen writes them at the end of
`_firstload.soar`, which is loaded before the rule files; they change condition order only. -/
def Variant.matchHints (vr : Variant) : List String :=
  let t := vr.task
  let item : Item → List Prod
    | .ps => t.problemSpace | .init => t.initProds | .achieve a => t.achieveProds a
    | .indifferent => t.indifferentProds | .ancestors => t.ancestorProds | .p x => [x]
  let prods := vr.files.flatMap fun (_, items) => items.flatMap item
  let nObj := (t.initBody.flatMap (Act.adds "objs")).foldl (fun n (a, k) => if a == "object" then n + k else n) 0
  let initW := t.initBody.flatMap (Act.adds "w")
  let names := (prods.flatMap fun p => p.acts.flatMap (Act.adds "w")).foldl
    (fun acc (a, _) => if a == "objects" || acc.contains a then acc else acc ++ [a]) []
  let line := fun (a : String) (k : Nat) => s!"production optimize-attribute {a} {max k 2}"
  if nObj == 0 && names.isEmpty then [] else
  ["", "## Matching hints for learned rules (World-Conventions L3-095, L11-009): many-valued attributes, sized from the initial world.",
   line "object" nObj] ++
  names.map fun a => line a ((initW.filter (·.1 == a)).foldl (fun n (_, k) => n + k) 0)

end Fam
