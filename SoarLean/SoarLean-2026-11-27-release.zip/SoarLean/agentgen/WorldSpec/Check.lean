import WorldSpec.Types
/-!
# Well-formedness of a WorldSpec description

`Task.wellFormed` lists what would make a description unusable; a description is checked by proving
that the list is empty (`by decide`, below for each task). The checks:
* W-CHK-009: no negation (`lacks`, `none`) in any compiled condition: operator preconditions and
  bindings, losing conditions and the goal. Negations may appear only in a maintained relation's
  definition, which is evaluated in Lean, not compiled.
* Effects and report lines use only the operator's parameters and the variables its binding condition
  binds (they are all the effect rules can see); a reported handle must be a parameter's.
* No arithmetic (`plus`, `minus`, `times`, `quot`, `rem`) in a compiled condition; no description variable with a name the back ends
  reserve or generate (`Var.badName`).
* Issue 6 (CLAUDE.md): no assumption of kind `gap` or `tooling` remains open in the ledger.
-/
namespace WorldSpec

def Arg.vars : Arg → List String
  | .var x => [x]
  | .h _ => []

def Rhs.vars : Rhs → List String
  | .val _ => []
  | .prop y _ => [y]
  | .plus a b | .minus a b | .times a b | .quot a b | .rem a b => a.vars ++ b.vars

def Atom.vars : Atom → List String
  | .obj x _ => [x]
  | .has x _ _ r => x :: r.vars
  | .rel _ as => as.flatMap Arg.vars
  | .distinct x y => [x, y]
  | .lacks x _ => [x]
  | .none _ => []

def Atom.isNeg : Atom → Bool
  | .lacks .. => true
  | .none .. => true
  | _ => false

def Cond.atoms : Cond → List Atom
  | .ex as => as
  | .all fa => fa.outer ++ fa.filter ++ fa.body

def Eff.vars : Eff → List String
  | .set x _ r => x :: r.vars
  | .update x _ r => x :: r.vars
  | .add _ as => as.flatMap Arg.vars
  | .del _ as => as.flatMap Arg.vars
  | .change _ as _ to => as.flatMap Arg.vars ++ to.vars
  | .each as e => let bound := as.flatMap Atom.vars; e.vars.filter (!bound.contains ·)

/-- The atoms and inner effects of `each` effects. -/
def Eff.eachAtoms : Eff → List Atom
  | .each as _ => as
  | _ => []

def Eff.nestedEach : Eff → Bool
  | .each _ (.each ..) => true
  | _ => false

def Eff.relName : Eff → Option String
  | .add r _ | .del r _ | .change r .. => some r
  | .each _ e => e.relName
  | _ => Option.none

def Op.check (o : Op) : List String :=
  let ps := o.params.map (·.1)
  let seen := ps ++ o.bind.flatMap Atom.vars
  let neg := ((o.pre ++ o.bind).filter Atom.isNeg).map fun _ => s!"{o.name}: negation in a compiled condition (W-CHK-009)"
  let eff := (o.effects.flatMap Eff.vars).filter (!seen.contains ·) |>.map fun x => s!"{o.name}: effect uses {x}, not bound"
  let rep := o.report.filterMap fun s => match s with
    | .handle x => if ps.contains x then Option.none else some s!"{o.name}: reports the handle of {x}, not a parameter"
    | .prop x _ => if seen.contains x then Option.none else some s!"{o.name}: reports {x}, not bound"
    | .text _ => Option.none
  neg ++ eff ++ rep

/-- Names the back ends use in the same rules as description variables (`<s>`, `<w>`, ...), or generate
(`<x-h>`, `<y-q>`, `<k-…>`, `<new-N>`, `<rN>`, `<eN>`): a description variable must not be one of them.
Found on Tower of London, where a variable `s` became `<s>` and the operator was never proposed. -/
def reservedVars : List String := ["s", "w", "objs", "ds", "op", "pre", "pa", "task", "any-unachieved", "dr"]

def Var.badName (x : String) : Bool :=
  let cs := x.toList
  reservedVars.contains x || cs.contains '-' ||
  (match cs with
   | c :: ds => (c == 'r' || c == 'e') && !ds.isEmpty && ds.all Char.isDigit
   | [] => true)

def Atom.hasArith : Atom → Bool
  | .has _ _ _ r => r.isArith
  | .none as => as.any fun a => match a with | .has _ _ _ r => r.isArith | _ => false
  | _ => false

def Task.vars (t : Task) : List String :=
  t.ops.flatMap (fun o => o.params.map (·.1) ++ (o.pre ++ o.bind).flatMap Atom.vars ++ o.effects.flatMap Eff.vars ++
    (match o.stepCost with | some r => r.vars | none => [])) ++
  t.failures.flatMap (fun f => f.cond.atoms.flatMap Atom.vars) ++
  t.goal.atoms.flatMap Atom.vars ++ (match t.goal with | .all fa => [fa.var] | .ex _ => []) ++
  t.ops.flatMap (fun o => o.effects.flatMap fun e => e.eachAtoms.flatMap Atom.vars) ++
  t.derived.flatMap (fun d => d.vars ++ d.defn.flatMap Atom.vars) ++
  t.evalMarks.flatMap (fun m => m.cond.flatMap Atom.vars)

def Task.wellFormed (t : Task) : List String :=
  ((t.vars.filter Var.badName).eraseDups.map fun x => s!"variable {x}: a name the back ends reserve or generate") ++
  ((t.ops.flatMap fun o => (o.effects.flatMap Eff.eachAtoms).filter Atom.isNeg |>.map fun _ => s!"{o.name}: negation in an each condition (W-CHK-009)")) ++
  ((t.ops.flatMap fun o => (o.effects.filter Eff.nestedEach).map fun _ => s!"{o.name}: an each inside an each")) ++
  ((t.ops.flatMap fun o => o.effects.filterMap fun e => match e.relName with
      | some r => if (t.derived.map (·.name)).contains r then some s!"{o.name}: changes derived relation {r}" else Option.none
      | Option.none => Option.none)) ++
  ((t.ops.flatMap fun o => ((o.pre ++ o.bind).filter Atom.hasArith).map fun _ => s!"{o.name}: arithmetic in a condition")) ++
  ((t.ops.filter fun o => match o.stepCost with | some r => r.isArith | none => false).map fun o => s!"{o.name}: arithmetic in a step cost") ++
  ((t.failures.flatMap fun f => (f.cond.atoms.filter Atom.hasArith).map fun _ => s!"failure {f.name}: arithmetic in a condition")) ++
  ((t.goal.atoms.filter Atom.hasArith).map fun _ => "goal: arithmetic in a condition") ++
  t.ops.flatMap Op.check ++
  ((t.failures.flatMap fun f => (f.cond.atoms.filter Atom.isNeg).map fun _ => s!"failure {f.name}: negation (W-CHK-009)")) ++
  ((t.goal.atoms.filter Atom.isNeg).map fun _ => "goal: negation (W-CHK-009)") ++
  ((t.evalMarks.filter fun m => !(t.ops.map (·.name)).contains m.op).map fun m => s!"evaluation mark {m.name}: no operator {m.op}") ++
  ((t.evalMarks.filter fun m => m.cond.any Atom.isNeg).map fun m => s!"evaluation mark {m.name}: negation") ++
  ((t.evalMarks.filter fun m => m.cond.any Atom.hasArith).map fun m => s!"evaluation mark {m.name}: arithmetic in a condition") ++
  ((t.assumptions.filter (·.kind != .intent)).map fun a => s!"assumption {a.id} is open ({repr a.kind}): raise it with the user")

end WorldSpec
