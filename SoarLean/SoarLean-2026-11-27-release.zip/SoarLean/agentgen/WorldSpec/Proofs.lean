import WorldSpec.Check
import WorldSpec.SlotOrder
import WorldSpec.Tasks.Hanoi
import WorldSpec.Tasks.Fox
import WorldSpec.Tasks.KenKen
import WorldSpec.Tasks.MonkeyBananas
import WorldSpec.Tasks.VacuumWorld
import WorldSpec.Tasks.TowerOfLondon
import WorldSpec.Tasks.InstantInsanity
import WorldSpec.Tasks.BridgeAndTorch
import WorldSpec.Tasks.CherylsBirthday
import WorldSpec.Tasks.MuddyChildren
import WorldSpec.Tasks.GuardTour
import WorldSpec.Tasks.GuardPatrol
/-! The three Rosie descriptions are well formed (WorldSpec/Check.lean). -/
namespace WorldSpec.Tasks

theorem hanoi_wellFormed : hanoi.wellFormed = [] := by decide
theorem fox_wellFormed : fox.wellFormed = [] := by decide
theorem kenken_wellFormed : kenken.wellFormed = [] := by decide
theorem monkeyBananas_wellFormed : monkeyBananas.wellFormed = [] := by decide
theorem vacuumWorld_wellFormed : vacuumWorld.wellFormed = [] := by decide
theorem towerOfLondon_wellFormed : towerOfLondon.wellFormed = [] := by decide
theorem instantInsanity_wellFormed : instantInsanity.wellFormed = [] := by decide
theorem bridgeAndTorch_wellFormed : bridgeAndTorch.wellFormed = [] := by decide
theorem cherylsBirthday_wellFormed : cherylsBirthday.wellFormed = [] := by decide
theorem muddyChildren_wellFormed : muddyChildren.wellFormed = [] := by decide

end WorldSpec.Tasks

/-! Generated slot order (World-Conventions L21-001, WorldSpec/SlotOrder.lean): which descriptions have the slot
structure. KenKen (write a number on each empty location) and Instant Insanity (place each cube) have it; the others
do not, so their rules are unchanged. -/
namespace WorldSpec.Tasks

theorem kenken_slots : kenken.slots?.isSome = true := by decide
theorem instantInsanity_slots : instantInsanity.slots?.isSome = true := by decide
theorem hanoi_noSlots : hanoi.slots?.isNone = true := by decide
theorem fox_noSlots : fox.slots?.isNone = true := by decide
theorem monkeyBananas_noSlots : monkeyBananas.slots?.isNone = true := by decide
theorem vacuumWorld_noSlots : vacuumWorld.slots?.isNone = true := by decide
theorem towerOfLondon_noSlots : towerOfLondon.slots?.isNone = true := by decide
theorem bridgeAndTorch_noSlots : bridgeAndTorch.slots?.isNone = true := by decide
theorem cherylsBirthday_noSlots : cherylsBirthday.slots?.isNone = true := by decide
theorem muddyChildren_noSlots : muddyChildren.slots?.isNone = true := by decide
theorem guardTour_noSlots : guardTour.slots?.isNone = true := by decide
theorem guardPatrol_noSlots : guardPatrol.slots?.isNone = true := by decide

end WorldSpec.Tasks
