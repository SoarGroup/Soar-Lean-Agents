import WorldSpec.Types
import Std.Data.HashSet
/-!
# WorldSpec semantics

A state is a set of objects with properties and a set of relation tuples over handles. This module
evaluates conditions, applies operators, and builds the initial state from a world file. It is the
reference the generated agents are checked against: the example states of a dialog (init, fail,
final) and the plans the agents produce are evaluated here, without Soar.
-/
namespace WorldSpec

structure State where
  objs : List Obj
  rels : List (String × List String)
  deriving Repr, Inhabited

abbrev Binding := List (String × String)

def State.obj? (st : State) (h : String) : Option Obj := st.objs.find? (·.handle == h)

def Obj.prop? (o : Obj) (p : String) : Option Val :=
  if p == "type" then some (.sym o.type) else o.props.lookup p

def State.prop? (st : State) (h p : String) : Option Val := (st.obj? h).bind (·.prop? p)

def cmpVal : Cmp → Val → Val → Bool
  | .eq, a, b => a == b
  | .ne, a, b => a != b
  | .lt, .int a, .int b => a < b
  | .le, .int a, .int b => a ≤ b
  | .gt, .int a, .int b => a > b
  | .ge, .int a, .int b => a ≥ b
  | _, _, _ => false

/-- The bindings that extend `b` with `x` bound to some object (or `b`, if `x` is bound). -/
def cands (st : State) (x : String) (b : Binding) : List Binding :=
  match b.lookup x with
  | some _ => [b]
  | none => st.objs.map fun o => (x, o.handle) :: b

def argMatch (b : Binding) : List (Arg × String) → Option Binding
  | [] => some b
  | (.h h, v) :: rest => if h == v then argMatch b rest else none
  | (.var x, v) :: rest =>
    match b.lookup x with
    | some w => if w == v then argMatch b rest else none
    | none => argMatch ((x, v) :: b) rest

/-- Integer arithmetic on two right-side values (`plus`, `minus`, `times`); none if either is not an integer. -/
def intOp (a c : Option Val) (f : Int → Int → Int) (nonzero : Bool := false) : Option Val :=
  match a, c with
  | some (.int i), some (.int j) => if nonzero && j == 0 then none else some (.int (f i j))
  | _, _ => none

def combine (xs : List (Binding × Val)) (ys : Binding → List (Binding × Val)) (f : Int → Int → Int) (nonzero : Bool := false) : List (Binding × Val) :=
  xs.flatMap fun (b1, v1) => (ys b1).filterMap fun (b2, v2) => (intOp (some v1) (some v2) f nonzero).map (b2, ·)

def rhsVals (st : State) (b : Binding) : Rhs → List (Binding × Val)
  | .val v => [(b, v)]
  | .prop y q => (cands st y b).filterMap fun b' =>
      ((b'.lookup y).bind (st.prop? · q)).map (b', ·)
  | .plus r1 r2 => combine (rhsVals st b r1) (fun b1 => rhsVals st b1 r2) (· + ·)
  | .minus r1 r2 => combine (rhsVals st b r1) (fun b1 => rhsVals st b1 r2) (· - ·)
  | .times r1 r2 => combine (rhsVals st b r1) (fun b1 => rhsVals st b1 r2) (· * ·)
  | .quot r1 r2 => combine (rhsVals st b r1) (fun b1 => rhsVals st b1 r2) Int.tdiv true
  | .rem r1 r2 => combine (rhsVals st b r1) (fun b1 => rhsVals st b1 r2) Int.tmod true

/-- The value of an effect's right side under a complete binding, in the state before the action. -/
def rhsVal (pre : State) (b : Binding) : Rhs → Option Val
  | .val v => some v
  | .prop y q => (b.lookup y).bind (pre.prop? · q)
  | .plus r1 r2 => intOp (rhsVal pre b r1) (rhsVal pre b r2) (· + ·)
  | .minus r1 r2 => intOp (rhsVal pre b r1) (rhsVal pre b r2) (· - ·)
  | .times r1 r2 => intOp (rhsVal pre b r1) (rhsVal pre b r2) (· * ·)
  | .quot r1 r2 => intOp (rhsVal pre b r1) (rhsVal pre b r2) Int.tdiv true
  | .rem r1 r2 => intOp (rhsVal pre b r1) (rhsVal pre b r2) Int.tmod true

mutual
def step (st : State) (b : Binding) : Atom → List Binding
  | .obj x t => (cands st x b).filter fun b' =>
      match t, b'.lookup x with
      | none, some h => (st.obj? h).isSome
      | some ty, some h => (st.obj? h).any (·.type == ty)
      | _, none => false
  | .has x p c r => (cands st x b).flatMap fun b' =>
      (rhsVals st b' r).filterMap fun (b'', v) =>
        match (b''.lookup x).bind (st.prop? · p) with
        | some u => if cmpVal c u v then some b'' else none
        | none => none
  | .rel r args => (st.rels.filter (fun (n, t) => n == r && t.length == args.length)).filterMap
      fun (_, t) => argMatch b (args.zip t)
  | .distinct x y => (cands st x b).flatMap fun b' => (cands st y b').filter fun b'' =>
      b''.lookup x != b''.lookup y
  | .lacks x p => (cands st x b).filter fun b' =>
      ((b'.lookup x).bind (st.prop? · p)).isNone
  | .none as => if (solve st b as).isEmpty then [b] else []

def solve (st : State) (b : Binding) : List Atom → List Binding
  | [] => [b]
  | a :: rest => (step st b a).flatMap fun b' => solve st b' rest
end

def holdsIn (st : State) (b : Binding) (as : List Atom) : Bool := !(solve st b as).isEmpty

def Cond.holds (st : State) : Cond → Bool
  | .ex as => holdsIn st [] as
  | .all fa => (solve st [] fa.outer).any fun b =>
      (st.objs.filter (·.type == fa.type)).all fun o =>
        let b' := (fa.var, o.handle) :: b
        !(holdsIn st b' fa.filter) || holdsIn st b' fa.body

/-- The state with the derived sums added (W-CHK: derived attributes, not copied in look-ahead). -/
def withSums (sums : List SumDef) (st : State) : State :=
  { st with objs := st.objs.map fun o => sums.foldl (fun o s =>
      if o.type != s.ownerType then o else
      let ms := st.rels.filterMap fun (n, t) => if n == s.rel && t.head? == some o.handle then t[1]? else none
      let vs := ms.map fun m => st.prop? m s.prop
      if ms.isEmpty || vs.any (·.isNone) then o else
      let total := vs.foldl (fun acc v => match v with | some (.int i) => acc + i | _ => acc) 0
      { o with props := o.props ++ [(s.attr, .int total)] }) o }

/-- The state with the derived relations added, in order (a later one may use an earlier one). -/
def withDerived (ds : List Derived) (st : State) : State :=
  ds.foldl (fun st d =>
    let tuples := ((solve st [] d.defn).filterMap fun b => d.vars.mapM (fun x => b.lookup x)).eraseDups
    { st with rels := st.rels ++ tuples.map (d.name, ·) }) st

def Task.view (t : Task) (st : State) : State := withDerived t.derived (withSums t.sums st)

def Task.failed (t : Task) (st : State) : List String :=
  (t.failures.filter fun f => f.cond.holds (t.view st)).map (·.name)

def Task.goalMet (t : Task) (st : State) : Bool := t.goal.holds (t.view st)

/-- The objects that meet a maintained relation's definition (the task object, which the agent adds,
is never a member). -/
def Maintained.members (m : Maintained) (st : State) : List String :=
  (st.objs.filter fun o => o.type != "task" && holdsIn st [(m.var, o.handle)] m.defn).map (·.handle)

/-- Differences between the maintained relations held in the state and their definitions. -/
def Task.maintainedErrors (t : Task) (st : State) : List String :=
  t.maintained.flatMap fun m =>
    let held := st.rels.filterMap fun (n, a) => if n == m.name then a.head? else none
    let want := m.members st
    (want.filter (!held.contains ·)).map (s!"{m.name} missing for " ++ ·) ++
    (held.filter (!want.contains ·)).map (s!"{m.name} held but false for " ++ ·)

def argH (b : Binding) : Arg → Except String String
  | .h h => .ok h
  | .var x => match b.lookup x with
    | some h => .ok h
    | none => .error s!"unbound variable {x}"

def setProp (st : State) (h p : String) (v : Val) : State :=
  { st with objs := st.objs.map fun o =>
      if o.handle != h then o else { o with props := (o.props.filter (·.1 != p)) ++ [(p, v)] } }

def removeFirst (r : String) (t : List String) : List (String × List String) → Option (List (String × List String))
  | [] => none
  | x :: xs => if x.1 == r && x.2 == t then some xs else (removeFirst r t xs).map (x :: ·)

/-- Effects are evaluated against the state before the action (Soar fires the right-hand side at once). -/
def applyEff (pre : State) (b : Binding) (st : State) : Eff → Except String State
  | .set x p r => do
    let h ← argH b (.var x)
    let some v := rhsVal pre b r | .error s!"no value for {x}.{p}"
    if (pre.prop? h p).isSome then .error s!"set: {h} already has {p}" else
    pure (setProp st h p v)
  | .update x p r => do
    let h ← argH b (.var x)
    let some v := rhsVal pre b r | .error s!"no value for {x}.{p}"
    if (pre.prop? h p).isNone then .error s!"update: {h} has no {p}" else
    pure (setProp st h p v)
  | .add r args => do
    let hs ← args.mapM (argH b)
    pure { st with rels := st.rels ++ [(r, hs)] }
  | .del r args => do
    let hs ← args.mapM (argH b)
    match removeFirst r hs st.rels with
    | some rs => pure { st with rels := rs }
    | none => .error s!"del: no {r}{hs}"
  | .change r args pos to => do
    let hs ← args.mapM (argH b)
    let th ← argH b to
    match removeFirst r hs st.rels with
    | some rs => pure { st with rels := rs ++ [(r, hs.set (pos - 1) th)] }
    | none => .error s!"change: no {r}{hs}"
  | .each as e => (solve pre b as).foldlM (fun st b' => applyEff pre b' st e) st

/-- The binding of a legal application of `op` to these argument handles, if any. -/
def Task.legal (t : Task) (st : State) (op : Op) (args : List String) : Option Binding :=
  if args.length != op.params.length then none else
  let b0 : Binding := (op.params.map (·.1)).zip args
  let typed := (op.params.zip args).all fun ((_, ty), h) =>
    match st.obj? h, ty with
    | some o, some ty => o.type == ty
    | some _, none => true
    | none, _ => false
  if !typed then none else (solve (t.view st) b0 op.pre).head?

def Task.apply (t : Task) (st : State) (opName : String) (args : List String) : Except String State := do
  let some op := t.ops.find? (·.name == opName) | .error s!"unknown operator {opName}"
  let some b := t.legal st op args | .error s!"{opName} {args} is not legal"
  let some b' := (solve (t.view st) b op.bind).head? | .error s!"{opName} {args}: bind has no match"
  op.effects.foldlM (applyEff (t.view st) b') st

/-- All legal applications in a state (operator name and argument handles). -/
def Task.legalMoves (t : Task) (st : State) : List (String × List String) :=
  t.ops.flatMap fun op =>
    let combos := op.params.foldr (fun _ acc => st.objs.flatMap fun o => acc.map (o.handle :: ·)) [[]]
    (combos.filter fun args => (t.legal st op args).isSome).map (op.name, ·)

/-- The task's initial state for a world file. -/
def Task.initial (t : Task) (wf : WorldFile) : State :=
  let h := fun (i : Nat) => match wf.objs.find? (·.id == i) with
    | some o => t.world.handle o
    | none => s!"unknown-{i}"
  let objs := wf.objs.map fun o =>
    { handle := t.world.handle o,
      type := match o.attrs.lookup "category" with | some (.sym c) => c | _ => "object",
      props := o.attrs.filter (·.1 != "category") : Obj }
  let objs := objs ++ [{ handle := "task", type := "task" }] ++ t.world.extra wf
  let rels := t.world.rels.flatMap fun r =>
    ((wf.rels.lookup r).getD []).map fun tup => (r, tup.map h)
  let extra := (t.world.extraRels wf).map fun (r, hs) => (r, hs)
  let st0 : State := { objs, rels := rels ++ extra }
  let maint := t.maintained.flatMap fun m => (m.members st0).map fun x => (m.name, [x])
  { objs, rels := rels ++ maint ++ extra }

end WorldSpec

namespace WorldSpec

/-- A canonical key for a state (sorted properties and relation tuples), for duplicate detection. -/
def State.key (st : State) : String :=
  let os := (st.objs.map fun o => o.handle ++ ":" ++ ",".intercalate
    ((o.props.map fun (p, v) => p ++ "=" ++ v.toSoar).mergeSort (· ≤ ·))).mergeSort (· ≤ ·)
  let rs := (st.rels.map fun (r, hs) => r ++ "(" ++ ",".intercalate hs ++ ")").mergeSort (· ≤ ·)
  ";".intercalate os ++ "|" ++ ";".intercalate rs

/-- Breadth-first search of the reachable states (losing states are not expanded), up to `limit`
states. Returns the length of a shortest plan to the goal, if found, the number of states seen and
every maintained-relation or effect error met on the way. -/
def Task.explore (t : Task) (s0 : State) (limit : Nat) : Option Nat × Nat × List String := Id.run do
  let mut seen : Std.HashSet String := {}
  let mut frontier : List State := [s0]
  let mut errs : List String := []
  let mut depth := 0
  seen := seen.insert s0.key
  if t.goalMet s0 && (t.failed s0).isEmpty then return (some 0, 1, [])
  for _ in [0:limit] do
    if frontier.isEmpty || seen.size ≥ limit then break
    depth := depth + 1
    let mut next : List State := []
    for st in frontier do
      for (op, args) in t.legalMoves st do
        match t.apply st op args with
        | .error e => errs := errs ++ [s!"{op} {args}: {e}"]
        | .ok st' =>
          let me := t.maintainedErrors st'
          if !me.isEmpty then errs := errs ++ [s!"after {op} {args}: {me}"]
          if !seen.contains st'.key then
            seen := seen.insert st'.key
            if (t.failed st').isEmpty then
              if t.goalMet st' then return (some depth, seen.size, errs)
              next := next ++ [st']
    frontier := next
  return (none, seen.size, errs)

end WorldSpec
