import WorldSpec.Sem
import WorldSpec.Check
/-!
# Generated search control: fill the slots in a fixed order (World-Conventions L21-001)

Some tasks are a set of slots, each filled once, in any order: KenKen writes a number on each empty location,
Instant Insanity places each cube in some orientation. When the description has that structure, every order of the
fills reaches the same states, so look-ahead over all orders repeats the same work up to k! times. This module
recognizes the structure from the description alone (never from the task's name) and has the generators propose the
fill operators only for the first unfilled slot, in the order of the initial world. Nothing here is stated in the
English: it is search control the generator derives, like `repeatControl` (but generated, not written), and it
changes which orders are searched, not which solutions exist.

The structure (all checked on the description):
1. Slots. A maintained relation `M(x)` whose definition is `[obj x T, lacks x p]` (filled by the property `p`) or
   `[obj x T, none [rel R [x, …]]]` (filled by a tuple of `R` whose first argument is `x`).
2. Fill operators. Every operator has a parameter `x` of type `T` with `M(x)` among its preconditions, no binding
   condition, and exactly two effects: the fill (`set x p …`, or `add R [x, …]`) and `del M [x]`.
3. Preconditions that read no other slot. Apart from `M(x)`, no precondition (or step cost, or the fill's right side)
   tests `p`, `R`, `M`, a derived relation or a sum. So a fill stays legal whatever the other slots hold, and an
   order stated in the English (a test that the previous slot is filled) makes the task fail this check and keeps
   its own order.
4. Losing conditions that stay true. Every losing condition is existential (`.ex`) and tests neither `M` nor a derived
   relation. Conditions are positive (W-CHK-009) and fills are never undone (2), so a state that loses still loses
   after more fills: a partial assignment of a winning state never loses.
5. A goal that needs every slot. The goal is universal over `T`, without outer atoms or filter, its body tests the
   fill of the variable, and it tests neither `M` nor a derived relation. So every goal state has every slot filled.
6. No phases, no termination condition, `slotOrder` not turned off.

Why the order loses nothing: by 5 a goal state has every slot filled; by 2 its fills can be made in the fixed order;
by 3 each is legal when made; by 4 no state on the way loses. The checks are syntactic and decided by `slots?`; the
argument above is not (yet) a Lean theorem over the semantics.

Generation (paths A and B write the same): a static chain `<M>-next(x, y)` over the slots unfilled in the initial
world, in the order of its objects; a relation `<M>-first(x)` held by the first of them; each fill operator also
tests `<M>-first(x)`, and its effects move it along the chain (`del <M>-first [x]`, and for the successor `y`,
`add <M>-first [y]`). Every test is positive (L11-003, W-CHK-009).
-/
namespace WorldSpec

/-- How a slot is filled: by a property of the slot, or by a relation tuple whose first argument is the slot. -/
inductive Fill where
  | prop : String → Fill
  | rel  : String → Fill
  deriving Repr, Inhabited, BEq

/-- A recognized slot structure. -/
structure Slots where
  marker : String     -- the maintained relation that holds of an unfilled slot
  type   : String
  fill   : Fill
  /-- For each operator, in order: the parameter that names the slot. -/
  slotParams : List String
  deriving Repr, Inhabited

def Slots.next (s : Slots) : String := s.marker ++ "-next"
def Slots.first (s : Slots) : String := s.marker ++ "-first"

def Maintained.slotFill? (m : Maintained) : Option (String × Fill) :=
  match m.defn with
  | [.obj x (some ty), .lacks y p] => if x == m.var && y == x then some (ty, .prop p) else none
  | [.obj x (some ty), .none [.rel r (.var y :: _)]] => if x == m.var && y == x then some (ty, .rel r) else none
  | _ => none

def Rhs.props : Rhs → List String
  | .val _ => []
  | .prop _ q => [q]
  | .plus a b | .minus a b | .times a b | .quot a b | .rem a b => a.props ++ b.props

/-- The property names and relation names a slot-reading test would use. -/
structure Reads where
  props : List String   -- the fill property and every sum attribute
  rels  : List String   -- the marker, the fill relation and every derived relation

mutual
def Atom.reads (r : Reads) : Atom → Bool
  | .has _ p _ rhs => r.props.contains p || rhs.props.any r.props.contains
  | .rel n _ => r.rels.contains n
  | .none as => Atom.readsAny r as
  | _ => false

def Atom.readsAny (r : Reads) : List Atom → Bool
  | [] => false
  | a :: as => Atom.reads r a || Atom.readsAny r as
end

def Task.reads (t : Task) (marker : String) (f : Fill) : Reads :=
  { props := (match f with | .prop p => [p] | .rel _ => []) ++ t.sums.map (·.attr),
    rels := [marker] ++ (match f with | .rel r => [r] | .prop _ => []) ++ t.derived.map (·.name) }

/-- `rel r [x]` for the variable `x` (written without `BEq Atom`, so `decide` can evaluate it). -/
def Atom.isRel1 (r x : String) : Atom → Bool
  | .rel n [.var y] => n == r && y == x
  | _ => false

/-- `del r [x]` for the variable `x`. -/
def Eff.isDel1 (r x : String) : Eff → Bool
  | .del n [.var y] => n == r && y == x
  | _ => false

/-- The fill effect of the slot variable `x`. -/
def Eff.isFill (f : Fill) (rd : Reads) (x : String) : Eff → Bool
  | .set y p rhs => (match f with | .prop q => q == p | _ => false) && y == x && !(rhs.props.any rd.props.contains)
  | .add r (.var y :: _) => (match f with | .rel q => q == r | _ => false) && y == x
  | _ => false

/-- The slot parameter of a fill operator (checks 2 and 3), if `o` is one. -/
def Op.slotParam? (t : Task) (marker type : String) (f : Fill) (o : Op) : Option String := do
  let rd := t.reads marker f
  let x ← (o.params.find? fun (x, ty) => ty == some type && o.pre.any (Atom.isRel1 marker x)).map (·.1)
  if !o.bind.isEmpty then none
  match o.effects with
  | [e1, e2] =>
    if !((e1.isFill f rd x && e2.isDel1 marker x) || (e2.isFill f rd x && e1.isDel1 marker x)) then none
  | _ => none
  if (o.pre.eraseP (Atom.isRel1 marker x)).any (Atom.reads rd) then none
  if (match o.stepCost with | some r => r.props.any rd.props.contains | none => false) then none
  pure x

def Fill.testedOn (f : Fill) (v : String) : Atom → Bool
  | .has y p _ _ => (match f with | .prop q => q == p | _ => false) && y == v
  | .rel r (.var y :: _) => (match f with | .rel q => q == r | _ => false) && y == v
  | _ => false

/-- Every relation name the description uses (so the generated names can be checked against them). -/
def Task.allRelNames (t : Task) : List String :=
  let fromAtoms := fun (as : List Atom) => as.filterMap fun a => match a with | .rel r _ => some r | _ => none
  t.maintained.map (·.name) ++ t.derived.map (·.name) ++ t.world.rels ++
  t.ops.flatMap (fun o => fromAtoms (o.pre ++ o.bind) ++ o.effects.filterMap Eff.relName) ++
  t.failures.flatMap (fun f => fromAtoms f.cond.atoms) ++ fromAtoms t.goal.atoms

/-- Checks 1 to 6: the slot structure of the description, if it has one. -/
def Task.slots? (t : Task) : Option Slots :=
  if !t.slotOrder || !t.phases.isEmpty || t.termination.isSome || t.ops.isEmpty then none else
  t.maintained.findSome? fun m => do
    let (type, f) ← m.slotFill?
    let ps ← t.ops.mapM (Op.slotParam? t m.name type f)
    let bad := fun (a : Atom) => Atom.reads { props := [], rels := [m.name] ++ t.derived.map (·.name) } a
    if !(t.failures.all fun fl => match fl.cond with | .ex as => !as.any bad | .all _ => false) then none
    match t.goal with
    | .all fa =>
      if fa.type != type || !fa.outer.isEmpty || !fa.filter.isEmpty || !fa.body.any (f.testedOn fa.var) ||
         fa.body.any bad then none
    | .ex _ => none
    let s : Slots := { marker := m.name, type, fill := f, slotParams := ps }
    if t.allRelNames.contains s.next || t.allRelNames.contains s.first then none
    pure s

/-- A variable name for the successor slot that the operator does not use. -/
def freshVar (used : List String) : String :=
  let cands := ["nextslot"] ++ (List.range 50).map (fun k => s!"nextslot{k + 2}")
  (cands.find? (!used.contains ·)).getD "nextslotz"

def Op.vars (o : Op) : List String :=
  o.params.map (·.1) ++ (o.pre ++ o.bind).flatMap Atom.vars ++ o.effects.flatMap Eff.vars ++
  o.effects.flatMap (fun e => e.eachAtoms.flatMap Atom.vars)

/-- The fill operator with the order test and the effects that move the turn along the chain. -/
def Op.withSlotOrder (s : Slots) (x : String) (o : Op) : Op :=
  let y := freshVar o.vars
  let pre := o.pre.foldr (fun a acc => if a.isRel1 s.marker x then a :: .rel s.first [.var x] :: acc else a :: acc) []
  { o with pre,
           effects := o.effects ++ [.del s.first [.var x],
                                    .each [.rel s.next [.var x, .var y]] (.add s.first [.var y])] }

/-- The comment the rules carry (paths A and B write it after the assumption ledger). -/
def Slots.note (s : Slots) (t : Task) : String :=
  let ops := ", ".intercalate (t.ops.map (·.name))
  "##\n## Search control generated from the structure of the description (World-Conventions L21-001; not stated in the English):\n" ++
  s!"##   each {s.type} gets exactly one {ops}, and these commute, so {ops} is proposed only for the first {s.type} still without one,\n" ++
  s!"##   in the order of the initial world ({s.first}, moved along {s.next}).\n"

/-- The task and initial state with the slot order applied, and the comment; unchanged when not recognized. -/
def Task.withSlotOrder (t : Task) (st : State) : Task × State × String :=
  match t.slots? with
  | none => (t, st, "")
  | some s =>
    let slots := (st.objs.filter fun o => o.type == s.type && st.rels.contains (s.marker, [o.handle])).map (·.handle)
    let chain := (slots.zip slots.tail).map fun (a, b) => (s.next, [a, b])
    let first := (slots.head?.map fun h => [(s.first, [h])]).getD []
    let ops := (t.ops.zip s.slotParams).map fun (o, x) => o.withSlotOrder s x
    ({ t with ops }, { st with rels := st.rels ++ chain ++ first }, s.note t)

end WorldSpec
