"""Path B: world-convention Soar rules from a WorldSpec description exported by Lean (rosiegen json).

usage: python3 spec_backend.py DESC.json OUT.soar

The description is typed and checked in Lean (agentgen/WorldSpec); its initial world arrives evaluated
(objects and relation tuples, maintained relations included). This back end follows the emission scheme
written down in agentgen/WorldSpec/Compile.lean (path A), so the two outputs can be compared byte for byte:

* an object variable x is <x>, declared by (<objs> ^object <x>) when it first occurs outside a relation;
  a constant handle h is <k-h>, declared with (<k-h> ^object-handle h);
* has x p c v: (<x> ^p c v); a property y.q on the right is bound first as (<y> ^q <y-q>);
* rel r [a1 .. an]: (<w> ^r <rK>) and (<rK> ^argument1 a1 .. ^argumentn an); a tuple already tested in the
  rule reuses its variable;
* distinct x y: (<objs> ^object { <> <x> <y> });
* lacks and none are negations: refused in compiled conditions (W-CHK-009);
* a universal goal is expanded over the objects of its type in the initial world;
* object-handle tests on variables carry $ (W-CHK-011)."""
import re
import json, sys

LIB_COPIED = ('on', 'above', 'in')
CMP = {'eq': '', 'ne': '<> ', 'lt': '< ', 'le': '<= ', 'gt': '> ', 'ge': '>= '}


def val(x):
    if 'sym' in x: return x['sym']
    if 'int' in x: return str(x['int'])
    return 'true' if x['bool'] else 'false'


def v(x): return f'<{x}>'
ARITH_KEYS = ('plus', 'minus', 'times', 'quot', 'rem')
def is_arith(r): return any(k in r for k in ARITH_KEYS)
def kv(h): return f'<k-{h}>'


class CS:
    """The state of compiling one rule's conditions."""
    def __init__(s):
        s.lines, s.objs, s.consts, s.vals, s.rels, s.n = [], [], [], [], [], 0

    def emit(s, l): s.lines.append(l)

    def fresh(s, pfx):
        s.n += 1
        return f'<{pfx}{s.n}>'

    def decl_obj(s, x):
        if x not in s.objs:
            s.emit(f'   (<objs> ^object {v(x)})')
            s.objs.append(x)

    def mark_bound(s, x):
        if x not in s.objs: s.objs.append(x)

    def arg(s, a):
        if 'var' in a: return v(a['var'])
        h = a['h']
        if h not in s.consts:
            s.emit(f'   (<objs> ^object {kv(h)})')
            s.emit(f'   ({kv(h)} ^object-handle {h})')
            s.consts.append(h)
        return kv(h)

    def val_var(s, y, q):
        name = f'<{y}-{q}>'
        if name not in s.vals:
            s.decl_obj(y)
            s.emit(f'   ({v(y)} ^{q} {name})')
            s.vals.append(name)
        return name

    def rhs(s, r):
        if 'val' in r: return val(r['val'])
        for k, op in (('plus', '+'), ('minus', '-'), ('times', '*'), ('quot', 'div'), ('rem', 'mod')):
            if k in r:
                a, b = (s.rhs(x) for x in r[k])
                return f'({op} {a} {b})'
        y, q = r['prop']
        return s.val_var(y, q)

    def rel(s, r, args, pfx):
        ts = [s.arg(a) for a in args]
        for (n, a, rv) in s.rels:
            if n == r and a == ts: return rv
        rv = s.fresh(pfx)
        s.emit(f'   (<w> ^{r} {rv})')
        s.emit(f'   ({rv} ' + ' '.join(f'^argument{k} {t}' for k, t in enumerate(ts, 1)) + ')')
        for a in args:
            if 'var' in a: s.mark_bound(a['var'])
        s.rels.append((r, ts, rv))
        return rv

    def atom(s, a):
        if 'obj' in a:
            s.decl_obj(a['obj'])
            if a['type'] is not None: s.emit(f"   ({v(a['obj'])} ^type {a['type']})")
        elif 'has' in a:
            if is_arith(a['rhs']): raise ValueError(f"cannot compile arithmetic in a condition ({a['has']}.{a['prop']})")
            rt = s.rhs(a['rhs'])
            s.decl_obj(a['has'])
            s.emit(f"   ({v(a['has'])} ^{a['prop']} {CMP[a['cmp']]}{rt})")
        elif 'rel' in a:
            s.rel(a['rel'], a['args'], 'r')
        elif 'distinct' in a:
            x, y = a['distinct']
            s.decl_obj(x)
            s.emit(f'   (<objs> ^object {{ <> {v(x)} {v(y)} }})')
            if y not in s.objs: s.objs.append(y)
        elif 'lacks' in a:
            # only in a derived relation's definition (checked by Task.wellFormed in Lean, W-CHK-009)
            x, p = a['lacks']
            s.decl_obj(x)
            s.emit(f'   -({v(x)} ^{p})')
        elif 'none' in a:
            # a negated conjunction: inner conditions inside -{ ... }; names bound inside stay inside
            saved = (list(s.lines), list(s.objs), list(s.consts), list(s.vals), list(s.rels))
            s.lines = []
            for b in a['none']: s.atom(b)
            inner = s.lines
            s.lines, s.objs, s.consts, s.vals, s.rels = saved
            s.emit('  -{' + '\n'.join(l[1:] for l in inner) + '}')
        else:
            raise ValueError(f'unknown atom {a}')


def sp(name, lhs, rhs, comment=''):
    c = f'\n## {comment}\n' if comment else ''
    return c + f'sp {{{name}\n' + '\n'.join(lhs) + '\n-->\n' + '\n'.join(rhs) + '\n}\n'


def stmt_note(ns):
    if not ns: return ''
    return ' (statement' + ('s ' if len(ns) > 1 else ' ') + ', '.join(map(str, ns)) + ')'


def header(d):
    st = [f'##  {k}. {s}' for k, s in d['statements']]
    asm = [f"##   {a['id']}: {a['text']}" for a in d['assumptions']]
    return (f"## {d['title']}: generated by spec_backend.py (WorldSpec, path B: Lean description, Python rules) from the instructor statements.\n##\n"
            '## Instructor statements used (numbers as in english-input.txt):\n' + '\n'.join(st) +
            '\n##\n## Assumption ledger:\n' + '\n'.join(asm) + '\n')


def static_info(d):
    """Static objects and shared relations (World-Conventions L7-028, candidate 26 Nov 2026). An object is static when no
    operator sets or updates a property of an object of its type and no sum is written on its type: the look-ahead shares it
    instead of copying it (^static true on the object). A relation is shared when no operator adds, deletes or changes it,
    it is not maintained or derived, and every argument in the initial world is a static object: the look-ahead world gets
    the same relation identifier (^share-relation on the problem space) instead of a copy."""
    if not d.get('staticSharing', True): return set(), []
    types = {o['handle']: o['type'] for o in d['objects']}
    changed = set(s_['ownerType'] for s_ in d['sums']) | {'task'}   # goal-met and the phase marks are elaborated on the task object
    def var_types(atoms, params):
        vt = dict(params)
        for a in atoms:
            if 'obj' in a and a.get('type'): vt[a['obj']] = a['type']
        return vt
    for o in d['ops']:
        vt = var_types(o['pre'] + o['bind'], [tuple(p) for p in o['params']])
        for e in o['effects']:
            each = e.get('each', [])
            ee = e['eff'] if 'each' in e else e
            x = ee.get('set') or ee.get('update')
            if x is None: continue
            t = var_types(each, list(vt.items())).get(x)
            if t is None: return set(), []          # an untyped variable: anything may change
            changed.add(t)
    static = {h for h, t in types.items() if t not in changed}
    touched = set()
    for o in d['ops']:
        for e in o['effects']:
            ee = e['eff'] if 'each' in e else e
            for k in ('add', 'del', 'change'):
                if k in ee: touched.add(ee[k])
    touched |= {m['name'] for m in d['maintained']} | {x['name'] for x in d.get('derived', [])}
    shared = []
    for r, hs in d['relations']:
        if r in touched or r in LIB_COPIED or r in shared: continue
        if all(all(h in static for h in hs2) for r2, hs2 in d['relations'] if r2 == r): shared.append(r)
    return static, shared


FIXED_MIN = 3   # properties a type must have under ^fixed (World-Conventions L7-022, measured 26 Nov 2026)


def fixed_info(d):
    """Fixed properties (World-Conventions L7-017 to L7-022, 26 Nov 2026; Compile.lean Task.fixedProps): with look-ahead
    (some operator not monotonic), an object type that has a property some operator changes, and at least FIXED_MIN
    properties no operator sets or updates, keeps those under a ^fixed substructure, which a look-ahead copy shares
    instead of copying each one. A property name is fixed on every type that has it or on none (rules test it by name).
    Variables are typed as in static_info; an operator that sets a property of an untyped variable makes nothing fixed.
    Returns the fixed property names, in order of first appearance."""
    if not d.get('staticSharing', True) or all(o.get('monotonic') for o in d['ops']): return []
    props = {}
    for o in d['objects']:
        ps = props.setdefault(o['type'], [])
        for pn, _ in o['props']:
            if pn not in ps: ps.append(pn)
    written = {'task': set()}
    for s_ in d['sums']: written.setdefault(s_['ownerType'], set()).add(s_['attr'])
    def var_types(atoms, params):
        vt = dict(params)
        for a in atoms:
            if 'obj' in a and a.get('type'): vt[a['obj']] = a['type']
        return vt
    for o in d['ops']:
        vt = var_types(o['pre'] + o['bind'], [tuple(p) for p in o['params']])
        for e in o['effects']:
            ee = e['eff'] if 'each' in e else e
            x = ee.get('set') or ee.get('update')
            if x is None: continue
            t = var_types(e.get('each', []), list(vt.items())).get(x)
            if t is None: return []
            written.setdefault(t, set()).add(ee['prop'])
    ok = lambda t: t in written and t != 'task'
    names = []
    for t, ps in props.items():
        for p in ps:
            if ok(t) and p not in written[t] and p not in names: names.append(p)
    while True:
        keep = [p for p in names if all(ok(t) and p not in written[t] for t, ps in props.items() if p in ps)]
        keep = [p for p in keep if all(len([q for q in ps if q in keep]) >= FIXED_MIN for t, ps in props.items() if p in ps)]
        if keep == names: return names
        names = keep


def fixed_lines(text, names):
    """Property tests of fixed properties become ^fixed.<p> (one-attribute condition lines, as WorldSpec writes them)."""
    if not names: return text
    out = []
    for line in text.split('\n'):
        m = re.match(r'^(\s*-?\(<[\w-]+> )\^([\w-]+)( |\))', line)
        if m and m.group(2) in names and '^object-handle' not in line and not m.group(1).rstrip().endswith('-fx>'):
            line = m.group(1) + '^fixed.' + line[len(m.group(1)) + 1:]
        out.append(line)
    return '\n'.join(out)


def obj_line(o, static=(), fixed=()):
    fx = [(p, x) for p, x in o['props'] if p in fixed]
    props = [f"^type {o['type']}"] + [f'^{p} {val(x)}' for p, x in o['props'] if p not in fixed] + \
            ([f"^fixed {kv(o['handle'])[:-1]}-fx>"] if fx else []) + (['^static true'] if o['handle'] in static else [])
    line = f"   ({kv(o['handle'])} ^object-handle {o['handle']} ^anchored true {' '.join(props)})"
    if fx: line += f"\n   ({kv(o['handle'])[:-1]}-fx> " + ' '.join(f'^{p} {val(x)}' for p, x in fx) + ')'
    return line


def desired_block(var, pre, attr):
    """One desireds structure: a single desired, ^<attr> true on the task object (Compile.lean desiredBlock)."""
    return f'   ({var} ^desired-count 1 ^desired <{pre}>)\n   (<{pre}> ^object <{pre}-o>)\n   (<{pre}-o> ^object-handle task ^{attr} true)\n'


def desireds_lines(d):
    """The initial desireds (World-Conventions L8-026 to L8-029; Compile.lean desiredsLines)."""
    phases = d.get('phases') or []
    if not phases: return desired_block('<ds>', 'd1', 'goal-met')
    names = ['<ds>' if k == 0 else f'<ph{k + 1}>' for k in range(len(phases))]
    ls_ = d.get('loopStart')
    out = ''
    for k, (p, var) in enumerate(zip(phases, names)):
        nxt = names[k + 1] if k + 1 < len(names) else (names[ls_] if ls_ is not None and ls_ < len(names) else None)
        out += desired_block(var, f'p{k + 1}d1', p['name'] + '-met') + (f'   ({var} ^next-desireds {nxt})\n' if nxt else '')
    if ls_ is not None and ls_ < len(names): out += f'   ({names[ls_]} ^loop-start true)\n'
    if d.get('termination'):
        out += '   (<s> ^termination-desireds <tds>)\n' + desired_block('<tds>', 'td1', d['termination']['name'] + '-met')
    if d.get('repeatCount') is not None: out += f"   (<s> ^repeat-count {d['repeatCount']})\n"
    return out


def init_rules(d):
    n = d['name']
    objs = ' '.join(kv(o['handle']) for o in d['objects'])
    rels = []
    for k, (r, hs) in enumerate(d['relations'], 1):
        rels.append(f'   (<w> ^{r} <rel-{k}>)')
        rels.append(f'   (<rel-{k}> ' + ' '.join(f'^argument{i} {kv(h)}' for i, h in enumerate(hs, 1)) + ')')
    return (f'''
sp {{{n}*propose*initialize-{n}
   (state <s> ^superstate nil ^world <w> -^name)
-->
   (<s> ^operator <o> + >)
   (<o> ^name initialize-{n} ^task-operator false)
}}

sp {{{n}*apply*initialize-{n}
   (state <s> ^operator.name initialize-{n} ^world <w>)
   (<w> ^objects <objs>)
-->
   (<s> ^name {n} ^desireds <ds>)
   (<objs> ^object {objs})
''' + '\n'.join(obj_line(o, static_info(d)[0], fixed_info(d)) for o in d['objects']) + '\n' + desireds_lines(d) + '\n'.join(rels) + f'''
   (log 1 (crlf) |Initialize {n}.|)
}}
''')


def rel_names(d):
    eff = [e['add'] if 'add' in e else e['eff']['add'] for o in d['ops'] for e in o['effects']
           if 'add' in e or ('each' in e and 'add' in e['eff'])]   # in operator and effect order, as Compile.lean
    out = []
    for r in [r for r, _ in d['relations']] + [m['name'] for m in d['maintained']] + eff:
        if r not in out and r not in LIB_COPIED: out.append(r)
    return out


def match_hints(d):
    """Matching hints (World-Conventions L3-095, L11-009), as Compile.lean matchHints: object count and, for each
    relation, its number of tuples in the initial world (at least 2)."""
    eff = [e['add'] if 'add' in e else e['eff']['add'] for o in d['ops'] for e in o['effects']
           if 'add' in e or ('each' in e and 'add' in e['eff'])]
    names = []
    for r in [r for r, _ in d['relations']] + [m['name'] for m in d['maintained']] + eff:
        if r not in names: names.append(r)
    out = ('## Matching hints for learned rules (World-Conventions L3-095, L11-009): many-valued attributes, sized from the initial world.\n'
           f"production optimize-attribute object {max(len(d['objects']), 2)}\n")
    for r in names: out += f"production optimize-attribute {r} {max(sum(1 for x, _ in d['relations'] if x == r), 2)}\n"
    return out + '\n'


def space_rules(d):
    n = d['name']
    dc = ''.join(' ^dont-copy-object-attribute ' + a for a in ['goal-met'] + [p['name'] + '-met' for p in d.get('phases') or []]
                 + ([d['termination']['name'] + '-met'] if d.get('termination') else []) + [s['attr'] for s in d['sums']])
    shared = static_info(d)[1]
    cr = ''.join(' ^copy-relation ' + r for r in rel_names(d) if r not in shared) + ''.join(' ^share-relation ' + r for r in shared)
    fl = ''.join(f' ^{f} {x}' for f, x in d['flags'])
    return f'''
sp {{{n}*elaborate*problem-space
   (state <s> ^name {n})
-->
   (<s> ^problem-space <p>)
   (<p> ^name {n}{cr}{dc})
}}

sp {{{n}*elaborate*problem-space*mea-substate
   (state <s> ^impasse no-change ^attribute operator ^superstate <ss>)
   (<ss> ^problem-space.name {n} ^operator <so>)
   (<so> ^task-operator true -^pre-conditions-satisfied true)
-->
   (<s> ^problem-space <p>)
   (<p> ^name {n}{dc})
}}

sp {{{n}*elaborate*flags
   (state <s> ^superstate nil ^name {n})
-->
   (<s> ^flag-override <f>)
   (<f> ^mea-operator-selection true{fl})
}}
'''


def achievement_rules(n):
    return f'''
## Achievement of object-property desireds (supplied by the task).
sp {{{n}*elaborate*state*achieved*object-property
   (state <s> ^desireds <ds> ^world <w>)
   (<ds> ^desired <d>)
   (<d> ^object <do>)
   (<do> ^object-handle <h> ^{{ <> object-handle <a> }} <v>)
   (<w> ^anchored-world true ^objects.object <ob>)
   (<ob> ^object-handle <h> ^<a> <v>)
-->
   (<ds> ^achieved <d>)
}}

sp {{{n}*elaborate*state*unachieved*object-property
   (state <s> ^desireds <ds> ^world <w>)
   (<ds> ^desired <d>)
   (<d> ^object <do>)
   (<do> ^object-handle <h> ^{{ <> object-handle <a> }} <v>)
   (<w> ^anchored-world true)
  -{{(<w> ^objects.object <ob>)
    (<ob> ^object-handle <h> ^<a> <v>)}}
-->
   (<ds> ^unachieved <d>)
}}
'''


def propose_rule(d, o):
    s = CS()
    for x, ty in o['params']: s.atom({'obj': x, 'type': ty})
    for a in o['pre']: s.atom(a)
    cost = ''
    if o.get('stepCost') is not None:
        if is_arith(o['stepCost']): raise ValueError(f"{o['name']}: arithmetic in a step cost")
        cost = f" ^step-cost {s.rhs(o['stepCost'])}"
    lhs = [f"   (state <s> ^problem-space.name {d['name']} ^flags.mea-operator-selection true ^world <w> ^desireds <ds>)",
           '   (<w> ^anchored-world true ^objects <objs>)'] + s.lines + ['   (<ds> ^unachieved-desireds true)']
    args = ' '.join(f'^argument{k} {v(x)}' for k, (x, _) in enumerate(o['params'], 1))
    return sp(f"{d['name']}*propose*{o['name']}", lhs,
              ['   (<s> ^operator <op> +)',
               f"   (<op> ^name {o['name']} ^task-operator true{' ^monotonic true' if o.get('monotonic') else ''} ^action-handle {o['name']} {args} ^argument-count {len(o['params'])}{cost} ^desireds <pre>)",
               '   (<pre> ^desired-count 0)'], f"Operator {o['name']}{stmt_note(o['stmts'])}.")


def eff_acts(s, e):
    """The actions of one effect; the conditions it needs are emitted on s."""
    if 'set' in e:
        return [f"   ({v(e['set'])} ^{e['prop']} {s.rhs(e['rhs'])})"]
    if 'update' in e:
        old = s.val_var(e['update'], e['prop'])
        rt = s.rhs(e['rhs'])
        return [f"   ({v(e['update'])} ^{e['prop']} {old} - {rt})"]
    if 'add' in e:
        ts = [s.arg(a) for a in e['args']]
        s.n += 1
        nv = f'<new-{s.n}>'
        return [f"   (<w> ^{e['add']} {nv})", f'   ({nv} ' + ' '.join(f'^argument{k} {t}' for k, t in enumerate(ts, 1)) + ')']
    if 'del' in e:
        rv = s.rel(e['del'], e['args'], 'e')
        return [f"   (<w> ^{e['del']} {rv} -)"]
    if 'change' in e:
        rv = s.rel(e['change'], e['args'], 'e')
        pos, args = e['pos'], e['args']
        old = s.arg(args[pos - 1] if pos - 1 < len(args) else {'h': 'none'})
        nw = s.arg(e['to'])
        return [f'   ({rv} ^argument{pos} {old} - {nw})']
    return []   # each: an apply rule of its own (each_bodies)


def base_conds(s, o):
    for x, _ in o['params']:
        s.emit(f'   (<objs> ^object {v(x)})')
        s.emit(f'   ({v(x)} ^object-handle $ <{x}-h>)')
        s.mark_bound(x)
    for a in o['bind']: s.atom(a)


def effect_body(o):
    s = CS()
    base_conds(s, o)
    acts = []
    for e in o['effects']: acts += eff_acts(s, e)
    return s, acts


def each_bodies(o):
    out = []
    for e in o['effects']:
        if 'each' not in e: continue
        s = CS()
        base_conds(s, o)
        for a in e['each']: s.atom(a)
        out.append((s, eff_acts(s, e['eff'])))
    return out


def say(s, p):
    if 'text' in p: return f"|{p['text']}|"
    if 'handle' in p: return f"<{p['handle']}-h>"
    x, q = p['prop']
    return s.val_var(x, q)


DEFAULT_OUTPUT = {'command': 'perform-action', 'nameAttribute': 'name', 'arguments': ['argument1', 'argument2', 'argument3'],
                  'done': ['interrupted', 'complete', 'success'], 'success': ['success'], 'error': ['error', 'failure'],
                  'applied': 'complete'}


def command_conds(d, o):
    """The output-link command a completed operator appears as, in the task's output form (World-Conventions L10-018)."""
    f = dict(DEFAULT_OUTPUT, **(d.get('output') or {}))
    attrs = f['arguments']
    arg_p = ' '.join(f"^{attrs[k] if k < len(attrs) else f'argument{k + 1}'} <{x}-h>" for k, (x, _) in enumerate(o['params']))
    if f.get('command'):
        return f['command'], f"   (<pa> ^{f['nameAttribute']} {o['name']} ^status {f['applied']} {arg_p} -^effect-applied true)"
    return o['name'], f"   (<pa> ^status {f['applied']} {arg_p} -^effect-applied true)"


def output_map_rule(d):
    """The environment's output map (World-Conventions L10-018), when the task declares an output form."""
    if not d.get('output'): return ''
    f = dict(DEFAULT_OUTPUT, **d['output'])
    body = ([f"        ^command {f['command']}", f"        ^name-attribute {f['nameAttribute']}"] if f.get('command')
            else ['        ^command-is-action-handle true'])
    body += [f'        ^argument{k} {a}' for k, a in enumerate(f['arguments'], 1)]
    body += [f"        ^done-status {' '.join(f['done'])}", f"        ^success-status {' '.join(f['success'])}",
             f"        ^error-status {' '.join(f['error'])})"]
    return sp(f"{d['name']}*elaborate*environment-output-map",
              [f"   (state <s> ^problem-space.name {d['name']} ^superstate nil)"],
              ['   (<s> ^environment-output-map <m>)', f'   (<m> {body[0].lstrip()}'] + body[1:],
              'How the environment takes actions on the output-link (World-Conventions L10-018).')


def apply_rules(d, o):
    s, acts = effect_body(o)
    n, on = d['name'], o['name']
    arg_h = ' '.join(f'^argument{k}.object-handle $ <{x}-h>' for k, (x, _) in enumerate(o['params'], 1))
    lhs_i = ['   (state <s> ^operator <op> ^internal-actions true ^world <w>)',
             f'   (<op> ^task-operator true ^name {on} ^pre-conditions-satisfied true {arg_h})',
             '   (<w> ^anchored-world true ^objects <objs>)'] + list(s.lines)
    internal = sp(f'{n}*apply*{on}*internal', lhs_i, acts, f'Effect of {on} (look-ahead).')
    say_ts = [say(s, p) for p in o['report']]
    cmd_c, pa_c = command_conds(d, o)
    lhs_e = ['   :o-support',
             f'   (state <s> ^superstate nil ^world <w> ^io.output-link.{cmd_c} <pa>)',
             pa_c,
             '   (<w> ^anchored-world true ^objects <objs>)'] + s.lines
    write = [f"   (write {' '.join(say_ts)} (crlf))"] if say_ts else []
    env = sp(f'{n}*apply*{on}*environment-effect', lhs_e, acts + ['   (<pa> ^effect-applied true)'] + write,
             f'Effect of a completed {on} command on the real world (once per command).')
    each_out = ''
    for k, (se, ae) in enumerate(each_bodies(o), 1):
        lhs_ie = lhs_i[:3] + list(se.lines)
        lhs_ee = lhs_e[:4] + list(se.lines)
        each_out += sp(f'{n}*apply*{on}*internal*each{k}', lhs_ie, ae, f'Effect of {on} on every match (look-ahead).')
        each_out += sp(f'{n}*apply*{on}*environment-effect*each{k}', lhs_ee, ae, f'Effect of a completed {on} command on every match (real world).')
    return internal + env + each_out


def sum_rules(d):
    out = ''
    for sd in d['sums']:
        sizes = []
        for o in d['objects']:
            if o['type'] != sd['ownerType']: continue
            k = sum(1 for r, hs in d['relations'] if r == sd['rel'] and hs[0] == o['handle'])
            props = dict((p, x) for p, x in o['props'])
            if 'size' not in props or 'int' not in props['size']:
                raise ValueError(f"{o['handle']}: a sum owner needs ^size")
            if props['size']['int'] != k: raise ValueError(f"{o['handle']}: size {props['size']['int']} but {k} members")
            if k not in sizes: sizes.append(k)
        for k in sorted(sizes):
            ms = range(1, k + 1)
            conds = []
            for i in ms:
                mterm = '<m1>' if i == 1 else '{ ' + ''.join(f'<> <m{j}> ' for j in range(1, i)) + f'<m{i}> }}'
                conds += [f'   (<r{i}> ^argument1 <g> ^argument2 {mterm})', f"   (<m{i}> ^{sd['prop']} <v{i}>)"]
            lhs = ['   (state <s> ^world <w>)',
                   f"   (<w> ^anchored-world true ^{sd['rel']} {' '.join(f'<r{i}>' for i in ms)})",  # <g> bound through the relation (L3-104)
                   f"   (<g> ^type {sd['ownerType']} ^size {k})"] + conds
            out += sp(f"{d['name']}*elaborate*{sd['ownerType']}*{sd['attr']}*{k}", lhs,
                      [f"   (<g> ^{sd['attr']} (+ " + ' '.join(f'<v{i}>' for i in ms) + '))'],
                      f"{sd['attr']} of a {sd['ownerType']} of {k}, once every member has {sd['prop']} (derived; not copied into look-ahead worlds).")
    return out


def rename(a, g):
    if 'obj' in a: return {**a, 'obj': g(a['obj'])}
    if 'has' in a:
        r = a['rhs']
        if 'prop' in r: r = {'prop': [g(r['prop'][0]), r['prop'][1]]}
        return {**a, 'has': g(a['has']), 'rhs': r}
    if 'rel' in a: return {**a, 'args': [{'var': g(x['var'])} if 'var' in x else x for x in a['args']]}
    if 'distinct' in a: return {'distinct': [g(x) for x in a['distinct']]}
    return a


def cond_atoms(d, c):
    if 'ex' in c: return c['ex']
    fa = c['all']
    if fa['filter']: raise ValueError('a universal condition with a filter is not compiled yet')
    outer_vars = []
    for a in fa['outer']:
        if 'obj' in a: outer_vars.append(a['obj'])
        elif 'has' in a: outer_vars.append(a['has'])
        elif 'rel' in a: outer_vars += [x['var'] for x in a['args'] if 'var' in x]
    inst = []
    for o in d['objects']:
        if o['type'] != fa['type']: continue
        h = o['handle']
        g = (lambda h: lambda x: f"{fa['var']}-{h}" if x == fa['var'] else (x if x in outer_vars else f'{x}-{h}'))(h)
        inst.append({'has': g(fa['var']), 'prop': 'object-handle', 'cmp': 'eq', 'rhs': {'val': {'sym': h}}})
        inst += [rename(a, g) for a in fa['body']]
    return fa['outer'] + inst


def eval_mark_rule(d, m):
    """An evaluation-order mark (World-Conventions L15-026): an elaboration of the proposed operator."""
    ops = [o for o in d['ops'] if o['name'] == m['op']]
    if not ops: raise ValueError(f"evaluation mark {m['name']}: no operator {m['op']}")
    o = ops[0]
    if any('lacks' in a or 'none' in a for a in m['cond']): raise ValueError(f"evaluation mark {m['name']}: negated condition")
    s = CS()
    for x, _ in o['params']: s.mark_bound(x)
    for a in m['cond']: s.atom(a)
    args = ' '.join(f'^argument{k} {v(x)}' for k, (x, _) in enumerate(o['params'], 1))
    which = m['mark']
    item = f" {m['item']} [evaluation]" if m.get('item') else ''
    return sp(f"{d['name']}*elaborate*{o['name']}*evaluate-{which}*{m['name']}",
              [f"   (state <s> ^problem-space.name {d['name']} ^operator <op> + ^world <w>)",
               '   (<w> ^anchored-world true ^objects <objs>)',
               f"   (<op> ^task-operator true ^name {o['name']} {args})"] + s.lines,
              [f'   (<op> ^evaluate-{which} true)'],
              f"Search control{item}{stmt_note(m.get('stmts', []))}: evaluate {o['name']} {which} when {m['name']} (World-Conventions L15-026; only the order of evaluation changes).")


def failure_rule(d, f):
    s = CS()
    for a in cond_atoms(d, f['cond']): s.atom(a)
    return sp(f"{d['name']}*elaborate*failure*{f['name']}",
              ['   (state <s> ^desireds <ds> ^world <w>)', '   (<w> ^anchored-world true ^objects <objs>)'] + s.lines,
              ['   (<s> ^failure <ds>)'], f"Losing condition {f['name']}{stmt_note(f['stmts'])}.")


def goal_rule(d):
    s = CS()
    for a in [{'obj': 'task', 'type': 'task'}] + cond_atoms(d, d['goal']): s.atom(a)
    return sp(f"{d['name']}*elaborate*goal",
              ['   (state <s> ^world <w>)', '   (<w> ^anchored-world true ^objects <objs>)'] + s.lines,
              ['   (<task> ^goal-met true)'], f"Goal{stmt_note(d['goalStmts'])}: ^goal-met true on the task object.")


def phase_rule(d, p, kind):
    """A phase or the termination condition (World-Conventions L8-026, L8-028; Compile.lean phaseRule)."""
    s = CS()
    for a in [{'obj': 'task', 'type': 'task'}] + cond_atoms(d, p['cond']): s.atom(a)
    return sp(f"{d['name']}*elaborate*{kind}*{p['name']}",
              ['   (state <s> ^world <w>)', '   (<w> ^anchored-world true ^objects <objs>)'] + s.lines,
              [f"   (<task> ^{p['name']}-met true)"],
              f"{'Phase' if kind == 'phase' else 'Termination'} {p['name']}{stmt_note(p['stmts'])}: ^{p['name']}-met true on the task object.")


def goal_rules(d):
    """The goal rule, or one rule per phase and one for the termination condition (Compile.lean goalRules)."""
    if not d.get('phases'): return goal_rule(d)
    return ''.join(phase_rule(d, p, 'phase') for p in d['phases']) + (phase_rule(d, d['termination'], 'termination') if d.get('termination') else '')


def achievement_for(d):
    """With termination desireds the task's achievement rules also mark them (World-Conventions L8-028)."""
    a = achievement_rules(d['name'])
    return a.replace('^desireds <ds> ^world <w>', '^<< desireds termination-desireds >> <ds> ^world <w>') if d.get('termination') else a


def repeat_rules(d):
    """Repeated-situation control (WorldSpec Task.repeatControl): stated in the description, not taught.
    The current look-ahead world is compared with each ancestor world directly (no derived label, which lags by a wave)."""
    rc = d.get('repeatControl')
    if not rc: return ''
    n, rl, tys = d['name'], rc['rel'], ' '.join(rc['types'])
    return f"""
## ---- Search control (stated in the description, not taught): a look-ahead state that returns to a situation on
## its look-ahead path fails, and the library rejects it. Situation: where each {' / '.join(rc['types'])} is ({rl}).
sp {{{n}*elaborate*ancestor-world*parent
   (state <s> ^name evaluate-operator ^superstate.superstate.world <aw>)
-->
   (<s> ^ancestor-world <aw>)
}}

sp {{{n}*elaborate*ancestor-world*inherited
   (state <s> ^name evaluate-operator ^superstate.superstate.ancestor-world <aw>)
-->
   (<s> ^ancestor-world <aw>)
}}

sp {{{n}*elaborate*failure*repeated-situation
   (state <s> ^name evaluate-operator ^look-ahead-operator <o> ^ancestor-world <aw> ^desireds <ds> ^world <w>)
   (<w> ^anchored-world true ^versioned-operator <o>)
  -{{(<w> ^{rl} <r>)
    (<r> ^argument1 <x> ^argument2 <p>)
    (<x> ^type << {tys} >> ^object-handle <h>)
    (<p> ^object-handle <ph>)
    (<aw> ^{rl} <ar>)
    (<ar> ^argument1 <ax> ^argument2 <ap>)
    (<ax> ^object-handle <h>)
    (<ap> ^object-handle <> <ph>)}}
-->
   (<s> ^failure <ds>)
}}
"""


def derived_rule(d, dr):
    s = CS()
    for a in dr['defn']: s.atom(a)
    args = ' '.join(f'^argument{k} {v(x)}' for k, x in enumerate(dr['vars'], 1))
    return sp(f"{d['name']}*elaborate*derived*{dr['name']}",
              ['   (state <s> ^world <w>)', '   (<w> ^anchored-world true ^objects <objs>)'] + s.lines,
              [f"   (<w> ^{dr['name']} <dr>)", f'   (<dr> {args})'],
              f"Derived relation {dr['name']}{stmt_note(dr['stmts'])}: recomputed in every world, never copied into look-ahead.")


# Reserved variable names (the same check as WorldSpec/Check.lean, Var.badName and Task.vars): a description
# variable may not be a name the generated rules use themselves, contain '-' (generated names such as <k-...>,
# <new-...>), or have the form r<digits> or e<digits>.
RESERVED_VARS = ['s', 'w', 'objs', 'ds', 'op', 'pre', 'pa', 'task', 'any-unachieved', 'dr']

def bad_var(x):
    return (x in RESERVED_VARS or '-' in x or x == '' or
            (x[0] in 're' and len(x) > 1 and x[1:].isdigit()))

def _rhs_vars(r):
    if 'prop' in r: return [r['prop'][0]]
    for k in ARITH_KEYS:
        if k in r: return _rhs_vars(r[k][0]) + _rhs_vars(r[k][1])
    return []

def _arg_vars(args): return [a['var'] for a in args if 'var' in a]

def _atom_vars(a):
    if 'obj' in a: return [a['obj']]
    if 'has' in a: return [a['has']] + _rhs_vars(a['rhs'])
    if 'rel' in a: return _arg_vars(a['args'])
    if 'distinct' in a: return list(a['distinct'])
    if 'lacks' in a: return [a['lacks'][0]]
    return []   # none: its variables are local (as in Lean)

def _eff_vars(e):
    if 'set' in e: return [e['set']] + _rhs_vars(e['rhs'])
    if 'update' in e: return [e['update']] + _rhs_vars(e['rhs'])
    if 'add' in e or 'del' in e: return _arg_vars(e['args'])
    if 'change' in e: return _arg_vars(e['args']) + _rhs_vars(e['to'])
    if 'each' in e:
        bound = [x for a in e['each'] for x in _atom_vars(a)]
        return [x for x in _eff_vars(e['eff']) if x not in bound]
    return []

def _cond_atoms(c):
    if 'ex' in c: return c['ex']
    fa = c['all']; return fa['outer'] + fa['filter'] + fa['body']

def task_vars(d):
    vs = []
    for o in d['ops']:
        vs += [p[0] for p in o['params']]
        vs += [x for a in o['pre'] + o['bind'] for x in _atom_vars(a)]
        vs += [x for e in o['effects'] for x in _eff_vars(e)]
        if 'stepCost' in o: vs += _rhs_vars(o['stepCost'])
        vs += [x for e in o['effects'] if 'each' in e for a in e['each'] for x in _atom_vars(a)]
    for f in d['failures']: vs += [x for a in _cond_atoms(f['cond']) for x in _atom_vars(a)]
    vs += [x for a in _cond_atoms(d['goal']) for x in _atom_vars(a)]
    if 'all' in d['goal']: vs.append(d['goal']['all']['var'])
    for dr in d.get('derived', []): vs += dr['vars'] + [x for a in dr['defn'] for x in _atom_vars(a)]
    for m in d.get('evalMarks', []): vs += [x for a in m['cond'] for x in _atom_vars(a)]
    return vs

def _is_neg(a): return 'lacks' in a or 'none' in a

def well_formed(d):
    """The checks of agentgen/WorldSpec/Check.lean Task.wellFormed, for path B (added 26 Nov 2026: path B compiled
    descriptions that path A rejects, and two of them made rules that looped or learned wrongly)."""
    errs = []
    derived = [x['name'] for x in d.get('derived', [])]
    for o in d['ops']:
        n, ps = o['name'], [p[0] for p in o['params']]
        seen = ps + [x for a in o['bind'] for x in _atom_vars(a)]
        errs += [f'{n}: negation in a compiled condition (W-CHK-009; put it in a derived relation and test that)'
                 for a in o['pre'] + o['bind'] if _is_neg(a)]
        errs += [f'{n}: effect uses {x}, not a parameter or bound by bind (it would become a new identifier on every firing)'
                 for x in dict.fromkeys(x for e in o['effects'] for x in _eff_vars(e)) if x not in seen]
        for p in o['report']:
            if 'handle' in p and p['handle'] not in ps: errs.append(f"{n}: reports the handle of {p['handle']}, not a parameter")
            if 'prop' in p and p['prop'][0] not in seen: errs.append(f"{n}: reports {p['prop'][0]}, not bound")
        for e in o['effects']:
            if 'each' in e:
                errs += [f'{n}: negation in an each condition (W-CHK-009)' for a in e['each'] if _is_neg(a)]
                if 'each' in e['eff']: errs.append(f'{n}: an each inside an each')
            r = e.get('add') or e.get('del') or e.get('change') or (e['eff'].get('add') or e['eff'].get('del') or e['eff'].get('change') if 'each' in e else None)
            if r in derived: errs.append(f'{n}: changes derived relation {r}')
        errs += [f'{n}: arithmetic in a condition' for a in o['pre'] + o['bind'] if 'has' in a and is_arith(a['rhs'])]
    for f in d['failures']:
        errs += [f"failure {f['name']}: negation (W-CHK-009; put it in a derived relation and test that)" for a in _cond_atoms(f['cond']) if _is_neg(a)]
        errs += [f"failure {f['name']}: arithmetic in a condition" for a in _cond_atoms(f['cond']) if 'has' in a and is_arith(a['rhs'])]
    errs += ['goal: negation (W-CHK-009)' for a in _cond_atoms(d['goal']) if _is_neg(a)]
    errs += ['goal: arithmetic in a condition' for a in _cond_atoms(d['goal']) if 'has' in a and is_arith(a['rhs'])]
    for m in d.get('evalMarks', []):
        if m['op'] not in [o['name'] for o in d['ops']]: errs.append(f"evaluation mark {m['name']}: no operator {m['op']}")
        if any(_is_neg(a) for a in m['cond']): errs.append(f"evaluation mark {m['name']}: negation")
    errs += [f"assumption {a['id']} is open ({a['kind']}): raise it with the user" for a in d.get('assumptions', []) if a.get('kind', 'intent') != 'intent']
    hs = [o['handle'] for o in d['objects']]
    dups = sorted(set(h for h in hs if hs.count(h) > 1))
    if dups: errs.append(f'objects share a handle: {dups}')
    if errs:
        raise SystemExit('spec_backend: the description is not well formed (WorldSpec/Check.lean):\n  ' + '\n  '.join(errs))

def check_vars(d):
    bad = sorted(set(x for x in task_vars(d) if bad_var(x)))
    if bad:
        raise SystemExit('spec_backend: description variables with names the back ends reserve or generate: ' +
                         ', '.join(bad) + ' (rename them; WorldSpec/Check.lean Var.badName)')



# ---------------------------------------------------------------- generated search control: slot order
# World-Conventions L21-001; the same checks and generation as agentgen/WorldSpec/SlotOrder.lean (path A), which
# documents why the order loses no solution. Recognized from the description's structure, never from its name.

def _slot_fill(m):
    """Check 1: a maintained relation that holds of an unfilled slot. Returns (type, ('prop', p) or ('rel', R))."""
    df = m['defn']
    if len(df) != 2 or 'obj' not in df[0] or df[0]['type'] is None or df[0]['obj'] != m['var']: return None
    x, ty = m['var'], df[0]['type']
    if 'lacks' in df[1] and df[1]['lacks'][0] == x: return ty, ('prop', df[1]['lacks'][1])
    if 'none' in df[1] and len(df[1]['none']) == 1 and 'rel' in df[1]['none'][0]:
        r = df[1]['none'][0]
        if r['args'] and r['args'][0] == {'var': x}: return ty, ('rel', r['rel'])
    return None

def _rhs_props(r):
    if 'prop' in r: return [r['prop'][1]]
    for k in ARITH_KEYS:
        if k in r: return _rhs_props(r[k][0]) + _rhs_props(r[k][1])
    return []

def _reads(props, rels, a):
    if 'has' in a: return a['prop'] in props or any(q in props for q in _rhs_props(a['rhs']))
    if 'rel' in a: return a['rel'] in rels
    if 'none' in a: return any(_reads(props, rels, b) for b in a['none'])
    return False

def _task_reads(d, marker, f):
    props = ([f[1]] if f[0] == 'prop' else []) + [x['attr'] for x in d['sums']]
    rels = [marker] + ([f[1]] if f[0] == 'rel' else []) + [x['name'] for x in d.get('derived', [])]
    return props, rels

def _is_fill(f, props, x, e):
    if f[0] == 'prop' and 'set' in e:
        return e['prop'] == f[1] and e['set'] == x and not any(q in props for q in _rhs_props(e['rhs']))
    if f[0] == 'rel' and 'add' in e:
        return e['add'] == f[1] and bool(e['args']) and e['args'][0] == {'var': x}
    return False

def _slot_param(d, marker, ty, f, o):
    """Checks 2 and 3: the slot parameter of a fill operator, or None."""
    props, rels = _task_reads(d, marker, f)
    x = next((p for p, pty in o['params'] if pty == ty and {'rel': marker, 'args': [{'var': p}]} in o['pre']), None)
    if x is None or o['bind']: return None
    es = o['effects']
    del_m = {'del': marker, 'args': [{'var': x}]}
    if len(es) != 2 or not ((_is_fill(f, props, x, es[0]) and es[1] == del_m) or (_is_fill(f, props, x, es[1]) and es[0] == del_m)):
        return None
    rest = list(o['pre']); rest.remove({'rel': marker, 'args': [{'var': x}]})
    if any(_reads(props, rels, a) for a in rest): return None
    if o.get('stepCost') is not None and any(q in props for q in _rhs_props(o['stepCost'])): return None
    return x

def _tested_on(f, var, a):
    if f[0] == 'prop' and 'has' in a: return a['prop'] == f[1] and a['has'] == var
    if f[0] == 'rel' and 'rel' in a: return a['rel'] == f[1] and bool(a['args']) and a['args'][0] == {'var': var}
    return False

def _all_rel_names(d):
    rs = lambda atoms: [a['rel'] for a in atoms if 'rel' in a]
    eff = lambda e: e.get('add') or e.get('del') or e.get('change') or (eff(e['eff']) if 'each' in e else None)
    out = [m['name'] for m in d['maintained']] + [x['name'] for x in d.get('derived', [])] + [r for r, _ in d['relations']]
    for o in d['ops']: out += rs(o['pre'] + o['bind']) + [n for n in map(eff, o['effects']) if n]
    for fl in d['failures']: out += rs(_cond_atoms(fl['cond']))
    return out + rs(_cond_atoms(d['goal']))

def slots(d):
    """Checks 1 to 6 (SlotOrder.lean Task.slots?): (marker, type, fill, slot parameter per operator), or None."""
    if d.get('slotOrder') is False or d.get('phases') or d.get('termination') or not d['ops']: return None
    derived = [x['name'] for x in d.get('derived', [])]
    for m in d['maintained']:
        sf = _slot_fill(m)
        if sf is None: continue
        ty, f = sf
        ps = [_slot_param(d, m['name'], ty, f, o) for o in d['ops']]
        if None in ps: continue
        bad = lambda a: _reads([], [m['name']] + derived, a)
        if not all('ex' in fl['cond'] and not any(bad(a) for a in fl['cond']['ex']) for fl in d['failures']): continue
        g = d['goal']
        if 'all' not in g: continue
        fa = g['all']
        if fa['type'] != ty or fa['outer'] or fa['filter'] or not any(_tested_on(f, fa['var'], a) for a in fa['body']) or \
           any(bad(a) for a in fa['body']): continue
        names = _all_rel_names(d)
        if m['name'] + '-next' in names or m['name'] + '-first' in names: continue
        return m['name'], ty, f, ps
    return None

def _op_vars(o):
    return ([p for p, _ in o['params']] + [x for a in o['pre'] + o['bind'] for x in _atom_vars(a)] +
            [x for e in o['effects'] for x in _eff_vars(e)] +
            [x for e in o['effects'] if 'each' in e for a in e['each'] for x in _atom_vars(a)])

def _fresh_var(used):
    for c in ['nextslot'] + [f'nextslot{k + 2}' for k in range(50)]:
        if c not in used: return c
    return 'nextslotz'

def with_slot_order(d):
    """The description with the slot order applied, and the comment for the rules ('' when not recognized)."""
    sl = slots(d)
    if sl is None: return d, ''
    marker, ty, f, ps = sl
    nxt, first = marker + '-next', marker + '-first'
    rels = [r for r, _ in d['relations']]
    slot_hs = [o['handle'] for o in d['objects'] if o['type'] == ty and [marker, [o['handle']]] in [list(t) for t in d['relations']]]
    chain = [[nxt, [a, b]] for a, b in zip(slot_hs, slot_hs[1:])]
    head = [[first, [slot_hs[0]]]] if slot_hs else []
    ops = []
    for o, x in zip(d['ops'], ps):
        y = _fresh_var(_op_vars(o))
        m_atom = {'rel': marker, 'args': [{'var': x}]}
        pre = []
        for a in o['pre']:
            pre.append(a)
            if a == m_atom: pre.append({'rel': first, 'args': [{'var': x}]})
        ops.append(dict(o, pre=pre, effects=o['effects'] + [
            {'del': first, 'args': [{'var': x}]},
            {'each': [{'rel': nxt, 'args': [{'var': x}, {'var': y}]}], 'eff': {'add': first, 'args': [{'var': y}]}}]))
    names = ', '.join(o['name'] for o in d['ops'])
    note = ('##\n## Search control generated from the structure of the description (World-Conventions L21-001; not stated in the English):\n'
            f"##   each {ty} gets exactly one {names}, and these commute, so {names} is proposed only for the first {ty} still without one,\n"
            f'##   in the order of the initial world ({first}, moved along {nxt}).\n')
    return dict(d, ops=ops, relations=[list(t) for t in d['relations']] + chain + head), note


def compile_task(d):
    assert d.get('format') == 'worldspec-1', d.get('format')
    check_vars(d)
    well_formed(d)
    d, slot_note = with_slot_order(d)   # generated search control (World-Conventions L21-001)
    out = header(d) + slot_note + match_hints(d) + init_rules(d) + output_map_rule(d) + space_rules(d) + achievement_for(d)
    for o in d['ops']: out += propose_rule(d, o) + apply_rules(d, o)
    out += sum_rules(d)
    for m in d.get('evalMarks', []): out += eval_mark_rule(d, m)
    for dr in d.get('derived', []): out += derived_rule(d, dr)
    for f in d['failures']: out += failure_rule(d, f)
    import convpass   # 18 Nov 2026 conventions: problem-space test (L3-005), group comments (L3-012)
    return convpass.apply(fixed_lines(out + goal_rules(d) + repeat_rules(d), fixed_info(d))) + learning_block(d)


def learning_block(d):
    """Learning off (World-Conventions L5-021): appended after the rules, so it overrides the library's chunk only."""
    lr = d.get('learning')
    if not lr:
        return ''
    return ('\n## Learning is off for this agent: the English statement says "Learning: do not learn from look-ahead"'
            ' (World-Conventions L5-021).\n' + (f"## Reason given: {lr['reason']}\n" if lr.get('reason') else '') + 'chunk never\n')


if __name__ == '__main__':
    d = json.load(open(sys.argv[1]))
    open(sys.argv[2], 'w').write(compile_task(d))
    print('wrote', sys.argv[2])
