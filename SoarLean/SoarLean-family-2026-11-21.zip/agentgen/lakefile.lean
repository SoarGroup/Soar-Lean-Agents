import Lake
open Lake DSL

package agentgen

lean_lib WorldSpec

lean_exe rosiegen where
  root := `RosieGen

lean_lib Family

lean_exe familygen where
  root := `FamilyGen
