import WorldSpec.Sem
import Lean.Data.Json
/-!
# Path B: the WorldSpec description as JSON, for worldgen/spec_backend.py

The description is exported with its world evaluated in Lean: the objects and relation tuples of the
initial state (maintained relations included, computed from their definitions), so the back end
needs no world-file reader and no semantics. Conditions, operators and effects are exported as
written; the back end compiles them.
-/
namespace WorldSpec
open Lean

def Val.toJ : Val → Json
  | .sym s => Json.mkObj [("sym", s)]
  | .int i => Json.mkObj [("int", toJson i)]
  | .bool b => Json.mkObj [("bool", toJson b)]

def Arg.toJ : Arg → Json
  | .var x => Json.mkObj [("var", x)]
  | .h hd => Json.mkObj [("h", hd)]

def Cmp.toJ : Cmp → Json
  | .eq => "eq" | .ne => "ne" | .lt => "lt" | .le => "le" | .gt => "gt" | .ge => "ge"

def Rhs.toJ : Rhs → Json
  | .val x => Json.mkObj [("val", x.toJ)]
  | .prop y q => Json.mkObj [("prop", Json.arr #[y, q])]
  | .plus a b => Json.mkObj [("plus", Json.arr #[a.toJ, b.toJ])]

def Atom.toJ : Atom → Json
  | .obj x t => Json.mkObj [("obj", x), ("type", match t with | some ty => ty | Option.none => Json.null)]
  | .has x p c r => Json.mkObj [("has", x), ("prop", p), ("cmp", c.toJ), ("rhs", r.toJ)]
  | .rel r as => Json.mkObj [("rel", r), ("args", Json.arr (as.map Arg.toJ).toArray)]
  | .distinct x y => Json.mkObj [("distinct", Json.arr #[x, y])]
  | .lacks x p => Json.mkObj [("lacks", Json.arr #[x, p])]
  | .none as => Json.mkObj [("none", Json.arr (as.map Atom.toJ).toArray)]

def atomsJ (as : List Atom) : Json := Json.arr (as.map Atom.toJ).toArray

def Cond.toJ : Cond → Json
  | .ex as => Json.mkObj [("ex", atomsJ as)]
  | .all fa => Json.mkObj [("all", Json.mkObj [("outer", atomsJ fa.outer), ("var", fa.var), ("type", fa.type),
      ("filter", atomsJ fa.filter), ("body", atomsJ fa.body)])]

def Eff.toJ : Eff → Json
  | .set x p r => Json.mkObj [("set", x), ("prop", p), ("rhs", r.toJ)]
  | .update x p r => Json.mkObj [("update", x), ("prop", p), ("rhs", r.toJ)]
  | .add r as => Json.mkObj [("add", r), ("args", Json.arr (as.map Arg.toJ).toArray)]
  | .del r as => Json.mkObj [("del", r), ("args", Json.arr (as.map Arg.toJ).toArray)]
  | .change r as pos to => Json.mkObj [("change", r), ("args", Json.arr (as.map Arg.toJ).toArray),
      ("pos", toJson pos), ("to", to.toJ)]

def Say.toJ : Say → Json
  | .text s => Json.mkObj [("text", s)]
  | .handle x => Json.mkObj [("handle", x)]
  | .prop x p => Json.mkObj [("prop", Json.arr #[x, p])]

def Op.toJ (o : Op) : Json := Json.mkObj (([
  ("name", (o.name : Json)),
  ("params", Json.arr (o.params.map fun (x, t) => Json.arr #[x, match t with | some ty => ty | none => Json.null]).toArray),
  ("pre", atomsJ o.pre), ("bind", atomsJ o.bind),
  ("effects", Json.arr (o.effects.map Eff.toJ).toArray),
  ("report", Json.arr (o.report.map Say.toJ).toArray), ("stmts", toJson o.stmts)] : List (String × Json)) ++
  (match o.stepCost with | some r => [("stepCost", r.toJ)] | none => []))

def Obj.toJ (o : Obj) : Json := Json.mkObj [("handle", o.handle), ("type", o.type),
  ("props", Json.arr (o.props.map fun (p, x) => Json.arr #[p, x.toJ]).toArray)]

def AssumptionKind.toJ : AssumptionKind → Json
  | .intent => "intent" | .gap => "gap" | .tooling => "tooling"

/-- The description with its initial world evaluated (path B input). -/
def Task.toJ (t : Task) (wf : WorldFile) : Json :=
  let st := t.initial wf
  Json.mkObj <| [
    ("format", ("worldspec-1" : Json)),
    ("name", t.name), ("title", t.title),
    ("statements", Json.arr (t.statements.map fun (k, s) => Json.arr #[toJson k, s]).toArray),
    ("assumptions", Json.arr (t.assumptions.map fun a => Json.mkObj [("id", a.id), ("kind", a.kind.toJ),
       ("text", a.text), ("stmts", toJson a.stmts)]).toArray),
    ("flags", Json.arr (t.flags.map fun (f, x) => Json.arr #[f, x]).toArray),
    ("objects", Json.arr (st.objs.map Obj.toJ).toArray),
    ("relations", Json.arr (st.rels.map fun (r, hs) => Json.arr #[r, toJson hs]).toArray),
    ("maintained", Json.arr (t.maintained.map fun m => Json.mkObj [("name", m.name), ("var", m.var),
       ("defn", atomsJ m.defn), ("stmts", toJson m.stmts)]).toArray),
    ("sums", Json.arr (t.sums.map fun s => Json.mkObj [("attr", s.attr), ("ownerType", s.ownerType),
       ("rel", s.rel), ("prop", s.prop)]).toArray),
    ("ops", Json.arr (t.ops.map Op.toJ).toArray),
    ("goal", t.goal.toJ), ("goalStmts", toJson t.goalStmts),
    ("failures", Json.arr (t.failures.map fun f => Json.mkObj [("name", f.name), ("cond", f.cond.toJ),
       ("stmts", toJson f.stmts)]).toArray)] ++
    (match t.repeatControl with
     | some rc => [("repeatControl", Json.mkObj [("rel", rc.rel), ("types", toJson rc.types)])]
     | none => [])

end WorldSpec
