import WorldSpec.Check
import WorldSpec.Tasks.Hanoi
import WorldSpec.Tasks.Fox
import WorldSpec.Tasks.KenKen
import WorldSpec.Tasks.MonkeyBananas
import WorldSpec.Tasks.VacuumWorld
import WorldSpec.Tasks.TowerOfLondon
import WorldSpec.Tasks.InstantInsanity
import WorldSpec.Tasks.BridgeAndTorch
/-! The three Rosie descriptions are well formed (WorldSpec/Check.lean). -/
namespace WorldSpec.Tasks

theorem hanoi_wellFormed : hanoi.wellFormed = [] := by decide
theorem fox_wellFormed : fox.wellFormed = [] := by decide
theorem kenken_wellFormed : kenken.wellFormed = [] := by decide
theorem monkeyBananas_wellFormed : monkeyBananas.wellFormed = [] := by decide
theorem vacuumWorld_wellFormed : vacuumWorld.wellFormed = [] := by decide
theorem towerOfLondon_wellFormed : towerOfLondon.wellFormed = [] := by decide
theorem instantInsanity_wellFormed : instantInsanity.wellFormed = [] := by decide
theorem bridgeAndTorch_wellFormed : bridgeAndTorch.wellFormed = [] := by decide

end WorldSpec.Tasks
