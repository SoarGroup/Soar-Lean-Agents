/-!
# WorldSpec: a typed task description for agents written from restricted English

`World.Task` (World/Types.lean) describes tasks whose operators are proposed by means-ends analysis
from desireds. The Rosie teaching dialogs (Tasks/From-English/rosie-teaching) state tasks differently:
an action is legal when its conditions hold ("You can move a clear block onto a clear object that is
larger than the block"), the goal is a condition on the world ("two green locations are clear"), and
losing conditions end the task ("If a red block and a yellow block are on the opposite bank then you
lose"). This module gives that form a typed description. It is compiled to world-convention Soar rules
in Lean (WorldSpec/Compile.lean, path A) and exported as JSON for the Python back end
(WorldSpec/Json.lean and worldgen/spec_backend.py, path B); WorldSpec/Sem.lean gives it a semantics
that checks example states and replays plans without Soar.

Every element carries the numbers of the instructor statements it comes from, and the description
carries the assumption ledger (CLAUDE.md, issue 6: kinds intent, gap, tooling).

Conventions referred to (World-Conventions-Spec-v6): objects are named by handles (W-OBJ-002); a
relation is a relation object with ^argument1..N (W-REL-001); a concept that tests absence and decides
legality is a maintained relation, not a negated condition (section 3, W-CHK-009); derived object
attributes are not copied into look-ahead worlds (^dont-copy-object-attribute); object-handle tests
carry `$` (W-CHK-011).
-/
namespace WorldSpec

/-- A property value. Rosie's symbols lose their trailing sense number (red1 → red). -/
inductive Val where
  | sym  : String → Val
  | int  : Int → Val
  | bool : Bool → Val
  deriving DecidableEq, Repr, Inhabited, BEq

def Val.toSoar : Val → String
  | .sym s => s
  | .int i => toString i
  | .bool b => if b then "true" else "false"

/-- An object in a condition: a variable (bound by the condition) or a constant handle. -/
inductive Arg where
  | var : String → Arg
  | h   : String → Arg
  deriving DecidableEq, Repr, Inhabited, BEq

inductive Cmp where
  | eq | ne | lt | le | gt | ge
  deriving DecidableEq, Repr, Inhabited, BEq

def Cmp.toSoar : Cmp → String
  | .eq => "" | .ne => "<> " | .lt => "< " | .le => "<= " | .gt => "> " | .ge => ">= "

/-- The right side of a property test or assignment: a constant, a property of a bound object, or
the sum of two integer right sides. A sum is allowed only in an effect (`set`, `update`): Soar computes
it on a rule's right-hand side with `(+ a b)`; a condition cannot (checked by `Task.wellFormed`). -/
inductive Rhs where
  | val  : Val → Rhs
  | prop : String → String → Rhs        -- variable, property
  | plus : Rhs → Rhs → Rhs
  deriving DecidableEq, Repr, Inhabited, BEq

def Rhs.isArith : Rhs → Bool
  | .plus .. => true
  | _ => false

/-- One test in a condition. A condition is a list of atoms, all of which must hold for one binding
of its variables. -/
inductive Atom where
  /-- `x` is a world object, of the given type (`^type`) if one is named. Binds `x`. -/
  | obj      : String → Option String → Atom
  /-- `x.p c rhs`: object `x` has property `p` with a value that compares so with `rhs`. -/
  | has      : String → String → Cmp → Rhs → Atom
  /-- The relation holds of these objects, in order. -/
  | rel      : String → List Arg → Atom
  /-- `x` and `y` are different objects. -/
  | distinct : String → String → Atom
  /-- `x` has no property `p`. A negation: allowed only in the definition of a maintained relation,
  which the compiler turns into initial relation objects, never into a rule condition (W-CHK-009). -/
  | lacks    : String → String → Atom
  /-- No extension of the binding meets these atoms (a negated conjunction). As for `lacks`. -/
  | none     : List Atom → Atom
  deriving Repr, Inhabited, BEq

def Atom.negated : Atom → Bool
  | .lacks .. | .none .. => true
  | _ => false

/-- A condition that holds when every object of a type that meets `filter` also meets `body`.
Variables bound in `outer` are shared by every instance. -/
structure ForAll where
  outer  : List Atom := []
  var    : String
  type   : String
  filter : List Atom := []
  body   : List Atom
  deriving Repr, Inhabited, BEq

/-- A condition: some binding meets all atoms, or a universal statement over a type. -/
inductive Cond where
  | ex  : List Atom → Cond
  | all : ForAll → Cond
  deriving Repr, Inhabited, BEq

/-- An effect of an operator, over the operator's parameters and the variables its `bind` condition
binds in the state before the action. -/
inductive Eff where
  /-- `x.p := rhs`; `x` has no `p` before the action. -/
  | set    : String → String → Rhs → Eff
  /-- `x.p := rhs`, replacing the value `x.p` has before the action (statement form "add the time of
  the crossing to the elapsed time"). The right side is evaluated in the state before the action. -/
  | update : String → String → Rhs → Eff
  /-- Add the relation tuple. -/
  | add    : String → List Arg → Eff
  /-- Remove the relation tuple. -/
  | del    : String → List Arg → Eff
  /-- The tuple `rel(args)` now has `to` at position `pos` (1-based); the relation object is kept. -/
  | change : String → List Arg → Nat → Arg → Eff
  deriving DecidableEq, Repr, Inhabited, BEq

/-- A sum over a set of objects: on each `owner` of type `ownerType`, `attr` is the sum of property
`prop` of the objects `m` with `rel(owner, m)`, defined once every such object has `prop`
(statement form "the sum of the values of the group"). A derived attribute: never copied into a
look-ahead world. -/
structure SumDef where
  attr      : String
  ownerType : String
  rel       : String
  prop      : String
  deriving Repr, Inhabited, BEq

/-- A one-argument relation kept by the actions (a concept that tests absence and decides legality,
W-SPEC v6 section 3). `defn` states it over `var`; the initial world gets one relation object per
object that meets it, and each operator's effects keep it (checked by WorldSpec/Sem.lean). -/
structure Maintained where
  name  : String
  var   : String
  defn  : List Atom
  stmts : List Nat := []
  deriving Repr, Inhabited, BEq

/-- Part of the line the agent writes when a real action completes. -/
inductive Say where
  | text   : String → Say
  | handle : String → Say           -- the handle of a variable's object
  | prop   : String → String → Say  -- a property of a variable's object
  deriving Repr, Inhabited, BEq

/-- An action the agent can take: proposed whenever `pre` holds (statement form "You can ..."). -/
structure Op where
  name   : String
  /-- argument1, argument2, ... in order: variable and required type (`none`: any object). -/
  params : List (String × Option String)
  pre    : List Atom
  /-- Bound in the state before the action, after the parameters (for example the bank the boat
  leaves); must have exactly one match. -/
  bind   : List Atom := []
  effects : List Eff
  /-- What the agent writes when the real action completes: literal text and variables, in order. -/
  report : List Say := []
  stmts  : List Nat := []
  /-- The operator's cost in look-ahead (`^step-cost`, read by the library when the task sets
  `cost-metric unit`, for example with `iterative-step cost`): a constant or a property of a bound
  object, such as the minutes a crossing takes. `none`: the library's unit cost. -/
  stepCost : Option Rhs := none
  deriving Repr, Inhabited, BEq

/-- A losing condition: the state is marked ^failure (statement form "If ... then you lose"). -/
structure Failure where
  name  : String
  cond  : Cond
  stmts : List Nat := []
  deriving Repr, Inhabited, BEq

inductive AssumptionKind where
  | intent | gap | tooling
  deriving DecidableEq, Repr, Inhabited, BEq

/-- An assumption-ledger entry. `intent`: the English was open and a reading was chosen; `gap` and
`tooling` must be raised with the user before the description is used (CLAUDE.md, issue 6). -/
structure Assumption where
  id    : String
  kind  : AssumptionKind
  text  : String
  stmts : List Nat := []
  deriving Repr, Inhabited, BEq

/-- A world object as read from a .world file: its number and attributes (`category` included). -/
structure WObj where
  id    : Nat
  attrs : List (String × Val)
  deriving Repr, Inhabited, BEq

/-- A world file: objects, relations (name, tuples of object numbers). -/
structure WorldFile where
  objs : List WObj
  rels : List (String × List (List Nat))
  deriving Repr, Inhabited

/-- An object of the task's world: handle, type and properties. -/
structure Obj where
  handle : String
  type   : String
  props  : List (String × Val) := []
  deriving Repr, Inhabited, BEq

/-- How the task's world is built from a world file. -/
structure WorldMap where
  /-- The handle of a world-file object. -/
  handle  : WObj → String
  /-- Relations of the world file that are kept, as relation objects. -/
  rels    : List String := ["on", "below"]
  /-- Objects the task adds (the task object is always added). -/
  extra   : WorldFile → List Obj := fun _ => []
  /-- Static relations the task adds, over handles. -/
  extraRels : WorldFile → List (String × List String) := fun _ => []
  deriving Inhabited

/-- Search control stated in the description, not taught in the English (JL, 16 Nov 2026, as for the
river crossings): a look-ahead state whose situation already occurs on its look-ahead path fails, so
the library rejects it (v2.39). The situation is, for every object of `types` in the initial world (in
handle order), the handle of the second argument of its `rel` tuple, for example where each person and
the torch are. Properties such as a clock are not part of it. -/
structure RepeatControl where
  rel   : String
  types : List String
  deriving Repr, Inhabited, BEq

/-- A task description. -/
structure Task where
  name        : String
  title       : String
  /-- Instructor statements, numbered as in english-input.txt. -/
  statements  : List (Nat × String)
  world       : WorldMap
  maintained  : List Maintained := []
  sums        : List SumDef := []
  ops         : List Op
  goal        : Cond
  goalStmts   : List Nat := []
  failures    : List Failure := []
  assumptions : List Assumption := []
  /-- Flag values that differ from the library defaults (`^flag-override`). -/
  flags       : List (String × String) := []
  repeatControl : Option RepeatControl := none
  deriving Inhabited

end WorldSpec
