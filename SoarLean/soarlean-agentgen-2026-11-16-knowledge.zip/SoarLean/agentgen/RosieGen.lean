import WorldSpec
import Lean.Data.Json
/-!
`rosiegen`: the WorldSpec tools for the Rosie dialogs.

    rosiegen check   TASK WORLD            goal, losing conditions and maintained relations in a world file
    rosiegen replay  TASK WORLD RUN.json   replay a run's actions (run_agent.py --json) in the semantics
    rosiegen compile TASK WORLD OUT.soar   path A: Lean writes the task rules
    rosiegen json    TASK WORLD OUT.json   path B: the description, evaluated on the world, for spec_backend.py

TASK: tower-of-hanoi, goose-fox-beans, color-ken-ken, monkey-and-bananas, vacuum-world, tower-of-london, instant-insanity, bridge-and-torch, cheryls-birthday, muddy-children.
-/
open WorldSpec Lean

def tasks : List Task := [Tasks.hanoi, Tasks.fox, Tasks.kenken, Tasks.monkeyBananas, Tasks.vacuumWorld, Tasks.towerOfLondon, Tasks.instantInsanity, Tasks.bridgeAndTorch, Tasks.cherylsBirthday, Tasks.muddyChildren]

def loadWorld (path : String) : IO WorldFile := do
  let text ← IO.FS.readFile path
  match parseWorld (text.replace "\r" "") with
  | .ok wf => pure wf
  | .error e => throw (IO.userError e)

def findTask (n : String) : IO Task :=
  match tasks.find? (·.name == n) with
  | some t => pure t
  | none => throw (IO.userError s!"unknown task {n}")

def checkCmd (t : Task) (wf : WorldFile) : IO Unit := do
  let st := t.initial wf
  IO.println (Json.compress (Json.mkObj [("goal-met", toJson (t.goalMet st)), ("failure", toJson (t.failed st)),
    ("maintained-errors", toJson (t.maintainedErrors st))]))

def replayCmd (t : Task) (wf : WorldFile) (runPath : String) : IO Unit := do
  let j ← IO.ofExcept (Json.parse (← IO.FS.readFile runPath))
  let acts ← IO.ofExcept (j.getObjValAs? (List (List String)) "actions")
  let outcome := (j.getObjValAs? String "outcome").toOption.getD "?"
  let mut st := t.initial wf
  let mut n := 0
  for a in acts do
    n := n + 1
    match a with
    | name :: args =>
      match t.apply st name args with
      | .ok st' =>
        st := st'
        let errs := t.maintainedErrors st
        if !errs.isEmpty then
          IO.println s!"{outcome}, {acts.length} actions: action {n} breaks a maintained relation: {errs}"; return
        let f := t.failed st
        if !f.isEmpty then
          IO.println s!"{outcome}, {acts.length} actions: action {n} reaches a losing state ({f})"; return
      | .error e => IO.println s!"{outcome}, {acts.length} actions: action {n} illegal: {e}"; return
    | [] => pure ()
  IO.println s!"{outcome}, {acts.length} actions: {if t.goalMet st then "goal holds" else "goal does not hold"}"

def main (args : List String) : IO UInt32 := do
  match args with
  | ["check", tn, w] => checkCmd (← findTask tn) (← loadWorld w); pure 0
  | ["replay", tn, w, r] => replayCmd (← findTask tn) (← loadWorld w) r; pure 0
  | ["compile", tn, w, out] =>
    match compile (← findTask tn) (← loadWorld w) with
    | .ok text => IO.FS.writeFile out text; IO.println s!"wrote {out}"; pure 0
    | .error e => IO.eprintln e; pure 1
  | ["json", tn, w, out] =>
    IO.FS.writeFile out ((Task.toJ (← findTask tn) (← loadWorld w)).pretty ++ "\n"); IO.println s!"wrote {out}"; pure 0
  | ["explore", tn, w, lim] =>
    let t ← findTask tn
    let (d, n, errs) := t.explore (t.initial (← loadWorld w)) lim.toNat!
    IO.println s!"shortest plan: {match d with | some k => toString k ++ " actions" | none => "none found"}; {n} states; {errs.length} errors"
    for e in errs.take 10 do IO.println s!"  {e}"
    pure 0
  | _ => IO.eprintln "usage: rosiegen check|replay|compile|json TASK WORLD [FILE]"; pure 1
