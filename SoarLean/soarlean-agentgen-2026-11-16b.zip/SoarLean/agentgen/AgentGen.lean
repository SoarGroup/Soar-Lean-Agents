import Agent
import Lean.Data.Json
/-! `agentgen FAMILY OUT.json`: the generated projects of a family as JSON (files with Soar text,
commands, the English, and which originals each variant replaces). `tools/vsproject.py` writes
them out as VisualSoar projects. -/
open Agent Lean

def schemaJson (s : Schema) : Json :=
  let attr (d : AttrDecl) : Json := Json.mkObj [("name", d.name), ("multi", d.multi), ("derived", d.derived),
    ("doc", d.doc), ("type", match d.ty with
      | .int => Json.mkObj [("kind", "int")]
      | .sym cs => Json.mkObj [("kind", "sym"), ("choices", Json.arr (cs.map Json.str).toArray)]
      | .obj t => Json.mkObj [("kind", "obj"), ("type", t)])]
  Json.mkObj [("task", s.task), ("state", Json.arr (s.stateAttrs.map attr).toArray),
    ("types", Json.arr (s.types.map fun t => Json.mkObj [("name", t.name), ("doc", t.doc),
      ("attrs", Json.arr (t.attrs.map attr).toArray)]).toArray)]

def variantJson (name : String) (a : Agent) (replaces : List String) : Json :=
  let files := (compile a).map fun f => Json.mkObj [("path", f.path), ("kind", f.kind),
    ("rules", Json.arr (f.prods.map fun p => Json.str p.toSoar).toArray),
    ("cmds", Json.arr (f.cmds.map Json.str).toArray)]
  Json.mkObj [("name", name), ("task", a.schema.task), ("replaces", Json.arr (replaces.map Json.str).toArray),
    ("selection", needsSelection a), ("check", Json.arr ((check a).map Json.str).toArray),
    ("english", english a), ("schema", schemaJson a.schema),
    ("ops", Json.arr (a.ops.map fun o => Json.str o.name).toArray),
    ("files", Json.arr files.toArray)]

/-! `agentgen water-jug-desc OUT.json`: the description itself (objects, derivations, operators with
guards and effects, goal, constraints, look-ahead method, assumptions), for back-ends that generate
Soar under other conventions (the world conventions: worldgen/world_backend.py). -/
def jarr {α : Type} (f : α → Json) (l : List α) : Json := Json.arr (l.map f).toArray
def exprJson : Expr → Json
  | .lit n => Json.mkObj [("k", "lit"), ("n", toJson n)]
  | .get o a => Json.mkObj [("k", "get"), ("obj", o), ("attr", a)]
  | .add a b => Json.mkObj [("k", "add"), ("a", exprJson a), ("b", exprJson b)]
  | .sub a b => Json.mkObj [("k", "sub"), ("a", exprJson a), ("b", exprJson b)]
def atomJson : Atom → Json
  | .lit n => Json.mkObj [("k", "lit"), ("n", toJson n)]
  | .get o a => Json.mkObj [("k", "get"), ("obj", o), ("attr", a)]
def cmpStr : Cmp → String
  | .eq => "=" | .ne => "<>" | .lt => "<" | .le => "<=" | .gt => ">" | .ge => ">="
def guardJson : Guard → Json
  | .cmp o a op r => Json.mkObj [("k", "cmp"), ("obj", o), ("attr", a), ("op", cmpStr op), ("rhs", atomJson r)]
  | .distinct a b => Json.mkObj [("k", "distinct"), ("a", a), ("b", b)]
  | .holds a p => Json.mkObj [("k", "holds"), ("attr", a), ("p", p)]
  | .unset a => Json.mkObj [("k", "unset"), ("attr", a)]
def patJson (p : ObjPat) : Json := Json.mkObj (p.map fun (a, v) => (a, toJson v))
def caseJson (c : Case) : Json := Json.mkObj [("guard", jarr guardJson c.guard),
  ("effects", jarr (fun (e : Effect) => Json.mkObj [("obj", e.obj), ("attr", e.attr), ("val", exprJson e.val)]) c.effects)]
def opJson (o : Operator) : Json := Json.mkObj [("name", o.name), ("doc", o.doc),
  ("params", jarr (fun (p : String × String) => Json.mkObj [("name", p.1), ("type", p.2)]) o.params),
  ("propose", jarr guardJson o.propose), ("apply", jarr caseJson o.apply),
  ("atomic", toJson (o.impl == .atomic))]
def statePatJson (p : StatePat) : Json := Json.mkObj [("type", p.ty), ("objs", jarr patJson p.objs)]
def methodJson : Method → Json
  | .random => Json.mkObj [("k", "random")]
  | .tieHeuristic _ => Json.mkObj [("k", "tie-heuristic")]
  | .lookahead avoid v => Json.mkObj [("k", "lookahead"), ("avoid", jarr statePatJson avoid),
      ("avoidValue", match v with | some n => toJson n | none => Json.null)]
  | .rl _ => Json.mkObj [("k", "rl")]
def descJson (name : String) (a : Agent) : Json := Json.mkObj [("name", name), ("schema", schemaJson a.schema),
  ("keys", Json.mkObj (a.schema.types.map fun t => (t.name, match t.key with | some k => Json.str k | none => Json.null))),
  ("init", jarr (fun (p : String × ObjPat) => Json.mkObj [("holder", p.1), ("vals", patJson p.2)]) a.init),
  ("derive", jarr (fun (d : Derive) => Json.mkObj [("type", d.ty), ("attr", d.attr), ("val", exprJson d.val)]) a.derive),
  ("ops", jarr opJson a.ops), ("goal", Json.mkObj [("type", a.goal.ty), ("vals", patJson a.goal.vals)]),
  ("constraints", jarr (fun (c : Constraint) => Json.mkObj [("type", c.ty), ("guard", jarr guardJson c.guard), ("doc", c.doc)]) a.constraints),
  ("method", methodJson a.method),
  ("assumptions", jarr (fun (s : Assumption) => Json.mkObj [("id", s.id), ("text", s.text), ("status", s.status)]) a.assumptions),
  ("english", english a), ("check", jarr Json.str (check a))]

def main (args : List String) : IO Unit := do
  match args with
  | ["water-jug", out] =>
    let vs := WaterJug.variants.map fun (n, a, r) => variantJson n a r
    IO.FS.writeFile out (Json.arr vs.toArray).pretty
    IO.println s!"{vs.length} variants written to {out}"
  | ["water-jug-desc", out] =>
    let vs := WaterJug.variants.map fun (n, a, _) => descJson n a
    IO.FS.writeFile out (Json.arr vs.toArray).pretty
    IO.println s!"{vs.length} descriptions written to {out}"
  | _ => IO.eprintln "usage: agentgen water-jug OUT.json | agentgen water-jug-desc OUT.json"
