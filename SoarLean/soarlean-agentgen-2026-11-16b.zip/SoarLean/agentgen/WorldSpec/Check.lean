import WorldSpec.Types
/-!
# Well-formedness of a WorldSpec description

`Task.wellFormed` lists what would make a description unusable; a description is checked by proving
that the list is empty (`by decide`, below for each task). The checks:
* W-CHK-009: no negation (`lacks`, `none`) in any compiled condition: operator preconditions and
  bindings, losing conditions and the goal. Negations may appear only in a maintained relation's
  definition, which is evaluated in Lean, not compiled.
* Effects and report lines use only the operator's parameters and the variables its binding condition
  binds (they are all the effect rules can see); a reported handle must be a parameter's.
* Issue 6 (CLAUDE.md): no assumption of kind `gap` or `tooling` remains open in the ledger.
-/
namespace WorldSpec

def Arg.vars : Arg → List String
  | .var x => [x]
  | .h _ => []

def Atom.vars : Atom → List String
  | .obj x _ => [x]
  | .has x _ _ r => x :: (match r with | .prop y _ => [y] | .val _ => [])
  | .rel _ as => as.flatMap Arg.vars
  | .distinct x y => [x, y]
  | .lacks x _ => [x]
  | .none _ => []

def Atom.isNeg : Atom → Bool
  | .lacks .. => true
  | .none .. => true
  | _ => false

def Cond.atoms : Cond → List Atom
  | .ex as => as
  | .all fa => fa.outer ++ fa.filter ++ fa.body

def Eff.vars : Eff → List String
  | .set x _ r => x :: (match r with | .prop y _ => [y] | .val _ => [])
  | .add _ as => as.flatMap Arg.vars
  | .del _ as => as.flatMap Arg.vars
  | .change _ as _ to => as.flatMap Arg.vars ++ to.vars

def Op.check (o : Op) : List String :=
  let ps := o.params.map (·.1)
  let seen := ps ++ o.bind.flatMap Atom.vars
  let neg := ((o.pre ++ o.bind).filter Atom.isNeg).map fun _ => s!"{o.name}: negation in a compiled condition (W-CHK-009)"
  let eff := (o.effects.flatMap Eff.vars).filter (!seen.contains ·) |>.map fun x => s!"{o.name}: effect uses {x}, not bound"
  let rep := o.report.filterMap fun s => match s with
    | .handle x => if ps.contains x then Option.none else some s!"{o.name}: reports the handle of {x}, not a parameter"
    | .prop x _ => if seen.contains x then Option.none else some s!"{o.name}: reports {x}, not bound"
    | .text _ => Option.none
  neg ++ eff ++ rep

def Task.wellFormed (t : Task) : List String :=
  t.ops.flatMap Op.check ++
  ((t.failures.flatMap fun f => (f.cond.atoms.filter Atom.isNeg).map fun _ => s!"failure {f.name}: negation (W-CHK-009)")) ++
  ((t.goal.atoms.filter Atom.isNeg).map fun _ => "goal: negation (W-CHK-009)") ++
  ((t.assumptions.filter (·.kind != .intent)).map fun a => s!"assumption {a.id} is open ({repr a.kind}): raise it with the user")

end WorldSpec
