import WorldSpec.Check
import WorldSpec.Tasks.Hanoi
import WorldSpec.Tasks.Fox
import WorldSpec.Tasks.KenKen
/-! The three Rosie descriptions are well formed (WorldSpec/Check.lean). -/
namespace WorldSpec.Tasks

theorem hanoi_wellFormed : hanoi.wellFormed = [] := by decide
theorem fox_wellFormed : fox.wellFormed = [] := by decide
theorem kenken_wellFormed : kenken.wellFormed = [] := by decide

end WorldSpec.Tasks
