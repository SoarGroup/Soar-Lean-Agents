# WorldSpec: Rosie dialogs to Soar through Lean (16 November 2026)

**Runnable.** `lake build rosiegen` (Lean 4.35.0; the `cmcsoar` release beside `agentgen`, as for the other
targets; WorldSpec imports nothing from it). Three Rosie tasks are described: Tower of Hanoi, fox-goose-bean and
KenKen (color groups).

## What it is

A typed description of a task stated the way the Rosie teaching dialogs state it: actions legal when a condition
holds, a goal condition, losing conditions. `World.Task` (World/Types.lean) cannot express these (no losing
conditions, no comparisons, joins or sums in conditions, operators only proposed by means-ends analysis), so
WorldSpec is a separate description language next to it.

| File | Contents |
|---|---|
| `Types.lean` | The description: objects from a world file (`WorldMap`), conditions (`Atom`, `Cond`: property tests with comparisons, relation tuples, distinct objects, universal conditions, and negations for definitions only), maintained relations with their definitions, sums, operators (precondition, binding, effects, report), losing conditions, goal, assumption ledger (kinds intent, gap, tooling), statement numbers on every element. |
| `Sem.lean` | Semantics: condition evaluation, operator application, the initial state from a world file (maintained relations computed from their definitions), losing and goal tests, maintained-relation consistency, breadth-first search for a shortest plan. |
| `WorldFile.lean` | Reader for Rosie `.world` files (red1 -> red, 4.0 -> 4). |
| `Check.lean`, `Proofs.lean` | `Task.wellFormed`: no negation in a compiled condition (W-CHK-009); effects and reports use only bound variables; no open `gap` or `tooling` assumption (CLAUDE.md issue 6). Proved `= []` by `decide` for the three tasks. |
| `Compile.lean` | Path A: the Soar task rules, written by Lean. |
| `Json.lean` | Path B: the description with its initial world evaluated, as JSON for `worldgen/spec_backend.py`. |
| `Tasks/Hanoi.lean`, `Tasks/Fox.lean`, `Tasks/KenKen.lean` | The three descriptions, with the instructor statements and assumption ledgers. |
| `../RosieGen.lean` | The `rosiegen` executable. |

## Commands

    rosiegen check   TASK WORLD            goal, losing conditions, maintained-relation errors in a world file
    rosiegen replay  TASK WORLD RUN.json   replay an agent's actions (run_agent.py --json) in the semantics
    rosiegen explore TASK WORLD LIMIT      shortest plan by breadth-first search; checks every effect on the way
    rosiegen compile TASK WORLD OUT.soar   path A: Lean writes the task rules
    rosiegen json    TASK WORLD OUT.json   path B input; then: python3 ../worldgen/spec_backend.py OUT.json RULES.soar

TASK: `tower-of-hanoi`, `goose-fox-beans`, `color-ken-ken`.

## The two paths

- **A (Lean writes the rules).** `Compile.lean` follows the emission scheme written at its top (the rule shapes of
  `wg.py` and the Rosie pilot generators).
- **B (Lean describes, Python writes).** `spec_backend.py` follows the same scheme from the JSON.

For the three tasks the two outputs are identical apart from the first header line, so path B is a second,
independent implementation of path A's compiler and each checks the other. Results against the direct agents are in
`Tasks/From-English/rosie-teaching/LEAN-PATHS.md`.

## Limits

- Universal conditions are compiled by expansion over the initial world's objects of the type, so objects must not
  be created or destroyed; a filter on a universal condition is not compiled yet.
- `set` assumes the property is absent before the action (checked in the semantics).
- Sums need `^size` on the owner (checked against the member count when compiling).
- Path control for river crossings, counted attributes (missionaries and cannibals) and line sums with clue objects
  (kakuro, shuffle, survo) are not in the language yet.
- The report line can name a parameter's handle or a bound property only.
