import WorldSpec.Sem
import WorldSpec.WorldFile
/-! Fox, goose and beans (rosie-teaching/river-crossing-puzzles/fox-goose-bean). -/
namespace WorldSpec.Tasks
open WorldSpec

def foxBoatMoves : List Eff :=
  [.change "on" [.var "boat", .var "old"] 2 (.var "opp"),
   .change "below" [.var "old", .var "boat"] 1 (.var "opp"),
   .del "opposite" [.var "opp"], .add "opposite" [.var "old"]]

def foxHandle (o : WObj) : String :=
  if o.sym "category" == "location" then "bank-" ++ toString o.id
  else if o.sym "shape" != "" then o.sym "shape" ++ "-" ++ toString o.id
  else o.sym "color" ++ "-" ++ toString o.id

def fox : Task where
  name := "goose-fox-beans"
  title := "Fox, goose and beans (goose-fox-beans)"
  statements := [
    (4, "The name of an action is ferry-one."),
    (5, "You can move the boat and a block on the current bank onto the opposite bank."),
    (6, "If an object is below a boat then it is current."),
    (7, "If a location is not below a boat then it is opposite."),
    (8, "You can move a boat onto the opposite bank."),
    (10, "If a red block is on an opposite bank and a yellow block is on the opposite bank then you lose."),
    (13, "If a green block is on an opposite bank and a yellow block is on the opposite bank then you lose."),
    (18, "The goal is that all the blocks are on a destination bank.")]
  world := { handle := foxHandle }
  -- Statement 7: a location not below a boat.
  maintained := [{ name := "opposite", var := "x", stmts := [7], defn := [.obj "x" (some "location"), .none [.rel "below" [.var "x", .var "bt"], .has "bt" "shape" .eq (.val (.sym "boat"))]] }]
  ops := [
    { name := "ferry-one", params := [("x", some "block"), ("opp", some "location")], stmts := [5, 6]
      -- Statement 5, with current (6) expanded in place; A-F1: the block is not the boat.
      pre := [.obj "boat" (some "block"), .has "boat" "shape" .eq (.val (.sym "boat")), .distinct "x" "boat",
              .rel "below" [.var "cur", .var "boat"], .rel "on" [.var "x", .var "cur"], .rel "opposite" [.var "opp"]]
      bind := [.obj "boat" (some "block"), .has "boat" "shape" .eq (.val (.sym "boat")),
               .rel "on" [.var "boat", .var "old"], .rel "below" [.var "old", .var "boat"],
               .rel "on" [.var "x", .var "old"], .rel "below" [.var "old", .var "x"]]
      -- A-F2: the boat and the block both move.
      effects := foxBoatMoves ++ [.change "on" [.var "x", .var "old"] 2 (.var "opp"),
                                  .change "below" [.var "old", .var "x"] 1 (.var "opp")]
      report := [.text "Ferry boat and ", .handle "x", .text " onto ", .handle "opp"] },
    { name := "cross", params := [("boat", some "block"), ("opp", some "location")], stmts := [8]
      pre := [.has "boat" "shape" .eq (.val (.sym "boat")), .rel "opposite" [.var "opp"]]
      bind := [.rel "on" [.var "boat", .var "old"], .rel "below" [.var "old", .var "boat"]]
      effects := foxBoatMoves
      report := [.text "Cross with the boat alone onto ", .handle "opp"] }]
  -- Statement 18 (A-F3, A-F4): every block, the boat included, is on the bank named destination.
  goal := .all { outer := [.obj "dest" (some "location"), .has "dest" "name" .eq (.val (.sym "destination"))],
                 var := "x", type := "block", body := [.rel "on" [.var "x", .var "dest"]] }
  goalStmts := [18]
  failures := [
    { name := "red-and-yellow-on-opposite-bank", stmts := [10],
      cond := .ex [.obj "r" (some "block"), .has "r" "color" .eq (.val (.sym "red")),
                   .obj "y" (some "block"), .has "y" "color" .eq (.val (.sym "yellow")),
                   .obj "b" (some "location"), .rel "opposite" [.var "b"], .rel "on" [.var "r", .var "b"], .rel "on" [.var "y", .var "b"]] },
    { name := "green-and-yellow-on-opposite-bank", stmts := [13],
      cond := .ex [.obj "g" (some "block"), .has "g" "color" .eq (.val (.sym "green")),
                   .obj "y" (some "block"), .has "y" "color" .eq (.val (.sym "yellow")),
                   .obj "b" (some "location"), .rel "opposite" [.var "b"], .rel "on" [.var "g", .var "b"], .rel "on" [.var "y", .var "b"]] }]
  assumptions := [
    { id := "A-F1", kind := .intent, stmts := [5], text := "\"the boat and a block\": the block is not the boat." },
    { id := "A-F2", kind := .intent, stmts := [5], text := "Both the boat and the block move to the opposite bank." },
    { id := "A-F3", kind := .intent, stmts := [18], text := "\"all the blocks\" includes the boat, which is a block in the world file." },
    { id := "A-F4", kind := .intent, stmts := [18], text := "\"all the blocks\" ranges over the blocks of the world file (compiled by expansion, so the test is positive)." },
    { id := "A-F5", kind := .intent, stmts := [8], text := "The second action has no name in the dialog; it is called cross." },
    { id := "A-F6", kind := .intent, stmts := [10, 13], text := "\"on an opposite bank ... on the opposite bank\": both blocks on the same bank." }]

end WorldSpec.Tasks
