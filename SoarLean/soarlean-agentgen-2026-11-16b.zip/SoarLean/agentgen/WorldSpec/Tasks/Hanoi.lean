import WorldSpec.Sem
import WorldSpec.WorldFile
/-! Tower of Hanoi (rosie-teaching/block-puzzles/tower-of-hanoi), from the instructor's statements. -/
namespace WorldSpec.Tasks
open WorldSpec

def hanoi : Task where
  name := "tower-of-hanoi"
  title := "Tower of Hanoi (tower-of-hanoi)"
  statements := [
    (4, "You can move a clear block onto a clear object that is larger than the block."),
    (5, "If a location is not below an object then it is clear."),
    (6, "If the volume of a block is more than the volume of an object then the block is larger than the object."),
    (8, "The goal is that there are two clear green locations.")]
  world := { handle := fun o => s!"{o.sym "category"}-{o.id}" }
  -- Statement 5 (A-H1: for every object): x is clear when x is not below any object.
  maintained := [{ name := "clear", var := "x", defn := [.none [.rel "below" [.var "x", .var "y"]]], stmts := [5] }]
  ops := [{
    name := "move", params := [("b", some "block"), ("d", none)]
    -- Statement 4, with 6 expanded in place (A-H2): d's volume is more than b's.
    pre := [.rel "clear" [.var "b"], .rel "clear" [.var "d"], .has "d" "volume" .gt (.prop "b" "volume")]
    -- A-H4: the object the block leaves.
    bind := [.rel "on" [.var "b", .var "old"], .rel "below" [.var "old", .var "b"]]
    effects := [.change "on" [.var "b", .var "old"] 2 (.var "d"),
                .change "below" [.var "old", .var "b"] 1 (.var "d"),
                .del "clear" [.var "d"], .add "clear" [.var "old"]]
    report := [.text "Move ", .handle "b", .text " onto ", .handle "d"]
    stmts := [4, 6] }]
  -- Statement 8 (A-H3): two different green locations, both clear.
  goal := .ex [.obj "l1" (some "location"), .has "l1" "color" .eq (.val (.sym "green")),
               .obj "l2" (some "location"), .has "l2" "color" .eq (.val (.sym "green")),
               .distinct "l1" "l2", .rel "clear" [.var "l1"], .rel "clear" [.var "l2"]]
  goalStmts := [8]
  assumptions := [
    { id := "A-H1", kind := .intent, stmts := [5], text := "\"clear\" is defined for a location but used for \"a clear block\": any object that is not below an object is clear." },
    { id := "A-H2", kind := .intent, stmts := [6], text := "\"larger than\": X is larger than Y when X's volume is more than Y's." },
    { id := "A-H3", kind := .intent, stmts := [8], text := "\"two clear green locations\": two different green locations, both clear." },
    { id := "A-H4", kind := .intent, stmts := [4], text := "Moving X onto Y: X's on relation and the matching below relation now name Y; the object X left becomes clear." },
    { id := "A-H5", kind := .intent, stmts := [4], text := "The action has no name in the dialog; it is called move." }]

end WorldSpec.Tasks
