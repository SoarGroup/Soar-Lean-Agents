import WorldSpec.Sem
import WorldSpec.WorldFile
/-! KenKen with color groups (rosie-teaching/logic-puzzles/kenken; puzzle name color-ken-ken). -/
namespace WorldSpec.Tasks
open WorldSpec

/-- The colors of the world's locations, in order of first appearance. -/
def kenColors (wf : WorldFile) : List String :=
  (wf.objs.filter (·.sym "category" == "location")).foldl (fun acc o =>
    let c := o.sym "color"; if c == "" || acc.contains c then acc else acc ++ [c]) []

def kenLoc (o : WObj) : String :=
  if o.sym "category" == "location" then "loc-" ++ o.sym "row" ++ "-" ++ o.sym "column" else "block-" ++ toString o.id

def kenMembers (wf : WorldFile) (c : String) : List WObj :=
  wf.objs.filter fun o => o.sym "category" == "location" && o.sym "color" == c

def kenNumber (k : Nat) : Obj :=
  { handle := "number-" ++ toString k, type := "number", props := [("number", .int k)] }

def kenGroup (wf : WorldFile) (c : String) : Obj :=
  { handle := "group-" ++ c, type := "group",
    props := [("size", .int (kenMembers wf c).length), ("target-value", .int 10)] }

def kenExtra (wf : WorldFile) : List Obj :=
  ((List.range 4).map fun k => kenNumber (k + 1)) ++ (kenColors wf).map (kenGroup wf)

def sameValue (name attr : String) (stmts : List Nat) : Failure :=
  { name, stmts, cond := .ex [.obj "l1" (some "location"), .obj "l2" (some "location"), .distinct "l1" "l2",
      .has "l1" attr .eq (.prop "l2" attr), .has "l1" "value" .eq (.prop "l2" "value")] }

def kenken : Task where
  name := "color-ken-ken"
  title := "KenKen (color groups)"
  statements := [
    (5, "You can write a number that is between one and four onto an empty location."),
    (6, "If the value of a location is absent then the location is empty."),
    (11, "If the row of a location is the row of a location and the value of the former location is the value of the latter location then you lose."),
    (14, "If the column of a location is the column of a location and the value of the former location is the value of the latter location then you lose."),
    (18, "The goal is that all locations are filled."),
    (19, "If the value of a location is more than zero then the location is filled."),
    (23, "If the locations in a group are filled and the sum of the values of the group is not ten then you lose."),
    (24, "If the blocks have the same color then they are in a group.")]
  world := {
    handle := kenLoc
    -- Statement 5: the numbers one to four are objects (operator arguments are objects).
    extra := kenExtra
    -- Statement 24: the locations of one color are a group.
    extraRels := fun wf => (kenColors wf).flatMap fun c =>
      (kenMembers wf c).map fun o => ("member", ["group-" ++ c, kenLoc o]) }
  -- Statement 6.
  maintained := [{ name := "empty", var := "x", defn := [.obj "x" (some "location"), .lacks "x" "value"], stmts := [6] }]
  sums := [{ attr := "sum", ownerType := "group", rel := "member", prop := "value" }]
  ops := [{ name := "write", params := [("l", some "location"), ("n", some "number")], stmts := [5]
            pre := [.rel "empty" [.var "l"]]
            effects := [.set "l" "value" (.prop "n" "number"), .del "empty" [.var "l"]]
            report := [.text "Write ", .prop "n" "number", .text " on ", .handle "l"] }]
  -- Statements 18 and 19: every location has a value more than zero.
  goal := .all { var := "x", type := "location", body := [.has "x" "value" .gt (.val (.int 0))] }
  goalStmts := [18, 19]
  failures := [sameValue "same-row-value" "row" [11], sameValue "same-column-value" "column" [14],
    { name := "group-sum-constant", stmts := [23],
      cond := .ex [.obj "g" (some "group"), .has "g" "sum" .ne (.prop "g" "target-value")] }]
  assumptions := [
    { id := "A-L1", kind := .intent, stmts := [11, 14], text := "\"a location ... a location ... the former ... the latter\" are two different locations." },
    { id := "A-K1", kind := .intent, stmts := [24], text := "group: the locations with the same color; each must sum to ten when filled." },
    { id := "A-K2", kind := .intent, stmts := [5], text := "The action write takes the location and a number object number-1 .. number-4 (operator arguments are objects)." }]

end WorldSpec.Tasks
