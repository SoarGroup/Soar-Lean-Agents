import WorldSpec.Types
/-!
# Reading a Rosie .world file

Blocks separated by blank lines: `objid N` followed by `attribute value` lines, or `predicate NAME`
followed by `a b` lines (object numbers). Values: a number becomes an integer (4.0 → 4); a symbol
loses Rosie's trailing sense number 1 (red1 → red, on1 → on), as in tools/rosie-language.md.
-/
namespace WorldSpec

def dropLast (s : String) (n : Nat) : String := String.ofList (s.toList.take (s.length - n))
def trimS (s : String) : String :=
  String.ofList ((s.toList.dropWhile Char.isWhitespace).reverse.dropWhile Char.isWhitespace).reverse

def stripSense (s : String) : String := if s.endsWith "1" then dropLast s 1 else s

def parseVal (s : String) : Val :=
  let t := if s.endsWith ".0" then dropLast s 2 else s
  match t.toInt? with
  | some i => .int i
  | none => .sym (stripSense s)

def parseWorld (text : String) : Except String WorldFile := do
  let blocks := (text.splitOn "\n\n").map fun b =>
    ((b.splitOn "\n").map fun l => ((trimS l).splitOn " ").filter (· != "")).filter (!·.isEmpty)
  let mut objs : List WObj := []
  let mut rels : List (String × List (List Nat)) := []
  for blk in blocks do
    match blk with
    | ["objid", n] :: rest =>
      let some i := n.toNat? | throw s!"bad objid {n}"
      let attrs := rest.filterMap fun l => match l with
        | [a, v] => some (a, parseVal v)
        | _ => none
      objs := objs ++ [{ id := i, attrs }]
    | ["predicate", r] :: rest =>
      let tups := rest.filterMap fun l => (l.mapM String.toNat?)
      let name := stripSense r
      rels := match rels.lookup name with
        | some old => (rels.filter (·.1 != name)) ++ [(name, old ++ tups)]
        | none => rels ++ [(name, tups)]
    | [] => pure ()
    | _ => pure ()
  pure { objs, rels }

def WObj.attr? (o : WObj) (a : String) : Option Val := o.attrs.lookup a
def WObj.sym (o : WObj) (a : String) : String :=
  match o.attr? a with
  | some v => v.toSoar
  | none => ""

end WorldSpec
