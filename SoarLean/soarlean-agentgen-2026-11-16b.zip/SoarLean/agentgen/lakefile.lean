import Lake
open Lake DSL

package agentgen

-- The Lean release (soar-lean). Unzip cmcsoar-release-2026-11-14.zip so that its `cmcsoar`
-- folder sits beside this `agentgen` folder, or change this path.
require cmcsoar from "../cmcsoar"

@[default_target]
lean_lib Agent

lean_exe agentgen where
  root := `AgentGen

lean_lib World

lean_exe worldcheck where
  root := `WorldCheck

lean_lib WorldSpec

lean_exe rosiegen where
  root := `RosieGen
