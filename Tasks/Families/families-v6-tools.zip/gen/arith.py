"""arithmetic family, world-v6.  Problem, columns, digits and arithmetic facts are world objects (facts named by
handles such as add-3-4); process-column is a composite task operator whose implementation substate keeps its
working values (d1, d2, adj, r, cout, ten) on the substate; get-digit2 and borrow are internal operators with
their own implementation substates (^desireds with ^desired-count 0, so agent-world names their problem spaces,
W-COP-007)."""
import re, os
from collections import defaultdict
from v6 import *

ORIG = '/home/claude/w/repo/Tasks/Families/arithmetic/original'
T = 'arithmetic'


def parse(v):
    d = f'{ORIG}/{v}/{v}'
    f = [x for x in os.listdir(d) if x.startswith('initialize')][0]
    t = open(f'{d}/{f}').read()
    rhs = t[t.index('apply*initialize'):]
    rhs = rhs[rhs.index('-->'):]
    attrs = defaultdict(lambda: defaultdict(list)); kind = {}; order = []
    for a, b, c in re.findall(r'\((<[\w-]+>) \^([\w|-]+) ([^)]+)\)', rhs):
        b = b.strip('|'); c = c.strip().strip('|')
        if a == '<s>':
            kind[c] = b; order.append(c)
        else:
            attrs[a][b].append(c)
    goal = re.search(r'\^count (\d+)\)\s*}', rhs)
    return attrs, kind, order


def init_text(v):
    attrs, kind, order = parse(v)
    g = lambda x, k: attrs[x][k][0]
    L = []; objs = []
    for x in order:
        k = kind[x]
        if k not in ('problem', 'column', 'digit', 'add-fact', 'sub-fact', 'inc-fact', 'ten-fact'):
            continue
        a = attrs[x]
        if k == 'problem':
            h = 'problem'; props = ' '.join(f'^{p} {g(x, p)}' for p in ('operation', 'carry', 'count', 'pid', 'digits'))
        elif k == 'column':
            h = f'column{g(x, "pos")}'; props = ' '.join(f'^{p} {g(x, p)}' for p in a if p != 'name')
        elif k == 'digit':
            h = f'digit{g(x, "val")}'; props = f'^val {g(x, "val")}'
        elif k == 'add-fact':
            h = f'add-{g(x, "d1")}-{g(x, "d2")}'; props = ' '.join(f'^|{p}| {g(x, p)}' for p in ('d1', 'd2', 'sum', 'carry'))
        elif k == 'sub-fact':
            h = f'sub-{g(x, "d1")}-{g(x, "d2")}'; props = ' '.join(f'^|{p}| {g(x, p)}' for p in a if p != 'name')
        elif k == 'inc-fact':
            h = f'inc-{g(x, "n")}'; props = ' '.join(f'^{p} {g(x, p)}' for p in a if p != 'name')
        elif k == 'ten-fact':
            h = f'ten-{g(x, "n")}'; props = ' '.join(f'^{p} {g(x, p)}' for p in a if p != 'name')
        var = f'<o{len(objs)}>'; objs.append(var)
        L.append(f'({var} ^object-handle {h} ^anchored true ^type {k} {props})')
    ncols = sum(1 for x in kind.values() if x == 'column')
    L.insert(0, '(<objs> ^object ' + ' '.join(objs) + ')')
    L.append('(<ds> ^desired-count 1 ^desired <d1>)\n(<d1> ^object <d1o>)\n(<d1o> ^object-handle problem ^count 0)')
    return '\n'.join(L), ncols


P = '(state <s> ^problem-space.name arithmetic ^flags.mea-operator-selection true ^desireds.unachieved-desireds true ^world <w>)\n       (<w> ^anchored-world true ^objects.object <p>)\n       (<p> ^type problem'


def top_rules(a, ncols, solve_level=False):
    ps = 'solve-problem' if solve_level else 'arithmetic'
    PP = '(state <s> ^problem-space.name solve-problem ^world <w>)\n       (<w> ^anchored-world true ^objects.object <p>)\n       (<p> ^type problem' if solve_level else P
    if solve_level:
        a.add('solve-problem.soar', f"""
        ## solve-problem <problem> (composite, W-COP-002): once all digits are generated; effect: the last column
        ## is done for this problem.  process-column runs in its implementation substate (problem space
        ## solve-problem).
        sp {{arithmetic*propose*solve-problem
           {P.replace(chr(10) + '       ', chr(10) + '           ')} ^digits {2 * ncols} ^pid <pid>)
           (<w> ^objects.object <c>)
           (<c> ^type column ^pos {ncols} ^done <> <pid>)
        -->
           (<s> ^operator <o> +)
           (<o> ^name solve-problem ^task-operator true ^argument1 <p> ^argument-count 1 ^desireds <pre> ^effect-desireds <ed>)
           (<pre> ^desired-count 0)
           (<ed> ^desired-count 1 ^desired <e1>)
           (<e1> ^object <e1o>)
           (<e1o> ^object-handle column{ncols} ^done <pid>)
        }}
        """)
    a.add('choose-operation.soar', f"""
    ## choose-operation <problem> (1 add, 2 subtract): when no operation is chosen and problems remain.
    sp {{arithmetic*propose*choose-operation
       {P} ^operation 0 ^count > 0)
    -->
       (<s> ^operator <o1> + ^operator <o2> +)
       (<o1> ^name choose-operation ^task-operator true ^action-handle choose-operation ^argument1 <p> ^argument2 1 ^argument-count 2 ^desireds <pre1>)
       (<pre1> ^desired-count 0)
       (<o2> ^name choose-operation ^task-operator true ^action-handle choose-operation ^argument1 <p> ^argument2 2 ^argument-count 2 ^desireds <pre2>)
       (<pre2> ^desired-count 0)
    }}

    sp {{arithmetic*apply*choose-operation*internal
       (state <s> ^operator <o> ^internal-actions true ^world <w>)
       (<o> ^name choose-operation ^pre-conditions-satisfied true ^argument1.object-handle $ <h> ^argument2 <k>)
       (<w> ^anchored-world true ^objects.object <p>)
       (<p> ^object-handle $ <h> ^operation <op> ^carry <c>)
    -->
       (log 1 (crlf) |Choose operation | <k>)
       (<p> ^operation <op> - <k> ^carry <c> - 0)
    }}
    """)
    for n, extra in ((1, ''), (2, '')):
        pass
    a.add('generate-digit.soar', f"""
    ## generate-digit1 <column> <digit>: a random top digit; for subtraction the top digit of the last column is
    ## not 0.  generate-digit2: a random bottom digit; for subtraction the last column's is below its top digit.
    sp {{arithmetic*propose*generate-digit1*add
       {P} ^operation 1 ^pid <pid>)
       (<w> ^objects.object <c> <d>)
       (<c> ^type column ^gen1 <> <pid>)
       (<d> ^type digit)
    -->
       (<s> ^operator <o> +)
       (<o> ^name generate-digit1 ^task-operator true ^action-handle generate-digit1 ^argument1 <c> ^argument2 <d> ^argument-count 2 ^desireds <pre>)
       (<pre> ^desired-count 0)
    }}

    sp {{arithmetic*propose*generate-digit1*sub-inner
       {P} ^operation 2 ^pid <pid>)
       (<w> ^objects.object <c> <d>)
       (<c> ^type column ^gen1 <> <pid> ^last 0)
       (<d> ^type digit)
    -->
       (<s> ^operator <o> +)
       (<o> ^name generate-digit1 ^task-operator true ^action-handle generate-digit1 ^argument1 <c> ^argument2 <d> ^argument-count 2 ^desireds <pre>)
       (<pre> ^desired-count 0)
    }}

    sp {{arithmetic*propose*generate-digit1*sub-last
       {P} ^operation 2 ^pid <pid>)
       (<w> ^objects.object <c> <d>)
       (<c> ^type column ^gen1 <> <pid> ^last 1)
       (<d> ^type digit ^val > 0)
    -->
       (<s> ^operator <o> +)
       (<o> ^name generate-digit1 ^task-operator true ^action-handle generate-digit1 ^argument1 <c> ^argument2 <d> ^argument-count 2 ^desireds <pre>)
       (<pre> ^desired-count 0)
    }}

    sp {{arithmetic*propose*generate-digit2*add
       {P} ^operation 1 ^pid <pid>)
       (<w> ^objects.object <c> <d>)
       (<c> ^type column ^gen1 <pid> ^gen2 <> <pid>)
       (<d> ^type digit)
    -->
       (<s> ^operator <o> +)
       (<o> ^name generate-digit2 ^task-operator true ^action-handle generate-digit2 ^argument1 <c> ^argument2 <d> ^argument-count 2 ^desireds <pre>)
       (<pre> ^desired-count 0)
    }}

    sp {{arithmetic*propose*generate-digit2*sub-inner
       {P} ^operation 2 ^pid <pid>)
       (<w> ^objects.object <c> <d>)
       (<c> ^type column ^gen1 <pid> ^gen2 <> <pid> ^last 0)
       (<d> ^type digit)
    -->
       (<s> ^operator <o> +)
       (<o> ^name generate-digit2 ^task-operator true ^action-handle generate-digit2 ^argument1 <c> ^argument2 <d> ^argument-count 2 ^desireds <pre>)
       (<pre> ^desired-count 0)
    }}

    sp {{arithmetic*propose*generate-digit2*sub-last
       {P} ^operation 2 ^pid <pid>)
       (<w> ^objects.object <c> <d>)
       (<c> ^type column ^gen1 <pid> ^gen2 <> <pid> ^last 1 ^digit1 <top>)
       (<d> ^type digit ^val < <top>)
    -->
       (<s> ^operator <o> +)
       (<o> ^name generate-digit2 ^task-operator true ^action-handle generate-digit2 ^argument1 <c> ^argument2 <d> ^argument-count 2 ^desireds <pre>)
       (<pre> ^desired-count 0)
    }}

    sp {{arithmetic*apply*generate-digit*internal
       (state <s> ^operator <o> ^internal-actions true ^world <w>)
       (<o> ^name {{ << generate-digit1 generate-digit2 >> <n> }} ^pre-conditions-satisfied true ^argument1.object-handle $ <ch> ^argument2.val <v>)
       (<w> ^anchored-world true ^objects.object <c> <p>)
       (<c> ^object-handle $ <ch>)
       (<p> ^type problem ^pid <pid> ^digits <dg>)
    -->
       (<p> ^digits <dg> - (+ <dg> 1))
    }}

    sp {{arithmetic*apply*generate-digit1*internal*column
       (state <s> ^operator <o> ^internal-actions true ^world <w>)
       (<o> ^name generate-digit1 ^pre-conditions-satisfied true ^argument1.object-handle $ <ch> ^argument2.val <v>)
       (<w> ^anchored-world true ^objects.object <c> <p>)
       (<c> ^object-handle $ <ch> ^digit1 <old> ^gen1 <g>)
       (<p> ^type problem ^pid <pid>)
    -->
       (log 1 (crlf) |Digit1 of | <ch> |: | <v>)
       (<c> ^digit1 <old> - <v> ^gen1 <g> - <pid>)
    }}

    sp {{arithmetic*apply*generate-digit1*internal*newd1
       (state <s> ^operator <o> ^internal-actions true ^world <w>)
       (<o> ^name generate-digit1 ^pre-conditions-satisfied true ^argument1.object-handle $ <ch> ^argument2.val <v>)
       (<w> ^anchored-world true ^objects.object <c>)
       (<c> ^object-handle $ <ch> ^newd1 <old>)
    -->
       (<c> ^newd1 <old> - <v>)
    }}

    sp {{arithmetic*apply*generate-digit2*internal*column
       (state <s> ^operator <o> ^internal-actions true ^world <w>)
       (<o> ^name generate-digit2 ^pre-conditions-satisfied true ^argument1.object-handle $ <ch> ^argument2.val <v>)
       (<w> ^anchored-world true ^objects.object <c> <p>)
       (<c> ^object-handle $ <ch> ^digit2 <old> ^gen2 <g>)
       (<p> ^type problem ^pid <pid>)
    -->
       (log 1 (crlf) |Digit2 of | <ch> |: | <v>)
       (<c> ^digit2 <old> - <v> ^gen2 <g> - <pid>)
    }}
    """)
    cols = ' '.join(f'<c{i}>' for i in range(1, ncols + 1))
    ccond = '\n       '.join(f'(<c{i}> ^object-handle $ column{i} ^digit1 <a{i}> ^digit2 <b{i}> ^result <r{i}>)' for i in range(1, ncols + 1))
    top = ' '.join(f'<a{i}>' for i in range(ncols, 0, -1)); bot = ' '.join(f'<b{i}>' for i in range(ncols, 0, -1)); res = ' '.join(f'<r{i}>' for i in range(ncols, 0, -1))
    a.add('process-column.soar', f"""
    ## process-column <column> (composite, W-COP-002): the lowest column not yet done for this problem, once all
    ## {2 * ncols} digits are generated.  Effect: the column is done for this problem (^done <pid>).
    sp {{arithmetic*propose*process-column
       {PP} ^digits {2 * ncols} ^pid <pid>)
       (<w> ^objects.object <c>)
       (<c> ^type column ^pos <pos> ^done <> <pid>)
      -{{(<w> ^objects.object <c2>)
        (<c2> ^type column ^pos < <pos> ^done <> <pid>)}}
    -->
       (<s> ^operator <o> +)
       (<o> ^name process-column ^task-operator true ^argument1 <c> ^argument2 <p> ^argument-count 2 ^desireds <pre> ^effect-desireds <ed>)
       (<pre> ^desired-count 0)
       (<ed> ^desired-count 1 ^desired <e1>)
       (<e1> ^object <e1o>)
       (<e1o> ^object-handle (concat column <pos>) ^done <pid>)
    }}

    ## finish-problem <problem>: every column done: one problem fewer, next pid, digits and operation reset.
    sp {{arithmetic*propose*finish-problem
       {P} ^digits {2 * ncols} ^pid <pid>)
      -{{(<w> ^objects.object <c>)
        (<c> ^type column ^done <> <pid>)}}
    -->
       (<s> ^operator <o> +)
       (<o> ^name finish-problem ^task-operator true ^action-handle finish-problem ^argument1 <p> ^argument-count 1 ^desireds <pre>)
       (<pre> ^desired-count 0)
    }}

    sp {{arithmetic*apply*finish-problem*internal
       (state <s> ^operator <o> ^internal-actions true ^world <w>)
       (<o> ^name finish-problem ^pre-conditions-satisfied true ^argument1.object-handle $ <h>)
       (<w> ^anchored-world true ^objects.object <p> {cols})
       (<p> ^object-handle $ <h> ^count <n> ^pid <pid> ^digits <dg> ^operation <op> ^carry <cy>)
       {ccond}
    -->
       (log 1 (crlf) |problem op | <op> | top | {top} | bottom | {bot} | answer | {res} | carry | <cy>)
       (<p> ^count <n> - (- <n> 1) ^pid <pid> - (+ <pid> 1) ^digits <dg> - 0 ^operation <op> - 0)
    }}
    """)


def column_rules(a, v5=False, smem=None):
    base = """
    ## In process-column's implementation substate (problem space process-column; ^argument1 = column,
    ## ^argument2 = problem, W-SUB-005).  init-local copies the digits and the carry into working values.
    sp {arithmetic*propose*init-local
       (state <s> ^problem-space.name process-column ^argument1 <c> -^|d1|)
    -->
       (<s> ^operator <o> + >)
       (<o> ^name init-local ^task-operator false)
    }

    sp {arithmetic*apply*init-local
       (state <s> ^operator.name init-local ^argument1 <c> ^argument2 <p>)
       (<c> ^digit1 <d1> ^digit2 <d2>)
       (<p> ^carry <cy>)
    -->
       (log 1 (crlf) |Apply init-local.|)
       (<s> ^|d1| <d1> ^|d2| <d2> ^adj (- 1 <cy>) ^r -1 ^cout 0 ^ten 0)
    }

    ## add-digits / subtract-digits: look up the fact for d1 and d2 (facts are world objects).
    sp {arithmetic*propose*add-digits
       (state <s> ^problem-space.name process-column ^argument2.operation 1 ^adj 1 ^r -1 ^|d1| <d1> ^|d2| <d2> ^world <w>)
       (<w> ^objects.object <f>)
       (<f> ^type add-fact ^|d1| <d1> ^|d2| <d2>)
    -->
       (<s> ^operator <o> + =)
       (<o> ^name add-digits ^task-operator false ^fact <f>)
    }

    sp {arithmetic*apply*add-digits
       (state <s> ^operator <o> ^r <r> ^cout <co>)
       (<o> ^name add-digits ^fact <f>)
       (<f> ^sum <sum> ^carry <cy>)
    -->
       (log 1 (crlf) |Apply add-digits: | <sum> | carry | <cy>)
       (<s> ^r <r> - <sum> ^cout <co> - <cy>)
    }

    sp {arithmetic*propose*subtract-digits
       (state <s> ^problem-space.name process-column ^argument2.operation 2 ^adj 1 ^r -1 ^|d1| <d1> ^|d2| <d2> ^world <w>)
       (<w> ^objects.object <f>)
       (<f> ^type sub-fact ^|d1| <d1> ^|d2| <d2>)
    -->
       (<s> ^operator <o> + =)
       (<o> ^name subtract-digits ^task-operator false ^fact <f>)
    }

    sp {arithmetic*apply*subtract-digits
       (state <s> ^operator <o> ^r <r>)
       (<o> ^name subtract-digits ^fact <f>)
       (<f> ^diff <df>)
    -->
       (log 1 (crlf) |Apply subtract-digits: | <df>)
       (<s> ^r <r> - <df>)
    }

    ## write-result <column> <problem>: the result digit to the column and the carry to the problem.
    sp {arithmetic*propose*write-result
       (state <s> ^problem-space.name process-column ^argument1 <c> ^argument2 <p> ^r <> -1)
    -->
       (<s> ^operator <o> + =)
       (<o> ^name write-result ^task-operator true ^action-handle write-result ^argument1 <c> ^argument2 <p> ^argument-count 2 ^desireds <pre>)
       (<pre> ^desired-count 0)
    }

    sp {arithmetic*apply*write-result*internal
       (state <s> ^operator <o> ^internal-actions true ^r <r> ^cout <co> ^world <w>)
       (<o> ^name write-result ^pre-conditions-satisfied true ^argument1.object-handle $ <ch> ^argument2.object-handle $ <ph>)
       (<w> ^anchored-world true ^objects.object <c> <p>)
       (<c> ^object-handle $ <ch> ^result <old> ^done <dn> ^pos <pos> ^digit1 <d1> ^digit2 <d2>)
       (<p> ^object-handle $ <ph> ^carry <cy> ^pid <pid> ^operation <op>)
    -->
       (log 1 (crlf) |column | <pos> | op | <op> |: | <d1> | | <d2> | -> | <r> | carry | <co>)
       (<c> ^result <old> - <r> ^done <dn> - <pid>)
       (<p> ^carry <cy> - <co>)
    }
    """
    if v5:
        base = base.replace("(<c> ^digit1 <d1> ^digit2 <d2>)\n       (<p> ^carry <cy>)", "(<c> ^newd1 <d1> ^digit2 <d2> ^pos <pos>)\n       (<p> ^carry <cy> ^operation <op>)")
        base = base.replace("(<s> ^|d1| <d1> ^|d2| <d2> ^adj (- 1 <cy>) ^r -1 ^cout 0 ^ten 0)", "(<s> ^|d1| <d1> ^|d2| <d2> ^got1 (- 1 <cy>) ^r -1 ^cout 0 ^ten 0 ^nxt (+ <pos> 1) ^issub (- <op> 1))")
        base = base.replace("^argument2.operation 1 ^adj 1 ^r -1", "^argument2.operation 1 ^got1 1 ^r -1")
        base = base.replace("(<s> ^r <r> - <sum> ^cout <co> - <cy>)", "(<s> ^r <r> - <sum> ^cout <co> - (+ <co> <cy>))")
        base = base.replace("^argument2.operation 2 ^adj 1 ^r -1", "^argument2.operation 2 ^r -1")
    a.add('process-column-impl.soar', base)
    if v5:
        a.add('process-column-impl.soar', V5)
    if not v5:
        a.add('process-column-impl.soar', """
        ## get-digit2: add the incoming carry to d2 (an internal operator with its own substate).
        sp {arithmetic*propose*get-digit2
           (state <s> ^problem-space.name process-column ^|d1| <any> ^adj 0)
        -->
           (<s> ^operator <o> + =)
           (<o> ^name get-digit2 ^task-operator false ^desireds <pre>)
           (<pre> ^desired-count 0)
        }

        sp {arithmetic*propose*increment-digit2
           (state <s> ^problem-space.name get-digit2 ^superstate <ss> ^world <w>)
           (<ss> ^|d2| <d2>)
           (<w> ^objects.object <i>)
           (<i> ^type inc-fact ^n <d2>)
        -->
           (<s> ^operator <o> + =)
           (<o> ^name increment-digit2 ^task-operator false ^fact <i>)
        }

        sp {arithmetic*apply*increment-digit2
           (state <s> ^operator <o> ^superstate <ss>)
           (<o> ^name increment-digit2 ^fact <i>)
           (<i> ^next <n>)
           (<ss> ^|d2| <d2> ^adj <adj>)
        -->
           (log 1 (crlf) |Apply increment-digit2: | <n>)
           (<ss> ^|d2| <d2> - <n> ^adj <adj> - 1)
        }

        ## borrow: subtraction with d1 < d2: add ten to d1 and set the outgoing borrow.
        sp {arithmetic*propose*borrow
           (state <s> ^problem-space.name process-column ^argument2.operation 2 ^adj 1 ^ten 0 ^|d2| <d2> ^|d1| < <d2>)
        -->
           (<s> ^operator <o> + =)
           (<o> ^name borrow ^task-operator false ^desireds <pre>)
           (<pre> ^desired-count 0)
        }

        sp {arithmetic*propose*add-ten
           (state <s> ^problem-space.name borrow ^superstate <ss> ^world <w>)
           (<ss> ^|d1| <d1>)
           (<w> ^objects.object <t>)
           (<t> ^type ten-fact ^n <d1>)
        -->
           (<s> ^operator <o> + =)
           (<o> ^name add-ten ^task-operator false ^fact <t>)
        }

        sp {arithmetic*apply*add-ten
           (state <s> ^operator <o> ^superstate <ss>)
           (<o> ^name add-ten ^fact <t>)
           (<t> ^plus10 <n>)
           (<ss> ^|d1| <d1> ^ten <ten> ^cout <co>)
        -->
           (log 1 (crlf) |Apply add-ten: | <n>)
           (<ss> ^|d1| <d1> - <n> ^ten <ten> - 1 ^cout <co> - 1)
        }
        """)


V5 = """
## get-digit1: add the incoming carry to d1 (an add fact with d2 = 1), in its own substate.
sp {arithmetic*propose*get-digit1
   (state <s> ^problem-space.name process-column ^|d1| <any> ^got1 0)
-->
   (<s> ^operator <o> + =)
   (<o> ^name get-digit1 ^task-operator false ^desireds <pre>)
   (<pre> ^desired-count 0)
}

sp {arithmetic*propose*add-carry
   (state <s> ^problem-space.name get-digit1 ^superstate <ss> ^world <w>)
   (<ss> ^|d1| <d1>)
   (<w> ^objects.object <f>)
   (<f> ^type add-fact ^|d1| <d1> ^|d2| 1)
-->
   (<s> ^operator <o> + =)
   (<o> ^name add-carry ^task-operator false ^fact <f>)
}

sp {arithmetic*apply*add-carry
   (state <s> ^operator <o> ^superstate <ss>)
   (<o> ^name add-carry ^fact <f>)
   (<f> ^sum <sum> ^carry <cy>)
   (<ss> ^|d1| <d1> ^cout <co> ^got1 <g>)
-->
   (log 1 (crlf) |Apply add-carry: | <sum>)
   (<ss> ^|d1| <d1> - <sum> ^cout <co> - <cy> ^got1 <g> - 1)
}

## borrow-from <column>: subtraction with d1 < d2: borrow one from the next column (recursively when that
## column's digit is 0).  The column is the operator's ^borrow-column, which the substate receives (W-SUB-005).
sp {arithmetic*propose*borrow-from
   (state <s> ^problem-space.name << process-column borrow-from >> ^issub 1 ^ten 0 ^|d2| <d2> ^|d1| < <d2> ^nxt <n> ^world <w>)
   (<w> ^objects.object <m>)
   (<m> ^type column ^pos <n>)
-->
   (<s> ^operator <o> + =)
   (<o> ^name borrow-from ^task-operator false ^borrow-column <m> ^desireds <pre>)
   (<pre> ^desired-count 0)
}

sp {arithmetic*propose*borrow-from*init-local
   (state <s> ^problem-space.name borrow-from ^borrow-column <m> -^|d1|)
-->
   (<s> ^operator <o> + >)
   (<o> ^name init-local ^task-operator false)
}

sp {arithmetic*apply*borrow-from*init-local
   (state <s> ^problem-space.name borrow-from ^operator.name init-local ^borrow-column <m>)
   (<m> ^digit1 <d1> ^pos <pos>)
-->
   (log 1 (crlf) |Apply init-local (borrow-from).|)
   (<s> ^|d1| <d1> ^|d2| 1 ^ten 0 ^nxt (+ <pos> 1) ^issub 1 ^r -1 ^wrote 0)
}

sp {arithmetic*propose*take-one
   (state <s> ^problem-space.name borrow-from ^r -1 ^|d1| <d1> ^|d2| <d2> ^world <w>)
   (<w> ^objects.object <f>)
   (<f> ^type sub-fact ^|d1| <d1> ^|d2| <d2>)
-->
   (<s> ^operator <o> + =)
   (<o> ^name take-one ^task-operator false ^fact <f>)
}

sp {arithmetic*apply*take-one
   (state <s> ^operator <o> ^r <r>)
   (<o> ^name take-one ^fact <f>)
   (<f> ^diff <df>)
-->
   (log 1 (crlf) |Apply take-one: | <df>)
   (<s> ^r <r> - <df>)
}

## write-borrow <column>: the reduced digit goes to the column's ^newd1 (task-action operator).
sp {arithmetic*propose*write-borrow
   (state <s> ^problem-space.name borrow-from ^r <> -1 ^wrote 0 ^borrow-column <m>)
-->
   (<s> ^operator <o> + =)
   (<o> ^name write-borrow ^task-operator true ^action-handle write-borrow ^argument1 <m> ^argument-count 1 ^desireds <pre>)
   (<pre> ^desired-count 0)
}

sp {arithmetic*apply*write-borrow*internal
   (state <s> ^operator <o> ^internal-actions true ^r <r> ^wrote <wr> ^world <w>)
   (<o> ^name write-borrow ^pre-conditions-satisfied true ^argument1.object-handle $ <mh>)
   (<w> ^anchored-world true ^objects.object <m>)
   (<m> ^object-handle $ <mh> ^newd1 <old>)
-->
   (log 1 (crlf) |Write borrow: | <mh> | | <r>)
   (<m> ^newd1 <old> - <r>)
   (<s> ^wrote <wr> - 1)
}

sp {arithmetic*propose*add-ten-up
   (state <s> ^problem-space.name borrow-from ^wrote 1 ^superstate <ss> ^world <w>)
   (<ss> ^|d1| <d1>)
   (<w> ^objects.object <t>)
   (<t> ^type ten-fact ^n <d1>)
-->
   (<s> ^operator <o> + =)
   (<o> ^name add-ten-up ^task-operator false ^fact <t>)
}

sp {arithmetic*apply*add-ten-up
   (state <s> ^operator <o> ^superstate <ss>)
   (<o> ^name add-ten-up ^fact <t>)
   (<t> ^plus10 <n>)
   (<ss> ^|d1| <d1> ^ten <ten>)
-->
   (log 1 (crlf) |Apply add-ten-up: | <n>)
   (<ss> ^|d1| <d1> - <n> ^ten <ten> - 1)
}
"""


SMEM_LOOKUP = """
## {OP}: look up the {KIND} for the working values in semantic memory (SMM-016: the command is created by the
## operator's application; agent-world removes the query once it has a result, W-OTH-003).
sp {{arithmetic*propose*{OP}
   (state <s> ^problem-space.name {PS} {COND})
-->
   (<s> ^operator <o> + =)
   (<o> ^name {OP} ^task-operator false{DES})
}}

sp {{arithmetic*apply*{OP}*query
   (state <s> ^operator <o> ^smem.command <c> -^queried <o> {QSRC})
   (<o> ^name {OP})
-->
   (<s> ^queried <o>)
   (<c> ^query <q>)
   (<q> ^kind {KIND} {QATTRS})
}}

sp {{arithmetic*apply*{OP}
   (state <s> ^operator <o> ^queried <o> ^smem.result.retrieved <f> {TSRC})
   (<o> ^name {OP})
   (<f> ^kind {KIND} {FMATCH})
-->
   (log 1 (crlf) |Apply {OP}.|)
   {RHS}
}}
"""


def smem_rules(a, learn):
    des = ' ^desireds <pre>)\n   (<pre> ^desired-count 0' if learn else ''
    for op, ps, cond, kind, qsrc, qattrs, tsrc, fmatch, rhs in (
        ('add-digits', 'process-column', '^argument2.operation 1 ^adj 1 ^r -1', 'add-fact', '^|d1| <d1> ^|d2| <d2>', '^|d1| <d1> ^|d2| <d2>',
         '^|d1| <d1> ^|d2| <d2> ^r <r> ^cout <co>', '^|d1| <d1> ^|d2| <d2> ^sum <sum> ^carry <cy>', '(<s> ^r <r> - <sum> ^cout <co> - <cy>)'),
        ('subtract-digits', 'process-column', '^argument2.operation 2 ^adj 1 ^r -1 ^|d2| <d2> ^|d1| >= <d2>', 'sub-fact', '^|d1| <d1> ^|d2| <d2>', '^|d1| <d1> ^|d2| <d2>',
         '^|d1| <d1> ^|d2| <d2> ^r <r>', '^|d1| <d1> ^|d2| <d2> ^diff <df>', '(<s> ^r <r> - <df>)'),
        ('increment-digit2', 'get-digit2', '', 'inc-fact', '^superstate.|d2| <d2>', '^n <d2>',
         '^superstate <ss>)\n   (<ss> ^|d2| <d2> ^adj <adj>', '^n <d2> ^next <n>', '(<ss> ^|d2| <d2> - <n> ^adj <adj> - 1)'),
        ('add-ten', 'borrow', '', 'ten-fact', '^superstate.|d1| <d1>', '^n <d1>',
         '^superstate <ss>)\n   (<ss> ^|d1| <d1> ^ten <ten> ^cout <co>', '^n <d1> ^plus10 <n>', '(<ss> ^|d1| <d1> - <n> ^ten <ten> - 1 ^cout <co> - 1)')):
        a.add('process-column-impl.soar', SMEM_LOOKUP.format(OP=op, PS=ps, COND=cond, KIND=kind, QSRC=qsrc, QATTRS=qattrs, TSRC=tsrc,
                                                               FMATCH=fmatch, RHS=rhs, DES=des if op in ('add-digits', 'subtract-digits') else ''))
    if learn:
        a.add('process-column-impl.soar', """
        ## When the fact is not in semantic memory, add-digits / subtract-digits get an operator no-change: count it
        ## out in the substate, store the new fact (both orders for addition) and write the result.
        sp {arithmetic*propose*learn*init-local
           (state <s> ^problem-space.name << add-digits subtract-digits >> -^base)
        -->
           (<s> ^operator <o> + >)
           (<o> ^name init-local ^task-operator false)
        }

        sp {arithmetic*apply*learn*init-local
           (state <s> ^problem-space.name << add-digits subtract-digits >> ^operator.name init-local ^superstate.|d1| <d1>)
        -->
           (<s> ^base <d1> ^n 0 ^stored 0)
        }

        sp {arithmetic*propose*count
           (state <s> ^problem-space.name { << add-digits subtract-digits >> <ps> } ^base <any> ^n <n> ^superstate.|d2| <> <n>)
        -->
           (<s> ^operator <o> + =)
           (<o> ^name (concat count- <ps>) ^task-operator false)
        }

        sp {arithmetic*apply*count*add
           (state <s> ^problem-space.name add-digits ^operator.name count-add-digits ^base <b> ^n <n>)
        -->
           (<s> ^base <b> - (+ <b> 1) ^n <n> - (+ <n> 1))
        }

        sp {arithmetic*apply*count*subtract
           (state <s> ^problem-space.name subtract-digits ^operator.name count-subtract-digits ^base <b> ^n <n>)
        -->
           (<s> ^base <b> - (- <b> 1) ^n <n> - (+ <n> 1))
        }

        sp {arithmetic*propose*store
           (state <s> ^problem-space.name { << add-digits subtract-digits >> <ps> } ^base <any> ^stored 0 ^n <n> ^superstate.|d2| <n>)
        -->
           (<s> ^operator <o> + =)
           (<o> ^name (concat store- <ps>) ^task-operator false)
        }

        sp {arithmetic*apply*store*add
           (state <s> ^operator.name store-add-digits ^stored <st> ^base <b> ^superstate <ss> ^smem.command <c>)
           (<ss> ^|d1| <d1> ^|d2| <d2>)
        -->
           (log 1 (crlf) |Store add fact | <d1> | + | <d2>)
           (<s> ^stored <st> - 1)
           (<c> ^store <f1> <f2>)
           (<f1> ^kind add-fact ^|d1| <d1> ^|d2| <d2> ^sum (- <b> (* (div <b> 10) 10)) ^carry (div <b> 10))
           (<f2> ^kind add-fact ^|d1| <d2> ^|d2| <d1> ^sum (- <b> (* (div <b> 10) 10)) ^carry (div <b> 10))
        }

        sp {arithmetic*apply*store*subtract
           (state <s> ^operator.name store-subtract-digits ^stored <st> ^base <b> ^superstate <ss> ^smem.command <c>)
           (<ss> ^|d1| <d1> ^|d2| <d2>)
        -->
           (log 1 (crlf) |Store sub fact | <d1> | - | <d2>)
           (<s> ^stored <st> - 1)
           (<c> ^store <f1>)
           (<f1> ^kind sub-fact ^|d1| <d1> ^|d2| <d2> ^diff <b>)
        }

        sp {arithmetic*propose*done-learn
           (state <s> ^problem-space.name { << add-digits subtract-digits >> <ps> } ^stored 1)
        -->
           (<s> ^operator <o> + =)
           (<o> ^name (concat done- <ps>) ^task-operator false)
        }

        sp {arithmetic*apply*done*add
           (state <s> ^operator.name done-add-digits ^base <b> ^superstate <ss>)
           (<ss> ^r <r> ^cout <co>)
        -->
           (<ss> ^r <r> - (- <b> (* (div <b> 10) 10)) ^cout <co> - (div <b> 10))
        }

        sp {arithmetic*apply*done*subtract
           (state <s> ^operator.name done-subtract-digits ^base <b> ^superstate <ss>)
           (<ss> ^r <r>)
        -->
           (<ss> ^r <r> - <b>)
        }
        """)


def build(v, about, solve_level=False, v5=False, smem=None):
    text, ncols = init_text(v)
    a = Agent('arithmetic', v, T, about)
    if smem:
        fl = open(f'{ORIG}/{v}/{v}/_firstload.soar').read()
        a.settings += [l for l in fl.splitlines() if l.startswith('chunk')]
        a.settings += ['smem --set learning on', fl[fl.index('smem --add'):].strip()]
    else:
        a.settings += ['chunk always', 'chunk add-osk on']
    problem_space(a)
    initialize(a, text, flags={'mea-operator-selection': 'true'})
    achievement_object(a)
    top_rules(a, ncols, solve_level)
    column_rules(a, v5, smem)
    if smem:
        drop = {'propose*add-digits', 'apply*add-digits', 'propose*subtract-digits', 'apply*subtract-digits',
                'propose*increment-digit2', 'apply*increment-digit2', 'propose*add-ten', 'apply*add-ten'}
        def strip(t):
            for nm in drop:
                t = re.sub(r'(## [^\n]*\n)*sp \{arithmetic\*' + re.escape(nm) + r'\n.*?\n\}\n', '', t, flags=re.S)
            return t
        a.files['process-column-impl.soar'] = [strip(t) for t in a.files['process-column-impl.soar']]
        smem_rules(a, smem == 'learn')
    indifferent(a)
    return a.write()


if __name__ == '__main__':
    print(build('arithmetic', 'Arithmetic: 10,000 random 3-digit additions and subtractions, column by column with fact lookup.'))
    print(build('addition', 'Addition of one 2-digit problem, column by column with fact lookup.'))
    print(build('arithmetic-solve-problem', 'Arithmetic (10 problems) with solve-problem as a composite operator over process-column.', solve_level=True))
    print(build('arithmetic-v5', 'Arithmetic (10,000 problems) with carries added to the top digit and borrowing from the next column, recursively.', v5=True))
    print(build('arithmetic-smem', 'Arithmetic (1,000 problems); arithmetic facts are retrieved from semantic memory.', smem='lookup'))
    print(build('arithmetic-smem-chunk', 'Arithmetic (10,000 problems); facts from semantic memory, chunking on.', smem='lookup'))
    print(build('arithmetic-smem-learn', 'Arithmetic (2,000 problems); a missing addition or subtraction fact is counted out in a substate and stored in semantic memory.', smem='learn'))
    print(build('subtraction', 'Subtraction of one 3-digit problem, column by column with fact lookup and borrowing.'))
