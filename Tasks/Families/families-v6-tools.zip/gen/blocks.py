"""blocks-world family, world-v6 (part 1: simple, random, rl, look-ahead, operator subgoaling).
Blocks and the table are world objects; on is a relation; clear is a maintained object property (true/false),
set by move applications (spec section 3; W-CHK-004), so it can also be a precondition desired (W-DES-016)."""
from v6 import *

F, T = 'blocks-world', 'blocks-world'
C3 = dict(start={'A': 'table', 'B': 'table', 'C': 'A'}, goal={'A': 'B', 'B': 'C', 'C': 'table'})
C3S = dict(start={'A': 'B', 'B': 'table', 'C': 'table'}, goal={'A': 'B', 'B': 'C', 'C': 'table'})
C3R = dict(start={'A': 'table', 'B': 'table', 'C': 'table'}, goal={'A': 'B', 'B': 'C', 'C': 'table'})
C4 = dict(start={'A': 'table', 'B': 'D', 'C': 'A', 'D': 'table'}, goal={'A': 'B', 'B': 'C', 'C': 'D', 'D': 'table'})
C5 = dict(start={'A': 'table', 'B': 'E', 'C': 'A', 'D': 'table', 'E': 'D'}, goal={'A': 'B', 'B': 'C', 'C': 'D', 'D': 'E', 'E': 'table'})


def init(cfg, extra_objs='', extra=''):
    blocks = sorted(cfg['start'])
    under = set(cfg['start'].values())
    L = ['(<objs> ^object <table> ' + ' '.join(f'<{b}>' for b in blocks) + extra_objs + ')',
         '(<table> ^object-handle table ^anchored true ^type table ^clear true)']
    for b in blocks:
        L.append(f'(<{b}> ^object-handle {b} ^anchored true ^type block ^clear {"false" if b in under else "true"})')
    for i, b in enumerate(blocks):
        L.append(f'(<w> ^on <on{i}>) (<on{i}> ^argument1 <{b}> ^argument2 <{cfg["start"][b]}>)')
    L.append(f'(<ds> ^desired-count {len(blocks)} ^desired ' + ' '.join(f'<g{b}>' for b in blocks) + ')')
    for b in blocks:
        L.append(f'(<g{b}> ^on <gr{b}>) (<gr{b}> ^argument1 <ga{b}> ^argument2 <gb{b}>) (<ga{b}> ^object-handle {b}) (<gb{b}> ^object-handle {cfg["goal"][b]})')
    return '\n'.join(L) + extra


MOVE_APPLY = """
## move-block <block> <dest>: the block's on relation moves to <dest>; clear is maintained: what the block was
## on becomes clear, a block destination stops being clear (the table stays clear).
sp {blocks-world*apply*move-block*internal
   (state <s> ^operator <o> ^internal-actions true ^world <w>)
   (<o> ^name move-block ^pre-conditions-satisfied true ^argument1.object-handle $ <bh> ^argument2.object-handle $ <dh>)
   (<w> ^anchored-world true ^objects.object <b> <d> ^on <on>)
   (<b> ^object-handle $ <bh>)
   (<d> ^object-handle $ <dh>)
   (<on> ^argument1 <b> ^argument2 <old>)
-->
   (log 1 (crlf) |Move block | <bh> | to | <dh>)
   (<on> ^argument2 <old> - <d>)
}

sp {blocks-world*apply*move-block*internal*clear-source
   (state <s> ^operator <o> ^internal-actions true ^world <w>)
   (<o> ^name move-block ^pre-conditions-satisfied true ^argument1.object-handle $ <bh>)
   (<w> ^anchored-world true ^objects.object <b> ^on <on>)
   (<b> ^object-handle $ <bh>)
   (<on> ^argument1 <b> ^argument2 <old>)
   (<old> ^type block ^clear false)
-->
   (<old> ^clear false - true)
}

sp {blocks-world*apply*move-block*internal*cover-dest
   (state <s> ^operator <o> ^internal-actions true ^world <w>)
   (<o> ^name move-block ^pre-conditions-satisfied true ^argument2.object-handle $ <dh>)
   (<w> ^anchored-world true ^objects.object <d>)
   (<d> ^object-handle $ <dh> ^type block ^clear true)
-->
   (<d> ^clear true - false)
}
"""

LEGAL = """
## move-block <block> <dest>: a clear block onto the table or onto another clear block it is not already on.
sp {blocks-world*propose*move-block
   (state <s> ^problem-space.name blocks-world ^flags.mea-operator-selection true ^desireds.unachieved-desireds true ^world <w>)
   (<w> ^anchored-world true ^objects.object <b> { <> <b> <d> } ^on <on>)
   (<b> ^type block ^clear true)
   (<d> ^clear true)
   (<on> ^argument1 <b> ^argument2 <> <d>)
-->
   (<s> ^operator <o> +)
   (<o> ^name move-block ^task-operator true ^action-handle move-block ^argument1 <b> ^argument2 <d> ^argument-count 2 ^desireds <pre>)
   (<pre> ^desired-count 0)
}
"""

IN_PLACE = """
## Derived (dont-copy): the table is in place; a block is in place when it is on what its desired names and that
## is in place.
sp {blocks-world*elaborate*in-place*table
   (state <s> ^problem-space.name blocks-world ^world <w>)
   (<w> ^objects.object <t>)
   (<t> ^type table)
-->
   (<t> ^in-place true)
}

sp {blocks-world*elaborate*in-place*block
   (state <s> ^problem-space.name blocks-world ^desireds.desired.on <dr> ^world <w>)
   (<dr> ^argument1.object-handle $ <bh> ^argument2.object-handle $ <uh>)
   (<w> ^objects.object <b> <u> ^on <on>)
   (<b> ^object-handle $ <bh>)
   (<u> ^object-handle $ <uh> ^in-place true)
   (<on> ^argument1 <b> ^argument2 <u>)
-->
   (<b> ^in-place true)
}
"""

SIMPLE_PREFS = """
## Search control of the original: a block that is not in place goes to the table (best) ...
sp {blocks-world*compare*out-of-place-to-table
   (state <s> ^problem-space.name blocks-world ^operator <o> +)
   (<o> ^name move-block ^argument1 <b> ^argument2.type table)
   (<b> -^in-place true)
-->
   (<s> ^operator <o> >)
}

## ... and a move onto the block's desired destination, when that is in place, is better than any other.
sp {blocks-world*compare*onto-desired-in-place
   (state <s> ^problem-space.name blocks-world ^operator <o> + ^operator { <> <o> <o2> } + ^desireds.desired.on <dr>)
   (<o> ^name move-block ^argument1.object-handle <bh> ^argument2 <d>)
   (<d> ^object-handle <dh> ^in-place true)
   (<dr> ^argument1.object-handle <bh> ^argument2.object-handle <dh>)
-->
   (<s> ^operator <o> > <o2>)
}
"""


def agent(v, about, cfg, settings, dont_copy=' ^dont-copy-object-attribute in-place', flags=None, extra_objs='', extra=''):
    a = Agent(F, v, T, about)
    a.settings += settings
    problem_space(a, dont_copy)
    initialize(a, init(cfg, extra_objs, extra), flags=dict({'mea-operator-selection': 'true'}, **(flags or {})))
    achievement_relation(a)
    return a


def build():
    out = []
    for v, cfg in (('blocks-world-simple', C5), ('blocks-world-simple-3', C3)):
        a = agent(v, f'Blocks world ({len(cfg["start"])} blocks): out-of-place blocks to the table, then build the goal tower.', cfg, ['chunk never'])
        a.add('move-block.soar', LEGAL + MOVE_APPLY); a.add('elaborations.soar', IN_PLACE); a.add('search-control.soar', SIMPLE_PREFS)
        indifferent(a, 'the original makes its moves indifferent apart from the preferences above'); out.append(a.write())

    a = agent('blocks-world-random', 'Blocks world (3 blocks, all on the table): random legal moves until the tower is built.', C3R, ['chunk never'], dont_copy='')
    a.add('move-block.soar', LEGAL + MOVE_APPLY); indifferent(a); out.append(a.write())

    a = agent('blocks-world-rl', 'Blocks world (4 blocks) with reinforcement learning over the positions of all blocks; reward 1 on success.', C4,
              ['chunk never', 'rl --set learning on', 'rl --set learning-rate 0.300000', 'rl --set discount-rate 0.900000', 'indifferent-selection --epsilon-greedy'],
              dont_copy='', flags={'rl': 'true'})
    a.add('move-block.soar', LEGAL + MOVE_APPLY)
    a.add('rl.soar', """
    ## RL template (RL-007) over the move and what each block is on; the reward of 1 on success comes from
    ## agent-world with ^flags.rl true (W-CHK-001), replacing the original's reward rule.
    sp {blocks-world*rl*move-block
       :template
       (state <s> ^problem-space.name blocks-world ^operator <o> + ^world <w>)
       (<o> ^name move-block ^argument1.object-handle <bh> ^argument2.object-handle <dh>)
       (<w> ^on <ra> <rb> <rc> <rd>)
       (<ra> ^argument1.object-handle A ^argument2.object-handle <ua>)
       (<rb> ^argument1.object-handle B ^argument2.object-handle <ub>)
       (<rc> ^argument1.object-handle C ^argument2.object-handle <uc>)
       (<rd> ^argument1.object-handle D ^argument2.object-handle <ud>)
    -->
       (<s> ^operator <o> = 0)
    }
    """)
    indifferent(a, 'the original chooses by RL values among indifferent operators'); out.append(a.write())

    a = agent('blocks-world-look-ahead', 'Blocks world (3 blocks) by look-ahead; in look-ahead the block moved last is not moved again.', C3,
              ['chunk always', 'chunk add-osk on'], dont_copy='', extra_objs=' <mem>',
              extra='\n(<mem> ^object-handle memory ^anchored true ^type memory ^last-block none)')
    a.add('move-block.soar', LEGAL + MOVE_APPLY + LAST_BLOCK); out.append(a.write())

    a = agent('blocks-world-look-ahead-state-eval', 'Blocks world (3 blocks) by look-ahead; look-ahead states get expected values by how much of the tower is in place; RL on.', C3,
              ['chunk always', 'chunk add-osk on', 'rl --set learning on', 'rl --set learning-rate 0.300000', 'rl --set discount-rate 0.900000', 'indifferent-selection --epsilon-greedy'],
              flags={'rl': 'true'})
    a.add('move-block.soar', LEGAL + MOVE_APPLY); a.add('elaborations.soar', IN_PLACE)
    a.add('state-evaluation.soar', """
    ## Expected value of a look-ahead state (W-LAH-009): 1 when A is in place, 0.6 when B is (and A not on B),
    ## 0.3 when C is (and B not on C), 0 when C is not on the table (original state-evaluation rules).
    sp {blocks-world*elaborate*look-ahead*level-A
       (state <s> ^problem-space.name blocks-world ^tried-tied-operator <any> ^world.objects.object <a>)
       (<a> ^object-handle $ A ^in-place true)
    -->
       (<s> ^expected-value 1)
    }

    sp {blocks-world*elaborate*look-ahead*level-B
       (state <s> ^problem-space.name blocks-world ^tried-tied-operator <any> ^world <w>)
       (<w> ^objects.object <b> ^on <ra>)
       (<b> ^object-handle $ B ^in-place true)
       (<ra> ^argument1.object-handle A ^argument2.object-handle <> B)
    -->
       (<s> ^expected-value 0.6)
    }

    sp {blocks-world*elaborate*look-ahead*level-C
       (state <s> ^problem-space.name blocks-world ^tried-tied-operator <any> ^world <w>)
       (<w> ^objects.object <c> ^on <rb>)
       (<c> ^object-handle $ C ^in-place true)
       (<rb> ^argument1.object-handle B ^argument2.object-handle <> C)
    -->
       (<s> ^expected-value 0.3)
    }

    sp {blocks-world*elaborate*look-ahead*level-none
       (state <s> ^problem-space.name blocks-world ^tried-tied-operator <any> ^world <w>)
       (<w> ^on <rc>)
       (<rc> ^argument1.object-handle C ^argument2.object-handle <> table)
    -->
       (<s> ^expected-value 0)
    }
    """)
    out.append(a.write())

    for v, chunk in (('blocks-world-operator-subgoaling', ['chunk never']), ('blocks-world-operator-subgoaling-chunk', ['chunk always', 'chunk add-osk on'])):
        a = agent(v, 'Blocks world (3 blocks) by operator subgoaling: any move may be selected; when its block or destination is not clear, the substate clears them.', C3S, chunk, dont_copy='')
        a.add('move-block.soar', SUBGOAL_PROPOSE.replace('{EXTRA}', '') + MOVE_APPLY + SUBGOAL_PREFS)
        achievement_object(a, operators=True); achievement_object(a); indifferent(a); out.append(a.write())
    a = agent('blocks-world-operator-subgoaling-relevant', 'Blocks world (3 blocks) by operator subgoaling, proposing only relevant moves: onto a block\'s desired destination, or clearing a block that must be clear.', C3S, ['chunk never'], dont_copy='')
    a.add('move-block.soar', RELEVANT + MOVE_APPLY)
    achievement_object(a, operators=True); achievement_object(a); indifferent(a); out.append(a.write())
    return out


LAST_BLOCK = """
## The block moved last (memory object, spec section 2); in look-ahead it is not moved again (original
## blocks-world*select*reject-twice, which applies only under evaluate-operator).
sp {blocks-world*apply*move-block*internal*last-block
   (state <s> ^operator <o> ^internal-actions true ^world <w>)
   (<o> ^name move-block ^pre-conditions-satisfied true ^argument1.object-handle $ <bh>)
   (<w> ^anchored-world true ^objects.object <m>)
   (<m> ^type memory ^last-block <l>)
-->
   (<m> ^last-block <l> - <bh>)
}

sp {blocks-world*compare*move-block*reject-twice
   (state <s> ^problem-space.name blocks-world ^tried-tied-operator <any> ^operator <o> + ^world.objects.object <m>)
   (<m> ^type memory ^last-block <bh>)
   (<o> ^name move-block ^argument1.object-handle $ <bh>)
-->
   (<s> ^operator <o> -)
}
"""

SUBGOAL_PROPOSE = """
## move-block <block> <dest>: any block onto any other object it is not on.  Preconditions (^desireds): the block
## and the destination are clear; when they are not, the operator no-change substate gets them as its desireds
## (W-MEA-002, W-MEA-003).
sp {blocks-world*propose*move-block
   (state <s> ^problem-space.name blocks-world ^flags.mea-operator-selection true ^desireds.unachieved-desireds true ^world <w>)
   (<w> ^anchored-world true ^objects.object <b> { <> <b> <d> } ^on <on>)
   (<b> ^type block ^object-handle $ <bh>)
   (<d> ^object-handle $ <dh>)
   (<on> ^argument1 <b> ^argument2 <> <d>){EXTRA}
-->
   (<s> ^operator <o> +)
   (<o> ^name move-block ^task-operator true ^action-handle move-block ^argument1 <b> ^argument2 <d> ^argument-count 2 ^desireds <pre>)
   (<pre> ^desired-count 2 ^desired <p1> <p2>)
   (<p1> ^object <p1o>)
   (<p1o> ^object-handle <bh> ^clear true)
   (<p2> ^object <p2o>)
   (<p2o> ^object-handle <dh> ^clear true)
}
"""

SUBGOAL_PREFS = """
## Search control of the original: avoid covering an object the state wants clear (worst); prefer a move that
## achieves a desired on (best) and a move that clears an object the state wants clear (best).
sp {blocks-world*compare*avoid-clobbering
   (state <s> ^problem-space.name blocks-world ^operator <o> + ^desireds.desired.object <do>)
   (<o> ^name move-block ^argument2.object-handle <dh>)
   (<do> ^object-handle <dh> ^clear true)
-->
   (<s> ^operator <o> <)
}

sp {blocks-world*compare*prefer-ontop
   (state <s> ^problem-space.name blocks-world ^operator <o> + ^desireds.desired.on <dr>)
   (<o> ^name move-block ^argument1.object-handle <bh> ^argument2.object-handle <dh>)
   (<dr> ^argument1.object-handle <bh> ^argument2.object-handle <dh>)
-->
   (<s> ^operator <o> >)
}

sp {blocks-world*compare*prefer-clearing
   (state <s> ^problem-space.name blocks-world ^operator <o> + ^desireds.desired.object <do> ^world <w>)
   (<o> ^name move-block ^argument1 <b>)
   (<w> ^on <on>)
   (<on> ^argument1 <b> ^argument2.object-handle <uh>)
   (<do> ^object-handle <uh> ^clear true)
-->
   (<s> ^operator <o> >)
}
"""

RELEVANT = SUBGOAL_PROPOSE.replace('{EXTRA}', """
   (<s> ^desireds.desired.on <dr>)
   (<dr> ^argument1.object-handle <bh> ^argument2.object-handle <dh>)""").replace(
    'sp {blocks-world*propose*move-block\n', 'sp {blocks-world*propose*move-block*onto-desired\n') + SUBGOAL_PROPOSE.replace('{EXTRA}', """
   (<s> ^desireds.desired.object <do>)
   (<on> ^argument2.object-handle <uh>)
   (<do> ^object-handle <uh> ^clear true)
   (<d> ^clear true)""").replace('sp {blocks-world*propose*move-block\n', 'sp {blocks-world*propose*move-block*clearing\n')

if __name__ == '__main__':
    for p in build(): print(p)
