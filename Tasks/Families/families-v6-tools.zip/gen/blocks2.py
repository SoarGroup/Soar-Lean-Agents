"""blocks-world family, world-v6 (part 2: the gripper hierarchies: hierarchical, hrl, hrl-3level).
World: table and blocks A-C; on relations; a gripper object (^position ^open ^empty ^above <handle>
^holding <handle>).  free (nothing on an object) is a maintained property; the gripper's state is tested directly
where the original tests clear.  move-block, pick-up and put-down are composite task operators (W-COP-002); the
gripper actions are task-action operators with internal applications."""
from v6 import *
from blocks import init, IN_PLACE, SIMPLE_PREFS, C3

F, T = 'blocks-world', 'blocks-world'
GRIP = '\n(<grip> ^object-handle gripper ^anchored true ^type gripper ^position 1 ^open 1 ^empty 1 ^above table ^holding table)'


def world(cfg):
    t = init(cfg, ' <grip>', GRIP)
    return t.replace('^clear true', '^free true').replace('^clear false', '^free false')


G = '(<w> ^anchored-world true ^objects.object <g>)\n       (<g> ^type gripper'


def act(name, ps, cond, rhs, log):
    """A gripper action (task-action operator) proposed in problem space ps, with its internal application."""
    return f"""
    sp {{blocks-world*propose*{name}
       (state <s> ^problem-space.name {ps} ^argument1 <b> ^argument2 <d> ^world <w>)
       (<b> ^object-handle $ <bh>)
       (<d> ^object-handle $ <dh>)
       {G}{cond})
    -->
       (<s> ^operator <o> + =)
       (<o> ^name {name} ^task-operator true ^action-handle {name} ^argument1 <b> ^argument2 <d> ^argument-count 2 ^desireds <pre>)
       (<pre> ^desired-count 0)
    }}

    sp {{blocks-world*apply*{name}*internal
       (state <s> ^operator <o> ^internal-actions true ^world <w>)
       (<o> ^name {name} ^pre-conditions-satisfied true ^argument1.object-handle $ <bh> ^argument2.object-handle $ <dh>)
       {G}{cond})
    -->
       (log 1 (crlf) {log})
       {rhs}
    }}
    """


PUT_ON = """
## The block now rests on the destination: on moves, and free is maintained (the old support becomes free, a
## block destination stops being free).
sp {blocks-world*apply*{OP}*internal*on
   (state <s> ^operator <o> ^internal-actions true ^world <w>)
   (<o> ^name {OP} ^pre-conditions-satisfied true ^argument1.object-handle $ <bh> ^argument2.object-handle $ <dh>)
   (<w> ^anchored-world true ^objects.object <b> <d> <g> ^on <on>)
   (<g> ^type gripper ^above $ <dh>{EXTRA})
   (<b> ^object-handle $ <bh>)
   (<d> ^object-handle $ <dh>)
   (<on> ^argument1 <b> ^argument2 <old>)
-->
   (<on> ^argument2 <old> - <d>)
}

sp {blocks-world*apply*{OP}*internal*free-old
   (state <s> ^operator <o> ^internal-actions true ^world <w>)
   (<o> ^name {OP} ^pre-conditions-satisfied true ^argument1.object-handle $ <bh> ^argument2.object-handle $ <dh>)
   (<w> ^anchored-world true ^objects.object <b> <g> ^on <on>)
   (<g> ^type gripper ^above $ <dh>{EXTRA})
   (<b> ^object-handle $ <bh>)
   (<on> ^argument1 <b> ^argument2 <old>)
   (<old> ^type block ^free false)
-->
   (<old> ^free false - true)
}

sp {blocks-world*apply*{OP}*internal*cover-dest
   (state <s> ^operator <o> ^internal-actions true ^world <w>)
   (<o> ^name {OP} ^pre-conditions-satisfied true ^argument2.object-handle $ <dh>)
   (<w> ^anchored-world true ^objects.object <d> <g>)
   (<g> ^type gripper ^above $ <dh>{EXTRA})
   (<d> ^object-handle $ <dh> ^type block ^free true)
-->
   (<d> ^free true - false)
}
"""


def top(a, rl=False):
    a.add('move-block.soar', """
    ## move-block <block> <dest> (composite, W-COP-002): a free block, when the gripper holds nothing else, onto a
    ## free destination that is not held.  Effect: the block is on the destination.  As in the original, one
    ## proposal covers both the free and the held block, so the operator stays selected throughout.
    sp {blocks-world*propose*move-block
       (state <s> ^problem-space.name blocks-world ^flags.mea-operator-selection true ^desireds.unachieved-desireds true ^world <w>)
       (<w> ^anchored-world true ^objects.object <b> { <> <b> <d> } <g> ^on <on>)
       (<b> ^type block ^free true ^object-handle $ <bh>)
       (<d> ^free true ^object-handle $ <dh>)
       (<g> ^type gripper)
      -{(<g> ^empty 0 ^holding <> <bh>)}
      -{(<g> ^empty 0 ^holding <dh>)}
       (<on> ^argument1 <b> ^argument2 <> <d>)
    -->
       (<s> ^operator <o> +)
       (<o> ^name move-block ^task-operator true ^argument1 <b> ^argument2 <d> ^argument-count 2 ^desireds <pre> ^effect-desireds <ed>)
       (<pre> ^desired-count 0)
       (<ed> ^desired-count 1 ^desired <e1>)
       (<e1> ^on <e1r>)
       (<e1r> ^argument1 <e1a> ^argument2 <e1b>)
       (<e1a> ^object-handle <bh>)
       (<e1b> ^object-handle <dh>)
    }
    """)
    if not rl:
        a.add('elaborations.soar', IN_PLACE)
        a.add('search-control.soar', SIMPLE_PREFS)


def composites(a, pick_effect=True):
    a.add('move-block.soar', """
    ## In move-block's implementation substate (problem space move-block, ^argument1 block, ^argument2 dest):
    ## pick-up when the gripper is empty and the block is free; put-down when the gripper holds the block.
    sp {blocks-world*propose*pick-up
       (state <s> ^problem-space.name move-block ^argument1 <b> ^argument2 <d> ^world <w>)
       (<b> ^free true ^object-handle <bh>)
       (<w> ^anchored-world true ^objects.object <g>)
       (<g> ^type gripper ^empty 1)
    -->
       (<s> ^operator <o> + =)
       (<o> ^name pick-up ^task-operator true ^argument1 <b> ^argument2 <d> ^argument-count 2 ^desireds <pre> ^effect-desireds <ed>)
       (<pre> ^desired-count 0)
       (<ed> ^desired-count 2 ^desired <e1> <e2>)
       (<e1> ^object <e1o>)
       (<e1o> ^object-handle gripper ^empty 0)
       (<e2> ^object <e2o>)
       (<e2o> ^object-handle gripper ^holding <bh>)
    }

    sp {blocks-world*propose*put-down
       (state <s> ^problem-space.name move-block ^argument1 <b> ^argument2 <d> ^world <w>)
       (<b> ^object-handle $ <bh>)
       (<d> ^object-handle <dh>)
       (<w> ^anchored-world true ^objects.object <g>)
       (<g> ^type gripper ^empty 0 ^holding $ <bh>)
    -->
       (<s> ^operator <o> + =)
       (<o> ^name put-down ^task-operator true ^argument1 <b> ^argument2 <d> ^argument-count 2 ^desireds <pre> ^effect-desireds <ed>)
       (<pre> ^desired-count 0)
       (<ed> ^desired-count 2 ^desired <e1> <e2>)
       (<e1> ^on <e1r>)
       (<e1r> ^argument1 <e1a> ^argument2 <e1b>)
       (<e1a> ^object-handle <bh>)
       (<e1b> ^object-handle <dh>)
       (<e2> ^object <e2o>)
       (<e2o> ^object-handle gripper ^empty 1)
    }
    """)


def hierarchical(v='blocks-world-hierarchical'):
    a = Agent(F, v, T, 'Blocks world (3 blocks) with a gripper: move-block, then pick-up and put-down, then the gripper actions, each level a composite operator.')
    a.settings += ['chunk never']
    problem_space(a, ' ^dont-copy-object-attribute in-place')
    initialize(a, world(C3), flags={'mea-operator-selection': 'true'})
    achievement_relation(a); achievement_object(a)
    top(a); composites(a)
    a.add('pick-up.soar', ''.join([
        act('move-gripper-above', 'pick-up', ' ^position 1 ^empty 1 ^above { <> <bh> <ab> }', '(<g> ^above <ab> - <bh>)', "|Move gripper above | <bh>"),
        act('move-gripper-down', 'pick-up', ' ^position 1 ^empty 1 ^above $ <bh>', '(<g> ^position 1 - 0)', '|Move gripper down|'),
        act('close-gripper', 'pick-up', ' ^position 0 ^open 1 ^empty 1 ^above $ <bh> ^holding <hd>', '(<g> ^open 1 - 0 ^empty 1 - 0 ^holding <hd> - <bh>)', "|Close gripper on | <bh>"),
        act('move-gripper-up', 'pick-up', ' ^position 0 ^empty 1 ^above <> <bh>', '(<g> ^position 0 - 1)', '|Move gripper up|'),
    ]))
    a.add('put-down.soar', ''.join([
        act('move-gripper-up-holding', 'put-down', ' ^position 0 ^above <> <dh>', '(<g> ^position 0 - 1)', '|Move gripper up (holding)|'),
        act('move-gripper-above-destination', 'put-down', ' ^position 1 ^above { <> <dh> <ab> }', '(<g> ^above <ab> - <dh>)', "|Move gripper above destination | <dh>"),
        act('move-gripper-down-holding', 'put-down', ' ^position 1 ^above $ <dh>', '(<g> ^position 1 - 0)', '|Move gripper down (holding)|'),
        act('open-gripper', 'put-down', ' ^position 0 ^open 0 ^above $ <dh> ^empty <e>', '(<g> ^open 0 - 1 ^empty <e> - 1 ^above <dh> - <bh>)', "|Open gripper: | <bh> | on | <dh>"),
    ]))
    a.add('put-down.soar', PUT_ON.replace('{OP}', 'open-gripper').replace('{EXTRA}', ' ^position 0 ^open 0'))
    indifferent(a, 'the original makes its operators indifferent apart from the top-level preferences')
    return a.write()


def hrl3():
    v = 'blocks-world-hrl-3level'
    a = Agent(F, v, T, 'Blocks world (3 blocks) with a gripper, three levels, and hierarchical reinforcement learning of the gripper actions (rewards in pick-up and put-down).')
    a.settings += ['chunk never', 'rl --set learning on', 'rl --set learning-rate 0.300000', 'rl --set discount-rate 0.900000', 'indifferent-selection --epsilon-greedy']
    problem_space(a, ' ^dont-copy-object-attribute in-place')
    initialize(a, world(C3), flags={'mea-operator-selection': 'true'})
    achievement_relation(a); achievement_object(a)
    top(a); composites(a)
    a.add('pick-up.soar', ''.join([
        act('above-block', 'pick-up', ' ^position 1 ^above { <> <bh> <ab> }', '(<g> ^above <ab> - <bh>)', '|Above block|'),
        act('down', 'pick-up', ' ^position 1', '(<g> ^position 1 - 0)', '|Down|'),
        act('up', 'pick-up', ' ^position 0', '(<g> ^position 0 - 1)', '|Up|'),
        act('open', 'pick-up', ' ^open 0 ^empty 1', '(<g> ^open 0 - 1)', '|Open|'),
    ]))
    a.add('pick-up.soar', """
    ## close: grasps the block when the gripper is down above it (case 1); otherwise it only closes (cases 2, 3).
    sp {blocks-world*propose*close
       (state <s> ^problem-space.name pick-up ^argument1 <b> ^argument2 <d> ^world <w>)
       (<w> ^anchored-world true ^objects.object <g>)
       (<g> ^type gripper ^open 1)
    -->
       (<s> ^operator <o> + =)
       (<o> ^name close ^task-operator true ^action-handle close ^argument1 <b> ^argument2 <d> ^argument-count 2 ^desireds <pre>)
       (<pre> ^desired-count 0)
    }

    sp {blocks-world*apply*close*internal*grasp
       (state <s> ^operator <o> ^internal-actions true ^world <w>)
       (<o> ^name close ^pre-conditions-satisfied true ^argument1.object-handle $ <bh>)
       (<w> ^anchored-world true ^objects.object <g>)
       (<g> ^type gripper ^open 1 ^empty 1 ^position 0 ^above $ <bh> ^holding <hd>)
    -->
       (log 1 (crlf) |Close on | <bh>)
       (<g> ^open 1 - 0 ^empty 1 - 0 ^holding <hd> - <bh>)
    }

    sp {blocks-world*apply*close*internal*empty
       (state <s> ^operator <o> ^internal-actions true ^world <w>)
       (<o> ^name close ^pre-conditions-satisfied true ^argument1.object-handle $ <bh>)
       (<w> ^anchored-world true ^objects.object <g>)
       (<g> ^type gripper ^open 1)
      -{(<g> ^empty 1 ^position 0 ^above <bh>)}
    -->
       (log 1 (crlf) |Close|)
       (<g> ^open 1 - 0)
    }

    ## Rewards (RL-002, i-supported): +1 when the block is held, -1 when the gripper is closed on nothing.
    sp {blocks-world*elaborate*reward*pick-up*held
       (state <s> ^problem-space.name pick-up ^reward-link <rl> ^argument1.object-handle <bh> ^world <w>)
       (<w> ^anchored-world true ^objects.object <g>)
       (<g> ^type gripper ^empty 0 ^holding <bh>)
    -->
       (<rl> ^reward <r>)
       (<r> ^value 1)
    }

    sp {blocks-world*elaborate*reward*pick-up*closed-empty
       (state <s> ^problem-space.name pick-up ^reward-link <rl> ^world <w>)
       (<w> ^anchored-world true ^objects.object <g>)
       (<g> ^type gripper ^open 0 ^empty 1)
    -->
       (<rl> ^reward <r>)
       (<r> ^value -1)
    }
    """)
    a.add('put-down.soar', ''.join([
        act('up-holding', 'put-down', ' ^position 0', '(<g> ^position 0 - 1)', '|Up (holding)|'),
        act('above-dest', 'put-down', ' ^position 1 ^above { <> <dh> <ab> }', '(<g> ^above <ab> - <dh>)', '|Above destination|'),
        act('down-holding', 'put-down', ' ^position 1', '(<g> ^position 1 - 0)', '|Down (holding)|'),
    ]))
    a.add('put-down.soar', """
    ## release: over the destination the block is put there (case 1); elsewhere the gripper just opens (case 2).
    sp {blocks-world*propose*release
       (state <s> ^problem-space.name put-down ^argument1 <b> ^argument2 <d> ^world <w>)
       (<w> ^anchored-world true ^objects.object <g>)
       (<g> ^type gripper ^open 0 ^position 0)
    -->
       (<s> ^operator <o> + =)
       (<o> ^name release ^task-operator true ^action-handle release ^argument1 <b> ^argument2 <d> ^argument-count 2 ^desireds <pre>)
       (<pre> ^desired-count 0)
    }

    sp {blocks-world*apply*release*internal*gripper
       (state <s> ^operator <o> ^internal-actions true ^world <w>)
       (<o> ^name release ^pre-conditions-satisfied true ^argument1.object-handle $ <bh> ^argument2.object-handle $ <dh>)
       (<w> ^anchored-world true ^objects.object <g>)
       (<g> ^type gripper ^open 0 ^empty <e> ^above <ab>)
    -->
       (log 1 (crlf) |Release|)
       (<g> ^open 0 - 1 ^empty <e> - 1)
    }

    sp {blocks-world*apply*release*internal*above
       (state <s> ^operator <o> ^internal-actions true ^world <w>)
       (<o> ^name release ^pre-conditions-satisfied true ^argument1.object-handle $ <bh> ^argument2.object-handle $ <dh>)
       (<w> ^anchored-world true ^objects.object <g>)
       (<g> ^type gripper ^open 0 ^above $ <dh>)
    -->
       (<g> ^above <dh> - <bh>)
    }

    sp {blocks-world*elaborate*reward*put-down
       (state <s> ^problem-space.name put-down ^reward-link <rl> ^argument1 <b> ^argument2 <d> ^world <w>)
       (<w> ^anchored-world true ^objects.object <g> ^on <on>)
       (<g> ^type gripper ^empty 1)
       (<on> ^argument1 <b> ^argument2 <d>)
    -->
       (<rl> ^reward <r>)
       (<r> ^value 1)
    }
    """)
    a.add('put-down.soar', PUT_ON.replace('{OP}', 'release').replace('{EXTRA}', ' ^open 0'))
    for ps, ops in (('pick-up', 'above-block down up open close'), ('put-down', 'up-holding above-dest down-holding release')):
        a.add('rl.soar', f"""
        ## RL template (RL-007; the original's gp rules) over the gripper's state, in {ps}.
        sp {{blocks-world*rl*{ps}
           :template
           (state <s> ^problem-space.name {ps} ^operator <o> + ^argument1.object-handle <bh> ^argument2.object-handle <dh> ^world <w>)
           (<o> ^name {{ << {ops} >> <n> }})
           (<w> ^objects.object <g>)
           (<g> ^type gripper ^position <p> ^open <op> ^empty <e> ^above <ab>)
        -->
           (<s> ^operator <o> = 0)
        }}
        """)
    indifferent(a, 'the original makes its operators indifferent (RL values decide)')
    a.add('search-control.soar', """
    sp {blocks-world*compare*substate-operator*indifferent
       (state <s> ^problem-space.name << move-block pick-up put-down >> ^operator <o> +)
       (<o> ^task-operator true)
    -->
       (<s> ^operator <o> =)
    }
    """)
    return a.write()


def hrl():
    v = 'blocks-world-hrl'
    a = Agent(F, v, T, 'Blocks world (3 blocks), two levels: move-block chooses pick-up and put-down of any block by RL; rewards in move-block and on success.')
    a.settings += ['chunk never', 'rl --set learning on', 'rl --set learning-rate 0.300000', 'rl --set discount-rate 0.900000', 'indifferent-selection --epsilon-greedy']
    problem_space(a)
    initialize(a, world(C3), flags={'mea-operator-selection': 'true', 'rl': 'true'})
    achievement_relation(a)
    a.add('move-block.soar', """
    ## move-block <block> <dest> (composite): a free block onto a free destination.  Effect: the block on dest.
    sp {blocks-world*propose*move-block
       (state <s> ^problem-space.name blocks-world ^flags.mea-operator-selection true ^desireds.unachieved-desireds true ^world <w>)
       (<w> ^anchored-world true ^objects.object <b> { <> <b> <d> } ^on <on>)
       (<b> ^type block ^free true ^object-handle $ <bh>)
       (<d> ^free true ^object-handle $ <dh>)
       (<on> ^argument1 <b> ^argument2 <> <d>)
    -->
       (<s> ^operator <o> +)
       (<o> ^name move-block ^task-operator true ^argument1 <b> ^argument2 <d> ^argument-count 2 ^desireds <pre> ^effect-desireds <ed>)
       (<pre> ^desired-count 0)
       (<ed> ^desired-count 1 ^desired <e1>)
       (<e1> ^on <e1r>)
       (<e1r> ^argument1 <e1a> ^argument2 <e1b>)
       (<e1a> ^object-handle <bh>)
       (<e1b> ^object-handle <dh>)
    }

    ## In move-block's substate: pick-up <x> of any free block when the gripper is empty; put-down <y> <d> of the
    ## held block onto any free object that is not held (task-action operators; RL chooses).
    sp {blocks-world*propose*pick-up
       (state <s> ^problem-space.name move-block ^world <w>)
       (<w> ^anchored-world true ^objects.object <x> <g>)
       (<g> ^type gripper ^empty 1)
       (<x> ^type block ^free true)
    -->
       (<s> ^operator <o> + =)
       (<o> ^name pick-up ^task-operator true ^action-handle pick-up ^argument1 <x> ^argument-count 1 ^desireds <pre>)
       (<pre> ^desired-count 0)
    }

    sp {blocks-world*apply*pick-up*internal
       (state <s> ^operator <o> ^internal-actions true ^world <w>)
       (<o> ^name pick-up ^pre-conditions-satisfied true ^argument1.object-handle $ <xh>)
       (<w> ^anchored-world true ^objects.object <g>)
       (<g> ^type gripper ^empty 1 ^holding <hd>)
    -->
       (log 1 (crlf) |Pick up | <xh>)
       (<g> ^empty 1 - 0 ^holding <hd> - <xh>)
    }

    sp {blocks-world*propose*put-down
       (state <s> ^problem-space.name move-block ^world <w>)
       (<w> ^anchored-world true ^objects.object <y> { <> <y> <d> } <g>)
       (<g> ^type gripper ^empty 0 ^holding <yh>)
       (<y> ^object-handle $ <yh>)
       (<d> ^free true)
    -->
       (<s> ^operator <o> + =)
       (<o> ^name put-down ^task-operator true ^action-handle put-down ^argument1 <y> ^argument2 <d> ^argument-count 2 ^desireds <pre>)
       (<pre> ^desired-count 0)
    }

    sp {blocks-world*apply*put-down*internal
       (state <s> ^operator <o> ^internal-actions true ^world <w>)
       (<o> ^name put-down ^pre-conditions-satisfied true ^argument1.object-handle $ <yh> ^argument2.object-handle $ <dh>)
       (<w> ^anchored-world true ^objects.object <g> <y> <d> ^on <on>)
       (<g> ^type gripper ^empty 0)
       (<y> ^object-handle $ <yh>)
       (<d> ^object-handle $ <dh>)
       (<on> ^argument1 <y> ^argument2 <old>)
    -->
       (log 1 (crlf) |Put down | <yh> | on | <dh>)
       (<g> ^empty 0 - 1)
       (<on> ^argument2 <old> - <d>)
    }

    sp {blocks-world*apply*put-down*internal*free-old
       (state <s> ^operator <o> ^internal-actions true ^world <w>)
       (<o> ^name put-down ^pre-conditions-satisfied true ^argument1.object-handle $ <yh>)
       (<w> ^anchored-world true ^objects.object <y> ^on <on>)
       (<y> ^object-handle $ <yh>)
       (<on> ^argument1 <y> ^argument2 <old>)
       (<old> ^type block ^free false)
    -->
       (<old> ^free false - true)
    }

    sp {blocks-world*apply*put-down*internal*cover-dest
       (state <s> ^operator <o> ^internal-actions true ^world <w>)
       (<o> ^name put-down ^pre-conditions-satisfied true ^argument2.object-handle $ <dh>)
       (<w> ^anchored-world true ^objects.object <d>)
       (<d> ^object-handle $ <dh> ^type block ^free true)
    -->
       (<d> ^free true - false)
    }
    """)
    a.add('rl.soar', """
    ## RL templates (RL-007): move-block over the whole situation; pick-up and put-down over the move's block and
    ## destination and their own arguments.
    sp {blocks-world*rl*move-block
       :template
       (state <s> ^problem-space.name blocks-world ^operator <o> + ^world <w>)
       (<o> ^name move-block ^argument1.object-handle <bh> ^argument2.object-handle <dh>)
       (<w> ^on <ra> <rb> <rc> ^objects.object <g>)
       (<ra> ^argument1.object-handle A ^argument2.object-handle <ua>)
       (<rb> ^argument1.object-handle B ^argument2.object-handle <ub>)
       (<rc> ^argument1.object-handle C ^argument2.object-handle <uc>)
       (<g> ^type gripper ^position <p> ^open <op> ^empty <e> ^above <ab> ^holding <hd>)
    -->
       (<s> ^operator <o> = 0)
    }

    sp {blocks-world*rl*pick-up
       :template
       (state <s> ^problem-space.name move-block ^operator <o> + ^argument1.object-handle <bh> ^argument2.object-handle <dh>)
       (<o> ^name pick-up ^argument1.object-handle <xh>)
    -->
       (<s> ^operator <o> = 0)
    }

    sp {blocks-world*rl*put-down
       :template
       (state <s> ^problem-space.name move-block ^operator <o> + ^argument1.object-handle <bh> ^argument2.object-handle <dh>)
       (<o> ^name put-down ^argument1.object-handle <yh> ^argument2.object-handle <ph>)
    -->
       (<s> ^operator <o> = 0)
    }

    ## Rewards in move-block: +1 when its block is on its destination, -1 when another block is held.  The +1 on
    ## success at the top comes from agent-world with ^flags.rl true (W-CHK-001).
    sp {blocks-world*elaborate*reward*move-block*done
       (state <s> ^problem-space.name move-block ^reward-link <rl> ^argument1 <b> ^argument2 <d> ^world <w>)
       (<w> ^on <on>)
       (<on> ^argument1 <b> ^argument2 <d>)
    -->
       (<rl> ^reward <r>)
       (<r> ^value 1)
    }

    sp {blocks-world*elaborate*reward*move-block*wrong-block
       (state <s> ^problem-space.name move-block ^reward-link <rl> ^argument1.object-handle <bh> ^world <w>)
       (<w> ^objects.object <g>)
       (<g> ^type gripper ^empty 0 ^holding <> <bh>)
    -->
       (<rl> ^reward <r>)
       (<r> ^value -1)
    }
    """)
    indifferent(a, 'the original chooses by RL values among indifferent operators')
    return a.write()


def hier_lookahead():
    v = 'blocks-world-hierarchical-lookahead'
    a = Agent(F, v, T, 'Blocks world (3 blocks), two levels: inside move-block, pick-up and put-down of any block tie and look-ahead chooses (success: the block on its destination; failure: the wrong block held, or the gripper empty with the block elsewhere).')
    a.settings += ['chunk never']
    problem_space(a, ' ^dont-copy-object-attribute in-place')
    initialize(a, world(C3), flags={'mea-operator-selection': 'true'})
    achievement_relation(a)
    h = open(__file__).read()
    hrl_text = h[h.index('    ## move-block <block> <dest> (composite): a free block'):h.index('    a.add(\'rl.soar\', """\n    ## RL templates')]
    hrl_text = hrl_text[:hrl_text.rindex('""")')]
    a.add('move-block.soar', hrl_text.replace('(<s> ^operator <o> + =)', '(<s> ^operator <o> +)'))
    a.add('elaborations.soar', IN_PLACE)
    a.add('search-control.soar', SIMPLE_PREFS)
    a.add('look-ahead.soar', """
    ## Look-ahead inside move-block: the evaluation state gets the move-block problem space (W-LAH-026, W-FLG-003).
    sp {blocks-world*elaborate*problem-space*move-block*look-ahead
       (state <s> ^name evaluate-operator ^superstate.superstate.problem-space.name move-block)
    -->
       (<s> ^problem-space <p>)
       (<p> ^name move-block)
    }

    ## Failure (original move-block*evaluate*failure*1, *2): after a tried operator, a block other than the move's
    ## is held, or the gripper is empty and the move's block is not on its destination.
    sp {blocks-world*elaborate*look-ahead*failure*wrong-block
       (state <s> ^problem-space.name move-block ^tried-tied-operator <any> ^desireds <ds> ^world <w>)
       (<ds> ^desired.on.argument1.object-handle <bh>)
       (<w> ^objects.object <g>)
       (<g> ^type gripper ^empty 0 ^holding <> <bh>)
    -->
       (<s> ^failure <ds>)
    }

    sp {blocks-world*elaborate*look-ahead*failure*misplaced
       (state <s> ^problem-space.name move-block ^tried-tied-operator <any> ^desireds <ds> ^world <w>)
       (<ds> ^desired.on <dr>)
       (<dr> ^argument1.object-handle $ <bh> ^argument2.object-handle <dh>)
       (<w> ^objects.object <g> <b> ^on <on>)
       (<g> ^type gripper ^empty 1)
       (<b> ^object-handle $ <bh>)
       (<on> ^argument1 <b> ^argument2.object-handle <> <dh>)
    -->
       (<s> ^failure <ds>)
    }
    """)
    indifferent(a, 'the original makes its top-level moves indifferent apart from the preferences above')
    return a.write()


if __name__ == '__main__':
    print(hierarchical()); print(hrl3()); print(hrl()); print(hier_lookahead())
