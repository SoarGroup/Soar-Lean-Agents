"""eight-puzzle family, world-v6.  The goal has 9 (16) cell bindings, more than the library's 6 desireds
(W-DES-004), and no 6 of them determine it (a BFS over the 181,440 reachable states: whichever 6 are fixed, 3
reachable boards remain).  So each tile has its goal cell as a static ^home, a derived ^at-home, and the board a
derived ^solved true, tested positively for every tile; the goal is one desired, board ^solved true."""
from v6 import *

F, T = 'eight-puzzle', 'eight-puzzle'
E8 = dict(n=3, start={'11': 2, '12': 1, '13': 7, '21': 8, '22': 6, '23': 0, '31': 3, '32': 4, '33': 5},
          goal={'11': 1, '12': 8, '13': 7, '21': 2, '22': 0, '23': 6, '31': 3, '32': 4, '33': 5})
E15 = dict(n=4, start=dict(zip([f'{r}{c}' for r in range(1, 5) for c in range(1, 5)], [2, 1, 7, 8, 6, 15, 3, 4, 5, 9, 10, 11, 12, 13, 14, 0])),
           goal=dict(zip([f'{r}{c}' for r in range(1, 5) for c in range(1, 5)], [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 0])))


def init(p):
    n = p['n']; cells = sorted(p['start'])
    home = {v: k for k, v in p['goal'].items()}
    L = ['(<objs> ^object <board> ' + ' '.join(f'<c{c}>' for c in cells) + ' ' + ' '.join(f'<t{t}>' for t in range(n * n)) + ' <mem>)',
         '(<board> ^object-handle board ^anchored true ^type board)',
         '(<mem> ^object-handle memory ^anchored true ^type memory ^last-tile none)']
    for c in cells:
        L.append(f'(<c{c}> ^object-handle c{c} ^anchored true ^type cell ^id {c})')
    for t in range(n * n):
        L.append(f'(<t{t}> ^object-handle t{t} ^anchored true ^type tile ^number {t} ^home c{home[t]})')
    k = 0
    for c, t in p['start'].items():
        k += 1; L.append(f'(<w> ^at <a{k}>) (<a{k}> ^argument1 <t{t}> ^argument2 <c{c}>)')
    for c in cells:
        for d in cells:
            if abs(int(c[0]) - int(d[0])) + abs(int(c[1]) - int(d[1])) == 1:
                k += 1; L.append(f'(<w> ^adjacent <a{k}>) (<a{k}> ^argument1 <c{c}> ^argument2 <c{d}>)')
    L.append('(<ds> ^desired-count 1 ^desired <d1> ^better higher)\n(<d1> ^object <d1o>)\n(<d1o> ^object-handle board ^solved true)')
    return '\n'.join(L)


def build(v, p, value_attr, about):
    n = p['n']
    a = Agent(F, v, T, about)
    a.settings += ['chunk always', 'chunk add-osk on']
    problem_space(a, ' ^copy-relation at ^copy-relation adjacent ^dont-copy-object-attribute at-home ^dont-copy-object-attribute solved')
    initialize(a, init(p), flags={'mea-operator-selection': 'true'})
    achievement_object(a)
    tiles = range(1, n * n)
    conds = '\n       '.join(f'(<w> ^objects.object <t{t}>) (<t{t}> ^object-handle $ t{t} ^at-home true)' for t in tiles)
    a.add('elaborations.soar', f"""
    ## Derived: a tile is at home when it is at its goal cell; the board is solved when every tile is
    ## (positive tests only, W-CHK-004).  Both are listed as ^dont-copy-object-attribute (W-SEL-009).
    sp {{eight-puzzle*elaborate*tile*at-home
       (state <s> ^world <w>)
       (<w> ^objects.object <t> <c> ^at <r>)
       (<t> ^type tile ^home <ch>)
       (<c> ^object-handle $ <ch>)
       (<r> ^argument1 <t> ^argument2 <c>)
    -->
       (<t> ^at-home true)
    }}

    sp {{eight-puzzle*elaborate*board*solved
       (state <s> ^world <w>)
       (<w> ^objects.object <b>)
       (<b> ^type board)
       {conds}
    -->
       (<b> ^solved true)
    }}
    """)
    a.add('move-tile.soar', """
    ## move-tile <tile> <to> <from>: a tile next to the blank moves into the blank's cell.
    sp {eight-puzzle*propose*move-tile
       (state <s> ^problem-space.name eight-puzzle ^flags.mea-operator-selection true ^desireds.unachieved-desireds true ^world <w>)
       (<w> ^anchored-world true ^objects.object <t> <k> ^at <rt> <rk> ^adjacent <adj>)
       (<t> ^type tile ^number <> 0)
       (<k> ^type tile ^number 0)
       (<rt> ^argument1 <t> ^argument2 <from>)
       (<rk> ^argument1 <k> ^argument2 <to>)
       (<adj> ^argument1 <from> ^argument2 <to>)
    -->
       (<s> ^operator <o> +)
       (<o> ^name move-tile ^task-operator true ^action-handle move-tile ^argument1 <t> ^argument2 <to> ^argument3 <from> ^argument-count 3 ^desireds <pre>)
       (<pre> ^desired-count 0)
    }

    sp {eight-puzzle*apply*move-tile*internal
       (state <s> ^operator <o> ^internal-actions true ^world <w>)
       (<o> ^name move-tile ^pre-conditions-satisfied true ^argument1.object-handle $ <th> ^argument2.object-handle $ <toh>)
       (<w> ^anchored-world true ^objects.object <t> <k> <to> <m> ^at <rt> <rk>)
       (<t> ^object-handle $ <th>)
       (<k> ^type tile ^number 0)
       (<to> ^object-handle $ <toh>)
       (<m> ^type memory ^last-tile <lt>)
       (<rt> ^argument1 <t> ^argument2 <from>)
       (<rk> ^argument1 <k> ^argument2 <to>)
    -->
       (log 1 (crlf) |Move tile | <th> | to | <toh>)
       (<rt> ^argument2 <from> - <to>)
       (<rk> ^argument2 <to> - <from>)
       (<m> ^last-tile <lt> - <th>)
    }

    ## Search control: never move the tile moved last (original eight-puzzle*select*reject-inverse).
    sp {eight-puzzle*compare*move-tile*reject-inverse
       (state <s> ^problem-space.name eight-puzzle ^operator <o> + ^world <w>)
       (<o> ^name move-tile ^argument1.object-handle $ <th>)
       (<w> ^anchored-world true ^objects.object <m>)
       (<m> ^type memory ^last-tile <th>)
    -->
       (<s> ^operator <o> -)
    }
    """)
    a.add('state-evaluation.soar', f"""
    ## Look-ahead evaluation of the move just tried ({value_attr}; the goal set has ^better higher, W-DES-018):
    ## +1 when the tile moved home, -1 when it moved away from home, 0 otherwise.
    sp {{eight-puzzle*elaborate*look-ahead*moved-into-place
       (state <s> ^problem-space.name eight-puzzle ^tried-tied-operator <o>)
       (<o> ^name move-tile ^argument1.home <h> ^argument2.object-handle <h>)
    -->
       (<s> ^{value_attr} 1)
    }}

    sp {{eight-puzzle*elaborate*look-ahead*moved-out-of-place
       (state <s> ^problem-space.name eight-puzzle ^tried-tied-operator <o>)
       (<o> ^name move-tile ^argument1.home <h> ^argument3.object-handle <h>)
    -->
       (<s> ^{value_attr} -1)
    }}

    sp {{eight-puzzle*elaborate*look-ahead*moved-neutral
       (state <s> ^problem-space.name eight-puzzle ^tried-tied-operator <o>)
       (<o> ^name move-tile ^argument1.home <h> ^argument2.object-handle <> <h> ^argument3.object-handle <> <h>)
    -->
       (<s> ^{value_attr} 0)
    }}
    """)
    return a.write()


if __name__ == '__main__':
    print(build('eight-puzzle', E8, 'numeric-value', 'Eight puzzle (5 moves from the goal) by look-ahead with a numeric move evaluation.'))
    print(build('eight-puzzle-expected-value', E8, 'expected-value', 'Eight puzzle by look-ahead; the move evaluation is an expected value (numeric-indifferent preference).'))
    print(build('fifteen-puzzle', E15, 'numeric-value', 'Fifteen puzzle by look-ahead with a numeric move evaluation.'))
