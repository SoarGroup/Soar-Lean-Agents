"""towers-of-hanoi family, world-v6: 5 discs on peg A, goal all on peg C."""
from v6 import *

F, T = 'towers-of-hanoi', 'towers-of-hanoi'
N = 5


def world_init(control):
    objs = ['<pa>', '<pb>', '<pc>'] + [f'<d{i}>' for i in range(1, N + 1)] + ['<ba>', '<bb>', '<bc>']
    L = ['(<objs> ^object ' + ' '.join(objs) + (' <m>)' if control else ')')]
    for p in 'abc':
        L.append(f'(<p{p}> ^object-handle {p.upper()} ^anchored true ^type peg)')
        L.append(f'(<b{p}> ^object-handle base-{p.upper()} ^anchored true ^type base ^size 6)')
    for i in range(1, N + 1):
        L.append(f'(<d{i}> ^object-handle d{i} ^anchored true ^type disc ^size {i})')
    if control:
        L.append('(<m> ^object-handle control ^anchored true ^type memory ^lastsize 2 ^lastpeg B)')
    # on: disc or base -> peg ; above: disc -> what it rests on ; clear: maintained (W-CHK-004)
    for i in range(1, N + 1):
        L.append(f'(<w> ^on <on{i}>) (<on{i}> ^argument1 <d{i}> ^argument2 <pa>)')
        below = f'<d{i+1}>' if i < N else '<ba>'
        L.append(f'(<w> ^above <ab{i}>) (<ab{i}> ^argument1 <d{i}> ^argument2 {below})')
    for p in 'abc':
        L.append(f'(<w> ^on <onb{p}>) (<onb{p}> ^argument1 <b{p}> ^argument2 <p{p}>)')
    L.append('(<w> ^clear <c1> <cb> <cc>) (<c1> ^argument1 <d1>) (<cb> ^argument1 <bb>) (<cc> ^argument1 <bc>)')
    L.append(f'(<ds> ^desired-count {N} ^desired ' + ' '.join(f'<g{i}>' for i in range(1, N + 1)) + ')')
    for i in range(1, N + 1):
        L.append(f'(<g{i}> ^on <gr{i}>) (<gr{i}> ^argument1 <ga{i}> ^argument2 <gb{i}>) (<ga{i}> ^object-handle d{i}) (<gb{i}> ^object-handle C)')
    return '\n'.join(L)


APPLY = """
## move-disc <disc> <onto> <peg>: the disc leaves what it was on and rests on <onto> (a disc or a peg's base)
## on <peg>.  on, above and clear are maintained here (spec section 3).
sp {towers-of-hanoi*apply*move-disc*internal
   (state <s> ^operator <o> ^internal-actions true ^world <w>)
   (<o> ^name move-disc ^pre-conditions-satisfied true ^argument1.object-handle $ <dh> ^argument2.object-handle $ <th> ^argument3.object-handle $ <ph>)
   (<w> ^anchored-world true ^objects.object <d> <t> <p>)
   (<d> ^object-handle $ <dh> ^size <size>)
   (<t> ^object-handle $ <th>)
   (<p> ^object-handle $ <ph>)
   (<w> ^on <on> ^above <ab> ^clear <ct>)
   (<on> ^argument1 <d> ^argument2 <oldp>)
   (<ab> ^argument1 <d> ^argument2 <oldbelow>)
   (<ct> ^argument1 <t>)
-->
   (log 1 (crlf) |Move disc | <size> | to peg | <ph>)
   (<on> ^argument2 <oldp> - <p>)
   (<ab> ^argument2 <oldbelow> - <t>)
   (<w> ^clear <ct> - <nc>)
   (<nc> ^argument1 <oldbelow>)
}
"""


def base_agent(v, about, control=True):
    a = Agent(F, v, T, about)
    a.settings += ['chunk never']
    problem_space(a)
    initialize(a, world_init(control), flags={'mea-operator-selection': 'true'})
    achievement_relation(a, operators=(v.endswith('-mea')))
    return a


def plain():
    a = base_agent('towers-of-hanoi', 'Towers of Hanoi, 5 discs, A to C, by the cyclic algorithm: the smallest disc moves on every other step, never back to the peg it came from.')
    a.add('move-disc.soar', """
    ## Smallest disc (size 1): moved when the last move was not of disc 1, to a peg it did not just leave.
    sp {towers-of-hanoi*propose*move-disc*smallest
       (state <s> ^problem-space.name towers-of-hanoi ^flags.mea-operator-selection true ^desireds.unachieved-desireds true ^world <w>)
       (<w> ^anchored-world true ^objects.object <d> <t> <p> <m>)
       (<d> ^type disc ^size 1)
       (<m> ^type memory ^lastsize <> 1 ^lastpeg { <> <ph> })
       (<p> ^type peg ^object-handle <ph>)
       (<w> ^clear <cd> <ct> ^on <ondp> <ontp>)
       (<cd> ^argument1 <d>)
       (<ct> ^argument1 <t>)
       (<ondp> ^argument1 <d> ^argument2 <> <p>)
       (<ontp> ^argument1 <t> ^argument2 <p>)
    -->
       (<s> ^operator <o> +)
       (<o> ^name move-disc ^task-operator true ^action-handle move-disc ^argument1 <d> ^argument2 <t> ^argument3 <p> ^argument-count 3 ^desireds <pre>)
       (<pre> ^desired-count 0)
    }

    ## Any other clear disc (sizes 2 to 5) after disc 1 moved: onto a clear larger disc or base on another peg.
    sp {towers-of-hanoi*propose*move-disc*other
       (state <s> ^problem-space.name towers-of-hanoi ^flags.mea-operator-selection true ^desireds.unachieved-desireds true ^world <w>)
       (<w> ^anchored-world true ^objects.object <d> <t> <p> <m>)
       (<d> ^type disc ^size { > 1 <size> })
       (<t> ^size > <size>)
       (<m> ^type memory ^lastsize 1)
       (<p> ^type peg)
       (<w> ^clear <cd> <ct> ^on <ondp> <ontp>)
       (<cd> ^argument1 <d>)
       (<ct> ^argument1 <t>)
       (<ondp> ^argument1 <d> ^argument2 <> <p>)
       (<ontp> ^argument1 <t> ^argument2 <p>)
    -->
       (<s> ^operator <o> +)
       (<o> ^name move-disc ^task-operator true ^action-handle move-disc ^argument1 <d> ^argument2 <t> ^argument3 <p> ^argument-count 3 ^desireds <pre>)
       (<pre> ^desired-count 0)
    }

    ## Control memory: size of the disc moved last, and (for disc 1) the peg it left.
    sp {towers-of-hanoi*apply*move-disc*control*smallest
       (state <s> ^operator <o> ^internal-actions true ^world <w>)
       (<o> ^name move-disc ^pre-conditions-satisfied true ^argument1 <d>)
       (<d> ^size 1 ^object-handle $ <dh>)
       (<w> ^anchored-world true ^objects.object <m> <d2> ^on <on>)
       (<d2> ^object-handle $ <dh>)
       (<on> ^argument1 <d2> ^argument2.object-handle <from>)
       (<m> ^type memory ^lastsize <ls> ^lastpeg <lp>)
    -->
       (<m> ^lastsize <ls> - 1 ^lastpeg <lp> - <from>)
    }

    sp {towers-of-hanoi*apply*move-disc*control*other
       (state <s> ^operator <o> ^internal-actions true ^world <w>)
       (<o> ^name move-disc ^pre-conditions-satisfied true ^argument1 <d>)
       (<d> ^size { > 1 <size> })
       (<w> ^anchored-world true ^objects.object <m>)
       (<m> ^type memory ^lastsize <ls>)
    -->
       (<m> ^lastsize <ls> - <size>)
    }
    """)
    a.add('move-disc.soar', APPLY)
    indifferent(a, 'the original makes its proposals indifferent (in this algorithm only one move is ever proposed)')
    return a.write()


def mea():
    a = base_agent('towers-of-hanoi-mea', 'Towers of Hanoi, 5 discs, A to C, by means-ends analysis: to move disc k to a peg, the smaller discs must first be on the third peg (operator subgoaling).', control=False)
    a.add('move-disc.soar', """
    ## Means-ends proposal (W-TOP-009): for an unachieved desired "disc D on peg P" whose disc is the largest one
    ## not yet in place in this desireds, move D onto P.  Preconditions (^desireds): every smaller disc is on
    ## the third peg; they are added by the operator elaboration below.  When they do not hold, the operator
    ## no-change substate gets them as its desireds (W-MEA-002, W-MEA-003): operator subgoaling.
    sp {towers-of-hanoi*propose*move-disc*mea
       (state <s> ^problem-space.name towers-of-hanoi ^flags.mea-operator-selection true ^desireds <ds> ^world <w>)
       (<ds> ^desired <g> ^unachieved <g>)
       (<g> ^on <gr>)
       (<gr> ^argument1.object-handle $ <dh> ^argument2.object-handle $ <ph>)
       (<w> ^anchored-world true ^objects.object <d> <p>)
       (<d> ^object-handle $ <dh> ^size <size>)
       (<p> ^object-handle $ <ph> ^type peg)
      -{(<ds> ^unachieved <g2>)
        (<g2> ^on.argument1.object-handle <h2>)
        (<w> ^objects.object <d2>)
        (<d2> ^object-handle <h2> ^size > <size>)}
    -->
       (<s> ^operator <o> +)
       (<o> ^name move-disc ^task-operator true ^action-handle move-disc ^super-desired <g> ^argument1 <d> ^argument3 <p> ^argument-count 3
            ^desireds <pre>)
       (<pre> ^desired-count (- <size> 1))
    }

    ## The third peg: neither the disc's current peg nor the target.
    sp {towers-of-hanoi*elaborate*move-disc*aux-peg
       (state <s> ^operator <o> + ^world <w>)
       (<o> ^name move-disc ^argument1 <d> ^argument3 <p>)
       (<w> ^anchored-world true ^on <on>)
       (<on> ^argument1 <d> ^argument2 { <> <p> <from> })
       (<w> ^objects.object { <> <p> <> <from> <z> })
       (<z> ^type peg)
    -->
       (<o> ^aux-peg <z>)
    }
    """)
    a.add('move-disc.soar', """
    ## Precondition desireds of move-disc: each smaller disc on the auxiliary peg.
    sp {towers-of-hanoi*elaborate*move-disc*preconditions
       (state <s> ^operator <o> + ^world <w>)
       (<o> ^name move-disc ^argument1 <d> ^aux-peg <z> ^desireds <pre>)
       (<d> ^size <size>)
       (<z> ^object-handle <zh>)
       (<w> ^anchored-world true ^objects.object <d2>)
       (<d2> ^type disc ^size < <size> ^object-handle <h2>)
    -->
       (<pre> ^desired <pd>)
       (<pd> ^on <pr>)
       (<pr> ^argument1 <pa1> ^argument2 <pa2>)
       (<pa1> ^object-handle <h2>)
       (<pa2> ^object-handle <zh>)
    }

    ## Destination: the clear object on the target peg (argument2).
    sp {towers-of-hanoi*elaborate*move-disc*destination
       (state <s> ^operator <o> + ^world <w>)
       (<o> ^name move-disc ^argument3 <p>)
       (<w> ^anchored-world true ^clear <ct> ^on <ont>)
       (<ct> ^argument1 <t>)
       (<ont> ^argument1 <t> ^argument2 <p>)
    -->
       (<o> ^argument2 <t>)
    }
    """)
    a.add('move-disc.soar', APPLY)
    a.add('move-disc.soar', """
    ## Precondition desireds may name the disc's own peg as target when the disc is already there; such a move
    ## is never proposed (the desired is achieved).  The original moves the largest misplaced disc first.
    sp {towers-of-hanoi*compare*move-disc*indifferent
       (state <s> ^problem-space.name towers-of-hanoi ^operator <o> +)
       (<o> ^task-operator true)
    -->
       (<s> ^operator <o> =)
    }
    """)
    return a.write()


if __name__ == '__main__':
    print(plain()); print(mea())
