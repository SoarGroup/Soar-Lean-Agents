"""kenken family, world-v6.  Cells, candidates (one per cell and value), cage tuples and the puzzle are world
objects; has-cand (cell, candidate) and in-tuple (candidate, tuple) are relations.  The original's absence tests
that decide failure, single candidates and pruning in look-ahead are replaced by maintained counts (W-CHK-004):
a cell's ^alive-count of live candidates and a candidate's ^live-tuples of live tuples using it."""
import re, os
from collections import defaultdict
from v6 import *

ORIG = '/home/claude/w/repo/Tasks/Families/kenken/original'
T = 'kenken'
TIE = {'kenken-4-5', 'kenken-6-1', 'kenken-6-2', 'kenken-6-3'}  # chosen by measurement (tie-impasse solves all seeds; operator depth does not)


def parse(v):
    t = open(f'{ORIG}/{v}/{v}/initialize-kenken.soar').read()
    rhs = t[t.index('initialize-kenken)\n-->', t.index('apply*initialize')):]
    attrs = defaultdict(lambda: defaultdict(list)); kind = {}
    for a, b, c in re.findall(r'\((<\w+>) \^([\w|-]+) ([^)]+)\)', rhs):
        b = b.strip('|'); c = c.strip().strip('|')
        if a == '<s>':
            kind[c] = b
        else:
            attrs[a][b].append(c)
    return attrs, kind


def init(v):
    attrs, kind = parse(v)
    name = lambda x: attrs[x]['name'][0]
    cells = [x for x, k in kind.items() if k == 'cell']
    cands = [x for x, k in kind.items() if k == 'cand']
    tuples = [x for x, k in kind.items() if k == 'tuple']
    puz = [x for x, k in kind.items() if k == 'puzzle'][0]
    n = len(cells) ** 0.5; n = int(round(n))
    L = ['(<objs> ^object ' + ' '.join(f'<o{name(x)}>' for x in cells + cands + tuples) + ' <opuzzle>)']
    for c in cells:
        a = attrs[c]
        L.append(f'(<o{name(c)}> ^object-handle {name(c)} ^anchored true ^type cell ^coord {a["coord"][0]} ^row {a["row"][0]} ^col {a["col"][0]} ^mark {a["mark"][0]} ^alive-count {len(a["cand"])})')
    k = 0
    uses = defaultdict(list)
    for tu in tuples:
        for x in attrs[tu]['uses']:
            uses[x].append(tu)
    for x in cands:
        a = attrs[x]
        alive_tuples = sum(1 for tu in uses[x] if attrs[tu]['alive'][0] == '1')
        L.append(f'(<o{name(x)}> ^object-handle {name(x)} ^anchored true ^type cand ^row {a["row"][0]} ^col {a["col"][0]} ^coord {a["coord"][0]} ^value {a["value"][0]} ^alive {a["alive"][0]} ^live-tuples {alive_tuples})')
        for tu in uses[x]:
            k += 1; L.append(f'(<w> ^in-tuple <r{k}>) (<r{k}> ^argument1 <o{name(x)}> ^argument2 <o{name(tu)}>)')
    for c in cells:
        for x in attrs[c]['cand']:
            k += 1; L.append(f'(<w> ^has-cand <r{k}>) (<r{k}> ^argument1 <o{name(c)}> ^argument2 <o{name(x)}>)')
    for tu in tuples:
        L.append(f'(<o{name(tu)}> ^object-handle {name(tu)} ^anchored true ^type tuple ^tid {attrs[tu]["tid"][0]} ^alive {attrs[tu]["alive"][0]})')
    L.append(f'(<opuzzle> ^object-handle puzzle ^anchored true ^type puzzle ^marks 0 ^gcell 0)')
    L.append(f'(<ds> ^desired-count 1 ^desired <d1>)\n(<d1> ^object <d1o>)\n(<d1o> ^object-handle puzzle ^marks {n * n})')
    return '\n'.join(L), n


KILL = """
   (<w> ^has-cand <hc>)
   (<hc> ^argument1 <cell> ^argument2 <x>)
   (<cell> ^alive-count <ac>)"""
KILLR = '(<cell> ^alive-count <ac> - (- <ac> 1))'


def rules(a, n):
    P = '(state <s> ^problem-space.name kenken ^flags.mea-operator-selection true ^desireds.unachieved-desireds true ^world <w>)\n       (<w> ^anchored-world true)'
    a.add('elaborations.soar', """
    ## Failure (W-DES-001): an unmarked cell with no live candidate, or a marked cell whose candidate for its mark
    ## is dead.  Both are positive tests on maintained counts and values (W-CHK-004).
    sp {kenken*elaborate*failure*no-candidate
       (state <s> ^problem-space.name kenken ^desireds <ds> ^world <w>)
       (<w> ^anchored-world true ^objects.object <c>)
       (<c> ^type cell ^mark 0 ^alive-count 0)
    -->
       (<s> ^failure <ds>)
    }

    sp {kenken*elaborate*failure*mark-dead
       (state <s> ^problem-space.name kenken ^desireds <ds> ^world <w>)
       (<w> ^anchored-world true ^objects.object <c> ^has-cand <hc>)
       (<c> ^type cell ^mark { <> 0 <m> })
       (<hc> ^argument1 <c> ^argument2 <x>)
       (<x> ^value <m> ^alive 0)
    -->
       (<s> ^failure <ds>)
    }

    ## Print the solved board (monitoring; the original prints it with print-row operators before halting).
    sp {kenken*elaborate*print-solution
       (state <s> ^superstate nil ^success <ds> ^desireds <ds> ^world <w>)
       (<w> ^anchored-world true)
    -->
       (write (crlf) |Solved.|)
    }
    """)
    a.add('assign.soar', f"""
    ## assign <cell> <cand>: the cell's only live candidate (alive-count 1) ...
    sp {{kenken*propose*assign*single
       {P}
       (<w> ^objects.object <p> <c> <x> ^has-cand <hc>)
       (<p> ^type puzzle)
       (<c> ^type cell ^mark 0 ^alive-count 1)
       (<hc> ^argument1 <c> ^argument2 <x>)
       (<x> ^alive 1)
    -->
       (<s> ^operator <o> +)
       (<o> ^name assign ^task-operator true ^action-handle assign ^argument1 <c> ^argument2 <x> ^argument-count 2 ^desireds <pre>)
       (<pre> ^desired-count 0)
    }}
    """)
    for line in ('row', 'col'):
        a.add('assign.soar', f"""
        ## ... or the only live candidate for its value in its {line} (as the original, an absence test).
        sp {{kenken*propose*assign*hidden-{line}
           {P}
           (<w> ^objects.object <p> <c> <x> ^has-cand <hc>)
           (<p> ^type puzzle)
           (<c> ^type cell ^mark 0 ^{line} <l> ^coord <cc>)
           (<hc> ^argument1 <c> ^argument2 <x>)
           (<x> ^alive 1 ^value <v>)
          -{{(<w> ^objects.object <y>)
            (<y> ^type cand ^{line} <l> ^value <v> ^alive 1 ^coord <> <cc>)}}
        -->
           (<s> ^operator <o> +)
           (<o> ^name assign ^task-operator true ^action-handle assign ^argument1 <c> ^argument2 <x> ^argument-count 2 ^desireds <pre>)
           (<pre> ^desired-count 0)
        }}
        """)
    a.add('assign.soar', """
    sp {kenken*apply*assign*internal
       (state <s> ^operator <o> ^internal-actions true ^world <w>)
       (<o> ^name assign ^pre-conditions-satisfied true ^argument1.object-handle $ <ch> ^argument2.object-handle $ <xh>)
       (<w> ^anchored-world true ^objects.object <c> <x> <p>)
       (<c> ^object-handle $ <ch> ^mark <m> ^coord <cc>)
       (<x> ^object-handle $ <xh> ^value <v>)
       (<p> ^type puzzle ^marks <n>)
    -->
       (log 1 (crlf) |Set cell: | <cc> | to | <v>)
       (<c> ^mark <m> - <v>)
       (<p> ^marks <n> - (+ <n> 1))
    }

    sp {kenken*apply*guess*internal
       (state <s> ^operator <o> ^internal-actions true ^world <w>)
       (<o> ^name guess ^pre-conditions-satisfied true ^argument1.object-handle $ <ch> ^argument2.object-handle $ <xh>)
       (<w> ^anchored-world true ^objects.object <c> <x> <p>)
       (<c> ^object-handle $ <ch> ^mark <m> ^coord <cc>)
       (<x> ^object-handle $ <xh> ^value <v>)
       (<p> ^type puzzle ^marks <n> ^gcell <g>)
    -->
       (log 1 (crlf) |Guess: | <cc> | to | <v>)
       (<c> ^mark <m> - <v>)
       (<p> ^marks <n> - (+ <n> 1) ^gcell <g> - 0)
    }

    ## guess <cell> <cand>: any live candidate of the chosen guess cell.  Only an acceptable preference, so the
    ## guesses tie and look-ahead chooses (as in the original).
    sp {kenken*propose*guess
       (state <s> ^problem-space.name kenken ^flags.mea-operator-selection true ^desireds.unachieved-desireds true ^world <w>)
       (<w> ^anchored-world true ^objects.object <p> <c> <x> ^has-cand <hc>)
       (<p> ^type puzzle ^gcell <cc>)
       (<c> ^type cell ^coord <cc>)
       (<hc> ^argument1 <c> ^argument2 <x>)
       (<x> ^alive 1)
    -->
       (<s> ^operator <o> +)
       (<o> ^name guess ^task-operator true ^action-handle guess ^argument1 <c> ^argument2 <x> ^argument-count 2 ^desireds <pre>)
       (<pre> ^desired-count 0)
    }
    """)
    for k in (2, 3):
        a.add('choose-cell.soar', f"""
        ## choose-cell ({k} live candidates): pick the cell to guess in.
        sp {{kenken*propose*choose-cell*{k}
           {P}
           (<w> ^objects.object <p> <c>)
           (<p> ^type puzzle ^gcell 0)
           (<c> ^type cell ^mark 0 ^alive-count {k})
        -->
           (<s> ^operator <o> +)
           (<o> ^name choose-cell-{k} ^task-operator true ^action-handle choose-cell ^argument1 <c> ^argument-count 1 ^desireds <pre>)
           (<pre> ^desired-count 0)
        }}

        sp {{kenken*compare*choose-cell-{k}*last
           (state <s> ^problem-space.name kenken ^operator <o> +)
           (<o> ^name choose-cell-{k})
        -->
           (<s> ^operator <o> <)
        }}
        """)
    a.add('choose-cell.soar', """
    sp {kenken*apply*choose-cell*internal
       (state <s> ^operator <o> ^internal-actions true ^world <w>)
       (<o> ^name << choose-cell-2 choose-cell-3 >> ^pre-conditions-satisfied true ^argument1.object-handle $ <ch>)
       (<w> ^anchored-world true ^objects.object <c> <p>)
       (<c> ^object-handle $ <ch> ^coord <cc>)
       (<p> ^type puzzle ^gcell <g>)
    -->
       (log 1 (crlf) |Guess cell: | <cc>)
       (<p> ^gcell <g> - <cc>)
    }

    sp {kenken*compare*choose-cell*two-before-three
       (state <s> ^problem-space.name kenken ^operator <o> + ^operator { <> <o> <o2> } +)
       (<o> ^name choose-cell-2)
       (<o2> ^name choose-cell-3)
    -->
       (<s> ^operator <o> > <o2>)
    }
    """)
    a.add('propagate.soar', f"""
    ## cleanup <cell> <cand>: a marked cell's other live candidates die.
    sp {{kenken*propose*cleanup
       {P}
       (<w> ^objects.object <c> ^has-cand <hc>)
       (<c> ^type cell ^mark {{ <> 0 <m> }})
       (<hc> ^argument1 <c> ^argument2 <x>)
       (<x> ^alive 1 ^value <> <m>)
    -->
       (<s> ^operator <o> +)
       (<o> ^name cleanup ^task-operator true ^action-handle kill-candidate ^argument1 <x> ^argument-count 1 ^desireds <pre>)
       (<pre> ^desired-count 0)
    }}

    ## eliminate <cand>: a live candidate with the value of a marked cell in its row or column dies.
    sp {{kenken*propose*eliminate*row
       {P}
       (<w> ^objects.object <c1> <c2> <x> ^has-cand <hc>)
       (<c1> ^type cell ^mark {{ <> 0 <m> }} ^row <r>)
       (<c2> ^type cell ^row <r>)
       (<hc> ^argument1 {{ <> <c1> <c2> }} ^argument2 <x>)
       (<x> ^alive 1 ^value <m>)
    -->
       (<s> ^operator <o> +)
       (<o> ^name eliminate ^task-operator true ^action-handle kill-candidate ^argument1 <x> ^argument-count 1 ^desireds <pre>)
       (<pre> ^desired-count 0)
    }}

    sp {{kenken*propose*eliminate*col
       {P}
       (<w> ^objects.object <c1> <c2> <x> ^has-cand <hc>)
       (<c1> ^type cell ^mark {{ <> 0 <m> }} ^col <r>)
       (<c2> ^type cell ^col <r>)
       (<hc> ^argument1 {{ <> <c1> <c2> }} ^argument2 <x>)
       (<x> ^alive 1 ^value <m>)
    -->
       (<s> ^operator <o> +)
       (<o> ^name eliminate ^task-operator true ^action-handle kill-candidate ^argument1 <x> ^argument-count 1 ^desireds <pre>)
       (<pre> ^desired-count 0)
    }}

    ## prune <cand>: a live candidate that no live tuple uses (live-tuples 0) dies.
    sp {{kenken*propose*prune
       {P}
       (<w> ^objects.object <x>)
       (<x> ^type cand ^alive 1 ^live-tuples 0)
    -->
       (<s> ^operator <o> +)
       (<o> ^name prune ^task-operator true ^action-handle kill-candidate ^argument1 <x> ^argument-count 1 ^desireds <pre>)
       (<pre> ^desired-count 0)
    }}

    ## Killing a candidate (cleanup, eliminate, prune): alive 0 and its cell's alive-count down by one.
    sp {{kenken*apply*kill-candidate*internal
       (state <s> ^operator <o> ^internal-actions true ^world <w>)
       (<o> ^name << cleanup eliminate prune >> ^pre-conditions-satisfied true ^argument1.object-handle $ <xh>)
       (<w> ^anchored-world true ^objects.object <x>)
       (<x> ^object-handle $ <xh> ^alive 1){KILL}
    -->
       (log 2 (crlf) |Kill | <xh>)
       (<x> ^alive 1 - 0)
       {KILLR}
    }}

    ## drop-tuple <tuple>: a live tuple that uses a dead candidate dies; each candidate it uses loses a live tuple.
    sp {{kenken*propose*drop-tuple
       {P}
       (<w> ^objects.object <t> <x> ^in-tuple <it>)
       (<t> ^type tuple ^alive 1)
       (<it> ^argument1 <x> ^argument2 <t>)
       (<x> ^alive 0)
    -->
       (<s> ^operator <o> +)
       (<o> ^name drop-tuple ^task-operator true ^action-handle drop-tuple ^argument1 <t> ^argument-count 1 ^desireds <pre>)
       (<pre> ^desired-count 0)
    }}

    sp {{kenken*apply*drop-tuple*internal
       (state <s> ^operator <o> ^internal-actions true ^world <w>)
       (<o> ^name drop-tuple ^pre-conditions-satisfied true ^argument1.object-handle $ <th>)
       (<w> ^anchored-world true ^objects.object <t>)
       (<t> ^object-handle $ <th> ^alive 1)
    -->
       (log 2 (crlf) |Drop tuple | <th>)
       (<t> ^alive 1 - 0)
    }}

    sp {{kenken*apply*drop-tuple*internal*count
       (state <s> ^operator <o> ^internal-actions true ^world <w>)
       (<o> ^name drop-tuple ^pre-conditions-satisfied true ^argument1.object-handle $ <th>)
       (<w> ^anchored-world true ^objects.object <t> <x> ^in-tuple <it>)
       (<t> ^object-handle $ <th> ^alive 1)
       (<it> ^argument1 <x> ^argument2 <t>)
       (<x> ^live-tuples <n>)
    -->
       (<x> ^live-tuples <n> - (- <n> 1))
    }}

    ## The original makes every operator except guess indifferent.
    sp {{kenken*compare*task-operator*indifferent
       (state <s> ^problem-space.name kenken ^operator <o> +)
       (<o> ^task-operator true ^name <> guess)
    -->
       (<s> ^operator <o> =)
    }}
    """)


def build(v):
    text, n = init(v)
    a = Agent('kenken', v, T, f'KenKen {n}x{n} ({v}): constraint propagation over candidates and cage tuples; when stuck, choose a cell with 2 (then 3) candidates and guess, with look-ahead choosing the guess.')
    a.settings += ['chunk always', 'chunk add-osk on', 'chunk allow-local-negations off']
    problem_space(a, ' ^copy-relation has-cand ^copy-relation in-tuple')
    flags = {'mea-operator-selection': 'true'}
    if v in TIE: flags['iterative-step'] = 'tie-impasse'
    initialize(a, text, flags=flags)
    achievement_object(a)
    rules(a, n)
    return a.write()


if __name__ == '__main__':
    for v in sorted(os.listdir(ORIG)):
        print(build(v))
