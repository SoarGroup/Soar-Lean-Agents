"""knights family (closed knight's tour by depth-first search with backup, Warnsdorff ordering), world-v6."""
from v6 import *

F, T = 'knights', 'knights'


def board(n):
    sq = [(r, c) for r in range(1, n + 1) for c in range(1, n + 1)]
    jumps = {s: [(s[0] + dr, s[1] + dc) for dr, dc in ((-2, -1), (-2, 1), (-1, -2), (-1, 2), (1, -2), (1, 2), (2, -1), (2, 1))
                 if 1 <= s[0] + dr <= n and 1 <= s[1] + dc <= n] for s in sq}
    return sq, jumps


def init_text(n):
    sq, jumps = board(n)
    name = lambda s: f'b{s[0]}{s[1]}'
    var = lambda s: f'<{name(s)}>'
    L = ['(<objs> ^object <tour> ' + ' '.join(var(s) for s in sq) + ')']
    for s in sq:
        start = s == (2, 3)
        L.append(f'({var(s)} ^object-handle {name(s)} ^anchored true ^type square ^coord {s[0]}{s[1]} ^used {1 if start else 0}'
                 f' ^degree {len(jumps[s])} ^visit {1 if start else 0} ^prev {name(s)})')
    k = 0
    for s in sq:
        for t in jumps[s]:
            k += 1
            L.append(f'(<w> ^jump <j{k}>) (<j{k}> ^argument1 {var(s)} ^argument2 {var(t)})')
    L.append('(<tour> ^object-handle tour ^anchored true ^type tour ^depth 1 ^moves 0 ^frame 1 ^solutions 0 ^goal 0 ^done 0 ^at b23 ^first b23)')
    L.append('(<ds> ^desired-count 1 ^desired <d1>)\n(<d1> ^object <d1o>)\n(<d1o> ^object-handle tour ^done 1)')
    return '\n'.join(L)


def build(n):
    v = f'knights-{n}'
    a = Agent(F, v, T, f'Knight\'s tour on a {n}x{n} board from b23: depth-first search with backup and lowest-degree-first ordering; counts closed tours until the search is exhausted or 1,000,000 moves.')
    a.settings += ['chunk never']
    problem_space(a)
    initialize(a, init_text(n), flags={'mea-operator-selection': 'true'})
    achievement_object(a)
    last = n * n
    T0 = '(state <s> ^problem-space.name knights ^flags.mea-operator-selection true ^desireds.unachieved-desireds true ^world <w>)\n       (<w> ^anchored-world true ^objects.object <t>)\n       (<t> ^type tour ^done 0 ^at $ <ch>)'
    a.add('knight-move.soar', f"""
    ## The squares are world objects; the knight's moves are jump relations (W-REL-001).  The tour object
    ## records where the knight is, by handle (W-OBJ-004).
    ## knight-move <from> <to>: to an unused square not yet tried from this visit of <from>.
    sp {{knights*propose*knight-move
       {T0}
       (<w> ^objects.object <c> <y> ^jump <j>)
       (<c> ^object-handle $ <ch> ^visit <cv>)
       (<j> ^argument1 <c> ^argument2 <y>)
       (<y> ^used 0 -^tried <cv>)
    -->
       (<s> ^operator <o> +)
       (<o> ^name knight-move ^task-operator true ^action-handle knight-move ^argument1 <c> ^argument2 <y> ^argument-count 2 ^desireds <pre>)
       (<pre> ^desired-count 0)
    }}

    sp {{knights*apply*knight-move*internal
       (state <s> ^operator <o> ^internal-actions true ^world <w>)
       (<o> ^name knight-move ^pre-conditions-satisfied true ^argument1.object-handle $ <ch> ^argument2.object-handle $ <yh>)
       (<w> ^anchored-world true ^objects.object <t> <y>)
       (<t> ^type tour ^at <at> ^frame <f> ^depth <d> ^moves <m>)
       (<y> ^object-handle $ <yh> ^used <u> ^prev <p> ^visit <v>)
    -->
       (log 2 (crlf) |Move to | <yh>)
       (<t> ^at <at> - <yh> ^frame <f> - (+ <f> 1) ^depth <d> - (+ <d> 1) ^moves <m> - (+ <m> 1))
       (<y> ^used <u> - 1 ^prev <p> - <ch> ^visit <v> - (+ <f> 1))
    }}

    ## Each square a jump away from the new square loses one free neighbour.
    sp {{knights*apply*knight-move*internal*degree
       (state <s> ^operator <o> ^internal-actions true ^world <w>)
       (<o> ^name knight-move ^pre-conditions-satisfied true ^argument2 <y>)
       (<w> ^anchored-world true ^jump <j>)
       (<j> ^argument1 <y> ^argument2 <z>)
       (<z> ^degree <g>)
    -->
       (<z> ^degree <g> - (- <g> 1))
    }}
    """)
    backups = [
        ('dead-end', '(<c> ^visit <cv>)\n      -{(<w> ^jump <j>)\n        (<j> ^argument1 <c> ^argument2 <y>)\n        (<y> ^used 0 -^tried <cv>)}'),
        ('after-goal', '(<t> ^goal 1)'),
        ('two-forced', f'(<t> ^depth < {last})\n       (<w> ^jump <j1> {{ <> <j1> <j2> }})\n       (<j1> ^argument1 <c> ^argument2 <y1>)\n       (<j2> ^argument1 <c> ^argument2 {{ <> <y1> <y2> }})\n       (<y1> ^used 0 ^degree 1)\n       (<y2> ^used 0 ^degree 1)'),
    ]
    if n == 6:
        backups.append(('tried-forced', '(<c> ^visit <cv>)\n       (<w> ^jump <j>)\n       (<j> ^argument1 <c> ^argument2 <y>)\n       (<y> ^tried <cv> ^degree 1)'))
    for nm, cond in backups:
        a.add('backup.soar', f"""
        ## backup <square> <previous> ({nm}): return to the square the knight came from.
        sp {{knights*propose*backup*{nm}
           {T0}
           (<w> ^objects.object <c> <p>)
           (<c> ^object-handle $ <ch> ^prev {{ <> <ch> <ph> }})
           (<p> ^object-handle $ <ph>)
           {cond}
        -->
           (<s> ^operator <o> +)
           (<o> ^name backup ^task-operator true ^action-handle backup ^argument1 <c> ^argument2 <p> ^argument-count 2 ^desireds <pre>)
           (<pre> ^desired-count 0)
        }}
        """)
    a.add('backup.soar', """
    sp {knights*apply*backup*internal
       (state <s> ^operator <o> ^internal-actions true ^world <w>)
       (<o> ^name backup ^pre-conditions-satisfied true ^argument1.object-handle $ <ch> ^argument2.object-handle $ <ph>)
       (<w> ^anchored-world true ^objects.object <t> <c> <p>)
       (<t> ^type tour ^at <at> ^depth <d> ^moves <m> ^goal <g>)
       (<c> ^object-handle $ <ch> ^used <u>)
       (<p> ^object-handle $ <ph> ^visit <pv>)
    -->
       (log 2 (crlf) |Back to | <ph>)
       (<t> ^at <at> - <ph> ^depth <d> - (- <d> 1) ^moves <m> - (+ <m> 1) ^goal <g> - 0)
       (<c> ^used <u> - 0 ^tried <pv>)
    }

    ## Each square a jump away regains a free neighbour and forgets what was tried from this visit.
    sp {knights*apply*backup*internal*degree
       (state <s> ^operator <o> ^internal-actions true ^world <w>)
       (<o> ^name backup ^pre-conditions-satisfied true ^argument1 <c>)
       (<c> ^visit <cv>)
       (<w> ^anchored-world true ^jump <j>)
       (<j> ^argument1 <c> ^argument2 <z>)
       (<z> ^degree <g>)
    -->
       (<z> ^degree <g> - (+ <g> 1) ^tried <cv> -)
    }
    """)
    a.add('detect-goal.soar', f"""
    ## detect-goal <square>: all {last} squares visited and the first square is a jump away: a closed tour.
    sp {{knights*propose*detect-goal
       {T0}
       (<t> ^goal 0 ^depth {last} ^first <fh>)
       (<w> ^objects.object <c> <f> ^jump <j>)
       (<c> ^object-handle $ <ch>)
       (<f> ^object-handle $ <fh>)
       (<j> ^argument1 <c> ^argument2 <f>)
    -->
       (<s> ^operator <o> +)
       (<o> ^name detect-goal ^task-operator true ^action-handle detect-goal ^argument1 <c> ^argument-count 1 ^desireds <pre>)
       (<pre> ^desired-count 0)
    }}

    sp {{knights*apply*detect-goal*internal
       (state <s> ^operator <o> ^internal-actions true ^world <w>)
       (<o> ^name detect-goal ^pre-conditions-satisfied true ^argument1 <c>)
       (<c> ^coord <cc>)
       (<w> ^anchored-world true ^objects.object <t>)
       (<t> ^type tour ^solutions <n> ^goal <g>)
    -->
       (log 1 (crlf) |Success! | (+ <n> 1) | | <cc>)
       (<t> ^solutions <n> - (+ <n> 1) ^goal <g> - 1)
    }}

    ## exhausted <tour>: back at the first square with no untried move left: the search is complete.
    sp {{knights*propose*exhausted
       {T0}
       (<t> ^first <ch>)
       (<w> ^objects.object <c>)
       (<c> ^object-handle $ <ch> ^visit <cv>)
      -{{(<w> ^jump <j>)
        (<j> ^argument1 <c> ^argument2 <y>)
        (<y> ^used 0 -^tried <cv>)}}
    -->
       (<s> ^operator <o> +)
       (<o> ^name exhausted ^task-operator true ^action-handle exhausted ^argument1 <t> ^argument-count 1 ^desireds <pre>)
       (<pre> ^desired-count 0)
    }}

    ## finish-run <tour>: stop after 1,000,000 moves.
    sp {{knights*propose*finish-run
       (state <s> ^problem-space.name knights ^flags.mea-operator-selection true ^desireds.unachieved-desireds true ^world <w>)
       (<w> ^anchored-world true ^objects.object <t>)
       (<t> ^type tour ^done 0 ^moves >= 1000000)
    -->
       (<s> ^operator <o> +)
       (<o> ^name finish-run ^task-operator true ^action-handle finish-run ^argument1 <t> ^argument-count 1 ^desireds <pre>)
       (<pre> ^desired-count 0)
    }}

    sp {{knights*apply*finish*internal
       (state <s> ^operator <o> ^internal-actions true ^world <w>)
       (<o> ^name << exhausted finish-run >> ^pre-conditions-satisfied true ^argument1.object-handle $ <th>)
       (<w> ^anchored-world true ^objects.object <t>)
       (<t> ^object-handle $ <th> ^done <dn> ^solutions <n>)
    -->
       (log 1 (crlf) |Search over: | <n> | solutions|)
       (<t> ^done <dn> - 1)
    }}
    """)
    a.add('search-control.soar', """
    ## Search control of the original (preferences.soar), as evaluation rules in the task state.
    sp {knights*compare*finish-first
       (state <s> ^problem-space.name knights ^operator <o> + ^operator { <> <o> <o2> } +)
       (<o> ^name finish-run)
       (<o2> ^name << knight-move backup detect-goal >>)
    -->
       (<s> ^operator <o> > <o2>)
    }

    sp {knights*compare*goal-before-backup
       (state <s> ^problem-space.name knights ^operator <o> + ^operator { <> <o> <o2> } +)
       (<o> ^name detect-goal)
       (<o2> ^name << knight-move backup >>)
    -->
       (<s> ^operator <o> > <o2>)
    }

    sp {knights*compare*backup-before-move
       (state <s> ^problem-space.name knights ^operator <o> + ^operator { <> <o> <o2> } +)
       (<o> ^name backup)
       (<o2> ^name knight-move)
    -->
       (<s> ^operator <o> > <o2>)
    }

    sp {knights*compare*lower-degree
       (state <s> ^problem-space.name knights ^operator <o> + ^operator { <> <o> <o2> } +)
       (<o> ^name knight-move ^argument2.degree <g>)
       (<o2> ^name knight-move ^argument2.degree > <g>)
    -->
       (<s> ^operator <o> > <o2>)
    }

    sp {knights*compare*degree-one
       (state <s> ^problem-space.name knights ^operator <o> +)
       (<o> ^name knight-move ^argument2 <y>)
       (<y> ^degree 1 ^coord <> 23)
    -->
       (<s> ^operator <o> >)
    }

    sp {knights*compare*task-operator*indifferent
       (state <s> ^problem-space.name knights ^operator <o> +)
       (<o> ^task-operator true)
    -->
       (<s> ^operator <o> =)
    }
    """)
    return a.write()


if __name__ == '__main__':
    print(build(6)); print(build(8))
