"""missionaries-cannibals family, world-v6."""
from v6 import *

F, T = 'missionaries-cannibals', 'mac'
INIT = """
(<objs> ^object <l> <r>)
(<l> ^object-handle left ^anchored true ^type bank ^missionaries 3 ^cannibals 3 ^boat 1 ^other-bank right)
(<r> ^object-handle right ^anchored true ^type bank ^missionaries 0 ^cannibals 0 ^boat 0 ^other-bank left)
(<ds> ^desired-count 2 ^desired <d1> <d2>{better})
(<d1> ^object <d1o>)
(<d1o> ^object-handle right ^missionaries 3)
(<d2> ^object <d2o>)
(<d2o> ^object-handle right ^cannibals 3)
"""
LOADS = [(0, 1), (0, 2), (1, 0), (1, 1), (2, 0)]


def base(v, about, better=False):
    a = Agent(F, v, T, about)
    problem_space(a)
    initialize(a, INIT.replace('{better}', ' ^better higher' if better else ''), flags={'mea-operator-selection': 'true'})
    achievement_object(a)
    for m, c in LOADS:
        a.add('move-boat.soar', f"""
        ## move-boat <from> <to> carrying {m} missionaries and {c} cannibals: the boat is at <from>, which has them.
        sp {{mac*propose*move-boat*m{m}*c{c}
           (state <s> ^problem-space.name mac ^flags.mea-operator-selection true ^desireds.unachieved-desireds true ^world <w>)
           (<w> ^anchored-world true ^objects.object <from> <to>)
           (<from> ^type bank ^boat 1 ^other-bank <th> ^missionaries >= {m} ^cannibals >= {c})
           (<to> ^object-handle $ <th>)
        -->
           (<s> ^operator <o> +)
           (<o> ^name move-boat ^task-operator true ^action-handle move-boat ^argument1 <from> ^argument2 <to> ^argument-count 2
                ^missionaries {m} ^cannibals {c} ^desireds <pre>)
           (<pre> ^desired-count 0)
        }}
        """)
    a.add('move-boat.soar', """
    sp {mac*apply*move-boat*internal
       (state <s> ^operator <o> ^internal-actions true ^world <w>)
       (<o> ^name move-boat ^pre-conditions-satisfied true ^argument1.object-handle $ <fh> ^argument2.object-handle $ <th>
            ^missionaries <m> ^cannibals <c>)
       (<w> ^anchored-world true ^objects.object <from> <to>)
       (<from> ^object-handle $ <fh> ^missionaries <fm> ^cannibals <fc> ^boat <fb>)
       (<to> ^object-handle $ <th> ^missionaries <tm> ^cannibals <tc> ^boat <tb>)
    -->
       (log 1 (crlf) |Move boat | <fh> | -> | <th> |: | <m> | M, | <c> | C|)
       (<from> ^missionaries <fm> - (- <fm> <m>) ^cannibals <fc> - (- <fc> <c>) ^boat <fb> - 0)
       (<to> ^missionaries <tm> - (+ <tm> <m>) ^cannibals <tc> - (+ <tc> <c>) ^boat <tb> - 1)
    }
    """)
    a.add('elaborations.soar', """
    ## Failure: on some bank the missionaries (if any) are outnumbered (W-DES-001: ^failure <desireds>).
    ## At the top state the library reports the failure and interrupts (W-DES-017).
    sp {mac*elaborate*failure*outnumbered
       (state <s> ^problem-space.name mac ^desireds <ds> ^world <w>)
       (<w> ^anchored-world true ^objects.object <b>)
       (<b> ^type bank ^cannibals <c> ^missionaries { > 0 < <c> })
    -->
       (<s> ^failure <ds>)
    }
    """)
    return a


def duplicate(a):
    ancestors(a)
    a.add('state-evaluation.soar', """
    ## Look-ahead: a state equal to an ancestor task state (both banks) is a failure (original
    ## mac*evaluate*state*failure*duplicate).
    sp {mac*elaborate*look-ahead*duplicate
       (state <s> ^problem-space.name mac ^tried-tied-operator <any> ^desireds <ds> ^world <w> ^ancestor-world <aw>)
       (<w> ^objects.object <l> <r>)
       (<l> ^object-handle $ left ^missionaries <lm> ^cannibals <lc> ^boat <lb>)
       (<r> ^object-handle $ right ^missionaries <rm> ^cannibals <rc>)
       (<aw> ^objects.object <al> <ar>)
       (<al> ^object-handle $ left ^missionaries <lm> ^cannibals <lc> ^boat <lb>)
       (<ar> ^object-handle $ right ^missionaries <rm> ^cannibals <rc>)
    -->
       (<s> ^failure <ds>)
    }
    """)


def build():
    out = []
    a = base('mac', 'Missionaries and cannibals (3 and 3), random choice of crossings; an outnumbered bank is a failure.')
    a.settings += ['chunk never']; indifferent(a); out.append(a.write())

    a = base('mac-look-ahead', 'Missionaries and cannibals by look-ahead; repeated states and outnumbered banks are failures.')
    a.settings += ['chunk always', 'chunk add-osk on']; duplicate(a); out.append(a.write())

    a = base('mac-look-ahead-numeric', 'Missionaries and cannibals by look-ahead with a numeric evaluation: people on the right bank (higher is better).', better=True)
    a.settings += ['chunk always', 'chunk add-osk on']; duplicate(a)
    a.add('state-evaluation.soar', """
    ## Numeric evaluation of a look-ahead state (W-LAH-006): the number of people on the right bank;
    ## the goal set declares ^better higher (W-DES-018).
    sp {mac*elaborate*look-ahead*numeric-value
       (state <s> ^problem-space.name mac ^tried-tied-operator <any> ^world <w>)
       (<w> ^objects.object <r>)
       (<r> ^object-handle $ right ^missionaries <m> ^cannibals <c>)
    -->
       (<s> ^numeric-value (+ <m> <c>))
    }
    """)
    out.append(a.write())

    a = base('mac-rl', 'Missionaries and cannibals with RL over both banks (templates); reward -1 failure, +1 success, -0.01 per step.')
    a.settings += ['chunk never', 'rl --set learning on', 'rl --set learning-rate 0.100000', 'rl --set discount-rate 0.500000',
                   'indifferent-selection --epsilon-greedy']
    a.add('rl.soar', """
    ## RL template over the move and both banks (RL-007; STA-029: other-bank, which never changes, left out).
    sp {mac*rl*move-boat
       :template
       (state <s> ^problem-space.name mac ^operator <o> +)
       (<o> ^name move-boat ^argument1 <from> ^argument2 <to> ^missionaries <m> ^cannibals <c>)
       (<from> ^object-handle <fh> ^missionaries <fm> ^cannibals <fc> ^boat <fb>)
       (<to> ^object-handle <th> ^missionaries <tm> ^cannibals <tc> ^boat <tb>)
    -->
       (<s> ^operator <o> = 0)
    }

    sp {mac*elaborate*reward*failure
       (state <s> ^problem-space.name mac ^reward-link <r> ^failure <any>)
    -->
       (<r> ^reward <rw>)
       (<rw> ^value -1)
    }

    sp {mac*elaborate*reward*success
       (state <s> ^problem-space.name mac ^reward-link <r> ^success <any>)
    -->
       (<r> ^reward <rw>)
       (<rw> ^value 1)
    }

    sp {mac*elaborate*reward*step
       (state <s> ^problem-space.name mac ^reward-link <r>)
    -->
       (<r> ^reward <rw>)
       (<rw> ^value -0.01)
    }
    """)
    indifferent(a, 'the original chooses by RL values among indifferent operators'); out.append(a.write())
    return out


if __name__ == '__main__':
    for p in build(): print(p)
