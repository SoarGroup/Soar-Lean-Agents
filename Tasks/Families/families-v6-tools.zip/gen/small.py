"""hello-world and counting families, world-v6."""
from v6 import *


def hello_world():
    a = Agent('hello-world', 'hello-world', 'hello-world', 'Hello world: write a greeting once.')
    a.settings += ['chunk never']
    problem_space(a)
    initialize(a, """
    (<objs> ^object <g>)
    (<g> ^object-handle greeting ^anchored true ^type greeting ^written 0)
    (<ds> ^desired-count 1 ^desired <d1>)
    (<d1> ^object <d1o>)
    (<d1o> ^object-handle greeting ^written 1)
    """, flags={'mea-operator-selection': 'true'})
    achievement_object(a)
    a.add('hello-world-operator.soar', """
    ## hello-world <greeting>: write the greeting when it has not been written.
    sp {hello-world*propose*hello-world
       (state <s> ^problem-space.name hello-world ^flags.mea-operator-selection true ^desireds.unachieved-desireds true ^world <w>)
       (<w> ^anchored-world true ^objects.object <g>)
       (<g> ^type greeting ^written 0)
    -->
       (<s> ^operator <o> +)
       (<o> ^name hello-world ^task-operator true ^action-handle hello-world ^argument1 <g> ^argument-count 1 ^desireds <pre>)
       (<pre> ^desired-count 0)
    }

    sp {hello-world*apply*hello-world*internal
       (state <s> ^operator <o> ^internal-actions true ^world <w>)
       (<o> ^name hello-world ^pre-conditions-satisfied true ^argument1.object-handle $ <h>)
       (<w> ^anchored-world true ^objects.object <g>)
       (<g> ^object-handle $ <h> ^written <old>)
    -->
       (log 1 (crlf) |Apply hello-world: | <h>)
       (write (crlf) |Hello World|)
       (<g> ^written <old> - 1)
    }
    """)
    return a.write()


def counter_init(a, start, goal):
    initialize(a, f"""
    (<objs> ^object <c>)
    (<c> ^object-handle counter ^anchored true ^type counter ^value {start})
    (<ds> ^desired-count 1 ^desired <d1>)
    (<d1> ^object <d1o>)
    (<d1o> ^object-handle counter ^value {goal})
    """, flags={'mea-operator-selection': 'true'})


def count_up():
    a = Agent('counting', 'count-up', 'count-up', 'Count a counter from 0 to 100, one step per operator.')
    a.settings += ['chunk never']
    problem_space(a); counter_init(a, 0, 100); achievement_object(a)
    a.add('count.soar', """
    ## count <counter>: add 1 while the value is below 100.
    sp {count-up*propose*count
       (state <s> ^problem-space.name count-up ^flags.mea-operator-selection true ^desireds.unachieved-desireds true ^world <w>)
       (<w> ^anchored-world true ^objects.object <c>)
       (<c> ^type counter ^value < 100)
    -->
       (<s> ^operator <o> +)
       (<o> ^name count ^task-operator true ^action-handle count ^argument1 <c> ^argument-count 1 ^desireds <pre>)
       (<pre> ^desired-count 0)
    }

    sp {count-up*apply*count*internal
       (state <s> ^operator <o> ^internal-actions true ^world <w>)
       (<o> ^name count ^pre-conditions-satisfied true ^argument1.object-handle $ <h>)
       (<w> ^anchored-world true ^objects.object <c>)
       (<c> ^object-handle $ <h> ^value <v>)
    -->
       (log 1 (crlf) |Apply count: | <v>)
       (<c> ^value <v> - (+ <v> 1))
    }
    """)
    return a.write()


def count_in_substate():
    a = Agent('counting', 'count-in-substate', 'count-in-substate',
              'Count from 1 to 75000 in the substate of one composite operator (count-to-limit).')
    a.settings += ['chunk never']
    problem_space(a); counter_init(a, 1, 75000); achievement_object(a)
    a.add('count-to-limit.soar', """
    ## count-to-limit <counter> (composite, W-COP-002): effect: the counter is 75000.  It counts in a local
    ## count on its implementation substate (problem space count-to-limit, W-COP-007), then writes the result.
    sp {count-in-substate*propose*count-to-limit
       (state <s> ^problem-space.name count-in-substate ^flags.mea-operator-selection true ^desireds.unachieved-desireds true ^world <w>)
       (<w> ^anchored-world true ^objects.object <c>)
       (<c> ^type counter ^value < 75000)
    -->
       (<s> ^operator <o> +)
       (<o> ^name count-to-limit ^task-operator true ^argument1 <c> ^argument-count 1 ^desireds <pre> ^effect-desireds <ed>)
       (<pre> ^desired-count 0)
       (<ed> ^desired-count 1 ^desired <e1>)
       (<e1> ^object <e1o>)
       (<e1o> ^object-handle counter ^value 75000)
    }

    ## init-local: copy the counter's value to the substate's local count (internal operator, W-NOP-001).
    sp {count-in-substate*propose*init-local
       (state <s> ^problem-space.name count-to-limit ^argument1 <c> -^count)
    -->
       (<s> ^operator <o> + >)
       (<o> ^name init-local ^task-operator false)
    }

    sp {count-in-substate*apply*init-local
       (state <s> ^operator.name init-local ^argument1 <c>)
       (<c> ^value <v>)
    -->
       (log 1 (crlf) |Apply init-local: | <v>)
       (<s> ^count <v>)
    }

    ## increment: local count + 1 while below 75000 (internal operator).
    sp {count-in-substate*propose*increment
       (state <s> ^problem-space.name count-to-limit ^count < 75000)
    -->
       (<s> ^operator <o> + =)
       (<o> ^name increment ^task-operator false)
    }

    sp {count-in-substate*apply*increment
       (state <s> ^operator.name increment ^count <n>)
    -->
       (log 2 (crlf) |Apply increment: | <n>)
       (<s> ^count <n> - (+ <n> 1))
    }

    ## done <counter>: write the local count to the counter (task-action operator, internal application).
    sp {count-in-substate*propose*done
       (state <s> ^problem-space.name count-to-limit ^count 75000 ^argument1 <c>)
    -->
       (<s> ^operator <o> + =)
       (<o> ^name done ^task-operator true ^action-handle done ^argument1 <c> ^argument-count 1 ^desireds <pre>)
       (<pre> ^desired-count 0)
    }

    sp {count-in-substate*apply*done*internal
       (state <s> ^operator <o> ^internal-actions true ^count <n> ^world <w>)
       (<o> ^name done ^pre-conditions-satisfied true ^argument1.object-handle $ <h>)
       (<w> ^anchored-world true ^objects.object <c>)
       (<c> ^object-handle $ <h> ^value <v>)
    -->
       (log 1 (crlf) |Apply done: | <n>)
       (<c> ^value <v> - <n>)
    }
    """)
    return a.write()


def count_add_smem():
    a = Agent('counting', 'count-add-smem', 'count-add-smem',
              'Add digit2 to digit1 (9 + 9) by counting with successor facts retrieved from semantic memory.')
    a.settings += ['chunk never', 'smem --set learning on', """smem --add {
   (<l0> ^kind succ ^|symbol| 0 ^|next| 1)
   (<l1> ^kind succ ^|symbol| 1 ^|next| 2)
   (<l2> ^kind succ ^|symbol| 2 ^|next| 3)
   (<l3> ^kind succ ^|symbol| 3 ^|next| 4)
   (<l4> ^kind succ ^|symbol| 4 ^|next| 5)
   (<l5> ^kind succ ^|symbol| 5 ^|next| 6)
   (<l6> ^kind succ ^|symbol| 6 ^|next| 7)
   (<l7> ^kind succ ^|symbol| 7 ^|next| 8)
   (<l8> ^kind succ ^|symbol| 8 ^|next| 9)
   (<l9> ^kind succ ^|symbol| 9 ^|next| 0)
}"""]
    problem_space(a)
    initialize(a, """
    (<objs> ^object <ad>)
    (<ad> ^object-handle adder ^anchored true ^type adder ^digit1 9 ^digit2 9 ^carry 0 ^done 0)
    (<ds> ^desired-count 1 ^desired <d1>)
    (<d1> ^object <d1o>)
    (<d1o> ^object-handle adder ^done 1)
    """, flags={'mea-operator-selection': 'true'})
    achievement_object(a)
    a.add('add.soar', """
    ## add <adder> (composite, W-COP-002): effect: adder done 1.  Its substate (problem space add) counts
    ## digit1 up digit2 times with successor facts from semantic memory (SMM-016: commands created by
    ## operator applications; agent-world removes a query once it has a result, W-OTH-003).
    sp {count-add-smem*propose*add
       (state <s> ^problem-space.name count-add-smem ^flags.mea-operator-selection true ^desireds.unachieved-desireds true ^world <w>)
       (<w> ^anchored-world true ^objects.object <ad>)
       (<ad> ^type adder ^done 0)
    -->
       (<s> ^operator <o> +)
       (<o> ^name add ^task-operator true ^argument1 <ad> ^argument-count 1 ^desireds <pre> ^effect-desireds <ed>)
       (<pre> ^desired-count 0)
       (<ed> ^desired-count 1 ^desired <e1>)
       (<e1> ^object <e1o>)
       (<e1o> ^object-handle adder ^done 1)
    }

    sp {count-add-smem*propose*init-local
       (state <s> ^problem-space.name add ^argument1 <ad> -^d1)
    -->
       (<s> ^operator <o> + >)
       (<o> ^name init-local ^task-operator false)
    }

    sp {count-add-smem*apply*init-local
       (state <s> ^operator.name init-local ^argument1 <ad>)
       (<ad> ^digit1 <d1>)
    -->
       (log 1 (crlf) |Apply init-local: | <d1>)
       (<s> ^d1 <d1> ^d3 0 ^carry 0 ^phase 0)
    }

    ## next-digit1: d1 := successor(d1) (carry when d1 was 9).
    sp {count-add-smem*propose*next-digit1
       (state <s> ^problem-space.name add ^argument1 <ad> ^phase 0 ^d3 { <> <d2> })
       (<ad> ^digit2 <d2>)
    -->
       (<s> ^operator <o> + =)
       (<o> ^name next-digit1 ^task-operator false)
    }

    sp {count-add-smem*apply*next-digit1*query
       (state <s> ^operator <o> ^d1 <d1> ^smem.command <c> -^queried <o>)
       (<o> ^name next-digit1)
    -->
       (<s> ^queried <o>)
       (<c> ^query <q>)
       (<q> ^kind succ ^symbol <d1>)
    }

    sp {count-add-smem*apply*next-digit1
       (state <s> ^operator <o> ^d1 <d1> ^carry <cy> ^phase 0 ^queried <o> ^smem.result.retrieved <f>)
       (<o> ^name next-digit1)
       (<f> ^kind succ ^symbol <d1> ^next <n>)
    -->
       (log 1 (crlf) |Apply next-digit1: | <n>)
       (<s> ^d1 <d1> - <n> ^phase 0 - 1)
    }

    sp {count-add-smem*apply*next-digit1*carry
       (state <s> ^operator <o> ^d1 9 ^carry 0 ^phase 0 ^queried <o> ^smem.result.retrieved <f>)
       (<o> ^name next-digit1)
       (<f> ^kind succ ^symbol 9)
    -->
       (<s> ^carry 0 - 1)
    }

    ## next-digit3: d3 := successor(d3).
    sp {count-add-smem*propose*next-digit3
       (state <s> ^problem-space.name add ^phase 1)
    -->
       (<s> ^operator <o> + =)
       (<o> ^name next-digit3 ^task-operator false)
    }

    sp {count-add-smem*apply*next-digit3*query
       (state <s> ^operator <o> ^d3 <d3> ^smem.command <c> -^queried <o>)
       (<o> ^name next-digit3)
    -->
       (<s> ^queried <o>)
       (<c> ^query <q>)
       (<q> ^kind succ ^symbol <d3>)
    }

    sp {count-add-smem*apply*next-digit3
       (state <s> ^operator <o> ^d3 <d3> ^phase 1 ^queried <o> ^smem.result.retrieved <f>)
       (<o> ^name next-digit3)
       (<f> ^kind succ ^symbol <d3> ^next <n>)
    -->
       (log 1 (crlf) |Apply next-digit3: | <n>)
       (<s> ^d3 <d3> - <n> ^phase 1 - 0)
    }

    ## done <adder>: write the sum digit and carry to the adder (task-action operator).
    sp {count-add-smem*propose*done
       (state <s> ^problem-space.name add ^argument1 <ad> ^phase 0 ^d3 <d2>)
       (<ad> ^digit2 <d2>)
    -->
       (<s> ^operator <o> + =)
       (<o> ^name done ^task-operator true ^action-handle done ^argument1 <ad> ^argument-count 1 ^desireds <pre>)
       (<pre> ^desired-count 0)
    }

    sp {count-add-smem*apply*done*internal
       (state <s> ^operator <o> ^internal-actions true ^d1 <d1> ^carry <cy> ^world <w>)
       (<o> ^name done ^pre-conditions-satisfied true ^argument1.object-handle $ <h>)
       (<w> ^anchored-world true ^objects.object <ad>)
       (<ad> ^object-handle $ <h> ^digit1 <od1> ^carry <ocy> ^done 0)
    -->
       (log 1 (crlf) |Apply done: digit1 | <d1> | carry | <cy>)
       (<ad> ^digit1 <od1> - <d1> ^carry <ocy> - <cy> ^done 0 - 1)
    }
    """)
    return a.write()


if __name__ == '__main__':
    for f in (hello_world, count_up, count_in_substate, count_add_smem): print(f())
