"""left-right and pyramid families, world-v6."""
from v6 import *


def left_right():
    a = Agent('left-right', 'left-right', 'left-right', 'Left-right: one move, left (-1, reward -1) or right (1, reward 1); RL learns which.')
    a.settings += ['chunk never', 'rl --set learning on', 'rl --set learning-rate 0.300000', 'rl --set discount-rate 0.900000',
                   'indifferent-selection --epsilon-greedy']
    problem_space(a)
    initialize(a, """
    (<objs> ^object <ag>)
    (<ag> ^object-handle agent ^anchored true ^type agent ^location 0 ^moved 0)
    (<ds> ^desired-count 1 ^desired <d1>)
    (<d1> ^object <d1o>)
    (<d1o> ^object-handle agent ^moved 1)
    """, flags={'mea-operator-selection': 'true'})
    achievement_object(a)
    a.add('move.soar', """
    ## move <agent> <direction>: from location 0, one step left (-1) or right (1).  The direction is a
    ## non-object parameter (W-APP-004).
    sp {left-right*propose*move
       (state <s> ^problem-space.name left-right ^flags.mea-operator-selection true ^desireds.unachieved-desireds true ^world <w>)
       (<w> ^anchored-world true ^objects.object <ag>)
       (<ag> ^type agent ^location 0)
    -->
       (<s> ^operator <l> + ^operator <r> +)
       (<l> ^name move ^task-operator true ^action-handle move ^argument1 <ag> ^argument2 -1 ^argument-count 2 ^desireds <lp>)
       (<lp> ^desired-count 0)
       (<r> ^name move ^task-operator true ^action-handle move ^argument1 <ag> ^argument2 1 ^argument-count 2 ^desireds <rp>)
       (<rp> ^desired-count 0)
    }

    sp {left-right*apply*move*internal
       (state <s> ^operator <o> ^internal-actions true ^world <w>)
       (<o> ^name move ^pre-conditions-satisfied true ^argument1.object-handle $ <h> ^argument2 <dir>)
       (<w> ^anchored-world true ^objects.object <ag>)
       (<ag> ^object-handle $ <h> ^location <l> ^moved <m>)
    -->
       (log 1 (crlf) |Moved: | <dir>)
       (<ag> ^location <l> - <dir> ^moved <m> - 1)
    }
    """)
    a.add('rl.soar', """
    ## RL template (RL-007) over the move direction and the agent's state.
    sp {left-right*rl*move
       :template
       (state <s> ^problem-space.name left-right ^operator <o> +)
       (<o> ^name move ^argument2 <dir> ^argument1 <ag>)
       (<ag> ^location <l> ^moved <m>)
    -->
       (<s> ^operator <o> = 0)
    }

    ## Rewards (RL-002, RL-008 i-supported): -1 at location -1, +1 at location 1.
    sp {left-right*elaborate*reward*left
       (state <s> ^problem-space.name left-right ^reward-link <r> ^world <w>)
       (<w> ^anchored-world true ^objects.object <ag>)
       (<ag> ^type agent ^location -1)
    -->
       (<r> ^reward <rw>)
       (<rw> ^value -1)
    }

    sp {left-right*elaborate*reward*right
       (state <s> ^problem-space.name left-right ^reward-link <r> ^world <w>)
       (<w> ^anchored-world true ^objects.object <ag>)
       (<ag> ^type agent ^location 1)
    -->
       (<r> ^reward <rw>)
       (<rw> ^value 1)
    }
    """)
    indifferent(a, 'the original chooses by RL values among indifferent operators')
    return a.write()


def pyramid_flat(v, height):
    a = Agent('pyramid', v, 'pyramid', f'Pyramid sum: add the terms 5, 4, 3, ... ({height + 1} terms, height {height}) one at a time.')
    a.settings += ['chunk never']
    problem_space(a)
    initialize(a, f"""
    (<objs> ^object <py>)
    (<py> ^object-handle pyramid ^anchored true ^type pyramid ^term 5 ^height {height} ^sum 0)
    (<ds> ^desired-count 1 ^desired <d1>)
    (<d1> ^object <d1o>)
    (<d1o> ^object-handle pyramid ^height -1)
    """, flags={'mea-operator-selection': 'true'})
    achievement_object(a)
    a.add('add-next-term.soar', """
    ## add-next-term <pyramid>: sum := sum + term; term := term - 1; height := height - 1.
    sp {pyramid*propose*add-next-term
       (state <s> ^problem-space.name pyramid ^flags.mea-operator-selection true ^desireds.unachieved-desireds true ^world <w>)
       (<w> ^anchored-world true ^objects.object <py>)
       (<py> ^type pyramid ^height >= 0)
    -->
       (<s> ^operator <o> +)
       (<o> ^name add-next-term ^task-operator true ^action-handle add-next-term ^argument1 <py> ^argument-count 1 ^desireds <pre>)
       (<pre> ^desired-count 0)
    }

    sp {pyramid*apply*add-next-term*internal
       (state <s> ^operator <o> ^internal-actions true ^world <w>)
       (<o> ^name add-next-term ^pre-conditions-satisfied true ^argument1.object-handle $ <h>)
       (<w> ^anchored-world true ^objects.object <py>)
       (<py> ^object-handle $ <h> ^sum <sum> ^term <t> ^height <ht>)
    -->
       (log 1 (crlf) | + | <t>)
       (<py> ^sum <sum> - (+ <sum> <t>) ^term <t> - (- <t> 1) ^height <ht> - (- <ht> 1))
    }

    ## Report the answer when the goal is reached (a monitoring rule).
    sp {pyramid*elaborate*answer
       (state <s> ^superstate nil ^success <ds> ^desireds <ds> ^world <w>)
       (<w> ^anchored-world true ^objects.object <py>)
       (<py> ^type pyramid ^sum <sum>)
    -->
       (write (crlf) |The answer is | <sum> |.|)
    }
    """)
    return a.write()


def pyramid_hierarchical():
    a = Agent('pyramid', 'pyramid-hierarchical', 'pyramid',
              'Pyramid sum in two composite steps: expand-pyramid writes the terms 10, 9, ... (7 terms) as world objects; sum-terms adds them.')
    a.settings += ['chunk never']
    problem_space(a)
    initialize(a, """
    (<objs> ^object <py>)
    (<py> ^object-handle pyramid ^anchored true ^type pyramid ^term 10 ^height 6 ^terms 0 ^sum 0 ^summed 0)
    (<ds> ^desired-count 1 ^desired <d1>)
    (<d1> ^object <d1o>)
    (<d1o> ^object-handle pyramid ^summed 1)
    """, flags={'mea-operator-selection': 'true'})
    achievement_object(a)
    a.add('expand-pyramid.soar', """
    ## expand-pyramid <pyramid> (composite, W-COP-002): effect: height -1 (every term written).
    ## As in the original, relevance is a state elaboration, so the operator persists while height changes.
    sp {pyramid*elaborate*expand-pyramid-relevant
       (state <s> ^problem-space.name pyramid ^world <w>)
       (<w> ^anchored-world true ^objects.object <py>)
       (<py> ^type pyramid ^height >= 0)
    -->
       (<s> ^expand-pyramid-relevant <py>)
    }

    sp {pyramid*propose*expand-pyramid
       (state <s> ^problem-space.name pyramid ^flags.mea-operator-selection true ^desireds.unachieved-desireds true ^expand-pyramid-relevant <py>)
    -->
       (<s> ^operator <o> +)
       (<o> ^name expand-pyramid ^task-operator true ^argument1 <py> ^argument-count 1 ^desireds <pre> ^effect-desireds <ed>)
       (<pre> ^desired-count 0)
       (<ed> ^desired-count 1 ^desired <e1>)
       (<e1> ^object <e1o>)
       (<e1o> ^object-handle pyramid ^height -1)
    }

    ## expand-next-term: a new term object (handle term-<index>) in the world; term, height and the count move on.
    sp {pyramid*propose*expand-next-term
       (state <s> ^problem-space.name expand-pyramid ^argument1 <py>)
       (<py> ^height >= 0)
    -->
       (<s> ^operator <o> + =)
       (<o> ^name expand-next-term ^task-operator true ^action-handle expand-next-term ^argument1 <py> ^argument-count 1 ^desireds <pre>)
       (<pre> ^desired-count 0)
    }

    sp {pyramid*apply*expand-next-term*internal
       (state <s> ^operator <o> ^internal-actions true ^world <w>)
       (<o> ^name expand-next-term ^pre-conditions-satisfied true ^argument1.object-handle $ <h>)
       (<w> ^anchored-world true ^objects <objs>)
       (<objs> ^object <py>)
       (<py> ^object-handle $ <h> ^terms <n> ^term <t> ^height <ht>)
    -->
       (log 1 (crlf) | + | <t>)
       (<objs> ^object <new>)
       (<new> ^object-handle (concat term- <n>) ^anchored true ^type term ^index <n> ^value <t>)
       (<py> ^terms <n> - (+ <n> 1) ^term <t> - (- <t> 1) ^height <ht> - (- <ht> 1))
    }
    """)
    a.add('sum-terms.soar', """
    ## sum-terms <pyramid> (composite): when every term is written; effect: summed 1.
    sp {pyramid*propose*sum-terms
       (state <s> ^problem-space.name pyramid ^flags.mea-operator-selection true ^desireds.unachieved-desireds true ^world <w>)
       (<w> ^anchored-world true ^objects.object <py>)
       (<py> ^type pyramid ^height -1 ^summed 0)
    -->
       (<s> ^operator <o> +)
       (<o> ^name sum-terms ^task-operator true ^argument1 <py> ^argument-count 1 ^desireds <pre> ^effect-desireds <ed>)
       (<pre> ^desired-count 0)
       (<ed> ^desired-count 1 ^desired <e1>)
       (<e1> ^object <e1o>)
       (<e1o> ^object-handle pyramid ^summed 1)
    }

    ## init-local, add-term: a running sum and the next index on the substate (internal operators, W-NOP-001).
    sp {pyramid*propose*init-local
       (state <s> ^problem-space.name sum-terms -^sum)
    -->
       (<s> ^operator <o> + >)
       (<o> ^name init-local ^task-operator false)
    }

    sp {pyramid*apply*init-local
       (state <s> ^operator.name init-local)
    -->
       (log 1 (crlf) |Apply init-local.|)
       (<s> ^sum 0 ^next 0)
    }

    sp {pyramid*propose*add-term
       (state <s> ^problem-space.name sum-terms ^sum <any> ^next <i> ^world <w>)
       (<w> ^anchored-world true ^objects.object <t>)
       (<t> ^type term ^index <i> ^value <v>)
    -->
       (<s> ^operator <o> + =)
       (<o> ^name add-term ^task-operator false ^term-value <v>)
    }

    sp {pyramid*apply*add-term
       (state <s> ^operator <o> ^sum <sum> ^next <i>)
       (<o> ^name add-term ^term-value <v>)
    -->
       (log 1 (crlf) |Apply add-term: | <v>)
       (<s> ^sum <sum> - (+ <sum> <v>) ^next <i> - (+ <i> 1))
    }

    ## final-sum <pyramid>: write the sum to the pyramid (task-action operator).
    sp {pyramid*propose*final-sum
       (state <s> ^problem-space.name sum-terms ^argument1 <py> ^sum <any> ^next <n>)
       (<py> ^terms <n>)
    -->
       (<s> ^operator <o> + =)
       (<o> ^name final-sum ^task-operator true ^action-handle final-sum ^argument1 <py> ^argument-count 1 ^desireds <pre>)
       (<pre> ^desired-count 0)
    }

    sp {pyramid*apply*final-sum*internal
       (state <s> ^operator <o> ^internal-actions true ^sum <sum> ^world <w>)
       (<o> ^name final-sum ^pre-conditions-satisfied true ^argument1.object-handle $ <h>)
       (<w> ^anchored-world true ^objects.object <py>)
       (<py> ^object-handle $ <h> ^sum <old> ^summed <sd>)
    -->
       (log 1 (crlf) |Apply final-sum: | <sum>)
       (<py> ^sum <old> - <sum> ^summed <sd> - 1)
    }

    sp {pyramid*elaborate*answer
       (state <s> ^superstate nil ^success <ds> ^desireds <ds> ^world <w>)
       (<w> ^anchored-world true ^objects.object <py>)
       (<py> ^type pyramid ^sum <sum>)
    -->
       (write (crlf) |The answer is | <sum> |.|)
    }
    """)
    return a.write()


if __name__ == '__main__':
    print(left_right()); print(pyramid_flat('pyramid', 10)); print(pyramid_flat('pyramid-anderson', 2)); print(pyramid_hierarchical())
