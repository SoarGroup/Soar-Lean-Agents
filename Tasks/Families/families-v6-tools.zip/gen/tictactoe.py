"""tictactoe family, world-v6: both sides play random legal marks until a win or a draw."""
from v6 import *

LINES = {'row1': ['11', '21', '31'], 'row2': ['12', '22', '32'], 'row3': ['13', '23', '33'],
         'column1': ['11', '12', '13'], 'column2': ['21', '22', '23'], 'column3': ['31', '32', '33'],
         'diagonal1': ['11', '22', '33'], 'diagonal2': ['31', '22', '13']}


def build():
    cells = [f'{x}{y}' for y in (1, 2, 3) for x in (1, 2, 3)]
    L = ['(<objs> ^object <game> ' + ' '.join(f'<c{c}>' for c in cells) + ' ' + ' '.join(f'<{l}>' for l in LINES) + ')']
    for c in cells:
        L.append(f'(<c{c}> ^object-handle c{c} ^anchored true ^type cell ^xy {c} ^x {c[0]} ^y {c[1]} ^content 0)')
    k = 0
    for l, cs in LINES.items():
        L.append(f'(<{l}> ^object-handle {l} ^anchored true ^type line)')
        for c in cs:
            k += 1
            L.append(f'(<w> ^in-line <r{k}>) (<r{k}> ^argument1 <c{c}> ^argument2 <{l}>)')
    L.append('(<game> ^object-handle game ^anchored true ^type game ^turn 1 ^winner 0 ^over 0)')
    L.append('(<ds> ^desired-count 1 ^desired <d1>)\n(<d1> ^object <d1o>)\n(<d1o> ^object-handle game ^over 1)')
    a = Agent('tictactoe', 'tictactoe', 'tictactoe', 'Tic-tac-toe: X and O take turns marking a random empty cell until one side has a line or the board is full.')
    a.settings += ['chunk never']
    problem_space(a)
    initialize(a, '\n'.join(L), flags={'mea-operator-selection': 'true'})
    achievement_object(a)
    G = '(state <s> ^problem-space.name tictactoe ^flags.mea-operator-selection true ^desireds.unachieved-desireds true ^world <w>)\n       (<w> ^anchored-world true ^objects.object <g>)\n       (<g> ^type game ^over 0)'
    a.add('mark.soar', f"""
    ## Cells and lines are world objects; in-line relations say which cells make up each line (W-REL-001).
    ## mark <cell>: the side to move marks an empty cell (content 1 = X, 2 = O).
    sp {{tictactoe*propose*mark
       {G}
       (<w> ^objects.object <c>)
       (<c> ^type cell ^content 0)
    -->
       (<s> ^operator <o> +)
       (<o> ^name mark ^task-operator true ^action-handle mark ^argument1 <c> ^argument-count 1 ^desireds <pre>)
       (<pre> ^desired-count 0)
    }}

    sp {{tictactoe*apply*mark*internal
       (state <s> ^operator <o> ^internal-actions true ^world <w>)
       (<o> ^name mark ^pre-conditions-satisfied true ^argument1.object-handle $ <ch>)
       (<w> ^anchored-world true ^objects.object <c> <g>)
       (<c> ^object-handle $ <ch> ^content <old>)
       (<g> ^type game ^turn <t>)
    -->
       (log 1 (crlf) |Mark | <ch> | by | <t>)
       (<c> ^content <old> - <t>)
       (<g> ^turn <t> - (- 3 <t>))
    }}
    """)
    for side, n in (('x', 1), ('o', 2)):
        a.add('wins.soar', f"""
        ## {side}-wins <line>: three cells of a line hold {n}.
        sp {{tictactoe*propose*{side}-wins
           {G}
           (<w> ^objects.object <l> ^in-line <r1> {{ <> <r1> <r2> }} {{ <> <r1> <> <r2> <r3> }})
           (<l> ^type line)
           (<r1> ^argument1 <c1> ^argument2 <l>)
           (<r2> ^argument1 {{ <> <c1> <c2> }} ^argument2 <l>)
           (<r3> ^argument1 {{ <> <c1> <> <c2> <c3> }} ^argument2 <l>)
           (<c1> ^content {n})
           (<c2> ^content {n})
           (<c3> ^content {n})
        -->
           (<s> ^operator <o> +)
           (<o> ^name {side}-wins ^task-operator true ^action-handle {side}-wins ^argument1 <l> ^argument-count 1 ^desireds <pre>)
           (<pre> ^desired-count 0)
        }}

        sp {{tictactoe*apply*{side}-wins*internal
           (state <s> ^operator <o> ^internal-actions true ^world <w>)
           (<o> ^name {side}-wins ^pre-conditions-satisfied true)
           (<w> ^anchored-world true ^objects.object <g>)
           (<g> ^type game ^over <ov> ^winner <wn>)
        -->
           (log 1 (crlf) |Side {side.upper()} won.|)
           (<g> ^over <ov> - 1 ^winner <wn> - {n})
        }}

        sp {{tictactoe*compare*{side}-wins*best
           (state <s> ^problem-space.name tictactoe ^operator <o> +)
           (<o> ^name {side}-wins)
        -->
           (<s> ^operator <o> >)
        }}
        """)
    a.add('wins.soar', f"""
    ## detect-draw <game>: no empty cell left.
    sp {{tictactoe*propose*detect-draw
       {G}
      -{{(<w> ^objects.object <c>)
        (<c> ^type cell ^content 0)}}
    -->
       (<s> ^operator <o> +)
       (<o> ^name detect-draw ^task-operator true ^action-handle detect-draw ^argument1 <g> ^argument-count 1 ^desireds <pre>)
       (<pre> ^desired-count 0)
    }}

    sp {{tictactoe*apply*detect-draw*internal
       (state <s> ^operator <o> ^internal-actions true ^world <w>)
       (<o> ^name detect-draw ^pre-conditions-satisfied true)
       (<w> ^anchored-world true ^objects.object <g>)
       (<g> ^type game ^over <ov>)
    -->
       (log 1 (crlf) |Draw.|)
       (<g> ^over <ov> - 1)
    }}
    """)
    indifferent(a)
    return a.write()


if __name__ == '__main__':
    print(build())
