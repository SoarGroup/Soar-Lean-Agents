"""v6.py: shared pieces for the world-v6 task agents (World-Conventions-Spec v6, workbook v6 of
17 Nov 2026, Soar library v2.42). Each family generator calls these and writes
Tasks/Families/<family>/world-v6/<variant>/."""
import os, sys, textwrap
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

OUT = os.environ.get('V6OUT', '/home/claude/w/repo/Tasks/Families')
LIBPATH = '../../../../../Soar/soar-library'


def d(s):
    return textwrap.dedent(s).strip('\n') + '\n'


class Agent:
    def __init__(self, family, variant, task, about, kind='world-v6'):
        self.family, self.variant, self.task, self.kind = family, variant, task, kind
        self.about = about.strip()
        self.files = {}          # name -> list of text chunks
        self.order = []
        self.settings = []

    def add(self, fname, text):
        assert fname != self.variant + '.soar', 'file name clashes with the load file'
        if fname not in self.files:
            self.files[fname] = []; self.order.append(fname)
        self.files[fname].append(d(text))

    def write(self):
        base = os.path.join(OUT, self.family, self.kind, self.variant)
        os.makedirs(base, exist_ok=True)
        for f in os.listdir(base):
            os.remove(os.path.join(base, f))
        fl = ['## Soar settings (from the original program; see README.md)'] + self.settings
        open(os.path.join(base, '_firstload.soar'), 'w').write('\n'.join(fl) + '\n')
        # 18 Nov 2026 conventions (convpass.py): problem-space tests (L3-005), a comment per rule group (L3-012),
        # no indifferent preference in the proposals of RL variants (L3-039, L3-083).
        import convpass
        rl = any(x == 'rl' or x.startswith('hrl') for x in self.variant.lower().split('-'))
        texts, _ = convpass.apply_files({f: '\n'.join(self.files[f]) for f in self.order}, rl=rl)
        for f in self.order:
            open(os.path.join(base, f), 'w').write(texts[f])
        load = [f'## {self.variant}: {self.kind} version, regenerated from the original program on 17 Nov 2026.',
                '## ' + self.about.replace('\n', '\n## '),
                '## Loads the shared Soar library (v2.42) from Soar/soar-library; the path assumes this folder is',
                '## Tasks/Families/<family>/' + self.kind + '/<variant>.',
                f'pushd "{LIBPATH}"', 'source soar-library.soar', 'popd', 'source _firstload.soar']
        load += [f'source {f}' for f in self.order]
        open(os.path.join(base, self.variant + '.soar'), 'w').write('\n'.join(load) + '\n')
        return base


# ---------------------------------------------------------------- common rules

def problem_space(a, extra=''):
    """W-WLD-008, W-LAH-026, W-SEL-009: task state (and look-ahead state, which also has the task ^name)
    and the MEA substate get the same problem space."""
    t = a.task
    a.add('elaborations.soar', f"""
    ## Problem space of the task state and of look-ahead states (both have ^name {t}); W-WLD-008, W-LAH-026.
    sp {{{t}*elaborate*problem-space
       (state <s> ^name {t})
    -->
       (<s> ^problem-space <p>)
       (<p> ^name {t}{extra})
    }}

    ## The same problem space on a means-ends (MEA) substate of a task operator; W-MEA-001.
    sp {{{t}*elaborate*problem-space*mea-substate
       (state <s> ^impasse no-change ^attribute operator ^superstate <ss>)
       (<ss> ^problem-space.name {t} ^operator <so>)
       (<so> ^task-operator true -^pre-conditions-satisfied true)
    -->
       (<s> ^problem-space <p>)
       (<p> ^name {t}{extra})
    }}
    """)


def initialize(a, body, flags=None, environment_none=True, fname=None):
    """W-WLD-010: initialize-<task>, acceptable and best, once ^world exists and there is no ^name.
    body: RHS lines that create objects/relations/desireds; it may use <w>, <objs>, <ds>."""
    t = a.task
    fl = ''
    if flags:
        fl = '\n   (<s> ^flag-override <f>)\n   (<f>' + ''.join(f' ^{k} {v}' for k, v in flags.items()) + ')'
    env = ' ^environment none' if environment_none else ''
    a.add(fname or f'initialize-{t}.soar', f"""
    ## initialize-{t} (W-WLD-010, W-WLD-011, W-FLG-002): world objects, relations, desireds and flag overrides.
    sp {{{t}*propose*initialize-{t}
       (state <s> ^superstate nil ^world <w> -^name)
    -->
       (<s> ^operator <o> + >)
       (<o> ^name initialize-{t} ^task-operator false)
    }}

    sp {{{t}*apply*initialize-{t}
       (state <s> ^operator.name initialize-{t} ^world <w>)
       (<w> ^objects <objs>)
    -->
       (<s> ^name {t}{env} ^desireds <ds>){fl}
    """ + textwrap.indent(d(body), '   ') + f"""   (log 1 (crlf) |Initialize {t}.|)
    }}
    """)


def achievement_object(a, fname='elaborations.soar', operators=False):
    """W-DBK-002, W-DBK-004, W-DBK-006: achieved/unachieved for object-property desireds."""
    t = a.task
    if operators:
        a.add(fname, f"""
        ## Object-property desireds of a proposed operator (its preconditions; W-TOP-011, W-DBK-006).
        sp {{{t}*elaborate*operator-desired*achieved*object-property
           (state <s> ^operator <op> + ^world <w>)
           (<op> ^desireds <ds>)
           (<ds> ^desired <d>)
           (<d> ^object <do>)
           (<do> ^object-handle $ <h> ^{{ <> object-handle <> anchored <> duplicate-of <> origin-object-handle <a> }} <v>)
           (<w> ^anchored-world true ^objects.object <ob>)
           (<ob> ^object-handle $ <h> ^<a> <v>)
        -->
           (<ds> ^achieved <d>)
        }}

        sp {{{t}*elaborate*operator-desired*unachieved*object-property
           (state <s> ^operator <op> + ^world <w>)
           (<op> ^desireds <ds>)
           (<ds> ^desired <d>)
           (<d> ^object <do>)
           (<do> ^object-handle $ <h> ^{{ <> object-handle <> anchored <> duplicate-of <> origin-object-handle <a> }} <v>)
           (<w> ^anchored-world true)
          -{{(<w> ^objects.object <ob>)
            (<ob> ^object-handle <h> ^<a> <v>)}}
        -->
           (<ds> ^unachieved <d>)
        }}
        """)
        return
    a.add(fname, f"""
    ## Object-property desireds: achieved when an anchored world object with the handle has the value (W-DBK-002).
    sp {{{t}*elaborate*desired*achieved*object-property
       (state <s> ^desireds <ds> ^world <w>)
       (<ds> ^desired <d>)
       (<d> ^object <do>)
       (<do> ^object-handle $ <h> ^{{ <> object-handle <> anchored <> duplicate-of <> origin-object-handle <a> }} <v>)
       (<w> ^anchored-world true ^objects.object <ob>)
       (<ob> ^object-handle $ <h> ^<a> <v>)
    -->
       (<ds> ^achieved <d>)
    }}

    ## ... and unachieved otherwise (a positive WME, W-DBK-004; no $ inside the negation, W-CHK-006).
    sp {{{t}*elaborate*desired*unachieved*object-property
       (state <s> ^desireds <ds> ^world <w>)
       (<ds> ^desired <d>)
       (<d> ^object <do>)
       (<do> ^object-handle $ <h> ^{{ <> object-handle <> anchored <> duplicate-of <> origin-object-handle <a> }} <v>)
       (<w> ^anchored-world true)
      -{{(<w> ^objects.object <ob>)
        (<ob> ^object-handle <h> ^<a> <v>)}}
    -->
       (<ds> ^unachieved <d>)
    }}
    """)


def achievement_relation(a, fname='elaborations.soar', operators=False):
    t = a.task
    if operators:
        a.add(fname, f"""
        ## Relation desireds of a proposed operator (its preconditions; W-TOP-011): achieved or unachieved in the
        ## operator's state, supplied by the task like those of a state (W-DBK-002, W-DBK-006).
        sp {{{t}*elaborate*operator-desired*achieved*relation
           (state <s> ^operator <op> + ^world <w>)
           (<op> ^desireds <ds>)
           (<ds> ^desired <d>)
           (<d> ^<rel> <dr>)
           (<dr> ^argument1.object-handle $ <h1> ^argument2.object-handle $ <h2>)
           (<w> ^anchored-world true ^<rel> <wr>)
           (<wr> ^argument1.object-handle $ <h1> ^argument2.object-handle $ <h2>)
        -->
           (<ds> ^achieved <d>)
        }}

        sp {{{t}*elaborate*operator-desired*unachieved*relation
           (state <s> ^operator <op> + ^world <w>)
           (<op> ^desireds <ds>)
           (<ds> ^desired <d>)
           (<d> ^<rel> <dr>)
           (<dr> ^argument1.object-handle $ <h1> ^argument2.object-handle $ <h2>)
           (<w> ^anchored-world true)
          -{{(<w> ^<rel> <wr>)
            (<wr> ^argument1.object-handle <h1> ^argument2.object-handle <h2>)}}
        -->
           (<ds> ^unachieved <d>)
        }}
        """)
    a.add(fname, f"""
    ## Relation desireds (two arguments): achieved when the world has the relation between those handles (W-DBK-002).
    sp {{{t}*elaborate*desired*achieved*relation
       (state <s> ^desireds <ds> ^world <w>)
       (<ds> ^desired <d>)
       (<d> ^<rel> <dr>)
       (<dr> ^argument1.object-handle $ <h1> ^argument2.object-handle $ <h2>)
       (<w> ^anchored-world true ^<rel> <wr>)
       (<wr> ^argument1.object-handle $ <h1> ^argument2.object-handle $ <h2>)
    -->
       (<ds> ^achieved <d>)
    }}

    sp {{{t}*elaborate*desired*unachieved*relation
       (state <s> ^desireds <ds> ^world <w>)
       (<ds> ^desired <d>)
       (<d> ^<rel> <dr>)
       (<dr> ^argument1.object-handle $ <h1> ^argument2.object-handle $ <h2>)
       (<w> ^anchored-world true)
      -{{(<w> ^<rel> <wr>)
        (<wr> ^argument1.object-handle <h1> ^argument2.object-handle <h2>)}}
    -->
       (<ds> ^unachieved <d>)
    }}
    """)


def indifferent(a, why='the original selects among its task operators at random'):
    """A separate evaluation rule (SYN-001; PRO-005: proposals stay acceptable-only, W-TOP-014)."""
    t = a.task
    a.add('search-control.soar', f"""
    ## Search control: {why}, so task operators are made indifferent here
    ## (an evaluation rule; proposals create only the acceptable preference, W-TOP-014, PRO-005).
    sp {{{t}*compare*task-operator*indifferent
       (state <s> ^problem-space.name {t} ^operator <o> +)
       (<o> ^task-operator true)
    -->
       (<s> ^operator <o> =)
    }}
    """)


def ancestors(a):
    t = a.task
    a.add('elaborations.soar', f"""
    ## Ancestors of a state that have the task's problem space (used for repeated-state detection in look-ahead).
    sp {{{t}*elaborate*ancestor*superstate
       (state <s> ^superstate <ss>)
       (<ss> ^problem-space.name {t} ^world <aw>)
       (<aw> ^anchored-world true)
    -->
       (<s> ^ancestor-world <aw>)
    }}

    sp {{{t}*elaborate*ancestor*inherit
       (state <s> ^superstate.ancestor-world <aw>)
    -->
       (<s> ^ancestor-world <aw>)
    }}
    """)
