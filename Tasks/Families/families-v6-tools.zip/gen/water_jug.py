"""water-jug family, world-v6. Originals: Tasks/Families/water-jug/original/<variant>."""
from v6 import *

F = 'water-jug'
INIT = """
(<objs> ^object <j3> <j5>)
(<j3> ^object-handle jug3 ^anchored true ^type jug ^volume 3 ^contents 0)
(<j5> ^object-handle jug5 ^anchored true ^type jug ^volume 5 ^contents 0)
(<ds> ^desired-count 1 ^desired <d1>)
(<d1> ^object <d1o>)
(<d1o> ^object-handle jug3 ^contents 1)
"""
# hierarchy variants also have a hand object
INIT_HAND = INIT.replace("(<objs> ^object <j3> <j5>)", "(<objs> ^object <j3> <j5> <hand>)\n(<hand> ^object-handle hand ^anchored true ^type hand ^holding none)")


def base(v, about, flags=None, init=INIT, fill=True):
    a = Agent(F, v, 'water-jug', about)
    problem_space(a, ' ^dont-copy-object-attribute free')
    initialize(a, init, flags=dict(mea_flag(), **(flags or {})))
    a.add('elaborations.soar', """
    ## Derived object attribute: room left in a jug.  i-supported, so listed as ^dont-copy-object-attribute
    ## on the problem space (W-SEL-009).
    sp {water-jug*elaborate*jug*free
       (state <s> ^world <w>)
       (<w> ^objects.object <j>)
       (<j> ^type jug ^volume <v> ^contents <c>)
    -->
       (<j> ^free (- <v> <c>))
    }
    """)
    achievement_object(a)
    if fill:
        a.add('fill.soar', """
        ## fill <jug>: legal when the jug is not full.
        sp {water-jug*propose*fill
           (state <s> ^problem-space.name water-jug ^flags.mea-operator-selection true ^desireds.unachieved-desireds true ^world <w>)
           (<w> ^anchored-world true ^objects.object <j>)
           (<j> ^type jug ^free > 0)
        -->
           (<s> ^operator <o> +)
           (<o> ^name fill ^task-operator true ^action-handle fill ^argument1 <j> ^argument-count 1 ^desireds <pre>)
           (<pre> ^desired-count 0)
        }

        sp {water-jug*apply*fill*internal
           (state <s> ^operator <o> ^internal-actions true ^world <w>)
           (<o> ^name fill ^pre-conditions-satisfied true ^argument1.object-handle $ <h>)
           (<w> ^anchored-world true ^objects.object <j>)
           (<j> ^object-handle $ <h> ^volume <v> ^contents <c>)
        -->
           (log 1 (crlf) |Apply fill: | <h>)
           (<j> ^contents <c> - <v>)
        }
        """)
    a.add('empty.soar', """
    ## empty <jug>: legal when the jug has contents.
    sp {water-jug*propose*empty
       (state <s> ^problem-space.name water-jug ^flags.mea-operator-selection true ^desireds.unachieved-desireds true ^world <w>)
       (<w> ^anchored-world true ^objects.object <j>)
       (<j> ^type jug ^contents > 0)
    -->
       (<s> ^operator <o> +)
       (<o> ^name empty ^task-operator true ^action-handle empty ^argument1 <j> ^argument-count 1 ^desireds <pre>)
       (<pre> ^desired-count 0)
    }

    sp {water-jug*apply*empty*internal
       (state <s> ^operator <o> ^internal-actions true ^world <w>)
       (<o> ^name empty ^pre-conditions-satisfied true ^argument1.object-handle $ <h>)
       (<w> ^anchored-world true ^objects.object <j>)
       (<j> ^object-handle $ <h> ^contents <c>)
    -->
       (log 1 (crlf) |Apply empty: | <h>)
       (<j> ^contents <c> - 0)
    }
    """)
    a.add('pour.soar', """
    ## pour <from> <to>: legal when <from> has contents and <to> is not full.
    sp {water-jug*propose*pour
       (state <s> ^problem-space.name water-jug ^flags.mea-operator-selection true ^desireds.unachieved-desireds true ^world <w>)
       (<w> ^anchored-world true ^objects.object <from> { <> <from> <to> })
       (<from> ^type jug ^contents > 0)
       (<to> ^type jug ^free > 0)
    -->
       (<s> ^operator <o> +)
       (<o> ^name pour ^task-operator true ^action-handle pour ^argument1 <from> ^argument2 <to> ^argument-count 2 ^desireds <pre>)
       (<pre> ^desired-count 0)
    }

    ## <from> holds more than <to> can take: <to> becomes full.
    sp {water-jug*apply*pour*internal*overflow
       (state <s> ^operator <o> ^internal-actions true ^world <w>)
       (<o> ^name pour ^pre-conditions-satisfied true ^argument1.object-handle $ <fh> ^argument2.object-handle $ <th>)
       (<w> ^anchored-world true ^objects.object <from> <to>)
       (<from> ^object-handle $ <fh> ^contents <fc>)
       (<to> ^object-handle $ <th> ^contents <tc> ^volume <tv> ^free { < <fc> <tf> })
    -->
       (log 1 (crlf) |Apply pour: | <fh> | -> | <th>)
       (<from> ^contents <fc> - (- <fc> <tf>))
       (<to> ^contents <tc> - <tv>)
    }

    ## <to> can take everything in <from>: <from> becomes empty.
    sp {water-jug*apply*pour*internal*fits
       (state <s> ^operator <o> ^internal-actions true ^world <w>)
       (<o> ^name pour ^pre-conditions-satisfied true ^argument1.object-handle $ <fh> ^argument2.object-handle $ <th>)
       (<w> ^anchored-world true ^objects.object <from> <to>)
       (<from> ^object-handle $ <fh> ^contents <fc>)
       (<to> ^object-handle $ <th> ^contents <tc> ^free >= <fc>)
    -->
       (log 1 (crlf) |Apply pour: | <fh> | -> | <th>)
       (<from> ^contents <fc> - 0)
       (<to> ^contents <tc> - (+ <tc> <fc>))
    }
    """)
    return a


def mea_flag():
    return {'mea-operator-selection': 'true'}


def duplicate(a, value='partial-failure'):
    """Original: a look-ahead state equal to an ancestor state gets ^partial-failure."""
    ancestors(a)
    a.add('state-evaluation.soar', f"""
    ## Look-ahead: a state whose jug contents equal those of an ancestor task state is a partial failure
    ## (original: water-jug*evaluate*state*failure*duplicate; W-DES-001 outcome on the state's own desireds).
    sp {{water-jug*elaborate*look-ahead*duplicate
       (state <s> ^problem-space.name water-jug ^tried-tied-operator <any> ^desireds <ds> ^world <w> ^ancestor-world <aw>)
       (<w> ^objects.object <a3> <a5>)
       (<a3> ^object-handle $ jug3 ^contents <c3>)
       (<a5> ^object-handle $ jug5 ^contents <c5>)
       (<aw> ^objects.object <b3> <b5>)
       (<b3> ^object-handle $ jug3 ^contents <c3>)
       (<b5> ^object-handle $ jug5 ^contents <c5>)
    -->
       (<s> ^{value} <ds>)
    }}
    """)


def avoid(a, outcome):
    """Original: look-ahead states 3-5 and 0-0 are known dead ends."""
    rhs = {'partial-failure': '(<s> ^partial-failure <ds>)', 'expected-value': '(<s> ^expected-value -1)'}[outcome]
    for n, (c3, c5) in ((1, (3, 5)), (2, (0, 0))):
        a.add('state-evaluation.soar', f"""
        ## Look-ahead: jug contents {c3}-{c5} is a known dead end (original: water-jug*evaluate*state*avoid*{n}).
        sp {{water-jug*elaborate*look-ahead*avoid*{n}
           (state <s> ^problem-space.name water-jug ^tried-tied-operator <any> ^desireds <ds> ^world <w>)
           (<w> ^objects.object <a3> <a5>)
           (<a3> ^object-handle $ jug3 ^contents {c3})
           (<a5> ^object-handle $ jug5 ^contents {c5})
        -->
           {rhs}
        }}
        """)


def rl(a):
    a.settings += ['rl --set learning on', 'rl --set learning-rate 0.100000', 'rl --set discount-rate 0.500000',
                   'indifferent-selection --epsilon-greedy']
    for op, args in (('fill', 1), ('empty', 1)):
        a.add('rl.soar', f"""
        ## RL template (RL-007): Q-value of {op} for the jug's volume and contents.
        sp {{water-jug*rl*{op}
           :template
           (state <s> ^problem-space.name water-jug ^operator <o> +)
           (<o> ^name {op} ^argument1 <j>)
           (<j> ^volume <v> ^contents <c>)
        -->
           (<s> ^operator <o> = 0)
        }}
        """)
    a.add('rl.soar', """
    sp {water-jug*rl*pour
       :template
       (state <s> ^problem-space.name water-jug ^operator <o> +)
       (<o> ^name pour ^argument1 <from> ^argument2 <to>)
       (<from> ^volume <fv> ^contents <fc>)
       (<to> ^volume <tv> ^contents <tc>)
    -->
       (<s> ^operator <o> = 0)
    }

    ## Reward -1 when both jugs are empty (original water-jug*reward*1).  The +1 reward for reaching the goal
    ## comes from agent-world with ^flags.rl true (W-CHK-001), replacing the original's water-jug*reward*2.
    sp {water-jug*elaborate*reward*both-empty
       (state <s> ^problem-space.name water-jug ^reward-link <r> ^world <w>)
       (<w> ^anchored-world true ^objects.object <a3> <a5>)
       (<a3> ^object-handle $ jug3 ^contents 0)
       (<a5> ^object-handle $ jug5 ^contents 0)
    -->
       (<r> ^reward <rw>)
       (<rw> ^value -1)
    }
    """)


def last_operator_control(a):
    """water-jug-tie: the original evaluates its tie in its own tie space from the last operator.  Ties belong
    to selection-world (W-NAM-008/009), so the same knowledge is stated as preferences in the task state."""
    a.add('elaborations.soar', """
    ## The last task operator applied is kept on a memory object in the world (spec section 2: mutable
    ## bookkeeping lives on a world object).
    sp {water-jug*apply*task-operator*record-last
       (state <s> ^operator <o> ^world <w>)
       (<o> ^task-operator true ^pre-conditions-satisfied true ^name <n>)
       (<w> ^anchored-world true ^objects.object <m>)
       (<m> ^type memory ^last-operator { <> <n> <l> })
    -->
       (<m> ^last-operator <l> - <n>)
    }
    """)
    a.add('search-control.soar', """
    ## Original tie heuristics (Impasse__Operator_Tie, evaluate-operator h1 to h5), as preferences:
    ## h1: nothing done yet: all operators equal.
    sp {water-jug*compare*first-move*indifferent
       (state <s> ^problem-space.name water-jug ^operator <o> + ^world.objects.object <m>)
       (<m> ^type memory ^last-operator none)
       (<o> ^task-operator true)
    -->
       (<s> ^operator <o> =)
    }

    ## h2, h3: after pour, fill and empty are equal and pour is worst.
    sp {water-jug*compare*after-pour
       (state <s> ^problem-space.name water-jug ^operator <o> + ^world.objects.object <m>)
       (<m> ^type memory ^last-operator pour)
       (<o> ^task-operator true ^name <n>)
    -->
       (<s> ^operator <o> =)
    }

    sp {water-jug*compare*after-pour*pour-worst
       (state <s> ^problem-space.name water-jug ^operator <o> + ^world.objects.object <m>)
       (<m> ^type memory ^last-operator pour)
       (<o> ^name pour)
    -->
       (<s> ^operator <o> <)
    }

    ## h4, h5: after fill or empty, pour is best and fill and empty are worst.
    sp {water-jug*compare*after-fill-empty
       (state <s> ^problem-space.name water-jug ^operator <o> + ^world.objects.object <m>)
       (<m> ^type memory ^last-operator << fill empty >>)
       (<o> ^task-operator true ^name <n>)
    -->
       (<s> ^operator <o> =)
    }

    sp {water-jug*compare*after-fill-empty*pour-best
       (state <s> ^problem-space.name water-jug ^operator <o> + ^world.objects.object <m>)
       (<m> ^type memory ^last-operator << fill empty >>)
       (<o> ^name pour)
    -->
       (<s> ^operator <o> >)
    }

    sp {water-jug*compare*after-fill-empty*fill-empty-worst
       (state <s> ^problem-space.name water-jug ^operator <o> + ^world.objects.object <m>)
       (<m> ^type memory ^last-operator << fill empty >>)
       (<o> ^name << fill empty >>)
    -->
       (<s> ^operator <o> <)
    }
    """)


def hierarchy(a):
    """fill is a complex composite task operator (W-COP-002): fill-jug, pick-up and put-down in its
    implementation substate (problem space fill, W-COP-007)."""
    a.add('fill.soar', """
    ## fill <jug> (composite, W-COP-002) is relevant when the jug is not full, or full and still held.  As in the
    ## original, both cases support one state WME, so the fill operator stays selected from pick-up to put-down.
    ## Effect: the jug is full and the hand is empty.  No application rule: the proposal retracts once the
    ## effect holds (W-COP-003, W-COP-005).
    sp {water-jug*elaborate*fill-relevant*not-full
       (state <s> ^problem-space.name water-jug ^world <w>)
       (<w> ^anchored-world true ^objects.object <j>)
       (<j> ^type jug ^free > 0)
    -->
       (<s> ^fill-relevant <j>)
    }

    sp {water-jug*elaborate*fill-relevant*held
       (state <s> ^problem-space.name water-jug ^world <w>)
       (<w> ^anchored-world true ^objects.object <j> <hand>)
       (<j> ^type jug ^free <= 0 ^object-handle $ <h>)
       (<hand> ^type hand ^holding $ <h>)
    -->
       (<s> ^fill-relevant <j>)
    }

    sp {water-jug*propose*fill
       (state <s> ^problem-space.name water-jug ^flags.mea-operator-selection true ^desireds.unachieved-desireds true ^fill-relevant <j>)
       (<j> ^object-handle $ <h> ^volume <v>)
    -->
       (<s> ^operator <o> +)
       (<o> ^name fill ^task-operator true ^argument1 <j> ^argument-count 1 ^desireds <pre> ^effect-desireds <ed>)
       (<pre> ^desired-count 0)
       (<ed> ^desired-count 2 ^desired <e1> <e2>)
       (<e1> ^object <e1o>)
       (<e1o> ^object-handle <h> ^contents <v>)
       (<e2> ^object <e2o>)
       (<e2o> ^object-handle hand ^holding none)
    }

    ## Implementation substate of fill (^problem-space.name fill, ^argument1 = the jug; W-COP-007, W-SUB-005).
    sp {water-jug*propose*pick-up
       (state <s> ^problem-space.name fill ^argument1 <j> ^world <w>)
       (<j> ^object-handle $ <h>)
       (<w> ^anchored-world true ^objects.object <hand>)
       (<hand> ^type hand ^holding none)
    -->
       (<s> ^operator <o> +)
       (<o> ^name pick-up ^task-operator true ^action-handle pick-up ^argument1 <j> ^argument-count 1 ^desireds <pre>)
       (<pre> ^desired-count 0)
    }

    sp {water-jug*apply*pick-up*internal
       (state <s> ^operator <o> ^internal-actions true ^world <w>)
       (<o> ^name pick-up ^pre-conditions-satisfied true ^argument1.object-handle $ <h>)
       (<w> ^anchored-world true ^objects.object <hand>)
       (<hand> ^type hand ^holding none)
    -->
       (log 1 (crlf) |Apply pick-up: | <h>)
       (<hand> ^holding none - <h>)
    }

    sp {water-jug*propose*fill-jug
       (state <s> ^problem-space.name fill ^argument1 <j> ^world <w>)
       (<j> ^object-handle $ <h> ^free > 0)
       (<w> ^anchored-world true ^objects.object <hand>)
       (<hand> ^type hand ^holding $ <h>)
    -->
       (<s> ^operator <o> +)
       (<o> ^name fill-jug ^task-operator true ^action-handle fill-jug ^argument1 <j> ^argument-count 1 ^desireds <pre>)
       (<pre> ^desired-count 0)
    }

    sp {water-jug*apply*fill-jug*internal
       (state <s> ^operator <o> ^internal-actions true ^world <w>)
       (<o> ^name fill-jug ^pre-conditions-satisfied true ^argument1.object-handle $ <h>)
       (<w> ^anchored-world true ^objects.object <j>)
       (<j> ^object-handle $ <h> ^volume <v> ^contents <c>)
    -->
       (log 1 (crlf) |Apply fill-jug: | <h>)
       (<j> ^contents <c> - <v>)
    }

    sp {water-jug*propose*put-down
       (state <s> ^problem-space.name fill ^argument1 <j> ^world <w>)
       (<j> ^object-handle $ <h> ^free <= 0)
       (<w> ^anchored-world true ^objects.object <hand>)
       (<hand> ^type hand ^holding $ <h>)
    -->
       (<s> ^operator <o> +)
       (<o> ^name put-down ^task-operator true ^action-handle put-down ^argument1 <j> ^argument-count 1 ^desireds <pre>)
       (<pre> ^desired-count 0)
    }

    sp {water-jug*apply*put-down*internal
       (state <s> ^operator <o> ^internal-actions true ^world <w>)
       (<o> ^name put-down ^pre-conditions-satisfied true ^argument1.object-handle $ <h>)
       (<w> ^anchored-world true ^objects.object <hand>)
       (<hand> ^type hand ^holding $ <h>)
    -->
       (log 1 (crlf) |Apply put-down: | <h>)
       (<hand> ^holding <h> - none)
    }

    ## The original makes the implementation operators indifferent (only one is ever proposed).
    sp {water-jug*compare*fill-implementation*indifferent
       (state <s> ^problem-space.name fill ^operator <o> +)
       (<o> ^task-operator true)
    -->
       (<s> ^operator <o> =)
    }
    """)


def build():
    out = []
    a = base('water-jug', 'Water jug: 3 and 5 litre jugs, empty; get 1 litre in the 3-litre jug. Random choice of moves.')
    a.settings += ['chunk never']; indifferent(a); out.append(a.write())

    for v, chunk in (('water-jug-hierarchy', 'chunk never'), ('water-jug-hierarchy-chunk', 'chunk always\nchunk add-osk on')):
        a = base(v, 'Water jug with fill as a composite operator (pick-up, fill-jug, put-down in a substate). Random choice of moves.',
                 init=INIT_HAND, fill=False)
        a.settings += chunk.split('\n'); hierarchy(a); indifferent(a); out.append(a.write())

    for v, chunk in (('water-jug-tie', 'chunk never'), ('water-jug-tie-chunk', 'chunk always\nchunk add-osk on')):
        init = INIT.replace("(<objs> ^object <j3> <j5>)", "(<objs> ^object <j3> <j5> <m>)\n(<m> ^object-handle memory ^anchored true ^type memory ^last-operator none)")
        a = base(v, 'Water jug; moves chosen by the original tie heuristics on the last operator (alternate pour with fill/empty).', init=init)
        a.settings += chunk.split('\n'); last_operator_control(a); out.append(a.write())

    a = base('water-jug-rl', 'Water jug with reinforcement learning over jug contents (templates), random exploration.')
    a.settings += ['chunk never']; rl(a); indifferent(a, 'the original selects among its task operators by RL values among indifferent operators')
    a.files['initialize-water-jug.soar'][0] = a.files['initialize-water-jug.soar'][0].replace('^mea-operator-selection true', '^mea-operator-selection true ^rl true')
    out.append(a.write())

    for v, about, extra in (
            ('water-jug-look-ahead', 'Water jug solved by look-ahead; a state that repeats an ancestor is a partial failure.', None),
            ('water-jug-look-ahead-failure-states', 'Water jug by look-ahead, plus known dead-end states (3-5, 0-0) as partial failures.', 'partial-failure'),
            ('water-jug-look-ahead-rl', 'Water jug by look-ahead with RL; dead-end states (3-5, 0-0) get expected value -1.', 'expected-value')):
        a = base(v, about)
        a.settings += ['chunk always', 'chunk add-osk on']
        duplicate(a)
        if extra: avoid(a, extra)
        if v.endswith('-rl'):
            a.settings += ['rl --set learning on', 'rl --set learning-rate 0.100000', 'rl --set discount-rate 0.500000',
                           'indifferent-selection --epsilon-greedy']
        out.append(a.write())
    return out


if __name__ == '__main__':
    for p in build(): print(p)
