"""wizards family (three wizards and the spots on their foreheads; nested views of what each knows), world-v6.
The original links views, records and mark variables by identifiers.  Under W-OBJ-004 every object attribute is a
constant, so views, records and mark variables are world objects named by handles, and the links between records
(sib, sub) are relation objects (W-REL-001)."""
from v6 import *

T = 'wizards'
DERIVED = ['own', 'white', 'black', 'blackish', 'gwhite', 'gblack', 'contra']
W = '(state <s> ^problem-space.name wizards ^flags.mea-operator-selection true ^desireds.unachieved-desireds true ^world <w>)\n       (<w> ^anchored-world true)'


def op(name, args):
    a = ' '.join(f'^argument{i+1} {v}' for i, v in enumerate(args))
    return f"""(<s> ^operator <o> +)
       (<o> ^name {name} ^task-operator true ^action-handle {name} {a} ^argument-count {len(args)} ^desireds <pre>)
       (<pre> ^desired-count 0)"""


def build():
    a = Agent('wizards', 'wizards', T, 'Three wizards: A sees B and C marked white and must say his own colour; nested models of what each wizard knows.')
    a.settings += ['chunk never']
    problem_space(a, ''.join(f' ^dont-copy-object-attribute {d}' for d in DERIVED))
    initialize(a, """
    (<objs> ^object <pz> <v1> <ra> <rb> <rc>)
    (<pz> ^object-handle puzzle ^anchored true ^type puzzle ^done 0 ^nviews 1)
    (<v1> ^object-handle view-1 ^anchored true ^type view ^vid 1 ^owner 1 ^depth 1 ^parent none)
    (<ra> ^object-handle A ^anchored true ^type record ^wiz 1 ^mark 0 ^var 0 ^modeled 0 ^aguess 0 ^view view-1 ^mv none)
    (<rb> ^object-handle B ^anchored true ^type record ^wiz 2 ^mark 1 ^var 0 ^modeled 0 ^aguess 0 ^view view-1 ^mv none)
    (<rc> ^object-handle C ^anchored true ^type record ^wiz 3 ^mark 1 ^var 0 ^modeled 0 ^aguess 0 ^view view-1 ^mv none)
    (<w> ^sib <s1> <s2> <s3> <s4> <s5> <s6>)
    (<s1> ^argument1 <ra> ^argument2 <rb>) (<s2> ^argument1 <ra> ^argument2 <rc>)
    (<s3> ^argument1 <rb> ^argument2 <ra>) (<s4> ^argument1 <rb> ^argument2 <rc>)
    (<s5> ^argument1 <rc> ^argument2 <ra>) (<s6> ^argument1 <rc> ^argument2 <rb>)
    (<ds> ^desired-count 1 ^desired <d1>)
    (<d1> ^object <d1o>)
    (<d1o> ^object-handle puzzle ^done 1)
    """, flags={'mea-operator-selection': 'true'})
    achievement_object(a)
    # ---------------------------------------------------------------- derived (i-supported, listed as dont-copy)
    E = '(state <s> ^problem-space.name wizards ^world <w>)\n       (<w> ^anchored-world true ^objects.object <r>)'
    SUB = '(<w> ^sub <sr>)\n       (<sr> ^argument1 <r> ^argument2 <b>)'
    rules = [
        ('own', '(<r> ^type record ^wiz <wz> ^view <vh>)\n       (<w> ^objects.object <v>)\n       (<v> ^object-handle $ <vh> ^owner <wz>)', 'own'),
        ('white*mark', '(<r> ^type record ^mark 1)', 'white'),
        ('white*two-blackish-sibs', '(<r> ^type record ^own 1)\n       (<w> ^sib <x1> { <> <x1> <x2> })\n       (<x1> ^argument1 <r> ^argument2 <b1>)\n       (<x2> ^argument1 <r> ^argument2 { <> <b1> <b2> })\n       (<b1> ^blackish 1)\n       (<b2> ^blackish 1)', 'white'),
        ('white*via-sub', f'{SUB}\n       (<b> ^white 1 -^contra 1)', 'white'),
        ('black*mark', '(<r> ^type record ^mark 2)', 'black'),
        ('black*via-sub', f'{SUB}\n       (<b> ^black 1 -^contra 1)', 'black'),
        ('blackish*black', '(<r> ^type record ^black 1)', 'blackish'),
        ('blackish*assumed', '(<r> ^type record ^mv { <> none <mh> })\n       (<w> ^objects.object <m>)\n       (<m> ^object-handle $ <mh> ^value 2)', 'blackish'),
        ('gwhite*own', '(<r> ^type record ^own 1 ^white 1)', 'gwhite'),
        ('gwhite*guess', '(<r> ^type record ^aguess 1)', 'gwhite'),
        ('gwhite*via-sub', f'{SUB}\n       (<b> ^gwhite 1 -^contra 1)', 'gwhite'),
        ('gblack*own', '(<r> ^type record ^own 1 ^black 1)', 'gblack'),
        ('gblack*guess', '(<r> ^type record ^aguess 2)', 'gblack'),
        ('gblack*via-sub', f'{SUB}\n       (<b> ^gblack 1 -^contra 1)', 'gblack'),
        ('contra*white-unguessed', '(<r> ^type record ^gwhite 1 ^aguess 0)', 'contra'),
        ('contra*black-unguessed', '(<r> ^type record ^gblack 1 ^aguess 0)', 'contra'),
        ('contra*both', '(<r> ^type record ^gwhite 1 ^gblack 1)', 'contra'),
    ]
    for nm, cond, attr in rules:
        a.add('derived.soar', f"""
        ## Derived record property {attr} ({nm}); i-supported, listed as ^dont-copy-object-attribute (W-SEL-009).
        sp {{wizards*elaborate*record*{nm}
           {E}
           {cond}
        -->
           (<r> ^{attr} 1)
        }}
        """)
    # ---------------------------------------------------------------- operators
    for gv in (0, 1, 2):
        a.add('ascribe.soar', f"""
        ## ascribe-guess <x1> <x2> (guess {gv}): the guess of a record passes to the record below it.
        sp {{wizards*propose*ascribe-guess*gv-{gv}
           {W}
           (<w> ^sub <sr> ^objects.object <x1> <x2>)
           (<sr> ^argument1 <x1> ^argument2 <x2>)
           (<x1> ^aguess {gv})
           (<x2> -^own 1 -^aguess {gv})
        -->
           {op('ascribe-guess', ['<x1>', '<x2>'])}
           (<o> ^gv {gv})
        }}
        """)
    a.add('ascribe.soar', f"""
    sp {{wizards*apply*ascribe-guess*internal
       (state <s> ^operator <o> ^internal-actions true ^world <w>)
       (<o> ^name ascribe-guess ^pre-conditions-satisfied true ^argument2.object-handle $ <h> ^gv <gv>)
       (<w> ^anchored-world true ^objects.object <x2>)
       (<x2> ^object-handle $ <h>)
    -->
       (log 1 (crlf) |Ascribe guess | <gv> | to | <h>)
       (<x2> ^aguess <gv>)
    }}

    ## ascribe-mark <x1> <x2>: a known mark passes to the record below.
    sp {{wizards*propose*ascribe-mark
       {W}
       (<w> ^sub <sr> ^objects.object <x1> <x2>)
       (<sr> ^argument1 <x1> ^argument2 <x2>)
       (<x1> ^mark <> 0)
       (<x2> -^own 1 ^mark 0)
    -->
       {op('ascribe-mark', ['<x1>', '<x2>'])}
    }}

    sp {{wizards*apply*ascribe-mark*internal
       (state <s> ^operator <o> ^internal-actions true ^world <w>)
       (<o> ^name ascribe-mark ^pre-conditions-satisfied true ^argument1.object-handle $ <h1> ^argument2.object-handle $ <h2>)
       (<w> ^anchored-world true ^objects.object <x1> <x2>)
       (<x1> ^object-handle $ <h1> ^mark <m1>)
       (<x2> ^object-handle $ <h2> ^mark <m2>)
    -->
       (log 1 (crlf) |Ascribe mark | <m1> | to | <h2>)
       (<x2> ^mark <m2> - <m1>)
    }}

    ## ascribe-unknown <x1> <x2>: an unknown mark (a mark variable) passes to the record below.
    sp {{wizards*propose*ascribe-unknown
       {W}
       (<w> ^sub <sr> ^objects.object <x1> <x2>)
       (<sr> ^argument1 <x1> ^argument2 <x2>)
       (<x1> ^mv <> none)
       (<x2> -^own 1 ^var 0)
    -->
       {op('ascribe-unknown', ['<x1>', '<x2>'])}
    }}

    sp {{wizards*apply*ascribe-unknown*internal
       (state <s> ^operator <o> ^internal-actions true ^world <w>)
       (<o> ^name ascribe-unknown ^pre-conditions-satisfied true ^argument1.object-handle $ <h1> ^argument2.object-handle $ <h2>)
       (<w> ^anchored-world true ^objects.object <x1> <x2>)
       (<x1> ^object-handle $ <h1> ^mv <mh>)
       (<x2> ^object-handle $ <h2> ^mv <old> ^var <v>)
    -->
       (log 1 (crlf) |Ascribe unknown | <mh> | to | <h2>)
       (<x2> ^mv <old> - <mh> ^var <v> - 1)
    }}
    """)
    for colour, val, untried, extra in (('black', 2, '2', ''), ('white', 1, '1', '-^untried 2')):
        a.add('assume.soar', f"""
        ## assume-{colour} <record>: in a view, assume the record's unknown spot is {colour}.
        sp {{wizards*propose*assume-{colour}
           {W}
           (<w> ^objects.object <r> <v> <m>)
           (<r> ^type record -^own 1 ^view <vh> ^mv <mh>)
           (<v> ^object-handle $ <vh>)
           (<m> ^object-handle $ <mh> ^value 0 ^untried {untried} {extra})
        -->
           {op('assume-' + colour, ['<r>', '<v>', '<m>'])}
        }}

        sp {{wizards*apply*assume-{colour}*internal
           (state <s> ^operator <o> ^internal-actions true ^world <w>)
           (<o> ^name assume-{colour} ^pre-conditions-satisfied true ^argument1.object-handle $ <rh> ^argument2.object-handle $ <vh> ^argument3.object-handle $ <mh>)
           (<w> ^anchored-world true ^objects.object <r> <v> <m>)
           (<r> ^object-handle $ <rh> ^wiz <wz>)
           (<v> ^object-handle $ <vh> ^vid <vid> ^owner <ow>)
           (<m> ^object-handle $ <mh> ^value <val> ^assigned <as>)
        -->
           (log 1 (crlf) |In the view of wizard | <ow> |, assume wizard | <wz> |'s spot is {colour}.|)
           (<m> ^value <val> - {val} ^untried {untried} - ^assigned <as> - <vid>)
        }}
        """)
    for u in (1, 2):
        a.add('complement.soar', f"""
        ## complement (untried {u}): a contradiction in view k1 means that, in the child view k2 where the mark
        ## variable was assumed, the record's spot is the remaining colour {u}.
        sp {{wizards*propose*complement*u-{u}
           {W}
           (<w> ^objects.object <w1> <k1> <k2> <w2> <m>)
           (<w1> ^type record ^contra 1 ^view <k1h>)
           (<k1> ^object-handle $ <k1h>)
           (<k2> ^type view ^parent <k1h> ^object-handle <k2h> ^vid <vid2>)
           (<w2> ^type record ^view <k2h> ^mv <mh>)
           (<m> ^object-handle $ <mh> ^assigned <vid2> ^untried {u})
        -->
           {op('complement', ['<w2>', '<k1>', '<k2>'])}
           (<o> ^u {u})
        }}
        """)
    a.add('complement.soar', """
    sp {wizards*apply*complement*internal
       (state <s> ^operator <o> ^internal-actions true ^world <w>)
       (<o> ^name complement ^pre-conditions-satisfied true ^argument1.object-handle $ <h2> ^argument2.owner <o1> ^argument3.owner <o2> ^u <u>)
       (<w> ^anchored-world true ^objects.object <w2>)
       (<w2> ^object-handle $ <h2> ^mark <mk> ^mv <mh> ^var <v> ^wiz <wz>)
    -->
       (log 1 (crlf) |Contradiction in the view of wizard | <o1> |: in the view of wizard | <o2> |, wizard | <wz> |'s spot must be | <u>)
       (<w2> ^mark <mk> - <u> ^mv <mh> - none ^var <v> - 0)
    }

    ## consider-knows <record> in view k: model, in a new view, what that wizard knows: a new view and three
    ## new records (one per wizard), siblings of each other and below the three records of view k.
    sp {wizards*propose*consider-knows
       (state <s> ^problem-space.name wizards ^flags.mea-operator-selection true ^desireds.unachieved-desireds true ^world <w>)
       (<w> ^anchored-world true ^objects.object <r> <k> <a1> <a2> <a3>)
       (<r> ^type record -^own 1 ^modeled 0 ^view <kh>)
       (<k> ^object-handle $ <kh>)
       (<a1> ^type record ^view <kh> ^wiz 1)
       (<a2> ^type record ^view <kh> ^wiz 2)
       (<a3> ^type record ^view <kh> ^wiz 3)
    -->
       (<s> ^operator <o> +)
       (<o> ^name consider-knows ^task-operator true ^action-handle consider-knows ^argument1 <r> ^argument2 <k> ^argument-count 2 ^desireds <pre>)
       (<pre> ^desired-count 0)
    }

    sp {wizards*apply*consider-knows*internal
       (state <s> ^operator <o> ^internal-actions true ^world <w>)
       (<o> ^name consider-knows ^pre-conditions-satisfied true ^argument1.object-handle $ <rh> ^argument2.object-handle $ <kh>)
       (<w> ^anchored-world true ^objects <objs>)
       (<objs> ^object <pz> <r> <k> <a1> <a2> <a3>)
       (<pz> ^type puzzle ^nviews <n>)
       (<r> ^object-handle $ <rh> ^modeled <md> ^wiz <wz>)
       (<k> ^object-handle $ <kh> ^owner <ow> ^depth <dp>)
       (<a1> ^type record ^view $ <kh> ^wiz 1)
       (<a2> ^type record ^view $ <kh> ^wiz 2)
       (<a3> ^type record ^view $ <kh> ^wiz 3)
    -->
       (log 1 (crlf) |In the view of wizard | <ow> |, model what wizard | <wz> | knows.|)
       (<pz> ^nviews <n> - (+ <n> 1))
       (<r> ^modeled <md> - 1)
       (<objs> ^object <v> <r1> <r2> <r3>)
       (<v> ^object-handle (concat view- (+ <n> 1)) ^anchored true ^type view ^vid (+ <n> 1) ^owner <wz> ^depth (+ <dp> 1) ^parent <kh>)
       (<r1> ^object-handle (concat rec- (+ <n> 1) -1) ^anchored true ^type record ^wiz 1 ^mark 0 ^var 0 ^modeled 0 ^view (concat view- (+ <n> 1)) ^mv none)
       (<r2> ^object-handle (concat rec- (+ <n> 1) -2) ^anchored true ^type record ^wiz 2 ^mark 0 ^var 0 ^modeled 0 ^view (concat view- (+ <n> 1)) ^mv none)
       (<r3> ^object-handle (concat rec- (+ <n> 1) -3) ^anchored true ^type record ^wiz 3 ^mark 0 ^var 0 ^modeled 0 ^view (concat view- (+ <n> 1)) ^mv none)
       (<w> ^sib <s1> <s2> <s3> <s4> <s5> <s6> ^sub <u1> <u2> <u3>)
       (<s1> ^argument1 <r1> ^argument2 <r2>) (<s2> ^argument1 <r1> ^argument2 <r3>)
       (<s3> ^argument1 <r2> ^argument2 <r1>) (<s4> ^argument1 <r2> ^argument2 <r3>)
       (<s5> ^argument1 <r3> ^argument2 <r1>) (<s6> ^argument1 <r3> ^argument2 <r2>)
       (<u1> ^argument1 <a1> ^argument2 <r1>) (<u2> ^argument1 <a2> ^argument2 <r2>) (<u3> ^argument1 <a3> ^argument2 <r3>)
    }

    ## self-unknown <record>: a wizard's own spot, neither known white nor black: a new mark variable.
    sp {wizards*propose*self-unknown
       (state <s> ^problem-space.name wizards ^flags.mea-operator-selection true ^desireds.unachieved-desireds true ^world <w>)
       (<w> ^anchored-world true ^objects.object <r>)
       (<r> ^type record ^own 1 -^white 1 -^black 1 ^mark 0 ^var 0)
    -->
       (<s> ^operator <o> +)
       (<o> ^name self-unknown ^task-operator true ^action-handle self-unknown ^argument1 <r> ^argument-count 1 ^desireds <pre>)
       (<pre> ^desired-count 0)
    }

    sp {wizards*apply*self-unknown*internal
       (state <s> ^operator <o> ^internal-actions true ^world <w>)
       (<o> ^name self-unknown ^pre-conditions-satisfied true ^argument1.object-handle $ <rh>)
       (<w> ^anchored-world true ^objects <objs>)
       (<objs> ^object <r>)
       (<r> ^object-handle $ <rh> ^var <v> ^mv <old> ^wiz <wz>)
    -->
       (log 1 (crlf) |In the view of wizard | <wz> |, his own spot is unknown.|)
       (<objs> ^object <m>)
       (<m> ^object-handle (concat mv- <rh>) ^anchored true ^type markvar ^value 0 ^assigned 0 ^untried 1 2)
       (<r> ^mv <old> - (concat mv- <rh>) ^var <v> - 1)
    }
    """)
    for colour, attr in (('black', 'gblack'), ('white', 'gwhite')):
        a.add('guess.soar', f"""
        ## guess-{colour}: in the top view, a wizard who can conclude his own spot is {colour} says so.
        sp {{wizards*propose*guess-{colour}
           {W}
           (<w> ^objects.object <pz> <r> <k>)
           (<pz> ^type puzzle ^done 0)
           (<r> ^type record ^own 1 ^{attr} 1 ^view <kh>)
           (<k> ^object-handle $ <kh> ^depth 1)
        -->
           {op('guess-' + colour, ['<r>'])}
        }}

        sp {{wizards*apply*guess-{colour}*internal
           (state <s> ^operator <o> ^internal-actions true ^world <w>)
           (<o> ^name guess-{colour} ^pre-conditions-satisfied true ^argument1.wiz <wz>)
           (<w> ^anchored-world true ^objects.object <pz>)
           (<pz> ^type puzzle ^done <d>)
        -->
           (log 1 (crlf) |Wizard | <wz> | guesses his spot is {colour}.|)
           (<pz> ^done <d> - 1)
        }}
        """)
    a.add('search-control.soar', """
    ## Search control of the original (preferences.soar), as evaluation rules in the task state.
    sp {wizards*compare*self-unknown-first
       (state <s> ^problem-space.name wizards ^operator <o> +)
       (<o> ^name self-unknown ^argument1.var 0)
    -->
       (<s> ^operator <o> >)
    }

    sp {wizards*compare*complement-first
       (state <s> ^problem-space.name wizards ^operator <o> +)
       (<o> ^name complement)
    -->
       (<s> ^operator <o> >)
    }

    sp {wizards*compare*guess-first
       (state <s> ^problem-space.name wizards ^operator <o> +)
       (<o> ^name << guess-white guess-black >>)
    -->
       (<s> ^operator <o> >)
    }

    sp {wizards*compare*consider-last
       (state <s> ^problem-space.name wizards ^operator <o> +)
       (<o> ^name consider-knows ^argument1.modeled 0)
    -->
       (<s> ^operator <o> <)
    }

    sp {wizards*compare*assume-late
       (state <s> ^problem-space.name wizards ^operator <o> +)
       (<o> ^name << assume-black assume-white >> ^argument3.value 0)
    -->
       (<s> ^operator <o> <)
    }

    sp {wizards*compare*assume-before-consider
       (state <s> ^problem-space.name wizards ^operator <o> + ^operator { <> <o> <o2> } +)
       (<o> ^name << assume-black assume-white >>)
       (<o2> ^name consider-knows)
    -->
       (<s> ^operator <o> > <o2>)
    }

    ## Prefer the deepest view: reject consider-knows in view k when another works in a child view of k.
    sp {wizards*compare*prefer-deeper
       (state <s> ^problem-space.name wizards ^operator <o> + ^operator { <> <o> <o2> } +)
       (<o> ^name consider-knows ^argument2.object-handle <kh>)
       (<o2> ^name consider-knows ^argument2.parent <kh>)
    -->
       (<s> ^operator <o> -)
    }

    ## Prefer modelling a wizard who has no view yet.
    sp {wizards*compare*prefer-new-names
       (state <s> ^problem-space.name wizards ^operator <o> + ^operator { <> <o> <o2> } + ^world <w>)
       (<o> ^name consider-knows ^argument1.wiz <wz>)
       (<o2> ^name consider-knows ^argument1.wiz <wz2>)
       (<w> ^anchored-world true ^objects.object <v>)
       (<v> ^type view ^owner <wz>)
      -{(<w> ^objects.object <v2>)
        (<v2> ^type view ^owner <wz2>)}
    -->
       (<s> ^operator <o> -)
    }

    sp {wizards*compare*task-operator*indifferent
       (state <s> ^problem-space.name wizards ^operator <o> +)
       (<o> ^task-operator true)
    -->
       (<s> ^operator <o> =)
    }
    """)
    return a.write()


if __name__ == '__main__':
    print(build())
