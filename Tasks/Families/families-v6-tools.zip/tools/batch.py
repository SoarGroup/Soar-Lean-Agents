"""batch.py ROOT KIND OUT.jsonl [--only fam,...]  KIND = original | world | world-v6 | world-lean
Caps and time limits come from ROOT/caps.json (Tasks/Families/caps.json; 25 Nov 2026)."""
import sys, os, json, subprocess, concurrent.futures as cf
root, kind, outp = sys.argv[1:4]
only = sys.argv[sys.argv.index('--only')+1].split(',') if '--only' in sys.argv else None
L = [l.split() for l in open(os.path.join(root, 'list.txt')) if l.strip()]
if only: L = [x for x in L if x[0] in only or x[1] in only]
C = json.load(open(os.path.join(root, 'caps.json')))
def caps(v):
    x = C['variants'].get(v, {})
    return x.get('cap', C['default_cap']), x.get('time_limit_s', C['default_time_limit_s'])
def go(fv):
    f, v = fv; d = os.path.join(root, f, kind, v)
    if not os.path.isdir(d): return dict(family=f, variant=v, error='missing')
    cap, tl = caps(v)
    try:
        r = subprocess.run([sys.executable, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'run2.py'), d, v + '.soar', '--seeds', '1-3', '--episodes', '1', '--cap', str(cap)], capture_output=True, text=True, timeout=tl)
        seeds = [json.loads(l) for l in r.stdout.splitlines() if l.startswith('{')]
        return dict(family=f, variant=v, seeds=seeds, stderr=r.stderr[-500:])
    except subprocess.TimeoutExpired: return dict(family=f, variant=v, error=f'timeout ({tl} s)')
with cf.ThreadPoolExecutor(int(os.environ.get('J', 4))) as ex, open(outp, 'w') as o:
    for res in ex.map(go, L): o.write(json.dumps(res) + '\n'); o.flush(); print(res['variant'], res.get('error') or [ (s["episodes"][0]["result"], s["episodes"][0]["decisions"]) for s in res['seeds']], flush=True)
