"""batch.py ROOT KIND OUT.jsonl [--only fam,...]  KIND = original | world | world-v6"""
import sys, os, json, subprocess, concurrent.futures as cf
root, kind, outp = sys.argv[1:4]
only = sys.argv[sys.argv.index('--only')+1].split(',') if '--only' in sys.argv else None
L = [l.split() for l in open(os.path.join(root, 'list.txt')) if l.strip()]
if only: L = [x for x in L if x[0] in only or x[1] in only]
def go(fv):
    f, v = fv; d = os.path.join(root, f, kind, v)
    if not os.path.isdir(d): return dict(family=f, variant=v, error='missing')
    cap = '80000' if v == 'count-in-substate' else '3000'
    try:
        r = subprocess.run([sys.executable, '/home/claude/w/tools/run2.py', d, v + '.soar', '--seeds', '1-3', '--episodes', '1', '--cap', cap], capture_output=True, text=True, timeout=900)
        seeds = [json.loads(l) for l in r.stdout.splitlines() if l.startswith('{')]
        return dict(family=f, variant=v, seeds=seeds, stderr=r.stderr[-500:])
    except subprocess.TimeoutExpired: return dict(family=f, variant=v, error='timeout')
with cf.ThreadPoolExecutor(int(os.environ.get('J', 4))) as ex, open(outp, 'w') as o:
    for res in ex.map(go, L): o.write(json.dumps(res) + '\n'); o.flush(); print(res['variant'], res.get('error') or [ (s["episodes"][0]["result"], s["episodes"][0]["decisions"]) for s in res['seeds']], flush=True)
