#!/bin/bash
# dump.sh FAMILY VARIANT : task files of an original (no default/ copies)
d=/home/claude/w/repo/Tasks/Families/$1/original/$2
cd $d; for f in $(find . -name '*.soar' -not -path './default/*' | sort); do echo "### $f"; grep -v '^\s*$' $f; done
