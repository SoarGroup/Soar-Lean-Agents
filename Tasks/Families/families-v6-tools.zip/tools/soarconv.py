"""soarconv.py SRC DST: apply the Soar-Conventions.xlsx fixes to an original program tree (task files only;
default/ library copies are left as they are) and write it to DST.
  SYN-048  a # comment before every rule (generated from the rule's structure)
  SYN-044  constants in a single case (mixed-case symbols lower-cased consistently in the program)
  SYN-033  the first condition of a state rule tests ^name (operator-subgoal share rules)
  L0/L1    conditions on unconnected identifiers bound to the state they mean (arithmetic-smem-learn store rules)
Writes a CHANGES.md listing what changed."""
import os, re, shutil, sys
sys.path.insert(0, os.path.dirname(__file__))
from soarlint import rules_in

ROLE = {'propose': 'Propose', 'apply': 'Apply', 'elaborate': 'Elaborate', 'compare': 'Search control',
        'select': 'Search control', 'monitor': 'Monitor', 'detect': 'Detect', 'evaluate': 'Evaluate state',
        'halt': 'Halt', 'rl': 'RL value', 'reward': 'Reward', 'model': 'Episodic model', 'copy': 'Copy'}


def attrs(text):
    seen = []
    for a in re.findall(r'\^([\w|.-]+)', text):
        a = a.strip('|')
        if a not in seen and a not in ('operator',):
            seen.append(a)
    return seen


def comment(name, body):
    lhs, _, rhs = body.partition('-->')
    f = name.split('*')
    role = ROLE.get(f[1] if len(f) > 1 else '', 'Rule')
    op = re.search(r'\^name\s+([\w|-]+)', rhs) if f[1:2] == ['propose'] else None
    opn = op.group(1) if op else (f[2] if len(f) > 2 else name)
    state = f[0]
    tested = [a for a in attrs(lhs) if a not in ('superstate', 'type', 'name')][:6]
    made = [a for a in attrs(rhs) if a != 'name'][:6]
    pref = []
    for sym, word in (('>', 'better/best'), ('<', 'worse/worst'), ('=', 'indifferent'), (' -)', 'reject'), ('!', 'require')):
        if re.search(r'\^operator <\w+> [^)]*' + re.escape(sym.strip()), rhs):
            pref.append(word)
    if f[1:2] == ['propose']:
        s = f'# In state {state}: propose operator {opn} when the state has {", ".join(tested) or "the tested structure"}.'
    elif f[1:2] == ['apply']:
        s = f'# In state {state}: apply {opn}: changes {", ".join(made) or "the state"}' + (' (removes old values)' if ' -)' in rhs or '- )' in rhs else '') + '.'
    elif f[1:2] in (['compare'], ['select']):
        s = f'# In state {state}: search control: {", ".join(pref) or "preference"} for {opn}, testing {", ".join(tested)}.'
    elif f[1:2] == ['halt']:
        s = f'# In state {state}: stop the run when {", ".join(tested)}.'
    else:
        s = f'# In state {state}: {role.lower()} ({".".join(f[2:]) or name}): from {", ".join(tested) or "the state"}, add {", ".join(made) or "nothing"}.'
    return s


def fix_text(text, lower_map, report):
    out = []; i = 0
    for kind, body, line, before in rules_in(text):
        pass
    # rebuild with comments: walk again keeping positions
    pos = 0; res = ''
    for m in re.finditer(r'(?m)^(\s*)(sp|gp)\s*\{', text):
        if m.start() < pos:
            continue
        # find end of this rule
        j = m.end(); depth = 1
        while depth and j < len(text):
            c = text[j]
            if c == '\\':
                j += 2; continue
            if c == '|':
                k = j + 1
                while k < len(text) and text[k] != '|':
                    k += 2 if text[k] == '\\' else 1
                j = k
            elif c == '{':
                depth += 1
            elif c == '}':
                depth -= 1
            j += 1
        rule = text[m.start():j]
        before = text[pos:m.start()]
        body = text[m.end():j - 1]
        name = body.split()[0]
        new = rule
        for a, b in lower_map.items():
            new2 = re.sub(r'(?<![\w|-])' + re.escape(a) + r'(?![\w|-])', b, new)
            if new2 != new:
                report.append(f'SYN-044 {name}: {a} -> {b}')
                new = new2
        # SYN-033: share rules
        m33 = re.search(r'\(state <s> \^type operator-subgoal\)', new)
        if m33:
            st = name.split('*')[0]
            new = new.replace('(state <s> ^type operator-subgoal)', f'(state <s> ^name {st} ^type operator-subgoal)')
            report.append(f'SYN-033 {name}: first condition now tests ^name {st}')
        # unconnected identifiers in the smem-learn store rules
        if re.search(r'\(<up> \^', new):
            new = new.replace('(<up> ', '(<ss> ').replace('<up-d1>', '<ss-d1>').replace('<up-d2>', '<ss-d2>')
            report.append(f'L0 {name}: <up> was unconnected; bound to the superstate <ss>')
        if re.search(r'\(<local> \^', new):
            new = new.replace('(<local> ', '(<s> ').replace('<local-sum>', '<s-sum>').replace('<local-base>', '<s-base>')
            report.append(f'L0 {name}: <local> was unconnected; bound to the state <s>')
        if not re.search(r'#[^\n]*\n\s*$', before):
            nb = new[new.index('{') + 1:-1]
            ws = re.match(r'\s*', new).group(0)
            new = ws + comment(name, nb) + '\n' + new[len(ws):]
            report.append(f'SYN-048 {name}: comment added')
        res += before + new
        pos = j
    res += text[pos:]
    return res


def mixed_case(src):
    found = set()
    for root, _, files in os.walk(src):
        if '/default' in root:
            continue
        for fn in files:
            if fn.endswith('.soar'):
                t = open(os.path.join(root, fn)).read()
                for kind, body, line, before in rules_in(t):
                    body = re.sub(r'\|(?:\\.|[^|])*\|', ' ', body)
                    body = re.sub(r'(?m)#.*$', ' ', body)
                    for c in re.findall(r'(?<![\w<|-])([A-Za-z][\w-]*)(?![\w>|-])', body):
                        if c != c.lower() and c != c.upper():
                            found.add(c)
    return {c: c.lower().replace('__', '-').replace('_', '-') for c in found}


def convert(src, dst):
    if os.path.exists(dst):
        shutil.rmtree(dst)
    shutil.copytree(src, dst)
    lower = mixed_case(src)
    report = []
    for root, _, files in os.walk(dst):
        if '/default' in root:
            continue
        for fn in files:
            if fn.endswith('.soar'):
                p = os.path.join(root, fn)
                t = open(p).read()
                nt = fix_text(t, lower, report)
                if nt != t:
                    open(p, 'w').write(nt)
    return report


if __name__ == '__main__':
    r = convert(sys.argv[1], sys.argv[2])
    print(len(r), 'changes')
