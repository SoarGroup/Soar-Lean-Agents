"""soarlint.py: check Soar rule files against the checkable rows of Soar-Conventions.xlsx (L1-L6).
usage: python3 soarlint.py DIR [DIR...]   (prints one line per finding: ID file rule message)"""
import re, sys, os, collections

FUNCS = {'propose', 'apply', 'elaborate', 'compare', 'select', 'monitor', 'detect', 'evaluate', 'halt', 'rl', 'reward', 'model', 'copy'}


def rules_in(text):
    out = []; i = 0
    while True:
        m = re.search(r'(?m)^\s*(sp|gp)\s*\{', text[i:])
        if not m:
            return out
        start = i + m.start(); j = i + m.end(); depth = 1
        while depth and j < len(text):
            c = text[j]
            if c == '\\':
                j += 2; continue
            if c == '|':
                k = j + 1
                while k < len(text) and text[k] != '|':
                    k += 2 if text[k] == '\\' else 1
                j = k
            elif c == '{':
                depth += 1
            elif c == '}':
                depth -= 1
            j += 1
        body = text[i + m.end():j - 1]
        out.append((m.group(1), body, text[:start].count('\n') + 1, text[max(0, start - 300):start]))
        i = j


def lint_rule(kind, body, comment_before):
    f = []
    name = body.split()[0]
    rest = body[len(name):]
    flags = re.findall(r'^\s*(:[\w-]+)', rest, re.M)
    lhs, _, rhs = rest.partition('-->')
    fields = name.split('*')
    if len(fields) < 3 or fields[1] not in FUNCS:
        f.append(('SYN-025', f'rule name fields {fields[:3]}'))
    if any(fl in (':o-support', ':i-support', ':default', ':chunk') for fl in flags):
        f.append(('SYN-041', 'rule flag ' + ' '.join(flags)))
    first = re.search(r'\(state\s+<s>([^)]*)\)', lhs)
    if not first:
        f.append(('SYN-032', 'state variable is not <s> or no state test'))
    elif '^name' not in first.group(1) and '^superstate nil' not in first.group(1) and 'impasse' not in first.group(1) and 'superstate <' not in first.group(1):
        nxt = lhs[first.end():first.end() + 120]
        if '^name' not in nxt and '^superstate nil' not in nxt:
            f.append(('SYN-033', 'first condition does not test ^name'))
    if not re.search(r'#[^\n]*\n\s*$', comment_before):
        f.append(('SYN-048', 'no comment before the rule'))
    nprop = len(re.findall(r'\^operator\s+<\w+>\s*\+', rhs))
    if nprop > 1 and len(set(re.findall(r'\^operator\s+(<\w+>)\s*\+', rhs))) > 1:
        f.append(('PRO-020', 'proposes two operators'))
    if re.search(r'\^operator\s+<\w+>\s*\)', rhs) and not re.search(r'\^operator\s+<\w+>\s*[+=<>!~-]', rhs):
        f.append(('PRO-016', 'operator without explicit +'))
    # unconnected condition identifiers (bound nowhere else): a variable whose first appearance is as an object
    lvars = re.findall(r'\((<[\w-]+>)', lhs)
    linked = set(re.findall(r'\^[\w|.-]+\s+(?:\{[^}]*?)?(<[\w-]+>)', lhs)) | set(re.findall(r'state\s+(<[\w-]+>)', lhs))
    for v in lvars:
        if v not in linked:
            f.append(('L0-unconnected', f'condition on unconnected identifier {v}'))
    # constants in mixed case
    for c in set(re.findall(r'\^name\s+([A-Za-z][\w-]*)', body)):
        if c != c.lower() and not re.match(r'^[A-Z]\d*$', c):
            f.append(('SYN-044', f'mixed-case constant {c}'))
    if re.search(r'\(<[\w-]+>\s+\^[\w-]+\.[\w-]+\s+[^)]*\)', rhs):
        f.append(('SYN-030', 'dot notation in action'))
    if re.search(r'\^operator <\w+> \+\s*\)\s*\n\s*\(<s> \^operator <\w+> =', rhs) or re.search(r'\+ =', rhs):
        f.append(('PRO-019', 'indifferent preference in proposal'))
    if 'halt' in rhs and not re.search(r'\(halt\)', rhs):
        pass
    return name, f


def main(dirs):
    tot = collections.Counter()
    for d in dirs:
        for root, _, files in os.walk(d):
            if '/default' in root or root.endswith('default'):
                continue
            for fn in files:
                if not fn.endswith('.soar'):
                    continue
                p = os.path.join(root, fn); t = open(p).read()
                for kind, body, line, before in rules_in(t):
                    name, fs = lint_rule(kind, body, before)
                    for cid, msg in fs:
                        tot[cid] += 1
                        if '-v' in sys.argv:
                            print(cid, os.path.relpath(p, d), name, msg)
    for k, v in tot.most_common():
        print(f'{k:16} {v}')


if __name__ == '__main__':
    main([a for a in sys.argv[1:] if not a.startswith('-')])
