import sys,json
for l in sys.stdin:
    try: d=json.loads(l)
    except: print(l.strip()); continue
    e=d['episodes'][0]; print(d['seed'],e['result'],'dec',e['decisions'],'top',e['top_ops'],'act',e['actions'],' '.join(e['top_plan'][:25]))
