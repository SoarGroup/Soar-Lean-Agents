# Instructions for writing one Soar agent (read fully before starting)

You are writing a Soar agent, from an English task description, that runs with the Soar library v2.45 and follows the
World and Soar conventions. Your output is compared in a controlled experiment, so the rules about which files you
may read are strict.

## Files you may read

Only these (your prompt says which apply to you):
1. Your task description: /home/claude/gen3/tasks/<FAMILY>/task.md
2. The conventions: /home/claude/gen3/conventions/World-Conventions-Spec-v8.md and Soar-Conventions-Spec.md
3. The Soar library (to understand its interface, flags and messages): /home/claude/lib244/soar-library/
4. The run harness: /home/claude/gen3/tools/run2.py and this file
5. ONLY IF your prompt names one: the example folder it names, under /home/claude/gen3/examples/
6. Your own output folder.

Do NOT read, list, search or grep anything else: not other folders under /home/claude/gen3 (other tasks, other
example sets, other writers' outputs), not /home/claude/runroot, /home/claude/repo, /home/claude/runtools, /tmp,
/mnt, home-directory files, or web pages about Soar agents. Do not use find/grep/ls outside the allowed paths.
If you are unsure whether a path is allowed, do not read it.

## What to produce

In your output folder /home/claude/gen3/out/<CONDITION>/<FAMILY>/:
- <FAMILY>.soar: the main file. It must load the library with
    pushd /home/claude/lib244/soar-library
    source soar-library.soar
    popd
  and then source your own rule files (relative to the output folder).
- Your rule files (any organisation the conventions call for).
- REPORT.md: approach chosen and why (search method, flags), files, each test run (seed, result, decisions), known
  problems, and a list of every file you read outside your output folder.

The agent must solve the instance in task.md, report the result in the trace with a line containing
"TASK-RESULT: success" (or "TASK-RESULT: failure" if it detects failure), and halt. Follow the conventions; where they
leave a choice, choose as the conventions suggest for a task of this kind.

## Testing

Run (from any directory):
    python3 /home/claude/gen3/tools/run2.py /home/claude/gen3/out/<CONDITION>/<FAMILY> <FAMILY>.soar --seeds 1-3 --episodes 1 --cap 20000
It prints one JSON line per seed (result, decisions, actions, load_errors, runtime_errors, ...). Fix load errors and
runtime errors. Aim for success on all three seeds. Stop when it succeeds on all seeds, or after 15 test runs, and
report honestly what works and what does not. Do not modify the library, the harness, the task or the conventions.
Keep total effort reasonable (about an hour of work).

Final message: 3-6 lines: success per seed, decisions per seed, number of rules, and anything notable.
