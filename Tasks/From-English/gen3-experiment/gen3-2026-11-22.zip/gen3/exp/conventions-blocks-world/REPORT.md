# blocks-world (condition: conventions)

## Approach
- World (L7): blocks A, B, C and the table are world objects with ^object-handle, ^anchored true and ^static.type
  (block/table; never changed by an operator, L7-017). Stacking is the relation ^on (^argument1 top, ^argument2 below),
  one relation object per fact (L7-016); ^on is copied by look-ahead (L14-007).
- Desireds (L8): three relation desireds on(A,B), on(B,C), on(C,table), ^desired-count 3. Task elaborations supply
  ^achieved/^unachieved (L8-018..L8-020); the library adds ^success.
- One task-action operator move-block (L9-004): ^argument1 block, ^argument2 destination, ^argument-count 2,
  ^action-handle, ^task-operator true, ^desireds with ^desired-count 0 (clearness is tested in the proposal).
  Two proposals (onto a clear block / onto the table) that never propose the same move (L9-027); proposals create only
  the acceptable preference (L9-014). One internal application rule that matches arguments by handle (L14-014).
- No external environment: ^environment none (L7-011), so every operator is applied internally.
- Search: forward search with the library's default look-ahead (iterative deepening on operator steps, starting at the
  number of unachieved desireds = 3). No flag overrides: MEA left off (L15-025: blocks-world desireds interact - this
  instance is the Sussman anomaly - so working on one undoes another); uniform costs, so no cost-metric/optimize
  (L14-048..L14-050). No desired ordering supplied: the task description gives none, and without ^super-desired
  (forward search) desired preferences would not apply anyway (L15-024, L9-003).
- Problem space: top state gets ^problem-space.name blocks-world in initialize-blocks-world; the look-ahead state gets the
  same name from an elaboration (L15-017). All task rules test ^problem-space.name (L6-003, L3-005).
- Result: a detect rule on the real top state prints TASK-RESULT: success (or failure) and halts.

## Files
- blocks-world.soar (load file), initialize-blocks-world.soar, move-block.soar,
  elaborations/problem-space.soar, elaborations/desireds.soar, elaborations/task-result.soar. 11 rules.

## Test runs
Run 1 (seeds 1-3, cap 20000): all success, 0 load errors, 0 runtime errors.
- seed 1: success, 230 decisions; seed 2: success, 283 decisions; seed 3: success, 76 decisions.
- Top-level plan 3 x move-block (the only 3-move solution: C->table, B->C, A->B, i.e. optimal).

## Known problems
- No repeated-state detection (L14-040/L14-068); not needed at this size since iterative deepening bounds the search.
- Decision counts vary with seed because of the random order of evaluations among tied operators.

## Files read outside the output folder
- /home/claude/gen3/WRITER-INSTRUCTIONS.md
- /home/claude/gen3/tasks/blocks-world/task.md
- /home/claude/gen3/conventions/World-Conventions-Spec-v8.md (L0 start, L2/L3 file organization and naming, L6-L10, L14-L15)
- /home/claude/gen3/conventions/ (directory listing only; Soar-Conventions-Spec.md headings only)
- /home/claude/gen3/tools/run2.py
- Library: directory listing of /home/claude/lib244/soar-library; agent-world/_readme.soar, agent-world/_flags.soar,
  agent-world/goal-completed.soar (first part), selection-world/_flags.soar, selection-world/elaborations/top-state.soar;
  grep for TASK-RESULT/halt in the library.
