# Eight puzzle: conventions condition

## Approach
- Search: forward search with look-ahead. Uses the library default strategy: iterative deepening on task-operator
  steps, start depth 2, maximum 12, no cost metric.
  - L15-025 names the eight puzzle as a forward-search task, so mea-operator-selection is not set.
  - L14-048 says to change no flag without a reason. None applies (uniform costs, short plan), so no flag overrides.
  - RL is off because this is a single episode (L11-007).
- World (L7):
  - Objects: cells cell-R-C (static type/row/column/neighbor handles), tiles tile-N (static type/number), and tray.
  - Relations: ^on (tile, cell), copied by default; ^empty (one-argument, cell), a maintained relation (L11-003)
    declared with ^copy-relation.
  - ^environment none (L7-011).
- Operator: move-tile is a TAO (L9-004). argument1 is the tile, argument2 the empty cell; ^argument-count 2;
  precondition desired-count 0. Acceptable preference only (L9-014), one instantiation per tile.
  - The internal application finds objects by handle (L14-014).
  - In look-ahead (^real false), a move of the tile just moved is rejected (L3-048, ^last-moved-tile on the state).
- Goal (deviation forced by L8-004): 8 tile-on-cell relation desireds exceed the library's 6-desired limit.
  - The goal is one object desired, tray ^solved true (desired-count 1).
  - The goal arrangement (8 ^place tile/cell handle pairs) is stored on the top desireds as ^arrangement, so the goal
    is a WM structure (L3-024).
  - tray ^solved is derived. It reads the arrangement via ^external-top-state, so it works in look-ahead, and it is
    listed as dont-copy-object-attribute (L14-026).
  - The task supplies achieved/unachieved (L8-018); the library computes the counts and ^success.
  - This departs from L8-005/L8-009, and ^arrangement is not a desired form that look-ahead copies (L8-016).
- Result: a monitor rule prints TASK-RESULT: success and halts on real top-state ^success. Real moves print
  "MOVE: tile N to cell-R-C".

## Files
- eight-puzzle.soar: main file.
- initialize-eight-puzzle.soar
- move-tile.soar
- elaborations/problem-space.soar
- elaborations/desireds.soar
- elaborations/monitor.soar
- bfs8.py: offline BFS used to check the optimal plan length (5). Not part of the agent.

13 rules.

## Test runs
1. Seeds 1-3: success on all three; decisions 1213/911/1065; 5 moves each (optimal); 0 errors.
   - The trace showed handles like c23 printing as identifiers (C23), so I renamed them to cell-R-C and tile-N (L7-013/L7-015).
2. Seeds 1-3 after the rename: success on all three; decisions 1213/911/1065; 5 moves each; 0 errors, 0 warnings.
   - Seed-1 plan: tile 6 -> cell-2-3, 8 -> cell-2-2, 2 -> cell-2-1, 1 -> cell-1-1, 8 -> cell-1-2.

## Known problems
- The goal representation deviates from the one-fact-per-desired convention (above). The fifteen puzzle would use
  the same scheme.
- No failure detection if iterative deepening reaches its maximum depth without a plan. This cannot happen for this
  5-move instance.

## Files read outside the output folder
- /home/claude/gen3/WRITER-INSTRUCTIONS.md
- /home/claude/gen3/tasks/eight-puzzle/task.md
- /home/claude/gen3/conventions/World-Conventions-Spec-v8.md (L0 intro table, L2, L3 parts, L6-L11, L14-L16)
- /home/claude/gen3/conventions/Soar-Conventions-Spec.md (headings, L3S, L6P)
- /home/claude/gen3/tools/run2.py
- /home/claude/lib244/soar-library:
  - directory listing, VERSION.txt, soar-library.soar
  - agent-world/_readme.soar, _flags.soar, initialize-agent-world.soar
  - agent-world/elaborations/achieved-desireds.soar, internal-actions.soar
  - selection-world/Operator_Tie/evaluate-operator/elaborations.soar (lines 1-300)
  - selection-world/elaborations/top-state.soar (halt rules)
  - greps for last-operator, chunk, copy-relation
