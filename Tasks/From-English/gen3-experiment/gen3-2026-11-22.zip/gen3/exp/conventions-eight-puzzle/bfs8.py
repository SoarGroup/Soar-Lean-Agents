from collections import deque
s=(2,1,7,8,6,0,3,4,5); g=(1,8,7,2,0,6,3,4,5)
prev={s:None};q=deque([s])
while q:
    x=q.popleft()
    if x==g: break
    z=x.index(0);r,c=divmod(z,3)
    for dr,dc in((1,0),(-1,0),(0,1),(0,-1)):
        rr,cc=r+dr,c+dc
        if 0<=rr<3 and 0<=cc<3:
            y=list(x);y[z],y[rr*3+cc]=y[rr*3+cc],0;y=tuple(y)
            if y not in prev: prev[y]=x;q.append(y)
p=[];x=g
while x: p.append(x);x=prev[x]
print(len(p)-1)
for x in reversed(p): print(x)
