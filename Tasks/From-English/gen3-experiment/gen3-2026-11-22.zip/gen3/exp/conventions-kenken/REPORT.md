# kenken (condition: conventions)

(Saved by the main session from the writer's hand-back message; the writer's Write tool refused report files.)

## Result
`run2.py ... --seeds 1-3 --episodes 1 --cap 20000`, one run, 24 user rules, no load or runtime errors.

| seed | result | decisions | top-level ops |
|---|---|---|---|
| 1 | success | 281 | 33 |
| 2 | success | 285 | 33 |
| 3 | success | 279 | 33 |

Final grid: 3421 / 2314 / 4132 / 1243. A trace run (seed 1) showed 18 tie impasses settled by look-ahead.

## Approach
- **World (L7):** 16 cell objects (c11..c44) and one `grid` object, each with a handle, `^anchored true` and a `^static` part. Cells change `^value` (0 = empty) and a multi-valued `^cand` list; the grid changes `^next` and `^unassigned`. Each cell's `^static` holds type, row, column, order, cage label, operation, target and size.
- **Cages:** a shared static label, not a relation object, so look-ahead copies no relations.
- **Arithmetic facts:** digits 1-4 and x*y facts on the problem space, shared by look-ahead states (`/` returns a float that does not match an integer).
- **Goal (L8):** one desired, `grid ^unassigned 0`, `^desired-count 1`.
- **`assign` (task operator):** `^argument1` cell, `^argument2` digit, `^desireds` count 0; proposed with acceptable only for each candidate of the next empty cell. Applying sets the value, removes the digit from row and column peers, advances the grid.
- **`eliminate` (internal operator, `^task-operator false`, indifferent):** removes a candidate the cage cannot support; preferred to `assign` by the library (L15-001).
- **Cage support:** derived `^cage-ok` for single cells, 2- and 3-cell sums, differences, quotients and 2-cell products; listed as `^dont-copy-object-attribute` (L14-026).
- **Dead ends:** an empty cell with no candidates marks `^failure` (L14-059a).
- **Search:** ties between `assign` operators resolved by look-ahead (iterative deepening). Flag overrides: `iterative-step tie-impasse`, `max-evaluation-depth 16`. Otherwise defaults (L14-048): MEA off (L15-025), no cost metric, optimize false, no chunking, no RL.
- `^environment none` (L7-011).

## Judgement calls
- `tie-impasse` departs from L14-051's default for forward search; justified because propagation makes most steps forced.
- Cage label rather than relation object (reading of L7-016).
- Derived object attribute `^cage-ok` (L14-026 allows but does not recommend).

## Known limits
- Products of 3+ cells and sums of 4+ cells not implemented.
- 3-cell sum support does not check row/column distinctness (weaker pruning only).
- Success message names this instance's 16 cell handles.

## Files
kenken.soar, initialize-kenken.soar, assign.soar, eliminate.soar, elaborations/problem-space.soar, elaborations/cage.soar, elaborations/desireds.soar, elaborations/result.soar.

## Files read outside the output folder
- /home/claude/gen3/WRITER-INSTRUCTIONS.md and tasks/kenken/task.md
- World-Conventions-Spec-v8.md: levels header, start of L2–L3, L6–L16, search for "kenken"
- Soar-Conventions-Spec.md: headings and searches only
- tools/run2.py
- /home/claude/lib244/soar-library: directory listings, soar-library.soar, VERSION.txt, search for chunking settings; agent-world/_flags.soar, initialize-agent-world.soar, first 150 lines of Impasse__Operator_Tie/evaluate-operator/elaborations.soar, excerpts of elaborations/internal-actions.soar and search-control.soar; selection-world/_flags.soar, start of _readme.soar, elaborations/top-state.soar, parts of Operator_Tie/evaluate-operator/elaborations.soar, strategies/strategies_source.soar, strategies/iterative-deepening/_flags.soar
- No example agents read.
