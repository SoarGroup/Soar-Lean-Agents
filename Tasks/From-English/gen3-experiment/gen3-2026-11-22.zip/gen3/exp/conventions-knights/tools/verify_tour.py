# Runs the agent for one seed and checks the printed tour (legal knight moves, each of 36 squares once).
import re, sys, os, soar_sml as S
seed = int(sys.argv[1]); d = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
k = S.Kernel.CreateKernelInNewThread(0); a = k.CreateAgent('v'); out = []
a.RegisterForPrintEvent(S.smlEVENT_PRINT, lambda m, u, ag, msg: out.append(msg), None)
os.chdir(d); a.ExecuteCommandLine('source knights.soar'); a.ExecuteCommandLine(f'srand {seed}')
a.ExecuteCommandLine('trace 1'); a.RunSelf(20000)
txt = ''.join(out)
path = [(2, 3)] + [tuple(map(int, m)) for m in re.findall(r'Knight moves to column (\d+), row (\d+)', txt)]
ties = len(re.findall(r'==>S: S\d+ \(operator tie\)', txt))
legal = all(sorted((abs(a[0]-b[0]), abs(a[1]-b[1]))) == [1, 2] for a, b in zip(path, path[1:]))
print(dict(seed=seed, squares=len(path), distinct=len(set(path)), legal=legal, ties=ties,
           result=re.findall(r'TASK-RESULT: \w+', txt), path=' '.join(f'{c}{r}' for c, r in path)))
k.Shutdown()
