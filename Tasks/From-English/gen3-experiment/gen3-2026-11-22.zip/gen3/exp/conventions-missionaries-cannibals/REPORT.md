# Missionaries and cannibals (condition: conventions)

(Saved by the main session from the writer's hand-back message; the writer's Write tool refused report files.)

## Result
| Seed | Result | Decisions | Top-level moves |
|---|---|---|---|
| 1 | success | 4999 | 11 |
| 2 | success | 6476 | 11 |
| 3 | success | 5121 | 11 |

Final run: `run2.py ... --seeds 1-3 --episodes 1 --cap 20000`; 0 load errors, 0 runtime errors, 0 warnings; 23 user rules. Every seed found an optimal 11-crossing plan.

## Approach
- **World:** two bank objects `left` and `right`, each `^anchored true`, `^object-handle`, constants `^missionaries`, `^cannibals`, `^boat`; type under `^static.type bank`. No relations.
- **Goal:** right `^missionaries 3` and right `^cannibals 3`, `^desired-count 2`; positive-test achieved/unachieved elaborations.
- **Initialization:** after `initialize-agent-world`; `^environment none`, `^problem-space.name missionaries-cannibals`, objects, desireds, empty `^last-operator`.
- **Operator:** one task-action operator `move-boat` (`^argument1` from bank, `^argument2` to bank, constant load parameters, `^desireds` count 0); one proposal rule per legal load (5); acceptable only; moves into failure states are still proposed. Internal application finds banks by handle.
- **Failure:** a bank with missionaries outnumbered marks `^failure`; at top state prints TASK-RESULT: failure and halts.
- **Search:** forward search, MEA off (L15-025); library default iterative deepening, no flag overrides; max depth 12 > 11. No RL; chunking off.
- **Look-ahead problem space (L15-017):** an elaboration gives each evaluate-operator state of this task the problem-space name.
- **Repeated states:** library v2.45 has no `^ancestor-world` rule (though L14-068 says it does), so the task creates it; a look-ahead world whose left bank equals an ancestor world's is marked `^failure` (the world the copy was made from is excluded).
- **Undo control:** `^last-operator` records the last load; the reverse move is rejected in look-ahead and made worst in the real state.
- **Result reporting:** monitor rules print TASK-RESULT success/failure and halt; a third prints each real move.

## Test runs
1. Seeds 1-3 hit the 20000 cap without a top-level move. Run to completion, seed 1 solved optimally in 72,572 decisions. `chunk only`/`chunk always` gave over-general chunks and looping. Decision: add undo control.
2. Success on all seeds (4999, 6476, 5121). Final version.

## Known problems
- The duplicate test excludes the world a look-ahead world was copied from; caught one level lower.
- `-^last-operator` in `...*last-operator*first` is a negation over substate structure (would be dropped from chunks, L3-035).
- Chunking not used (over-general chunks; cause not investigated).
- The library's own "achieved - success" interrupt fires in the same phase as the TASK-RESULT line.

## Files
missionaries-cannibals.soar, initialize-missionaries-cannibals.soar, move-boat.soar, elaborations/problem-space.soar, elaborations/desireds.soar, elaborations/failure.soar, elaborations/duplicate-state.soar, elaborations/monitor.soar.

## Files read outside the output folder
- /home/claude/gen3/WRITER-INSTRUCTIONS.md
- /home/claude/gen3/tasks/missionaries-cannibals/task.md
- /home/claude/gen3/conventions/World-Conventions-Spec-v8.md (L2, L3, L4 parts, L6-L16, L21; grep)
- /home/claude/gen3/conventions/Soar-Conventions-Spec.md (header, L5-011/L5-012 region, L6P section; grep)
- /home/claude/gen3/tools/run2.py
- Library (/home/claude/lib244/soar-library): soar-library.soar, VERSION.txt, directory listing; agent-world/_flags.soar, _readme.soar, goal-completed.soar (start), initialize-agent-world.soar (proposal); agent-world/elaborations/internal-actions.soar and achieved-desireds.soar; agent-world/Impasse__Operator_Tie/evaluate-operator/elaborations.soar (start); selection-world/_flags.soar, elaborations/top-state.soar, Operator_Tie/evaluate-operator/elaborations.soar (first 200 lines); soar-base/settings/agent-world-settings.soar; greps for halt, problem-space, chunk settings and ancestor-world
