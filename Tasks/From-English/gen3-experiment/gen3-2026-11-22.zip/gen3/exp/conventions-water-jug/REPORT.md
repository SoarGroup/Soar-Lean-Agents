# water-jug (condition: conventions)

(Saved by the main session from the writer's hand-back message; the writer's Write tool refused report files.)

## Approach
- **World (L7):** the two jugs are world objects jug3 and jug5, with `^anchored true` and `^contents`, which operators change. Volume and class are kept under `^static` (`^class jug ^volume 3|5`) because no operator changes them (L7-017, L7-021).
  - Free space is derived: `^free` = volume - contents, an i-supported rule with no negation (L3-031).
  - `free` is listed as `^dont-copy-object-attribute` on the problem space, so look-ahead derives it again from the copied contents (L14-026).
- **Goal (L8):** one desired, `(^object-handle jug3 ^contents 1)`, with `^desired-count 1`. Task rules add `^achieved` and `^unachieved` using positive tests only (L8-018 to L8-020); the library adds `^success`.
- **Operators (L9, L10):** fill, empty and pour are task-action operators.
  - Each has `^task-operator true`, `^action-handle`, `^argument1` (and `^argument2` for pour), `^argument-count`, and `^desireds` with `^desired-count 0`.
  - Each is proposed only when it would change something (L3-034), with an acceptable preference only (L9-014).
  - Internal application rules test `^internal-actions true` and `^pre-conditions-satisfied true`. Pour has two mutually exclusive cases (L3-050).
  - Application rules find jugs by handle, because in look-ahead the operator's arguments still point to real-world jugs (L14-014).
  - initialize-water-jug sets `^environment none` (L7-011).
- **Search method:** forward search; mea-operator-selection is not set.
  - The desired "contents 1" does not identify any operator, since none has it as an effect (L15-025).
  - Look-ahead uses the library defaults (L14-048): iterative deepening on task-operator steps, no cost metric, optimize false.
  - With uniform step costs, the shortest plan is the cheapest (L14-049, L14-050). A 4-step plan is well under the default maximum depth of 12 (L14-053). No flag overrides.
- **Search control:**
  - There is no desired ordering, because there is only one desired (L15-024).
  - The last operator is recorded as its name plus jug handles (L3-021).
  - An operator that undoes it (fill after empty of the same jug, empty after fill, pour back) gets worst in the real state (L3-047) and reject in look-ahead (L3-048).
  - The undo mark is on the state, not the operator, so the look-ahead operator copy (L14-044) does not inherit it.
- **Result reporting:** on the real top state (`^superstate nil ^real true`), `^success <desireds>` prints `TASK-RESULT: success` and halts; a failure mark prints `TASK-RESULT: failure` and halts. Monitor rules print each real action and every change in jug contents (L3-056).
- **Learning:** chunking and RL are off, since this is a single-problem run (L11-007).

## Files
- water-jug.soar: main file; loads the library (pushd, source, popd), then the task files.
- initialize-water-jug.soar: sets the task name, `^environment none`, the jugs and the desireds.
- fill.soar, empty.soar, pour.soar: proposal and internal application rules.
- elaborations/_all.soar: sources the files below.
- elaborations/problem-space.soar: the problem space and the dont-copy entry for `free`.
- elaborations/jug.soar: `^free`.
- elaborations/desireds.soar: achieved and unachieved.
- elaborations/last-operator.soar: the last-operator record and the undo worst/reject preferences.
- elaborations/monitor.soar: trace output.
- elaborations/task-result.soar: TASK-RESULT and halt.

The agent has 25 user rules.

## Test runs
Command: `run2.py --seeds 1-3 --episodes 1 --cap 20000`

| Run | Version | Seed 1 | Seed 2 | Seed 3 |
|---|---|---|---|---|
| 1 | without last-operator rules (18 rules) | success, 1079 decisions | success, 793 | success, 849 |
| 2 | with last-operator rules (25 rules) | success, 528 decisions | success, 434 | success, 420 |

- Neither run had load errors, runtime errors or warnings.
- Every seed found the shortest plan: fill(jug3), pour(jug3->jug5), fill(jug3), pour(jug3->jug5).

## Known problems
- Pour-back is treated as an undo. When both jugs hold water it is not always an exact inverse, so rejecting it in look-ahead could prune a useful branch in other instances. It does not do so here.
- There is no repeated-state detection (L14-040, L14-068). Library v2.45 has no `^ancestor-world` rules, so the depth limit of iterative deepening bounds the search instead.
- The `$` handle tests (L11-005) are in the rules, but chunking is off, so they have no effect in these runs.

## Files read outside the output folder
- /home/claude/gen3/WRITER-INSTRUCTIONS.md
- /home/claude/gen3/tasks/water-jug/task.md
- /home/claude/gen3/conventions/World-Conventions-Spec-v8.md: sections L3 and L6 to L16
- /home/claude/gen3/conventions/Soar-Conventions-Spec.md: headings only
- /home/claude/gen3/tools/run2.py
- /home/claude/lib244/soar-library/: soar-library.soar, VERSION.txt, CHANGES.md (start, v2.45 entry), agent-world/_flags.soar, agent-world/_readme.soar, agent-world/initialize-agent-world.soar, agent-world/goal-completed.soar (first part), agent-world/Impasse__Operator_Tie/evaluate-operator/elaborations.soar (look-ahead-operator copy rules), selection-world/elaborations/top-state.soar, selection-world/_flags.soar, soar-base/settings/*.soar; directory listings and greps (halt, ancestor, chunk settings)
