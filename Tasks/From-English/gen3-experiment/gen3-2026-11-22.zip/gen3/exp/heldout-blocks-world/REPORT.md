# Blocks world (condition: heldout)

(Saved by the main session from the writer's hand-back message; the writer's Write tool refused report files.)

## Approach
- World (L7): blocks A, B, C (`^type block`) and `table` (`^type table`), all anchored with handles. Relations: `^on` (argument1 block, argument2 block or table) and the one-argument relation `^clear`, kept up to date by the move application (L11-003); declared `^copy-relation clear` so look-ahead copies it.
- Goal (L8): three relation desireds on(A,B), on(B,C), on(C,table), `^desired-count 3`; task supplies achieved/unachieved elaborations (L8-018).
- `^environment none` (L7-011); every operator applied internally.
- Search method: means-ends (`mea-operator-selection true`, L15-025); `^iterative-step tie-impasse` (L14-051); other look-ahead flags default (L14-048).
  - `move-block X Y` proposed for each unachieved on(X,Y); preconditions clear(X), and clear(Y) when Y is a block; operator subgoaling (L17-002); a third proposal achieves clear(X) by moving the block on X to the table.
  - Ordering (L15-024, blocks world bottom-up): i-supported `^preferred-desired` on on(X,table), and on on(X,Y) once Y's own desired is achieved and preferred; library gives best (L15-002).
- Result: top-state rule writes `TASK-RESULT: success` and halts on `^success`; failure rule for failure, prohibit-failure or exhaustion-failure.
- Chunking default (never), RL off.

## Files
blocks-world.soar (main), initialize-blocks-world.soar, elaborations.soar, move-block.soar (3 MEA proposals, 3 internal applications, monitor rule), search-control.soar, task-result.soar. 21 user rules.

## Test runs (run2.py, --seeds 1-3 --episodes 1 --cap 20000)
1. Success on seeds 1-3, 5 decisions each; plan C to table, B onto C, A onto B (optimal, no tie, no look-ahead).
2. About 5 diagnostic runs with search-control.soar removed, to exercise look-ahead with MEA subgoaling: Soar crashed with a segmentation fault at about decision 60 on every seed. Excising rules isolated the crash to library rule `selection-world*apply*world*local-version`, which fires when an MEA subgoal operator is applied in a nested operator no-change substate to a look-ahead world whose `^versioned-operator` belongs to a different, now-removed state. Library not modified; temporary files deleted.
3. Final run: success on seeds 1-3, 5 decisions each, 0 errors.

## Known problems
- Without the ordering knowledge, look-ahead combined with MEA subgoaling crashes the kernel in library v2.45. An instance with ties (e.g. two independent towers) might hit it.
- The bottom-up preference assumes every supporting block has its own on-desired.

## Files read outside the output folder
- /home/claude/gen3/WRITER-INSTRUCTIONS.md
- /home/claude/gen3/tasks/blocks-world/task.md
- /home/claude/gen3/conventions/World-Conventions-Spec-v8.md (start of L0; L6–L10; L11; L14-048 to L14-056; L15; L17; grep for `$`) and Soar-Conventions-Spec.md (headings only)
- /home/claude/gen3/tools/run2.py
- /home/claude/gen3/examples/heldout-blocks-world: directory listings; families/towers-of-hanoi/towers-of-hanoi and towers-of-hanoi-mea (all files); families/eight-puzzle/eight-puzzle (all files); families/water-jug/water-jug-look-ahead (all files); english-world/mc-world (all .soar files, english-input.txt); grep results and success rules from english-world/artists-world and zebra-world; grep of rosie/block-puzzles rules (iterative-step lines only)
- /home/claude/lib244/soar-library: directory listing, VERSION.txt, agent-world/_flags.soar (grep), selection-world/elaborations/top-state.soar, agent-world/elaborations/search-control.soar (start), selection-world/Operator_Tie/evaluate-operator/elaborations.soar (copy-relation rules), selection-world/strategies/iterative-deepening/.../Impasse__State_No-Change/ground-state.soar (lines 180-250); greps for TASK-RESULT, halt, copy-relation, preferred-desired and local-version
