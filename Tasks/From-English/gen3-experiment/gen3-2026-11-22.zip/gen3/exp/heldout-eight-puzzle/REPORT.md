# eight-puzzle (CONDITION=heldout)

## Approach
- **World (L7):** 9 cell objects `c11..c33` (static `^row`/`^col`, maintained `^empty true/false`),
  8 tile objects `t1..t8` (static `^number`, `^goal-row`, `^goal-col`), and a `tray` object with
  `^in-place` (tiles on their goal cell, maintained) and `^last-tile` (tile slid last).
  A tile's position is the relation `^at` (tile, cell); neighbouring cells are joined by `^adjacent`
  (both directions). Both are declared with `^copy-relation` on the problem space (L14-007).
- **Goal (L8):** one object-property desired, `tray ^in-place 8`. Eight position desireds are more than the
  library's limit of 6 (L8-004), so the goal is held in a counter that slide-tile updates. The KenKen example
  (`puzzle ^marks 16`) does the same.
- **Operator:** `slide-tile <tile> <cell>` is a task-action operator (L9-004/L9-011, `^desired-count 0`).
  It has one proposal (a tile on a cell adjacent to the empty cell) and internal application rules. The main
  rule moves `^at`, swaps `^empty` and records `^last-tile`; two more rules raise or lower `^in-place` when the
  tile enters or leaves its goal cell. `^environment none` (L7-011).
- **Search control:** a reject preference stops the tile slid last from being slid again at once, because that
  would only undo the previous move.
- **Search method/flags:** forward search, so `mea-operator-selection` is left unset/false. L15-025 names the
  eight puzzle as the case for this. No flag overrides are used: the library default is iterative deepening on
  task-operator steps, starting at depth 2 and stopping at 12, with no cost metric. It returns a plan with the
  fewest steps (L14-048, L16-033). The optimal plan here is 5 moves, well inside the bound. There is no
  repeated-state detection beyond the undo reject, because iterative deepening bounds the search. Chunking is
  left at the Soar default, which is off.
- **Result reporting:** on the real top state, `^success` writes `TASK-RESULT: success` and halts.

## Files
- `eight-puzzle.soar`: loads the library, then the rule files
- `initialize-eight-puzzle.soar`: 2 rules
- `elaborations.soar`: 4 rules (problem space, achieved/unachieved, success report)
- `slide-tile.soar`: 6 rules (proposal, reject-undo, 3 application rules, real-move monitor)
- `bfs-check.py`: my own breadth-first check of the optimal length (5) and path. It is not part of the agent.

Total: 12 user rules.

## Test runs
Run 1: `run2.py ... --seeds 1-3 --episodes 1 --cap 20000`

| Seed | Result | Decisions | Real moves |
|---|---|---|---|
| 1 | success | 1141 | 5 |
| 2 | success | 1045 | 5 |
| 3 | success | 783 | 5 |

There were no load or runtime errors. On every seed the plan was 6, 8, 2, 1, 8 (tile numbers), which is the
optimal path that BFS finds. I checked this with a separate trace run that printed the real moves.

## Known problems / notes
- The goal depends on a maintained counter rather than one desired per tile. This is correct only if the
  `in-place`/`out-of-place` application rules stay consistent with `^at`.
- The `^adjacent` relations (24) are copied into every look-ahead world. This costs some copying but is small here.
- The task text mentions the fifteen puzzle. Only the 3 x 3 instance is implemented and tested. A 4 x 4 version
  needs more cells/tiles in the initialization. Its plans can be longer than the default `max-evaluation-depth`
  of 12, which would then need raising (L14-053).

## Files read outside the output folder
- /home/claude/gen3/WRITER-INSTRUCTIONS.md
- /home/claude/gen3/tasks/eight-puzzle/task.md
- /home/claude/gen3/conventions/World-Conventions-Spec-v8.md: level table, L3 file organisation and naming
  (part), L6 to L16 in full; headings list. Soar-Conventions-Spec.md: line count only, not read.
- /home/claude/gen3/tools/run2.py (first 80 lines)
- Library: VERSION.txt, soar-library.soar (head), selection-world/elaborations/top-state.soar (halt rules),
  selection-world/Operator_Tie/evaluate-operator/elaborations.soar (relation copy rules). Also greps for
  desired-count, chunk, TASK-RESULT and tried-tied-operator.
- Examples (/home/claude/gen3/examples/heldout-eight-puzzle): directory listings; families/knights/knights-6 (all
  files, output truncated); families/blocks-world/blocks-world-look-ahead (all files);
  families/water-jug/water-jug-look-ahead (fill, initialize, elaborations, state-evaluation, loader, _firstload);
  families/kenken/kenken-4-1 (end of initialize, elaborations head); excerpts of
  english-world/zebra-world/zebra-rules.soar and english-world/artists-world/artists-rules.soar; artists README
  (head); a grep for TASK-RESULT and desired-count over the example folder.
