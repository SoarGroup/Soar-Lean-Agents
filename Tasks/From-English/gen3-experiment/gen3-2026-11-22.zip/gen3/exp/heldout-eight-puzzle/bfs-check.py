from collections import deque
s=(2,1,7,8,6,0,3,4,5); g=(1,8,7,2,0,6,3,4,5)
def nb(st):
    z=st.index(0); r,c=divmod(z,3)
    for dr,dc in ((-1,0),(1,0),(0,-1),(0,1)):
        rr,cc=r+dr,c+dc
        if 0<=rr<3 and 0<=cc<3:
            l=list(st); n=rr*3+cc; l[z],l[n]=l[n],l[z]; yield tuple(l)
d={s:0};p={s:None};q=deque([s])
while q:
    x=q.popleft()
    if x==g: break
    for y in nb(x):
        if y not in d: d[y]=d[x]+1;p[y]=x;q.append(y)
print(d[g])
x=g;path=[]
while x: path.append(x);x=p[x]
for st in reversed(path): print(st)
