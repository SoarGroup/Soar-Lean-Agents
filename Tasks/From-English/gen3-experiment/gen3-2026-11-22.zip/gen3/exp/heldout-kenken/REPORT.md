# KenKen 4 x 4 agent (CONDITION=heldout, FAMILY=kenken)

## Approach
Modelled on the zebra-world example (a constraint puzzle in the same conventions): candidate
elimination over a world model, with branching plus look-ahead as fallback.

- World (L7): `grid` (^digit 1-4; desired `grid ^solved true`), 16 `cell` objects
  (^row ^col ^rank ^cage <cage handle> ^cage-index, ^candidate for every digit still possible), 8
  `cage` objects (^op sum|difference|product|quotient|value ^target ^size ^text). Every attribute
  value is a constant (L7-015). `^environment none` (L7-011), so all operators are applied internally.
- Derived facts (state, i-supported, re-derived in look-ahead): `^tuple` (every digit assignment
  of each 2- and 3-cell cage, with sum/diff/product/quotient tests computed by RHS functions),
  `^line-pair` (cage cells sharing a row/column, which must differ), `^tuple ^ok true`,
  `^open-rank`, `grid ^solved true`, `^failure <desireds>` (empty cell, or a digit with no place
  in a row/column).
- Task operator `eliminate` (TAO form: ^task-operator true, ^action-handle, ^argument1 cell
  handle, ^argument2 digit, ^argument-count 2, ^desireds with ^desired-count 0, ^super-desired),
  proposed by MEA proposals (test ^unachieved desired) for: row/column single, row/column hidden
  single, single-cell cage, and cage support (no allowed cage assignment fits the other cells'
  remaining candidates; generalized arc consistency for sizes 2 and 3). Each reason is printed.
- Task operator `assign`: when no elimination is proposed and the grid is not solved, one assign per
  candidate of the lowest-rank open cell; they tie and selection-world look-ahead (iterative
  deepening) decides.
- Flags (through ^flag-override, L6-008): `mea-operator-selection true`, `iterative-step tie-impasse`
  (as in the zebra example). Other flags left at library defaults (cost-metric none, optimize false).
- Result: when `grid ^solved true` at the top state, an elaboration prints the grid and
  `TASK-RESULT: success` and halts; `^failure` at the top state prints `TASK-RESULT: failure`.
  This is an elaboration, not an operator, because the library's "achieved all desireds"
  interrupt fires in the same decision and the harness stops there.

Deviations / choices to note:
- `kenken*compare*eliminate*indifferent` gives every eliminate a unary indifferent preference.
  L9-014 leaves selection to the library, but eliminations are order-independent (any order
  reaches the same fixpoint) and two reasons can propose the same elimination (L9-027 allows
  indifference for such duplicates); without it, eliminations would tie and start look-ahead.
- `grid ^solved` is computed only from world structure plus the derived tuples under a double
  negation, so it is never true transiently (a first version that tested "no eliminate proposed"
  and "-^open-rank" was transiently true and caused a false halt plus a match explosion).
- Cells' static attributes (row, col, cage) are kept flat rather than under ^static (L7-017 is
  optional; the 4 x 4 copy cost is small).

## Files
- kenken.soar: loads the library (pushd/source/popd) and the rule files.
- initialize-kenken.soar: initialize-kenken, problem space, flags, desired achievement rules.
- elaborations.soar: line pairs, tuples and their checks, open-rank, solved, failure.
- eliminate.soar: the 9 eliminate proposals, indifferent preference, application, trace report.
- assign.soar: assign proposal, application, trace report.
- report.soar: row texts, success / failure report and halt.
39 user rules.

## Test runs (run2.py, --seeds 1-3 --episodes 1 --cap 20000)
1. First run: killed (out of memory). Cause: the success-report rule joined 16 cells with
   4 candidates each (up to 4^16 partial matches), and `grid ^solved` was transiently true.
   Debugged with a small step script (deleted afterwards).
2. After rewriting `solved` (stable) and the report (one elaboration per row): seed 1 success,
   50 decisions; seed 2 success, 50; seed 3 success, 50. No load or runtime errors. Solved by
   deduction alone (48 eliminations), no branching needed.
   Solution: 3 4 2 1 / 2 3 1 4 / 4 1 3 2 / 1 2 4 3 (matches a hand solution; unique).

Extra check of the look-ahead path (not a harness run): with the two hidden-single proposals
excised, the agent branched once at (1,1), look-ahead chose 3, and it solved on seeds 1-3 in
71, 77 and 58 decisions.

## Known problems
- Cage-support elimination is written for cage sizes 1, 2 and 3 only (enough for this instance);
  larger cages would need more tuple/support rules. Report rule assumes a 4-column grid.
- The ^solved attribute is an i-supported attribute on a world object (as in the zebra example);
  L14-026 does not recommend derived object attributes.

## Files read outside the output folder
- /home/claude/gen3/WRITER-INSTRUCTIONS.md
- /home/claude/gen3/tasks/kenken/task.md
- /home/claude/gen3/conventions/World-Conventions-Spec-v8.md (parts: start, L6, L7, L9, L10, L14, L15 headlines, keyword greps)
- /home/claude/gen3/conventions/Soar-Conventions-Spec.md (keyword grep only)
- /home/claude/gen3/tools/run2.py
- /home/claude/gen3/examples/heldout-kenken/ (directory listing); english-world/zebra-world/zebra.soar,
  english-input.txt, zebra-rules.soar, run.py
- /home/claude/lib244/soar-library: VERSION.txt, CHANGES.md (head), directory listing, greps for
  attribute names and flag defaults, agent-world/initialize-agent-world.soar (head),
  selection-world/elaborations/top-state.soar, selection-world/Operator_Tie/evaluate-operator/elaborations.soar (copy rules)
- Note: during debugging I once copied kenken.soar to /tmp/k.bak and back (my own file only;
  nothing else under /tmp was read).
