# missionaries-cannibals (CONDITION=heldout)

## Approach
- Representation (World conventions L7): no external environment (`^environment none`, L7-011; every operator is
  applied internally, as in water-jug-look-ahead). Two bank objects (`left-bank`, `right-bank`) each with
  `^missionaries`, `^cannibals` (counts) and `^boat` 1/0; a `history` object for search control.
- Desireds (L8): two object-property desireds on `right-bank`: `^missionaries 3`, `^cannibals 3`, with the task's own
  achieved/unachieved elaborations (as in the examples).
- One task operator, `cross` (`^task-operator true`, `^argument1` from-bank, `^argument2` to-bank, `^argument-count 2`,
  plus `^missionaries`/`^cannibals` = the boat load, `^desireds` with `^desired-count 0`). The five legal loads
  (1M, 2M, 1C, 2C, 1M1C — one or two people, never empty) are listed on the problem space, so one proposal covers them.
  Application is split into boat/missionaries/cannibals rules so a zero count is never removed and re-added.
- Failure (task: missionaries are eaten): a bank with missionaries > 0 and cannibals > missionaries gives
  `^failure <desireds>` (L5-008, L14-059 names this exact case). At the top this ends the run with TASK-RESULT: failure.
- Search: forward search with the library's look-ahead (selection-world iterative deepening, default settings,
  L14-048). `^mea-operator-selection` not set (L15-025: one operator kind, effects do not index desireds).
  Flag override: `^init-evaluation-depth one` (L14-052: one crossing can achieve both desireds). max-evaluation-depth
  left at 12 (L14-053: shortest plan is 11 crossings). cost-metric none (uniform costs, L14-049).
- Search control (as in the jealous-husbands example): the situation label is the left bank's (M,C,boat); each cross
  carries the label of its result; applying cross records both labels on the history object (copied into look-ahead
  worlds); in look-ahead a cross to a visited situation is rejected; on the real state it is only made worst.
- Result reporting: `*detect*task-result*success/failure` rules with the same conditions as the library's
  top-goal halt rules write `TASK-RESULT: ...` and `(halt)`. A monitor rule prints each real crossing.

## Files
- missionaries-cannibals.soar (main; loads the library then the files below)
- initialize-missionaries-cannibals.soar, elaborations.soar, cross.soar, search-control.soar, monitor.soar
- 19 user rules.

## Test runs (run2.py, seeds 1-3, 1 episode, cap 20000)
1. First version used water-jug-look-ahead's approach (repeated ancestor state -> `^partial-failure`). Seeds 1, 3: no
   result at cap (agent oscillated: 4 crossings in 20000 decisions); seed 2: success after 29 crossings, 13359
   decisions. Cause (traced): with iterative-step operator, when a nested tie is resolved at the depth limit the
   evaluation state continues applying operators in place; reaching a repeated situation there marked the whole
   top-level item partial-failure, so good moves were rejected (e.g. 2C back to the start chosen over 1C back).
2. Replaced with path-history search control (reject visited situations in look-ahead, worst on real moves).
   Seed 1: success, 5085 decisions, 11 crossings. Seed 2: success, 3915 decisions, 11 crossings.
   Seed 3: success, 4957 decisions, 11 crossings. No load or runtime errors. Plan (seed 1): 1M1C>, 1M<, 2C>, 1C<,
   2M>, 1M1C<, 2M>, 1C<, 2C>, 1C<, 2C> (valid, optimal length).

## Known problems
- The plan is recomputed by a fresh iterative-deepening search at each real step (no chunking), hence ~4-5k decisions.
- max-evaluation-depth 12 leaves only one step of margin over the 11-step plan from the initial state.
- `actions` is 0 in the harness output because the task has no external environment (nothing on the output-link).

## Files read outside the output folder
- /home/claude/gen3/WRITER-INSTRUCTIONS.md
- /home/claude/gen3/tasks/missionaries-cannibals/task.md
- /home/claude/gen3/tools/run2.py (first ~80 lines)
- /home/claude/gen3/conventions/World-Conventions-Spec-v8.md (sections: headings, L2/L3 file organization and
  monitoring, L6 naming/flags, L14 flags and look-ahead settings, L15 search control, L16 iterative deepening, and
  grep results for TASK-RESULT/halt, mea-operator-selection, partial-failure, environment, monitor)
- /home/claude/gen3/conventions/Soar-Conventions-Spec.md: only its line count (not read)
- Example folder /home/claude/gen3/examples/heldout-missionaries-cannibals: directory listing;
  rosie/river-crossing-puzzles/jealous-husbands/{english-input.txt, jealous-husbands.soar, jealous-husbands-rules.soar};
  families/water-jug/water-jug-look-ahead/* (all files)
- Library /home/claude/lib244/soar-library: soar-library.soar, agent-world/_flags.soar, agent-world/goal-completed.soar
  (first 60 lines), agent-world/external-operator-application.soar (first 80 lines),
  selection-world/elaborations/top-state.soar, selection-world/Operator_Tie/evaluate-operator/elaborations.soar
  (lines 495-545), and greps for TASK-RESULT, halt, failed, internal-actions, tried-tied-operator, partial-failure.
- Debug scripts written in the output folder (scratch/, deleted afterwards) used soar_sml to trace the agent.
