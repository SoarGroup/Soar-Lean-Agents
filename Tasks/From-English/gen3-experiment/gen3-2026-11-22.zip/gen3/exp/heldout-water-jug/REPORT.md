# water-jug (condition: heldout)

(Saved by the main session from the writer's hand-back message; the writer's Write tool refused report files.)

## Approach
- **World.** Two anchored objects, `jug3` and `jug5`, each with `^contents` (changed by operators) and `^static` holding `^type jug` and `^volume` (L7-017, L7-021). No relations. `^environment none` (L7-011, L10-009).
- **Goal.** One object desired: `jug3 ^contents 1` (`^desired-count 1`); task supplies achieved/unachieved (L8-018, L8-020).
- **Operators.** fill, empty, pour — task-action operators with proposal and internal application (L9-004, L9-011, L9-012, L10-007), `^desireds` count 0. Pour amount `min(from, room left in to)` via RHS functions.
- **Search method.** Forward search with library look-ahead; MEA off (L15-025); iterative deepening resolves ties.
- **Flags.** Library defaults (L14-048..L14-053).
- **Repeated states.** A look-ahead state whose jug contents equal those of an ancestor task world is marked `^failure` (L14-059a, L14-068), using `^ancestor-world` rules modelled on mac-look-ahead.
- **Chunking.** `chunk always`, `chunk add-osk on` (L5-021), as in the library's look-ahead example families.
- **Result.** Top-state elaboration writes `TASK-RESULT: success` and halts on `^success`; `TASK-RESULT: failure` on `^failure`.
- **Handles.** Tested with `$` in application and duplicate rules (L11-005).

Departures from the examples: the examples set `mea-operator-selection true` even for forward search; this agent leaves it off per L15-025. Capacity and type under `^static`.

## Files
water-jug.soar (main), _firstload.soar (chunking settings), initialize-water-jug.soar (2 rules), elaborations.soar (5), fill.soar, empty.soar, pour.soar (2 each), state-evaluation.soar (1), report.soar (2). Total 16 task rules.

## Test runs
Run 1 (only run): `run2.py ... --seeds 1-3 --episodes 1 --cap 20000`.

| Seed | Result | Decisions | Chunks | Real plan |
|---|---|---|---|---|
| 1 | success | 619 | 74 | fill jug3, pour jug3→jug5, fill jug3, pour jug3→jug5 |
| 2 | success | 615 | 78 | same |
| 3 | success | 373 | 59 | same |

No load errors, runtime errors or warnings. A direct run of seed 1 (check script /tmp/wjcheck/t.py) confirmed TASK-RESULT, the halt, and final jug3 = 1, jug5 = 5.

## Known problems
- None observed. The failure rule in report.soar is never exercised.

## Files read outside the output folder
- /home/claude/gen3/WRITER-INSTRUCTIONS.md
- /home/claude/gen3/tasks/water-jug/task.md
- /home/claude/gen3/conventions/World-Conventions-Spec-v8.md: parts (L0, L6–L11, L14–L16, greps)
- /home/claude/gen3/conventions/Soar-Conventions-Spec.md: beginning only
- /home/claude/gen3/tools/run2.py
- /home/claude/gen3/examples/heldout-water-jug/: directory listing; families/missionaries-cannibals/mac and mac-look-ahead (all .soar); families/eight-puzzle/eight-puzzle (initialize, elaborations, state-evaluation, move-tile); `_firstload.soar` of the look-ahead, eight-puzzle, Hanoi and blocks-world variants (a broader grep also printed the arithmetic `_firstload.soar` files); english-world/artists-world: README.md, artists.soar, part of artists-rules.soar
- /home/claude/lib244/soar-library/: soar-library.soar, VERSION.txt, CHANGES.md (start of v2.45 entry), agent-world/_flags.soar, agent-world/_readme.soar, selection-world/_flags.soar, selection-world/strategies/iterative-deepening/_flags.soar, part of soar-base/simple.soar, agent-world/goal-completed.soar, selection-world/elaborations/top-state.soar, part of agent-world/elaborations/achieved-desireds.soar; greps for flags, mea-operator-selection, ancestor-world, tried-tied-operator, halt, interrupt
- Created and ran /tmp/wjcheck/t.py (own script).
