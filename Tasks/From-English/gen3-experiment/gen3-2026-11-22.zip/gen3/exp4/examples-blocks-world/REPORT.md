# REPORT: blocks-world (CONDITION=examples)

## Approach
The instance (A on table, B on table, C on A; goal A on B, B on C, C on table) is exactly the instance of the
reference example families/blocks-world/blocks-world-simple-3, so the agent follows that example's structure:
- Internal problem: ^environment none on the top state (L7-011); operators applied by internal application rules
  testing ^internal-actions true (L10-007, L10-009).
- World model: anchored objects (table, A, B, C) with ^clear, and ^on relation objects (^argument1/^argument2).
- Goal: three ^on relation desireds; achieved/unachieved elaborated by comparing handles with the world.
- Search method: MEA operator selection (flag-override mea-operator-selection true) with domain search control, no
  look-ahead: a block not in place goes to the table (best); a move onto the block's desired destination when that
  destination is in place is better than any other; otherwise task operators indifferent. "in-place" is derived and
  dont-copy. Solves the instance in the optimal 3 moves with no impasses.
- Result: task-result.soar writes "TASK-RESULT: success" and halts when the top-state desireds are all achieved
  (L3-053: halt since the run ends for good); a failure signal on the top-state desireds writes
  "TASK-RESULT: failure" and halts.
- chunk never (as in the example).

## Files
blocks-world.soar (main; loads library via pushd/source/popd), _firstload.soar, elaborations.soar,
initialize-blocks-world.soar, move-block.soar, search-control.soar, task-result.soar. 17 user rules.

## Test runs
Run 1 (run2.py --seeds 1-3 --episodes 1 --cap 20000): seeds 1, 2, 3 all success, 5 decisions each, halted,
0 load errors, 0 runtime errors. Plan: move C to table, B to C, A to B.
One additional manual trace run (soar_sml) to confirm the moves and the TASK-RESULT line.

## Known problems
None observed. The library's own "achieved - success" / "achieved all desireds" rules also fire (interrupt); the
agent's rule halts, so the run ends either way.

## Files read outside the output folder
- /home/claude/gen3/WRITER-INSTRUCTIONS.md
- /home/claude/gen3/tasks/blocks-world/task.md
- /home/claude/gen3/conventions/ (listed; grep of both spec files for TASK-RESULT/halt/internal-actions/environment)
- /home/claude/gen3/tools/run2.py (first 80 lines)
- /home/claude/lib244/soar-library (listed; grep for TASK-RESULT / "achieved all desireds";
  selection-world/elaborations/top-state.soar lines 1-60)
- /home/claude/gen3/examples/all (listed), families/blocks-world (listed); all files of blocks-world-simple; diff of
  blocks-world-simple vs blocks-world-simple-3 (simple-3 files copied as this agent's base)
- examples/all/english-world/artists-world/artists-rules.soar lines 300-329 and zebra-world/zebra-rules.soar around
  its TASK-RESULT rule
