# eight-puzzle (CONDITION=examples)

## Approach
- World representation (L7): anchored world objects for the board, 9 cells (c11..c33), 9 tiles (t0 = empty square,
  each with ^home = goal cell handle) and a memory object (^last-tile). Operator-changed relation ^at
  (argument1 tile, argument2 cell) and static relation ^adjacent (cell pairs); both are listed as ^copy-relation
  so the look-ahead world copy has them (L14-007). Derived ^at-home / ^solved are ^dont-copy-object-attribute.
- Goal: one object-property desired (board ^solved true), ^better higher (L14-008).
- Operator: move-tile <tile> <to> <from> (task operator, internal action, desired-count 0 preconditions).
- Search: forward search with the selection-world look-ahead. The flag ^mea-operator-selection is NOT set: L15-025
  says to leave it false for the eight puzzle (every move changes many features, effects cannot be tied to the
  desired). This is the one deliberate departure from the reference example (which sets it true); results are the same.
- Evaluation: look-ahead numeric-value +1 / -1 / 0 when the tried move puts a tile home / moves it off home / neither.
- Search control: reject moving the tile moved last (L3-048, inverse move).
- Result: monitor.soar prints "TASK-RESULT: success" and halts when the real top-state board is solved.
- _firstload.soar: chunk always, add-osk on (as in the reference example).

## Files
eight-puzzle.soar (main), _firstload.soar, elaborations.soar, initialize-eight-puzzle.soar, move-tile.soar,
state-evaluation.soar, monitor.soar. 14 user rules.

Structure and most rules are taken from the reference example
examples/all/families/eight-puzzle/eight-puzzle (same instance); changes: forward search (flag override, MEA-substate
problem-space rule and flag test removed), instance comments, and the new monitor.soar success/halt rule.

## Test runs (run2.py --seeds 1-3 --episodes 1 --cap 20000)
1. Example structure with MEA flag + monitor rule: seeds 1/2/3 success, 29/29/31 decisions, 5/5/9 moves, 0 errors.
2. Forward search (final): seeds 1/2/3 success, 29/29/31 decisions, 5/5/9 moves, 0 load/runtime errors, 0 warnings.

## Known problems
- Seed 3 finds a 9-move solution instead of the 5-move optimum (one-step look-ahead with a local evaluation is not
  optimal). No failure detection rule (the agent never runs out of moves; the cap would end a non-solving run).

## Files read outside the output folder
- /home/claude/gen3/WRITER-INSTRUCTIONS.md
- /home/claude/gen3/tasks/eight-puzzle/task.md
- /home/claude/gen3/tools/run2.py
- /home/claude/gen3/conventions/World-Conventions-Spec-v8.md and Soar-Conventions-Spec.md (grep plus sections:
  L14 4692-4900, L3-048/L3-102 area, L15-025, L3S-001)
- Library: selection-world/elaborations/top-state.soar, agent-world/elaborations/achieved-desired-operators.soar
  (lines 1-60), greps for TASK-RESULT / pre-conditions-satisfied / achieved messages, directory listing.
- Examples (/home/claude/gen3/examples/all): directory listing; families/eight-puzzle/eight-puzzle/* (all files);
  diff against eight-puzzle-expected-value; TASK-RESULT rules in english-world/artists-world/artists-rules.soar and
  english-world/zebra-world/zebra-rules.soar (grep context).
- Also listed /home/claude/gen3/out/examples/ (parent of my output folder, before creating it; it printed nothing).
