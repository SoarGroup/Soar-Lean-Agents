# knights (CONDITION=examples): open knight's tour, 6 x 6, from column 2, row 3

## Approach
- Followed the structure of the reference agent examples/all/families/knights/knights-6. That agent counts closed
  tours from the same square b23 until the search is exhausted. This agent stops at the first open tour.
- World representation: 36 square objects (handle b<column><row>, so b23 = column 2, row 3) and a tour object,
  plus 160 ^jump relations, built in initialize-knights. Soar reads `b23` as the constant |B23|; this is
  consistent throughout. Goal: one object-property desired (tour ^solved yes), checked by the
  achieved/unachieved elaborations copied from the example (L8-018).
- Search method: depth-first search in the task state with operators knight-move, backup, detect-goal,
  exhausted and finish-run. It uses the flag override mea-operator-selection true, as the example does, and
  internal actions only (no output-link commands). Chunking is off (`chunk never`, as in the example).
  Look-ahead/selection space is not used: a tour needs deep search with backtracking, which suits
  in-state DFS better.
- Search control: Warnsdorff ordering (move to the square with the lowest ^degree, meaning the fewest unused
  neighbours). Stopping operators come before backup, and backup before move. All other choices are
  indifferent (random ties).
- Pruning (for an open tour): backup at a dead end, or when an unused square has degree 0 while depth < 35
  (that square can never be entered later). The example's closed-tour rules (degree-1, return to start)
  were dropped. Degrees are initialised with the start square already counted as used.
- Result: detect-goal (depth 36) sets ^solved yes, writes the tour path and `TASK-RESULT: success`, then
  halts. If the first square has no untried moves left (exhausted), or after 1,000,000 moves, the agent writes
  `TASK-RESULT: failure` and halts.

## Files
knights.soar (main; loads the library with pushd/source/popd), _firstload.soar, elaborations.soar
(copied from the example), initialize-knights.soar (generated with a one-off Python snippet; not kept),
knight-move.soar, backup.soar, detect-goal.soar, search-control.soar. 24 user rules.

## Test runs (run2.py --seeds 1-3 --episodes 1 --cap 20000)
1. Seeds 1-3: success, 38 decisions each, halted, 0 load or runtime errors. Warnsdorff ordering found a
   tour with no backups. An independent check of the printed path confirmed 36 distinct squares and
   legal knight moves (seeds 1 and 2 found the same tour; seed 3 found a different one).
2. After changing the path's start literal to |B23| (consistent case): seeds 1-3 success, 38 decisions, 0 errors.
Extra checks (outside the harness, through soar_sml):
- With the Warnsdorff rule removed (excised), random search did not finish within 10 minutes and the run
  was stopped.
- Over 15,000 moves and backups, depth equalled the count of used squares and every ^degree matched a
  recomputation: backup and degree bookkeeping are correct.

## Known problems
- Without Warnsdorff ordering the search is impractically slow (blind DFS). With it, the instance needs no
  backups.
- The square of a printed path is shown as B<column><row> (Soar upper-cases these constants).

## Files read outside the output folder
- /home/claude/gen3/WRITER-INSTRUCTIONS.md
- /home/claude/gen3/tasks/knights/task.md
- /home/claude/gen3/tools/run2.py
- /home/claude/gen3/conventions/ (directory listing; grep over both spec files for halt/success/TASK-RESULT)
- /home/claude/lib244/soar-library/ (listing, VERSION.txt, selection-world/elaborations/top-state.soar, grep)
- /home/claude/gen3/examples/all/ (listings), all of families/knights/knights-6/*,
  english-world/artists-world/artists-rules.soar (lines 290-330, TASK-RESULT pattern), grep for TASK-RESULT
- Scratch checker script written in /home/claude/kcheck (my own, not task material)
