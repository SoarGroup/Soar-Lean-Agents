# missionaries-cannibals (CONDITION=examples)

## Approach
- Followed the family reference agent examples/all/families/missionaries-cannibals/mac-look-ahead (world-lean, 19 Nov 2026),
  which is written to the same conventions for this exact task, and adapted names and output.
- Internal problem: ^environment none (L7-011), so every crossing is applied internally to ^world (L10-009, L10-017).
- World: two banks (left, right) with ^missionaries, ^cannibals, ^boat (1/0), ^other-bank.
- Desireds: two object-property desireds, right bank ^missionaries 3 and ^cannibals 3 (L8-018/L8-020 achieved/unachieved rules).
- Task operator move-boat, one proposal per legal load (1M, 2M, 1C, 2C, 1M1C; never empty), ^argument1/^argument2 banks,
  internal application rule (L10-007). Flag override ^mea-operator-selection true, as in the reference.
- Search: library default look-ahead (iterative deepening; default init-evaluation-depth unachieved-desireds) chooses among
  tied crossings. Failure marks (L3-025): an outnumbered bank, and in look-ahead a state equal to an ancestor world
  (repeated-state detection is left to the task, L14-040; via ^ancestor-world without ^quiescence, L14-068).
  The library does not elaborate ^ancestor-world in v2.45 (grep found no rule), so the task supplies the two rules, as the reference does.
- Settings: chunk always, chunk add-osk on (as in the reference).
- Result protocol: a top-state rule prints "TASK-RESULT: success" (or failure) and halts; the library's own
  "achieved - success" interrupt also fires. A monitoring rule prints each real crossing.

## Files
missionaries-cannibals.soar (main), _firstload.soar, initialize-missionaries-cannibals.soar, elaborations.soar,
move-boat.soar, state-evaluation.soar, task-result.soar. 19 user rules.

## Test runs
Run 1 (seeds 1-3, 1 episode, cap 20000): all success, halted, 0 load errors, 0 runtime errors, 11 crossings (optimal).
- seed 1: 744 decisions; seed 2: 692; seed 3: 652.
Checked seed 1 trace: 1M1C over, 1M back, 2C over, 1C back, 2M over, 1M1C back, 2M over, 1C back, 2C over, 1M back,
1M1C over -- a valid solution.

## Known problems
None observed. The harness's always-complete environment is unused (no output commands; actions = 0).

## Files read outside the output folder
- /home/claude/gen3/WRITER-INSTRUCTIONS.md
- /home/claude/gen3/tasks/missionaries-cannibals/task.md
- /home/claude/gen3/tools/run2.py
- /home/claude/gen3/conventions/World-Conventions-Spec-v8.md (outline and sections L10, L14 World/state, L14-038..041, L14-068, grep hits); Soar-Conventions-Spec.md only listed
- /home/claude/lib244/soar-library: VERSION.txt, CHANGES.md (v2.41-v2.45), agent-world/_flags.soar, selection-world/_flags.soar (grep),
  selection-world/elaborations/top-state.soar (grep), directory listings, grep for TASK-RESULT / ancestor-world
- /home/claude/gen3/examples/all: directory listings; families/missionaries-cannibals (mac, mac-look-ahead files);
  english-world/mc-world (missionaries-cannibals.soar, english-input.txt, missionaries-cannibals-rules.soar, run.py);
  english-world/artists-world/artists-rules.soar (header and TASK-RESULT rule); english-world/zebra-world/zebra-rules.soar (TASK-RESULT rule)
