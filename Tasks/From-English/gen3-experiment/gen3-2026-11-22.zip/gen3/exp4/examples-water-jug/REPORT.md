# water-jug (CONDITION=examples)

## Approach
- Search method: library look-ahead (selection-world). Task operators fill / empty / pour are proposed with only an
  acceptable preference, so they tie; the library's tie impasse evaluates each candidate on a copied world
  (evaluate-operator) and passes success/failure back. Chosen because the task is a small state-space puzzle whose goal
  needs a multi-step plan; random choice (water-jug example) can wander, and look-ahead finds a short plan.
- Repeated-state detection: a look-ahead state whose jug contents equal those of an ancestor task state gets
  ^partial-failure (state-evaluation.soar), which prunes cycles.
- Flags: flag-override ^mea-operator-selection true (task operators are proposed under this flag, as in the example
  family); all other flags library defaults. _firstload.soar: chunk always, chunk add-osk on (chunks summarise
  look-ahead results).
- World: two anchored objects jug3 (volume 3) and jug5 (volume 5), ^contents 0; derived ^free = volume - contents.
  Goal: one desired, object jug3 with ^contents 1 (object-property desired, achieved/unachieved elaborations).
- Result reporting: report-result.soar writes "TASK-RESULT: success" (or failure) and halts when the top state has
  ^success / all desireds achieved (or a failure value). The library itself only writes "achieved ... " and interrupts.

## Files
- water-jug.soar (load file: library, then rule files)
- _firstload.soar, elaborations.soar, initialize-water-jug.soar, fill.soar, empty.soar, pour.soar,
  state-evaluation.soar (adapted from examples/all/families/water-jug/water-jug-look-ahead)
- report-result.soar (TASK-RESULT line + halt)
20 user rules in total.

## Test runs (run2.py --seeds 1-3 --episodes 1 --cap 20000)
1. Load error: _firstload.soar not copied into the folder (0 user rules, no result). Fixed by copying it.
2. Seed 1: success, 199 decisions, 46 chunks. Seed 2: success, 178 decisions, 37 chunks. Seed 3: success, 336
   decisions, 59 chunks. Top-level plan on every seed: fill(jug3), pour(jug3->jug5), fill(jug3), pour(jug3->jug5),
   leaving 1 in jug3 (a shortest 4-step solution). No runtime errors; halted.

## Known problems
- None observed. Plan quality is not guaranteed optimal in general (look-ahead with default cost-metric none), but it
  was optimal on all three seeds.

## Files read outside the output folder
- /home/claude/gen3/WRITER-INSTRUCTIONS.md
- /home/claude/gen3/tasks/water-jug/task.md
- /home/claude/gen3/tools/run2.py (first 80 lines)
- /home/claude/gen3/conventions/Soar-Conventions-Spec.md and World-Conventions-Spec-v8.md (grep for halt/TASK-RESULT/selection guidance only)
- Library: agent-world/_flags.soar, agent-world/goal-completed.soar (head), selection-world/elaborations/top-state.soar;
  directory listing and grep of the library
- Examples: listing of /home/claude/gen3/examples/all; all files of families/water-jug/water-jug-look-ahead;
  water-jug/{water-jug.soar,_firstload.soar,search-control.soar}, water-jug-tie/{search-control.soar,water-jug-tie.soar},
  water-jug-look-ahead-failure-states/state-evaluation.soar, diffs of water-jug vs water-jug-look-ahead files;
  english-world/artists-world/artists-rules.soar (TASK-RESULT rule excerpt, via grep)
