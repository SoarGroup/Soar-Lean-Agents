# Multi-column arithmetic

Solve multi-digit addition and subtraction problems column by column, as taught in school: write the numbers one above
the other, work from the ones column leftwards, carry 1 to the next column when a column's sum is 10 or more, and borrow
from the next column when a digit to subtract is larger than the digit above it.

Goal: give the correct answer to each problem.

## The instance to solve

One addition problem: 35 + 96. Solve it column by column as taught in school (ones column first, carrying when a column sum is 10 or more), using single-digit addition facts. Goal: report the answer (131).
