# Blocks world

Lettered blocks sit on a table, some stacked on others. You may move one block at a time, and only a block with
nothing on top of it; it can go onto the table or onto another block that has nothing on top of it.

Goal: rebuild the blocks into the target stacks.

## The instance to solve

Three blocks A, B, C. Start: A on the table, B on the table, C on A. Goal: A on B, B on C, C on the table (a tower with C at the bottom, B in the middle, A on top).
