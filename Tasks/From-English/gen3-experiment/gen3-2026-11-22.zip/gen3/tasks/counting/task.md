# Counting

Count upwards from a starting number to a target number, one at a time.

## The instance to solve

Start at 0. Goal: count up one at a time and stop at 100.
