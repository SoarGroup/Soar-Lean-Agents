# Eight puzzle (and fifteen puzzle)

A 3 x 3 tray holds eight numbered tiles and one empty square. A tile next to the empty square (left, right, above or
below, not diagonally) may slide into it, leaving its own square empty. Tiles may not be lifted out.

Goal: slide tiles until they match the target arrangement.

The fifteen puzzle is the same game on a 4 x 4 tray with fifteen tiles.

## The instance to solve

3 x 3 grid, rows numbered 1-3 top to bottom and columns 1-3 left to right; 0 is the empty square.
Start:
  2 1 7
  8 6 0
  3 4 5
Goal:
  1 8 7
  2 0 6
  3 4 5
