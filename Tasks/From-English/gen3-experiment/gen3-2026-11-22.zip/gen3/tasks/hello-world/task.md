# Hello World

Write the words "Hello World" once, then stop.

## The instance to solve

Goal: write the words Hello World once and stop.
