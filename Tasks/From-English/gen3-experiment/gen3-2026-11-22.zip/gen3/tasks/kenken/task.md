# KenKen

Fill an n x n grid with the numbers 1 to n so that no number repeats in any row or column. The grid is divided into
outlined groups of cells called cages; each cage shows a target number and an operation (+, -, x or /). The numbers in a
cage, combined with that operation in any order, must give the target. A single-cell cage simply contains its target.
A number may repeat within a cage if the repeats are in different rows and columns.

## The instance to solve

A 4 x 4 KenKen; rows 1-4 top to bottom, columns 1-4 left to right; numbers 1-4. Cages (cells as (row,column)):
- (1,1),(1,2): difference 1
- (1,3),(1,4): quotient 2
- (2,1),(2,2): difference 1
- (2,3),(2,4): sum 5
- (3,1),(4,1),(4,2): sum 7
- (3,2),(3,3): difference 2
- (3,4): the number 2
- (4,3),(4,4): difference 1
Goal: fill all 16 cells satisfying the rows, columns and cages.
