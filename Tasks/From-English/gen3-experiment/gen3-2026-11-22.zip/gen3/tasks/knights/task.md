# Knight's tour

A chess knight moves in an L: two squares in one direction and one square at right angles. Starting from a given square,
move the knight so that it lands on every square of the board exactly once.

## The instance to solve

A 6 x 6 board. The knight starts on the square in column 2, row 3 (that square counts as visited). The task is to find
many tours, not one: search all tours from the start square, backing up at each dead end and after each tour found, and
count the closed tours (tours that visit all 36 squares exactly once and end on a square a knight's move away from the
start square). Stop after 100 closed tours have been found, after 30,000 moves (each knight move and each backup counts as one
move), or when the search is exhausted, whichever comes first. Report the number of closed tours found.
