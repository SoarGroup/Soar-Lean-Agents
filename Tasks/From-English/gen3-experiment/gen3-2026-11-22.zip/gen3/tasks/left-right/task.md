# Left or right

You may move either left or right, once. Moving right earns a reward of +1 and moving left a reward of -1, but you are
not told this in advance: over repeated tries, learn to choose the better direction.

## The instance to solve

The agent can move left or right, once per episode. Moving right gives reward +1 and moving left reward -1 (the agent is not told this; use Soar reinforcement learning with the reward link). Goal of one run: make a move, receive the reward, and end the episode. Over repeated episodes (init-soar between them) the agent should come to prefer right.
