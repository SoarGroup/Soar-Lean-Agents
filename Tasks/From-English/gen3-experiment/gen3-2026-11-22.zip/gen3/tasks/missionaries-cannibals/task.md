# Missionaries and cannibals

Three missionaries and three cannibals stand on the left bank of a river with a rowing boat that carries one or two
people. The boat never crosses empty. If, on either bank, the cannibals ever outnumber the missionaries who are there,
the missionaries are eaten (a bank with no missionaries is safe).

Goal: get all six people to the right bank.

## The instance to solve

Three missionaries, three cannibals and the boat on the left bank; the right bank is empty. The boat holds 1 or 2 people and never crosses empty. On either bank, if missionaries are present they must not be outnumbered by cannibals. Goal: all six on the right bank.
