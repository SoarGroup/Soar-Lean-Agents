# Pyramid problems

A pyramid problem adds a run of consecutive numbers counting down from a base: the base gives the first term and the
height says how many terms to add, each one less than the last. For example, base 5 with height 3 is 5 + 4 + 3 = 12.

Goal: compute the sum.

## The instance to solve

Base 5, height 2, where the computation adds one term per step while the remaining height is zero or more: 5 + 4 + 3. Goal: compute and report the sum (12).
