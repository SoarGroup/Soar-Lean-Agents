# Tic-tac-toe

Two players take turns marking empty squares of a 3 x 3 grid, one with X and the other with O. The first to get three
of their marks in a row, column or diagonal wins; if all nine squares fill with no line, the game is a draw.

## The instance to solve

An empty 3 x 3 board. The agent plays both sides, X moving first, alternating with O, each side playing sensibly (win if possible, otherwise block). Goal: play the game to its end (a win or a draw) and report the result.
