# Tower of Hanoi

Three pegs, A, B and C, and a stack of disks of different sizes, all on peg A, largest at the bottom. Move one disk at a
time, taking only the top disk of a peg and placing it on an empty peg or on a larger disk; a disk may never rest on a
smaller one.

Goal: move the whole stack to another peg.

## The instance to solve

Three pegs A, B, C; three disks (sizes 1 to 3) all on peg A, largest at the bottom. Goal: all three disks on another peg (peg C), in size order.
