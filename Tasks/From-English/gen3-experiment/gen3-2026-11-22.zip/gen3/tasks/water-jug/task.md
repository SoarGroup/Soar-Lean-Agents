# Water jug puzzle

You have two unmarked jugs, one holding 3 gallons and one holding 5 gallons, both empty, and an unlimited supply of
water. Because the jugs have no markings, you can only measure an amount by filling a jug to the brim or by pouring
until one jug is full or the other is empty. In one step you may fill a jug completely, empty a jug completely, or pour
from one jug into the other until the receiving jug is full or the pouring jug is empty.

Goal: end with exactly 1 gallon in the 3-gallon jug.

## The instance to solve

Two jugs: capacity 3 and capacity 5, both empty. Unlimited water source. Goal: exactly 1 unit of water in the 3-unit jug.
