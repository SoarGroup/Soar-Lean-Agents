# Three wizards (the wise men puzzle)

Three wizards, A, B and C, sit where each can see the others but not himself. Each has a spot on his forehead that is
either white or black, and they are told that at least one spot is white. They are asked in turn whether they know the
colour of their own spot; each can reason about what the others would have concluded from what they see and from the
answers so far.

Goal: a wizard correctly states the colour of his own spot.

## The instance to solve

Three wizards A, B, C. The agent reasons as wizard A. A can see that B's and C's spots are white; A's own spot is in fact white but A cannot see it. All are told at least one spot is white. Goal: by reasoning about what B and C would know and conclude (if A's spot were black, ...), A concludes the colour of his own spot (white) and says so.
