import json, glob, os, datetime
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.formatting.rule import FormulaRule
from openpyxl.utils import get_column_letter as L
FAM=['hello-world','counting','arithmetic','pyramid','left-right','tictactoe','wizards','blocks-world','towers-of-hanoi','water-jug','missionaries-cannibals','eight-puzzle','kenken','knights']
CONDS=['conventions','examples','heldout']
CN={'conventions':'Conventions only','examples':'Conventions + examples','heldout':'Conventions + examples, task held out'}
NOTES={
('conventions','hello-world'):'Written from conventions only.',
('conventions','counting'):'MEA; one count operator.',
('conventions','arithmetic'):'Column addition using a 100-fact table; MEA-style preference for next column.',
('conventions','pyramid'):'Writer report returned inline and not preserved; see REPORT.md stub.',
('conventions','left-right'):'RL; learns right.',
('conventions','tictactoe'):'Win/block preferences, other moves random; no look-ahead.',
('conventions','wizards'):'Possible-worlds elimination; order B, C, A assumed.',
('conventions','blocks-world'):'Look-ahead; 3-move plan.',
('conventions','towers-of-hanoi'):'3 disks (task changed 22 Nov). MEA with clear-subgoals and largest-first avoid-desired; look-ahead inside subgoals; init-evaluation-depth one; 7 moves. Writer reported a library issue: the look-ahead operator copy shares ^desireds with the tied operator (segfault in its first design).',
('conventions','water-jug'):'Default look-ahead plus last-operator undo control; optimal 4-step plan. Noted library lacks ^ancestor-world (L14-068).',
('conventions','missionaries-cannibals'):'Default look-ahead; task-written ^ancestor-world duplicate detection plus undo control; optimal 11 crossings. Without undo control: 72,572 decisions.',
('conventions','eight-puzzle'):'Default look-ahead; optimal 5 moves. Goal collapsed to one "tray solved" desired because of the 6-desired limit (deviates from L8-005/L8-009).',
('conventions','kenken'):'assign + eliminate with look-ahead on ties; tie-impasse, max depth 16.',
('conventions','knights'):'Count closed tours (task changed 22 Nov: stop at 100 closed tours or 30,000 moves, knight moves and backups). Depth-first on the real state in a fixed direction order: 0 closed tours in 30,000 moves on every seed (no move ordering).',
('examples','hello-world'):'Copied structure of families/hello-world; harness stops before the halt decision.',
('examples','counting'):'Follows families/counting/count-up (same task).',
('examples','arithmetic'):'MEA column processing with fact table.',
('examples','pyramid'):'Copied families/pyramid/pyramid-anderson (exact instance).',
('examples','left-right'):'Adapted families/left-right; added receive-reward step so RL updates.',
('examples','tictactoe'):'Adapted families/tictactoe; fixed duplicate win-detection matches.',
('examples','wizards'):'Rewrite of families/wizards (nested views); harness stops before the halt decision.',
('examples','blocks-world'):'Copied blocks-world-simple-3.',
('examples','towers-of-hanoi'):'3 disks. Follows the towers-of-hanoi-mea example; 7 moves.',
('examples','water-jug'):'Look-ahead, following water-jug examples.',
('examples','missionaries-cannibals'):'Look-ahead, following mac examples.',
('examples','eight-puzzle'):'Following eight-puzzle example; seed 3 took 9 moves (non-optimal).',
('examples','kenken'):'Following kenken examples.',
('examples','knights'):'Count closed tours. Near copy of the knights-6 example (same task): 100 closed tours in 3,767-4,473 moves.',
('heldout','hello-world'):'Built from artists/hello-world-like patterns (own task removed).',
('heldout','counting'):'Modelled on pyramid/hello-world examples; first version counted to 100 in one decision, fixed.',
('heldout','arithmetic'):'Composite add-column operator with substate; addition facts in semantic memory (following count-add-smem); MEA.',
('heldout','pyramid'):'Modelled on counting examples.',
('heldout','left-right'):'gp-generated RL rules; learns right (27-29 of 30).',
('heldout','tictactoe'):'Win/block/random policy; no look-ahead.',
('heldout','wizards'):'Possible-worlds elimination with MEA subgoaling; order B, C, A assumed.',
('heldout','blocks-world'):'MEA with bottom-up ordering; writer found a kernel segfault in look-ahead+MEA subgoaling (selection-world*apply*world*local-version) when ordering removed.',
('heldout','towers-of-hanoi'):'3 disks. MEA, largest disk first (^preferred-desired); 7 moves. Added task workarounds for a precondition mark that did not retract and a dropped selected move.',
('heldout','water-jug'):'Look-ahead with ancestor-world duplicate failure and chunk always; optimal plan.',
('heldout','missionaries-cannibals'):'Look-ahead with visited-situation rejection (from jealous-husbands example); optimal 11 crossings.',
('heldout','eight-puzzle'):'Look-ahead; goal as tiles-in-place count = 8 (kenken pattern); optimal 5 moves.',
('heldout','kenken'):'Zebra-style elimination; solved without look-ahead on this instance.',
('heldout','knights'):'Count closed tours. Depth-first on the real state with Warnsdorff ordering it chose itself: 26 / 26 / 21 closed tours (176 / 176 / 141 tours) at the 30,000-move limit.',
}
ARIAL=Font(name='Arial',size=10); B=Font(name='Arial',size=10,bold=True)
HDR=PatternFill('solid',fgColor='D9E1F2'); ORANGE=PatternFill('solid',fgColor='FFC000')
wb=Workbook()
# Detail sheet
dt=wb.active; dt.title='Runs'
hd=['Condition','Family','Seed','Result','Decisions','Halted','Load errors','Runtime errors','Warnings','User rules','Chunks','Top-level operators']
dt.append(hd)
for c in CONDS:
  for f in FAM:
    fn=f'/home/claude/gen3/rerun/{c}__{f}.txt'
    for line in open(fn):
      if not line.startswith('{'): continue
      d=json.loads(line); e=d['episodes'][0]
      dt.append([CN[c],f,d['seed'],e['result'],e['decisions'],'yes' if e['halted'] else 'no',d['load_errors'],e['runtime_errors'],e['warnings'],d['user_rules'],e['chunks'],e['top_ops']])
n=dt.max_row
dt.conditional_formatting.add(f'A2:L{n}',FormulaRule(formula=['$D2<>"success"'],fill=ORANGE))
# Summary sheet
sm=wb.create_sheet('Summary',0)
sm.append(['gen3 experiment: Soar agents written from English task statements by fresh writers, library v2.45'])
sm.append(['Rerun in one harness (run2.py, seeds 1-3, 1 episode, cap 20000 decisions; knights 100000). Tower of Hanoi rows are 3 disks and knights rows count closed tours (tasks changed 22 Nov 2026). Generated '+datetime.datetime.now().strftime('%d %b %Y %H:%M')+'. Failing cells are filled orange.'])
sm.append([])
r0=4
sm.append(['Family']+[f'{CN[c]}: seeds succeeded' for c in CONDS]+[f'{CN[c]}: mean decisions' for c in CONDS]+[f'{CN[c]}: user rules' for c in CONDS])
for i,f in enumerate(FAM):
  r=r0+1+i; row=[f]
  for c in CONDS: row.append(f'=COUNTIFS(Runs!$A:$A,"{CN[c]}",Runs!$B:$B,$A{r},Runs!$D:$D,"success")')
  for c in CONDS: row.append(f'=ROUND(AVERAGEIFS(Runs!$E:$E,Runs!$A:$A,"{CN[c]}",Runs!$B:$B,$A{r}),0)')
  for c in CONDS: row.append(f'=INDEX(Runs!$J:$J,MATCH(1,INDEX((Runs!$A$1:$A${n}="{CN[c]}")*(Runs!$B$1:$B${n}=$A{r}),0),0))')
  sm.append(row)
last=r0+len(FAM)
tr=last+1
sm.append(['Total seeds succeeded (of 42)']+[f'=SUM({L(j)}{r0+1}:{L(j)}{last})' for j in (2,3,4)])
sm.conditional_formatting.add(f'B{r0+1}:D{last}',FormulaRule(formula=[f'B{r0+1}<3'],fill=ORANGE))
sm.conditional_formatting.add(f'B{tr}:D{tr}',FormulaRule(formula=[f'B{tr}<42'],fill=ORANGE))
# Notes sheet
nt=wb.create_sheet('Notes')
nt.append(['Condition','Family','Approach and remarks'])
for c in CONDS:
  for f in FAM: nt.append([CN[c],f,NOTES.get((c,f),'')])
nt.append([]); 
for t in ['Conditions: "Conventions only" writers read the two convention specs, the library and the task statement; "Conventions + examples" writers could also read all example agents; held-out writers read the examples with every agent for that task (family folder, same-task English and Rosie agents) removed.',
 'File-access check: every REPORT.md was scanned; no writer listed a file outside its allowed set. Three used scratch files in /tmp they created themselves (conventions knights, heldout water-jug, heldout kenken).',
 'Six REPORT.md files were saved by the main session from writers\' messages because the writers\' file tool refused them; the conventions pyramid report text was not preserved. Two writers (heldout hello-world, heldout knights) saved REPORT.md with a shell command.',
 '"Halted = no" for examples hello-world and wizards: the harness stops at the success message one decision before the agent halts; direct runs halt.']:
  nt.append([t])
for ws in wb.worksheets:
  for row in ws.iter_rows():
    for cell in row: cell.font=ARIAL; cell.alignment=Alignment(wrap_text=True,vertical='top')
for ws,hr in ((dt,1),(nt,1),(sm,r0)):
  for cell in ws[hr]: cell.font=B; cell.fill=HDR
  ws.freeze_panes=ws.cell(hr+1,1)
sm['A1'].font=Font(name='Arial',size=12,bold=True)
for cell in sm[tr]: cell.font=B
for j in range(1,11): sm.column_dimensions[L(j)].width=14 if j>1 else 26
sm.merge_cells('A1:J1'); sm.merge_cells('A2:J2'); sm.row_dimensions[2].height=28
for j,w in enumerate([30,22,8,10,10,8,10,12,10,10,8,12],1): dt.column_dimensions[L(j)].width=w
nt.column_dimensions['A'].width=30; nt.column_dimensions['B'].width=22; nt.column_dimensions['C'].width=100
# Search-control sheet
sc=wb.create_sheet('Search control')
rows=[['Rosie Tower of Hanoi (agents generated from the English with tools/control.py; library v2.45; cap 100,000 decisions)'],
 ['Task','Control items','Seed 1','Seed 2','Seed 3','Mean decisions']]
import glob,os,json as J
for d in ['tower-of-hanoi','tower-of-hanoi-4','tower-of-hanoi-5']:
  for v,lab in [('','none'),('-sc1','SC-1'),('-sc2','SC-2'),('-sc3','SC-3'),('-sc1-sc2','SC-1 + SC-2'),('-sc1-sc3','SC-1 + SC-3')]:
    cells=[];decs=[]
    for sd in (1,2,3):
      f=f'/home/claude/rr4/res/{d}{v}-s{sd}.json'; lines=open(f).read().splitlines(); x=J.loads(lines[0])
      cells.append(f"{x['outcome']} {x['decisions']} ({len(x.get('actions',[]))} moves)"); decs.append(x['decisions'])
    rows.append([{'tower-of-hanoi':'3 blocks','tower-of-hanoi-4':'4 blocks','tower-of-hanoi-5':'5 blocks'}[d],lab]+cells+[round(sum(decs)/3)])
rows+= [[],['SC-1: during look-ahead, do not move the smallest block twice in a row. SC-2: work first on the largest block that is not yet in place. SC-3: in look-ahead, do not move the smallest block back to the location it was on before.'],[],
 ['gen3 Tower of Hanoi, 3 disks, writers given SC-1 (seeds 1-3; the same agent with its SC-1 rule excised)'],
 ['Condition','With SC-1 (decisions)','SC-1 excised (decisions)','Moves'],
 ['Conventions only','3,532 / 2,127 / 3,469','cap 20,000 on every seed','7'],
 ['Conventions + examples','1,472 / 1,356 / 1,476','11,200 / 11,983 / 13,816','7'],
 ['Task held out','4,187 / 2,214 / 3,644','cap 20,000 on every seed','7'],[],
 ['Evaluation order from search control (L15-026; library v2.46 candidate; conventions-only agents with a task file adding ^evaluate-first / ^evaluate-last)'],
 ['Agent','Without (mean decisions)','With (mean decisions)','Moves'],
 ['eight-puzzle, seeds 1-5','1,100','470','5 every seed (shortest)'],
 ['missionaries-cannibals, seeds 1-3','5,532','1,468','11 every seed (shortest)']]
for r in rows: sc.append(r)
for row in sc.iter_rows():
  for cell in row: cell.font=ARIAL; cell.alignment=Alignment(wrap_text=True,vertical='top')
for r in (1,2): 
  for cell in sc[r]: cell.font=B
for j,w in enumerate([22,16,24,24,24,14],1): sc.column_dimensions[L(j)].width=w
sc.conditional_formatting.add('C3:E20',FormulaRule(formula=['LEFT(C3,7)<>"success"'],fill=ORANGE))
wb.save('/home/claude/gen3/results/gen3 three-condition results (22 Nov 2026).xlsx')
