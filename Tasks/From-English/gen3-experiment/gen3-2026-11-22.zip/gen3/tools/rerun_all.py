import json, os, subprocess, sys, re
from concurrent.futures import ThreadPoolExecutor
ROOT = '/home/claude/gen3/out'
RES = '/home/claude/gen3/rerun'
os.makedirs(RES, exist_ok=True)

def job(cf):
    c, f = cf
    d = os.path.join(ROOT, c, f)
    out = os.path.join(RES, f'{c}__{f}.txt')
    try:
        p = subprocess.run(['python3', '/home/claude/gen3/tools/run2.py', d, f + '.soar',
                            '--seeds', '1-3', '--episodes', '1', '--cap', '100000' if f == 'knights' else '20000'],
                           capture_output=True, text=True, timeout=1800)
        txt = p.stdout + '\n--stderr--\n' + p.stderr
    except subprocess.TimeoutExpired:
        txt = 'TIMEOUT'
    open(out, 'w').write(txt)
    return c, f

items = []
for c in ['conventions', 'examples', 'heldout']:
    for f in sorted(os.listdir(os.path.join(ROOT, c))):
        if os.path.exists(os.path.join(ROOT, c, f, f + '.soar')):
            if len(sys.argv) > 1 and f'{c}/{f}' not in sys.argv[1:]:
                continue
            items.append((c, f))
with ThreadPoolExecutor(6) as ex:
    for r in ex.map(job, items):
        print('done', *r, flush=True)
