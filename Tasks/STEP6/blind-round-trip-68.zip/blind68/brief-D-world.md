# Phase D: original Soar -> Soar under a convention set (direct, no English)

You are rewriting existing Soar programs so that they follow a given set of conventions. You
work directly from the original code; there is no English description in between.

## Isolation (strict)
- Read ONLY:
  - /home/claude/blind68/src/<family>/ for your assigned families (the original programs);
  - /home/claude/blind68/conventions/ and /home/claude/blind68/lib/;
  - /home/claude/blind68/tools/run.py.
- Do NOT read anything else under /home/claude: not blind68/english, blind68/results, any
  blind68 impl-* folder other than your own, and nothing outside blind68 (no READMEs, notes,
  Lean files, earlier agents, examples). Do not search the disk for them.
- Write ONLY under /home/claude/blind68/<impl>/<family>/ (your <impl> is given below), plus
  scratch files in /tmp.

## What to produce, for each variant in your families
- Folder /home/claude/blind68/<impl>/<family>/<variant>/ with load file <variant>.soar (sourced
  from that folder) and any rule files it sources. Source libraries by absolute path.
- A rewrite, not a copy: restructure the task knowledge into the conventions below. Keep the
  behaviour of the original: same task, same knowledge (no added heuristics or search control),
  same selection and learning method and parameters (RL settings, chunking settings, smem/epmem
  use, look-ahead), same end condition and printed output. Where the original relies on
  something the conventions forbid or cannot express, keep the behaviour by the nearest
  conforming means and record it. Do not copy default/library rules into the task; use the
  libraries named below.
- Runner protocol: the originals print `TASK-RESULT: success` or `TASK-RESULT: failure` when an
  episode ends, then halt; keep exactly that behaviour (same conditions). If the original never
  stops, do not halt; the runner's cap ends the run.
- Test every variant: python3 /home/claude/blind68/tools/run.py <variant dir> <variant>.soar
  --seeds 1-3 --episodes 3 --cap 3000 (count-in-substate: --cap 80000). It prints JSON per seed;
  it marks every output-link command ^status complete and does nothing else. Run the original
  the same way for comparison. Fix until the rewrite behaves like the original; no load errors.
  Keep tests short; the machine has 2 CPUs shared with other workers.
- Write /home/claude/blind68/<impl>/<family>/NOTES.md: per variant, what changed structurally,
  anything you could not keep, and the test comparison with the original (successes, median
  decisions).

## Conventions for your <impl>
<impl> = impl-direct-world. Use the world conventions in no-environment mode: read
/home/claude/blind68/conventions/world-notes.md first (including the 9 Nov update on tasks with no
external environment), then World-Conventions--*.csv (or the .xlsx). Build every agent on
/home/claude/blind68/lib/world2 (agent-world, simple.soar, selection-world,
selection-iterative-deepening), never lib/world: the task's situation in ^world, goals as
^desireds, actions as task operators. The top state gets ^environment none, so each task operator
is applied by internal application rules that update ^world in the decision it is selected: one
decision per action, no output commands, no waiting substates. None of these tasks has an external
environment; where the original writes output-link commands only to act on its own state, replace
them with ^world updates. Use look-ahead through selection-world (and iterative deepening only
where the original's search corresponds to it). Do not use lib/soar-default.

When done, reply with one line per variant (variant: works / partly / fails, one reason) and the
main difficulties.
