# arithmetic family: impl-direct-soar (original Soar rewritten under the standard Soar conventions)

All eight variants were rewritten directly from `src/arithmetic/<variant>/`. No library is sourced:
none of the originals uses look-ahead (every choice is an indifferent `+ =` choice), so
`lib/soar-default/selection.soar` is not needed (ORG-003 applies only with look-ahead).

## Structural changes in every variant

- **Layout (ORG-001).** `<variant>.soar` is the load file. It sources `_firstload.soar` (settings),
  `elaborations/` (lookup tables, problem classification, goal), and one file per top-level operator
  (`initialize-arithmetic`, `choose-operation`, `generate-digit`, `process-column` or `solve-problem`,
  `finish-problem`). Each operator substate is a folder named after the operator, holding its
  sub-operators.
- **Names (STA-016, SYN-008).** Single-letter and letter-digit attributes are replaced by descriptive
  ones: operator `^p ^c ^d ^f ^i ^t ^m ^k` become `^problem ^column ^digit ^fact ^borrow-column
  ^operation`. Problem `^pid ^digits` become `^id ^digit-count`. Column `^pos ^last ^digit1 ^digit2 ^gen1
  ^gen2 ^done ^newd1` become `^position ^leftmost ^top-digit ^bottom-digit ^top-generated-for
  ^bottom-generated-for ^done-for ^current-top`. Facts `^d1 ^d2 ^diff ^n ^plus10` become `^top ^bottom
  ^difference ^number ^plus-ten`. Substate locals `^d1 ^d2 ^r ^cout ^adj ^ten ^got1 ^nxt ^issub ^wrote ^n`
  become `^top ^bottom ^result-digit ^carry-out ^carry-applied ^borrowed ^top-ready ^next-position
  ^is-subtraction ^borrow-written ^counted`. finish-problem's `^c1 ^c2 ^c3` become `^column1..3`.
  Operator and state names are unchanged.
- **Lookup tables (STA-020).** The digits and the add/sub/inc/ten fact tables were part of the
  initialize-arithmetic application in the originals, which made them o-supported. They are now created
  by i-supported elaborations (`elaborations/facts.soar`, one rule per table) that test only the named
  task state. The tables have the same content, checked by comparing them with the originals' tables.
  initialize-arithmetic now creates only the name, the problem record, the columns and `^desired`.
- **Classification (STA-021).** The check "all digits written" (`^digits 6`, or `4` in addition) was
  repeated in process-column, finish-problem and solve-problem. It is now one elaboration,
  `^digits-complete yes`, and those proposals test it.
- **Merged operator (OPR-013).** generate-digit1 and generate-digit2 are now one operator,
  `generate-digit ^row top|bottom`, with the same six proposal cases and one application rule per row.
  The candidate set and the indifferent random choice are unchanged.
- **Substates (SUB-013, RES-019).** Each substate is named by its own elaboration rule, from the
  superoperator name. It receives `^task-state`, `^problem` and `^column`, and every sub-operator
  proposal tests the substate `^name`. Copies that no rule used were dropped: the originals copied
  `^p ^c ^c1 ^c2 ^c3` into every substate and tested them in every rule. Sub-operators read the task
  facts through `^task-state`.
- **Rules.** Each rule plays one role (SYN-001), has an English comment (SYN-048), writes `+ =`
  explicitly (PRO-016), and changes values with add/remove pairs in application rules (APP-011).
  Conditions that were redundant were removed, for example `^d1 <_v>` alongside a test that implies it.
- **Goal (GOL-002/014/016).** `^success <desired>` is an elaboration. The top-state detection rule
  prints the original message `The problem has been solved.`, then `TASK-RESULT: success`, then halts.
  The second line is new: it is the runner protocol line, and the originals did not print it. The halt
  condition is unchanged (problem count = desired count 0). The printed `column ...` and
  `problem op ...` lines are unchanged character for character.
- **Settings.** Chunking settings (`always`, `add-osk on`, `bottom-only on` in solve-problem, `never`
  in smem/smem-learn), the multi-attributes declarations (renamed) and the smem settings are kept.
  `smem --enable` was added (SET-003), which is the default anyway. The smem `--add` content is the same
  facts with the renamed attributes.

## Per variant

| variant | what changed beyond the common changes | not kept / deviations |
|---|---|---|
| arithmetic | none | none |
| addition | 2 columns, preset problem 35+96 (count 1), as the original | none |
| subtraction | preset problem 207-178 (count 1), as the original | none |
| arithmetic-solve-problem | solve-problem keeps only `^problem` (its `^c1..^c3` parameters were never used by a rule). The `position 3` test stays in the proposal. process-column is proposed inside the solve-problem substate over the task-state columns. | SUB-013 (Should): process-column's write-result is a second-level sub-operator, yet it changes task-state objects directly (column result, problem carry). This is kept, because routing the result up through solve-problem would change decisions and chunks. |
| arithmetic-v5 | get-digit1/add-carry, recursive borrow-from (take-one, write-borrow, add-ten-up), and `^current-top` on columns, all kept. The two borrow-from proposals (in process-column and in borrow-from) are separate rules, one per state name. | SUB-013 (Should): write-borrow, a nested sub-operator, writes the borrow column's `^current-top` on the task state. This is kept because it is the original design. borrow-from's init-local reads the column's written top digit, not its current top, as in the original. Using `^current-top` there gave an over-general chunk that fired repeatedly; this was found and fixed during testing. |
| arithmetic-smem | Facts are in smem. Each fact-using operator has two application rules: one issues the query once (`^queried <o>`) and one applies the retrieved fact. The apply rule now also tests `^result.success` (SMM-011). The query is removed after use (SMM-019). | `^queried <o>` keeps a local pointer to the operator identifier (STA-025 Should); it is kept because it marks the one query per selection. |
| arithmetic-smem-chunk | Same as arithmetic-smem, with chunk always and add-osk on | same as arithmetic-smem |
| arithmetic-smem-learn | Same as arithmetic-smem, plus the retrieval-failed rules and the counting substates add-digits and subtract-digits (init-local, count, store, done), which store learned facts in smem. smem starts with only the inc and ten facts. | The original store-add and store-sub rules had disconnected conditions: `(<up> ^d1 ^d2)` and `(<local> ^sum/^base)` were not linked to the state (SYN-003 / CHK-019). They are now bound to the parent substate and the local state. Runs show identical smem activity: 301 queries, 157 stores and 177 nodes in 3000 decisions, the same as the original. So, in practice, the disconnected match was always these objects. The results also use RHS arithmetic (`div`, `+`, `-`), as in the original. |

Kept on purpose, in every variant:
- Indifferent `+ =` proposals (PRO-019 exception: random generation is the task).
- The `-1` "no result yet" sentinel and the local negation `-^top` in the init-local proposals (IMP-015
  Should). Removing them would change the chunks.
- Numeric codes for the operation (0/1/2), because the printed output shows them.

## Tests

`python3 tools/run.py <dir> <variant>.soar --seeds 1-3 --episodes 3 --cap 3000` was run on the
original and on the rewrite. There were no load errors, runtime errors or warnings in either.

| variant | original: successes, median decisions, chunks per episode | rewrite: successes, median decisions, chunks per episode |
|---|---|---|
| arithmetic | 0/9, 3000 (runs to cap; count 10000), 8 | 0/9, 3000, 8 |
| addition | 9/9, 4 (episode 1: 15; later episodes reuse chunks), 3 | 9/9, 4 (15), 3 |
| subtraction | 9/9, 5 (episode 1: 25), 5 | 9/9, 5 (25), 5 |
| arithmetic-v5 | 0/9, 3000, 21/19 | 0/9, 3000, 21/19 |
| arithmetic-solve-problem | 9/9, 95 (decisions 158/95/91, 146/102/93, 157/95/91) | 9/9, 95 (identical per episode) |
| arithmetic-smem | 0/9, 3000, 0 | 0/9, 3000, 0 |
| arithmetic-smem-chunk | 0/9, 3000, 262..401 | 0/9, 3000, identical per episode |
| arithmetic-smem-learn | 0/9, 3000, 0 | 0/9, 3000, 0 |

The variants with 0/9 never stop within the cap in either version: they are set up to do 1000 to
10000 problems, so there is no TASK-RESULT line, as in the original. The rewrite's halt condition is
the same.

For a stronger check, the full print output was captured for 3000 decisions with seeds 1 and 2, for
both the original and the rewrite. It is identical in every variant: the same random problems, the same
column and problem lines, the same chunk firings. The only difference is the added
`TASK-RESULT: success` line in addition, subtraction and solve-problem. Every printed answer was also
checked arithmetically: all are correct, for example 269 of 269 for arithmetic and 68 of 68 for
smem-learn with seed 1. Per-episode decision and chunk counts in the runner output are identical too.
