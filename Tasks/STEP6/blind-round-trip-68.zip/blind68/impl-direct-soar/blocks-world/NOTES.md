# blocks-world: impl-direct-soar rewrites (original Soar -> standard Soar conventions)

Every variant folder has a load file `<variant>.soar` that holds the settings, sources the default
selection library by absolute path (`/home/claude/blind68/lib/soar-default/selection.soar`) when the
original used look-ahead, and then sources the task files.

Test: `run.py <dir> <variant>.soar --seeds 1-3 --episodes 3 --cap 3000`, for both the original and
the rewrite. "succ" counts successful episodes out of 9; "med" is the median number of decisions
over all 9 episodes (a capped episode counts 3000). No variant has load errors or runtime errors.

## Changes common to all variants

- **Layout (ORG-001):** `elaborations/` (derived attributes, goal, problem space, state evaluation,
  reward), `initialize-blocks-world.soar`, `move-block.soar`, `move-block/` (one folder per
  substate operator, with `*_source.soar`), `search-control.soar`, `rl.soar`. Settings are in the
  load file. Each rule has an English comment before it (SYN-048) and names follow SYN-034.
- **Representation:**
  - Objects are typed with `^type table|block` instead of `^table 1|0`.
  - Derived flags have the value `yes` instead of `1`.
  - The gripper uses `^position up|down` and `^open`/`^empty yes|no`.
  - Operator parameters are `^block`, `^destination` and `^gripper` instead of `^dest` and `^g`.
  - Sub-operator parameters have meaningful names: `^target`, `^held`, `^onto` instead of `^x`,
    `^y`, `^d`.
- **Derived attributes (ELB-011):** `^clear`, and in the gripper variants `^free`, are computed by
  elaborations. Proposals test them instead of repeating negated conjunctions. Because of this,
  the two move-block proposal rules of the originals (onto the table, onto a block) are now one
  rule. Derived attributes are listed as `^dont-copy` for look-ahead (STA-012).
- **Initialization:** the `initialize-blocks-world` operator is kept (PRO-011). The goal is a
  `^desired` with one object per block, holding the block's `^name` and `^on` (GOL-012, GOL-013),
  as in the original.
- **Goal:**
  - The success rule is still a positive conjunction over the known blocks (CHK-016). This keeps
    chunks over it correct; a general rule with negation would give over-general chunks in
    look-ahead.
  - The detection rule tests `^name blocks-world ^superstate nil ^success <d>`, then prints the
    original's line `The problem has been solved.` and halts (GOL-014, GOL-016).
  - The originals print this line, not `TASK-RESULT: ...`, so the rewrites print the same line.
    The runner maps it to success.
- **Dropped dead code:** the `^ancestor` elaborations of the look-ahead variants and epmem were
  never tested by any rule, so they are gone, and with them `multi-attributes ancestor`.

## Per variant

| variant | orig succ / med | rewrite succ / med | verdict |
|---|---|---|---|
| simple | 9/9, 7 | 9/9, 7 (identical per episode) | works |
| simple-3 | 9/9, 4 | 9/9, 4 (identical) | works |
| random | 9/9, 13 | 9/9, 23 | works (random walk; the sequence differs) |
| rl | 9/9, 132 | 9/9, 102 | works |
| look-ahead | 6/9, 37 | 6/9, 23 (seed 3 never finishes in either) | works |
| look-ahead-state-eval | 9/9, 4 | 9/9, 4 (identical, 32 chunks, 16 RL rules) | works |
| epmem | 9/9, 389 | 9/9, 294 | works |
| operator-subgoaling | 9/9, 5 | 9/9, 5 (identical) | works |
| operator-subgoaling-chunk | 6/9, 5 | 6/9, 5 (identical; episode 3 loops at max-elaborations in both) | works |
| operator-subgoaling-relevant | 9/9, 11 | 9/9, 11 | works |
| hierarchical | 9/9, 42 | 9/9, 42 (identical) | works |
| hierarchical-lookahead | 9/9, 78 | 9/9, 78 (identical per episode) | works |
| hrl | 9/9, 95 | 9/9, 131 | works |
| hrl-3level | 9/9, 43 | 9/9, 118 | partly: always succeeds but learns more slowly (see below) |

### blocks-world-simple, -simple-3, -random
- **Structure:** one move-block proposal over `^clear` objects, with `+ =`, and one application
  rule (APP-011). simple and simple-3 keep the two search-control rules in `search-control.soar`
  (out-of-place block to the table is best; onto its in-place desired support is better than any
  other candidate). random has none, as in the original.
- **Not kept:** nothing.

### blocks-world-rl
- **Structure:** the RL template is in `rl.soar`. It is keyed on the same features as the
  original: the block and destination name and type, and the support of every block. The reward
  rule (RL-010) is in `elaborations/reward.soar`. Settings are unchanged.
- **Deviation from RL-019:** the proposal keeps its indifferent preference. In this Soar build,
  rules instantiated from a `:template` after `init-soar` can be malformed (variables are merged,
  for example `(state <b4> ^name A ...)`), so they never match. Without `=` the operators then tie
  and the agent stacks state no-changes. I checked that the original has the same malformed rules;
  only its `=` hides them.

### blocks-world-look-ahead
- **Structure:**
  - The proposal has only `+` (PRO-013).
  - `problem-space.soar` gives `^two-level-attributes object` and dont-copy for the derived
    attributes.
  - The last-move record (APP-011/APP-026 pair) is in `move-block.soar`.
  - The original's reject-twice rule tests `^superstate.operator.name evaluate-operator`.
  - Chunking settings are unchanged (`chunk always`, `add-osk on`).
- **Not kept:** nothing. Seed 3 never finishes in the original either.

### blocks-world-look-ahead-state-eval
- **Structure:**
  - The state-evaluation rules test `^tried-tied-operator` (ELB-010) and give `^expected-value`.
  - They keep the original's "world feature" conditions (the support of every block). These make
    the learned chunks, which become RL rules, specific to the whole state.
  - `^desired.better higher` is kept. Success is recognised only at the top state, as in the
    original. RL and chunking settings are unchanged.
- **Not kept:** nothing. Results are identical.

### blocks-world-epmem
- **Structure:**
  - The epmem model is a substate named `model` (STA-006). It records `^evaluation-state` and
    `^predict` locally and has the operators model-query, model-next, model-update and
    model-unknown, each in its own file under `model/`.
  - Commands go on `^epmem.command`, and `^query` is replaced by `^next` (EPM-009, EPM-011).
  - model-unknown now puts `^partial-success <desired>` and `^numeric-value 2.5` on the
    evaluation state, and the selection rules turn them into the evaluation (GOL-002, GOL-004).
    The original wrote them directly into the selection space's `^evaluation` object.
  - The state evaluations test the task's own `^model-applied` marker, set by model-update. ELB-010
    notes that `^tried-tied-operator` does not work for operators applied by a sequence of rules.
    The original instead made model-update create `^tried-tied-operator` and remove
    `^untried-tied-operator`, both reserved library attributes (SYN-038).
- **Escape hatch (ORG-007):** `escape-hatch/selection-excise.soar` excises
  `evaluate-operator*elaborate*state*remove*untried-tied-operator`. Without it the tried operator
  is deselected before its no-change impasse can arise, so no model can apply it. The original
  excised this rule and also `...*tried-tied-operator`, which is no longer needed.
- **Also kept:** the move-block application and last-move rules test `-^look-ahead-operator <o>`.
  This tests the library attribute but does not create it.
- **Check:** in one run the model was used like the original (queries, updates and unknowns all
  occur).

### blocks-world-operator-subgoaling, -chunk, -relevant
- **Structure:**
  - The goal-style proposal (PRO-023) is in `move-block.soar`. The application rule requires the
    block and the destination to be `^clear yes`.
  - When a move-block cannot apply, its operator no-change substate is now named `move-block`, with
    `^desired.clear` for the block and the destination.
  - The original named that substate `blocks-world` and marked it by adding a second `^type`
    value (`operator-subgoal`). STA-005 forbids changing `^type`.
  - The substate shares the superstate's objects (`move-block*elaborate*substate*object`), so moves
    made in it are results (RES-010).
  - Proposal, application and search-control rules match `^name << blocks-world move-block >>`.
    Derived attributes and the goal test match only `blocks-world`, as in the original.
  - The relevant variant has the two goal-relevant proposals (onto the desired support; off an
    object that must be cleared, onto a clear object) and no search control.
- **Not kept:** nothing. The chunk variant reproduces the original's third-episode loop exactly
  (same chunks, max-elaborations every decision).

### blocks-world-hierarchical
- **Structure:**
  - Three levels in VisualSoar folders: `move-block.soar` → `move-block/` (pick-up, put-down) →
    `move-block/pick-up/`, `move-block/put-down/` (gripper operators).
  - Each substate is named after its superoperator by a substate rule. It gets `^task-state`
    (SUB-013) and local copies of block, destination and gripper (STA-023).
  - move-block, pick-up and put-down are abstract (IMP-016).
  - The clear/free distinction is now explicit. `^free` means nothing is on the object; `^clear`
    means free and not held by the gripper.
- **Not kept:** nothing. Results are identical.

### blocks-world-hierarchical-lookahead
- **Structure:**
  - The move-block space has a `problem-space` declaration: `^two-level-attributes object gripper`,
    and the block and destination as `^one-level-attributes`. The library maps them to the copies,
    so the original's three hand-written copy rules (which matched by name through
    `^duplicate-of`) are replaced.
  - Evaluation rules (success; two failures) are in `move-block/evaluation.soar`.
  - pick-up and put-down are parameterised (`^target`, `^held`/`^onto`) and have no `=`, so they
    tie.
- **Changed means:**
  - In an evaluation copy, pick-up and put-down are applied by simulation rules (APP-020). In the
    real substate they are applied by the gripper sub-operators.
  - The original recognised the copy by `^duplicate-of`, a reserved library attribute. The
    rewrite recognises it by the absence of `^task-state`, which only the real substate has.
  - `^tried-tied-operator` cannot be used as the gate. The library retracts the tried operator's
    proposal in the first elaboration wave, so the operator is deselected before a rule that
    tests `^tried-tied-operator` can fire. This was observed in a trace.
  - The rules that re-derive `clear` and `free` in copies use the same `-^task-state` test.
- **Not kept:** nothing. Results are identical per episode.

### blocks-world-hrl
- **Structure:**
  - The top-level RL template and success reward are in `rl.soar` and `elaborations/reward.soar`.
  - The move-block substate has pick-up(`^target`) and put-down(`^held`, `^onto`), each applied
    directly.
  - Its RL templates and the +1/-1 rewards are in `move-block/rl.soar`.
  - The template features are those of the original, renamed.
- **Deviation from RL-019:** `=` is kept in all RL-valued proposals, for the template reason given
  under blocks-world-rl.
- **Results:** the decision counts differ because RL exploration is seeded and candidate order
  differs. Learning is comparable.

### blocks-world-hrl-3level
- **Structure:**
  - Same three-level layout as hierarchical. The bottom-level operators (up, down, above-block,
    close, open; up-holding, down-holding, above-dest, release) have disjoint application cases
    (APP-022).
  - The gp-enumerated RL rules (4608, RL-020) and the rewards are in `pick-up/rl.soar` and
    `put-down/rl.soar`.
  - The bottom-level proposals have no `=` (RL-019). The gp rules cover every reachable case, and
    a test with `=` restored gave identical results.
- **Could not keep, and why:** the original `put-down*apply*release*case1` binds
  `^above { <g-above> <dest> }` and rejects `<g-above>`. In this Soar build that reject is lost.
  I saw the same effect when I first wrote `^empty { yes <empty> }`. As a result, the original's
  gripper builds up several `^above` values, both release cases fire, and the block is placed
  whenever any of them is the destination. The rewrite keeps `^above` single-valued, as the
  knowledge intends. The task is then harder:
  - all episodes still succeed;
  - over 12 seeds × 3 episodes, the median decisions per episode were 118 / 92 / 86 for the
    rewrite against 69 / 41 / 41 for the original;
  - learning does work: the RL values update normally.
- **Gotcha:** with the gp conditions written as `^above.name [...]` on one object, `DestroyAgent`
  hung inside rete excision (`resize_hash_table`) after three RL episodes (a kernel problem). The
  conditions are now written one per line, as in the original, and the hang does not occur.
