# counting (impl-direct-soar)

All three: one file per operator, substate operators in a folder named after the
superoperator, `elaborations/goal.soar` with a general success test against `^desired`
(GOL-012/013) and a detection rule that prints the original "The problem has been solved."
followed by `TASK-RESULT: success`, then halts. English comment before every rule; `+`
written explicitly; indifferent preferences kept where the original had them; `chunk never`
kept. Redundant conditions of the originals (unused `^superstate <ss>`, duplicated value
tests) removed.

## count-up
- Structure: initialize-count-up, count (parameter ^counter). Essentially the original with
  conventional rule form.
- Test: original 9/9 success, median 101 decisions; rewrite 9/9, median 101.

## count-in-substate
- Structure: count-to-limit is proposed from a relevance elaboration
  (`^count-to-limit-relevant`, OPR-017) and has no application rules; its operator
  no-change substate is named by a substate-specific rule that also copies the operator's
  parameters. The limit 75000 is now a constant parameter on the operator (`^limit`,
  OPR-016) and copied to the substate, instead of being repeated in three substate rules.
  Local counting operators: init-count (was init-local), increment, done; done writes the
  local count back to the counter (result, o-support through the superoperator).
- Not kept: nothing behavioural.
- Test (cap 80000): original 9/9 success, median 75004 decisions; rewrite 9/9, median 75004.

## count-add-smem
- Structure: add proposed from a relevance elaboration (OPR-017), parameter renamed
  `^a` -> `^adder`. Substate local attributes renamed to describe their role:
  `^d1` -> `^digit` (running sum digit), `^d3` -> `^steps`; operators next-digit1 ->
  next-digit, next-digit3 -> next-step. smem settings and successor facts unchanged.
- smem use: queries issued in an application rule on `^smem.command`, results used only
  after testing `^result.success <query>` (SMM-011), and the query removed in the rule that
  consumes the result (SMM-019). The original's per-operator marker `^queried <o>` is kept
  (local o-supported) to stop the query rule refiring after the query is removed but before
  the operator retracts.
- Not kept: nothing behavioural. Final adder identical to the original (digit1 8, carry 1,
  done 1).
- Test: original 9/9 success, median 41 decisions; rewrite 9/9, median 41.
