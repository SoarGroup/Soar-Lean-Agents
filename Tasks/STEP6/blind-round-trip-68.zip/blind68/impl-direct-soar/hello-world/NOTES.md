# hello-world (impl-direct-soar)

## hello-world
- Structure: load file `hello-world.soar` (settings + sources), `initialize-hello-world.soar`,
  `elaborations/goal.soar`, `hello-world-op.soar` (operator hello-world). Every rule has an
  English comment; proposals give `+` explicitly; the initialize apply rule tests
  `^superstate nil`; the goal test compares `^greeting.written` with the desired one through
  one shared variable (GOL-013); the apply rule tests the old value it removes.
- Output: same "Hello World" line; at the goal it prints the original "The problem has been
  solved." and then `TASK-RESULT: success`, then halts.
- Not kept: nothing. Operator still named hello-world (same as the task) as in the original.
- Test (seeds 1-3, 3 episodes, cap 3000): original 9/9 success, median 2 decisions;
  rewrite 9/9 success, median 2 decisions. 6 rules in both. No load or runtime errors.
