# kenken family: impl-direct-soar rewrite (standard Soar conventions)

All 16 variants (kenken-4-1 to 4-7, 5-1 to 5-5, 6-1 to 6-4) share the same task knowledge.
They differ only in the puzzle data (cells, candidates, cage tuples), the grid size N
(number of rows printed and cells to mark), and the matcher hints. The variant folders were
produced by one generator (kept in /tmp/kk/gen.py, not part of the deliverable). It reads
each original's initial-state data and writes the conforming rule set. So the structural
notes below apply to every variant.

## Structure of each variant folder
- `<variant>.soar`: the load file. It holds the settings (chunk always, add-osk on,
  allow-local-negations off, as in the original), `production optimize-attribute` hints
  (SET-011), sources `/home/claude/blind68/lib/soar-default/selection.soar` by absolute path
  (ORG-002/003), and then sources the task files.
- `initialize-kenken.soar`: the initialize-kenken operator (PRO-011). The initial state is
  regenerated in object form, with one WME group per cell, candidate and tuple, and with
  named variables (`<cell-11>`, `<cand-111>`, `<tuple-32>`). The `^desired` structure has the
  same shape as the puzzle record (GOL-012/013).
- `elaborations/problem-space.soar`: look-ahead copy controls. It lists cell, cand, tuple and
  puzzle as two-level attributes, sets default state and operator copy, and puts success and
  failure under `^dont-copy` (STA-010/012/014/015).
- `elaborations/goal.soar`: desired-state recognition as `^success <d>` elaborations
  (GOL-002). There are two cases. In a look-ahead state, all cells marked. At the top state,
  all cells marked and all N rows printed.
- `elaborations/failure.soar`: failure recognition as `^failure <d>` (ELB-013/014). There
  are two cases: an unmarked cell with no live candidate, and a marked cell whose candidate
  for that mark is dead.
- `elaborations/monitor.soar`: monitoring rules that print the original end messages (MON-001).
- One file per operator, each holding its proposal, application and search control (ORG-001):
  assign, cleanup, eliminate, prune, drop-tuple, choose-cell, guess, print-row.

## What changed structurally (same in all variants)
1. **Halting goes through the library.** The original had task rules that halt
   (`kenken*halt*goal*success`, `kenken*halt*failure`). These are gone. The task only
   signals `^success`/`^failure` on `^desired`, and the selection library's
   `top-goal*halt*success` / `top-goal*halt*failure` halt the agent (GOL-003, MON-002).
   Monitoring rules print the original messages, "The problem has been solved." and
   "Failure state: the task has failed.". The original had already loaded the library, so
   in the original both the task rule and the library rule halted at the same moment.
2. **The goal test is stratified.** The intermediate `^goal-reached` flag is removed.
   Success, and the print-row proposals, compare the puzzle's `^marks` with the desired
   `^marks` directly. This way, derived attributes come only from non-derived ones (ELB-012).
3. **choose-cell and choose-cell-3 are now one operator.** They were two operators with the
   same application. Now there is one operator, `choose-cell`, with a value parameter
   `^alive-count 2|3`, and one proposal rule per value (OPR-016, OPR-013). There is one
   application rule. The search control is unchanged: choose-cell gets a worst preference,
   and count 2 is better than count 3.
4. **print-row is simpler.** Each operator now carries only `^puzzle` and `^row r`, with one
   proposal rule per row (OPR-016). One general application rule matches the row's N cells
   by `^row <r>` and `^col 1..N`. The original's operator carried N cell links plus a
   redundant `^rp` argument, and its proposals re-matched all N cells.
5. **Names are clearer.** Operator parameters have meaningful names (`^puzzle ^cell ^cand
   ^tuple ^marked-cell` instead of `^p ^c ^x ^z ^y ^c1 ^c2 ^t`). Rule names follow
   `kenken*propose|apply|select|elaborate|monitor*...` (SYN-034). Every rule tests the
   state `^name` first (SYN-033) and has an English comment before it (SYN-048). Proposals
   write `+` explicitly (PRO-016).
6. **Dead structure is removed.** This covers the `^ancestor` elaborations (and their
   multi-attribute declaration), which no rule used and which were only listed under
   `^dont-copy`. It also covers the unused `^name |c11|` / `|v111|` / `|t32|` / `puzzle`
   labels on data objects. The key attributes coord, cid, tid and pid are kept (STA-028).
7. guess is still proposed without an indifferent preference, so guesses tie and are
   evaluated by look-ahead with the default selection rules (PRO-013). All other operators
   keep `=`.

## What could not be kept or followed
- **ELB-010 (state evaluations test `^tried-tied-operator`) is not followed.** In this task,
  a guess is followed by a long run of propagation operators in the evaluation state.
  `^tried-tied-operator` is only present while the copied guess is selected, so success and
  failure, which appear many decisions later, would never be seen. This is the documented
  exception, "operators applied by a sequence". The original did not use the test either.
- **Two success rules and two failure rules.** GOL-016 and ELB-013 ask for one rule each.
  Success needs a top-state case (rows printed first) and a look-ahead case, because
  print-row runs only at the top state, as in the original. Failure needs two cases because
  Soar has no disjunction of conditions (SYN-012). Each pair sits in a single file and marks
  a single attribute.
- Nothing behavioural was lost. The printed output, task, knowledge, selection method,
  chunking settings and end conditions are the same as the original. As in the original,
  chunking is on, but the runs build no chunks.

## Test comparison
Command: `run.py <dir> <variant>.soar --seeds 1-3 --episodes 3 --cap 3000`. That gives
9 episodes per variant. No variant had load errors, runtime errors or warnings.

| variant | original succ | original median dec | rewrite succ | rewrite median dec | user rules orig/new |
|---|---|---|---|---|---|
| kenken-4-1 | 9/9 | 98 | 9/9 | 98 | 40/35 |
| kenken-4-2 | 9/9 | 96 | 9/9 | 96 | 40/35 |
| kenken-4-3 | 9/9 | 102 | 9/9 | 102 | 40/35 |
| kenken-4-4 | 9/9 | 99 | 9/9 | 99 | 40/35 |
| kenken-4-5 | 9/9 | 150 | 9/9 | 150 | 40/35 |
| kenken-4-6 | 9/9 | 94 | 9/9 | 94 | 40/35 |
| kenken-4-7 | 9/9 | 97 | 9/9 | 97 | 40/35 |
| kenken-5-1 | 9/9 | 180 | 9/9 | 180 | 41/36 |
| kenken-5-2 | 9/9 | 180 | 9/9 | 180 | 41/36 |
| kenken-5-3 | 9/9 | 178 | 9/9 | 178 | 41/36 |
| kenken-5-4 | 9/9 | 176 | 9/9 | 176 | 41/36 |
| kenken-5-5 | 9/9 | 190 | 9/9 | 190 | 41/36 |
| kenken-6-1 | 9/9 | 437 | 9/9 | 437 | 42/37 |
| kenken-6-2 | 9/9 | 795 | 9/9 | 795 | 42/37 |
| kenken-6-3 | 9/9 | 599 | 9/9 | 599 | 42/37 |
| kenken-6-4 | 9/9 | 473 | 9/9 | 473 | 42/37 |

The decision counts match the original episode by episode, under the same seeds. Variants
that guess (4-5, 6-x) give different counts from episode to episode, and those match too.
For every variant, the full printed trace at seed 2 was compared with the original's: the
"Set cell" and "Guess" lines, the solution rows and the final message are identical.
