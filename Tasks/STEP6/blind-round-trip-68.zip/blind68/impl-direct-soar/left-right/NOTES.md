# left-right (impl-direct-soar)

## left-right
- Structure: load file with the original RL settings (learning on, rate 0.3, discount 0.9,
  epsilon-greedy, chunk never); initialize-left-right; `elaborations/goal.soar`;
  `elaborations/reward.soar` (i-supported reward rules on the task state's reward-link,
  RL-010); `move.soar` (one proposal rule per direction value, OPR-016); `move-rl.soar`.
- RL changes: the unary indifferent preference was removed from the move proposals
  (RL-019); the numeric-indifferent values make the two moves indifferent anyway. The
  original's `:template` RL rule was replaced by the two RL rules of the enumerable space
  (agent at location 0, not moved, direction -1 / 1), initial value 0 (RL-015, RL-020).
  The template also produced 2-4 extra instances for transient states (location +-1,
  moved 1) that are never used for selection; these no longer exist, so the runner's
  `rl_rules` count is 2 instead of 4-6.
- Output: "Moved: <dir>" kept; goal prints "The problem has been solved." and
  `TASK-RESULT: success`, then halts.
- Test: original 9/9 success, median 2 decisions; rewrite 9/9, median 2. Same moves chosen
  in every episode for seeds 1-3, and the same learned Q-values (seed 1 and 2: left -0.30,
  right 0.51; seed 3: right 0.657).
