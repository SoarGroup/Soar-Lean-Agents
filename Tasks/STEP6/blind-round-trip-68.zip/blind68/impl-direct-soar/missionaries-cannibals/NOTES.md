# Missionaries and cannibals: direct rewrite under the standard Soar conventions

Test: `run.py <dir> <variant>.soar --seeds 1-3 --episodes 3 --cap 3000` on the original and the rewrite.
Each cell gives decisions and result (s = success, f = failure, n = no result before the cap).

## Common to all four variants
- Files follow the operator layout (ORG-001): the load file `<variant>.soar` holds the settings and
  sources `initialize-mac.soar`, `elaborations/` and `move-boat.soar` (plus `rl.soar`). Each rule
  has an English comment (SYN-048), a `mac*<function>*<what>` name (SYN-034), and tests the state
  `^name` first (SYN-033). The state schema is written as a comment in `initialize-mac.soar` (STA-027).
- Initialization uses the operator `initialize-mac` (PRO-011). The banks are objects with fixed
  `^other-bank` links (STA-017, STA-029). The desired bank uses the same attributes as the state's
  banks (GOL-013).
- The five loads are five proposal rules with constant `^missionaries`/`^cannibals` (OPR-016). One
  general application rule applies every load (OPR-013, APP-011), as in the original.
- Failure is declared once, as the elaboration `mac*elaborate*failure*outnumbered` (GOL-015, ELB-013).
  Moves into failure states are still proposed (ELB-014).
- **Printed output is kept from the original**: `The problem has been solved.` and
  `Failure state: the task has failed.`. The originals of this family do not print `TASK-RESULT`
  lines; `run.py` maps these messages to success and failure.

## mac (random selection)
- Proposals are `+ =`, because random choice is the selection method (PRO-019). Task rules detect
  success and failure, print, and halt (GOL-014).
- Original: 4f/2f/4f 2f/2f/3f 4f/4f/2f. Rewrite: identical. Success 0/9 in both; median 3 decisions.

## mac-rl
- Proposals give only `+`. The template RL rule (`:template`, RL-022) supplies the values (RL-019).
  Removing `=` does not change selection, because every move-boat gets a numeric preference. The
  RL settings are unchanged. The rewards are i-supported elaborations: -1 for failure, +1 for
  success, -0.01 per step (RL-010, RL-011). The template leaves out `^other-bank` (STA-029).
- Original: 5f/2f/2f 2f/4f/7f 2f/4f/3f, with 52/62/41 RL rules. Rewrite: identical, with the same
  RL rule counts.

## mac-look-ahead (symbolic evaluation)
- The default selection library is loaded from `/home/claude/blind68/lib/soar-default` by absolute
  path, not from a local copy (ORG-002, ORG-003). Proposals give only `+` (PRO-013).
- `elaborations/problem-space.soar` declares the problem space and copies only `^bank`, two levels
  deep (STA-010, STA-014, STA-015, STA-012).
- The original `^ancestor` became `^superstate-set` (GOL-010). These two rules are general over
  every state, selection states included, so they do not test a state name. This is a recorded
  exception to SYN-033.
- Duplicate detection (`elaborations/duplicate.soar`) uses positive conditions over the two banks,
  compared by key and counts (CHK-016, STA-029). It tests `^tried-tied-operator` (ELB-010).
- Halting: the library's `top-goal*halt*success/failure` now halts the agent (GOL-003). The task's
  success and failure rules only print (`mac*monitor*goal*…`, MON-001). In the original, both the
  task rules and the library halted.
- Original: 3000n in every episode (it never finishes within the cap), with 61/54/91 chunks.
  Rewrite: identical, including the chunk counts.

## mac-look-ahead-numeric
- Same as mac-look-ahead, plus `^desired.better higher` and the numeric evaluation rule
  `mac*evaluate*state*numeric-value` (people on the right bank, GOL-004).
- Original: 125s/30s/16s 135s/57s/16s 132s/23s/12s. Rewrite: identical, with the same chunk counts
  and printed output. Success 9/9 in both; median 30 decisions.

## Not kept / deviations
- None that change behaviour.
