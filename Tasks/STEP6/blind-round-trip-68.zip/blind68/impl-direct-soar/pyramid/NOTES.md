# Pyramid: direct rewrite under the standard Soar conventions

Test: `run.py --seeds 1-3 --episodes 3 --cap 3000` on the original and the rewrite.
Printed output was also compared directly (one episode each); it is identical.

## Common
- One file per operator (ORG-001), plus `elaborations/goal.soar`. Each rule has an English comment,
  a conventional name (SYN-034, SYN-048), and a first condition that tests the state name. The
  state schema is a comment in the initialize file (STA-027). Initialization is an operator
  (PRO-011).
- The goal is `^desired`, recognized by a success elaboration that shares variables with the state
  (GOL-012, GOL-013). The detect rule (GOL-014) prints `The answer is N.` and
  `The problem has been solved.`, then halts. It no longer repeats the height test of the original
  halt rule, which was redundant. The original does not print a `TASK-RESULT` line; `run.py` maps
  its message to success.

## pyramid / pyramid-anderson
- `add-next-term` is proposed with `+` only: there is never more than one candidate, so `=` served
  no purpose (PRO-019). The application uses the combined add/remove form (APP-011) and prints
  ` + term` as before.
- pyramid: 12s in all 9 episodes, in the original and the rewrite (answer 0).
- pyramid-anderson: 4s in all 9 episodes, in the original and the rewrite (answer 12).

## pyramid-hierarchical
- `expand-pyramid` and `sum-terms` are abstract operators with no application rules (IMP-016). They
  are proposed through relevance elaborations (OPR-017), as in the original. Their substates are
  folders named after the operator (ORG-001).
- Substate naming: the general default rule `elaborate*state*name` is not in the project's library
  (only the selection library is), and the brief forbids copying default rules into the task. Each
  substate is therefore named by a substate-specific rule, which also copies the operator's
  `^pyramid` onto the substate (STA-006, SUB-007, STA-023).
- `sum-terms` keeps its running sum locally (SUB-012) and returns it with `final-sum` (RES-010).
  `init-local` still tests the local `-^sum` (RES-011). Chunking is off in this variant, so this
  has no effect. The original behaviour is kept.
- Results: 21s in all 9 episodes, in the original and the rewrite (answer 49).
