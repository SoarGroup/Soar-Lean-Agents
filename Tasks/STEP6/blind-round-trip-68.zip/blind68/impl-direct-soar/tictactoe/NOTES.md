# Tic-tac-toe: direct rewrite under the standard Soar conventions

Test: `run.py --seeds 1-3 --episodes 3 --cap 3000`. Rules: original 18, rewrite 15.

## Structural changes
- State name `TicTacToe` became `tictactoe`, because constants should use a single case (SYN-044).
  The name is never printed.
- The cells' unused `^xy` and `^name` attributes are dropped. The cells keep `^x ^y ^content`.
  The lines are objects with three `^cell` links (STA-017, STA-018).
- A fixed lookup table `^symbol` (0 is blank, 1 is X, 2 is O) is created by an elaboration that
  tests only the state (STA-020). Both the board monitor's `^shown` and the winner message use it.
  This replaces three `shown` rules and the two side-specific messages.
- A derived line classification `^complete-for <side>` was added (STA-021, ELB-011).
  `x-wins` and `o-wins` became one operator, `declare-winner ^side <side>` (OPR-007, OPR-013), with
  one general application. It prints `Side X won.` / `Side O won.` through the table. One
  search-control rule makes it best, as the two originals did.
- `detect-draw` was renamed `declare-draw`, with the same conditions and the same `Draw.` message.
- The monitor rules are kept in `elaborations/monitor.soar` (MON-006). The printed board is
  unchanged.
- The printed `The problem has been solved.` is kept. The original prints no `TASK-RESULT` line.

## Test comparison
- Original: 9s/9s/9s 10s/11s/10s 9s/7s/10s. Rewrite: 9s/9s/11s 10s/9s/8s 9s/7s/10s.
  Success 9/9 in both; median 9 decisions in both.
- The printed output of the first episode is identical for seeds 1 to 5.
- Later episodes can differ, because the random-number stream diverges at the winning decision.
  The original proposed six `x-wins` operators per winning line, one per ordering of the line's
  cells. The rewrite proposes one `declare-winner` per line. The choice among them draws from the
  same random generator that later selects marks. The play knowledge is unchanged.
