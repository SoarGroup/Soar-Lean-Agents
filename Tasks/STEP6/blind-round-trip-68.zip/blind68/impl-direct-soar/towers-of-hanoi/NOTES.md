# Towers of Hanoi: direct rewrite under the standard Soar conventions

Test: `run.py --seeds 1-3 --episodes 3 --cap 3000`. Printed move sequences were also compared
directly and are identical.

## Common
- Pegs, disks (including the bases and the ground) and `^holds` relation objects are kept
  (STA-030), with `^name` as the key of each holds object (STA-028). The schema is a comment in
  `initialize-towers-of-hanoi.soar`.
- A new derived attribute `(<s> ^clear <disk>)` is true when no holds object is above the disk
  (ELB-011). Proposals and applications test it instead of repeating the nested negation.
- The goal test is now general (GOL-011, GOL-013). `^achieved <gh>` holds for each desired holds
  object that is met, and `^success` holds when the desired state has holds objects and all are
  achieved. This replaces one rule that matched h1 to h5 explicitly. In substates whose desired
  state has no holds objects, the guard keeps success from holding trivially.
- `The problem has been solved.` and `Move Disk: N to peg P` are kept. The originals print no
  `TASK-RESULT` line.

## towers-of-hanoi
- The original built its control knowledge into the two proposals. The rewrite proposes every
  legal move (precondition style, PRO-017). The control knowledge becomes three reject preferences,
  marked as heuristic (PRO-024, PRO-025, EVA-018):
  - disk 1 does not move twice in a row;
  - disk 1 does not go back to the peg it last left;
  - two disks other than disk 1 do not move in a row.
  Exactly one move survives at each step, as before.
- `^control` (`^lastsize`, `^lastpeg`) became the record `^last-move` with `^disk-size` and
  `^disk1-from` (EVA-025, STA-025). The initial values are unchanged: size 2, and disk 1 "from" B.
- The two application cases became one general application rule, plus one rule that records
  `^disk1-from` when disk 1 moves (APP-022). The operator parameters now have descriptive names.
- Results: 32s in all 9 episodes, in the original and the rewrite (8 rules became 12).

## towers-of-hanoi-mea
- Goal-style (means-ends) proposals are kept (PRO-023), as three rules with descriptive names
  (`goal`, `unblock`, `clear-target`). Their conditions are unchanged, except for an identity
  binding that the original made redundantly.
- The operator subgoal is named `towers-of-hanoi` by a substate-specific rule (STA-006). It stays in
  the task's problem space and gets `^desired` with `^disk` and `^peg`. One rule shares
  `peg disk holds`, using an attribute disjunction (SYN-049) instead of four copy rules.
- **Changed:** the original marked the substate with `^type operator-subgoal`. `^type` is an
  architecture attribute (STA-005), so the mark is now `^purpose operator-subgoal`.
- Dropped as unused: the `^control` object, which this variant never tests, and the operator
  parameters `^hd`/`^dd`, which the application never reads.
- Results: 47s in all 9 episodes, in the original and the rewrite (13 rules became 12).
