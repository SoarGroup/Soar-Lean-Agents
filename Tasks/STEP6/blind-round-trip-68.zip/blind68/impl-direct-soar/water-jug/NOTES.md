# water-jug family: impl-direct-soar (original Soar rewritten under the Soar conventions)

All nine variants are rewritten from the originals in src/water-jug/. Each folder has a load
file `<variant>.soar` that sources its own rule files. Look-ahead variants source the default
selection library by absolute path (`/home/claude/blind68/lib/soar-default/selection.soar`) and
no longer use a local copy (ORG-002/003). No world libraries are used.

## Changes common to every variant
- Layout (ORG-001): `<variant>.soar` holds the settings (SET-011 `multi-attributes` before the
  rules), then sources `schema.soar`, `elaborations/` (free, goal, and for some variants
  problem-space, superstate-set, state-evaluation, last-operator), `initialize-water-jug.soar`,
  one file per operator, and a folder per substate (`fill/`, `heuristic-tie/`).
- `schema.soar` (comments only) declares every state, object and operator attribute with whether
  it is single- or multi-valued and derived or o-supported (STA-027, STA-028: ^volume is the jug key).
- Each rule has an English comment before it (SYN-048). Rules use `<task>*<function>*<item>` names
  with propose/apply/elaborate/select/detect/evaluate/rl (SYN-034). Every task rule tests the state
  `^name` (or `^superstate nil` for initialization) in its first condition (SYN-033). The
  initialize application now also tests `^superstate nil`. Conditions are grouped per object, and
  single-valued paths use dot notation (SYN-042).
- The goal: `^desired` is created at initialization with the same attributes as a jug (GOL-012/013).
  `water-jug*elaborate*state*success` marks `^success <d>` (GOL-002), and a separate monitoring
  rule `water-jug*detect*goal*achieved` prints and halts at the top state (GOL-014/016).
- Pour application cases are renamed (`target-fills`, `source-empties`). They are still mutually
  exclusive (APP-022), and `^free` is still a derived elaboration (ELB-011/012).
- Printed output is unchanged: `The problem has been solved.` then halt. The originals do not
  print `TASK-RESULT:`, so the rewrite does not either. The runner recognises this message as
  success.

## Per variant

### water-jug
Random search: proposals `+ =`, kept on purpose under the PRO-019 exception. Only the common
changes apply.
Test: original 9/9 successes, median 197 decisions; rewrite 9/9, median 197. The per-episode
decision lists are identical.

### water-jug-rl
Same RL settings (learning on, rate 0.1, discount 0.5, epsilon-greedy, chunk never). RL rules
still use `:template` (RL-022), now with named variables and English comments. The reward rules
are renamed `water-jug*elaborate*reward*both-empty/goal` (i-supported, RL-010/011).
**Not kept: RL-020 (gp-enumerated rules instead of templates) and RL-019 (drop `=` from
proposals).** I built and tested a gp version with all state-operator pairs enumerated. It loads
and solves, but it learns measurably slower than the original. Over 30 seeds and 5 episodes, the
original's median decisions were 135/5/5/5/5; the gp version's were 103/45.5/39.5/6/6. Template
instances are created only when a pair first matches, and they do not give a preference in that
decision, which changes the Q-update dynamics. Templates also need the `=` in the proposals:
without it, the first decision in a new state is a tie that nothing resolves, and the agent stacks
impasses up to the goal-depth limit (tested: 0/9 successes). So templates plus `+ =` are kept to
keep the original's learning behaviour.
Test: original 9/9, median 22; rewrite 9/9, median 22. Decision lists and RL rule counts
(53/48/49) are identical.

### water-jug-tie
Hand-coded tie heuristics in a tie substate. Restructured:
- `^last-operator` is now kept by one application rule, `water-jug*apply*all*last-operator`,
  which adds the new name and removes the old one together (APP-011). It replaces the separate
  record and remove rules. It is initialized to `none` (APP-026 exception).
- The tie substate is renamed from `Impasse__Operator_Tie` to `heuristic-tie`. Its local
  structures are renamed so that the selection library's reserved names (SYN-038:
  evaluate-operator, ^evaluation, ^value) are not reused: ^rating objects with ^candidate and
  ^rank, and the operators `rate-candidate` and `post-preferences`.
- **Preferences are no longer created by operator application (EVA-012).** In the original,
  create-preferences applied (`<ss> ^operator <so> > =`) directly. Now `post-preferences` only sets
  a local `^preferences-posted true`. Three i-supported selection rules
  (`heuristic-tie*select*equal/worst/best`) then give the superstate preferences from the ranks.
  The timing (all candidates rated, then one decision to post) and the decision count are
  unchanged. The difference is that the preferences are i-supported results rather than
  o-supported ones. In these runs that made no observable difference.
- Proposals no longer have `=`, as in the original, so ties occur.
Test: original 9/9, median 85; rewrite 9/9, median 85. Decision lists are identical.

### water-jug-tie-chunk
Same as water-jug-tie, with chunk always and add-osk on. The learned chunks are now i-supported
preference rules. For example:
`(state ^name water-jug ^last-operator pour ^operator <o> +)(<o> ^name pour) --> (<s> ^operator <o> < =)`.
Test: original 9/9, median 20, 5 chunks; rewrite 9/9, median 20, 5 chunks. Decision lists are
identical.

### water-jug-hierarchy
Fill is carried out in an operator no-change substate (IMP-016) and is proposed through a
relevance elaboration `^fill-relevant` (OPR-017).
Changes:
- The substate naming rule is split in two: `fill*elaborate*state*name`, and
  `fill*elaborate*state*jug` for the local jug copy (STA-023).
- The sub-operators pick-up, fill-jug and put-down now carry `^jug <j>` as a parameter (OPR-007),
  and their applications read the jug from the operator.
- put-down removes the specific `^holding <j>`.
- The fill-jug application no longer tests an unused `^superstate`.
Proposals test the substate `^name` (RES-019). Changes to the task state are made by sub-operator
applications (RES-010). A general `elaborate*state*name` rule is not written (SYN-050), because
the brief offers only the selection library and a fill-specific naming rule is used instead
(STA-006).
Test: original 9/9, median 161; rewrite 9/9, median 161. Decision lists are identical.

### water-jug-hierarchy-chunk
Same as water-jug-hierarchy, with chunk always and add-osk on.
Test: original 9/9, median 65, 3 chunks; rewrite 9/9, median 65, 3 chunks. Decision lists are
identical.

### water-jug-look-ahead
Uses the shared default selection library instead of the original's local copy, which is
byte-identical to the library.
Changes:
- The ancestor elaborations are renamed to `^superstate-set` (GOL-010) and stay all-state rules.
- The problem space is unchanged: default state and operator copy, `^two-level-attributes jug`
  (STA-015), `^dont-copy free` (STA-012) and `^dont-copy superstate-set`.
- The duplicate-state evaluation `water-jug*evaluate*state*duplicate` tests `^tried-tied-operator`
  (ELB-010). It is written with positive conditions over the two jugs (CHK-016) and gives
  `^partial-failure <d>`.
- Proposals have only `+` (PRO-013).
Both the task's detect rule and the library's top-goal*halt*success halt, as in the original.
Test: original 6/9, median 77; rewrite 6/9, median 77. Decision lists are identical. Seed 1 hits
the 3000 cap in all three episodes in both, so this comes from the original's behaviour and is not
a rewrite fault.

### water-jug-look-ahead-rl
Same as water-jug-look-ahead, plus the original's RL settings and two state evaluations: both
jugs full, and both jugs empty, each give `^expected-value -1`.
**Kept, against GOL-004 (^numeric-value plus ^desired.better):** `^expected-value` is a
library-supported evaluation that becomes numeric preferences. Switching to numeric-value would
change the knowledge. As in the original, there are no RL rules; RL learning is on and applies
only to whatever chunks carry numeric preferences.
Test: original 8/9, median 376; rewrite 8/9, median 376. Decision lists are identical, and one
episode hits the cap in both.

### water-jug-look-ahead-failure-states
Same as water-jug-look-ahead, plus the both-full and both-empty evaluations as
`^partial-failure <d>`. These are heuristic evaluations that apply only in look-ahead copies
(they test `^tried-tied-operator`), not task-constraint failure states. The top-state halt of
ELB-014 is therefore not applied: the start state itself is both-empty.
Test: original 9/9, median 9; rewrite 9/9, median 9. Decision lists are identical.

## Test command
`python3 /home/claude/blind68/tools/run.py <dir> <variant>.soar --seeds 1-3 --episodes 3 --cap 3000`
Every variant ran with 0 load errors, 0 runtime errors and 0 warnings.
