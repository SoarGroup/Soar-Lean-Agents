# Wizards: direct rewrite under the standard Soar conventions

Test: `run.py --seeds 1-3 --episodes 3 --cap 3000`. Printed output was also compared directly for
seeds 1 to 3 and is identical. Rules: original 55, rewrite 44.

## Structural changes
- One file per operator, with that operator's search control in the same file (ORG-001). The
  derived record attributes are in `elaborations/derived.soar`. The schema is a comment in
  `initialize-wizards.soar` (STA-027), and every rule has an English comment.
- Operator parameters got descriptive names (STA-016, OPR-007). For example, `|x1|`/`|x2|` became
  `^rec`/`^sub-rec`; `|k1| |w1| |k2| |w2| ^m ^u` became
  `^outer-view ^outer-rec ^inner-view ^inner-rec ^markvar ^value`; `^w |a1| |a2| |a3|` became
  `^wizard ^rec1 ^rec2 ^rec3`.
- Merged operators, with the value as a parameter (OPR-013, OPR-016):
  - `assume-black`/`assume-white` became `assume-mark ^value 2|1`, with two proposal rules and one
    general application;
  - `guess-black`/`guess-white` became `guess ^value 2|1`.
  The colour words in the messages come from a lookup table `^color` (STA-020). The two
  operators of each pair had identical preferences, so their preference rules merged too.
- Some proposals carried the value in a constant only because the original had one rule per value.
  These became one rule each, with the value taken from the state: `ascribe-guess` (3 rules
  became 1) and `complement` (2 became 1). They produce the same instances.
- Derived rules: the four "via-sub" propagation rules became one rule with an attribute
  disjunction (SYN-049). The two "contra when guessing but ascribed guess 0" rules merged the
  same way.
- **Kept:** `ascribe-guess` adds to the multi-valued `^aguess` and removes nothing, as in the
  original. This is documented in the schema as a set.
- `The problem has been solved.` is kept. The original prints no `TASK-RESULT` line.

## Test comparison
- Original: 18s in all 9 episodes. Rewrite: 18s in all 9 episodes. The trace is the same sequence
  of 10 messages ending in `Wizard 1 guesses his spot is white.`.
