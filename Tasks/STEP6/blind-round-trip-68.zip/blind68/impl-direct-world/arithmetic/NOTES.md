# arithmetic family: impl-direct-world (original Soar -> world conventions, lib/world2, no environment)

All eight variants share one structure (generated from one script so the shared parts stay identical;
the per-variant differences are the original's).

Files per variant `<v>/`:
- `<v>.soar`: load file. Sources lib/world2 by absolute path (agent-world, simple, selection-world,
  selection-iterative-deepening), then the original settings unchanged (chunk always / never,
  add-osk, bottom-only, multi-attributes, smem learning and the same `smem --add` facts), then the task.
- `arithmetic-world.soar`: initialization, world objects, desireds, achievement rules, knowledge tables,
  completion.
- `arithmetic-operators.soar`: top-level task operators.
- `process-column.soar`: the operator-implementation substates (process-column and below).

## Common structural changes (all variants)

- Initialization: `initialize-arithmetic` (^task-operator false) is proposed after agent-world's
  `initialize-agent-world` (tests ^world). It gives the top state ^name arithmetic, **^environment none**,
  ^problem-space (name arithmetic, ^agent-world true), ^flags, and the goal as ^desireds.
- World: the problem and each column are world objects under ^world.objects (^object-handle problem,
  column1..3, ^anchored true) with the original attributes (operation, carry, count, pid, digits; pos,
  last, digit1, digit2, result, gen1, gen2, done, and newd1 in v5).
- Goal: `^desireds` with one desired `^object (^object-handle problem ^count 0)`, ^desired-count 1.
  Task rules supply ^achieved / ^unachieved for object-property desireds (W-DBK-002). The library then
  adds ^success; agent-world proposes goal-completed, whose task application prints the original
  `The problem has been solved.`, plus `TASK-RESULT: success`, and halts.
- Knowledge tables (digit list; add/sub/inc/ten facts in the non-smem variants) are a ^facts lookup
  table on the top state, created by an elaboration (STA-020), not part of the world.
- Task operators (choose-operation, generate-digit1/2, finish-problem, write-result, and write-borrow in v5):
  ^task-operator true, ^action-handle, ^super-desired (the top desired), ^argumentN, ^argument-count, and
  precondition ^desireds with ^desired-count 0. Each has an internal application rule testing
  ^internal-actions true and ^pre-conditions-satisfied true that updates the world in the decision the
  operator is selected and logs (log 1). There are no output commands.
- Value parameters: the digit chosen by generate-digit1/2 is a constant argument (^argument2 <val>, no
  handle, W-APP-005). The operation chosen by choose-operation is a constant argument; there is one
  proposal rule per value, as in the original.
- process-column (and solve-problem, and borrow-from in v5) are composite task operators implemented
  in operator-implementation substates (agent-world gives them ^problem-space.name <op>, and copies
  ^argument1/^argument2 onto the substate). The substate's working values (d1, d2, adj, r, cout, ten,
  got1, nxt, issub, wrote) are local state of the substate, not world. The sub-steps that only change that
  local state (init-local, add-digits, subtract-digits, borrow/add-ten, get-digit2/increment-digit2,
  get-digit1/add-carry, take-one, add-ten-up, the counting operators) are non-task operators
  (^task-operator false). Only write-result (and write-borrow) change the world.
- Selection, learning and memory are unchanged: the same proposals with the same indifferent (=)
  preferences, so the same random choices (softmax, the default; agent-world does not change it), and the
  same chunking/smem settings. The original never searches, so there are no ties and selection-world /
  iterative deepening are loaded but never used.

## Departures from the conventions (kept behaviour by the nearest conforming means)

1. Proposals keep the original `=` preference (W-TOP-021/024 say leave task operators tied for
   look-ahead). Leaving them tied would replace the original's random choice with look-ahead search.
2. Proposals are precondition-style, not MEA. Top-level proposals test the top desired's ^unachieved.
   Substate task operators take ^super-desired from ^top-state.desireds, because process-column has no
   desireds of its own.
3. The composite operators have no ^effect-desireds (W-COP-002/007). With effect-desireds, agent-world
   makes the operator's effect-desireds the substate's own ^desireds (same identifier). Every
   achievement/count elaboration and the library's ^better lower on it would then be a result and
   build extra chunks. The original's process-column chunks would also change. Termination stays as in the
   original: the proposal retracts when the column's ^done equals the problem's ^pid.
4. finish-problem has one argument (the problem) and reads the columns from the world. It acts on four
   objects, and arguments are limited to 3.
5. Library defect: the task initialize operator ties with initialize-agent-world, because agent-world
   keeps proposing that operator (best) until the top state has a ^name. A task rule prefers
   initialize-arithmetic over it. This costs one decision.
6. Completion uses goal-completed (W-DES-016) instead of halting in the elaboration, which costs one
   decision. selection-world also prints `arithmetic achieved - success` / `achieved all desireds` and
   interrupts.
7. Printed output: the original `write` lines (column and problem lines, the solved message) are
   unchanged. The library operator-monitor (`Select ...`) lines and the task's `log 1` application
   lines (W-APP-011) are added.
8. smem-learn: the original store-add / store-sub rules matched `<up>` and `<local>` as unconnected
   identifiers (any WME with ^d1/^d2, ^sum/^base). In the rewrite they are bound to the superstate and the
   substate, which is what they meant. The results are the same in the tests.
9. The attributes `d1`/`d2` are written `|d1|`/`|d2|`, as in the original. Unquoted, Soar reads them as
   D1/D2 and they do not match the smem facts.

## Per variant: what changed, and tests

Test: `run.py <dir> <v>.soar --seeds 1-3 --episodes 3 --cap 3000`, original and rewrite. The table gives
results per seed and episode, and the median decisions over all 9 episodes. For variants that never stop
(count 10000/1000/2000 problems), the problems solved in 3000 decisions are also compared (a separate
check with the same seed). Every one of those answers was checked arithmetically. There were no load errors,
runtime errors or warnings in any run.

| variant | original | rewrite |
|---|---|---|
| addition (1 fixed 2-column problem) | 9/9 success; decisions 15,4,4; median 4; 3 chunks | 9/9 success; 17,6,6; median 6; 3 chunks |
| subtraction (1 fixed 3-column problem, borrowing) | 9/9 success; 25,5,5; median 5; 5 chunks | 9/9 success; 27,7,7; median 7; 5 chunks |
| arithmetic-solve-problem (10 random problems, solve-problem substate, bottom-only) | 9/9 success; median 95 (ep1 146-158, later 91-102); 10-14 chunks | 9/9 success; median 101 (ep1 147-159, later 93-104); 9-14 chunks |
| arithmetic (10000 problems; never ends) | cap 3000; 8 chunks; 269/269 correct problems (seeds 1-3) | cap 3000; 8 chunks; 269/269 correct (same problem mix per seed) |
| arithmetic-v5 (other column algorithm; never ends) | cap; 19-21 chunks; 266-267 correct | cap; 19-21 chunks; 266-267 correct (same) |
| arithmetic-smem (facts in smem, no chunking) | cap; 0 chunks; 93-94 problems | cap; 0 chunks; 92-94 problems |
| arithmetic-smem-chunk (smem + chunking) | cap; 255-404 chunks over episodes; 143-144 problems | cap; 255-404 chunks; 141-147 problems |
| arithmetic-smem-learn (count, store new facts in smem) | cap; 0 chunks; 66-68 problems | cap; 0 chunks; 67-68 problems |

Variant-specific notes:
- addition / subtraction: the initial problem is preset in the world (operation, digits, gen flags), as in
  the original. The generation and choose-operation rules are present but never apply. Each episode
  takes two more decisions (init ordering + goal-completed). The column outputs are identical.
- arithmetic-solve-problem: the top operator solve-problem (composite, 1 argument) proposes process-column
  in its substate. process-column's substate is the same as in arithmetic. chunk bottom-only is kept.
- arithmetic-v5: get-digit1/add-carry, recursive borrow-from (a composite task operator, argument1 = the
  column borrowed from, proposed in process-column and in borrow-from states), take-one, write-borrow
  (a task operator: changes the column's ^newd1) and add-ten-up. generate-digit1 also sets ^newd1.
- smem variants: queries and retrievals are in the application rules of add-digits, subtract-digits,
  add-ten and increment-digit2, with the original ^queried guard. smem-learn adds the retrieval-failed
  rules and the counting substates (add-digits / subtract-digits) that store the new facts.

Not kept / not applicable: no look-ahead or iterative deepening, because the original does not search.
Decisions per episode are 1-2 higher (the init tie fix and goal-completed). The extra log/monitor lines
noted above are printed.
