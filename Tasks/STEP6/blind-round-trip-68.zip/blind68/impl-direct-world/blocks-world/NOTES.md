# blocks-world under the world conventions (impl-direct-world, lib/world2, no environment)

All 14 variants were rewritten from the original code to the world conventions. Each variant
folder has `<variant>.soar`. It sources `lib/world2` by absolute path (agent-world.soar,
simple.soar, selection-world.soar, selection-iterative-deepening.soar), restores the original's
Soar settings, then sources the task files. No default/library rules were copied into the
programs.

## Common structure (all variants)

- **Initialisation.** agent-world's `initialize-agent-world` creates `^world`. The task's
  `initialize-blocks-world` (`^task-operator false`) is proposed once `^world` exists and is made
  better than `initialize-agent-world`, which otherwise stays proposed with `>` until the state
  has a `^name`. It gives the top state:
  - `^name blocks-world`, `^environment none` and `^flags`;
  - world objects (`^object-handle`, `^class block|table|gripper`, `^anchored true`) in the
    world's own `^objects`;
  - `^on` relation objects (`^argument1/^argument2/^argument-count 2`);
  - the goal as `^desireds`: one `^on` relation desired per block, with `^desired-count`.
- **Problem space.** `^problem-space` (name blocks-world, `^agent-world true`) is elaborated on
  every state named blocks-world, including look-ahead states.
- **Achievement.** Achievement of `^on` desireds is task-supplied, as both `^achieved` and
  `^unachieved` and compared by handle. agent-world counts them and puts `^success <desireds>` on
  the state. At the top state that prints the original message `The problem has been solved.`
  and halts. The originals print that message, not `TASK-RESULT`, and the runner accepts it. The
  libraries also print `blocks-world achieved ...` and log `Select/Apply ...` lines.
- **Task operators.** move-block and the gripper actions are task-action operators. Each has
  `^task-operator true`, `^action-handle`, world-object `^argument1..n` and `^argument-count`.
  move-block also has `^super-desired` (the block's own `^on` desired). Precondition `^desireds`
  are present on every task-action operator, with `^desired-count 0` unless stated otherwise.
- **Internal application.** With `^environment none` every state has `^internal-actions true`. A
  task operator's internal application rule therefore changes `^world` in the decision it is
  selected, at the top state too: one decision per action, no output-link commands. The rules
  match arguments by object handle, so they also work on look-ahead copies of the world, and a
  "not already so" test makes each fire once.
- **Proposals.** Proposals keep the original's conditions and preferences:
  - `=` where the original had it;
  - no MEA proposal and `^flags.mea-operator-selection false`, because the originals propose
    every legal move, not only moves for unachieved desireds.
- **Derived information** (in-place, clear, free) lives on the state, never on world objects, so
  look-ahead copies cannot hold stale values. The exception is the operator-subgoaling variants
  (see below).
- **Settings.** agent-world switches the indifferent-selection policy to epsilon-greedy. Each
  non-RL program sets it back to the Soar default (softmax). RL programs keep the original's
  `rl` settings and epsilon-greedy. chunk, epmem and multi-attributes settings are as in the
  original.
- **Decisions.** Every rewrite takes one more decision than its original for
  `initialize-agent-world`.

## Library and Soar behaviour found while testing (affects several variants)

1. **RL templates.**
   - In Soar 9.6.50, rules built from a `:template` that tests several identifiers often merge
     distinct identifiers into one variable. This was seen with dot notation and with relation
     objects that are replaced as blocks move. The learned rules never match again, so RL does
     not work at all.
   - The rewrites therefore give the templates constant features: `^rl-situation` (a `concat` of
     what the original template tested) on the state and `^rl-action` on the operator. The
     feature space is the same as the original's.
   - The original's own templates (`^object` attributes on stable identifiers) are not affected.
     Its rule counts also include duplicates.
2. **Composite operators with effect desireds.**
   - For a cCTO, agent-world makes the implementation substate's `^desireds` the operator's own
     `^effect-desireds` object. The counts and achievements computed there are results with
     o-support.
   - For pick-up and put-down inside the move-block substate, this put the move-block substate
     under goal dependency. Soar removed and rebuilt it whenever the gripper changed, and the
     rewards of the pick-up and put-down substates were lost.
   - pick-up and put-down therefore carry no `^effect-desireds`; they are composite operators
     implemented in a substate. move-block, at the top state, keeps its `^effect-desireds`.
3. **Two wait operators.** In a state no-change, both simple.soar and agent-world propose `wait`.
   The two waits then tie and are evaluated by selection-world.
4. **Success under `^better`.** selection-world turns `success` into a best preference only when
   the tied state's desireds have no `^better`. agent-world adds `^better lower` to every effect
   desireds. Where that matters (hierarchical-lookahead), `^best 0` and `^flags.use-timers true`
   make a success come back with numeric value 0, which is then best.

## Per variant

The test command was `run.py <dir> <variant>.soar --seeds 1-3 --episodes 3 --cap 3000`. Each
"Original" or "Rewrite" line gives successes out of 9 episodes and the median decisions.

### blocks-world-random
- **Changes.** Flat world: move-block (table and block destinations) with `=`, applied
  internally. No search control.
- **Not kept.** Nothing.
- **Test.**
  - Original: 9/9, median 13.
  - Rewrite: 9/9, median 24. Random walk.
  - Over 15 seeds: original median 30, rewrite median 24, all 45 episodes succeed in both.

### blocks-world-simple / blocks-world-simple-3
- **Changes.** As random, plus in-place (on the state) and the original's two preference rules
  (out-of-place block to table is best; a move onto its desired in-place support is better than
  all others).
- **Test.**
  - simple: original 9/9, median 7. Rewrite 9/9, median 8.
  - simple-3: original 9/9, 4 decisions. Rewrite 9/9, 5 decisions.

### blocks-world-rl
- **Changes.** As random, plus an RL template over (move, situation), with the features given as
  constants (see library note 1). The reward is agent-world's (`^flags.rl true`), 1.0 at goal
  success, which is the original's reward.
- **Test.**
  - Original: 9/9, median 132; 780–1611 RL rules.
  - Rewrite: 9/9, median 107; 210–235 RL rules (one per distinct move and situation).

### blocks-world-operator-subgoaling
- **Changes.**
  - move-block is proposed for any block that is not on the destination. Its preconditions are
    two `^clear true` object desireds (block and destination).
  - Selected unsatisfied, it has no application. agent-world's MEA operator subgoal gets those
    desireds, a problem space named blocks-world (task rule), and the shared world.
  - `^clear true` is an elaborated world-object property, because operator object-property
    desireds are matched against world objects. There is no look-ahead in this program, so the
    property is never copied.
  - The task supplies achieved/unachieved for clear desireds on states and unachieved on
    operators.
  - The original's preferences (avoid-clobbering, prefer-ontop, prefer-clearing) are written
    over the clear/on desireds.
- **Test.** Original 9/9, 5 decisions. Rewrite 9/9, 6 decisions.

### blocks-world-operator-subgoaling-relevant
- **Changes.** As above, with the original's two "relevant" proposals: a move achieving an `^on`
  desired of the state, or a move of a block that sits on an object the state wants clear, onto
  a clear object. No preferences.
- **Test.** Original 9/9, median 11. Rewrite 9/9, median 13.

### blocks-world-operator-subgoaling-chunk
- **Changes.** As operator-subgoaling, with `chunk always` and `add-osk on`. The MEA substate
  gets its own problem-space object; sharing the superstate's turned library elaborations into
  results and chunks.
- **Not kept.** Chunking learns different rules: 1 chunk in the rewrite against 3 in the
  original.
  - Original: its overgeneral chunks loop at elaboration (max-elaborations) in episode 3.
  - Rewrite: its chunk generalises the clearing move, and episodes 2–3 succeed.
- **Test.**
  - Original: 6/9 (every episode 3 reaches the cap), median 5.
  - Rewrite: 9/9, median 3 (6 decisions, then 3).

### blocks-world-hierarchical
- **Changes.**
  - The gripper is a world object: `^position up|down`, `^open true|false`, `^last-held`.
  - What it holds is `^holding-object`, either the held object or an object with
    `^object-handle none`, which is the form selection-world copies. Where it is is an `^above`
    relation.
  - move-block is a cCTO: no preconditions, `^effect-desireds` block on destination, no
    application.
  - In its implementation substate, pick-up and put-down are composite operators (library note
    2). The original's gripper actions are task-action operators in their substates.
  - The top preferences and the clear/in-place derivations are the original's.
- **Test.** Original 9/9, 42 decisions every episode. Rewrite 9/9, 43 decisions every episode.

### blocks-world-hrl
- **Changes.**
  - Top: move-block (cCTO) onto free destinations, with an RL template.
  - Move-block space: pick-up(x) and put-down(y, d) are task-action operators applied
    internally, with an RL template.
  - Rewards: +1 in the move-block space when the block is on the destination, -1 while the
    gripper holds another block; agent-world gives 1.0 at the top.
  - The original's gripper `^holding` keeps the last-held block after a put-down and is part of
    its RL state. That is kept as the gripper's `^last-held`.
- **Test.**
  - Original: 9/9, median 95; 439–601 RL rules.
  - Rewrite: 9/9, median 82; 238–337 RL rules.

### blocks-world-hrl-3level
- **Changes.**
  - As hierarchical, with the original's RL gripper actions (up, down, above-block, close in 3
    cases, open, up-holding, down-holding, above-dest, release).
  - gp Q-value rules: 9 operators × 512 = 4608, as in the original.
  - Rewards in the pick-up and put-down substates.
  - `^flags.rl false`: the original has no top-state reward.
- **Kept quirk.** The original release rule tests `^above { <g-above> <dest> }`, which Soar reads
  without the destination test. Release therefore always puts the block on the destination; the
  rewrite does the same.
- **Test.**
  - Original: 9/9, median 43; 4608 RL rules.
  - Rewrite: 9/9, median 44; 4608 RL rules. The traces are the same decision for decision, one
    decision later.

### blocks-world-hierarchical-lookahead
- **Changes.**
  - As hierarchical, but the move-block space proposes pick-up(x) for any clear block and
    put-down(y, d) for any clear destination, without preferences. They tie and selection-world
    evaluates them in look-ahead states of the move-block space; the task supplies their
    problem space.
  - In look-ahead (`^real false`) pick-up and put-down are applied by the original's abstract
    model rules. In the real state they are carried out by gripper actions.
  - Failure (task rules, after the evaluated operator is tried): holding another block, or empty
    with the block not on the destination. This tests the world directly, because `^unachieved`
    lags one wave and gave a transient failure.
  - Success is the look-ahead state's own desireds. `^best 0` and `^flags.use-timers true` make it
    best under the library-added `^better lower` (library note 4).
- **Not kept.** selection-world maps failure to worst (classic selection: reject). There are more
  decisions per tie: init-remaining-operators, and evaluation of each candidate.
- **Test.** Original 9/9, median 78. Rewrite 9/9, median 95.

### blocks-world-look-ahead
- **Changes.**
  - move-block without preferences: ties go to selection-world. Each tied move is applied in a
    look-ahead state by the same internal rule.
  - `^last-move` is recorded on the state, once per application, and the original's reject-twice
    applies in look-ahead states.
  - A look-ahead state starts from the evaluated state's last move through `^inherited-last-move`.
    The original's default copy carried it over, but selection-world copies only the world.
  - chunk always, add-osk on.
- **Not kept.** selection-world instead of the original's own selection copy. Depth is unbounded
  (no iterative-deepening flags), as in the original.
- **Test.**
  - Original: 6/9, median 37; seed 3 reaches the cap in all episodes; 7–16 chunks.
  - Rewrite: 9/9, median 17; 10 chunks; later episodes take 5 decisions.

### blocks-world-look-ahead-state-eval
- **Changes.**
  - As look-ahead, without last-move. The original's state evaluation (expected value 1, 0.6,
    0.3 or 0 by tower level) is placed on look-ahead states after the tried operator. `^better
    higher` is on the desireds.
  - RL is on. The reward is a task rule at the top state only, because the original recognised
    success only there. agent-world's reward is off.
- **Not kept.**
  - agent-world also recognises success in look-ahead states, which the original did not.
  - The original's nested pass-back of a discounted expected value (in its own selection copy)
    has no counterpart in selection-world.
- **Test.**
  - Original: 9/9, median 4 (43 decisions, then 4–6); 32 chunks, 16 RL rules.
  - Rewrite: 9/9, median 5 (47, then 5–7); 37 chunks, 16 RL rules.

### blocks-world-epmem
- **Changes.**
  - Look-ahead as above, with numeric state evaluation (3, 2, 1, 0) and `^better higher`.
  - In a look-ahead state the evaluated move is not applied internally. In its no-change substate
    the original's epmem model runs: model-query, model-next, model-update or model-unknown.
  - The query cue is the move (name and argument handles) plus the look-ahead world's `^on`
    relations, with one cue node per handle. The next episode's supports are copied into the
    look-ahead world.
  - model-unknown puts `^partial-success <desireds>` and `^numeric-value 2.5` on the look-ahead
    state, and selection-world passes them up. The original wrote them into the evaluation
    directly, but `^evaluation` is reserved.
  - The load file excises selection-world's `apply*look-ahead*tried-tied-operator`, so the
    evaluated move stays selected until the model has been applied. The original excised the
    corresponding rules of its own selection copy.
- **Not kept.**
  - With `^better` on the desireds, selection-world does not make partial-success best.
    Therefore every tied move is evaluated (about 3× the original's decisions). The original
    selected the first one evaluated.
  - As in the original, a cue can match the current tie episode (acceptable preferences on the
    top state are recorded), so the model often returns the unchanged situation.
- **Test.** Original 9/9, median 389. Rewrite 9/9, median 1086.

## Variant status
- **Works, and matches the original closely:**
  - random
  - simple
  - simple-3
  - rl
  - operator-subgoaling
  - operator-subgoaling-relevant
  - hierarchical
  - hrl
  - hrl-3level
  - look-ahead-state-eval
- **Works, with library-driven differences:**
  - operator-subgoaling-chunk: different chunks
  - look-ahead: better results than the original
  - hierarchical-lookahead: +20% decisions
  - epmem: about 3× the original's decisions
