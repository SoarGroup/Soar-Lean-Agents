# counting (impl-direct-world)

All three built on lib/world2 (agent-world, simple.soar, selection-world,
selection-iterative-deepening), top state `^environment none`. Common to all:
- Task init after agent-world's initialize-agent-world, with a binary preference
  task-init > initialize-agent-world (otherwise agent-world's init, best and still acceptable
  until ^name exists, is reselected).
- The task's situation is one world object (counter / adder, with ^object-handle and
  ^anchored true); the goal is ^desireds with one object-property desired (^desired-count 1).
- Task-supplied ^achieved/^unachieved elaborations (generic object-property comparison);
  agent-world adds ^success; a task rule at the real top state prints the original's
  "The problem has been solved." plus `TASK-RESULT: success` and halts.
- The top-level operator is a task operator (^task-operator true, ^action-handle,
  ^super-desired, ^argument1, ^argument-count 1, ^desireds.desired-count 0), MEA-proposed on
  the unachieved desired, with the original's indifferent preference.
- _firstload keeps the original settings (chunk never) and restores softmax
  indifferent-selection (agent-world sets epsilon-greedy).
- One extra decision per episode (initialize-agent-world). Libraries print extra log lines.

## count-up
- count: internal application rule, counter value + 1 while < 100.
- Test: original 9/9 success, 101 decisions (median 101); rewrite 9/9, 102 (median 102).

## count-in-substate (cap 80000)
- count-to-limit is a task operator with no internal application rule; as in the original it
  is implemented in its operator no-change substate. agent-world gives that substate the
  operator's attributes (^name, ^argument1, ...) and ^problem-space.name count-to-limit
  (operator-implementation substate: ^pre-conditions-satisfied true), and shares the world.
  The original's own substate-naming elaboration is dropped (library does it); a task
  problem-space elaboration was removed because it duplicated the library's and doubled the
  sub-operators (tie).
- Sub-operators init-local / increment / done are internal (^task-operator false); the local
  ^count is scratch state on the substate (not world); done writes it into the counter.
- Deviation from the brief's "one decision per action": the action is implemented by a
  substate as in the original (the original's structure), not by one internal rule.
- Test: original 9/9 success, 75004 decisions (median 75004); rewrite 9/9, 75005 (median 75005).

## count-add-smem
- add is a task operator implemented in its substate (^name add, ^problem-space.name add from
  agent-world). Sub-operators init-local, next-digit1, next-digit3, done (^task-operator
  false); d1/d3/carry/phase are substate scratch; successor facts retrieved from smem exactly
  as in the original (query, then read ^result.retrieved.next and remove the query; agent-world's
  smem clean-up rule also removes completed queries, which does not change the outcome). done
  writes digit1 and carry into the adder and marks it done (9+9: digit1 8, carry 1).
- The original's add-relevant elaboration is folded into the proposal (adder ^done 0).
- smem settings and contents as in the original; multi-attributes hints dropped (attributes no
  longer on the state).
- Test: original 9/9 success, 41 decisions (median 41); rewrite 9/9, 42 (median 42).

No load errors or runtime errors in any run.
