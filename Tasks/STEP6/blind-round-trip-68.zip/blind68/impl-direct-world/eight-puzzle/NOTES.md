# eight-puzzle (impl-direct-world)

Built on lib/world2 (agent-world, simple.soar, selection-world, selection-iterative-deepening),
top state `^environment none`. Files are generated from the original initialization (same
start and goal). The original used the classic selection space (default/selection); the
rewrite uses selection-world look-ahead (one-step evaluation, as in the original).

## eight-puzzle, eight-puzzle-expected-value, fifteen-puzzle (same structure)
Structural changes
- World: cell objects (handle c11.., ^id, ^neighbor <cell-handle>, ^tile <tile-handle>), tile
  objects (t0 = blank .., ^number) and a board object. The original's binding objects
  (cell-tile pairs) became the cells' ^tile property, so the copied world in look-ahead needs
  only selection-world's object copy (constants, no identifier remapping).
- Goal: agent-world desireds hold at most 6 desired and the original goal is a conjunction of
  9 (16) cell bindings. Nearest conforming form: ONE desired on the board,
  ^arrangement <arr> with ^binding (^cell <handle> ^tile <handle>) items; task-supplied
  ^achieved (every binding holds) / ^unachieved (some binding fails) elaborations. agent-world
  then adds ^success; the halt rule at the real top state prints the original message +
  TASK-RESULT and halts. ^better higher is on the desireds (selection-world reads it there).
- move-tile is a task operator: ^argument1 tile, ^argument2 from-cell, ^argument3 to-cell
  (holds the blank), ^argument-count 3, ^super-desired, ^desireds count 0; acceptable
  preference only, so ties go to selection-world. Its internal application rule finds the
  cells by handle and swaps their ^tile values; it works in the real world and in look-ahead
  copies alike.
- Last move: kept on the state (search-control history, not world) as ^last-move (tile, from,
  to handles); reject-inverse rejects moving the same tile again. The record rule has a
  once-per-operator guard (recorded tile differs from the moving tile; safe because
  reject-inverse forbids moving the same tile twice).
- Evaluation: the original tested the selection library's ^tried-tied-operator (reserved in
  the world conventions). The rewrite evaluates a look-ahead state (^real false) from its
  ^last-move against the arrangement: +1 moved into goal cell, -1 moved out of goal cell, 0
  otherwise, as ^numeric-value (eight-puzzle, fifteen-puzzle) or ^expected-value
  (expected-value variant; selection-world turns it into a numeric-indifferent preference).
- Problem space: elaboration on ^name, so the look-ahead state (named after the task state by
  selection-world) gets the same ^problem-space.name. Copy flags of the classic selection
  space (one/two-level attributes, dont-copy ancestor) are not needed (only ^world is copied).
- Dropped: the ancestor elaborations (no rule read them); multi-attributes hints for the
  original state attributes.
- Kept: chunk always, add-osk on; softmax indifferent-selection restored after agent-world.

Not kept / differences
- selection-iterative-deepening, which must be loaded, runs init-remaining-operators in every
  tie (one extra decision per tie) though its depth control is inactive (no ID flags set); the
  original search is one-step look-ahead, not iterative deepening.
- In the classic library a look-ahead that reaches the goal gave a best preference; in
  selection-world with ^better on the desireds a success evaluation passes no numeric value
  and gives no preference, so the solving move is only not-dominated. No failure seen.
- More chunks (11-12 vs 7-8): the evaluations and library bookkeeping differ.
- One extra decision (initialize-agent-world); TASK-RESULT line and library log lines added.

Test (seeds 1-3, 3 episodes, cap 3000; episodes 2-3 keep the chunks)
- eight-puzzle: original 9/9 success, decisions [19,6,6] [24,6,10] [24,10,10], median 10;
  rewrite 9/9 success, [28,11,11] [25,11,7] [23,7,7], median 11.
- eight-puzzle-expected-value (random walk on numeric-indifferent values, softmax): original
  5/9 success, [17,cap,cap] [cap,2256,6] [1764,6,cap], median 2256; rewrite 6/9,
  [21,cap,cap] [cap,15,11] [1526,2833,1929], median 1929. RL rules 3 in both.
- fifteen-puzzle: original 0/9 within the cap (3000), rewrite 0/9 (3000). Chunks 8 vs 12.
- No load errors or runtime errors.
