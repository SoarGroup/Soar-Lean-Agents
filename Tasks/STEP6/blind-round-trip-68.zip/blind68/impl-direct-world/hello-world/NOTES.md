# hello-world (impl-direct-world)

Built on lib/world2 (agent-world, simple.soar, selection-world, selection-iterative-deepening),
top state `^environment none`.

## hello-world
Structural changes
- Initialization split: agent-world's initialize-agent-world first, then the task's
  initialize-hello-world (tests ^world, ^task-operator false). It creates ^name, ^environment
  none, ^problem-space (hello-world, ^agent-world true), ^flags.mea-operator-selection true,
  the world object `greeting` (^object-handle, ^anchored true, ^written 0) and the goal as
  ^desireds (one desired object: greeting ^written 1, ^desired-count 1).
- A binary preference initialize-hello-world > initialize-agent-world is needed: agent-world's
  init stays acceptable and best until the top state has a ^name, so it would be reselected
  (operator no-change), or tie with the task init if that one were also best.
- Goal test: task-supplied ^achieved/^unachieved elaborations on the desireds (generic
  object-property comparison); agent-world adds ^success <desireds>; a task rule at the real
  top state prints the original message and halts.
- hello-world is a task operator (^task-operator true, ^action-handle, ^super-desired,
  ^argument1 greeting, ^argument-count 1, ^desireds.desired-count 0), MEA proposal on the
  unachieved desired, internal application rule (^internal-actions true,
  ^pre-conditions-satisfied true) that sets ^written 1 and writes "Hello World".
- The original's indifferent preference is kept (no look-ahead in the original).
- _firstload: chunk never; `decide indifferent-selection --softmax` restores the original's
  policy (agent-world sets epsilon-greedy).

Not kept / additions
- Output adds `TASK-RESULT: success` after "The problem has been solved." and the libraries
  print their own lines (log messages, "hello-world achieved - success").
- One extra decision (initialize-agent-world).

Test (run.py, seeds 1-3, 3 episodes, cap 3000)
- Original: 9/9 success, 2 decisions each (median 2).
- Rewrite:  9/9 success, 3 decisions each (median 3). No load or runtime errors.
