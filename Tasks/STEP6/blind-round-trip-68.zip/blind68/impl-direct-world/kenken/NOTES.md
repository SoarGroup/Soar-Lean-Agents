# kenken family: original -> world conventions (impl-direct-world, lib/world2, environment none)

All 16 variants (kenken-4-1 .. kenken-6-4) have the same task rules and differ only in the puzzle
data (cells, candidates, cage tuples) and the grid size (print rows, number of marks). So every
variant folder has the same three-part layout, generated from the original's
initialize-kenken.soar / _firstload.soar:

- `<variant>.soar`: load file. Sources lib/world2 by absolute path (agent-world.soar, simple.soar,
  selection-world.soar), keeps the original learning settings (chunk always, add-osk on,
  allow-local-negations off), sets multi-attributes hints, then sources the three files below.
- `kenken-rules.soar`: task rules (identical in all variants).
- `initialize-kenken.soar`: the puzzle data as world objects plus the goal (one per variant).
- `print-row.soar`: print the solved grid, one proposal per row (one per variant, as in the original).

## Structural changes (same for every variant)

- **Top state / world.** agent-world's initialize-agent-world runs first. Then the task's
  initialize-kenken (task-operator false; proposed when `^world` exists) gives the top state
  `^name kenken`, `^environment none`, `^flags.mea-operator-selection true`, the goal and the
  world objects. A binary preference makes initialize-kenken better than initialize-agent-world.
  That operator stays proposed with `>` until the top state has a name, and without the binary
  preference the two operators tied.
- **World objects.** Each original state attribute `^cell`, `^cand`, `^tuple` or `^puzzle` became a
  `^world.objects.object` with `^object-handle` (the original `^name`: c11, v111, t1, puzzle),
  `^anchored true` and `^type cell|cand|tuple|puzzle`. All the original attributes are kept. Links
  between objects are now handle constants rather than identifiers: cell `^cand <cand-handle>`,
  cand `^in-tuple <tuple-handle>` (was `^in`), tuple `^uses-cand <cand-handle>` (was `^uses`).
  selection-world's look-ahead copy duplicates objects by handle but copies attribute values
  unchanged, so identifier links would point back into the real world.
- **Derived indexes on the state.** Joining world objects by handle made Soar's condition reorderer
  build cross products of all objects. The first choose-cell rule ran out of memory. So
  i-supported state structures (`^cell-info`, `^cand-info`, `^tuple-info`, `^puzzle`) turn the
  handle links into identifier links for each world, including every look-ahead copy. Following
  the world notes, they are kept on the state, not on world objects. The failure and goal rules
  test the world directly (handle joins on a single object). They then never fire while an index
  is half built: a first version halted with failure during initialization.
- **Goal.** The original `^desired.puzzle.marks N` became `^desireds` (desired-count 1) with one
  desired `^object (^object-handle puzzle ^marks N)`. The task supplies `^achieved` and
  `^unachieved`, and agent-world adds `^success <desireds>`. Failure (an unmarked cell with no
  live candidate, or a marked cell whose candidate is dead) is the original condition, now
  written as `^failure <desireds>` on any state of problem space kenken.
- **Problem space.** `^problem-space (^name kenken ^agent-world true)` on every state named
  kenken, including the look-ahead state. The original's selection copy flags
  (default-state-copy, two-level-attributes, dont-copy ancestor) and the `^ancestor` elaborations
  are dropped, because selection-world copies the world by its own rules.
- **Task operators.** cleanup, eliminate (row and column proposals), prune, drop-tuple, assign
  (three proposals), choose-cell, choose-cell-3 and guess are task-action operators. Each has
  `^task-operator true`, `^action-handle`, `^argument1..3`, `^argument-count`, `^super-desired`
  and empty precondition `^desireds` (desired-count 0, so agent-world marks them
  pre-conditions-satisfied). They are proposed MEA-style: each tests
  `^flags.mea-operator-selection true` and the unachieved puzzle desired. The proposals give only
  `+`.
- **Search control** (the original's preferences, now in separate rules): propagation operators and
  choose-cell are indifferent; choose-cell and choose-cell-3 are worst; choose-cell is better than
  choose-cell-3; guess gets no preference, so its alternatives tie and go to look-ahead.
- **Application.** Each operator has one internal application rule (tests `^internal-actions true`
  and `^pre-conditions-satisfied true`). It maps the arguments by object-handle to the objects of
  the state's own world and changes them in the decision the operator is selected. The same rule
  applies the real operator and the evaluated (uncopied) operator in look-ahead. No output
  commands and no waiting substates are used. Each application rule also tests the value it
  changes, so it fires once per operator.
- **Look-ahead.** Ties between guesses use selection-world. The evaluate-operator state is a
  hypothetical kenken state with a deep copy of the world, and the original propagation, nested
  guesses and nested ties run in it, as before. Success means the copied puzzle reaches N marks,
  and failure is the original failure test. The search is the original's unbounded depth-first
  look-ahead. selection-iterative-deepening is **not** loaded: the original search has no depth
  bound, so iterative deepening does not correspond to it. Look-ahead worked without it (the
  older note that selection-world needs it does not hold with lib/world2 here).
- **Printing and end.** print-row is a non-task operator (task-operator false) on the real top
  state once the goal has `^success`. The printed-row counter moved from the puzzle object to the
  top state (`^printed-rows`), because it is bookkeeping, not part of the puzzle situation. After
  N rows the original messages are printed (`The problem has been solved.` /
  `Failure state: the task has failed.`), followed by `TASK-RESULT: success|failure` and halt,
  under the same conditions as the original.

## What could not be kept exactly

- **Failure evaluation becomes worst, not reject.** selection-world turns a failure evaluation into
  a worst preference, and equal failures become indifferent; the original's selection rejected
  failed operators. When every guess in a nested tie fails, the rewrite still applies one of them
  and finds the failure one level later. On kenken-6-2, the only variant with nested ties, this
  gives more decisions on some runs.
- **Propagation stops once the goal holds.** The MEA proposals test the unachieved desired, so once
  the last cell is marked, the remaining cleanup and eliminate steps are no longer done before
  printing. In the original they were interleaved with print-row. The grid printed is the same.
- **Extra library output.** Library messages are printed: `Select <op>: ...` (agent-world
  monitor, log 1), `Evaluate operator: guess`, `Success (1) : D1`, `kenken achieved - success`
  and `kenken achieved all desireds`. selection-world also interrupts (not halts) when the goal is
  reached; the runner continues and the task halts after printing. The original output lines are
  all still there. No log lines were added to the task's silent operators.
- **Elaborations on copies.** World copies in look-ahead are i-supported. Application rules remove
  copied values with o-supported rejects, which works in this Soar.
- **Speed.** Kernel CPU time is about 3 to 5 times the original's: the world is copied object by
  object, the indexes are re-derived for each look-ahead state, and library rules are added.
- No chunks are learned, in either the original or the rewrite (chunk always is kept).

## Tests

`python3 tools/run.py <dir> <variant>.soar --seeds 1-3 --episodes 3 --cap 3000`, original vs rewrite.
There are no load errors and no runtime errors in either. The library load reports
"1 production excised, 2 ignored", which comes from duplicate rules in lib/world2.

| variant | orig success | orig decisions median (range) | orig CPU s | new success | new decisions median (range) | new CPU s |
|---|---|---|---|---|---|---|
| kenken-4-1 | 9/9 | 98 (97-98) | 0.03 | 9/9 | 98 (93-99) | 0.09 |
| kenken-4-2 | 9/9 | 96 (94-96) | 0.02 | 9/9 | 95 (93-97) | 0.06 |
| kenken-4-3 | 9/9 | 102 (102-102) | 0.03 | 9/9 | 101 (98-103) | 0.11 |
| kenken-4-4 | 9/9 | 99 (98-99) | 0.03 | 9/9 | 99 (97-100) | 0.07 |
| kenken-4-5 | 9/9 | 150 (134-152) | 0.10 | 9/9 | 144 (127-152) | 0.24 |
| kenken-4-6 | 9/9 | 94 (94-94) | 0.03 | 9/9 | 94 (89-95) | 0.08 |
| kenken-4-7 | 9/9 | 97 (97-97) | 0.03 | 9/9 | 96 (93-97) | 0.09 |
| kenken-5-1 | 9/9 | 180 (180-180) | 0.09 | 9/9 | 179 (178-181) | 0.30 |
| kenken-5-2 | 9/9 | 180 (180-180) | 0.09 | 9/9 | 179 (174-181) | 0.31 |
| kenken-5-3 | 9/9 | 178 (178-178) | 0.07 | 9/9 | 177 (170-179) | 0.30 |
| kenken-5-4 | 9/9 | 176 (175-176) | 0.07 | 9/9 | 175 (171-177) | 0.30 |
| kenken-5-5 | 9/9 | 190 (190-190) | 0.07 | 9/9 | 189 (185-191) | 0.34 |
| kenken-6-1 | 9/9 | 437 (428-438) | 0.85 | 9/9 | 436 (409-438) | 3.37 |
| kenken-6-2 | 9/9 | 795 (724-1074) | 3.13 | 9/9 | 914 (581-1324) | 16.59 |
| kenken-6-3 | 9/9 | 599 (489-603) | 1.04 | 9/9 | 598 (525-602) | 4.54 |
| kenken-6-4 | 9/9 | 473 (473-473) | 0.46 | 9/9 | 473 (471-474) | 2.85 |
Variants that need look-ahead: kenken-4-5, kenken-6-1 and kenken-6-3 (one tie), and kenken-6-2
(several ties, some nested). The others are solved by propagation alone. In all of them the
rewrite prints the same final grid as the original.
