# knights (impl-direct-world)

Built on lib/world2 (agent-world, simple.soar, selection-world, selection-iterative-deepening),
top state `^environment none`. initialize-knights.soar is generated from the original's
initialization (same board, same start square).

## knights-6, knights-8 (same structure)
Structural changes
- World: one object per square (handle = original square name, e.g. b23) with ^coord, ^used,
  ^degree, ^odeg, ^visit, ^tried, ^move <handle> (knight-move neighbours) and ^prev <handle>;
  one `tour` object with ^depth, ^moves, ^frame, ^solutions, ^goal, ^done, ^at <handle>,
  ^first <handle>. All links between objects are object-handle constants instead of
  identifiers (W-OBJ-002); rules join objects through ^object-handle.
- Goal: one desired object, tour ^done 1 (task ^achieved/^unachieved elaborations; agent-world
  ^success; task halt rule prints the original message + TASK-RESULT and halts).
- knight-move, backup (4 proposals in 6x6, 3 in 8x8), detect-goal, exhausted, finish-run are
  task operators: ^argument1 tour, ^argument2 current square, ^argument3 target / previous /
  first square, ^argument-count, ^super-desired (the tour desired), ^desireds count 0. MEA
  proposals test the unachieved desired and keep every original condition; internal
  application rules do the original's world changes (including the per-neighbour degree /
  tried updates) and print the original messages ("Success! n coord", "Search complete",
  "Run over").
- The original's search-control rules are kept as task preference rules (finish-run first,
  detect-goal before backup, backup before knight-move, lower degree (6x6: current degree,
  plus degree-one best except b23; 8x8: original degree)); proposals keep `=`. No look-ahead,
  as in the original.
- Init: binary preference task-init > initialize-agent-world (see other families); chunk never;
  softmax restored. The original's multi-attributes hint for ^square is dropped (no ^square).

Not kept / additions
- One extra decision (initialize-agent-world); TASK-RESULT line and library log lines added.

Test (seeds 1-3, 3 episodes, cap 3000)
- Neither the original nor the rewrite ends within 3000 decisions (the search runs to
  exhaustion or 1,000,000 moves): both 0/9 results, 3000 decisions (median 3000), no errors.
- Same behaviour in the trace: knights-6 seed 1, 3000 decisions: original 78 solutions
  printed, rewrite 80; seed 2: 73 vs 70 (first solutions identical, later ones differ by the
  random choice among indifferent moves). knights-8: seed 1 the same sequence of first
  solutions; seed 2 no solution in either.
