# left-right (impl-direct-world)

Built on lib/world2 (agent-world, simple.soar, selection-world, selection-iterative-deepening),
top state `^environment none`.

## left-right
Structural changes
- World object `agent` (^location 0, ^moved 0); goal as ^desireds: agent ^moved 1.
  Task init after initialize-agent-world, with the binary preference task-init >
  initialize-agent-world (agent-world's init stays acceptable/best until ^name exists).
- move is a task operator with one proposal per direction value (OPR-016): ^argument1 agent,
  ^argument2 -1 or 1 (a non-object argument), ^argument-count 2, ^super-desired, ^desireds
  count 0; MEA proposal on the unachieved desired, internal application (location <- direction,
  moved 1, prints "Moved: <direction>").
- RL kept as in the original: same template (now over the operator's ^argument1/^argument2 and
  the agent's location/moved), same rewards (-1 at location -1, +1 at location 1) on the top
  state's reward-link, read from the world; learning-rate 0.3, discount 0.9, epsilon-greedy
  (set after the libraries). ^flags.rl is NOT set, because agent-world's generic reward (1.0 at
  success) would add a reward the original does not give.
- Proposals keep the original's `=` (choice by RL values, no look-ahead).
- Goal test via task ^achieved/^unachieved elaborations + agent-world's ^success; task halt
  rule at the real top state.

Not kept / additions
- Extra output: `TASK-RESULT: success`, library log lines. One extra decision.

Test (seeds 1-3, 3 episodes, cap 3000)
- Original: 9/9 success, 2 decisions (median 2); RL rules 6, 6, 4.
- Rewrite:  9/9 success, 3 decisions (median 3); RL rules 6, 6, 4. No errors.
