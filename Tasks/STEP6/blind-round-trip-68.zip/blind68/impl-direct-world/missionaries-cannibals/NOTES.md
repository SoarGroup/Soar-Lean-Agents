# missionaries-cannibals: impl-direct-world (original -> world conventions, lib/world2, no environment)

Common to all four variants
- Load file sources lib/world2 agent-world, simple.soar, selection-world, selection-iterative-deepening
  (absolute paths), then the task files (mac-world.soar, mac-move-boat.soar, mac-search-control.soar,
  plus variant files).
- World: the two banks are world objects (handles left, right; ^anchored true) with constant
  properties ^missionaries ^cannibals ^boat and ^other-bank-handle (the original's ^other-bank
  identifier link became a handle so it survives the look-ahead copy).
- Goal: ^desireds with 2 object-property desireds (right ^missionaries 3, right ^cannibals 3),
  replacing the original's single ^desired.bank description (W-DES-005: one property per desired).
  Achieved/unachieved elaborations are task rules (W-DBK-002); success comes from agent-world's count rules.
- Failure: i-supported ^failure <desireds> when a bank has missionaries outnumbered (as the original).
- Top state: ^environment none, ^problem-space (mac, ^agent-world true), ^flags. The task's
  initialize operator is made better than initialize-agent-world (both are proposed once ^world exists).
- move-boat: task-action operator, one proposal per (missionaries, cannibals) combination (OPR-016),
  ^argument1 from-bank, ^argument2 to-bank, ^desireds.desired-count 0 (legality tested in the
  proposal, as in the original); one internal application rule that finds the banks by handle in
  the state's own world (needed because selection-world evaluates the uncopied tied operator), guarded
  by ^boat 1 on the from bank.
- End: the original messages ("The problem has been solved." / "Failure state: the task has failed.")
  plus `TASK-RESULT: success|failure`, then halt, at the top state. selection-world's own
  top-goal messages ("mac achieved - success", "mac failed") and agent-world log lines also print.
- Selection: the original makes every move indifferent. Kept as a task search-control rule that is
  active only with ^flags.look-ahead-planning false (mac, mac-rl); in the look-ahead variants the flag
  is true and the moves are left tied (W-TOP-024).
- One extra decision per episode (initialize-agent-world).

## mac
- Random indifferent moves until failure or success; chunk never.
- Test (seeds 1-3, 3 episodes, cap 3000): original 0/9 success, 9/9 failure, median 3 decisions;
  rewrite 0/9 success, 9/9 failure, median 4. Same behaviour (+1 init decision).

## mac-rl
- Same, plus RL: rl learning on, learning-rate 0.1, discount 0.5, epsilon-greedy, chunk never (as the
  original). Template rule over move-boat keyed on the operator's numbers and both banks' handle and
  contents (the original keyed on bank names and contents).
- Rewards: +1 on success from agent-world's reward rule (^flags.rl true, ^problem-space.agent-world true);
  task rules give -1 on failure and -0.01 per decision, as the original.
- Test: original 9/9 failure, median 3 decisions, RL rules 52/62/41; rewrite 9/9 failure, median 3,
  RL rules 52/62/51. Same behaviour.

## mac-look-ahead
- Look-ahead through selection-world instead of the original's own copy of the default selection
  space (the original's copy flags -- default-state-copy, two-level-attributes bank, dont-copy ancestor --
  have no counterpart: selection-world deep-copies the world by fixed rules, W-LAH-032).
  chunk always, add-osk on (as the original).
- Kept knowledge: failure on outnumbering; failure on a look-ahead situation that repeats an enclosing
  task state (^ancestor elaborations as in the original; the comparison is between world objects
  matched by handle). The original tested the selection library's ^tried-tied-operator to wait until
  the move had been applied in the look-ahead state; that attribute is reserved (W-NAM-012), so the
  move's application marks the look-ahead state (^real false) ^moved true and the test uses that.
- Could not keep directly: the original library turns a failure evaluation into a reject; selection-world
  makes it a worst preference (W-LAH-014). Nearest conforming means: in look-ahead the same failure
  conditions also elaborate ^constraint-failure <desireds> with a ^failure-string (W-LAH-023), which
  agent-world turns into a reject. It must be elaborated in the same wave as ^failure (testing the
  failure condition, not ^failure), otherwise the evaluation is complete and the substate gone before it
  arrives. Side effect from agent-world: when the tied state is the real top state it also puts a
  send-message command (i-supported) on the output-link.
- Test: original never ends (0/9, all 3000 decisions): after its first look-ahead it oscillates at the top
  between two situations because an overgeneral chunk from success-evaluation-becomes-best keeps
  preferring "move 2 missionaries back". Rewrite: 9/9 success; median 18 decisions (first episodes
  192/174/254, later episodes 13-18 with chunks; 11-move optimal solutions). Not the same outcome: the
  original's loop comes from its own selection library and chunks, and is not reproduced with
  selection-world. I did not add anything to force the loop.

## mac-look-ahead-numeric
- As mac-look-ahead plus the original's numeric evaluation: once the move has been applied in a
  look-ahead state, ^numeric-value = missionaries + cannibals on the right bank; the goal says
  ^desireds.better higher (selection-world puts it on ^desireds, W-DES-023).
- The reject-by-constraint-failure mapping above is essential here: without it, failing moves (which
  put more people on the right bank) got both a failure and the highest numeric value, and the
  numeric "better" preferences overrode the worst preference, so the agent walked into failure states
  (first attempt: 6/9 failure, 3 runs hit the cap).
- Test: original 9/9 success, median 30 decisions (first episodes 125/135/132); rewrite 9/9 success,
  median 27 (first episodes 162/170/168). Same behaviour.
