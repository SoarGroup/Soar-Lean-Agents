# pyramid: impl-direct-world (original -> world conventions, lib/world2, no environment)

Common
- Load file sources lib/world2 agent-world, simple.soar, selection-world, selection-iterative-deepening
  (absolute paths), then the task files. chunk never, as the originals.
- The original's state ^pyramid structure is a world object (handle pyramid, ^anchored true).
- Goal as ^desireds with one object-property desired; achieved/unachieved elaborations are task
  rules; success from agent-world's count rules.
- Top state: ^environment none, ^problem-space (^agent-world true), ^flags.look-ahead-planning false.
  The task's initialize operator is made better than initialize-agent-world.
- Operators: task operators with ^argument1 (the pyramid world object), ^argument-count,
  ^desireds.desired-count 0 (applicability tested in the proposal, as in the original), one internal
  application rule each, finding the pyramid by handle and re-testing the condition its change makes
  false (so it fires once while the operator stays selected).
- The original's "=" on every proposal is kept as a search-control rule for task operators while
  look-ahead planning is off.
- End: "The answer is <sum>." and "The problem has been solved." (original) plus `TASK-RESULT: success`,
  then halt. Each term still prints " + <term>" when it is added.
- One extra decision per episode (initialize-agent-world).

## pyramid
- add-next-term: task-action operator (argument1 = pyramid); sum += term, term -= 1, height -= 1.
  Goal: pyramid ^height -1. Start: term 5, height 10, sum 0.
- Test (seeds 1-3, 3 episodes, cap 3000): original 9/9 success, 12 decisions each; rewrite 9/9 success,
  13 decisions each; same answer (0). Same behaviour.

## pyramid-anderson
- Same program with height 2.
- Test: original 9/9 success, 4 decisions; rewrite 9/9 success, 5 decisions; same answer (12).

## pyramid-hierarchical
- expand-pyramid and sum-terms are complex composite task operators (^effect-desireds, no application
  of their own): agent-world gives their operator-implementation substates ^problem-space.name
  expand-pyramid / sum-terms and makes the effect-desireds the substate's ^desireds (pyramid ^height -1;
  pyramid ^summed 1). The original named the substates itself and passed ^pyramid down; now the
  substate shares the world.
- The proposals keep the original's i-supported "-relevant" elaborations so that the composite operator
  is not re-proposed (and its substate lost) each time a term is expanded.
- expand-next-term (task-action operator in expand-pyramid): creates a term world object (handle
  term-<index>, ^index ^value) -- the original put ^term structures on the top state -- and updates the
  pyramid.
- sum-terms implementation: init-local and add-term are internal operators (^task-operator false) on a
  local accumulator (^sum ^next) kept on the substate as in the original (it is reasoning state of the
  implementation, not task situation); final-sum is a task-action operator writing the sum and
  ^summed 1 to the pyramid.
- Test: original 9/9 success, 21 decisions; rewrite 9/9 success, 22 decisions; same answer (49), same
  operator sequence.
