# tictactoe: impl-direct-world (original -> world conventions, lib/world2, no environment)

## tictactoe
- Load file sources lib/world2 agent-world, simple.soar, selection-world, selection-iterative-deepening
  (absolute paths), then tictactoe-world.soar, tictactoe-operators.soar, tictactoe-monitor.soar.
  chunk never.
- World objects: 9 cells (handles c11..c33, ^type cell, ^x ^y ^xy ^content), 8 lines (handles row1..
  diagonal2, ^type line, ^cell-handle of their three cells -- the original linked lines to cell
  identifiers), the game (handle game: ^turn ^winner ^over). The original's state ^cell/^line/^game
  structures are gone from the state.
- Goal: ^desireds with one object-property desired (game ^over 1); achievement elaborations are task
  rules; success from agent-world's count rules. End: "The problem has been solved." plus
  `TASK-RESULT: success`, then halt.
- Top state: ^environment none, ^problem-space (TicTacToe, ^agent-world true),
  ^flags.look-ahead-planning false. The task's initialize operator is made better than
  initialize-agent-world.
- Operators mark (cell, game), x-wins (game, line), o-wins (game, line), detect-draw (game): task-action
  operators with ^argument1..2, ^desireds.desired-count 0 (legality tested in proposals, as in the
  original), internal application rules that find their objects by handle and re-test the condition
  they change. Messages "Side X won." / "Side O won." / "Draw." kept.
- Search control kept: x-wins and o-wins best; every task operator indifferent (as a rule active while
  look-ahead planning is off, instead of "=" in each proposal).
- Monitor kept (prints the board after every change); the display attribute ^shown is derived on the
  cell world objects (no look-ahead here, so no stale copies).
- Test (seeds 1-3, 3 episodes, cap 3000): original 9/9 success, median 9 decisions (7-11); rewrite 9/9
  success, median 10 (8-12). With the same seed the rewrite plays the same game as the original
  (checked for seed 1); +1 decision for initialize-agent-world.
