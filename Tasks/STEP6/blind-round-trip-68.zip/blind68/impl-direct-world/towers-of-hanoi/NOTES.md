# towers-of-hanoi: impl-direct-world (original -> world conventions, lib/world2, no environment)

Common
- Load file sources lib/world2 agent-world, simple.soar, selection-world, selection-iterative-deepening
  (absolute paths), then towers-of-hanoi-world.soar and move-disk.soar. chunk never.
- World objects: pegs A, B, C; disks 1..5, base-A/B/C (size 6) and ground (size 7) as in the original.
  The original's ^holds structures (disk, on peg, above disk) became world relations ^on (argument1 disk,
  argument2 peg) and ^above (argument1 disk, argument2 disk below), changed in place by move-disk.
  Derived ^clear true on disks (nothing above), on the world objects (no look-ahead, so no stale copies).
- Goal: ^desireds with 5 relation desireds (disk k ^on C); achievement of relation desireds is task
  rules; success from agent-world's count rules. End: "The problem has been solved." plus
  `TASK-RESULT: success`, then halt. "Move Disk: <size> to peg <peg>" printed for each move.
- Top state: ^environment none, ^problem-space (towers-of-hanoi, ^agent-world true), ^flags. The task's
  initialize operator is made better than initialize-agent-world. The original's "=" on each proposal is
  a search-control rule active while look-ahead planning is off.
- move-disk: task-action operator, ^argument1 disk, ^argument2 target peg; internal application finds the
  target's top disk and changes the disk's ^on and ^above relations; guarded by the disk's ^on still
  naming another peg.

## towers-of-hanoi
- The original's alternating strategy kept: proposal *1 (smallest disk, when the last move was not of
  it, not to the peg it last left) and *2 (another disk, right after the smallest moved), both with
  legality (disk clear, target's top disk larger) in the proposal (^desireds.desired-count 0).
- ^control (^lastsize, ^lastpeg -- now a peg handle) is the strategy's memory of the last move; it is kept
  on the top state, not in the world (W-WLD-011: state-control is not world).
- Test (seeds 1-3, 3 episodes, cap 3000): original 9/9 success, 32 decisions; rewrite 9/9 success, 33
  decisions (31 moves, +1 init). Same behaviour.

## towers-of-hanoi-mea
- ^flags.mea-operator-selection true; the three original proposals are MEA proposals testing an
  ^unachieved desired: *1 at the top (largest disk not on its goal peg when every larger one is),
  *2 and *3 in subgoals (clear the subgoal disk; clear smaller disks off the subgoal peg).
- Structure: as in the original, move-disk's applicability (disk clear, target top larger) is tested by
  its internal application rule, not by precondition desireds (^desireds.desired-count 0), and each
  move-disk carries ^effect-desireds {disk ^on target}. When it cannot apply, its operator no-change
  substate is agent-world's operator-implementation substate (problem space move-disk, ^desireds = the
  effect-desireds) -- the counterpart of the original's own subgoal with ^desired disk/peg -- and the
  selected operator above applies as soon as the subgoal moves make it applicable.
- Could not keep as conventions intend: I first wrote the preconditions as ^desireds (disk ^clear true,
  target ^open-for <size>), i.e. W-MEA-002 operator subgoaling. agent-world marks an operator's
  achieved precondition desireds with o-support (its rule tests the selected operator), so whenever a
  subgoal move undoes a precondition already achieved for an enclosing operator (common in this
  strategy: moving disk 1 onto the target of the enclosing "move 3"), Soar removes that subgoal
  (GDS violation) and the agent thrashed: no solution in 3000 decisions on any seed. The
  effect-desireds structure above avoids that (no o-supported achievement on the operators).
  This is a convention deviation (a task-action operator with ^effect-desireds and an internal
  application; W-COP describes effect-desireds for composite operators without application).
- Unused original structure dropped: the original MEA initialisation also creates ^control, which no
  MEA rule reads.
- Test: original 9/9 success, 47 decisions; rewrite 9/9 success, 59 decisions, 31 moves (optimal, same
  as the original). The extra decisions: +1 init, and impasses regenerated where a move applied in a
  subgoal removes that subgoal (GDS) instead of the original's applying two moves in one decision.
