# water-jug family: rewrite under the world conventions (impl-direct-world)

All variants are built on lib/world2 (agent-world, simple.soar, selection-world,
selection-iterative-deepening, sourced by absolute path) in no-environment mode.

## Common structure (all variants)

- **Initialization.** `initialize-water-jug` (^task-operator false) is proposed once agent-world
  has made ^world. It is made better than initialize-agent-world, which stays proposed (best)
  until the top state has a ^name. It creates:
  - ^name water-jug and ^environment none;
  - ^flags;
  - two world objects, `jug3` (^volume 3) and `jug5` (^volume 5), each with ^object-handle,
    ^anchored true and ^contents 0;
  - the goal as ^desireds with one desired, `^object (^object-handle jug3 ^contents 1)`, and
    ^desired-count 1.
- **Problem space.** Every state named water-jug, including look-ahead states, gets
  ^problem-space (^name water-jug, ^agent-world true).
- **Derived free capacity.** It is kept on the state (`^jug-free (^jug <obj> ^free n)`), not on
  the world object, so look-ahead copies of the world never carry a stale ^free.
- **Goal achievement.** The task supplies i-supported `^achieved` and `^unachieved` for
  object-property desireds. agent-world counts them and adds ^success.
- **Task operators.** `fill <jug>`, `empty <jug>` and `pour <from> <to>` carry ^task-operator
  true, ^action-handle, ^argument1..2, ^argument-count, ^super-desired (the goal desired) and
  ^desireds with ^desired-count 0 (no precondition desireds).
  - Each has one internal application rule. It tests ^internal-actions true and
    ^pre-conditions-satisfied true, and finds the jug in the state's own ^world by
    ^object-handle, so the same rule works at the top state and in look-ahead copies. It
    updates ^contents in the decision the operator is selected and logs the application.
  - Each rule has a guard (not full / not empty / free > 0), so it fires once per application.
  - There are no output commands.
- **Proposals are not MEA.** They keep the original's conditions: the moves do not achieve the
  goal desired directly, so MEA proposal (testing ^unachieved) cannot express this task.
- **End of episode.** The original halted from an elaboration at the goal. Here a non-task
  operator `report-success` is proposed at the real top state when agent-world gives
  ^success <desireds>. It prints the original's line `The problem has been solved.`, then
  `TASK-RESULT: success`, and halts.
  - This costs one extra decision.
  - The library also prints `water-jug achieved - success` / `achieved all desireds` and
    interrupts. The runner continues after the interrupt.
  - There is no failure end, as in the original.
- **Decision counts.** Every rewrite adds 2 decisions: initialize-agent-world and
  report-success. The library monitor and the application rules also print log lines.

## Variants

### water-jug: works

- **Structure:** as above. Proposals keep the `=` preference (random walk), as in the original.
- **Not kept:** nothing.
- **Test (seeds 1-3 × 3 episodes, cap 3000):**
  - rewrite: 9/9 successes, median 199 decisions;
  - original: 9/9 successes, median 197.
  - Same random sequence, +2 decisions per episode.

### water-jug-rl: works

- **Structure:** same RL settings (learning on, rate 0.1, discount 0.5, epsilon-greedy).
  - RL templates are per task operator over the involved jugs' ^volume and ^contents (world
    objects).
  - The reward of +1 at the goal comes from agent-world's reward rule (^flags.rl true,
    ^problem-space.agent-world true, ^success).
  - The reward of -1 when both jugs are empty is a task rule, as in the original.
- **Not kept:** the extra report-success decision means the last task operator gets its RL
  update, with the goal reward, when report-success is selected. In the original the agent
  halted first.
- **Test:**
  - rewrite: 9/9 successes, median 24, 51-60 RL rules;
  - original: 9/9 successes, median 22, 48-53 RL rules.

### water-jug-tie: works

- **Structure:** proposals have no preferences, so the operators tie. The original solved the
  tie in its own tie problem space, with an evaluate-operator per item plus create-preferences,
  using a heuristic on ^last-operator. Here:
  - The tie is handled by selection-world's selection space.
  - Task rules apply evaluate-operator directly in the selection state, with no look-ahead,
    from the superstate's ^last-operator: equal → `indifferent`, worst → `partial-failure`,
    best → `partial-success`.
  - selection-world turns these values into the =, < and > preferences.
  - ^last-operator is state-control information on the top state (not in ^world): initialized
    to none, updated once per task-operator application.
- **Not kept:** the original made all preferences at once (create-preferences). In
  selection-world, preferences appear as each evaluation gets a value, which has two effects:
  - A tie can be resolved before every item is evaluated.
  - An item made worst leaves the tie, and ID's remove-evaluation then removes its evaluation,
    so it can be evaluated again.
  - Together with init-remaining-operators (one decision per tie), this changes the decision
    count, but not which operator is chosen: it is uniform over the best class, as before.
- **Test:**
  - rewrite: 9/9 successes, median 173 (seeds 1-12: 36/36, median 111);
  - original: 9/9 successes, median 85 (seeds 1-12: 36/36, median 73).

### water-jug-tie-chunk: works

- **Structure:** as water-jug-tie, with chunk always and add-osk on. Chunks are learned over
  the selection space. They are preference rules on ^last-operator and the operator name: the
  same knowledge the original's chunks hold, plus binary-indifference chunks.
- **Not kept:** the chunk count differs: 6-8 here, 5 in the original.
- **Test:**
  - rewrite: 9/9 successes, median 24;
  - original: 9/9 successes, median 20.

### water-jug-hierarchy: works

- **Structure:**
  - `fill` is a composite task operator with no application rule and ^desireds count 0.
  - It is implemented in agent-world's operator-implementation substate
    (^problem-space.name fill). That substate gets ^argument1 and ^super-desired copied from
    the operator.
  - In the substate, the task-action operators pick-up, fill-jug and put-down have internal
    application rules.
  - Holding is the world relation ^holding-object. The empty hand is an object with
    ^object-handle none (the form selection-world copies).
  - The fill proposal keeps the original's two `fill-relevant` conditions: the jug is not full,
    or it is full and still held. So fill terminates when its proposal retracts, as in the
    original.
  - Substate rules read free capacity from the superstate, as the original read ^free on the
    jug.
- **Not kept:** no ^effect-desireds. agent-world makes the substate's ^desireds the same
  identifier as the operator's ^effect-desireds, so the task's i-supported achieved/unachieved
  elaborations in the substate become o-supported results. They went stale (an effect desired
  was marked achieved and unachieved at once) and would be chunked.
- **Test:**
  - rewrite: 9/9 successes, median 163;
  - original: 9/9 successes, median 161 (same sequence, +2).

### water-jug-hierarchy-chunk: works

- **Structure:** as hierarchy, with chunk always and add-osk on. It learns 3 chunks, as the
  original does: application chunks for pick-up, fill-jug and put-down under fill.
  - Reading ^superstate.jug-free keeps them general.
  - An earlier version used a local elaboration and learned one chunk per contents value.
- **Test:**
  - rewrite: 9/9 successes, median 67;
  - original: 9/9 successes, median 65 (same sequence, +2).

### water-jug-look-ahead: partly

- **Structure:**
  - Look-ahead uses selection-world in place of the original's classic default selection.
    selection-iterative-deepening is loaded but inactive: there is no ^flags.iterative-step,
    because the original search is depth-first and unbounded, not iterative deepening.
  - The evaluate-operator state is a hypothetical top state named water-jug, with a copied
    world and copied desireds.
  - The evaluated (original) operator is applied there by the same internal application rules,
    matching by handle.
  - Success is detected by agent-world from the task's achieved rules.
  - The original's duplicate-state failure is kept. ^ancestor elaborations compare the jugs'
    contents by handle with every ancestor water-jug state's world, after ^tried-tied-operator,
    and give `^partial-failure <own desireds>` (worst).
  - Same chunking settings (always, add-osk).
- **Not kept:**
  - Selection-space dynamics differ (library):
    - preferences appear as each evaluation gets a value;
    - an item made worst is removed from the tie and can be evaluated again (remove-evaluation);
    - two `success` evaluations get no binary indifference: selection-world's
      `same-symbolic-evaluations-are-indifferent*success` can never match, because its first
      condition excludes success. Such ties are resolved by simple.soar's
      state-no-change rule (=, <) after a no-change.
  - The chunks therefore differ, and the trajectories differ.
  - Both versions can fall into chunk-driven cycles that the ancestor test cannot see. The
    original cycles fill/empty/pour at the top state; the rewrite cycles fill/empty inside a
    look-ahead state.
- **Test:**
  - Seeds 1-3 × 3 episodes:
    - rewrite: 3/9 successes (seed 2: 272, 67, 12; seeds 1 and 3 hit the cap);
    - original: 6/9 successes (seed 1 hits the cap; seeds 2-3: 77/7/7 and 102/7/7).
  - Seeds 4-9, 1 episode each: both 3/6.
  - The success rate is comparable. Later-episode decision counts are higher in the rewrite.

### water-jug-look-ahead-failure-states: works

- **Structure:** as look-ahead, plus the original's two avoided states (both jugs full, both
  empty) as partial-failure on the look-ahead state.
- **Test:**
  - rewrite: 9/9 successes, median 22 (later episodes 7-30);
  - original: 9/9 successes, median 9 (later episodes 5-12).

### water-jug-look-ahead-rl: partly

- **Structure:** as look-ahead.
  - The two avoided states give `^expected-value -1` on the look-ahead state. selection-world
    makes this a numeric-indifferent preference on the evaluated operator, and those chunks
    become RL rules.
  - Same RL settings.
  - No reward rules, as in the original (^flags.rl is not set, so agent-world's reward rule is
    off).
- **Not kept:** the original's classic selection space produced many state-level
  expected-value chunks (10-22 RL rules). Here only 1-3 are learned. The classic copy and
  evaluation semantics (copying the jug list, value propagation within continuing evaluation
  states) are not reproduced by selection-world.
- **Test:**
  - rewrite: 7/9 successes, median 59 (seed 2 fails twice, then succeeds);
  - original: 8/9 successes, median 309.

## Library observations

- **initialize-agent-world** is proposed best until the top state has a ^name. The task's
  initialization must be made better than it, or it stays selected (operator no-change).
- **effect-desireds:** sharing ^effect-desireds as the implementation substate's ^desireds
  turns task achievement elaborations into o-supported results (stale; chunked).
- **selection-world:** `selection*compare*same-symbolic-evaluations-are-indifferent*success` is
  unreachable, because evaluation1 excludes success.
- **ID with no flags:**
  - init-remaining-operators still fires in every selection (one decision per tie).
  - remove-evaluation re-evaluates items that left the tie because of a worst preference.
- **Chunks over look-ahead** include agent-world's operator-desireds count and
  pre-conditions-satisfied elaborations as results. Some chunks also test
  ^top-state.environment none, so they do not transfer between real and look-ahead states.
