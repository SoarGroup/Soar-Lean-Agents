# wizards: impl-direct-world (original -> world conventions, lib/world2, no environment)

## wizards
- Load file sources lib/world2 agent-world, simple.soar, selection-world, selection-iterative-deepening
  (absolute paths), then wizards-world.soar, wizards-derived.soar, wizards-operators.soar,
  wizards-search-control.soar. chunk never.
- World: everything the original kept on the state is a world object with a handle and ^anchored true:
  the puzzle (handle puzzle: ^done ^nviews -- the original's state ^world structure; ^world now belongs
  to agent-world), views (^vid ^owner ^depth ^parent), recs (a wizard in a view: ^wiz ^mark ^var
  ^modeled [^aguess] ^view ^sib [^sub] [^mv]) and markvars (^value ^assigned ^untried). New views,
  recs and markvars get generated handles (view-<vid>, rec-<vid>-<wiz>, markvar-<rec>).
- Links between these objects (^view ^parent ^sib ^sub ^mv) stay object-valued attributes, as in the
  original (STA-029 allows object-valued links); they would not survive a look-ahead copy, but this
  program does no look-ahead. Likewise the derived properties (own, white, black, blackish, gwhite,
  gblack, contra) stay i-supported elaborations on the rec objects.
- Goal: ^desireds with one object-property desired (puzzle ^done 1); achievement elaborations are task
  rules; success from agent-world's count rules. End: "The problem has been solved." plus
  `TASK-RESULT: success`, then halt.
- Top state: ^environment none, ^problem-space (wizards, ^agent-world true),
  ^flags.look-ahead-planning false; task initialize made better than initialize-agent-world.
- Operators: all ten are task operators (^task-operator true) applied internally: the model of views is
  the situation this task works on, and marking them ^task-operator false would bring in agent-world's
  "non-task better than task" preference and change the original's ordering. Parameters became
  ^argument1..3 (at most 3, W-TOP-005); parameters that the application can find from the arguments
  (a rec's view, a view's parent, the recs of a view, the puzzle) were dropped: consider-knows has one
  argument instead of six, complement three plus ^u instead of six. Each application re-tests the
  condition its change falsifies. All messages kept.
- Search control: all the original preferences kept, rewritten on the arguments (e.g. prefer-deeper
  compares argument1.view / argument1.view.parent); the original's "=" on every proposal is a rule active
  while look-ahead planning is off.
- Test (seeds 1-3, 3 episodes, cap 3000): original 9/9 success, 18 decisions; rewrite 9/9 success, 19
  decisions (+1 init). Same operator sequence and the same ten messages, ending "Wizard 1 guesses his
  spot is white."
