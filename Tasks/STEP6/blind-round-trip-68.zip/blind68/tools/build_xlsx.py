import json
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
from openpyxl.utils import get_column_letter as L

d = json.load(open('/home/claude/blind68/results/collected.json'))
rows, raw = d['rows'], d['raw']
IMPLS = ['Original', 'Standard', 'World', 'World-NoEnv', 'Direct-Std', 'Direct-World']
NI = len(IMPLS)
F = 'Arial'
H = Font(name=F, bold=True, color='FFFFFF'); HF = PatternFill('solid', fgColor='1F6F6B')
B = Font(name=F); BB = Font(name=F, bold=True); T = Font(name=F, bold=True, size=14)
SUB = PatternFill('solid', fgColor='EDF2F1')
wrap = Alignment(wrap_text=True, vertical='top')

def header(ws, r, names, widths=None):
    for i, n in enumerate(names, 1):
        c = ws.cell(r, i, n); c.font = H; c.fill = HF; c.alignment = Alignment(wrap_text=True, vertical='center')
    if widths:
        for i, w in enumerate(widths, 1): ws.column_dimensions[L(i)].width = w

def fontall(ws):
    for row in ws.iter_rows():
        for c in row:
            if c.font is None or c.font.name != F:
                c.font = Font(name=F, bold=c.font.bold if c.font else False, size=c.font.size if c.font else 10, color=c.font.color if c.font else None)

notes_std = {
 'water-jug-look-ahead-rl': 'One episode unsolved at the cap, as the English predicts.',
 'water-jug-hierarchy': 'Fill proposed through one "fill-relevant" flag so it stays selected through its substate.',
 'mac-look-ahead': 'Solves on some seeds and loops on others (4 of 8 seeds solved; English: 1 of 8).',
 'count-in-substate': 'Needs about 75,000 decisions; run with cap 80,000.',
 'blocks-world-look-ahead': 'Learned rules cycle at the top level on some seeds.',
 'blocks-world-operator-subgoaling-chunk': 'Carry-out split into two rules to avoid an over-general chunk.',
 'blocks-world-epmem': 'Two default rules removed (the "tried" marking), as the English requires.',
 'blocks-world-hrl': 'One episode hit the cap while RL was still exploring.',
 'left-right': 'Two explicit RL rules instead of a template (the template duplicated rules after init-soar).',
 'knights-6': 'Search needs about 1,000,000 decisions; every run stops at the cap.',
 'knights-8': 'Search needs about 1,000,000 decisions; every run stops at the cap.',
 'arithmetic': 'Solves thousands of problems; runs to the cap. Value changes written as single actions to keep chunks correct.',
 'arithmetic-smem': 'Runs to the cap (1,000 problems).', 'arithmetic-smem-chunk': 'Runs to the cap (10,000 problems).',
 'arithmetic-smem-learn': 'Runs to the cap (2,000 problems).', 'arithmetic-v5': 'Runs to the cap (10,000 problems).',
 'fifteen-puzzle': 'Wanders without solving, as the English reports.',
 'eight-puzzle-expected-value': 'Near-random walk (softmax, temperature 25).',
}
notes_world2 = {
 'kenken-6-1': 'Same failing run as World: the goal test only counts filled cells.',
 'water-jug-look-ahead-failure-states': 'Partly: seed 1 cycles exactly as before.',
 'blocks-world-operator-subgoaling-chunk': 'Partly: the chunk is now learned (4 decisions in later episodes) but is over-general: in episode 2 A ends on both the table and B.',
 'left-right': 'Reward held back while goal-completed is selected (otherwise Soar-RL counts it twice).',
 'arithmetic-v5': 'borrow-from given ^desireds so its substate gets ^internal-actions (library gap since fixed).',
 'knights-6': 'Runs to the cap; finds about 3 times as many tours within it.',
 'knights-8': 'Runs to the cap, as before.',
 'count-in-substate': 'Needs about 75,000 decisions; run with cap 80,000.',
 'blocks-world-epmem': 'Look-ahead rules now test ^real false; real moves need their own application rules.',
 'blocks-world-hierarchical-lookahead': 'pick-up/put-down look-ahead rules test ^real false so the gripper level is not skipped.',
}
fam_world2 = {
 'arithmetic': 'World changes now test ^internal-actions true.',
 'blocks-world': 'Primitive actions applied when selected; excise of remove-command dropped; constraint-failure print-out excised.',
}
notes_world = {
 'mac-look-ahead': 'Solves every episode (original usually loops).',
 'kenken-6-1': 'Fails in some runs: the goal test only counts filled cells, so a wrong guess can pass look-ahead.',
 'blocks-world-operator-subgoaling-chunk': 'Learns no chunk: the subgoal move is an output command, which is not chunked.',
 'blocks-world-look-ahead': 'Moves re-identified after each real move to stop stale failure preferences.',
 'water-jug-look-ahead': 'Needs an added rule (not in the English) that avoids revisiting real situations.',
 'water-jug-look-ahead-failure-states': 'Partly: a learned rule cycles on one seed.',
 'water-jug-hierarchy': 'Hierarchy steps change the world directly (output rules block chunking).',
 'water-jug-hierarchy-chunk': 'Hierarchy steps change the world directly (output rules block chunking).',
 'count-in-substate': 'Needs about 75,000 decisions; run with cap 80,000.',
 'knights-6': 'Search needs about 1,000,000 decisions; every run stops at the cap.',
 'knights-8': 'Search needs about 1,000,000 decisions; every run stops at the cap.',
 'blocks-world-rl': 'RL slow and noisy within 3 episodes.',
 'blocks-world-hrl': 'RL noisy; 35/36 solved over 6 seeds x 6 episodes (cap 6,000).',
 'blocks-world-hierarchical-lookahead': 'Failed candidates get worst, not reject; success only beats failure.',
}
fam_world = {
 'arithmetic': 'No search libraries loaded; task operators change ^world directly (no external world).',
 'kenken': 'Links between cells by name constants (look-ahead copies one level); failure gives worst, not reject.',
 'blocks-world': 'Library rules excised or replaced (wait tie, selection-world and iterative-deepening failure rules, depth-exceeded chunks).',
 'eight-puzzle': 'Library error rule for more than 6 desireds excised; task detects success itself.',
 'missionaries-cannibals': 'Library failure gives worst; a task rule rejects instead.',
}

notes_dstd = {
 'water-jug-rl': 'Kept :template RL rules and = against RL-020/RL-019; following them slowed or stopped learning.',
 'water-jug-tie': 'Tie preferences now from i-supported rules, not an operator application (EVA-012).',
 'blocks-world-rl': 'Kept = (RL-019): template RL rules made after init-soar are malformed in this Soar build.',
 'blocks-world-hrl': 'Kept = for the same template reason as blocks-world-rl.',
 'blocks-world-hrl-3level': 'Slower learning: the original relies on a Soar quirk (dropped removal leaves several ^above values); the rewrite keeps ^above single-valued.',
 'blocks-world-epmem': 'One library rule excised in a documented file, as the original did.',
 'tictactoe': 'One win operator per line instead of six copies; later random games differ.',
 'left-right': 'Template RL rule written as two explicit rules.',
 'arithmetic-smem-learn': 'Original store rules had unconnected conditions; bound to the right states.',
}
notes_dworld = {
 'water-jug-look-ahead': 'Partly: 3/9 vs 6/9 on seeds 1-3; both versions can loop on learned chunks.',
 'water-jug-look-ahead-rl': 'Partly: 1-3 RL rules vs 10-22; selection-world does not pass values up like the original selection space.',
 'water-jug-tie': 'Custom tie space became evaluation rules in selection-world; more decisions per tie, same choices.',
 'mac-look-ahead': 'Solves (9/9, optimal 11 moves) where the original loops on an over-general chunk.',
 'towers-of-hanoi-mea': 'Preconditions not written as precondition goals: the standard form thrashed (goal-dependency set removals).',
 'kenken-6-2': 'Failed guesses are worst, not rejected, in selection-world; more decisions (median 914 vs 795).',
 'blocks-world-epmem': 'With ^better, partial success is not made best, so every tied move is evaluated (median 1086 vs 389).',
 'blocks-world-rl': 'RL features made constant: template rules over several world objects are malformed.',
 'blocks-world-hrl': 'RL features made constant, as blocks-world-rl.',
 'eight-puzzle': 'Goal of 9 cell-tile pairs held as one desired on a board object (library limit of 6 desireds).',
 'fifteen-puzzle': 'Goal of 16 pairs held as one desired on a board object.',
}

wb = Workbook()
# README
ws = wb.active; ws.title = 'README'
txt = [
 ('68 generated agents rewritten under two convention sets: blind round trip through English, and direct Soar -> Soar', T),
 ('Built 9 November 2026; direct rewrites added 10 November 2026.', B), ('', B),
 ('Method', BB),
 ('1. Soar -> English. For each of the 68 variants (14 families), an agent that could read only that Soar program wrote an English description.', B),
 ('2. English -> Soar, standard conventions ("Standard"). A separate agent that could read only the English, the standard Soar conventions and Soar\'s default selection rules wrote a new program.', B),
 ('3. English -> Soar, world conventions ("World"). Another separate agent, with the English, the world conventions and the world libraries (agent-world, simple.soar, selection-world, selection-iterative-deepening), wrote a third program.', B),
 ('4. "Original" is the generated variant the English was written from.', B),
 ('5. "World-NoEnv": the World programs converted (by agents that read the World program and its English) to a proposed agent-world mode for tasks with no external environment: the top state has ^environment none, every state has ^internal-actions true, and each task operator updates ^world as it is applied. No output commands, one decision per real action. Library copy: lib/world2.', B),
 ('6. Direct rewrites, no English in between. "Direct-Std": an agent that could read only the original program, the standard conventions and the default selection rules rewrote it under the standard conventions, keeping its behaviour. "Direct-World": the same under the world conventions in no-environment mode (lib/world2; one decision per real action). Twelve agents, one per family group and convention set.', B),
 ('7. Every program was run in Soar 9.6.50 (soar_sml): 3 seeds x 3 episodes, cap 3,000 decisions per episode (count-in-substate: 80,000). Episodes 2-3 follow init-soar in the same agent, keeping learned rules and RL values. A generic environment marks every output-link command complete.', B),
 ('', B), ('Columns', BB),
 ('Task rules: user productions loaded (Original blocks-world-hrl-3level includes 4,600+ generated RL rules). Library rules: :default productions loaded. Excised library rules: library rules the program removes with excise.', B),
 ('Success / failure: episodes ending in the task\'s success or failure message (of 3 per seed set). Halted: episodes that ended by halting rather than at the cap.', B),
 ('Decisions, kernel CPU seconds, wall seconds, production firings, WM changes (additions + removals) and maximum WM size: means over the 3 seeds for episode 1 and episode 3. Runs shared 2 CPUs, so wall times are inflated; kernel CPU time is the better speed measure. Chunks: learned rules at the end of the episode. RL rules: rules listed by print --rl after the run (mean over seeds).', B),
 ('', B), ('Caveats', BB),
 ('World programs act through output commands; with this test environment (which only acknowledged commands) each real action took 3 decisions (select, operator no-change, state no-change). None of the 68 tasks has an external environment; World-NoEnv removes this cost.', B),
 ('Variants that solve thousands of problems (arithmetic, smem variants, v5) or search for a million moves (knights) run to the cap in every version; their success counts are 0 by design.', B),
 ('The Original programs print their own messages; success and failure were read from "The problem has been solved" and failure messages.', B),
 ('Sheets: Summary (totals by implementation), By family, Comparison (one row per variant, the three versions side by side), Results (one row per version), Episodes (every seed and episode), Library findings.', B),
]
for i, (t, f) in enumerate(txt, 1):
    c = ws.cell(i, 1, t); c.font = f; c.alignment = Alignment(wrap_text=True, vertical='top')
ws.column_dimensions['A'].width = 130

# Results (long)
R = wb.create_sheet('Results')
cols = [('Implementation', 'impl', 12), ('Family', 'family', 20), ('Variant', 'variant', 34), ('Task rules', 'user_rules', 10), ('Library rules', 'library_rules', 10),
        ('Excised library rules', 'excised_library_rules', 10), ('Source files', 'source_files', 9), ('Source lines', 'source_lines', 9), ('Load errors', 'load_errors', 8),
        ('Runtime errors', 'runtime_errors', 8), ('Warnings', 'warnings', 8), ('Seeds', 'seeds_run', 7),
        ('Ep1 success', 'ep1_success', 8), ('Ep1 failure', 'ep1_failure', 8), ('Ep1 halted', 'ep1_halted', 8), ('Ep1 decisions (mean)', 'ep1_decisions', 11),
        ('Ep1 kernel CPU s (mean)', 'ep1_cpu_s', 11), ('Ep1 wall s (mean)', 'ep1_wall_s', 10),
        ('Ep1 production firings (mean)', 'ep1_firings', 11), ('Ep1 WM changes (mean)', 'ep1_wme_changes', 11), ('Ep1 WM size max (mean)', 'ep1_wm_max', 10),
        ('Ep3 success', 'ep3_success', 8), ('Ep3 failure', 'ep3_failure', 8), ('Ep3 halted', 'ep3_halted', 8), ('Ep3 decisions (mean)', 'ep3_decisions', 11),
        ('Ep3 kernel CPU s (mean)', 'ep3_cpu_s', 11), ('Chunks after ep1 (mean)', 'ep1_chunks', 10), ('Chunks after ep3 (mean)', 'ep3_chunks', 10), ('RL rules (mean)', 'rl_rules', 9), ('Notes', None, 70)]
header(R, 1, [c[0] for c in cols], [c[2] for c in cols])
order = {k: i for i, k in enumerate(IMPLS)}
rows_sorted = sorted(rows, key=lambda r: (r['family'], r['variant'], order[r['impl']]))
for i, r in enumerate(rows_sorted, 2):
    for j, (_, k, _) in enumerate(cols, 1):
        if k: v = r.get(k)
        else:
            if r['impl'] == 'Standard': v = notes_std.get(r['variant'], '')
            elif r['impl'] == 'World': v = ' '.join(x for x in [notes_world.get(r['variant'], ''), fam_world.get(r['family'], '')] if x)
            elif r['impl'] == 'World-NoEnv': v = ' '.join(x for x in ['No output commands; one decision per real action.', notes_world2.get(r['variant'], ''), fam_world2.get(r['family'], '')] if x)
            elif r['impl'] == 'Direct-Std': v = notes_dstd.get(r['variant'], '')
            elif r['impl'] == 'Direct-World': v = ' '.join(x for x in ['One decision per real action; +1 decision for agent-world initialization.', notes_dworld.get(r['variant'], '')] if x)
            else: v = ''
        c = R.cell(i, j, v); c.font = B
R.freeze_panes = 'D2'; R.auto_filter.ref = f'A1:{L(len(cols))}{len(rows_sorted)+1}'
NR = len(rows_sorted) + 1
col = {c[1]: L(i) for i, c in enumerate(cols, 1) if c[1]}

def rng(k): return f"Results!${col[k]}$2:${col[k]}${NR}"

# Comparison (wide)
C = wb.create_sheet('Comparison', 1)
metrics = [('Task rules', 'user_rules', '0'), ('Ep1 success (of 3)', 'ep1_success', '0'), ('Ep3 success (of 3)', 'ep3_success', '0'),
           ('Ep1 decisions', 'ep1_decisions', '#,##0'), ('Ep3 decisions', 'ep3_decisions', '#,##0'), ('Ep1 CPU s', 'ep1_cpu_s', '0.000'),
           ('Ep1 WM changes', 'ep1_wme_changes', '#,##0'), ('Chunks after ep3', 'ep3_chunks', '0'), ('Excised library rules', 'excised_library_rules', '0')]
C.cell(1, 1, 'Family').font = H; C.cell(1, 2, 'Variant').font = H
C.cell(1, 1).fill = HF; C.cell(1, 2).fill = HF; C.cell(2, 1).fill = HF; C.cell(2, 2).fill = HF
c0 = 3
for m, k, fmt in metrics:
    C.merge_cells(start_row=1, start_column=c0, end_row=1, end_column=c0 + NI - 1)
    h = C.cell(1, c0, m); h.font = H; h.fill = HF; h.alignment = Alignment(horizontal='center')
    for j, im in enumerate(IMPLS):
        x = C.cell(2, c0 + j, im); x.font = H; x.fill = HF
    c0 += NI
for t, w in (('Notes: Standard', 50), ('Notes: World', 70), ('Notes: World-NoEnv', 60), ('Notes: Direct-Std', 60), ('Notes: Direct-World', 60)):
    x = C.cell(1, c0, t); x.font = H; x.fill = HF; C.cell(2, c0).fill = HF; C.column_dimensions[L(c0)].width = w; c0 += 1
C.column_dimensions['A'].width = 20; C.column_dimensions['B'].width = 34
var_list = sorted({(r['family'], r['variant']) for r in rows})
for i, (fam, v) in enumerate(var_list, 3):
    C.cell(i, 1, fam).font = B; C.cell(i, 2, v).font = B
    c0 = 3
    for m, k, fmt in metrics:
        for j, im in enumerate(IMPLS):
            f = f'=SUMIFS({rng(k)},Results!$A$2:$A${NR},"{im}",Results!$C$2:$C${NR},$B{i})'
            x = C.cell(i, c0 + j, f); x.font = B; x.number_format = fmt
            if j == 0: x.fill = SUB
            C.column_dimensions[L(c0 + j)].width = 9
        c0 += NI
    C.cell(i, c0, notes_std.get(v, '')).font = B
    C.cell(i, c0 + 1, ' '.join(x for x in [notes_world.get(v, ''), fam_world.get(fam, '')] if x)).font = B
    C.cell(i, c0 + 2, ' '.join(x for x in [notes_world2.get(v, ''), fam_world2.get(fam, '')] if x)).font = B
    C.cell(i, c0 + 3, notes_dstd.get(v, '')).font = B
    C.cell(i, c0 + 4, notes_dworld.get(v, '')).font = B
C.freeze_panes = 'C3'
last_c = len(var_list) + 2

# Summary
S = wb.create_sheet('Summary', 0)
S['A1'] = 'Totals by implementation (68 variants each)'; S['A1'].font = T
header(S, 3, ['Measure'] + IMPLS + ['How computed'], [44] + [12] * NI + [60])
A = f'Results!$A$2:$A${NR}'
summ = [
 ('Variants run', 'COUNTIFS({A},"{im}")', 'count of Results rows', '0'),
 ('Variants with load errors', 'COUNTIFS({A},"{im}",' + rng('load_errors') + ',">0")', '', '0'),
 ('Runtime errors (all episodes)', 'SUMIFS(' + rng('runtime_errors') + ',{A},"{im}")', '', '0'),
 ('Task rules (total)', 'SUMIFS(' + rng('user_rules') + ',{A},"{im}")', 'Original includes 4,600+ generated RL rules in blocks-world-hrl-3level', '#,##0'),
 ('Task rules excluding blocks-world-hrl-3level', 'SUMIFS(' + rng('user_rules') + ',{A},"{im}")-SUMIFS(' + rng('user_rules') + ',{A},"{im}",Results!$C$2:$C$' + str(NR) + ',"blocks-world-hrl-3level")', 'Original and both Direct versions keep its 4,600 enumerated RL rules; the English-based rebuilds use templates', '#,##0'),
 ('Task rules (median per variant)', 'MEDIAN(IF({A}="{im}",' + rng('user_rules') + '))', 'array formula', '0'),
 ('Variants loading library rules', 'COUNTIFS({A},"{im}",' + rng('library_rules') + ',">0")', '', '0'),
 ('Excised library rules (total)', 'SUMIFS(' + rng('excised_library_rules') + ',{A},"{im}")', 'library rules removed by the programs', '0'),
 ('Source lines (total, excluding libraries)', 'SUMIFS(' + rng('source_lines') + ',{A},"{im}")', '', '#,##0'),
 ('Episode-1 successes (of 204)', 'SUMIFS(' + rng('ep1_success') + ',{A},"{im}")', '68 variants x 3 seeds', '0'),
 ('Episode-3 successes (of 204)', 'SUMIFS(' + rng('ep3_success') + ',{A},"{im}")', '', '0'),
 ('Variants solving all 3 seeds in episode 1', 'COUNTIFS({A},"{im}",' + rng('ep1_success') + ',3)', '', '0'),
 ('Variants never solving in episode 1', 'COUNTIFS({A},"{im}",' + rng('ep1_success') + ',0)', 'includes run-to-cap variants (arithmetic, knights, ...)', '0'),
 ('Episode-1 decisions (median of variant means)', 'MEDIAN(IF({A}="{im}",' + rng('ep1_decisions') + '))', 'array formula; World about 3x per action by protocol', '#,##0'),
 ('Episode-3 decisions (median of variant means)', 'MEDIAN(IF({A}="{im}",' + rng('ep3_decisions') + '))', 'array formula', '#,##0'),
 ('Episode-1 kernel CPU s (total of variant means)', 'SUMIFS(' + rng('ep1_cpu_s') + ',{A},"{im}")', '', '0.00'),
 ('Decisions per kernel CPU second (episode 1)', 'SUMIFS(' + rng('ep1_decisions') + ',{A},"{im}")/SUMIFS(' + rng('ep1_cpu_s') + ',{A},"{im}")', 'total decisions / total kernel CPU, all variants', '#,##0'),
 ('Decisions per kernel CPU second (median of variants, episode 1)', 'MEDIAN(IF({A}="{im}",IF(' + rng('ep1_cpu_s') + '>0,' + rng('ep1_decisions') + '/' + rng('ep1_cpu_s') + ')))', 'array formula; variants under 1 ms CPU excluded', '#,##0'),
 ('Episode-1 WM changes (median of variants)', 'MEDIAN(IF({A}="{im}",' + rng('ep1_wme_changes') + '))', 'array formula', '#,##0'),
 ('Episode-1 WM changes (total of variant means)', 'SUMIFS(' + rng('ep1_wme_changes') + ',{A},"{im}")', 'additions + removals', '#,##0'),
 ('WM changes per decision (episode 1)', 'SUMIFS(' + rng('ep1_wme_changes') + ',{A},"{im}")/SUMIFS(' + rng('ep1_decisions') + ',{A},"{im}")', '', '0.0'),
 ('Episode-1 production firings (total of variant means)', 'SUMIFS(' + rng('ep1_firings') + ',{A},"{im}")', '', '#,##0'),
 ('Chunks after episode 3 (total of variant means)', 'SUMIFS(' + rng('ep3_chunks') + ',{A},"{im}")', '', '#,##0'),
 ('Variants that learn chunks', 'COUNTIFS({A},"{im}",' + rng('ep3_chunks') + ',">0")', '', '0'),
]
from openpyxl.worksheet.formula import ArrayFormula
for i, (lab, f, how, fmt) in enumerate(summ, 4):
    S.cell(i, 1, lab).font = B; S.cell(i, 2 + NI, how).font = B
    for j, im in enumerate(IMPLS):
        cell = S.cell(i, 2 + j)
        formula = '=' + f.format(A=A, im=im)
        if 'MEDIAN(IF' in f:
            cell.value = ArrayFormula(cell.coordinate, formula)
        else:
            cell.value = formula
        cell.font = B; cell.number_format = fmt
r0 = 4 + len(summ) + 1
S.cell(r0, 1, 'Reading it').font = BB
for k, t in enumerate([
 'All three versions of every variant load without errors and run without runtime errors.',
 'The blind rebuilds solve as often as the originals; the World versions fix some original failures (mac-look-ahead, blocks-world-look-ahead) and fail in a few places of their own (kenken-6-1, one water-jug look-ahead variant).',
 'The Standard rebuilds are the most compact. The World versions need more task rules and lines (world, desireds, task operators, environment response) and, for search, library changes (excised rules).',
 'World decision counts were inflated about 3x by issuing output commands to a test environment; World-NoEnv (world updated as each operator is applied) brings them in line with Original and Standard.',
 'Direct rewrites (no English) keep the originals\' behaviour more closely: Direct-Std matches decision counts exactly in most variants; Direct-World is within one or two decisions except where selection-world differs from the original selection space (look-ahead, RL through look-ahead, epmem, kenken-6-2).',
 'Direct rewrites keep detail the English summarised: enumerated RL rules, exact random choice structure, and quirks the agents chose to reproduce or record. Both solve as often as the originals (168 and 170 episode-1 successes).'], 1):
    c = S.cell(r0 + k, 1, t); c.font = B
    S.merge_cells(start_row=r0 + k, start_column=1, end_row=r0 + k, end_column=2 + NI); c.alignment = Alignment(wrap_text=True)
    S.row_dimensions[r0 + k].height = 30

# By family
Fm = wb.create_sheet('By family', 1)
fams = sorted({r['family'] for r in rows})
hdr = ['Family', 'Variants'] + [f'Task rules: {im}' for im in IMPLS] + [f'Ep1 successes: {im}' for im in IMPLS] + [f'Ep1 decisions (sum of means): {im}' for im in IMPLS] + [f'Excised: {im}' for im in IMPLS]
header(Fm, 1, hdr, [22, 9] + [11] * (4 * NI))
FAM = f'Results!$B$2:$B${NR}'
for i, fam in enumerate(fams, 2):
    Fm.cell(i, 1, fam).font = B
    Fm.cell(i, 2, f'=COUNTIFS({FAM},A{i},{A},"Original")').font = B
    c = 3
    for k in ('user_rules', 'ep1_success', 'ep1_decisions', 'excised_library_rules'):
        for im in IMPLS:
            x = Fm.cell(i, c, f'=SUMIFS({rng(k)},{FAM},$A{i},{A},"{im}")'); x.font = B; x.number_format = '#,##0'; c += 1
n = len(fams) + 2
Fm.cell(n, 1, 'Total').font = BB
for c in range(2, len(hdr) + 1):
    x = Fm.cell(n, c, f'=SUM({L(c)}2:{L(c)}{n-1})'); x.font = BB; x.number_format = '#,##0'
Fm.freeze_panes = 'C2'

# Episodes
E = wb.create_sheet('Episodes')
ecols = ['impl', 'family', 'variant', 'seed', 'episode', 'result', 'halted', 'decisions', 'kernel_cpu_s', 'wall_s', 'chunks', 'runtime_errors', 'warnings']
header(E, 1, ['Implementation', 'Family', 'Variant', 'Seed', 'Episode', 'Result', 'Halted', 'Decisions', 'Kernel CPU s', 'Wall s', 'Chunks', 'Runtime errors', 'Warnings'], [12, 20, 34, 6, 8, 9, 8, 10, 10, 9, 8, 8, 8])
for i, e in enumerate(sorted(raw, key=lambda e: (e['family'], e['variant'], order[e['impl']], e['seed'], e['episode'])), 2):
    for j, k in enumerate(ecols, 1):
        v = e.get(k); v = '' if v is None else v
        E.cell(i, j, v).font = B
E.freeze_panes = 'D2'; E.auto_filter.ref = f'A1:M{len(raw)+1}'

# Library findings
Lb = wb.create_sheet('Library findings')
header(Lb, 1, ['Library', 'Finding (reported by the World rebuild agents)', 'Found in', 'Workaround used'], [24, 80, 30, 50])
finds = [
 ('simple.soar + agent-world', 'Both propose a wait operator in a state no-change; the two tie.', 'blocks-world, towers-of-hanoi-mea', 'Excise one, or make them indifferent'),
 ('selection-world', 'A failure rule marks every evaluation in the selection as failed, not only the current one.', 'blocks-world', 'Replaced'),
 ('selection-iterative-deepening', 'Two failure rules mark the evaluation one level up as failed.', 'blocks-world', 'Replaced'),
 ('selection-iterative-deepening', 'Depth-exceeded results are learned as chunks that block later searches.', 'blocks-world', 'Rule re-added to test quiescence'),
 ('selection-iterative-deepening', 'No rule for a nested selection whose evaluations are all depth-limited.', 'blocks-world', 'Rule added'),
 ('selection-world', 'No pass-up of partial success from nested searches.', 'water-jug look-ahead variants', 'Rule added'),
 ('simple.soar', 'default*select*indifferent-and-worst*tied lets nested look-ahead continue with a random operator.', 'water-jug look-ahead variants', 'Excised'),
 ('agent-world', 'Its initialize operator stays proposed until the top state has a name and ties with the task\'s initialize operator.', 'most families', 'Task initialize made better'),
 ('agent-world', 'goal-completed does not halt the agent.', 'small families', 'Task rule prints and halts'),
 ('agent-world', 'Command-removal rule fires at the top level before a substate operator can respond to completion.', 'blocks-world', 'Excised'),
 ('agent-world', 'Error rule for more than 6 desireds prevents goals with 9 or 16 items.', 'eight-puzzle', 'Excised; task detects success'),
 ('agent-world (look-ahead)', 'Operators are not copied: success in look-ahead can satisfy a real operator\'s precondition subgoal (seen earlier in three-wizards).', 'earlier test', 'Avoid precondition subgoals under look-ahead'),
 ('selection-world', 'Failure gives worst, not reject; with ^better, success only counts with a numeric value.', 'kenken, mac, blocks-world', 'Task reject rules / success-best rule'),
 ('agent-world (external application)', 'The one-argument external application rules did not test ^internal-actions false.', 'no-environment conversion', 'Test added in lib/world2'),
 ('agent-world (no environment)', 'With ^environment none every state has ^internal-actions true, so it no longer marks an imagined state; tasks need a real/imagined flag from the library.', 'blocks-world, water-jug', 'Task rules test ^real false'),
 ('agent-world (no environment)', 'Messages printed by application rules also print during look-ahead.', 'small families, blocks-world', 'Messages kept out of look-ahead tasks'),
 ('agent-world (no environment)', 'A composite operator\'s look-ahead application rule fires in the real world and bypasses its substate.', 'blocks-world hierarchical-lookahead', 'Look-ahead rules test ^real false'),
 ('agent-world', '^internal-actions reached a state only through ^problem-space, so substates of operators without ^desireds lacked it.', 'arithmetic-v5', 'Library rule added in lib/world2'),
 ('agent-world', 'selection*select*constraint-failure-print-out writes send-message to the output-link with no environment.', 'blocks-world', 'Excised'),
 ('agent-world', 'Internal application leaves ^task-operator-applied true on the real top state for good.', 'water-jug', 'None needed there'),
 ('agent-world + Soar-RL', 'goal-completed has no learned value, so a state-based reward after the last action is counted twice.', 'left-right', 'Reward held back during goal-completed'),
 ('Soar 9.6.50 (unconfirmed)', 'Some RL template rules created after init-soar have contradictory conditions.', 'mac-rl', 'To investigate'),
 ('agent-world', 'initialize-agent-world tests only -^name, so it stays proposed after building ^world; a look-ahead can apply it again and give the top state two worlds.', 'artists-managers; direct rewrites (all families)', 'Task rejects it once ^world exists; library fix: test -^world'),
 ('selection-iterative-deepening', 'The look-ahead limit is a constant (7; 10 only with ^flags.verify true, which has other effects).', 'artists-managers', 'Task selection-space operator raises it'),
 ('selection-iterative-deepening', 'With ^iterative-step operator, depth is decremented once per evaluation state (-^applied-lookahead true); in no-environment mode many operators apply in one state, so depth stays near 2.', 'artists-managers', 'Guard per operator in a local copy'),
 ('selection-world', 'Look-ahead copies world objects but not identifier links between them; links point back into the real world.', 'kenken (Direct-World)', 'Links held as handles'),
 ('selection-world', 'The rule meant to make two success evaluations indifferent can never fire; such ties settle only after a state no-change.', 'water-jug (Direct-World)', 'None'),
 ('selection-iterative-deepening', 'init-remaining-operators adds a decision to every tie even when iterative deepening is not used.', 'water-jug, eight-puzzle (Direct-World)', 'None'),
 ('agent-world', '^effect-desireds shared with the substate: achieved/unachieved elaborations become o-supported results that go stale and are chunked; in blocks-world the substate is rebuilt on every gripper change.', 'water-jug, blocks-world (Direct-World)', '^effect-desireds removed on sub-operators'),
 ('selection-world', 'A look-ahead that reaches the goal is only kept from being worst; the older library made it best.', 'eight-puzzle (Direct-World)', 'None needed'),
 ('Soar 9.6.50', 'Structure built on a superstate operator from a substate becomes a substate result; removing it when a tie resolved crashed the kernel (remove_preference_from_tm).', 'artists-managers', 'Predictions kept on the state'),
]
for i, f in enumerate(finds, 2):
    for j, v in enumerate(f, 1):
        c = Lb.cell(i, j, v); c.font = B; c.alignment = wrap

for ws in wb.worksheets:
    for row in ws.iter_rows():
        for c in row:
            if c.font and c.font.name != F:
                c.font = Font(name=F, bold=c.font.b, size=c.font.sz, color=c.font.color)
wb.save('/home/claude/blind68/out/Blind-Round-Trip-68.xlsx')
print('saved')
