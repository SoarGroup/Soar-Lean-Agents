import Agent.DSL
import Soar.Syntax
/-!
# From a description to productions of the Soar specification

`compile a` gives the files of a VisualSoar project, each with productions of the Soar
specification (`Soar.Production`) and the commands it needs. Printing uses the specification's own
printer (`Soar.Production.toSoar`), so every generated rule is one the specification can parse and
run.

Layout (VisualSoar):
* `_firstload.soar` — commands (learning, multi-attributes)
* `elaborations/` — derived attributes, goal detection, problem space, ancestors
* `initialize-<task>.soar` — the initialization operator
* `<op>.soar` — one file per operator; an operator carried out in a substate also has a folder
  `<op>/` with one file per step
* `Impasse__Operator_Tie.soar`, `Impasse__Operator_Tie/` — the tie space of `tieHeuristic`
* `rl.soar` — RL templates and rewards
* `elaborations/failure.soar` — failure states (`Agent.failure`)
* `elaborations/last-move.soar`, `preferences.soar` — the last task operator and the
  search-control preference rules (`Agent.prefs`)
-/
namespace Agent
open Soar

/-- A file of the generated project. `kind` is the VisualSoar node type. -/
structure GenFile where
  path : String
  kind : String
  prods : List Production := []
  cmds : List String := []

/-! ## Small constructors -/

def vt (x : String) : Test := [.var x]
def ct (x : String) : Test := [.const (.str x)]
def itest (n : Int) : Test := [.const (.int n)]
def pp (i a : String) (val : Test) : Pat := { id := vt i, attr := ct a, val := val }
def P (i a : String) (val : Test) : Cond := .pos (pp i a val)
def Ps (i a : String) (val : Test) : Cond := .pos { pp i a val with goal := true }
def Pacc (i a : String) (val : Test) : Cond := .pos { pp i a val with acc := true }
def N (i a : String) (val : Test) : Cond := .neg [pp i a val]
def rv (x : String) : RVal := .var x
def rs (x : String) : RVal := .sym (.str x)
def ri (n : Int) : RVal := .sym (.int n)
def mk (i a : String) (val : RVal) : Action := .make i (rs a) val
def rm (i a : String) (val : RVal) : Action := .remove i (rs a) val

/-- The variable holding `obj.attr`. -/
def av (o a : String) : String := o ++ "-" ++ a

def Cmp.rel : Cmp → Option RelOp
  | .eq => none | .ne => some .ne | .lt => some .lt | .le => some .le
  | .gt => some .gt | .ge => some .ge | .lacks => some .ne

def Atom.term : Atom → Term
  | .lit n => .sym (.int n)
  | .get o a => .var (av o a)
  | .val p => .var p
  | .obj p => .var p

def Expr.rval : Expr → RVal
  | .lit n => ri n
  | .get o a => rv (av o a)
  | .add x y => .call "+" [x.rval, y.rval]
  | .sub x y => .call "-" [x.rval, y.rval]
  | .val p => rv p
  | .mul x y => .call "*" [x.rval, y.rval]
  | .div x y => .call "div" [x.rval, y.rval]
  | .obj p => rv p

/-- Actions making a case's new objects, held by the task state `ts`. -/
def createActs (ts : String) (c : Case) : List Action :=
  c.creates.flatMap fun no => mk ts no.holder (rv no.var) :: no.vals.map fun (a, e) => mk no.var a e.rval

/-- Attribute references of the new objects' values. -/
def createRefs (c : Case) : List (String × String) := c.creates.flatMap fun no => no.vals.flatMap (·.2.refs)

/-- A `write` action for a message (none for an empty message). -/
def msgActs (ms : List Msg) : List Action :=
  if ms.isEmpty then [] else
  [.write (ms.map fun m => match m with | .text s => rs s | .val e => e.rval)]

/-- What an effect reads: the old value (to replace it) and its expression's references. -/
def Effect.reads (e : Effect) : List (String × String) :=
  (if e.mode == .set then [(e.obj, e.attr)] else []) ++ e.val.refs

/-- Attribute references of a case's effects and of its message. -/
def caseRefs (c : Case) : List (String × String) :=
  c.effects.flatMap Effect.reads ++ c.write.flatMap Msg.refs ++
    c.store.flatMap (fun (_, vals) => vals.flatMap fun (_, e) => e.refs)

/-- Storing objects in semantic memory: each made on `^smem.command.store` with its type as
`^kind` (conditions bind the command of the rule's state `s`). -/
def storeConds (c : Case) : List Cond :=
  if c.store.isEmpty then [] else [P "s" "smem" (vt "sms"), P "sms" "command" (vt "smsc")]

def storeActs (c : Case) : List Action :=
  (c.store.zip (List.range c.store.length)).flatMap fun ((t, vals), k) =>
    let v := s!"st{k}"
    [mk "smsc" "store" (rv v), mk v "kind" (rs t)] ++ vals.map fun (a, e) => mk v a e.rval

/-- Value parameters replaced by their values (a combination). -/
def Atom.subst (vals : List (String × Int)) : Atom → Atom
  | .val p => match vals.lookup p with | some v => .lit v | none => .val p
  | a => a

def Guard.subst (vals : List (String × Int)) : Guard → Guard
  | .cmp o a op r => .cmp o a op (r.subst vals)
  | .noneSuch ty cs => .noneSuch ty (cs.map fun (a, op, r) => (a, op, r.subst vals))
  | .linked p l ty cs k => .linked p l ty (cs.map fun (a, op, r) => (a, op, r.subst vals)) k
  | .fewer p l ty cs k => .fewer p l ty (cs.map fun (a, op, r) => (a, op, r.subst vals)) k
  | .someSuch ty cs => .someSuch ty (cs.map fun (a, op, r) => (a, op, r.subst vals))
  | g => g

/-- `(<a> ^attr <b>)` for each link guard. -/
def linkConds (gs : List Guard) : List Cond :=
  gs.filterMap fun g => match g with
    | .link a attr b => some (P a attr (vt b))
    | _ => none

/-- Conditions for goal-link and flag guards (state variable `ts`; objects of type with holder
`h` and key `k` via `hk`): `desired o.attr = t` compares by key, since look-ahead copies link to
copies while `^desired` links to the task's own objects. -/
def goalFlagConds (s : Schema) (ts : String) (types : String → Option String) (gs : List Guard) : List Cond :=
  (gs.zip (List.range gs.length)).flatMap fun (g, i) => match g with
    | .desired o attr t =>
      match types o with
      | some ty =>
        let h := ((s.holder? ty).map (·.name)).getD ty
        let k := ((s.type? ty).bind (·.key)).getD "name"
        [P ts "desired" (vt s!"des{i}"), P s!"des{i}" h (vt s!"dx{i}"), P o k (vt s!"ko{i}"),
         P s!"dx{i}" k (vt s!"ko{i}"), P s!"dx{i}" attr (vt s!"dt{i}"), P s!"dt{i}" k (vt s!"kt{i}"),
         P t k (vt s!"kt{i}")]
      | none => []
    | .flag o attr true => [P o attr (itest 1)]
    | .flag o attr false => [N o attr (itest 1)]
    | .unwants pred o => [P ts "desired" (vt s!"wd{i}"), N s!"wd{i}" pred (vt o)]
    | .wants pred o via =>
      [P ts "desired" (vt s!"wd{i}")] ++
      (match via with
       | none => [P s!"wd{i}" pred (vt o)]
       | some l => [P o l (vt s!"wv{i}"), P s!"wd{i}" pred (vt s!"wv{i}")])
    | _ => []

/-- The test of `x.attr op atom` inside a negated conjunction. -/
def noneTest (op : Cmp) (r : Atom) : Test :=
  match op.rel, r with
  | none, .lit n => [.const (.int n)]
  | none, .get o a => [.var (av o a)]
  | none, .val p => [.var p]
  | none, .obj p => [.var p]
  | some rel, r => [.rel rel r.term]

/-- Conditions that bind `obj.attr` for every reference and carry the guards' comparisons. -/
def refConds (refs0 : List (String × String)) (gs : List Guard) : List Cond :=
  let refs := (refs0 ++ gs.flatMap Guard.refs).eraseDups
  -- references used as values (by other guards' atoms or by the caller), not only tested
  let used : List (String × String) := refs0 ++ gs.flatMap fun g => match g with
    | .cmp _ _ _ r => r.refs | _ => []
  (refs.map fun (o, a) =>
    let tests : Test := gs.filterMap fun g => match g with
      | .cmp o' a' op r =>
        if o' == o && a' == a then
          match op.rel, r with
          | none, .lit n => some (.const (.int n))
          | none, .get o2 a2 => some (.var (av o2 a2))
          | none, .val p => some (.var p)
          | none, .obj p => some (.var p)
          | some rel, r => some (.rel rel r.term)
        else none
      | _ => none
    -- Soar allows one equality test per conjunctive test: when the value must equal another
    -- variable and is not needed under its own name, test only that variable
    let eqVars := tests.filter fun t => match t with | .var _ => true | _ => false
    let eqConsts := tests.filter fun t => match t with | .const _ => true | _ => false
    if !eqVars.isEmpty && !used.contains (o, a) then [P o a tests]
    -- Soar keeps one equality test per conjunctive test (it silently drops a constant next to a
    -- variable): a value that is both bound and compared with a constant gets two conditions
    else if !eqConsts.isEmpty && (used.contains (o, a) || !eqVars.isEmpty) then
      [P o a (.var (av o a) :: tests.filter (fun t => match t with | .const _ => false | _ => true)), P o a eqConsts]
    else if !eqConsts.isEmpty then [P o a tests]
    else [P o a (.var (av o a) :: tests)]).flatten ++
  -- `lacks`: the set has no such value
  gs.filterMap fun g => match g with
    | .cmp o a .lacks r => some (N o a (noneTest .eq r))
    | _ => none

/-- Conditions on the task state (variable `ts`): `holds` and `unset` guards. -/
def stateConds (ts : String) (gs : List Guard) : List Cond :=
  gs.filterMap fun g => match g with
    | .holds attr p => some (P ts attr (vt p))
    | .unset attr => some (N ts attr [])
    | _ => none

/-- A negated conjunction over `x` (bound by `first`) with conditions `cs`; a `lacks` condition
becomes a negation inside it. -/
def negWith (first : Pat) (x : String) (cs : List (String × Cmp × Atom)) : Cond :=
  let pos := first :: (cs.filter (·.2.1 != .lacks)).map fun (a, op, r) => pp x a (noneTest op r)
  let negs := (cs.filter (·.2.1 == .lacks)).map fun (a, _, r) => [pp x a (noneTest .eq r)]
  if negs.isEmpty then .neg pos else .ncc pos negs

/-- `-{ (<ts> ^holder <x>) (<x> ^attr op atom) … }` for each `none` guard (`hd` gives a type's
holder attribute). -/
def noneConds (ts : String) (hd : String → String) (gs : List Guard) : List Cond :=
  ((gs.zip (List.range gs.length)).filterMap fun (g, i) => match g with
    | .noneSuch ty cs =>
      let x := s!"none{i+1}"
      some (negWith (pp ts (hd ty) (vt x)) x cs)
    | _ => none) ++
  -- `linked` guards: a negation (none), or `k` distinct linked objects
  ((gs.zip (List.range gs.length)).flatMap fun (g, i) => match g with
    | .linked p l _ cs 0 =>
      let x := s!"lk{i+1}"
      [negWith (pp p l (vt x)) x cs]
    | .linked p l _ cs k =>
      (List.range k).flatMap fun j =>
        let x := s!"lk{i+1}x{j+1}"
        P p l (.var x :: (List.range j).map fun j' => .rel .ne (.var s!"lk{i+1}x{j'+1}")) ::
          cs.map fun (a, op, r) => if op == .lacks then N x a (noneTest .eq r) else P x a (noneTest op r)
    | .fewer p l _ cs k =>
      -- no k distinct linked objects satisfy the conditions
      let xs := (List.range k).map fun j => s!"fw{i+1}x{j+1}"
      let pos := (xs.zip (List.range k)).flatMap fun (x, j) =>
        pp p l (.var x :: (xs.take j).map fun y => .rel .ne (.var y)) ::
          (cs.filter (·.2.1 != .lacks)).map fun (a, op, r) => pp x a (noneTest op r)
      let negs := xs.flatMap fun x => (cs.filter (·.2.1 == .lacks)).map fun (a, _, r) => [pp x a (noneTest .eq r)]
      [if negs.isEmpty then .neg pos else .ncc pos negs]
    | .someSuch ty cs =>
      let x := s!"some{i+1}"
      P ts (hd ty) (vt x) :: cs.map fun (a, op, r) =>
        if op == .lacks then N x a (noneTest .eq r) else P x a (noneTest op r)
    | _ => [])

/-- References of the `noneSuch` guards' atoms (to be bound before the negations). -/
def noneRefs (gs : List Guard) : List (String × String) :=
  gs.flatMap fun g => match g with
    | .noneSuch .. => g.refs | .linked .. => g.refs | .fewer .. => g.refs | .someSuch .. => g.refs | _ => []

def Schema.hd (s : Schema) (t : String) : String := ((s.holder? t).map (·.name)).getD t

/-- Actions (and the conditions they need) for a case's changes to the task state `ts`. -/
def stateEffectConds (ts : String) (c : Case) : List Cond :=
  c.stateEffects.filterMap fun (attr, v) => match v with
    | none => some (P ts attr (vt (attr ++ "-old")))
    | some _ => none

def stateEffectActs (ts : String) (c : Case) : List Action :=
  c.stateEffects.map fun (attr, v) => match v with
    | some p => mk ts attr (rv p)
    | none => rm ts attr (rv (attr ++ "-old"))

/-- `(<s> ^holder <p>)` for each parameter, with distinctness tests. -/
def paramFromState (s : Schema) (ps : List (String × String)) (gs : List Guard) : List Cond :=
  ps.map fun (p, t) =>
    let h := ((s.holder? t).map (·.name)).getD t
    let ne : Test := gs.filterMap fun g => match g with
      | .distinct a b => if b == p then some (.rel .ne (.var a)) else none
      | _ => none
    P "s" h (.var p :: ne)

def opWithParams (o : String) (name : String) (ps : List (String × String)) : List Cond :=
  P o "name" (ct name) :: ps.map fun (p, _) => P o p (vt p)

/-- The operator with its parameters and value parameters bound to variables. -/
def opWithAll (o : String) (op : Operator) : List Cond :=
  opWithParams o op.name op.params ++ op.vparams.map fun (p, _) => P o p (vt p)

def effectActs (es : List Effect) : List Action :=
  es.flatMap fun e => match e.mode with
    | .set => [mk e.obj e.attr e.val.rval, rm e.obj e.attr (rv (av e.obj e.attr))]
    | .add => [mk e.obj e.attr e.val.rval]
    | .remove => [rm e.obj e.attr e.val.rval]

def effectRefs (es : List Effect) : List (String × String) :=
  es.flatMap Effect.reads

/-! ## Pieces -/

def initOpName (a : Agent) : String := "initialize-" ++ a.schema.task

def objActs (holderOwner : String) (h : String) (var : String) (vals : ObjPat) : List Action :=
  mk holderOwner h (rv var) :: vals.map fun (k, n) => mk var k (ri n)

def initFile (a : Agent) : GenFile :=
  let t := a.schema.task
  let goalH := ((a.schema.holder? a.goal.ty).map (·.name)).getD a.goal.ty
  let objs := (a.init.zip (List.range a.init.length)).flatMap fun ((h, vals), i) =>
    objActs "s" h s!"x{i}" vals
  let n0 := a.init.length
  let var (nm : String) : String := match a.objs.findIdx? (·.name == nm) with
    | some j => s!"x{n0 + j}"
    | none => nm
  let named := a.objs.flatMap fun o =>
    objActs "s" o.holder (var o.name) o.vals ++ [mk (var o.name) "name" (rs o.name)] ++
      o.links.map (fun (attr, tgt) => mk (var o.name) attr (rv (var tgt)))
  let goalName := match a.goal.name with
    | some nm => [mk "dg" "name" (rs nm)]
    | none => []
  let better := match a.method with
    | .lookahead _ _ _ (some sc) => [mk "d" "better" (rs (if sc.higher then "higher" else "lower"))]
    | _ => []
  let lastOp := match a.method with
    | .tieHeuristic _ => [mk "s" "last-operator" (rs "none")]
    | _ => []
  { path := initOpName a ++ ".soar", kind := "OPERATOR", prods := [
    { name := s!"{t}*propose*{initOpName a}",
      conds := [Ps "s" "superstate" (ct "nil"), N "s" "name" []],
      acts := [.pref "s" (rv "o") .acceptable none none, mk "o" "name" (rs (initOpName a))] },
    { name := s!"{t}*apply*{initOpName a}",
      conds := [Ps "s" "operator" (vt "o"), P "o" "name" (ct (initOpName a))],
      acts := mk "s" "name" (rs t) :: objs ++ named ++
        [mk "s" "desired" (rv "d")] ++
        (if !a.goal.links.isEmpty then
           (a.goal.links.zip (List.range a.goal.links.length)).flatMap fun ((o, attr, tgt), i) =>
             [mk "d" goalH (rv s!"dg{i}"), mk s!"dg{i}" "name" (rs o), mk s!"dg{i}" attr (rv (var tgt))]
         else if a.goal.each.isEmpty then objActs "d" goalH "dg" a.goal.vals ++ goalName
         else (a.goal.each.zip (List.range a.goal.each.length)).flatMap fun (p, i) => objActs "d" goalH s!"dg{i}" p) ++
        better ++ lastOp }] }

/-- Operator subgoaling: the substate of an operator selected without its preconditions is named
like the task (so the task's operators and preferences work there), shares the task's objects
(each object-holding state attribute is copied by reference), and has a `^desired` with the
operator's `pregoals`. Elaborations (i-support): the substate goes away when the operator applies. -/
def subgoalProds (a : Agent) : List Production :=
  if !a.subgoaling then [] else
  let t := a.schema.task
  let holders := a.schema.stateAttrs.filter fun d => match d.ty with | .obj _ => d.multi | _ => false
  (a.ops.filter (!·.pregoals.isEmpty)).map (fun o =>
    { name := s!"{t}*elaborate*operator-subgoal*{o.name}",
      conds := [Ps "s" "impasse" (ct "no-change"), P "s" "attribute" (ct "operator"),
        P "s" "superstate" (vt "ss"), P "ss" "name" (ct t), P "ss" "operator" (vt "so"),
        P "so" "name" (ct o.name)] ++
        (o.pregoals.map (·.2)).eraseDups.map (fun p => P "so" p (vt p)),
      -- `sgd`: not a parameter name (an operator may have a parameter `d`)
      acts := [mk "s" "type" (rs "operator-subgoal"), mk "s" "name" (rs t), mk "s" "desired" (rv "sgd")] ++
        o.pregoals.map fun (pred, p) => mk "sgd" pred (rv p) : Production }) ++
  holders.map fun h =>
    { name := s!"{t}*elaborate*operator-subgoal*share*{h.name}",
      conds := [Ps "s" "type" (ct "operator-subgoal"), P "s" "superstate" (vt "ss"), P "ss" h.name (vt "x")],
      acts := [mk "s" h.name (rv "x")] }

/-- The recursive flags: a base rule and a rule along the link (elaborations, i-support). -/
def flagProds (a : Agent) : List Production :=
  let t := a.schema.task
  let isCmp (g : Guard) : Bool := match g with | .cmp .. => true | _ => false
  -- operator subgoaling (JL, 8 Nov 2026): the substates share the task's objects, so flags are
  -- elaborated in the task's own states only. Elaborated in every state, a flag had support from
  -- several levels; when a deeper operator's change made two waiting operators applicable, the
  -- support from one level had not yet retracted when the next level's operator applied (Soar
  -- applies level by level), and both applied (two blocks put on one).
  let notSub : List Cond := if a.subgoaling then [N "s" "type" (ct "operator-subgoal")] else []
  (a.flags.zip (List.range a.flags.length)).flatMap fun (f, fi) =>
    let h := ((a.schema.holder? f.ty).map (·.name)).getD f.ty
    let below := match a.schema.attr? f.ty f.via with | some { ty := .obj tb, .. } => tb | _ => f.ty
    let types := fun (p : String) => if p == "self" then some f.ty else if p == "below" then some below else none
    let gconds (gs : List Guard) : List Cond :=
      linkConds gs ++ goalFlagConds a.schema "s" types gs ++
      refConds (noneRefs gs) (gs.filter isCmp) ++
      noneConds "s" (fun ty => ((a.schema.holder? ty).map (·.name)).getD ty) gs
    (if f.base.isEmpty then [] else
      [{ name := s!"{t}*elaborate*{f.ty}*{f.attr}*base" ++ (if fi == 0 then "" else s!"*{fi+1}"),
         conds := [Ps "s" "name" (ct t), P "s" h (vt "self")] ++ notSub ++ gconds f.base,
         acts := [mk "self" f.attr (ri 1)] }]) ++
    (if f.via == "" then [] else
    [{ name := s!"{t}*elaborate*{f.ty}*{f.attr}*via-{f.via}",
       conds := [Ps "s" "name" (ct t), P "s" h (vt "self"), P "self" f.via (vt "below"),
         P "below" f.attr (itest 1)] ++ notSub ++ gconds f.step,
       acts := [mk "self" f.attr (ri 1)] }])

def deriveProds (a : Agent) : List Production :=
  a.derive.map fun d =>
    let h := ((a.schema.holder? d.ty).map (·.name)).getD d.ty
    { name := s!"{a.schema.task}*elaborate*{d.ty}*{d.attr}",
      conds := [Ps "s" "name" (ct a.schema.task), P "s" h (vt "self")] ++
        (if a.subgoaling then [N "s" "type" (ct "operator-subgoal")] else []) ++ refConds d.val.refs [],
      acts := [mk "self" d.attr d.val.rval] }

/-- The goal: success when some object matches the desired object; halt at the top state. -/
def goalProds0 (a : Agent) : List Production :=
  let t := a.schema.task
  let h := ((a.schema.holder? a.goal.ty).map (·.name)).getD a.goal.ty
  let keys := a.goal.vals.map (·.1) ++ (if a.goal.name.isSome then ["name"] else [])
  let key := ((a.schema.type? a.goal.ty).bind (·.key))
  [if !a.goal.links.isEmpty then
    -- every desired link holds: the named object links to the same object as in `^desired`
    { name := s!"{t}*elaborate*goal*success",
      conds := [Ps "s" "name" (ct t), P "s" "desired" (vt "d")] ++
        (a.goal.links.zip (List.range a.goal.links.length)).flatMap (fun ((o, attr, _), i) =>
          -- the targets are compared by name: in a look-ahead copy the state's links point to
          -- copies of the objects, `^desired` to the originals
          [P "d" h (vt s!"dx{i}"), P s!"dx{i}" "name" (ct o), P s!"dx{i}" attr (vt s!"dt{i}"),
           P s!"dt{i}" "name" (vt s!"tn{i}"),
           P "s" h (vt s!"x{i}"), P s!"x{i}" "name" (ct o), P s!"x{i}" attr (vt s!"t{i}"),
           P s!"t{i}" "name" (vt s!"tn{i}")]),
      acts := [mk "s" "success" (rv "d")] }
   else if !a.goal.each.isEmpty then
    -- several desired objects, each picked out by its key: each has a matching object
    { name := s!"{t}*elaborate*goal*success",
      conds := [Ps "s" "name" (ct t), P "s" "desired" (vt "d")] ++
        (a.goal.each.zip (List.range a.goal.each.length)).flatMap (fun (p, i) =>
          let ks := p.map (·.1)
          [P "d" h (vt s!"dx{i}")] ++
          ks.map (fun k => match key, p.lookup k with
            | some kk, some v => if k == kk then P s!"dx{i}" k (itest v) else P s!"dx{i}" k (vt s!"g{i}-{k}")
            | _, _ => P s!"dx{i}" k (vt s!"g{i}-{k}")) ++
          [P "s" h (vt s!"x{i}")] ++
          ks.map (fun k => match key, p.lookup k with
            | some kk, some v => if k == kk then P s!"x{i}" k (itest v) else P s!"x{i}" k (vt s!"g{i}-{k}")
            | _, _ => P s!"x{i}" k (vt s!"g{i}-{k}"))),
      acts := [mk "s" "success" (rv "d")] }
   else if a.goal.all then
    -- every object has the desired values: no object differs in any of them
    { name := s!"{t}*elaborate*goal*success",
      conds := [Ps "s" "name" (ct t), P "s" "desired" (vt "d"), P "d" h (vt "dx")] ++
        keys.map (fun k => P "dx" k (vt ("g-" ++ k))) ++
        keys.map (fun k => Cond.neg [pp "s" h (vt ("x-" ++ k)), pp ("x-" ++ k) k [.rel .ne (.var ("g-" ++ k))]]),
      acts := [mk "s" "success" (rv "d")] }
   else
   { name := s!"{t}*elaborate*goal*success",
     conds := [Ps "s" "name" (ct t), P "s" "desired" (vt "d"), P "s" h (vt "x"), P "d" h (vt "dx")] ++
       keys.map (fun k => P "dx" k (vt ("g-" ++ k))) ++ keys.map (fun k => P "x" k (vt ("g-" ++ k))),
     acts := [mk "s" "success" (rv "d")] },
   { name := s!"{t}*halt*goal*success",
     conds := [Ps "s" "superstate" (ct "nil"), P "s" "desired" (vt "d"), P "s" "success" (vt "d")] ++
       -- operators that finish the task after the goal (e.g. printing) have set `after`
       (if a.goal.after.isEmpty then [] else
         P "s" h (vt "fin") :: a.goal.after.map fun (k, v) => P "fin" k (itest v)) ++
       -- with a report: the goal object, as `self`, and the attributes the report refers to
       (if a.goal.report.isEmpty then [] else
         [P "s" h (vt "self"), P "d" h (vt "dx")] ++ keys.map (fun k => P "dx" k (vt ("g-" ++ k))) ++
         keys.map (fun k => P "self" k (vt ("g-" ++ k))) ++ refConds (a.goal.report.flatMap Msg.refs) []),
     acts := (if a.goal.report.isEmpty then [] else
         [.write (.call "crlf" [] :: a.goal.report.map fun m => match m with | .text s => rs s | .val e => e.rval)]) ++
       [.write [.call "crlf" [], rs "The problem has been solved."], .halt] }]

/-- The goal rules. With `Goal.after`, the top state first gets `^goal-reached` (operators marked
`atGoal` then finish the task) and `^success` only once the `after` values hold, since the default
library halts on `^success` at the top state; other states (look-ahead) get `^success` as before. -/
def goalProds (a : Agent) : List Production :=
  let ps := goalProds0 a
  -- `Agent.lookaheadSuccess = false`: `^success` only at the top state; look-ahead states are
  -- evaluated by their score alone
  let ps := if a.lookaheadSuccess then ps else match ps with
    | succ :: rest => { succ with conds := succ.conds ++ [P "s" "superstate" (ct "nil")] } :: rest
    | [] => []
  if a.goal.after.isEmpty then ps else
  let h := ((a.schema.holder? a.goal.ty).map (·.name)).getD a.goal.ty
  match ps with
  | succ :: rest =>
    let sub : Production :=
      { succ with name := succ.name ++ "*substate",
                  conds := succ.conds ++ [P "s" "superstate" [.rel .ne (.sym (.str "nil"))]] }
    let top : Production :=
      { succ with name := succ.name ++ "*top*reached",
                  conds := succ.conds ++ [P "s" "superstate" (ct "nil")],
                  acts := [mk "s" "goal-reached" (rv "d")] }
    let finConds : List Cond := [Ps "s" "superstate" (ct "nil"), P "s" "desired" (vt "d"),
      P "s" "goal-reached" (vt "d"), P "s" h (vt "fin")] ++ a.goal.after.map (fun (k, v) => P "fin" k (itest v))
    let fin : Production :=
      { name := a.schema.task ++ "*elaborate*goal*success*after"
        conds := finConds
        acts := [mk "s" "success" (rv "d")] }
    sub :: top :: fin :: rest
  | [] => []

def proposeProdWith (a : Agent) (o : Operator) (gs : List Guard) (suffix : String)
    (vals : List (String × Int) := []) : Production :=
  let indiff := match a.method with
    | .random | .rl .. => [Action.pref "s" (rv "o") .unaryIndiff none none]
    | _ => if o.indifferent then [Action.pref "s" (rv "o") .unaryIndiff none none] else []
  let gs := (gs.filter (!·.isStatic)).map (Guard.subst vals)
  { name := s!"{a.schema.task}*propose*{o.name}{suffix}",
    conds := Ps "s" "name" (ct a.schema.task) :: (if o.atGoal then [P "s" "superstate" (ct "nil"), P "s" "goal-reached" []] else []) ++
      paramFromState a.schema o.params gs ++ linkConds gs ++
      goalFlagConds a.schema "s" (fun p => o.params.lookup p) gs ++
      refConds (noneRefs gs) (gs.filter fun g => match g with | .cmp .. => true | _ => false) ++ stateConds "s" gs ++
      noneConds "s" a.schema.hd gs,
    acts := [.pref "s" (rv "o") .acceptable none none] ++ indiff ++
      mk "o" "name" (rs o.name) :: o.params.map (fun (p, _) => mk "o" p (rv p)) ++
      vals.map (fun (p, v) => mk "o" p (ri v)) }

/-- Proposal rules. With alternatives, each alternative (and `propose`) is an elaboration deriving
`(<s> ^<op>-relevant <p>)`, and a single proposal rule tests it: the derived WME stays while any
alternative holds, so the proposed operator keeps its identity (two proposal rules would replace the
operator when one alternative gives way to the other, ending its substate). Needs exactly one
parameter (`check`). -/
def proposeProds (a : Agent) (o : Operator) : List Production :=
  -- an operator carried out by sub-operators that change what its proposal tests: proposed through
  -- a relevance elaboration (as with alternatives), so it keeps its identity while its sub-operators
  -- work (a proposal rule that tests the changed values would be retracted and fire again, making a
  -- new operator and ending the substate after every sub-operator)
  let subKeep := match o.impl, o.params, o.vparams with
    | .sub _, [_], [] => true
    | _, _, _ => false
  match (if subKeep && o.proposeAlt.isEmpty then [[]] else o.proposeAlt), o.params with
  | [], _ =>
    if !o.proposeOr.isEmpty then
      (o.proposeOr.zip (List.range o.proposeOr.length)).map fun (alt, i) =>
        proposeProdWith a o (o.propose ++ alt) s!"*{i+1}"
    else if o.vparams.isEmpty then [proposeProdWith a o o.propose ""] else
    -- one proposal rule per combination of values that passes the static guards
    o.combos.map fun vals =>
      proposeProdWith a o o.propose (String.join (vals.map fun (p, v) => s!"*{p}-{v}")) vals
  | alts, [(p, _)] =>
    let flag := o.name ++ "-relevant"
    let elabRule (gs : List Guard) (i : Nat) : Production :=
      { name := s!"{a.schema.task}*elaborate*{flag}*{i+1}",
        conds := Ps "s" "name" (ct a.schema.task) :: paramFromState a.schema o.params gs ++
          refConds (noneRefs gs) (gs.filter fun g => match g with | .cmp .. => true | _ => false) ++ stateConds "s" gs ++
          noneConds "s" a.schema.hd gs,
        acts := [mk "s" flag (rv p)] }
    let indiff := match a.method with
      | .random | .rl .. => [Action.pref "s" (rv "o") .unaryIndiff none none]
      | _ => if o.indifferent then [Action.pref "s" (rv "o") .unaryIndiff none none] else []
    let prop : Production :=
      { name := s!"{a.schema.task}*propose*{o.name}",
        conds := [Ps "s" "name" (ct a.schema.task), P "s" flag (vt p)],
        acts := [.pref "s" (rv "o") .acceptable none none] ++ indiff ++
          [mk "o" "name" (rs o.name), mk "o" p (rv p)] }
    let alts := if o.proposeAlt.isEmpty then [] else alts
    (((o.propose :: alts).zip (List.range (alts.length + 1))).map fun (gs, i) => elabRule gs i) ++ [prop]
  | _, _ => [proposeProdWith a o o.propose ""]

def proposeProd (a : Agent) (o : Operator) : Production := proposeProdWith a o o.propose ""

def applyProds (a : Agent) (o : Operator) : List Production :=
  -- the preconditions (operator subgoaling) are required by every apply rule
  (o.apply.zip (List.range o.apply.length)).flatMap fun (c0, i) =>
    let c : Case := { c0 with guard := o.pre ++ c0.guard }
    let nm := s!"{a.schema.task}*apply*{o.name}" ++ (if o.apply.length > 1 then s!"*case{i+1}" else "")
    let guardConds : List Cond := linkConds c.guard ++ goalFlagConds a.schema "s" (fun p => (o.params ++ o.applyParams).lookup p) c.guard
    let isCmp (g : Guard) : Bool := match g with | .cmp .. => true | _ => false
    -- apply-time parameters are bound from the state, not the operator
    let applyPs : List Cond := paramFromState a.schema o.applyParams c.guard
    let main : Production :=
      { name := nm,
        conds := [Ps "s" "name" (ct a.schema.task), P "s" "operator" (vt "o")] ++
          opWithAll "o" o ++ applyPs ++ guardConds ++ refConds (caseRefs c ++ createRefs c ++ noneRefs c.guard) (c.guard.filter isCmp) ++
          stateConds "s" c.guard ++ noneConds "s" a.schema.hd c.guard ++ stateEffectConds "s" c,
        acts := createActs "s" c ++ effectActs c.effects ++ stateEffectActs "s" c ++ msgActs c.write }
    -- effects on linked objects: one rule per `Each`, matching each linked object
    let eachProds := (c.each.zip (List.range c.each.length)).map fun (ea, k) =>
      let ec : Case := { effects := ea.effects }
      { name := nm ++ s!"*each{k+1}",
        conds := [Ps "s" "name" (ct a.schema.task), P "s" "operator" (vt "o")] ++
          opWithAll "o" o ++ guardConds ++ refConds (caseRefs ec ++ noneRefs c.guard) (c.guard.filter isCmp) ++
          stateConds "s" c.guard ++ noneConds "s" a.schema.hd c.guard ++ [P ea.src ea.link (vt ea.var)],
        acts := effectActs ea.effects : Production }
    main :: eachProds

/-- An operator carried out by steps in its operator no-change substate. -/
def stepFiles (a : Agent) (o : Operator) (steps : List String) : List GenFile :=
  let nameProd : Production :=
    { name := s!"{o.name}*elaborate*substate",
      conds := [Ps "s" "impasse" (ct "no-change"), P "s" "attribute" (ct "operator"),
        P "s" "superstate" (vt "ss"), P "ss" "operator" (vt "so")] ++ opWithParams "so" o.name o.params,
      acts := mk "s" "name" (rs o.name) :: o.params.map (fun (p, _) => mk "s" p (rv p)) }
  let n := steps.length
  let stepFile (k : Nat) (st : String) : GenFile :=
    let prev := if k == 0 then [] else [P "s" "done" (ct steps[k-1]!)]
    let prop : Production :=
      { name := s!"{o.name}*propose*{st}",
        conds := [Ps "s" "name" (ct o.name), N "s" "done" (ct st)] ++ prev,
        acts := [.pref "s" (rv "o") .acceptable none none, .pref "s" (rv "o") .unaryIndiff none none,
          mk "o" "name" (rs st)] }
    let applies : List Production :=
      if k + 1 < n then
        [{ name := s!"{o.name}*apply*{st}",
           conds := [Ps "s" "name" (ct o.name), P "s" "operator" (vt "o"), P "o" "name" (ct st)],
           acts := [mk "s" "done" (rs st)] }]
      else
        (o.apply.zip (List.range o.apply.length)).map fun (c, i) =>
          { name := s!"{o.name}*apply*{st}" ++ (if o.apply.length > 1 then s!"*case{i+1}" else ""),
            conds := [Ps "s" "name" (ct o.name), P "s" "operator" (vt "o"), P "o" "name" (ct st)] ++
              o.params.map (fun (p, _) => P "s" p (vt p)) ++ refConds (caseRefs c) c.guard,
            acts := effectActs c.effects ++ [mk "s" "done" (rs st)] ++ msgActs c.write }
    { path := s!"{o.name}/{st}.soar", kind := "OPERATOR", prods := prop :: applies }
  { path := s!"{o.name}/elaborations.soar", kind := "FILE_OPERATOR", prods := [nameProd] } ::
    (steps.zip (List.range n)).map fun (st, k) => stepFile k st

/-- Rename object `x` to `y` (substate-local attributes: `local` becomes the substate `s`). -/
def Expr.ren (x y : String) : Expr → Expr
  | .get o a => .get (if o == x then y else o) a
  | .add p q => .add (p.ren x y) (q.ren x y)
  | .sub p q => .sub (p.ren x y) (q.ren x y)
  | .mul p q => .mul (p.ren x y) (q.ren x y)
  | .div p q => .div (p.ren x y) (q.ren x y)
  | e => e

def Atom.ren (x y : String) : Atom → Atom
  | .get o a => .get (if o == x then y else o) a
  | r => r

def Guard.ren (x y : String) : Guard → Guard
  | .cmp o a op r => .cmp (if o == x then y else o) a op (r.ren x y)
  | .link a attr b => .link (if a == x then y else a) attr (if b == x then y else b)
  | .distinct a b => .distinct (if a == x then y else a) (if b == x then y else b)
  | .linked p l ty cs k => .linked (if p == x then y else p) l ty (cs.map fun (a, op, r) => (a, op, r.ren x y)) k
  | .fewer p l ty cs k => .fewer (if p == x then y else p) l ty (cs.map fun (a, op, r) => (a, op, r.ren x y)) k
  | .noneSuch ty cs => .noneSuch ty (cs.map fun (a, op, r) => (a, op, r.ren x y))
  | .someSuch ty cs => .someSuch ty (cs.map fun (a, op, r) => (a, op, r.ren x y))
  | .flag o a b => .flag (if o == x then y else o) a b
  | g => g

def Case.ren (x y : String) (c : Case) : Case :=
  { c with guard := c.guard.map (Guard.ren x y),
           effects := c.effects.map fun e => { obj := if e.obj == x then y else e.obj, attr := e.attr, val := e.val.ren x y },
           write := c.write.map fun m => match m with | .val e => .val (e.ren x y) | m => m }

def SubOp.ren (x y : String) (so : SubOp) : SubOp :=
  { so with propose := so.propose.map (Guard.ren x y), apply := so.apply.map (Case.ren x y),
            retrieve := so.retrieve.map fun r => { r with cue := r.cue.map fun (a, e) => (a, e.ren x y) } }

/-- The rules of one substate level: the sub-operators `subs` working in the substate named `ctx`.
`bind` binds the substate (`s`), the task state (`ts`, a variable name) and the level's parameters;
`locals` are the substate-local attributes (`local`; `up` is the parent substate, variable `ss`,
for nested levels). -/
def levelFiles (a : Agent) (ctx : String) (bind : List Cond) (ts : String)
    (locals : List (String × Expr)) (subs : List SubOp) (paramTypes : List (String × String))
    (rl : Option SubRl := none) (indiff : Bool := true) (copyApply : Bool := false) : List GenFile :=
  let subs := subs.map fun x => (x.ren "local" "s").ren "up" "ss"
  -- substate-local attributes: made by a first sub-operator; every other sub-operator waits for them
  let localReady : List Cond := match locals with
    | [] => []
    | (l, _) :: _ => [P "s" l []]
  let isCmp (g : Guard) : Bool := match g with | .cmp .. => true | _ => false
  let subFile (x0 : SubOp) : GenFile :=
    -- a sub-operator parameter named like one of the level's own (a recursive sub-operator, e.g.
    -- borrow-from's column m) gets its own variable, `<m-sub>`; the operator attribute keeps the name
    let clash := x0.params.filter fun (p, _) => paramTypes.any (·.1 == p)
    let x : SubOp := clash.foldl (fun (y : SubOp) (p, _) =>
      { y with propose := y.propose.map (Guard.ren p (p ++ "-sub")), apply := y.apply.map (Case.ren p (p ++ "-sub")),
               params := y.params.map fun (q, t) => (if q == p then q ++ "-sub" else q, t) }) x0
    let attrOf (q : String) : String := if q.endsWith "-sub" && clash.any (·.1 ++ "-sub" == q) then ((clash.find? (·.1 ++ "-sub" == q)).map (·.1)).getD q else q
    -- the sub-operator's own parameters: objects of the task state
    let own : List Cond := x.params.map fun (p, t) => P ts (a.schema.hd t) (vt p)
    let prop : Production :=
      { name := s!"{ctx}*propose*{x.name}",
        conds := bind ++ localReady ++ own ++ linkConds x.propose ++
          goalFlagConds a.schema ts (fun p => (paramTypes ++ x.params).lookup p) x.propose ++
          refConds (noneRefs x.propose) (x.propose.filter isCmp) ++ stateConds ts x.propose ++
          noneConds ts a.schema.hd x.propose,
        acts := [.pref "s" (rv "o") .acceptable none none] ++
          (if indiff then [.pref "s" (rv "o") .unaryIndiff none none] else []) ++
          [mk "o" "name" (rs x.name)] ++ x.params.map (fun (p, _) => mk "o" (attrOf p) (rv p)) }
    -- a semantic-memory retrieval: the query (once per selection: `^queried <o>` on the state),
    -- then, from the retrieved object, the effects (and the query is removed)
    let recallConds : List Cond := match x.retrieve with
      | some r => [P "s" "smem" (vt "sm"), P "sm" "result" (vt "smr"), P "smr" "retrieved" (vt r.var),
          P "sm" "command" (vt "smc"), P "smc" "query" (vt "smq")]
      | none => []
    let recallActs : List Action := match x.retrieve with
      | some _ => [rm "smc" "query" (rv "smq")]
      | none => []
    let queryProd : List Production := match x.retrieve with
      | some r =>
        let qn : String := ctx ++ "*apply*" ++ x.name ++ "*query"
        let cueRefs : List (String × String) := r.cue.flatMap fun (_, e) => e.refs
        let qc : List Cond := bind ++ [P "s" "operator" (vt "o"), P "o" "name" (ct x.name), N "s" "queried" (vt "o"),
            P "s" "smem" (vt "sm"), P "sm" "command" (vt "smc")] ++
            x.params.map (fun (p, _) => P "o" (attrOf p) (vt p)) ++ refConds cueRefs []
        -- the marker is on the state (a WME on the operator would make the rule an operator
        -- elaboration, with i-support); it stays for the operator's selection
        let qa : List Action := [mk "s" "queried" (rv "o"), mk "smc" "query" (rv "smq"), mk "smq" "kind" (rs r.ty)] ++
            r.cue.map (fun (k, e) => mk "smq" k e.rval)
        [({ name := qn, conds := qc, acts := qa } : Production)]
      | none => []
    -- a sub-operator with its own sub-operators is carried out in its substate: no apply rules
    -- a retrieval that fails: the query is removed and the operator's no-change substate (its
    -- sub-operators) does the work
    let failProd : List Production := match x.retrieve with
      | some _ =>
        if x.subs.isEmpty then [] else
        let fn : String := ctx ++ "*apply*" ++ x.name ++ "*retrieval-failed"
        let fc : List Cond := bind ++ [P "s" "operator" (vt "o"), P "o" "name" (ct x.name),
          P "s" "smem" (vt "sm"), P "sm" "result" (vt "smr"), P "smr" "failure" (vt "smq"),
          P "sm" "command" (vt "smc"), P "smc" "query" (vt "smq")] ++ x.params.map (fun (p, _) => P "o" (attrOf p) (vt p))
        [({ name := fn, conds := fc, acts := [rm "smc" "query" (rv "smq")] } : Production)]
      | none => []
    -- a sub-operator with its own sub-operators is carried out in its substate: no apply rules
    -- (unless it retrieves: then it applies when the retrieval succeeds)
    -- in a look-ahead copy (`SubLookahead`), a sub-operator with its own sub-operators is applied by
    -- its specified effect
    let inCopy : List Cond := if !x.subs.isEmpty && copyApply then [P "s" "duplicate-of" []] else []
    let applies := if !x.subs.isEmpty && x.retrieve.isNone && !copyApply then [] else queryProd ++ failProd ++
      (x.apply.zip (List.range x.apply.length)).map fun (c, i) =>
      { name := s!"{ctx}*apply*{x.name}" ++ (if x.apply.length > 1 then s!"*case{i+1}" else ""),
        conds := bind ++ [P "s" "operator" (vt "o"), P "o" "name" (ct x.name)] ++ inCopy ++
          x.params.map (fun (p, _) => P "o" (attrOf p) (vt p)) ++ recallConds ++
          refConds (caseRefs c ++ createRefs c) (c.guard.filter isCmp) ++ stateConds ts c.guard ++ stateEffectConds ts c ++
          storeConds c,
        acts := createActs ts c ++ effectActs c.effects ++ stateEffectActs ts c ++ msgActs c.write ++ recallActs ++
          storeActs c : Production }
    { path := s!"{ctx}/{x.name}.soar", kind := if x.subs.isEmpty then "OPERATOR" else "HIGH_LEVEL_OPERATOR",
      prods := prop :: applies }
  let initLocal : List GenFile := match locals with
    | [] => []
    | (l, _) :: _ =>
      let locals := locals.map fun (k, e) => (k, (e.ren "local" "s").ren "up" "ss")
      let refs := locals.flatMap fun (_, e) => e.refs
      [{ path := s!"{ctx}/init-local.soar", kind := "OPERATOR", prods := [
        { name := s!"{ctx}*propose*init-local",
          conds := bind ++ [N "s" l []],
          acts := [.pref "s" (rv "o") .acceptable none none, mk "o" "name" (rs "init-local")] },
        { name := s!"{ctx}*apply*init-local",
          conds := bind ++ [P "s" "operator" (vt "o"), P "o" "name" (ct "init-local")] ++ refConds refs [],
          acts := locals.map fun (k, e) => mk "s" k e.rval }] }]
  -- RL over this level's sub-operators: a template per sub-operator over its parameters and the
  -- level's parameters (by key), and the level's rewards on its own reward link
  let keyOf (t : String) : String := ((a.schema.type? t).bind (·.key)).getD "name"
  -- Soar defect 28: a template that binds another state's identifier (`^superstate`,
  -- `^task-state`) is instantiated with that state and the matched state as one variable
  -- (`(state <s1> ^superstate <s1>)`), and the instance never fires; the templates do not test them
  let notStateLink (c : Cond) : Bool := match c with
    | .pos p => p.attr != ct "superstate" && p.attr != ct "task-state"
    | _ => true
  let rlFile : List GenFile := match rl with
    | none => []
    | some r =>
      -- the level parameters' attributes the templates test: a value, or a link by its key
      let attrConds : List Cond := r.attrs.flatMap fun (p, atr) =>
        let v := p ++ "-" ++ atr
        match (paramTypes.lookup p).bind (a.schema.attr? · atr) with
        | some { ty := .obj t2, .. } => [P p atr (vt v), P v (keyOf t2) (vt (v ++ "-k"))]
        | _ => [P p atr (vt v)]
      let tmpl := subs.map fun x =>
        let levelKeys : List Cond := paramTypes.flatMap fun (p, t) => [P p (keyOf t) (vt (p ++ "-k"))]
        { name := s!"{ctx}*rl*{x.name}",
          conds := bind.filter notStateLink ++ [Pacc "s" "operator" (vt "o"), P "o" "name" (ct x.name)] ++
            x.params.flatMap (fun (p, t) => [P "o" p (vt ("op-" ++ p)), P ("op-" ++ p) (keyOf t) (vt ("op-" ++ p ++ "-k"))]) ++
            levelKeys ++ attrConds,
          acts := [.pref "s" (rv "o") .numericIndiff none (some (.int 0))],
          template := true : Production }
      let rw := (r.rewards.zip (List.range r.rewards.length)).map fun ((gs, v), i) =>
        let gs := gs.map fun g => (g.ren "local" "s").ren "up" "ss"
        { name := s!"{ctx}*reward*{i+1}",
          conds := bind ++ [P "s" "reward-link" (vt "rl")] ++ linkConds gs ++
            goalFlagConds a.schema ts (fun p => paramTypes.lookup p) gs ++
            refConds (noneRefs gs) (gs.filter isCmp) ++ stateConds ts gs ++ noneConds ts a.schema.hd gs,
          acts := [mk "rl" "reward" (rv "w"), mk "w" "value" (ri v)] : Production }
      -- as a table: one `gp` rule per sub-operator, over the finite domains
      let namesOf (ty : String) : String :=
        let h := ((a.schema.holder? ty).map (·.name)).getD ty
        "[ " ++ " ".intercalate (a.objs.filter (·.holder == h) |>.map (·.name)) ++ " ]"
      let ints := "[ " ++ " ".intercalate (r.ints.map toString) ++ " ]"
      let gp (x : SubOp) : String :=
        let lp := paramTypes.map fun (p, ty) => s!"   (<s> ^{p} <{p}>)\n   (<{p}> ^{keyOf ty} {namesOf ty})\n"
        let own := x.params.map fun (p, ty) => s!"   (<o> ^{p} <op-{p}>)\n   (<op-{p}> ^{keyOf ty} {namesOf ty})\n"
        let ats := r.attrs.map fun (p, atr) =>
          match (paramTypes.lookup p).bind (a.schema.attr? · atr) with
          | some { ty := .obj t2, .. } => s!"   (<{p}> ^{atr} <{p}-{atr}>)\n   (<{p}-{atr}> ^{keyOf t2} {namesOf t2})\n"
          | _ => s!"   (<{p}> ^{atr} {ints})\n"
        s!"gp \{{ctx}*rl*{x.name}\n   (state <s> ^name {ctx} ^operator <o> +)\n   (<o> ^name {x.name})\n" ++
          String.join lp ++ String.join own ++ String.join ats ++ "-->\n   (<s> ^operator <o> = 0)\n}\n"
      if r.table then
        [{ path := s!"{ctx}/rl.soar", kind := "FILE_OPERATOR", prods := rw, cmds := subs.map gp }]
      else
      [{ path := s!"{ctx}/rl.soar", kind := "FILE_OPERATOR", prods := tmpl ++ rw }]
  initLocal ++ subs.map subFile ++ rlFile

/-- The substate of a nested sub-operator `x` (from the library), in folder `dir` (under its
parent's folder, as VisualSoar places high-level operators): named `x`, it holds x's parameters
and the task state (`^task-state`, from its parent). `fuel` bounds the depth of the folders
written (a recursive library would otherwise not end). -/
def nestedFiles (a : Agent) : Nat → String → List (String × String) → SubOp → List GenFile
  | 0, _, _, _ => []
  | fuel + 1, dir, inherited, x =>
    -- a recursive sub-operator's substate (a folder below one of the same name) is written once
    if (dir.splitOn "/").dropLast.contains x.name then [] else
    -- the ancestors' parameters are copied down from the superstate (the semantics passes them
    -- to every nested level); x's own parameters come from its operator and shadow them
    let up := inherited.filter fun (p, _) => !x.params.any (·.1 == p)
    let all := up ++ x.params
    let nameProd : Production :=
      { name := s!"{x.name}*elaborate*substate",
        conds := [Ps "s" "impasse" (ct "no-change"), P "s" "attribute" (ct "operator"),
          P "s" "superstate" (vt "ss"), P "ss" "operator" (vt "so"), P "so" "name" (ct x.name),
          P "ss" "task-state" (vt "ts")] ++ x.params.map (fun (p, _) => P "so" p (vt p)) ++
          up.map (fun (p, _) => P "ss" p (vt p)),
        acts := [mk "s" "name" (rs x.name), mk "s" "task-state" (rv "ts")] ++ all.map (fun (p, _) => mk "s" p (rv p)) }
    let bind : List Cond := [Ps "s" "name" (ct x.name), P "s" "superstate" (vt "ss"), P "s" "task-state" (vt "ts")] ++
      all.map (fun (p, _) => P "s" p (vt p))
    let subs := x.subs.filterMap fun n => a.subLib.find? (·.name == n)
    ({ path := s!"{dir}/elaborations.soar", kind := "FILE_OPERATOR", prods := [nameProd] } ::
      (levelFiles a x.name bind "ts" x.locals subs all x.subRl).map (fun f =>
        { f with path := dir ++ (f.path.drop x.name.length).toString })) ++
      (subs.filter (!·.subs.isEmpty)).flatMap fun y => nestedFiles a fuel s!"{dir}/{y.name}" all y

/-- `Operator.subLookahead`: the rules that let Soar's selection library look ahead among the
sub-operators of `o`'s substate. The substate holds the task's objects (`^object`, … — links to
the superstate's, the same identifiers, so the sub-operators' changes are results) and a
`^desired`; its problem space copies the objects two levels deep and not the parameters, which a
copy re-binds to the copied objects by key; flags and derived attributes are elaborated in copies;
a copy is a success or a failure by the guards. -/
def subLookaheadProds (a : Agent) (o : Operator) : List Production :=
  match o.subLookahead with
  | none => []
  | some la =>
  let t := a.schema.task
  let s := a.schema
  let n := o.name
  let isCmp (g : Guard) : Bool := match g with | .cmp .. => true | _ => false
  let holders := s.stateAttrs.filter (fun d => d.multi && match d.ty with | .obj _ => true | _ => false)
  let derivedAttrs := s.types.flatMap fun ty => ty.attrs.filter (·.derived) |>.map (·.name)
  let objs : List Production := holders.map fun h =>
    { name := s!"{n}*elaborate*substate*{h.name}",
      conds := [Ps "s" "name" (ct n), P "s" "superstate" (vt "ss"), P "ss" h.name (vt "x")],
      acts := [mk "s" h.name (rv "x")] }
  let desired : Production :=
    { name := s!"{n}*elaborate*substate*desired",
      conds := [Ps "s" "name" (ct n), N "s" "duplicate-of" []],
      acts := [mk "s" "desired" (rv "d")] }
  let ps : Production :=
    { name := s!"{n}*elaborate*problem-space",
      conds := [Ps "s" "name" (ct n)],
      acts := [mk "s" "problem-space" (rv "p"), mk "p" "name" (rs n),
        mk "p" "default-state-copy" (rs "yes"), mk "p" "default-operator-copy" (rs "yes")] ++
        holders.map (fun h => mk "p" "two-level-attributes" (rs h.name)) ++
        (o.params.map (·.1) ++ derivedAttrs ++ ["task-state"]).map (fun d => mk "p" "dont-copy" (rs d)) }
  let rebind : List Production := o.params.filterMap fun (p, ty) =>
    match s.holder? ty, s.type? ty with
    | some h, some td =>
      let k := td.key.getD "name"
      let nm := s!"{n}*elaborate*copy*{p}"
      let cs : List Cond := [Ps "s" "name" (ct n), P "s" "duplicate-of" (vt "orig"), P "orig" p (vt "x"),
        P "x" k (vt "xk"), P "s" h.name (vt "y"), P "y" k (vt "xk")]
      some ({ name := nm, conds := cs, acts := [mk "s" p (rv "y")] } : Production)
    | _, _ => none
  -- the task's flags and derived attributes, in copies (named like the substate)
  let inCopies (pr : Production) : Production :=
    { pr with name := n ++ "*copy*" ++ pr.name,
              conds := pr.conds.map (fun c => if c == Ps "s" "name" (ct t) then Ps "s" "name" (ct n) else c) ++
                [P "s" "duplicate-of" []] }
  let flags := (deriveProds a ++ flagProds a).map inCopies
  let gconds (gs : List Guard) : List Cond :=
    linkConds gs ++ goalFlagConds s "s" (fun p => o.params.lookup p) gs ++
      refConds (noneRefs gs) (gs.filter isCmp) ++ stateConds "s" gs ++ noneConds "s" s.hd gs
  let base : List Cond := [Ps "s" "name" (ct n), P "s" "tried-tied-operator" [], P "s" "desired" (vt "d")] ++
    o.params.map (fun (p, _) => P "s" p (vt p))
  let success : Production :=
    { name := s!"{n}*evaluate*success", conds := base ++ gconds la.success, acts := [mk "s" "success" (rv "d")] }
  let failures := (la.failure.zip (List.range la.failure.length)).map fun (gs, i) =>
    { name := s!"{n}*evaluate*failure*{i+1}", conds := base ++ gconds gs, acts := [mk "s" "failure" (rv "d")] : Production }
  objs ++ [desired, ps] ++ rebind ++ flags ++ [success] ++ failures

/-- An operator carried out by real sub-operators in its operator no-change substate. The
substate is named after the operator and holds its parameters; sub-operators test and change the
task state (the superstate, `ss`), so their changes are results. -/
def subFiles (a : Agent) (o : Operator) (subs : List SubOp) : List GenFile :=
  let nested := !(subs.all (·.subs.isEmpty))
  let nameProd : Production :=
    { name := s!"{o.name}*elaborate*substate",
      conds := [Ps "s" "impasse" (ct "no-change"), P "s" "attribute" (ct "operator"),
        P "s" "superstate" (vt "ss"), P "ss" "operator" (vt "so")] ++ opWithParams "so" o.name o.params,
      acts := mk "s" "name" (rs o.name) :: o.params.map (fun (p, _) => mk "s" p (rv p)) ++
        -- nested levels find the task state through `^task-state`
        (if nested then [mk "s" "task-state" (rv "ss")] else []) }
  let bind : List Cond := [Ps "s" "name" (ct o.name), P "s" "superstate" (vt "ss")] ++
    o.params.map (fun (p, _) => P "s" p (vt p))
  let la := o.subLookahead
  -- with look-ahead, the level works on the task's objects held by the substate itself (`s`), so a
  -- copy of it (with copies of the objects) is a state the same rules work on
  let ts := if la.isSome then "s" else "ss"
  { path := s!"{o.name}/elaborations.soar", kind := "FILE_OPERATOR", prods := [nameProd] ++ subLookaheadProds a o } ::
    levelFiles a o.name bind ts o.locals subs o.params o.subRl (indiff := la.isNone) (copyApply := la.isSome) ++
    (subs.filter (!·.subs.isEmpty)).flatMap fun x => nestedFiles a 4 s!"{o.name}/{x.name}" o.params x

def opFiles (a : Agent) (o : Operator) : List GenFile :=
  match o.impl with
  | .atomic => [{ path := o.name ++ ".soar", kind := "OPERATOR", prods := proposeProds a o ++ applyProds a o }]
  | .steps ss => { path := o.name ++ ".soar", kind := "HIGH_LEVEL_OPERATOR", prods := proposeProds a o } ::
      stepFiles a o ss
  | .sub xs => { path := o.name ++ ".soar", kind := "HIGH_LEVEL_OPERATOR", prods := proposeProds a o } ::
      subFiles a o xs

/-- Conditions: `s` has objects matching each pattern of `p` (distinct objects). -/
def statePatConds (a : Agent) (st : String) (p : StatePat) (pfx : String) : List Cond :=
  let h := ((a.schema.holder? p.ty).map (·.name)).getD p.ty
  let vars := (List.range p.objs.length).map fun i => s!"{pfx}{i}"
  (vars.zip (List.range vars.length)).map (fun (x, i) =>
      P st h (.var x :: (vars.take i).map fun y => .rel .ne (.var y))) ++
    (p.objs.zip vars).flatMap fun (o, x) => o.map fun (k, n) => P x k (itest n)

/-! ## Selection methods -/

def tieFiles (a : Agent) (hs : List Heur) : List GenFile :=
  let t := a.schema.task
  let imp := "Impasse__Operator_Tie"
  let record : GenFile := { path := "elaborations/last-operator.soar", kind := "FILE_OPERATOR", prods := [
    { name := s!"{t}*apply*record*last-operator",
      conds := [Ps "s" "name" (ct t), P "s" "operator" (vt "o"),
        P "o" "name" [.var "n", .rel .ne (.sym (.str (initOpName a)))]],
      acts := [mk "s" "last-operator" (rv "n")] },
    { name := s!"{t}*apply*remove*last-operator",
      conds := [Ps "s" "name" (ct t), P "s" "last-operator" (vt "l"), P "s" "operator" (vt "o"),
        P "o" "name" [.var "n", .rel .ne (.var "l"), .rel .ne (.sym (.str (initOpName a)))]],
      acts := [rm "s" "last-operator" (rv "l")] }] }
  let elabF : GenFile := { path := imp ++ "/elaborations.soar", kind := "FILE_OPERATOR", prods := [
    { name := s!"{imp}*elaborate*name",
      conds := [Ps "s" "impasse" (ct "tie"), P "s" "attribute" (ct "operator"),
        P "s" "superstate" (vt "ss"), P "ss" "name" (ct t)],
      acts := [mk "s" "name" (rs imp)] },
    { name := s!"{imp}*elaborate*evaluation",
      conds := [Ps "s" "name" (ct imp), P "s" "item" (vt "x")],
      acts := [mk "s" "evaluation" (rv "e"), mk "e" "super-operator" (rv "x")] },
    { name := s!"{imp}*elaborate*last-operator",
      conds := [Ps "s" "name" (ct imp), P "s" "superstate" (vt "ss"), P "ss" "last-operator" (vt "l")],
      acts := [mk "s" "last-operator" (rv "l")] }] }
  let hval : HVal → String := fun | .best => "best" | .worst => "worst" | .equal => "equal" | .reject => "reject" | .better => "better"
  let disj (xs : List String) : Test := match xs with
    | [x] => ct x
    | xs => [.disj (xs.map Sym.str)]
  let evalProds := (hs.zip (List.range hs.length)).map fun (h, i) =>
    { name := s!"{imp}*apply*evaluate-operator*h{i+1}",
      conds := [Ps "s" "name" (ct imp), P "s" "operator" (vt "o"), P "s" "last-operator" (disj h.last),
        P "o" "name" (ct "evaluate-operator"), P "o" "evaluation" (vt "e"),
        P "e" "super-operator" (vt "so"), P "so" "name" (disj h.cands)],
      acts := [mk "e" "value" (rs (hval h.value))] : Production }
  let evalOp : GenFile := { path := imp ++ "/evaluate-operator.soar", kind := "OPERATOR", prods :=
    { name := s!"{imp}*propose*evaluate-operator",
      conds := [Ps "s" "name" (ct imp), P "s" "evaluation" (vt "e"), N "e" "value" []],
      acts := [.pref "s" (rv "o") .acceptable none none, .pref "s" (rv "o") .unaryIndiff none none,
        mk "o" "name" (rs "evaluate-operator"), mk "o" "evaluation" (rv "e")] } :: evalProds }
  let prefActs : HVal → List Action
    | .equal => [.pref "ss" (rv "so") .unaryIndiff none none]
    | .worst => [.pref "ss" (rv "so") .worst none none, .pref "ss" (rv "so") .unaryIndiff none none]
    | .best => [.pref "ss" (rv "so") .best none none, .pref "ss" (rv "so") .unaryIndiff none none]
    | .reject => [.pref "ss" (rv "so") .reject none none]
    | .better => [.pref "ss" (rv "so") .best none none, .pref "ss" (rv "so") .unaryIndiff none none]
  let createOp : GenFile := { path := imp ++ "/create-preferences.soar", kind := "OPERATOR", prods :=
    { name := s!"{imp}*propose*create-preferences",
      conds := [Ps "s" "name" (ct imp),
        .ncc [pp "s" "evaluation" (vt "e")] [[pp "e" "value" []]]],
      acts := [.pref "s" (rv "o") .acceptable none none, .pref "s" (rv "o") .unaryIndiff none none,
        .pref "s" (rv "o") .best none none, mk "o" "name" (rs "create-preferences")] } ::
    [HVal.equal, .worst, .best].map fun v =>
      { name := s!"{imp}*apply*create-preferences*{hval v}",
        conds := [Ps "s" "name" (ct imp), P "s" "operator" (vt "o"), P "o" "name" (ct "create-preferences"),
          P "s" "superstate" (vt "ss"), P "s" "evaluation" (vt "e"), P "e" "value" (ct (hval v)),
          P "e" "super-operator" (vt "so")],
        acts := prefActs v } }
  [record, { path := imp ++ ".soar", kind := "HIGH_LEVEL_IMPASSE_OPERATOR" }, elabF, evalOp, createOp]

/-- A state equal to an ancestor state: each of its `n` objects has a twin there (same non-derived
values). Written with positive conditions only, over the number of objects the task starts with,
so that chunking can trace it: a nested negation over the ancestor (the first version) made
chunking learn over-general rules ("every operator is a partial failure"). -/
def dupProd (t h : String) (keys : List String) (n : Nat) (extra : List Cond := []) (suffix := "")
    (failAttr := "partial-failure") : Production where
  name := t ++ "*evaluate*state*failure*duplicate" ++ suffix
  conds := [Ps "s" "name" (ct t), P "s" "tried-tied-operator" [], P "s" "desired" (vt "d"),
    P "s" "ancestor" (vt "a"), P "a" "name" (ct t)] ++ extra ++
    ((List.range n).flatMap fun i =>
      P "s" h (.var s!"x{i}" :: (List.range i).map fun j => .rel .ne (.var s!"x{j}")) ::
      keys.map (fun k => P s!"x{i}" k (vt s!"k{i}-{k}"))) ++
    ((List.range n).flatMap fun i =>
      P "a" h (vt s!"y{i}") :: keys.map (fun k => P s!"y{i}" k (vt s!"k{i}-{k}")))
  acts := [mk "s" failAttr (rv "d")]

/-- The number of initial objects held by state attribute `h`. -/
def Agent.count (a : Agent) (h : String) : Nat :=
  (a.init.filter (·.1 == h)).length + (a.objs.filter (·.holder == h)).length

/-- Attributes compared and recorded as an object's state: the non-derived ones that are not
links (links are identifiers, different in every copy of a state). -/
def stateKeys (s : Schema) (ty : String) : List String :=
  ((s.type? ty).map (fun o => (o.attrs.filter (fun d => !d.derived && !(match d.ty with | .obj _ => true | _ => false))).map (·.name))).getD []

/-- `Agent.rlWholeState`: every named object's links (by the linked object's key), on state `<s>`,
so a learned value (an RL template's rules, or chunks over a look-ahead's evaluation) is for one
configuration. -/
def wholeStateConds (a : Agent) : List Cond :=
  if !a.rlWholeState then [] else
    (a.objs.zip (List.range a.objs.length)).flatMap fun (nobj, i) =>
      let v := s!"w{i}"
      let key := ((a.schema.types.find? fun ty => (a.schema.holder? ty.name).map (·.name) == some nobj.holder).bind (·.key)).getD "name"
      [P "s" nobj.holder (vt v), P v key (ct nobj.name)] ++
        nobj.links.flatMap fun (l, _) => [P v l (vt s!"{v}-{l}"), P s!"{v}-{l}" key (vt s!"{v}-{l}-{key}")]

def lookaheadFiles (a : Agent) (avoid : List StatePat) (avoidValue : Option Int)
    (dup : FailKind := .partialFailure) (score : Option Score := none) : List GenFile :=
  let t := a.schema.task
  let s := a.schema
  let allHolders := s.stateAttrs.filter (fun d => d.multi && match d.ty with | .obj _ => true | _ => false)
  -- object types some operator (or sub-operator) changes; objects of the other types never change
  -- (e.g. the cells of a board) and are shared by reference (one level) instead of copied
  let allCases := a.ops.flatMap fun o => (o.apply ++ match o.impl with | .sub xs => xs.flatMap (·.apply) | _ => []).map (o, ·)
  let changed : List String := (allCases.flatMap fun (o, c) =>
    c.effects.filterMap fun e => (o.params.lookup e.obj)).eraseDups
  let isChanged (d : AttrDecl) : Bool := match d.ty with | .obj t => changed.contains t | _ => true
  let holders := allHolders.filter isChanged
  let shared := allHolders.filter (!isChanged ·)
  let derivedAttrs := s.types.flatMap fun ty => ty.attrs.filter (·.derived) |>.map (·.name)
  let ps : Production :=
    { name := s!"{t}*elaborate*problem-space",
      conds := [Ps "s" "name" (ct t)],
      acts := [mk "s" "problem-space" (rv "p"), mk "p" "name" (rs t),
        mk "p" "default-state-copy" (rs "yes"), mk "p" "default-operator-copy" (rs "yes")] ++
        holders.map (fun h => mk "p" "two-level-attributes" (rs h.name)) ++
        shared.map (fun h => mk "p" "one-level-attributes" (rs h.name)) ++
        (derivedAttrs ++ ["ancestor"]).map (fun d => mk "p" "dont-copy" (rs d)) }
  let anc : List Production :=
    [{ name := s!"{t}*elaborate*ancestor*superstate",
       conds := [Ps "s" "superstate" (vt "ss"), P "ss" "superstate" []],
       acts := [mk "s" "ancestor" (rv "ss")] },
     { name := s!"{t}*elaborate*ancestor*inherit",
       conds := [Ps "s" "superstate" (vt "ss"), P "ss" "ancestor" (vt "a")],
       acts := [mk "s" "ancestor" (rv "a")] }]
  -- task-state object attributes that some operator (or sub-operator) of this agent can change:
  -- they count in the comparison, in both cases (same object by key; both unset)
  let cases := a.ops.flatMap fun o => o.apply ++ match o.impl with | .sub xs => xs.flatMap (·.apply) | _ => []
  let written := (cases.flatMap fun c => c.stateEffects.map (·.1)).eraseDups
  let stateCmp : List (List Cond × String) := written.foldl (fun acc attr =>
    let key := (s.stateAttrs.find? (·.name == attr)).bind (fun d => match d.ty with
      | .obj ty => (s.type? ty).bind (·.key) | _ => none)
    let k := key.getD "name"
    acc.flatMap fun (cs, sfx) =>
      [(cs ++ [P "s" attr (vt s!"{attr}-s"), P s!"{attr}-s" k (vt s!"{attr}-k"),
               P "a" attr (vt s!"{attr}-a"), P s!"{attr}-a" k (vt s!"{attr}-k")], sfx ++ s!"*{attr}-same"),
       (cs ++ [N "s" attr [], N "a" attr []], sfx ++ s!"*{attr}-none")]) [([], "")]
  let failAttr := match dup with | .partialFailure => "partial-failure" | _ => "failure"
  let dups : List Production := if dup == .off then [] else holders.flatMap fun h => match h.ty with
    | .obj ty => stateCmp.map fun (extra, sfx) =>
        dupProd t h.name (stateKeys s ty) (a.count h.name) extra sfx failAttr
    | _ => []
  let evalAttr := match score with
    | some { expected := true, .. } => "expected-value"
    | _ => "numeric-value"
  let scoreProds : List Production := match score with
    | none => []
    | some { ty, delta := some dl, .. } =>
      if dl.links then
      let h := ((s.holder? ty).map (·.name)).getD ty
      let (p, mv) := dl.old
      -- the destination's and the source's desired targets, by name
      let base : List Cond := [Ps "s" "name" (ct t), P "s" "tried-tied-operator" (vt "o"), P "o" "name" (ct dl.op),
        P "o" dl.obj (vt "x"), P "o" p (vt "p"), P "o" mv (vt "m"), P "s" "desired" (vt "d"),
        P "x" "name" (vt "xn"), P "d" h (vt "dx"), P "dx" "name" (vt "xn"), P "dx" dl.attr (vt "dxt"),
        P "dxt" "name" (vt "dxn"), P "x" dl.attr (vt "xt"), P "xt" "name" (vt "xtn"),
        P "p" "name" (vt "pn"), P "d" h (vt "dp"), P "dp" "name" (vt "pn"), P "dp" dl.attr (vt "dpt"),
        P "dpt" "name" (vt "dpn"), P "m" "name" (vt "mn")]
      [{ name := s!"{t}*evaluate*state*moved-into-place", conds := base ++ [P "xt" "name" (vt "dxn")],
         acts := [mk "s" evalAttr (ri 1)] },
       { name := s!"{t}*evaluate*state*moved-out-of-place", conds := base ++ [P "m" "name" (vt "dpn")],
         acts := [mk "s" evalAttr (ri (-1))] },
       { name := s!"{t}*evaluate*state*moved-neutral",
         conds := base ++ [P "xt" "name" [.rel .ne (.var "dxn")], P "m" "name" [.rel .ne (.var "dpn")]],
         acts := [mk "s" evalAttr (ri 0)] }]
      else
      let h := ((s.holder? ty).map (·.name)).getD ty
      let key := ((s.type? ty).bind (·.key)).getD "name"
      let (p, pa) := dl.old
      let base : List Cond := [Ps "s" "name" (ct t), P "s" "tried-tied-operator" (vt "o"), P "o" "name" (ct dl.op),
        P "o" dl.obj (vt "x"), P "o" p (vt "p"), P "s" "desired" (vt "d"), P "d" h (vt "dx"),
        P "dx" key (vt "k"), P "x" key (vt "k"), P "dx" dl.attr (vt "g")]
      [{ name := s!"{t}*evaluate*state*moved-into-place", conds := base ++ [P "x" dl.attr (vt "g")],
         acts := [mk "s" evalAttr (ri 1)] },
       { name := s!"{t}*evaluate*state*moved-out-of-place", conds := base ++ [P "p" pa (vt "g")],
         acts := [mk "s" evalAttr (ri (-1))] },
       { name := s!"{t}*evaluate*state*moved-neutral",
         conds := base ++ [P "x" dl.attr [.rel .ne (.var "g")], P "p" pa [.rel .ne (.var "g")]],
         acts := [mk "s" evalAttr (ri 0)] }]
    | some sc =>
      let h := ((s.holder? sc.ty).map (·.name)).getD sc.ty
      if !sc.levels.isEmpty then
        -- by levels: the first named object (highest first) whose flag is set gives the value
        let key := ((s.type? sc.ty).bind (·.key)).getD "name"
        let fval (v : Int) := if v % 1000 == 0 then ri (v / 1000) else .sym (.float (Float.ofInt v / 1000).toBits)
        let base : List Cond := [Ps "s" "name" (ct t), P "s" "tried-tied-operator" [], P "s" "desired" (vt "d")]
        let isSet (nm : String) (i : Nat) : List Pat :=
          [pp "s" h (vt s!"l{i}"), pp s!"l{i}" key (ct nm), pp s!"l{i}" sc.levelFlag (itest 1)]
        -- the level above is out of place, tested positively (so chunks over the evaluation test
        -- the configuration): it is not linked to what the goal links it to. Levels are ordered
        -- from the top of the goal stack, so given this level in place, the one above is out of
        -- place exactly when its link differs from the goal's.
        let outOfPlace (nm : String) (i : Nat) : List Cond :=
          match a.goal.links.find? (·.1 == nm) with
          | some (_, attr, tgt) =>
            [P "s" h (vt s!"u{i}"), P s!"u{i}" key (ct nm), P s!"u{i}" attr (vt s!"u{i}t"),
             P s!"u{i}t" key [.rel .ne (.sym (.str tgt))]]
          | none => [.neg (isSet nm i)]
        let n := sc.levels.length
        ((sc.levels.zip (List.range n)).map fun ((nm, v), k) =>
          let above : List Cond := if k == 0 then [] else outOfPlace (sc.levels[k - 1]!).1 (k - 1)
          ({ name := s!"{t}*evaluate*state*level*{nm}",
             conds := base ++ above ++ (isSet nm k).map Cond.pos ++ wholeStateConds a,
             acts := [mk "s" evalAttr (fval v)] } : Production)) ++
        [({ name := s!"{t}*evaluate*state*level*none",
            conds := base ++ (if n == 0 then [] else outOfPlace (sc.levels[n - 1]!).1 (n - 1)) ++ wholeStateConds a,
            acts := [mk "s" evalAttr (ri 0)] } : Production)]
      else
      [{ name := s!"{t}*evaluate*state*score",
         conds := [Ps "s" "name" (ct t), P "s" "tried-tied-operator" [], P "s" "desired" (vt "d"),
           P "s" h (vt "self")] ++ (match sc.name with | some nm => [P "self" "name" (ct nm)] | none => []) ++
           refConds sc.val.refs [],
         acts := [mk "s" evalAttr sc.val.rval] }]
  let avoids := (avoid.zip (List.range avoid.length)).map fun (p, i) =>
    { name := s!"{t}*evaluate*state*avoid*{i+1}",
      conds := [Ps "s" "name" (ct t), P "s" "tried-tied-operator" [], P "s" "desired" (vt "d")] ++
        statePatConds a "s" p "x",
      acts := match avoidValue with
        | none => [mk "s" "partial-failure" (rv "d")]
        | some v => [mk "s" "expected-value" (ri v)] : Production }
  [{ path := "elaborations/problem-space.soar", kind := "FILE_OPERATOR", prods := [ps] },
   { path := "elaborations/ancestors.soar", kind := "FILE_OPERATOR", prods := anc },
   { path := "elaborations/state-evaluation.soar", kind := "FILE_OPERATOR", prods := dups ++ avoids ++ scoreProds }]

def rlFiles (a : Agent) (rewards : List (StatePat × Int)) (failureReward goalReward : Option Int := none)
    (stepCost : Option Int := none) :
    List GenFile :=
  let t := a.schema.task
  let tmpl := a.ops.map fun o =>
    let refs := o.params.flatMap fun (p, ty) => (stateKeys a.schema ty).map fun d => (p, d)
    -- the whole state (`Agent.rlWholeState`): each named object's links, by the linked object's key
    let whole : List Cond := wholeStateConds a
    { name := s!"{t}*rl*{o.name}",
      conds := [Ps "s" "name" (ct t), Pacc "s" "operator" (vt "o")] ++ opWithAll "o" o ++
        refConds refs [] ++ whole,
      acts := [.pref "s" (rv "o") .numericIndiff none (some (.int 0))],
      template := true : Production }
  let rw := (rewards.zip (List.range rewards.length)).map fun ((p, v), i) =>
    { name := s!"{t}*reward*{i+1}",
      conds := [Ps "s" "name" (ct t), P "s" "reward-link" (vt "r")] ++ statePatConds a "s" p "x",
      acts := [mk "r" "reward" (rv "w"), mk "w" "value" (ri v)] : Production }
  let flagRw (attr : String) (r : Option Int) : List Production := match r with
    | none => []
    | some v =>
      [({ name := t ++ "*reward*" ++ attr,
          conds := [Ps "s" "name" (ct t), P "s" "reward-link" (vt "r"), P "s" attr []],
          acts := [mk "r" "reward" (rv "w"), mk "w" "value" (ri v)] } : Production)]
  -- A cost per move: a reward on every decision while the task runs (JL, 6 Nov 2026).
  let stepRw : List Production := match stepCost with
    | none => []
    | some c =>
      [({ name := t ++ "*reward*step",
          conds := [Ps "s" "name" (ct t), P "s" "reward-link" (vt "r")],
          acts := [mk "r" "reward" (rv "w"), mk "w" "value" (.sym (.float (Float.ofInt c / 1000).toBits))] } : Production)]
  [{ path := "rl.soar", kind := "FILE_OPERATOR", prods := tmpl ++ rw ++ flagRw "failure" failureReward ++
      flagRw "success" goalReward ++ stepRw }]

/-! ## Failure states and preference rules -/

/-- `Agent.goalReward`: a reward on the reward link when the goal holds (`^success`). -/
def goalRewardFile (a : Agent) : List GenFile :=
  match a.goalReward with
  | none => []
  | some v =>
    let t := a.schema.task
    [{ path := "elaborations/reward.soar", kind := "FILE_OPERATOR",
       prods := [{ name := t ++ "*reward*goal",
                   conds := [Ps "s" "name" (ct t), P "s" "reward-link" (vt "r"), P "s" "success" []],
                   acts := [mk "r" "reward" (rv "w"), mk "w" "value" (ri v)] }] }]

/-- `^failure <desired>` on any task state with an object satisfying a failure guard. -/
def failureFile (a : Agent) : List GenFile :=
  if a.failure.isEmpty then [] else
  let t := a.schema.task
  let prods := (a.failure.zip (List.range a.failure.length)).map fun (f, i) =>
    let h := ((a.schema.holder? f.ty).map (·.name)).getD f.ty
    { name := s!"{t}*elaborate*failure*{i+1}",
      conds := [Ps "s" "name" (ct t), P "s" "desired" (vt "d"), P "s" h (vt "self")] ++
        linkConds f.guard ++
        refConds (noneRefs f.guard) (f.guard.filter fun g => match g with | .cmp .. => true | _ => false) ++
        noneConds "s" a.schema.hd f.guard,
      acts := [mk "s" "failure" (rv "d")] : Production }
  -- Convention (JL, 6 Nov 2026): a failure state violates a task constraint; entering one at the
  -- top state ends the task (halt). Look-ahead substates evaluate it as a failure instead.
  let haltP : Production :=
    { name := s!"{t}*halt*failure",
      conds := [Ps "s" "superstate" (ct "nil"), P "s" "desired" (vt "d"), P "s" "failure" (vt "d")],
      acts := [.write [.call "crlf" [], rs "Failure state: the task has failed."], .halt] }
  [{ path := "elaborations/failure.soar", kind := "FILE_OPERATOR", prods := prods ++ [haltP] }]

/-- The last task operator applied, as `^last-move`: a record of its name, parameters and value
parameters. Changing it follows the convention for single-valued attributes: one rule replaces an
old record (adds the new, removes the old), another adds the first. -/
def lastMoveFiles (a : Agent) : List GenFile :=
  if a.prefs.isEmpty then [] else
  let needLast := a.prefs.any fun p => !p.sameAsLast.isEmpty || !p.lastGuard.isEmpty
  let t := a.schema.task
  let rec' (o : Operator) : List Action :=
    mk "n" "name" (rs o.name) :: o.params.map (fun (p, _) => mk "n" p (rv p)) ++
      o.vparams.map (fun (p, _) => mk "n" p (rv p))
  let prods := a.ops.flatMap fun o =>
    [{ name := s!"{t}*apply*{o.name}*last-move*replace",
       conds := [Ps "s" "name" (ct t), P "s" "operator" (vt "o"), P "s" "last-move" (vt "l")] ++ opWithAll "o" o,
       acts := [rm "s" "last-move" (rv "l"), mk "s" "last-move" (rv "n")] ++ rec' o : Production },
     { name := s!"{t}*apply*{o.name}*last-move*first",
       conds := [Ps "s" "name" (ct t), P "s" "operator" (vt "o"), N "s" "last-move" []] ++ opWithAll "o" o,
       acts := mk "s" "last-move" (rv "n") :: rec' o }]
  let hval : HVal → PrefKind := fun | .best => .best | .worst => .worst | .equal => .unaryIndiff | .reject => .reject | .better => .better
  let prefs := a.prefs.map fun p =>
    let fl : List Cond := match p.failure with
      | some true => [P "s" "failure" []]
      | some false => [N "s" "failure" []]
      | none => []
    let vars := (p.sameAsLast.zip (List.range p.sameAsLast.length)).map fun ((x, y), i) => (x, y, s!"v{i+1}")
    let o? := a.ops.find? (·.name == p.op)
    -- the candidate's own conditions: its parameters (objects and values) and the guard
    let candConds : List Cond := match o? with
      | none => []
      | some o =>
        if p.guard.isEmpty && p.versus.isEmpty then [] else
        (o.params.map (·.1) ++ o.vparams.map (·.1)).map (fun q => P "o" q (vt q)) ++
        linkConds p.guard ++ goalFlagConds a.schema "s" (fun q => o.params.lookup q) p.guard ++
        refConds (noneRefs p.guard) (p.guard.filter fun g => match g with | .cmp .. => true | _ => false) ++
        stateConds "s" p.guard ++ noneConds "s" a.schema.hd p.guard
    let lastConds : List Cond := if p.sameAsLast.isEmpty && p.lastGuard.isEmpty then [] else
      P "s" "last-move" (vt "l") :: P "l" "name" (ct p.op) :: vars.map (fun (_, y, v) => P "l" y (vt v)) ++
      (match o? with
       | some o => if p.lastGuard.isEmpty then [] else
           (o.params.map (·.1) ++ o.vparams.map (·.1)).map (fun q => P "l" q (vt ("last-" ++ q))) ++
           refConds [] (p.lastGuard.filter fun g => match g with | .cmp .. => true | _ => false)
       | none => [])
    let la : List Cond := if p.inLookahead then
      [P "s" "superstate" (vt "ss"), P "ss" "operator" (vt "so"), P "so" "name" (ct "evaluate-operator")] else []
    { name := s!"{t}*select*{p.name}",
      conds := [Ps "s" "name" (ct t), Pacc "s" "operator" (vt "o")] ++ la ++ fl ++
        P "o" "name" (ct p.op) :: vars.map (fun (x, _, v) => P "o" x (vt v)) ++ lastConds ++ candConds ++
        (if p.value == .better || !p.than.isEmpty then [Pacc "s" "operator" [.var "o2", .rel .ne (.var "o")]] else []) ++
        -- binary preferences: the other operator's name, parameters and the comparisons
        (if p.than.isEmpty then [] else
          let o2ps := match p.than with
            | [n] => ((a.ops.find? (fun (o : Operator) => o.name == n)).map (fun (o : Operator) => o.params)).getD []
            | _ => []
          P "o2" "name" (match p.than with | [n] => ct n | ns => [.disj (ns.map Sym.str)]) ::
          o2ps.map (fun (q, _) => P "o2" q (vt ("other-" ++ q))) ++
          linkConds p.versus ++
          refConds (noneRefs p.versus) (p.versus.filter fun g => match g with | .cmp .. => true | _ => false) ++
          noneConds "s" a.schema.hd p.versus),
      acts := (if p.value == .better then [.pref "s" (rv "o") .better (some (rv "o2")) none]
               else if p.value == .reject && !p.than.isEmpty then [.pref "s" (rv "o") .reject none none]
               else [.pref "s" (rv "o") (hval p.value) none none]) : Production }
  (if needLast then [{ path := "elaborations/last-move.soar", kind := "FILE_OPERATOR", prods := prods }] else []) ++
   [{ path := "preferences.soar", kind := "FILE_OPERATOR", prods := prefs }]

/-- `Agent.epmemModel`: the operator no-change of a look-ahead copy's task operator applies it from
episodic memory. Operators in that substate: `model-query` (cue: the operator, its parameters
being the copy's own objects, and every object of the copy, so the cue's identifiers are shared as
in the episodes), `model-next` (after a full match: the next episode), `model-update` (the changed
attributes of the next episode copied into the copy; the operator marked tried, so the copy is
evaluated), `model-unknown` (no full match, or no next episode: partial success with the value).
The selection library's own tried-tied rules are excised: they would mark the operator tried, and
the copy be evaluated, before it is applied. -/
def epmemModelFiles (a : Agent) : List GenFile :=
  match a.epmemModel with
  | none => []
  | some v =>
  let t := a.schema.task
  let s := a.schema
  let fval : RVal := if v % 1000 == 0 then ri (v / 1000) else .sym (.float (Float.ofInt v / 1000).toBits)
  let base : List Cond := [Ps "s" "impasse" (ct "no-change"), P "s" "attribute" (ct "operator"),
    P "s" "superstate" (vt "e"), P "e" "name" (ct t), P "e" "look-ahead-operator" (vt "o"), P "e" "operator" (vt "o")]
  let propose (nm suffix : String) (extra : List Cond) : Production :=
    { name := s!"{t}*model*propose*{suffix}", conds := base ++ extra,
      acts := [.pref "s" (rv "x") .acceptable none none, .pref "s" (rv "x") .unaryIndiff none none, mk "x" "name" (rs nm)] }
  let holders := s.stateAttrs.filter (fun d => d.multi && match d.ty with | .obj _ => true | _ => false)
  -- the attributes the task operators change, by object type
  let changed : List (String × String) := (a.ops.flatMap fun o => o.apply.flatMap fun c =>
    c.effects.filterMap fun e => (o.params.lookup e.obj).map (·, e.attr)).eraseDups
  let queryOps : List Production := a.ops.map fun o =>
    { name := s!"{t}*model*query*{o.name}",
      conds := [Ps "s" "operator" (vt "m"), P "m" "name" (ct "model-query"), P "s" "superstate" (vt "e"),
        P "s" "epmem" (vt "em"), P "em" "command" (vt "c"), P "e" "look-ahead-operator" (vt "o"),
        P "o" "name" (ct o.name)] ++ o.params.map (fun (p, _) => P "o" p (vt p)) ++
        o.vparams.map (fun (p, _) => P "o" p (vt p)),
      acts := [mk "c" "query" (rv "q"), mk "q" "operator" (rv "qo"), mk "qo" "name" (rs o.name)] ++
        o.params.map (fun (p, _) => mk "qo" p (rv p)) ++ o.vparams.map (fun (p, _) => mk "qo" p (rv p)) ++
        [mk "s" "queried" (rs "yes")] }
  let queryObjs : List Production := holders.map fun h =>
    { name := s!"{t}*model*query*{h.name}",
      conds := [Ps "s" "operator" (vt "m"), P "m" "name" (ct "model-query"), P "s" "superstate" (vt "e"),
        P "s" "epmem" (vt "em"), P "em" "command" (vt "c"), P "c" "query" (vt "q"), P "e" h.name (vt "x")],
      acts := [mk "q" h.name (rv "x")] }
  let next : Production :=
    { name := s!"{t}*model*next",
      conds := [Ps "s" "operator" (vt "m"), P "m" "name" (ct "model-next"), P "s" "epmem" (vt "em"),
        P "em" "command" (vt "c"), P "c" "query" (vt "q")],
      acts := [rm "c" "query" (rv "q"), mk "c" "next" (rv "n"), mk "s" "stepped" (rs "yes")] }
  let updates : List Production := changed.filterMap fun (ty, attr) =>
    match s.holder? ty, s.type? ty with
    | some h, some tyd =>
      let key := tyd.key.getD "name"
      let isLink := match (tyd.attrs.find? (·.name == attr)).map (·.ty) with | some (.obj _) => true | _ => false
      let common : List Cond := [Ps "s" "operator" (vt "m"), P "m" "name" (ct "model-update"), P "s" "superstate" (vt "e"),
        P "s" "epmem" (vt "em"), P "em" "result" (vt "res"), P "res" "retrieved" (vt "r"),
        P "e" h.name (vt "x"), P "x" key (vt "xk"), P "x" attr (vt "cur"),
        P "r" h.name (vt "rx"), P "rx" key (vt "xk"), P "rx" attr (vt "rt")]
      some (if isLink then
        { name := s!"{t}*model*update*{ty}*{attr}",
          conds := common ++ [P "cur" key (vt "ck"), P "rt" key [.rel .ne (.var "ck"), .var "tk"],
            P "e" h.name (vt "tt"), P "tt" key (vt "tk")],
          acts := [rm "x" attr (rv "cur"), mk "x" attr (rv "tt")] }
      else
        { name := s!"{t}*model*update*{ty}*{attr}",
          conds := common.dropLast ++ [P "rx" attr [.rel .ne (.var "cur"), .var "nv"]],
          acts := [rm "x" attr (rv "cur"), mk "x" attr (rv "nv")] })
    | _, _ => none
  let tried : Production :=
    { name := s!"{t}*model*update*tried",
      conds := [Ps "s" "operator" (vt "m"), P "m" "name" (ct "model-update"), P "s" "superstate" (vt "e"),
        P "e" "look-ahead-operator" (vt "o"), P "e" "operator" (vt "o"), P "e" "untried-tied-operator" (vt "o")],
      acts := [mk "e" "tried-tied-operator" (rv "o"), rm "e" "untried-tied-operator" (rv "o")] }
  let unknown : Production :=
    { name := s!"{t}*model*unknown",
      conds := [Ps "s" "operator" (vt "m"), P "m" "name" (ct "model-unknown"), P "s" "superstate" (vt "e"),
        P "e" "superstate" (vt "sel"), P "sel" "operator" (vt "eo"), P "eo" "evaluation" (vt "ev")],
      acts := [mk "ev" "symbolic-value" (rs "partial-success"), mk "ev" "numeric-value" fval] }
  let props : List Production := [
    propose "model-query" "query" [N "s" "queried" (ct "yes")],
    propose "model-next" "next" [P "s" "queried" (ct "yes"), N "s" "stepped" (ct "yes"),
      P "s" "epmem" (vt "em"), P "em" "result" (vt "res"), P "res" "graph-match" (itest 1)],
    -- the next episode's result, not the query's (only a query's result has a graph match)
    propose "model-update" "update" [P "s" "stepped" (ct "yes"), P "s" "epmem" (vt "em"),
      P "em" "result" (vt "res"), P "res" "retrieved" [], N "res" "graph-match" []],
    propose "model-unknown" "unknown*no-match" [P "s" "queried" (ct "yes"), N "s" "stepped" (ct "yes"),
      P "s" "epmem" (vt "em"), P "em" "result" (vt "res"), P "res" "graph-match" (itest 0)],
    propose "model-unknown" "unknown*failure" [P "s" "queried" (ct "yes"), P "s" "epmem" (vt "em"),
      P "em" "result" (vt "res"), P "res" "failure" []]]
  [{ path := "elaborations/epmem-model.soar", kind := "FILE_OPERATOR",
     prods := props ++ queryOps ++ queryObjs ++ [next] ++ updates ++ [tried, unknown],
     cmds := ["excise evaluate-operator*elaborate*state*tried-tied-operator",
              "excise evaluate-operator*elaborate*state*remove*untried-tied-operator"] }]

/-! ## The whole project -/

def firstload (a : Agent) : GenFile :=
  let holders := a.schema.stateAttrs.filter (·.multi)
  let multi := holders.map fun h => s!"multi-attributes {h.name} {a.count h.name + 1}"
  let anc := match a.method with | .lookahead .. => ["multi-attributes ancestor 20"] | _ => []
  let chunk (ss : List String) := ["chunk always", "chunk add-osk on"] ++
    (if a.chunkLocalNegations then [] else ["chunk allow-local-negations off"]) ++
    (if a.chunkBottomOnly then ["chunk bottom-only on"] else []) ++
    ss.map fun x => s!"chunk singleton any {x} any"
  let rl (r d : Nat) := ["rl --set learning on", s!"rl --set learning-rate {Float.ofNat r / 1000}",
    s!"rl --set discount-rate {Float.ofNat d / 1000}", "indifferent-selection --epsilon-greedy"]
  let learn := match a.learning with
    | .none => ["chunk never"]
    | .chunk ss => chunk ss
    | .rl r d => ["chunk never"] ++ rl r d
    | .chunkRl ss r d => chunk ss ++ rl r d
  -- long-term knowledge: semantic memory, loaded once (each object with its type as `^kind`)
  let ltm := if a.ltm.isEmpty then [] else
    ["smem --set learning on",
     "smem --add {\n" ++ String.join ((a.ltm.zip (List.range a.ltm.length)).map fun ((t, vals), i) =>
       -- attributes quoted: the smem --add parser reads a name such as d1 as an identifier
       s!"   (<l{i}> ^kind {t}" ++ String.join (vals.map fun (k, v) => s!" ^|{k}| {v}") ++ ")\n") ++ "}"]
  let epm := if a.epmemModel.isNone then [] else
    ["epmem --set learning on", "epmem --set trigger dc", "epmem --set phase selection"]
  { path := "_firstload.soar", kind := "FILE_OPERATOR", cmds := learn ++ multi ++ anc ++ ltm ++ epm }

/-- Hand-written rules (escape hatches, outside the conventions), each in its own file, headed by
why it is written by hand. -/
def rawFiles (a : Agent) : List GenFile :=
  a.raw.map fun r =>
    let cs : List String := ["# Written by hand (Raw): " ++ r.why, r.text]
    ({ path := r.file ++ ".soar", kind := "FILE_OPERATOR", cmds := cs } : GenFile)

/-- Apply rules (named `task*apply*…`) of a file get `-(<s> ^look-ahead-operator <o>)`. -/
def guardApplyProd (t : String) (p : Production) : Production :=
  if p.name.startsWith (t ++ "*apply*") then { p with conds := p.conds ++ [N "s" "look-ahead-operator" (vt "o")] } else p

def guardApplyFile (t : String) (f : GenFile) : GenFile :=
  { f with prods := f.prods.map (guardApplyProd t) }

def compile (a : Agent) : List GenFile :=
  let base := [firstload a,
    { path := "elaborations/derived.soar", kind := "FILE_OPERATOR", prods := deriveProds a ++ flagProds a },
    { path := "elaborations/goal.soar", kind := "FILE_OPERATOR", prods := goalProds a },
    initFile a] ++
    (if a.subgoaling then [{ path := "elaborations/operator-subgoal.soar", kind := "FILE_OPERATOR", prods := subgoalProds a }] else []) ++
    a.ops.flatMap (opFiles a) ++
    []
  let m := match a.method with
    | .random => []
    | .tieHeuristic hs => tieFiles a hs
    | .lookahead av v dup sc => lookaheadFiles a av v dup sc
    | .rl rs fr gr sc => rlFiles a rs fr gr sc
  let fs := base ++ m ++ failureFile a ++ lastMoveFiles a ++ rawFiles a ++ goalRewardFile a ++ epmemModelFiles a
  -- with episodic memory as the look-ahead's action model, apply rules do not apply the operator
  -- being evaluated in a look-ahead copy
  if a.epmemModel.isNone then fs else
    fs.map (guardApplyFile a.schema.task)

/-- Does the project need Soar's default selection library? -/
def needsSelection (a : Agent) : Bool :=
  (match a.method with | .lookahead .. => true | _ => false) || a.ops.any (·.subLookahead.isSome)

end Agent
