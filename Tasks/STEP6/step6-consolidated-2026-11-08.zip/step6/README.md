# Step 6: Soar agents regenerated from English descriptions

John Laird's English → Lean → Soar agent generation, step 6: the corpus's task agents normalized into families of variants described in a Lean DSL (agentgen), each with an English description; Soar projects generated from the descriptions and compared with the originals at the task level and against soar-lean (the Lean model of Soar 9.6.5). As of 8 Nov 2026.

## Counts

- Corpus: 598 programs; 262 task agents. The rest are Soar unit tests and architecture probes (173), expected-output files (97), fragments and scaffolds (55), RL rule dumps (9) and libraries (2); they are not included.
- The 262 task agents (`index.csv`, one row each):
  - replaced by a generated variant: 140, by 66 variants in 14 families;
  - skipped: 87 (they need an environment or read the input-link, or are `^world`/`^scene` versions, Pyramid instruct agents, or excluded by JL);
  - deferred: 7; not replaced (the original does not work in Soar 9.6.5, or is misfiled): 5; tests: 3;
  - open (not yet addressed): 20.
- Soar vs soar-lean: every generated variant matches, except `blocks-world-hrl`, which differs in its RL rules only (Soar defect 28).

## Layout

```
README.md            this file
step6-summary.pptx   one-slide summary
index.csv            every task agent: family, status, the variant(s) replacing it, note, rules, load file
families/<family>/
  README.md          the family report: variants, assumptions, task-level and soar-lean results
  originals/<agent>/<version>/   the originals replaced (as given; each once)
  english/<variant>.md           English description of each variant (generated from the Lean)
  generated/<variant>/           the VisualSoar project generated for it (load <variant>.soar)
  generated/<family>.json        the compiler's output for the family (all variants), from which the projects are written
  lean/<Family>.lean             the Lean description: task, variants, assumptions, theorems
  comparison/                    harnesses, task-level results, soar-lean comparisons (leancmp*);
                                 task/: the family's corpus programs as flat load files, replaced or not
skipped/README.md    the task agents not replaced, by status and reason (listed, not copied)
agentgen/            the DSL, compiler, English generator and tools, to regenerate everything
notes/               the queue, decisions, process notes, the corpus classification, Soar-Conventions.xlsx,
                     soar-defects/ (Soar 9.6.5 kernel defects found, with reproductions),
                     leancmp-small/ (soar-lean runs of the small families), small-baseline/ and
                     small-before/ (outputs kept to check that compiler changes left other families unchanged)
```

Graph Search and HRL Navigation have a task description in Lean and a report but no variant (deferred, and skipped for I/O). `families/games` has no variant (its agents are open).

## Families

| Family | Variants | Originals replaced |
|---|---|---|
| [Arithmetic](families/arithmetic/README.md) | 8 | 13 |
| [Blocks World](families/blocks-world/README.md) | 13 | 55 |
| [Counting](families/counting/README.md) | 2 | 2 |
| [Eight/Fifteen Puzzle](families/eight-puzzle/README.md) | 3 | 12 |
| [Hello World](families/hello-world/README.md) | 1 | 4 |
| [KenKen](families/kenken/README.md) | 16 | 1 |
| [Knights](families/knights/README.md) | 2 | 2 |
| [Left-Right](families/left-right/README.md) | 1 | 1 |
| [Missionaries & Cannibals](families/missionaries-cannibals/README.md) | 4 | 12 |
| [Pyramid](families/pyramid/README.md) | 3 | 4 |
| [Tic-Tac-Toe](families/tictactoe/README.md) | 1 | 1 |
| [Towers of Hanoi](families/towers-of-hanoi/README.md) | 2 | 13 |
| [Wizards](families/wizards/README.md) | 1 | 2 |
| [Water Jug](families/water-jug/README.md) | 9 | 18 |
| [Graph Search](families/graph-search/README.md) | 0 | 0 |
| [HRL Navigation](families/hrl-navigation/README.md) | 0 | 0 |

## Regenerating

`agentgen/`: Lean 4.35 (`lake build agentgen`); `agentgen FAMILY OUT.json`, then `python3 -I tools/vsproject.py OUT.json PROJECTS DEFAULT_DIR` (the default selection library, for look-ahead variants).
