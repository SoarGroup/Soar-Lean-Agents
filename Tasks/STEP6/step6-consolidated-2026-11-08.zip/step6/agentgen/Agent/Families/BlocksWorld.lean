import Agent.DSL
import Agent.Sem

/-!
# Family: Blocks World

75 originals (step 6, `families/blocks-world`). The task: blocks on a table, each on the table or
on one other block; move a clear block onto the table or onto another clear block until the
desired stacking holds. The methods vary: simple search-control preferences (BW-Simple,
blocks-world-simple), one-step and deeper look-ahead with the selection library (BW-LA,
blocks-world-lookahead, the look-ahead demos), look-ahead with state evaluation and RL (BW-LA-state-
eval), hierarchical operators (move-block carried out by pick-up/put-down with a gripper;
BW-Hierarchical, blocks-world-hierarchical, hierarchical look-ahead), operator subgoaling (means-
ends analysis; BW-Op-Subgoal, blocks-world-operator-subgoaling, ±RL), RL (BW-RL, blocks-world-RL),
hierarchical RL, episodic memory. This file has the task and the variants built so far.

Representation: one object type for the blocks and the table, each with a `name`, `table` (1 for
the table) and a changing link `on` (what it rests on; the table rests on nothing). The originals
keep separate `^ontop` objects (`^top-block`, `^bottom-block`); `move-block` changes the bottom
block, here the moved block's `on`.
-/

namespace Agent.BlocksWorld

def obj : String := "object"

/-- Nothing is on `p`. -/
def clear (p : String) : Guard := .noneSuch obj [("on", .eq, .obj p)]

def clearAttr : AttrDecl where
  name := "clear"
  ty := .int
  derived := true
  doc := "1 when something can be put on it: the table, or a block with nothing on it"

def objAttrs (withClear : Bool) : List AttrDecl :=
  [{ name := "name", ty := .sym [], doc := "the block's name (A, B, …) or table" },
   { name := "table", ty := .int, doc := "1 for the table, 0 for a block" },
   { name := "on", ty := .obj obj, doc := "what it rests on (changes as blocks move; the table has none)" },
   { name := "in-place", ty := .int, derived := true,
     doc := "1 when it is where the goal wants it all the way down (the table always)" }] ++
  (if withClear then [clearAttr] else [])

def schema (task : String) (withClear : Bool := false) : Schema where
  task := task
  stateAttrs := [{ name := "object", ty := .obj obj, multi := true, doc := "The blocks and the table." }]
  types := [{ name := obj, key := some "name", attrs := objAttrs withClear }]

/-- "Clear" (the operator-subgoaling originals' `^clear`): the table, or an object with nothing on it. -/
def clearFlags : List Flag := [
  { ty := obj, attr := "clear", base := [.cmp "self" "table" .eq (.lit 1)], doc := "the table is clear" },
  { ty := obj, attr := "clear", base := [clear "self"], doc := "nothing is on it" }]

/-- "In place" (the originals' `^inplace-object`): the table is; a block is when it is on what the
goal puts it on and that is in place. -/
def inPlace : Flag where
  ty := obj
  attr := "in-place"
  base := [.cmp "self" "table" .eq (.lit 1)]
  via := "on"
  step := [.desired "self" "on" "below"]
  doc := "in place: the table, or on its desired object which is in place"

/-- Move a clear block onto the table or onto another clear block. -/
def moveBlock : Operator where
  name := "move-block"
  params := [("block", obj), ("dest", obj)]
  propose := [
    .cmp "block" "table" .eq (.lit 0),
    clear "block",
    .distinct "block" "dest",
    .cmp "block" "on" .ne (.obj "dest")]
  proposeOr := [
    [.cmp "dest" "table" .eq (.lit 1)],
    [.cmp "dest" "table" .eq (.lit 0), clear "dest"]]
  apply := [{ effects := [{ obj := "block", attr := "on", val := .obj "dest" }] }]
  doc := "Move a clear block onto the table or onto another clear block."

/-- move-block for operator subgoaling (the operator-subgoaling originals): proposed whenever it is
relevant (a block, a different destination it is not already on); its preconditions — the block
and the destination are clear — are what its substate works on. -/
def moveBlockOpSub : Operator where
  name := "move-block"
  params := [("block", obj), ("dest", obj)]
  propose := [.cmp "block" "table" .eq (.lit 0), .distinct "block" "dest", .cmp "block" "on" .ne (.obj "dest")]
  pre := [.flag "block" "clear" true, .flag "dest" "clear" true]
  pregoals := [("clear", "block"), ("clear", "dest")]
  apply := [{ effects := [{ obj := "block", attr := "on", val := .obj "dest" }] }]
  doc := "Move a block onto the table or onto another block; both must be clear."

/-- move-block for operator subgoaling with relevant moves only (BW-Op-Subgoal-RL,
blocks-world-operator-subgoaling-RL): at the top state, a move the goal asks for (a block onto what
the goal puts it on); in a subgoal, moving the block that is on something the subgoal wants clear
onto a clear object. Two proposal rules (disjoint: the first tests the task's goal, which holds
only at the top state; the second the subgoal's). -/
def moveBlockRelevant : Operator :=
  { moveBlockOpSub with
    proposeOr := [
      [.desired "block" "on" "dest"],
      [.wants "clear" "block" (some "on"), .flag "dest" "clear" true]] }

/-- The operator-subgoaling originals' search control (wants: the substate's goals). -/
def opSubControl : List Pref := [
  { name := "avoid-clobbering", op := "move-block", value := .worst, sameAsLast := [],
    guard := [.wants "clear" "dest" none], doc := "Do not put a block on something the subgoal wants clear." },
  { name := "prefer-ontop", op := "move-block", value := .best, sameAsLast := [],
    guard := [.desired "block" "on" "dest"], doc := "Prefer a move the goal asks for." },
  { name := "prefer-clearing", op := "move-block", value := .best, sameAsLast := [],
    guard := [.wants "clear" "block" (some "on")], doc := "Prefer moving the block that is on something the subgoal wants clear." }]

/-- An instance: blocks with what each starts on, and the desired `on` of each block. -/
structure Instance where
  start : List (String × String)
  goal : List (String × String)

/-- The operator-subgoaling originals' instance: A on B, B and C on the table; goal A on B on C. -/
def threeOpSub : Instance := { start := [("A", "B"), ("B", "table"), ("C", "table")],
                               goal := [("A", "B"), ("B", "C"), ("C", "table")] }

/-- The originals' three-block instance: C on A, A and B on the table; goal A on B on C. -/
def three : Instance := { start := [("A", "table"), ("B", "table"), ("C", "A")],
                          goal := [("A", "B"), ("B", "C"), ("C", "table")] }

/-- The originals' five-block instance (BW-Simple, blocks-world-simple): C on A, A and D on the
table, E on D, B on E; goal A on B on C on D on E. -/
def five : Instance := { start := [("A", "table"), ("B", "E"), ("C", "A"), ("D", "table"), ("E", "D")],
                         goal := [("A", "B"), ("B", "C"), ("C", "D"), ("D", "E"), ("E", "table")] }

/-- The RL originals' four-block instance (BW-RL, blocks-world-RL): C on A, A and D on the table,
B on D; goal A on B on C on D on the table. -/
def four : Instance := { start := [("A", "table"), ("B", "D"), ("C", "A"), ("D", "table")],
                         goal := [("A", "B"), ("B", "C"), ("C", "D"), ("D", "table")] }

/-- The search control of the simple originals (P6, P7): moving a block that is not in place
onto the table is best; moving a block onto the in-place object the goal puts it on is better
than any other move. -/
def simpleControl : List Pref := [
  { name := "out-of-place-to-table", op := "move-block", value := .best, sameAsLast := [],
    guard := [.flag "block" "in-place" false, .cmp "dest" "table" .eq (.lit 1)],
    doc := "Move a block that is not in place to the table." },
  { name := "onto-desired-in-place", op := "move-block", value := .better, sameAsLast := [],
    guard := [.flag "dest" "in-place" true, .desired "block" "on" "dest"],
    doc := "Move a block onto what the goal puts it on, when that is in place." }]

/-- BW-LA-state-eval's evaluation of a look-ahead state: by how much of the goal stack is in
place, from the bottom (C 0.3, C and B 0.6, all 1.0; none 0), as an expected value. -/
def stackLevels : Score := { ty := obj, levels := [("A", 1000), ("B", 600), ("C", 300)], expected := true }

/-- blocks-world-epmem's evaluation: blocks in place from the bottom of the goal stack, C 1, C and B
2, all 3, none 0, compared (higher is better). -/
def epmemLevels : Score := { ty := obj, levels := [("A", 3000), ("B", 2000), ("C", 1000)] }

/-- The search control of the look-ahead originals: never move the same block twice in a row. -/
def notTwice : List Pref := [
  { name := "reject-twice", op := "move-block", value := .reject, sameAsLast := [("block", "block")],
    inLookahead := true, doc := "In look-ahead, do not move the block just moved." }]

def assumptions : List Assumption := [
  { id := "A1", text := "Representation: one object type for blocks and the table, with `name`, `table` (1 for the table) and a changing link `on`. The originals keep `^ontop` objects (`^top-block`, `^bottom-block`) and `^type block/table`; `move-block` changes an ontop's bottom block, here the moved block's `on` (a changing link, `block.on := dest`)." },
  { id := "A2", text := "move-block(block, dest): proposed when the block is clear and not already on dest, and dest is the table or another clear block (two proposal rules, disjoint). The originals elaborate `^clear` (blocks with nothing on them, and always the table) and propose from it." },
  { id := "A3", text := "Goal: the desired `on` of every block, as `^desired` links to the task's own objects (the originals' desired ontops); success halts at the top state." },
  { id := "A5", text := "Simple variants: the originals' P6 (moving a block that is not in place to the table is best) and P7 (moving a block onto the in-place object the goal puts it on is better than every other move, binary preferences); \"in place\" is a derived flag (elaborated recursively along `on`, as the originals' `^inplace-object`). The originals elaborate success from in-place objects; here the goal is the desired links. blocks-world V2 also has three RL template rules with no reward or RL settings; they are dropped." },
  { id := "A6", text := "RL variant (BW-RL V1, V2, blocks-world-RL V2): reward 1 when the goal holds (then halt), Soar's default RL (learning rate 0.3, discount 0.9, epsilon-greedy 0.1), learning over repeated runs (init-soar between). The originals list 5120 RL rules, one for each configuration of the four blocks and each move, all at 0; here one RL template tests the operator and the whole state (`Agent.rlWholeState`: every block's `on`), so Soar makes the same rules, each when its configuration and move first occur." },
  { id := "A7", text := "Operator subgoaling with relevant moves (BW-Op-Subgoal-RL V1, blocks-world-operator-subgoaling-RL V2–V4): move-block is proposed only when relevant — at the top state a move the goal asks for, in a subgoal moving a block off something the subgoal wants clear onto a clear object — and chosen at random. The originals also turn RL on with an RL template over the subgoal's operator, the configuration and the move, and rewards (1 at the goal; 1 when a subgoal's blocks are clear); in Soar 9.6.5 every rule instantiated from that template is malformed (its state and its operator are the same identifier: defect 28), so none ever matches and the choice is random. The variant has that behaviour: no RL. Four blocks (V1; V4's rules are V1's; V2/V3 differ in a rule name and one redundant test)." },
  { id := "A8", text := "Look-ahead with state evaluation (BW-LA-state-eval V1, V2, blocks-world-lookahead-state-evaluation V2, V3; their task rules are identical): a tie is resolved by one-step look-ahead whose state is scored by how much of the goal stack is in place (`Score.levels`: C 0.3, B 0.6, A 1.0, none 0) as an expected value; chunking makes RL rules from the evaluations (`Learning.chunkRl`, Soar's default rate 0.3 and discount 0.9), which RL tunes in later runs, with reward 1 at the goal (`Agent.goalReward`, the originals' reward.soar). The score rules test every block's `on` (`Agent.rlWholeState`), as the originals' `evaluate-state` rules test every `ontop`, so each chunk is for one configuration; the goal gives no `^success` inside the look-ahead (`Agent.lookaheadSuccess := false`): as in the originals, a look-ahead reaching it is valued 1.0, so every evaluation chunk is an RL rule and none is a best preference. The originals score with an `evaluate-state` operator in the evaluation substate (best, so the look-ahead is one step); here an elaboration gives the same expected value. Their `^moveable` excludes a `last-bottom` that nothing sets, so it is `clear`. No duplicate-state detection and no rejection of moving the same block again, as the originals." },
  { id := "A9", text := "Hierarchical (BW-Hierarchical V1, V2, blocks-world-hierarchical V2–V5): move-block is carried out by pick-up and put-down in its substate, and those by gripper operators (move the gripper up, above an object, down; close; open) in theirs. The gripper is an object of the task state (position, open, above, holding, empty); the gripper operators change it directly, and close/open pick up and put down the block. The originals write gripper commands to the output-link and simulate the world with o-supported rules on the top state (`apply*…*external`); after close the gripper is above what the block stood on (here: above the block), and the held block keeps its `ontop` (here: `on`) until it is put down. pick-up's and put-down's gripper operators have distinct names here (move-gripper-up-holding, …-above-destination, …-down-holding), the originals use the same names in both substates. Search control: the simple originals' P6/P7. Clear excludes a held block, as the originals." },
  { id := "A10", text := "Episodic memory as the look-ahead's action model (blocks-world-epmem V2): a tie is resolved by one-step look-ahead in which move-block is not applied by its rules but recalled (`Agent.epmemModel`). The cue is the copy's configuration with the move selected. A full match is followed by the next episode, whose links are copied into the copy; when nothing matches, the move is valued 2.5 as partial success, above every in-place value, so unexperienced moves are tried. A copy is valued by the blocks in place from the bottom of the goal stack (C 1, B 2, A 3, none 0; higher better). The goal gives no success inside the look-ahead. Moving the block just moved is rejected in look-ahead. Episodic memory records every decision at the selection phase; chunking is off. The originals' update operator is proposed as soon as the next episode is asked for, so it first fires on the query's result (the state before the move) and marks the operator tried before the next episode arrives; here it waits for the next episode. The originals' guard against a match without the operator selected (an interrupt) is not needed: the cue's operator is matched only by a selected operator." },
  { id := "A11", text := "Hierarchical RL (blocks-world-HRL V1, run with RL on as its readme says): move-block is proposed as in the originals (a clear block onto the table or onto a block with nothing on it; no gripper condition, so picking up another block does not retract it and lose the substate's reward), chosen at the top state by RL over the whole configuration (as `blocks-world-rl`) with reward 1 at the goal, and carried out in its substate by pick-up (any clear block, when the gripper is empty) and put-down (the held block onto any clear object), chosen by RL (`SubRl`: a template per sub-operator over its parameters and move-block's, by name). The substate's rewards: 1 when move-block's block is on its destination; −1 while the gripper holds another block. The original rewards 1 for the same, and −1 when something is put on the moving block; with no penalty for picking up another block, its runs loop picking up a block and putting it back where it was (no reward either way), and 8 of 10 seeds never solve in 3000 decisions. The gripper is the hierarchical variants' gripper object (only `empty` and `holding` are used); a held block keeps its `on` until it is put down and is not clear. Soar defect 28 applies to the templates after init-soar (runs are in fresh agents carrying the learned rules), and to a substate template that tests `^superstate`: its instances test `(state <s1> ^superstate <s1>)` and never fire, so the substate templates do not test it." },
  { id := "A12", text := "Hierarchical RL at the gripper level (block-world-HRL-3level V1 with its default parameters, blocks-world-hierarcical-RL V2): move-block is chosen by the simple control (P6/P7) and carried out by pick-up and put-down as in the hierarchical variant; their gripper operators are proposed whenever they can apply (up, down, above the level's target, close, open; in put-down: up, down, above the destination, release) and chosen by RL over the gripper's position, open, empty and above, and the level's block and destination (`SubRl` with `attrs`), with rewards local to pick-up's substate (1 holding the block, −1 closed on nothing) and put-down's (1 when the block is on the destination). The RL rules are a table of `gp` rules, one per combination of values (`SubRl.table`), as the originals write them: Soar's template instances at this level are almost all malformed (defect 28), so templates do not learn. Differences: the originals move the gripper above any clear object (here only the level's target), close on any block (here the block or nothing), and keep the gripper on the top state with output-link commands (here the task's gripper object, changed directly). blocks-world-hierarcical-RL V2 learns at all three levels; with all levels learning the originals do not converge (their readme says so; 9 of 10 seeds never solve in 3000 decisions)." },
  { id := "A13", text := "Hierarchical look-ahead (BW-Hierarchical-LA V3, blocks-world-hierachical-lookahead V2–V6): move-block is chosen by the simple control; in its substate pick-up (any clear block) and put-down (the held block onto any clear object) tie and the tie is resolved by look-ahead (`SubLookahead`) on a copy of the substate, where they apply by their specified effects: success when move-block's block is on its destination, failure when the gripper holds another block or put down the block elsewhere. For real they are carried out by the gripper operators. The originals copy the top state with rules of their own (ontop structures, the gripper) and evaluate the same way. Chunking is off: with chunking, Soar learns an overgeneral reject chunk from the failure evaluation (the test that the held block is not the moving block is lost), which rejects every pick-up in later runs (decisions per run 102–1000). The originals learn with chunking, and after the first run take 42 decisions." },
  { id := "A4", text := "Look-ahead variant: the selection library, no duplicate-state detection (the originals have none), chunking on. As in the originals, moving the block just moved is rejected inside look-ahead states only (at the top state it may be the only move)." }]

def mk (task : String) (inst : Instance) (method : Method) (prefs : List Pref) (learning : Learning)
    (opsub : Bool := false) : Agent where
  schema := schema task opsub
  init := []
  objs := { holder := "object", name := "table", vals := [("table", 1)] } ::
    inst.start.map fun (b, on) => { holder := "object", name := b, vals := [("table", 0)], links := [("on", on)] }
  derive := []
  ops := [if opsub then moveBlockOpSub else moveBlock]
  goal := { ty := obj, vals := [], links := inst.goal.map fun (b, on) => (b, "on", on) }
  constraints := []
  flags := inPlace :: (if opsub then clearFlags else [])
  subgoaling := opsub
  prefs := prefs
  method := method
  learning := learning
  assumptions := assumptions


/-! ## Hierarchical: move-block carried out by pick-up and put-down, and those by gripper operators

BW-Hierarchical V1, V2, blocks-world-hierarchical V2–V5: three levels. The gripper is an object
of the task state (`position` 1 up / 0 down, `open`, `above`, `holding`, `empty`). -/

def gripperT : String := "gripper"

def gripperAttrs : List AttrDecl := [
  { name := "name", ty := .sym [], doc := "gripper" },
  { name := "position", ty := .int, doc := "1 up, 0 down" },
  { name := "open", ty := .int, doc := "1 open, 0 closed" },
  { name := "empty", ty := .int, doc := "1 holding nothing, 0 holding the block `holding`" },
  { name := "above", ty := .obj obj, doc := "what the gripper is above" },
  { name := "holding", ty := .obj obj, doc := "the block held (meaningful when empty = 0)" }]

def hierSchema (task : String) : Schema where
  task := task
  stateAttrs := [{ name := "object", ty := .obj obj, multi := true, doc := "The blocks and the table." },
                 { name := "gripper", ty := .obj gripperT, multi := true, doc := "The gripper." }]
  types := [{ name := obj, key := some "name", attrs := objAttrs true },
            { name := gripperT, key := some "name", attrs := gripperAttrs }]

/-- Clear: the table; or an object with nothing on it that the gripper does not hold. -/
def hierClear : List Flag := [
  { ty := obj, attr := "clear", base := [.cmp "self" "table" .eq (.lit 1)], doc := "the table is clear" },
  { ty := obj, attr := "clear", base := [clear "self", .noneSuch gripperT [("empty", .eq, .lit 0), ("holding", .eq, .obj "self")]],
    doc := "nothing is on it and it is not held" }]

def geff (a : String) (v : Expr) : Effect := { obj := "g", attr := a, val := v }

/-- The gripper operators (the bottom level), in pick-up's and put-down's substates. -/
def gripperSubs : List SubOp := [
  -- pick-up
  { name := "move-gripper-up", propose := [.cmp "g" "position" .eq (.lit 0), .cmp "g" "empty" .eq (.lit 1), .cmp "g" "above" .ne (.obj "block")],
    apply := [{ effects := [geff "position" (.lit 1)] }], doc := "Raise the empty gripper." },
  { name := "move-gripper-above", propose := [.cmp "g" "position" .eq (.lit 1), .cmp "g" "empty" .eq (.lit 1), .cmp "g" "above" .ne (.obj "block")],
    apply := [{ effects := [geff "above" (.obj "block")] }], doc := "Move the empty gripper above the block." },
  { name := "move-gripper-down", propose := [.cmp "g" "position" .eq (.lit 1), .cmp "g" "above" .eq (.obj "block"), .cmp "g" "empty" .eq (.lit 1)],
    apply := [{ effects := [geff "position" (.lit 0)] }], doc := "Lower the gripper onto the block." },
  { name := "close-gripper", propose := [.cmp "g" "position" .eq (.lit 0), .cmp "g" "open" .eq (.lit 1), .cmp "g" "empty" .eq (.lit 1), .cmp "g" "above" .eq (.obj "block")],
    apply := [{ effects := [geff "open" (.lit 0), geff "empty" (.lit 0), geff "holding" (.obj "block")] }],
    doc := "Close the gripper on the block: it holds it." },
  -- put-down
  { name := "move-gripper-up-holding", propose := [.cmp "g" "position" .eq (.lit 0), .cmp "g" "above" .ne (.obj "dest")],
    apply := [{ effects := [geff "position" (.lit 1)] }], doc := "Raise the gripper with the block." },
  { name := "move-gripper-above-destination", propose := [.cmp "g" "position" .eq (.lit 1), .cmp "g" "above" .ne (.obj "dest")],
    apply := [{ effects := [geff "above" (.obj "dest")] }], doc := "Move the gripper above the destination." },
  { name := "move-gripper-down-holding", propose := [.cmp "g" "position" .eq (.lit 1), .cmp "g" "above" .eq (.obj "dest")],
    apply := [{ effects := [geff "position" (.lit 0)] }], doc := "Lower the gripper onto the destination." },
  { name := "open-gripper", propose := [.cmp "g" "position" .eq (.lit 0), .cmp "g" "open" .eq (.lit 0), .cmp "g" "above" .eq (.obj "dest")],
    apply := [{ effects := [geff "open" (.lit 1), geff "empty" (.lit 1), geff "above" (.obj "block"),
                            { obj := "block", attr := "on", val := .obj "dest" }] }],
    doc := "Open the gripper: the block is on the destination." }]

/-- move-block for the hierarchical originals: proposed for a clear block and a clear destination
(the table, or a block nothing is on and the gripper does not hold), when the gripper is empty or
holds this block; carried out by pick-up and put-down. Its effect: the block is on the
destination and the gripper is down above it, open and empty. -/
def moveBlockHier : Operator where
  name := "move-block"
  params := [("block", obj), ("dest", obj), ("g", gripperT)]
  propose := [.cmp "block" "table" .eq (.lit 0), clear "block", .distinct "block" "dest", .cmp "block" "on" .ne (.obj "dest"),
    .flag "dest" "clear" true, .noneSuch gripperT [("empty", .eq, .lit 0), ("holding", .ne, .obj "block")]]
  apply := [{ effects := [{ obj := "block", attr := "on", val := .obj "dest" }, geff "position" (.lit 0), geff "open" (.lit 1),
                          geff "empty" (.lit 1), geff "above" (.obj "block"), geff "holding" (.obj "block")] }]
  impl := .sub [
    { name := "pick-up", propose := [.cmp "g" "empty" .eq (.lit 1), clear "block"], apply := [],
      subs := ["move-gripper-up", "move-gripper-above", "move-gripper-down", "close-gripper"],
      doc := "Pick up the block, with the gripper operators." },
    { name := "put-down", propose := [.cmp "g" "empty" .eq (.lit 0), .cmp "g" "holding" .eq (.obj "block")], apply := [],
      subs := ["move-gripper-up-holding", "move-gripper-above-destination", "move-gripper-down-holding", "open-gripper"],
      doc := "Put the block down on the destination, with the gripper operators." }]
  doc := "Move a clear block onto the table or another clear block, by picking it up and putting it down."

def mkHier (task : String) (inst : Instance) : Agent where
  schema := hierSchema task
  init := []
  objs := ({ holder := "object", name := "table", vals := [("table", 1)] } ::
    inst.start.map fun (b, on) => { holder := "object", name := b, vals := [("table", 0)], links := [("on", on)] }) ++
    [{ holder := "gripper", name := "gripper", vals := [("position", 1), ("open", 1), ("empty", 1)],
       links := [("above", "table"), ("holding", "table")] }]
  derive := []
  ops := [moveBlockHier]
  subLib := gripperSubs
  goal := { ty := obj, vals := [], links := inst.goal.map fun (b, on) => (b, "on", on) }
  constraints := []
  flags := inPlace :: hierClear
  prefs := simpleControl
  method := .random
  learning := .none
  assumptions := assumptions

/-! ## Hierarchical RL: move-block's pick-up and put-down chosen by RL

blocks-world-HRL V1 (with RL on, as its readme says to): pick-up may take any clear block and put-down
may put the held block on any clear object; RL chooses among them in move-block's substate, with
rewards local to it. -/

/-- move-block for hierarchical RL: as `moveBlockHier`, carried out by pick-up and put-down
sub-operators with their own parameters, chosen by RL. -/
def moveBlockHrl : Operator where
  name := "move-block"
  params := [("block", obj), ("dest", obj), ("g", gripperT)]
  -- clear as in the originals: nothing on it (a held block is clear); no gripper condition, so
  -- picking up another block, or the destination, does not retract it (its substate's rewards,
  -- and its RL updates, would be lost)
  propose := moveBlock.propose ++ [.flag "dest" "free" true]
  apply := [{ effects := [{ obj := "block", attr := "on", val := .obj "dest" }, geff "empty" (.lit 1)] }]
  impl := .sub [
    { name := "pick-up", params := [("x", obj)],
      propose := [.cmp "g" "empty" .eq (.lit 1), .cmp "x" "table" .eq (.lit 0), clear "x"],
      apply := [{ effects := [geff "empty" (.lit 0), geff "holding" (.obj "x")] }],
      doc := "Pick up a clear block (any)." },
    { name := "put-down", params := [("y", obj), ("d", obj)],
      propose := [.cmp "g" "empty" .eq (.lit 0), .cmp "g" "holding" .eq (.obj "y"), .distinct "y" "d", .flag "d" "clear" true],
      apply := [{ effects := [{ obj := "y", attr := "on", val := .obj "d" }, geff "empty" (.lit 1)] }],
      doc := "Put the held block on a clear object (any)." }]
  subRl := some { rewards := [
    ([.cmp "block" "on" .eq (.obj "dest")], 1),
    ([.cmp "g" "empty" .eq (.lit 0), .cmp "g" "holding" .ne (.obj "block")], -1)] }
  doc := "Move a clear block onto the table or another clear block, by picking up and putting down blocks, chosen by RL."

def freeAttr : AttrDecl := { name := "free", ty := .int, derived := true, doc := "1 for the table and for an object with nothing on it (held or not)" }

/-- Free (the originals' clear): the table, or an object with nothing on it (held or not). -/
def freeFlags : List Flag := [
  { ty := obj, attr := "free", base := [.cmp "self" "table" .eq (.lit 1)], doc := "the table is free" },
  { ty := obj, attr := "free", base := [clear "self"], doc := "nothing is on it" }]

def hrlSchema (task : String) : Schema :=
  let h := hierSchema task
  { h with types := h.types.map fun t => if t.name == obj then { t with attrs := t.attrs ++ [freeAttr] } else t }

def mkHrl (task : String) (inst : Instance) : Agent :=
  { mkHier task inst with schema := hrlSchema task, ops := [moveBlockHrl], subLib := [], prefs := [], method := .rl [] none (some 1), learning := .rl 300 900, rlWholeState := true, flags := inPlace :: hierClear ++ freeFlags }

/-! ## Hierarchical RL at the gripper level (block-world-HRL-3level V1, blocks-world-hierarcical-RL V2)

move-block chosen by the simple control (P6/P7), carried out by pick-up and put-down (as the
hierarchical variant), and those by gripper operators proposed whenever they can apply (move up,
move down, move above the level's target, close, open) and chosen by RL, with rewards local to
pick-up's and put-down's substates. -/

def hrlGripperSubs : List SubOp := [
  -- pick-up's level (target: the block)
  { name := "up", propose := [.cmp "g" "position" .eq (.lit 0)],
    apply := [{ effects := [geff "position" (.lit 1)] }], doc := "Raise the gripper." },
  { name := "down", propose := [.cmp "g" "position" .eq (.lit 1)],
    apply := [{ effects := [geff "position" (.lit 0)] }], doc := "Lower the gripper." },
  { name := "above-block", propose := [.cmp "g" "position" .eq (.lit 1), .cmp "g" "above" .ne (.obj "block")],
    apply := [{ effects := [geff "above" (.obj "block")] }], doc := "Move the raised gripper above the block." },
  { name := "close", propose := [.cmp "g" "open" .eq (.lit 1)],
    apply := [
      { guard := [.cmp "g" "position" .eq (.lit 0), .cmp "g" "above" .eq (.obj "block"), .cmp "g" "empty" .eq (.lit 1)],
        effects := [geff "open" (.lit 0), geff "empty" (.lit 0), geff "holding" (.obj "block")] },
      { guard := [.cmp "g" "position" .eq (.lit 1)], effects := [geff "open" (.lit 0)] },
      { guard := [.cmp "g" "position" .eq (.lit 0), .cmp "g" "above" .ne (.obj "block")], effects := [geff "open" (.lit 0)] }],
    doc := "Close the gripper: on the block when it is down above it, otherwise on nothing." },
  { name := "open", propose := [.cmp "g" "open" .eq (.lit 0), .cmp "g" "empty" .eq (.lit 1)],
    apply := [{ effects := [geff "open" (.lit 1)] }], doc := "Open the empty gripper." },
  -- put-down's level (target: the destination; the gripper holds the block)
  { name := "up-holding", propose := [.cmp "g" "position" .eq (.lit 0)],
    apply := [{ effects := [geff "position" (.lit 1)] }], doc := "Raise the gripper with the block." },
  { name := "down-holding", propose := [.cmp "g" "position" .eq (.lit 1)],
    apply := [{ effects := [geff "position" (.lit 0)] }], doc := "Lower the gripper with the block." },
  { name := "above-dest", propose := [.cmp "g" "position" .eq (.lit 1), .cmp "g" "above" .ne (.obj "dest")],
    apply := [{ effects := [geff "above" (.obj "dest")] }], doc := "Move the raised gripper above the destination." },
  { name := "release", propose := [.cmp "g" "open" .eq (.lit 0), .cmp "g" "position" .eq (.lit 0)],
    apply := [
      { guard := [.cmp "g" "above" .eq (.obj "dest")],
        effects := [geff "open" (.lit 1), geff "empty" (.lit 1), geff "above" (.obj "block"), { obj := "block", attr := "on", val := .obj "dest" }] },
      { guard := [.cmp "g" "above" .ne (.obj "dest")], effects := [geff "open" (.lit 1), geff "empty" (.lit 1)] }],
    doc := "Open the lowered gripper: the block is on the destination when the gripper is above it, otherwise it stays where it was." }]

def gripperState : List (String × String) := [("g", "position"), ("g", "open"), ("g", "empty"), ("g", "above")]

def moveBlockHrl3 : Operator :=
  { moveBlockHier with impl := .sub [
    { name := "pick-up", propose := [.cmp "g" "empty" .eq (.lit 1), clear "block"], apply := [],
      subs := ["up", "down", "above-block", "close", "open"],
      subRl := some { rewards := [([.cmp "g" "empty" .eq (.lit 0), .cmp "g" "holding" .eq (.obj "block")], 1),
                                  ([.cmp "g" "open" .eq (.lit 0), .cmp "g" "empty" .eq (.lit 1)], -1)], attrs := gripperState, table := true },
      doc := "Pick up the block, with gripper operators chosen by RL." },
    { name := "put-down", propose := [.cmp "g" "empty" .eq (.lit 0), .cmp "g" "holding" .eq (.obj "block")], apply := [],
      subs := ["up-holding", "down-holding", "above-dest", "release"],
      subRl := some { rewards := [([.cmp "block" "on" .eq (.obj "dest"), .cmp "g" "empty" .eq (.lit 1)], 1)], attrs := gripperState, table := true },
      doc := "Put the block down on the destination, with gripper operators chosen by RL." }] }

def mkHrl3 (task : String) (inst : Instance) : Agent :=
  { mkHier task inst with ops := [moveBlockHrl3], subLib := hrlGripperSubs, learning := .rl 300 900 }

/-! ## Hierarchical look-ahead (BW-Hierarchical-LA V3, blocks-world-hierachical-lookahead V2–V6)

move-block chosen by the simple control; in its substate, pick-up (any clear block) and put-down
(the held block onto any clear object) tie and the tie is resolved by look-ahead on a copy of the
substate (`SubLookahead`), where they apply by their effects; for real they are carried out by
gripper operators, as in the hierarchical variant. -/

def hlaGripperSubs : List SubOp := [
  { name := "move-gripper-up", propose := [.cmp "g" "position" .eq (.lit 0), .cmp "g" "empty" .eq (.lit 1), .cmp "g" "above" .ne (.obj "x")],
    apply := [{ effects := [geff "position" (.lit 1)] }], doc := "Raise the empty gripper." },
  { name := "move-gripper-above", propose := [.cmp "g" "position" .eq (.lit 1), .cmp "g" "empty" .eq (.lit 1), .cmp "g" "above" .ne (.obj "x")],
    apply := [{ effects := [geff "above" (.obj "x")] }], doc := "Move the empty gripper above the block." },
  { name := "move-gripper-down", propose := [.cmp "g" "position" .eq (.lit 1), .cmp "g" "above" .eq (.obj "x"), .cmp "g" "empty" .eq (.lit 1)],
    apply := [{ effects := [geff "position" (.lit 0)] }], doc := "Lower the gripper onto the block." },
  { name := "close-gripper", propose := [.cmp "g" "position" .eq (.lit 0), .cmp "g" "open" .eq (.lit 1), .cmp "g" "empty" .eq (.lit 1), .cmp "g" "above" .eq (.obj "x")],
    apply := [{ effects := [geff "open" (.lit 0), geff "empty" (.lit 0), geff "holding" (.obj "x")] }],
    doc := "Close the gripper on the block: it holds it." },
  { name := "move-gripper-up-holding", propose := [.cmp "g" "position" .eq (.lit 0), .cmp "g" "above" .ne (.obj "d")],
    apply := [{ effects := [geff "position" (.lit 1)] }], doc := "Raise the gripper with the block." },
  { name := "move-gripper-above-destination", propose := [.cmp "g" "position" .eq (.lit 1), .cmp "g" "above" .ne (.obj "d")],
    apply := [{ effects := [geff "above" (.obj "d")] }], doc := "Move the gripper above the destination." },
  { name := "move-gripper-down-holding", propose := [.cmp "g" "position" .eq (.lit 1), .cmp "g" "above" .eq (.obj "d")],
    apply := [{ effects := [geff "position" (.lit 0)] }], doc := "Lower the gripper onto the destination." },
  { name := "open-gripper", propose := [.cmp "g" "position" .eq (.lit 0), .cmp "g" "open" .eq (.lit 0), .cmp "g" "above" .eq (.obj "d")],
    apply := [{ effects := [geff "open" (.lit 1), geff "empty" (.lit 1), geff "above" (.obj "y"), { obj := "y", attr := "on", val := .obj "d" }] }],
    doc := "Open the gripper: the block is on the destination." }]

/-- The look-ahead's evaluation of a copy of move-block's substate: success when the block is on
the destination; failure when the gripper holds another block, or is empty with the block not on
the destination (after a put-down). -/
def hlaEval : SubLookahead where
  success := [.cmp "block" "on" .eq (.obj "dest")]
  failure := [[.cmp "g" "empty" .eq (.lit 0), .cmp "g" "holding" .ne (.obj "block")], [.cmp "g" "empty" .eq (.lit 1), .cmp "block" "on" .ne (.obj "dest")]]

def moveBlockHla : Operator where
  name := "move-block"
  params := [("block", obj), ("dest", obj), ("g", gripperT)]
  propose := moveBlockHrl.propose
  apply := moveBlockHrl.apply
  impl := .sub [
    { name := "pick-up", params := [("x", obj)],
      propose := [.cmp "g" "empty" .eq (.lit 1), .cmp "x" "table" .eq (.lit 0), clear "x"],
      apply := [{ effects := [geff "empty" (.lit 0), geff "holding" (.obj "x")] }],
      subs := ["move-gripper-up", "move-gripper-above", "move-gripper-down", "close-gripper"],
      doc := "Pick up a clear block (any)." },
    { name := "put-down", params := [("y", obj), ("d", obj)],
      propose := [.cmp "g" "empty" .eq (.lit 0), .cmp "g" "holding" .eq (.obj "y"), .distinct "y" "d", .flag "d" "clear" true],
      apply := [{ effects := [{ obj := "y", attr := "on", val := .obj "d" }, geff "empty" (.lit 1)] }],
      subs := ["move-gripper-up-holding", "move-gripper-above-destination", "move-gripper-down-holding", "open-gripper"],
      doc := "Put the held block on a clear object (any)." }]
  subLookahead := some hlaEval
  doc := "Move a clear block onto the table or another clear block, by picking up and putting down blocks, chosen by look-ahead."

def mkHla (task : String) (inst : Instance) : Agent :=
  { mkHier task inst with schema := hrlSchema task, ops := [moveBlockHla], subLib := hlaGripperSubs, flags := inPlace :: hierClear ++ freeFlags }

def variants : List (String × Agent × List String) := [
  ("blocks-world-operator-subgoaling", mk "blocks-world" threeOpSub .random opSubControl .none true,
    ["blocks-world-operator-subgoaling V1, V3, V6", "BW-Op-Subgoal V1", "FunctionalTests_testBlocksWorldOperatorSubgoaling V1"]),
  ("blocks-world-operator-subgoaling-chunk", mk "blocks-world" threeOpSub .random opSubControl (.chunk []) true,
    ["blocks-world-operator-subgoaling V4", "ChunkingDemoTests_Demo_Blocks_World_Operator_Subgoaling V1"]),
  ("blocks-world-simple", mk "blocks-world" five .random simpleControl .none,
    ["BW-Simple V1, V2", "blocks-world-simple V2–V4"]),
  ("blocks-world-simple-3", mk "blocks-world" three .random simpleControl .none,
    ["blocks-world V2, V3"]),
  ("blocks-world-rl", { mk "blocks-world" four (.rl [] none (some 1)) [] (.rl 300 900) with rlWholeState := true },
    ["BW-RL V1, V2", "blocks-world-RL V2"]),
  ("blocks-world-operator-subgoaling-relevant", { mk "blocks-world" four .random [] .none true with ops := [moveBlockRelevant] },
    ["BW-Op-Subgoal-RL V1", "blocks-world-operator-subgoaling-RL V2–V4"]),
  ("blocks-world-look-ahead-state-eval", { mk "blocks-world" three (.lookahead [] none .off (some stackLevels)) [] (.chunkRl [] 300 900) with goalReward := some 1, rlWholeState := true, lookaheadSuccess := false },
    ["BW-LA-state-eval V1, V2", "blocks-world-lookahead-state-evaluation V2, V3"]),
  ("blocks-world-epmem", { mk "blocks-world" three (.lookahead [] none .off (some epmemLevels)) notTwice .none with lookaheadSuccess := false, epmemModel := some 2500 },
    ["blocks-world-epmem V2"]),
  ("blocks-world-hrl", mkHrl "blocks-world" three,
    ["blocks-world-HRL V1"]),
  ("blocks-world-hrl-3level", mkHrl3 "blocks-world" three,
    ["block-world-HRL-3level V1", "blocks-world-hierarcical-RL V2"]),
  ("blocks-world-hierarchical-lookahead", mkHla "blocks-world" three,
    ["BW-Hierarchical-LA V3", "blocks-world-hierachical-lookahead V2–V6"]),
  ("blocks-world-hierarchical", mkHier "blocks-world" three,
    ["BW-Hierarchical V1, V2", "blocks-world-hierarchical V2–V5"]),
  ("blocks-world-look-ahead", mk "blocks-world" three (.lookahead [] none .off) notTwice (.chunk []),
    ["blocks-world-lookahead V1–V4", "BW-LA V1, V2", "BW-LA-X V1", "blocks-world-look-ahead V1, V2",
     "ChunkingDemoTests_Demo_Blocks_World_Look_Ahead V1", "FunctionalTests_testBlocksWorldLookAhead V1"])]

/-- Every variant obeys the conventions. -/
theorem conventions : variants.all (fun v => check v.2.1 == []) = true := by decide

/-- The three-block instance: three moves (C to the table, B onto C, A onto B), no fewer. -/
theorem three_shortest : ((mk "bw" three .random [] .none).bfs 4).1.map List.length = some 3 := by native_decide

/-- The five-block instance: six moves at least (C, B and E must leave their places first). -/
theorem five_shortest : ((mk "bw" five .random [] .none).bfs 7).1.map List.length = some 6 := by native_decide

/-- Operator subgoaling decides every step of its three-block instance: 3 moves (A to the table,
B onto C, A onto B), each choice left unique by the preferences. -/
theorem opsub_three : (mk "bw" threeOpSub .random opSubControl .none true).runOpSub 30 = some 3 := by native_decide

/-- The simple control decides every step of the three-block instance: following it, the goal is
reached in 3 moves with no random choice. -/
theorem simple_three : (mk "bw" three .random simpleControl .none).runPrefs 10 = some 3 := by native_decide



/-- The four-block instance: four moves at least (C to the table, C onto D, B onto C, A onto B). -/
theorem four_shortest : ((mk "bw" four .random [] .none).bfs 5).1.map List.length = some 4 := by native_decide

/-- Hierarchical: from every state reachable in three moves, each proposed move-block's gripper
operators produce exactly its specified effect. -/
theorem hier_refines : (mkHier "blocks-world" three).refinesSub 3 40 = true := by native_decide

end Agent.BlocksWorld
