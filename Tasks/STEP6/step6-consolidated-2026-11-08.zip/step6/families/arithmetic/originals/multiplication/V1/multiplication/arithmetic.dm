59
SOAR_ID 0
SOAR_ID 1
SOAR_ID 2
SOAR_ID 3
SOAR_ID 4
ENUMERATION 5 1 state
ENUMERATION 6 1 nil
ENUMERATION 7 1 arithmetic
ENUMERATION 8 1 initialize-arithmetic
SOAR_ID 9
ENUMERATION 10 1 process-column
SOAR_ID 11
ENUMERATION 12 1 next-column
SOAR_ID 13
SOAR_ID 14
ENUMERATION 15 1 nil
SOAR_ID 16
ENUMERATION 17 1 finish-problem
INTEGER_RANGE 18 -2147483648 2147483647
INTEGER_RANGE 19 -2147483648 2147483647
INTEGER_RANGE 20 -2147483648 2147483647
SOAR_ID 21
INTEGER_RANGE 22 0 9
INTEGER_RANGE 23 0 9
INTEGER_RANGE 24 0 1
SOAR_ID 25
ENUMERATION 26 1 state
ENUMERATION 27 2 get-digit1 process-column
ENUMERATION 28 1 compute-result
SOAR_ID 29
ENUMERATION 30 1 carry-borrow
SOAR_ID 31
ENUMERATION 32 1 get-digit1
SOAR_ID 33
ENUMERATION 34 1 get-digit2
SOAR_ID 35
INTEGER_RANGE 36 0 9
INTEGER_RANGE 37 0 1
ENUMERATION 38 1 write-result
SOAR_ID 39
SOAR_ID 40
SOAR_ID 41
ENUMERATION 42 1 state
ENUMERATION 43 1 get-digit1
ENUMERATION 44 1 write-digit1
SOAR_ID 45
SOAR_ID 46
ENUMERATION 47 1 state
ENUMERATION 48 1 carry-borrow
ENUMERATION 49 1 new-column
SOAR_ID 50
SOAR_ID 51
ENUMERATION 52 1 retrieve-facts
ENUMERATION 53 3 addition multiplication subtraction
STRING 54
INTEGER_RANGE 55 0 9
INTEGER_RANGE 56 0 9
ENUMERATION 57 1 compute-result
SOAR_ID 58
81
0 arithmetic 40
0 arithmetic-problem 13
0 io 1
0 name 7
0 operator 4
0 operator 9
0 operator 11
0 operator 16
0 operator 51
0 superstate 6
0 top-state 0
0 type 5
1 input-link 2
1 output-link 3
4 name 8
9 name 10
11 name 12
13 columns 14
13 current-column 14
13 one-column 14
13 operation 53
13 operation-symbol 54
14 carry-borrow 24
14 digit1 18
14 digit2 19
14 next-column 14
14 next-column 15
14 result 20
16 name 17
21 carry-borrow 23
21 digit1 22
21 digit2 22
21 product 55
21 product 56
21 sum 22
25 arithmetic 40
25 arithmetic-problem 13
25 carry-borrow 37
25 current-column 14
25 digit1 36
25 digit2 36
25 name 27
25 operator 29
25 operator 31
25 operator 33
25 operator 35
25 operator 39
25 result 36
25 superstate 0
25 top-state 0
25 type 26
29 name 28
31 name 30
33 name 32
35 name 34
39 name 38
40 facts 21
40 multiplication 21
41 arithmetic 40
41 arithmetic-problem 13
41 carry-borrow 37
41 current-column 14
41 digit1 36
41 digit2 36
41 name 43
41 operator 45
41 operator 58
41 result 36
41 superstate 25
41 top-state 0
41 type 42
45 name 44
46 current-column 14
46 name 48
46 operator 50
46 superstate 25
46 top-state 0
46 type 47
50 name 49
51 name 52
58 name 57
