# Blocks World — step 6 (in progress)

Lean: `agentgen/Agent/Families/BlocksWorld.lean`. 75 originals, flattened in `task/`, all run in Soar 9.6.5 (`results/orig`, 10 seeds, cap 2000 decisions; summary in `compare.csv`).

## Stage 1 (6 Nov 2026): changing links, and the look-ahead variant

### New general DSL features
- **Changing links.** An operator may set an object-valued attribute to one of its object parameters (`Expr.obj p`: `block.on := obj dest`); the semantics keeps such links in the state (as the target's index); `check` types them. Static links (e.g. cells' neighbours) are unchanged.
- **Comparing with an object**: `Atom.obj p` (`block.on ≠ obj dest`; inside `noneSuch`: "nothing is on `p`").
- **Goal by links** (`Goal.links`): named objects linked as desired (A on B …); `^desired` links to the task's own objects, and the success test compares the targets by name (look-ahead copies point to copies).
- **Proposal disjunction** (`Operator.proposeOr`): one proposal rule per disjoint alternative ("dest is the table" / "dest is a clear block").
- **Look-ahead-only preferences** (`Pref.inLookahead`), and links are optional on named objects (the table rests on nothing).

### Variant `blocks-world-look-ahead` (3 blocks: C on A, A and B on the table → A on B on C)

Replaces blocks-world-lookahead V1–V4, BW-LA V1/V2, BW-LA-X V1, blocks-world-look-ahead V1/V2, ChunkingDemoTests_Demo_Blocks_World_Look_Ahead V1, FunctionalTests_testBlocksWorldLookAhead V1.

| Agent | Solved (10 seeds) | Median decisions | Chunks |
|---|---|---|---|
| blocks-world-lookahead V1, V3; BW-LA V1, V2; BW-LA-X V1 (book versions) | 4/10 | 2000 (loops) | 9–11 |
| blocks-world-look-ahead V1 / V2 | 6/10 / 10/10 | 51 / 30 | 6 / 5 |
| ChunkingDemo Look_Ahead V1 | 10/10 | 43 | 6 |
| FunctionalTests LookAhead V1 | 10/10 | 51.5 | 0 (chunking off) |
| blocks-world-lookahead V2, V4 | 0/10 | — | (V4 never moves) |
| **generated blocks-world-look-ahead** | **5/10** | — (5 loop to the cap) | 7 |

The generated agent behaves like the book versions: when it does not solve, it loops (chunks lock a cycle, as in M&C). **Why the demo solves 10/10:** its copy of the selection library is edited — `selection*pass-back-success` passes back only `required-success` (the book library also passes back `success`/`partial-success`), and the look-ahead operator is required with all others rejected. Passing back success from a deeper level is exactly what made M&C's look-ahead chunks loop ("success" = goal still reachable). This bears on the M&C chunk question.

Soar 9.6.5 vs soar-lean: MATCH (`leancmp/chunk.out`: 23 decisions, 54 WMEs, 7 chunks).

Theorems: `conventions`; `three_shortest` (3 moves, no fewer).

### Assumptions (A1–A4, in BlocksWorld.lean)
- A1 representation: one object type for blocks and table with `name`, `table` (1 for the table) and a changing link `on`, instead of `^ontop` objects and `^type`.
- A2 move-block(block, dest): two disjoint proposal rules (dest = table / dest = clear block), instead of an elaborated `^clear`.
- A3 goal: desired `on` of every block (`^desired` links), success halts.
- A4 look-ahead: library as is, no duplicate detection, chunking; moving the block just moved is rejected only in look-ahead (as the originals).

## Stage 2 (6–7 Nov 2026): simple control and operator subgoaling

### New general DSL features
- **Recursive derived flags** (`Agent.flags`): a 0/1 attribute elaborated from base cases and along a link (Blocks World's "in place": the table; a block on what the goal puts it on, which is in place). Several `Flag`s with one attribute give alternative base cases ("clear": the table, or nothing on it).
- **Goal-link guard** (`Guard.desired o attr t`): the goal puts `o` on `t` (compared by name, so it also works in look-ahead copies).
- **Flag guard** (`Guard.flag`) and **binary "better than every other" preference** (`HVal.better`, Soar `o > o2`); the semantics applies better before best/worst, as Soar's decision procedure.
- **Operator subgoaling** (`Operator.pre`, `pregoals`, `Agent.subgoaling`, `Guard.wants`): proposals say when an operator is relevant; its preconditions are required only by the apply rules; selected without them, it gets a substate named like the task that shares the task's objects and has the preconditions as `^desired`; preferences can test what the substate wants. `Agent.runOpSub` follows this deterministically (outermost pending operator applies as soon as its preconditions hold).

### Variants

| Variant | Replaces | Original | Generated |
|---|---|---|---|
| blocks-world-simple (5 blocks) | BW-Simple V1/V2, blocks-world-simple V2–V4 | 10/10, 7–8 decisions | 20/20, 6–7 moves, 7–8 decisions |
| blocks-world-simple-3 | blocks-world V2, V3 | 10/10, 4 decisions | 20/20, 3 moves, 4 decisions |
| blocks-world-operator-subgoaling | blocks-world-operator-subgoaling V1, V3, V6; BW-Op-Subgoal V1; FunctionalTests OperatorSubgoaling V1 | 10/10, 5 decisions | 20/20, 5 decisions |
| blocks-world-operator-subgoaling-chunk | blocks-world-operator-subgoaling V4; ChunkingDemo Operator_Subgoaling V1 | 10/10, 5 decisions, 1 chunk | 20/20, 3 decisions, 3 chunks |

All four MATCH soar-lean (`leancmp/plain.out`, `leancmp/chunk.out`). Theorems: `five_shortest` (6 moves), `simple_three` (the simple control decides every step: 3 moves), `opsub_three` (operator subgoaling decides every step: 3 moves).

Harness fix: several originals keep their blocks under `^world` (blocks-world-simple V3/V4, blocks-world-lookahead V2, blocks-world-hierarchical V4, operator-subgoaling V3, RL V3, …); they were scored 0/10 by mistake and are 10/10 (`compare.csv` updated).

### Assumptions added
- A5 simple variants: P6 (best: an out-of-place block to the table) and P7 (better: onto the in-place object the goal puts it on); "in place" as a recursive flag; blocks-world V2's three stray RL template rules dropped.
- A6 operator subgoaling: move-block proposed when relevant (a block, a different destination it is not on); preconditions block clear and destination clear (a "clear" flag: the table, or nothing on it); substate goals `^clear` both; the originals' three preferences (avoid clobbering what the subgoal wants clear: worst; a move the goal asks for: best; moving the block that sits on something the subgoal wants clear: best).

## Still to do in this family
- Look-ahead with state evaluation (+RL), operator subgoaling with RL, RL, hierarchical (pick-up/put-down with a gripper simulated through the output link — needs I/O), hierarchical look-ahead, HRL.
- Not replaced (to confirm): blocks-world-epmem, count-blocks, cube-stack, opsub-core, blocksworld V1–V3, blocks-opsub, the `_expected` chunk files.

## Regenerated 7 Nov 2026 (17:05): operator-subgoal `^desired` variable

The compiler now names the operator subgoal's `^desired` variable `<sgd>`. It was `<d>`, which clashed with Towers of Hanoi's parameter `d`. In the operator-subgoaling variants only that variable name changed. Their runs are unchanged (5 and 3 decisions, solved on seeds 1–3), and soar-lean matches with and without chunking (`leancmp-sgd/`).

## Queue work, 8 Nov 2026: RL and operator subgoaling with relevant moves

### `blocks-world-rl` replaces BW-RL V1, V2 and blocks-world-RL V2

The three originals are the same agent:
- Four blocks: C on A, A and D on the table, B on D. Goal: A on B on C on D on the table.
- Every legal move is proposed.
- Reward 1 at the goal, then halt.
- Soar's default RL, learning over repeated runs.
- 5,120 hand-written RL rules, one per configuration of the four blocks and move, all at 0.

The variant uses one RL template over the operator and the whole state. This is the new `Agent.rlWholeState`: the template also tests every named object's links, here each block's `on`. Soar makes the same rules, each when its configuration and move first occur.

Soar defect 28 (RL template variable map, `init-soar` case) applies here. After `init-soar`, rules instantiated from the template are malformed: distinct variables collapse into one identifier, e.g. `(state <o1> ^on <o1> … ^object <o1>)`, so they never match. With `init-soar` between runs the variant learned more slowly (runs 91–100: 9.2 decisions against V1's 6.8) and made up to 8,021 rules.
- So the harness (`rlharness.py --fresh`) runs each episode in a new agent that sources the RL rules learned so far with their values, renamed `carried*N`. This is the same workaround as the Missionaries & Cannibals harness.
- BW-RL V1 is unaffected because its rules are hand-written, not instantiated.

Results (Soar 9.6.5, 10 seeds; mean decisions per run, initialize and halt included, minimum 6):

| Agent | Runs 1–10 | Runs 21–30 | Runs 51–60 | RL rules |
|---|---|---|---|---|
| BW-RL V1 (`init-soar` between runs) | 90 | 7.7 | 6.5 | 5,120 |
| `blocks-world-rl` (fresh agent per run) | 75 | 7.1 | 6.6 | 814 (mean) |

All runs solved. Soar vs soar-lean (`leancmp-rl/`, `--rl --explore`): MATCH, 30 decisions, 167 RL rules with equal values.

### `blocks-world-operator-subgoaling-relevant` replaces BW-Op-Subgoal-RL V1 and blocks-world-operator-subgoaling-RL V2–V4

The originals are operator subgoaling on the same four blocks. `move-block` is proposed only when relevant:
- at the top state, a move the goal asks for;
- in a subgoal, moving the block that is on something the subgoal wants clear onto a clear object.

All proposals are indifferent.

The originals also turn RL on, with:
- an RL template over the subgoal's operator, the configuration and the move;
- rewards of 1 at the goal, and 1 when a subgoal's two blocks are clear.

Every rule Soar instantiates from that template is malformed (the state and the operator are the same identifier: defect 28), so none matches and the choice is random. The variant reproduces that behaviour, with no RL (assumption A7).

The variant uses `proposeOr` with two rules:
- `.desired "block" "on" "dest"`: holds only at the top state, where `^desired` is the task's goal;
- `.wants "clear" "block" (on)` plus the destination clear.

Results (Soar 9.6.5, seeds 1–20): both solve 20/20.

| Agent | Mean decisions | Median | Range |
|---|---|---|---|
| BW-Op-Subgoal-RL V1 | 12.7 | 11 | 6–25 |
| `blocks-world-operator-subgoaling-relevant` | 7.0 | 7 | 5–9 |

Soar vs soar-lean: MATCH (6 decisions).

Open issue: parallel application in operator subgoaling. When a move in the deepest substate makes several waiting superoperators applicable at once, Soar fires all their apply rules in the same phase.
- In seed 1 of the variant, one decision moved B to the table, then A onto B and C onto B together, so for that phase two blocks were on B. It recovered, and the run ended solved.
- The Lean semantics applies one operator at a time and never reaches such a state.
- The originals cascade the same way: decision 7 of BW-Op-Subgoal-RL V1 moves B to the table and C onto D together. This probably explains part of the difference in decisions.
- A fix would make a superoperator's apply rule wait while its substate has an operator selected, or apply only the innermost.

### blocks-world-operator-subgoaling-lookahead V2: not working, no variant

It has 15 rules: no operator-subgoal rules and no selection library. The two goal moves are proposed without preferences, so an operator tie arises, and state no-change impasses then nest every decision; it never moves a block.

### Fix (JL, 8 Nov 2026: have the compiler prevent it): no parallel application in operator subgoaling

Cause, found in a trace of seed 1 (`watch 5`):
- Soar applies operators level by level, deepest first. After B went to the table at depth 3, the waiting move at depth 2 (C onto B) applied, and then the top-level move (A onto B) applied in the same phase.
- The `clear` flags were elaborated in every state named `blocks-world`. The substates share the task's objects, so B's `^clear 1` had support from several levels, and the support from one level had not yet retracted when the depth-1 apply rule matched.
- A first attempt was an apply-rule test that no substate has an operator selected. It does nothing, because the deeper substate is already gone when the next level applies.

The compiler now elaborates flags and derived attributes only in the task's own states, not in operator-subgoal substates (`-(<s> ^type operator-subgoal)`), when the agent uses operator subgoaling. Each flag then has one support, which retracts before the next level's apply rule is matched. Operators that become applicable together still apply in the same phase when each is still legal; an operator that is no longer legal does not apply.

Results (Soar 9.6.5, seeds 1–20, checked after every decision):

| Variant | Solved | Decisions | Decisions with two blocks on one object |
|---|---|---|---|
| `blocks-world-operator-subgoaling` | 20/20 | 5 | 0 |
| `blocks-world-operator-subgoaling-chunk` | 20/20 | 5 (1 chunk) | 0 |
| `blocks-world-operator-subgoaling-relevant` | 20/20 | mean 14.2, range 7–25 (was 7.0, 5–9) | 0 (was 18) |
| BW-Op-Subgoal-RL V1 | 20/20 | mean 12.7, range 6–25 | — |

The relevant-moves variant is now close to its originals: most of the earlier difference was the illegal parallel moves.

Soar vs soar-lean (`leancmp-flags/`, with chunking): MATCH for all three, and for `towers-of-hanoi-mea`.

## Queue work, 8 Nov 2026 (continued): state evaluation and hierarchy

### `blocks-world-look-ahead-state-eval` replaces BW-LA-state-eval V1, V2, blocks-world-lookahead-state-evaluation V2, V3

One-step look-ahead at ties. A look-ahead state is scored by how much of the goal stack (C, then B, then A) is in place: 0, 0.3, 0.6 or 1.0. Chunking turns the evaluations into RL rules, and RL tunes them over runs.

Three DSL/compiler additions were needed to reproduce the originals' learning:
- **`Agent.goalReward`** (`elaborations/reward.soar`): reward 1 when the goal holds, as the originals' reward rule. Without it RL only discounted the chunked values, and over 60 runs the decisions per run diverged to about 30.
- **Level rules test the whole state** (`Agent.rlWholeState`, extended from the RL template to the score rules). The originals' `evaluate-state` rules test every `ontop`, so each chunk is for one configuration. Ours had tested only the goal links, so one RL rule covered several configurations and averaged their values; runs levelled off at about 12 decisions.
- **No `^success` inside the look-ahead** (`Agent.lookaheadSuccess := false`). Our goal rule fired in look-ahead states, so the selection library rated a look-ahead reaching the goal as success, and chunking turned that into a best preference: a plain chunk, not an RL rule. In the originals that state is valued 1.0 (rule P11), so every evaluation chunk is an RL rule. The fresh-agent harness carries only RL rules (defect 28 workaround), so the best-preference chunks were lost between episodes and those ties were searched again (8 decisions per run at best, against 4).

The Lean semantics do not model look-ahead; these are compiler-level changes. Assumption A8 is updated.

Results (Soar 9.6.5, `rlharness.py --fresh`, mean decisions per run; 10 seeds × 30 runs, and 5 seeds × 60 runs):

| | Run 1 | Runs 1–10 | 11–20 | 21–30 | 41–50 | 51–60 | RL rules (30 runs) |
|---|---|---|---|---|---|---|---|
| BW-LA-state-eval V1 | 52.3 | 10.5 | 5.1 | 5.1 | 4.5 | 4.6 | 16.7 |
| `blocks-world-look-ahead-state-eval` | 44.2 | 9.4 | 5.0 | 5.6 | 4.7 | 4.8 | 24.6 |

All runs solved. The best possible is 4 decisions (initialize and three moves). Soar vs soar-lean (`leancmp-lase2/`, `--chunk --rl`, the agent's settings prepended to the flattened file): MATCH, 40 decisions, 30 chunks, 15 RL rules with equal values.

### `blocks-world-hierarchical` replaces BW-Hierarchical V1, V2, blocks-world-hierarchical V2–V5

move-block is carried out in its substate by pick-up and put-down, and those by gripper operators in theirs. The gripper is an object of the task state; the originals' output-link commands and simulated world become direct changes (assumption A9).

- Decision traces (seed 1, 42 decisions, 3 moves) are identical to blocks-world-hierarchical V2 at every level. The only difference is in names: the gripper operators in put-down are `move-gripper-up-holding`, `move-gripper-above-destination` and `move-gripper-down-holding` (the originals reuse the pick-up names).
- Seeds 1–5: solved, 42 decisions. Theorem `hier_refines`: each move-block's sub-operator sequence refines its specification (3 blocks).
- Soar vs soar-lean (`leancmp-hier/`): MATCH, 42 decisions, with and without chunking.

BW-Hierarchical V1, V2 (with `chunk always`) do not work. Their gripper commands are written to the output link on the top state, reached from the substates through `^top-state`, so each command is a result and chunking learns a rule for it. Those chunks test the top state's selected move-block and the gripper's state, and they fire outside the operator hierarchy. With the rules that simulate the gripper, the down and up commands then alternate within one decision until max-elaborations (decision 13 onward, 1 move in 500 decisions). This is a fault of the agents, not of Soar. The originals without chunking (blocks-world-hierarchical V2–V5) work, and the variant has chunking off, as they do.

### `blocks-world-epmem` replaces blocks-world-epmem V2 (new construct: episodic memory as the look-ahead's action model)

blocks-world-epmem V2 resolves ties by one-step look-ahead, but it applies move-block in the look-ahead copy by recalling it from episodic memory instead of by its rules. It uses a modified selection library (`selection-epmem`).

New construct, `Agent.epmemModel` (compiler only; the Lean semantics do not model look-ahead):
- In a look-ahead copy, the task operator's apply rules do not fire (`-^look-ahead-operator <o>`), so it reaches an operator no-change.
- In that substate there are four operators:
  - `model-query`: the cue is the operator plus every object of the copy. The cue uses the copy's own identifiers, so the operator's parameters and the objects share identifiers, as they do in the episodes. With separate identifiers, as in a first attempt, no cue ever matched.
  - `model-next`: after a full match, retrieves the next episode.
  - `model-update`: copies the next episode's changed links into the copy and marks the operator tried, so the copy is evaluated.
  - `model-unknown`: when there is no full match or no next episode, the evaluation is partial success with value 2.5.
- The selection library's two tried-tied rules are excised, as in the original; otherwise the copy would be evaluated before the operator is applied.
- Episodic memory: learning on, trigger dc, phase selection.

Evaluation: blocks in place from the bottom of the goal stack (C 1, B 2, A 3, none 0; higher is better). The goal gives no success inside the look-ahead. Moving the block just moved is rejected in look-ahead. Chunking is off. Assumption A10.

Two differences from the original:
- **Update timing:** the original proposes update-superstate as soon as `next` is issued, so it first fires on the query's result (the state before the move) and marks the operator tried early. Ours waits for the next episode's result: a result without `^graph-match`.
- **No interrupt guard:** the original's guard against a match without the operator selected (an interrupt) is not needed. Episodes record proposed operators as `^operator*`, so the cue's `^operator` matches only a selected operator.

Results (Soar 9.6.5, 5 seeds × 10 runs in one agent, init-soar between runs, so the episodic store is kept):

| | Decisions per run | Moves | Model hits | Unknown | Solved |
|---|---|---|---|---|---|
| blocks-world-epmem V2 | 270 (runs 1–5: 249, 6–10: 291) | 20.7 | 12.4 | 16.9 | 50/50 |
| `blocks-world-epmem` | 242 (runs 1–5: 235, 6–10: 249) | 18.9 | 10.9 | 15.4 | 50/50 |

Neither improves over runs. An unexperienced move is valued 2.5, above the values for C in place (1) and C and B in place (2), so the agent keeps trying new moves rather than exploiting what it remembers. This is as the original was written.

Soar vs soar-lean (`leancmp-epmem/`, `--epmem`): MATCH, 129 decisions, 129 episodes.

### `blocks-world-hrl` replaces blocks-world-HRL V1 (JL option (b): a construct for RL in substates, and a variant that converges)

New construct, `SubRl` (on `Operator` or `SubOp` with sub-operators): RL over the sub-operators of a substate level.
- Sub-operators are proposed indifferent.
- There is one RL template per sub-operator, over its parameters and the level's parameters, by key.
- Rewards are local to the substate (its own reward link): a value whenever a list of guards holds.

The variant:
- **Top level:** move-block is chosen by RL over the whole configuration (as `blocks-world-rl`), with reward 1 at the goal.
- **Substate:** move-block is carried out by pick-up (any clear block, when the gripper is empty) and put-down (the held block onto any clear object), chosen by RL.
- **Substate rewards:** 1 when move-block's block is on its destination; −1 while the gripper holds another block. Assumption A11.

What it took to converge (each step checked on hand-edited rules first):
1. **Original rewards:** the original has no penalty for picking up a block other than the moving block. Its runs loop picking up B and putting it back on the table, where no reward fires either way. Hence the −1 for holding another block.
2. **Proposal that survives the substate's actions:** our first proposal for move-block required a gripper that is empty or holds the block, and a destination that is not held. Picking up another block, or the destination, then retracted move-block, so its substate and its rewards disappeared after one sub-operator, and no substate RL rule was ever updated. Now move-block is proposed as in the original: a clear block onto the table or onto a block with nothing on it (a derived flag `free`), with no gripper condition.
3. **Soar defect 28, substate form:** a substate template that tests `^superstate` is instantiated as `(state <s1> ^superstate <s1> …)` and never fires. The compiler now leaves `^superstate` and `^task-state` out of substate templates.

Results (Soar 9.6.5, `rlharness.py --fresh`, cap 3000 decisions; 10 seeds × 30 runs; 5 seeds × 60 runs):

| | Run 1 | Runs 1–10 | 11–20 | 21–30 | Runs reaching the cap |
|---|---|---|---|---|---|
| blocks-world-HRL V1 (RL on) | 3000 | 2586 | 2104 | 2104 | 226 of 300; 2 seeds converge, to 13 and 17 |
| `blocks-world-hrl` | 229 | 148 | 29 | 32 | 0 of 300 |

Over 60 runs, runs 41–50 average 22 and runs 51–60 average 25. The minimum is 13 decisions (initialize, then per move: move-block, its substate, pick-up and put-down). Half of the seeds end at 13.

Soar vs soar-lean (`leancmp-hrl/`, `--rl --explore`): DIFF in the RL rules only. Decisions (307) and working memory agree.
- Soar makes 297 template instances; 40 of them are malformed and never fire (24 top-level, 16 in the substate).
- An example: `(state <s1> ^name move-block ^name blocks-world ^operator <s1> + …)`. The top state, the substate and the operator share one variable.
- This is defect 28 in another form: template instances created while a substate exists. soar-lean models defect 28 only in its init-soar form, so its 253 rules correspond to Soar's 257 well-formed ones, and the rules' numbering and update counts diverge.
- To do in cmcsoar: model this form of defect 28 (or record it in the defects document).

### `blocks-world-hrl-3level` replaces block-world-HRL-3level V1 and blocks-world-hierarcical-RL V2 (option (b))

- **Top level:** move-block is chosen by the simple control (P6/P7).
- **Middle level:** move-block is carried out by pick-up and put-down, as in the hierarchical variant.
- **Gripper level:** the gripper operators are proposed whenever they can apply and are chosen by RL:
  - in pick-up's substate: up, down, above the block, close, open;
  - in put-down's substate: up, down, above the destination, release.
- **RL rules:** they test the gripper's position, open, empty and above, and the level's block and destination (`SubRl.attrs`).
- **Rewards:** in pick-up's substate, 1 when holding the block and −1 when closed on nothing; in put-down's substate, 1 when the block is on the destination. Assumption A12.

New option `SubRl.table`: the RL rules are emitted as a table of `gp` rules (one rule per combination of values; 4,608 rules here), as the originals write them. With RL templates the variant did not learn: at this level nearly every Soar template instance is malformed. An example: `(state <o1> ^name pick-up ^name open ^operator <o1> + ^g <x1> ^dest <x1> ^block <x1>)`, which is defect 28 again, in a fresh agent and without init-soar. The table needs no fresh-agent harness.

Results (Soar 9.6.5, 10 seeds × 30 runs, init-soar between runs, cap 3000):

| | Run 1 | Runs 1–10 | 11–20 | 21–30 | Runs reaching the cap | Minimum |
|---|---|---|---|---|---|---|
| block-world-HRL-3level V1 (RL on) | 2501 | 2611 | 2474 | 2567 | 205 of 300 | 105 |
| blocks-world-hierarcical-RL V2 | 2975 | 2627 | 2588 | 2645 | 260 of 300 | 42 |
| `blocks-world-hrl-3level` | 71 | 41 | 35 | 35 | 0 of 300 | 33 |

Soar vs soar-lean (`leancmp-hrl3/`, `--rl --explore`): MATCH, 66 decisions, 4,608 RL rules with equal counts and values.

### `blocks-world-hierarchical-lookahead` replaces BW-Hierarchical-LA V3 and blocks-world-hierachical-lookahead V2–V6 (option (b))

New construct, `SubLookahead`: look-ahead among the sub-operators of an operator's substate.
- The sub-operators are proposed without indifference, so alternatives tie.
- The substate holds links to the task's objects (shared identifiers, so the sub-operators' changes are results). Its problem space copies those objects two levels deep and leaves out the parameters, which a copy re-binds to the copied objects by key.
- Flags and derived attributes are elaborated in copies.
- In a copy, a sub-operator that has its own sub-operators is applied by its specified effect.
- A copy is evaluated as success or failure by guards.

The variant:
- **Top level:** move-block is chosen by the simple control.
- **Substate:** pick-up (any clear block) and put-down (the held block onto any clear object) tie, and the tie is resolved by look-ahead.
- **Evaluation:** success when the block is on the destination; failure when the gripper holds another block, or when the block was put down elsewhere.
- **For real:** pick-up and put-down are carried out by the gripper operators. Assumption A13.

The decision trace has the same structure as blocks-world-hierachical-lookahead V2: a tie in move-block's substate, evaluate pick-up, a nested tie, evaluate put-down, then the gripper operators.

Results (Soar 9.6.5, seeds 1–10; the originals' later runs after init-soar):

| | Solved | Run 1 decisions | Later runs |
|---|---|---|---|
| BW-Hierarchical-LA V3 | 10/10 | 57 (46–71) | 42 (chunks) |
| blocks-world-hierachical-lookahead V2, V6 | 10/10 | 60 (50–71) | 42 (chunks) |
| blocks-world-hierachical-lookahead V3 | 10/10 | 110 (79–170) | — |
| blocks-world-hierachical-lookahead V4, V5 | 0 | no move in 1000 | — |
| `blocks-world-hierarchical-lookahead` | 10/10 | 78 (73–85) | 76–89 (no chunking) |

**Chunking is off in the variant.** With chunking on, Soar learns an overgeneral reject chunk from the failure evaluation. The chunk loses the test that the held block is not the moving block, and then rejects every pick-up when the gripper's `holding` link names the destination. Later runs take 102 decisions or reach the cap, with or without `chunk bottom-only`. This is the kind of relational test lost in suspected defect 34; a minimal example is still to do. The originals copy the top state with their own rules (ontop structures, objects shared one level deep) and their chunks are correct.

Soar vs soar-lean (`leancmp-hla/`, `--replay`): MATCH, 76 decisions.

## Blocks World: done (8 Nov 2026)

All 75 originals are accounted for: replaced by the variants above, or skipped by the queue rules (`^world`/`^scene` versions; the non-working blocks-world-operator-subgoaling-lookahead V2).
