chunk*selection*evaluation*expected-values*t5-2 3 -0.011041
chunk*selection*evaluation*expected-values*t8-2 3 0.287582
chunk*selection*evaluation*expected-values*t11-2 4 0.153308
chunk*selection*evaluation*expected-values*t16-2 6 0.181769
chunk*selection*evaluation*expected-values*t27-2 1 0.744000
chunk*selection*evaluation*expected-values*t30-2 1 0.196865
chunk*selection*evaluation*expected-values*t37-3 1 0.496865
chunk*selection*evaluation*expected-values*t37-4 1 0.196865