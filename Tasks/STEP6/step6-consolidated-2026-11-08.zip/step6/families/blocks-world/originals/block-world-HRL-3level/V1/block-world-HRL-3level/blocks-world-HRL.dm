31
SOAR_ID 0
ENUMERATION 1 1 state
ENUMERATION 2 1 nil
ENUMERATION 3 1 blocks-world
SOAR_ID 4
ENUMERATION 5 1 move-block
SOAR_ID 6
SOAR_ID 7
SOAR_ID 8
SOAR_ID 9
ENUMERATION 10 3 A B C
ENUMERATION 11 4 A B C table
ENUMERATION 12 2 block table
SOAR_ID 13
SOAR_ID 14
SOAR_ID 15
ENUMERATION 16 1 initialize-blocks-world
ENUMERATION 17 4 A B C table
ENUMERATION 18 2 block table
SOAR_ID 19
ENUMERATION 20 1 state
ENUMERATION 21 1 move-block
ENUMERATION 22 1 pick-up
SOAR_ID 23
ENUMERATION 24 1 put-down
SOAR_ID 25
SOAR_ID 26
SOAR_ID 27
FLOAT_RANGE 28 -Infinity Infinity
SOAR_ID 29
ENUMERATION 30 1 nothing
42
0 clear 14
0 desired 7
0 gripper 29
0 inplace-object 14
0 last-moved-block 14
0 name 3
0 object 14
0 ontop 6
0 operator 4
0 operator 15
0 reward-link 26
0 superstate 2
0 type 1
4 destination 14
4 moving-block 14
4 name 5
6 bottom-block 9
6 top-block 8
7 ontop 13
8 name 10
9 name 11
9 type 12
13 bottom-block 14
13 top-block 14
14 name 17
14 type 18
15 name 16
19 name 21
19 operator 23
19 operator 25
19 reward-link 26
19 superstate 0
19 top-state 0
19 type 20
23 moving-block 14
23 name 22
25 destination 14
25 name 24
26 value 27
27 value 28
29 holding 30
29 holding 14
