40
SOAR_ID 0
ENUMERATION 1 1 state
ENUMERATION 2 1 nil
ENUMERATION 3 2 blocks-world evaluate-operator
SOAR_ID 4
ENUMERATION 5 1 move-block
SOAR_ID 6
SOAR_ID 7
SOAR_ID 8
SOAR_ID 9
ENUMERATION 10 3 A B C
ENUMERATION 11 4 A B C table
ENUMERATION 12 1 table
SOAR_ID 13
SOAR_ID 14
SOAR_ID 15
ENUMERATION 16 1 initialize-blocks-world
ENUMERATION 17 4 A B C table
ENUMERATION 18 2 block table
SOAR_ID 19
SOAR_ID 20
INTEGER_RANGE 21 -2147483648 2147483647
SOAR_ID 22
ENUMERATION 23 1 move-blocks
ENUMERATION 24 1 yes
ENUMERATION 25 4 clear inplace-object movable top-state
ENUMERATION 26 3 desired gripper ontop
ENUMERATION 27 1 object
SOAR_ID 28
ENUMERATION 29 1 detect-success
ENUMERATION 30 1 higher
SOAR_ID 31
ENUMERATION 32 1 state
ENUMERATION 33 1 Impasse__Operator_Tie
ENUMERATION 34 1 evaluate-operator
SOAR_ID 35
SOAR_ID 36
ENUMERATION 37 1 state
ENUMERATION 38 1 evaluate-operator
INTEGER_RANGE 39 -2147483648 2147483647
58
0 clear 14
0 desired 7
0 inplace-object 14
0 last-moved-block 14
0 name 3
0 not-inplace-object 14
0 object 14
0 ontop 6
0 operator 4
0 operator 15
0 operator 28
0 problem-space 22
0 reward-link 19
0 success 7
0 superstate 2
0 superstate 0
0 top-state 0
0 type 1
4 destination 14
4 moving-block 14
4 name 5
6 bottom-block 9
6 top-block 8
7 better 30
7 ontop 13
8 name 10
9 name 11
9 type 12
13 bottom-block 14
13 top-block 14
14 name 17
14 type 18
15 name 16
19 reward 20
20 value 21
22 default-state-copy 24
22 dont-copy 25
22 name 23
22 one-level-attributes 27
22 two-level-attributes 26
28 name 29
31 name 33
31 operator 35
31 superstate 0
31 top-state 0
31 type 32
35 name 34
36 inplace-object 14
36 name 38
36 not-inplace-object 14
36 numeric-value 39
36 object 14
36 ontop 6
36 operator 4
36 superstate 31
36 top-state 0
36 tried-tied-operator 4
36 type 37
