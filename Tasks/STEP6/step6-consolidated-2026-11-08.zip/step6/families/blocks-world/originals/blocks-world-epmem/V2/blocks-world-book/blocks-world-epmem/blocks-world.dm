22
SOAR_ID 0
ENUMERATION 1 1 state
ENUMERATION 2 1 nil
ENUMERATION 3 1 blocks-world
SOAR_ID 4
ENUMERATION 5 1 move-block
SOAR_ID 6
SOAR_ID 7
SOAR_ID 8
SOAR_ID 9
ENUMERATION 10 2 A C
ENUMERATION 11 1 table
ENUMERATION 12 1 table
SOAR_ID 13
SOAR_ID 14
SOAR_ID 15
ENUMERATION 16 1 initialize-blocks-world
ENUMERATION 17 4 A B C table
ENUMERATION 18 2 block table
SOAR_ID 19
SOAR_ID 20
INTEGER_RANGE 21 -2147483648 2147483647
28
0 clear 14
0 desired 7
0 inplace-object 14
0 last-moved-block 14
0 name 3
0 object 14
0 ontop 6
0 operator 4
0 operator 15
0 reward-link 19
0 superstate 2
0 type 1
4 destination 14
4 moving-block 14
4 name 5
6 bottom-block 9
6 top-block 8
7 ontop 13
8 name 10
9 name 11
9 type 12
13 bottom-block 14
13 top-block 14
14 name 17
14 type 18
15 name 16
19 reward 20
20 value 21
