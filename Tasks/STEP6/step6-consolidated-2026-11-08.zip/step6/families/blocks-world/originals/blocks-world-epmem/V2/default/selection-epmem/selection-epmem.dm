70
SOAR_ID 0
SOAR_ID 1
SOAR_ID 2
SOAR_ID 3
ENUMERATION 4 1 state
ENUMERATION 5 1 nil
SOAR_ID 6
ENUMERATION 7 1 state
ENUMERATION 8 1 evaluate-operator
SOAR_ID 9
SOAR_ID 10
ENUMERATION 11 1 state
ENUMERATION 12 1 evaluate-operator
ENUMERATION 13 1 selection
ENUMERATION 14 1 no-change
SOAR_ID 15
SOAR_ID 16
STRING 17
SOAR_ID 18
SOAR_ID 19
SOAR_ID 20
FLOAT_RANGE 21 -Infinity Infinity
STRING 22
ENUMERATION 23 1 true
SOAR_ID 24
SOAR_ID 25
SOAR_ID 26
INTEGER_RANGE 27 -2147483648 2147483647
INTEGER_RANGE 28 -2147483648 2147483647
INTEGER_RANGE 29 -2147483648 2147483647
FLOAT_RANGE 30 -Infinity Infinity
ENUMERATION 31 1 t
ENUMERATION 32 1 state
SOAR_ID 33
ENUMERATION 34 1 state
ENUMERATION 35 1 Impasse__State_No-Change
ENUMERATION 36 1 no-change
ENUMERATION 37 4 failure indifferent lose partial-success
ENUMERATION 38 1 move-block
SOAR_ID 39
SOAR_ID 40
ENUMERATION 41 1 state
ENUMERATION 42 1 move-block
ENUMERATION 43 1 retrieve-earlier-state
SOAR_ID 44
ENUMERATION 45 1 next-state
SOAR_ID 46
ENUMERATION 47 1 update-superstate
SOAR_ID 48
ENUMERATION 49 1 failed-retrieval
SOAR_ID 50
ENUMERATION 51 1 yes
ENUMERATION 52 1 yes
SOAR_ID 53
SOAR_ID 54
SOAR_ID 55
ENUMERATION 56 2 failure success
SOAR_ID 57
SOAR_ID 58
ENUMERATION 59 4 A B C table
ENUMERATION 60 2 block table
SOAR_ID 61
SOAR_ID 62
SOAR_ID 63
INTEGER_RANGE 64 -2147483648 2147483647
STRING 65
ENUMERATION 66 1 t
FLOAT_RANGE 67 -Infinity Infinity
STRING 68
SOAR_ID 69
91
0 desired 25
0 epmem 53
0 io 1
0 object 58
0 ontop 61
0 operator 24
0 superstate 5
0 superstate 6
0 top-state 0
0 type 4
1 input-link 2
1 output-link 3
6 evaluation 18
6 name 13
6 operator 9
6 quiescence 31
6 superstate 0
6 top-state 0
6 type 7
9 evaluation 18
9 name 8
9 superoperator 19
9 visited 20
10 desired 62
10 exhaustion-failure 63
10 failure 20
10 impasse 14
10 look-ahead-operator 15
10 name 12
10 object 58
10 ontop 61
10 operator 39
10 quiescence 31
10 superstate 6
10 top-state 0
10 tried-tied-operator 15
10 type 11
10 untried-tied-operator 69
15 duplicate-of 16
15 name 17
18 desired 20
18 numeric-value 67
18 superoperator 19
18 symbolic-value 37
18 value 23
20 id 22
20 x 30
20 y 21
25 location 26
26 id 29
26 x 27
26 y 28
33 attribute 32
33 impasse 36
33 name 35
33 quiescence 31
33 superstate 10
33 top-state 0
33 type 34
39 destination 58
39 moving-block 58
39 name 38
40 epmem 53
40 initiated-earlier-state-retrieval 51
40 initiated-next-state-retrieval 52
40 name 42
40 operator 44
40 operator 46
40 operator 48
40 operator 50
40 quiescence 66
40 superstate 10
40 top-state 0
40 type 41
44 name 43
46 name 45
48 name 47
50 name 49
53 command 55
53 result 54
54 failure 68
54 graph-match 64
54 retrieved 10
54 status 56
54 success 65
55 next 57
55 query 10
58 name 59
58 type 60
61 bottom-block 58
61 top-block 58
