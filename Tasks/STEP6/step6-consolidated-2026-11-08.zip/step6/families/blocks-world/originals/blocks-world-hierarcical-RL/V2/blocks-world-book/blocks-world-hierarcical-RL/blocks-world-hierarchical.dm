56
SOAR_ID 0
ENUMERATION 1 1 state
ENUMERATION 2 1 nil
ENUMERATION 3 2 blocks-world evaluate-operator
SOAR_ID 4
ENUMERATION 5 1 move-block
SOAR_ID 6
SOAR_ID 7
SOAR_ID 8
SOAR_ID 9
ENUMERATION 10 3 A B C
ENUMERATION 11 5 A B C gripper table
ENUMERATION 12 2 block table
SOAR_ID 13
SOAR_ID 14
SOAR_ID 15
ENUMERATION 16 1 initialize-blocks-world
ENUMERATION 17 5 A B C gripper table
ENUMERATION 18 2 block table
SOAR_ID 19
ENUMERATION 20 1 state
ENUMERATION 21 1 move-block
ENUMERATION 22 1 pick-up
SOAR_ID 23
ENUMERATION 24 1 put-down
SOAR_ID 25
SOAR_ID 26
SOAR_ID 27
FLOAT_RANGE 28 -Infinity Infinity
SOAR_ID 29
ENUMERATION 30 1 nothing
ENUMERATION 31 2 down up
ENUMERATION 32 2 no yes
SOAR_ID 33
ENUMERATION 34 1 state
ENUMERATION 35 2 pick-up put-down
ENUMERATION 36 1 open-gripper
SOAR_ID 37
ENUMERATION 38 1 close-gripper
SOAR_ID 39
ENUMERATION 40 1 move-gripper-up
SOAR_ID 41
ENUMERATION 42 1 move-gripper-down
SOAR_ID 43
ENUMERATION 44 1 move-gripper-above
SOAR_ID 45
ENUMERATION 46 1 gripper-operators
SOAR_ID 47
SOAR_ID 48
SOAR_ID 49
ENUMERATION 50 5 close down move-gripper-above open up
SOAR_ID 51
ENUMERATION 52 3 gripper move-block pick-up-put-down
ENUMERATION 53 1 yes
ENUMERATION 54 5 desired gripper ontop superstate top-state
ENUMERATION 55 1 object
79
0 clear 14
0 desired 7
0 gripper 29
0 inplace-object 14
0 io 47
0 last-moved-block 14
0 moveable 14
0 name 3
0 object 14
0 ontop 6
0 operator 4
0 operator 15
0 problem-space 51
0 superstate 2
0 superstate 0
0 top-state 0
0 type 1
4 destination 14
4 moving-block 14
4 name 5
6 bottom-block 9
6 last-bottom 9
6 top-block 8
7 ontop 13
8 name 10
9 name 11
9 type 12
13 bottom-block 14
13 top-block 14
14 name 17
14 type 18
15 name 16
19 desired 4
19 name 21
19 operator 23
19 operator 25
19 problem-space 51
19 reward-link 26
19 superstate 0
19 top-state 0
19 type 20
23 moving-block 14
23 name 22
25 destination 14
25 name 24
26 reward 27
27 value 28
29 above 14
29 holding 30
29 holding 14
29 open 32
29 position 31
33 desired 4
33 name 35
33 operator 37
33 operator 39
33 operator 41
33 operator 43
33 operator 45
33 problem-space 51
33 reward-link 26
33 state-type 46
33 superstate 19
33 top-state 0
33 type 34
37 name 36
39 name 38
41 name 40
43 name 42
45 destination 14
45 name 44
47 output-link 48
48 gripper 49
49 command 50
49 destination 14
51 default-state-copy 53
51 name 52
51 one-level-attributes 55
51 two-level-attributes 54
