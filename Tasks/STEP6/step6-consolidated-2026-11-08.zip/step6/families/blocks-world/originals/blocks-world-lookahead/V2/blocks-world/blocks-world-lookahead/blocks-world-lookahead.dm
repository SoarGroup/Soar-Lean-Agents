31
SOAR_ID 0
ENUMERATION 1 1 state
ENUMERATION 2 1 nil
ENUMERATION 3 2 blocks-world evaluate-operator
SOAR_ID 4
ENUMERATION 5 1 move-block
SOAR_ID 6
SOAR_ID 7
SOAR_ID 8
SOAR_ID 9
ENUMERATION 10 3 A B C
ENUMERATION 11 4 A B C table
ENUMERATION 12 2 block table
SOAR_ID 13
SOAR_ID 14
SOAR_ID 15
ENUMERATION 16 1 initialize-blocks-world
ENUMERATION 17 4 A B C table
ENUMERATION 18 2 block table
SOAR_ID 19
ENUMERATION 20 1 move-blocks
ENUMERATION 21 1 yes
ENUMERATION 22 5 desired gripper ontop superstate top-state
ENUMERATION 23 3 last-moved-block move-count object
ENUMERATION 24 4 clear inplace-object moveable top-state
SOAR_ID 25
INTEGER_RANGE 26 -2147483648 2147483647
SOAR_ID 27
ENUMERATION 28 1 evaluate-operator
ENUMERATION 29 1 true
INTEGER_RANGE 30 -2147483648 2147483647
43
0 desired 7
0 inplace-object 14
0 moveable 14
0 name 3
0 numeric-value 30
0 operator 4
0 operator 15
0 operator 27
0 problem-space 19
0 success 7
0 superstate 2
0 superstate 0
0 top-state 0
0 type 1
0 world 25
4 destination 14
4 moving-block 14
4 name 5
4 preconditions 29
6 bottom-block 9
6 last-bottom 9
6 top-block 8
7 ontop 13
8 name 10
9 name 11
9 type 12
13 bottom-block 14
13 top-block 14
14 name 17
14 type 18
15 name 16
19 default-state-copy 21
19 dont-copy 24
19 name 20
19 one-level-attributes 23
19 two-level-attributes 22
25 clear 14
25 last-moved-block 14
25 move-count 26
25 moveable 14
25 object 14
25 ontop 6
27 name 28
