# Games (open)

No variant yet. The task agents chal V1, safe V1 and kenken V2 (filed under Tic-Tac-Toe / games) are open; `comparison/results` holds the runs of the originals. Tic-Tac-Toe and KenKen V1 have their own family folders.
