148
SOAR_ID 0
SOAR_ID 1
SOAR_ID 2
SOAR_ID 3
SOAR_ID 4
ENUMERATION 5 1 state
ENUMERATION 6 1 nil
ENUMERATION 7 1 kenken
ENUMERATION 8 1 initialize-kenken
SOAR_ID 9
ENUMERATION 10 1 detect-goal
SOAR_ID 11
ENUMERATION 12 1 apply-equal-constraint
SOAR_ID 13
ENUMERATION 14 1 mark-single-value
SOAR_ID 15
ENUMERATION 16 1 remove-column-row-values
SOAR_ID 17
ENUMERATION 18 1 notice-single-column-row-value
SOAR_ID 19
ENUMERATION 20 1 print-board
SOAR_ID 21
ENUMERATION 22 1 state
ENUMERATION 23 1 print-board
ENUMERATION 24 1 print-row
SOAR_ID 25
ENUMERATION 26 1 initialize-print
SOAR_ID 27
SOAR_ID 28
ENUMERATION 29 1 state
ENUMERATION 30 1 print-row
ENUMERATION 31 1 initial-row
SOAR_ID 32
ENUMERATION 33 1 print-number
SOAR_ID 34
ENUMERATION 35 1 end-row
SOAR_ID 36
ENUMERATION 37 1 end-print
SOAR_ID 38
ENUMERATION 39 1 print-legal-values
SOAR_ID 40
SOAR_ID 41
ENUMERATION 42 1 state
ENUMERATION 43 1 print-legal-values
ENUMERATION 44 1 init-legal-values
SOAR_ID 45
ENUMERATION 46 1 print-single-legal-value
SOAR_ID 47
ENUMERATION 48 1 end-legal-values
SOAR_ID 49
SOAR_ID 50
ENUMERATION 51 1 check-group
SOAR_ID 52
ENUMERATION 53 1 state
ENUMERATION 54 1 check-group
ENUMERATION 55 1 initialize-check
SOAR_ID 56
ENUMERATION 57 1 check-cell-values
SOAR_ID 58
ENUMERATION 59 1 check-cell-values
SOAR_ID 60
SOAR_ID 61
ENUMERATION 62 1 state
ENUMERATION 63 1 check-cell-values
ENUMERATION 64 1 check-legal-value
SOAR_ID 65
ENUMERATION 66 1 end-check-legal-values
SOAR_ID 67
ENUMERATION 68 1 end-check-group
SOAR_ID 69
SOAR_ID 70
ENUMERATION 71 1 add-linear-sum-group
SOAR_ID 72
ENUMERATION 73 1 add-subgroup
SOAR_ID 74
ENUMERATION 75 1 detect-failure
ENUMERATION 76 1 print-value
SOAR_ID 77
SOAR_ID 78
ENUMERATION 79 1 recheck-group
SOAR_ID 80
ENUMERATION 81 1 check-double-column
SOAR_ID 82
ENUMERATION 83 1 check-double-row
SOAR_ID 84
ENUMERATION 85 1 check-triple-column
SOAR_ID 86
ENUMERATION 87 1 check-triple-row
SOAR_ID 88
ENUMERATION 89 1 add-subgroup-2-4
SOAR_ID 90
ENUMERATION 91 1 checkk-parallel-double-value-row
SOAR_ID 92
ENUMERATION 93 1 next-board
SOAR_ID 94
ENUMERATION 95 1 initialize-board-size
SOAR_ID 96
ENUMERATION 97 1 initialize-board-number
SOAR_ID 98
ENUMERATION 99 1 next-board-size
SOAR_ID 100
ENUMERATION 101 1 next-board-number
SOAR_ID 102
ENUMERATION 103 1 halt
SOAR_ID 104
INTEGER_RANGE 105 2 7
INTEGER_RANGE 106 1 20
SOAR_ID 107
INTEGER_RANGE 108 0 49
SOAR_ID 109
INTEGER_RANGE 110 11 77
ENUMERATION 111 2 false true
INTEGER_RANGE 112 1 7
INTEGER_RANGE 113 1 7
ENUMERATION 114 1 nil
INTEGER_RANGE 115 1 7
SOAR_ID 116
ENUMERATION 117 4 add divide multiply subtract
INTEGER_RANGE 118 1 6
INTEGER_RANGE 119 1 10000
INTEGER_RANGE 120 1 20
INTEGER_RANGE 121 1 7
INTEGER_RANGE 122 4 49
STRING 123
INTEGER_RANGE 124 3 1000
INTEGER_RANGE 125 2 2000000
SOAR_ID 126
SOAR_ID 127
SOAR_ID 128
SOAR_ID 129
SOAR_ID 130
INTEGER_RANGE 131 -2147483648 2147483647
INTEGER_RANGE 132 -2147483648 2147483647
INTEGER_RANGE 133 -2147483648 2147483647
INTEGER_RANGE 134 -2147483648 2147483647
INTEGER_RANGE 135 -2147483648 2147483647
INTEGER_RANGE 136 -2147483648 2147483647
INTEGER_RANGE 137 -2147483648 2147483647
INTEGER_RANGE 138 -2147483648 2147483647
SOAR_ID 139
ENUMERATION 140 1 state
ENUMERATION 141 1 Impasse__Operator_Tie
ENUMERATION 142 1 evaluate-operator
SOAR_ID 143
SOAR_ID 144
ENUMERATION 145 1 decide-to-guess
SOAR_ID 146
ENUMERATION 147 1 guess
157
0 io 1
0 kenken-data 104
0 name 7
0 operator 4
0 operator 9
0 operator 11
0 operator 13
0 operator 15
0 operator 17
0 operator 19
0 operator 50
0 operator 70
0 operator 72
0 operator 74
0 operator 78
0 operator 80
0 operator 82
0 operator 84
0 operator 86
0 operator 88
0 operator 90
0 operator 92
0 operator 94
0 operator 96
0 operator 98
0 operator 100
0 operator 102
0 operator 144
0 operator 146
0 superstate 6
0 top-state 0
0 type 5
1 input-link 2
1 output-link 3
4 name 8
9 name 10
11 name 12
13 name 14
15 name 16
17 name 18
19 name 20
21 name 23
21 operator 25
21 operator 27
21 operator 38
21 superstate 0
21 top-state 0
21 type 22
25 name 24
27 name 26
28 name 30
28 operator 32
28 operator 34
28 operator 36
28 operator 40
28 superstate 21
28 top-state 0
28 type 29
32 name 31
34 name 33
36 name 35
38 name 37
40 name 39
41 name 43
41 operator 45
41 operator 47
41 operator 49
41 operator 77
41 superstate 28
41 top-state 0
41 type 42
45 name 44
47 name 46
49 name 48
50 name 51
52 name 54
52 operator 56
52 operator 58
52 operator 60
52 operator 69
52 superstate 0
52 top-state 0
52 type 53
56 name 55
58 name 57
60 name 59
61 name 63
61 operator 65
61 operator 67
61 superstate 52
61 top-state 0
61 type 62
65 name 64
67 name 66
69 name 68
70 name 71
72 name 73
74 name 75
77 name 76
78 name 79
80 name 81
82 name 83
84 name 85
86 name 87
88 name 89
90 name 91
92 name 93
94 name 95
96 name 97
98 name 99
100 name 101
102 name 103
104 add-total 124
104 board 107
104 board-row-print 123
104 board-size 105
104 cell-number 122
104 column-rows 121
104 current-number 106
104 final-number 120
104 multiply-total 125
104 number-db 126
104 number-db-triple-linear 126
104 number-db-triple-non-linear 126
107 cell 109
107 group 116
107 mark-count 108
109 column 112
109 coordinate 110
109 legal-value 114
109 legal-value 115
109 marked 111
109 row 113
116 cell 109
116 cell-number 118
116 operation 117
116 value 119
126 add 127
126 divide 129
126 multiply 128
126 subtract 130
127 6 131
127 7 132
127 8 133
127 9 134
128 12 137
128 24 138
128 6 135
128 8 136
139 name 141
139 operator 143
139 superstate 0
139 top-state 0
139 type 140
143 name 142
144 name 145
146 name 147
