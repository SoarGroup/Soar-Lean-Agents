42
SOAR_ID 0
SOAR_ID 1
SOAR_ID 2
SOAR_ID 3
SOAR_ID 4
ENUMERATION 5 1 state
ENUMERATION 6 1 nil
ENUMERATION 7 1 knights
ENUMERATION 8 1 initialize-knights
SOAR_ID 9
ENUMERATION 10 1 knight-move
SOAR_ID 11
ENUMERATION 12 1 backup
SOAR_ID 13
ENUMERATION 14 1 detect-goal
SOAR_ID 15
ENUMERATION 16 1 finish-run
ENUMERATION 17 11 closed-solution connected-move-degree-0 degree-update-by-move monitor-moves monitor-success multiple-connected-moves-degree-1 multiple-moves-degree-1 open-solution select-operator-heuristic-based-on-degree-negative select-operator-heuristic-based-on-degree-positive select-operator-prefer-degree-one
INTEGER_RANGE 18 -2147483648 2147483647
INTEGER_RANGE 19 -2147483648 2147483647
INTEGER_RANGE 20 0 2147483647
INTEGER_RANGE 21 1 2147483647
SOAR_ID 22
ENUMERATION 23 1 nil
INTEGER_RANGE 24 1 2147483647
SOAR_ID 25
SOAR_ID 26
INTEGER_RANGE 27 0 8
INTEGER_RANGE 28 11 88
ENUMERATION 29 2 false true
ENUMERATION 30 1 true
ENUMERATION 31 1 true
ENUMERATION 32 1 nil
ENUMERATION 33 1 true
SOAR_ID 34
ENUMERATION 35 1 global-init-knights-tour
SOAR_ID 36
ENUMERATION 37 1 next-run
SOAR_ID 38
ENUMERATION 39 1 finish-strategy
SOAR_ID 40
ENUMERATION 41 1 halt
61
0 backup 30
0 board 25
0 current-square 26
0 finished 31
0 first-square 26
0 flags 17
0 goal-detected 33
0 io 1
0 move-count 20
0 move-count-max 21
0 move-sequence 32
0 move-sequence 22
0 name 7
0 operator 4
0 operator 9
0 operator 11
0 operator 13
0 operator 15
0 operator 34
0 operator 36
0 operator 38
0 operator 40
0 solution-count 19
0 solution-depth 18
0 superstate 6
0 top-state 0
0 type 5
1 input-link 2
1 output-link 3
4 name 8
9 move 26
9 name 10
11 move 26
11 name 12
13 name 14
15 name 16
22 depth 24
22 prior-move 23
22 prior-move 22
22 square 26
25 11 26
25 12 26
25 13 26
25 14 26
25 15 26
25 16 26
25 21 26
25 22 26
25 23 26
25 33 26
25 34 26
25 35 26
26 coordinate 28
26 degree 27
26 move 26
26 moved 26
26 used 29
34 name 35
36 name 37
38 name 39
40 name 41
