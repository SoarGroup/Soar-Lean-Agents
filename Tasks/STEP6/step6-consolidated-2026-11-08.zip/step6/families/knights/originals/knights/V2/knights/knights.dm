124
SOAR_ID 0
SOAR_ID 1
SOAR_ID 2
SOAR_ID 3
SOAR_ID 4
ENUMERATION 5 1 state
ENUMERATION 6 1 nil
ENUMERATION 7 1 knights
ENUMERATION 8 1 initialize-knights
SOAR_ID 9
ENUMERATION 10 1 knight-move
SOAR_ID 11
ENUMERATION 12 1 backup
SOAR_ID 13
ENUMERATION 14 1 detect-goal
SOAR_ID 15
ENUMERATION 16 1 finish-run
ENUMERATION 17 13 closed-solution connected-move-degree-0 degree-update-by-move final-move-degree-0 monitor-moves monitor-success multiple-connected-moves-degree-1 multiple-distance-moves-degree-2 multiple-moves-degree-1 open-solution select-operator-heuristic-based-on-degree-negative select-operator-heuristic-based-on-degree-positive select-operator-prefer-degree-one
INTEGER_RANGE 18 -2147483648 2147483647
INTEGER_RANGE 19 -2147483648 2147483647
INTEGER_RANGE 20 0 2147483647
INTEGER_RANGE 21 1 2147483647
SOAR_ID 22
ENUMERATION 23 1 nil
INTEGER_RANGE 24 1 2147483647
SOAR_ID 25
SOAR_ID 26
INTEGER_RANGE 27 0 8
INTEGER_RANGE 28 11 88
ENUMERATION 29 2 false true
ENUMERATION 30 1 true
ENUMERATION 31 1 true
ENUMERATION 32 1 nil
ENUMERATION 33 1 true
SOAR_ID 34
ENUMERATION 35 1 global-init-knights-tour
SOAR_ID 36
ENUMERATION 37 1 next-run
SOAR_ID 38
ENUMERATION 39 1 finish-strategy
SOAR_ID 40
ENUMERATION 41 1 halt
SOAR_ID 42
INTEGER_RANGE 43 -2147483648 2147483647
INTEGER_RANGE 44 -2147483648 2147483647
ENUMERATION 45 1 true
INTEGER_RANGE 46 -2147483648 2147483647
INTEGER_RANGE 47 -2147483648 2147483647
INTEGER_RANGE 48 -2147483648 2147483647
SOAR_ID 49
INTEGER_RANGE 50 -2147483648 2147483647
INTEGER_RANGE 51 -2147483648 2147483647
INTEGER_RANGE 52 -2147483648 2147483647
INTEGER_RANGE 53 -2147483648 2147483647
ENUMERATION 54 9 closed-solution connected-move-degree-0 degree-update-by-move final-move-degree-0 multiple-connected-moves-degree-1 multiple-distance-moves-degree-2 multiple-moves-degree-1 select-operator-heuristic-based-on-degree-positive select-operator-prefer-degree-one
ENUMERATION 55 7 level-0 level-1 level-2 level-3 level-4 level-5 level-6
ENUMERATION 56 1 nil
SOAR_ID 57
ENUMERATION 58 2 level-5 level-6
ENUMERATION 59 1 level-5
ENUMERATION 60 4 connected-move-degree-0 final-move-degree-0 multiple-distance-moves-degree-2 multiple-moves-degree-1
ENUMERATION 61 1 nil
SOAR_ID 62
SOAR_ID 63
SOAR_ID 64
SOAR_ID 65
SOAR_ID 66
SOAR_ID 67
SOAR_ID 68
SOAR_ID 69
SOAR_ID 70
SOAR_ID 71
SOAR_ID 72
SOAR_ID 73
SOAR_ID 74
SOAR_ID 75
SOAR_ID 76
SOAR_ID 77
SOAR_ID 78
SOAR_ID 79
SOAR_ID 80
SOAR_ID 81
SOAR_ID 82
SOAR_ID 83
SOAR_ID 84
SOAR_ID 85
SOAR_ID 86
SOAR_ID 87
SOAR_ID 88
SOAR_ID 89
SOAR_ID 90
SOAR_ID 91
SOAR_ID 92
SOAR_ID 93
SOAR_ID 94
SOAR_ID 95
SOAR_ID 96
SOAR_ID 97
SOAR_ID 98
SOAR_ID 99
SOAR_ID 100
SOAR_ID 101
SOAR_ID 102
SOAR_ID 103
SOAR_ID 104
SOAR_ID 105
SOAR_ID 106
SOAR_ID 107
SOAR_ID 108
SOAR_ID 109
SOAR_ID 110
SOAR_ID 111
SOAR_ID 112
SOAR_ID 113
SOAR_ID 114
SOAR_ID 115
INTEGER_RANGE 116 -2147483648 2147483647
INTEGER_RANGE 117 -2147483648 2147483647
ENUMERATION 118 1 false
SOAR_ID 119
INTEGER_RANGE 120 -2147483648 2147483647
INTEGER_RANGE 121 -2147483648 2147483647
ENUMERATION 122 1 false
SOAR_ID 123
143
0 backup 30
0 board 25
0 board-size 51
0 current-square 26
0 current-strategy 42
0 finished 31
0 first-square 26
0 goal-detected 33
0 io 1
0 move-count 20
0 move-count-max 21
0 move-sequence 32
0 move-sequence 22
0 name 7
0 operator 4
0 operator 9
0 operator 11
0 operator 13
0 operator 15
0 operator 34
0 operator 36
0 operator 38
0 operator 40
0 runs-per-level 48
0 solution-count 19
0 solution-depth 18
0 strategies 49
0 superstate 6
0 top-state 0
0 type 5
1 input-link 2
1 output-link 3
4 name 8
9 move 26
9 name 10
11 move 26
11 name 12
13 name 14
15 name 16
22 depth 24
22 prior-move 23
22 prior-move 22
22 square 26
25 11 26
25 12 26
25 13 26
25 14 26
25 15 26
25 16 26
25 17 86
25 18 87
25 21 26
25 22 26
25 23 26
25 24 62
25 25 69
25 26 70
25 27 88
25 28 89
25 31 63
25 32 64
25 33 26
25 34 26
25 35 26
25 36 71
25 37 90
25 38 91
25 41 65
25 42 66
25 43 67
25 44 68
25 45 72
25 46 73
25 47 92
25 48 93
25 51 74
25 52 75
25 53 76
25 54 77
25 55 78
25 56 79
25 57 94
25 58 95
25 61 80
25 62 81
25 63 82
25 64 83
25 65 84
25 66 85
25 67 96
25 68 97
25 71 98
25 72 99
25 73 100
25 74 101
25 75 102
25 76 103
25 77 104
25 78 105
25 81 106
25 82 107
25 83 108
25 84 109
25 85 110
25 86 111
25 87 112
25 88 113
26 coordinate 28
26 degree 27
26 move 26
26 moved 26
26 original-degree 43
26 used 29
34 name 35
36 name 37
38 name 39
40 name 41
42 active 45
42 flags 17
42 name 59
42 next 61
42 next 114
42 run-count 47
42 solution-count 44
42 total-solutions 46
49 flags 54
49 name 55
49 next 56
49 next 57
49 run-count 53
49 solution-count 50
49 total-solutions 52
57 flags 60
57 name 58
86 coordinate 117
86 degree 116
86 move 119
86 used 118
87 coordinate 121
87 degree 120
87 move 123
87 used 122
114 name 115
