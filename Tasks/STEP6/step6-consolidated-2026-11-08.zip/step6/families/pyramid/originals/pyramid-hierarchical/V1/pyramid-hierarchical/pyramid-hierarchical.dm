36
SOAR_ID 0
SOAR_ID 1
SOAR_ID 2
SOAR_ID 3
SOAR_ID 4
ENUMERATION 5 1 state
ENUMERATION 6 1 nil
ENUMERATION 7 1 pyramid-hierarchical
ENUMERATION 8 1 initialize-pyramid
INTEGER_RANGE 9 -2147483648 2147483647
INTEGER_RANGE 10 -2147483648 2147483647
SOAR_ID 11
ENUMERATION 12 1 terminate
SOAR_ID 13
ENUMERATION 14 1 expand-pyramid
SOAR_ID 15
ENUMERATION 16 1 sum-expansion
SOAR_ID 17
ENUMERATION 18 1 state
ENUMERATION 19 1 expand-pyramid
ENUMERATION 20 1 expand-next-base
SOAR_ID 21
SOAR_ID 22
SOAR_ID 23
INTEGER_RANGE 24 -2147483648 2147483647
SOAR_ID 25
ENUMERATION 26 1 state
ENUMERATION 27 1 sum-expansion
ENUMERATION 28 1 sum-values
SOAR_ID 29
ENUMERATION 30 1 initialize-sum
SOAR_ID 31
INTEGER_RANGE 32 -2147483648 2147483647
INTEGER_RANGE 33 -2147483648 2147483647
ENUMERATION 34 1 final-sum
SOAR_ID 35
41
0 base 9
0 expansion 22
0 final-sum 33
0 height 10
0 io 1
0 name 7
0 operator 4
0 operator 11
0 operator 13
0 operator 15
0 superstate 6
0 top-state 0
0 type 5
1 input-link 2
1 output-link 3
4 name 8
11 name 12
13 name 14
15 name 16
17 name 19
17 operator 21
17 superstate 0
17 top-state 0
17 type 18
21 name 20
22 current 23
22 first 23
23 next 23
23 value 24
25 current-value 23
25 name 27
25 operator 29
25 operator 31
25 operator 35
25 sum 32
25 superstate 0
25 top-state 0
25 type 26
29 name 28
31 name 30
35 name 34
