26
SOAR_ID 0
ENUMERATION 1 1 state
ENUMERATION 2 1 nil
ENUMERATION 3 1 eight-puzzle
SOAR_ID 4
ENUMERATION 5 1 initialize-eight-puzzle
SOAR_ID 6
ENUMERATION 7 1 move-tile
SOAR_ID 8
STRING 9
ENUMERATION 10 1 nil
SOAR_ID 11
SOAR_ID 12
ENUMERATION 13 9 0 1 2 3 4 5 6 7 8
SOAR_ID 14
ENUMERATION 15 1 higher
SOAR_ID 16
ENUMERATION 17 1 eight-puzzle
ENUMERATION 18 1 yes
ENUMERATION 19 2 no yes
ENUMERATION 20 1 blank-cell
ENUMERATION 21 1 binding
SOAR_ID 22
ENUMERATION 23 1 mark
SOAR_ID 24
ENUMERATION 25 1 detect-draw
32
0 binding 11
0 blank-cell 8
0 desired 14
0 name 3
0 operator 4
0 operator 6
0 operator 22
0 operator 24
0 problem-space 16
0 success 14
0 superstate 2
0 tile-cell 8
0 tile-cell 10
0 type 1
4 name 5
6 blank-cell 8
6 name 7
6 tile-cell 8
8 cell 8
8 name 9
11 cell 8
11 tile 12
12 name 13
14 better 15
14 binding 11
16 default-operator-copy 19
16 default-state-copy 18
16 name 17
16 one-level-attributes 20
16 two-level-attributes 21
22 name 23
24 name 25
