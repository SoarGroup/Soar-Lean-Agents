26
SOAR_ID 0
ENUMERATION 1 1 state
ENUMERATION 2 1 nil
ENUMERATION 3 1 water-jug
SOAR_ID 4
ENUMERATION 5 2 initialize initialize-water-jug-look-ahead
SOAR_ID 6
ENUMERATION 7 1 empty
SOAR_ID 8
ENUMERATION 9 1 pour
SOAR_ID 10
INTEGER_RANGE 11 -2147483648 2147483647
SOAR_ID 12
ENUMERATION 13 1 fill
INTEGER_RANGE 14 -2147483648 2147483647
SOAR_ID 15
SOAR_ID 16
ENUMERATION 17 1 tie
ENUMERATION 18 1 operator
SOAR_ID 19
ENUMERATION 20 1 water-jug
ENUMERATION 21 1 yes
ENUMERATION 22 1 jug
ENUMERATION 23 1 empty
SOAR_ID 24
FLOAT_RANGE 25 -Infinity Infinity
41
0 desired 15
0 failure 15
0 jug 10
0 name 3
0 operator 4
0 operator 6
0 operator 8
0 operator 12
0 problem-space 19
0 success 15
0 superstate 2
0 superstate-set 0
0 tried-tied-operator 24
0 type 1
4 into 10
4 jug 10
4 name 5
6 into 10
6 jug 10
6 name 7
8 into 10
8 jug 10
8 name 9
10 contents 25
10 empty 11
10 volume 14
12 into 10
12 name 13
15 jug 10
16 attribute 18
16 impasse 17
16 item 8
16 item 12
16 item 6
16 superstate 0
16 superstate-set 0
19 default-state-copy 21
19 dont-copy 23
19 jug 10
19 name 20
19 two-level-attributes 22
