43
SOAR_ID 0
SOAR_ID 1
SOAR_ID 2
SOAR_ID 3
SOAR_ID 4
ENUMERATION 5 1 state
ENUMERATION 6 1 nil
ENUMERATION 7 1 wizards
ENUMERATION 8 1 initialize-wizards
SOAR_ID 9
ENUMERATION 10 3 A B C
SOAR_ID 11
ENUMERATION 12 3 black no white
ENUMERATION 13 3 black unknown white
SOAR_ID 14
ENUMERATION 15 2 black white
ENUMERATION 16 2 black white
SOAR_ID 17
ENUMERATION 18 1 consider-knows
SOAR_ID 19
ENUMERATION 20 1 ascribe-knowledge
ENUMERATION 21 2 black white
ENUMERATION 22 2 guessed mark
SOAR_ID 23
ENUMERATION 24 1 ascribe-variable
ENUMERATION 25 1 variable
SOAR_ID 26
ENUMERATION 27 1 assign
ENUMERATION 28 2 black white
SOAR_ID 29
ENUMERATION 30 1 deduce-bbw
SOAR_ID 31
ENUMERATION 32 1 self-unknown
SOAR_ID 33
ENUMERATION 34 1 knows-own-mind
ENUMERATION 35 3 A B C
ENUMERATION 36 2 black white
ENUMERATION 37 2 no yes
ENUMERATION 38 1 true
SOAR_ID 39
ENUMERATION 40 1 complement
SOAR_ID 41
ENUMERATION 42 1 detect-done
56
0 io 1
0 knows 9
0 name 7
0 operator 4
0 operator 17
0 operator 19
0 operator 23
0 operator 26
0 operator 29
0 operator 31
0 operator 33
0 operator 39
0 operator 41
0 superstate 6
0 top-knows 9
0 top-state 0
0 type 5
1 input-link 2
1 output-link 3
4 name 8
9 knows 9
9 name 10
9 wizard 11
11 contradiction 38
11 guessed 12
11 mark 13
11 mark 14
11 name 10
14 assigned 9
14 failed-mark 16
14 type 25
14 untried-value 28
14 value 15
17 name 18
17 wizard 11
19 attribute 22
19 knows 9
19 mark 21
19 name 20
19 wizard-name 10
23 attribute 22
23 knows 9
23 name 24
23 wizard-name 10
26 mark 14
26 name 27
26 value 28
29 name 30
31 name 32
31 wizard 11
33 guessed 37
33 mark 36
33 name 34
33 wizard-name 35
39 name 40
41 name 42
