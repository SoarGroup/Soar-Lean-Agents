# Decisions, 7 November 2026 (JL)

1. KenKen chunking: (b) recast negated tests as positive counts so chunks can form. To do (general: affects `none` tests inside look-ahead).
2. Knight's tour backtracking: allowed. It abandons a path in a forward search; there is no undo operator. Recorded as an exception to ELB-014.
3. SUB-013 (^task-state for nested substates): accepted, Should.
4. M&C look-ahead chunk loop: (a) do not chunk duplicate-state failures. To do.
5. Soar RL-template bug: reported. Added to Soar-9.6.5-Kernel-Defects.docx, defect 28 (the init-soar case), with bugs/rl-template-init-soar.soar.
6. Eight Puzzle V2: keep an expected-value variant (it is what later becomes RL rules; numeric values become comparative preferences). To do.
7. Arithmetic V4, V9, V10, save, solve-problem: check their procedures and add them as variants. To do, after I/O.

## Assumption review (JL, 11:12)
- Eight puzzle E1: keep the originals' bindings (learning is more general). New convention STA (Should): relations changed by operators are explicit on the state, pointing to their arguments, not numeric codes or static links. To do: regenerate eight puzzle with ^binding objects.
- E2–E5, E7: accepted. (No E6 in the list: A6 was decision 6, expected-value variant.)
- Blocks World B1–B5: accepted.
- Pyramid P5, P7: accepted.
- Arithmetic R1–R3, R5–R7: accepted. R4: keep V5's approach as an alternative variant (carry into the top digit; borrow by decrementing the next column, recursively). To do.
- Knight's tour K2–K6: accepted.
- KenKen N1–N4, N6: accepted. N5: do NOT drop board printing — print the board at the end. To do.
- Wizards W1–W7: accepted.

- 14:32 graph-search-smem V1/V2: skipped for now and kept on QUEUE.md under Deferred (needs real numbers, an A* look-ahead and a semantic-memory construct; the originals never start their mission in 9.6.5).
- 14:30 count-epmem V1: moved to testing-only (a regression test of episodic and semantic memory, like count-test).
- 16:45 tower-of-hanoi-search V1: deferred by analogy with graph-search-smem (modified iterative-deepening selection library; no first move in 100,000 decisions on five disks). JL to confirm.
- 17:30 Arithmetic: (1) V3, V9, V10, V11 deferred until a semantic-memory construct; (2) multiplication V1 is replaced by the `subtraction` variant (its built-in problem is a subtraction; the multiplication branch is unfinished); (3) algebra V3 deferred. V4 joins `arithmetic-v5`, arithmetic-save joins `arithmetic`; new variants `arithmetic-solve-problem`, `addition`, `subtraction`.
