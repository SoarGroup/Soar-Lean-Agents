# Step 6 queue (7 Nov 2026, 14:10, revised)

Task agents in the corpus: 262. Done: 91. Dropped earlier: testing-only 18, trivial 15. Skipped now: 83. Remaining: 20.

Rules (JL, 7 Nov): skip agents with ^world/^scene when other versions exist; skip the Pyramid instruct agents; skip agents that need an external environment; Towers of Hanoi limited to five disks on three pegs. An agent is skipped for I/O only if it reads the input-link; agents that keep their own model on the output-link (the Blocks World gripper) or only write to it are kept.

Done from this queue: KenKen board printing; TicTacToe V1 (`tictactoe`, MATCH); left-right V1 (`left-right`, identical to V1 on 100 seeds, MATCH); Towers of Hanoi iterative: towers-of-hanoi V1/V2, -fast V1/V2, -faster V1/V2 (`towers-of-hanoi`, same 31 moves, MATCH) and -no-ops V1 (outside the conventions, replaced by `towers-of-hanoi`); Towers of Hanoi means-ends: -recursive V1/V2, -recur V1 (`towers-of-hanoi-mea`, same moves, MATCH); Arithmetic: V4 (`arithmetic-v5`), arithmetic-save (`arithmetic`), arithmetic-solve-problem, addition, subtraction (new variants, MATCH), multiplication (replaced by `subtraction`, JL); Blocks World: BW-RL V1/V2, blocks-world-RL V2 (`blocks-world-rl`), BW-Op-Subgoal-RL V1 and blocks-world-operator-subgoaling-RL V2–V4 (`blocks-world-operator-subgoaling-relevant`); blocks-world-operator-subgoaling-lookahead V2 not working (unfinished).

Order (JL, 7 Nov): after KenKen, families with the fewest remaining first, Blocks World last: Blocks World.

## Blocks World — 0 (done 8 Nov 2026)

Done 8 Nov: `blocks-world-look-ahead-state-eval` (BW-LA-state-eval V1, V2, blocks-world-lookahead-state-evaluation V2, V3); `blocks-world-hierarchical` (BW-Hierarchical V1, V2, blocks-world-hierarchical V2–V5); `blocks-world-epmem` (blocks-world-epmem V2, episodic-memory construct); `blocks-world-hrl` (blocks-world-HRL V1, substate RL construct).

HRL (3) and hierarchical look-ahead (6): JL 8 Nov 13:32, option (b): done 8 Nov (`blocks-world-hrl`, `blocks-world-hrl-3level`, `blocks-world-hierarchical-lookahead`; constructs `SubRl`, `SubLookahead`).

## Next after the current family (JL, 7 Nov 17:30)
- Semantic-memory construct: retrieval and storing done 8 Nov (arithmetic V3, V9, V10, V11 replaced). graph-search-smem still deferred (also needs an A* look-ahead).
- Episodic-memory construct for retrieval: done 8 Nov (`Agent.epmemModel`, blocks-world-epmem V2).

## Deferred (JL, 7 Nov 14:32: skip for now, remember for later)
- arithmetic V3: done 8 Nov (`arithmetic-smem`, semantic-memory construct). arithmetic V9, V10, V11: done 8 Nov (`arithmetic-smem-learn`, `arithmetic-smem-chunk`; store construct). Originally: V9 and V11 (near-duplicates) also compute missing facts by counting and store them; V10 is V9 with a fixed problem list and chunking. Wait for a semantic-memory construct.
- algebra V3 (JL, 7 Nov 17:30): a different task (4·(23 + x) = 4 by about 30 rewrite operators), with floats, fixed numeric preferences and a print to the output-link; the DSL is integer-only.
- tower-of-hanoi-search V1 (deferred 7 Nov 16:45 by analogy with graph-search-smem; JL to confirm): look-ahead with a modified selection library (`selection-iterative-deepening.soar`) and an interrupt at the first top-level move; on five disks it makes no top-level move in 100,000 decisions (11 disks: out of memory). A replacement needs an iterative-deepening look-ahead, which the DSL's default-library look-ahead is not.
- graph-search-smem V1, V2: neither original starts its mission in Soar 9.6.5 (state no-changes nest to the goal-depth limit, halt at 107 decisions). A replacement needs real numbers and `compute-range`, an A*-style look-ahead through a modified selection library, and a semantic-memory construct; build a graph-search variant replacing graph-search V2 first.

## Skipped
- read the input-link (the task needs an environment) (28): Robot V1, advanced-move V1, advanced-move V2, avoider-robot V1, collect-cubes V1, count-blocks V1, cozmo V1, cozmo-save V1, cozmo-save2 V1, cube-stack V1, event-comprehension V1, flat-all V1, flat-phase V1, flat-phase-regions V1, flat-smart V1, hrl-full-max V1, hrl-nav V1, hrl-nav-general V1, hrl-nav-max V1, hrl-nav-max-general V1, johns-eater V1, jump-and-move V1, laird-dudo V1, move20 V1, robot-RL V1, robot-hierarchical-pickup V1, robot-move-turn-pickup-block V1, robot-pickup-block V1
- need an external environment (simulator) (33): Johnbot V1, MOUTBot V1, UCBot V1, agent_1 V1, buttons V1, clean-house-9-4-09 V1, clean-house-new V5, dice-easy V1, dice-hard V1, dice-harder V1, dice-hardest V1, dice-medium V1, dice-model-bot-new V1, dice-probabilities-true V1, discrete-agent V1, mummymaze1p-horiz.xbiduy V1, mummymaze1p-hreform.d9du2o V1, mummymaze1p-hv.d0mkoc V1, mummymaze1p-hv.ebd8g3 V1, mummymaze1p-hvrope.6ho6jr V1, mummymaze1p-hvrope.m9buyr V1, newmummy-jel V1, simple-robot-with-avoidance-line V1, simple-robot-with-avoidance-patrol-lab V1, simple-robot-with-avoidance-rectangle V1, simple-robot-with-avoidance-square V1, simple-robot-with-avoidance-star-plan V1, taxi V2, taxi-hrl V1, taxi-hrl-oracle V1, taxi-mapping V1, taxi-rl V1, taxi-rl-oracle V1
- ^world / ^scene on the state (other versions exist) (7): blocks-world-RL V3, blocks-world-operator-subgoaling-RL-world V1, blocks-world-opsub-lookahead V1, blocks-world-opsub-lookahead V2, blocks-world-opsub-lookahead V3, interpret-game-state-tower-change V1, opsub-core V1
- Pyramid instruct agents (JL: skip the rest of Pyramid) (10): instruct V1, instruct V2, instruct V3, instruct V5, instruct V6, instruct V7, instruct V8, instruct V9, instruct V10, instruct-01-03-05 V1
- JL, 7 Nov 14:05 (5): taxi V1, patrol V1, mummy-draw V1, mummy-draw-num V1, mummy-monitor V1
- testing-only, found on review (1): count-epmem V1 (a regression test of episodic and semantic memory: record 99 counter episodes, query each back, check the graph match; like count-test V1–V3)
