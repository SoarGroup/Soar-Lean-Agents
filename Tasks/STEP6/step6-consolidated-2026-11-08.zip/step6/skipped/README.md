# Originals not replaced

Task agents of the corpus with no generated variant, by status and reason (from `index.csv`). They are listed, not copied; the originals are in the corpus (`agents/working/<agent>/<version>`).

## skipped (87)

- **^world / ^scene on the state (other versions exist)** (7): blocks-world-RL V3, blocks-world-operator-subgoaling-RL-world V1, blocks-world-opsub-lookahead V1, blocks-world-opsub-lookahead V2, blocks-world-opsub-lookahead V3, opsub-core V1, interpret-game-state-tower-change V1
- **read the input-link (the task needs an environment)** (28): count-blocks V1, cube-stack V1, laird-dudo V1, advanced-move V1, advanced-move V2, johns-eater V1, jump-and-move V1, move20 V1, flat-all V1, flat-phase V1, flat-phase-regions V1, flat-smart V1, hrl-full-max V1, hrl-nav V1, hrl-nav-general V1, hrl-nav-max V1, hrl-nav-max-general V1, event-comprehension V1, Robot V1, avoider-robot V1, collect-cubes V1, cozmo V1, cozmo-save V1, cozmo-save2 V1, robot-RL V1, robot-hierarchical-pickup V1, robot-move-turn-pickup-block V1, robot-pickup-block V1
- **need an external environment (simulator)** (33): clean-house-9-4-09 V1, clean-house-new V5, dice-easy V1, dice-hard V1, dice-harder V1, dice-hardest V1, dice-medium V1, dice-model-bot-new V1, dice-probabilities-true V1, mummymaze1p-horiz.xbiduy V1, mummymaze1p-hreform.d9du2o V1, mummymaze1p-hv.d0mkoc V1, mummymaze1p-hv.ebd8g3 V1, mummymaze1p-hvrope.6ho6jr V1, mummymaze1p-hvrope.m9buyr V1, newmummy-jel V1, agent_1 V1, Johnbot V1, MOUTBot V1, UCBot V1, discrete-agent V1, simple-robot-with-avoidance-line V1, simple-robot-with-avoidance-patrol-lab V1, simple-robot-with-avoidance-rectangle V1, simple-robot-with-avoidance-square V1, simple-robot-with-avoidance-star-plan V1, taxi V2, taxi-hrl V1, taxi-hrl-oracle V1, taxi-mapping V1, taxi-rl V1, taxi-rl-oracle V1, buttons V1
- **testing-only, found on review** (1): count-epmem V1
- **JL, 7 Nov 14:05** (5): mummy-draw V1, mummy-draw-num V1, mummy-monitor V1, patrol V1, taxi V1
- **Mummy Maze (JL, 7 Nov)** (1): mummy-heuristics V1
- **Pyramid instruct agents (JL: skip the rest of Pyramid)** (10): instruct V1, instruct V10, instruct V2, instruct V3, instruct V5, instruct V6, instruct V7, instruct V8, instruct V9, instruct-01-03-05 V1
- **needs an external environment** (2): ChunkingDemoTests_Teach_Soar_90_Games V2, ChunkingDemoTests_Teach_Soar_9_Games V2

## deferred (7)

- **see notes/QUEUE.md** (4): algebra V3, graph-search-smem V1, graph-search-smem V2, tower-of-hanoi-search V1
- **with graph-search (A*-style look-ahead)** (1): ChunkingDemoTests_Demo_Graph_Search V1
- **A*-style look-ahead through a modified selection library** (2): graph-search V2, graph-search V3

## not replaced (5)

- **does not work in Soar 9.6.5 (tie with no selection library; never moves)** (1): blocks-world-operator-subgoaling-lookahead V2
- **a language-comprehension agent, misfiled under Eight Puzzle** (1): load-8p V1
- **RL never on; 0/17 solved; Soar 9.6.5 segfaults on 3 seeds** (1): mac-lookahead-RL V1
- **two top initializations tie; never starts** (1): mac-planning V2
- **duplicate rule does not prune; halts at the goal-depth limit** (1): mac3-planning V1

## test (3)

- **architecture regression test** (3): count-test V1, count-test V2, count-test V3

## open (20)

- **Blocks World test-harness copy (not mapped)** (1): FunctionalTests_testBlocksWorld V1
- **Blocks World (to confirm)** (5): blocks-opsub V1, blocks-opsub V2, blocksworld V1, blocksworld V2, blocksworld V3
- **Counting (smem construct now exists)** (1): count V1
- **Dice** (1): bid46 V1
- **Eaters** (6): eater-default V1, jump V1, move V1, move-north V1, move-north-2 V1, move-to-food V1
- **Robots** (1): simple-robot-large-room V1
- **games** (2): chal V1, safe V1
- **games (KenKen V2)** (1): kenken V2
- **Water Jug (not in the pilot mapping)** (2): water-jug V1, water-jug-hierarchy V1

