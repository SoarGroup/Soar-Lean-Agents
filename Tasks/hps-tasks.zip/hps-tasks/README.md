# Task sets for replicating Langley, Barley & Meadows (2018)

Formal descriptions (PDDL) of the four domains and 52 problems for replicating the experiments in
P. Langley, M. Barley and B. Meadows, "Adaptive Search in a Hierarchical Problem-Solving
Architecture," *Advances in Cognitive Systems* 6 (2018), 251–270.

## Where the tasks came from

The paper does not publish its problems, and no public copy of HPS or its problem files was
found. Places checked: the paper itself, its University of Auckland ResearchSpace record (the
paper only), Langley's ISLE pages (not reachable), and web and GitHub searches for HPS, FPS and
the authors' names. The original Lisp task files are most likely with Pat Langley or Mike
Barley.

These sets are therefore **derived**. The domains follow what the paper specifies. The problems
are new instances generated to match the counts and solution-length ranges in the paper's
footnote 3. Each optimal length was computed by breadth-first search in the generator and checked
independently with pyperplan's breadth-first search; all 52 agree.

## What the paper specifies, and what these sets contain

| Domain | Paper (Sections 2.1, 3.1, footnote 3, p. 258) | These sets |
|---|---|---|
| Blocks World | 20 tasks with solutions of 4–10 operators. The operators are (pickup X), (putdown X), (stack X Y) and (unstack X Y) (Figure 1). Goals are conjunctions of `on` relations. | 20 tasks with 3–6 blocks. Goals are 1–3 `on` relations, taken from a random target configuration. There are five tasks each with optimal length 4, 6, 8 and 10. |
| Kinship | 10 problems needing 2–8 inference steps. Relations such as uncle, grandparent and ancestor are inferred from parent and male. The operators are datalog rules that only add literals. The forward branching factor is 34. | 10 problems over one family of 11 people across six generations. Exactly 34 rule instances apply to the initial state. There are 13 rules (below). Goals are 1–3 derived relations, needing 2–8 rule firings at minimum. |
| Five Puzzle | 12 tasks with 4–8 moves. There are five tiles and six cells, and the operators move a tile up, down, left or right. | 12 tasks on a 2 × 3 grid with goal `1 2 3 / 4 5 _`. Optimal lengths are 4 (2 tasks), 5 (2), 6 (3), 7 (2) and 8 (3). |
| Logistics | 10 tasks with 3–10 steps and at most two goals. The operators load and unload trucks and airplanes, drive trucks and fly airplanes. | 10 tasks using the STRIPS Logistics domain from the AIPS-98/2000 planning competitions. Each has 2–3 cities, each city with an airport and one other location, one truck per city, one airplane and 1–2 packages. Optimal lengths run from 3 to 10, with two tasks each of length 9 and 10. |

## Choices made here, not given in the paper

- **Blocks World, even lengths only.** The paper's range of 4–10 operators produces only even
  lengths here. With one gripper and `on` goals, every plan alternates grasping and releasing, so
  odd lengths cannot occur.
- **Kinship rules.** The rules are father, mother, grandparent, grandfather, grandmother,
  sibling, brother, sister, uncle, aunt, cousin, ancestor (base: parent) and ancestor
  (step: parent then ancestor). `(distinct ?x ?y)` is a static relation listing all pairs of
  different people. It replaces `:equality`, which some planners do not support.
- **Kinship family.** The family was chosen so that the initial state's forward branching factor
  is the paper's 34. The paper's own rule set and family are unknown, so the match is in this
  statistic only.
- **Kinship "inference steps".** These are taken to be the minimal number of rule firings needed
  to derive all the goal facts.
- **Five Puzzle.** Which cell is blank in the goal, and the layout, are assumptions.
- **Logistics.** The map sizes are assumptions chosen to give 3–10 step solutions with at most
  two package goals.
- **Typing.** All domains use `:typing`. The paper says HPS uses type information when it
  grounds operators.

## Experimental settings from the paper (for the replication)

- Search is limited to 10,000 generated nodes; a failure is recorded as 10,000.
- Each task is run 20 times, because HPS chooses among operators at random.
- Default parameters are in Table 1: one solution; depth limit 10 with loop checking; 30
  children per node; 10 retrieval failures; on failure, select the parent node.
- The measure is the number of nodes generated before a solution is found.

## Files

- `blocks/`, `logistics/`, `five-puzzle/`, `kinship/`: `domain.pddl` plus one file per problem.
  Each problem file has its optimal length in a comment on its first line.
- `manifest.csv`: for each problem, the domain, name, optimal length, size, number of goals and one
  optimal plan.
- `gen/`: `make_tasks.py` and `strips.py`. `python3 gen/make_tasks.py OUTDIR 2018` regenerates
  these exact sets; another seed gives new sets with the same properties.
