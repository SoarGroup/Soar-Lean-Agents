; optimal plan length 4
(define (problem bw-01) (:domain blocks)
  (:objects
    a b c d - block)
  (:init
    (clear a)
    (clear b)
    (handempty)
    (on a c)
    (on c d)
    (ontable b)
    (ontable d))
  (:goal (and
      (on c b))))
