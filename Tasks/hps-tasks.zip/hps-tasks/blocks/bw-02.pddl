; optimal plan length 4
(define (problem bw-02) (:domain blocks)
  (:objects
    a b c - block)
  (:init
    (clear a)
    (clear c)
    (handempty)
    (on a b)
    (ontable b)
    (ontable c))
  (:goal (and
      (on b c))))
