; optimal plan length 4
(define (problem bw-03) (:domain blocks)
  (:objects
    a b c d - block)
  (:init
    (clear a)
    (clear b)
    (clear c)
    (handempty)
    (on b d)
    (ontable a)
    (ontable c)
    (ontable d))
  (:goal (and
      (on b a)
      (on c d))))
