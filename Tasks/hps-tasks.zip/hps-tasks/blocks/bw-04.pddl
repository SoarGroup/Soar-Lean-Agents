; optimal plan length 4
(define (problem bw-04) (:domain blocks)
  (:objects
    a b c d e - block)
  (:init
    (clear a)
    (clear b)
    (clear c)
    (clear e)
    (handempty)
    (on b d)
    (ontable a)
    (ontable c)
    (ontable d)
    (ontable e))
  (:goal (and
      (on a d)
      (on b e))))
