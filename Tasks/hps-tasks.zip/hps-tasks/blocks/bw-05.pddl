; optimal plan length 4
(define (problem bw-05) (:domain blocks)
  (:objects
    a b c d - block)
  (:init
    (clear a)
    (clear c)
    (handempty)
    (on a b)
    (on c d)
    (ontable b)
    (ontable d))
  (:goal (and
      (on a d))))
