; optimal plan length 6
(define (problem bw-06) (:domain blocks)
  (:objects
    a b c d e - block)
  (:init
    (clear a)
    (clear b)
    (handempty)
    (on b e)
    (on c d)
    (on e c)
    (ontable a)
    (ontable d))
  (:goal (and
      (on c b))))
