; optimal plan length 6
(define (problem bw-07) (:domain blocks)
  (:objects
    a b c d e - block)
  (:init
    (clear c)
    (clear d)
    (handempty)
    (on c e)
    (on d b)
    (on e a)
    (ontable a)
    (ontable b))
  (:goal (and
      (on d a))))
