; optimal plan length 6
(define (problem bw-08) (:domain blocks)
  (:objects
    a b c d e f - block)
  (:init
    (clear a)
    (clear c)
    (clear e)
    (handempty)
    (on c f)
    (on d b)
    (on f d)
    (ontable a)
    (ontable b)
    (ontable e))
  (:goal (and
      (on d f))))
