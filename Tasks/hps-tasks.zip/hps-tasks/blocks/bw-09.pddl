; optimal plan length 6
(define (problem bw-09) (:domain blocks)
  (:objects
    a b c d - block)
  (:init
    (clear a)
    (clear b)
    (clear c)
    (handempty)
    (on c d)
    (ontable a)
    (ontable b)
    (ontable d))
  (:goal (and
      (on a c)
      (on d b))))
