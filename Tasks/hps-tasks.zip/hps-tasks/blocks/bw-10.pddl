; optimal plan length 6
(define (problem bw-10) (:domain blocks)
  (:objects
    a b c d e - block)
  (:init
    (clear b)
    (clear e)
    (handempty)
    (on a c)
    (on c d)
    (on e a)
    (ontable b)
    (ontable d))
  (:goal (and
      (on b c))))
