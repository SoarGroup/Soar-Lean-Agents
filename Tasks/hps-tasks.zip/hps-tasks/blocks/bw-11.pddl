; optimal plan length 8
(define (problem bw-11) (:domain blocks)
  (:objects
    a b c d e - block)
  (:init
    (clear b)
    (clear e)
    (handempty)
    (on a d)
    (on b a)
    (on e c)
    (ontable c)
    (ontable d))
  (:goal (and
      (on a b)
      (on c a)
      (on e d))))
