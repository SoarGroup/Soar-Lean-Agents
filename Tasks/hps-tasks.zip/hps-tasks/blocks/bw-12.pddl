; optimal plan length 8
(define (problem bw-12) (:domain blocks)
  (:objects
    a b c d - block)
  (:init
    (clear c)
    (clear d)
    (handempty)
    (on b a)
    (on d b)
    (ontable a)
    (ontable c))
  (:goal (and
      (on a c)
      (on b d)
      (on c b))))
