; optimal plan length 8
(define (problem bw-13) (:domain blocks)
  (:objects
    a b c d e f - block)
  (:init
    (clear b)
    (clear c)
    (clear e)
    (clear f)
    (handempty)
    (on e d)
    (on f a)
    (ontable a)
    (ontable b)
    (ontable c)
    (ontable d))
  (:goal (and
      (on a f)
      (on d a))))
