; optimal plan length 8
(define (problem bw-14) (:domain blocks)
  (:objects
    a b c d e - block)
  (:init
    (clear a)
    (clear c)
    (clear e)
    (handempty)
    (on c d)
    (on d b)
    (ontable a)
    (ontable b)
    (ontable e))
  (:goal (and
      (on b a)
      (on e c))))
