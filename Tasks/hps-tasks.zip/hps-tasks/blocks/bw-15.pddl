; optimal plan length 8
(define (problem bw-15) (:domain blocks)
  (:objects
    a b c d - block)
  (:init
    (clear b)
    (clear c)
    (handempty)
    (on a d)
    (on b a)
    (ontable c)
    (ontable d))
  (:goal (and
      (on a c)
      (on c b)
      (on d a))))
