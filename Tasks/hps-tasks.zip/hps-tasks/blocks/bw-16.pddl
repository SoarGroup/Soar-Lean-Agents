; optimal plan length 10
(define (problem bw-16) (:domain blocks)
  (:objects
    a b c d e - block)
  (:init
    (clear a)
    (clear b)
    (clear c)
    (handempty)
    (on b e)
    (on c d)
    (ontable a)
    (ontable d)
    (ontable e))
  (:goal (and
      (on b e)
      (on d c)
      (on e d))))
