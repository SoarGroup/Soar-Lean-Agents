; optimal plan length 10
(define (problem bw-17) (:domain blocks)
  (:objects
    a b c d e - block)
  (:init
    (clear a)
    (clear d)
    (handempty)
    (on b e)
    (on c b)
    (on d c)
    (ontable a)
    (ontable e))
  (:goal (and
      (on b e)
      (on e c))))
