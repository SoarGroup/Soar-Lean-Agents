; optimal plan length 10
(define (problem bw-18) (:domain blocks)
  (:objects
    a b c d e - block)
  (:init
    (clear c)
    (clear e)
    (handempty)
    (on a b)
    (on b d)
    (on c a)
    (ontable d)
    (ontable e))
  (:goal (and
      (on c a)
      (on d b))))
