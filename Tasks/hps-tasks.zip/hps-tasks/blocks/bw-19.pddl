; optimal plan length 10
(define (problem bw-19) (:domain blocks)
  (:objects
    a b c d e f - block)
  (:init
    (clear a)
    (clear c)
    (handempty)
    (on a f)
    (on c b)
    (on d e)
    (on f d)
    (ontable b)
    (ontable e))
  (:goal (and
      (on b c)
      (on d a))))
