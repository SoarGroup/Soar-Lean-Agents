; optimal plan length 10
(define (problem bw-20) (:domain blocks)
  (:objects
    a b c d e f - block)
  (:init
    (clear a)
    (clear c)
    (handempty)
    (on a e)
    (on b d)
    (on c f)
    (on e b)
    (ontable d)
    (ontable f))
  (:goal (and
      (on a d)
      (on d e))))
