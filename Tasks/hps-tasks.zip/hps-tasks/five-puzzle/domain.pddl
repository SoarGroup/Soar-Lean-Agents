; Five Puzzle: five numbered tiles and one blank in a 2 x 3 grid. As in the Eight Puzzle,
; the operators move a tile up, down, left or right into the blank cell.
(define (domain five-puzzle)
  (:requirements :strips :typing)
  (:types tile cell)
  (:predicates (at ?t - tile ?c - cell) (blank ?c - cell)
               (above ?c1 - cell ?c2 - cell)    ; ?c1 is directly above ?c2
               (left-of ?c1 - cell ?c2 - cell)) ; ?c1 is directly left of ?c2
  (:action up :parameters (?t - tile ?from - cell ?to - cell)
    :precondition (and (at ?t ?from) (blank ?to) (above ?to ?from))
    :effect (and (at ?t ?to) (blank ?from) (not (at ?t ?from)) (not (blank ?to))))
  (:action down :parameters (?t - tile ?from - cell ?to - cell)
    :precondition (and (at ?t ?from) (blank ?to) (above ?from ?to))
    :effect (and (at ?t ?to) (blank ?from) (not (at ?t ?from)) (not (blank ?to))))
  (:action left :parameters (?t - tile ?from - cell ?to - cell)
    :precondition (and (at ?t ?from) (blank ?to) (left-of ?to ?from))
    :effect (and (at ?t ?to) (blank ?from) (not (at ?t ?from)) (not (blank ?to))))
  (:action right :parameters (?t - tile ?from - cell ?to - cell)
    :precondition (and (at ?t ?from) (blank ?to) (left-of ?from ?to))
    :effect (and (at ?t ?to) (blank ?from) (not (at ?t ?from)) (not (blank ?to)))))
