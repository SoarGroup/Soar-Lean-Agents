; optimal plan length 5; goal 1 2 3 / 4 5 _ with c11 top-left
(define (problem fp-04) (:domain five-puzzle)
  (:objects
    t1 t2 t3 t4 t5 - tile
    c11 c12 c13 c21 c22 c23 - cell)
  (:init
    (above c11 c21)
    (above c12 c22)
    (above c13 c23)
    (at t1 c21)
    (at t2 c11)
    (at t3 c12)
    (at t4 c22)
    (at t5 c23)
    (blank c13)
    (left-of c11 c12)
    (left-of c12 c13)
    (left-of c21 c22)
    (left-of c22 c23))
  (:goal (and
      (at t1 c11)
      (at t2 c12)
      (at t3 c13)
      (at t4 c21)
      (at t5 c22))))
