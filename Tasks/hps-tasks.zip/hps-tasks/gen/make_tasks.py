"""Generate the four HPS task domains (Langley, Barley & Meadows, ACS 6, 2018) as PDDL, with
instance sets matching the paper's stated distributions; optimal lengths by breadth-first search.
Usage: python3 make_tasks.py OUTDIR [SEED]"""
import random, sys, os, itertools, csv
from strips import Action, bfs, fact

OUT = sys.argv[1]; SEED = int(sys.argv[2]) if len(sys.argv) > 2 else 2018
rows = []

def write(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    open(path, "w").write(text)

def problem_pddl(name, domain, objs, init, goal, comment):
    o = "\n    ".join(objs)
    i = "\n    ".join(fact(f) for f in sorted(init))
    g = "\n      ".join(fact(f) for f in sorted(goal))
    return (f"; {comment}\n(define (problem {name}) (:domain {domain})\n  (:objects\n    {o})\n"
            f"  (:init\n    {i})\n  (:goal (and\n      {g})))\n")

def pick(cands, targets, per):
    """cands: list of (length, data). Choose `per[t]` per target length, in order of generation."""
    chosen = []
    for t in targets:
        got = [c for c in cands if c[0] == t][:per.get(t, 1)]
        if len(got) < per.get(t, 1): raise SystemExit(f"not enough candidates of length {t}")
        chosen += got
    return chosen

# ---------------------------------------------------------------- Blocks World (4 operators)
BW_DOMAIN = """; Blocks World with the four operators named in the paper's Figure 1:
; (pickup ?x) (putdown ?x) (stack ?x ?y) (unstack ?x ?y), one gripper.
(define (domain blocks)
  (:requirements :strips :typing)
  (:types block)
  (:predicates (on ?x - block ?y - block) (ontable ?x - block) (clear ?x - block)
               (handempty) (holding ?x - block))
  (:action pickup :parameters (?x - block)
    :precondition (and (clear ?x) (ontable ?x) (handempty))
    :effect (and (holding ?x) (not (ontable ?x)) (not (clear ?x)) (not (handempty))))
  (:action putdown :parameters (?x - block)
    :precondition (holding ?x)
    :effect (and (ontable ?x) (clear ?x) (handempty) (not (holding ?x))))
  (:action stack :parameters (?x - block ?y - block)
    :precondition (and (holding ?x) (clear ?y))
    :effect (and (on ?x ?y) (clear ?x) (handempty) (not (holding ?x)) (not (clear ?y))))
  (:action unstack :parameters (?x - block ?y - block)
    :precondition (and (on ?x ?y) (clear ?x) (handempty))
    :effect (and (holding ?x) (clear ?y) (not (on ?x ?y)) (not (clear ?x)) (not (handempty)))))
"""
def bw_actions(bs):
    acts = []
    for x in bs:
        acts.append(Action(f"(pickup {x})", [("clear",x),("ontable",x),("handempty",)], [("holding",x)], [("ontable",x),("clear",x),("handempty",)]))
        acts.append(Action(f"(putdown {x})", [("holding",x)], [("ontable",x),("clear",x),("handempty",)], [("holding",x)]))
        for y in bs:
            if x == y: continue
            acts.append(Action(f"(stack {x} {y})", [("holding",x),("clear",y)], [("on",x,y),("clear",x),("handempty",)], [("holding",x),("clear",y)]))
            acts.append(Action(f"(unstack {x} {y})", [("on",x,y),("clear",x),("handempty",)], [("holding",x),("clear",y)], [("on",x,y),("clear",x),("handempty",)]))
    return acts
def bw_random_towers(rng, bs):
    bs = bs[:]; rng.shuffle(bs); towers = []
    for b in bs:
        if towers and rng.random() < 0.6: rng.choice(towers).append(b)
        else: towers.append([b])
    return towers
def bw_state(towers):
    s = {("handempty",)}
    for t in towers:
        s.add(("ontable", t[0])); s.add(("clear", t[-1]))
        for a, b in zip(t, t[1:]): s.add(("on", b, a))
    return s
def blocks(rng):
    write(f"{OUT}/blocks/domain.pddl", BW_DOMAIN)
    cands = []; seen = set()
    for _ in range(4000):
        n = rng.choice([3, 4, 4, 5, 5, 6])
        bs = [chr(ord("a") + i) for i in range(n)]
        init = bw_state(bw_random_towers(rng, bs))
        goal_full = {f for f in bw_state(bw_random_towers(rng, bs)) if f[0] == "on"}
        if not goal_full: continue
        k = rng.randint(1, len(goal_full)); goal = set(rng.sample(sorted(goal_full), k))
        key = (frozenset(init), frozenset(goal))
        if key in seen: continue
        seen.add(key)
        r = bfs(init, goal, bw_actions(bs), limit=10)
        if r and 4 <= r[0] <= 10: cands.append((r[0], (bs, init, goal, r[1])))

    # With one gripper and 'on' goals every plan alternates grasp and release, so lengths are even.
    per = {4: 5, 6: 5, 8: 5, 10: 5}
    for i, (L, (bs, init, goal, plan)) in enumerate(pick(cands, (4, 6, 8, 10), per), 1):
        name = f"bw-{i:02d}"
        write(f"{OUT}/blocks/{name}.pddl", problem_pddl(name, "blocks", [" ".join(bs) + " - block"], init, goal,
              f"optimal plan length {L}"))
        rows.append(["blocks", name, L, len(bs), len(goal), " ".join(plan)])

# ---------------------------------------------------------------- Logistics (IPC STRIPS)
LOG_DOMAIN = """; Logistics in the STRIPS form of the AIPS-98/2000 planning competitions: trucks move
; packages between locations of one city, airplanes between airports of different cities.
(define (domain logistics)
  (:requirements :strips :typing)
  (:types truck airplane - vehicle  package vehicle - physobj
          airport - location  city location physobj - object)
  (:predicates (in-city ?loc - location ?city - city) (at ?obj - physobj ?loc - location)
               (in ?pkg - package ?veh - vehicle))
  (:action load-truck :parameters (?pkg - package ?truck - truck ?loc - location)
    :precondition (and (at ?truck ?loc) (at ?pkg ?loc))
    :effect (and (not (at ?pkg ?loc)) (in ?pkg ?truck)))
  (:action load-airplane :parameters (?pkg - package ?airplane - airplane ?loc - location)
    :precondition (and (at ?pkg ?loc) (at ?airplane ?loc))
    :effect (and (not (at ?pkg ?loc)) (in ?pkg ?airplane)))
  (:action unload-truck :parameters (?pkg - package ?truck - truck ?loc - location)
    :precondition (and (at ?truck ?loc) (in ?pkg ?truck))
    :effect (and (not (in ?pkg ?truck)) (at ?pkg ?loc)))
  (:action unload-airplane :parameters (?pkg - package ?airplane - airplane ?loc - location)
    :precondition (and (in ?pkg ?airplane) (at ?airplane ?loc))
    :effect (and (not (in ?pkg ?airplane)) (at ?pkg ?loc)))
  (:action drive-truck :parameters (?truck - truck ?loc-from - location ?loc-to - location ?city - city)
    :precondition (and (at ?truck ?loc-from) (in-city ?loc-from ?city) (in-city ?loc-to ?city))
    :effect (and (not (at ?truck ?loc-from)) (at ?truck ?loc-to)))
  (:action fly-airplane :parameters (?airplane - airplane ?loc-from - airport ?loc-to - airport)
    :precondition (at ?airplane ?loc-from)
    :effect (and (not (at ?airplane ?loc-from)) (at ?airplane ?loc-to))))
"""
def logistics(rng):
    write(f"{OUT}/logistics/domain.pddl", LOG_DOMAIN)
    cands = []; seen = set()
    for _ in range(3000):
        nc = rng.choice([2, 2, 3]); npk = rng.choice([1, 2, 2])
        cities = [f"c{i}" for i in range(nc)]
        locs = {c: [f"{c}-ap", f"{c}-p1"] for c in cities}          # one airport, one other place
        airports = [locs[c][0] for c in cities]; alll = [l for c in cities for l in locs[c]]
        trucks = {c: f"t{i}" for i, c in enumerate(cities)}; plane = "a0"; pkgs = [f"p{i}" for i in range(npk)]
        static = {("in-city", l, c) for c in cities for l in locs[c]}
        init = set(static) | {("at", trucks[c], rng.choice(locs[c])) for c in cities} | {("at", plane, rng.choice(airports))}
        init |= {("at", p, rng.choice(alll)) for p in pkgs}
        goal = {("at", p, rng.choice(alll)) for p in pkgs}
        if goal <= init: continue
        key = (frozenset(init), frozenset(goal))
        if key in seen: continue
        seen.add(key)
        acts = []
        for p in pkgs:
            for c in cities:
                for l in locs[c]:
                    t = trucks[c]
                    acts.append(Action(f"(load-truck {p} {t} {l})", [("at",t,l),("at",p,l)], [("in",p,t)], [("at",p,l)]))
                    acts.append(Action(f"(unload-truck {p} {t} {l})", [("at",t,l),("in",p,t)], [("at",p,l)], [("in",p,t)]))
            for l in airports:
                acts.append(Action(f"(load-airplane {p} {plane} {l})", [("at",plane,l),("at",p,l)], [("in",p,plane)], [("at",p,l)]))
                acts.append(Action(f"(unload-airplane {p} {plane} {l})", [("at",plane,l),("in",p,plane)], [("at",p,l)], [("in",p,plane)]))
        for c in cities:
            for a, b in itertools.permutations(locs[c], 2):
                acts.append(Action(f"(drive-truck {trucks[c]} {a} {b} {c})", [("at",trucks[c],a)], [("at",trucks[c],b)], [("at",trucks[c],a)]))
        for a, b in itertools.permutations(airports, 2):
            acts.append(Action(f"(fly-airplane {plane} {a} {b})", [("at",plane,a)], [("at",plane,b)], [("at",plane,a)]))
        r = bfs(init, goal, acts, limit=10)
        if r and 3 <= r[0] <= 10:
            objs = [" ".join(pkgs) + " - package", " ".join(trucks.values()) + " - truck", plane + " - airplane",
                    " ".join(airports) + " - airport", " ".join(l for c in cities for l in locs[c][1:]) + " - location",
                    " ".join(cities) + " - city"]
            cands.append((r[0], (objs, init, goal, r[1], nc, npk)))
    from collections import Counter; print("logistics lengths", sorted(Counter(c[0] for c in cands).items()))
    per = {3: 1, 4: 1, 5: 1, 6: 1, 7: 1, 8: 1, 9: 2, 10: 2}
    for i, (L, (objs, init, goal, plan, nc, npk)) in enumerate(pick(cands, range(3, 11), per), 1):
        name = f"log-{i:02d}"
        write(f"{OUT}/logistics/{name}.pddl", problem_pddl(name, "logistics", objs, init, goal, f"optimal plan length {L}"))
        rows.append(["logistics", name, L, f"{nc} cities, {npk} packages", len(goal), " ".join(plan)])

# ---------------------------------------------------------------- Five Puzzle (2 x 3, five tiles)
FP_DOMAIN = """; Five Puzzle: five numbered tiles and one blank in a 2 x 3 grid. As in the Eight Puzzle,
; the operators move a tile up, down, left or right into the blank cell.
(define (domain five-puzzle)
  (:requirements :strips :typing)
  (:types tile cell)
  (:predicates (at ?t - tile ?c - cell) (blank ?c - cell)
               (above ?c1 - cell ?c2 - cell)    ; ?c1 is directly above ?c2
               (left-of ?c1 - cell ?c2 - cell)) ; ?c1 is directly left of ?c2
  (:action up :parameters (?t - tile ?from - cell ?to - cell)
    :precondition (and (at ?t ?from) (blank ?to) (above ?to ?from))
    :effect (and (at ?t ?to) (blank ?from) (not (at ?t ?from)) (not (blank ?to))))
  (:action down :parameters (?t - tile ?from - cell ?to - cell)
    :precondition (and (at ?t ?from) (blank ?to) (above ?from ?to))
    :effect (and (at ?t ?to) (blank ?from) (not (at ?t ?from)) (not (blank ?to))))
  (:action left :parameters (?t - tile ?from - cell ?to - cell)
    :precondition (and (at ?t ?from) (blank ?to) (left-of ?to ?from))
    :effect (and (at ?t ?to) (blank ?from) (not (at ?t ?from)) (not (blank ?to))))
  (:action right :parameters (?t - tile ?from - cell ?to - cell)
    :precondition (and (at ?t ?from) (blank ?to) (left-of ?from ?to))
    :effect (and (at ?t ?to) (blank ?from) (not (at ?t ?from)) (not (blank ?to)))))
"""
def five(rng):
    write(f"{OUT}/five-puzzle/domain.pddl", FP_DOMAIN)
    cells = [f"c{r}{c}" for r in (1, 2) for c in (1, 2, 3)]
    static = {("above", f"c1{c}", f"c2{c}") for c in (1, 2, 3)} | {("left-of", f"c{r}{c}", f"c{r}{c+1}") for r in (1, 2) for c in (1, 2)}
    tiles = [f"t{i}" for i in range(1, 6)]
    acts = []
    for t in tiles:
        for (k, a, b) in [(f[0], f[1], f[2]) for f in static]:
            if k == "above":
                acts.append(Action(f"(up {t} {b} {a})", [("at",t,b),("blank",a)], [("at",t,a),("blank",b)], [("at",t,b),("blank",a)]))
                acts.append(Action(f"(down {t} {a} {b})", [("at",t,a),("blank",b)], [("at",t,b),("blank",a)], [("at",t,a),("blank",b)]))
            else:
                acts.append(Action(f"(left {t} {b} {a})", [("at",t,b),("blank",a)], [("at",t,a),("blank",b)], [("at",t,b),("blank",a)]))
                acts.append(Action(f"(right {t} {a} {b})", [("at",t,a),("blank",b)], [("at",t,b),("blank",a)], [("at",t,a),("blank",b)]))
    goal = {("at", tiles[i], cells[i]) for i in range(5)}          # 1 2 3 / 4 5 _
    goal_state = set(static) | goal | {("blank", cells[5])}
    cands = []; seen = set()
    for _ in range(3000):
        s = set(goal_state)
        for _ in range(rng.randint(4, 30)):                         # random walk: always solvable
            s = set(rng.choice([a for a in acts if a.pre <= s]).apply(frozenset(s)))
        key = frozenset(s)
        if key in seen: continue
        seen.add(key)
        r = bfs(s, goal, acts, limit=8)
        if r and 4 <= r[0] <= 8: cands.append((r[0], (s, r[1])))
    from collections import Counter; print("five lengths", sorted(Counter(c[0] for c in cands).items()))
    per = {4: 2, 5: 2, 6: 3, 7: 2, 8: 3}
    for i, (L, (s, plan)) in enumerate(pick(cands, range(4, 9), per), 1):
        name = f"fp-{i:02d}"
        write(f"{OUT}/five-puzzle/{name}.pddl", problem_pddl(name, "five-puzzle", [" ".join(tiles) + " - tile", " ".join(cells) + " - cell"],
              s, goal, f"optimal plan length {L}; goal 1 2 3 / 4 5 _ with c11 top-left"))
        rows.append(["five-puzzle", name, L, "5 tiles", len(goal), " ".join(plan)])

# ---------------------------------------------------------------- Kinship (datalog rules as add-only operators)
KIN_RULES = [  # (name, head, body, distinct-pairs)
    ("father",      ("father","?x","?y"),      [("parent","?x","?y"),("male","?x")], []),
    ("mother",      ("mother","?x","?y"),      [("parent","?x","?y"),("female","?x")], []),
    ("grandparent", ("grandparent","?x","?z"), [("parent","?x","?y"),("parent","?y","?z")], []),
    ("grandfather", ("grandfather","?x","?z"), [("grandparent","?x","?z"),("male","?x")], []),
    ("grandmother", ("grandmother","?x","?z"), [("grandparent","?x","?z"),("female","?x")], []),
    ("sibling",     ("sibling","?x","?y"),     [("parent","?p","?x"),("parent","?p","?y"),("distinct","?x","?y")], []),
    ("brother",     ("brother","?x","?y"),     [("sibling","?x","?y"),("male","?x")], []),
    ("sister",      ("sister","?x","?y"),      [("sibling","?x","?y"),("female","?x")], []),
    ("uncle",       ("uncle","?x","?z"),       [("brother","?x","?y"),("parent","?y","?z")], []),
    ("aunt",        ("aunt","?x","?z"),        [("sister","?x","?y"),("parent","?y","?z")], []),
    ("cousin",      ("cousin","?x","?y"),      [("parent","?a","?x"),("sibling","?a","?b"),("parent","?b","?y")], []),
    ("ancestor-base", ("ancestor","?x","?y"),  [("parent","?x","?y")], []),
    ("ancestor-step", ("ancestor","?x","?z"),  [("parent","?x","?y"),("ancestor","?y","?z")], []),
]
def kin_domain():
    out = ["; Kinship: primitive relations parent, male and female; each operator is a datalog rule",
           "; that only adds its conclusion to the state (monotonic inference).",
           "; (distinct ?x ?y) is a static relation listing every pair of different people, so the domain",
           "; needs no :equality.",
           "(define (domain kinship)", "  (:requirements :strips :typing)", "  (:types person)",
           "  (:predicates (parent ?x - person ?y - person) (male ?x - person) (female ?x - person) (distinct ?x - person ?y - person)"]
    preds = sorted({r[1][0] for r in KIN_RULES})
    out.append("               " + " ".join(f"({p} ?x - person ?y - person)" for p in preds) + ")")
    for name, head, body, dist in KIN_RULES:
        vs = sorted({v for f in [head] + body for v in f[1:]})
        pre = " ".join(fact(f) for f in body) + "".join(f" (not (= {a} {b}))" for a, b in dist)
        out.append(f"  (:action {name} :parameters ({' '.join(v + ' - person' for v in vs)})")
        out.append(f"    :precondition (and {pre})")
        out.append(f"    :effect {fact(head)})")
    out[-1] += ")"
    return "\n".join(out) + "\n"
def kin_ground(people, facts):
    """All rule instances (with bodies over any facts) as add-only actions."""
    acts = []
    for name, head, body, dist in KIN_RULES:
        vs = sorted({v for f in [head] + body for v in f[1:]})
        for vals in itertools.product(people, repeat=len(vs)):
            b = dict(zip(vs, vals))
            if any(b[x] == b[y] for x, y in dist): continue
            sub = lambda f: tuple([f[0]] + [b[v] for v in f[1:]])
            acts.append(Action(f"({name} {' '.join(vals)})", [sub(f) for f in body], [sub(head)]))
    return acts
def kinship(rng):
    write(f"{OUT}/kinship/domain.pddl", kin_domain())
    # A four-generation family; names are arbitrary.
    # Six generations, chosen so that 34 rule instances apply to the initial state, the forward
    # branching factor the paper reports for its Kinship tasks.
    tree = {"ann": ["bob", "dee"], "bob": ["eve"], "dee": ["gus", "hal"], "eve": ["ivy"],
            "gus": ["kim"], "kim": ["lee", "max"], "max": ["ned"]}
    male = {"bob", "gus", "hal", "lee", "max", "ned"}
    people = sorted(set(tree) | {c for cs in tree.values() for c in cs})
    init = {("parent", p, c) for p, cs in tree.items() for c in cs}
    init |= {("male", x) for x in people if x in male} | {("female", x) for x in people if x not in male}
    init |= {("distinct", x, y) for x in people for y in people if x != y}
    acts = kin_ground(people, init)
    fb = sum(1 for a in acts if a.pre <= init and not a.add <= init)
    # candidate goals: every derivable fact (and pairs of them); minimal number of rule firings by BFS
    # over the facts relevant to the goal (backward cone), which is exact for monotonic rules.
    closure = set(init)
    while True:
        new = {f for a in acts if a.pre <= closure for f in a.add} - closure
        if not new: break
        closure |= new
    derived = sorted(closure - init)
    def steps(goal):
        rel = set(goal); changed = True
        while changed:
            changed = False
            for a in acts:
                if a.add & rel and not a.pre <= rel:
                    rel |= a.pre; changed = True
        ra = [a for a in acts if a.add <= rel and a.pre <= closure and not a.add <= init]
        return bfs(init, goal, ra, limit=8, max_states=2_000_000)
    cands = []
    singles = derived[:]; rng.shuffle(singles)
    for g in singles:
        r = steps({g})
        if r and 2 <= r[0] <= 8: cands.append((r[0], ({g}, r[1])))
    for _ in range(600):
        g = set(rng.sample(derived, rng.choice([2, 3]))); r = steps(g)
        if r and 2 <= r[0] <= 8: cands.append((r[0], (g, r[1])))
    from collections import Counter; print("kinship lengths", sorted(Counter(c[0] for c in cands).items()))
    per = {2: 1, 3: 1, 4: 2, 5: 2, 6: 2, 7: 1, 8: 1}
    for i, (L, (goal, plan)) in enumerate(pick(cands, range(2, 9), per), 1):
        name = f"kin-{i:02d}"
        write(f"{OUT}/kinship/{name}.pddl", problem_pddl(name, "kinship", [" ".join(people) + " - person"], init, goal,
              f"minimal number of inference steps {L}; forward branching factor of the initial state {fb}"))
        rows.append(["kinship", name, L, f"{len(people)} people", len(goal), " ".join(plan)])
    return fb

rng = random.Random(SEED)
blocks(random.Random(SEED)); logistics(random.Random(SEED + 1)); five(random.Random(SEED + 2)); fb = kinship(random.Random(SEED + 3))
with open(f"{OUT}/manifest.csv", "w", newline="") as f:
    w = csv.writer(f); w.writerow(["domain", "problem", "optimal_length", "size", "goals", "one_optimal_plan"]); w.writerows(rows)
print(len(rows), "problems; kinship forward branching", fb)
