"""Grounded STRIPS: states are frozensets of fact tuples; breadth-first optimal planning."""
from collections import deque

class Action:
    __slots__ = ("name", "pre", "add", "dele")
    def __init__(self, name, pre, add, dele=()):
        self.name, self.pre, self.add, self.dele = name, frozenset(pre), frozenset(add), frozenset(dele)
    def applicable(self, s): return self.pre <= s
    def apply(self, s): return (s - self.dele) | self.add

def bfs(init, goal, actions, limit=12, max_states=3_000_000):
    """Optimal plan length (and one plan) or None. goal: set of facts."""
    init = frozenset(init); goal = frozenset(goal)
    if goal <= init: return 0, []
    parent = {init: None}; q = deque([(init, 0)])
    while q:
        s, d = q.popleft()
        if d >= limit: continue
        for a in actions:
            if a.pre <= s:
                t = (s - a.dele) | a.add
                if t in parent: continue
                parent[t] = (s, a.name)
                if goal <= t:
                    plan = []; u = t
                    while parent[u] is not None:
                        p, n = parent[u]; plan.append(n); u = p
                    return d + 1, plan[::-1]
                if len(parent) > max_states: return None
                q.append((t, d + 1))
    return None

def fact(f): return "(" + " ".join(f) + ")"
