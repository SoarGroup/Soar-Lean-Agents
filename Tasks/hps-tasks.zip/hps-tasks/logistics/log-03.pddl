; optimal plan length 5
(define (problem log-03) (:domain logistics)
  (:objects
    p0 p1 - package
    t0 t1 - truck
    a0 - airplane
    c0-ap c1-ap - airport
    c0-p1 c1-p1 - location
    c0 c1 - city)
  (:init
    (at a0 c0-ap)
    (at p0 c1-p1)
    (at p1 c1-p1)
    (at t0 c0-p1)
    (at t1 c1-p1)
    (in-city c0-ap c0)
    (in-city c0-p1 c0)
    (in-city c1-ap c1)
    (in-city c1-p1 c1))
  (:goal (and
      (at p0 c1-ap)
      (at p1 c1-ap))))
