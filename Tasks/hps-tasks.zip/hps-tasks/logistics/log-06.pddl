; optimal plan length 8
(define (problem log-06) (:domain logistics)
  (:objects
    p0 p1 - package
    t0 t1 t2 - truck
    a0 - airplane
    c0-ap c1-ap c2-ap - airport
    c0-p1 c1-p1 c2-p1 - location
    c0 c1 c2 - city)
  (:init
    (at a0 c0-ap)
    (at p0 c2-ap)
    (at p1 c1-p1)
    (at t0 c0-p1)
    (at t1 c1-p1)
    (at t2 c2-ap)
    (in-city c0-ap c0)
    (in-city c0-p1 c0)
    (in-city c1-ap c1)
    (in-city c1-p1 c1)
    (in-city c2-ap c2)
    (in-city c2-p1 c2))
  (:goal (and
      (at p0 c0-p1)
      (at p1 c1-p1))))
