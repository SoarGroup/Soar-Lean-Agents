# Agents that load but crash, do not finish, wait for input, or run incorrectly in Soar 9.6.5

13 versions of 9 agents, one folder per version: other-issues/<agent>/V<k>/, with every file Soar loads for it.
Run a version by sourcing its load file (MANIFEST.csv, column 'load file') from its folder.
Versions are numbered in the order received; a corrected version is a new version.
Status: Soar 9.6.5 (release), first indifferent choice, srand 0, at most 300 decisions; soar-lean comparison of November 3, 2026 (at most 100 decisions).
