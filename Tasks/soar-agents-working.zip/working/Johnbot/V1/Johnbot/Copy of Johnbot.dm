391
SOAR_ID 0
SOAR_ID 1
SOAR_ID 2
SOAR_ID 3
SOAR_ID 4
STRING 5
SOAR_ID 6
SOAR_ID 7
SOAR_ID 8
ENUMERATION 9 2 operator state
ENUMERATION 10 3 tie no-change conflict
SOAR_ID 11
SOAR_ID 12
STRING 13
ENUMERATION 14 1 true
SOAR_ID 15
SOAR_ID 16
SOAR_ID 17
INTEGER 18
SOAR_ID 19
SOAR_ID 20
SOAR_ID 21
SOAR_ID 22
ENUMERATION 23 1 true
SOAR_ID 24
SOAR_ID 25
SOAR_ID 26
INTEGER 27
ENUMERATION 28 2 room hall
SOAR_ID 29
SOAR_ID 30
SOAR_ID 31
SOAR_ID 32
INTEGER_RANGE 33 1 45
SOAR_ID 34
SOAR_ID 35
SOAR_ID 36
SOAR_ID 37
SOAR_ID 38
SOAR_ID 39
ENUMERATION 40 2 on off
ENUMERATION 41 2 on off
ENUMERATION 42 2 on off
ENUMERATION 43 2 on off
ENUMERATION 44 2 on off
ENUMERATION 45 11 attack explore retreat wander record-enemy remove-enemy select-enemy die live drop-item get-item
SOAR_ID 46
SOAR_ID 47
SOAR_ID 48
SOAR_ID 49
ENUMERATION 50 2 on off
SOAR_ID 51
SOAR_ID 52
ENUMERATION 53 2 true false
SOAR_ID 54
INTEGER 55
INTEGER 56
ENUMERATION 57 3 off up down
ENUMERATION 58 1 quake
SOAR_ID 59
INTEGER 60
ENUMERATION 61 3 dead dying alive
SOAR_ID 62
SOAR_ID 63
INTEGER 64
INTEGER 65
SOAR_ID 66
INTEGER 67
INTEGER 68
INTEGER 69
INTEGER 70
SOAR_ID 71
SOAR_ID 72
SOAR_ID 73
INTEGER 74
SOAR_ID 75
SOAR_ID 76
SOAR_ID 77
ENUMERATION 78 2 true false
SOAR_ID 79
SOAR_ID 80
SOAR_ID 81
ENUMERATION 82 26 weapon_railgun weapon_rocketlauncher weapon_blaster weapon_hyperblaster weapon_machinegun weapon_shotgun weapon_supershotgun weapon_chaingun weapon_grenadelauncher weapon_bfg ammo_cells ammo_slugs ammo_rockets ammo_grenades ammo_bullets ammo_shells item_armor_body item_armor_shard item_armor_combat item_armor_jacket item_health_small item_health item_health_medium item_health_large item_health_mega item_adrenaline
INTEGER 83
SOAR_ID 84
INTEGER 85
INTEGER 86
ENUMERATION 87 1 nil
ENUMERATION 88 3 off left right
ENUMERATION 89 3 off forward backward
ENUMERATION 90 2 true false
INTEGER 91
INTEGER 92
SOAR_ID 93
ENUMERATION 94 26 ammo_cells ammo_slugs ammo_rockets ammo_grenades ammo_bullets ammo_shells item_armor_shard item_armor_combat item_armor_jacket item_armor_body item_health_small item_health_mega item_adrenaline item_health_mega item_health item_health_large item_health_medium weapon_supershotgun weapon_shotgun weapon_machinegun weapon_chaingun weapon_grenadelauncher weapon_hyperblaster weapon_railgun weapon_bfg weapon_rocketlauncher
ENUMERATION 95 4 ammo weapon armor health
SOAR_ID 96
ENUMERATION 97 4 item_armor_shard item_armor_jacket item_armor_combat item_armor_body
INTEGER 98
INTEGER 99
STRING 100
STRING 101
ENUMERATION 102 2 tie no-change
SOAR_ID 103
ENUMERATION 104 1 none
ENUMERATION 105 1 true
SOAR_ID 106
SOAR_ID 107
INTEGER 108
ENUMERATION 109 4 east west north south
SOAR_ID 110
ENUMERATION 111 4 north south east west
ENUMERATION 112 4 north south east west
ENUMERATION 113 4 north south east west
SOAR_ID 114
ENUMERATION 115 6 item_health_large item_health_medium item_health item_health_small item_health_mega item_adrenaline
INTEGER 116
INTEGER 117
ENUMERATION 118 6 item_health_small item_health_large item_health_mega item_adrenaline item_health item_health_medium
INTEGER 119
ENUMERATION 120 1 true
ENUMERATION 121 1 true
ENUMERATION 122 1 none
ENUMERATION 123 4 east west north south
INTEGER 124
INTEGER 125
INTEGER 126
INTEGER 127
INTEGER 128
INTEGER 129
INTEGER 130
INTEGER 131
INTEGER 132
INTEGER 133
INTEGER 134
INTEGER 135
INTEGER 136
INTEGER 137
INTEGER 138
INTEGER 139
INTEGER 140
INTEGER 141
INTEGER 142
SOAR_ID 143
INTEGER 144
INTEGER 145
INTEGER 146
INTEGER 147
SOAR_ID 148
ENUMERATION 149 2 right left
ENUMERATION 150 2 left right
ENUMERATION 151 2 forward backward
ENUMERATION 152 2 forward backward
SOAR_ID 153
SOAR_ID 154
SOAR_ID 155
ENUMERATION 156 4 east west south north
ENUMERATION 157 4 north south east west
ENUMERATION 158 4 north south east west
INTEGER 159
SOAR_ID 160
ENUMERATION 161 2 west east
INTEGER 162
INTEGER 163
INTEGER 164
ENUMERATION 165 4 north south east west
ENUMERATION 166 6 item_health item_health_small item_health_medium item_health_mega item_adrenaline item_health_large
INTEGER 167
SOAR_ID 168
INTEGER 169
INTEGER 170
INTEGER 171
INTEGER 172
INTEGER 173
SOAR_ID 174
ENUMERATION 175 2 right left
ENUMERATION 176 2 right left
ENUMERATION 177 2 forward backward
ENUMERATION 178 2 forward backward
SOAR_ID 179
ENUMERATION 180 4 east west south north
ENUMERATION 181 1 backward
ENUMERATION 182 1 forward
ENUMERATION 183 1 left
ENUMERATION 184 1 right
INTEGER 185
INTEGER 186
INTEGER 187
INTEGER 188
ENUMERATION 189 2 hall room
ENUMERATION 190 3 easy medium hard
ENUMERATION 191 1 true
ENUMERATION 192 2 left right
ENUMERATION 193 3 forward backward off
SOAR_ID 194
INTEGER 195
INTEGER 196
SOAR_ID 197
INTEGER 198
ENUMERATION 199 2 true false
INTEGER 200
INTEGER 201
ENUMERATION 202 2 armor health
ENUMERATION 203 2 armor health
INTEGER 204
SOAR_ID 205
SOAR_ID 206
SOAR_ID 207
SOAR_ID 208
SOAR_ID 209
SOAR_ID 210
INTEGER 211
INTEGER 212
INTEGER 213
ENUMERATION 214 1 none
ENUMERATION 215 7 ammo_shells ammo_bullets ammo_grenades ammo_cells ammo_slugs ammo_rockets none
STRING 216
ENUMERATION 217 11 weapon_supershotgun weapon_shotgun weapon_bfg weapon_machinegun weapon_rocketlauncher weapon_railgun weapon_blaster weapon_hyperblaster weapon_chaingun weapon_grenadelauncher ammo_grenades
INTEGER 218
INTEGER 219
INTEGER 220
ENUMERATION 221 3 slow fast medium
ENUMERATION 222 6 short medium long short-medium short-medium-long medium-long
ENUMERATION 223 3 small medium large
ENUMERATION 224 2 no true
INTEGER 225
INTEGER 226
INTEGER 227
INTEGER 228
INTEGER 229
ENUMERATION 230 1 large
STRING 231
ENUMERATION 232 4 health weapon ammo armor
SOAR_ID 233
ENUMERATION 234 1 true
ENUMERATION 235 2 true false
ENUMERATION 236 1 true
ENUMERATION 237 1 true
ENUMERATION 238 1 attack
ENUMERATION 239 1 wander
ENUMERATION 240 1 true
ENUMERATION 241 2 circle-strafe direct-attack
ENUMERATION 242 4 left right backward forward
INTEGER 243
INTEGER 244
INTEGER 245
INTEGER 246
ENUMERATION 247 1 different
ENUMERATION 248 2 true false
ENUMERATION 249 2 low-weapon low-health
INTEGER 250
INTEGER 251
ENUMERATION 252 2 true false
SOAR_ID 253
ENUMERATION 254 14 approach-enemy charge-enemy circle-strafe clean-up-enemy create-retreat direct-attack face-enemy follow-enemy get-item jump select-attack-type select-target shoot set-current-room
ENUMERATION 255 2 left right
SOAR_ID 256
ENUMERATION 257 2 left right
ENUMERATION 258 2 on off
ENUMERATION 259 2 left right
INTEGER 260
ENUMERATION 261 3 left right off
INTEGER 262
SOAR_ID 263
INTEGER 264
INTEGER 265
INTEGER 266
ENUMERATION 267 4 attack retreat wander explore
INTEGER 268
SOAR_ID 269
ENUMERATION 270 2 true false
ENUMERATION 271 3 up down off
FLOAT 272
FLOAT 273
FLOAT 274
FLOAT 275
INTEGER 276
STRING 277
STRING 278
STRING 279
INTEGER 280
STRING 281
STRING 282
INTEGER 283
INTEGER 284
INTEGER 285
SOAR_ID 286
STRING 287
STRING 288
STRING 289
ENUMERATION 290 3 left right off
ENUMERATION 291 3 up off down
ENUMERATION 292 2 on off
STRING 293
STRING 294
STRING 295
SOAR_ID 296
SOAR_ID 297
STRING 298
INTEGER 299
STRING 300
SOAR_ID 301
INTEGER 302
INTEGER 303
INTEGER 304
STRING 305
INTEGER 306
ENUMERATION 307 3 left right off
STRING 308
SOAR_ID 309
ENUMERATION 310 3 circle-strafe direct-attack pop-out
ENUMERATION 311 2 on off
ENUMERATION 312 9 get-item go-through-door hide notice-item-missing notice-item-present remove-search-room search-room update-health-armor set-current-room
SOAR_ID 313
ENUMERATION 314 10 get-item go-through-door hide notice-item-missing notice-item-present search-room remove-search-room set-current-room update-health update-armor
SOAR_ID 315
INTEGER 316
INTEGER 317
INTEGER 318
ENUMERATION 319 4 north south east west
INTEGER 320
ENUMERATION 321 4 health armor ammo weapon
ENUMERATION 322 1 true
ENUMERATION 323 3 wander attack explore
ENUMERATION 324 2 in-room recorded-in-room
SOAR_ID 325
INTEGER 326
ENUMERATION 327 1 hide
INTEGER 328
INTEGER 329
SOAR_ID 330
ENUMERATION 331 2 face-out move-to-corner
ENUMERATION 332 1 true
ENUMERATION 333 1 true
SOAR_ID 334
STRING 335
INTEGER 336
INTEGER 337
INTEGER 338
INTEGER 339
ENUMERATION 340 1 search-room
SOAR_ID 341
ENUMERATION 342 4 init-turn record-item turn-left turn-right
INTEGER 343
INTEGER 344
INTEGER 345
INTEGER 346
INTEGER 347
INTEGER 348
INTEGER 349
SOAR_ID 350
STRING 351
INTEGER 352
INTEGER 353
SOAR_ID 354
INTEGER 355
SOAR_ID 356
SOAR_ID 357
SOAR_ID 358
SOAR_ID 359
SOAR_ID 360
SOAR_ID 361
SOAR_ID 362
SOAR_ID 363
SOAR_ID 364
ENUMERATION 365 3 ammo-shells ammo-cells ammo-bullets
STRING 366
STRING 367
ENUMERATION 368 3 other-room in-room recorded-in-room
ENUMERATION 369 1 true
INTEGER 370
INTEGER 371
INTEGER 372
ENUMERATION 373 4 weapon health armor ammo
ENUMERATION 374 1 get-item
SOAR_ID 375
ENUMERATION 376 2 go-through-door goto-item
INTEGER 377
ENUMERATION 378 4 attack retreat explore wander
ENUMERATION 379 1 goto-item
SOAR_ID 380
ENUMERATION 381 4 face-item notice-item-missing move-to-item stop-moving
INTEGER 382
INTEGER 383
FLOAT 384
FLOAT 385
ENUMERATION 386 1 true
ENUMERATION 387 1 true
ENUMERATION 388 1 true
ENUMERATION 389 2 left right
ENUMERATION 390 2 right left
415
0 attribute 9
0 debug 248
0 died 90
0 direction-headings 143
0 direction-map 153
0 enemy 38
0 enemy-detected 105
0 heading 110
0 impasse 102
0 io 7
0 item 12
0 map 6
0 maybe-dead-enemy-in-room 79
0 name 58
0 operator 12
0 opposite 154
0 parameters 62
0 self 46
0 side-direction 148
0 strafe-direction 256
0 superstate 0
0 superstate 87
0 top-state 0
1 classname 82
1 current-room 16
1 io 7
1 item 15
1 name 374
1 operator 375
1 place 368
1 superstate 0
1 top-state 0
1 type 373
2 angle-off 385
2 io 7
2 item 15
2 item 93
2 item-angle-backward 387
2 item-angle-off-check 386
2 item-distance-check 388
2 item-heading 384
2 mode 378
2 name 379
2 operator 380
2 superstate 1
2 top-state 0
2 weave-check 390
6 current-room 16
6 explore-room 16
6 explored 14
6 item 15
6 last-room 16
6 last-room 104
6 room 16
6 room-count 18
6 unexplored-room 122
6 unexplored-room 19
7 input-link 20
7 output-link 39
12 actions 39
12 classname 82
12 enemy 38
12 find-item 369
12 item 15
12 name 45
12 place 368
12 priority 371
12 range 370
12 type 373
15 angle-off 73
15 available 120
15 classname 82
15 in-current-room 235
15 origin 66
15 range 268
15 regeneration-time 119
15 room 16
15 sensor 52
15 type 232
16 at-door 22
16 detected-type 189
16 door 22
16 explored 23
16 forward-backward-sum 188
16 hiding-place 315
16 item 93
16 last-room-updated 31
16 left-right-sum 187
16 path 26
16 resurrect 80
16 room-number 27
16 search 325
16 type 28
16 wall 29
20 agent 54
20 entity 49
20 feedback 48
20 game 286
20 map 76
22 direction 319
22 wall 29
22 x 250
22 y 251
26 destination-room 16
26 distance 372
26 in-room-door 22
29 side 123
29 x 124
29 x-max 245
29 x-min 243
29 y 125
29 y-max 246
29 y-min 244
34 attack-type 241
34 blocked 242
34 current-room 16
34 enemy 51
34 enemy-angle-off-achieved 240
34 enemy-facing 237
34 enemy-room 16
34 enemy-room 247
34 io 7
34 name 238
34 operator 253
34 retreat 249
34 top-state 0
35 current-room 16
35 io 7
35 name 239
35 operator 313
35 top-state 0
35 weapon-in-room 15
35 weapon-not-in-room 15
36 corner-heading 328
36 corner-range 329
36 current-room 16
36 io 7
36 name 327
36 operator 330
36 top-state 0
37 current-room 16
37 io 7
37 item 15
37 name 340
37 operator 341
37 right-heading-difference 343
37 superstate 35
37 top-state 0
38 forget-time 60
38 old-angle-off 265
38 old-range 69
38 old-yaw 163
38 sensed-enemy 51
38 x 70
38 y 162
39 attack 42
39 centerview 40
39 climb 57
39 faceabs 266
39 facetarget 43
39 invdrop 367
39 jump 308
39 leadtarget 44
39 selecttarget 51
39 sidestep 88
39 speed 41
39 thrust 89
39 turn 307
39 use 309
46 difficulty 190
46 get-object 233
46 need 202
46 need 206
46 retreat 47
46 stopped 191
46 stuck 192
46 want 203
46 want 207
47 time 56
48 attack 50
48 climb 271
48 facetarget 258
48 leadtarget 311
48 look 291
48 selecttarget 51
48 sidestep 261
48 speed 292
48 thrust 193
48 turn 290
49 enemy 51
49 item 15
49 projectile 269
51 angle-off 73
51 angle-yaw 65
51 aspect 84
51 classname 294
51 deadflag 61
51 health 299
51 model 300
51 name 293
51 origin 66
51 range 64
51 sensor 52
51 skin 295
51 team 298
51 velocity 301
51 weapon 82
52 infront 252
52 visible 53
54 air-finished 284
54 angle 107
54 armor-amount 201
54 armor-type 281
54 cycle 55
54 deadflag 61
54 health 280
54 health 200
54 item 15
54 item-selected 15
54 lightlevel 283
54 model 279
54 name 277
54 origin 66
54 random-number 262
54 skin 278
54 team 282
54 velocity 194
54 waterlevel 285
54 weapon 81
54 weapon-selected 81
62 armor 96
62 armor-need 136
62 armor-want 137
62 attack-distances 209
62 attack-get-item-range 138
62 close-weapon-range 142
62 detect-stuck-time 141
62 door-bounding-box 133
62 door-value 126
62 drift 131
62 enemy-remember-time 140
62 health 114
62 health-need 134
62 health-want 135
62 item-regeneration-time 139
62 room-min 130
62 room-min-2 132
62 wall-align-axis-close 128
62 wall-close 127
62 wall-end 129
62 weapon 208
66 x 67
66 y 68
66 z 276
73 h 74
73 v 164
76 backward 77
76 down 77
76 forward 77
76 left 77
76 leftlos 197
76 right 77
76 rightlos 197
76 up 77
77 blocked 78
77 classname 288
77 distance 186
77 ground 289
80 x 91
80 y 92
81 ammo-count 204
81 ammo-type 365
81 classname 82
81 name 231
84 h 85
84 v 86
93 available 121
93 classname 94
93 regeneration-time 336
93 type 95
93 x 382
93 y 383
96 better 97
96 classname 97
96 increase 98
96 max 99
96 name 97
106 within-90 109
107 pitch 272
107 roll 274
107 yaw 273
110 within-45 165
110 within-5 165
110 within-90 165
114 classname 166
114 increase 167
114 max 169
114 name 166
143 east 172
143 north 170
143 south 171
143 west 173
148 backward 176
148 forward 175
148 left 178
148 right 177
153 east 179
153 north 179
153 south 179
153 west 179
154 backward 182
154 forward 181
154 left 184
154 right 183
179 angle 185
179 backward 180
179 forward 180
179 left 180
179 right 180
194 x 195
194 y 196
194 z 275
197 blocked 199
197 distance 198
208 ammo-need 218
208 ammo-type 215
208 ammo-want 219
208 better 217
208 charge 229
208 circle-strafe 227
208 classname 217
208 damage 230
208 minimum-ammo 220
208 name 216
208 projectile-speed 221
208 quality 228
208 range 222
208 second-damage 226
208 shot-damage 225
208 splash 224
208 spray 223
209 long 210
209 medium 210
209 medium-long 210
209 short 210
209 short-medium 210
209 short-medium-long 210
210 max 213
210 mid 212
210 min 211
233 classname 82
233 map-item 15
233 need 234
233 type 232
233 want 236
253 actions 39
253 direction 259
253 item 15
253 mode 267
253 name 254
253 type 310
256 direction 257
256 expire-time 260
269 classname 305
269 range 306
269 sensor 52
269 will-hit 270
286 mapname 287
301 x 303
301 y 304
301 z 302
313 actions 39
313 classname 82
313 door 22
313 find-item 322
313 item 15
313 mode 323
313 name 314
313 place 324
313 priority 320
313 type 321
315 final-facing 318
315 x 316
315 y 317
325 armor 338
325 health 337
325 hide-time 326
325 left-heading 346
325 original-heading 347
325 recorded 350
325 right-heading 345
325 saved-health-time 339
325 turned-left 333
325 turned-right 332
325 x 348
325 y 349
330 actions 39
330 name 331
334 classname 335
341 actions 39
341 left-heading-difference 344
341 name 342
350 classname 351
350 regeneration-time 352
350 x 353
350 y 355
375 actions 39
375 distance 377
375 door 22
375 item 93
375 mode 378
375 name 376
380 actions 39
380 item 93
380 name 381

