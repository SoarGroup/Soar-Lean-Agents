638
SOAR_ID 0
SOAR_ID 1
SOAR_ID 2
SOAR_ID 3
SOAR_ID 4
SOAR_ID 5
SOAR_ID 6
ENUMERATION 7 2 operator state
SOAR_ID 8
ENUMERATION 9 1 true
SOAR_ID 10
SOAR_ID 11
INTEGER_RANGE 12 -2147483648 2147483647
SOAR_ID 13
SOAR_ID 14
SOAR_ID 15
ENUMERATION 16 1 true
SOAR_ID 17
INTEGER_RANGE 18 -2147483648 2147483647
ENUMERATION 19 4 forward-hall hall room side-hall
SOAR_ID 20
SOAR_ID 21
SOAR_ID 22
SOAR_ID 23
SOAR_ID 24
SOAR_ID 25
ENUMERATION 26 2 off on
ENUMERATION 27 2 off on
ENUMERATION 28 2 off on
ENUMERATION 29 2 off on
ENUMERATION 30 2 off on
ENUMERATION 31 38 ambush attack chase collect-powerups deny-powerups die drop-item enter-room explore face-attack get-item go-through-door hunt initialize-bot notice-item notice-item-missing notice-item-present predict-enemy record-enemy record-explore-item record-sound record-stuck record-temp-item remove-enemy remove-sound remove-stuck retreat search-room select-enemy select-weapon sidestep spawn start-moving update-armor update-health use-item wait wander
SOAR_ID 32
SOAR_ID 33
SOAR_ID 34
SOAR_ID 35
ENUMERATION 36 2 off on
SOAR_ID 37
SOAR_ID 38
ENUMERATION 39 2 false true
SOAR_ID 40
INTEGER_RANGE 41 -2147483648 2147483647
INTEGER_RANGE 42 -2147483648 2147483647
ENUMERATION 43 3 down off up
ENUMERATION 44 2 predict-enemy quake
INTEGER_RANGE 45 -2147483648 2147483647
ENUMERATION 46 3 alive dead dying
SOAR_ID 47
INTEGER_RANGE 48 -2147483648 2147483647
INTEGER_RANGE 49 -2147483648 2147483647
SOAR_ID 50
INTEGER_RANGE 51 -2147483648 2147483647
INTEGER_RANGE 52 -2147483648 2147483647
INTEGER_RANGE 53 -2147483648 2147483647
INTEGER_RANGE 54 -2147483648 2147483647
SOAR_ID 55
INTEGER_RANGE 56 -2147483648 2147483647
SOAR_ID 57
SOAR_ID 58
ENUMERATION 59 2 false true
SOAR_ID 60
SOAR_ID 61
ENUMERATION 62 28 ammo_bullets ammo_cells ammo_grenades ammo_rockets ammo_shells ammo_slugs item_adrenaline item_armor_body item_armor_combat item_armor_jacket item_armor_shard item_health item_health_large item_health_medium item_health_mega item_health_small item_quad none weapon_bfg weapon_blaster weapon_chaingun weapon_grenadelauncher weapon_hyperblaster weapon_machinegun weapon_railgun weapon_rocketlauncher weapon_shotgun weapon_supershotgun
SOAR_ID 63
INTEGER_RANGE 64 -2147483648 2147483647
INTEGER_RANGE 65 -2147483648 2147483647
ENUMERATION 66 1 nil
ENUMERATION 67 3 left off right
ENUMERATION 68 3 backward forward off
ENUMERATION 69 2 false true
INTEGER_RANGE 70 -2147483648 2147483647
INTEGER_RANGE 71 -2147483648 2147483647
SOAR_ID 72
ENUMERATION 73 26 ammo_bullets ammo_cells ammo_grenades ammo_rockets ammo_shells ammo_slugs item_adrenaline item_armor_body item_armor_combat item_armor_jacket item_armor_shard item_health item_health_large item_health_medium item_health_mega item_health_small item_quad weapon_bfg weapon_chaingun weapon_grenadelauncher weapon_hyperblaster weapon_machinegun weapon_railgun weapon_rocketlauncher weapon_shotgun weapon_supershotgun
ENUMERATION 74 4 ammo armor health weapon
SOAR_ID 75
ENUMERATION 76 4 item_armor_body item_armor_combat item_armor_jacket item_armor_shard
INTEGER_RANGE 77 -2147483648 2147483647
INTEGER_RANGE 78 -2147483648 2147483647
ENUMERATION 79 2 no-change tie
ENUMERATION 80 1 none
SOAR_ID 81
SOAR_ID 82
SOAR_ID 83
INTEGER_RANGE 84 -2147483648 2147483647
ENUMERATION 85 1 true
ENUMERATION 86 1 true
ENUMERATION 87 1 none
ENUMERATION 88 4 east north south west
INTEGER_RANGE 89 -2147483648 2147483647
INTEGER_RANGE 90 -2147483648 2147483647
INTEGER_RANGE 91 -2147483648 2147483647
INTEGER_RANGE 92 -2147483648 2147483647
INTEGER_RANGE 93 -2147483648 2147483647
INTEGER_RANGE 94 -2147483648 2147483647
INTEGER_RANGE 95 -2147483648 2147483647
INTEGER_RANGE 96 -2147483648 2147483647
INTEGER_RANGE 97 -2147483648 2147483647
INTEGER_RANGE 98 -2147483648 2147483647
INTEGER_RANGE 99 -2147483648 2147483647
INTEGER_RANGE 100 -2147483648 2147483647
INTEGER_RANGE 101 -2147483648 2147483647
INTEGER_RANGE 102 -2147483648 2147483647
INTEGER_RANGE 103 -2147483648 2147483647
INTEGER_RANGE 104 -2147483648 2147483647
INTEGER_RANGE 105 -2147483648 2147483647
INTEGER_RANGE 106 -2147483648 2147483647
INTEGER_RANGE 107 -2147483648 2147483647
SOAR_ID 108
SOAR_ID 109
SOAR_ID 110
SOAR_ID 111
INTEGER_RANGE 112 -2147483648 2147483647
INTEGER_RANGE 113 -2147483648 2147483647
INTEGER_RANGE 114 -2147483648 2147483647
ENUMERATION 115 4 east north south west
ENUMERATION 116 6 item_adrenaline item_health item_health_large item_health_medium item_health_mega item_health_small
INTEGER_RANGE 117 -2147483648 2147483647
INTEGER_RANGE 118 -2147483648 2147483647
INTEGER_RANGE 119 -2147483648 2147483647
INTEGER_RANGE 120 -2147483648 2147483647
INTEGER_RANGE 121 -2147483648 2147483647
INTEGER_RANGE 122 -2147483648 2147483647
ENUMERATION 123 2 left right
ENUMERATION 124 2 left right
ENUMERATION 125 2 backward forward
ENUMERATION 126 2 backward forward
SOAR_ID 127
ENUMERATION 128 4 east north south west
ENUMERATION 129 1 backward
ENUMERATION 130 1 forward
ENUMERATION 131 1 left
ENUMERATION 132 1 right
INTEGER_RANGE 133 -2147483648 2147483647
INTEGER_RANGE 134 -2147483648 2147483647
INTEGER_RANGE 135 -2147483648 2147483647
INTEGER_RANGE 136 -2147483648 2147483647
ENUMERATION 137 2 hall room
ENUMERATION 138 1 true
ENUMERATION 139 2 left right
ENUMERATION 140 3 backward forward off
SOAR_ID 141
INTEGER_RANGE 142 -2147483648 2147483647
INTEGER_RANGE 143 -2147483648 2147483647
SOAR_ID 144
INTEGER_RANGE 145 -2147483648 2147483647
ENUMERATION 146 2 false true
INTEGER_RANGE 147 -2147483648 2147483647
ENUMERATION 148 2 armor health
ENUMERATION 149 2 armor health
INTEGER_RANGE 150 -2147483648 2147483647
SOAR_ID 151
SOAR_ID 152
SOAR_ID 153
SOAR_ID 154
SOAR_ID 155
INTEGER_RANGE 156 -2147483648 2147483647
INTEGER_RANGE 157 -2147483648 2147483647
INTEGER_RANGE 158 -2147483648 2147483647
ENUMERATION 159 7 ammo_bullets ammo_cells ammo_grenades ammo_rockets ammo_shells ammo_slugs none
STRING 160
ENUMERATION 161 11 ammo_grenades weapon_bfg weapon_blaster weapon_chaingun weapon_grenadelauncher weapon_hyperblaster weapon_machinegun weapon_railgun weapon_rocketlauncher weapon_shotgun weapon_supershotgun
INTEGER_RANGE 162 -2147483648 2147483647
INTEGER_RANGE 163 -2147483648 2147483647
INTEGER_RANGE 164 -2147483648 2147483647
ENUMERATION 165 3 fast medium slow
ENUMERATION 166 6 long medium medium-long short short-medium short-medium-long
ENUMERATION 167 3 large medium small
ENUMERATION 168 2 no true
INTEGER_RANGE 169 -2147483648 2147483647
INTEGER_RANGE 170 -2147483648 2147483647
INTEGER_RANGE 171 -2147483648 2147483647
INTEGER_RANGE 172 -2147483648 2147483647
INTEGER_RANGE 173 -2147483648 2147483647
ENUMERATION 174 1 large
STRING 175
ENUMERATION 176 5 ammo armor health quad weapon
SOAR_ID 177
ENUMERATION 178 1 true
ENUMERATION 179 2 false true
ENUMERATION 180 1 true
ENUMERATION 181 1 true
ENUMERATION 182 1 attack
ENUMERATION 183 1 wander
ENUMERATION 184 1 true
ENUMERATION 185 2 circle-strafe direct-attack
ENUMERATION 186 4 backward forward left right
INTEGER_RANGE 187 -2147483648 2147483647
INTEGER_RANGE 188 -2147483648 2147483647
INTEGER_RANGE 189 -2147483648 2147483647
INTEGER_RANGE 190 -2147483648 2147483647
ENUMERATION 191 1 different
ENUMERATION 192 2 false true
INTEGER_RANGE 193 -2147483648 2147483647
INTEGER_RANGE 194 -2147483648 2147483647
ENUMERATION 195 2 false true
SOAR_ID 196
ENUMERATION 197 16 approach-enemy charge-enemy circle-strafe clean-up-enemy create-retreat direct-attack face-enemy follow-enemy get-item goto-next-room jump record-enemy-weapon select-attack-type select-target set-current-room shoot
SOAR_ID 198
ENUMERATION 199 2 left right
ENUMERATION 200 2 off on
ENUMERATION 201 2 left right
INTEGER_RANGE 202 -2147483648 2147483647
ENUMERATION 203 3 left off right
INTEGER_RANGE 204 -2147483648 2147483647
INTEGER_RANGE 205 -2147483648 2147483647
INTEGER_RANGE 206 -2147483648 2147483647
ENUMERATION 207 4 attack explore retreat wander
INTEGER_RANGE 208 -2147483648 2147483647
SOAR_ID 209
ENUMERATION 210 2 false true
ENUMERATION 211 3 down off up
FLOAT_RANGE 212 -Infinity Infinity
FLOAT_RANGE 213 -Infinity Infinity
FLOAT_RANGE 214 -Infinity Infinity
FLOAT_RANGE 215 -Infinity Infinity
INTEGER_RANGE 216 -2147483648 2147483647
STRING 217
STRING 218
STRING 219
INTEGER_RANGE 220 -2147483648 2147483647
STRING 221
STRING 222
INTEGER_RANGE 223 -2147483648 2147483647
INTEGER_RANGE 224 -2147483648 2147483647
INTEGER_RANGE 225 -2147483648 2147483647
SOAR_ID 226
STRING 227
STRING 228
STRING 229
ENUMERATION 230 3 left off right
ENUMERATION 231 3 down off up
ENUMERATION 232 2 off on
STRING 233
STRING 234
STRING 235
STRING 236
INTEGER_RANGE 237 -2147483648 2147483647
STRING 238
SOAR_ID 239
INTEGER_RANGE 240 -2147483648 2147483647
INTEGER_RANGE 241 -2147483648 2147483647
INTEGER_RANGE 242 -2147483648 2147483647
STRING 243
INTEGER_RANGE 244 -2147483648 2147483647
ENUMERATION 245 3 left off right
STRING 246
ENUMERATION 247 3 circle-strafe direct-attack pop-out
ENUMERATION 248 2 off on
SOAR_ID 249
ENUMERATION 250 2 get-item goto-next-room
SOAR_ID 251
INTEGER_RANGE 252 -2147483648 2147483647
INTEGER_RANGE 253 -2147483648 2147483647
INTEGER_RANGE 254 -2147483648 2147483647
ENUMERATION 255 4 east north south west
INTEGER_RANGE 256 -2147483648 2147483647
ENUMERATION 257 4 ammo armor health weapon
ENUMERATION 258 1 true
ENUMERATION 259 1 collect-powerups
ENUMERATION 260 2 in-room recorded-in-room
SOAR_ID 261
INTEGER_RANGE 262 -2147483648 2147483647
ENUMERATION 263 1 hide-in-corner
INTEGER_RANGE 264 -2147483648 2147483647
INTEGER_RANGE 265 -2147483648 2147483647
SOAR_ID 266
ENUMERATION 267 2 face-out move-to-corner
INTEGER_RANGE 268 -2147483648 2147483647
SOAR_ID 269
STRING 270
INTEGER_RANGE 271 -2147483648 2147483647
INTEGER_RANGE 272 -2147483648 2147483647
INTEGER_RANGE 273 -2147483648 2147483647
SOAR_ID 274
SOAR_ID 275
SOAR_ID 276
SOAR_ID 277
SOAR_ID 278
SOAR_ID 279
SOAR_ID 280
SOAR_ID 281
ENUMERATION 282 3 ammo-bullets ammo-cells ammo-shells
STRING 283
ENUMERATION 284 3 in-room other-room recorded-in-room
ENUMERATION 285 1 true
INTEGER_RANGE 286 -2147483648 2147483647
INTEGER_RANGE 287 -2147483648 2147483647
INTEGER_RANGE 288 -2147483648 2147483647
ENUMERATION 289 10 ammo armor enemy-died enemy-disappeared enemy-room health hide prediction state weapon
ENUMERATION 290 1 get-item
SOAR_ID 291
ENUMERATION 292 2 goto-item goto-next-room
INTEGER_RANGE 293 -2147483648 2147483647
ENUMERATION 294 4 attack explore retreat wander
ENUMERATION 295 1 goto-item
SOAR_ID 296
ENUMERATION 297 5 face-item move-to-item notice-item-missing select-target stop-moving
INTEGER_RANGE 298 -2147483648 2147483647
INTEGER_RANGE 299 -2147483648 2147483647
FLOAT_RANGE 300 -Infinity Infinity
FLOAT_RANGE 301 -Infinity Infinity
ENUMERATION 302 1 true
ENUMERATION 303 1 true
ENUMERATION 304 1 true
ENUMERATION 305 2 left right
SOAR_ID 306
ENUMERATION 307 3 exit-explore-room exit-room goto-door
ENUMERATION 308 1 goto-next-room
ENUMERATION 309 1 goto-door
SOAR_ID 310
ENUMERATION 311 7 align-with-door face-door move-to-door record-at-door sidestep-to-door stop-move-to-door stop-sidestep-to-door
FLOAT_RANGE 312 -Infinity Infinity
FLOAT_RANGE 313 -Infinity Infinity
ENUMERATION 314 1 true
FLOAT_RANGE 315 -Infinity Infinity
FLOAT_RANGE 316 -Infinity Infinity
FLOAT_RANGE 317 -Infinity Infinity
ENUMERATION 318 1 true
FLOAT_RANGE 319 -Infinity Infinity
FLOAT_RANGE 320 -Infinity Infinity
ENUMERATION 321 1 true
FLOAT_RANGE 322 -Infinity Infinity
FLOAT_RANGE 323 -Infinity Infinity
FLOAT_RANGE 324 -Infinity Infinity
FLOAT_RANGE 325 -Infinity Infinity
ENUMERATION 326 1 true
ENUMERATION 327 1 true
SOAR_ID 328
ENUMERATION 329 1 true
FLOAT_RANGE 330 -Infinity Infinity
ENUMERATION 331 2 multiple none
ENUMERATION 332 1 elaboration
SOAR_ID 333
INTEGER_RANGE 334 -2147483648 2147483647
INTEGER_RANGE 335 -2147483648 2147483647
INTEGER_RANGE 336 -2147483648 2147483647
STRING 337
STRING 338
ENUMERATION 339 1 true
ENUMERATION 340 1 explore
SOAR_ID 341
ENUMERATION 342 4 create-explore-room explore-room update-path-data visit-unexplored-room
ENUMERATION 343 1 true
ENUMERATION 344 1 explore-room
SOAR_ID 345
ENUMERATION 346 5 align-with-room classify-room explore-axis finish-room stop-sidestep
ENUMERATION 347 1 true
SOAR_ID 348
ENUMERATION 349 2 east-west north-south
ENUMERATION 350 1 true
ENUMERATION 351 1 explore-axis
SOAR_ID 352
ENUMERATION 353 7 align-with-axis finish-axis follow-hall-axis follow-room-axis init-axis mark-axis retry-axis
ENUMERATION 354 1 true
ENUMERATION 355 1 true
FLOAT_RANGE 356 -Infinity Infinity
ENUMERATION 357 1 true
ENUMERATION 358 1 wall
ENUMERATION 359 1 true
ENUMERATION 360 1 true
ENUMERATION 361 2 left right
INTEGER_RANGE 362 -2147483648 2147483647
INTEGER_RANGE 363 -2147483648 2147483647
INTEGER_RANGE 364 -2147483648 2147483647
INTEGER_RANGE 365 -2147483648 2147483647
ENUMERATION 366 4 east north south west
SOAR_ID 367
INTEGER_RANGE 368 -2147483648 2147483647
ENUMERATION 369 1 true
ENUMERATION 370 1 true
ENUMERATION 371 1 align-with-axis
SOAR_ID 372
INTEGER_RANGE 373 -2147483648 2147483647
INTEGER_RANGE 374 -2147483648 2147483647
ENUMERATION 375 2 close-to-wall heading
ENUMERATION 376 1 true
ENUMERATION 377 5 backup face-heading finished-align forward stop
ENUMERATION 378 1 follow-hall-axis
SOAR_ID 379
ENUMERATION 380 4 finish-hall forward-to-door process-door update-door
ENUMERATION 381 3 forward left right
INTEGER_RANGE 382 -2147483648 2147483647
ENUMERATION 383 3 forward left right
ENUMERATION 384 3 forward left right
ENUMERATION 385 1 true
INTEGER_RANGE 386 -2147483648 2147483647
INTEGER_RANGE 387 -2147483648 2147483647
INTEGER_RANGE 388 -2147483648 2147483647
INTEGER_RANGE 389 -2147483648 2147483647
ENUMERATION 390 1 true
ENUMERATION 391 2 follow-hall-axis follow-room-axis
SOAR_ID 392
ENUMERATION 393 7 back-out-next-room backed-out finish-hall finished-follow forward-past-door forward-to-door process-door
INTEGER_RANGE 394 -2147483648 2147483647
INTEGER_RANGE 395 -2147483648 2147483647
ENUMERATION 396 1 update-path-data
SOAR_ID 397
ENUMERATION 398 6 finish-update increment-distance init-update update-doors update-room update-tested
INTEGER_RANGE 399 -2147483648 2147483647
SOAR_ID 400
ENUMERATION 401 1 visit-unexplored-room
ENUMERATION 402 3 detect-all-explored get-item goto-next-room
ENUMERATION 403 1 true
FLOAT_RANGE 404 -Infinity Infinity
FLOAT_RANGE 405 -Infinity Infinity
SOAR_ID 406
ENUMERATION 407 1 voice
FLOAT_RANGE 408 -Infinity Infinity
FLOAT_RANGE 409 -Infinity Infinity
FLOAT_RANGE 410 -Infinity Infinity
ENUMERATION 411 9 blaster_fire chaingun_fire hyperblaster_fire machinegun_fire player_run railgun_fire rocket_fire shotgun_fire supershotgun_fire
ENUMERATION 412 1 true
ENUMERATION 413 1 true
SOAR_ID 414
SOAR_ID 415
ENUMERATION 416 2 goto-next-room turn
ENUMERATION 417 1 chase
INTEGER_RANGE 418 -2147483648 2147483647
ENUMERATION 419 1 true
ENUMERATION 420 4 east north south west
ENUMERATION 421 1 chase
INTEGER_RANGE 422 -2147483648 2147483647
INTEGER_RANGE 423 -2147483648 2147483647
SOAR_ID 424
ENUMERATION 425 1 retreat
SOAR_ID 426
ENUMERATION 427 3 goto-item goto-next-room record-visited-room
INTEGER_RANGE 428 -2147483648 2147483647
INTEGER_RANGE 429 -2147483648 2147483647
SOAR_ID 430
INTEGER_RANGE 431 -2147483648 2147483647
ENUMERATION 432 2 false true
ENUMERATION 433 2 false true
SOAR_ID 434
SOAR_ID 435
INTEGER_RANGE 436 -2147483648 2147483647
INTEGER_RANGE 437 -2147483648 2147483647
INTEGER_RANGE 438 -2147483648 2147483647
STRING 439
INTEGER_RANGE 440 -2147483648 2147483647
SOAR_ID 441
INTEGER_RANGE 442 -2147483648 2147483647
INTEGER_RANGE 443 -2147483648 2147483647
INTEGER_RANGE 444 -2147483648 2147483647
SOAR_ID 445
ENUMERATION 446 2 predict-enemy quake
SOAR_ID 447
ENUMERATION 448 1 create-enemy-state
INTEGER_RANGE 449 -2147483648 2147483647
SOAR_ID 450
ENUMERATION 451 3 forget-dead-enemy goto-next-room turn-to-enemy
INTEGER_RANGE 452 -2147483648 2147483647
INTEGER_RANGE 453 -2147483648 2147483647
STRING 454
SOAR_ID 455
STRING 456
ENUMERATION 457 1 true
ENUMERATION 458 1 true
ENUMERATION 459 2 false true
INTEGER_RANGE 460 -2147483648 2147483647
INTEGER_RANGE 461 -2147483648 2147483647
INTEGER_RANGE 462 -2147483648 2147483647
ENUMERATION 463 1 change-rooms
ENUMERATION 464 1 true
SOAR_ID 465
ENUMERATION 466 2 collect-powerups wander
SOAR_ID 467
SOAR_ID 468
SOAR_ID 469
ENUMERATION 470 1 wander
SOAR_ID 471
ENUMERATION 472 3 enemy-room hide prediction
ENUMERATION 473 1 ambush
SOAR_ID 474
ENUMERATION 475 2 hide-by-door hide-in-corner
INTEGER_RANGE 476 -2147483648 2147483647
ENUMERATION 477 1 hunt
ENUMERATION 478 1 hunt
ENUMERATION 479 1 get-item
SOAR_ID 480
ENUMERATION 481 1 deny-powerups
SOAR_ID 482
ENUMERATION 483 2 get-item goto-next-room
ENUMERATION 484 1 deny-powerups
SOAR_ID 485
INTEGER_RANGE 486 -2147483648 2147483647
ENUMERATION 487 1 true
ENUMERATION 488 4 enemy-died enemy-disappeared enemy-room prediction
INTEGER_RANGE 489 -2147483648 2147483647
INTEGER_RANGE 490 -2147483648 2147483647
ENUMERATION 491 1 true
SOAR_ID 492
ENUMERATION 493 1 hide-by-door
SOAR_ID 494
INTEGER_RANGE 495 -2147483648 2147483647
INTEGER_RANGE 496 -2147483648 2147483647
INTEGER_RANGE 497 -2147483648 2147483647
INTEGER_RANGE 498 -2147483648 2147483647
INTEGER_RANGE 499 -2147483648 2147483647
INTEGER_RANGE 500 -2147483648 2147483647
ENUMERATION 501 1 true
ENUMERATION 502 1 true
SOAR_ID 503
ENUMERATION 504 4 face-door move-to-hiding-place pick-hiding-place shoot
INTEGER_RANGE 505 -2147483648 2147483647
INTEGER_RANGE 506 -2147483648 2147483647
INTEGER_RANGE 507 -2147483648 2147483647
ENUMERATION 508 4 east north south west
INTEGER_RANGE 509 -2147483648 2147483647
SOAR_ID 510
SOAR_ID 511
INTEGER_RANGE 512 -2147483648 2147483647
INTEGER_RANGE 513 -2147483648 2147483647
INTEGER_RANGE 514 -2147483648 2147483647
INTEGER_RANGE 515 -2147483648 2147483647
ENUMERATION 516 1 none
INTEGER_RANGE 517 -2147483648 2147483647
ENUMERATION 518 2 left right
ENUMERATION 519 1 retreat
INTEGER_RANGE 520 -2147483648 2147483647
INTEGER_RANGE 521 -2147483648 2147483647
INTEGER_RANGE 522 -2147483648 2147483647
ENUMERATION 523 3 aggressive passive standard
ENUMERATION 524 3 full none standard
ENUMERATION 525 4 bad good medium medium-good
ENUMERATION 526 3 fast medium slow
ENUMERATION 527 1 true
INTEGER_RANGE 528 -2147483648 2147483647
INTEGER_RANGE 529 -2147483648 2147483647
ENUMERATION 530 1 true
INTEGER_RANGE 531 -2147483648 2147483647
INTEGER_RANGE 532 -2147483648 2147483647
INTEGER_RANGE 533 -2147483648 2147483647
ENUMERATION 534 1 true
SOAR_ID 535
STRING 536
INTEGER_RANGE 537 -2147483648 2147483647
INTEGER_RANGE 538 -2147483648 2147483647
INTEGER_RANGE 539 -2147483648 2147483647
INTEGER_RANGE 540 -2147483648 2147483647
INTEGER_RANGE 541 -2147483648 2147483647
SOAR_ID 542
ENUMERATION 543 1 die
SOAR_ID 544
ENUMERATION 545 2 lower-difficulty-level raise-difficulty-level
INTEGER_RANGE 546 -2147483648 2147483647
FLOAT_RANGE 547 -Infinity Infinity
INTEGER_RANGE 548 -2147483648 2147483647
ENUMERATION 549 2 false true
SOAR_ID 550
SOAR_ID 551
ENUMERATION 552 1 none
SOAR_ID 553
STRING 554
STRING 555
ENUMERATION 556 1 true
ENUMERATION 557 1 true
ENUMERATION 558 1 remove-prediction
SOAR_ID 559
INTEGER_RANGE 560 -2147483648 2147483647
INTEGER_RANGE 561 -2147483648 2147483647
INTEGER_RANGE 562 -2147483648 2147483647
ENUMERATION 563 1 true
ENUMERATION 564 1 true
ENUMERATION 565 3 stop turn-left turn-right
SOAR_ID 566
ENUMERATION 567 1 state
ENUMERATION 568 1 search-room
ENUMERATION 569 1 stop
SOAR_ID 570
ENUMERATION 571 1 turn-right
SOAR_ID 572
ENUMERATION 573 1 turn-left
SOAR_ID 574
INTEGER_RANGE 575 -2147483648 2147483647
INTEGER_RANGE 576 -2147483648 2147483647
ENUMERATION 577 1 true
ENUMERATION 578 1 true
INTEGER_RANGE 579 -2147483648 2147483647
INTEGER_RANGE 580 -2147483648 2147483647
INTEGER_RANGE 581 -2147483648 2147483647
INTEGER_RANGE 582 -2147483648 2147483647
ENUMERATION 583 1 remove-at-door
SOAR_ID 584
ENUMERATION 585 4 exit-explore-room exit-hall exit-room goto-door
SOAR_ID 586
SOAR_ID 587
ENUMERATION 588 1 exit-hall
ENUMERATION 589 1 face-door
SOAR_ID 590
ENUMERATION 591 1 goto-door
SOAR_ID 592
INTEGER_RANGE 593 -2147483648 2147483647
ENUMERATION 594 1 true
INTEGER_RANGE 595 -2147483648 2147483647
INTEGER_RANGE 596 -2147483648 2147483647
INTEGER_RANGE 597 -2147483648 2147483647
ENUMERATION 598 1 goto-next-room
SOAR_ID 599
ENUMERATION 600 9 ambush attack collect-powerups deny-powerups die explore hunt retreat wander
ENUMERATION 601 1 chase
ENUMERATION 602 1 attack
ENUMERATION 603 1 ambush
ENUMERATION 604 1 deny-powerups
ENUMERATION 605 1 die
ENUMERATION 606 1 explore
ENUMERATION 607 1 hunt
ENUMERATION 608 1 retreat
ENUMERATION 609 1 wander
ENUMERATION 610 1 choose-best-item
SOAR_ID 611
SOAR_ID 612
SOAR_ID 613
SOAR_ID 614
SOAR_ID 615
SOAR_ID 616
SOAR_ID 617
SOAR_ID 618
SOAR_ID 619
SOAR_ID 620
SOAR_ID 621
SOAR_ID 622
SOAR_ID 623
SOAR_ID 624
SOAR_ID 625
SOAR_ID 626
SOAR_ID 627
SOAR_ID 628
ENUMERATION 629 1 search-room
SOAR_ID 630
ENUMERATION 631 4 east north south west
INTEGER_RANGE 632 -2147483648 2147483647
INTEGER_RANGE 633 -2147483648 2147483647
ENUMERATION 634 1 true
INTEGER_RANGE 635 -2147483648 2147483647
INTEGER_RANGE 636 -2147483648 2147483647
INTEGER_RANGE 637 -2147483648 2147483647
953
0 attribute 7
0 choices 331
0 current-room 11
0 debug 192
0 died 69
0 direction-headings 108
0 direction-map 110
0 enemy 24
0 enemy-data 535
0 enemy-detected 37
0 enemy-just-died 487
0 goal-type 463
0 heading 82
0 impasse 79
0 io 6
0 item 8
0 map 5
0 mode 600
0 monitor 328
0 monitor 327
0 name 44
0 operator 8
0 opposite 111
0 outside-room 10
0 parameters 47
0 predicting 458
0 self 32
0 side-direction 109
0 sound 435
0 strafe-direction 198
0 superstate 0
0 superstate 66
0 top-state 0
1 classname 62
1 current-room 11
1 io 6
1 item 10
1 name 290
1 operator 291
1 place 284
1 superstate 0
1 top-state 0
1 type 289
2 angle-off 301
2 io 6
2 item 10
2 item 72
2 item-angle-backward 303
2 item-angle-off-check 302
2 item-distance-check 304
2 item-heading 300
2 mode 294
2 name 295
2 operator 296
2 superstate 1
2 top-state 0
2 weave-check 305
3 current-room 11
3 door 15
3 door-aligned 315
3 door-angle 316
3 explore-room 11
3 io 6
3 mode 294
3 name 308
3 operator 586
3 operator 306
3 superstate 0
3 top-state 0
4 current-room 11
4 door 15
4 door-aligned 319
4 door-aligned-check 318
4 door-angle 317
4 door-angle-off 313
4 door-angle-off-check 314
4 door-distance 320
4 door-distance-check 321
4 door-heading 312
4 door-overlap 326
4 io 6
4 mode 294
4 name 309
4 operator 310
4 operator 584
4 superstate 3
4 top-state 0
5 current-room 11
5 deleted-room 11
5 door-count 12
5 enemy-room 11
5 explore-room 11
5 explored 9
5 initialized 530
5 item 72
5 last-room 11
5 last-room 80
5 room 11
5 room-count 12
5 room-number 11
5 saved-room 87
5 saved-room 11
5 unexplored-rooms 13
5 unexplored-rooms 87
6 input-link 14
6 output-link 612
8 actions 25
8 classname 62
8 direction 255
8 door 15
8 enemy 24
8 enemy 37
8 find-item 285
8 item 10
8 mode 294
8 name 31
8 place 284
8 priority 287
8 random 332
8 range 286
8 room 11
8 sound 434
8 time 335
8 type 289
8 weapon 61
8 weapon-parameter 551
10 angle-off 55
10 angle-yaw 423
10 available 85
10 classname 62
10 in-current-room 179
10 origin 50
10 range 208
10 regeneration-time 84
10 room 11
10 sensor 38
10 soar-id 637
10 type 176
11 aligned-room 128
11 at-door 15
11 axis 348
11 current-door 15
11 detected-type 137
11 door 15
11 east-west-search 563
11 east-west-size 560
11 enemy-visit-count 449
11 explored 16
11 forward-backward-sum 136
11 hiding-place 251
11 item 72
11 last-room-updated 21
11 left-right-sum 135
11 no-connecting-room 15
11 north-south-search 564
11 north-south-size 561
11 orientation 349
11 path 17
11 resurrect 60
11 room-number 18
11 search 261
11 type 19
11 update-data 441
11 updated-paths 343
11 wall 20
13 next 13
13 next 87
13 room 11
14 agent 40
14 entity 35
14 feedback 34
14 game 226
14 map 57
14 sound 406
15 connecting-door 15
15 direction 255
15 door-angle-off 596
15 door-heading 595
15 max-x 323
15 max-y 325
15 min-x 322
15 min-y 324
15 mmax-x 388
15 mmax-y 389
15 mmin-x 387
15 mmin-y 386
15 new-room 11
15 new-x 405
15 new-y 404
15 number 517
15 processed 385
15 room 11
15 side 518
15 updated 390
15 wall 20
15 x 193
15 y 194
17 destination-room 11
17 distance 288
17 distance-plus-one 395
17 in-room-door 15
20 connects-to-door 15
20 door 15
20 mapped 359
20 marked 369
20 side 88
20 tentative 403
20 x 89
20 x-max 189
20 x-min 187
20 y 90
20 y-max 190
20 y-min 188
22 attack-type 185
22 blocked 186
22 current-room 11
22 enemy 37
22 enemy-angle-off-achieved 184
22 enemy-facing 181
22 enemy-room 11
22 enemy-room 191
22 goal-type 463
22 io 6
22 mode 602
22 name 182
22 operator 196
22 top-state 0
23 current-room 11
23 goal-type 463
23 io 6
23 mode 609
23 name 183
23 operator 249
23 operator 630
23 top-state 0
24 enemy-facing 556
24 forget-time 45
24 health 422
24 name 456
24 next-room-number 597
24 old-angle-off 205
24 old-aspect-h 452
24 old-cycle 460
24 old-range 53
24 old-room 11
24 old-yaw 113
24 predict-range 557
24 prediction-final-room-number 461
24 prediction-get-item 485
24 prediction-last-door-number 515
24 sensed-enemy 37
24 skin 454
24 team 552
24 team 455
24 weapon 62
24 x 54
24 y 112
24 z 453
25 attack 28
25 centerview 26
25 climb 43
25 face 330
25 faceabs 206
25 facetarget 29
25 invdrop 283
25 jump 246
25 leadtarget 30
25 selecttarget 37
25 sidestep 67
25 speed 27
25 thrust 68
25 turn 245
25 use 62
25 use-weapon 62
32 adjust-skill 549
32 aggressiveness 523
32 aiming-skill 525
32 deaths 540
32 get-object 177
32 get-objects-exist 464
32 jcd 527
32 jump-time 529
32 last-die-time 541
32 need 148
32 need 151
32 parameters 550
32 reaction-time 526
32 reaction-time-delay 548
32 retreat 33
32 saved-armor 510
32 saved-health 511
32 stopped 138
32 stuck 139
32 stuck-time 333
32 tactics 524
32 want 149
32 want 152
33 reason 337
33 time 42
33 visited-room 11
34 attack 36
34 climb 211
34 facetarget 200
34 leadtarget 248
34 look 231
34 selecttarget 635
34 sidestep 203
34 speed 232
34 thrust 140
34 turn 230
35 enemy 37
35 item 10
35 projectile 209
37 angle-off 55
37 angle-yaw 49
37 aspect 63
37 classname 234
37 deadflag 46
37 health 237
37 model 238
37 name 233
37 origin 50
37 range 48
37 sensor 38
37 skin 235
37 soar-id 637
37 team 236
37 velocity 239
37 weapon 62
38 infront 195
38 visible 39
40 air-finished 224
40 angle 81
40 armor-amount 147
40 armor-type 221
40 cycle 41
40 deadflag 46
40 health 220
40 item 10
40 item-selected 10
40 lightlevel 223
40 model 219
40 name 217
40 origin 50
40 random-number 204
40 skin 218
40 team 222
40 velocity 141
40 waterlevel 225
40 weapon 61
40 weapon-selected 62
47 armor 75
47 armor-need 101
47 armor-want 102
47 attack-distances 154
47 attack-get-item-range 103
47 big-room-size 562
47 close-ammo-range 443
47 close-weapon-range 107
47 close-weapon-range-wander 528
47 detect-stuck-time 106
47 door-bounding-box 98
47 door-value 91
47 drift 96
47 enemy-remember-time 105
47 enemy-visit-cutoff 462
47 get-item-close-range 521
47 health 83
47 health-need 99
47 health-want 100
47 hiding-place-close 533
47 item-regeneration-time 104
47 max-hide-time 522
47 max-sound-range 444
47 min-sound-range 520
47 retreat-range 428
47 room-min 95
47 room-min-2 97
47 sound-remember-time 438
47 wall-align-axis-close 93
47 wall-close 92
47 wall-end 94
47 weapon 153
50 x 51
50 y 52
50 z 216
55 h 56
55 v 114
57 backward 58
57 down 58
57 forward 58
57 left 58
57 leftlos 144
57 right 58
57 rightlos 144
57 up 58
58 blocked 59
58 classname 228
58 distance 134
58 ground 229
60 x 70
60 y 71
61 ammo-count 150
61 ammo-type 282
61 classname 62
61 name 175
63 h 64
63 v 65
72 available 86
72 classname 73
72 range 633
72 regeneration-time 268
72 room 11
72 type 74
72 x 298
72 y 299
75 better 76
75 classname 76
75 increase 77
75 max 78
75 name 76
81 pitch 212
81 roll 214
81 yaw 213
82 within-45 115
82 within-5 115
82 within-90 115
83 classname 116
83 increase 117
83 max 118
83 name 116
108 east 121
108 north 119
108 south 120
108 west 122
109 backward 124
109 forward 123
109 left 126
109 right 125
110 east 127
110 north 127
110 south 127
110 west 127
111 backward 130
111 forward 129
111 left 132
111 right 131
127 angle 133
127 backward 128
127 forward 128
127 left 128
127 right 128
141 x 142
141 y 143
141 z 215
144 blocked 146
144 distance 145
153 ammo-need 162
153 ammo-type 159
153 ammo-want 163
153 charge 173
153 circle-strafe 171
153 classname 161
153 damage 174
153 minimum-ammo 164
153 name 160
153 projectile-speed 165
153 quality 172
153 range 166
153 second-damage 170
153 shot-damage 169
153 splash 168
153 spray 167
154 long 155
154 medium 155
154 medium-long 155
154 short 155
154 short-medium 155
154 short-medium-long 155
155 max 158
155 mid 157
155 min 156
177 classname 62
177 map-item 10
177 need 178
177 type 176
177 want 180
196 actions 25
196 direction 201
196 door 15
196 item 10
196 mode 207
196 name 197
196 reason 338
196 type 247
198 direction 199
198 expire-time 202
209 classname 243
209 range 244
209 sensor 38
209 soar-id 637
209 will-hit 210
226 mapname 227
239 x 241
239 y 242
239 z 240
249 actions 25
249 classname 62
249 door 15
249 exit-dead-end 459
249 item 10
249 mode 470
249 name 250
249 place 260
249 priority 256
249 range 632
249 type 257
251 final-facing 254
251 x 252
251 y 253
261 hide-time 262
261 recorded 269
261 searched 565
261 x 531
261 y 532
266 actions 25
266 name 267
269 classname 270
269 regeneration-time 271
269 x 272
269 y 273
274 explore-room 11
274 mode 606
274 name 340
274 operator 341
274 top-state 0
275 explore-room 11
275 io 6
275 name 344
275 operator 345
275 room-explored 347
275 superstate 274
275 top-state 0
276 axis 348
276 east 364
276 explore-room 11
276 io 6
276 name 351
276 north 362
276 operator 352
276 south 363
276 superstate 275
276 top-state 0
276 west 365
277 achieved 375
277 axis 348
277 backed-up 376
277 direction 128
277 explore-room 11
277 heading-difference 374
277 io 6
277 name 371
277 new-heading 373
277 operator 372
277 superstate 276
277 top-state 0
278 axis 348
278 direction 128
278 door 381
278 end-wall 383
278 explore-room 11
278 io 6
278 name 378
278 operator 379
278 superstate 276
278 top-state 0
279 axis 348
279 direction 128
279 door 381
279 end-wall 383
279 expect-door 381
279 explore-room 11
279 io 6
279 name 391
279 operator 392
279 sidestep 413
279 superstate 276
279 top-state 0
280 explore-room 11
280 name 396
280 operator 397
280 room 11
280 superstate 274
280 top-state 0
281 io 6
281 name 401
281 operator 400
281 top-state 0
291 actions 25
291 distance 293
291 door 15
291 item 72
291 mode 294
291 name 292
296 actions 25
296 item 72
296 name 297
306 actions 25
306 door 15
306 mode 294
306 name 307
310 actions 25
310 name 311
328 init 329
328 room 11
328 room-number 11
333 original-time 336
333 stuck-time 334
341 actions 25
341 name 342
341 room 11
345 actions 25
345 axis 348
345 direction 128
345 name 346
348 aligned 128
348 backed-out 634
348 backed-up 354
348 backing-out 370
348 end-of-wall 355
348 followed-to-end 412
348 initialized 357
348 left 367
348 mapped 350
348 marked 358
348 orientation 349
348 retry 360
348 right 367
348 search-directions 128
348 updated 361
348 updated 366
348 wall 20
352 actions 25
352 axis 348
352 direction 128
352 name 353
352 new-heading 356
367 distance 368
367 max-distance 382
367 min-distance 394
372 actions 25
372 axis 25
372 name 377
379 actions 25
379 direction 128
379 door 15
379 name 380
379 side 384
392 actions 25
392 direction 128
392 door 15
392 name 393
392 side 384
397 active-room 11
397 distance 399
397 door 15
397 name 398
397 other-room 11
397 room 11
400 classname 62
400 door 15
400 item 10
400 mode 259
400 name 402
400 place 260
406 sound 434
414 current-room 11
414 goal-type 463
414 heading-achieved 419
414 heading-difference 418
414 io 6
414 mode 601
414 name 417
414 operator 415
414 sound-yaw 440
414 top-state 0
414 wall-direction 420
415 actions 25
415 door 15
415 mode 421
415 name 416
424 current-room 11
424 goal-type 463
424 io 6
424 mode 608
424 name 425
424 operator 426
424 superstate 0
424 top-state 0
426 actions 25
426 distance 429
426 door 15
426 item 10
426 mode 519
426 name 427
430 extended 432
430 number 431
430 tested 433
434 angle-yaw 442
434 channel 407
434 h 408
434 range 410
434 type 411
434 v 409
435 angle-yaw 437
435 faced-in-room 11
435 forget-time 45
435 range 436
435 type 439
441 active-rooms 11
441 current-distance 430
441 updated 15
445 current-room 11
445 direction-headings 108
445 direction-map 110
445 fake-top-state 445
445 first-room 594
445 heading 82
445 io 6
445 item 8
445 last-door 516
445 last-door 15
445 map 5
445 name 446
445 next-room 11
445 operator 599
445 operator 447
445 operator 8
445 operator 291
445 operator 474
445 operator 559
445 opposite 111
445 predicted-distance 514
445 predicting 457
445 real-top-state 0
445 self 32
445 side-direction 109
445 superstate 0
445 superstate 445
445 top-state 445
447 actions 25
447 door 15
447 item 10
447 name 448
450 actions 25
450 door 15
450 mode 478
450 name 451
465 best-item 10
465 current-room 11
465 goal-type 463
465 io 6
465 name 466
465 operator 467
465 operator 611
465 top-state 0
465 weapon-in-room 10
465 weapon-not-in-room 10
467 actions 25
467 classname 62
467 door 15
467 exit-dead-end 459
467 find-item 258
467 item 10
467 item 339
467 map-item 10
467 mode 259
467 name 479
467 place 260
467 priority 256
467 room 11
467 type 257
468 ambush-type 472
468 corner-heading 264
468 corner-range 265
468 current-room 11
468 io 6
468 mode 603
468 name 473
468 operator 474
468 operator 559
468 superstate 0
468 top-state 0
469 current-room 11
469 hunt-type 488
469 io 6
469 mode 607
469 name 477
469 operator 450
469 resurrect-heading 489
469 resurrect-heading-achieved 491
469 resurrect-heading-difference 490
469 room 11
469 superstate 0
469 top-state 0
471 achieved-final-facing 476
471 corner-heading 264
471 corner-range 265
471 current-room 11
471 io 6
471 name 263
471 operator 266
471 top-state 0
474 name 475
480 current-room 11
480 mode 604
480 name 481
480 operator 482
480 superstate 0
480 top-state 0
482 actions 25
482 door 15
482 mode 484
482 name 483
485 classname 62
485 room-number 486
492 current-room 11
492 entry-door 15
492 hiding-place 494
492 inroom-door 15
492 io 6
492 name 493
492 operator 503
492 top-state 0
494 final-facing 495
494 final-facing-achieved 502
494 final-facing-difference 509
494 heading 499
494 heading-achieved 501
494 heading-difference 500
494 range 498
494 range-close 534
494 x 496
494 y 497
503 actions 25
503 direction 508
503 name 504
503 range 507
503 x 505
503 y 506
510 cycle 513
510 value 512
511 cycle 513
511 value 512
535 deaths 537
535 last-dead-time 538
535 last-see-time 539
535 last-weapon 62
535 name 536
535 parameters 550
535 possible-better 553
542 death-quotient 547
542 death-sum 546
542 io 6
542 mode 605
542 name 543
542 operator 544
542 top-state 0
544 name 545
550 weapons 551
551 better 161
551 classname 161
553 new 554
553 old 555
559 name 558
566 current-room 11
566 direction 255
566 io 6
566 left-side-size 582
566 name 568
566 operator 570
566 operator 572
566 operator 574
566 right-side-size 581
566 superstate 0
566 top-state 0
566 turn-left-achieved 577
566 turn-left-angle 575
566 turn-left-difference 579
566 turn-right-achieved 578
566 turn-right-angle 576
566 turn-right-difference 580
566 type 567
570 actions 25
570 name 569
572 actions 25
572 name 571
574 actions 25
574 name 573
584 name 583
586 name 585
587 current-room 11
587 door 15
587 door-angle-off 313
587 door-angle-off-check 314
587 door-heading 593
587 io 6
587 name 588
587 operator 590
587 operator 592
587 superstate 3
587 top-state 0
590 actions 25
590 name 589
592 actions 25
592 name 591
599 door 15
599 name 598
611 name 610
612 attack 613
612 centerview 614
612 climb 615
612 face 616
612 faceabs 617
612 facetarget 618
612 invdrop 619
612 jump 620
612 leadtarget 621
612 selecttarget 622
612 sidestep 623
612 speed 624
612 thrust 625
612 turn 626
612 use 627
612 use-weapon 628
613 value 28
614 value 26
615 value 43
616 value 330
617 value 206
618 value 29
619 value 283
620 value 246
621 value 30
622 value 636
623 value 67
624 value 27
625 value 68
626 value 245
627 value 62
628 value 62
630 direction 631
630 name 629
