###
###  map.tcl 
###
###  this file creates a map for an agent to add lines and letters.
###  the viewable area is 500 x 500 pixels.  scrollbars allow users
###  to scan the entire map area if it is larger than 500x500.
###
###  init-map xmin xmax ymin ymax [f]:  creates the map, draws x-and y-axes
###                                 and draws agent's fov
###                                 initialized to 90 deg angle 
###                                 located at 0,0 facing 0 deg
###                                 optional f is scale factor
###
###  draw-letter  letter x y color: add "letter" to map at x,y in color
###
###  draw-line  x1 y1 x2 y2 [color]: draw black line from x1,y1 to x2,y2
###
###  fov-angle [angle]            : if no arg, returns current fov in deg
###                                 if arg given, sets fov to angle
###
###  fov-radius [length]          : if no arg, returns current range of fov
###                                 if length given, sets fov range to length
###
###  fov-dir [dir]                : if no arg, returns current orientation
###                                 if dir given, repoints fov to dir
###
###  fov-move [deltaX deltaY deltaAngle] : if no args, returns [x, y, dir]
###                                 if args given, moves fov by amount 
###                                    specified.  eg:
###                                 fov-move 20 30 -45
###                                    moves + 20 in X, +30 in Y, and turns
###                                    45 deg to right (clockwise).
###
###  fov-pos [X Y Angle]           : if no args, returns [x, y, dir]
###                                 if args given, moves fov to new x,y,angle
###
###  all move commands are echoed to the top of the map screen
###
###  7/9/99  added trail_params and changed draw-letter so that agent's
###          trail is fixed length, unique char and specific color.  
###		 ditto for enemy.
###  10/99   changed orientation of agent coordinate system
###

proc init-map {xmin xmax ymin ymax args} {
	 # creates the map with scrollbars, and the
	 # default fov at coords 0,0; angle is 90 deg, pointed at 0 deg
	 global c w colors activeMap Xoffset Yoffset fov scalef
	 if {[llength $args] >= 1} {
		  set scalef [lindex $args 0]
	 } else {
		  set scalef 1
	 }
	 set Xmin [expr $xmin / $scalef]
	 set Ymin [expr $ymin / $scalef]
	 set Xmax [expr $xmax / $scalef]
	 set Ymax [expr $ymax / $scalef]
	 set Xoffset [expr 0 - $Xmin]
	 set Yoffset $Ymax
	 set w .map
	 catch {destroy $w}
	 toplevel $w
	 wm title $w "Agent Map"
	 wm iconname $w "AgentMap"
	 wm geometry $w +20+20
	 wm minsize $w 100 100

	 label $w.msg -wraplength 8i -justify left -text "drawing commands will be printed in this area as they are issued."
	 pack $w.msg -side top

	 # agent coord system is   ^         canvas coord sys is  -----> +x
	 #                         |+y                            |
	 #                   -x    |    +x                        |
	 #                   <----------->                        |+y
	 #                         |
	 #                         |-y
	 #                    

	 set xsize [expr ($xmax - $xmin)/$scalef]
	 set ysize [expr ($ymax - $ymin)/$scalef]

	 set f [frame $w.frame]
	 pack $f -side top -fill both -expand yes
	 set h [scrollbar $f.hscroll -highlightthickness 0 -orient horizontal]
	 set v [scrollbar $f.vscroll -highlightthickness 0 -orient vertical]
	 set f1 [frame $f.f1 -bd 2 -relief sunken]
	 set c [canvas $f1.c -width 500 -height 500 -borderwidth 0 \
				-highlightthickness 0 -xscrollcommand "$h set" \
				-yscrollcommand "$v set" ]
	 $c config -scrollregion "0 0 $xsize $ysize"
	 pack $c -expand yes -fill both
	 grid $f1 -padx 1 -pady 1 \
				-row 0 -column 0 -rowspan 1 -columnspan 1 -sticky news
	 grid $v -padx 1 -pady 1 \
				-row 0 -column 1 -rowspan 1 -columnspan 1 -sticky news
	 grid $h -padx 1 -pady 1 \
				-row 1 -column 0 -rowspan 1 -columnspan 1 -sticky news
	 grid rowconfig    $f 0 -weight 1 -minsize 0
	 grid columnconfig $f 0 -weight 1 -minsize 0
	 pack $f -expand yes -fill both -padx 1 -pady 1
	 
	 $v config -command "$c yview"
	 $h config -command "$c xview"

	 # draw the origin and axes for the agent coord system - removed JEL 2/9/00
	 # $c create line 0 $Yoffset $xsize $Yoffset -arrow both -fill blue -tag x-axis
	 # $c create line $Xoffset 0 $Xoffset $ysize -arrow both -fill blue -tag y-axis

	 # create an arc to represent the agent FOV and put at agent loc 0,0
	 $c create arc [expr $Xoffset + 100] [expr $Yoffset + 100] \
				[expr $Xoffset - 100] [expr $Yoffset - 100] \
				-start -45 -extent 90 -style pieslice \
				-fill {} -outline darkgreen -tag fov

	 #initialize the params for the agent trail and enemy trail
	 global trail_life trail_count enemy_life enemy_count
	 set trail_life 25
	 set trail_count 0
	 set enemy_life 10
	 set enemy_count 0
	 trail-params "x" white 30
         enemy-params "x" red 10
}

proc xtrans {agent_x} {
	 # transform arg in X from agent coord to canvas coord 
	 global Xoffset scalef
	 return [expr $Xoffset + ($agent_x/$scalef)]
}

proc ytrans {agent_y} {
	 # transform arg in Y from agent coord to canvas coord 
	 global Yoffset scalef
	 return [expr $Yoffset - ($agent_y/$scalef)]
}

proc trail-params {char color lt} {
	global c w trail_life trail_char trail_color trail_count

	# check for numerical value for lifetime
	set newlt $trail_life
	regexp {^[0-9]+$} $lt newlt
	set trail_char $char
	set trail_color $color

	# if lifetime less than previous lifetime, delete trail 
	if {$newlt < $trail_life} {
		$c delete agent
		set trail_count 0
	}
	set trail_life $newlt
	$w.msg config -text "trail_params $char $color $lt"
}

proc enemy-params {char color lt} {
	global c w enemy_life enemy_char enemy_color enemy_count

	# check for numerical value for lifetime
	set newlt $enemy_life
	regexp {^[0-9]+$} $lt newlt
	set enemy_char $char
	set enemy_color $color

	# if lifetime less than previous lifetime, delete trail 
	if {$newlt < $enemy_life} {
		$c delete enemy
		set enemy_count 0
	}
	set enemy_life $newlt
	$w.msg config -text "enemy_params $char $color $lt"
}
proc is_agent {letter color} {
	global trail_color trail_char
	if {[string match $letter $trail_char] && \
	    [string match $color  $trail_color]} {
		return 1
	} else {
		return 0
	}
}
proc is_enemy {letter color} {
	global enemy_color enemy_char
	if {[string match $letter $enemy_char] && \
          [string match $color  $enemy_color]} {
		return 1
	} else {
		return 0
	}
}
proc draw-agent { x y } {
	global c w trail_color trail_char trail_life trail_count

	incr trail_count
	if {[expr $trail_count >= $trail_life]} { set trail_count 0 }
	set tagname ${trail_char}$trail_count
	$c delete $tagname
	$c create text [xtrans $x] [ytrans $y] -tags "agent $tagname" \
               -text "$trail_char" -fill $trail_color
}
proc draw-enemy { x y } {
	global c w enemy_color enemy_char enemy_life enemy_count

	incr enemy_count
	if {[expr $enemy_count >= $enemy_life]} { set enemy_count 0 }
	set tagname ${enemy_char}$enemy_count
#	echo "tagname = $tagname"
	$c delete $tagname
	$c create text [xtrans $x] [ytrans $y] -tags "enemy $tagname" \
               -text "$enemy_char" -fill $enemy_color
}
proc draw-letter {letter x y color} {
	 #put down any letter, used for health, enemies, etc
	 global c w
	
	if {[is_agent $letter $color]} {
	    draw-agent $x $y
	} elseif {[is_enemy $letter $color]} {
	    draw-enemy $x $y
	} else {
	 $c create text [xtrans $x] [ytrans $y] -text "$letter" -fill $color
	}
	$w.msg config -text "draw-letter $letter $x $y $color"
}

proc draw-line {x1 y1 x2 y2 args} {
	 global c w

	 $w.msg config -text "draw-line $x1 $y1 $x2 $y2 $args"
	 if {[llength $args] >= 1} {
		  set color [lindex $args 0]
	 } else {
		  set color "black"
	 }
	 $c create line [xtrans $x1] [ytrans $y1] [xtrans $x2] [ytrans $y2] \
				-fill $color
}

proc fov-angle {args} {
	 #set the absolute angle of the field-of-view
	 global c w fov
	 
	 set cur_extent [$c itemcget fov -extent]
	 if {$args == {} } {
		  $w.msg config -text "current FOV is $cur_extent degrees"
		  return $cur_extent
	 } elseif {[llength $args] == 1} {
		  $w.msg config -text "fov-radius $args"
		  set newfov [lindex $args 0]
		  # change start so stay centered about normal
		  set diff [expr $newfov - [$c itemcget fov -extent] ]
		  set cur_start [$c itemcget fov -start]
		  $c itemconfigure fov -start [expr $cur_start - $diff / 2] \
					 -extent $newfov
	 }
		  
} 
proc fov-dir {args} {
	 # set the absolute direction (normal) of the field-of-view
	 global c w fov
	 
	 set cur_extent [$c itemcget fov -extent]
	 set cur_dir [expr ([$c itemcget fov -start] + $cur_extent/2)]
	 if {$args == {} } {
		  $w.msg config -text "current FOV direction is $cur_dir degrees"
		  return $cur_dir
	 } elseif {[llength $args] == 1} {
		  $w.msg config -text "fov-dir $args"
		  set newdir [lindex $args 0]
		  set new_start [expr $newdir - $cur_extent/2]
		  $c itemconfigure fov -start $new_start
	 }
		  
} 
proc fov-radius {args} {
	 # set the range or radius of the field-of-view
	 global c w fov scalef
	 
	 set cur_indices [$c coords fov]
	 set cur_range [expr $scalef * abs([lindex $cur_indices 0] - \
				                          [lindex $cur_indices 2]) / 2]
	 if {$args == {} } {
		  $w.msg config -text "current FOV range is $cur_range "
		  return $cur_range
	 } elseif {[llength $args] == 1} {
		  $w.msg config -text "fov-range $args"
		  set newrange [lindex $args 0]
		  set diff [expr ($cur_range - $newrange) / $scalef ]
		  $c coords fov [expr [lindex $cur_indices 0] + $diff] \
					 [expr [lindex $cur_indices 1] + $diff] \
					 [expr [lindex $cur_indices 2] - $diff] \
					 [expr [lindex $cur_indices 3] - $diff]
	 }
}

proc fov-move {args} {
	 # move the fov by the amount in args,
	 # first arg is deltaX, 2nd arg is deltaY, 3rd arg is deltaDirection
	 global c w fov Xoffset Yoffset scalef

	 set cur_indices [$c coords fov]
	 #set cur_X [expr $scalef * ($Ymax - ([lindex $cur_indices 3] + \
	 #			                            [lindex $cur_indices 1])/2) ]
	 #set cur_Y [expr $scalef * ($Xmax - ([lindex $cur_indices 2] + \
	 #			                            [lindex $cur_indices 0])/2) ]
	 set cur_X [expr $scalef * (([lindex $cur_indices 2] + \
				     [lindex $cur_indices 0])/2 - $Xoffset) ]
	 set cur_Y [expr $scalef * ($Yoffset - ([lindex $cur_indices 3] + \
				                [lindex $cur_indices 1])/2) ]
	 set cur_dir [fov-dir]
	 if {$args == {} } {
		  $w.msg config -text "current location: $cur_X, $cur_Y, $cur_dir deg"
		  return [list $cur_X $cur_Y $cur_dir]
	 }
	 if { [llength $args] >= 1} {
		  set deltaX [expr ([lindex $args 0]) / $scalef ]
		  set deltaY 0
		  set deltaDir 0
	 }
	 if { [llength $args] >= 2} {
		  set deltaY [expr (0 - [lindex $args 1]) / $scalef ]
	 }
	 if { [llength $args] >= 3} {
		  set deltaDir [lindex $args 2]
	 }
	 $c move fov $deltaX  $deltaY
	 fov-dir [expr $cur_dir + $deltaDir]
	 $w.msg config -text "fov-move $args"
}
proc fov-pos {args} {
	 # move to the specified location, x, y, orientation
	 # first arg is X, 2nd arg is Y, 3rd arg is Direction
	 global c w fov Xoffset Yoffset scalef
    set changeDir 0

	 set cur_indices [$c coords fov]
	 #set cur_X [expr $scalef * ($Ymax - ([lindex $cur_indices 3] + \
	 #			                            [lindex $cur_indices 1])/2) ]
	 #set cur_Y [expr $scalef * ($Xmax - ([lindex $cur_indices 2] + \
	 #			                            [lindex $cur_indices 0])/2) ]
	 set cur_X [expr $scalef * (([lindex $cur_indices 2] + \
				     [lindex $cur_indices 0])/2 - $Xoffset) ]
	 set cur_Y [expr $scalef * ($Yoffset - ([lindex $cur_indices 3] + \
				                [lindex $cur_indices 1])/2) ]
	 set cur_dir [fov-dir]
	 if {$args == {} } {
		  $w.msg config -text "current location: $cur_X, $cur_Y, $cur_dir deg"
		  return [list $cur_X $cur_Y $cur_dir]
	 }
	 if { [llength $args] >= 1} {
		  set X [lindex $args 0]
		  set Y 0
		  set Dir 0
	 }
	 if { [llength $args] >= 2} {
		  set Y [lindex $args 1]
	 }
	 if { [llength $args] >= 3} {
		  set Dir [lindex $args 2]
		  set changeDir 1
	 }
	 set deltaX [expr ($X - $cur_X) / $scalef]
	 set deltaY [expr ($cur_Y - $Y) / $scalef]
	 $c coords fov [expr [lindex $cur_indices 0] + $deltaX]  \
				      [expr [lindex $cur_indices 1] + $deltaY]  \
						[expr [lindex $cur_indices 2] + $deltaX]  \
						[expr [lindex $cur_indices 3] + $deltaY]  
    if {$changeDir} {	 fov-dir $Dir  }
	 $w.msg config -text "fov-move $args"
}

