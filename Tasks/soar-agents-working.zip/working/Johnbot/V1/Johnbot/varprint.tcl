#####################################################
###
###  file:  substruct.tcl  (for lack of a better name)
###
###  this procedure takes a Soar identifier as the arg and
###  prints out the entire substructure, substituting variables
###  for any Soar identifiers that appear.  An optional integer
###  argument depth can limit the depth of the structure, otherwise
###  the depth is 100.
###
###  the string matching is not robust.  If there is any capital
###  letter followed by one or more integers, this proc will
###  add angle brackets around it, even if it is embedded in
###  an attribute or sym constant.  If it's a problem, this
###  can somehow be fixed.
###

proc varprint {id args} {

  if {[llength $args] == 1} {
    set depth [lindex $args 0]
  } else {
    set depth 100
  }

  output-strings-destination -push -append-to-result
  set objects [print -depth $depth $id]
  output-strings-destination -pop

  regsub -all {[A-Z][0-9]+} $objects {<&>} varobj
  return $varobj
}

