#######################################################################
###
###  file:  textwin.tcl
###
###  these routines create a text box to display messages.  
###  
###  initText lines length  -- creates of text box with empty lines
###                            of length $length.  lines will wrap
###                            when necessary
###  
###  writeText line  txt   -- replaces the text in $line with $txt
###
###

proc initText {lines length} {
	 global ww

	 set ww .textbox
	 catch {destroy $ww}
	 toplevel $ww
	 wm title $ww "Agent TextBox"
	 wm iconname $ww "TextBox"

	 text $ww.text -yscrollcommand "$ww.scroll set" -setgrid true \
				-font {Courier 12 bold} -spacing1 0.25i \
				-width $length -height $lines -wrap word
	 scrollbar $ww.scroll -command "$ww.text yview"
	 pack $ww.scroll -side right -fill y
	 pack $ww.text -expand yes -fill both

	 $ww.text tag configure bold -font {Courier 12 bold} -spacing1 0.15i

	 for {set n 1} {$n <= $lines} {incr n} {
		  $ww.text insert $n.0 "\n"
	 }
}

proc writeText {line txt} {
	 global ww

	 $ww.text delete $line.0 $line.end
	 $ww.text insert $line.0 $txt bold
}
