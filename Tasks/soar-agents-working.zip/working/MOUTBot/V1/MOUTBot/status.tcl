###
###  status.tcl 
###
###  this file creates status window that can be used to display any agent-specific information.
###  Intially, this info will include current behavior, status and feeler info.
###
###
###
### NOTE: One slight hack exists in this code... due to conflicts when using this
###       status window and the agent map window simultaneously, I had to rename the
###       canvas object from 'c' to 'can', as there was a conflict with map.tcl's 
###       version of 'c'. -->MJP 5/29/03
###

proc init-status { } {

	 global can w colors activeMap meterLength meterSpacing meterWidth meterGap Xmeter Ymeter feelerWidth Xfeeler Yfeeler
	 
	 set w .status
	 catch {destroy $w}
	 toplevel $w
	 wm title $w "Status"
	 wm iconname $w "Status"
	 wm geometry $w -283+0
	 wm minsize $w 100 100

	 label $w.msg -wraplength 130 -justify left -text "drawing commands will be printed in this area as they are issued."
	 pack $w.msg -side bottom

                


	 set f [frame $w.frame]
	 pack $f -side top -fill both -expand yes

	 set f1 [frame $f.f1 -bd 2 -relief sunken]

	 set can [canvas $f1.c -width 165 -height 270 -borderwidth 0 \
				-highlightthickness 0 ]
				
	 pack $can -expand yes -fill both
	 grid $f1 -padx 1 -pady 1 \
				-row 0 -column 0 -rowspan 1 -columnspan 1 -sticky news
	 
	 
	 # set up meter size and positioning
	 set meterLength 60
	 set meterGap 4
	 set meterWidth 17
	 set meterSpacing [expr $meterGap + $meterWidth]
	 set Xmeter 3
	 set Ymeter 3
	 
	 # feeler size and positioning
	 set feelerWidth 10
	 set Xfeeler 10
	 set Yfeeler 230
}

# debug function used to test the status window from the WISH console
proc test-all { } {
	init-status
	feeler-test none
	
	draw-condition-level health 100 red
	draw-condition-level hunger 100 red	
	draw-condition-level thirst 100 red	
	draw-condition-level strength 70.1 red	
	draw-condition-level temperature 100 red	
	draw-condition-level fatigue 100 red
	draw-condition-level dexterity 100 red
			
	draw-behavior eat
	draw-carried-decoration match1
	draw-area-visit-count mainhall 3
	draw-message "Hello, World"
}






# used to draw meters for	hunger 
#				health,
#				thirst, 
#				temperature, 
#				fatigue, 
#				temperature
# 				dexterity
#
#
proc draw-condition-level { name level color } {
	
	global meterSpacing
	
	if { [string match $name "health"] } {
		
		draw-meter $level 100 0 [expr $meterSpacing * 0] "Health" $color
		
	} elseif { [string match $name "hunger"] } {
	
		draw-meter $level 960 0 [expr $meterSpacing * 1] "Hunger" $color
		
	} elseif { [string match $name "thirst"] } {
	
		draw-meter $level 480 0 [expr $meterSpacing * 2] "Thirst" $color
		
	} elseif { [string match $name "fatigue"] } {
	
		draw-meter $level 100 0 [expr $meterSpacing * 3] "Fatigue" $color
		
	} elseif { [string match $name "temperature"] } {
	
		draw-meter $level 100 0 [expr $meterSpacing * 4] "Temperature" $color
		
	} elseif { [string match $name "strength"] } {
	
		draw-meter $level 100 0 [expr $meterSpacing * 5] "Strength" $color
		
	} elseif { [string match $name "dexterity"] } {
	
		draw-meter $level 100 0 [expr $meterSpacing * 6] "Dexterity" $color
		
	}
}


# utility function to draw a status meter, used by 'draw-condition-level'
proc draw-meter {current max x y name color} {
	
	global can w meterLength meterWidth Xmeter Ymeter
	
	set metertag "meter$name"
	
	# delete previous status meter for each update
	$can delete $metertag
	
	set Xstart [expr $x + $Xmeter]
	set Ystart [expr $y + $Ymeter]
	set Xend [expr $Xstart + $meterLength]
	set Yend [expr $Ystart + $meterWidth]
	
	set level [expr ((double($current) / $max) * $meterLength) + $Xmeter]
	
	set Xmid [expr ($Xend + $Xstart) / 2]
	set Ymid [expr ($Yend + $Ystart) / 2]
	
	$can create rect $Xstart $Ystart $Xend   $Yend -fill darkgrey -tags $metertag
	$can create rect $Xstart $Ystart $level $Yend -fill $color -tags $metertag
	
	$can create text $Xmid $Ymid -text "$current" -tags $metertag \
	                           -justify center -anchor center -fill white	
	
	$can create text [expr $Xend + 5] $Ymid -text "$name" -tags $metertag \
					-fill black -justify left -anchor w
	
	
   #     $w.msg config -text "draw-meter $name $current"
}


# simple function for displaying a Haunt Bot's current behavior (ie eat/drink)
proc draw-behavior { name } {
	global can

	set behaviorTag "behavior"
	
	$can delete $behaviorTag
	
	$can create text 0 175 -text "Behavior: $name" -tags $behaviorTag -justify left -anchor w -fill black

}


# simple function for displaying a Haunt Bot's currently held decoration
proc draw-carried-decoration { name } {
	
	global can
	
	set myTag "carriedDecoration"
	
	$can delete $myTag
	
	$can create text 0 160 -text "Carrying: $name" -tags $myTag -justify left -anchor w -fill black
}



# simple function for displaying current area information
proc draw-area-visit-count { name count } {
	
	global can
	
	set myTag "areaVisitCount"
	
	$can delete $myTag
	
	$can create text 0 190 -text "Area $name, count $count" -tags $myTag -justify left -anchor w -fill black
}

# utility function for displaying a single message (old messages are overwrittent)
proc draw-message { msg } {
	
	global can
	
	set myTag "drawMessage"
	
	$can delete $myTag
	
	$can create text 0 205 -text "$msg" -tags $myTag -justify left -anchor w -fill blue
}	

proc draw-action { msg } {
	
	global can
	
	set myTag "drawAction"
	
	$can delete $myTag
	
	$can create text 0 220 -text "$msg" -tags $myTag -justify left -anchor w -fill blue
}


# ******************************************************************************
#
#
#  FEELER INFO
#
#
# ******************************************************************************

proc feeler-test { status } {
	
	draw-feeler left-front $status
	draw-feeler front $status
	draw-feeler right-front $status
	draw-feeler left $status
	draw-feeler right $status
	draw-feeler back $status	
	draw-feeler up $status
	draw-feeler knee $status
	draw-feeler down $status
}


# sets up position for each feeler so that boxes are arranged as follows:
#
#
#      left-front      front      right-front      up
#      left                       right            knee
#                      back                        down
#
#
# 'blocked' feelers are RED, 'unblocked' are YELLOW
#
#	
proc draw-feeler { name status } {

	global feelerWidth

	if { [string match $name "left-front"] } {  
		set x [expr $feelerWidth * 0]
		set y [expr $feelerWidth * 0]
	} elseif { [string match $name "front"] } { 
		set x [expr $feelerWidth * 1]
		set y [expr $feelerWidth * 0]
	} elseif { [string match $name "right-front"] } { 
		set x [expr $feelerWidth * 2]
		set y [expr $feelerWidth * 0]
	} elseif { [string match $name "left"] } { 
		set x [expr $feelerWidth * 0]
		set y [expr $feelerWidth * 1]
	} elseif { [string match $name "right"] } { 
		set x [expr $feelerWidth * 2]
		set y [expr $feelerWidth * 1]
	} elseif { [string match $name "back"] } { 
		set x [expr $feelerWidth * 1]
		set y [expr $feelerWidth * 2]
	} elseif { [string match $name "up"] } { 
		set x [expr $feelerWidth * 4]
		set y [expr $feelerWidth * 0]
	} elseif { [string match $name "knee"] } { 
		set x [expr $feelerWidth * 4]
		set y [expr $feelerWidth * 1]
	} elseif { [string match $name "down"] } { 
		set x [expr $feelerWidth * 4]
		set y [expr $feelerWidth * 2]
	}
			
	set y [expr $y]
	
	

	if { [string match $status "none"] } {
		draw-feeler-box $x $y yellow
       } elseif { [string match $status "None"] } {
		draw-feeler-box $x $y yellow
	} else {
		draw-feeler-box $x $y red
	}
}


# draw a single feeler box, called by 'draw-feeler' (above)
proc draw-feeler-box { x y color } {
	
	global can w feelerWidth Xfeeler Yfeeler
	
	set feelerTag "feeler$x$y"
	
	$can delete $feelerTag
	
	set Xstart [expr $x + $Xfeeler]
	set Ystart [expr $y + $Yfeeler]
	set Xend [expr $Xstart + $feelerWidth]
	set Yend [expr $Ystart + $feelerWidth]
		
	$can create rect $Xstart $Ystart $Xend $Yend -fill $color -tags $feelerTag
	
 #     $w.msg config -text "draw-feeler"
}


