382
SOAR_ID 0
SOAR_ID 1
SOAR_ID 2
SOAR_ID 3
SOAR_ID 4
ENUMERATION 5 1 state
ENUMERATION 6 1 nil
ENUMERATION 7 5 UCBot explore go-to-flag search-for-flag selection
ENUMERATION 8 1 initialize-UCBot
SOAR_ID 9
INTEGER_RANGE 10 -2147483648 2147483647
INTEGER_RANGE 11 -2147483648 2147483647
SOAR_ID 12
FLOAT_RANGE 13 -Infinity Infinity
FLOAT_RANGE 14 -Infinity Infinity
FLOAT_RANGE 15 -Infinity Infinity
SOAR_ID 16
SOAR_ID 17
FLOAT_RANGE 18 -Infinity Infinity
INTEGER_RANGE 19 -2147483648 2147483647
INTEGER_RANGE 20 -2147483648 2147483647
SOAR_ID 21
INTEGER_RANGE 22 -2147483648 2147483647
FLOAT_RANGE 23 -Infinity Infinity
FLOAT_RANGE 24 -Infinity Infinity
FLOAT_RANGE 25 -Infinity Infinity
SOAR_ID 26
INTEGER_RANGE 27 -2147483648 2147483647
INTEGER_RANGE 28 -2147483648 2147483647
INTEGER_RANGE 29 -2147483648 2147483647
SOAR_ID 30
SOAR_ID 31
INTEGER_RANGE 32 -2147483648 2147483647
INTEGER_RANGE 33 -2147483648 2147483647
SOAR_ID 34
FLOAT_RANGE 35 -Infinity Infinity
FLOAT_RANGE 36 -Infinity Infinity
FLOAT_RANGE 37 -Infinity Infinity
INTEGER_RANGE 38 -2147483648 2147483647
SOAR_ID 39
INTEGER_RANGE 40 -2147483648 2147483647
STRING 41
STRING 42
INTEGER_RANGE 43 -2147483648 2147483647
SOAR_ID 44
SOAR_ID 45
INTEGER_RANGE 46 -2147483648 2147483647
SOAR_ID 47
SOAR_ID 48
STRING 49
INTEGER_RANGE 50 -2147483648 2147483647
INTEGER_RANGE 51 -2147483648 2147483647
STRING 52
SOAR_ID 53
SOAR_ID 54
SOAR_ID 55
INTEGER_RANGE 56 -2147483648 2147483647
STRING 57
STRING 58
SOAR_ID 59
INTEGER_RANGE 60 -2147483648 2147483647
INTEGER_RANGE 61 -2147483648 2147483647
INTEGER_RANGE 62 -2147483648 2147483647
INTEGER_RANGE 63 -2147483648 2147483647
INTEGER_RANGE 64 -2147483648 2147483647
INTEGER_RANGE 65 -2147483648 2147483647
INTEGER_RANGE 66 -2147483648 2147483647
INTEGER_RANGE 67 -2147483648 2147483647
INTEGER_RANGE 68 -2147483648 2147483647
SOAR_ID 69
FLOAT_RANGE 70 -Infinity Infinity
FLOAT_RANGE 71 -Infinity Infinity
FLOAT_RANGE 72 -Infinity Infinity
INTEGER_RANGE 73 -2147483648 2147483647
SOAR_ID 74
SOAR_ID 75
INTEGER_RANGE 76 -2147483648 2147483647
INTEGER_RANGE 77 -2147483648 2147483647
INTEGER_RANGE 78 -2147483648 2147483647
INTEGER_RANGE 79 -2147483648 2147483647
SOAR_ID 80
ENUMERATION 81 1 nothing
ENUMERATION 82 1 complete
SOAR_ID 83
ENUMERATION 84 2 backward forward
SOAR_ID 85
ENUMERATION 86 3 left none right
SOAR_ID 87
ENUMERATION 88 2 backward forward
SOAR_ID 89
SOAR_ID 90
SOAR_ID 91
SOAR_ID 92
SOAR_ID 93
ENUMERATION 94 2 down up
SOAR_ID 95
ENUMERATION 96 3 in out reset
SOAR_ID 97
SOAR_ID 98
SOAR_ID 99
SOAR_ID 100
SOAR_ID 101
SOAR_ID 102
SOAR_ID 103
SOAR_ID 104
SOAR_ID 105
ENUMERATION 106 1 first-to-flag
SOAR_ID 107
SOAR_ID 108
FLOAT_RANGE 109 -Infinity Infinity
FLOAT_RANGE 110 -Infinity Infinity
FLOAT_RANGE 111 -Infinity Infinity
SOAR_ID 112
SOAR_ID 113
SOAR_ID 114
FLOAT_RANGE 115 -Infinity Infinity
SOAR_ID 116
SOAR_ID 117
INTEGER_RANGE 118 -2147483648 2147483647
INTEGER_RANGE 119 -2147483648 2147483647
INTEGER_RANGE 120 -2147483648 2147483647
INTEGER_RANGE 121 -2147483648 2147483647
SOAR_ID 122
ENUMERATION 123 1 record-area
ENUMERATION 124 2 false true
SOAR_ID 125
ENUMERATION 126 1 explore
SOAR_ID 127
ENUMERATION 128 1 record-path
INTEGER_RANGE 129 -2147483648 2147483647
FLOAT_RANGE 130 -Infinity Infinity
INTEGER_RANGE 131 -2147483648 2147483647
ENUMERATION 132 2 connected-area unconnected-area
SOAR_ID 133
ENUMERATION 134 1 state
ENUMERATION 135 1 explore
ENUMERATION 136 1 move-to-area
SOAR_ID 137
ENUMERATION 138 1 move-to-area
SOAR_ID 139
SOAR_ID 140
ENUMERATION 141 1 state
ENUMERATION 142 1 move-to-area
ENUMERATION 143 1 move-to-gateway
SOAR_ID 144
ENUMERATION 145 1 move-to-xy
SOAR_ID 146
FLOAT_RANGE 147 -Infinity Infinity
FLOAT_RANGE 148 -Infinity Infinity
ENUMERATION 149 2 left right
ENUMERATION 150 1 turn-left
SOAR_ID 151
ENUMERATION 152 1 turn-right
SOAR_ID 153
ENUMERATION 154 1 sprint-forward
SOAR_ID 155
SOAR_ID 156
ENUMERATION 157 1 state
ENUMERATION 158 1 move-to-xy
ENUMERATION 159 1 move-forward
SOAR_ID 160
SOAR_ID 161
ENUMERATION 162 1 state
ENUMERATION 163 1 move-to-gateway
ENUMERATION 164 1 move-to-xy
SOAR_ID 165
FLOAT_RANGE 166 -Infinity Infinity
FLOAT_RANGE 167 -Infinity Infinity
FLOAT_RANGE 168 -Infinity Infinity
FLOAT_RANGE 169 -Infinity Infinity
ENUMERATION 170 1 wait
SOAR_ID 171
ENUMERATION 172 1 wait
ENUMERATION 173 2 operator state
ENUMERATION 174 1 none
ENUMERATION 175 1 wait
ENUMERATION 176 1 stop-turn
SOAR_ID 177
SOAR_ID 178
ENUMERATION 179 3 left none right
ENUMERATION 180 4 none run sprint walk
ENUMERATION 181 3 backward forward none
FLOAT_RANGE 182 -Infinity Infinity
FLOAT_RANGE 183 -Infinity Infinity
SOAR_ID 184
ENUMERATION 185 2 none stop
SOAR_ID 186
FLOAT_RANGE 187 -Infinity Infinity
FLOAT_RANGE 188 -Infinity Infinity
SOAR_ID 189
SOAR_ID 190
SOAR_ID 191
FLOAT_RANGE 192 -Infinity Infinity
FLOAT_RANGE 193 -Infinity Infinity
FLOAT_RANGE 194 -Infinity Infinity
FLOAT_RANGE 195 -Infinity Infinity
SOAR_ID 196
FLOAT_RANGE 197 -Infinity Infinity
FLOAT_RANGE 198 -Infinity Infinity
FLOAT_RANGE 199 -Infinity Infinity
ENUMERATION 200 2 false true
ENUMERATION 201 1 move-through-gateway
SOAR_ID 202
ENUMERATION 203 1 move-through-gateway
SOAR_ID 204
SOAR_ID 205
ENUMERATION 206 1 state
ENUMERATION 207 1 move-through-gateway
ENUMERATION 208 1 turn-left
SOAR_ID 209
ENUMERATION 210 1 turn-right
SOAR_ID 211
ENUMERATION 212 1 stop-turn
SOAR_ID 213
ENUMERATION 214 1 move-forward
SOAR_ID 215
ENUMERATION 216 1 wait
FLOAT_RANGE 217 -Infinity Infinity
FLOAT_RANGE 218 -Infinity Infinity
FLOAT_RANGE 219 -Infinity Infinity
ENUMERATION 220 2 false true
SOAR_ID 221
ENUMERATION 222 1 update-paths-recorded
ENUMERATION 223 1 done
SOAR_ID 224
FLOAT_RANGE 225 -Infinity Infinity
ENUMERATION 226 1 tail
ENUMERATION 227 1 back-out
SOAR_ID 228
INTEGER_RANGE 229 -2147483648 2147483647
SOAR_ID 230
ENUMERATION 231 1 propogate-path
ENUMERATION 232 1 propogate-path
SOAR_ID 233
ENUMERATION 234 2 jump none
ENUMERATION 235 2 jump none
ENUMERATION 236 3 left none right
ENUMERATION 237 2 left right
INTEGER_RANGE 238 -2147483648 2147483647
SOAR_ID 239
ENUMERATION 240 1 go-to-flag
SOAR_ID 241
ENUMERATION 242 1 state
ENUMERATION 243 1 go-to-flag
ENUMERATION 244 1 move-to-xy
SOAR_ID 245
SOAR_ID 246
SOAR_ID 247
FLOAT_RANGE 248 -Infinity Infinity
FLOAT_RANGE 249 -Infinity Infinity
INTEGER_RANGE 250 -2147483648 2147483647
FLOAT_RANGE 251 -Infinity Infinity
FLOAT_RANGE 252 -Infinity Infinity
INTEGER_RANGE 253 -2147483648 2147483647
ENUMERATION 254 1 swap-flags
SOAR_ID 255
ENUMERATION 256 3 run sprint walk
ENUMERATION 257 2 explore-all go-to-flag
SOAR_ID 258
SOAR_ID 259
FLOAT_RANGE 260 -Infinity Infinity
FLOAT_RANGE 261 -Infinity Infinity
ENUMERATION 262 1 initialize-map
SOAR_ID 263
ENUMERATION 264 2 false true
SOAR_ID 265
ENUMERATION 266 1 initialize-UCBot
ENUMERATION 267 1 explore
SOAR_ID 268
SOAR_ID 269
ENUMERATION 270 1 detect-flag
SOAR_ID 271
ENUMERATION 272 1 update-all-paths
SOAR_ID 273
ENUMERATION 274 1 state
ENUMERATION 275 1 update-all-paths
ENUMERATION 276 1 delete-duplicate-paths
SOAR_ID 277
ENUMERATION 278 1 no-path-to-update
SOAR_ID 279
ENUMERATION 280 1 record-path
SOAR_ID 281
ENUMERATION 282 1 update-path
SOAR_ID 283
ENUMERATION 284 2 false true
ENUMERATION 285 2 false true
ENUMERATION 286 2 connected extended
INTEGER_RANGE 287 -2147483648 2147483647
ENUMERATION 288 3 none original-location start-location
ENUMERATION 289 1 search-for-flag
SOAR_ID 290
ENUMERATION 291 2 false true
SOAR_ID 292
ENUMERATION 293 1 search-for-flag
SOAR_ID 294
ENUMERATION 295 1 state
ENUMERATION 296 1 search-for-flag
ENUMERATION 297 1 increment-radius
SOAR_ID 298
ENUMERATION 299 1 initialize-search
SOAR_ID 300
ENUMERATION 301 1 mark-as-searched
SOAR_ID 302
ENUMERATION 303 1 move-to-area
SOAR_ID 304
INTEGER_RANGE 305 -2147483648 2147483647
ENUMERATION 306 2 false true
ENUMERATION 307 2 breadth-first depth-first
SOAR_ID 308
ENUMERATION 309 1 swap-flags
SOAR_ID 310
ENUMERATION 311 1 uct
ENUMERATION 312 1 no
ENUMERATION 313 1 true
SOAR_ID 314
ENUMERATION 315 1 state
ENUMERATION 316 2 Impasse__Operator_Tie selection
ENUMERATION 317 2 evaluate-operator move-to-area
SOAR_ID 318
SOAR_ID 319
ENUMERATION 320 1 state
ENUMERATION 321 1 evaluate-operator
ENUMERATION 322 1 connected-area
ENUMERATION 323 1 no-change
ENUMERATION 324 1 state
ENUMERATION 325 1 go-to-flag
SOAR_ID 326
ENUMERATION 327 1 state
ENUMERATION 328 1 Impasse__State_No-Change
SOAR_ID 329
ENUMERATION 330 1 evaluate-operator
INTEGER_RANGE 331 -2147483648 2147483647
ENUMERATION 332 2 false true
SOAR_ID 333
ENUMERATION 334 1 detect-record-area-complete
SOAR_ID 335
SOAR_ID 336
ENUMERATION 337 7 black blue green orange purple red yellow
ENUMERATION 338 2 static update
SOAR_ID 339
FLOAT_RANGE 340 -Infinity Infinity
FLOAT_RANGE 341 -Infinity Infinity
ENUMERATION 342 2 false true
ENUMERATION 343 2 false true
INTEGER_RANGE 344 -2147483648 2147483647
INTEGER_RANGE 345 -2147483648 2147483647
ENUMERATION 346 2 false true
ENUMERATION 347 1 true
ENUMERATION 348 1 true
INTEGER_RANGE 349 -2147483648 2147483647
ENUMERATION 350 1 t
SOAR_ID 351
SOAR_ID 352
INTEGER_RANGE 353 -2147483648 2147483647
INTEGER_RANGE 354 -2147483648 2147483647
INTEGER_RANGE 355 -2147483648 2147483647
ENUMERATION 356 1 t
FLOAT_RANGE 357 -Infinity Infinity
ENUMERATION 358 2 higher lower
SOAR_ID 359
ENUMERATION 360 4 failure partial-failure partial-success success
INTEGER_RANGE 361 -2147483648 2147483647
INTEGER_RANGE 362 -2147483648 2147483647
SOAR_ID 363
ENUMERATION 364 1 update-gateway
ENUMERATION 365 2 blocked new
SOAR_ID 366
ENUMERATION 367 5 achieved-flag all-areas-recorded all-paths-updated halt start
ENUMERATION 368 3 all none vital
SOAR_ID 369
ENUMERATION 370 1 finish-trial
ENUMERATION 371 1 true
ENUMERATION 372 2 finish halt
SOAR_ID 373
ENUMERATION 374 1 state
ENUMERATION 375 1 Impasse__State_No-Change
ENUMERATION 376 1 start-over
SOAR_ID 377
ENUMERATION 378 1 clear-previous-areas
SOAR_ID 379
ENUMERATION 380 1 state
ENUMERATION 381 1 none
519
0 attribute 173
0 canvas 335
0 choices 174
0 depth 349
0 desired 247
0 flag 247
0 flags 246
0 headings 117
0 io 1
0 map 112
0 mission 105
0 name 7
0 operator 4
0 operator 122
0 operator 125
0 operator 127
0 operator 139
0 operator 146
0 operator 171
0 operator 202
0 operator 221
0 operator 230
0 operator 239
0 operator 255
0 operator 265
0 operator 269
0 operator 271
0 operator 292
0 operator 308
0 operator 329
0 operator 333
0 operator 363
0 operator 369
0 parameters 116
0 problem-space 310
0 quiescence 350
0 superstate 6
0 superstate 0
0 top-state 0
0 type 5
1 input-link 2
1 output-link 3
2 accuracy 9
2 angles 12
2 area 39
2 entities 16
2 feedback 178
2 health 17
2 items 30
2 location 34
2 speed 38
2 status 59
2 velocity 69
2 view-height 73
2 weapons 74
3 bandage 101
3 center 98
3 do 80
3 duck 99
3 fire 97
3 jump 89
3 look 93
3 mark 366
3 move 184
3 quit 102
3 reload 100
3 restore 104
3 run 91
3 sprint 83
3 stop 90
3 strafe 92
3 suicide 103
3 turn 85
3 walk 87
3 zoom 95
4 name 8
9 hits 10
9 shots 11
12 pitch 13
12 roll 14
12 yaw 15
17 bleed-rate 18
17 damage-from 21
17 damage-to 26
17 health 19
17 take-damage 20
21 world 22
21 x 23
21 y 24
21 z 25
26 below-waist 27
26 head 28
26 torso 29
30 item 31
31 flag 33
31 id 32
34 x 35
34 y 36
34 z 37
39 connected-area 39
39 dead-end 347
39 id 40
39 info 41
39 name 42
39 negative-spaces 47
39 num-vertices 43
39 objects 54
39 partially-recorded-link 39
39 partially-recorded-link 226
39 path 114
39 paths-recorded 220
39 positive-spaces 44
39 recorded 124
39 searched 291
39 start-id 344
39 vertices 258
44 positive-space 45
45 id 46
47 negative-space 48
48 action 52
48 blocked 313
48 centroid 339
48 gateway-name 49
48 id 50
48 num-vertices 51
48 vertices 189
53 vertex 186
54 object 55
55 id 56
55 info 58
55 name 57
55 vertices 53
59 is-bandaging 60
59 is-bleeding 61
59 is-ducked 62
59 is-firing 63
59 is-jumping 64
59 is-ladder 65
59 is-limping 66
59 is-reload 67
59 is-using 68
69 x 70
69 y 71
69 z 72
74 weapon 75
75 ammo 77
75 clips 78
75 id 76
75 mode 79
80 info 81
80 status 82
83 direction 84
83 status 82
85 direction 86
85 status 82
87 direction 88
87 status 82
89 direction 235
89 status 82
90 status 82
91 direction 84
91 status 82
92 direction 86
92 status 82
93 direction 94
93 status 82
95 direction 96
95 status 82
97 status 82
98 status 82
99 status 82
100 status 82
101 status 82
102 status 82
103 status 82
104 status 82
105 achieved-flag 247
105 complete 371
105 flag-info 107
105 search-for-flag 39
105 type 106
105 updated-all-paths 285
107 location 108
108 x 109
108 y 110
108 z 111
112 areas 113
112 current-area 39
112 last-area 39
112 partially-recorded-head 39
112 previous-area 39
112 search-complete 332
113 area 39
114 area-count 129
114 area-count-minus-one 131
114 distance 115
114 from-area 39
114 gateway 48
114 next-area 39
114 to-area 39
116 explore-or-flag 257
116 gateway-buffer 225
116 heading-left-threshold 182
116 heading-right-threshold 183
116 initial-area-id 331
116 internal-simulation 284
116 load-map 264
116 monitor-level 368
116 search-origin 288
116 search-strategy 307
116 update-all-paths 346
117 east 120
117 flag-range 253
117 normalized-head 148
117 north 118
117 should-strafe 237
117 should-turn 149
117 south 119
117 target-heading 147
117 west 121
122 name 123
125 name 126
127 area-count 129
127 area-count-minus-one 131
127 connected-area 39
127 destination-area 39
127 distance 130
127 intermediate-area 39
127 name 128
127 source-area 39
127 type 132
133 attribute 173
133 choices 174
133 io 1
133 name 135
133 operator 137
133 operator 224
133 operator 228
133 operator 233
133 operator 263
133 superstate 0
133 top-state 0
133 type 134
137 name 136
137 path 114
137 speed 256
139 distance-to-flag 357
139 name 138
139 path 114
139 speed 256
139 type 322
140 io 1
140 line-through-gateway 196
140 name 142
140 operator 144
140 operator 204
140 path 114
140 projection-agent 199
140 projection1 199
140 projection2 199
140 quiescence 356
140 speed 256
140 superstate 0
140 top-state 0
140 trans-x 217
140 trans-y 218
140 type 141
140 within-gateway 200
140 within-gateway-int 229
144 gateway 48
144 name 143
144 speed 256
146 name 145
146 x 168
146 y 169
151 name 150
153 name 152
155 name 154
155 type 172
156 headings 117
156 io 1
156 name 158
156 operator 160
156 operator 155
156 operator 153
156 operator 151
156 operator 177
156 speed 256
156 superstate 0
156 top-state 0
156 type 157
160 jump 343
160 name 159
160 speed 256
161 io 1
161 name 163
161 operator 165
161 quiescence 356
161 speed 256
161 superstate 140
161 top-state 0
161 type 162
165 name 164
165 speed 256
165 x 166
165 y 167
171 name 170
171 type 175
177 name 176
178 jump 234
178 movement-dir 181
178 movement-type 180
178 strafe 236
178 turn 179
184 direction 185
186 x 187
186 y 188
189 vertex1 190
189 vertex2 191
190 x 192
190 y 193
191 x 194
191 y 195
196 x 197
196 y 198
202 name 201
204 name 203
205 headings 117
205 io 1
205 name 207
205 operator 209
205 operator 211
205 operator 213
205 operator 215
205 pos-rel-to-gate 219
205 quiescence 356
205 speed 256
205 superstate 140
205 top-state 0
205 type 206
205 within-gateway-first-half-int 238
209 name 208
211 name 210
213 name 212
213 type 216
215 jump 342
215 name 214
215 speed 256
221 name 222
224 name 223
228 current-area 39
228 name 227
230 name 231
233 area-count 129
233 area-count-minus-one 131
233 connected-area 39
233 destination-area 39
233 distance 130
233 intermediate-area 39
233 name 232
233 source-area 39
239 flag 247
239 name 240
241 desired 247
241 flag 247
241 name 243
241 operator 245
241 operator 268
241 operator 290
241 operator 139
241 path-blocked 348
241 problem-space 310
241 quiescence 350
241 superstate 0
241 top-state 0
241 type 242
245 name 244
245 x 251
245 y 252
246 flag 247
247 area 39
247 area-id 250
247 better 358
247 previous-id 287
247 start-id 345
247 x 248
247 y 249
255 current-flag 247
255 name 254
255 other-flag 247
258 centroid 339
258 vertex1 259
258 vertex2 259
258 vertex3 259
258 vertex4 259
258 vertex5 259
258 vertex6 259
259 x 260
259 y 261
263 name 262
265 name 266
268 name 267
269 name 270
271 name 272
273 io 1
273 name 275
273 operator 277
273 operator 279
273 operator 281
273 operator 283
273 superstate 0
273 top-state 0
273 type 274
277 area 39
277 name 276
277 path 114
279 name 278
281 area-count 129
281 area-count-minus-one 131
281 connected-area 39
281 destination-area 39
281 name 280
281 source-area 39
281 type 132
283 area-count 129
283 area-count-minus-one 131
283 connected-area 39
283 destination-area 39
283 name 282
283 old-path 114
283 source-area 39
283 type 286
290 name 289
290 start-area 39
292 name 293
294 name 296
294 operator 298
294 operator 300
294 operator 302
294 operator 304
294 search-radius 305
294 superstate 0
294 top-state 0
294 type 295
298 name 297
300 name 299
302 name 301
304 name 303
304 original-location 306
304 path 114
304 speed 256
308 current-flag 247
308 name 309
308 other-flag 247
310 default-state-copy 312
310 name 311
314 evaluation 359
314 name 316
314 operator 318
314 superstate 241
314 top-state 0
314 type 315
318 name 317
318 superoperator 139
319 depth 355
319 desired 247
319 failure 247
319 flag 247
319 impasse 323
319 map 112
319 mission 105
319 name 321
319 name 325
319 numeric-value 362
319 operator 139
319 reward-link 351
319 success 247
319 success-depth 354
319 superstate 314
319 top-state 0
319 type 320
326 attribute 324
326 impasse 323
326 name 328
326 quiescence 350
326 superstate 319
326 top-state 0
326 type 327
329 name 330
333 name 334
335 region 336
336 area 39
336 color 337
336 type 338
339 x 340
339 y 341
351 reward 352
352 value 353
359 desired 247
359 numeric-value 361
359 superoperator 139
359 symbolic-value 360
363 gate 48
363 name 364
363 type 365
366 value 367
369 name 370
369 type 372
373 attribute 380
373 choices 381
373 name 375
373 operator 377
373 operator 379
373 superstate 241
373 top-state 0
373 type 374
377 name 376
379 name 378
379 to-clear 39
