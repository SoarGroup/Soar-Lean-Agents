from string import digits, strip, split

def cleanMap(filename):
    parseFloats(filename, filename)
    removeStragglers(filename, filename)

def parseFloats(in_filename, out_filename):
    f = open(in_filename, 'r')
    lines = f.readlines()
    f.close()
    
    f = open(out_filename, 'w')
    for line in lines:
        i = 0
        n = len(line)
        while '.' in line[i:]:
            i += line[i:].index('.')
            if i > 0 and line[i - 1] in digits and line[i + 1] != '0':
                line = line[0:i + 1] + '0' + line[i + 1:]
            i = i + 1
        f.write(line)
    f.close()

def removeStragglers(in_filename, out_filename):
    f = open(in_filename, 'r')
    lines = f.readlines()
    f.close()
    
    f = open(out_filename, 'w')
    for line in lines:
        s = strip(line)
        if len(s) >= 5 and s[0] == '(' and s[1] == '<' and s[-1] == ')' and s[-2] == '>' and len(split(s)) == 1:
            pass
        else:
            f.write(line)
    f.close()
