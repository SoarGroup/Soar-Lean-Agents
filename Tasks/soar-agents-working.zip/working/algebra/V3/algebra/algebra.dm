134
SOAR_ID 0
SOAR_ID 1
SOAR_ID 2
SOAR_ID 3
SOAR_ID 4
ENUMERATION 5 1 state
ENUMERATION 6 1 nil
ENUMERATION 7 1 algebra
ENUMERATION 8 1 initialize-algebra
SOAR_ID 9
ENUMERATION 10 1 process-clause
SOAR_ID 11
ENUMERATION 12 1 state
ENUMERATION 13 2 process-clause solve-problem
SOAR_ID 14
ENUMERATION 15 5 add divide equal multiply subtract
INTEGER_RANGE 16 -2147483648 2147483647
SOAR_ID 17
ENUMERATION 18 4 add divide multiply subtract
SOAR_ID 19
ENUMERATION 20 1 finish
SOAR_ID 21
ENUMERATION 22 1 swap-sides
SOAR_ID 23
ENUMERATION 24 1 associate
ENUMERATION 25 2 left right
SOAR_ID 26
ENUMERATION 27 1 print-out-equation
SOAR_ID 28
ENUMERATION 29 1 state
ENUMERATION 30 3 print-left-side print-out-equation print-right-side
ENUMERATION 31 1 print-left-side
SOAR_ID 32
ENUMERATION 33 1 print-right-side
SOAR_ID 34
ENUMERATION 35 1 print-operation
SOAR_ID 36
ENUMERATION 37 1 print-out-equation
ENUMERATION 38 1 print-value
SOAR_ID 39
ENUMERATION 40 1 print-variable
SOAR_ID 41
SOAR_ID 42
STRING 43
STRING 44
STRING 45
STRING 46
STRING 47
SOAR_ID 48
ENUMERATION 49 1 yes
ENUMERATION 50 1 yes
SOAR_ID 51
ENUMERATION 52 1 fail
ENUMERATION 53 1 t
SOAR_ID 54
ENUMERATION 55 1 add-both-sides
INTEGER_RANGE 56 -2147483648 2147483647
ENUMERATION 57 2 divide multiply
ENUMERATION 58 2 number variable
ENUMERATION 59 3 x y z
SOAR_ID 60
ENUMERATION 61 1 multiply-both-sides
ENUMERATION 62 2 add subtract
SOAR_ID 63
INTEGER_RANGE 64 -2147483648 2147483647
STRING 65
SOAR_ID 66
INTEGER_RANGE 67 -2147483648 2147483647
SOAR_ID 68
ENUMERATION 69 1 print-list
ENUMERATION 70 1 print-left-paren
SOAR_ID 71
ENUMERATION 72 2 left-side right-side
ENUMERATION 73 1 print-right-paren
SOAR_ID 74
ENUMERATION 75 6 complete left-paren left-side operation right-paren right-side
SOAR_ID 76
ENUMERATION 77 1 across-level-swap
SOAR_ID 78
ENUMERATION 79 1 state
SOAR_ID 80
ENUMERATION 81 1 convert-subtract-to-add
FLOAT_RANGE 82 -Infinity Infinity
SOAR_ID 83
ENUMERATION 84 1 distribute
SOAR_ID 85
ENUMERATION 86 1 undistribute
STRING 87
SOAR_ID 88
ENUMERATION 89 5 defined failed initialized printed solved
INTEGER_RANGE 90 -2147483648 2147483647
SOAR_ID 91
STRING 92
ENUMERATION 93 5 clause-beginning post-close-bracket post-left post-operation post-right
ENUMERATION 94 1 nil
SOAR_ID 95
ENUMERATION 96 1 true
ENUMERATION 97 1 true
SOAR_ID 98
ENUMERATION 99 1 add-variable-products
SOAR_ID 100
ENUMERATION 101 1 convert-x-1times-x
ENUMERATION 102 1 true
ENUMERATION 103 2 left right
ENUMERATION 104 1 complete
ENUMERATION 105 1 nil
ENUMERATION 106 1 nil
SOAR_ID 107
ENUMERATION 108 1 state
ENUMERATION 109 1 Impasse__State_No-Change
ENUMERATION 110 1 state
SOAR_ID 111
ENUMERATION 112 1 retry
SOAR_ID 113
ENUMERATION 114 1 solve-problem
SOAR_ID 115
ENUMERATION 116 1 state
ENUMERATION 117 1 solve-problem
SOAR_ID 118
ENUMERATION 119 1 swap-sides
SOAR_ID 120
ENUMERATION 121 1 clean-up-problem
SOAR_ID 122
ENUMERATION 123 1 add-local
SOAR_ID 124
ENUMERATION 125 1 next-line
ENUMERATION 126 1 add-variable
SOAR_ID 127
ENUMERATION 128 1 swap-variable-constant
SOAR_ID 129
ENUMERATION 130 1 subtract-variable
SOAR_ID 131
SOAR_ID 132
ENUMERATION 133 6 add-variable-nx-x add-variable-simple add-variable-x-nx subtract-variable-nx-x subtract-variable-simple subtract-variable-x-nx
173
0 added 56
0 current-clause 14
0 io 1
0 name 7
0 operations 42
0 operator 4
0 operator 26
0 operator 68
0 operator 113
0 operator 120
0 print-id 78
0 problem 95
0 processed 88
0 quiescence 53
0 superstate 6
0 top-state 0
0 type 5
1 input-link 2
1 output-link 3
2 text 88
3 text 88
4 name 8
9 clause 14
9 name 10
9 side 72
11 current-clause 14
11 name 13
11 superstate 115
11 top-state 0
11 type 12
14 dont-multiply 102
14 failed 50
14 left-side 14
14 operation 15
14 parent-clause 14
14 parent-clause 105
14 parse-status 93
14 print 48
14 right-side 14
14 swapped 49
14 type 58
14 value 16
14 value 59
14 value 82
17 name 18
19 name 20
19 operator 21
21 name 22
23 name 24
23 side 25
26 clause 14
26 name 27
26 print-id 78
28 attribute 79
28 current-clause 14
28 name 30
28 operator 32
28 operator 34
28 operator 36
28 operator 39
28 operator 41
28 operator 71
28 operator 74
28 print-id 78
28 quiescence 53
28 superstate 0
28 top-state 0
28 type 29
28 type 37
32 clause 14
32 name 31
32 print-id 48
34 clause 14
34 name 33
34 print-id 48
36 name 35
39 name 38
41 name 40
42 add 43
42 divide 45
42 equal 47
42 multiply 46
42 subtract 44
48 flag 75
48 print-id 78
51 name 52
54 name 55
54 new-item 14
54 new-structure 14
54 operation 62
60 name 61
60 new-item 14
60 operation 57
63 next 63
63 value 65
63 value 64
66 count 67
66 next 63
66 pointer 66
66 printed 48
66 value 87
68 name 69
68 problem-list 66
71 name 70
74 name 73
76 name 77
80 name 81
83 name 84
85 name 86
85 side 103
85 type 58
88 get 125
88 next 91
88 status 104
88 text-input-number 90
91 next 91
91 value 92
91 value 106
95 clauses 122
95 current-input-value 94
95 current-input-value 91
95 failed 96
95 parse-clause 14
95 problem-list 66
95 request-printed 97
95 status 89
95 top-clause 14
98 name 99
100 name 101
107 attribute 110
107 name 109
107 quiescence 53
107 superstate 115
107 top-state 0
107 type 108
111 clause 14
111 name 112
113 name 114
115 current-clause 14
115 name 117
115 operator 9
115 operator 23
115 operator 54
115 operator 60
115 operator 51
115 operator 76
115 operator 80
115 operator 83
115 operator 85
115 operator 98
115 operator 100
115 operator 111
115 operator 17
115 operator 118
115 operator 19
115 operator 124
115 operator 127
115 operator 129
115 operator 131
115 operator 132
115 problem 95
115 quiescence 53
115 superstate 0
115 top-state 0
115 type 116
118 name 119
120 name 121
122 clause 14
124 name 123
127 name 126
129 name 128
131 name 130
132 name 133
