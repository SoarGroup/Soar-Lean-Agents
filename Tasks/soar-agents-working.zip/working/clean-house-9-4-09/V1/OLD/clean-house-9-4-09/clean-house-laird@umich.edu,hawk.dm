361
SOAR_ID 0
SOAR_ID 1
SOAR_ID 2
SOAR_ID 3
ENUMERATION 4 2 goto-area state
ENUMERATION 5 1 nil
ENUMERATION 6 3 accepted complete error
SOAR_ID 7
STRING 8
ENUMERATION 9 2 operator state
ENUMERATION 10 2 multiple none
ENUMERATION 11 2 no-change tie
ENUMERATION 12 2 evaluate-operator robot
SOAR_ID 13
ENUMERATION 14 1 wait
SOAR_ID 15
SOAR_ID 16
SOAR_ID 17
INTEGER_RANGE 18 0 2147483647
SOAR_ID 19
INTEGER_RANGE 20 0 2147483647
INTEGER_RANGE 21 0 2147483647
SOAR_ID 22
INTEGER_RANGE 23 0 2147483647
INTEGER_RANGE 24 0 2147483647
FLOAT_RANGE 25 0.0 Infinity
FLOAT_RANGE 26 0.0 Infinity
ENUMERATION 27 4 east north south west
SOAR_ID 28
FLOAT_RANGE 29 0.0 Infinity
FLOAT_RANGE 30 0.0 Infinity
INTEGER_RANGE 31 0 2147483647
SOAR_ID 32
ENUMERATION 33 2 false true
ENUMERATION 34 2 false true
FLOAT_RANGE 35 0.0 Infinity
FLOAT_RANGE 36 0.0 Infinity
SOAR_ID 37
FLOAT_RANGE 38 -180.0 180.0
ENUMERATION 39 4 accepted complete error interrupted
ENUMERATION 40 2 complete error
INTEGER_RANGE 41 -2147483648 2147483647
ENUMERATION 42 4 east north south west
SOAR_ID 43
INTEGER_RANGE 44 -2147483648 2147483647
ENUMERATION 45 1 block
SOAR_ID 46
INTEGER_RANGE 47 -2147483648 2147483647
INTEGER_RANGE 48 -2147483648 2147483647
ENUMERATION 49 1 block
FLOAT_RANGE 50 -Infinity Infinity
ENUMERATION 51 2 no yes
FLOAT_RANGE 52 -Infinity Infinity
FLOAT_RANGE 53 -Infinity Infinity
SOAR_ID 54
SOAR_ID 55
INTEGER_RANGE 56 -2147483648 2147483647
INTEGER_RANGE 57 -2147483648 2147483647
ENUMERATION 58 2 complete error
ENUMERATION 59 2 complete error
SOAR_ID 60
ENUMERATION 61 1 grasp-block
SOAR_ID 62
FLOAT_RANGE 63 -Infinity Infinity
SOAR_ID 64
ENUMERATION 65 1 stop
SOAR_ID 66
ENUMERATION 67 1 state
INTEGER_RANGE 68 -2147483648 2147483647
SOAR_ID 69
ENUMERATION 70 1 pickup-block
INTEGER_RANGE 71 -2147483648 2147483647
ENUMERATION 72 1 pickup-block
ENUMERATION 73 1 spin
SOAR_ID 74
SOAR_ID 75
ENUMERATION 76 1 find-block-in-area
SOAR_ID 77
ENUMERATION 78 1 record-area
SOAR_ID 79
ENUMERATION 80 1 init-robot
SOAR_ID 81
INTEGER_RANGE 82 -2147483648 2147483647
SOAR_ID 83
ENUMERATION 84 1 state
ENUMERATION 85 1 find-block-in-area
ENUMERATION 86 1 record-area-direction
SOAR_ID 87
ENUMERATION 88 4 east north south west
ENUMERATION 89 4 east north south west
ENUMERATION 90 1 spin
SOAR_ID 91
ENUMERATION 92 1 note-turning
SOAR_ID 93
SOAR_ID 94
ENUMERATION 95 1 stop-spin
SOAR_ID 96
ENUMERATION 97 1 yes
SOAR_ID 98
SOAR_ID 99
ENUMERATION 100 1 goto-unvisited-area
FLOAT_RANGE 101 -Infinity Infinity
ENUMERATION 102 1 yes
SOAR_ID 103
ENUMERATION 104 1 get-block
SOAR_ID 105
ENUMERATION 106 1 state
ENUMERATION 107 1 get-block
ENUMERATION 108 1 goto-not-clean-area
SOAR_ID 109
SOAR_ID 110
ENUMERATION 111 1 deposit-block
SOAR_ID 112
ENUMERATION 113 1 finished-cleaning
INTEGER_RANGE 114 -2147483648 2147483647
SOAR_ID 115
ENUMERATION 116 1 state
ENUMERATION 117 1 deposit-block
ENUMERATION 118 1 goto-storage-area
SOAR_ID 119
ENUMERATION 120 1 move-to-wall
SOAR_ID 121
ENUMERATION 122 2 go-to-area goto-area
ENUMERATION 123 1 go-to-area
ENUMERATION 124 4 east north south west
SOAR_ID 125
ENUMERATION 126 1 state
ENUMERATION 127 1 move-to-wall
ENUMERATION 128 1 turn-to-wall
SOAR_ID 129
ENUMERATION 130 1 move-forward
SOAR_ID 131
ENUMERATION 132 2 false true
ENUMERATION 133 1 drop-block
SOAR_ID 134
INTEGER_RANGE 135 -2147483648 2147483647
SOAR_ID 136
ENUMERATION 137 1 clean-house
SOAR_ID 138
STRING 139
ENUMERATION 140 2 no yes
SOAR_ID 141
ENUMERATION 142 1 state
ENUMERATION 143 2 Impasse__Operator_Tie selection
ENUMERATION 144 1 evaluate-operator
SOAR_ID 145
SOAR_ID 146
ENUMERATION 147 1 state
ENUMERATION 148 1 evaluate-operator
ENUMERATION 149 1 go-to-next-area
SOAR_ID 150
ENUMERATION 151 1 turn-from-block
SOAR_ID 152
SOAR_ID 153
ENUMERATION 154 1 record-block
SOAR_ID 155
SOAR_ID 156
SOAR_ID 157
INTEGER_RANGE 158 -2147483648 2147483647
INTEGER_RANGE 159 -2147483648 2147483647
INTEGER_RANGE 160 -2147483648 2147483647
ENUMERATION 161 1 yes
ENUMERATION 162 1 detect-no-storage-area
SOAR_ID 163
ENUMERATION 164 1 t
ENUMERATION 165 1 t
ENUMERATION 166 1 tie
FLOAT_RANGE 167 -Infinity Infinity
ENUMERATION 168 2 no yes
FLOAT_RANGE 169 -Infinity Infinity
FLOAT_RANGE 170 -Infinity Infinity
SOAR_ID 171
ENUMERATION 172 1 chase
SOAR_ID 173
ENUMERATION 174 1 state
ENUMERATION 175 1 chase
ENUMERATION 176 1 move-to-player
SOAR_ID 177
SOAR_ID 178
ENUMERATION 179 1 record-unconnected-area
SOAR_ID 180
ENUMERATION 181 2 no yes
SOAR_ID 182
INTEGER_RANGE 183 -2147483648 2147483647
INTEGER_RANGE 184 -2147483648 2147483647
STRING 185
SOAR_ID 186
INTEGER_RANGE 187 -180 180
SOAR_ID 188
FLOAT_RANGE 189 -Infinity Infinity
ENUMERATION 190 4 ball block brick player
STRING 191
INTEGER_RANGE 192 -2147483648 2147483647
SOAR_ID 193
FLOAT_RANGE 194 -180.0 180.0
FLOAT_RANGE 195 -0.5 0.5
SOAR_ID 196
SOAR_ID 197
STRING 198
FLOAT_RANGE 199 -Infinity Infinity
FLOAT_RANGE 200 -Infinity Infinity
SOAR_ID 201
SOAR_ID 202
SOAR_ID 203
STRING 204
STRING 205
SOAR_ID 206
SOAR_ID 207
ENUMERATION 208 1 nil
SOAR_ID 209
STRING 210
SOAR_ID 211
SOAR_ID 212
STRING 213
FLOAT_RANGE 214 -Infinity Infinity
FLOAT_RANGE 215 -Infinity Infinity
FLOAT_RANGE 216 -Infinity Infinity
FLOAT_RANGE 217 -Infinity Infinity
FLOAT_RANGE 218 -Infinity Infinity
FLOAT_RANGE 219 -Infinity Infinity
FLOAT_RANGE 220 -Infinity Infinity
FLOAT_RANGE 221 -Infinity Infinity
FLOAT_RANGE 222 -Infinity Infinity
FLOAT_RANGE 223 -Infinity Infinity
FLOAT_RANGE 224 -Infinity Infinity
FLOAT_RANGE 225 -Infinity Infinity
FLOAT_RANGE 226 -Infinity Infinity
FLOAT_RANGE 227 -Infinity Infinity
FLOAT_RANGE 228 -Infinity Infinity
FLOAT_RANGE 229 -Infinity Infinity
FLOAT_RANGE 230 -Infinity Infinity
FLOAT_RANGE 231 -Infinity Infinity
ENUMERATION 232 1 go-to
SOAR_ID 233
SOAR_ID 234
ENUMERATION 235 1 state
ENUMERATION 236 1 go-to
ENUMERATION 237 1 set-waypoint
SOAR_ID 238
ENUMERATION 239 1 abandon-waypoint
SOAR_ID 240
ENUMERATION 241 1 initialize-progress
SOAR_ID 242
ENUMERATION 243 1 record-progress
SOAR_ID 244
ENUMERATION 245 1 turn-to-waypoint
SOAR_ID 246
ENUMERATION 247 1 move-forward
SOAR_ID 248
ENUMERATION 249 2 false true
FLOAT_RANGE 250 -Infinity Infinity
FLOAT_RANGE 251 -Infinity Infinity
SOAR_ID 252
INTEGER_RANGE 253 0 2147483647
FLOAT_RANGE 254 0.0 Infinity
FLOAT_RANGE 255 0.0 Infinity
FLOAT_RANGE 256 -Infinity Infinity
FLOAT_RANGE 257 -Infinity Infinity
FLOAT_RANGE 258 -Infinity Infinity
FLOAT_RANGE 259 -Infinity Infinity
FLOAT_RANGE 260 -Infinity Infinity
FLOAT_RANGE 261 -Infinity Infinity
FLOAT_RANGE 262 -Infinity Infinity
SOAR_ID 263
ENUMERATION 264 2 immediate true
ENUMERATION 265 2 false true
SOAR_ID 266
INTEGER_RANGE 267 0 2147483647
FLOAT_RANGE 268 0.0 Infinity
FLOAT_RANGE 269 0.0 Infinity
FLOAT_RANGE 270 -Infinity Infinity
FLOAT_RANGE 271 -Infinity Infinity
FLOAT_RANGE 272 -Infinity Infinity
FLOAT_RANGE 273 -Infinity Infinity
ENUMERATION 274 2 smem wm
ENUMERATION 275 2 smem wm
SOAR_ID 276
ENUMERATION 277 1 record-smem-current-area
FLOAT_RANGE 278 -Infinity Infinity
INTEGER_RANGE 279 -2147483648 2147483647
INTEGER_RANGE 280 -2147483648 2147483647
INTEGER_RANGE 281 -2147483648 2147483647
FLOAT_RANGE 282 -Infinity Infinity
FLOAT_RANGE 283 -Infinity Infinity
SOAR_ID 284
SOAR_ID 285
SOAR_ID 286
ENUMERATION 287 2 failure success
ENUMERATION 288 1 yes
ENUMERATION 289 1 yes
SOAR_ID 290
ENUMERATION 291 1 yes
INTEGER_RANGE 292 -2147483648 2147483647
FLOAT_RANGE 293 -Infinity Infinity
FLOAT_RANGE 294 -Infinity Infinity
ENUMERATION 295 2 no yes
ENUMERATION 296 1 go-to
SOAR_ID 297
FLOAT_RANGE 298 -Infinity Infinity
ENUMERATION 299 2 no yes
FLOAT_RANGE 300 -Infinity Infinity
ENUMERATION 301 1 yes
ENUMERATION 302 2 no yes
ENUMERATION 303 1 go-to-area
SOAR_ID 304
SOAR_ID 305
ENUMERATION 306 2 go-to-area state
ENUMERATION 307 2 evaluate-operator go-to-area
ENUMERATION 308 1 go-to
SOAR_ID 309
ENUMERATION 310 1 go-to-next-area
SOAR_ID 311
SOAR_ID 312
ENUMERATION 313 1 state
ENUMERATION 314 1 go-to-next-area
ENUMERATION 315 1 go-to
SOAR_ID 316
INTEGER_RANGE 317 -2147483648 2147483647
SOAR_ID 318
STRING 319
ENUMERATION 320 1 yes
ENUMERATION 321 1 top-state
ENUMERATION 322 2 door room
ENUMERATION 323 2 door room
ENUMERATION 324 1 yes
ENUMERATION 325 1 yes
ENUMERATION 326 1 yes
SOAR_ID 327
ENUMERATION 328 1 turn-through-doorway
SOAR_ID 329
INTEGER_RANGE 330 -2147483648 2147483647
SOAR_ID 331
INTEGER_RANGE 332 -2147483648 2147483647
INTEGER_RANGE 333 -2147483648 2147483647
INTEGER_RANGE 334 -2147483648 2147483647
ENUMERATION 335 1 go-to-seen-block
SOAR_ID 336
ENUMERATION 337 4 east north south west
FLOAT_RANGE 338 -Infinity Infinity
ENUMERATION 339 2 destination-area type
SOAR_ID 340
FLOAT_RANGE 341 -Infinity Infinity
INTEGER_RANGE 342 -2147483648 2147483647
INTEGER_RANGE 343 -2147483648 2147483647
FLOAT_RANGE 344 -Infinity Infinity
FLOAT_RANGE 345 -Infinity Infinity
SOAR_ID 346
ENUMERATION 347 1 record-smem-new-gateway-area
ENUMERATION 348 2 no yes
SOAR_ID 349
ENUMERATION 350 1 retrieve-current-area-walls
SOAR_ID 351
ENUMERATION 352 1 retrieve-current-area-gateways
SOAR_ID 353
SOAR_ID 354
SOAR_ID 355
SOAR_ID 356
SOAR_ID 357
SOAR_ID 358
SOAR_ID 359
SOAR_ID 360
470
0 areas 98
0 attribute 9
0 blocks 155
0 choices 10
0 current-location 81
0 desired 138
0 destination-waypoint 263
0 direction 89
0 directions 94
0 epmem 353
0 gateway-directions 327
0 impasse 11
0 io 1
0 name 12
0 no-storage-area 161
0 numbers 156
0 operator 13
0 operator 77
0 operator 79
0 operator 99
0 operator 103
0 operator 110
0 operator 112
0 operator 153
0 operator 171
0 operator 178
0 operator 233
0 operator 276
0 operator 304
0 operator 346
0 operator 349
0 operator 351
0 parameters 62
0 path-cost 338
0 problem-space 136
0 quiescence 165
0 smem 284
0 superstate 5
0 superstate 0
0 tight-direction 89
0 top-state 0
0 type 4
1 input-link 2
1 output-link 3
2 area-description 16
2 object 180
2 self 15
2 time 182
3 add-waypoint 197
3 clear-message 211
3 configure 212
3 disable-waypoint 202
3 drop-object 55
3 enable-waypoint 202
3 estop 196
3 get-object 54
3 remove-message 209
3 remove-waypoint 201
3 send-message 203
3 set-heading 37
3 set-heading-linear 290
3 set-velocity 193
3 stop 196
3 stop-sim 7
7 status 40
7 true 8
13 actions 3
13 name 14
15 area 41
15 carry 43
15 collision 32
15 name 185
15 pose 186
15 stopped 302
15 waypoints 188
16 gateway 28
16 id 192
16 type 323
16 wall 17
17 direction 27
17 id 18
17 left 19
17 right 22
17 stored 289
17 x 25
17 y 26
17 yaw 169
19 col 20
19 row 21
22 col 24
22 row 23
28 connected 348
28 direction 42
28 id 31
28 range 101
28 stored 288
28 to 292
28 x 29
28 y 30
28 yaw 170
32 x 34
32 y 33
37 status 39
37 yaw 38
43 id 44
43 type 45
46 area 47
46 id 48
46 range 50
46 type 49
46 visible 51
46 x 52
46 y 53
46 yaw 167
54 id 57
54 status 58
55 id 56
55 status 59
60 actions 3
60 name 61
62 areas-held-in 274
62 high-angular-velocity 218
62 high-linear-velocity 218
62 low-angular-velocity 216
62 low-linear-velocity 216
62 max-angular-distance 250
62 medium-angular-velocity 217
62 medium-linear-velocity 217
62 message-update-time 279
62 min-angular-distance 251
62 min-progress-distance 259
62 objects-held-in 275
62 pickup-range 63
62 progress-update-time 260
62 range-tolerance 280
62 rotation-tolerance 281
62 waypoint-tolerance 278
64 actions 3
64 name 65
66 block-id 68
66 io 1
66 name 72
66 object 180
66 object-in-range-lined-up 295
66 object-lined-up 168
66 operator 60
66 operator 74
66 operator 297
66 quiescence 165
66 stopped 301
66 superstate 105
66 top-state 0
66 type 67
69 id 71
69 name 70
74 name 73
75 name 76
77 area 81
77 name 78
79 name 80
81 cleaned 102
81 gateway 28
81 gateway-x 342
81 gateway-y 343
81 id 82
81 neighbor-area 81
81 next 81
81 previous-area 81
81 search-start-direction 88
81 turning 291
81 type 322
81 visited 97
81 wall 17
81 x 293
81 y 294
83 current-location 81
83 io 1
83 name 85
83 operator 87
83 operator 91
83 operator 93
83 operator 96
83 quiescence 165
83 superstate 105
83 top-state 0
83 type 84
87 name 86
91 actions 3
91 name 90
93 name 92
94 ene 224
94 ese 227
94 ne 219
94 nne 223
94 nnw 225
94 nw 220
94 opposite 337
94 se 221
94 sse 228
94 ssw 230
94 sw 222
94 value 337
94 wnw 226
94 wsw 229
96 name 95
98 area 81
99 area 81
99 name 100
99 type 122
103 name 104
105 current-location 81
105 epmem 353
105 io 1
105 name 107
105 operator 109
105 operator 69
105 operator 75
105 operator 336
105 quiescence 165
105 superstate 0
105 top-state 0
105 type 106
109 area 81
109 name 108
109 type 123
110 name 111
112 name 113
115 current-location 81
115 io 1
115 name 117
115 operator 119
115 operator 121
115 operator 163
115 quiescence 165
115 superstate 0
115 top-state 0
115 type 116
119 area 81
119 name 118
119 type 123
121 name 120
121 wall-direction 124
125 collision 132
125 collision-distance 135
125 io 1
125 name 127
125 operator 129
125 operator 131
125 operator 134
125 operator 152
125 quiescence 164
125 superstate 115
125 top-state 0
125 type 126
129 name 128
131 name 130
134 actions 3
134 name 133
136 default-state-copy 140
136 name 137
136 one-level-attributes 139
138 location 81
138 storage-area-id 114
141 evaluation 340
141 impasse 166
141 name 143
141 operator 145
141 quiescence 165
141 superstate 0
141 top-state 0
141 type 142
145 name 144
146 current-location 81
146 desired 138
146 destination-area 81
146 failure 138
146 indifferent 138
146 name 148
146 operator 150
146 partial-failure 138
146 quiescence 165
146 success 138
146 superstate 141
146 top-state 0
146 type 147
146 visited-area 81
150 name 149
150 next-waypoint 28
152 name 151
153 block 46
153 name 154
155 block 46
156 number 157
157 one-less 160
157 one-more 159
157 value 158
163 name 162
171 name 172
171 player 180
173 io 1
173 name 175
173 operator 177
173 superstate 0
173 top-state 0
173 type 174
177 actions 3
177 name 176
178 name 179
180 abs-relative-bearing 283
180 distance 101
180 id 31
180 name 191
180 relative-bearing 282
180 type 190
180 visible 181
180 x 29
180 y 30
180 yaw 231
182 microseconds 184
182 seconds 183
186 x 35
186 x-velocity 189
186 y 36
186 y-velocity 189
186 yaw 187
186 yaw-velocity 189
186 z 35
188 waypoint 266
193 angular-velocity 194
193 linear-velocity 195
193 status 6
196 status 39
197 id 198
197 status 39
197 x 199
197 y 200
201 id 198
201 status 39
202 id 198
202 status 39
203 destination 204
203 first 206
203 next 206
203 status 39
203 word 205
206 next 207
206 next 208
209 id 210
209 status 39
211 status 39
212 offset-x 214
212 offset-y 215
212 status 39
212 yaw-format 213
233 cross-doorway 326
233 destination 28
233 name 232
233 range 300
234 cross-doorway 325
234 destination 252
234 destination-in-range 299
234 name 236
234 operator 238
234 operator 240
234 operator 242
234 operator 244
234 operator 246
234 operator 248
234 operator 64
234 operator 329
234 set-waypoint 265
234 superstate 0
234 top-state 0
234 type 235
234 waypoint-data 266
234 yaw-aligned 249
238 name 237
240 name 239
242 name 241
244 name 243
246 actions 3
246 name 245
248 actions 3
248 name 247
252 distance 257
252 id 253
252 x 254
252 y 255
252 yaw 256
263 give-up 264
263 last-distance 261
263 next-update-time 258
263 progress 262
263 waypoint 252
266 abs-relative-bearing 273
266 distance 271
266 id 267
266 relative-bearing 272
266 x 268
266 y 269
266 yaw 270
276 name 277
284 command 285
284 result 286
285 query 81
285 retrieve 81
285 store 81
286 retrieved 81
286 status 287
290 linear-velocity 195
290 status 39
290 yaw 38
297 destination 180
297 name 296
297 range 298
304 name 303
305 current-location 81
305 desired 138
305 destination-area 81
305 name 307
305 operator 309
305 operator 311
305 problem-space 318
305 superstate 0
305 top-state 0
305 type 306
309 cross-doorway 324
309 destination 81
309 gateway-area-id 330
309 name 308
311 name 310
311 next-waypoint 81
312 name 314
312 operator 316
312 superstate 305
312 top-state 0
312 type 313
316 destination 28
316 gateway-area-id 317
316 name 315
318 default-state-copy 320
318 name 319
318 one-level-attributes 339
318 two-level-attributes 321
327 east 331
327 north 331
327 south 331
327 west 331
329 name 328
331 max 334
331 min 333
331 value 332
336 name 335
340 current-location 81
340 estimated-cost 345
340 path-cost 341
340 total-estimated-cost 344
346 gateway 28
346 name 347
349 name 350
349 wall 17
351 gateway 28
351 name 352
353 command 354
353 result 357
354 neg-query 355
354 query 356
357 failure 360
357 retrieved 358
357 success 359
