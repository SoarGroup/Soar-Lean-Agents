220
SOAR_ID 0
SOAR_ID 1
SOAR_ID 2
SOAR_ID 3
SOAR_ID 4
ENUMERATION 5 1 state
ENUMERATION 6 1 nil
ENUMERATION 7 1 cozmo
ENUMERATION 8 1 initialize-cozmo
SOAR_ID 9
ENUMERATION 10 1 move-to
SOAR_ID 11
ENUMERATION 12 1 find-item
SOAR_ID 13
ENUMERATION 14 1 pickup-cube
SOAR_ID 15
ENUMERATION 16 1 put-down
SOAR_ID 17
ENUMERATION 18 1 record-led-cube
SOAR_ID 19
ENUMERATION 20 1 record-original-location
SOAR_ID 21
ENUMERATION 22 1 state
ENUMERATION 23 1 move-to
ENUMERATION 24 1 move-forward
SOAR_ID 25
ENUMERATION 26 1 turn-to-object
SOAR_ID 27
SOAR_ID 28
ENUMERATION 29 1 color-cube
SOAR_ID 30
ENUMERATION 31 1 record-object
SOAR_ID 32
ENUMERATION 33 1 find-item
ENUMERATION 34 1 init-turn
SOAR_ID 35
ENUMERATION 36 1 turn
SOAR_ID 37
ENUMERATION 38 1 increment-turn
SOAR_ID 39
ENUMERATION 40 1 add-turn-counter
SOAR_ID 41
SOAR_ID 42
ENUMERATION 43 1 update-object-position
SOAR_ID 44
ENUMERATION 45 1 update-dropped-object
SOAR_ID 46
ENUMERATION 47 1 find-object
SOAR_ID 48
ENUMERATION 49 1 wait
SOAR_ID 50
ENUMERATION 51 1 stack-cube
SOAR_ID 52
ENUMERATION 53 1 state
ENUMERATION 54 1 stack-cube
ENUMERATION 55 1 find-item
SOAR_ID 56
ENUMERATION 57 1 pickup-cube
SOAR_ID 58
ENUMERATION 59 1 move-to
SOAR_ID 60
ENUMERATION 61 1 place-object-on
SOAR_ID 62
ENUMERATION 63 1 select-cube
SOAR_ID 64
SOAR_ID 65
ENUMERATION 66 1 state
ENUMERATION 67 1 find-object
ENUMERATION 68 1 select-object
SOAR_ID 69
SOAR_ID 70
ENUMERATION 71 1 update-cube-position
SOAR_ID 72
ENUMERATION 73 1 center-head
ENUMERATION 74 1 select-object
SOAR_ID 75
SOAR_ID 76
ENUMERATION 77 1 store-cubes
SOAR_ID 78
ENUMERATION 79 1 state
ENUMERATION 80 1 store-cubes
ENUMERATION 81 1 search-for-unstored-cube
SOAR_ID 82
SOAR_ID 83
ENUMERATION 84 1 state
ENUMERATION 85 1 search-for-unstored-cube
ENUMERATION 86 1 find-item
SOAR_ID 87
ENUMERATION 88 1 failed-find
SOAR_ID 89
ENUMERATION 90 1 search-for-storage-object
SOAR_ID 91
ENUMERATION 92 1 put-down
SOAR_ID 93
ENUMERATION 94 1 finish-store-cube
SOAR_ID 95
SOAR_ID 96
ENUMERATION 97 1 state
ENUMERATION 98 2 search-for-storage-object search-for-unstored-cube
ENUMERATION 99 1 find-item
SOAR_ID 100
SOAR_ID 101
FLOAT_RANGE 102 -Infinity Infinity
FLOAT_RANGE 103 -Infinity Infinity
FLOAT_RANGE 104 -Infinity Infinity
SOAR_ID 105
FLOAT_RANGE 106 -Infinity Infinity
FLOAT_RANGE 107 -Infinity Infinity
ENUMERATION 108 2 false true
ENUMERATION 109 2 false true
ENUMERATION 110 2 false true
ENUMERATION 111 1 collect-cubes
SOAR_ID 112
SOAR_ID 113
SOAR_ID 114
ENUMERATION 115 1 nil
SOAR_ID 116
ENUMERATION 117 8 blue green nil orange purple red white yellow
ENUMERATION 118 1 True
INTEGER_RANGE 119 -2147483648 2147483647
STRING 120
INTEGER_RANGE 121 -2147483648 2147483647
ENUMERATION 122 2 False True
INTEGER_RANGE 123 -2147483648 2147483647
ENUMERATION 124 1 led-cube
FLOAT_RANGE 125 -Infinity Infinity
INTEGER_RANGE 126 -2147483648 2147483647
INTEGER_RANGE 127 -2147483648 2147483647
INTEGER_RANGE 128 -2147483648 2147483647
INTEGER_RANGE 129 -2147483648 2147483647
INTEGER_RANGE 130 -2147483648 2147483647
FLOAT_RANGE 131 -Infinity Infinity
SOAR_ID 132
FLOAT_RANGE 133 -Infinity Infinity
FLOAT_RANGE 134 -Infinity Infinity
FLOAT_RANGE 135 -Infinity Infinity
INTEGER_RANGE 136 -2147483648 2147483647
INTEGER_RANGE 137 -2147483648 2147483647
INTEGER_RANGE 138 -2147483648 2147483647
STRING 139
SOAR_ID 140
INTEGER_RANGE 141 -2147483648 2147483647
INTEGER_RANGE 142 -2147483648 2147483647
SOAR_ID 143
FLOAT_RANGE 144 -Infinity Infinity
STRING 145
SOAR_ID 146
SOAR_ID 147
ENUMERATION 148 1 complete
ENUMERATION 149 1 nil
ENUMERATION 150 1 nil
SOAR_ID 151
SOAR_ID 152
ENUMERATION 153 2 complete running
INTEGER_RANGE 154 -2147483648 2147483647
SOAR_ID 155
SOAR_ID 156
ENUMERATION 157 1 true
SOAR_ID 158
SOAR_ID 159
SOAR_ID 160
STRING 161
FLOAT_RANGE 162 -Infinity Infinity
FLOAT_RANGE 163 -Infinity Infinity
FLOAT_RANGE 164 -Infinity Infinity
FLOAT_RANGE 165 -Infinity Infinity
FLOAT_RANGE 166 -Infinity Infinity
FLOAT_RANGE 167 -Infinity Infinity
FLOAT_RANGE 168 -Infinity Infinity
FLOAT_RANGE 169 -Infinity Infinity
INTEGER_RANGE 170 -2147483648 2147483647
INTEGER_RANGE 171 -2147483648 2147483647
SOAR_ID 172
SOAR_ID 173
ENUMERATION 174 1 evaluate-operator
STRING 175
STRING 176
STRING 177
STRING 178
INTEGER_RANGE 179 -2147483648 2147483647
ENUMERATION 180 1 true
SOAR_ID 181
SOAR_ID 182
ENUMERATION 183 1 complete
INTEGER_RANGE 184 -2147483648 2147483647
INTEGER_RANGE 185 -2147483648 2147483647
ENUMERATION 186 1 original-location
ENUMERATION 187 1 true
SOAR_ID 188
SOAR_ID 189
ENUMERATION 190 2 complete running
INTEGER_RANGE 191 -2147483648 2147483647
INTEGER_RANGE 192 -2147483648 2147483647
INTEGER_RANGE 193 -2147483648 2147483647
ENUMERATION 194 1 true
FLOAT_RANGE 195 -Infinity Infinity
SOAR_ID 196
SOAR_ID 197
ENUMERATION 198 2 complete running
INTEGER_RANGE 199 -2147483648 2147483647
INTEGER_RANGE 200 -2147483648 2147483647
ENUMERATION 201 1 true
ENUMERATION 202 2 picked-up stacked
ENUMERATION 203 2 cube object
SOAR_ID 204
SOAR_ID 205
ENUMERATION 206 1 complete
SOAR_ID 207
ENUMERATION 208 1 pickup-cube
ENUMERATION 209 2 cube object
ENUMERATION 210 1 not-stored
ENUMERATION 211 1 true
ENUMERATION 212 1 failed-find
SOAR_ID 213
ENUMERATION 214 1 true
INTEGER_RANGE 215 -2147483648 2147483647
ENUMERATION 216 1 stack
SOAR_ID 217
ENUMERATION 218 1 turn-to-seen-item
SOAR_ID 219
280
0 cube 105
0 current-cube 105
0 current-cube 149
0 current-object 105
0 current-object 150
0 current-task 111
0 epmem 112
0 failed-find 180
0 io 1
0 name 7
0 object 105
0 operator 4
0 operator 9
0 operator 11
0 operator 13
0 operator 15
0 operator 17
0 operator 19
0 operator 28
0 operator 30
0 operator 42
0 operator 44
0 operator 46
0 operator 48
0 operator 50
0 operator 70
0 operator 72
0 operator 76
0 operator 173
0 original-location 101
0 reward-link 113
0 smem 114
0 storage-location 101
0 stored-cubes 115
0 stored-cubes 116
0 superstate 6
0 superstate 0
0 time-delay 169
0 top-state 0
0 type 5
0 unplaced-cubes 110
1 input-link 2
1 output-link 3
2 battery-voltage 125
2 carrying-block 126
2 carrying-object-id 127
2 charging 128
2 cliff-detected 129
2 face-count 130
2 head-angle 131
2 lift 132
2 object 105
2 object-count 136
2 picked-up 137
2 pose 101
2 robot-id 138
2 serial 139
2 time 140
3 change-block-color 155
3 drive-forward 172
3 move-head 143
3 pick-up-object 156
3 place-object-down 160
3 turn-in-place 182
4 name 8
9 desired-location 101
9 name 10
9 type 186
11 color 178
11 name 12
11 subtype 177
11 type 176
13 actions 151
13 cube 105
13 name 14
15 actions 158
15 name 16
17 name 18
17 object 105
19 name 20
19 pose 101
21 desired-location 101
21 name 23
21 operator 25
21 operator 27
21 operator 39
21 superstate 0
21 top-state 0
21 type 22
25 actions 188
25 name 24
27 actions 196
27 name 26
28 actions 146
28 color 145
28 name 29
30 name 31
30 object 105
32 color 178
32 io 1
32 name 33
32 operator 35
32 operator 37
32 operator 41
32 operator 64
32 operator 75
32 operator 89
32 subtype 177
32 superstate 0
32 top-state 0
32 turn-count 179
32 turned 179
32 type 176
35 name 34
37 actions 181
37 name 36
39 name 38
41 name 40
41 turned 179
42 name 43
42 recorded-object 105
42 sensed-object 105
44 name 45
46 name 47
48 minutes 171
48 name 49
48 seconds 170
50 name 51
52 base-cube 105
52 base-cube-color 117
52 current-cube 105
52 name 54
52 operator 56
52 operator 58
52 operator 60
52 operator 62
52 superstate 0
52 top-cube 105
52 top-cube-color 117
52 top-state 0
52 type 53
56 color 117
56 name 55
56 type 203
58 name 57
60 cube 105
60 name 59
62 actions 204
62 base-cube 105
62 name 61
64 cube 105
64 name 63
65 name 67
65 operator 69
65 superstate 0
65 top-state 0
65 type 66
65 type 176
69 name 68
69 object 105
70 name 71
70 recorded-cube 105
70 sensed-cube 105
72 name 73
75 name 74
75 object 105
76 name 77
78 current-cube 105
78 io 1
78 name 80
78 operator 82
78 operator 91
78 operator 93
78 operator 95
78 operator 9
78 operator 207
78 operator 217
78 operator 219
78 superstate 0
78 top-state 0
78 type 79
82 name 81
83 failed-find 211
83 name 85
83 operator 87
83 superstate 78
83 top-state 0
83 type 84
87 name 86
87 subtype 210
87 type 209
89 name 88
91 name 90
93 name 92
95 name 94
96 failed-find 211
96 name 98
96 operator 100
96 operator 213
96 superstate 78
96 top-state 0
96 type 97
100 name 99
100 type 209
101 aligned 201
101 close 187
101 distance 193
101 facing 194
101 heading 195
101 rot 104
101 x 102
101 x-max 164
101 x-min 163
101 y 103
101 y-max 166
101 y-min 165
101 z 162
101 z-max 168
101 z-min 167
105 aligned 214
105 close 109
105 color 117
105 connected 118
105 cube-id 119
105 descriptive-name 120
105 distance 107
105 facing 108
105 heading 106
105 last-tapped 161
105 liftable 121
105 moving 122
105 name 175
105 object-id 123
105 picked-up 157
105 pose 101
105 status 202
105 storage-distance 215
105 type 124
116 item 105
132 angle 133
132 height 134
132 ratio 135
140 seconds 141
140 steps 142
143 angle 144
143 status 153
146 change-block-color 147
147 color 145
147 object-id 123
147 status 148
151 pick-up-object 152
152 object-id 154
152 status 153
155 status 153
156 status 153
158 place-object-down 159
159 status 153
160 status 153
172 status 153
173 name 174
181 turn-in-place 182
182 angle 184
182 speed 185
182 status 183
188 drive-forward 189
189 distance 191
189 speed 192
189 status 190
196 turn-in-place 197
197 angle 200
197 speed 199
197 status 198
204 place-object-on 205
205 object-id 123
205 status 206
207 cube 105
207 name 208
213 name 212
217 name 216
219 name 218
