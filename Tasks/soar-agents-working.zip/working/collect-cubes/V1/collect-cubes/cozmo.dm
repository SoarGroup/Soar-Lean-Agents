87
SOAR_ID 0
SOAR_ID 1
SOAR_ID 2
SOAR_ID 3
SOAR_ID 4
ENUMERATION 5 1 state
ENUMERATION 6 1 nil
ENUMERATION 7 1 cozmo
ENUMERATION 8 1 initialize-cozmo
SOAR_ID 9
ENUMERATION 10 1 execute-task
SOAR_ID 11
ENUMERATION 12 1 move-to
SOAR_ID 13
ENUMERATION 14 1 end-agent
SOAR_ID 15
ENUMERATION 16 1 find-cube
SOAR_ID 17
ENUMERATION 18 1 next-task
SOAR_ID 19
ENUMERATION 20 1 pickup-cube
SOAR_ID 21
ENUMERATION 22 1 put-down
SOAR_ID 23
ENUMERATION 24 1 record-led-cube
SOAR_ID 25
ENUMERATION 26 1 record-original-pose
SOAR_ID 27
ENUMERATION 28 1 state
ENUMERATION 29 1 move-to
ENUMERATION 30 1 move-forward
SOAR_ID 31
ENUMERATION 32 1 turn-to-object
SOAR_ID 33
SOAR_ID 34
ENUMERATION 35 1 color-cube
SOAR_ID 36
ENUMERATION 37 1 record-object
SOAR_ID 38
ENUMERATION 39 1 state
ENUMERATION 40 1 find-cube
ENUMERATION 41 1 init-turn
SOAR_ID 42
ENUMERATION 43 1 turn
SOAR_ID 44
ENUMERATION 45 1 increment-turn
SOAR_ID 46
ENUMERATION 47 1 add-turn-counter
SOAR_ID 48
SOAR_ID 49
ENUMERATION 50 1 update-object-position
SOAR_ID 51
ENUMERATION 52 1 update-dropped-object
SOAR_ID 53
ENUMERATION 54 1 find-object
SOAR_ID 55
ENUMERATION 56 1 wait
SOAR_ID 57
ENUMERATION 58 1 stack-cube
SOAR_ID 59
ENUMERATION 60 1 state
ENUMERATION 61 1 stack-cube
ENUMERATION 62 1 find-cube
SOAR_ID 63
ENUMERATION 64 1 pickup-cube
SOAR_ID 65
ENUMERATION 66 1 move-to
SOAR_ID 67
ENUMERATION 68 1 place-object-on
SOAR_ID 69
ENUMERATION 70 1 select-cube
SOAR_ID 71
SOAR_ID 72
ENUMERATION 73 1 state
ENUMERATION 74 1 find-object
ENUMERATION 75 1 select-object
SOAR_ID 76
SOAR_ID 77
ENUMERATION 78 1 update-cube-position
SOAR_ID 79
ENUMERATION 80 1 center-head
SOAR_ID 81
ENUMERATION 82 1 execute-subtask
SOAR_ID 83
ENUMERATION 84 1 next-subtask
SOAR_ID 85
ENUMERATION 86 1 end-task
91
0 io 1
0 name 7
0 operator 4
0 operator 9
0 operator 11
0 operator 13
0 operator 15
0 operator 17
0 operator 19
0 operator 21
0 operator 23
0 operator 25
0 operator 34
0 operator 36
0 operator 49
0 operator 51
0 operator 53
0 operator 55
0 operator 57
0 operator 77
0 operator 79
0 operator 81
0 operator 83
0 operator 85
0 superstate 6
0 top-state 0
0 type 5
1 input-link 2
1 output-link 3
4 name 8
9 name 10
11 name 12
13 name 14
15 name 16
17 name 18
19 name 20
21 name 22
23 name 24
25 name 26
27 name 29
27 operator 31
27 operator 33
27 operator 46
27 superstate 0
27 top-state 0
27 type 28
31 name 30
33 name 32
34 name 35
36 name 37
38 name 40
38 operator 42
38 operator 44
38 operator 48
38 operator 71
38 superstate 0
38 top-state 0
38 type 39
42 name 41
44 name 43
46 name 45
48 name 47
49 name 50
51 name 52
53 name 54
55 name 56
57 name 58
59 name 61
59 operator 63
59 operator 65
59 operator 67
59 operator 69
59 superstate 0
59 top-state 0
59 type 60
63 name 62
65 name 64
67 name 66
69 name 68
71 name 70
72 name 74
72 operator 76
72 superstate 0
72 top-state 0
72 type 73
76 name 75
77 name 78
79 name 80
81 name 82
83 name 84
85 name 86
