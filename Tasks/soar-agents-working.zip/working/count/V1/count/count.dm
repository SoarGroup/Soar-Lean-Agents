33
SOAR_ID 0
SOAR_ID 1
SOAR_ID 2
SOAR_ID 3
SOAR_ID 4
ENUMERATION 5 1 state
ENUMERATION 6 1 nil
ENUMERATION 7 1 count
ENUMERATION 8 1 initialize-count
SOAR_ID 9
ENUMERATION 10 1 add
SOAR_ID 11
ENUMERATION 12 1 report
SOAR_ID 13
ENUMERATION 14 1 state
ENUMERATION 15 1 add
ENUMERATION 16 1 init
SOAR_ID 17
ENUMERATION 18 1 add-init
SOAR_ID 19
ENUMERATION 20 1 add-next
SOAR_ID 21
ENUMERATION 22 1 add-check
SOAR_ID 23
SOAR_ID 24
ENUMERATION 25 1 state
ENUMERATION 26 1 add-next
ENUMERATION 27 1 add-next-cue
SOAR_ID 28
ENUMERATION 29 1 add-next-expand
SOAR_ID 30
ENUMERATION 31 1 add-next-return
SOAR_ID 32
35
0 io 1
0 name 7
0 operator 4
0 operator 9
0 operator 11
0 superstate 6
0 top-state 0
0 type 5
1 input-link 2
1 output-link 3
4 name 8
9 name 10
11 name 12
13 name 15
13 operator 17
13 operator 19
13 operator 21
13 operator 23
13 superstate 0
13 top-state 0
13 type 14
17 name 16
19 name 18
21 name 20
23 name 22
24 name 26
24 operator 28
24 operator 30
24 operator 32
24 superstate 13
24 top-state 0
24 type 25
28 name 27
30 name 29
32 name 31
