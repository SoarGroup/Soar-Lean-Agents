58
SOAR_ID 0
SOAR_ID 1
SOAR_ID 2
SOAR_ID 3
SOAR_ID 4
ENUMERATION 5 1 state
ENUMERATION 6 1 nil
ENUMERATION 7 1 cozmo
ENUMERATION 8 1 initialize-cozmo
SOAR_ID 9
ENUMERATION 10 1 execute-task
SOAR_ID 11
ENUMERATION 12 1 move-to
SOAR_ID 13
ENUMERATION 14 1 end-agent
SOAR_ID 15
ENUMERATION 16 1 find-cube
SOAR_ID 17
ENUMERATION 18 1 next-task
SOAR_ID 19
ENUMERATION 20 1 pickup-cube
SOAR_ID 21
ENUMERATION 22 1 put-down
SOAR_ID 23
ENUMERATION 24 1 record-led-cube
SOAR_ID 25
ENUMERATION 26 1 record-original-pose
SOAR_ID 27
ENUMERATION 28 1 state
ENUMERATION 29 1 execute-task
ENUMERATION 30 1 end-subtask
SOAR_ID 31
ENUMERATION 32 1 execute-subtask
SOAR_ID 33
ENUMERATION 34 1 next-subtask
SOAR_ID 35
SOAR_ID 36
ENUMERATION 37 1 state
ENUMERATION 38 1 move-to
ENUMERATION 39 1 move-forward
SOAR_ID 40
ENUMERATION 41 1 turn-to-object
SOAR_ID 42
SOAR_ID 43
ENUMERATION 44 1 color-cube
SOAR_ID 45
ENUMERATION 46 1 record-object
SOAR_ID 47
ENUMERATION 48 1 state
ENUMERATION 49 1 find-cube
ENUMERATION 50 1 init-turn
SOAR_ID 51
ENUMERATION 52 1 turn
SOAR_ID 53
ENUMERATION 54 1 increment-turn
SOAR_ID 55
ENUMERATION 56 1 add-turn-counte
SOAR_ID 57
61
0 io 1
0 name 7
0 operator 4
0 operator 9
0 operator 11
0 operator 13
0 operator 15
0 operator 17
0 operator 19
0 operator 21
0 operator 23
0 operator 25
0 operator 43
0 operator 45
0 superstate 6
0 top-state 0
0 type 5
1 input-link 2
1 output-link 3
4 name 8
9 name 10
11 name 12
13 name 14
15 name 16
17 name 18
19 name 20
21 name 22
23 name 24
25 name 26
27 name 29
27 operator 31
27 operator 33
27 operator 35
27 superstate 0
27 top-state 0
27 type 28
31 name 30
33 name 32
35 name 34
36 name 38
36 operator 40
36 operator 42
36 operator 55
36 superstate 0
36 top-state 0
36 type 37
40 name 39
42 name 41
43 name 44
45 name 46
47 name 49
47 operator 51
47 operator 53
47 operator 57
47 superstate 0
47 top-state 0
47 type 48
51 name 50
53 name 52
55 name 54
57 name 56
