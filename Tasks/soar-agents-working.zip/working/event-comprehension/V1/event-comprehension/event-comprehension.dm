110
SOAR_ID 0
SOAR_ID 1
SOAR_ID 2
SOAR_ID 3
SOAR_ID 4
ENUMERATION 5 1 state
ENUMERATION 6 1 nil
ENUMERATION 7 1 event-comprehension
ENUMERATION 8 1 initialize-event-comprehension
SOAR_ID 9
ENUMERATION 10 1 add-event-to-event-set
SOAR_ID 11
ENUMERATION 12 1 choose-schema
SOAR_ID 13
ENUMERATION 14 1 wait
SOAR_ID 15
STRING 16
SOAR_ID 17
SOAR_ID 18
SOAR_ID 19
SOAR_ID 20
SOAR_ID 21
SOAR_ID 22
SOAR_ID 23
SOAR_ID 24
ENUMERATION 25 1 catch
ENUMERATION 26 1 throw
ENUMERATION 27 1 travel
SOAR_ID 28
ENUMERATION 29 1 catch
SOAR_ID 30
ENUMERATION 31 1 throw
ENUMERATION 32 2 negative positive
STRING 33
ENUMERATION 34 2 far near
ENUMERATION 35 2 fast slow
STRING 36
ENUMERATION 37 1 travel
SOAR_ID 38
SOAR_ID 39
STRING 40
STRING 41
SOAR_ID 42
STRING 43
STRING 44
SOAR_ID 45
STRING 46
SOAR_ID 47
SOAR_ID 48
SOAR_ID 49
SOAR_ID 50
SOAR_ID 51
STRING 52
STRING 53
STRING 54
SOAR_ID 55
SOAR_ID 56
STRING 57
ENUMERATION 58 3 high low moderate
SOAR_ID 59
STRING 60
ENUMERATION 61 2 false true
SOAR_ID 62
ENUMERATION 63 1 add-event-to-current-schema
ENUMERATION 64 2 far near
ENUMERATION 65 2 fast slow
SOAR_ID 66
SOAR_ID 67
ENUMERATION 68 1 discrepancy
INTEGER_RANGE 69 0 2147483647
INTEGER_RANGE 70 0 2147483647
SOAR_ID 71
SOAR_ID 72
SOAR_ID 73
STRING 74
SOAR_ID 75
SOAR_ID 76
ENUMERATION 77 2 false true
SOAR_ID 78
SOAR_ID 79
ENUMERATION 80 1 balloon-exchange
SOAR_ID 81
STRING 82
STRING 83
ENUMERATION 84 2 false true
SOAR_ID 85
ENUMERATION 86 1 true
ENUMERATION 87 1 true
ENUMERATION 88 1 true
SOAR_ID 89
ENUMERATION 90 1 true
SOAR_ID 91
SOAR_ID 92
SOAR_ID 93
SOAR_ID 94
SOAR_ID 95
ENUMERATION 96 1 update-next-prediction
SOAR_ID 97
ENUMERATION 98 1 state
ENUMERATION 99 1 choose-schema
ENUMERATION 100 1 abstract-events
SOAR_ID 101
ENUMERATION 102 1 clear-schema
SOAR_ID 103
SOAR_ID 104
ENUMERATION 105 1 concretize-prediction
SOAR_ID 106
ENUMERATION 107 1 true
ENUMERATION 108 1 choose-schema2
SOAR_ID 109
130
0 attribute 53
0 choices 54
0 event-set 38
0 io 1
0 name 7
0 operator 4
0 operator 9
0 operator 11
0 operator 13
0 operator 62
0 operator 95
0 schema-set 104
0 self 56
0 superstate 6
0 top-state 0
0 type 5
1 emotion-link 66
1 input-link 2
1 output-link 3
2 event 21
2 event 17
2 event 24
4 name 8
9 event 47
9 event 79
9 event-set 38
9 from-abstraction 90
9 from-input-link 88
9 name 10
9 old-event 17
9 old-event 24
9 old-schema 89
11 abstract-prediction 79
11 event 39
11 name 12
11 schema 41
13 name 14
13 random 52
15 event 24
15 event 17
15 event 21
17 action 18
17 actor 20
17 type 26
18 type 31
20 body-language 32
20 identity 33
21 action 23
21 actor 22
21 type 27
22 identity 36
23 speed 35
23 trajectory 34
23 type 37
24 action 28
24 actor 59
24 type 25
28 success 61
28 type 29
38 event 24
38 event 21
38 event 79
38 event 85
38 event 17
39 action 45
39 actor 42
39 after 51
39 before 50
39 type 40
42 body-language 44
42 identity 43
45 speed 65
45 trajectory 64
45 type 46
47 after 49
47 before 48
55 before 71
56 name 57
56 skill 58
59 identity 60
62 event 76
62 name 63
66 appraisal 67
67 different 70
67 total 69
67 type 68
72 action 75
72 before 73
72 type 74
75 speed 35
75 trajectory 34
76 action 78
78 success 77
79 action 91
79 actor 81
79 type 80
81 catcher 83
81 thrower 82
85 added-from-abstraction 87
85 added-from-input-link 86
85 after 30
85 before 19
91 success 84
92 event 85
92 is-abstract 107
92 last-event 55
92 name 16
92 next-prediction 72
93 event 79
93 next-prediction 94
94 action 91
94 actor 81
95 name 96
97 event-set 38
97 name 99
97 operator 101
97 operator 103
97 operator 106
97 operator 109
97 schema-set 104
97 superstate 0
97 top-state 0
97 type 98
101 name 100
103 name 102
104 current-schema 15
104 current-schema 92
104 current-schema 93
106 name 105
109 name 108
