290
SOAR_ID 0
SOAR_ID 1
SOAR_ID 2
SOAR_ID 3
SOAR_ID 4
ENUMERATION 5 1 state
ENUMERATION 6 1 nil
ENUMERATION 7 3 attempt-simple-problem instruct test-x
ENUMERATION 8 1 initialize-instruct
SOAR_ID 9
SOAR_ID 10
STRING 11
STRING 12
SOAR_ID 13
SOAR_ID 14
ENUMERATION 15 10 add decrement divide goal-test increment multiply output set subtract write
ENUMERATION 16 3 constant list variable
SOAR_ID 17
SOAR_ID 18
ENUMERATION 19 3 equal greater-than less-than
STRING 20
STRING 21
SOAR_ID 22
ENUMERATION 23 1 next-step
SOAR_ID 24
ENUMERATION 25 1 execute-step
SOAR_ID 26
ENUMERATION 27 1 state
ENUMERATION 28 1 execute-step
ENUMERATION 29 1 execute-action
SOAR_ID 30
SOAR_ID 31
SOAR_ID 32
STRING 33
SOAR_ID 34
ENUMERATION 35 1 goal-action
SOAR_ID 36
ENUMERATION 37 1 execute-goal-action
STRING 38
STRING 39
INTEGER_RANGE 40 -2147483648 2147483647
INTEGER_RANGE 41 -2147483648 2147483647
STRING 42
STRING 43
SOAR_ID 44
ENUMERATION 45 1 encode
ENUMERATION 46 1 true
SOAR_ID 47
STRING 48
ENUMERATION 49 4 constant symbol unknown variable
SOAR_ID 50
ENUMERATION 51 1 state
ENUMERATION 52 1 encode
ENUMERATION 53 1 next-item
SOAR_ID 54
ENUMERATION 55 1 skip-symbol
SOAR_ID 56
ENUMERATION 57 1 create-variable
SOAR_ID 58
ENUMERATION 59 1 init-encode
SOAR_ID 60
ENUMERATION 61 1 terminate-encode
SOAR_ID 62
ENUMERATION 63 1 nil
ENUMERATION 64 1 nil
ENUMERATION 65 1 nil
ENUMERATION 66 1 process-unknown
SOAR_ID 67
STRING 68
SOAR_ID 69
ENUMERATION 70 1 write-answer
SOAR_ID 71
ENUMERATION 72 1 state
ENUMERATION 73 1 write-answer
ENUMERATION 74 1 init-write
SOAR_ID 75
ENUMERATION 76 1 terminate-write
SOAR_ID 77
ENUMERATION 78 1 skip-symbol
SOAR_ID 79
ENUMERATION 80 1 write-constant
SOAR_ID 81
ENUMERATION 82 1 write-unknown
SOAR_ID 83
ENUMERATION 84 4 equal greater-than less-than not-equal
SOAR_ID 85
ENUMERATION 86 1 next-step
SOAR_ID 87
INTEGER_RANGE 88 -2147483648 2147483647
INTEGER_RANGE 89 -2147483648 2147483647
SOAR_ID 90
ENUMERATION 91 1 smem-retrieve
ENUMERATION 92 2 fail success
INTEGER_RANGE 93 -2147483648 2147483647
ENUMERATION 94 1 true
SOAR_ID 95
STRING 96
ENUMERATION 97 1 true
SOAR_ID 98
ENUMERATION 99 1 next-problem
ENUMERATION 100 1 nil
ENUMERATION 101 1 nil
SOAR_ID 102
ENUMERATION 103 2 symbol variable
SOAR_ID 104
ENUMERATION 105 1 initialize-problem
ENUMERATION 106 2 describe-plus solve
SOAR_ID 107
ENUMERATION 108 1 execute-solve-procedure
SOAR_ID 109
ENUMERATION 110 1 state
ENUMERATION 111 1 execute-solve-procedure
ENUMERATION 112 1 true
ENUMERATION 113 1 true
ENUMERATION 114 1 detect-long-problem
SOAR_ID 115
ENUMERATION 116 1 fail
ENUMERATION 117 1 attempt-simple-problem
SOAR_ID 118
SOAR_ID 119
ENUMERATION 120 1 state
ENUMERATION 121 1 attempt-simple-problem
ENUMERATION 122 1 create-simple-problem
SOAR_ID 123
ENUMERATION 124 1 execute-solve-procedure
SOAR_ID 125
ENUMERATION 126 1 use-answer
SOAR_ID 127
ENUMERATION 128 1 attempt-abstract-solution
SOAR_ID 129
SOAR_ID 130
ENUMERATION 131 1 state
ENUMERATION 132 1 attempt-abstract-solution
SOAR_ID 133
ENUMERATION 134 4 answer base height term
ENUMERATION 135 4 first-term last-term length-add sum
SOAR_ID 136
ENUMERATION 137 3 0 last-term length-add
ENUMERATION 138 1 first-term
ENUMERATION 139 3 balanced equal minus
ENUMERATION 140 2 last-term length-add
ENUMERATION 141 1 find-term
SOAR_ID 142
ENUMERATION 143 1 check-balance
SOAR_ID 144
ENUMERATION 145 1 use-balance
SOAR_ID 146
SOAR_ID 147
ENUMERATION 148 1 state
ENUMERATION 149 1 find-term
ENUMERATION 150 1 use-definition
SOAR_ID 151
ENUMERATION 152 1 use-relation
SOAR_ID 153
ENUMERATION 154 1 find-term
SOAR_ID 155
ENUMERATION 156 1 calculate
SOAR_ID 157
ENUMERATION 158 2 false true
INTEGER_RANGE 159 -2147483648 2147483647
INTEGER_RANGE 160 -2147483648 2147483647
INTEGER_RANGE 161 -2147483648 2147483647
ENUMERATION 162 2 first-term last-term
INTEGER_RANGE 163 -2147483648 2147483647
INTEGER_RANGE 164 -2147483648 2147483647
INTEGER_RANGE 165 -2147483648 2147483647
INTEGER_RANGE 166 -2147483648 2147483647
SOAR_ID 167
ENUMERATION 168 1 minus
STRING 169
STRING 170
STRING 171
SOAR_ID 172
ENUMERATION 173 1 state
ENUMERATION 174 1 describe
ENUMERATION 175 1 init-describe
SOAR_ID 176
ENUMERATION 177 1 describe-variable
SOAR_ID 178
ENUMERATION 179 1 write-symbol
SOAR_ID 180
ENUMERATION 181 1 true
SOAR_ID 182
ENUMERATION 183 1 describe
SOAR_ID 184
ENUMERATION 185 1 finish-up
STRING 186
SOAR_ID 187
ENUMERATION 188 1 state
ENUMERATION 189 1 describe-variable
ENUMERATION 190 1 use-definition
SOAR_ID 191
ENUMERATION 192 1 count-pluses
SOAR_ID 193
ENUMERATION 194 1 use-relation
SOAR_ID 195
ENUMERATION 196 1 describe-term
SOAR_ID 197
ENUMERATION 198 1 write-variable
SOAR_ID 199
ENUMERATION 200 1 failure
ENUMERATION 201 1 length-add
INTEGER_RANGE 202 -2147483648 2147483647
ENUMERATION 203 2 first-term last-term
STRING 204
ENUMERATION 205 2 first-term last-term
ENUMERATION 206 1 answer
STRING 207
SOAR_ID 208
ENUMERATION 209 1 reflect
SOAR_ID 210
ENUMERATION 211 1 addition-fact
INTEGER_RANGE 212 -2147483648 2147483647
INTEGER_RANGE 213 -2147483648 2147483647
INTEGER_RANGE 214 -2147483648 2147483647
ENUMERATION 215 1 true
SOAR_ID 216
ENUMERATION 217 1 state
ENUMERATION 218 1 reflect
ENUMERATION 219 1 gather-final-values
SOAR_ID 220
SOAR_ID 221
ENUMERATION 222 5 answer base height sum term
INTEGER_RANGE 223 -2147483648 2147483647
INTEGER_RANGE 224 -2147483648 2147483647
ENUMERATION 225 2 definition intermediate
ENUMERATION 226 1 check-equality
SOAR_ID 227
ENUMERATION 228 1 true
SOAR_ID 229
ENUMERATION 230 1 state
ENUMERATION 231 1 execute-action
ENUMERATION 232 1 repair-equal
SOAR_ID 233
INTEGER_RANGE 234 0 2147483647
ENUMERATION 235 1 guess-x
SOAR_ID 236
ENUMERATION 237 1 test-x
SOAR_ID 238
ENUMERATION 239 1 return-x
SOAR_ID 240
SOAR_ID 241
ENUMERATION 242 1 state
ENUMERATION 243 1 guess-x
ENUMERATION 244 1 retrieve-prior-result
SOAR_ID 245
ENUMERATION 246 1 create-x
SOAR_ID 247
SOAR_ID 248
INTEGER_RANGE 249 -2147483648 2147483647
ENUMERATION 250 2 too-large too-small
ENUMERATION 251 1 retrieve-last-guess
SOAR_ID 252
ENUMERATION 253 1 true
SOAR_ID 254
ENUMERATION 255 1 state
ENUMERATION 256 1 test-x
ENUMERATION 257 1 create-problem
SOAR_ID 258
ENUMERATION 259 1 execute-solve-procedure
SOAR_ID 260
ENUMERATION 261 2 too-large too-small
INTEGER_RANGE 262 -2147483648 2147483647
ENUMERATION 263 1 true
ENUMERATION 264 1 evaluate-goal-completion
SOAR_ID 265
ENUMERATION 266 2 finished solved
ENUMERATION 267 1 minimum-abstract-sum
SOAR_ID 268
ENUMERATION 269 1 slot-done
SOAR_ID 270
INTEGER_RANGE 271 -2147483648 2147483647
ENUMERATION 272 1 double
ENUMERATION 273 1 base
ENUMERATION 274 1 true
STRING 275
ENUMERATION 276 1 impossible
ENUMERATION 277 1 impossible
INTEGER_RANGE 278 -2147483648 2147483647
ENUMERATION 279 1 unknown
SOAR_ID 280
INTEGER_RANGE 281 -2147483648 2147483647
ENUMERATION 282 1 init-count-pluses
SOAR_ID 283
ENUMERATION 284 1 process-prior-result
SOAR_ID 285
ENUMERATION 286 1 special-guess
SOAR_ID 287
SOAR_ID 288
ENUMERATION 289 1 terminate-run
354
0 alternative-action 14
0 current-problem 95
0 current-problem 100
0 instructions 9
0 io 1
0 name 7
0 operator 4
0 operator 22
0 operator 34
0 operator 36
0 operator 44
0 operator 69
0 operator 98
0 operator 104
0 operator 107
0 operator 182
0 operator 208
0 operator 288
0 reflect 274
0 superstate 6
0 top-state 0
0 type 5
1 input-link 2
1 output-link 3
4 name 8
9 definitions 133
9 facts 210
9 first-step 13
9 goal-tests 17
9 problem-structure 47
9 relations 136
9 steps 13
9 unknown-value 68
10 next 10
10 next 64
10 type 49
10 value 12
13 action 14
13 next 13
14 command 15
14 list 38
14 relation 84
14 save-command 15
14 substitute 14
14 type 266
14 value 12
14 value-type 16
14 variable 11
17 goal-test 14
18 relation 19
18 value 21
18 value-type 16
18 variable 20
22 name 23
24 name 25
26 alternate-action 14
26 current-problem 95
26 name 28
26 operator 30
26 operator 85
26 operator 270
26 superstate 109
26 top-state 0
26 type 27
30 action 14
30 name 29
31 current 32
31 next 32
32 command 33
32 next 32
32 value 43
32 variable 39
34 name 35
36 name 37
44 name 45
47 name 48
47 next 47
47 next 65
47 type 103
50 current-problem-ptr 10
50 current-problem-ptr 63
50 current-problem-structure-ptr 47
50 name 52
50 operator 54
50 operator 56
50 operator 58
50 operator 60
50 operator 62
50 operator 67
50 superstate 0
50 top-state 0
50 type 51
54 name 53
56 name 55
58 name 57
60 name 59
62 name 61
67 name 66
69 name 70
71 current-problem-ptr 10
71 current-problem-ptr 63
71 current-problem-structure-ptr 47
71 name 73
71 operator 75
71 operator 77
71 operator 79
71 operator 81
71 operator 83
71 superstate 0
71 top-state 0
71 type 72
75 name 74
77 name 76
79 name 78
81 name 80
83 name 82
85 name 86
87 answer 165
87 base 88
87 complete 94
87 height 89
87 retrieved 92
87 sum 93
90 name 91
95 answer 42
95 base 40
95 base-list 280
95 complete 97
95 completed-action 14
95 completed-step 13
95 count 281
95 current-step 13
95 described 181
95 element 10
95 encoded 46
95 failed 261
95 goal-test-success 18
95 height 41
95 initialized 112
95 list 31
95 minimum-math-computations 278
95 minimum-math-computations 279
95 next-problem 95
95 next-problem 101
95 prior-problem 95
95 problem-name 96
95 problem-number 234
95 reflect 215
95 result 87
95 success 113
95 sum 164
95 term 262
95 terms 221
95 type 106
95 unknown 206
98 name 99
102 current-problem 95
102 current-problem 100
104 name 105
107 name 108
109 current-problem 95
109 execute-step 116
109 name 111
109 operator 24
109 operator 90
109 operator 115
109 operator 118
109 operator 129
109 superstate 0
109 top-state 0
109 type 110
115 name 114
118 name 117
119 current-problem 95
119 name 121
119 operator 123
119 operator 125
119 operator 127
119 problems 102
119 superstate 109
119 top-state 0
119 type 120
123 name 122
125 name 124
127 name 126
129 name 128
130 balanced 158
130 first-term 159
130 last-term 160
130 last-term 276
130 less-than 275
130 less-than-last-term 277
130 name 132
130 operator 142
130 operator 144
130 operator 146
130 operator 268
130 superstate 109
130 top-state 0
130 type 131
130 value 163
133 function 135
133 term 134
136 answer 271
136 arg 273
136 arg1 138
136 arg2 140
136 minimum-math-computations 272
136 relation 139
136 term 137
142 arg 162
142 name 141
144 arg 161
144 name 143
146 name 145
147 define 166
147 name 149
147 operator 151
147 operator 153
147 operator 155
147 operator 157
147 relation 167
147 superstate 130
147 top-state 0
147 type 148
151 name 150
153 name 152
155 arg 171
155 name 154
157 name 156
157 relation 168
167 arg1 169
167 arg2 170
167 relation 168
172 current-problem-ptr 95
172 current-problem-structure-ptr 47
172 dummy 207
172 name 174
172 operator 176
172 operator 178
172 operator 180
172 operator 184
172 operator 199
172 superstate 0
172 top-state 0
172 type 173
176 name 175
178 arg 186
178 name 177
180 name 179
182 name 183
184 name 185
187 count 202
187 define 200
187 first-term 204
187 last-term 204
187 name 189
187 operator 191
187 operator 193
187 operator 195
187 operator 197
187 operator 283
187 pointer 10
187 relation 136
187 role 201
187 role 205
187 superstate 172
187 top-state 0
187 type 188
191 name 190
193 name 192
195 name 194
197 arg 203
197 name 196
199 name 198
208 name 209
210 addend1 212
210 addend2 213
210 name 211
210 sum 214
216 current-problem 95
216 name 218
216 operator 220
216 operator 227
216 superstate 0
216 term 221
216 top-state 0
216 type 217
220 name 219
220 term 221
221 checked 228
221 term-final-value 224
221 term-initial-value 223
221 term-name 222
221 type 225
227 name 226
227 term 221
229 action 14
229 current-problem 95
229 name 231
229 operator 233
229 operator 236
229 operator 238
229 operator 240
229 superstate 26
229 top-state 0
229 type 230
229 x-guess 248
233 name 232
236 action 14
236 name 235
236 prior-x-guess 248
238 name 237
238 x-guess 248
240 name 239
241 current-problem 95
241 name 243
241 operator 245
241 operator 247
241 operator 252
241 operator 285
241 operator 287
241 prior-result 87
241 superstate 229
241 top-state 0
241 type 242
245 name 244
247 name 246
248 failed 250
248 newer-x-guess 253
248 success 263
248 value 249
252 last-guess 248
252 name 251
254 current-problem 95
254 current-problem 100
254 name 256
254 operator 258
254 operator 260
254 operator 265
254 superstate 229
254 top-state 0
254 type 255
258 name 257
260 name 259
265 name 264
268 name 267
270 name 269
280 current 280
280 next 280
283 name 282
285 name 284
287 name 286
288 name 289
