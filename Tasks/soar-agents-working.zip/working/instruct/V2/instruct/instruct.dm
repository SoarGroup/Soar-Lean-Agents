150
SOAR_ID 0
SOAR_ID 1
SOAR_ID 2
SOAR_ID 3
SOAR_ID 4
ENUMERATION 5 1 state
ENUMERATION 6 1 nil
ENUMERATION 7 1 instruct
ENUMERATION 8 1 initialize-instruct
SOAR_ID 9
SOAR_ID 10
STRING 11
STRING 12
SOAR_ID 13
SOAR_ID 14
ENUMERATION 15 10 add decrement divide goal-test increment multiply output set subtract write
ENUMERATION 16 3 constant list variable
SOAR_ID 17
SOAR_ID 18
ENUMERATION 19 3 equal greater-than less-than
STRING 20
STRING 21
SOAR_ID 22
ENUMERATION 23 1 next-step
SOAR_ID 24
ENUMERATION 25 1 execute-step
SOAR_ID 26
ENUMERATION 27 1 state
ENUMERATION 28 1 execute-step
ENUMERATION 29 1 execute-action
SOAR_ID 30
SOAR_ID 31
SOAR_ID 32
STRING 33
SOAR_ID 34
ENUMERATION 35 1 goal-action
SOAR_ID 36
ENUMERATION 37 1 execute-goal-action
STRING 38
STRING 39
INTEGER_RANGE 40 -2147483648 2147483647
INTEGER_RANGE 41 -2147483648 2147483647
STRING 42
STRING 43
SOAR_ID 44
ENUMERATION 45 1 encode
ENUMERATION 46 1 true
SOAR_ID 47
STRING 48
ENUMERATION 49 4 constant symbol unknown variable
SOAR_ID 50
ENUMERATION 51 1 state
ENUMERATION 52 1 encode
ENUMERATION 53 1 next-item
SOAR_ID 54
ENUMERATION 55 1 skip-symbol
SOAR_ID 56
ENUMERATION 57 1 create-variable
SOAR_ID 58
ENUMERATION 59 1 init-encode
SOAR_ID 60
ENUMERATION 61 1 terminate-encode
SOAR_ID 62
ENUMERATION 63 1 nil
ENUMERATION 64 1 nil
ENUMERATION 65 1 nil
ENUMERATION 66 1 process-unknown
SOAR_ID 67
STRING 68
SOAR_ID 69
ENUMERATION 70 1 write-answer
SOAR_ID 71
ENUMERATION 72 1 state
ENUMERATION 73 1 write-answer
ENUMERATION 74 1 init-write
SOAR_ID 75
ENUMERATION 76 1 terminate-write
SOAR_ID 77
ENUMERATION 78 1 skip-symbol
SOAR_ID 79
ENUMERATION 80 1 write-constant
SOAR_ID 81
ENUMERATION 82 1 write-unknown
SOAR_ID 83
ENUMERATION 84 4 equal greater-than less-than not-equal
SOAR_ID 85
ENUMERATION 86 1 next-step
SOAR_ID 87
INTEGER_RANGE 88 -2147483648 2147483647
INTEGER_RANGE 89 -2147483648 2147483647
SOAR_ID 90
ENUMERATION 91 1 smem-retrieve
ENUMERATION 92 2 fail success
INTEGER_RANGE 93 -2147483648 2147483647
ENUMERATION 94 1 true
SOAR_ID 95
STRING 96
ENUMERATION 97 1 true
SOAR_ID 98
ENUMERATION 99 1 next-problem
ENUMERATION 100 1 nil
ENUMERATION 101 1 nil
SOAR_ID 102
ENUMERATION 103 2 symbol variable
SOAR_ID 104
ENUMERATION 105 1 initialize-problem
ENUMERATION 106 2 describe solve
SOAR_ID 107
ENUMERATION 108 1 execute-solve-procedure
SOAR_ID 109
ENUMERATION 110 1 state
ENUMERATION 111 1 execute-solve-procedure
ENUMERATION 112 1 d
SOAR_ID 113
ENUMERATION 114 1 true
ENUMERATION 115 1 true
ENUMERATION 116 1 detect-long-problem
SOAR_ID 117
ENUMERATION 118 1 fail
ENUMERATION 119 1 attempt-simple-problem
SOAR_ID 120
SOAR_ID 121
ENUMERATION 122 1 state
ENUMERATION 123 1 attempt-simple-problem
ENUMERATION 124 1 create-simple-problem
SOAR_ID 125
ENUMERATION 126 1 execute-solve-procedure
SOAR_ID 127
ENUMERATION 128 1 use-answer
SOAR_ID 129
ENUMERATION 130 1 abstract-solution
SOAR_ID 131
SOAR_ID 132
ENUMERATION 133 1 state
ENUMERATION 134 1 abstract-solution
SOAR_ID 135
ENUMERATION 136 1 encode
SOAR_ID 137
ENUMERATION 138 1 describe
SOAR_ID 139
ENUMERATION 140 1 state
ENUMERATION 141 1 describe
ENUMERATION 142 1 init-describe
SOAR_ID 143
ENUMERATION 144 1 process-variable
SOAR_ID 145
ENUMERATION 146 1 write-symbol
SOAR_ID 147
ENUMERATION 148 1 finished-description
SOAR_ID 149
182
0 instructions 9
0 io 1
0 name 7
0 operator 4
0 operator 22
0 operator 34
0 operator 36
0 operator 44
0 operator 69
0 operator 98
0 operator 104
0 operator 107
0 operator 135
0 operator 137
0 problems 102
0 superstate 6
0 top-state 0
0 type 5
1 input-link 2
1 output-link 3
4 name 8
9 first-step 13
9 goal-tests 17
9 problem-structure 47
9 steps 13
9 unknown-value 68
10 next 10
10 next 64
10 type 49
10 value 12
13 action 14
13 next 13
14 command 15
14 list 38
14 relation 84
14 save-command 15
14 value 12
14 value-type 16
14 variable 11
17 goal-test 18
18 relation 19
18 value 21
18 value-type 16
18 variable 20
22 name 23
24 name 25
26 current-problem 95
26 name 28
26 operator 30
26 operator 85
26 superstate 109
26 top-state 0
26 type 27
30 action 14
30 name 29
31 current 32
31 next 32
32 command 33
32 next 32
32 value 43
32 variable 39
34 name 35
36 name 37
44 name 45
47 name 48
47 next 47
47 next 65
47 type 103
50 current-problem-ptr 10
50 current-problem-ptr 63
50 current-problem-structure-ptr 47
50 name 52
50 operator 54
50 operator 56
50 operator 58
50 operator 60
50 operator 62
50 operator 67
50 superstate 0
50 top-state 0
50 type 51
54 name 53
56 name 55
58 name 57
60 name 59
62 name 61
67 name 66
69 name 70
71 current-problem-ptr 10
71 current-problem-ptr 63
71 current-problem-structure-ptr 47
71 name 73
71 operator 75
71 operator 77
71 operator 79
71 operator 81
71 operator 83
71 superstate 0
71 top-state 0
71 type 72
75 name 74
77 name 76
79 name 78
81 name 80
83 name 82
85 name 86
87 base 88
87 complete 94
87 height 89
87 retrieved 92
87 sum 93
90 name 91
95 answer 42
95 base 40
95 complete 97
95 completed-action 14
95 completed-step 13
95 current-step 13
95 element 10
95 encoded 46
95 goal-test-success 18
95 height 41
95 initialized 114
95 list 31
95 next-problem 95
95 next-problem 101
95 problem-name 96
95 result 87
95 success 115
95 type 106
98 name 99
102 current-problem 95
102 current-problem 100
104 name 105
107 name 108
109 current-problem 95
109 execute-step 118
109 name 111
109 operator 113
109 operator 24
109 operator 90
109 operator 117
109 operator 120
109 operator 131
109 problems 102
109 superstate 0
109 top-state 0
109 type 110
113 name 112
117 name 116
120 name 119
121 current-problem 95
121 name 123
121 operator 125
121 operator 127
121 operator 129
121 problems 102
121 superstate 109
121 top-state 0
121 type 122
125 name 124
127 name 126
129 name 128
131 name 130
132 name 134
132 superstate 109
132 top-state 0
132 type 133
135 name 136
137 name 138
139 name 141
139 operator 143
139 operator 145
139 operator 147
139 operator 149
139 superstate 0
139 top-state 0
139 type 140
143 name 142
145 name 144
147 name 146
149 name 148
