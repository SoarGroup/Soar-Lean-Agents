152
SOAR_ID 0
SOAR_ID 1
SOAR_ID 2
SOAR_ID 3
SOAR_ID 4
ENUMERATION 5 1 state
ENUMERATION 6 1 nil
ENUMERATION 7 2 attempt-simple-problem instruct
ENUMERATION 8 1 initialize-instruct
SOAR_ID 9
SOAR_ID 10
STRING 11
STRING 12
SOAR_ID 13
SOAR_ID 14
ENUMERATION 15 10 add decrement divide goal-test increment multiply output set subtract write
ENUMERATION 16 3 constant list variable
SOAR_ID 17
SOAR_ID 18
ENUMERATION 19 3 equal greater-than less-than
STRING 20
STRING 21
SOAR_ID 22
ENUMERATION 23 1 next-step
SOAR_ID 24
ENUMERATION 25 1 execute-step
SOAR_ID 26
ENUMERATION 27 1 state
ENUMERATION 28 1 execute-step
ENUMERATION 29 1 execute-action
SOAR_ID 30
SOAR_ID 31
SOAR_ID 32
STRING 33
SOAR_ID 34
ENUMERATION 35 1 goal-action
SOAR_ID 36
ENUMERATION 37 1 execute-goal-action
STRING 38
STRING 39
INTEGER_RANGE 40 -2147483648 2147483647
INTEGER_RANGE 41 -2147483648 2147483647
STRING 42
STRING 43
SOAR_ID 44
ENUMERATION 45 1 encode
ENUMERATION 46 1 true
SOAR_ID 47
STRING 48
ENUMERATION 49 4 constant symbol unknown variable
SOAR_ID 50
ENUMERATION 51 1 state
ENUMERATION 52 1 encode
ENUMERATION 53 1 next-item
SOAR_ID 54
ENUMERATION 55 1 skip-symbol
SOAR_ID 56
ENUMERATION 57 1 create-variable
SOAR_ID 58
ENUMERATION 59 1 init-encode
SOAR_ID 60
ENUMERATION 61 1 terminate-encode
SOAR_ID 62
ENUMERATION 63 1 nil
ENUMERATION 64 1 nil
ENUMERATION 65 1 nil
ENUMERATION 66 1 process-unknown
SOAR_ID 67
STRING 68
SOAR_ID 69
ENUMERATION 70 1 write-answer
SOAR_ID 71
ENUMERATION 72 1 state
ENUMERATION 73 1 write-answer
ENUMERATION 74 1 init-write
SOAR_ID 75
ENUMERATION 76 1 terminate-write
SOAR_ID 77
ENUMERATION 78 1 skip-symbol
SOAR_ID 79
ENUMERATION 80 1 write-constant
SOAR_ID 81
ENUMERATION 82 1 write-unknown
SOAR_ID 83
ENUMERATION 84 4 equal greater-than less-than not-equal
SOAR_ID 85
ENUMERATION 86 1 next-step
SOAR_ID 87
INTEGER_RANGE 88 -2147483648 2147483647
INTEGER_RANGE 89 -2147483648 2147483647
SOAR_ID 90
ENUMERATION 91 1 smem-retrieve
SOAR_ID 92
ENUMERATION 93 1 state
ENUMERATION 94 1 smem-retrieve
ENUMERATION 95 1 create-cue
SOAR_ID 96
SOAR_ID 97
SOAR_ID 98
ENUMERATION 99 1 get-result
SOAR_ID 100
SOAR_ID 101
ENUMERATION 102 1 failure
ENUMERATION 103 2 fail success
INTEGER_RANGE 104 -2147483648 2147483647
INTEGER_RANGE 105 -2147483648 2147483647
ENUMERATION 106 1 true
SOAR_ID 107
ENUMERATION 108 1 state
ENUMERATION 109 1 get-result
ENUMERATION 110 1 failed-retrieval
SOAR_ID 111
ENUMERATION 112 1 failed-smem
SOAR_ID 113
SOAR_ID 114
STRING 115
ENUMERATION 116 1 true
SOAR_ID 117
ENUMERATION 118 1 next-problem
ENUMERATION 119 1 nil
ENUMERATION 120 1 nil
SOAR_ID 121
ENUMERATION 122 2 symbol variable
SOAR_ID 123
ENUMERATION 124 1 initialize-problem
ENUMERATION 125 2 describe solve
SOAR_ID 126
ENUMERATION 127 1 execute-solve-procedure
SOAR_ID 128
ENUMERATION 129 1 state
ENUMERATION 130 1 execute-solve-procedure
ENUMERATION 131 1 d
SOAR_ID 132
ENUMERATION 133 1 true
ENUMERATION 134 1 true
ENUMERATION 135 1 detect-long-problem
SOAR_ID 136
ENUMERATION 137 1 fail
ENUMERATION 138 1 attempt-simple-problem
SOAR_ID 139
SOAR_ID 140
ENUMERATION 141 1 state
ENUMERATION 142 1 attempt-simple-problem
ENUMERATION 143 1 create-simple-problem
SOAR_ID 144
ENUMERATION 145 1 execute-solve-procedure
SOAR_ID 146
ENUMERATION 147 1 use-answer
SOAR_ID 148
ENUMERATION 149 1 answer
INTEGER_RANGE 150 -2147483648 2147483647
INTEGER_RANGE 151 -2147483648 2147483647
185
0 instructions 9
0 io 1
0 name 7
0 operator 4
0 operator 22
0 operator 34
0 operator 36
0 operator 44
0 operator 69
0 operator 117
0 operator 123
0 operator 126
0 problems 121
0 superstate 6
0 top-state 0
0 type 5
1 input-link 2
1 output-link 3
4 name 8
9 first-step 13
9 goal-tests 17
9 problem-structure 47
9 steps 13
9 unknown-value 68
10 next 10
10 next 64
10 type 49
10 value 12
13 action 14
13 next 13
14 command 15
14 list 38
14 relation 84
14 save-command 15
14 value 12
14 value-type 16
14 variable 11
17 goal-test 18
18 relation 19
18 value 21
18 value-type 16
18 variable 20
22 name 23
24 name 25
26 current-problem 114
26 name 28
26 operator 30
26 operator 85
26 superstate 128
26 top-state 0
26 type 27
30 action 14
30 name 29
31 current 32
31 next 32
32 command 33
32 next 32
32 value 43
32 variable 39
34 name 35
36 name 37
44 name 45
47 name 48
47 next 47
47 next 65
47 type 122
50 current-problem-ptr 10
50 current-problem-ptr 63
50 current-problem-structure-ptr 47
50 name 52
50 operator 54
50 operator 56
50 operator 58
50 operator 60
50 operator 62
50 operator 67
50 superstate 0
50 top-state 0
50 type 51
54 name 53
56 name 55
58 name 57
60 name 59
62 name 61
67 name 66
69 name 70
71 current-problem-ptr 10
71 current-problem-ptr 63
71 current-problem-structure-ptr 47
71 name 73
71 operator 75
71 operator 77
71 operator 79
71 operator 81
71 operator 83
71 superstate 0
71 top-state 0
71 type 72
75 name 74
77 name 76
79 name 78
81 name 80
83 name 82
85 name 86
87 answer 150
87 base 88
87 complete 106
87 height 89
87 retrieved 103
87 sum 104
90 name 91
92 name 94
92 operator 96
92 operator 100
92 operator 113
92 smem 97
92 superstate 128
92 top-state 0
92 type 93
96 name 95
97 retrieve 98
98 cue 87
98 retrieved 101
100 name 99
101 status 102
101 sum 105
107 name 109
107 operator 111
107 superstate 92
107 top-state 0
107 type 108
111 name 110
113 name 112
114 answer 42
114 base 40
114 complete 116
114 completed-action 14
114 completed-step 13
114 current-step 13
114 element 10
114 encoded 46
114 goal-test-success 18
114 height 41
114 initialized 133
114 list 31
114 next-problem 114
114 next-problem 120
114 problem-name 115
114 result 87
114 success 134
114 sum 151
114 type 125
114 unknown 149
117 name 118
121 current-problem 114
121 current-problem 119
123 name 124
126 name 127
128 current-problem 114
128 execute-step 137
128 name 130
128 operator 132
128 operator 24
128 operator 90
128 operator 136
128 operator 139
128 problems 121
128 superstate 0
128 top-state 0
128 type 129
132 name 131
136 name 135
139 name 138
140 current-problem 114
140 name 142
140 operator 144
140 operator 146
140 operator 148
140 problems 121
140 superstate 128
140 top-state 0
140 type 141
144 name 143
146 name 145
148 name 147
