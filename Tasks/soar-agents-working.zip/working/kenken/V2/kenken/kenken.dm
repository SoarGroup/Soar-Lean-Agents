85
SOAR_ID 0
SOAR_ID 1
SOAR_ID 2
SOAR_ID 3
SOAR_ID 4
ENUMERATION 5 1 state
ENUMERATION 6 1 nil
ENUMERATION 7 1 kenken
ENUMERATION 8 1 initialize-kenken
SOAR_ID 9
ENUMERATION 10 1 detect-goal
INTEGER_RANGE 11 0 2147483647
SOAR_ID 12
SOAR_ID 13
INTEGER_RANGE 14 11 88
ENUMERATION 15 2 false true
ENUMERATION 16 1 true
ENUMERATION 17 1 true
SOAR_ID 18
ENUMERATION 19 1 apply-equal-constraint
SOAR_ID 20
ENUMERATION 21 1 mark-single-value
SOAR_ID 22
ENUMERATION 23 1 remove-column-row-values
SOAR_ID 24
ENUMERATION 25 1 notice-single-column-row-value
SOAR_ID 26
ENUMERATION 27 1 print-board
SOAR_ID 28
ENUMERATION 29 1 state
ENUMERATION 30 1 print-board
ENUMERATION 31 1 print-row
SOAR_ID 32
ENUMERATION 33 1 initialize-print
SOAR_ID 34
SOAR_ID 35
ENUMERATION 36 1 state
ENUMERATION 37 1 print-row
ENUMERATION 38 1 initial-row
SOAR_ID 39
ENUMERATION 40 1 print-number
SOAR_ID 41
ENUMERATION 42 1 end-row
SOAR_ID 43
ENUMERATION 44 1 end-print
SOAR_ID 45
ENUMERATION 46 1 print-legal-values
SOAR_ID 47
SOAR_ID 48
ENUMERATION 49 1 state
ENUMERATION 50 1 print-legal-values
ENUMERATION 51 1 init-legal-values
SOAR_ID 52
ENUMERATION 53 1 print-single-legal-value
SOAR_ID 54
ENUMERATION 55 1 end-legal-values
SOAR_ID 56
SOAR_ID 57
ENUMERATION 58 1 check-group
SOAR_ID 59
ENUMERATION 60 1 state
ENUMERATION 61 1 check-group
ENUMERATION 62 1 initialize-check
SOAR_ID 63
ENUMERATION 64 1 check-cell-values
SOAR_ID 65
ENUMERATION 66 1 check-cell-values
SOAR_ID 67
SOAR_ID 68
ENUMERATION 69 1 state
ENUMERATION 70 1 check-cell-values
ENUMERATION 71 1 check-legal-value
SOAR_ID 72
ENUMERATION 73 1 end-check-legal-values
SOAR_ID 74
ENUMERATION 75 1 end-check-group
SOAR_ID 76
SOAR_ID 77
ENUMERATION 78 1 add-linear-sum-group
SOAR_ID 79
ENUMERATION 80 1 add-subgroup
SOAR_ID 81
ENUMERATION 82 1 detect-failure
ENUMERATION 83 1 print-value
SOAR_ID 84
102
0 board 12
0 finished 16
0 goal-detected 17
0 io 1
0 mark-count 11
0 name 7
0 operator 4
0 operator 9
0 operator 18
0 operator 20
0 operator 22
0 operator 24
0 operator 26
0 operator 57
0 operator 77
0 operator 79
0 operator 81
0 superstate 6
0 top-state 0
0 type 5
1 input-link 2
1 output-link 3
4 name 8
9 name 10
12 11 13
12 12 13
12 13 13
12 14 13
12 15 13
12 16 13
12 21 13
12 22 13
12 23 13
12 33 13
12 34 13
12 35 13
12 cell 13
13 coordinate 14
13 used 15
18 name 19
20 name 21
22 name 23
24 name 25
26 name 27
28 name 30
28 operator 32
28 operator 34
28 operator 45
28 superstate 0
28 top-state 0
28 type 29
32 name 31
34 name 33
35 name 37
35 operator 39
35 operator 41
35 operator 43
35 operator 47
35 superstate 28
35 top-state 0
35 type 36
39 name 38
41 name 40
43 name 42
45 name 44
47 name 46
48 name 50
48 operator 52
48 operator 54
48 operator 56
48 operator 84
48 superstate 35
48 top-state 0
48 type 49
52 name 51
54 name 53
56 name 55
57 name 58
59 name 61
59 operator 63
59 operator 65
59 operator 67
59 operator 76
59 superstate 0
59 top-state 0
59 type 60
63 name 62
65 name 64
67 name 66
68 name 70
68 operator 72
68 operator 74
68 superstate 59
68 top-state 0
68 type 69
72 name 71
74 name 73
76 name 75
77 name 78
79 name 80
81 name 82
84 name 83
