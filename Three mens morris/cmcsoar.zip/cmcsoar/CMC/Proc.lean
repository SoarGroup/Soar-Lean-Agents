import CMC.Meta
/-!
# The CMC with an expanded procedural module

This file extends the metacognition version (`CMC.Meta`, unchanged) with the account of
procedural processing needed to cover Soar. `CMC.Base` and `CMC.Meta` remain the reference
versions; this layer records where an architecture with automatic rule firing departs from
the single-act picture, and which CMC properties survive.

DECIDED (Laird, 2026-10-28), from formalizing Soar:
1. *Automatic and deliberate procedural processing.* Rules are either retractable
   (i-support: elaboration, operator proposal and evaluation; they fire in parallel and
   their results disappear when they no longer match) or tied to the selected operator
   (o-support: they test the operator and the state and make persistent, destructive
   changes). The two kinds fire separately. The operator is selected at quiescence of the
   automatic processing, and the selection itself is non-monotonic. "A significant expansion
   on the CMC approach", but "only a single operator is selected and applied per cycle so
   that corresponds to a retrieval from the procedural memory in the CMC".
2. *Procedural module state.* Preference memory, instantiation and support records, and the
   goal dependency set are internal state of the procedural module (`PSig.PState`), not
   examinable by rules — like the internal state that perception and motor modules already
   have in the CMC files.
3. *Architecture structures cannot be overwritten.* Procedural processing never removes or
   replaces architecture-written content. It may add to it in Soar (an instance can add
   attributes under a retrieval result); the stricter 2017/metacognition requirement that
   procedural memory never writes those areas is kept as a separate property
   (`PArch.Strict`), which Soar does not satisfy.
4. *Substate structures are procedural process data.* An architecture's report of a
   selection failure (in Soar, the initial structures of the substate) is written to
   `Loc.procProcess`.

Procedural memory is abstract here (`PSig.PM`): the rule language is the architecture's
own. The learning mechanisms act on it as in `CMC.Meta`.
-/

namespace CMC.Proc
open CMC.Meta

/-- A signature with procedural memory and procedural module state. -/
structure PSig extends Sig where
  /-- The contents of procedural memory (e.g., Soar productions). -/
  PM : Type
  /-- Internal state of the procedural module (DECIDED 2026-10-28). -/
  PState : Type

variable {σ : PSig}

abbrev W (σ : PSig) := WM σ.toSig
abbrev E (σ : PSig) := Elem σ.toSig
abbrev Lc (σ : PSig) := L σ.toSig

/-- Content of `w` at `ℓ` is kept in `w'`: nothing removed or replaced. -/
def Keeps (w w' : W σ) (ℓ : Lc σ) : Prop := ∀ e ∈ w ℓ, e ∈ w' ℓ

/-- An architecture conforming to the CMC with an expanded procedural module. All
non-procedural mechanisms are as in `CMC.Meta.Arch`. -/
structure PArch (σ : PSig) where
  /-- **Automatic procedural processing** to quiescence: parallel, retractable firings
  (elaboration, proposal, evaluation), and their retraction. -/
  elaborate : σ.PM → σ.PState → W σ → W σ × σ.PState
  /-- **Selection** at quiescence: one deliberate act or a failure. The act includes its
  application (persistent changes) and the automatic processing that follows it. -/
  select : σ.PM → σ.PState → W σ → Outcome σ.toSig × σ.PState
  /-- **Procedural process data** (DECIDED 2026-10-28: in Soar, substate structures). -/
  procReport : Option SelFail → σ.PState → W σ → List (E σ)
  /-- Architecture-written content is never removed or replaced by automatic processing
  (outside the procedural module's own process area). -/
  elaborate_keeps : ∀ pm p w ℓ, ℓ.archWritten = true → ℓ ≠ Loc.procProcess →
      Keeps w (elaborate pm p w).1 ℓ
  /-- … nor by a deliberate act. -/
  select_keeps : ∀ pm p w a p', select pm p w = (.act a, p') →
      ∀ ℓ, ℓ.archWritten = true → ℓ ≠ Loc.procProcess → Keeps w (a w) ℓ
  retrieve : (d : σ.DMem) → DeclMem σ.toSig → List (E σ) → List (E σ) × List (E σ)
  retrieveTouch : (d : σ.DMem) → DeclMem σ.toSig → List (E σ) → DeclMem σ.toSig
  retrieveTouch_symbolic : ∀ d dm c,
      (retrieveTouch d dm c).elems.map Elem.rel = dm.elems.map Elem.rel
  perceive : (p : σ.PMod) → σ.PLearn → σ.Input → W σ → List (E σ) × List (E σ)
  motor : (m : σ.MMod) → σ.MLearn → List (E σ) → σ.Output
  motorStatus : (m : σ.MMod) → σ.MLearn → List (E σ) → List (E σ)
  appraise : W σ → List (E σ)
  record : DeclMem σ.toSig → W σ → DeclMem σ.toSig
  record_incremental : ∀ dm w r, r ∈ dm.elems.map Elem.rel → r ∈ (record dm w).elems.map Elem.rel
  perceptLearn : (p : σ.PMod) → σ.PLearn → σ.Input → W σ → σ.PLearn
  motorLearn : (m : σ.MMod) → σ.MLearn → List (E σ) → σ.Output → σ.MLearn
  /-- Procedural learning (e.g., chunking, reinforcement learning) acts on procedural
  memory after a cycle. -/
  compose : σ.PM → (W σ × W σ) → σ.PM
  rlTune : σ.PM → (W σ × W σ) → σ.PM
  declCreate : (d : σ.DMem) → DeclMem σ.toSig → (W σ × W σ) → DeclMem σ.toSig
  declTune : (d : σ.DMem) → DeclMem σ.toSig → (W σ × W σ) → DeclMem σ.toSig
  declTune_symbolic : ∀ d dm e, (declTune d dm e).elems.map Elem.rel = dm.elems.map Elem.rel
  declCreate_incremental : ∀ d dm e r, r ∈ dm.elems.map Elem.rel →
      r ∈ (declCreate d dm e).elems.map Elem.rel
  decayWM : Meta σ.toSig → Meta σ.toSig
  decayDM : Meta σ.toSig → Meta σ.toSig
  forgettable : Meta σ.toSig → Bool

/-- The stricter requirement of `CMC.Base` and `CMC.Meta`: deliberate acts never change
architecture-written content at all. Soar does not satisfy it (rules can add under a
retrieval result). -/
def PArch.Strict (A : PArch σ) : Prop :=
  ∀ pm p w a p', A.select pm p w = (.act a, p') →
    ∀ ℓ, ℓ.archWritten = true → ℓ ≠ Loc.procProcess → a w ℓ = w ℓ

structure State (σ : PSig) where
  wm : W σ
  pm : σ.PM
  pst : σ.PState
  dm : σ.DMem → DeclMem σ.toSig
  lastCycle : Option (W σ × W σ)
  ps : σ.PMod → σ.PLearn
  ms : σ.MMod → σ.MLearn

/-- One cognitive cycle: automatic processing to quiescence, selection, application of the
selected act, and the architecture's report in procedural process data.

> "Proposal … Decision … Application" — [Man] §2.5 (Soar) -/
def cycle (A : PArch σ) (pm : σ.PM) (p : σ.PState) (w : W σ) : W σ × σ.PState :=
  let r₁ := A.elaborate pm p w
  let r₂ := A.select pm r₁.2 r₁.1
  (upd (r₂.1.apply r₁.1) Loc.procProcess (A.procReport r₂.1.failure r₂.2 r₁.1), r₂.2)

def decayElemWM (A : PArch σ) (e : E σ) : E σ := { e with «meta» := A.decayWM e.«meta» }
def decayElemDM (A : PArch σ) (e : E σ) : E σ := { e with «meta» := A.decayDM e.«meta» }

/-- Labelled execution, with the labels of `CMC.Meta`. -/
def exec (A : PArch σ) : Label σ.toSig → State σ → State σ × Option σ.Output
  | .perceive p i, s =>
      ({ s with wm := upd (upd s.wm (Loc.percept p .content) (A.perceive p (s.ps p) i s.wm).1)
                          (Loc.percept p .process) (A.perceive p (s.ps p) i s.wm).2 }, none)
  | .retrieve d, s =>
      ({ s with wm := upd (upd s.wm (Loc.decl d .result) (A.retrieve d (s.dm d) (s.wm (Loc.decl d .cue))).1)
                          (Loc.decl d .process) (A.retrieve d (s.dm d) (s.wm (Loc.decl d .cue))).2,
                dm := upd s.dm d (A.retrieveTouch d (s.dm d) (s.wm (Loc.decl d .cue))) }, none)
  | .motor m, s =>
      ({ s with wm := upd s.wm (Loc.motor m .process) (A.motorStatus m (s.ms m) (s.wm (Loc.motor m .command))) },
       some (A.motor m (s.ms m) (s.wm (Loc.motor m .command))))
  | .appraise, s => ({ s with wm := upd s.wm Loc.wmProcess (A.appraise s.wm) }, none)
  | .learnPercept p i, s => ({ s with ps := upd s.ps p (A.perceptLearn p (s.ps p) i s.wm) }, none)
  | .learnMotor m, s =>
      ({ s with ms := upd s.ms m (A.motorLearn m (s.ms m) (s.wm (Loc.motor m .command))
                                   (A.motor m (s.ms m) (s.wm (Loc.motor m .command)))) }, none)
  | .cycle, s =>
      let r := cycle A s.pm s.pst s.wm
      ({ s with wm := r.1, pst := r.2, lastCycle := some (s.wm, r.1),
                dm := upd s.dm σ.epi (A.record (s.dm σ.epi) r.1) }, none)
  | .compose, s => match s.lastCycle with
      | some e => ({ s with pm := A.compose s.pm e }, none)
      | none => (s, none)
  | .rl, s => match s.lastCycle with
      | some e => ({ s with pm := A.rlTune s.pm e }, none)
      | none => (s, none)
  | .create d, s => match s.lastCycle with
      | some e => ({ s with dm := upd s.dm d (A.declCreate d (s.dm d) e) }, none)
      | none => (s, none)
  | .tune d, s => match s.lastCycle with
      | some e => ({ s with dm := upd s.dm d (A.declTune d (s.dm d) e) }, none)
      | none => (s, none)
  | .decay, s =>
      ({ s with wm := fun b => (s.wm b).map (decayElemWM A),
                dm := fun d => ⟨(s.dm d).elems.map (decayElemDM A)⟩ }, none)
  | .forgetWM b, s =>
      if b.archWritten then (s, none)
      else ({ s with wm := upd s.wm b ((s.wm b).filter (fun e => !A.forgettable e.«meta»)) }, none)
  | .forgetDecl d, s =>
      ({ s with dm := upd s.dm d ⟨(s.dm d).elems.filter (fun e => !A.forgettable e.«meta»)⟩ }, none)

def execAll (A : PArch σ) : List (Label σ.toSig) → State σ → State σ × List (Option σ.Output)
  | [], s => (s, [])
  | l :: ls, s =>
      let r := exec A l s
      let rs := execAll A ls r.1
      (rs.1, r.2 :: rs.2)

/-! ## Properties that survive the expansion -/

section Theorems
variable {A : PArch σ}

/-- **Selection failure is reported** in procedural process data on every cycle. -/
theorem cycle_reports (pm : σ.PM) (p : σ.PState) (w : W σ) :
    (cycle A pm p w).1 Loc.procProcess =
      A.procReport (A.select pm (A.elaborate pm p w).2 (A.elaborate pm p w).1).1.failure
        (A.select pm (A.elaborate pm p w).2 (A.elaborate pm p w).1).2 (A.elaborate pm p w).1 := by
  unfold cycle; simp only [upd_same]

/-- **Seriality, with automatic processing.** Outside procedural process data, a cycle's
result is the automatic processing's result with exactly the selected act applied, or with
nothing applied if selection failed. -/
theorem cycle_serial (pm : σ.PM) (p : σ.PState) (w : W σ) (ℓ : Lc σ) (hℓ : ℓ ≠ Loc.procProcess) :
    let r₁ := A.elaborate pm p w
    (∃ a p', A.select pm r₁.2 r₁.1 = (.act a, p') ∧ (cycle A pm p w).1 ℓ = a r₁.1 ℓ) ∨
    (∃ f p', A.select pm r₁.2 r₁.1 = (.fail f, p') ∧ (cycle A pm p w).1 ℓ = r₁.1 ℓ) := by
  intro r₁
  unfold cycle
  simp only
  rw [upd_other _ _ _ hℓ]
  cases h : A.select pm r₁.2 r₁.1 with
  | mk o p' =>
    cases o with
    | act a => exact Or.inl ⟨a, p', rfl, rfl⟩
    | fail f => exact Or.inr ⟨f, p', rfl, rfl⟩

/-- **Architecture-written content is never overwritten by procedural processing**
(DECIDED 2026-10-28). A cycle keeps everything in every architecture-written location other
than procedural process data. -/
theorem cycle_keeps (pm : σ.PM) (p : σ.PState) (w : W σ) (ℓ : Lc σ)
    (ha : ℓ.archWritten = true) (hℓ : ℓ ≠ Loc.procProcess) : Keeps w (cycle A pm p w).1 ℓ := by
  intro e he
  have h₁ := A.elaborate_keeps pm p w ℓ ha hℓ e he
  unfold cycle; simp only; rw [upd_other _ _ _ hℓ]
  cases h : A.select pm (A.elaborate pm p w).2 (A.elaborate pm p w).1 with
  | mk o p' =>
    cases o with
    | act a => exact A.select_keeps pm _ _ a p' h ℓ ha hℓ e h₁
    | fail f => exact h₁

/-- Under the strict requirement, the 2017 and metacognition property holds: the deliberate
act leaves architecture-written content exactly as automatic processing left it. -/
theorem cycle_strict (hs : A.Strict) (pm : σ.PM) (p : σ.PState) (w : W σ) (ℓ : Lc σ)
    (ha : ℓ.archWritten = true) (hℓ : ℓ ≠ Loc.procProcess) :
    (cycle A pm p w).1 ℓ = (A.elaborate pm p w).1 ℓ := by
  unfold cycle; simp only; rw [upd_other _ _ _ hℓ]
  cases h : A.select pm (A.elaborate pm p w).2 (A.elaborate pm p w).1 with
  | mk o p' =>
    cases o with
    | act a => exact hs pm _ _ a p' h ℓ ha hℓ
    | fail f => rfl

/-- **No direct access to declarative memory**, unchanged: the cycle depends only on
working memory, procedural memory and procedural module state.

NOTE ON STRENGTH: the substance is carried by the type of `cycleWM`, which takes no declarative
memory, so the proof is `rw`. The theorem records that fact in a form a reader can cite; it is not
a deep result, and it would fail to typecheck if an instance's cycle were given access to `dm`. -/
theorem cycle_independent_of_decl (s₁ s₂ : State σ) (hw : s₁.wm = s₂.wm) (hp : s₁.pm = s₂.pm)
    (hq : s₁.pst = s₂.pst) : cycle A s₁.pm s₁.pst s₁.wm = cycle A s₂.pm s₂.pst s₂.wm := by
  rw [hw, hp, hq]

/-- Two states that agree on everything except declarative memory. -/
def AgreeExceptDM (s₁ s₂ : State σ) : Prop :=
  s₁.wm = s₂.wm ∧ s₁.pm = s₂.pm ∧ s₁.pst = s₂.pst ∧ s₁.lastCycle = s₂.lastCycle ∧
  s₁.ps = s₂.ps ∧ s₁.ms = s₂.ms

theorem exec_agree (l : Label σ.toSig) (hl : l.isRetrieve = false)
    {s₁ s₂ : State σ} (h : AgreeExceptDM s₁ s₂) :
    AgreeExceptDM (exec A l s₁).1 (exec A l s₂).1 ∧ (exec A l s₁).2 = (exec A l s₂).2 := by
  obtain ⟨w₁, p₁, q₁, d₁, c₁, ps₁, ms₁⟩ := s₁
  obtain ⟨w₂, p₂, q₂, d₂, c₂, ps₂, ms₂⟩ := s₂
  obtain ⟨hw, hp, hq, hc, hps, hms⟩ := h
  simp only at hw hp hq hc hps hms
  subst hw hp hq hc hps hms
  cases l with
  | retrieve d => simp [Label.isRetrieve] at hl
  | compose => cases c₁ <;> simp [exec, AgreeExceptDM]
  | rl => cases c₁ <;> simp [exec, AgreeExceptDM]
  | create d => cases c₁ <;> simp [exec, AgreeExceptDM]
  | tune d => cases c₁ <;> simp [exec, AgreeExceptDM]
  | forgetWM b => by_cases hb : b.archWritten <;> simp [exec, AgreeExceptDM, hb]
  | _ => simp [exec, AgreeExceptDM]

/-- **Declarative knowledge reaches behavior only through retrieval**, re-proved for the
expanded procedural module: automatic processing, selection and procedural module state do
not open another path from declarative memory to working memory or action. -/
theorem decl_influence_requires_retrieval (ls : List (Label σ.toSig))
    (hno : ∀ l ∈ ls, l.isRetrieve = false) {s₁ s₂ : State σ} (h : AgreeExceptDM s₁ s₂) :
    AgreeExceptDM (execAll A ls s₁).1 (execAll A ls s₂).1 ∧
    (execAll A ls s₁).2 = (execAll A ls s₂).2 := by
  induction ls generalizing s₁ s₂ with
  | nil => exact ⟨h, rfl⟩
  | cons l ls ih =>
    have hl := hno l (List.mem_cons_self)
    have hrest : ∀ l' ∈ ls, l'.isRetrieve = false :=
      fun l' hl' => hno l' (List.mem_cons_of_mem l hl')
    obtain ⟨h1, ho⟩ := exec_agree (A := A) l hl h
    obtain ⟨h2, hos⟩ := ih hrest h1
    exact ⟨h2, by simp [execAll, ho, hos]⟩

/-- **Procedural memory changes only by learning**, unchanged. -/
theorem proc_change_is_learning (l : Label σ.toSig) (s : State σ)
    (hne : (exec A l s).1.pm ≠ s.pm) : l = .compose ∨ l = .rl := by
  cases l with
  | compose => exact Or.inl rfl
  | rl => exact Or.inr rfl
  | create => exfalso; apply hne; simp only [exec]; split <;> rfl
  | tune => exfalso; apply hne; simp only [exec]; split <;> rfl
  | forgetWM b => exfalso; apply hne; simp only [exec]; split <;> rfl
  | _ => exact absurd rfl hne

/-- **Procedural module state changes only in the cycle**: no other module reads or writes
it. -/
theorem pstate_only_by_cycle (l : Label σ.toSig) (s : State σ)
    (hne : (exec A l s).1.pst ≠ s.pst) : l = .cycle := by
  cases l with
  | cycle => rfl
  | compose => exfalso; apply hne; simp only [exec]; split <;> rfl
  | rl => exfalso; apply hne; simp only [exec]; split <;> rfl
  | create => exfalso; apply hne; simp only [exec]; split <;> rfl
  | tune => exfalso; apply hne; simp only [exec]; split <;> rfl
  | forgetWM b => exfalso; apply hne; simp only [exec]; split <;> rfl
  | _ => exact absurd rfl hne

end Theorems
end CMC.Proc
