import Soar.Cycle
import Soar.Parse
import Soar.Store
/-!
# `soar-lean`: run a Soar program on the formal model

Usage: `soar-lean FILE.soar [-d N] [--wm] [--watch] [--rl] [--rl-values F] [--trace-file F] [--wm-file F] [--hints F]`

Runs `N` decision cycles (default 100, stopping at `halt`) and prints the decision trace in
the style of Soar's `watch 1`, any `write` output, and optionally the final working memory.
-/
open Soar

def wmLines (st : St) : List String :=
  st.wm.map fun w =>
    let act := if st.wma.on then s!" [{fmtG2 (st.wmaAct st.wmaS w true)}]" else ""
    s!"{w.id} {w.attr.toSoar} {w.val.toSoar}{act}{if w.acc then " +" else ""}"

/-- A float with nine decimal places (for comparison with Soar's printed values). -/
def fmtFloat (x : Float) : String :=
  let neg := x < 0
  let y := (if neg then -x else x) * 1000000000
  let n := y.round.toUInt64.toNat
  let ip := n / 1000000000
  let fp := toString (n % 1000000000)
  (if neg then "-" else "") ++ s!"{ip}." ++ "".pushn '0' (9 - fp.length) ++ fp

/-- The change in brace depth of a line of Soar source (ignoring `|…|` constants and
comments). -/
def braceDelta (l : String) : Int := Id.run do
  let mut d : Int := 0
  let mut inBar := false
  let mut prev := ' '
  for c in l.toList do
    if inBar then
      if c == '|' && prev != '\\' then inBar := false
    else if c == '|' then inBar := true
    else if c == '#' && (prev == ' ' || prev == '\t' || prev == ' ') && d == 0 then break
    else if c == '{' then d := d + 1
    else if c == '}' then d := d - 1
    prev := c
  return d

/-- Follow `source`, `pushd`, `popd` and `cd` commands (outside productions), as Soar 9.6.5's
command line does: a sourced file is read from the current directory, and while it is read
the current directory is the file's own (checked 2026-10-30). The result is one text, in
loading order. -/
partial def expandSource (dir : System.FilePath) (text : String) (stack : List System.FilePath := [])
    (fuel : Nat := 64) : IO (String × System.FilePath × List System.FilePath) := do
  let mut out : Array String := #[]
  let mut dir := dir
  let mut stack := stack
  let mut depth : Int := 0
  for l in text.splitOn "\n" do
    let ws := (l.trimAscii.toString.splitOn " ").filter (· != "")
    let arg (a : String) : String :=
      let a := if (a.startsWith "\"" && a.endsWith "\"") || (a.startsWith "{" && a.endsWith "}") then ((a.drop 1).dropEnd 1).toString else a
      a
    if depth == 0 then
      match ws with
      | ["source", f] =>
        let path := dir / arg f
        if fuel == 0 then throw (IO.userError s!"source nested too deeply at {path}")
        let t ← IO.FS.readFile path
        let fdir := path.parent.getD dir
        let (t', _, _) ← expandSource fdir t [] (fuel - 1)
        out := out.push t'
      | ["pushd", d] => stack := dir :: stack; dir := dir / arg d
      | ["popd"] => match stack with
        | d :: r => dir := d; stack := r
        | [] => pure ()
      | ["cd", d] => dir := dir / arg d
      | _ => out := out.push l
    else out := out.push l
    depth := depth + braceDelta l
  return ("\n".intercalate out.toList, dir, stack)

/-- An input script (`--input F`; see tools/simenv.py): lines `K + ID ^attr VALUE` and
`K - ID ^attr VALUE`, changes to the input link made before the input phase of decision
cycle K. `I2` is the input link; `#name` is an identifier the script names, given a number
from 1,000,000 up in order of first appearance. -/
def inputEnv (text : String) : Env :=
  let lines := (text.splitOn "\n").filterMap fun l =>
    match (l.trimAscii.toString.splitOn " ").filter (· != "") with
    | k :: op :: i :: a :: rest =>
      if (op == "+" || op == "-") && a.startsWith "^" && !rest.isEmpty then
        some (k.toNat!, op == "+", i, (a.drop 1).toString, " ".intercalate rest)
      else none
    | _ => none
  -- resolve names: each `+ … #name` makes a new identifier (as SML's CreateIdWME does); other
  -- uses refer to the latest one
  let (resolved, _, _) := lines.foldl (fun (acc : List (Nat × Bool × Nat × Sym × Sym) × List (String × Nat) × Nat)
      (k, add, i, a, v) =>
    let (out, names, next) := acc
    let cur (t : String) : Option Nat :=
      if t == "I2" || t == "input-link" then some inputLink else (names.find? (·.1 == t)).map (·.2)
    let (vSym, names, next) :=
      if v.startsWith "#" then
        if add then (Sym.id next, (v, next) :: names, next + 1)
        else ((cur v).map Sym.id |>.getD (.str v), names, next)
      else
        let t' := if v.startsWith "|" && v.endsWith "|" && v.length ≥ 2 then ((v.drop 1).dropEnd 1).toString else v
        let y : Sym := if t'.length < v.length then .str t' else match Parse.constOf v with
          | .ok y => y
          | .error _ => .str v
        (y, names, next)
    match cur i with
    | some n => (out ++ [(k, add, n, Sym.str a, vSym)], names, next)
    | none => (out, names, next)) ([], [], 1000000)
  { input := fun dc _ =>
      (resolved.filter (·.1 ≤ dc + 1)).foldl (fun (acc : List WME) (_, add, n, a, v) =>
        let w : WME := { id := n, attr := a, val := v }
        if add then acc ++ [w] else acc.erase w) [] }

/-- The empty semantic store with the settings read from the file. -/
def smemInit (cfg : Parse.SMemConfig) : SMemDB :=
  { activateOnQuery := cfg.activateOnQuery, frequency := cfg.frequency, baseLevel := cfg.baseLevel,
    baseDecay := cfg.baseDecay, baseUpdate := cfg.baseUpdate, baseThreshes := cfg.baseThreshes,
    baseOffset := cfg.baseOffset, baseInhibition := cfg.baseInhibition, thresh := cfg.thresh,
    activateOnAdd := cfg.activateOnAdd, spreading := cfg.spreading, spBaseline := cfg.spBaseline,
    spContinue := cfg.spContinue, spLimit := cfg.spLimit, spDepth := cfg.spDepth, spLoop := cfg.spLoop,
    spWmaSource := cfg.spWmaSource, spEdgeUpd := cfg.spEdgeUpd, spEdgeFactor := cfg.spEdgeFactor }

/-- Options that take a value, and flags that do not (every other argument is the file). -/
def valueOptions : List String :=
  ["--chunks-file", "-d", "--trace-file", "--wm-file", "--hints", "--rl-values", "--smem-file",
   "--ep-file", "--settings", "--mem-support", "--smem-debug", "--wma-debug", "--input",
   "--rete-debug", "--db-dir"]
def flagOptions : List String := ["--wm", "--watch", "--rl", "--no-rete", "--check-match"]

/-- The file to run: the last argument that is neither an option nor an option's value. -/
partial def positionalArg (file : Option String := none) : List String → Option String
  | [] => file
  | o :: r =>
    if valueOptions.contains o then positionalArg file r.tail
    else if flagOptions.contains o then positionalArg file r
    else positionalArg (some o) r

def main (args : List String) : IO UInt32 := do
  -- the value of an option, and all the values of one that may be repeated
  let optVal (o : String) : Option String := (args.zip (args.drop 1)).findSome? fun (a, b) => if a == o then some b else none
  let optVals (o : String) : List String := (args.zip (args.drop 1)).filterMap fun (a, b) => if a == o then some b else none
  let file := positionalArg none args
  let n := ((optVal "-d").map String.toNat!).getD 100
  let showWM := args.contains "--wm"
  let tf := optVal "--trace-file"
  let wf := optVal "--wm-file"
  let hf := optVal "--hints"
  let watch := args.contains "--watch"
  let rlOn := args.contains "--rl"
  let rvf := optVal "--rl-values"
  let smf := optVal "--smem-file"
  let epf := optVal "--ep-file"
  let some file := file | do
    IO.eprintln "usage: soar-lean FILE.soar [-d N] [--wm] [--trace-file F] [--wm-file F]"; return 2
  let src ← IO.FS.readFile file
  let (src, _, _) ← expandSource ((System.FilePath.mk file).parent.getD ".") src
  let ac := Parse.agentConfig src
  let cfg ← match Parse.smemConfig src with
    | .ok c => pure c
    | .error e => do IO.eprintln s!"parse error: {e}"; return 1
  match Parse.parseFile src with
  | .error e => IO.eprintln s!"parse error: {e}"; return 1
  | .ok pm =>
    IO.println s!"{pm.length} productions loaded"
    let hints ← match hf with
      | some f => do
        let ls ← IO.FS.lines f
        pure (ls.toList.filterMap fun l => match l.splitOn " " with
          | k :: rest => some (k.toNat!, " ".intercalate rest)
          | _ => none)
      | none => pure []
    -- `database file`: a store kept at `path` (relative paths under `--db-dir D` if given)
    let dbDir := optVal "--db-dir"
    let dbPath (p : String) : System.FilePath :=
      let fp := System.FilePath.mk p
      match dbDir with | some d => if fp.isAbsolute then fp else System.FilePath.mk d / fp | none => fp
    let readStore (p : String) : IO (Option String) := do
      if ← (dbPath p).pathExists then pure (some (← IO.FS.readFile (dbPath p))) else pure none
    let smemFile := cfg.database == "file" && cfg.path != ""
    let db0 ← if smemFile && cfg.append then
        match ← readStore cfg.path with
        | some txt => match Store.getSMem (Store.tokens txt) with
          | some stored => pure (SMemDB.reopen stored (smemInit cfg))
          | none => do IO.eprintln s!"cannot read the semantic store {cfg.path}"; return 1
        | none => pure (smemInit cfg)
      else if smemFile then
        match ← readStore cfg.path with
        | some txt => pure (((Store.getSMem (Store.tokens txt)).map (SMemDB.reopenEmpty · (smemInit cfg))).getD (smemInit cfg))
        | none => pure (smemInit cfg)
      else pure (smemInit cfg)
    let mut sdb := db0
    for o in cfg.ops do
      sdb := sdb.runOp o
      if let .backup f := o then IO.FS.writeFile (dbPath f) (Store.render (Store.putSMem sdb))
    let db := sdb
    let pol : RLPolicy := match ac.policy with
      | "q-learning" => .q | "on-policy-gq-lambda" => .onGQ | "off-policy-gq-lambda" => .offGQ | _ => .sarsa
    let dec : RLDecay := match ac.decay with
      | "exp" => .exp | "log" => .log | "delta-bar-delta" => .deltaBarDelta | _ => .normal
    let rlp : RLParams := { learning := rlOn || ac.rlLearning == some true, alpha := ac.alpha, gamma := ac.gamma, temporalExtension := ac.temporalExtension, hrlDiscount := ac.hrlDiscount,
                            policy := pol, lambda := ac.lambda, etTolerance := ac.etTolerance, decay := dec, eta := ac.eta, theta := ac.theta, temporalDiscount := ac.temporalDiscount }
    let symOrd := Parse.symbolOrder src
    let st0 : St := { St.init with hints := hints, verbose := watch, rl := rlp, reteOn := !args.contains "--no-rete", checkMatch := args.contains "--check-match" }
    -- RL templates: the loaded rules' duplicate keys and names, and the template counter
    -- (`rl_update_template_tracking`: a loaded rule named rl*…*N moves it past N)
    let tmplNum (nm : String) : Option Nat :=
      if nm.startsWith "rl*" && nm.length ≥ 6 then ((nm.splitOn "*").getLast?.bind String.toNat?) else none
    let tc := pm.foldl (fun c p => match tmplNum p.name with | some k => if k > c then k + 1 else c | none => c) 1
    let st0 : St := { st0 with rlKnownKeys := pm.map Production.dupKey, rlTemplCount := tc,
                               rlKnownNames := pm.map (·.name) ++ symOrd.filterMap (fun y => match y with | .str t => some t | _ => none) }
    let st0 : St := { st0 with maxElab := ac.maxElab, maxGoalDepth := ac.maxGoalDepth, waitSnc := ac.waitSnc, keepTopOprefs := ac.keepTopOprefs }
    let st0 : St := { st0 with smemOn := cfg.enabled, smem := db, wma := Parse.wmaConfig src }
    let ec := Parse.epConfig src
    let edb : EpDB := { trigger := ec.trigger, graphMatch := ec.graphMatch, exclusions := ec.exclusions, gmOrder := ec.gmOrder, phaseSel := ec.phaseSel, balance := ec.balance }
    let epFile := ec.database == "file" && ec.path != ""
    let edb ← if epFile && ec.append then
        match ← readStore ec.path with
        | some txt => match Store.getEp (Store.tokens txt) with
          | some stored => pure (EpDB.reopen stored edb)
          | none => do IO.eprintln s!"cannot read the episodic store {ec.path}"; return 1
        | none => pure edb
      else pure edb
    let st0 : St := { st0 with epOn := ec.enabled, ep := edb, chunkCfg := Parse.chunkConfig src, multi := Parse.multiAttributes src, symRank := symOrd.toArray, symIx := symOrd.enum.foldl (fun m (k, y) => m.insert y k) {} }
    -- commands given with `--settings "c₁; c₂"` run before the file
    let pre := optVals "--settings"
    let (xc, seed) := Parse.exploreConfig ("\n".intercalate (pre.flatMap (·.splitOn ";")) ++ "\n" ++ src)
    let st0 : St := { st0 with explore := xc, rng := MT.seed (seed.getD 0) }
    let env ← match optVal "--input" with
      | some f => do pure (inputEnv (← IO.FS.readFile f))
      | none => pure ({} : Env)
    let st := st0.run pm env n
    -- the stores kept in files, written when the agent ends (Soar closes its databases then)
    if smemFile && (cfg.enabled || !cfg.ops.isEmpty) then
      IO.FS.writeFile (dbPath cfg.path) (Store.render (Store.putSMem st.smem))
    if epFile && st.ep.connected then
      IO.FS.writeFile (dbPath ec.path) (Store.render (Store.putEp st.ep))
    if watch then
      for l in st.firings do IO.println l
    for l in st.log do IO.println l
    unless st.out.isEmpty do
      IO.println "--- write output ---"
      IO.println (String.join st.out)
    if st.halted then IO.println "System halted."
    if st.wmaS.stale > 0 then IO.println s!"wma: {st.wmaS.stale} reads of a freed preference (Soar's result undefined)"
    if showWM then
      IO.println "--- working memory ---"
      for l in wmLines st do IO.println l
    if let some f := tf then IO.FS.writeFile f ("\n".intercalate st.log)
    if let some f := wf then IO.FS.writeFile f ("\n".intercalate (wmLines st))
    if let some f := rvf then
      let rules := (pm ++ st.rlGen).filterMap fun p => p.rlInit?.map (p.name, ·)
      let st := rules.foldl (fun (st : St) (n, v) => st.rlMod n fun x => { x with init := some v }) st
      IO.FS.writeFile f ("\n".intercalate (rules.map fun (nm, _) =>
        let ev := (st.rlRefValue nm).getD 0
        let c := ((st.rlEntry nm).map (·.count)).getD 0
        s!"{nm} {c} {ev}"))
    -- `--mem-support F`: the support of each memory-system result element on a result link
    if let some f := optVal "--mem-support" then
      let resIds := st.wm.filterMap fun w => if w.attr == .str "result" then (match w.val with | .id n => some n | _ => none) else none
      let ls := st.prefs.filterMap fun p =>
        if resIds.contains p.id && ((st.instById p.inst).map (·.kind == .memory)).getD false &&
           st.wm.any (fun w => w.id == p.id && w.attr == p.attr && w.val == p.val) then
          some s!"{p.attr.toSoar} {if p.osup then ":O" else ":I"}" else none
      IO.FS.writeFile f ("\n".intercalate ((ls.toArray.qsort (· < ·)).toList))
    if let some f := smf then
      let db := st.smem
      let ls := db.ltis.flatMap fun l =>
        (db.edgesOf l).map (fun e => s!"{l} {e.attr.toSoar} " ++ match e.val with
          | .const (.float b) => fmtFloat (Float.ofBits b)
          | .const c => c.toSoar
          | .lti m => s!"@{m}") ++
        [s!"{l} ACT {match db.spread.fake.find? (fun (x : Nat × Fake) => x.1 == l) with
          | some (_, f) => f.value
          | none => ((db.ltiAct.find? (fun (x : Nat × Float) => x.1 == l)).map (fun (x : Nat × Float) => x.2)).getD 0}"]
      IO.FS.writeFile f ("\n".intercalate ls)
    -- `--rete-debug F`: the Rete's size and the new matches it did not have
    if let some f := optVal "--rete-debug" then
      let wmNow := st.wm
      let tts := ((st.tt.filter (fun (w, _) => wmNow.contains w)).mergeSort (fun a b => a.2 ≤ b.2)).map fun (w, t) => s!"{t}: {w.id} {w.attr.toSoar} {w.val.toSoar}{if w.acc then " +" else ""}"
      let lv := (st.rete.live.toList.mergeSort (fun a b => a.2 ≤ b.2)).map fun ((n, ts), k) => s!"live {k} {n} {ts}"
      let showT (t : Test) : String := " ".intercalate (t.map fun x => match x with
        | .var v => s!"<{v}>" | .const c => c.toSoar | _ => "~")
      let co := pm.map fun p => s!"order {p.name}: " ++ " ".intercalate ((placeGoals (soarCondOrder st.rank st.multi (reteConds p.conds))).map fun (i, c) =>
        match c with
        | .pos q => s!"[{i.getD 99}]({showT q.id} ^{showT q.attr} {showT q.val}{if q.goal then " G" else ""})"
        | _ => "-(...)")
      let lv := lv ++ co
      IO.FS.writeFile f (s!"{reprStr st.rete}\nmisses {st.rete.misses}\n" ++ "\n".intercalate (st.rete.missEx ++ tts ++ lv))
    -- `--wma-debug F`: each working-memory element's decay history, as Soar's `wma --history`
    if let some f := optVal "--wma-debug" then
      let ls := st.wm.filterMap fun w =>
        (st.wmaS.el (st.ttOf w)).map fun e =>
          s!"{w.id} {w.attr.toSoar} {w.val.toSoar} [{fmtG2 (st.wmaAct st.wmaS w true)}] :: ({e.histRefs}/{e.total}, first @ d{e.first}) " ++
          " ".intercalate (e.hist.map fun (dc, n) => s!"{n}@d{dc}") ++ s!" refs={e.refs}"
      IO.FS.writeFile f ("\n".intercalate (ls ++ [s!"cycle {st.wmaS.cycle}", s!"stale {st.wmaS.stale}"]))
    -- `--smem-debug F`: the activation bookkeeping (clock, access records, histories, prohibits)
    if let some f := optVal "--smem-debug" then
      let db := st.smem
      let ls := [s!"clock {db.clock}"] ++ db.accTimes.map (fun (l, t, f) =>
          s!"acc {l} n={((db.accesses.find? (·.1 == l)).map (·.2)).getD 0} last={t} first={f}") ++
        db.history.map (fun (l, h) => s!"hist {l} {h}") ++ db.prohib.map (fun (l, d) => s!"prohib {l} dirty={d}") ++
        [s!"spread inWm={db.spread.inWm} adds={db.spread.adds} rems={db.spread.rems} spreadTo={db.spread.spreadTo}",
         s!"spread cur={db.spread.cur.map fun ((s, r), (n, nN)) => (s, r, n, nN)}",
         s!"spread like={db.spread.like} trajNum={db.spread.trajNum}",
         s!"spread fake={db.spread.fake.map fun (l, f) => (l, f.base, f.spread, f.value)}",
         s!"spread traj={db.spread.traj}"]
      IO.FS.writeFile f ("\n".intercalate ls)
    if let some f := optVal "--chunks-file" then
      IO.FS.writeFile f ("\n\n".intercalate (st.chunks.map (fun c => chunkToSoar (storedRule st.rank st.multi c))))
    if let some f := epf then
      let db := st.ep
      let ls := (List.range (db.time - 1)).flatMap fun k =>
        (db.episode (k + 1)).map fun (p, a, v, l) =>
          s!"{k + 1} {p} {a.toSoar} " ++ match v with
            | .node n => if l != 0 then s!"#{n}@{l}" else s!"#{n}"
            | .const (.float b) => fmtFloat (Float.ofBits b)
            | .const c => c.toSoar
      IO.FS.writeFile f ("\n".intercalate ls)
    return 0
