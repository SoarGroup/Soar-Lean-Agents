# CMC and Soar in Lean 4

A Lean 4 formalization of the Common Model of Cognition (CMC), with Soar 9.6 as an
architecture built on it.

Developers and coding agents: see CLAUDE.md first; doc/HARNESS.md gives versions and run
times, and doc/DIFFERENCES.md how each remaining difference from Soar 9.6.5 was diagnosed.

## Layout

| File | Contents |
|---|---|
| `CMC/Util.lean` | `upd` and its lemmas, shared by `CMC/Base.lean` and `CMC/Meta.lean` |
| `CMC/Base.lean` | The 2017 Standard Model, with clarifications (unchanged in content from `CMC.lean`; syntax updated for Lean 4.35.0) |
| `CMC/Meta.lean` | The metacognition extension (unchanged in content from `CMC_Meta.lean`; syntax updated for Lean 4.35.0) |
| `CMC/Proc.lean` | The CMC with an expanded procedural module: automatic (retractable) processing, one deliberate act per cycle, procedural module state, no overwriting of architecture structures |
| `Soar/Syntax.lean` | Soar working memory and production language; printer to Soar source |
| `Soar/Match.lean` | Matcher, with a soundness proof |
| `Soar/MatchComplete.lean` | Completeness of the matcher (positive conditions, negations, one-level negated conjunctions) and independence of the order of patterns |
| `Soar/JoinOrder.lean` | The join order returns the rule's own conditions, reordered |
| `Soar/JoinOrderSem.lean` | Moving relational tests between values of one kind keeps the matches |
| `Soar/SyncProps.lean` | `sync_idem`: bringing the Rete up to date twice is the same as once |
| `Soar/SupportProps.lean` | `reteSupport_nil`: with no matches pending, Rete-based support is the o-support rule |
| `Soar/ReachProps.lean` | `reach` is correct: the identifiers linked to a state |
| `Soar/Prefs.lean` | Preference resolution (manual §2.4.2), with proofs about winners and impasses |
| `Soar/Cycle.lean` | Executable decision cycle: preference memory with Soar 9.6.5's slots, timetags, the outer and inner elaboration loops with consistency checks, i/o-support, decision, impasses and substates, results and justifications, goal dependency set, garbage collection, I/O, reinforcement learning, semantic- and episodic-memory commands and results, explanation records and learned rules |
| `Soar/Rete.lean` | The order of Soar 9.6.5's Rete network (`rete.cpp`): node sharing, merged and split beta memories, negative and conjunctive-negation nodes, memories newest first, left and right unlinking; gives the order in which a pass fires its matches and retracts instantiations |
| `Soar/Rhs.lean` | Right-hand-side values and functions |
| `Soar/Chunk.lean` | Chunking (explanation-based): identities, dependency analysis, variablization, rule formation |
| `Soar/Props.lean` | Theorems about the cycle, reinforcement learning and chunking |
| `Soar/Seriality.lean` | At most one selected operator per state over whole runs |
| `Soar/SMem.lean` | Semantic memory: the long-term store, storage, queries, recency, frequency, base-level and spreading activation, `smem --add`, `--remove`, `--query` |
| `Soar/WMA.lean` | Working-memory activation: decay elements, their arithmetic, forgetting estimates (the references and forgetting are in `Soar/Cycle.lean`) |
| `Soar/SMemProps.lean` | Theorems about semantic memory |
| `Soar/Conform.lean` | Soar as an instance of `CMC.Proc.PArch` |
| `Soar/Parse.lean` | Parser for Soar source (`sp {…}`) |
| `Main.lean` | The `soar-lean` program: runs a `.soar` file on the formal model |

## Checking

Requires Lean 4.35.0, which [elan](https://github.com/leanprover/elan) installs on first use from the pinned `lean-toolchain` (core library only; moved from 4.15.0 on October 30, 2026 with no change of meaning, see Appendix A of the report). `lake build` checks every definition and proof.

## Running a Soar program

`lake build soar-lean` builds `.lake/build/bin/soar-lean` (plain `lake build` builds the libraries and checks the proofs). Run `soar-lean agent.soar -d 40 --wm` for the decision
trace, write output and final working memory; add `--watch` for rule firings. Multi-file agents load
through their `source` commands; `python3 tools/flatten.py agent.soar flat.soar` (needs
`pip install soar-sml`) flattens agents that load files by other means.

## Comparing with Soar 9.6.5

`tests/` holds every test set from the report (`.soar` files with `.n` files giving the number of
decision cycles); `tools/run_all.sh results.txt` compares all of them with Soar 9.6.5, each with the options it needs (several hours; `GROUP=A` … `E` or `W` runs one group). The report's
Appendix B is a full user guide.

`python3 tools/diff.py <dir>` (needs
`pip install soar-sml`) runs every `.soar` file in the directory in both Soar 9.6.5 and `soar-lean`
and compares decision traces and final working memory, with identifiers abstracted. `--replay`
makes the model follow Soar's choices among mutually indifferent operators.

## Reinforcement learning

`soar-lean agent.soar --rl` runs with learning on; `--rl-values FILE` writes each RL rule's update count and
value in the form of Soar's `print --rl`. `python3 tools/diff.py <dir> --rl --explore` compares decisions, working
memory and learned values with Soar 9.6.5 under epsilon-greedy exploration (epsilon 0.3, seed 42), replaying
Soar's exploratory choices; add `--noreplay` to let the model make its own choices with the same seed.
Sarsa, Q-learning and on- and off-policy GQ(λ), eligibility traces, the decay modes (normal, exp,
log, delta-bar-delta) and `:template` rules are modelled, with every `rl --set` parameter they use;
`tests/rlvariants` and `tests/rltemplates` check them.

## Soar's Rete order

A model of Soar 9.6.5's Rete (`Soar/Rete.lean`) is the matcher: it gives the matches, the order in
which a pass fires them and retracts instantiations, and each match's support, decided when the
match is added; elements enter it in the order Soar makes them, so timetags are Soar's as well.
Rules with long-term-identifier tests, which the network does not evaluate, are matched by the
model's own matcher (`Soar/Match.lean`), the one the soundness and completeness theorems are about.
`--check-match` compares the two on every cycle. `soar-lean agent.soar --rete-debug FILE` writes
the network's size, any new match the Rete lacks, every element with its timetag and the current
matches; `--no-rete` uses the model's matcher with the earlier ordering (rules in load order). `python3 tools/firecmp.py agent.soar N` prints the first rule firing in N
decisions that differs from Soar's; `python3 tools/ttcmp.py agent.soar N` compares every element of
the final working memory with its timetag. Beyond 400,000 tokens the earlier ordering is used for
the rest of the run.

## Input from an environment

`soar-lean agent.soar --input agent.input` changes the input link before each input phase as the
script says (`K + ID ^attr VALUE`, `K - ID ^attr VALUE`; `I2` is the input link, `#name` an
identifier the script makes). `tools/diff.py` gives `X.input` to Soar through SML too; for a
reactive environment, `X.env.py` defines `step(k, output)`, which `tools/simenv.py` runs against
Soar and records for the model (`tests/input`).

## Exploration and random numbers

`srand`, `decide indifferent-selection` (`--first`, `--last`, `--softmax`, `--epsilon-greedy`,
`--boltzmann`, `--epsilon`, `--temperature`, `--auto-reduce`, `--reduction-policy`,
`--reduction-rate`) and `decide numeric-indifferent-mode` are read from the file, or given before it
with `soar-lean agent.soar --settings "srand 42; decide indifferent-selection --boltzmann"`. The
random-number generator is Soar's MT19937, reproduced bit for bit, and also serves `rand-int` and
`rand-float`. The default policy is softmax and the default seed 0. `tests/explore` exercises every
policy (`python3 tools/diff.py tests/explore --exe`).

## Settings, loading and the parser

`source`, `pushd`, `popd` and `cd` are followed (a sourced file is read from its own directory,
as in Soar). `soar max-elaborations`, `max-goal-depth`, `wait-snc`, `keep-all-top-oprefs` and
`rl --set` parameters are read. `gp` is expanded as Soar 9.6.5 expands it; negations may be nested to
any depth. `tests/settings`, `tests/rlsettings` and `tests/parser` check these;
`python3 tools/memsupport.py <dir>` compares the support of memory-system results with Soar's.

## Right-hand-side functions

Soar 9.6.5's whole right-hand-side function library is modelled except `from-st-xml` and
`accept` (`timestamp` gives a fixed time). `tests/rhslib` exercises every
function; `tools/gen_rhsfuzz.py` generates `tests/rhsfuzz`, random calls compared to 17 digits.

## Semantic memory

Programs with `smem --enable` (or `smem --set learning on`) and `smem --add {…}` run with semantic
memory. `soar-lean agent.soar --smem-file F` writes the final store (`lti attr value` lines and
each LTI's activation). `python3 tools/diff.py <dir> --smem` compares decisions, working memory and
the store with Soar 9.6.5 (LTIs compared up to renaming). `tools/gen_smemfuzz.py` and
`tools/gen_smemfuzz2.py` generate random semantic-memory programs. The long-term-identifier tests `@+`, `@-`, `@` and `!@`,
the `@` function and `link-stm-to-ltm` are modelled (`tests/lti`). `bugs/`
holds programs that show the Soar 9.6.5 kernel defects described in the report.

Spreading activation (`smem --set spreading on`, with its parameters and Soar's rules for
setting them) is modelled; `tools/gen_spread.py` generates `tests/smemspread` (LTIs with explicit
numbers, since Soar numbers the LTIs of one `smem --add` in an order that varies between runs).
`--smem-file` writes a spread LTI's spread activation, as `print @` shows it, and
`--smem-debug F` also writes the spreading tables.

## Episodic memory

Programs with `epmem --set learning on` run with episodic memory (`trigger`, `phase`,
`graph-match`, `graph-match-ordering` and `exclusions` are read from the file; `(cmd epmem --set
…)` actions change `trigger`, `force` and `graph-match` while running). `soar-lean agent.soar
--ep-file F` writes every stored episode (`episode parent attr value` lines, nodes as `#n`).
`python3 tools/diff.py <dir> --epmem` compares decisions, working memory and every episode with
Soar 9.6.5's `epmem --print` (episodes compared up to renaming of nodes; add `--replay` for agents
with indifferent choices). `tools/gen_epfuzz.py` and `tools/gen_epfuzz2.py` generate random
episodic-memory programs.

## Stores kept in files

`smem --set database file` / `epmem --set database file` with `--set path F` keep a store in `F`
between agents, as Soar does: soar-lean writes the store when the run ends, and a later run naming
the same file starts from it when `append` is on (the default for smem, not for epmem).
`smem --backup F`, `smem --clear` and `smem --init` are read. What a new agent finds is
`SMemDB.reopen` and `EpDB.reopen`; the files are soar-lean's own format (`Soar/Store.lean`), not
SQLite. `--db-dir D` resolves relative paths under `D`. `tests/dbfile` holds two-run programs:
`tools/diff.py` runs `X.pre.soar` (for `X.pre.n` decisions) in an agent that is then destroyed,
then `X.soar` in a new agent (`python3 tools/diff.py tests/dbfile --smem --epmem`).

## Working-memory activation

Programs with `wma --set activation on` run with working-memory activation (`decay-rate`,
`decay-thresh`, `petrov-approx`, `forgetting off|naive|bsearch|on`, `forget-wme all|lti` and
`fake-forgetting` are read; as in Soar, settings after activation is on are ignored), and
`epmem --set balance` below 1 weights episodic cues by activation. The working-memory file shows
each element's activation as Soar's `print` does (`S1 count 12 [4.5]`), so `tools/diff.py`
compares activations with every working-memory comparison. `--wma-debug F` writes each decay
element's history in the form of `wma --history`. `tools/gen_wma.py` generates random programs
(`tests/wmafuzz`); `tests/realwma` holds the Soar repository's activation tests, `tests/epwma` and
`tests/smemwma` memory programs with activation on. soar-lean prints a line when a run reaches a
point where Soar 9.6.5 reads a freed preference (report Section 12; `bugs/wma-stale-preference.soar`).

## Chunking

Programs with `chunk always` (or `only`/`except` with `force-learn`/`dont-learn`; `max-chunks`,
`max-dupes` and `automatically-create-singletons` are also read) learn rules. `soar-lean agent.soar
--chunks-file F` writes the learned rules in Soar syntax. `python3 tools/diff.py <dir> --chunk`
compares decisions, working memory and the learned rules with Soar 9.6.5 (`print --chunks`), rules
compared up to renaming of variables and the order of conditions and actions (`tools/chunkcmp.py`);
rule names are compared without the final per-decision counter. `ONLY=pattern` restricts any
`diff.py` run to matching files. `tests/chunkall` holds the Soar repository's Chunking unit-test
agents; `tests/chunkdemo` its demonstration agents, flattened (with Soar's default settings);
`tests/chunkextra` variants of the unit tests with `chunk bottom-only on` or automatic
singletons off. Also read: `chunk add-osk`, `bottom-only`, `singleton`, and `multi-attributes`
(condition ordering).
