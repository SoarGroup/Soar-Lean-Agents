import Soar.Rhs
import Soar.Prefs
/-!
# Soar 9.6 — chunking (explanation-based chunking)

This file gives the learning computation of chunking ([Man] chapter 4): from the record of
the instantiations that fired in a substate, it computes the rule learned when a result is
created. The decision cycle (`Soar/Cycle.lean`) records the instantiations, calls this
computation when results are created, adds learned rules to production memory, and gives
the results to the instantiation of the learned rule.

> "Chunking creates rules that summarize the processing in a substate that produced a
> result." — [Man] §4.1
>
> "EBC analyzes the explanation trace … to determine which working memory elements in the
> superstate were tested, and then variablizes them based on how they were matched." —
> [Man] §4.2

The model follows Soar 9.6.5's explanation-based chunking (`ebc_*.cpp`, checked 2026-10-29):

* **Identities.** Every variable of an instantiation, and every unbound right-hand-side
  variable, has its own identity; constants have none. An element without an equality test
  has an identity of its own.
* **Dependency analysis** ([Man] §4.3, "backtracing"). Starting from the instantiation that
  created the result, conditions on superstate elements (goal level at most the result's
  goal level) are *grounds*; conditions on local elements are traced through the
  instantiation that created the element, whose action is unified with the condition: two
  identities are joined; an identity facing a constant is literalized.
* **Singletons.** Two grounds that matched the same element have their value identities
  joined (`chunk automatically-create-singletons`, on by default, makes every element with a
  symbolic attribute a singleton; otherwise only architectural ones). Conditions on a
  substate's `^superstate` element share one identity for the state and one for the
  superstate, per substate.
* **Rule formation** ([Man] §4.4). Grounds become conditions: each joined identity becomes a
  variable, a literalized identity becomes the constant matched. Conditions with the same
  three elements are merged. Negated conditions are added when their identifier is tied to
  the grounds. Results become actions, with unbound identifiers as new variables. The
  first condition on each state gets the `state` test.

* **Constraints.** Relational tests and disjunctions of local conditions are moved to the
  first ground that tests the same identity ([Man] §4.6.4). Which condition of a rule
  carries a relational test is where Soar's reorderer puts it (`soarOrder`).
* **Literalization by `$`.** A variable marked `$` in a rule is literalized in every
  explanation through that rule.
* **Traces.** Each instantiation records, when it fires, the instantiation whose preference
  supports each element it tests (Soar's `bt.trace`); a selected operator is traced to the
  preference that won the decision (a require if there was one).
* **Results** ([Man] §4.4). The local structure reached from a result's value (a substate
  included) goes with it, traced from preferences made at the results' level.
* **Rule repair** ([Man] §4.6.6): see `Learned.repair`.
* **Operator selection knowledge** (`chunk add-osk`, on by default in Soar 9.6.5). When a
  state's operator is selected, the preferences that decided it are kept (`oskSelect`). An
  instantiation that tests the selected operator of its match goal, and the instantiation
  that proposed it, are backtraced together with the instantiations that made those
  preferences, without identity joins. Prohibit preferences of any operator tested are
  backtraced whatever the setting.
* **Memory retrievals.** A semantic-memory retrieval leaves an explanation record whose
  conditions are the state's link, command and result elements and the command's cue
  (Soar's architectural instantiation for memory systems).
* **deep-copy.** The copied structure is made by the instantiation that called `deep-copy`,
  which also tests each element copied; each copy has its source's identity.
* **Settings.** `chunk singleton`, `bottom-only`, `add-osk`, `max-chunks`, `max-dupes`,
  `automatically-create-singletons`.

SIMPLIFIED: Soar's reorderer breaks ties by the numbers of the constants' symbols, which
depend on the order in which the kernel made them; here that order is approximated by the
order of first appearance in the source file (`Parse.symbolOrder`). On whole look-ahead agents
the model's rule sometimes keeps a relational test between identifiers that Soar's rule
lacks.

Learning from semantic- and episodic-memory retrievals and `add-ltm-links` are modelled.
Rules made from reinforcement-learning templates in substates are made and fired as Soar does
while chunking (`St.addTemplateRule`, tests/rltemplates).
NOT FORMALIZED: the explainer. Preferences
made by rules matching only the top state (which leave no explanation record here) are not
backtraced as operator selection knowledge; they reach a substate's operator slot only when a
substate is returned as a result, and Soar then learns a rule with literal identifiers.
-/

namespace Soar

/-! ## Settings -/

/-- `chunk always|never|only|except` ([Man] §9.4.1 `chunk`). -/
inductive LearnMode where
  | never | always | only | except
  deriving DecidableEq, Repr

/-- The kinds of identifier and value a `chunk singleton` declaration names (Soar 9.6.5
`singleton_element_type`); Soar refuses any other name. -/
inductive SingletonKind where
  | any | state | operator | identifier | constant
  deriving DecidableEq, Repr, Inhabited

def SingletonKind.ofString? : String → Option SingletonKind
  | "any" => some .any | "state" => some .state | "operator" => some .operator
  | "identifier" => some .identifier | "constant" => some .constant | _ => none

/-- Chunking settings. Defaults are Soar 9.6.5's: learning off, `max-chunks 50`,
`max-dupes 3`, `automatically-create-singletons on`. -/
structure ChunkCfg where
  mode : LearnMode := .never
  maxChunks : Nat := 50
  maxDupes : Nat := 3
  autoSingletons : Bool := true
  /-- `chunk add-osk`: backtrace through operator selection knowledge (on in Soar 9.6.5). -/
  addOsk : Bool := true
  /-- `chunk singleton <id-type> <attribute> <value-type>` declarations (types `any`,
  `state`, `identifier`, `operator`, `constant`). -/
  singletons : List (SingletonKind × String × SingletonKind) := []
  /-- `chunk bottom-only`: no rule is learned for a state once one was learned below it. -/
  bottomOnly : Bool := false
  /-- `chunk add-ltm-links`: learned rules link their results to the long-term identifiers the
  original results were linked to. -/
  addLtmLinks : Bool := false
  deriving Repr

/-! ## Explanation records -/

/-- A record of an instantiation fired in a substate (Soar's explanation trace,
[Man] §4.3): the production, its bindings (including new identifiers for unbound
right-hand-side variables), the element each positive condition matched, the negated
conditions, and what it made. -/
structure XInst where
  key   : String
  prod  : Production
  /-- The user rule a learned rule was ultimately learned from (for naming). -/
  orig  : String
  /-- How many learned rules lie between this production and a user rule (for naming). -/
  depth : Nat := 0
  level : Nat
  /-- The match goal: the deepest state tested. -/
  goal  : Nat
  conds : List (Pat × WME)
  negs  : List Cond := []
  b     : Binding
  made  : List WME := []
  prefs : List Pref := []
  /-- Unbound right-hand-side variables (bound in `b` to the new identifiers made). -/
  fresh : List String := []
  /-- Elements it removed. -/
  rems  : List WME := []
  /-- For a justification: its explanation tested `^quiescence t` (Soar carries this to every
  later explanation through the justification). -/
  quiescence : Bool := false
  /-- Operator selection knowledge copied when it fired (Soar's `copy_OSK`): what made the
  preferences that selected an operator it tested, and prohibit preferences of operators it
  tested; backtraced without identity joins. -/
  osk : List String := []
  /-- For each positive condition, the record of the instantiation whose preference supported
  the element when this one fired (Soar's `bt.trace`, fixed when the instantiation is made). -/
  traces : List (Option String) := []
  /-- Variables whose identities are joined from the start (a `deep-copy` copy and its
  source). -/
  joins : List (String × String) := []
  deriving Repr

instance : Inhabited XInst := ⟨{ key := "", prod := { name := "", conds := [], acts := [] }, orig := "", level := 0, goal := 0, conds := [], b := [] }⟩

/-! ## Identities: a union–find structure with literalization -/

abbrev Ident := String

structure UF where
  par  : Std.HashMap Ident Ident := {}
  lits : Std.HashSet Ident := {}
  deriving Repr, Inhabited

def UF.find (u : UF) (x : Ident) : Ident := go 100000 x
where
  go : Nat → Ident → Ident
    | 0, x => x
    | n + 1, x => match u.par[x]? with
      | some y => go n y
      | none => x

/-- Join two identities; the joined identity is literalized if either was. -/
def UF.union (u : UF) (a b : Ident) : UF :=
  let ra := u.find a
  let rb := u.find b
  if ra == rb then u
  else { par := u.par.insert ra rb, lits := if u.lits.contains ra then u.lits.insert rb else u.lits }

def UF.lit (u : UF) (a : Ident) : UF := { u with lits := u.lits.insert (u.find a) }

def UF.isLit (u : UF) (a : Ident) : Bool := u.lits.contains (u.find a)

/-! ## Elements, identities and actions -/

def Pat.elem (p : Pat) : Nat → Test
  | 0 => p.id | 1 => p.attr | _ => p.val

def WME.elem (w : WME) : Nat → Sym
  | 0 => .id w.id | 1 => w.attr | _ => w.val

/-- The equality test of a test: its first variable or constant. -/
def eqTest? (t : Test) : Option STest :=
  t.find? fun st => match st with | .var _ => true | .const _ => true | _ => false

def XInst.ident (x : XInst) (v : String) : Ident := s!"{x.key}:{v}"

/-- The identity of element `e` of the `k`th condition. -/
def XInst.condId (x : XInst) (k e : Nat) (t : Test) : Option Ident :=
  match eqTest? t with
  | some (.var v) => some (x.ident v)
  | some _ => none
  | none => some (x.ident s!"_{k}_{e}")

/-- An element of an action: a variable (with its identity), a constant, or a function call. -/
inductive ATerm where
  | v : Ident → ATerm
  | c : ATerm
  | f : String → List RVal → ATerm

def XInst.term (x : XInst) : RVal → ATerm
  | .var v => .v (x.ident v)
  | .sym _ => .c
  | .call f as => .f f as

def XInst.ev (x : XInst) (r : RVal) : Option Sym := RVal.eval x.b [] r

/-- The action of `x` that made element `w`. -/
def XInst.actFor (x : XInst) (w : WME) : Option Action :=
  x.prod.acts.find? fun a => match a with
    | .make i aa v => (!w.acc || w.attr == .str "operator") && x.ev (.var i) == some (.id w.id) &&
      x.ev aa == some w.attr && x.ev v == some w.val
    | .pref sv o .acceptable _ _ =>
      w.attr == .str "operator" && x.ev (.var sv) == some (.id w.id) && x.ev o == some w.val
    -- a selected operator may have been selected by a require preference
    | .pref sv o .require _ _ =>
      !w.acc && w.attr == .str "operator" && x.ev (.var sv) == some (.id w.id) && x.ev o == some w.val
    | _ => false

def XInst.actTerms (x : XInst) : Action → ATerm × ATerm × ATerm
  | .make i aa v => (.v (x.ident i), x.term aa, x.term v)
  | .pref sv o _ _ _ => (.v (x.ident sv), .c, x.term o)
  | _ => (.c, .c, .c)

/-- The terms (identifier, attribute, value) of the action of `x` that made element `w`. -/
def XInst.termsFor (x : XInst) (w : WME) : Option (ATerm × ATerm × ATerm) := (x.actFor w).map x.actTerms

/-- Are the arguments of a right-hand-side function literalized (`rhsFunctions`)? -/
def literalizingFn (f : String) : Bool := rhsFunctions.any fun r => r.name == f && r.literalizes

partial def XInst.litArgs (x : XInst) (u : UF) : List RVal → UF
  | [] => u
  | .var v :: r =>
    let u := match x.b.get v with
      | some (.id _) => u
      | _ => u.lit (x.ident v)
    x.litArgs u r
  | .call f as :: r => x.litArgs (if literalizingFn f then x.litArgs u as else u) r
  | .sym _ :: r => x.litArgs u r

/-- Unify one element of a condition with the corresponding element of the action that made
the element it matched (Soar's `unify_lhs_rhs_connection`). -/
def unifyEl (y : XInst) (u : UF) (ci : Option Ident) : ATerm → UF
  | .v r => match ci with
    | some c => u.union r c
    | none => u.lit r
  | .c => match ci with
    | some c => u.lit c
    | none => u
  | .f f as =>
    let u := if literalizingFn f then y.litArgs u as else u
    match ci with
    | some c => u.lit c
    | none => u

/-! ## Dependency analysis -/

/-- What learning needs from the architecture state. -/
structure LEnv where
  /-- Goal level of an identifier (large for identifiers local to a substate). -/
  lvl : Nat → Nat
  isGoal : Nat → Bool
  /-- The instantiation that made a working-memory element. -/
  creator : WME → Option XInst
  autoSingletons : Bool
  /-- `chunk singleton` declarations. -/
  singletons : List (SingletonKind × String × SingletonKind) := []
  /-- Identifiers that are operators (have an acceptable preference as an operator). -/
  isOp : Nat → Bool := fun _ => false
  /-- The states (for the identities of their `^superstate` elements). -/
  goals : List Nat := []
  /-- The record with a key. -/
  byKey : String → Option XInst := fun _ => none
  /-- Operator selection knowledge held by the instantiation that proposed a selected
  operator (Soar's `OSK_proposal_prefs`). -/
  propOsk : String → List String := fun _ => []
  /-- The long-term identifier an identifier is linked to, and `chunk add-ltm-links`. -/
  lti : Nat → Option Nat := fun _ => none
  addLtmLinks : Bool := false

/-- A ground or local condition: pattern, element matched, its instantiation, its index. -/
abbrev BCond := Pat × WME × XInst × Nat

structure BT where
  uf : UF := {}
  grounds : List BCond := []
  locals : List BCond := []
  negs : List (Cond × XInst) := []
  /-- The instantiations already backtraced through, by key. -/
  seen : Std.HashSet String := {}
  /-- The first ground for each element (a ground matching the same element is unified with it). -/
  firstGround : Std.HashMap WME BCond := {}
  quiescence : Bool := false
  /-- Relational tests and disjunctions of local conditions ([Man] §4.6.4): the identity
  tested, the test, its instantiation, and the symbol matched. -/
  cons : List (Option Ident × STest × XInst × Sym) := []
  deriving Inhabited

/-- Elements Soar 9.6.5 treats as singletons when automatic singletons are off: those it
creates with `add_impasse_wme(…, true)` and `add_module_wme(…, true)`. -/
def archSingleton (a : String) : Bool :=
  ["type", "superstate", "object", "attribute", "impasse", "smem", "epmem", "reward-link"].contains a

/-- Is an element a singleton (Soar 9.6.5 `wme_is_a_singleton`): its attribute declared
with `chunk singleton` and its identifier and value of the declared kinds, or, with automatic
singletons, any element with a symbolic attribute that has no declaration. -/
def LEnv.singleton (E : LEnv) (w : WME) (aa : String) : Bool :=
  let kind (t : SingletonKind) (y : Sym) : Bool :=
    match t, y with
    | .any, _ => true
    | .state, .id n => E.isGoal n
    | .operator, .id n => E.isOp n
    | .identifier, .id n => !E.isGoal n && !E.isOp n
    | .constant, y => !y.isId
    | _, _ => false
  match E.singletons.find? (fun (_, a, _) => a == aa) with
  | some (it, _, vt) => kind it (.id w.id) && kind vt w.val
  | none => E.autoSingletons

/-- Add a ground, unifying it with an earlier ground that matched the same element. -/
def LEnv.addGround (E : LEnv) (bt : BT) (g : BCond) : BT :=
  let (p, w, x, k) := g
  match bt.firstGround[w]? with
  | none => { bt with grounds := bt.grounds ++ [g], firstGround := bt.firstGround.insert w g }
  | some (p', _, x', k') =>
    let a := x.condId k 2 p.val
    let b := x'.condId k' 2 p'.val
    let single := match w.attr with
      | .str aa => archSingleton aa || E.singleton w aa
      | _ => false
    let u := if single then
        match a, b with
        | some a, some b => bt.uf.union a b
        | some a, none => bt.uf.lit a
        | none, some b => bt.uf.lit b
        | none, none => bt.uf
      else if w.attr == .str "operator" && !w.acc then
        match a, b with
        | some a, some b => bt.uf.union a b
        | _, _ => bt.uf
      else bt.uf
    { bt with uf := u, grounds := bt.grounds ++ [g] }

/-- Backtrace through an instantiation: its conditions on elements at goal level `gl` or
above are grounds, the others locals. -/
partial def LEnv.btInst (E : LEnv) (gl : Nat) (bt : BT) (x : XInst) : BT :=
  if bt.seen.contains x.key then bt else
  let bt := { bt with seen := bt.seen.insert x.key, negs := bt.negs ++ x.negs.map (·, x),
                      quiescence := bt.quiescence || x.quiescence,
                      uf := x.joins.foldl (fun u (a, c) => u.union (x.ident a) (x.ident c))
                              (x.prod.lits.foldl (fun u v => u.lit (x.ident v)) bt.uf) }
  -- operator selection knowledge first, with no identity joins (Soar 9.6.5
  -- `backtrace_through_OSK`)
  let bt := (x.osk ++ E.propOsk x.key).foldl (fun bt k => match E.byKey k with
    | some y => E.btInst gl bt y
    | none => bt) bt
  -- the `state` keyword is Soar's goal test on the identifier, not a condition on `^type`
  -- (the parser writes it as a `^type state` pattern marked as a goal test)
  ((x.conds.enum).filter (fun (_, (p, _)) => !(p.goal && p.attr == [.const (.str "type")] &&
      p.val == [.const (.str "state")]))).foldl (fun bt (k, (p, w)) =>
    -- conditions on a substate's `^superstate` element share the substate's identities
    let bt := if w.attr == .str "superstate" && w.id == x.goal then
        let u := match x.condId k 0 p.id with
          | some c => bt.uf.union c s!"F{w.id}:id"
          | none => bt.uf
        let u := match x.condId k 2 p.val with
          | some c => u.union c s!"F{w.id}:val"
          | none => u
        { bt with uf := u }
      else bt
    if E.lvl w.id ≤ gl then E.addGround bt (p, w, x, k)
    else
      let cs := [0, 1, 2].flatMap fun e =>
        let t := p.elem e
        let eq := eqTest? t
        (t.filter fun st => some st != eq && match st with | .rel .. => true | .disj _ => true | _ => false).map
          fun st => (x.condId k e t, st, x, w.elem e)
      { bt with locals := (p, w, x, k) :: bt.locals, cons := bt.cons ++ cs }) bt

/-- Trace local conditions through the instantiations that made what they matched, until
none are left. Local conditions on a state with no creating instantiation are dropped;
testing `^quiescence t` is noted. -/
partial def LEnv.traceLocals (E : LEnv) (gl : Nat) (bt : BT) : BT :=
  match bt.locals with
  | [] => bt
  | (p, w, x, k) :: rest =>
    let bt := { bt with locals := rest }
    -- the trace recorded when `x` fired, else the instantiation that made the element
    let tr := match (x.traces[k]?).join with
      | some key => E.byKey key
      | none => none
    match tr <|> E.creator w with
    | some y =>
      let u := match y.termsFor w with
        | some (ti, ta, tv) =>
          let u := unifyEl y bt.uf (x.condId k 0 p.id) ti
          let u := unifyEl y u (x.condId k 1 p.attr) ta
          unifyEl y u (x.condId k 2 p.val) tv
        | none => bt.uf
      E.traceLocals gl (E.btInst gl { bt with uf := u } y)
    | none =>
      let q := E.isGoal w.id && w.attr == .str "quiescence" && w.val == .str "t" && !w.acc
      E.traceLocals gl (if q then { bt with quiescence := true } else bt)

/-! ## Variablization -/

structure VS where
  /-- Joined identity ↦ variable of the learned rule. -/
  vars : List (Ident × String) := []
  /-- Variable ↦ the symbol it stands for in this learning episode. -/
  syms : List (String × Sym) := []
  n    : Nat := 0
  deriving Inhabited

def VS.get (vs : VS) (r : Ident) : Option String := (alGet vs.vars r)

/-- The variable for a joined identity, made if new. -/
def VS.varFor (vs : VS) (isGoal : Nat → Bool) (r : Ident) (s : Sym) : String × VS :=
  match vs.get r with
  | some v => (v, vs)
  | none =>
    let pre := match s with
      | .id n => if isGoal n then "s" else "i"
      | _ => "c"
    let v := s!"{pre}{vs.n + 1}"
    (v, { vars := (r, v) :: vs.vars, syms := (v, s) :: vs.syms, n := vs.n + 1 })

/-- The equality test of element `e` of a ground. -/
def eqElem (E : LEnv) (uf : UF) (vs : VS) (g : BCond) (e : Nat) : STest × VS :=
  let (p, w, x, k) := g
  let s := w.elem e
  match x.condId k e (p.elem e) with
  | some i =>
    if uf.isLit i && !s.isId then (.const s, vs)
    else let (v, vs) := vs.varFor E.isGoal (uf.find i) s; (.var v, vs)
  | none => (.const s, vs)

/-- A term of a relational test, by lookup: the variable of its identity if it has one,
otherwise the value matched. -/
def lookupTerm (uf : UF) (vs : VS) (x : XInst) : Term → Option Term
  | .sym s => some (.sym s)
  | .var v => match vs.get (uf.find (x.ident v)) with
    | some cv => some (.var cv)
    | none => match x.b.get v with
      -- a test against an identifier with no variable in the rule is dropped
      | some (.id _) => none
      | some s => some (.sym s)
      | none => none

/-- The other tests of an element (relational tests, disjunctions). -/
def extraTests (uf : UF) (vs : VS) (x : XInst) (t : Test) : Test :=
  let eq := eqTest? t
  t.filterMap fun st =>
    if some st == eq then none else match st with
    | .rel r tm => (lookupTerm uf vs x tm).map (.rel r ·)
    | .disj cs => some (.disj cs)
    | .const c => some (.const c)
    | .var _ => none
    | .lti b => some (.lti b)
    | .ltiRel b tm => (lookupTerm uf vs x tm).map (.ltiRel b ·)

/-- A negated test, by lookup: the variable of its identity, the constant matched if the
identity is literalized, or else a new variable. -/
def negTest (uf : UF) (vs : VS) (x : XInst) (t : Test) : Test × VS :=
  let term (v : String) (vs : VS) : Sum String Sym × VS :=
    let r := uf.find (x.ident v)
    -- a variable bound only inside the negation has a variable of its own there
    let local_ (vs : VS) : Sum String Sym × VS :=
      let key := r ++ "#neg"
      match vs.get key with
      | some cv => (.inl cv, vs)
      | none => let cv := s!"n{vs.n + 1}"; (.inl cv, { vs with vars := (key, cv) :: vs.vars, n := vs.n + 1 })
    if x.fresh.contains v then local_ vs else
    match vs.get r with
    | some cv => (.inl cv, vs)
    | none => match x.b.get v with
      | some s => if uf.isLit r && !s.isId then (.inr s, vs)
                  else let cv := s!"n{vs.n + 1}"; (.inl cv, { vs with vars := (r, cv) :: vs.vars, n := vs.n + 1 })
      | none => local_ vs
  t.foldl (fun (acc : Test × VS) st =>
    let (ts, vs) := acc
    match st with
    | .var v => match term v vs with
      | (.inl cv, vs) => (ts ++ [.var cv], vs)
      | (.inr c, vs) => (ts ++ [.const c], vs)
    | .rel r (.var v) =>
      -- a test against an identifier with no variable in the rule is dropped
      match x.b.get v, vs.get (uf.find (x.ident v)) with
      | some (.id _), none => if x.fresh.contains v then (ts, vs) else (ts, vs)
      | _, _ => match term v vs with
        | (.inl cv, vs) => (ts ++ [.rel r (.var cv)], vs)
        | (.inr c, vs) => (ts ++ [.rel r (.sym c)], vs)
    | st => (ts ++ [st], vs)) ([], vs)

def negPats (uf : UF) (vs : VS) (x : XInst) (ps : List Pat) : List Pat × VS :=
  ps.foldl (fun (acc : List Pat × VS) p =>
    let (out, vs) := acc
    -- an element without an equality test gets a variable of its own
    let withEq (t : Test) (vs : VS) : Test × VS := match eqTest? t with
      | some _ => (t, vs)
      | none => let cv := s!"n{vs.n + 1}"; (.var cv :: t, { vs with n := vs.n + 1 })
    let (i, vs) := negTest uf vs x p.id
    let (a, vs) := negTest uf vs x p.attr
    let (v, vs) := negTest uf vs x p.val
    let (i, vs) := withEq i vs
    let (a, vs) := withEq a vs
    let (v, vs) := withEq v vs
    (out ++ [{ p with id := i, attr := a, val := v }], vs)) ([], vs)

/-- A right-hand-side value of the learned rule. -/
partial def rhsTerm (E : LEnv) (uf : UF) (y : XInst) (vs : VS) (r : RVal) : RVal × VS :=
  match r with
  | .sym s => (.sym s, vs)
  | .var v =>
    let root := uf.find (y.ident v)
    match vs.get root with
    | some cv => (.var cv, vs)
    | none => match y.b.get v with
      | some (.id n) => let (cv, vs) := vs.varFor E.isGoal root (.id n); (.var cv, vs)
      | some s => (.sym s, vs)
      | none => (.sym .nil, vs)
  | .call f as =>
    let (as', vs) := as.foldl (fun (acc : List RVal × VS) a =>
      let (t, vs) := rhsTerm E uf y acc.2 a; (acc.1 ++ [t], vs)) ([], vs)
    (.call f as', vs)

/-- The action of the learned rule for a result made by action `a` of `y`. -/
def rhsAction (E : LEnv) (uf : UF) (y : XInst) (vs : VS) (a : Action) (rem : Bool) : Option Action × VS :=
  let idv (i : String) (vs : VS) : String × VS :=
    let root := uf.find (y.ident i)
    match vs.get root with
    | some cv => (cv, vs)
    | none => vs.varFor E.isGoal root ((y.b.get i).getD .nil)
  match a with
  | .make i aa v | .remove i aa v =>
    let (iv, vs) := idv i vs
    let (aa', vs) := rhsTerm E uf y vs aa
    let (v', vs) := rhsTerm E uf y vs v
    -- a removal, or an element made that the learned rule removes instead
    let isRemove := rem || (match a with | .remove .. => true | _ => false)
    (some (if isRemove then .remove iv aa' v' else .make iv aa' v'), vs)
  | .pref sv o k o₂ num =>
    let (iv, vs) := idv sv vs
    let (o', vs) := rhsTerm E uf y vs o
    let (o₂', vs) := match o₂ with
      | some r => let (t, vs) := rhsTerm E uf y vs r; (some t, vs)
      | none => (none, vs)
    (some (.pref iv o' k o₂' num), vs)
  | _ => (none, vs)

/-- The action of `y` that made a preference. -/
def XInst.prefAct (y : XInst) (p : Pref) : Option Action :=
  y.prod.acts.find? fun a => match a with
    | .pref sv o k o₂ _ =>
      y.ev (.var sv) == some (.id p.state) && y.ev o == some p.op &&
      ((k == p.kind && (o₂.bind y.ev) == p.other) ||
       (k == .binaryIndiff && p.kind == .numericIndiff && (o₂.bind y.ev) == p.num))
    -- `^operator` through an attribute variable
    | .make i aa v => p.kind == .acceptable && y.ev (.var i) == some (.id p.state) &&
      y.ev aa == some (.str "operator") && y.ev v == some p.op
    | _ => false

/-- The action of `y` that removed an element. -/
def XInst.remAct (y : XInst) (w : WME) : Option Action :=
  y.prod.acts.find? fun a => match a with
    | .remove i aa v => y.ev (.var i) == some (.id w.id) && y.ev aa == some w.attr && y.ev v == some w.val
    | _ => false

/-! ## Learning a rule -/

/-- Results of one instantiation: elements made, preferences, removals, each with the
instantiation that made it. -/
structure Results where
  wmes  : List (WME × XInst) := []
  prefs : List (Pref × XInst) := []
  rems  : List (WME × XInst) := []

/-- What learning produces: the rule's conditions and actions, the grounds (paired with the
learned conditions), the bindings of the rule's variables, and the reasons a justification
must be made instead of a chunk. -/
structure Learned where
  conds : List Cond
  acts  : List Action
  /-- Positive conditions of the rule with the element each stands for. -/
  pairs : List (Pat × WME)
  syms  : Binding
  quiescence : Bool
  localNeg : Bool
  deriving Inhabited

/-- Simplify a test: drop repeated tests and replace several disjunctions by their
intersection (as Soar 9.6.5 prints learned rules; checked 2026-10-29). -/
def simplifyTest (t : Test) : Test :=
  let ds := t.filterMap fun st => match st with | .disj cs => some cs | _ => none
  let rest := (t.filter fun st => match st with | .disj _ => false | _ => true).eraseDups
  match ds with
  | [] => rest
  | d :: more => rest ++ [.disj (more.foldl (fun acc cs => acc.filter cs.contains) d)]

/-- Merge conditions whose three elements have the same equality tests ([Man] §4.4: "Merge
redundant conditions"). -/
def mergeConds (cs : List (Pat × WME)) : List (Pat × WME) :=
  let key (q : Pat) := (eqTest? q.id, eqTest? q.attr, eqTest? q.val, q.acc)
  let add (a b : Test) : Test := a ++ b.filter (!a.contains ·)
  cs.foldl (fun (out : List (Pat × WME)) (p, w) =>
    if out.any (fun (q, _) => key q == key p) then
      out.map fun (q, w') => if key q == key p then
        ({ q with id := add q.id p.id, attr := add q.attr p.attr, val := add q.val p.val }, w') else (q, w')
    else out ++ [(p, w)]) []

/-- Learn from the instantiations that made results, for a result goal level `gl` (the
match goal's level minus one). -/
def LEnv.learn (E : LEnv) (gl : Nat) (rs : Results) : Option Learned :=
  let srcs := (rs.wmes.map (·.2) ++ rs.prefs.map (·.2) ++ rs.rems.map (·.2))
  let bt := E.traceLocals gl (srcs.foldl (E.btInst gl) {})
  if bt.grounds.isEmpty then none else
  -- Soar 9.6.5 pushes each ground onto the front of its list (`add_to_grounds`) and builds the
  -- rule's conditions from that list (`create_initial_chunk_condition_lists`): the conditions
  -- come in the reverse of the order the grounds were found, and a constraint goes on the last
  -- ground found that tests its identity
  let bt := { bt with grounds := bt.grounds.reverse }
  -- a result reached through another result's value shares that value's identity
  -- (Soar's `add_pref_to_results`)
  let valTerm (r : WME) (y : XInst) : Option Ident := match y.termsFor r with
    | some (_, _, .v i) => some i
    | _ => none
  let idTerm (w : WME) (y : XInst) : Option Ident := match y.termsFor w with
    | some (.v i, _, _) => some i
    | _ => none
  let uf := rs.wmes.foldl (fun uf (w, yw) =>
    match rs.wmes.find? (fun (r, _) => r.val == .id w.id) with
    | some (r, yr) => match idTerm w yw, valTerm r yr with
      | some a, some b => uf.union a b
      | _, _ => uf
    | none => uf) bt.uf
  let superRoots := E.goals.map fun g => uf.find s!"F{g}:val"
  -- equality tests of the grounds first, so that relational tests can refer to them
  let (eqsRev, vs) := bt.grounds.foldl (fun (acc : List (STest × STest × STest) × VS) g =>
    let (out, vs) := acc
    let (i, vs) := eqElem E uf vs g 0
    let (a, vs) := eqElem E uf vs g 1
    let (v, vs) := eqElem E uf vs g 2
    ((i, a, v) :: out, vs)) ([], {})
  let eqs := eqsRev.reverse
  -- constraints of local conditions go on the first ground with the identity tested
  -- (Soar's `add_additional_constraints`)
  let opCond : Std.HashMap Ident (Nat × Nat) := (bt.grounds.enum).foldl (fun acc (gi, (p, _, x, k)) =>
    [2, 1, 0].foldl (fun acc e => match x.condId k e (p.elem e) with
      | some i => let r := uf.find i; if acc.contains r then acc else acc.insert r (gi, e)
      | none => acc) acc) {}
  let opOf (i : Ident) : Option (Nat × Nat) :=
    let r := uf.find i
    if uf.isLit r then none else opCond[r]?
  let inv : RelOp → RelOp
    | .lt => .gt | .gt => .lt | .le => .ge | .ge => .le | r => r
  let attached : List ((Nat × Nat) × STest) := bt.cons.filterMap fun (eqI, st, x, sym) =>
    match eqI.bind opOf with
    | some at_ => match st with
      | .rel r tm => (lookupTerm uf vs x tm).map fun t => (at_, .rel r t)
      | st => some (at_, st)
    | none => match st, eqI with
      | .rel r (.var v), some i => match opOf (x.ident v) with
        | some at_ =>
          let t : Option Term := match vs.get (uf.find i) with
            | some cv => some (.var cv)
            | none => if sym.isId then none else some (.sym sym)
          t.map fun t => (at_, .rel (inv r) t)
        | none => none
      | _, _ => none
  let more (gi e : Nat) : Test := (attached.filter (·.1 == (gi, e))).map (·.2)
  let pos : List (Pat × WME) := ((bt.grounds.zip eqs).enum).map fun (gi, ((p, w, x, _), (i, a, v))) =>
    -- an element that became a constant needs no other tests: they held of the constant
    let full (eq : STest) (t : Test) (e : Nat) : Test := match eq with
      | .const _ => [eq]
      | _ => eq :: extraTests uf vs x t ++ more gi e
    ({ id := full i p.id 0, attr := full a p.attr 1, val := full v p.val 2, acc := p.acc }, w)
  let pos := mergeConds pos
  let pos := pos.map fun (p, w) =>
    ({ p with id := simplifyTest p.id, attr := simplifyTest p.attr, val := simplifyTest p.val }, w)
  -- the first condition on a state reached through a `^superstate` element tests that it is
  -- a state (Soar 9.6.5 adds no state test for a state reached otherwise; checked 2026-10-29)
  let isSuper (p : Pat) : Bool := match eqTest? p.id with
    | some (.var v) => superRoots.any fun r => vs.get r == some v
    | _ => false
  let (pos, _) := pos.foldl (fun (acc : List (Pat × WME) × List Nat) (p, w) =>
    if E.isGoal w.id && isSuper p && !acc.2.contains w.id then (acc.1 ++ [({ p with goal := true }, w)], w.id :: acc.2)
    else (acc.1 ++ [(p, w)], acc.2)) ([], [])
  -- negated conditions tied to the grounds
  let tc : Std.HashSet Nat := Std.HashSet.ofList (bt.grounds.flatMap fun (_, w, _, _) =>
    w.id :: (match w.val with | .id n => [n] | _ => []))
  let inTc (x : XInst) (ps : List Pat) : Bool := match ps with
    | p :: _ => match eqTest? p.id with
      | some (.var v) => match x.b.get v with
        | some (.id n) => tc.contains n
        | _ => false
      | _ => false
    | [] => false
  -- negated conditions are a set: the same instantiated condition is added once
  let negKey (c : Cond) (x : XInst) : String :=
    let inst (t : Test) : List String := t.map fun st => match st with
      | .var v => match x.b.get v with | some s => s.toSoar | none => "_"
      | .rel r (.var v) => r.toSoar ++ (match x.b.get v with | some s => s.toSoar | none => "_")
      | st => st.toSoar
    let pk (p : Pat) : String := toString (inst p.id, inst p.attr, inst p.val, p.acc)
    match c with
    | .neg ps => toString (ps.map pk)
    | .ncc ps ns => toString (ps.map pk, ns.map (·.map pk))
    | .nccg ns => toString (ns.map fun (d, ps) => (d, ps.map pk))
    | .pos _ => ""
  let negsU := bt.negs.foldl (fun (acc : List (Cond × XInst) × Std.HashSet String) (c, x) =>
    let k := negKey c x
    if acc.2.contains k then acc else (acc.1 ++ [(c, x)], acc.2.insert k)) ([], {})
  let (negs, vs, localNeg) := negsU.1.foldl (fun (acc : List Cond × VS × Bool) (c, x) =>
    let (out, vs, ln) := acc
    match c with
    | .neg ps => if inTc x ps then let (ps', vs) := negPats uf vs x ps; (out ++ [.neg ps'], vs, ln)
                 else (out, vs, true)
    | .ncc ps ns => if inTc x ps then
                     let (ps', vs) := negPats uf vs x ps
                     let (ns', vs) := ns.foldl (fun (a : List (List Pat) × VS) n =>
                       let (n', vs) := negPats uf a.2 x n; (a.1 ++ [n'], vs)) ([], vs)
                     (out ++ [.ncc ps' ns'], vs, ln)
                   else (out, vs, true)
    | .nccg ns => if inTc x ((ns.head?.map (·.2)).getD []) then
                     let (ns', vs) := ns.foldl (fun (a : NegNodes × VS) (d, n) =>
                       let (n', vs) := negPats uf a.2 x n; (a.1 ++ [(d, n')], vs)) ([], vs)
                     (out ++ [.nccg ns'], vs, ln)
                   else (out, vs, true)
    | .pos _ => (out, vs, ln)) ([], vs, false)
  -- results become actions; an acceptable preference also appears as an element
  let isPrefW (w : WME) : Bool := rs.prefs.any fun (p, _) =>
    p.kind == .acceptable && p.state == w.id && w.attr == .str "operator" && p.op == w.val
  let addAct (rem : Bool) (acc : List Action × VS) (y : XInst) (oa : Option Action) : List Action × VS :=
    match oa with
    | some a => let (a', vs) := rhsAction E uf y acc.2 a rem; (acc.1 ++ a'.toList, vs)
    | none => acc
  let (acts, vs) := rs.wmes.foldl (fun acc (w, y) => if isPrefW w then acc else addAct false acc y (y.actFor w)) ([], vs)
  let (acts, vs) := rs.prefs.foldl (fun acc (p, y) => addAct false acc y (y.prefAct p)) (acts, vs)
  let (acts, vs) := rs.rems.foldl (fun acc (w, y) => addAct true acc y (y.remAct w)) (acts, vs)
  -- `chunk add-ltm-links` (Soar 9.6.5 `add_LTM_linking_actions`): each identifier of the
  -- results that is local to the substate and linked to a long-term identifier, taken in the
  -- order the actions' symbols are variablized, gets `(link-stm-to-ltm <v> n)`
  let linkActs : List Action := if !E.addLtmLinks then [] else
    let tv (t : RVal) : List String := match t with | .var u => [u] | _ => []
    let vars := acts.flatMap fun a => match a with
      | .make i x v | .remove i x v => i :: (tv x ++ tv v)
      | .pref i o _ o₂ _ => i :: (tv o ++ (o₂.map tv).getD [])
      | _ => []
    vars.eraseDups.filterMap fun v => match vs.syms.find? (·.1 == v) with
      | some (_, .id n) => (E.lti n).bind fun l =>
          if E.lvl n == gl + 1 then some (Action.cmd ["link-stm-to-ltm", s!"<{v}>", toString l]) else none
      | _ => none
  some { conds := pos.map (fun (p, _) => .pos p) ++ negs, acts := acts ++ linkActs, pairs := pos,
         syms := vs.syms, quiescence := bt.quiescence, localNeg := localNeg }

/-! ## Rule repair

> "Chunking may learn a rule with conditions that are not connected to a state, or actions on
> identifiers that no condition binds … the chunker will repair the rule by adding conditions
> that connect them" — [Man] §4.6.6 (Soar 9.6.5 `Repair_Manager`)

A learned rule is checked as Soar's reorderer checks it: every identifier of a positive
condition that is no condition's value must be tested as a state, and every action's
identifier must be bound by the conditions or made by an earlier action. Each ungrounded
identifier is connected by the working-memory elements on a path to it from the state at its
level (found by Soar's depth-first walk over elements made by rules), and states in between
by their `^superstate` elements. If the repaired rule is still ungrounded, a justification is
made instead. -/

/-- What repair needs from working memory. -/
structure REnv where
  /-- Elements on an identifier made by rules (those with a preference in Soar). -/
  prefWmes : Nat → List WME
  /-- `^superstate` elements. -/
  superW : Nat → Option WME
  lvl : Nat → Nat
  /-- The states, with their levels. -/
  goals : List (Nat × Nat)
  /-- The level of the rule's match goal. -/
  matchLevel : Nat
  /-- Identifiers that a rule behind the results made as new identifiers (an unbound
  right-hand-side variable): Soar 9.6.5 does not count an action on one as ungrounded
  (`reorder_action_list`, `rhs_value_to_was_unbound_var`). -/
  rhsNew : Nat → Bool := fun _ => false

def eqVarOf (t : Test) : Option String :=
  t.findSome? fun st => match st with | .var v => some v | _ => none

def actId : Action → Option String
  | .make i _ _ => some i
  | .remove i _ _ => some i
  | .pref i _ _ _ _ => some i
  | _ => none

/-- The ungrounded identifier variables of a learned rule. -/
def Learned.dangling (ln : Learned) : List String :=
  let ps := positives ln.conds
  let valVars := ps.filterMap (eqVarOf ·.val)
  let roots := (ps.filterMap (eqVarOf ·.id)).eraseDups.filter (!valVars.contains ·)
  let lhs := roots.filter fun r => !ps.any (fun p => p.goal && eqVarOf p.id == some r)
  -- actions in an order in which each identifier is bound first (Soar's `reorder_action_list`)
  let (_, rest) := (List.range (ln.acts.length + 1)).foldl
    (fun (acc : List String × List (Nat × Action)) _ =>
      let (b, rest) := acc
      let ok := rest.filter fun (_, a) => match actId a with
        | some i => b.contains i
        | none => true
      (b ++ ok.flatMap (actionVars ·.2), rest.filter fun (j, _) => !ok.any (·.1 == j)))
    (ps.flatMap Pat.eqVars, ln.acts.enum)
  (lhs ++ rest.filterMap (actId ·.2)).eraseDups

/-- Soar's depth-first walk from a state to an identifier (`find_path_to_goal_for_symbol`):
the elements on the path found, last first. -/
partial def repairPath (R : REnv) (target : Nat) : List (Nat × List WME) → List Nat → Option (List WME)
  | [], _ => none
  | (root, path) :: rest, seen =>
    let (seen, pushed, found) := (R.prefWmes root).foldl
      (fun (acc : List Nat × List (Nat × List WME) × Option (List WME)) w =>
        let (seen, pushed, found) := acc
        if found.isSome then acc else match w.val with
        | .id v => if seen.contains v then acc
                   else if v == target then (v :: seen, pushed, some (w :: path))
                   else (v :: seen, pushed ++ [(v, w :: path)], none)
        | _ => acc) (seen, [], none)
    match found with
    | some p => some p
    | none => repairPath R target (pushed.reverse ++ rest) seen

/-- Repair a learned rule; `none` when it cannot be grounded. -/
def Learned.repair (ln : Learned) (R : REnv) : Option Learned :=
  let dang := ln.dangling
  if dang.isEmpty then some ln else
  let dsyms := dang.filterMap fun v => match ln.syms.get v with
    | some (.id n) => some (v, n)
    | _ => none
  if dsyms.length != dang.length then none else
  let dsyms := dsyms.filter (fun (_, n) => !R.rhsNew n)
  let target := (dsyms.map (fun (_, n) => R.lvl n)).foldl min R.matchLevel
  let ruleWs := ln.pairs.map (·.2)
  let tested : List Nat := ruleWs.flatMap fun w => w.id :: (match w.val with | .id n => [n] | _ => [])
  -- `^superstate` elements of states between the highest ungrounded identifier and the match
  -- goal that the rule does not test (`add_state_link_WMEs`)
  let links := R.goals.filterMap fun (g, l) =>
    if target < l && l < R.matchLevel && !tested.contains g then
      match R.goals.find? (·.2 == l + 1) with
      | some (c, _) => R.superW c
      | none => none
    else none
  -- a path from the state at each identifier's level (`add_path_to_goal_WMEs`)
  let paths := dsyms.flatMap fun (_, n) =>
    if R.goals.any (·.1 == n) then [] else
    match R.goals.find? (·.2 == R.lvl n) with
    | some (g, _) => match repairPath R n [(g, [])] [g] with
      | some p => p.filter (fun w => !(ruleWs.contains w && w.val != .id n))
      | none => []
    | none => []
  let newWs := (links ++ paths).eraseDups
  -- identifiers keep the variables the rule has for them (`sti_variablize_test`); an
  -- ungrounded identifier keeps the variable of the condition or action that left it
  -- ungrounded, which may differ from one another condition has for the same identifier
  let vars0 : List (Nat × String) := dsyms.map (fun (v, n) => (n, v)) ++
    ln.pairs.flatMap (fun (p, w) =>
      (match eqVarOf p.id with | some v => [(w.id, v)] | none => []) ++
      (match eqVarOf p.val, w.val with | some v, .id n => [(n, v)] | _, _ => []))
  let term (n : Nat) (m : List (Nat × String)) (k : Nat) : String × List (Nat × String) × Nat :=
    match m.find? (·.1 == n) with
    | some (_, v) => (v, m, k)
    | none => let v := s!"r{k + 1}"; (v, (n, v) :: m, k + 1)
  let (added, m, _) := newWs.foldl (fun (acc : List (Pat × WME) × List (Nat × String) × Nat) w =>
    let (out, m, k) := acc
    let (iv, m, k) := term w.id m k
    let (vt, m, k) : STest × List (Nat × String) × Nat := match w.val with
      | .id n => let (v, m, k) := term n m k; (.var v, m, k)
      | sy => (.const sy, m, k)
    (out ++ [({ id := [.var iv], attr := [.const w.attr], val := [vt], acc := w.acc }, w)], m, k))
    ([], vars0, 0)
  let newSyms := (m.filter (fun (_, v) => (ln.syms.get v).isNone)).map (fun (n, v) => (v, Sym.id n))
  let ln' := { ln with conds := ln.conds ++ added.map (fun (p, _) => Cond.pos p),
                       pairs := ln.pairs ++ added, syms := ln.syms ++ newSyms }
  if ln'.dangling.isEmpty then some ln' else none

/-! ## Names and printing -/

/-- The name of a learned rule (Soar 9.6.5, `generate_name_for_new_rule`):
`chunk[x<depth>]*<rule>*<impasse>*t<decision>-<n>`, where the impasse is that of the match
goal's superstate.

Soar 9.6.5 names every no-change impasse `OpNoChange`, including state no-change impasses
(`create_new_context` is always called with `isONC = true`; checked 2026-10-29). -/
def chunkName (orig : String) (depth : Nat) (imp : Option Impasse) (dc n : Nat) : String :=
  let x := if depth ≥ 1 then s!"x{depth + 1}" else ""
  let it := match imp with
    | some .tie => "*Tie" | some .conflict => "*Conflict" | some .constraintFailure => "*Failure"
    | some .stateNoChange => "*OpNoChange" | some .operatorNoChange => "*OpNoChange"
    | none => ""
  s!"chunk{x}*{orig}{it}*t{dc}-{n}"

/-- A learned rule in Soar syntax, with `state` on conditions that test a state. -/
def chunkToSoar (p : Production) : String :=
  let pr (k : Nat) (q : Pat) : String :=
    s!"({if q.goal then "state " else ""}{testToSoar s!"_i{k}" q.id} ^{testToSoar s!"_a{k}" q.attr} " ++
      s!"{testToSoar s!"_v{k}" q.val}{if q.acc then " +" else ""})"
  let cs := (p.conds.zip (List.range p.conds.length)).map fun (c, k) => match c with
    | .pos q => pr k q
    | c => c.toSoar k false
  -- conditions on states first
  let (gs, rest) := (p.conds.zip cs).partition fun (c, _) => match c with
    | .pos q => q.goal
    | _ => false
  "sp {" ++ p.name ++ "\n   :chunk\n   " ++ "\n   ".intercalate ((gs ++ rest).map (·.2)) ++ "\n-->\n   " ++
    "\n   ".intercalate (p.acts.map Action.toSoar) ++ "\n}"

/-- A learned rule as Soar 9.6.5 stores it: its conditions in the order of Soar's reorderer,
with the tests the reorderer takes out put back on the first condition, in that order, that
binds their variables (`reorder_lhs`, `restore_and_deallocate_saved_tests`), and the state test
on the first condition on each state. Soar prints and compares rules in this form. -/
def storedRule (rank : Sym → Nat) (multi : List (String × Nat)) (p : Production) : Production :=
  let goals := (positives p.conds).filterMap fun q => if q.goal then eqTerm? q.id else none
  let cs := soarConds rank multi p.conds
  let (cs, _) := cs.foldl (fun (acc : List Cond × List Term) c => match c with
    | .pos q =>
      let g := match eqTerm? q.id with
        | some i => goals.contains i && !acc.2.contains i
        | none => false
      (acc.1 ++ [.pos { q with goal := g }], if g then (eqTerm? q.id).toList ++ acc.2 else acc.2)
    | c => (acc.1 ++ [c], acc.2)) ([], [])
  { p with conds := cs }

end Soar
