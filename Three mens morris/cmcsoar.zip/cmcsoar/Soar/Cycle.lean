import Soar.Match
import Soar.Prefs
import Soar.SMem
import Soar.EpMem
import Soar.Chunk
import Soar.Explore
import Soar.WMA
import Soar.Rete
import Std.Data.HashMap
import Std.Data.HashSet
/-!
# Soar 9.6 — the decision cycle, impasses and substates

This file gives an executable semantics of Soar's execution cycle ([Man] §2.5–2.7):
elaboration in waves to quiescence, i-support and o-support, the decision procedure,
impasses and substates, results and justifications, the goal dependency set, removal of
unlinked structures, input and output.

DECIDED (Laird, 2026-10-28), on how this relates to the CMC:
* Rules either test the operator and state and modify the state, making persistent
  (destructive) changes — o-support — or are retractable — i-support. "i-supported rules fire
  in parallel, and o-supported rules fire in parallel, but separate from i-support. The
  operator is selected at quiescence." Selection of the operator is also non-monotonic. This
  is a significant expansion of the CMC's account of procedural memory; the correspondence is
  that a single operator is selected and applied per cycle, which corresponds to the CMC's
  single deliberate act (the retrieval from procedural memory).
* Preference memory, instantiation and support records, and the goal dependency set are
  internal state of the procedural module (`PState` below), not examinable by rules.
* Rules cannot overwrite architecture-created structures (state and substate structures,
  operator selections). Checked against Soar 9.6.5 (2026-10-28): rules that remove
  `^type state`, `^superstate`, `^impasse`, or a semantic-memory `^success` status have no
  effect. Rules can *add* attributes to those objects, including under `^smem.result`; the
  CMC's requirement that procedural memory never write a result area is stronger than Soar.
  Correction (2026-10-29): rules *can* remove semantic-memory status elements such as
  `^success` (the earlier check used a status element not made by semantic memory); see the
  semantic-memory section below.
* The initial structures of a substate are procedural process data. (By extension, so are
  the initial structures of the top state.)
-/

namespace Soar

/-! ## Architecture state -/

/-- Which kind of instantiations an elaboration cycle fires (Soar's `FIRING_TYPE`).

DECIDED (Laird, 2026-10-28): "i-supported rules fire in parallel, and o-supported rules fire
in parallel, but separate from i-support." In Soar 9.6.5 the kind is chosen for the highest
state with pending activity: `IE` (new i-supported instantiations and retractions) if that
state has any, otherwise `PE` (new o-supported instantiations; application phase only). -/
inductive Firing where
  | ie | pe
  deriving DecidableEq, Repr

/-- What made an instantiation (Soar 9.6.5 `production_type`, and the memory systems'
architectural instantiations): a rule, a justification, a learned rule, or semantic or episodic
memory (`SMem_Manager::add_triple_to_recall_buffer`, `epmem_process_buffered_wmes`). -/
inductive InstKind where
  | rule | justification | chunk | memory
  deriving DecidableEq, Repr, Inhabited

/-- An instantiation: a matched production (identity: production name plus the elements
matched), a justification, or an architectural instantiation of a memory system. Its
preferences are in preference memory (`St.prefs`), tagged with `iid`; `made`, `prefs` and
`rems` record what its actions made (acceptable preferences as elements, operator preferences,
and reject preferences as removals), for learning.

An instantiation is in the match set (`inMs`) while its conditions match. An o-supported
instantiation that no longer matches is retracted but its preferences stay; an i-supported one
loses its preferences. Retracted instantiations of substates are kept until the substate is
removed, since backtracing follows the conditions of the instantiation that made an element
even after the element is gone (Soar keeps them through the references of other
instantiations' conditions).

> "Soar creates an instantiation of the production." — [Man] §2.3.1.1
> "Soar creates a temporary production, called a justification." — [Man] §2.7.4 -/
structure Inst where
  iid   : Nat := 0
  name  : String
  ws    : List WME
  /-- The timetags of the elements matched. -/
  tts   : List Nat := []
  level : Nat
  /-- The match goal (the deepest state tested). -/
  goal  : Nat := 0
  osup  : Bool := false
  kind  : InstKind := .rule
  inMs  : Bool := true
  made  : List WME := []
  prefs : List Pref := []
  rems  : List WME := []
  /-- The key of its explanation record (chunking), if one was kept. -/
  uid   : String := ""
  /-- The timetags of its positive conditions' elements in the rule's order (its key in the
  Rete, `Soar.Rete`). -/
  rkey  : List Nat := []
  deriving Repr

/-- A justification's instantiation. -/
def Inst.just (i : Inst) : Bool := i.kind == .justification

/-- A preference in preference memory (Soar 9.6.5 `preference`): every action of an
instantiation makes one — an element is an acceptable preference, a removal a reject
preference. `pid` numbers preferences in the order they were asserted; `level` and `goal` are
those of the instantiation (its match goal), and a preference is removed with its goal (Soar's
`preferences_from_goal`).

> "Preferences are held in a separate preference memory where they cannot be tested by
> productions." — [Man] §2.2 -/
structure PRec where
  pid   : Nat
  id    : Nat
  attr  : Sym
  val   : Sym
  kind  : PrefKind
  ref   : Option Sym := none
  num   : Option Sym := none
  osup  : Bool := false
  inst  : Nat := 0
  level : Nat := 1
  goal  : Nat := 0
  /-- The pass of the inner elaboration loop that asserted it. -/
  pass  : Nat := 0
  /-- Its place in the order Soar 9.6.5 adds preferences to preference memory
  (`assert_new_preferences` takes the pass's instantiations newest first, and each one's
  preferences in the reverse of the order its actions made them). -/
  aseq  : Nat := 0
  deriving Repr, DecidableEq

/-- An operator preference as the decision procedure sees it. -/
def PRec.toPref (p : PRec) : Pref :=
  { state := p.id, op := p.val, kind := p.kind, other := p.ref, num := p.num }

/-- A working-memory element made from preference memory, with the preference that supports it
(Soar's `w->preference`, set when the element's slot is decided). -/
structure WEnt where
  w    : WME
  pref : Nat
  deriving Repr, DecidableEq

/-- A state in the goal stack. `impasse` records why a substate exists (none for the top
state); `gds` is its goal dependency set ([Man] §2.7.9). -/
structure Goal where
  id      : Nat
  level   : Nat
  impasse : Option (Impasse × Sym × List Sym) := none   -- type, attribute, items
  gds     : List (WME × Nat) := []
  /-- Reinforcement learning, per state ([Man] §5.3.2): the RL rules behind the last RL
  operator selected here, its Q-value, reward collected since, and gap and hierarchy ages. -/
  rlPrev   : List String := []
  rlReward : Float := 0
  rlGap    : Nat := 0
  rlHrl    : Nat := 0
  /-- Eligibility traces of RL rules, in the order they were made, and the importance-sampling
  ratio of the last RL selection (for GQ(λ)). -/
  rlTraces : List (String × Float) := []
  rlRho    : Float := 1
  /-- The kind of firing interrupted here when activity moved to a higher state (Soar's
  `saved_firing_type`). -/
  savedFT  : Option Firing := none
  deriving Repr

/-- Reinforcement-learning parameters (the `rl` command). Defaults are Soar 9.6.5's
(checked 2026-10-28): learning off, Sarsa, learning rate 0.3, discount rate 0.9, temporal
extension on, hrl-discount off, eligibility traces off.

[Man] §5.3.2 says the default of `hrl-discount` is on; in Soar 9.6.5 it is off. -/
inductive RLPolicy where
  | sarsa | q | onGQ | offGQ
  deriving DecidableEq, Repr

inductive RLDecay where
  | normal | exp | log | deltaBarDelta
  deriving DecidableEq, Repr

structure RLParams where
  learning : Bool := false
  alpha : Float := 0.3
  gamma : Float := 0.9
  temporalExtension : Bool := true
  hrlDiscount : Bool := false
  /-- `learning-policy`: sarsa, q-learning, on-policy-gq-lambda, off-policy-gq-lambda. -/
  policy : RLPolicy := .sarsa
  /-- `eligibility-trace-decay-rate` (λ) and `eligibility-trace-tolerance`. -/
  lambda : Float := 0
  etTolerance : Float := 0.001
  /-- `decay-mode`: normal, exp, log, delta-bar-delta. -/
  decay : RLDecay := .normal
  /-- `step-size-parameter` (η, for GQ(λ)) and `meta-learning-rate` (θ, for delta-bar-delta). -/
  eta : Float := 1
  theta : Float := 0.1
  /-- `temporal-discount`: whether gaps count in the discount. -/
  temporalDiscount : Bool := true
  deriving Repr

def RLParams.offPolicy (p : RLParams) : Bool := p.policy == .q || p.policy == .offGQ
def RLParams.gql (p : RLParams) : Bool := p.policy == .onGQ || p.policy == .offGQ

/-- The condition orders of one rule (see `St.ordCache`). -/
structure OrdEntry where
  conds : List Cond
  multi : List (String × Nat)
  join  : List Cond
  sord  : List (Nat × Pat)
  rord  : List (Option Nat × Cond)
  deriving Repr

/-- Everything the agent records about one RL rule (Soar 9.6.5 `rl_data` of the rule's
`production`): its initial value (none once the rule is no longer an RL rule), the learned
(expected current, expected future) reward, the GQ(λ) secondary weight with delta-bar-delta's
β and h (Soar's initial values 0, -3 and 0), the value on its right-hand side
(`action_list->referent`: set to the rule's expected current plus future reward when it is
updated, but not changed by GQ(λ)'s later correction of the expected future reward; new
instantiations take it, and `print --rl` shows it), and how many times it has been updated. -/
structure RLEntry where
  init  : Option Float := none
  vals  : Option (Float × Float) := none
  aux   : Option (Float × Float × Float) := none
  ref   : Option Float := none
  count : Nat := 0
  deriving Repr

/-- The architecture state. Everything except working memory itself is internal to the
procedural module and invisible to rules. -/
structure St where
  /-- Architecture-created elements: state structures and operator selections. -/
  arch   : List WME
  /-- Elements placed on the input link by the environment. -/
  input  : List WME := []
  /-- Instantiations (in the match set, or retracted and kept; see `Inst`). -/
  insts  : List Inst := []
  /-- Preference memory, in the order preferences were asserted. -/
  prefs  : List PRec := []
  /-- Elements made from preference memory, with their supporting preferences, in the order
  they were made. -/
  slots  : List WEnt := []
  pNext  : Nat := 1
  iNext  : Nat := 1
  /-- Timetags of the elements in working memory ([Man] §3.1.3; Soar's `timetag`): an element
  that is removed and made again is a new element, with a new timetag. -/
  tt     : List (WME × Nat) := []
  tNext  : Nat := 1
  /-- States whose operator slot has changed preferences (Soar's slot `changed` flag), and the
  level of the highest of them since the last decision (`highest_goal_whose_context_changed`). -/
  ctxChanged : List Nat := []
  ctxTop : Option Nat := none
  /-- The preferences of the instantiations made so far in the current pass of the inner
  elaboration loop, not yet asserted (Soar's `newly_created_instantiations`, whose preferences
  `assert_new_preferences` adds to preference memory at the end of the pass). -/
  fresh : List PRec := []
  goals  : List Goal
  nextId : Nat
  halted : Bool := false
  /-- Set by `(interrupt)`: the run stops at the end of the current phase. -/
  stopped : Bool := false
  /-- Text produced by `write`. -/
  out    : List String := []
  dc     : Nat := 0
  log    : List String := []
  /-- Replay of indifferent choices: decision number ↦ signature of the operator to choose
  (used only to compare runs with Soar 9.6.5, whose tie-breaking order is not specified). -/
  hints  : List (Nat × String) := []
  /-- The random-number generator (Soar's `srand`) and the exploration settings
  (`decide indifferent-selection`, `decide numeric-indifferent-mode`). -/
  rng     : MT := MT.seed 0
  /-- Passes of the inner elaboration loop so far. -/
  passNo  : Nat := 0
  /-- Soar 9.6.5's `soar` settings: max-elaborations, max-goal-depth, wait-snc and
  keep-all-top-oprefs, with their defaults. -/
  maxElab : Nat := 100
  /-- The kind of the last elaboration cycle (Soar's `FIRING_TYPE`): set to IE when the
  proposal phase starts and to PE when the application phase starts, then to the kind of each
  elaboration cycle. Memory-system results take their support from it. -/
  firing : Firing := .ie
  maxGoalDepth : Nat := 100
  waitSnc : Bool := false
  keepTopOprefs : Bool := false
  /-- `make-constant-symbol`'s counter and the constants it has made (Soar's `mcs_counter`). -/
  mcs     : Nat := 1
  mcsMade : List String := []
  /-- The real-number zero made by a right-hand-side function, once one has been (see
  `RState.canon`; the model keeps it for the rest of the run, where Soar frees it when nothing
  refers to it). -/
  zeroSym : Option Float := none
  explore : ExploreCfg := {}
  /-- Reinforcement learning: parameters, the RL rules with their initial values, and the
  learned values (expected current reward, expected future reward) of each RL rule. -/
  rl       : RLParams := {}
  rlTab : List (String × RLEntry) := []
  /-- For the decision now being made among indifferent candidates: the highest candidate
  value, whether RL rules contributed to it, whether the chosen candidate has it, and the
  chosen candidate's importance-sampling ratio. -/
  rlTie : Option (Float × Bool × Bool × Float) := none
  /-- Semantic memory ([Man] chapter 6): whether it is enabled, the long-term store, the
  links from short-term identifiers to LTIs, and per state the status elements it created and
  the command elements each pass last looked at. -/
  smemOn   : Bool := false
  smem     : SMemDB := {}
  ltiOf    : List (Nat × Nat) := []
  smemMeta : List (Nat × List WME) := []
  smemSnap : List ((Nat × Bool) × List WME) := []
  /-- Soar's slots — one per identifier and attribute in use — in order of creation. Semantic
  memory reads commands in Soar's slot order, which can decide whether a command is
  well formed. -/
  slotSeq  : List (Nat × Sym) := []
  /-- Elements present, with the elaboration cycle in which each appeared. -/
  elemSeq  : List (WME × Nat) := []
  waveNo   : Nat := 0
  /-- Episodic memory ([Man] chapter 7): whether it is enabled (`learning`), the episode store,
  and per state the meta elements it created, the command elements it last looked at, and the
  last episode it retrieved. -/
  epOn     : Bool := false
  ep       : EpDB := {}
  epMeta   : List (Nat × List WME) := []
  epSnap   : List (Nat × List WME) := []
  epLast   : List (Nat × Nat) := []
  /-- Record rule firings and retractions (like Soar's `watch 3`). -/
  verbose : Bool := false
  firings : List String := []
  /-- Chunking ([Man] chapter 4): settings, the learned rules (in production memory, kept
  with the procedural module's state), the user rule each was learned from and its naming
  depth, the explanation records of instantiations fired in substates, and counters. -/
  chunkCfg  : ChunkCfg := {}
  /-- States marked by `force-learn` (for `chunk only`) and `dont-learn` (for `chunk except`). -/
  forceLearn : List Nat := []
  dontLearn  : List Nat := []
  chunks    : List Production := []
  /-- RL rules made by templates ([Man] §5.4.2), the next template number (Soar's
  `rl_template_count`), and the duplicate keys and names of the loaded rules. -/
  rlGen     : List Production := []
  rlTemplCount : Nat := 1
  rlKnownKeys  : List String := []
  rlKnownNames : List String := []
  /-- Working-memory activation ([Man] §9.3.2.1; Soar 9.6.5 `working_memory_activation.cpp`):
  its parameters and its state. -/
  wma  : WmaParams := {}
  wmaS : WmaSt := {}
  chunkMeta : List (String × String × Nat) := []
  xinsts    : List XInst := []
  xNext     : Nat := 1
  /-- Decision and number of rules learned in it (for naming and `max-chunks`). -/
  chunkCount : Nat × Nat := (0, 0)
  /-- Duplicates learned per rule in a decision (`max-dupes`). -/
  dupes     : List (String × Nat × Nat) := []
  /-- Operator selection knowledge per state, set when its operator is selected: what made
  the preferences that decided it, and the instantiation that proposed the operator. -/
  osk       : List (Nat × List String × String) := []
  /-- `multi-attributes` declarations: expected numbers of values, used to order the
  conditions of a match (Soar 9.6.5's reorderer). -/
  multi     : List (String × Nat) := []
  /-- States above one where a rule was learned (`chunk bottom-only`; Soar's
  `allow_bottom_up_chunks`). -/
  noBottomUp : List Nat := []
  /-- For each state's selected operator, the preference it was selected by (Soar's
  `w->preference` for a context slot, fixed at the decision). -/
  opPref    : List (Nat × Nat) := []
  /-- The explanation record of the instantiation that made that preference, kept when the
  operator is selected (the preference itself can leave preference memory while the operator
  stays selected; Soar's `w->preference` keeps it). -/
  opUid     : List (Nat × String) := []
  /-- Constants in the order Soar numbers them (`Parse.symbolOrder`), for its reorderer. -/
  symRank   : Array Sym := #[]
  /-- The position of each constant in `symRank`, for lookups. -/
  symIx     : Std.HashMap Sym Nat := {}
  /-- Identifiers made by `deep-copy`, with the level they were made at: Soar 9.6.5 does not
  promote them (they are made with promotion level 0), which shows in what goes with a result
  (observed 2026-10-29: a learned rule still carries a copied structure after the copy was
  linked to the superstate). Used by `St.idLevel`. -/
  dcLevels  : List (Nat × Nat) := []
  /-- The goal level of each identifier (Soar's `id->level`): a new identifier takes the level of
  the instantiation that made it; at the end of each working-memory phase identifiers are
  promoted to the highest state that links them and demoted when those links go
  (`do_promotion`, `do_demotion`; `St.relevel`). Between those points levels do not change. -/
  lv        : Std.HashMap Nat Nat := {}
  /-- The order structures of Soar's Rete (`Soar.Rete`): which new match the network reached
  last. `reteOn := false` takes new matches in the order of the rules instead (the model's
  earlier approximation, kept for comparison). -/
  rete      : Rete.Net := {}
  reteOn    : Bool := true
  /-- Each rule's condition orders, by rule name (S3 in the code review): `joinOrder`, Soar's
  reorderer on the rule's conditions, and on the Rete's form of them. They depend only on the
  rule, `multi` and the symbol ranks, so they are made once, when the rule is loaded or learned
  (`St.reteSync`), and used while the entry's conditions and `multi` are the rule's. -/
  ordCache  : Std.HashMap String OrdEntry := {}
  /-- The current matches as the Rete model has them, by their key in the Rete
  (`St.reteKey`): their bindings and elements in the matcher's order, and their support,
  classified once when the network added them (`St.reteCache`). -/
  mcache    : Std.HashMap (String × List Nat) (List (Binding × List WME × Bool)) := {}
  /-- Check the Rete model against the matcher (`St.matches`) at every elaboration cycle
  (`--check-match`): differences are counted with the Rete's misses. -/
  checkMatch : Bool := false
  /-- The variables given to identifiers by the RL templates' rules so far (Soar's
  `m_sym_to_var_map`, which `rl_build_template_instantiation` does not clear; it is cleared
  when a rule is learned, `clean_up`). -/
  tmplVars  : Std.HashMap Nat String := {}
  /-- Since the last working-memory phase: the slots whose preferences changed, in the order
  Soar marks them (`mark_slot_as_changed`; operator slots separately, for their
  acceptable-preference elements, `mark_context_slot_as_acceptable_preference_changed`), and
  the next preference sequence number. -/
  marks     : List (Nat × Sym) := []
  cmarks    : List (Nat × Sym) := []
  aNext     : Nat := 1
  /-- Elements removed by working-memory phases since the Rete was last brought up to date, in
  the order Soar makes the changes (`wmes_to_remove`). -/
  pushRem   : List WME := []
  deriving Repr

/-! ## Working memory and links -/

def dedupW (ws : List WME) : List WME :=
  -- keep the last occurrence of each element
  (ws.reverse.foldl (fun (acc : List WME × Std.HashSet WME) w =>
    if acc.2.contains w then acc else (w :: acc.1, acc.2.insert w)) ([], {})).1

/-- The elements of working memory, linked or not: architecture-created elements, input, and
elements made from preference memory. -/
def St.raw (s : St) : List WME :=
  dedupW (s.arch ++ s.input ++ s.slots.map (·.w))

def wmeIds (w : WME) : List Nat :=
  (match w.attr with | .id n => [n] | _ => []) ++ (match w.val with | .id n => [n] | _ => [])

/-- Identifiers reachable from `roots` (S13 in the code review: the elements are grouped by
identifier once, with their positions, so that a level of the search looks at the elements of
the identifiers found at the last level only, in the order of `wm`). -/
def reach (wm : List WME) (roots : List Nat) : List Nat :=
  let adj : Std.HashMap Nat (List (Nat × WME)) :=
    wm.enum.foldl (fun m (k, w) => m.insert w.id ((k, w) :: m.getD w.id [])) {}
  go adj (wm.length + 1) roots (Std.HashSet.ofList roots) (Std.HashSet.ofList roots)
where
  /-- One level of the search: `seen` as a list (in the order found) and as a set, and the
  identifiers found at the last level. -/
  go (adj : Std.HashMap Nat (List (Nat × WME))) : Nat → List Nat → Std.HashSet Nat → Std.HashSet Nat → List Nat
  | 0, seen, _, _ => seen
  | n + 1, seen, seenS, frontier =>
    let found := frontier.fold (fun acc i => (adj.getD i []).foldl (fun a p => p :: a) acc) []
    let next := (found.mergeSort (fun a b => a.1 ≤ b.1)).flatMap (fun (_, w) => wmeIds w)
    -- the identifiers not seen yet, in the order found, without repeats
    let (new, newS) := next.foldl (fun (acc : List Nat × Std.HashSet Nat) i =>
      if seenS.contains i || acc.2.contains i then acc else (i :: acc.1, acc.2.insert i)) ([], {})
    let new := new.reverse
    if new.isEmpty then seen else go adj n (seen ++ new) (newS.fold (·.insert ·) seenS) newS

/-- Working memory: every element linked, directly or indirectly, to a state.

> "All objects in working memory must be linked to a state, either directly or indirectly
> (through other objects). Objects that are not linked to a state will be automatically
> removed from working memory by the Soar architecture." — [Man] §2.2 -/
def St.wm (s : St) : List WME :=
  let raw := s.raw
  let ids := Std.HashSet.ofList (reach raw (s.goals.map (·.id)))
  raw.filter (fun w => ids.contains w.id)

/-- The timetag of an element (0 if it is not in working memory). -/
def St.ttOf (s : St) (w : WME) : Nat := ((alGet s.tt w)).getD 0

/-- Number the constants of new elements that Soar has not numbered yet, in the order the
elements were made: Soar numbers a symbol when it makes it (`get_next_symbol_hash_id`), and a
constant made while the agent runs (by a function, an input, a memory retrieval) is made with
the element that holds it. -/
def St.noteSyms (s : St) (ws : List WME) : St :=
  let isConst (y : Sym) : Bool := match y with | .id _ => false | _ => true
  ws.foldl (fun (s : St) w =>
    [w.attr, w.val].foldl (fun (s : St) y =>
      if !isConst y || s.symIx.contains y then s
      else { s with symIx := s.symIx.insert y s.symRank.size, symRank := s.symRank.push y }) s) s

/-- Give the elements now in working memory their timetags: those already there keep theirs;
new ones get new ones, in the order they were made. -/
def St.retag (s : St) : St :=
  let r := s.raw
  let old : Std.HashMap WME Nat := s.tt.foldl (fun m (w, t) => m.insert w t) {}
  let (tt, n) := r.foldl (fun (acc : List (WME × Nat) × Nat) w =>
    match old.get? w with
    | some t => ((w, t) :: acc.1, acc.2)
    | none => ((w, acc.2) :: acc.1, acc.2 + 1)) ([], s.tNext)
  ({ s with tt := tt.reverse, tNext := n } : St).noteSyms ((r.filter (!old.contains ·)))

/-- The timetags as a map. -/
def St.ttMap (s : St) : Std.HashMap WME Nat :=
  s.tt.foldl (fun m (w, t) => if m.contains w then m else m.insert w t) {}

theorem St.ttMap_fold (w : WME) : ∀ (l : List (WME × Nat)) (m : Std.HashMap WME Nat),
    (l.foldl (fun m (v, t) => if m.contains v then m else m.insert v t) m).getD w 0 =
      match m[w]? with
      | some t => t
      | none => ((alGet l w)).getD 0
  | [], m => by cases h : m[w]? <;> simp [alGet, h, Std.HashMap.getD_eq_getD_getElem?]
  | (v, t) :: l, m => by
    simp only [List.foldl_cons, List.find?_cons, alGet]
    by_cases hv : m.contains v = true
    · simp only [hv, ite_true]
      rw [St.ttMap_fold w l m]
      cases h : m[w]? with
      | none =>
        have : (v == w) = false := by
          cases hh : (v == w)
          · rfl
          · have := LawfulBEq.eq_of_beq hh; subst this
            simp [Std.HashMap.contains_eq_isSome_getElem?, h] at hv
        simp [alGet, this]
      | some t' => simp [alGet]
    · have hv' : m.contains v = false := by simpa using hv
      simp only [hv', Bool.false_eq_true, ite_false]
      rw [St.ttMap_fold w l (m.insert v t)]
      by_cases hw : (v == w) = true
      · have := LawfulBEq.eq_of_beq hw; subst this
        have h : m[v]? = none := by
          cases hh : m[v]? with
          | none => rfl
          | some x => rw [Std.HashMap.contains_eq_isSome_getElem?, hh] at hv'; simp at hv'
        simp [alGet, Std.HashMap.getElem?_insert, h]
      · have hw' : (v == w) = false := by simpa using hw
        simp [alGet, Std.HashMap.getElem?_insert, hw']

/-- The map answers as `St.ttOf` does: the first entry for an element wins in both. -/
theorem St.ttMap_getD_eq_ttOf (s : St) (w : WME) : s.ttMap.getD w 0 = s.ttOf w := by
  unfold St.ttMap St.ttOf
  rw [St.ttMap_fold]
  simp

def St.isGoal (s : St) (n : Nat) : Bool := s.goals.any (·.id == n)

def St.goalLevel (s : St) (n : Nat) : Option Nat := (s.goals.find? (·.id == n)).map (·.level)

/-- The goal level of an identifier (Soar's `id->level`): a state's own level; for an identifier
made by `deep-copy`, the level it was made at (Soar 9.6.5 never promotes those); otherwise the
level recorded in `St.lv`. An identifier with no recorded level is taken to be below every
state. -/
def St.idLevel (s : St) (n : Nat) : Nat :=
  match s.goalLevel n with
  | some l => l
  | none => match s.dcLevels.find? (·.1 == n) with
    | some (_, l) => l
    | none => s.lv.getD n 1000000

/-- Promotion and demotion of identifiers (Soar 9.6.5 `do_buffered_link_changes`,
`do_promotion`, `do_demotion`, `walk_and_update_levels`): each identifier linked from a state
takes the level of the highest such state. The links are the values of working-memory elements
and of preferences (and the referents of binary preferences); links to states are not links.
Identifiers no longer linked keep their level (Soar removes them; references to them in
instantiations keep it). -/
def St.relevel (s : St) : St :=
  let goalIds : Std.HashSet Nat := s.goals.foldl (fun m g => m.insert g.id) {}
  let addE (m : Std.HashMap Nat (List Nat)) (a : Nat) (v : Sym) : Std.HashMap Nat (List Nat) :=
    match v with
    | .id b => if goalIds.contains b then m else m.insert a (b :: m.getD a [])
    | _ => m
  let adj := s.raw.foldl (fun m w => addE m w.id w.val) {}
  let adj := s.prefs.foldl (fun m p => match p.ref with
    | some r => addE (addE m p.id p.val) p.id r
    | none => addE m p.id p.val) adj
  let fuel := adj.size + s.goals.length + 1
  let rec walk : Nat → List Nat → Nat → Std.HashMap Nat Nat → Std.HashSet Nat → Std.HashMap Nat Nat × Std.HashSet Nat
    | 0, _, _, lv, seen => (lv, seen)
    | _ + 1, [], _, lv, seen => (lv, seen)
    | n + 1, x :: rest, l, lv, seen =>
      let next := (adj.getD x []).filter (fun y => !seen.contains y)
      let seen := next.foldl (fun m y => m.insert y) seen
      walk n (rest ++ next) l (next.foldl (fun m y => m.insert y l) lv) seen
  let gs := s.goals.mergeSort (fun a b => a.level ≤ b.level)
  let (lv, _) := gs.foldl (fun (acc : Std.HashMap Nat Nat × Std.HashSet Nat) g =>
    walk (fuel * 4) [g.id] g.level acc.1 acc.2) (s.lv, goalIds)
  { s with lv := lv }

/-- The goal level of an instantiation: its deepest tested state.

> "A preference or working memory element is said to be created in a state if the
> production that created it tested that state and this is the most recent state that the
> production tested." — [Man] §2.7.3 -/
def St.instLevel (s : St) (ws : List WME) : Nat :=
  (ws.filterMap (fun w => s.goalLevel w.id)).foldl max 1

def St.deepestGoal (s : St) (ws : List WME) : Option Nat :=
  let lvl := s.instLevel ws
  (s.goals.find? (·.level == lvl)).map (·.id)

def isOpAttr (a : Sym) : Bool := a == .str "operator"

/-- Do the production's actions propose an operator: an acceptable preference for `^operator` of
a state (Soar 9.6.5, `calculate_support_for_instantiation_preferences`)? -/
def Production.proposes (p : Production) (s : St) (b : Binding) : Bool :=
  p.acts.any fun a => match a with
    | .pref sv _ .acceptable _ _ => match b.get sv with
      | some (.id n) => s.isGoal n
      | _ => false
    | _ => false

/-- The operators selected in the deepest state that a match's elements test. -/
def St.selectedOps (s : St) (ws : List WME) : List Sym :=
  match s.deepestGoal ws with
  | some g => (ws.filter (fun w => w.id == g && isOpAttr w.attr && !w.acc)).map (·.val)
  | none => []

/-- Does the production have a working-memory action (a rule with none, for example only
`halt`, is i-supported)? -/
def Production.changesWM (p : Production) : Bool :=
  p.acts.any fun a => match a with
    | .make .. => true | .remove .. => true | _ => false

/-- Does any action of the production, under `b`, add or remove an element of one of the
operators `ops`? -/
def Production.augments (p : Production) (b : Binding) (ops : List Sym) : Bool :=
  p.acts.any fun a => match a with
    | .make i _ _ | .remove i _ _ => match b.get i with
      | some x => ops.contains x
      | none => false
    | _ => false

/-- **O-support** ([Man] §2.7.6, the support mode used since 9.6): an instantiation gives
o-support if its actions propose no operator and its conditions test the selected operator
of the deepest state it tests — unless it augments the operator itself.

> "operator augmentations should always receive i-support … Soar has been written to
> recognize augmentations directly off the operator (ie, (<o> ^augmentation value)), and to
> attempt to give them i-support. … [for a production that] adds an operator augmentation,
> and adds a non-operator augmentation … both receive i-support." — [Man] §2.7.6

Confirmed against Soar 9.6.5 (2026-10-28): rules that test the selected operator and add
augmentations to it fire as i-supported. -/
def St.oSupported (s : St) (p : Production) (b : Binding) (ws : List WME) : Bool :=
  let noProposal := !(p.proposes s b)
  let selOps := s.selectedOps ws
  let testsOp := !selOps.isEmpty
  -- `:o-support` and `:i-support` in the production override the calculation ([Man] §3.3.3)
  match p.support with
  | some b => b
  | none => noProposal && testsOp && p.changesWM && !(p.augments b selOps)

/-- **O-support as Soar 9.6.5's Rete decides it** (`p_node_left_addition`), for a match of `p`
with bindings `b` and elements `ws`, when the production's other current matches are
`others`. Unless the production declares its support or proposes an operator, the Rete looks
at every current match of the production — this one and the others — and, in each, at the
selected operator of the deepest state that match tests: an action (making an element, a
removal or a preference) on an identifier other than that operator makes the match
o-supported; one on that operator is an operator elaboration; a match that does both is
i-supported with a warning. The actions' identifiers are always taken from the new match, so
an operator elaboration is o-supported when another match of the same production has a
different selected operator (observed 2026-10-30 in the graph-search demonstration agent,
whose nested selection states each select an evaluate-operator: Soar's `preferences` command
shows the elaborations of the earlier ones as `:O`). With no other match, and no preference action, this is
`St.oSupported`'s rule (`reteSupport_nil`). -/
def St.reteSupport (s : St) (p : Production) (b : Binding) (ws : List WME)
    (others : List (Binding × List WME)) : Bool :=
  let proposal := p.proposes s b
  let ids : List (Option Sym) := p.acts.filterMap fun a => match a with
    | .make i _ _ | .remove i _ _ | .pref i _ _ _ _ => some (b.get i)
    | _ => none
  match p.support with
  | some x => x
  | none =>
    if proposal then false else
    ((b, ws) :: others).foldl (fun (pe : Bool) (t : Binding × List WME) =>
      let tws := t.2
      let selOps : List Sym := s.selectedOps tws
      let r : Bool × Bool := selOps.foldl (fun (acc : Bool × Bool) o =>
        ids.foldl (fun (acc : Bool × Bool) i => if i == some o then (acc.1, true) else (true, acc.2)) acc) (pe, false)
      if r.1 && r.2 then false else r.1) false

/-- What one instantiation does: elements to add, elements to remove, preferences, halt, and
the random-number generator after its right-hand-side functions. -/
structure Effects where
  adds  : List WME := []
  rems  : List WME := []
  prefs : List Pref := []
  halt  : Bool := false
  out   : List String := []
  rs    : RState := {}
  /-- `(link-stm-to-ltm <x> n)` actions: identifier and long-term identifier number. -/
  links : List (Nat × Nat) := []
  deriving Repr

/-- Instantiate a rule's actions, in order, each one's fields in the order identifier,
attribute, value, referent (the order in which `rand-int` and `rand-float` draw). -/
def instantiate (p : Production) (b : Binding) (next : Nat) (isGoal : Nat → Bool := fun _ => true)
    (rs0 : RState := {}) (ctx : RhsCtx := {}) : Effects × Nat :=
  let unbound := (p.acts.flatMap actionVars).eraseDups.filter (fun v => (b.get v).isNone)
  let fresh := unbound.zip (List.range' next unbound.length)
  let ev := RVal.evalR ctx b fresh
  let idOf (v : String) : Option Nat := match RVal.eval b fresh (.var v) with
    | some (.id n) => some n
    | _ => none
  let eff := p.acts.foldl (fun (e : Effects) a => match a with
    | .make i aa v =>
      let (x?, r) := ev aa e.rs
      let (y?, r) := ev v r
      let e := { e with rs := r }
      match idOf i, x?, y? with
      | some n, some x, some y =>
        -- `^operator` reached through an attribute variable on a state is an acceptable
        -- preference too (every Soar action is a preference, acceptable by default)
        if isOpAttr x && isGoal n then
          { e with prefs := e.prefs ++ [{ state := n, op := y, kind := .acceptable }],
                   adds := e.adds ++ [{ id := n, attr := x, val := y, acc := true }] }
        else { e with adds := e.adds ++ [{ id := n, attr := x, val := y }] }
      | _, _, _ => e
    | .remove i aa v =>
      let (x?, r) := ev aa e.rs
      let (y?, r) := ev v r
      let e := { e with rs := r }
      match idOf i, x?, y? with
      | some n, some x, some y => { e with rems := e.rems ++ [{ id := n, attr := x, val := y }] }
      | _, _, _ => e
    | .pref sv o k o₂ num =>
      let (x?, r) := ev o e.rs
      let (v?, r) := match o₂ with
        | some q => ev q r
        | none => (none, r)
      let e := { e with rs := r }
      match idOf sv, x? with
      | some n, some x =>
        -- `= <value>` with a computed number is a numeric-indifferent preference
        let pr : Pref := match k, v? with
          | .binaryIndiff, some v => if v.num?.isSome then { state := n, op := x, kind := .numericIndiff, num := some v }
                                     else { state := n, op := x, kind := k, other := some v, num := num }
          | _, other => { state := n, op := x, kind := k, other := other, num := num }
        let e' := { e with prefs := e.prefs ++ [pr] }
        -- an acceptable preference for `^operator` of an object that is not a state makes an
        -- ordinary element (its slot is not a context slot)
        if k == .acceptable then
          { e' with adds := e'.adds ++ [{ id := n, attr := .str "operator", val := x, acc := isGoal n }] }
        else e'
      | _, _ => e
    | .halt => { e with halt := true }
    | .cmd ["link-stm-to-ltm", v, k] =>
      match idOf ((v.drop 1).dropEnd 1).toString, k.toNat? with
      | some n, some l => { e with links := e.links ++ [(n, l)] }
      | _, _ => e
    | .cmd _ => e
    | .write vs =>
      let (ts, r) := vs.foldl (fun (acc : List String × RState) v =>
        let (y, r) := ev v acc.2
        (acc.1 ++ [match y with | some (.str t) => t | some x => x.toSoar | none => ""], r)) ([], e.rs)
      { e with out := e.out ++ [String.join ts], rs := r }) { rs := rs0 }
  (eff, next + unbound.length)

/-! ## Preference memory ([Man] §2.4; Soar 9.6.5 `preference.cpp`, `decide.cpp`) -/

/-- Is `(id ^attr …)` a context slot (a state's operator slot)? -/
def St.isCtx (s : St) (id : Nat) (attr : Sym) : Bool := isOpAttr attr && s.isGoal id

/-- The order of a slot's preference lists (Soar 9.6.5 `add_preference_to_tm`): by the match
goal level of the instantiation, highest state first, then most recently asserted first. -/
def prefBefore (a b : PRec) : Bool :=
  -- by match-goal level, then most recently added first, in Soar's order of addition when
  -- both have been added (`PRec.aseq`)
  a.level < b.level || (a.level == b.level && (if a.aseq > 0 && b.aseq > 0 then a.aseq > b.aseq else a.pid > b.pid))

/-- The first of a list of preferences in slot order. -/
def firstPref (ps : List PRec) : Option PRec :=
  ps.foldl (fun acc q => match acc with
    | none => some q
    | some b => if prefBefore q b then some q else some b) none

/-- Record that a preference for a state's operator slot was added or removed (Soar's
`mark_slot_as_changed` for a context slot). -/
def St.markCtx (s : St) (id : Nat) (attr : Sym) : St :=
  if !s.isCtx id attr then s else
  let lvl := (s.goalLevel id).getD 0
  { s with ctxChanged := if s.ctxChanged.contains id then s.ctxChanged else s.ctxChanged ++ [id],
           ctxTop := some (match s.ctxTop with | some t => min t lvl | none => lvl) }

/-- Record that a slot's preferences changed (Soar 9.6.5 `mark_slot_as_changed`), in the order
the slots were first marked; a state's operator slot only for an acceptable or require
preference (its acceptable-preference elements are made from those). -/
def St.markSlot (s : St) (id : Nat) (attr : Sym) (k : PrefKind) : St :=
  if s.isCtx id attr then
    if (k == .acceptable || k == .require) && !s.cmarks.contains (id, attr) then { s with cmarks := s.cmarks ++ [(id, attr)] } else s
  else if s.marks.contains (id, attr) then s else { s with marks := s.marks ++ [(id, attr)] }

/-- Add a preference to preference memory (Soar 9.6.5 `add_preference_to_tm`). An o-supported
acceptable preference of a top-state instantiation for a value that already has one is
ignored, unless `soar keep-all-top-oprefs` is on (off by default). -/
def St.addPref (mark : Bool) (s : St) (p : PRec) : St :=
  let dupTop := !s.keepTopOprefs && p.level == 1 && p.osup && p.kind == .acceptable && !s.isCtx p.id p.attr &&
    s.prefs.any (fun q => q.id == p.id && q.attr == p.attr && q.val == p.val && q.osup && q.level == 1)
  if dupTop then s else
  let q : PRec := if p.aseq == 0 then { p with aseq := s.aNext } else p
  let s := ({ s with prefs := s.prefs ++ [q], aNext := if p.aseq == 0 then s.aNext + 1 else s.aNext }).markCtx p.id p.attr
  if mark then s.markSlot p.id p.attr p.kind else s

/-- Remove the preferences satisfying `f`. -/
def St.dropPrefs (s : St) (f : PRec → Bool) (mark : Bool := true) : St :=
  let gone := s.prefs.filter f
  let s := { s with prefs := s.prefs.filter (fun p => !f p) }
  gone.foldl (fun s p => let s := s.markCtx p.id p.attr; if mark then s.markSlot p.id p.attr p.kind else s) s

/-- Assert the preferences of an elaboration cycle's new instantiations (Soar 9.6.5
`assert_new_preferences`): o-supported reject preferences first remove every preference for
their value in their slot (`process_o_rejects_and_deallocate_them`) and are not kept; then
the other preferences are added. -/
def St.assertPrefs (s : St) (ps : List PRec) (mark : Bool := true) : St :=
  let oRej := ps.filter (fun p => p.kind == .reject && p.osup)
  let s := oRej.foldl (fun s r => s.dropPrefs (fun q => q.id == r.id && q.attr == r.attr && q.val == r.val)) s
  (ps.filter (fun p => !(p.kind == .reject && p.osup))).foldl (St.addPref mark) s

/-- One preference to make, as (identifier, attribute, value, kind, referent, number). -/
abbrev PrefRow := Nat × Sym × Sym × PrefKind × Option Sym × Option Sym

/-- Preference records for rows, numbered from `pid`, all of instantiation `iid` at match-goal
level `level` of state `goal`. -/
def mkPRecs (pid iid level goal : Nat) (osup : Bool) (xs : List PrefRow) : List PRec :=
  xs.enum.map fun (j, (i, a, v, k, r, n)) =>
    { pid := pid + j, id := i, attr := a, val := v, kind := k, ref := r, num := n, osup := osup,
      inst := iid, level := level, goal := goal }

/-- The preferences an instantiation's effects make, numbered from `pid`. -/
def effPrefs (e : Effects) (pid iid level goal : Nat) (osup : Bool) : List PRec :=
  mkPRecs pid iid level goal osup (
    e.adds.map (fun w => (w.id, w.attr, w.val, PrefKind.acceptable, none, none)) ++
    e.rems.map (fun w => (w.id, w.attr, w.val, PrefKind.reject, none, none)) ++
    (e.prefs.filter (·.kind != .acceptable)).map (fun p => (p.state, Sym.str "operator", p.op, p.kind, p.other, p.num)))

/-- The elements preference memory makes, with their supporting preferences, in the order they
were first made (Soar 9.6.5 `decide_non_context_slot`, `run_non_context_preference_semantics`,
`do_acceptable_preference_wme_changes_for_slot`):
* an ordinary slot has an element for each value with an acceptable preference and no reject
  preference, supported by the first acceptable preference for it in the slot's order;
* a state's operator slot has an acceptable-preference element for each value with an
  acceptable or require preference (rejected or not), supported by the first require
  preference for it, else the first acceptable one. -/
def St.desired (s : St) : List WEnt :=
  -- per value of a slot: when it was first made, whether it is rejected, and its first
  -- acceptable and first require preferences in slot order
  let better (p : PRec) (o : Option PRec) : Option PRec := match o with
    | none => some p
    | some q => if prefBefore p q then some p else some q
  let m : Std.HashMap (Nat × Sym × Sym) (Nat × Bool × Option PRec × Option PRec) :=
    s.prefs.foldl (fun m p =>
      let k := (p.id, p.attr, p.val)
      let (f, rj, a, r) := m.getD k (1000000000000, false, none, none)
      let v := match p.kind with
        | .reject => (f, true, a, r)
        | .acceptable => (min f p.pid, rj, better p a, r)
        | .require => (min f p.pid, rj, a, better p r)
        | _ => (f, rj, a, r)
      m.insert k v) {}
  let es := m.toList.filterMap fun ((i, att, v), (f, rj, a, r)) =>
    let ctx := s.isCtx i att
    let sup := if ctx then r <|> a else if rj then none else a
    sup.map fun q => (f, ({ w := { id := i, attr := att, val := v, acc := ctx }, pref := q.pid } : WEnt))
  (es.mergeSort (fun x y => x.1 ≤ y.1)).map (·.2)

def St.selected (s : St) (g : Nat) : Option Sym :=
  (s.arch.find? (fun w => w.id == g && isOpAttr w.attr && !w.acc)).map (·.val)

/-- The preference record of a working-memory element made from preference memory. -/
def St.wentOf (s : St) (w : WME) : Option PRec :=
  match s.slots.find? (·.w == w) with
  | some e => s.prefs.find? (·.pid == e.pref)
  | none => none

def St.instById (s : St) (n : Nat) : Option Inst := s.insts.find? (·.iid == n)

/-! ## Backtracing: dependencies of a working-memory element -/

/-- The instantiation whose preference supports `w` now, or else the most recent instantiation
that made it (the element may be gone). -/
def St.supportOf (s : St) (w : WME) : Option (Inst × Bool) :=
  match s.wentOf w with
  | some p => (s.instById p.inst).map (·, p.osup)
  | none =>
    let cands := s.insts.filter (fun i => i.made.contains w)
    (cands.foldl (fun (acc : Option Inst) i => match acc with
      | none => some i
      | some j => if i.iid > j.iid then some i else some j) none).map fun i => (i, i.osup)

/-- The superstate elements (goal level below `lvl`) that the creation of elements tested
through `ws` depended on, tracing back through local elements.

> "The conditions of a justification are those working memory elements that exist in the
> superstate (and above) that were necessary for producing the result. This is determined by
> collecting all of the working memory elements tested by the productions that fired in the
> subgoal that led to the creation of the result, and then removing those conditions that
> test working memory elements created in the subgoal." — [Man] §2.7.4

With `stopAtLocalO := true` this is the goal dependency set computation instead: local
o-supported elements contribute nothing, because their dependencies are already recorded
([Man] §2.7.9.2). -/
def St.backtrace (s : St) (lvl : Nat) (stopAtLocalO : Bool) (fuel : Nat) (ws : List WME) : List WME :=
  -- a breadth-first walk over the elements tested, each element visited once (the support
  -- of elements can be cyclic, through memory systems' instantiations)
  -- the queue is a front list and the chunks appended since, newest first; `out` is reversed
  let rec go : Nat → List WME → List (List WME) → Std.HashSet WME → List WME → List WME
    | 0, _, _, _, out => out.reverse
    | n + 1, [], back, seen, out =>
      match back with
      | [] => out.reverse
      | _ => go n (back.reverse.flatten) [] seen out
    | n + 1, w :: rest, back, seen, out =>
      if seen.contains w then go n rest back seen out else
      let seen := seen.insert w
      -- an identifier no longer linked to any state has no level here; it is treated as
      -- local and traced through, never taken as a superstate condition
      if s.idLevel w.id != 0 && s.idLevel w.id < lvl then go n rest back seen (w :: out)
      else
        match s.supportOf w with
        | some (i, os) => if stopAtLocalO && os then go n rest back seen out else go n rest (i.ws :: back) seen out
        | none =>
            -- an architecture-created substate item traces to the acceptable preference
            -- in the superstate
            if w.attr == .str "item" then
              match s.goals.find? (·.id == w.id) with
              | some g => match s.goals.find? (fun g' => g'.level + 1 == g.level) with
                | some sup => go n rest back seen ({ id := sup.id, attr := .str "operator", val := w.val, acc := true } :: out)
                | none => go n rest back seen out
              | none => go n rest back seen out
            else go n rest back seen out
  dedupW (go (fuel * 10000) ws [] {} [])

/-! ## Reinforcement learning ([Man] chapter 5)

DECIDED (Laird, 2026-10-28): the value of each RL rule is metadata of that rule, not
examinable by rules; it is kept with the procedural module's internal state and changed only
by reinforcement learning, which leaves every condition and action unchanged. -/

/-- An RL rule: its conditions test a proposed operator, and its only action is one
numeric-indifferent preference with a constant value. Returns that initial value.

> "A production is a RL rule if and only if its left hand side tests for a proposed
> operator, its right hand side creates a single numeric-indifferent preference, and it is
> not a template rule" — [Man] §5.1

A template rule ([Man] §5.4.2) is not an RL rule; the rules made from it are
(`St.addTemplateRule`). -/
def Production.rlInit? (p : Production) : Option Float :=
  let testsProposed := p.conds.any fun c => match c with
    | .pos q => q.acc && q.attr == [.const (.str "operator")]
    | _ => false
  if p.template then none else
  match p.acts with
  | [.pref _ _ .numericIndiff none (some v)] => if testsProposed then v.num? else none
  | _ => none

/-- The key by which Soar 9.6.5 finds a production to be a duplicate of another: its conditions
and actions, with variables renamed in order of appearance and, for a rule whose only action is
a numeric-indifferent preference, without the preference's value (`same_rhs`). -/
def Production.dupKey (q : Production) : String :=
  let acts := match q.acts with
    | [.pref t v .numericIndiff none (some _)] => [Action.pref t v .numericIndiff none none]
    | as => as
  toString (repr q.conds) ++ toString (repr acts)

/-- Rename a production's variables `v1`, `v2`, … in order of first appearance. -/
def Production.canonVars (q : Production) : Production :=
  let tv (t : Test) : List String := t.filterMap fun st => match st with
    | .var v => some v | .rel _ (.var v) => some v | _ => none
  let pv (p : Pat) : List String := tv p.id ++ tv p.attr ++ tv p.val
  let cv (c : Cond) : List String := c.pats.flatMap pv
  let rec rv : RVal → List String
    | .var v => [v] | .sym _ => [] | .call _ as => as.flatMap rv
  let av : Action → List String
    | .pref sv o _ o₂ _ => sv :: rv o ++ ((o₂.map rv).getD [])
    | .make i a v => i :: rv a ++ rv v
    | .remove i a v => i :: rv a ++ rv v
    | _ => []
  let vars := (q.conds.flatMap cv ++ q.acts.flatMap av).eraseDups
  let ren (v : String) : String := match vars.idxOf? v with | some i => s!"v{i + 1}" | none => v
  let rt (t : Test) : Test := t.map fun st => match st with
    | .var v => .var (ren v) | .rel r (.var v) => .rel r (.var (ren v)) | x => x
  let rp (p : Pat) : Pat := { p with id := rt p.id, attr := rt p.attr, val := rt p.val }
  let rc : Cond → Cond := Cond.mapPats rp
  let rec rr : RVal → RVal
    | .var v => .var (ren v) | .sym x => .sym x | .call f as => .call f (as.map rr)
  let ra : Action → Action
    | .pref sv o k o₂ n => .pref (ren sv) (rr o) k (o₂.map rr) n
    | .make i a v => .make (ren i) (rr a) (rr v)
    | .remove i a v => .remove (ren i) (rr a) (rr v)
    | a => a
  { q with conds := q.conds.map rc, acts := q.acts.map ra }

/-- The RL rule a template makes from one of its matches (Soar 9.6.5
`rl_build_template_instantiation`): the template's conditions instantiated with the match,
identifiers becoming variables and other values constants, and its action a numeric-indifferent
preference with the template's value (or the number its referent variable is bound to). -/
def Production.fromTemplate (p : Production) (b : Binding) (name : String) (idVar : Nat → String := fun n => s!"t{n}") :
    Option (Production × Float) :=
  let it (t : Test) : Test := (t.map fun st => match st with
    | .var v => match b.get v with
      | some (.id n) => .var (idVar n) | some c => .const c | none => .var v
    | .rel r (.var v) => match b.get v with
      | some (.id n) => .rel r (.var (idVar n)) | some c => .rel r (.sym c) | none => st
    | x => x).eraseDups
  let ip (q : Pat) : Pat := { q with id := it q.id, attr := it q.attr, val := it q.val }
  let ic : Cond → Cond := Cond.mapPats ip
  let varOf (v : String) : String := match b.get v with | some (.id n) => idVar n | _ => v
  let rvOf : RVal → RVal
    | .var v => match b.get v with | some (.id n) => .var (idVar n) | some c => .sym c | none => .var v
    | x => x
  let mk (sv : String) (o : RVal) (val : Sym) : Option (Production × Float) :=
    val.num?.map fun x =>
      ((({ name := name, conds := p.conds.map ic,
            acts := [.pref (varOf sv) (rvOf o) .numericIndiff none (some val)] } : Production).canonVars), x)
  match p.acts with
  | [.pref sv o .numericIndiff _ (some val)] => mk sv o val
  | [.pref sv o .binaryIndiff (some (.var x)) _] => (b.get x).bind (mk sv o)
  | _ => none

/-- The record of an RL rule. -/
def St.rlEntry (s : St) (name : String) : Option RLEntry := alGet s.rlTab name

/-- The learned values of all RL rules that have been updated. -/
def St.rlValues (s : St) : List (String × Float × Float) :=
  s.rlTab.filterMap fun (n, e) => e.vals.map (n, ·)

/-- The secondary weights of all RL rules that have them. -/
def St.rlAux (s : St) : List (String × Float × Float × Float) :=
  s.rlTab.filterMap fun (n, e) => e.aux.map (n, ·)

/-- The learned-value record of `name` after `f`. -/
def St.rlMod (s : St) (name : String) (f : RLEntry → RLEntry) : St :=
  { s with rlTab := alPut s.rlTab name (f ((s.rlEntry name).getD {})) }

/-- The learned value of an RL rule: (expected current reward, expected future reward). A
rule not yet updated has expected current reward 0 and its initial value as expected future
reward ([Man] §5.3.2). -/
def St.rlValue (s : St) (name : String) : Option (Float × Float) :=
  match (s.rlEntry name).bind (·.vals) with
  | some v => some v
  | none => ((s.rlEntry name).bind (·.init)).map fun v => (0, v)

def St.isRLRule (s : St) (name : String) : Bool := ((s.rlEntry name).bind (·.init)).isSome

/-- An RL rule's right-hand-side value: its initial value until it is first updated. -/
def St.rlRefValue (s : St) (name : String) : Option Float :=
  match (s.rlEntry name).bind (·.ref) with
  | some v => some v
  | none => (s.rlEntry name).bind (·.init)

/-- The reward on a state's reward link: the sum of `(<r1> ^reward <r2>) (<r2> ^value v)`.

> "If there are multiple valid reward signals, their values are summed into a single reward
> signal." — [Man] §5.2 -/
def St.rewardOf (s : St) (g : Nat) : Float :=
  match ((s.arch.find? (fun w => w.id == g && w.attr == .str "reward-link")).map (·.val) : Option Sym) with
  | some (Sym.id link) =>
    let wm := s.wm
    let rewards := (wm.filter (fun w => w.id == link && w.attr == .str "reward" && !w.acc)).filterMap
      fun w => match w.val with | .id r => some r | _ => none
    let vals := rewards.flatMap fun r =>
      (wm.filter (fun w => w.id == r && w.attr == .str "value" && !w.acc)).filterMap (·.val.num?)
    vals.foldl (· + ·) 0
  | _ => 0

/-- Collect the reward of state `g`, discounted by the gap and hierarchy ages ([Man] §5.2,
§5.3.1). With `hrl-discount` on, the hierarchy age of every state but the bottom one grows.

The manual says reward is collected "at the beginning of each decision phase". In Soar 9.6.5
(`rl_update_for_one_candidate`, checked 2026-10-29) it is collected, for every state, only
when an operator is selected in some state; a decision that creates an impasse collects
nothing. -/
def St.rlCollect (s : St) (g : Goal) : Goal :=
  if g.rlPrev.isEmpty then g
  else
    let bottom := s.goals.all (·.level ≤ g.level)
    { g with rlReward := g.rlReward + s.rewardOf g.id * Float.pow s.rl.gamma ((if s.rl.temporalDiscount then g.rlGap else 0) + g.rlHrl).toFloat,
             rlHrl := if s.rl.hrlDiscount && !bottom then g.rlHrl + 1 else g.rlHrl }

def St.rlTabulate (s : St) : St :=
  { s with goals := s.goals.map s.rlCollect }

/-- Reward collection for one state, when it is retracted. -/
def St.rlTabulateGoal (s : St) (gid : Nat) : St :=
  { s with goals := s.goals.map fun g => if g.id == gid then s.rlCollect g else g }

/-- One RL update's computation (Soar 9.6.5 `rl_perform_update`): the eligibility traces after
the update, and the new values, update counts and auxiliary weights of every rule with a
trace. With λ = 0 the traces are cleared first, so only the rules behind the previous
selection are updated, each by the share of the rules it made up; with λ > 0 earlier traces
decay by λ and the discount and are dropped below the tolerance. A state with a substate adds
no trace (`I = 0`). -/
structure RLStep where
  traces : List (String × Float)
  values : List (String × Float × Float)
  counts : List (String × Nat)
  aux    : List (String × Float × Float × Float)
  /-- The value given to the preferences of every traced rule's instantiations. -/
  combined : Float
  /-- The right-hand-side value of each updated rule. -/
  refs : List (String × Float)

def St.rlStep (s : St) (g : Goal) (opValue : Float) (updEfr : Bool) : RLStep :=
  let p := s.rl
  let age := g.rlHrl + 1 + (if p.temporalDiscount then g.rlGap else 0)
  let discount := Float.pow p.gamma age.toFloat
  let traces0 : List (String × Float) :=
    if p.lambda == 0 then []
    else (g.rlTraces.map fun (r, e) => (r, e * p.lambda * discount)).filter (fun (_, e) => !(e < p.etTolerance))
  let traces0 := if p.gql then traces0.map fun (r, e) => (r, e * g.rlRho) else traces0
  let hasLower := s.goals.any (·.level > g.level)
  let inc := (if hasLower then 0 else 1) * (1.0 / g.rlPrev.length.toFloat)
  let aux (r : String) : Float × Float × Float := ((alGet s.rlAux r)).getD (0, -3, 0)
  let vals := g.rlPrev.map fun r => (s.rlValue r).getD (0, 0)
  let sumEcr := (vals.map (·.1)).foldl (· + ·) (0 : Float)
  let sumEfr := (vals.map (·.2)).foldl (· + ·) (0 : Float)
  let dotWPhi := (g.rlPrev.map fun r => (aux r).1).foldl (· + ·) (0 : Float)
  let traces := g.rlPrev.foldl (fun (ts : List (String × Float)) r =>
    if ts.any (·.1 == r) then ts.map fun (r', e) => if r' == r then (r', e + inc) else (r', e)
    else ts ++ [(r, inc)]) traces0
  let deltaT := (g.rlReward + discount * opValue) - (sumEcr + sumEfr)
  let dotWE := (traces.map fun ((r, e) : String × Float) => (aux r).1 * e).foldl (· + ·) (0 : Float)
  let count (r : String) : Nat := ((s.rlEntry r).map (·.count)).getD 0
  let upd := traces.map fun ((r, e) : String × Float) =>
    let (ecr, efr) := (s.rlValue r).getD (0, 0)
    let (gq, beta, h) := aux r
    let n := (count r).toFloat
    let (alpha, beta, h) := match p.decay with
      | .normal => (p.alpha, beta, h)
      | .exp => (1.0 / (n + 1.0), beta, h)
      | .log => (1.0 / (Float.log (n + 1.0) + 1.0), beta, h)
      | .deltaBarDelta =>
        let beta := beta + p.theta * deltaT * 1.0 * h
        let a := Float.exp beta
        let d := 1.0 - a * 1.0 * 1.0
        let d := if d < 0.0 then 0.0 else d
        (a, beta, h * d + a * deltaT * 1.0)
    let dE := alpha * e * (g.rlReward - sumEcr)
    let dF := if updEfr then alpha * e * ((discount * opValue) - sumEfr) else 0
    (r, ecr + dE, efr + dF, gq + p.eta * (dE + dF), beta, h)
  let combined := match upd.getLast? with
    | some (_, e, f, _, _, _) => e + f
    | none => 0
  let values0 := (s.rlValues.filter (fun v => !upd.any (·.1 == v.1))) ++ upd.map fun (r, e, f, _, _, _) => (r, e, f)
  let aux0 := (s.rlAux.filter (fun v => !upd.any (·.1 == v.1))) ++ upd.map fun (r, _, _, gq, b, h) => (r, gq, b, h)
  -- GQ(λ): the expected future reward of the rules behind the operators now proposed here, and
  -- the secondary weights of the rules behind the previous selection
  let (values1, aux1) :=
    if !p.gql then (values0, aux0) else
    let here := (s.prefs.filter fun q => q.id == g.id && isOpAttr q.attr && q.kind == .numericIndiff).filterMap fun q =>
      (s.insts.find? (·.iid == q.inst)).map (·.name)
    let values1 := here.foldl (fun vs r =>
      let (e, f) := match vs.find? (·.1 == r) with
        | some (_, e, f) => (e, f)
        | none => (s.rlValue r).getD (0, 0)
      (alPut vs r (e, f - p.alpha * p.gamma * (1 - p.lambda) * dotWE))) values0
    let aux1 := g.rlPrev.foldl (fun as r =>
      let (gq, b, h) := match as.find? (·.1 == r) with
        | some (_, gq, b, h) => (gq, b, h)
        | none => aux r
      (alPut as r (gq - p.alpha * p.eta * dotWPhi, b, h))) aux0
    (values1, aux1)
  { traces := traces, values := values1, aux := aux1, combined := combined,
    refs := upd.map fun (r, e, f, _, _, _) => (r, e + f),
    counts := (s.rlTab.filterMap (fun (n, e) => if upd.any (·.1 == n) then none else some (n, e.count))) ++ upd.map fun (r, _) => (r, count r + 1) }

/-- The learning table after an update step: the new values, counts, secondary weights and
right-hand-side values written into the rules' records. -/
def St.rlApply (s : St) (r : RLStep) : List (String × RLEntry) :=
  let t := r.values.foldl (fun t (n, e, f) => alPut t n { (alGet t n).getD {} with vals := some (e, f) }) s.rlTab
  let t := r.counts.foldl (fun t (n, c) => alPut t n { (alGet t n).getD {} with count := c }) t
  let t := r.aux.foldl (fun t (n, a, b, h) => alPut t n { (alGet t n).getD {} with aux := some (a, b, h) }) t
  r.refs.foldl (fun t (n, v) => alPut t n { (alGet t n).getD {} with ref := some v }) t

/-- The update for the last RL operator selected in state `gid`, given the value of the
operator now selected there ([Man] §5.3; Soar 9.6.5 `rl_perform_update`): Sarsa or
Q-learning (the value given is then the highest candidate's), GQ(λ), with eligibility traces
and the decay modes. With `updEfr := false` (state retraction) only the expected current
reward is updated ([Man] §5.3.2).

Every traced rule's current instantiations take the same value, the new value of the last rule
updated: Soar 9.6.5 assigns `new_combined`, left over from its update loop, to all of them
(Section 11 of the report). -/
def St.rlUpdate (s : St) (gid : Nat) (opValue : Float) (opRL : Bool) (updEfr : Bool) : St :=
  match s.goals.find? (·.id == gid) with
  | none => s
  | some g =>
    if (!s.rl.temporalExtension || opRL) && !g.rlPrev.isEmpty then
      let r := s.rlStep g opValue updEfr
      { s with
        rlTab := s.rlApply r
        -- the preferences of current instantiations of the traced rules take the new value
        prefs := s.prefs.map fun p => if p.kind != .numericIndiff then p else
          match (s.insts.find? (·.iid == p.inst)).bind (fun i => r.traces.find? (·.1 == i.name)) with
          | some _ => { p with num := some (Sym.ofFloat r.combined) }
          | none => p
        goals := s.goals.map fun g' => if g'.id == gid then
          { g' with rlReward := 0, rlGap := 0, rlHrl := 0, rlTraces := r.traces } else g' }
    else s

/-- After an operator is selected in state `gid`: record the RL rules behind it, or extend
the gap ([Man] §5.3.1). -/
def St.rlStore (s : St) (gid : Nat) (o : Sym) : St :=
  let fired := (s.prefs.filter (fun p => p.kind == .numericIndiff && p.id == gid && isOpAttr p.attr && p.val == o)).filterMap
    fun p => match s.insts.find? (·.iid == p.inst) with
      | some i => if s.isRLRule i.name then some i.name else none
      | none => none
  { s with goals := s.goals.map fun g =>
      if g.id != gid then g
      else if !fired.isEmpty then { g with rlPrev := fired }
      else if !s.rl.temporalExtension then { g with rlPrev := [] }
      else if !g.rlPrev.isEmpty then { g with rlGap := g.rlGap + 1 }
      else g }

/-- The Q-value of operator `o` in state `gid`: its value as a candidate (`candValue`: the sum
of its numeric-indifferent preferences, [Man] §5.1, or their average with
`numeric-indifferent-mode --avg`). -/
def St.qValue (s : St) (gid : Nat) (o : Sym) : Float × Bool :=
  let ps := (s.prefs.filter (fun p => p.kind == .numericIndiff && p.id == gid && isOpAttr p.attr && p.val == o)).map
    fun p => (((s.insts.find? (·.iid == p.inst)).map (·.name)).getD "", p)
  (candValue s.explore.avg ((s.prefs.filter (fun p => p.id == gid && isOpAttr p.attr)).map PRec.toPref) o, ps.any fun (n, _) => s.isRLRule n)

/-- What an RL update at a selection uses (`exploration_choose_according_to_policy`): the value
and RL contribution to update toward, whether Q-learning clears the traces (the choice was not
the highest candidate), and the chosen candidate's importance-sampling ratio. Off-policy
learning updates toward the highest candidate's value when the choice was among indifferent
candidates. -/
def St.rlTarget (s : St) (qv : Float) (opRL : Bool) : Float × Bool × Bool × Float :=
  match s.rlTie with
  | some (top, topRL, isTop, rho) =>
    if s.rl.offPolicy then (top, topRL, s.rl.policy == RLPolicy.q && !isTop, rho) else (qv, opRL, false, rho)
  | none => (qv, opRL, false, 1.0)

def St.rlClearTraces (s : St) (gid : Nat) (c : Bool) : St :=
  if c then { s with goals := s.goals.map fun (g : Goal) => if g.id == gid then { g with rlTraces := [] } else g } else s

/-- The ratio kept for the next update (`rl_store_data`): the chosen candidate's if RL rules
contributed to it, 1 if not and gaps are not used, else unchanged. -/
def St.rlKeepRho (s : St) (gid : Nat) (opRL : Bool) (rho : Float) : St :=
  { s with rlTie := none, goals := s.goals.map fun (g : Goal) =>
      if g.id != gid then g
      else if opRL then { g with rlRho := rho }
      else if !s.rl.temporalExtension then { g with rlRho := 1.0 } else g }

/-- Reinforcement learning when operator `o` is selected in state `gid`. -/
def St.rlSelect (s : St) (gid : Nat) (o : Sym) : St :=
  if !s.rl.learning then s else
  let s := s.rlTabulate
  let qo := s.qValue gid o
  let tg := s.rlTarget qo.1 qo.2
  let rho := if s.rl.policy == RLPolicy.onGQ then 1.0 else tg.2.2.2
  (((s.rlUpdate gid tg.1 tg.2.1 true).rlClearTraces gid tg.2.2.1).rlStore gid o).rlKeepRho gid qo.2 rho

/-- Reinforcement learning when the states at level `lvl` and below are removed: rewards are
collected and only the expected current reward is updated ([Man] §5.3.2). -/
def St.rlRetractOne (s : St) (g : Goal) : St :=
  (s.rlTabulateGoal g.id).rlUpdate g.id 0 true false

def St.rlRetract (s : St) (lvl : Nat) : St :=
  if !s.rl.learning then s else
  (s.goals.filter (·.level ≥ lvl)).foldl St.rlRetractOne s

/-! ## Goal removal, unlinked elements, and the working-memory phase -/

/-- Remove every goal at level `lvl` or below, with everything created in them: their
architecture structures, their instantiations, and the preferences made in them (Soar's
`preferences_from_goal`; the clones a learned rule or justification made for their results
belong to that instantiation's goal and stay). -/
def St.removeGoalsFrom (s : St) (lvl : Nat) : St :=
  let s := s.rlRetract lvl
  let gone := (s.goals.filter (·.level ≥ lvl)).map (·.id)
  { s with
    goals := s.goals.filter (·.level < lvl)
    arch := s.arch.filter (fun w => !gone.contains w.id)
    insts := s.insts.filter (·.level < lvl)
    prefs := s.prefs.filter (fun p => !gone.contains p.goal && p.level < lvl)
    xinsts := s.xinsts.filter (·.level < lvl)
    dcLevels := s.dcLevels.filter (·.2 < lvl)
    opPref := s.opPref.filter (fun e => !gone.contains e.1)
    opUid := s.opUid.filter (fun e => !gone.contains e.1)
    ctxChanged := s.ctxChanged.filter (fun g => !gone.contains g)
    ctxTop := match s.ctxTop with
      | some t => if t ≥ lvl then none else some t
      | none => none }

/-- Remove a state's selected operator and the substates below it (Soar 9.6.5
`remove_wmes_for_context_slot`, `remove_existing_context_and_descendents`). -/
def St.removeOperator (s : St) (g : Goal) : St :=
  ({ s with arch := s.arch.filter (fun w => !(w.id == g.id && isOpAttr w.attr && !w.acc)),
            opPref := s.opPref.filter (·.1 != g.id), opUid := s.opUid.filter (·.1 != g.id) }).removeGoalsFrom (max 2 (g.level + 1))

/-- What a synchronisation step does to the slots: the elements it keeps (each with its slot's
current supporting preference), the new ones in the order they were first made, and the ones
that go. -/
def St.syncPlan (s : St) : List WEnt × List WEnt × List WEnt :=
  let d := s.desired
  let dm : Std.HashMap WME WEnt := d.foldl (fun m e => m.insert e.w e) {}
  let olds : Std.HashSet WME := s.slots.foldl (fun m e => m.insert e.w) {}
  -- kept, new, gone
  (s.slots.filterMap fun e => dm.get? e.w, d.filter fun e => !olds.contains e.w,
   s.slots.filter fun e => !dm.contains e.w)

/-- The state a synchronisation step ends in, before the timetags are given. -/
def St.syncStep (s : St) (p : List WEnt × List WEnt × List WEnt) : St :=
  { s with slots := p.1 ++ p.2.1 }

/-- The highest state whose selected operator lost its acceptable-preference element. -/
def St.syncLost (s' : St) (gone : List WEnt) : Option Goal :=
  s'.goals.find? fun g => gone.any fun e =>
    e.w.acc && isOpAttr e.w.attr && e.w.id == g.id && s'.selected g.id == some e.w.val

/-- Bring the elements made from preference memory up to date (the slot decisions of Soar's
working-memory phase). An element that is kept keeps its place and takes its slot's current
supporting preference; new ones are added in the order they were first made. When the
acceptable-preference element for a state's selected operator goes, the operator and the
substates below are removed at once (Soar 9.6.5 `remove_operator_if_necessary`); the
preferences made in those substates go with them, so the slots are decided again. -/
def St.sync (s : St) : Nat → St
  | 0 => s
  | n + 1 =>
    let p := s.syncPlan
    let s' := s.syncStep p
    match St.syncLost s' p.2.2 with
    | some g => (s'.removeOperator g).sync n
    | none => s'.retag

/-- Remove o-supported preferences for identifiers no longer linked to a state, and the
elements they made.

> "The architecture automatically removes WMEs that are no longer linked to a state (because
> some other WME has been removed)." — [Man] §2.2 -/
def St.gc (s : St) : St :=
  let s := s.relevel
  let ids := Std.HashSet.ofList (reach s.raw (s.goals.map (·.id)))
  let ps := s.prefs.filter (fun p => !p.osup || ids.contains p.id)
  -- (S23 in the code review: when no preference is removed there is nothing to bring up to date)
  if ps.length == s.prefs.length then s else ({ s with prefs := ps }).sync 4

/-- **Goal dependency set check**: a substate any of whose dependencies has left working
memory is removed (and regenerated by the next decision). The state above is marked as having
changed, so its decision is made again (Soar 9.6.5 `gds_invalid_so_remove_goal`).

> "Whenever any of the WMEs in the dependency set of a substate change, the substate is
> regenerated." — [Man] §2.7.7 -/
def St.gdsCheck (s : St) : St :=
  let wm : Std.HashSet WME := if s.goals.any (fun g => g.level ≥ 2 && !g.gds.isEmpty) then Std.HashSet.ofList s.wm else {}
  let tm : Std.HashMap WME Nat := if s.goals.any (fun g => g.level ≥ 2 && !g.gds.isEmpty) then s.ttMap else {}
  match s.goals.find? (fun g => g.level ≥ 2 && g.gds.any (fun (w, t) => !wm.contains w || tm.getD w 0 != t)) with
  | some g =>
    let above := (s.goals.find? (fun h => h.level + 1 == g.level)).map (·.id)
    let s := (s.removeGoalsFrom g.level)
    let s := match above with
      | some a => { s with ctxTop := some (match s.ctxTop with
                                | some t => if t ≥ g.level then g.level - 1 else t
                                | none => g.level - 1),
                           ctxChanged := if s.ctxChanged.contains a then s.ctxChanged else s.ctxChanged ++ [a] }
      | none => s
    (s.sync 4).gc
  | none => s

/-! ## Matching -/

inductive Phase where
  | propose | apply
  deriving DecidableEq, Repr

/-- A current match of a production. -/
structure Match where
  prod  : Production
  b     : Binding
  ws    : List WME
  level : Nat
  osup  : Bool
  tts   : List Nat := []

/-- A match is identified by its production and the timetags of the elements it matched: a
match of an element made again is a new match. -/
def Match.key (m : Match) : String × List Nat := (m.prod.name, m.tts)
def Inst.key (i : Inst) : String × List Nat := (i.name, i.tts)

/-- The match goal of a set of matched elements. -/
def St.goalOfWs (s : St) (ws : List WME) : Nat := (s.deepestGoal ws).getD 0

/-- Soar's symbol number of a constant (approximate; `St.symRank`). -/
def St.rank (s : St) (y : Sym) : Nat := (s.symIx.get? y).map (· + 1) |>.getD 1000000

/-- A rule's conditions in the order they are matched (`joinOrder`). The set of matches does not
depend on the order. Soar's own reorderer (`soarConds`) gives the order Soar's explanation
records follow, and is used for them (`St.soarPairs`); it is not used for matching, because
this matcher computes all matches from scratch by nested loops (Soar's Rete matches
incrementally), and for some rules Soar's order makes that exponentially slower (for example
`towers-of-hanoi*desired-of-disk*satisfied`, whose eleven `^holds` conditions it takes before
the conditions that tell them apart). -/
def St.condOrder (s : St) (p : Production) : List Cond :=
  match s.ordCache.get? p.name with
  | some e => if e.multi == s.multi && e.conds == p.conds then e.join else joinOrder p.conds s.multi
  | none => joinOrder p.conds s.multi

/-- Does a production test long-term-identifier links (`@`, `!@`, `@+`, `@-`)? -/
def Production.usesLti (p : Production) : Bool :=
  let t (x : Test) : Bool := x.any fun st => match st with | .lti _ | .ltiRel _ _ => true | _ => false
  let pt (q : Pat) : Bool := t q.id || t q.attr || t q.val
  p.conds.any fun c => c.pats.any pt

/-- The initial bindings for matching a production with long-term-identifier tests: `@n` ↦
the number of the long-term identifier that identifier `n` is linked to. -/
def St.ltiBindings (s : St) : Binding := s.ltiOf.map fun (n, l) => (s!"@{n}", Sym.int l)

def St.matches (s : St) (pm : List Production) : List Match :=
  if pm.isEmpty then [] else
  let ix := WmIndex.ofList s.wm
  let tm := s.ttMap
  -- the `state` keyword: the identifier must be a state, not merely have `^type state`
  -- (Soar's goal test; a retrieved episode has `^type state` but is not a state)
  pm.flatMap fun p =>
    let cs := s.condOrder p
    -- `matchCondsIx ix cs [] = matchConds s.wm cs []` (`matchCondsIx_eq`)
    let all := (matchCondsIx ix cs (if p.usesLti then s.ltiBindings else [])).filter fun (_, ws) =>
      ((positives cs).zip ws).all fun (pt, w) => !pt.goal || s.isGoal w.id
    all.enum.map fun (k, (b, ws)) =>
    { prod := p, b := b, ws := ws, level := s.instLevel ws, tts := ws.map (tm.getD · 0),
      osup := s.reteSupport p b ws ((all.eraseIdx k).reverse) }

/-- The matches of `p` whose positive conditions match elements of `ws` only (the
instantiation of a rule just learned from those elements). Negated conditions are tested
against all of working memory with the full bindings; the reorderer places them after the
conditions binding the variables they share, so this agrees with `St.matches`. -/
def St.matchesWithin (s : St) (p : Production) (ws : List WME) : List Match :=
  let ix := WmIndex.ofList s.wm
  let tm := s.ttMap
  let cs := s.condOrder p
  let negOk (b : Binding) : Cond → Bool
    | .pos _ => true
    | .neg ps => (matchPatsIx ix ps b).isEmpty
    | .ncc ps ns => !((matchPatsIx ix ps b).any (fun b' => ns.all fun n => (matchPatsIx ix n b').isEmpty))
    | .nccg ns => !(ns.tree.holds ix.wm b)
  ((matchConds ws ((positives cs).map Cond.pos) []).filter fun (b, ws') =>
      cs.all (negOk b) && ((positives cs).zip ws').all fun (pt, w) => !pt.goal || s.isGoal w.id).map fun (b, ws') =>
    { prod := p, b := b, ws := ws', level := s.instLevel ws', osup := s.oSupported p b ws', tts := ws'.map (tm.getD · 0) }


/-! ## The Rete's order -/

/-- A rule's conditions as Soar's parser makes them: `(state <s> ^a …)` is one condition with a
goal test on its identifier (`parse_head_of_conds_for_one_id`); the model's parser also makes a
`(<s> ^type state)` condition for the keyword (with the goal test), which the Rete leaves out,
putting the goal test on the next condition for the same identifier. -/
def reteConds : List Cond → List Cond
  | .pos p :: .pos q :: cs =>
    if p.goal && p.attr == [.const (.str "type")] && p.val == [.const (.str "state")] && q.id == p.id then
      .pos { q with goal := true } :: reteConds cs
    else .pos p :: reteConds (.pos q :: cs)
  | c :: cs => c :: reteConds cs
  | [] => []

/-- The condition orders of a rule (see `St.ordCache`). -/
def OrdEntry.ofProd (rank : Sym → Nat) (multi : List (String × Nat)) (p : Production) : OrdEntry :=
  { conds := p.conds, multi := multi, join := joinOrder p.conds multi,
    sord := soarOrder rank multi p.conds, rord := soarCondOrder rank multi (reteConds p.conds) }

/-- The cached entry for a rule, when it was made for the rule's conditions and `multi`. -/
def St.ordEntry (s : St) (p : Production) : Option OrdEntry :=
  (s.ordCache.get? p.name).filter fun e => e.multi == s.multi && e.conds == p.conds

/-- Soar's order of a rule's conditions (`soarOrder`), from the cache when it can be. -/
def St.soarOrderOf (s : St) (p : Production) : List (Nat × Pat) :=
  match s.ordEntry p with
  | some e => e.sord
  | none => soarOrder s.rank s.multi p.conds

/-- Soar's order of the Rete's form of a rule's conditions, from the cache when it can be. -/
def St.reteOrderOf (s : St) (p : Production) : List (Option Nat × Cond) :=
  match s.ordEntry p with
  | some e => e.rord
  | none => soarCondOrder s.rank s.multi (reteConds p.conds)

/-- Make the cache entries of the rules not in it: the loaded rules when the Rete is first
brought up to date, and rules learned or made by templates since. -/
def St.fillOrd (s : St) (pm : List Production) : St :=
  let ps := (if s.rete.inited then [] else pm) ++ s.chunks ++ s.rlGen
  { s with ordCache := ps.foldl (fun c p =>
      if c.contains p.name then c else c.insert p.name (OrdEntry.ofProd s.rank s.multi p)) s.ordCache }

/-- Soar's reorderer takes goal tests out with the other non-equality tests and puts them back
on the first condition, in the new order, whose identifier is the variable
(`restore_and_deallocate_saved_tests`: goal tests go only in identifier fields, once). -/
def placeGoals (cs : List (Option Nat × Cond)) : List (Option Nat × Cond) :=
  let idVar (p : Pat) : Option String := p.id.findSome? fun t => match t with | .var v => some v | _ => none
  let gv : List String := cs.filterMap fun (_, c) => match c with
    | .pos p => if p.goal then idVar p else none
    | _ => none
  (cs.foldl (fun (acc : List (Option Nat × Cond) × List String) (i, c) => match c with
    | .pos p =>
      let v := idVar p
      let put := match v with | some v => gv.contains v && !acc.2.contains v | none => false
      (acc.1 ++ [(i, .pos { p with goal := put })], if put then acc.2 ++ v.toList else acc.2)
    | c => (acc.1 ++ [(i, c)], acc.2)) ([], [])).1

/-- A match's key in the Rete: the rule's name and the timetags of the elements its positive
conditions matched, in the rule's order of conditions (`reteConds`). -/
def St.reteKey (s : St) (tm : Std.HashMap WME Nat) (m : Match) : String × List Nat :=
  (m.prod.name, (positives (reteConds m.prod.conds)).map fun p =>
    ((m.ws.find? fun w => (p.run m.b w).isSome).bind tm.get?).getD 0)

/-- Soar's initial elements, in the order they enter the Rete (`init_agent_memory`: the top
state's elements are made in one batch and its io elements in a second; each batch enters the
Rete last made first). -/
def initOrder : List (Nat × String) :=
  [(8, "result"), (8, "command"), (1, "smem"), (5, "present-id"), (5, "result"), (5, "command"),
   (1, "epmem"), (1, "reward-link"), (1, "superstate"), (1, "type"),
   (2, "output-link"), (2, "input-link"), (1, "io")]

/-- The bindings and elements of the match the Rete model has under `key`: the rule's positive
conditions matched, in the matcher's order (`St.condOrder`), against the elements the Rete
matched (and the states' `^type state` elements, which the Rete folds into a goal test). The
Rete has checked the negations against all of working memory. -/
def St.reteMatchOf (s : St) (p : Production) (key : String × List Nat) : List (Binding × List WME) :=
  let cs := s.condOrder p
  let pos := positives cs
  -- (each element once: one element can match several conditions)
  let small : List WME := dedupW (key.2.filterMap (fun t => s.rete.wm.get? t) ++
    s.goals.map (fun g => ({ id := g.id, attr := .str "type", val := .str "state" } : WME)))
  let tm := s.ttMap
  (matchConds small (pos.map Cond.pos) (if p.usesLti then s.ltiBindings else [])).filter fun (b, ws) =>
    (pos.zip ws).all (fun (pt, w) => !pt.goal || s.isGoal w.id) &&
    s.reteKey tm { prod := p, b := b, ws := ws, level := 0, osup := false } == key

/-- Bring the match cache up to date with the Rete model: matches the network added since are
reconstructed (`St.reteMatchOf`) and their support classified once, as Soar does when the
network reaches the production node, from the production's matches at that moment
(`p_node_left_addition`); matches the network removed are dropped. With `--check-match` the
cache is compared with the matcher's matches. -/
def St.reteCache (s : St) (pm : List Production) : St :=
  if s.rete.step == s.rete.cached then s else
  -- (rules with long-term-identifier tests are matched by the matcher: `St.curMatches`)
  let pm := pm.filter (!·.usesLti)
  let byName : Std.HashMap String Production := pm.foldl (fun m p => m.insert p.name p) {}
  let live := s.rete.live
  let kept := s.mcache.filter fun k _ => live.contains k
  let added := live.fold (fun (acc : List (String × List Nat)) k _ => if kept.contains k then acc else k :: acc) []
  let cache := added.foldl (fun (c : Std.HashMap (String × List Nat) (List (Binding × List WME × Bool))) k =>
    match byName.get? k.1 with
    | none => c
    | some p =>
      let others : List (Binding × List WME) := ((s.rete.sup.get? k).getD []).drop 1 |>.map fun tts =>
        ([], tts.filterMap (fun t => s.rete.wm.get? t))
      c.insert k ((s.reteMatchOf p k).map fun (b, ws) => (b, ws, s.reteSupport p b ws others))) kept
  let s := { s with mcache := cache, rete := { s.rete with sup := {}, cached := s.rete.step } }
  if !s.checkMatch then s else
  let tm := s.ttMap
  let ms := s.matches pm
  let mk : List (String × List Nat) := ms.map (s.reteKey tm ·)
  let missing := ms.filter fun m => !cache.contains (s.reteKey tm m)
  let extra := cache.toList.filter fun (k, _) => !mk.contains k
  let osupDiff := ms.filter fun m => match cache.get? (s.reteKey tm m) with
    | some l => l.any (fun (_, ws, o) => ws == m.ws && o != m.osup) || !l.any (fun (b, ws, _) => ws == m.ws && b == m.b)
    | none => false
  let cnt : Std.HashMap (String × List Nat) Nat := ms.foldl (fun c m => c.insert (s.reteKey tm m) ((c.getD (s.reteKey tm m) 0) + 1)) {}
  let countDiff := cache.toList.filter fun (k, l) => cnt.contains k && cnt.getD k 0 != l.length
  let n := missing.length + extra.length + countDiff.length
  let ex := countDiff.map (fun (k, l) => s!"d{s.dc} count differs {k}: matcher {cnt.getD k 0} rete {l.length}") ++
    missing.map (fun m => s!"d{s.dc} matcher-only {s.reteKey tm m}") ++
    extra.map (fun (k, _) => s!"d{s.dc} rete-only {k}") ++
    osupDiff.map (fun m => s!"d{s.dc} support or bindings differ {s.reteKey tm m}: matcher {m.osup} {repr m.b} / rete {repr ((cache.get? (s.reteKey tm m)).getD []).length}")
  if ex.isEmpty then s else
  { s with rete := { s.rete with misses := s.rete.misses + n, missEx := (s.rete.missEx ++ ex).take 40 } }

/-- The current matches: from the Rete model's match cache while the Rete is on (the network
matches incrementally, as Soar's does), else from the matcher (`St.matches`), which the
matcher theorems are about. That the two give the same matches is not proved: it is checked
at run time by `--check-match`; with the Rete off (`reteOn = false`) the two are the same.

SIMPLIFIED: rules with long-term-identifier tests (`@`, `!@`, `@+`, `@-`) are matched by the
matcher, against the links as they are when the match set is computed; the Rete model
evaluates those tests when an element enters the network, and the order of a link and the
elements that test it is not modeled finely enough for that to agree with Soar 9.6.5. -/
def St.curMatches (s : St) (pm : List Production) : List Match :=
  if s.reteOn && s.rete.inited then
    let byName : Std.HashMap String Production := (pm.filter (!·.usesLti)).foldl (fun m p => m.insert p.name p) {}
    let tm := s.ttMap
    s.mcache.fold (fun (acc : List Match) k l => match byName.get? k.1 with
      | none => acc
      | some p => l.foldl (fun acc (b, ws, o) =>
          { prod := p, b := b, ws := ws, level := s.instLevel ws, osup := o, tts := ws.map (tm.getD · 0) } :: acc) acc)
      (s.matches (pm.filter (·.usesLti)))
  else s.matches pm

/-- The match set's pending changes (Soar's assertion and retraction lists): new matches not yet
instantiated, i-supported and o-supported, and instantiations in the match set that no longer
match (a justification: whose conditions are not all present). -/
structure Pend where
  iAss : List Match := []
  oAss : List Match := []
  retr : List Inst := []

def St.pending (s : St) (pm : List Production) : Pend :=
  let ms := s.curMatches (pm ++ s.chunks ++ s.rlGen)
  let live := s.insts.filter (·.inMs)
  let keys : Std.HashSet (String × List Nat) := Std.HashSet.ofList (live.map (·.key))
  let fresh := ms.filter (fun m => !keys.contains m.key)
  let mkeys : Std.HashSet (String × List Nat) := Std.HashSet.ofList (ms.map (·.key))
  let wm : Std.HashSet WME := if live.any (·.just) then Std.HashSet.ofList s.wm else {}
  let tm : Std.HashMap WME Nat := if live.any (·.just) then s.ttMap else {}
  { iAss := fresh.filter (!·.osup), oAss := fresh.filter (·.osup),
    retr := live.filter fun i => if i.just then !(i.ws.zip i.tts).all (fun (w, t) => wm.contains w && tm.getD w 0 == t)
                                 else !mkeys.contains i.key }

/-- Activity at a level: i-supported (new i-supported matches or retractions) and o-supported. -/
def Pend.iAct (p : Pend) (l : Nat) : Bool := p.iAss.any (·.level == l) || p.retr.any (·.level == l)
def Pend.oAct (p : Pend) (l : Nat) : Bool := p.oAss.any (·.level == l)

/-- The most tokens the Rete model keeps (`St.reteSync`). -/
def reteTokenLimit : Nat := 400000

/-- Bring the Rete up to date (Soar adds rules to the Rete as they are loaded or learned, and
working-memory changes at the end of each phase): on the first call Soar's initial elements
and the loaded rules, in order; then rules learned since the last call, then the elements
added since (last made first) and removed since. -/
def St.reteSync (s : St) (pm : List Production) : St :=
  if !s.reteOn then s else
  let s := s.fillOrd pm
  let conds (p : Production) := placeGoals (s.reteOrderOf p)
  let net := { s.rete with goals := s.goals.map (·.id), ltis := s.ltiOf }
  let go : Rete.M Unit := do
    if !(← get).inited then
      for (i, a) in initOrder do
        match s.tt.find? (fun (w, _) => w.id == i && w.attr == .str a && !w.acc) with
        | some (w, t) => Rete.addWme t w
        | none => pure ()
      for p in pm do Rete.addProd p.name (conds p) p.support.isNone
      modify fun n => { n with inited := true }
    -- `Rete.addProd` ignores a rule already in the network, so skip the reordering for those
    for p in s.chunks ++ s.rlGen do
      unless (← get).names.contains p.name do Rete.addProd p.name (conds p) p.support.isNone
    let n ← get
    let cur : Std.HashMap Nat WME := s.tt.foldl (fun m (w, t) => m.insert t w) {}
    -- additions: those of the working-memory phases last made first (`wmes_to_add` is
    -- processed last pushed first), then the others (architecture and input), newest first
    -- additions: newest first (`wmes_to_add` is processed last pushed first; timetags follow
    -- Soar's order of creation, `St.soarRetag`)
    let adds := (s.tt.filter (fun (_, t) => !n.wm.contains t)).mergeSort (fun a b => a.2 ≥ b.2)
    for (w, t) in adds do Rete.addWme t w
    let rankR : Std.HashMap WME Nat := s.pushRem.enum.foldl (fun m (k, w) => m.insert w k) {}
    let rems := (← get).wm.toList.filter (fun (t, _) => !cur.contains t)
    let rRanked := (rems.filter (rankR.contains ·.2)).mergeSort (fun a b => rankR.getD a.2 0 ≥ rankR.getD b.2 0)
    -- removals: last pushed first (`St.pushOrder`); others (input) before them, oldest first
    let rOthers := (rems.filter (!rankR.contains ·.2)).mergeSort (fun a b => a.1 ≤ b.1)
    for (t, _) in rOthers ++ rRanked do Rete.removeWme t
  let net := (go.run net).2
  -- a limit on the network's size: beyond it (the partial matches of a rule with many similar
  -- conditions can grow without bound, as they do in Soar), the Rete's order is given up for
  -- the rest of the run
  if net.toks.size > reteTokenLimit then { s with rete := {}, reteOn := false, pushRem := [], marks := [], cmarks := [], mcache := {} }
  else
    -- the record of removed matches is kept for the instantiations that can still be retracted
    -- (S20 in the code review)
    let net := if net.gone.size < 4096 then net else
      let live : Std.HashSet (String × List Nat) := s.insts.foldl (fun m i => m.insert (i.name, i.rkey)) {}
      { net with gone := net.gone.filter fun k _ => live.contains k }
    ({ s with rete := net, pushRem := [] } : St).reteCache (pm ++ s.chunks ++ s.rlGen)

/-- Count new matches the Rete does not have (a check on the Rete model). -/
def St.reteNote (s : St) (pd : Pend) : St :=
  if !s.reteOn then s else
  let tm := s.ttMap
  let miss := (pd.iAss ++ pd.oAss).filter fun m => !(s.rete.live.contains (s.reteKey tm m))
  if miss.isEmpty then s else
  let ex := (s.rete.missEx ++ miss.map (fun m => s!"d{s.dc} {(s.reteKey tm m)}")).take 20
  { s with rete := { s.rete with misses := s.rete.misses + miss.length, missEx := ex } }

/-- New matches in the order Soar's preference phase takes them: the one the Rete reached last
first (`postpone_assertion` takes the head of the state's assertion list). Matches the Rete
does not have (it should have every one) keep their order, after the others. -/
def St.reteOrder (s : St) (pd : Pend) : Pend :=
  if !s.reteOn then pd else
  let tm := s.ttMap
  let seq (m : Match) : Nat := (s.rete.live.get? (s.reteKey tm m)).getD 0
  let ord (ms : List Match) := ms.mergeSort (fun a b => seq a ≥ seq b)
  -- retractions: the match the Rete removed last first (`get_next_retraction`)
  let gone (i : Inst) : Nat := (s.rete.gone.get? (i.name, i.rkey)).getD 0
  { pd with iAss := ord pd.iAss, oAss := ord pd.oAss, retr := pd.retr.mergeSort (fun a b => gone a ≥ gone b) }
/-! ## Results and justifications ([Man] §2.7.3–2.7.4) -/

/-- The preferences a new supporting instantiation `j` (a justification, or a learned rule's
instantiation) makes for results: elements as acceptable preferences, operator preferences,
and removals as reject preferences (Soar's clones of the result preferences). -/
def St.resultPrefs (s : St) (j : Inst) (rw : List WME) (rp : List Pref) (rr : List WME) : List PRec :=
  mkPRecs s.pNext j.iid j.level j.goal j.osup (
    rw.map (fun w => (w.id, w.attr, w.val, PrefKind.acceptable, none, none)) ++
    (rp.filter (fun p => !(p.kind == .acceptable && rw.any (fun w => w.id == p.state && isOpAttr w.attr && w.val == p.op)))).map
      (fun p => (p.state, Sym.str "operator", p.op, p.kind, p.other, p.num)) ++
    rr.map (fun w => (w.id, w.attr, w.val, PrefKind.reject, none, none)))

/-- Add an instantiation that supports results, with its preferences for them (Soar's clones of
the result preferences, `make_clones_of_results`); like those of the instantiation that made
the results, which stay as they are and go with its state, they are asserted at the end of the
pass. -/
def St.supportResults (s : St) (j : Inst) (rw : List WME) (rp : List Pref) (rr : List WME) : St :=
  let j := { j with iid := s.iNext, tts := if j.tts.isEmpty then j.ws.map s.ttOf else j.tts }
  let ps := s.resultPrefs j rw rp rr
  { s with insts := s.insts ++ [j], iNext := s.iNext + 1, pNext := s.pNext + ps.length, fresh := s.fresh ++ ps }

/-- Two preferences are the same result (Soar 9.6.5 `add_pref_to_results`): the same
identifier, attribute, value and type, and the same referent. -/
def PRec.sameResult (p q : PRec) : Bool :=
  p.id == q.id && p.attr == q.attr && p.val == q.val && p.kind == q.kind && p.ref == q.ref

/-- The results of an instantiation at level `L` whose own preferences are `own`, as a set of
preferences (Soar 9.6.5 `get_results_for_instantiation`, `add_pref_to_results`,
`add_results_if_needed`): its preferences for identifiers of higher states, and with each
result, transitively, the preferences of the identifiers local to level `L` reached from its
value and referent. Soar walks every preference of such an identifier's slots, the instantiation's
own preferences for it, and the values of its slots' and input elements (not the
architecture's elements other than operator selections). A preference made at another level
is replaced by a clone of it made at level `L`, and is left out if there is none; a preference
the same as one already among the results is left out. The results are in the order they were
found. -/
def St.resultSet (s : St) (L : Nat) (own : List PRec) : List PRec :=
  let pool := s.prefs ++ s.fresh ++ own
  let atL (p : PRec) : Option PRec :=
    if p.level == L then some p else pool.find? (fun q => q.sameResult p && q.level == L)
  let wm := s.raw
  let walked := wm.filter fun w => !s.arch.contains w || (isOpAttr w.attr && !w.acc)
  let idOf (y : Sym) : Option Nat := match y with
    | .id n => if s.idLevel n ≥ L then some n else none
    | _ => none
  -- one step: the preferences of identifier `n` to consider, and the values to walk on
  let prefsOn (n : Nat) : List PRec := s.prefs.filter (·.id == n) ++ own.filter (·.id == n)
  let walkedBy : Std.HashMap Nat (List Nat) :=
    walked.foldr (fun w m => match idOf w.val with
      | some v => m.insert w.id (v :: m.getD w.id [])
      | none => m) {}
  let valsOn (n : Nat) : List Nat := walkedBy.getD n []
  -- the walk: a queue of preferences to add and identifiers to visit
  let rec go : Nat → List PRec × List Nat → List (Sum PRec Nat) → List PRec × List Nat
    | 0, acc, _ => acc
    | _, acc, [] => acc
    | f + 1, (rs, seen), .inl p :: rest =>
      if rs.any (·.sameResult p) then go f (rs, seen) rest else -- `rs` is newest first
      match atL p with
      | none => go f (rs, seen) rest
      | some p =>
        let nxt := (idOf p.val).toList ++ ((p.ref.bind idOf).toList)
        go f (p :: rs, seen) (nxt.map .inr ++ rest)
    | f + 1, (rs, seen), .inr n :: rest =>
      if seen.contains n then go f (rs, seen) rest else
      go f (rs, n :: seen) ((prefsOn n).map .inl ++ (valsOn n).map .inr ++ rest)
  let start := own.filter (fun p => s.idLevel p.id < L)
  (go (4 * (pool.length + wm.length) + 8) ([], []) (start.map .inl)).1.reverse

/-- A set of result preferences as the elements, operator preferences and removals that the
model's instantiations record (the inverse of `effPrefs`): an acceptable preference is an
element (and, on a state's operator slot, an acceptable operator preference), a reject
preference for an attribute other than operator is a removal, and every other operator
preference is an operator preference. -/
def St.resultParts (s : St) (rs : List PRec) : List WME × List Pref × List WME :=
  let rw := (rs.filter (·.kind == .acceptable)).map fun p =>
    ({ id := p.id, attr := p.attr, val := p.val, acc := isOpAttr p.attr && s.isGoal p.id } : WME)
  let rp := (rs.filter (fun p => isOpAttr p.attr && (p.kind != .acceptable || s.isGoal p.id))).map PRec.toPref
  let rr := (rs.filter (fun p => p.kind == .reject && !isOpAttr p.attr)).map fun p =>
    ({ id := p.id, attr := p.attr, val := p.val } : WME)
  (rw, rp, rr)

/-- A justification for results `rw rp rr` of instantiation `i` at level `L` ([Man]
§2.7.3–2.7.4): its conditions are the superstate elements that `i`'s conditions, and `more`
(the conditions of the instantiations of results that go with them), depend on. -/
def St.justifyResults (s : St) (L : Nat) (i : Inst) (rw : List WME) (rp : List Pref) (rr : List WME)
    (more : List WME) : St :=
  -- conditions are traced back to the level the results attach to: elements of
  -- intermediate substates are local and are traced through (checked against Soar 9.6.5,
  -- 2026-10-28, on a result created two levels below the state it attaches to)
  let rLevel := ((rw.map (fun w => s.idLevel w.id)) ++ (rp.map (fun p => s.idLevel p.state)) ++
    (rr.map (fun w => s.idLevel w.id))).foldl min L
  let conds := s.backtrace (rLevel + 1) false 20 (i.ws ++ more)
  let jLevel := s.instLevel conds
  let jGoal := s.goalOfWs conds
  let testsOp := conds.any (fun w => w.id == jGoal && isOpAttr w.attr && !w.acc)
  let proposes := rw.any (·.acc)
  s.supportResults { name := s!"justification-{s.iNext}", ws := conds, level := jLevel, goal := jGoal,
                     osup := testsOp && !proposes, kind := .justification, made := rw, prefs := rp, rems := rr } rw rp rr

/-- Results without learning: for each new instantiation at level `L` that made preferences for
a higher state, a justification supports its results (`St.resultSet`); the conditions of the
instantiations of the results that go with them are traced too. -/
def St.makeResults (s : St) (L : Nat) (newInsts : List Inst) : St :=
  newInsts.foldl (fun (s : St) i =>
    let rs := s.resultSet L (s.prefs.filter (·.inst == i.iid))
    if rs.isEmpty then s else
    let (rw, rp, rr) := s.resultParts rs
    let more := ((rs.filter (·.inst != i.iid)).filterMap (fun p => s.instById p.inst)).flatMap (·.ws)
    s.justifyResults L i rw rp rr more) s


/-- Record in the goal dependency set of level `L` the superstate dependencies of new local
o-supported elements, whose creating instantiations tested `ws`.

> "Whenever such an o-supported WME is created, Soar records which superstate WMEs were
> tested, directly or indirectly, to create it." — [Man] §2.7.7 -/
def St.addGds (s : St) (L : Nat) (ws : List WME) : St :=
  if L ≥ 2 then
    let deps := s.backtrace L true 20 ws
    { s with goals := s.goals.map (fun g => if g.level == L then
        { g with gds := g.gds ++ (deps.map (fun w => (w, s.ttOf w))).filter (!g.gds.contains ·) } else g) }
  else s

/-! ## Chunking: recording instantiations and learning rules ([Man] chapter 4)

The learning computation is in `Soar/Chunk.lean`. Here: when learning is on, every
instantiation that fires in a substate leaves an explanation record (`XInst`); when results
are created, a rule is learned from the records, added to production memory (`chunks`), and
its instantiation takes over the support of the results. -/

/-- Is learning on? (`chunk always`; `chunk except` without `dont-learn` states.) -/
def St.learning (s : St) : Bool := s.chunkCfg.mode != .never

/-- Are rules (rather than justifications) learned for results of state `g`? -/
def St.learnsIn (s : St) (g : Nat) : Bool :=
  match s.chunkCfg.mode with
  | .always => true
  | .never => false
  | .only => s.forceLearn.contains g
  | .except => !s.dontLearn.contains g

/-- The variables a condition tests (positive patterns only: those bound by a match). -/
def condVars : Cond → List String
  | .pos p => p.eqVars ++ p.useVars
  | _ => []

def unboundOf (p : Production) (b : Binding) : List String :=
  (p.acts.flatMap actionVars).eraseDups.filter (fun v => (b.get v).isNone)

/-- The elements a working-memory phase adds and removes, in the order Soar 9.6.5 makes the
changes (`decide_non_context_slots`, then `do_buffered_acceptable_preference_wme_changes`):
slots in the reverse of the order they were first marked changed; in a slot, first the
removals (newest element first), then the new values in the order of
`run_non_context_preference_semantics` (the reverse of the slot's acceptable preferences, which
are by match-goal level and then most recently added first); then the operator slots'
acceptable-preference elements, in the reverse of the order those slots were marked, require
preferences before acceptable ones. -/
def St.pushOrder (s pre : St) : List WME × List WME :=
  let ptm := pre.ttMap
  let preW : Std.HashSet WME := pre.slots.foldl (fun m e => m.insert e.w) {}
  let nowW : Std.HashSet WME := s.slots.foldl (fun m e => m.insert e.w) {}
  let new := (s.slots.filter fun e => !preW.contains e.w).map (·.w)
  let gone := ((pre.slots.filter fun e => !nowW.contains e.w).map (·.w)).mergeSort (fun a b => ptm.getD a 0 ≥ ptm.getD b 0)
  let key (w : WME) : Nat × Sym := (w.id, w.attr)
  let order (ps : List PRec) : List PRec :=
    ps.mergeSort (fun a b => a.level < b.level || (a.level == b.level && a.aseq > b.aseq))
  -- the preferences of each slot, in the order of `s.prefs` (filtering all preferences per slot is quadratic)
  let bySlot : Std.HashMap (Nat × Sym) (List PRec) :=
    s.prefs.foldr (fun p m => m.insert (p.id, p.attr) (p :: m.getD (p.id, p.attr) [])) {}
  let slotPrefs (k : Nat × Sym) : List PRec := bySlot.getD k []
  let nonCtx (k : Nat × Sym) : List WME × List WME :=
    let ps := slotPrefs k
    let rej := (ps.filter (·.kind == .reject)).map (·.val)
    let vals := ((order (ps.filter (·.kind == .acceptable))).map (·.val)).eraseDups.filter (!rej.contains ·)
    let adds := vals.reverse.filterMap fun v => new.find? fun w => !w.acc && key w == k && w.val == v
    (adds, gone.filter fun w => !w.acc && key w == k)
  let ctx (k : Nat × Sym) : List WME × List WME :=
    let ps := slotPrefs k
    let vals := ((order (ps.filter (·.kind == .require))).map (·.val) ++ (order (ps.filter (·.kind == .acceptable))).map (·.val)).eraseDups
    let adds := vals.filterMap fun v => new.find? fun w => w.acc && key w == k && w.val == v
    (adds, gone.filter fun w => w.acc && key w == k)
  -- an element whose preference went with its state, or is still there (its identifier is
  -- no longer linked), is removed by garbage collection (`do_buffered_link_changes`), after
  -- the slots and the states' own elements; the others are removed when their slot is decided
  let slotOf : Std.HashMap WME WEnt := pre.slots.foldl (fun m e => if m.contains e.w then m else m.insert e.w e) {}
  let prefOf : Std.HashMap Nat PRec := pre.prefs.foldl (fun m p => if m.contains p.pid then m else m.insert p.pid p) {}
  let nowP : Std.HashSet Nat := Std.HashSet.ofList (s.prefs.map (·.pid))
  let gcd (w : WME) : Bool := match slotOf[w]? with
    | some e => match prefOf[e.pref]? with
      | some p => !s.goals.any (·.id == p.goal) || nowP.contains p.pid
      | none => false
    | none => false
  let ncs := s.marks.reverse.map nonCtx
  let cs := s.cmarks.reverse.map ctx
  let adds := ncs.flatMap (·.1) ++ cs.flatMap (·.1)
  let rems := (ncs.flatMap (·.2) ++ cs.flatMap (·.2)).filter (!gcd ·)
  let remsS : Std.HashSet WME := Std.HashSet.ofList rems
  let rems := rems ++ gone.filter (fun w => !gcd w && !remsS.contains w)
  -- the states' own elements (an operator selection, a substate), newest first
  let preArch : Std.HashSet WME := s.arch.foldl (fun m w => m.insert w) {}
  let archGone := ((pre.arch.filter fun w => !preArch.contains w && pre.wm.contains w)).mergeSort (fun a b => ptm.getD a 0 ≥ ptm.getD b 0)
  let addsS : Std.HashSet WME := Std.HashSet.ofList adds
  (adds ++ new.filter (!addsS.contains ·), rems ++ archGone ++ gone.filter gcd)

/-- Soar's order of the candidates for state `g`'s operator (Soar 9.6.5 `run_preference_semantics`
builds them by walking the slot's acceptable preferences, most recently asserted first, and
putting each operator, at its first preference, onto the front of the list). The preferences of
one pass of the inner elaboration loop are asserted in the reverse of the order their
instantiations were made (`assert_new_preferences` walks `newly_created_instantiations`, newest
first). So operators proposed in earlier passes come first, oldest first, and those proposed
in one pass come in the reverse of the order they were made.
Checked against Soar 9.6.5 (2026-10-30). -/
def St.candOrder (s : St) (g : Nat) (c : List Sym) : List Sym :=
  let acc := (s.prefs.filter fun p => p.id == g && isOpAttr p.attr && p.kind == .acceptable)
  -- slot order: highest state first, then most recently asserted first
  let key (p : PRec) : Nat × Nat × Nat := (p.level, s.passNo - p.pass, p.pid)
  -- with the Rete's order, Soar's order of assertion is known (`PRec.aseq`)
  let before (a b : PRec) : Bool :=
    if s.reteOn then a.level < b.level || (a.level == b.level && a.aseq > b.aseq) else
    let (la, qa, ia) := key a
    let (lb, qb, ib) := key b
    la < lb || (la == lb && (qa < qb || (qa == qb && ia < ib)))
  let walk := (acc.toArray.qsort before).toList
  let seen := walk.foldl (fun (l : List Sym) p => if l.contains p.val then l else p.val :: l) []
  let ordered := seen.filter c.contains
  if ordered.length == c.length then ordered else c

/-- The place of a new element in Soar 9.6.5's order of creation (`make_wme` numbers elements
as they are made): the initial state's elements (`create_top_goal`, then the io elements); a
new substate's elements (`create_new_context`: type, superstate, reward-link, the episodic and
semantic links, attribute, impasse, choices, quiescence, then `update_impasse_items`, which
makes the items last first), states taken from the top down; then the elements of a
working-memory phase in `pushOrder`'s order; then the others (input) as the model made them. -/
def St.creationKey (s : St) (push : Std.HashMap WME Nat) (raw : Nat) (w : WME) : Nat × Nat × Nat :=
  let a := match w.attr with | .str x => x | _ => ""
  let top : Option Nat :=
    if w.id == 1 then match a with
      | "type" => some 1 | "superstate" => some 2 | "reward-link" => some 3 | "epmem" => some 4
      | "smem" => some 8 | "io" => some 11 | _ => none
    else if w.id == 5 then match a with | "command" => some 5 | "result" => some 6 | "present-id" => some 7 | _ => none
    else if w.id == 8 then match a with | "command" => some 9 | "result" => some 10 | _ => none
    else if w.id == 2 then match a with | "input-link" => some 12 | "output-link" => some 13 | _ => none
    else none
  match top with
  | some k => (0, 0, k)
  | none =>
  let sub : Option (Nat × Nat) := s.goals.findSome? fun g =>
    if g.level < 2 then none else
    let n := g.id
    let items := match g.impasse with | some (_, _, is) => is | none => []
    -- `update_impasse_items` makes the items in the order of the candidates
    let ord := match s.goals.find? (·.level + 1 == g.level) with
      | some u => s.candOrder u.id items
      | none => items
    let pos (v : Sym) : Nat := ord.idxOf v
    if w.id == n then
      match a with
      | "type" => some (g.level, 0) | "superstate" => some (g.level, 1) | "reward-link" => some (g.level, 2)
      | "epmem" => some (g.level, 3) | "smem" => some (g.level, 7) | "attribute" => some (g.level, 10)
      | "impasse" => some (g.level, 11) | "choices" => some (g.level, 12) | "quiescence" => some (g.level, 13)
      | "item" => some (g.level, 20 + pos w.val) | "item-count" => some (g.level, 1000)
      | "non-numeric" => some (g.level, 1001 + pos w.val) | "non-numeric-count" => some (g.level, 3000)
      | _ => none
    else if w.id == n + 1 then
      match a with | "command" => some (g.level, 4) | "result" => some (g.level, 5) | _ => some (g.level, 6)
    else if w.id == n + 4 then
      match a with | "command" => some (g.level, 8) | _ => some (g.level, 9)
    else none
  -- a substate's elements are made when its superstate's slot is decided (states are decided
  -- from the top down; an operator selection at level l comes before the substate below it)
  match sub with
  | some (l, k) => (1, l - 1, k + 1)
  | none =>
    if isOpAttr w.attr && !w.acc && s.isGoal w.id then (1, (s.goalLevel w.id).getD 0, 0)
    else match push.get? w with
      | some k => (2, 0, k)
      | none => (3, 0, raw)

/-- Number the elements made since `pre` in Soar's order of creation (`St.creationKey`), so that
timetags agree with Soar's and the Rete takes each batch of new elements newest first. -/
def St.soarRetag (s pre : St) (push : List WME) : St :=
  let new := s.tt.filter (·.2 ≥ pre.tNext)
  if new.length ≤ 1 then s else
  let pm : Std.HashMap WME Nat := push.enum.foldl (fun m (k, w) => m.insert w k) {}
  let keyed := new.enum.map fun (k, (w, _)) => (s.creationKey pm k w, w)
  let lt (a b : (Nat × Nat × Nat) × WME) : Bool :=
    a.1.1 < b.1.1 || (a.1.1 == b.1.1 && (a.1.2.1 < b.1.2.1 || (a.1.2.1 == b.1.2.1 && a.1.2.2 ≤ b.1.2.2)))
  let sorted := keyed.mergeSort lt
  let tts := (new.map (·.2)).mergeSort (· ≤ ·)
  let m : Std.HashMap WME Nat := (sorted.zip tts).foldl (fun m ((_, w), t) => m.insert w t) {}
  { s with tt := s.tt.map fun (w, t) => if t ≥ pre.tNext then (w, m.getD w t) else (w, t) }

/-- Record a working-memory phase's changes in Soar's order (`St.pushOrder`), for the Rete. -/
def St.notePush (s pre : St) : St :=
  if !s.reteOn then { s with marks := [], cmarks := [] } else
  let ar := s.pushOrder pre
  ({ s with marks := [], cmarks := [], pushRem := s.pushRem ++ ar.2 } : St).soarRetag pre ar.1

/-- The elements of the slots as a hash set (membership in `s.slots.any (·.w == w)` in constant time). -/
def St.slotSet (s : St) : Std.HashSet WME := s.slots.foldl (fun m e => m.insert e.w) {}

theorem St.foldl_insert_contains (l : List WEnt) (m : Std.HashSet WME) (w : WME) :
    (l.foldl (fun m e => m.insert e.w) m).contains w = (m.contains w || l.any (·.w == w)) := by
  induction l generalizing m with
  | nil => simp
  | cons e l ih =>
    simp only [List.foldl_cons, ih, Std.HashSet.contains_insert, List.any_cons]
    cases m.contains w <;> cases (e.w == w) <;> simp [Bool.or_comm]

theorem St.slotSet_contains (s : St) (w : WME) : s.slotSet.contains w = s.slots.any (·.w == w) := by
  simp [St.slotSet, St.foldl_insert_contains]

/-- **The working-memory phase** after an elaboration cycle (Soar 9.6.5
`do_working_memory_phase`): slots are decided; for each new o-supported element made in a
substate, the superstate elements its creation depended on enter that substate's goal
dependency set (`decide_non_context_slot`, `elaborate_gds`); unlinked structure is removed;
and substates whose dependencies changed are removed. -/
def St.wmPhase (s pre : St) : St :=
  let s := s.sync 4
  let preS := pre.slotSet
  let new := s.slots.filter fun e => !preS.contains e.w
  let s := new.foldl (fun (s : St) e => match s.prefs.find? (·.pid == e.pref) with
    | some p => if p.osup && p.level ≥ 2 then
        match s.instById p.inst with
        | some i => s.addGds p.level i.ws
        | none => s
      else s
    | none => s) s
  s.gc.gdsCheck.notePush pre

/-- The long-term identifier an identifier is linked to, if any. -/
def St.ltiOf? (s : St) (n : Nat) : Option Nat := (alGet s.ltiOf n)

/-- The instantiation's unique name, if it has one (instantiations of rules that fired have). -/
def Inst.uidOpt (i : Inst) : Option String := if i.uid != "" then some i.uid else none

/-- The operator preferences for state `g` paired with the recorded instantiations that
made them, in the order of Soar 9.6.5's preference lists (by match goal level, then most
recently asserted first). -/
def St.prefObjs (s : St) (g : Nat) : List (Pref × String) :=
  ((s.prefs.filter (fun p => p.id == g && isOpAttr p.attr)).mergeSort prefBefore).filterMap fun p =>
    (s.instById p.inst).bind fun i => i.uidOpt.map (p.toPref, ·)

/-- Operator selection knowledge an instantiation copies when it fires (Soar 9.6.5
`copy_OSK`): for a condition on the selected operator of its match goal, that state's OSK
(with `add-osk` on); for any condition on an operator, its prohibit preferences. -/
def St.oskCopy (s : St) (level : Nat) (conds : List (Pat × WME)) : List String :=
  (conds.flatMap fun (p, w) =>
    if !(isOpAttr w.attr && s.isGoal w.id) then [] else
    let osk := if s.chunkCfg.addOsk && !p.acc && !w.acc && s.goalLevel w.id == some level then
        ((s.osk.find? (·.1 == w.id)).map (·.2.1)).getD []
      else []
    osk ++ (s.prefs.filter (fun q => q.kind == .prohibit && q.id == w.id && isOpAttr q.attr)).filterMap
      (fun q => (s.instById q.inst).bind Inst.uidOpt)).eraseDups

/-- The record of the instantiation whose preference supports an element now (Soar 9.6.5's
`w->preference`, `St.slots`). A selected operator is supported by the preference it was
selected by. With `atLevel`, the first preference for the element in its slot's order made by
an instantiation at that level (Soar's `add_pref_to_results`). -/
def St.traceOf (s : St) (w : WME) (atLevel : Option Nat := none) : Option String :=
  let uidOf (p : PRec) : Option String := (s.instById p.inst).bind Inst.uidOpt
  if isOpAttr w.attr && !w.acc && s.isGoal w.id then
    match s.opUid.find? (·.1 == w.id) with
    | some (_, k) => if k == "" then none else some k
    | none => none
  else
  match atLevel with
  | none => (s.wentOf w).bind uidOf
  | some l =>
    let k := if w.acc then [PrefKind.require, PrefKind.acceptable] else [PrefKind.acceptable]
    let cands := s.prefs.filter fun p => p.id == w.id && p.attr == w.attr && p.val == w.val &&
      k.contains p.kind && p.level == l && (uidOf p).isSome
    (firstPref cands).bind uidOf

/-- **`deep-copy`** ([Man] §3.3.6.8; Soar 9.6.5 `deep_copy_rhs_function_code`,
`add_deep_copy_prefs_to_inst`): an action value `(deep-copy <x>)` becomes a new identifier
under which the structure reachable from `<x>` is copied (the elements of its slots and its
input elements, each identifier copied once). The production is rewritten with the copy as
actions on bound variables; the instantiation also tests each element copied, and each copied
identifier shares the identity of its source. Returns the rewritten production and binding,
the next free identifier, the conditions on the copied elements and the identity joins. -/
def St.deepCopyFull (s : St) (p : Production) (b : Binding) (next : Nat) :
    Production × Binding × Nat × List (Pat × WME) × List (String × String) × List (Nat × Nat) :=
  let wm := s.wm
  let copyable (n : Nat) : List WME :=
    wm.filter fun w => w.id == n && !w.acc && (!s.arch.contains w || isOpAttr w.attr)
  let srcVar (b : Binding) (n : Nat) : String :=
    match b.find? (fun (_, y) => y == .id n) with
    | some (v, _) => v
    | none => s!"dcs{n}"
  p.acts.enum.foldl (fun (acc : Production × Binding × Nat × List (Pat × WME) × List (String × String) × List (Nat × Nat)) (j, a) =>
    let (p, b, next, cs, js, ls) := acc
    match a with
    | .make i aa (.call "deep-copy" [x]) =>
      match RVal.eval b [] x with
      | some (.id root) =>
        -- the identifiers reached, root first
        let ids := (List.range 50).foldl (fun (ids : List Nat) _ =>
          ids ++ ((ids.flatMap copyable).filterMap (fun w => match w.val with
            | .id m => if ids.contains m then none else some m
            | _ => none)).eraseDups) [root]
        let cv (m : Nat) : String := s!"dcc{m}"
        let b := b ++ (ids.enum.map fun (k, m) => (cv m, Sym.id (next + k))) ++
          (ids.filter (fun m => (b.find? (fun (_, y) => y == .id m)).isNone)).map (fun m => (s!"dcs{m}", Sym.id m))
        let ws := ids.flatMap copyable
        let rv (y : Sym) : RVal := match y with | .id m => .var (cv m) | c => .sym c
        let copies := ws.map fun w => Action.make (cv w.id) (.sym w.attr) (rv w.val)
        let conds := ws.map fun w =>
          (({ id := [.var (srcVar b w.id)], attr := [.const w.attr],
              val := match w.val with | .id m => [.var (srcVar b m)] | c => [.const c] } : Pat), w)
        let acts := p.acts.set j (.make i aa (.var (cv root)))
        let lvl := match RVal.eval b [] (.var i) with
          | some (.id h) => s.idLevel h
          | _ => 0
        ({ p with acts := acts ++ copies }, b, next + ids.length, cs ++ conds,
         js ++ ids.map (fun m => (cv m, srcVar b m)), ls ++ (List.range ids.length).map (fun k => (next + k, lvl)))
      | _ => acc
    | _ => acc) (p, b, next, [], [], [])

theorem List.foldl_const_of {f : β → α → β} :
    ∀ (l : List α) (acc : β), (∀ x ∈ l, ∀ a, f a x = a) → l.foldl f acc = acc
  | [], _, _ => rfl
  | x :: l, acc, h => by
    simp only [List.foldl_cons, h x (by simp) acc]
    exact List.foldl_const_of l acc fun y hy => h y (by simp [hy])

/-- An action whose value is `(deep-copy <x>)`. -/
def Action.isDeepCopy : Action → Bool
  | .make _ _ (.call "deep-copy" [_]) => true
  | _ => false

/-- `St.deepCopyFull` unless no action is a `deep-copy` (nearly every firing), when nothing is
copied and working memory need not be computed (`deepCopy_eq`). -/
def St.deepCopy (s : St) (p : Production) (b : Binding) (next : Nat) :
    Production × Binding × Nat × List (Pat × WME) × List (String × String) × List (Nat × Nat) :=
  if p.acts.any Action.isDeepCopy then s.deepCopyFull p b next else (p, b, next, [], [], [])

theorem St.deepCopy_eq (s : St) (p : Production) (b : Binding) (next : Nat) :
    s.deepCopy p b next = s.deepCopyFull p b next := by
  unfold St.deepCopy
  split
  · rfl
  · rename_i h
    have h' : ∀ a ∈ p.acts, a.isDeepCopy = false := by
      intro a ha; simpa using (List.any_eq_false.mp (by simpa using h) a ha)
    unfold St.deepCopyFull
    dsimp only
    symm
    apply List.foldl_const_of
    intro x hx a
    have hx2 : x.2 ∈ p.acts := List.enum_snd_mem hx
    have := h' x.2 hx2
    obtain ⟨j, act⟩ := x
    simp only at this ⊢
    cases act <;> try (simp_all [Action.isDeepCopy]; done)
    rename_i i aa v
    split
    · simp_all [Action.isDeepCopy]
    · rfl


/-- A match's positive conditions with the elements they matched, in Soar's order and with
the relational tests where Soar's reorderer puts them (`soarOrder`); in the matcher's order
if an element cannot be found. -/
def St.soarPairs (s : St) (p : Production) (b : Binding) (ws : List WME) : List (Pat × WME) :=
  let cs := s.condOrder p
  let pairs := (s.soarOrderOf p).map fun (_, q) => (q, ws.find? (fun w => (q.run b w).isSome))
  if pairs.all (·.2.isSome) then pairs.map (fun (q, w) => (q, w.getD default)) else (positives cs).zip ws

/-- The state right-hand-side functions change. -/
def St.rstate (s : St) : RState :=
  let isZero (y : Sym) : Bool := match y with | .float b => Float.ofBits b == 0 | _ => false
  let z : Option Float := s.zeroSym <|> (s.symRank.find? isZero).bind Sym.num? <|>
    ((s.raw.find? (fun w => isZero w.val)).map (·.val)).bind Sym.num?
  { rng := s.rng, mcs := s.mcs, made := s.mcsMade, zero := z }

/-- What right-hand-side functions see of the agent: an identifier's slots and values in
Soar's order (slots and elements most recent first), the decision count, and the string
constants in use — those of the source file, of working memory and those
`make-constant-symbol` has made (an approximation of Soar's symbol table, which also holds
constants no longer referenced until they are freed). -/
def St.rhsCtx (s : St) : RhsCtx :=
  { slots := fun n =>
      let mine := s.wm.filter (fun w => w.id == n && !w.acc)
      let attrs := ((s.slotSeq.filter (·.1 == n)).map (·.2)).reverse
      let attrs := attrs ++ (mine.map (·.attr)).eraseDups.filter (!attrs.contains ·)
      attrs.filterMap fun a =>
        let vs := ((mine.filter (·.attr == a)).toArray.qsort (fun x y => s.ttOf x > s.ttOf y)).toList.map (·.val)
        if vs.isEmpty then none else some (a, vs)
    dc := s.dc
    known := fun t => s.symRank.contains (.str t) || s.wm.any (fun w => w.attr == .str t || w.val == .str t)
    lti := s.ltiOf? }

/-- Fire a match: its effects (with `deep-copy` expanded) and the next free identifier. -/
def St.instantiateM (s : St) (m : Match) (next : Nat) : Effects × Nat :=
  let (p, b, n₀, _, _, _) := s.deepCopy m.prod m.b next
  instantiate p b n₀ s.isGoal s.rstate s.rhsCtx

/-- The explanation record of a match fired with new identifiers from `next`. -/
def St.xRecord (s : St) (m : Match) (next : Nat) (key : String) : XInst :=
  let cs := s.condOrder m.prod
  let (p, b, n₀, dcs, js, _) := s.deepCopy m.prod m.b next
  let ub := unboundOf p b
  let (eff, _) := instantiate p b n₀ s.isGoal s.rstate s.rhsCtx
  let (orig, depth) := match s.chunkMeta.find? (·.1 == m.prod.name) with
    | some (_, o, d) => (o, d)
    | none => (m.prod.name, 0)
  let sp := s.soarPairs m.prod m.b m.ws
  { key := key, prod := p, orig := orig, depth := depth, level := m.level,
    goal := (s.deepestGoal m.ws).getD 0, conds := sp ++ dcs,
    negs := cs.filter (fun c => match c with | .pos _ => false | _ => true),
    b := (ub.zip (List.range' n₀ ub.length)).map (fun (v, n) => (v, Sym.id n)) ++ b,
    made := eff.adds, prefs := eff.prefs, fresh := ub, rems := eff.rems,
    osk := s.oskCopy m.level sp,
    traces := (sp ++ dcs).map (s.traceOf ·.2), joins := js }

/-- The architecture's instantiation for a substate's `^item` element: it tested the
acceptable preference in the superstate (Soar 9.6.5,
`make_architectural_instantiation_for_impasse_item`). -/
def St.itemCreator (s : St) (w : WME) : Option XInst :=
  if w.attr != .str "item" then none else
  match s.goals.find? (·.id == w.id), w.val with
  | some g, .id o =>
    match s.goals.find? (fun g' => g'.level + 1 == g.level) with
    | some sup =>
      let p1 : Pat := { id := [.var "ss"], attr := [.const (.str "operator")], val := [.var "o"], acc := true }
      let p2 : Pat := { id := [.var "g"], attr := [.const (.str "superstate")], val := [.var "ss"] }
      some { key := s!"it{g.id}_{o}", prod := { name := "item", conds := [.pos p1, .pos p2], acts := [.make "g" (.sym (.str "item")) (.var "o")] },
             orig := "item", level := g.level, goal := g.id,
             conds := [(p1, { id := sup.id, attr := .str "operator", val := .id o, acc := true }),
                       (p2, { id := g.id, attr := .str "superstate", val := .id sup.id })],
             b := [("ss", .id sup.id), ("o", .id o), ("g", .id g.id)], made := [w] }
    | none => none
  | _, _ => none

/-- The instantiation that made an element: the instantiation whose preference supports it, else
the newest record that made it. -/
def St.creatorOf (s : St) (w : WME) : Option XInst :=
  let live := (s.traceOf w).bind fun k => s.xinsts.find? (·.key == k)
  match live with
  | some x => some x
  | none =>
    let w' := if isOpAttr w.attr && !w.acc && s.isGoal w.id then { w with acc := true } else w
    match (s.traceOf w').bind (fun k => s.xinsts.find? (·.key == k)) with
    | some x => some x
    | none => match s.xinsts.find? (fun (x : XInst) => x.made.contains w') with
      | some x => some x
      | none => s.itemCreator w

/-- The operator selection knowledge of selecting `o` for state `g` (Soar 9.6.5
`run_preference_semantics` with `add-osk`; not kept for the top state, nor without
learning). -/
def St.oskEntry (s : St) (g : Goal) (o : Sym) : List (Nat × List String × String) :=
  if !(s.learning && s.chunkCfg.addOsk && g.level > 1) then [] else
  let keys := ((oskSelect (s.prefObjs g.id) o).map (·.2)).eraseDups
  let win := (s.traceOf { id := g.id, attr := .str "operator", val := o, acc := true }).getD ""
  [(g.id, keys, win)]

/-- The record of an instantiation that made a preference now in preference memory. -/
def St.prefCreator (s : St) (p : Pref) : Option XInst :=
  let cands := s.prefs.filter fun q => q.toPref == p && isOpAttr q.attr &&
    ((s.instById q.inst).map (·.uid != "")).getD false
  match firstPref cands with
  | some q => (s.instById q.inst).bind fun i => s.xinsts.find? (·.key == i.uid)
  | none => none

/-- What learning needs, with goal levels taken before the elaboration cycle's changes. -/
def St.lenv (s : St) : LEnv :=
  { lvl := s.idLevel
    isGoal := s.isGoal
    creator := s.creatorOf
    autoSingletons := s.chunkCfg.autoSingletons
    singletons := s.chunkCfg.singletons
    isOp := fun n => s.wm.any (fun w => isOpAttr w.attr && w.acc && w.val == .id n && s.isGoal w.id)
    goals := s.goals.map (·.id)
    byKey := fun k => s.xinsts.find? (·.key == k)
    propOsk := fun k => (s.osk.filter (fun e => e.2.2 == k)).flatMap (·.2.1)
    lti := s.ltiOf?
    addLtmLinks := s.chunkCfg.addLtmLinks }

/-- The impasse of the superstate of the state at level `L`. -/
def St.superImpasse (s : St) (L : Nat) : Option Impasse :=
  match s.goals.find? (fun g => g.level + 1 == L) with
  | some g => g.impasse.map (·.1)
  | none => none

/-- Withdraw the preferences for results `rw rp rr` that are not yet asserted, made by the
instantiations recorded as `grp`: a duplicate rule was learned. Soar 9.6.5 deallocates the
duplicate's instantiation with its clones of the result preferences, and with them every
preference in their clone lists that nothing refers to yet — the result preferences of the
instantiation that made the results and, in bottom-up learning, the clones of the rules learned
below it, none yet asserted (`remove_chunk_instantiation`,
`possibly_deallocate_preference_and_clones`); preferences already in preference memory stay.
Observed 2026-10-29, `ChunkingTests_BUNCPS_0`. -/
def St.dropFresh (s : St) (grp : List String) (rw : List WME) (rp : List Pref) (rr : List WME) : St :=
  let ids := (s.insts.filter (fun i => i.uid != "" && grp.contains i.uid)).map (·.iid)
  let f (p : PRec) : Bool := ids.contains p.inst && (
      rw.any (fun w => w.id == p.id && w.attr == p.attr && w.val == p.val && p.kind == .acceptable) ||
      (isOpAttr p.attr && rp.contains p.toPref) ||
      rr.any (fun w => p.kind == .reject && w.id == p.id && w.attr == p.attr && w.val == p.val))
  { s with fresh := s.fresh.filter (fun p => !f p) }

/-- The results among `rw rp rr` for a state above level `lvl` (Soar 9.6.5
`get_results_for_instantiation`): those on an identifier above `lvl`, and with them, through
`add_results_if_needed`, the elements of identifiers at `lvl` or below that are reached from
their values. -/
def St.resultsAbove (s : St) (lvl : Nat) (rw : List WME) (rp : List Pref) (rr : List WME) :
    List WME × List Pref × List WME :=
  let direct := rw.filter (fun w => s.idLevel w.id < lvl)
  let vals (ws : List WME) : List Nat := ws.filterMap (fun w => match w.val with | .id n => some n | _ => none)
  let start := (vals direct ++ (rp.filter (fun p => s.idLevel p.state < lvl)).filterMap
    (fun p => match p.op with | .id n => some n | _ => none)).filter (fun n => s.idLevel n ≥ lvl)
  let rec close : Nat → List Nat → List Nat → List Nat
    | 0, ids, _ => ids
    | _ + 1, ids, [] => ids
    | k + 1, ids, x :: rest =>
      let nx := ((rw.filter (·.id == x)).filterMap (fun w => match w.val with
        | .id n => if s.idLevel n ≥ lvl && !ids.contains n then some n else none
        | _ => none)).eraseDups
      close k (ids ++ nx) (rest ++ nx)
  let ids := close (rw.length + 1) start.eraseDups start.eraseDups
  (rw.filter (fun w => s.idLevel w.id < lvl || ids.contains w.id),
   rp.filter (fun p => s.idLevel p.state < lvl || ids.contains p.state),
   rr.filter (fun w => s.idLevel w.id < lvl))

/-- Learn from the results `rw rp rr` of the instantiation recorded as `x`, then (bottom-up
chunking) from the new rule's instantiation if some results belong to a still higher state.
Falls back to a justification as without learning when no rule can be formed. -/
partial def St.learnFrom (s pre : St) (x : XInst) (rw : List WME) (rp : List Pref) (rr : List WME)
    (fuel : Nat) (grp : List String := [x.key]) : St :=
  let E := s.lenv
  let gl := x.level - 1
  -- results made by `x` are traced from `x`, others from the instantiation that made them
  -- an element that goes with a result is traced from a preference for it made at the
  -- results' level (Soar's `add_pref_to_results`)
  let rideCreator (w : WME) : Option XInst :=
    ((s.traceOf w (some x.level)).bind fun k => s.xinsts.find? (·.key == k)) <|> s.creatorOf w
  let rs : Results := { wmes := rw.map (fun w => (w, if x.made.contains w then x else (rideCreator w).getD x)),
                        prefs := rp.map (fun p => (p, if x.prefs.contains p then x else (s.prefCreator p).getD x)),
                        rems := rr.map (·, x) }
  -- rule repair (Soar 9.6.5 `reorder_and_validate_chunk`), for rules only
  let sS := s.slotSet
  let R : REnv := { prefWmes := fun n => s.wm.filter (fun w => w.id == n && sS.contains w)
                    superW := fun n => s.arch.find? (fun w => w.id == n && w.attr == .str "superstate")
                    lvl := E.lvl, goals := s.goals.map (fun g => (g.id, g.level)), matchLevel := gl,
                    rhsNew := fun n => (x :: rs.wmes.map (·.2) ++ rs.prefs.map (·.2)).any fun y =>
                      let cv := y.prod.conds.flatMap condVars
                      y.b.any fun (v, val) => val == .id n && !cv.contains v }
  let learned := (E.learn gl rs).map fun ln =>
    if s.learnsIn x.goal then match ln.repair R with
      | some ln' => (ln', true)
      | none => (ln, false)
    else (ln, true)
  match learned with
  | none =>
    -- no conditions: a justification as without learning
    s.justifyResults x.level { name := x.prod.name, ws := x.conds.map (·.2), level := x.level, made := rw, prefs := rp, rems := rr } rw rp rr []
  | some (ln, valid) =>
    let cnt := if s.chunkCount.1 == s.dc then s.chunkCount.2 else 0
    let dupN := ((s.dupes.find? (fun d => d.1 == x.prod.name && d.2.1 == s.dc)).map (·.2.2)).getD 0
    let bottomOk := !(s.chunkCfg.bottomOnly && s.noBottomUp.contains x.goal)
    let canChunk := valid && bottomOk && s.learnsIn x.goal && !ln.quiescence && cnt < s.chunkCfg.maxChunks && dupN < s.chunkCfg.maxDupes
    let name := chunkName x.orig x.depth (s.superImpasse x.level) s.dc (cnt + 1)
    let prod : Production := { name := name, conds := ln.conds, acts := ln.acts }
    -- Soar finds a duplicate when the rule, as its reorderer orders it, is already in the Rete
    -- (`add_production_to_rete` returns DUPLICATE_PRODUCTION): rules are compared in Soar's
    -- stored form and condition order, structurally, up to the names of their variables
    let key (p : Production) : List Cond × List Action :=
      let q := ({ storedRule s.rank s.multi p with name := "" } : Production).canonVars
      (q.conds, q.acts)
    let pk := key prod
    let dup := s.chunks.any (fun c => key c == pk)
    let ws := dedupW (ln.pairs.map (·.2))
    let key := s!"x{s.xNext}c{s.nextId}"
    -- results returned from here (by a rule or a justification) stop learning in the states
    -- above (bottom-only; Soar 9.6.5 `learn_rule_from_instance`)
    let s : St := { s with noBottomUp := s.noBottomUp ++ (s.goals.filter (fun (g : Goal) => g.level < x.level)).map (·.id) }
    -- the preferences of the instantiations that made the results stay; the new
    -- instantiation's preferences for them come first in their slots (a higher state)
    let mkX (p : Production) (lvl : Nat) (conds : List (Pat × WME)) (b : Binding) : XInst :=
      { key := key, prod := p, orig := x.orig, depth := x.depth + 1, level := lvl,
        goal := (s.deepestGoal (conds.map (·.2))).getD 0, conds := conds,
        negs := p.conds.filter (fun c => match c with | .pos _ => false | _ => true),
        b := b, made := rw, prefs := rp, quiescence := ln.quiescence, osk := s.oskCopy lvl conds }
    let (s, lvl, xn) :=
      if canChunk && !dup then
        let s := { s with chunks := s.chunks ++ [prod], chunkMeta := (name, x.orig, x.depth + 1) :: s.chunkMeta,
                          chunkCount := (s.dc, cnt + 1) }
        match (pre.matchesWithin prod ws).head? with
        | some m =>
          let cs := s.condOrder prod
          let ub := (prod.acts.flatMap actionVars).eraseDups.filter (fun v => (m.b.get v).isNone)
          let b := m.b ++ ln.syms.filter (fun (v, _) => ub.contains v)
          -- Soar 9.6.5's reorderer, when it moves a relational test to the condition of its
          -- referent and reverses it, does not update the test's identity in the rule's own
          -- instantiation (`restore_saved_tests_to_test` sets `inst_identity` but not
          -- `chunk_inst_identity`): in that instantiation the reversed test compares the
          -- condition's value with itself, and learning from it removes the test as
          -- contradictory (`remove_contradictory_tests_from_chunk`). Those tests are left out
          -- of the record. (Found 2026-10-30 with a debug build of 9.6.5.)
          let placed : List (String × RelOp × String) := prod.conds.flatMap fun c => match c with
            | .pos p => [p.id, p.attr, p.val].flatMap fun t => match eqVarOf t with
              | some e => t.filterMap fun st => match st with
                | .rel r (.var v) => some (e, r, v)
                | _ => none
              | none => []
            | _ => []
          let keep (t : Test) : Test := match eqVarOf t with
            | some e => t.filter fun st => match st with
              | .rel r (.var v) => placed.contains (e, r, v)
              | _ => true
            | none => t
          let xn := mkX prod m.level ((s.soarPairs prod m.b m.ws).map fun (p, w) =>
            ({ p with id := keep p.id, attr := keep p.attr, val := keep p.val }, w)) b
          let s := s.supportResults { name := name, ws := m.ws, tts := m.tts, level := m.level, goal := s.goalOfWs m.ws, osup := m.osup,
                                      kind := .chunk, made := rw, prefs := rp, rems := rr, uid := key } rw rp rr
          (s, m.level, xn)
        | none =>
          -- the learned rule does not match: its results are supported like a justification
          let lvl := s.instLevel ws
          (s.supportResults { name := name, ws := ws, level := lvl, goal := s.goalOfWs ws, osup := s.oSupported prod ln.syms ws,
                              made := rw, prefs := rp, rems := rr,
                              kind := .justification, uid := key } rw rp rr,
           lvl, mkX prod lvl ln.pairs ln.syms)
      else if canChunk && dup then
        -- a duplicate of a rule already learned: the results are not kept (Soar 9.6.5 asserts
        -- no preferences for them; the existing rule then fires in the superstate; checked
        -- 2026-10-29)
        let s : St := { s with dupes := (x.prod.name, s.dc, dupN + 1) :: s.dupes.filter (fun d => !(d.1 == x.prod.name && d.2.1 == s.dc)),
                               chunkCount := (s.dc, cnt + 1) }
        (s.dropFresh grp rw rp rr, 0, x)
      else
        let lvl := s.instLevel ws
        let jp : Production := { prod with name := s!"justification-{s.iNext}" }
        let os := s.oSupported jp ln.syms ws
        (s.supportResults { name := jp.name, ws := ws, level := lvl, goal := s.goalOfWs ws, osup := os, made := rw, prefs := rp,
                            rems := rr, kind := .justification, uid := key } rw rp rr,
         lvl, mkX jp lvl ln.pairs ln.syms)
    if lvl == 0 then s else
    let s := { s with xinsts := xn :: s.xinsts, nextId := s.nextId + 1 }
    -- bottom-up: results that belong to a state above the new instantiation's
    let (rw', rp', rr') := s.resultsAbove lvl rw rp rr
    if lvl ≥ 2 && fuel > 0 && !(rw'.isEmpty && rp'.isEmpty && rr'.isEmpty) then
      s.learnFrom pre xn rw' rp' rr' (fuel - 1) (grp ++ [xn.key])
    else s

/-- Results with learning on: each new instantiation's results, as in `makeResults`, learned
from. -/
partial def St.learnDelta (s pre : St) (L : Nat) (newInsts : List Inst) : St :=
  let fromI := newInsts.filterMap fun i =>
    let rs := s.resultSet L (s.prefs.filter (·.inst == i.iid))
    if rs.isEmpty then none
    else
      let (rw, rp, rr) := s.resultParts rs
      let more := ((rs.filter (·.inst != i.iid)).filterMap (fun p => s.instById p.inst)).flatMap (·.ws)
      some (i, rw, rp, rr, more)
  fromI.foldl (fun (s : St) (i, rw, rp, rr, more) =>
    match s.xinsts.find? (·.key == i.uid) with
    -- one rule per state the results pass on their way up (each learning step is one level)
    | some x => s.learnFrom pre x rw rp rr s.goals.length
    | none => s.justifyResults L { i with made := rw, prefs := rp, rems := rr } rw rp rr more) s

/-- The fields learning changes: the procedural module's records only. Learning does not
change working memory's architecture elements or the goal stack. -/
structure LDelta where
  insts : List Inst
  fresh : List PRec
  pNext : Nat
  iNext : Nat
  chunks : List Production
  chunkMeta : List (String × String × Nat)
  xinsts : List XInst
  nextId : Nat
  chunkCount : Nat × Nat
  dupes : List (String × Nat × Nat)
  noBottomUp : List Nat

def St.toDelta (s : St) : LDelta :=
  { insts := s.insts, fresh := s.fresh, pNext := s.pNext,
    iNext := s.iNext, chunks := s.chunks, chunkMeta := s.chunkMeta, xinsts := s.xinsts, nextId := s.nextId,
    chunkCount := s.chunkCount, dupes := s.dupes, noBottomUp := s.noBottomUp }

def St.withLearn (s : St) (d : LDelta) : St :=
  { s with insts := d.insts, fresh := d.fresh, pNext := d.pNext,
           iNext := d.iNext, chunks := d.chunks, chunkMeta := d.chunkMeta, xinsts := d.xinsts, nextId := d.nextId,
           chunkCount := d.chunkCount, dupes := d.dupes, noBottomUp := d.noBottomUp }

def St.learnResults (s pre : St) (L : Nat) (newInsts : List Inst) : St :=
  let r := s.withLearn (s.learnDelta pre L newInsts).toDelta
  -- a rule learned (or a justification made) with learning on clears the variables given to
  -- identifiers (`clean_up`: `clear_sti_variablization_map`)
  if r.iNext != s.iNext then { r with tmplVars := {} } else r

/-- Results of firings at level `L` ([Man] §2.7.3): with learning on, rules are learned
([Man] chapter 4); otherwise justifications. -/
def St.results (s pre : St) (L : Nat) (newInsts : List Inst) : St :=
  if L ≥ 2 then
    if s.learning then s.learnResults pre L newInsts
    else s.makeResults L newInsts
  else s

/-- What an instantiation's results are formed from (Soar 9.6.5: `learn_rule_from_instance` is
called from `create_instantiation`, before any preference of the pass is asserted): working
memory as it was before the elaboration cycle, preference memory as asserted so far, and the
instantiation's own preferences (`m_extra_results`). `St.resultSet` walks them as preferences;
the elements they make count as present for the learning computation's records. -/
def St.viewWith (s : St) (ps : List PRec) : St :=
  let sS := s.slotSet
  let own := ({ s with prefs := ps }).desired.filter (fun e => !sS.contains e.w)
  { s with prefs := s.prefs ++ ps, slots := s.slots ++ own }

/-- Form the results of a new instantiation `i` at level `L` with its preferences `ps`
(`St.results` on `St.viewWith`). Only the procedural module's records change: the
instantiations, explanation records, learned rules, and the preferences awaiting assertion. -/
def St.resultsOf (s pre : St) (L : Nat) (i : Inst) (ps : List PRec) : St :=
  let r := (s.viewWith ps).results pre L [i]
  { r with prefs := s.prefs, slots := s.slots }

/-- A `(cmd …)` action. Only `epmem --set trigger|force|graph-match …` is acted on (the tokenizer
drops the dashes of `--set`). -/
def St.runEpCmd (s : St) (ws : List String) : St :=
  match ws with
  | "set" :: "trigger" :: v :: _ | "--set" :: "trigger" :: v :: _ =>
    { s with ep := { s.ep with trigger := if v == "output" then .output else if v == "none" then .none else .dc } }
  | "set" :: "force" :: v :: _ | "--set" :: "force" :: v :: _ =>
    { s with ep := { s.ep with force := if v == "remember" then some true else if v == "ignore" then some false else none } }
  | "set" :: "graph-match" :: v :: _ | "--set" :: "graph-match" :: v :: _ =>
    { s with ep := { s.ep with graphMatch := v == "on" } }
  | _ => s

def St.runCmdLine (s : St) (ws : List String) : St :=
  match ws.filter (· != "") with
  | "interrupt" :: _ => { s with stopped := true }
  | "force-learn" :: n :: _ => { s with forceLearn := (n.drop 1).toNat! :: s.forceLearn }
  | "dont-learn" :: n :: _ => { s with dontLearn := (n.drop 1).toNat! :: s.dontLearn }
  | "epmem" :: r => s.runEpCmd r
  | _ => s

/-! ## The elaboration cycle ([Man] §2.5, §2.7.8; Soar 9.6.5 `do_preference_phase`) -/

/-- Record firings (like Soar's `watch 3`). -/
def St.logFirings (s : St) (ft : Firing) (L : Nat) (ms : List Match) : St :=
  let fl : List String := [s!"{s.dc} L{L} {if ft == .ie then "IE" else "PE"}"] ++
    ms.map (fun m => s!"  Firing {m.prod.name}{if m.osup then " :O" else ""}")
  if s.verbose then { s with firings := s.firings ++ fl } else s

/-- The `(cmd …)` actions of firing matches: episodic-memory settings, `interrupt`,
`force-learn`, `dont-learn`. -/
def St.runCmds (s : St) (ms : List Match) : St :=
  (ms.flatMap fun m => m.prod.acts.filterMap fun
      | .cmd ws => some (ws.map fun w =>
          -- a variable argument (of `force-learn`, `dont-learn`) is replaced by its value
          if w.startsWith "<" && w.endsWith ">" then match m.b.get ((w.drop 1).dropEnd 1).toString with
            | some (.id n) => s!"#{n}"
            | _ => w
          else w)
      | _ => none).foldl St.runCmdLine s

def St.bumpX (record : Bool) (s : St) : St := if record then { s with xNext := s.xNext + 1 } else s

/-- Make the instantiation of one match (Soar 9.6.5 `create_instantiation`): its explanation
record when learning, and its preferences, held with the pass's other new preferences until they
are asserted. `j` is its position in the pass. -/
def St.newInst (s : St) (record : Bool) (tag : String) (L j : Nat) (m : Match) : St × Inst × List PRec :=
  -- a template's actions are not executed: it makes a rule instead (`St.addTemplateRule`)
  let (eff, n') := if m.prod.template then (({ rs := s.rstate } : Effects), s.nextId) else s.instantiateM m s.nextId
  let iid := s.iNext
  let key := if record then s!"x{s.xNext}{tag}{j}" else ""
  let xs := if record then [s.xRecord m s.nextId key] else []
  let goal := s.goalOfWs m.ws
  let myPs := (effPrefs eff s.pNext iid L goal m.osup).map ({ · with pass := s.passNo })
  -- an RL rule's preference carries the rule's learned value
  let myPs := match s.rlRefValue m.prod.name with
    | some v => if s.isRLRule m.prod.name then myPs.map fun p =>
        if p.kind == .numericIndiff then { p with num := some (Sym.ofFloat v) } else p else myPs
    | none => myPs
  let inst : Inst := { iid := iid, name := m.prod.name, ws := m.ws, tts := m.tts, level := L, goal := goal, osup := m.osup,
                       made := eff.adds, prefs := eff.prefs, rems := eff.rems, uid := key,
                       rkey := if s.reteOn then (s.reteKey s.ttMap m).2 else [] }
  ({ s with nextId := n', iNext := iid + 1, pNext := s.pNext + myPs.length,
            insts := s.insts ++ [inst], xinsts := xs ++ s.xinsts, fresh := s.fresh ++ myPs,
            lv := (List.range (n' - s.nextId)).foldl (fun m k => m.insert (s.nextId + k) L) s.lv,
            -- `(link-stm-to-ltm <x> n)` links `<x>` to n, if n exists (Soar 9.6.5
            -- `set_lti_id_rhs_function_code`)
            ltiOf := eff.links.foldl (fun (lo : List (Nat × Nat)) (n, k) =>
              if s.smem.ltis.contains k then (alPut lo n k) else lo) s.ltiOf,
            halted := s.halted || eff.halt, out := s.out ++ eff.out, rng := eff.rs.rng, mcs := eff.rs.mcs, mcsMade := eff.rs.made, zeroSym := eff.rs.zero,
            dcLevels := s.dcLevels ++ (s.deepCopy m.prod m.b s.nextId).2.2.2.2.2 },
   inst, myPs)

/-- A template's match makes a new RL rule, named `rl*<template>*N` with the next free number,
unless it would duplicate a rule already loaded or made (Soar 9.6.5 then excises it and takes the
number back). The new rule starts with expected current reward 0 and its value as expected
future reward. -/
def St.templNum (s : St) (tmpl : String) : Nat := Id.run do
  let names := s.rlKnownNames ++ s.rlGen.map (·.name)
  let mut k := s.rlTemplCount
  for _ in [0:100000] do
    if names.contains s!"rl*{tmpl}*{k}" then k := k + 1 else break
  return k

/-- The letter Soar names an identifier with (`name_letter`): `s` for a state, `o` for an
operator, otherwise the first letter of the attribute of the element that holds it (the
attribute of the action that made it), `i` if there is none.
SIMPLIFIED: the attribute of the oldest element now holding the identifier. -/
def St.idLetter (s : St) (n : Nat) : Char :=
  if s.isGoal n then 's' else
  match (s.tt.filter (fun (w, _) => w.val == .id n)).mergeSort (fun a b => a.2 ≤ b.2) with
  | (w, _) :: _ => match w.attr with
    | .str a => match a.toList with
      | c :: _ => if c.isAlpha then c.toLower else 'v'
      | [] => 'v'
    | .int _ => 'i' | .float _ => 'f' | _ => 'v'
  | [] => 'i'

/-- The variables of a template's rule (Soar 9.6.5 `variablize_rl_condition_list`,
`sti_variablize_test`, `generate_new_variable`): each identifier, in the order of the
template's conditions (Soar's order) and then its action, keeps the variable it was given by
an earlier template's rule; otherwise it gets the next variable for its letter (`c` for an
identifier named `s` that is not a state, or `o` that is not an operator), counting from 1 for
each rule. Soar does not clear the identifiers' variables between templates' rules (kernel
defect 28), so a new identifier can get the same variable as one met before, and the rule then
tests the two as one. -/
def St.templateVars (s : St) (m : Match) : (Nat → String) × Std.HashMap Nat String :=
  let isOp (n : Nat) : Bool := s.tt.any fun (w, _) => isOpAttr w.attr && w.val == .id n
  let idsT (t : Test) : List Nat := t.filterMap fun st => match st with
    | .var v => match m.b.get v with | some (.id n) => some n | _ => none
    | .rel _ (.var v) => match m.b.get v with | some (.id n) => some n | _ => none
    | _ => none
  let idsP (q : Pat) : List Nat := idsT q.id ++ idsT q.attr ++ idsT q.val
  let idsC (c : Cond) : List Nat := c.pats.flatMap idsP
  let rv (r : RVal) : List Nat := match r with
    | .var v => match m.b.get v with | some (.id n) => [n] | _ => []
    | _ => []
  let actIds : List Nat := m.prod.acts.flatMap fun a => match a with
    | .pref sv o _ r _ => rv (.var sv) ++ rv o ++ (r.map rv).getD []
    | _ => []
  let order := ((s.reteOrderOf m.prod).flatMap (fun (_, c) => idsC c) ++ actIds).eraseDups
  let (mp, _, _) := order.foldl (fun (acc : Std.HashMap Nat String × Std.HashMap Char Nat × List String) n =>
    let (mp, cnt, made) := acc
    if mp.contains n then acc else
    let l0 := s.idLetter n
    let l := if (l0 == 's' && !s.isGoal n) || (l0 == 'o' && !isOp n) then 'c' else l0
    -- the next name for the letter not made for this rule
    let rec next (fuel k : Nat) : Nat := match fuel with
      | 0 => k
      | f + 1 => if made.contains s!"{l}{k}" then next f (k + 1) else k
    let k := next 1000 (cnt.getD l 1)
    let v := s!"{l}{k}"
    (mp.insert n v, cnt.insert l (k + 1), v :: made)) (s.tmplVars, {}, [])
  (fun n => mp.getD n s!"t{n}", mp)

def St.addTemplateRule (s : St) (m : Match) : St :=
  let k := s.templNum m.prod.name
  let name := s!"rl*{m.prod.name}*{k}"
  let (idVar, tv) := s.templateVars m
  match m.prod.fromTemplate m.b name idVar with
  | none => s
  | some (r, v) =>
    let s := { s with tmplVars := tv }
    if (s.rlKnownKeys ++ s.rlGen.map Production.dupKey).contains r.dupKey then { s with rlTemplCount := k }
    else { s with rlGen := s.rlGen ++ [r], rlTemplCount := k + 1, rlTab := alPut s.rlTab name ({ (s.rlEntry name).getD {} with init := some v }) }

/-- Fire one match (one step of `St.fireLevel`): make its instantiation, then form its results
at once — justifications, or with learning on, learned rules — as Soar 9.6.5's
`create_instantiation` does, before the pass's preferences are asserted. -/
def St.fireOneBase (pre : St) (record : Bool) (tag : String) (L : Nat) (acc : St × Nat) (m : Match) : St × Nat :=
  let r := acc.1.newInst record tag L acc.2 m
  let r := if m.prod.template then (r.1.addTemplateRule m, r.2) else r
  (r.1.resultsOf pre L r.2.1 r.2.2, acc.2 + 1)

/-- Fire one match (one step of `St.fireLevel`): make its instantiation, then form its results
at once — justifications, or with learning on, learned rules — as Soar 9.6.5's
`create_instantiation` does, before the pass's preferences are asserted. A rule a template
makes is added to the Rete at once, and its matches join the assertion list in front, so they
fire next, in the same elaboration cycle (Soar 9.6.5 `rl_build_template_instantiation`,
`add_production_to_rete`, `postpone_assertion`). The rules a template makes are not templates
(`Production.fromTemplate` leaves the flag off), so their matches fire as `fireOneBase`
fires any match. -/
def St.fireOne (pre : St) (record : Bool) (tag : String) (L : Nat) (acc : St × Nat) (m : Match) : St × Nat :=
  let res := St.fireOneBase pre record tag L acc m
  if !m.prod.template || res.1.rlGen.length == acc.1.rlGen.length then res else
  match res.1.rlGen.getLast? with
  | none => res
  | some rule =>
    let now := (res.1.matches [rule]).filter (fun x => x.level == L && x.osup == (tag == "o"))
    let s1 : St := if res.1.verbose then
        { res.1 with firings := res.1.firings ++ now.map (fun x => s!"  Firing {x.prod.name}{if x.osup then " :O" else ""}") }
      else res.1
    now.foldl (St.fireOneBase pre record tag L) (s1, res.2)

/-- Assert the preferences held for the pass (Soar 9.6.5 `assert_new_preferences`). -/
def St.assertFresh (s : St) : St :=
  -- Soar adds them newest instantiation first, each one's preferences last made first
  let n := s.fresh.length
  let ps := s.fresh.enum.map fun (k, p) => { p with aseq := s.aNext + (n - 1 - k) }
  -- with the Rete's order the instantiations' order is Soar's: of two o-supported top-level
  -- acceptable preferences of this pass for one value, the one Soar keeps is the one it adds
  -- first, the later one here
  let dupKey (p : PRec) : Bool := p.level == 1 && p.osup && p.kind == .acceptable && !s.isCtx p.id p.attr
  let ps := if s.reteOn && !s.keepTopOprefs then
      (ps.enum.filter (fun (k, p) => !(dupKey p && (ps.drop (k + 1)).any (fun q => dupKey q && q.id == p.id && q.attr == p.attr && q.val == p.val)))).map (·.2)
    else ps
  let s := ({ s with fresh := [], passNo := s.passNo + 1, aNext := s.aNext + n } : St).assertPrefs ps false
  (ps.reverse.filter (fun p => !(p.kind == .reject && p.osup))).foldl (fun s p => s.markSlot p.id p.attr p.kind) s

/-- Fire matches at goal level `L`, one pass of the inner elaboration loop (Soar 9.6.5
`do_preference_phase`): make their instantiations in turn, forming each one's results as it is
made ([Man] §2.7.3, chapter 4); then assert the pass's preferences, o-supported reject
preferences first. Working memory does not change until the working-memory phase. -/
def St.fireLevel (s pre : St) (ft : Firing) (L : Nat) (ms : List Match) : St :=
  if ms.isEmpty then s else
  let record := s.learning && L ≥ 2
  let tag := if ft == .ie then "i" else "o"
  let s := (s.logFirings ft L ms).runCmds ms
  ((ms.foldl (St.fireOne pre record tag L) (s, 0)).1.assertFresh).bumpX record

/-- Retract instantiations that no longer match (Soar 9.6.5 `retract_instantiation`): their
i-supported preferences leave preference memory; o-supported ones stay. -/
def St.retract (s : St) (is : List Inst) : St :=
  if is.isEmpty then s else
  let ids := is.map (·.iid)
  let s := if s.verbose then { s with firings := s.firings ++ is.map (fun i => s!"  Retracting {i.name}") } else s
  -- the slots are marked as Soar retracts: instantiations in turn, each one's preferences last
  -- made first
  let s := is.foldl (fun (s : St) i => ((s.prefs.filter (fun p => p.inst == i.iid && !p.osup)).reverse).foldl
    (fun (s : St) p => s.markSlot p.id p.attr p.kind) s) s
  let s := s.dropPrefs (fun p => ids.contains p.inst && !p.osup) false
  { s with insts := s.insts.filterMap fun i =>
      if !ids.contains i.iid then some i
      -- kept for backtracing while its state exists, or while its preferences remain
      else if i.level ≥ 2 || s.prefs.any (·.inst == i.iid) then some { i with inMs := false }
      else none }


/-- Does a match's every action change only states below level `change`? (Soar 9.6.5
`shouldCreateInstantiation`: an action whose identifier is bound to an identifier at or above
the level that changed blocks the firing; new identifiers do not.) -/
def waterfallOk (lvl : Nat → Nat) (change : Nat) (m : Match) : Bool :=
  m.prod.acts.all fun a =>
    let v : Option String := match a with
      | .make i _ _ => some i
      | .remove i _ _ => some i
      | .pref i _ _ _ _ => some i
      | _ => none
    match v with
    | none => true
    | some v => match m.b.get v with
      | some (.id n) => lvl n > change
      | _ => true

/-- Replace working-memory activation's state (it is not an architecture structure). -/
def St.setWma (s : St) (x : WmaSt) : St := { s with wmaS := x }

/-- Spreading activation's working-memory hooks, after a set of working-memory changes: the
sources entering and leaving (`SMemDB.spSync`), and the edge updates recorded by
working-memory activation passed to semantic memory. -/
def St.spSync (s : St) : St :=
  if !s.smem.spreading then s else
  let tm := s.ttMap
  let now := s.wm.map fun w => (tm.getD w 0, w.id)
  let db := s.smem.spSync now fun i => (s.ltiOf? i).getD 0
  let sp := s.wmaS.edgeLog.foldl (fun (sp : Spread) (p, ch, n, t) =>
    let eu := match sp.edgeUpd.find? (·.1 == p) with
      | some (_, us) => sp.edgeUpd.map fun (k, v) => if k == p then (k, us ++ [(ch, n, t)]) else (k, v)
      | none => sp.edgeUpd ++ [(p, [(ch, n, t)])]
    { sp with edgeUpd := eu, invalid := if sp.invalid.contains p then sp.invalid else sp.invalid ++ [p] }) db.spread
  { s with smem := { db with spread := sp }, wmaS := { s.wmaS with edgeLog := [] } }

/-- With `spreading-wma-source`, a source's working-memory activation (`calc_spread`): over the
decay elements of elements of the source's identifier, most recently made first, the sum of
each consolidated history entry's references times its age to the decay rate, entries taken
by their position in Soar's ring buffer, last to first. `none` when there is no such element. -/
def St.spPre (s : St) (src : Nat) : Option Float :=
  if !s.smem.spWmaSource || !s.wma.on then none else
  let els := ((s.wmaS.els.toList.filter (·.2.lti == src)).toArray.qsort (fun a b => a.2.born > b.2.born)).toList
  if els.isEmpty then none else
  some (els.foldl (fun acc (_, e) =>
    let ct := e.hist.length
    let byIdx := (e.hist.enum.map fun (j, h) => ((e.recs + 10 * 10 - 1 - j) % 10, h))
    let byIdx := (byIdx.toArray.qsort (fun a b => a.1 > b.1)).toList
    let _ := ct
    byIdx.foldl (fun acc (_, (dc, n)) =>
      acc + n.toFloat * Float.pow (s.wmaS.cycle - dc).toFloat s.wma.decay) acc) 0)

/-! ## Working-memory activation ([Man] §9.3.2.1)

The functions below compute the new activation state from a state they only read, so they
change nothing else: `St.wmaS` is the only field they set. -/

/-- The preference supporting an element (Soar's `w->preference`): its slot's supporting
preference or, for a state's selected operator, the preference that won. -/
def St.wmaSupport (s : St) (w : WME) : Option PRec :=
  let pid := match s.slots.find? (·.w == w) with
    | some e => some e.pref
    | none => if isOpAttr w.attr && !w.acc then (s.opPref.find? (fun (x : Nat × Nat) => x.1 == w.id)).map (fun (x : Nat × Nat) => x.2) else none
  pid.bind fun n => s.prefs.find? (·.pid == n)

/-- The elements an instantiation or match tested, with their timetags, as Soar's conditions
have them: the `state` keyword is a test on the identifier, not a condition on
`(<s> ^type state)`, so that element is left out (as is, in this model, an explicit
`^type state` test on a state). -/
def St.wmaConds (s : St) (ws : List WME) (tts : List Nat) : List (WME × Nat) :=
  (ws.zip (tts ++ List.replicate (ws.length - tts.length) 0)).filter fun (w, _) =>
    !(w.attr == .str "type" && w.val == .str "state" && s.isGoal w.id)

/-- The preference of an element no longer in working memory, if it still exists: an
acceptable preference for its value (the preference Soar's element still points to, when that
preference has not been freed). -/
def St.wmaHeldPref (s : St) (w : WME) : Option PRec :=
  firstPref (s.prefs.filter fun p => p.kind == .acceptable && p.id == w.id && p.attr == w.attr && p.val == w.val)

/-- Whether the element with timetag `tt` is in working memory. -/
def St.wmaLive (s : St) (tt : Nat) : Bool := tt != 0 && s.tt.any (·.2 == tt)

/-! A condition of an instantiation can name an element that has since left working memory: the
instantiation keeps it, and its decay element, alive. Soar's non-context elements hold no
reference on their preference, so once that element's preference has been removed and freed
(an o-supported element rejected, an i-supported one retracted) the element's `preference`
pointer is stale. Soar 9.6.5 still reads it when building an o-set (`wma_activate_wme` calls
`wma_should_have_decay_element`) and when computing an initial boost for such an element with no
decay element; what it finds depends on which preference the pool has since put in that
memory. Here such an element contributes nothing, and each such read is counted
(`WmaSt.stale`), so that a comparison with Soar can tell where Soar's result is undefined. -/

/-- An element's activation (`wma_get_wme_activation`): the log of its decay element's time sum,
or 1 (`WMA_ACTIVATION_NONE`) for an element without one; unlogged, the time sum or e. -/
def St.wmaAct (s : St) (a : WmaSt) (w : WME) (logR : Bool) : Float :=
  match a.el (s.ttOf w) with
  | some e => s.wma.decayAct e a.cycle logR
  | none => if logR then wmaNone else wmaTimeSumNone

/-- The references a new decay element starts with (`wma_calculate_initial_boost`): the mean
time sum, rounded down, of the elements tested by the instantiations of the element's
o-supported acceptable preferences — elements just given a decay element left out, an
i-supported element standing for its o-supported dependencies, one with no preference counting
e. -/
def St.wmaBoost (s : St) (a : WmaSt) (w : WME) : Nat × Nat :=
  let ps := (s.prefs.filter fun p => p.kind == .acceptable && p.osup && p.id == w.id && p.attr == w.attr && p.val == w.val).mergeSort prefBefore
  let (_, n, sum, st) := ps.foldl (fun (acc : List Nat × Nat × Float × Nat) p =>
    let cs := match s.instById p.inst with | some i => s.wmaConds i.ws i.tts | none => []
    cs.foldl (fun (acc : List Nat × Nat × Float × Nat) (cw, tt) =>
      let (seen, n, sum, st) := acc
      if tt == 0 || seen.contains tt then acc else
      let seen := seen ++ [tt]
      match a.el tt with
      | some e => if e.justCreated then (seen, n, sum, st) else (seen, n + 1, sum + s.wma.decayAct e a.cycle false, st)
      | none =>
        let live := s.wmaLive tt
        let sup := if live then s.wmaSupport cw else s.wmaHeldPref cw
        if !live && sup.isNone then (seen, n, sum, st + 1) else
        let (seen, n, sum) : List Nat × Nat × Float := match sup with
        | some q => match a.osets.find? (·.1 == q.pid) with
          | some (_, os) => os.foldl (fun (acc : List Nat × Nat × Float) o =>
              let (seen, n, sum) := acc
              if seen.contains o then acc else
              match a.el o with
              | some e => if e.justCreated then acc else (seen ++ [o], n + 1, sum + s.wma.decayAct e a.cycle false)
              | none => (seen ++ [o], n + 1, sum + wmaTimeSumNone)) (seen, n, sum)
          | none => (seen, n, sum)
        | none => (seen, n + 1, sum + wmaTimeSumNone)
        (seen, n, sum, st)) acc) ([], 0, 0, 0)
  -- a NaN mean (Petrov's approximation with decay rate 1 divides 0 by 0) converts, in Soar
  -- 9.6.5 on x86-64, to 2^63
  let mean := sum / n.toFloat
  (if n == 0 then 0 else if mean.isNaN then 2 ^ 63 else (Float.floor mean).toUInt64.toNat, st)

/-- Give an o-supported element its decay element if it has none. -/
def St.wmaEnsure (s : St) (a : WmaSt) (w : WME) (tt : Nat) : WmaSt :=
  match a.el tt with
  | some _ => a
  | none =>
    let (b, st) := s.wmaBoost a w
    let l := (s.ltiOf? w.id).getD 0
    { a.setEl tt { refs := b, lti := l, born := a.born } with stale := a.stale + st, born := a.born + 1 }

/-- With `spreading-edge-updating`, a reference to an o-supported element from one LTI to
another is recorded as an update of that edge (`wma_activate_wme`). For an element with a
constant value Soar reads an identifier field of the constant (undefined); here such elements
record nothing. -/
def St.wmaEdge (s : St) (a : WmaSt) (w : WME) (n : Nat) : WmaSt :=
  if !s.smem.spEdgeUpd then a else
  match s.ltiOf? w.id, w.val with
  | some p, .id x => match s.ltiOf? x with
    | some ch => { a with edgeLog := a.edgeLog ++ [(p, ch, n.toFloat, a.cycle)] }
    | none => a
  | _, _ => a

/-- The o-supported elements an i-supported preference depends on (`wma_o_set`), made once,
from its instantiation's conditions: an o-supported element itself (given a decay element), an
i-supported one through its own preference's set, one with no preference itself. -/
def St.wmaOSet (s : St) : Nat → WmaSt → PRec → WmaSt × List Nat
  | 0, a, _ => (a, [])
  | f + 1, a, p =>
    match a.osets.find? (·.1 == p.pid) with
    | some (_, os) => (a, os)
    | none =>
      let ins (os : List Nat) (t : Nat) : List Nat := if os.contains t then os else os ++ [t]
      let cs := match s.instById p.inst with | some i => s.wmaConds i.ws i.tts | none => []
      let (a, os) := cs.foldl (fun (acc : WmaSt × List Nat) (w, tt) =>
        let (a, os) := acc
        if tt == 0 then acc else
        let live := s.wmaLive tt
        let sup := if live then s.wmaSupport w else s.wmaHeldPref w
        if !live && sup.isNone then (a.markStale, os) else
        match sup with
        | some q =>
          if q.osup then (s.wmaEdge (s.wmaEnsure a w tt) w 0, ins os tt)
          else
            let (a, os2) := s.wmaOSet f a q
            (a, os2.foldl ins os)
        | none => (a, ins os tt)) (a, [])
      ({ a with osets := a.osets ++ [(p.pid, os)] }, os)

/-- `wma_activate_wme`: `n` references to an element — to its decay element if it is
o-supported, else (unless `oOnly`) to the o-supported elements it depends on. -/
def St.wmaActivate (s : St) (a : WmaSt) (w : WME) (n : Nat) (oOnly : Bool) : WmaSt :=
  let tt := s.ttOf w
  if tt == 0 then a else
  match s.wmaSupport w with
  | some p =>
    if p.osup then s.wmaEdge ((s.wmaEnsure a w tt).addRefs tt n) w n
    else if oOnly then a else
      let (a, os) := s.wmaOSet (s.prefs.length + 2) a p
      os.foldl (fun a o => a.addRefs o n) a
  | none => a

/-- After an elaboration cycle's preference changes, from state `pre` (Soar 9.6.5
`add_preference_to_tm`, `assert_new_preferences` with `wma_activate_wmes_in_pref`): the slots
whose preferences changed are marked; each preference added to an ordinary slot that was not
yet changed in this cycle first clears the slot's references, and then counts a reference to
its value if no element has it yet; an acceptable preference from a rule (`fromInst`) also
references the elements of its slot with its value. -/
def St.wmaPrefs (s pre : St) (fromInst : Bool) (a : WmaSt) : WmaSt :=
  if !s.wma.on then a else
  let nowP : Std.HashSet Nat := Std.HashSet.ofList (s.prefs.map (·.pid))
  let preP : Std.HashSet Nat := Std.HashSet.ofList (pre.prefs.map (·.pid))
  let gone := pre.prefs.filter fun p => !nowP.contains p.pid
  let added := s.prefs.filter fun p => !preP.contains p.pid
  let mark (a : WmaSt) (k : Nat × Sym) : WmaSt := if a.changed.contains k then a else { a with changed := a.changed ++ [k] }
  let a := gone.foldl (fun a p => mark a (p.id, p.attr)) a
  let wmK : Std.HashSet (Nat × Sym × Sym) :=
    Std.HashSet.ofList ((pre.slots.map (·.w)).filterMap fun w => if w.acc then none else some (w.id, w.attr, w.val))
  added.foldl (fun a p =>
    let ctx := s.isCtx p.id p.attr
    let a := if ctx then a else
      let a := if a.changed.contains (p.id, p.attr) then a
        else { a with slotRefs := a.slotRefs.filter fun (k, _) => !(k.1 == p.id && k.2.1 == p.attr) }
      let a := mark a (p.id, p.attr)
      if wmK.contains (p.id, p.attr, p.val) then a else
      let k := (p.id, p.attr, p.val)
      let c := ((alGet a.slotRefs k)).getD 0
      { a with slotRefs := (alPut a.slotRefs k (c + 1)) }
    if fromInst && p.kind == .acceptable then
      let ws := (pre.slots.map (·.w) ++ pre.arch).filter fun w => w.id == p.id && w.attr == p.attr && w.val == p.val && !w.acc
      ws.foldl (fun a w => pre.wmaActivate a w 1 false) a
    else a) a

/-- At the start of an elaboration cycle's preference phase (`wma_activate_wmes_tested_in_prods`):
the elements tested by the pending matches — those about to fire and those waiting, such as
o-supported matches in the proposal phase — each get a reference, o-supported matches first. -/
def St.wmaTested (s : St) (waiting : List Match) (a : WmaSt) : WmaSt :=
  if !s.wma.on then a else
  let os := waiting.filter (·.osup)
  let is := waiting.filter (!·.osup)
  (os ++ is).foldl (fun a m => (s.wmaConds m.ws m.tts).reverse.foldl (fun a (w, _) => s.wmaActivate a w 1 false) a) a

/-- After a working-memory phase, from state `pre` (`decide_non_context_slot`): each new
element of an ordinary slot takes the references counted for its value, as an o-supported
element; the slots are no longer changed, the o-sets of preferences gone are dropped, and so are
the decay elements of elements no longer in working memory or held by an instantiation or o-set. -/
def St.wmaNewWmes (s pre : St) (a : WmaSt) : WmaSt :=
  if !s.wma.on then a else
  let preS := pre.slotSet
  let new := s.slots.filter fun e => !e.w.acc && !preS.contains e.w
  let a := new.foldl (fun a e =>
    let k := (e.w.id, e.w.attr, e.w.val)
    match a.slotRefs.find? (·.1 == k) with
    | some (_, n) => { s.wmaActivate a e.w n true with slotRefs := a.slotRefs.filter (·.1 != k) }
    | none => a) a
  -- a decay element lasts while its element is in working memory or is held by an
  -- instantiation or an o-set (Soar frees it with the element, `deallocate_wme`)
  let nowP : Std.HashSet Nat := Std.HashSet.ofList (s.prefs.map (·.pid))
  let a := { a with osets := a.osets.filter fun (pid, _) => nowP.contains pid }
  let live : Std.HashSet Nat := Std.HashSet.ofList (s.tt.map (·.2) ++ s.insts.flatMap (·.tts) ++ a.osets.flatMap (·.2))
  { a with changed := [], els := a.els.filter (fun t _ => live.contains t),
           touched := a.touched.filter live.contains,
           pq := (a.pq.map fun (c, ts) => (c, ts.filter live.contains)).filter (!·.2.isEmpty) }

/-- `wma_update_decay_histories`: the references of every element referenced since the last
update become the newest entry of its history; with forgetting by `bsearch` or `on`, the
element is (re)queued at the cycle its activation will fall below the threshold. -/
def St.wmaHistories (s : St) (a : WmaSt) : WmaSt :=
  if !s.wma.on then a else
  let queued := s.wma.forgetting == .bsearch || s.wma.forgetting == .approx
  let a := a.touched.foldl (fun (a : WmaSt) tt =>
    match a.el tt with
    | none => a
    | some e =>
      let e := e.record a.cycle
      let c := s.wma.estimate e a.cycle true
      let a := if queued then a.requeue tt c else a
      a.setEl tt { e with justCreated := false, forgetCycle := if queued then some c else e.forgetCycle }) a
  { a with touched := [] }

/-- The elements to forget this cycle, and the activation state after looking (part of
`St.wmaForget`). -/
def St.wmaForgetVictims (s : St) : WmaSt × List WME :=
  let a := s.wmaS
  let cur := a.cycle
  let th := s.wma.threshExp
  let ltiId (w : WME) : Bool := s.ltiOf.any (·.1 == w.id)
  let (a, victims) : WmaSt × List WME :=
    if s.wma.forgetting == .naive then
      let tm := s.ttMap
      (a, s.wm.filter fun w => match a.el (tm.getD w 0) with
        | some e => (!s.wma.forgetLti || ltiId w) && e.total > 0 &&
            (match e.hist.head? with | some (dc, _) => decide (dc < cur) | none => false) &&
            s.wma.decayAct e cur false < th
        | none => false)
    else
      match a.pq.find? (·.1 == cur) with
      | none => (a, [])
      | some (_, tts) =>
        let r := tts.foldl (fun (acc : WmaSt × List WME) tt =>
          let (a, vs) := acc
          match a.el tt, s.tt.find? (·.2 == tt) with
          | some e, some (w, _) =>
            if s.wma.decayAct e cur false < th then
              let a := a.setEl tt { e with forgetCycle := some 0 }
              if s.wma.forgetLti then
                if !ltiId w then (a, vs) else
                let mine := s.slots.filter (fun en => en.w.id == w.id)
                let all := mine.all fun en => match s.prefs.find? (·.pid == en.pref) with
                  | some p => !p.osup || (match a.el (s.ttOf en.w) with | some e2 => e2.forgetCycle == some 0 | none => false)
                  | none => true
                if all then (a, vs ++ mine.map (·.w)) else (a, vs)
              else (a, vs ++ [w])
            else
              let c := s.wma.estimate e cur false
              ((a.requeue tt c).setEl tt { e with forgetCycle := some c }, vs)
          | some e, none =>
            -- an element out of working memory but still held: Soar's `wma_forgetting_forget_wme`
            -- would read its stale preference
            if s.wma.decayAct e cur false < th then (a.markStale.setEl tt { e with forgetCycle := some 0 }, vs)
            else
              let c := s.wma.estimate e cur false
              ((a.requeue tt c).setEl tt { e with forgetCycle := some c }, vs)
          | _, _ => acc) (a, [])
        ({ r.1 with pq := r.1.pq.filter (·.1 != cur) }, r.2)
  (a, victims)

/-- Remove the o-supported preferences behind the forgotten elements (part of `St.wmaForget`). -/
def St.wmaForgetDrop (s : St) (victims : List WME) : St :=
  if s.wma.fake || victims.isEmpty then s else
  let goneOf (p : PRec) : Bool := p.osup && victims.any fun w => w.id == p.id && w.attr == p.attr && w.val == p.val
  if !s.prefs.any goneOf then s else
  let r := s.dropPrefs goneOf
  let r := r.setWma (r.wmaPrefs s false r.wmaS)
  let u := r.wmPhase s
  (u.setWma (u.wmaNewWmes r u.wmaS)).spSync

/-- Forgetting (`wma_go` with `wma_forgetting`), at the end of the output phase: the elements
whose activation has fallen below the decay threshold lose their o-supported preferences and
working memory is brought up to date. naive looks at every element with a decay element each
cycle; bsearch and on look at those queued for this cycle, requeueing those still above the
threshold. With `forget-wme lti` only elements of identifiers linked to an LTI are forgotten,
and only when all the identifier's o-supported elements are. `fake-forgetting` forgets
nothing. -/
def St.wmaForget (s : St) : St :=
  if !s.wma.on || s.wma.forgetting == .off then s else
  let r := s.wmaForgetVictims
  (s.setWma r.1).wmaForgetDrop r.2

/-- One step of the inner elaboration loop (`St.elabCycle`): fire at level `l`, if it has
activity, the pending instantiations of kind `ft` that the waterfall test lets through; `next`
is the lowest level that has fired so far. -/
def St.elabStep (pre : St) (lt : Nat → Nat) (ph : Phase) (ft : Firing) (H : Nat) (pd : Pend)
    (acc : St × Nat) (l : Nat) : St × Nat :=
  let (s, next) := acc
  let active : Bool := pd.iAct l || (ph == .apply && pd.oAct l)
  if !(s.goals.any (·.level == l)) || (l != H && !active) then (s, next) else
  let ass := (if ft == .ie then pd.iAss else pd.oAss).filter (·.level == l)
  let fire := if l == H then ass else ass.filter (waterfallOk lt next)
  -- without the Rete's order: the matches of the first pass, present when the rules were
  -- loaded, fire in the reverse of the order the rules were loaded (observed in Soar 9.6.5,
  -- 2026-10-30)
  let fire := if !s.reteOn && s.passNo == 0 then fire.reverse else fire
  let next' := if ass.isEmpty then next else max next l
  (s.fireLevel pre ft l fire, next')

/-- **One elaboration cycle** (Soar 9.6.5 `do_preference_phase` followed by
`do_working_memory_phase`). `H` is the highest state with activity and `ft` the kind of firing
chosen for it. The inner elaboration loop fires, at `H` and then at each lower state with
activity, the pending instantiations of kind `ft`. Below `H` a firing is postponed when one of
its actions changes a state at or above the lowest level that has fired so far in this cycle
(Soar's "waterfall"); postponed instantiations stay pending. Retractions are made at `H`
only. The working-memory phase follows.

> "In each elaboration cycle, all matching productions fire and the working memory changes
> or operator preferences described through their actions are made." — [Man] §2.5
>
> "Soar goes through the substates, from oldest (highest) to newest (lowest), completing any
> necessary processing at that level for that phase before doing any processing in the next
> substate." — [Man] §2.7.8 -/
def St.elabCycle (s : St) (ph : Phase) (ft : Firing) (H : Nat) (pd : Pend) : St :=
  let levels := ((s.goals.map (·.level)).filter (· ≥ H)).mergeSort (· ≤ ·)
  let t := (levels.foldl (St.elabStep s s.idLevel ph ft H pd) (s, H)).1
  let t := t.retract (pd.retr.filter (fun i => i.level == H && t.insts.any (fun j => j.iid == i.iid)))
  -- working-memory activation: the elements tested by the pending matches (at the start of the
  -- preference phase), then the preferences asserted
  let t := t.setWma (t.wmaPrefs s true (s.wmaTested (pd.oAss ++ pd.iAss) s.wmaS))
  let u := t.wmPhase s
  (u.setWma (u.wmaNewWmes t u.wmaS)).spSync

/-! ## Semantic memory: commands and results ([Man] §6.1, §6.3, §6.4)

Each state has `(<s> ^smem <l>) (<l> ^command <c>) (<l> ^result <r>)`. Rules put commands
under `<c>`; semantic memory puts its status elements (`^success`, `^failure`, `^bad-cmd`,
`^retrieved`, `^depth-retrieved`) under `<r>`, and the augmentations of retrieved LTIs on new
identifiers.

Checked against the Soar 9.6.5 source (`semantic_memory.cpp`, `smem_instance.cpp`,
`run_soar.cpp`, 2026-10-29):

* Storage commands are processed after every elaboration cycle of the proposal and application
  phases; retrievals at the end of the output phase. In each pass the states are visited from
  the bottom of the goal stack up.
* A state's command is processed when what the pass looks at has changed since that pass last
  looked: the storage pass looks at `^store` elements and the augmentations of their values,
  the retrieval pass at the other command elements and the augmentations of `^query`
  values. A change first removes all of the state's status elements.

> "Storage commands are processed on every state at the end of every phase of every decision
> cycle." — [Man] §6.3.1
>
> "At the end of the output of each decision, semantic memory processes each state's smem
> ^command structure." — [Man] §6.4

Status elements and the augmentations of retrieved LTIs are kept with the o-supported
elements: rules can remove both (checked against Soar 9.6.5, 2026-10-29, for status elements
made in the proposal, application and output phases, removed by o- and i-supported rules),
and like other elements they are removed when no longer linked to a state. For retrieved
augmentations this is what the manual says ([Man] §6.2.1.1: they are "manipulated just like
any other WMEs"); for status elements it says "Production actions should not remove
augmentations of the result structure directly, as semantic memory will maintain these WMEs"
([Man] §6.1).

SIMPLIFIED: Soar decides that a command has changed by comparing WME timetags; here the set of
elements is compared, so removing an element and re-creating it between two passes is not a
change. NOT FORMALIZED: Soar gives retrieved augmentations i- or o-support according to the
kind of the last elaboration cycle; here they behave as o-supported. -/

/-- Track Soar's slots after an elaboration cycle: a slot lasts while elements with its
identifier and attribute exist; new slots are created in the reverse of the order in which
their elements were made (Soar adds an instantiation's preferences at the head of its list).
Checked against Soar 9.6.5 (2026-10-29) with commands whose validity depends on this order. -/
def St.trackSlots (s : St) : St :=
  if !s.smemOn && !s.epOn then s else
  let wm := s.wm
  let wmS : Std.HashSet WME := Std.HashSet.ofList wm
  let present := dedupFirst (wm.map fun w => (w.id, w.attr))
  let presentS : Std.HashSet (Nat × Sym) := Std.HashSet.ofList present
  let kept := s.slotSeq.filter presentS.contains
  let keptS : Std.HashSet (Nat × Sym) := Std.HashSet.ofList kept
  let new := (present.filter (!keptS.contains ·)).reverse
  let keptE := s.elemSeq.filter fun p => wmS.contains p.1
  let keptES : Std.HashSet WME := Std.HashSet.ofList (keptE.map (·.1))
  let newE := (wm.filter fun w => !keptES.contains w).map (·, s.waveNo)
  { s with slotSeq := kept ++ new, elemSeq := keptE ++ newE, waveNo := s.waveNo + 1 }

/-- Augmentations of an identifier in the order Soar's `get_direct_augs_of_id` lists them:
slots from the most recently created first, and within a slot the most recent element first —
where the elements one instantiation creates in a slot are listed in the order its actions
make them (Soar adds an instantiation's preferences in reverse and each new element at the
head of its slot). -/
def St.soarOrderWith (s : St) (posM : Std.HashMap (Nat × Sym) Nat) (bornM : Std.HashMap WME Nat)
    (ws : List WME) : List WME :=
  let pos (w : WME) : Nat := (posM[(w.id, w.attr)]?).getD s.slotSeq.length
  let attrs := (ws.map (·.attr)).eraseDups
  let attrs := (attrs.toArray.qsort fun a b =>
    pos { id := (ws.head?.map (·.id)).getD 0, attr := a, val := .nil } >
    pos { id := (ws.head?.map (·.id)).getD 0, attr := b, val := .nil }).toList
  let born (w : WME) : Nat := (bornM[w]?).getD s.waveNo
  attrs.flatMap fun a =>
    let inSlot := ws.filter (·.attr == a)
    let waves := ((inSlot.map born).eraseDups.toArray.qsort (· > ·)).toList
    waves.flatMap fun k => inSlot.filter (born · == k)

/-- The position of each slot in `slotSeq` (the first, as `findIdx?` finds it). -/
def St.slotPosMap (s : St) : Std.HashMap (Nat × Sym) Nat :=
  s.slotSeq.enum.foldl (fun m (i, k) => if m.contains k then m else m.insert k i) {}

/-- The wave in which each element was made (the first entry of `elemSeq`, as `find?` finds it). -/
def St.bornMap (s : St) : Std.HashMap WME Nat :=
  s.elemSeq.foldl (fun m (w, k) => if m.contains w then m else m.insert w k) {}

def St.soarOrder (s : St) (ws : List WME) : List WME :=
  s.soarOrderWith s.slotPosMap s.bornMap ws

def St.augs (s : St) (n : Nat) : List WME :=
  s.soarOrder (s.wm.filter fun w => w.id == n && !w.acc)

def St.linkLti (s : St) (n l : Nat) : St :=
  { s with ltiOf := (alPut s.ltiOf n l) }

/-- The link, command and result identifiers of a state for the memory whose link attribute is
`name` (`smem` or `epmem`). -/
def St.memLinks (s : St) (name : String) (g : Nat) : Option (Nat × Nat × Nat) :=
  let find (i : Nat) (a : String) : Option Nat :=
    match (s.arch.find? (fun w => w.id == i && w.attr == .str a)).map (·.val) with
    | some (Sym.id n) => some n
    | _ => none
  match find g name with
  | some l => match find l "command", find l "result" with
    | some c, some r => some (l, c, r)
    | _, _ => none
  | none => none

/-- The `^smem` link, command and result identifiers of a state. -/
def St.smemLinks (s : St) (g : Nat) : Option (Nat × Nat × Nat) := s.memLinks "smem" g

/-- The LTI for a short-term identifier being stored (Soar's `get_current_LTI_for_iSTI`):
with `lookup` (`^store-new`) a fresh LTI per identifier per command, otherwise the linked LTI
or a fresh one; the identifier is then linked to it unless already linked (or `relink`). -/
def St.ltiFor (s : St) (x : Nat) (lookup relink : Bool) (tbl : List (Nat × Nat)) :
    St × Nat × List (Nat × Nat) :=
  let (s, n, tbl) := if lookup then
      match tbl.find? (·.1 == x) with
      | some (_, n) => (s, n, tbl)
      | none => let (db, n) := s.smem.newLti; ({ s with smem := db }, n, tbl ++ [(x, n)])
    else
      match s.ltiOf? x with
      | some n => (s, n, tbl)
      | none => let (db, n) := s.smem.newLti; ({ s with smem := db }, n, tbl)
  let s := if relink || (s.ltiOf? x).isNone then s.linkLti x n else s
  (s, n, tbl)

/-- Store one identifier: its augmentations replace those of its LTI; identifier values are
stored as links to their LTIs (created if needed) but their own augmentations are not stored.

> "Semantic memory will encode and store all WMEs whose identifier is the value of the store
> command. Storing deeper levels of working memory is achieved through multiple store
> commands." — [Man] §6.3.1
> "If the identifier used in the store command is already linked to an LTI, the store will
> overwrite that long-term memory." — [Man] §6.3.1 -/
def St.storeId (s : St) (x : Nat) (lookup relink : Bool) (tbl : List (Nat × Nat)) :
    St × List (Nat × Nat) :=
  let kids := s.augs x
  let (s, n, tbl) := s.ltiFor x lookup relink tbl
  let (s, augs, tbl) := kids.foldl (fun (acc : St × List (Sym × LVal) × List (Nat × Nat)) w =>
    let (s, augs, tbl) := acc
    match w.attr with
    | .id _ => acc   -- identifier attributes are not stored ([Man] §6.2)
    | _ => match w.val with
      | .id y => let (s, m, tbl) := s.ltiFor y lookup relink tbl; (s, augs ++ [(w.attr, .lti m)], tbl)
      | c => (s, augs ++ [(w.attr, .const c)], tbl)) (s, [], tbl)
  ({ s with smem := s.smem.write n augs true true }, tbl)

/-- The identifier standing for LTI `m` in the current retrieval: one new identifier per LTI,
linked to it. -/
def St.stiFor (s : St) (tbl : List (Nat × Nat)) (m : Nat) : St × Nat × List (Nat × Nat) :=
  match tbl.find? (·.1 == m) with
  | some (_, x) => (s, x, tbl)
  | none => let x := s.nextId; ((({ s with nextId := x + 1 }).linkLti x m), x, tbl ++ [(m, x)])

abbrev InstAcc := St × List (Nat × Nat) × List WME × List (Nat × Nat × Nat)

/-- One augmentation of the LTI being placed on identifier `x`. -/
def installStep (x d : Nat) (acc : InstAcc) (av : Sym × LVal) : InstAcc :=
  let (s, tbl, ws, queue) := acc
  match av.2 with
  | LVal.const c => (s, tbl, ws ++ [({ id := x, attr := av.1, val := c } : WME)], queue)
  | LVal.lti m' =>
    let (s, y, tbl) := s.stiFor tbl m'
    (s, tbl, ws ++ [({ id := x, attr := av.1, val := .id y } : WME)],
     if d > 1 then queue ++ [(y, m', d - 1)] else queue)

/-- All augmentations of LTI `m` on identifier `x`; with depth `d` > 1 the LTIs they link to
are queued for expansion. -/
def installOne (acc : InstAcc) (x m d : Nat) : InstAcc :=
  (acc.1.smem.expand m).foldl (installStep x d) acc

/-- Breadth-first expansion of queued LTIs, each marked `(r ^depth-retrieved y)`. -/
def installBfs (r : Nat) : Nat → St → List (Nat × Nat) → List WME → List WME →
    List (Nat × Nat × Nat) → List Nat → St × List WME × List WME
  | 0, s, _, ws, «meta», _, _ => (s, «meta», ws)
  | _ + 1, s, _, ws, «meta», [], _ => (s, «meta», ws)
  | f + 1, s, tbl, ws, «meta», (y, m, d) :: rest, visited =>
    if visited.contains m then installBfs r f s tbl ws «meta» rest visited else
    let (s, tbl, ws, q') := installOne (s, tbl, ws, []) y m d
    installBfs r f s tbl ws («meta» ++ [({ id := r, attr := "depth-retrieved", val := .id y } : WME)])
      (rest ++ q') (visited ++ [m])

/-- Place an LTI in working memory (Soar's `install_memory`): `(r ^retrieved x)` and the LTI's
augmentations on `x` (a new identifier unless given), with LTI values on new identifiers, one
per LTI; with `depth` > 1, those identifiers' augmentations too, breadth first, each marked
`(r ^depth-retrieved y)`.

> "All augmentations of the long-term identifier in semantic memory will be created as new
> WMEs in working memory." — [Man] §6.4.1 -/
def St.install (s : St) (r : Nat) (n : Nat) (givenId : Option Nat) (act : Bool) (depth : Nat) :
    St × List WME × List WME :=
  -- the only change to the store: the LTI's activation
  let db := if act then (s.smem.activate n true (s.smem.edgesOf n).length).1 else s.smem
  let p₀ : St × Nat × List (Nat × Nat) := match givenId with
    | some x => (s, x, [])
    | none => s.stiFor [] n
  let p₁ := installOne (p₀.1, p₀.2.2, [], []) p₀.2.1 n depth
  let p₂ := installBfs r (s.smem.edges.length + 1) p₁.1 p₁.2.1 p₁.2.2.1 [] p₁.2.2.2 [n]
  ({ p₂.1 with smem := db }, [({ id := r, attr := "retrieved", val := .id p₀.2.1 } : WME)] ++ p₂.2.1, p₂.2.2)

/-- A math-query condition `(<c> ^less 5)`: `none` if malformed, `some none` if not a
condition. -/
def mathCondOf (a v : Sym) : Option (Option MathCond) :=
  match a, v.num? with
  | .str "less", some x => some (some (.less x))
  | .str "greater", some x => some (some (.greater x))
  | .str "less-or-equal", some x => some (some (.lessEq x))
  | .str "greater-or-equal", some x => some (some (.greaterEq x))
  | .str "max", _ => some (some .max)
  | .str "min", _ => some (some .min)
  | .str "less", none => none
  | .str "greater", none => none
  | .str "less-or-equal", none => none
  | .str "greater-or-equal", none => none
  | _, _ => some none

/-- The cue elements of a query: the augmentations of the cue (positive), of the `^neg-query`
cue (negative) and of the `^math-query` (conditions). `none` if the cue cannot match.

> "If no long-term identifier satisfies ALL of these requirements, an error is returned" —
> [Man] §6.4.2 -/
def St.cueElements (s : St) (q : Nat) (neg math : Option Nat) : Option (List CueEl) :=
  let db := s.smem
  let known (x : Sym) : Bool := db.syms.contains x
  let elOf (w : WME) (pos : Bool) : Option CueEl :=
    match w.val with
    | .id y => match s.ltiOf? y with
      | some m => some { attr := w.attr, kind := .lti m, pos }
      | none => some { attr := w.attr, kind := .any, pos }
    | c => some { attr := w.attr, kind := .const c, pos }
  -- a positive element the store has no instance of makes the cue fail; a negative one is
  -- dropped
  let posEls := (s.augs q).map fun w => (elOf w true).filter fun e => known w.attr && db.weight e > 0
  if posEls.isEmpty || posEls.any (·.isNone) then none else
  let posEls := posEls.filterMap id
  let mathEls : Option (List CueEl) := match math with
    | none => some []
    | some m =>
      let conds : List (Option (List CueEl)) := (s.augs m).map fun w => match w.val with
        | Sym.id y =>
          let cs := s.augs y
          if cs.isEmpty then none else
          let mcs : Option (List (Option MathCond)) := cs.mapM fun c => mathCondOf c.attr c.val
          mcs.map fun l => (l.filterMap id).map fun mc => ({ attr := w.attr, kind := .math mc, pos := true } : CueEl)
        | _ => some []
      (conds.mapM id).map fun (l : List (List CueEl)) =>
        -- a condition on an attribute the store has never seen is dropped (as in Soar)
        l.flatten.filter fun e => known e.attr && db.weight e > 0
  let maxes := (mathEls.getD []).filter fun e => match e.kind with | .math .max => true | _ => false
  let mins := (mathEls.getD []).filter fun e => match e.kind with | .math .min => true | _ => false
  match mathEls with
  | none => none
  | some me =>
    if maxes.length > 1 || mins.length > 1 then none else
    let negEls := match neg with
      | none => []
      | some ng => ((s.augs ng).filterMap fun w => elOf w false).filter fun e =>
          known e.attr && (match e.kind with | .const c => known c | _ => true) && db.weight e > 0
    some (posEls ++ me ++ negEls)

/-- The parts of a command ([Man] §6.3–6.4), following Soar 9.6.5's `respond_to_cmd`: at most
one kind of command, with its modifiers; anything else makes it a bad command.

> "Only one type of retrieval command (which may include optional modifiers) can be issued per
> state in a single decision cycle. Malformed commands (including attempts at multiple
> retrieval types) will result in an error" — [Man] §6.4 -/
inductive CmdPath where
  | blank | bad | retrieve | query | storeNew | store | prohibit
  deriving DecidableEq, Repr

structure Cmd where
  path : CmdPath := .blank
  retrieve : Option Nat := none
  query : Option Nat := none
  neg : Option Nat := none
  math : Option Nat := none
  stores : List Nat := []
  prohibits : List Nat := []
  relink : Bool := false
  linkToLtm : Bool := true
  depth : Nat := 1
  deriving Repr

def St.parseCmd (s : St) (cmds : List WME) : Cmd :=
  let c := cmds.foldl (fun (c : Cmd) w =>
    if c.path == .bad then c else
    let p := c.path
    let qOk := p == .blank || p == .prohibit || p == .query
    match w.attr, w.val with
    | .str "retrieve", .id x => if p == .blank then { c with retrieve := some x, path := .retrieve } else { c with path := .bad }
    | .str "query", .id x => if qOk && c.query.isNone then { c with query := some x, path := .query } else { c with path := .bad }
    | .str "neg-query", .id x => if qOk && c.neg.isNone then { c with neg := some x, path := .query } else { c with path := .bad }
    | .str "prohibit", .id x =>
      if qOk && (s.ltiOf? x).isSome then
        { c with prohibits := c.prohibits ++ [x], path := if p == .query then .query else .prohibit }
      else { c with path := .bad }
    | .str "math-query", .id x => if qOk && c.math.isNone then { c with math := some x, path := .query } else { c with path := .bad }
    | .str "store", .id x => if p == .blank || p == .store then { c with stores := c.stores ++ [x], path := .store } else { c with path := .bad }
    | .str "store-new", .id x => if p == .blank || p == .storeNew then { c with stores := c.stores ++ [x], path := .storeNew } else { c with path := .bad }
    | .str "link-to-new-ltm", .str v =>
      if (v == "yes" || v == "no") && (p == .blank || p == .storeNew) then { c with relink := v == "yes" } else { c with path := .bad }
    | .str "link-to-ltm", .str v =>
      if (v == "yes" || v == "no") && (p == .blank || p == .retrieve || p == .query) then { c with linkToLtm := v == "yes" } else { c with path := .bad }
    | .str "depth", .int d => { c with depth := if d > 0 then d.toNat else 1 }
    | _, _ => { c with path := .bad }) {}
  if c.path == .query && c.query.isNone then { c with path := .bad }
  else if c.path == .blank then { c with path := .bad }
  else c

/-- Carry out a command for the state with result identifier `r` and command identifier
`cid`; returns the status elements and the retrieved augmentations. -/
def stWme (r : Nat) (a : String) (x : Nat) : WME := { id := r, attr := a, val := .id x }

/-- A non-cue-based retrieval ([Man] §6.4.1). Soar 9.6.5 places the LTI on a new identifier
(`install_memory` is called without the command's identifier, despite the source comment
"install memory directly onto the retrieve identifier"; checked 2026-10-29). -/
def St.runRetrieve (s : St) (r : Nat) (c : Cmd) (x : Nat) : St × List WME × List WME :=
  match s.ltiOf? x with
  | none => (s, [stWme r "failure" x], [])
  | some n =>
    let p := s.install r n none true c.depth
    (p.1, [stWme r "success" x] ++ p.2.1, p.2.2)

/-- The LTI a cue-based retrieval finds, if any. -/
def St.queryResult (s : St) (c : Cmd) (q : Nat) : Option Nat :=
  let prohib := c.prohibits.filterMap s.ltiOf?
  let full := match c.math with
    | some m => (s.augs m).any fun w => match w.val with
      | .id y => (s.augs y).any fun x => x.attr == .str "max" || x.attr == .str "min"
      | _ => false
    | none => false
  (s.cueElements q c.neg c.math).bind fun els => s.smem.query els prohib full

/-- Before a query's search: the prohibits are marked and, with the naive base-level policy,
the candidates' activations recomputed (`SMemDB.markProhibits`, `SMemDB.naiveUpdate`). -/
def St.prepQuery (s : St) (c : Cmd) (q : Nat) : St :=
  let db := s.smem.markProhibits (c.prohibits.filterMap s.ltiOf?)
  { s with smem := match s.cueElements q c.neg c.math with
    | some els => (db.spreadPrep els s.spPre).naiveUpdate els
    | none => db }

/-- A cue-based retrieval ([Man] §6.4.2). -/
def St.runQuery (s0 : St) (r : Nat) (c : Cmd) (q : Nat) : St × List WME × List WME :=
  let s := s0.prepQuery c q
  let negSt := fun (a : String) => match c.neg with | some ng => [stWme r a ng] | none => []
  match s.queryResult c q with
  | some n =>
    let p := s.install r n none s.smem.activateOnQuery c.depth
    (p.1, [stWme r "success" q] ++ negSt "success" ++ p.2.1, p.2.2)
  | none => (s, [stWme r "failure" q] ++ negSt "failure", [])

/-- Storage ([Man] §6.3.1–6.3.2). -/
def St.runStore (s : St) (r : Nat) (c : Cmd) : St × List WME × List WME :=
  let lookup := c.path == .storeNew && !c.relink
  let relink := c.path == .storeNew && c.relink
  let p := c.stores.foldl (fun (acc : St × List (Nat × Nat)) x => acc.1.storeId x lookup relink acc.2) (s, [])
  (p.1, c.stores.map (stWme r "success" ·), [])

/-- Carry out a command for the state with result identifier `r` and command identifier
`cid`; returns the status elements and the retrieved augmentations. -/
def St.runCmd (s : St) (r cid : Nat) (c : Cmd) : St × List WME × List WME :=
  match c.path with
  | .retrieve => match c.retrieve with
    | none => (s, [], [])
    | some x => s.runRetrieve r c x
  | .query => match c.query with
    | none => (s, [], [])
    | some q => s.runQuery r c q
  | .store | .storeNew => s.runStore r c
  | .prohibit => (s, [], [])
  | _ => (s, [stWme r "bad-cmd" cid], [])

/-- What a memory's processing of a state changes in the instantiations, preferences and
elements it makes, in the identifiers it uses and in the LTI links. -/
structure MemDelta where
  insts : List Inst
  prefs : List PRec
  slots : List WEnt
  pNext : Nat
  iNext : Nat
  nextId : Nat
  ltiOf : List (Nat × Nat)
  xinsts : List XInst
  xNext : Nat

def St.memDelta (s : St) : MemDelta :=
  { insts := s.insts, prefs := s.prefs, slots := s.slots, pNext := s.pNext, iNext := s.iNext,
    nextId := s.nextId, ltiOf := s.ltiOf, xinsts := s.xinsts, xNext := s.xNext }

def St.withMemDelta (s : St) (d : MemDelta) : St :=
  { s with insts := d.insts, prefs := d.prefs, slots := d.slots, pNext := d.pNext, iNext := d.iNext,
           nextId := d.nextId, ltiOf := d.ltiOf, xinsts := d.xinsts, xNext := d.xNext }

/-- What semantic memory's processing of a state changes. -/
structure SMemDelta extends MemDelta where
  smem : SMemDB
  smemMeta : List (Nat × List WME)
  smemSnap : List ((Nat × Bool) × List WME)

def St.delta (s : St) : SMemDelta :=
  { s.memDelta with smem := s.smem, smemMeta := s.smemMeta, smemSnap := s.smemSnap }

def St.withDelta (s : St) (d : SMemDelta) : St :=
  { s.withMemDelta d.toMemDelta with smem := d.smem, smemMeta := d.smemMeta, smemSnap := d.smemSnap }

/-- A memory system's results for state `g` (Soar 9.6.5
`make_architectural_instantiation_for_memory_system`): an instantiation, never in the match
set, whose conditions are the command elements `cue` and whose acceptable preferences make the
elements `ws`; they belong to the state (`preferences_from_goal`). The preferences are
o-supported if the last elaboration cycle was a PE cycle and i-supported if it was an IE cycle
(`add_pref_to_inst` with `FIRING_TYPE`); never in the match set, they are not retracted
either way. -/
def St.memResults (s : St) (g : Goal) (cue ws : List WME) (uid : String) : St :=
  if ws.isEmpty then s else
  let os := s.firing == .pe
  let i : Inst := { iid := s.iNext, name := "memory", kind := .memory, ws := cue, tts := cue.map s.ttOf, level := g.level, goal := g.id, osup := os,
                    inMs := false, made := ws, uid := uid }
  let ps := ws.enum.map fun (k, w) =>
    ({ pid := s.pNext + k, id := w.id, attr := w.attr, val := w.val,
       kind := .acceptable, osup := os, inst := i.iid, level := g.level, goal := g.id } : PRec)
  ({ s with insts := s.insts ++ [i], iNext := s.iNext + 1, pNext := s.pNext + ps.length }).assertPrefs ps

/-- Withdraw a memory system's preferences for elements `ws` of state `g`. -/
def St.dropMemPrefs (s : St) (g : Nat) (ws : List WME) : St :=
  if ws.isEmpty then s else
  (s.dropPrefs fun p => p.goal == g && p.kind == .acceptable &&
    ws.any (fun w => w.id == p.id && w.attr == p.attr && w.val == p.val) &&
    ((s.instById p.inst).map (·.kind == .memory)).getD false)

/-- The explanation record of a memory system's retrieval into state `g` (Soar 9.6.5
`make_architectural_instantiation_for_memory_system`): its conditions are the state's link,
command and result elements and the command's cue, its actions the elements it made.
Identifiers have identities; constants are literal. -/
def St.memXInst (s : St) (g : Goal) (key : String) (condWs made : List WME) : XInst :=
  let vn (n : Nat) : String := s!"v{n}"
  let tst (y : Sym) : Test := match y with | .id n => [.var (vn n)] | c => [.const c]
  let rv (y : Sym) : RVal := match y with | .id n => .var (vn n) | c => .sym c
  let pats := condWs.map fun w => ({ id := [.var (vn w.id)], attr := tst w.attr, val := tst w.val, acc := w.acc } : Pat)
  let ids := ((condWs ++ made).flatMap fun w => w.id :: wmeIds w).eraseDups
  { key := key, prod := { name := "memory", conds := pats.map .pos, acts := made.map fun w => .make (vn w.id) (rv w.attr) (rv w.val) },
    orig := "memory", level := g.level, goal := g.id, conds := pats.zip condWs,
    b := ids.map (fun n => (vn n, Sym.id n)), made := made, traces := condWs.map s.traceOf }

def St.smemDelta (s : St) (storeOnly : Bool) (g : Goal) : SMemDelta :=
  match s.smemLinks g.id with
  | none => s.delta
  | some (lnk, cid, r) =>
    let wm := s.wm
    let top := s.soarOrder (wm.filter fun w => w.id == cid && !w.acc)
    let looked := top.filter fun w => (w.attr == .str "store") == storeOnly
    let deeper := looked.flatMap fun w => match w.val with
      | .id v => if w.attr == .str "query" || w.attr == .str "store" then
          wm.filter fun x => x.id == v && !x.acc && v != cid else []
      | _ => []
    let seen := looked ++ deeper
    let key := (g.id, storeOnly)
    let prev := (alGet s.smemSnap key)
    let changed := match prev with
      | some p => !(p.all seen.contains && seen.all p.contains)
      | none => !seen.isEmpty
    if !changed then s.delta else
    -- clear the old status elements
    let old := ((alGet s.smemMeta g.id)).getD []
    let s : St := { s.dropMemPrefs g.id old with
                           smemMeta := s.smemMeta.filter (·.1 != g.id),
                           smemSnap := (alPut s.smemSnap key seen) }
    if seen.isEmpty then s.delta else
    let c := s.parseCmd top
    let res := s.runCmd r cid c
    let «meta» := res.2.1
    let ws := res.2.2
    let ltiOf := if c.linkToLtm then res.1.ltiOf else
      let ids := ws.flatMap fun w => w.id :: wmeIds w
      res.1.ltiOf.filter (fun p => !ids.contains p.1)
    -- the status elements and retrieved augmentations depend on the command (Soar makes
    -- them by an architectural instantiation whose conditions are the command elements)
    -- a malformed command runs no query, so the query's elements are not part of its cue
    -- (its status element is `(<r> ^bad-cmd <c>)`, `stWme`)
    let isBad := «meta».any fun w => w.attr == .str "bad-cmd"
    let cue := top ++ (if isBad then [] else ([c.query, c.neg].filterMap id).flatMap fun x => wm.filter fun w => w.id == x && !w.acc)
    -- with learning, the retrieval leaves an explanation record
    let links : List WME := [{ id := g.id, attr := "smem", val := .id lnk }, { id := lnk, attr := "command", val := .id cid },
                             { id := lnk, attr := "result", val := .id r }]
    let (xs, xn, key) :=
        if s.learning && g.level ≥ 2 && !(«meta» ++ ws).isEmpty then
          ([s.memXInst g s!"x{s.xNext}m0" (links ++ cue) («meta» ++ ws)], s.xNext + 1, s!"x{s.xNext}m0")
        else ([], s.xNext, "")
    let s : St := { s with smem := res.1.smem, ltiOf := ltiOf, nextId := res.1.nextId,
                           smemMeta := s.smemMeta ++ [(g.id, «meta»)], xinsts := xs ++ s.xinsts, xNext := xn }
    (s.memResults g (links ++ cue) («meta» ++ ws) key).delta

/-- Semantic memory's processing of one state's command (Soar 9.6.5 `respond_to_cmd`, one
iteration). Only the long-term store, LTI links, new identifiers and the state's status and
retrieved elements change; architecture-created elements and the goal stack do not.

NOT FORMALIZED (a Soar 9.6.5 defect, found 2026-10-29): in a pass where two states have new
queries, 9.6.5 does not clear its list of queries between states (`orquery` in
`respond_to_cmd`), so the second state's query also runs the first state's cue; in every case
tried this ended with a double-free crash. Here each state's command is processed on its own,
as the manual describes. -/
def St.smemState (s : St) (storeOnly : Bool) (g : Goal) : St :=
  s.withDelta (s.smemDelta storeOnly g)

/-- One pass of semantic memory over the goal stack, from the bottom state up: `storeOnly`
for the pass after each elaboration cycle, otherwise the pass at the end of the output phase.
The elements it removes can unlink others and change goal dependency sets, so removal of
unlinked elements and the goal dependency set check follow. -/
def St.smemRun (s : St) (storeOnly : Bool) : St :=
  let states := (s.goals.toArray.qsort (fun a b => a.level > b.level)).toList
  states.foldl (fun (s : St) g => s.smemState storeOnly g) s

def St.smemPass (s : St) (storeOnly : Bool) : St :=
  if !s.smemOn then s else
  let r := s.smemRun storeOnly
  let r := r.setWma (r.wmaPrefs s false r.wmaS)
  let u := r.wmPhase s
  (u.setWma (u.wmaNewWmes r u.wmaS)).spSync

/-! ## Episodic memory: recording episodes and responding to commands -/

/-- An identifier's elements in working memory `wm`, in Soar's order, acceptable preferences
after the others (Soar's `epmem_get_augs_of_id`). -/
def St.epAugs (s : St) (wm : List WME) : Nat → List WME :=
  let posM := s.slotPosMap
  let bornM := s.bornMap
  let byId : Std.HashMap Nat (List WME) := wm.foldr (fun w m => m.insert w.id (w :: m.getD w.id [])) {}
  fun n =>
    let mine := byId.getD n []
    s.soarOrderWith posM bornM (mine.filter (!·.acc)) ++ mine.filter (·.acc)

/-- The `^epmem` link, command and result identifiers of a state. -/
def St.epLinks (s : St) (g : Nat) : Option (Nat × Nat × Nat) := s.memLinks "epmem" g

/-- Every element reachable from identifier `c` (Soar's breadth-first walk of a command). -/
def reachAll (wm : List WME) (c : Nat) : List WME :=
  let ids := Std.HashSet.ofList (reach wm [c])
  wm.filter (fun w => ids.contains w.id)

/-- Consider recording an episode (Soar's `epmem_consider_new_episode`): bring the encoder up
to date, and with the `dc` trigger (the default) record one every decision cycle; with the
`output` trigger, when the output link has a new element. After recording, every state's
`^present-id` is the number of the next episode.

> "Episodic memory records new episodes without deliberate action/consideration by the agent.
> … The value of the trigger parameter indicates to the architecture the event that concludes
> an episode: adding a new augmentation to the output-link (default) or each decision cycle."
> — [Man] §7.2

[Man] §7.2 and §9.5 give `output` as the default trigger; in Soar 9.6.5 it is `dc` (checked
2026-10-29, `episodic_memory.cpp` and runs).

SIMPLIFIED: the `output` trigger compares the output link with what it was at the previous
output phase; Soar compares timetags with the newest one it has seen, which can record a second
episode when two elements appear in one cycle. -/
def St.epConsider (s : St) : EpDB × Bool :=
  let wm := s.wm
  let db := s.ep.sync 1 wm (s.epAugs wm) (fun x => (s.ltiOf? x).getD 0)
  match db.force with
  | some b => ({ db with force := none }, b)
  | none =>
  match db.trigger with
  | .dc => (db, true)
  | .none => (db, false)
  | .output =>
    let ol := wm.filter (fun w => w.id == 4 && !w.acc)   -- the output link
    ({ db with olSeen := ol }, ol.any (!db.olSeen.contains ·))

/-- Set every `^present-id` to `k`. -/
def presentIs (k : Nat) (w : WME) : WME :=
  if w.attr == .str "present-id" then { w with val := .int k } else w

def St.epStore (s : St) : St :=
  let c := s.epConsider
  if !c.2 then { s with ep := c.1 } else
  let wm := s.wm
  let db := c.1.newEpisode (s.epAugs wm) (fun x => (s.ltiOf? x).getD 0) (wm.length + 2)
  { s with ep := db, arch := s.arch.map (presentIs db.time) }

/-- What episodic memory's response to one state's command changes. -/
structure EpDelta extends MemDelta where
  epMeta : List (Nat × List WME)
  epSnap : List (Nat × List WME)
  epLast : List (Nat × Nat)

def St.epDelta0 (s : St) : EpDelta :=
  { s.memDelta with epMeta := s.epMeta, epSnap := s.epSnap, epLast := s.epLast }

/-- Episodic memory's response to one state's command. A command is looked at again only when
something reachable from it has changed; the old result is then removed. The meta elements and
the retrieved episode are o-supported, made by an architectural instantiation whose conditions
are the command and cue elements. -/
def St.epDelta (s : St) (g : Goal) : EpDelta :=
  match s.epLinks g.id with
  | none => s.epDelta0
  | some (l, c, r) =>
    let wm := s.wm
    let seen := reachAll wm c
    let changed := match alGet s.epSnap g.id with
      | some p => !(p.all seen.contains && seen.all p.contains)
      | none => !seen.isEmpty
    if !changed then s.epDelta0 else
    let old := (alGet s.epMeta g.id).getD []
    let s0 := s.dropMemPrefs g.id old
    let epMeta := alErase s.epMeta g.id
    let epSnap := alSet s.epSnap g.id seen
    if seen.isEmpty then { s0.epDelta0 with epMeta := epMeta, epSnap := epSnap } else
    let augs := s.epAugs wm
    let out := s.ep.respond augs (augs c) r ((alGet s.epLast g.id).getD 0) s.nextId (s.wmaAct s.wmaS · true)
    let ltiOf := out.ltis.foldl (fun (l : List (Nat × Nat)) (p : Nat × Nat) =>
      if s.smem.ltis.contains p.2 then l.filter (·.1 != p.1) ++ [p] else l) s.ltiOf
    -- the conditions of Soar's architectural instantiation: the state's link, command and
    -- result elements, then the cue; with learning, the retrieval leaves an explanation record
    let links : List WME := [{ id := g.id, attr := "epmem", val := .id l }, { id := l, attr := "command", val := .id c },
                             { id := l, attr := "result", val := .id r }]
    let made := out.«meta» ++ out.ws
    let (xs, xn, key) :=
        if s.learning && g.level ≥ 2 && !made.isEmpty then
          ([s.memXInst g s!"x{s.xNext}m0" (links ++ out.cue) made], s.xNext + 1, s!"x{s.xNext}m0")
        else ([], s.xNext, "")
    let s1 := ({ s0 with nextId := out.next, xinsts := xs ++ s0.xinsts, xNext := xn } : St).memResults g (links ++ out.cue) made key
    { s1.epDelta0 with ltiOf := ltiOf, epMeta := alSet epMeta g.id out.«meta», epSnap := epSnap,
                       epLast := alSet s.epLast g.id out.last }

def St.epState (s : St) (g : Goal) : St :=
  let d := s.epDelta g
  { s.withMemDelta d.toMemDelta with epMeta := d.epMeta, epSnap := d.epSnap, epLast := d.epLast }

/-- Episodic memory at the end of the output phase (Soar's `epmem_go`): consider recording an
episode, then respond to commands from the bottom state up. -/
def St.epPass (s : St) : St :=
  if !s.epOn then s else
  let s := s.epStore
  let states := (s.goals.toArray.qsort (fun a b => a.level > b.level)).toList
  let r := states.foldl St.epState s
  let r := r.setWma (r.wmaPrefs s false r.wmaS)
  let u := r.wmPhase s
  (u.setWma (u.wmaNewWmes r u.wmaS)).spSync

/-! ## The decision procedure over the goal stack -/

/-- The operator preferences for state `g`, in the order they were asserted. -/
def St.prefsFor (s : St) (g : Nat) : List Pref :=
  (s.prefs.filter (fun p => p.id == g && isOpAttr p.attr)).map PRec.toPref

def defaultChoose : List Sym → Sym
  | x :: _ => x
  | [] => .nil

def impasseName : Impasse → String
  | .tie => "tie" | .conflict => "conflict" | .constraintFailure => "constraint-failure"
  | .stateNoChange => "no-change" | .operatorNoChange => "no-change"

/-- How Soar's trace names an impasse. -/
def impasseTrace : Impasse → String
  | .tie => "operator tie" | .conflict => "operator conflict"
  | .constraintFailure => "operator constraint-failure"
  | .stateNoChange => "state no-change" | .operatorNoChange => "operator no-change"

def choicesName : Impasse → String
  | .tie => "multiple" | .conflict => "multiple"
  -- [Man] §3.4.1 lists `constraint-failure`; Soar 9.6.5 creates `none` (checked 2026-10-28)
  | .constraintFailure => "none"
  | .stateNoChange => "none" | .operatorNoChange => "none"

/-- The links Soar 9.6.5 creates on every state for episodic memory, semantic memory and
reinforcement learning, starting at identifier `m` (uses 7 identifiers). They exist even when
those modules are disabled (checked 2026-10-28):
`(S ^epmem E) (E ^command C) (E ^result R) (E ^present-id 1) (S ^smem L) (L ^command C)
(L ^result R) (S ^reward-link R)`. -/
def stateLinks (s m : Nat) (present : Nat := 1) : List WME :=
  [ { id := s, attr := "epmem", val := .id m },
    { id := m, attr := "command", val := .id (m + 1) },
    { id := m, attr := "result", val := .id (m + 2) },
    { id := m, attr := "present-id", val := .int present },
    { id := s, attr := "smem", val := .id (m + 3) },
    { id := m + 3, attr := "command", val := .id (m + 4) },
    { id := m + 3, attr := "result", val := .id (m + 5) },
    { id := s, attr := "reward-link", val := .id (m + 6) } ]

/-- The `^item`, `^item-count`, `^non-numeric` and `^non-numeric-count` elements of an
impasse state. [Man] §3.4.1 describes `^non-numeric` for ties; Soar 9.6.5 also creates it for
conflict and constraint-failure impasses, with `^non-numeric-count` (checked 2026-10-28), and
remakes all four whenever the items change (`update_impasse_items`). -/
def impasseItems (n : Nat) (ps : List Pref) (items : List Sym) : List WME :=
  let itemW := items.map fun o => ({ id := n, attr := "item", val := o } : WME)
  let countW : List WME := if items.isEmpty then [] else
    [{ id := n, attr := "item-count", val := .int items.length }]
  let nn := items.filter (fun o => !has ps .numericIndiff o)
  let nonNum : List WME := if nn.isEmpty then [] else
    nn.map (fun o => ({ id := n, attr := "non-numeric", val := o } : WME)) ++
    [{ id := n, attr := "non-numeric-count", val := .int nn.length }]
  itemW ++ countW ++ nonNum

def isItemAttr (a : Sym) : Bool :=
  a == .str "item" || a == .str "item-count" || a == .str "non-numeric" || a == .str "non-numeric-count"

/-- Create a substate below goal `g` for an impasse. The structures created here are
procedural process data (DECIDED 2026-10-28).

> "^type state … ^impasse … ^choices … ^superstate … ^attribute … ^item … ^item-count …
> ^non-numeric … ^quiescence" — [Man] §3.4.1 -/
def St.createSubstate (s : St) (g : Goal) (k : Impasse) (attr : Sym) (items : List Sym) : St :=
  let n := s.nextId
  let ps := s.prefsFor g.id
  let base : List WME :=
    [ { id := n, attr := "type", val := "state" },
      { id := n, attr := "superstate", val := .id g.id },
      { id := n, attr := "impasse", val := .str (impasseName k) },
      { id := n, attr := "choices", val := .str (choicesName k) },
      { id := n, attr := "attribute", val := attr },
      { id := n, attr := "quiescence", val := "t" } ]
  { s with arch := s.arch ++ base ++ impasseItems n ps items ++ stateLinks n (n + 1) s.ep.time,
           goals := s.goals ++ [{ id := n, level := g.level + 1, impasse := some (k, attr, items) }],
           nextId := n + 8 }

def St.nameOf (s : St) (o : Sym) : String :=
  match o with
  | .id n => match s.wm.find? (fun w => w.id == n && w.attr == .str "name") with
    | some w => w.val.toSoar
    | none => s!"#{n}"
  | x => x.toSoar

/-- An operator's signature: its augmentations, sorted; an identifier value is shown by its
own augmentations one level down, and below that by its `^name`, or else by its
constant-valued augmentations (or `ID`). Used only to replay Soar's choices among mutually
indifferent operators. -/
def St.opSig (s : St) (o : Sym) : String :=
  let wm := s.wm
  let raw (v : Sym) : String := match v with
    | .str t => t
    | x => x.toSoar
  let nameOf (m : Nat) : String :=
    match wm.find? (fun w => w.id == m && w.attr == .str "name" && !w.acc) with
    | some w => raw w.val
    | none =>
      -- without a name: its constant-valued augmentations, if any (so that, say, two jugs
      -- of different volumes are told apart)
      let cs := (wm.filter (fun w => w.id == m && !w.acc && !(match w.val with | .id _ => true | _ => false))).map
        fun w => s!"{raw w.attr}={raw w.val}"
      if cs.isEmpty then "ID" else "{" ++ ",".intercalate (cs.toArray.qsort (· < ·)).toList ++ "}"
  let attrsOf (m : Nat) (val : Sym → String) : String :=
    let parts := (wm.filter (fun w => w.id == m && !w.acc)).map fun w => s!"{raw w.attr}={val w.val}"
    ",".intercalate (parts.toArray.qsort (· < ·)).toList
  let leaf (v : Sym) : String := match v with
    | .id m => nameOf m
    | x => raw x
  match o with
  | .id n => attrsOf n fun v => match v with
    | .id m => "{" ++ attrsOf m leaf ++ "}"
    | x => raw x
  | x => x.toSoar

/-- Indifferent selection, following a replay hint for this decision if there is one.

NOT FORMALIZED: the order in which Soar's `--first` policy considers mutually indifferent
candidates follows the matcher's internal order and is not specified by the manual. -/
def St.hinted (s : St) (choose : List Sym → Sym) (cands : List Sym) : Sym :=
  match s.hints.find? (·.1 == s.dc) with
  | some (_, h) => (cands.find? (fun o => s.opSig o == h)).getD (choose cands)
  | none => choose cands

/-- The choice among mutually indifferent candidates, if preference resolution needs one
(`tieCands`): a replay hint for this decision if there is one, else the exploration policy in
force, which may draw on the random-number generator. -/
def St.pickTie (s : St) (choose : List Sym → Sym) (ps : List Pref) (g : Nat) : St × Sym :=
  match tieCands ps with
  | none => (s, .nil)
  | some c =>
    let c := s.candOrder g c
    let cv := c.map fun o => (o, candValue s.explore.avg ps o)
    -- what reinforcement learning needs of the choice (`exploration_choose_according_to_policy`)
    let tie (o : Sym) : Option (Float × Bool × Bool × Float) :=
      match cv with
      | [] => none
      | (_, v₀) :: _ =>
        let top := cv.foldl (fun a (_, v) => if v > a then v else a) v₀
        -- `top_rl`: whether RL rules contributed to the first candidate with the highest value
        let first := (cv.find? (·.2 == top)).map (·.1)
        let topRL := first.any fun f => (s.prefs.any fun p => p.id == g && isOpAttr p.attr &&
          p.kind == .numericIndiff && p.val == f && ((s.instById p.inst).map (fun i => s.isRLRule i.name)).getD false)
        let ov := ((alGet cv o)).getD 0
        some (top, topRL, ov == top, if s.rl.policy == RLPolicy.offGQ then s.explore.rho cv o else 1.0)
    match s.hints.find? (·.1 == s.dc) with
    | some _ => let o := s.hinted choose c; ({ s with rlTie := tie o }, o)
    | none =>
      let (o, r) := s.explore.select choose ps c s.rng
      ({ s with rng := r, rlTie := tie o,
                firings := if s.verbose then s.firings ++ [s!"{s.dc} candidates {c.map s.opSig}"] else s.firings }, o)

/-- The winning preference for a selected operator: the first require preference for it in slot
order, else the first acceptable one (Soar's candidate for the context slot). -/
def St.winPref (s : St) (g : Nat) (o : Sym) : Option PRec :=
  let same (k : PrefKind) : List PRec := s.prefs.filter fun p => p.id == g && isOpAttr p.attr && p.val == o && p.kind == k
  firstPref (same .require) <|> firstPref (same .acceptable)

/-- Is a state's operator slot decidable (Soar 9.6.5 `context_slot_is_decidable`): no operator
selected, and its preferences changed? -/
def St.decidable (s : St) (g : Goal) : Bool := (s.selected g.id).isNone && s.ctxChanged.contains g.id

def St.logImpasse (s : St) (k : Impasse) : St :=
  { s with log := s.log ++ [s!"{s.dc}: ==>S: S{s.nextId - 1} ({impasseTrace k})"] }

/-- Make the substate for a new impasse (Soar 9.6.5 `decide_context_slot`, `create_new_context`):
with `soar wait-snc on`, a state no-change makes none (the state waits); a no-change substate
deeper than `max-goal-depth` halts the agent. -/
def St.newImpasse (s : St) (g : Goal) (k : Impasse) (attr : Sym) (items : List Sym) : St :=
  if s.waitSnc && k == .stateNoChange then
    -- Soar's trace prints the lowest context after the decision: the waiting state's own
    -- impasse, if it is a substate
    match g.impasse with
    | some (k', _, _) => { s with log := s.log ++ [s!"{s.dc}: ==>S: S{g.id} ({impasseTrace k'})"] }
    | none => s
  else
  let t := (s.createSubstate g k attr items).logImpasse k
  if (k == .stateNoChange || k == .operatorNoChange) && g.level + 1 > s.maxGoalDepth then
    { t with halted := true, out := t.out ++ [s!"Goal stack depth exceeded {s.maxGoalDepth} on a no-change impasse."] }
  else t

/-- An impasse for state `g`: if the substate `child` already has this impasse, its items are
updated and the decision continues below (`.inr`); otherwise the substate (and those below it)
is replaced by a new one (`.inl`). -/
def St.decideImpasse (s : St) (g : Goal) (child : Option Goal) (k : Impasse) (attr : Sym)
    (items : List Sym) : St ⊕ St :=
  -- (an operator no-change keeps the operator and its selection knowledge)
  let s : St := if (s.selected g.id).isSome then s else { s with osk := s.osk.filter (·.1 != g.id) }
  match child with
  | some c =>
    if c.impasse.map (fun (k', a', _) => (k', a')) == some (k, attr) then
      -- the same impasse persists: update its items and look further down
      -- (`update_impasse_items` keeps the items still there but always makes the counts again,
      -- so they are new elements)
      let isCount (w : WME) : Bool := w.id == c.id && (w.attr == .str "item-count" || w.attr == .str "non-numeric-count")
      .inr { s with
        arch := (s.arch.filter (fun (w : WME) => !(w.id == c.id && isItemAttr w.attr))) ++
                impasseItems c.id (s.prefsFor g.id) items,
        tt := if s.reteOn then s.tt.filter (fun (w, _) => !isCount w) else s.tt,
        goals := s.goals.map (fun g' => if g'.id == c.id then { g' with impasse := some (k, attr, items) } else g') }
    else
      .inl ((s.removeGoalsFrom (g.level + 1)).newImpasse g k attr items)
  | none => .inl (s.newImpasse g k attr items)

/-- Select operator `o` for state `g` (Soar 9.6.5 `decide_context_slot` with a winner): the RL
update, removal of the substates below, the operator selection, and its operator selection
knowledge and winning preference. -/
def St.decideSelect (s : St) (g : Goal) (o : Sym) : St :=
  let e := s.oskEntry g o
  let wp := s.winPref g.id o
  -- RL update before the old substates are removed (Soar 9.6.5 `decide_context_slot`)
  let t := ((s.rlSelect g.id o).removeGoalsFrom (g.level + 1))
  { t with arch := t.arch ++ [{ id := g.id, attr := "operator", val := o }],
           log := t.log ++ [s!"{t.dc}: O: {t.nameOf o}"],
           osk := e ++ t.osk.filter (fun x => x.1 != g.id && t.isGoal x.1),
           opPref := ((wp.map (·.pid)).map (g.id, ·)).toList ++ t.opPref.filter (·.1 != g.id),
           opUid := (((wp.bind (fun p => s.instById p.inst)).map (·.uid)).map (g.id, ·)).toList ++
                    t.opUid.filter (·.1 != g.id),
           firings := if t.verbose then t.firings ++ [s!"{t.dc} selected {t.opSig o}"] else t.firings }

/-- Decide state `g`'s slot: by the preference semantics if it is decidable, else (the bottom
state) a no-change impasse — an operator no-change if it has an operator, a state no-change
if not. -/
def St.decideSlot (s : St) (choose : List Sym → Sym) (g : Goal) (child : Option Goal) (dec : Bool) : St ⊕ St :=
  if !dec then
    if (s.selected g.id).isSome then s.decideImpasse g child .operatorNoChange "operator" []
    else s.decideImpasse g child .stateNoChange "state" []
  else
  let ps := s.prefsFor g.id
  let s := s.pickTie choose ps g.id
  match resolve (fun _ => s.2) ps with
  | .winner o => .inl (s.1.decideSelect g o)
  | .impasse .stateNoChange _ => s.1.decideImpasse g child .stateNoChange "state" []
  | .impasse k items => s.1.decideImpasse g child k "operator" items

/-- **The decision phase** (Soar 9.6.5 `decide_context_slots`, `decide_context_slot`). Starting
at the highest state whose operator preferences changed since the last decision (or at the
bottom state), the first state whose slot is decidable — no operator selected and changed
preferences — is decided by the preference semantics; states that are not decidable are
passed over. If none is, the bottom state has a no-change impasse: an operator no-change if it
has an operator, a state no-change if not. An impasse that persists in the substate already
there only updates its items, and the decision continues below.

> "for (each state in the stack, starting with the top-level state) until (a new decision is
> reached) EvaluateOperatorPreferences; if (one operator preferred after preference
> evaluation) SelectNewOperator; else CreateNewSubstate;" — [Man] Figure 2.10 -/
def St.decide (s : St) (choose : List Sym → Sym) : St :=
  { decide.go choose s.goals.length (match s.ctxTop with
      | some t => t
      | none => (s.goals.map (·.level)).foldl max 1) s with ctxTop := none }
where
  go (choose : List Sym → Sym) : Nat → Nat → St → St
  | 0, _, s => s
  | fuel + 1, lv, s =>
    match s.goals.find? (·.level == lv) with
    | none => s
    | some g =>
      if !s.decidable g && (s.goals.find? (·.level == lv + 1)).isSome then go choose fuel (lv + 1) s else
      match ({ s with ctxChanged := s.ctxChanged.filter (· != g.id) } : St).decideSlot choose g
              (s.goals.find? (·.level == lv + 1)) (s.decidable g) with
      | .inl t => t
      | .inr t => go choose fuel (lv + 1) t

/-- Is a state's decision still consistent with its preferences? (Soar 9.6.5
`decision_consistent_with_current_preferences`.) The preference semantics is run again: the
kind of outcome must be the same as the current one (an operator, or an impasse of the same
type; an operator no-change impasse counts as an operator), and a current operator must still
be among the winners. A no-change impasse without an operator is never consistent with a run
of the semantics, which reports no impasse when there are no candidates. -/
def St.decisionConsistent (s : St) (g : Goal) (choose : List Sym → Sym) : Bool :=
  let cur := s.selected g.id
  let child := s.goals.find? (·.level == g.level + 1)
  let curT : Option Impasse := match child.bind (·.impasse) with
    | some (k, _, _) =>
      if cur.isSome && (k == .operatorNoChange || k == .stateNoChange) then none else some k
    | none => none
  let keepCur (l : List Sym) : Sym := match cur with
    | some c => if l.contains c then c else choose l
    | none => choose l
  match resolve keepCur (s.prefsFor g.id) with
  | .winner o => curT.isNone && (match cur with | some c => o == c | none => child.isNone)
  | .impasse .stateNoChange _ => curT.isNone && cur.isNone && child.isNone
  | .impasse k _ => curT == some k && k != .operatorNoChange

/-- **The consistency check** through level `L` (Soar 9.6.5 `check_context_slot_decisions`): from
the highest state whose operator preferences changed, down to `L`, a state with an operator or
a substate whose preferences changed must still be consistent with them; the first that is not
loses its operator and substates (`remove_current_decision`), and the check fails. -/
def St.consistentThrough (s : St) (L : Nat) (choose : List Sym → Sym) : St × Bool :=
  match s.ctxTop with
  | none => (s, true)
  | some top =>
    let gs := s.goals.filter (fun g => g.level ≥ top && g.level ≤ L)
    match gs.find? (fun g => ((s.goals.any (·.level == g.level + 1)) || (s.selected g.id).isSome) &&
                             s.ctxChanged.contains g.id && !s.decisionConsistent g choose) with
    | some g => ((s.removeOperator g).sync 4, false)
    | none => (s, true)

/-- What the control of a phase does next: stop the phase, or run an elaboration cycle at a
level with a kind of firing. -/
inductive Next where
  | stop (s : St)
  | fire (s : St) (H : Nat) (ft : Firing) (pd : Pend)

/-- Is there activity at level `l` for phase `ph`? -/
def Pend.active (pd : Pend) (ph : Phase) (l : Nat) : Bool := pd.iAct l || (ph == .apply && pd.oAct l)

/-- The kind of firing at level `l` (`active_production_type_at_goal`). -/
def Pend.typeAt (pd : Pend) (ph : Phase) (l : Nat) : Firing := if ph == .propose || pd.iAct l then .ie else .pe

/-- Minor quiescence at level `l` after firing of kind `t`. -/
def Pend.minorQ (pd : Pend) (l : Nat) (t : Firing) : Bool := t == .ie && !pd.iAct l

/-- A consistency check through level `L` when `c` holds. -/
def St.checkIf (s : St) (c : Bool) (L : Nat) (choose : List Sym → Sym) : St × Bool :=
  if c then s.consistentThrough L choose else (s, true)

/-- Fire at `H` if a consistency check passed, else stop. -/
def Next.after (r : St × Bool) (H : Nat) (ft : Firing) (pd : Pend) : Next :=
  if r.2 then .fire r.1 H ft pd else .stop r.1

def St.logMaxElab (s : St) : St := { s with log := s.log ++ [s!"{s.dc}: max-elaborations reached"] }

def St.saveFT (s : St) (prev : Nat) (ft : Firing) : St :=
  { s with goals := s.goals.map fun (g : Goal) => if g.level == prev then { g with savedFT := some ft } else g }

/-- Activity moved to a lower state (the previous level `prev` had minor quiescence, or this is
the proposal phase): a consistency check, then the kind of firing the state resumes. -/
def St.lowerRest (r : St × Bool) (pd : Pend) (ph : Phase) (H : Nat) (choose : List Sym → Sym) : Next :=
  if !r.2 then .stop r.1 else
  match ph, (r.1.goals.find? (·.level == H)).bind (·.savedFT) with
  | .apply, some t => Next.after (r.1.checkIf (pd.minorQ H t) H choose) H (pd.typeAt ph H) pd
  | _, _ => .fire r.1 H (pd.typeAt ph H) pd

def St.lowerStep (s : St) (pd : Pend) (ph : Phase) (prev H : Nat) (ft : Firing) (choose : List Sym → Sym) : Next :=
  St.lowerRest (s.checkIf (ph == .propose || pd.minorQ prev ft) prev choose) pd ph H choose

/-- The highest level with activity. -/
def St.highest (s : St) (pd : Pend) (ph : Phase) : Nat :=
  ((s.goals.map (·.level)).filter (pd.active ph)).foldl min 1000000

/-- The bottom level. -/
def St.bottom (s : St) : Nat := (s.goals.map (·.level)).foldl max 1

/-- `St.determine` once the pending changes `pd` are known. -/
def St.determineIn (s : St) (pd : Pend) (ph : Phase) (prev : Nat) (ft : Firing)
    (n maxElab : Nat) (choose : List Sym → Sym) : Next :=
  if !((s.goals.map (·.level)).any (pd.active ph)) then
    .stop (s.checkIf (pd.minorQ s.bottom ft) s.bottom choose).1
  else if n ≥ maxElab then .stop s.logMaxElab
  else if prev == 0 then .fire s (s.highest pd ph) (pd.typeAt ph (s.highest pd ph)) pd
  else if s.highest pd ph > prev then s.lowerStep pd ph prev (s.highest pd ph) ft choose
  else if s.highest pd ph == prev then
    Next.after (s.checkIf (ph == .apply && pd.minorQ (s.highest pd ph) ft) (s.highest pd ph) choose)
      (s.highest pd ph) (pd.typeAt ph (s.highest pd ph)) pd
  -- activity moved to a higher state: the interrupted kind of firing is saved
  else Next.after ((s.saveFT prev ft).consistentThrough (s.highest pd ph) choose) (s.highest pd ph)
      (pd.typeAt ph (s.highest pd ph)) pd

/-- Find the highest state with activity and the kind of firing, with the consistency checks
at minor quiescence and on changes of level (Soar 9.6.5
`determine_highest_active_production_level_in_stack_propose` and `…_apply`). `prev` is the
level of the previous elaboration cycle (0 at the start of the phase) and `ft` its kind; `n`
counts the phase's elaboration cycles.

* The proposal phase fires only i-supported activity (`IE`). It ends at quiescence (after a
  consistency check of the whole stack), at `max-elaborations`, or when a consistency check
  fails.
* The application phase chooses, at the highest state with activity, `IE` if that state has
  i-supported activity and `PE` otherwise; a state whose firing was interrupted by activity
  above resumes it. It ends at quiescence, at `max-elaborations`, or when a consistency check
  fails.
* A consistency check is made before firing at a higher level than the previous cycle, and at
  minor quiescence: after `IE` firing at a state that has no i-supported activity left. -/
def St.determine (s : St) (pm : List Production) (ph : Phase) (prev : Nat) (ft : Firing)
    (n maxElab : Nat) (choose : List Sym → Sym) : Next :=
  let s := s.retag.reteSync pm
  let pd := s.pending pm
  let s := s.reteNote pd
  St.determineIn s (s.reteOrder pd) ph prev ft n maxElab choose

/-- Record the kind of the elaboration cycle about to run (Soar's `FIRING_TYPE`). -/
def St.setFiring (s : St) (ft : Firing) : St := { s with firing := ft }

/-- The elaboration cycles of a phase, under `St.determine`; after each, semantic memory's
storage pass. A `halt` stops the phase after the elaboration cycle in which it fired. -/
def St.phaseLoop (pm : List Production) (ph : Phase) (choose : List Sym → Sym) (maxElab : Nat) :
    Nat → St → Nat → Firing → Nat → St
  | 0, s, _, _, _ => s
  | fuel + 1, s, prev, ft, n =>
    match s.determine pm ph prev ft n maxElab choose with
    | .stop s => s
    | .fire s H ft pd =>
      let s := ((s.setFiring ft).elabCycle ph ft H pd).trackSlots.smemPass true
      if s.halted then s else St.phaseLoop pm ph choose maxElab fuel s H ft (n + 1)

/-- The proposal phase: i-supported elaboration cycles to quiescence, with Soar's limit on
elaboration cycles (`max-elaborations`, default 100). -/
def St.propose (s : St) (pm : List Production) (choose : List Sym → Sym) (maxElab : Nat) : St :=
  let s := { s with goals := s.goals.map ({ · with savedFT := none }), firing := .ie }
  St.phaseLoop pm .propose choose maxElab (maxElab + 2) s 0 .ie 0

/-- The application phase: elaboration cycles to quiescence, firing the o-supported
instantiations that apply the selected operators and the i-supported activity that follows.
Once a state's operator is removed, instantiations that tested it no longer match, so no
further o-supported firing applies it.

> "if, during the Apply phase, the production(s) that proposed the selected operator
> retract, that Apply phase will immediately end." — [Man] §2.5
>
> Soar 9.6.5 does not end the phase immediately: the operator is removed and the phase goes on
> (`remove_operator_if_necessary`); it ends when a consistency check fails, or at quiescence
> (checked 2026-10-28). -/
def St.apply (s : St) (pm : List Production) (choose : List Sym → Sym)
    (maxElab : Nat := 100) : St :=
  let s := { s with goals := s.goals.map ({ · with savedFT := none }), firing := .pe }
  St.phaseLoop pm .apply choose maxElab (maxElab + 2) s 0 .pe 0

/-! ## Input, output and the cycle -/

/-- The environment: given the decision count and the current output-link contents, the
elements to place on the input link (replacing the previous ones). Identifiers it creates
should come from a range the agent does not use. -/
structure Env where
  input : Nat → List WME → List WME := fun _ _ => []

def topIO : Nat := 2
def inputLink : Nat := 3
def outputLink : Nat := 4

/-- The initial state.

> "The initial state, created in the 0th decision cycle, contains a superstate attribute
> with the value of nil" — [Man] §2.7.2; "By default, the architecture creates an input-link
> attribute of the io object and an output-link attribute of the io object." — [Man] §3.5.2 -/
def St.init : St :=
  { arch := [ { id := 1, attr := "type", val := "state" },
              { id := 1, attr := "superstate", val := .nil },
              { id := 1, attr := "io", val := .id topIO },
              { id := topIO, attr := "input-link", val := .id inputLink },
              { id := topIO, attr := "output-link", val := .id outputLink } ] ++ stateLinks 1 5,
    goals := [{ id := 1, level := 1 }],
    nextId := 12 }

def St.output (s : St) : List WME :=
  let wm := s.wm
  let ids := reach wm [outputLink]
  wm.filter (fun w => ids.contains w.id && w.id != outputLink || w.id == outputLink)

/-- **Input and proposal** (the first part of `St.cycle`): the input phase gives the agent the
input `inp`, the first cycle numbers the initial elements as Soar does, the goal dependency sets
are checked, and rules fire to quiescence. -/
def St.cycleElab (s : St) (inp : List WME) (pm : List Production) (choose : List Sym → Sym)
    (maxElab : Nat) : St :=
  let s0 := s
  let s := { s with input := inp, dc := s.dc + 1 }
  let s := s.gc.gdsCheck
  -- the initial elements, numbered as Soar numbers them
  let s := if s0.tNext == 1 && s.reteOn then s.soarRetag s0 [] else s
  let s := s.spSync
  s.propose pm choose maxElab

/-- With learning on, each decision phase refreshes which rules are RL rules: those of the
program and the generated ones (`rlGen`) that already were; the records of the rest keep their
learned values but lose their initial value. -/
def St.rlReinit (s : St) (pm : List Production) : St :=
  let inits := pm.filterMap (fun (p : Production) => p.rlInit?.map (p.name, ·)) ++
    s.rlGen.filterMap (fun (p : Production) => ((s.rlEntry p.name).bind (·.init)).map (p.name, ·))
  let cleared := s.rlTab.map fun (n, e) => (n, { e with init := none })
  let setInit (t : List (String × RLEntry)) (nv : String × Float) :=
    alPut t nv.1 { (alGet t nv.1).getD {} with init := some nv.2 }
  { s with rlTab := inits.foldl setInit cleared }

/-- **Decision** (the second part of `St.cycle`): the decision phase and the working-memory
phase after it. -/
def St.cycleDec (s : St) (pm : List Production) (choose : List Sym → Sym) : St :=
  let s := if s.rl.learning then s.rlReinit pm else s
  let s := ((s.decide choose).wmPhase s).spSync
  -- exploration parameters are reduced after each decision phase
  { s with explore := s.explore.update }

/-- **Application and output** (the last part of `St.cycle`). -/
def St.cycleApply (s : St) (pm : List Production) (choose : List Sym → Sym) (maxElab : Nat) : St :=
  -- a halt in the decision phase (max-goal-depth) stops the run at once
  if s.halted then s else
  -- episodic memory runs here with `phase selection`
  let s := if s.ep.phaseSel then s.epPass else s
  let s := s.apply pm choose maxElab
  -- output phase: semantic-memory retrievals, then episodic memory; with working-memory
  -- activation, histories are updated before and after episodic memory (which sees the
  -- next cycle's activations), then forgetting (Soar 9.6.5 `do_one_top_level_phase`)
  if s.halted || s.stopped then s else
  let s := s.smemPass false
  let s := s.setWma (s.wmaHistories s.wmaS)
  let s := if s.ep.phaseSel || !s.epOn then s else
    let s := s.setWma ({ s.wmaS with cycle := s.wmaS.cycle + 1 })
    let s := s.epPass
    s.setWma ({ s.wmaS with cycle := s.wmaS.cycle - 1 })
  let s := s.setWma (s.wmaHistories s.wmaS)
  let s := s.wmaForget
  s.setWma ({ s.wmaS with cycle := s.wmaS.cycle + 1 })

/-- Everything after the proposal phase. -/
def St.cycleRest (s : St) (pm : List Production) (choose : List Sym → Sym) (maxElab : Nat) : St :=
  (s.cycleDec pm choose).cycleApply pm choose maxElab

/-- One decision cycle given the input of its input phase (`St.cycle` with `env.input` evaluated). -/
def St.cycleFrom (s : St) (inp : List WME) (pm : List Production) (choose : List Sym → Sym)
    (maxElab : Nat) : St :=
  let s := s.cycleElab inp pm choose maxElab
  -- the rest of the cycle uses the agent's own limit (`maxElab` limits the proposal phase; nothing
  -- before it changes the agent's limit, and `St.run` passes it)
  if s.halted || s.stopped then s else s.cycleRest pm choose s.maxElab

/-- One decision cycle: input, proposal, decision, application, output.

> "Each cycle has five phases: Input … Proposal … Decision … Application … Output" —
> [Man] §2.5 -/
def St.cycle (s : St) (pm : List Production) (env : Env)
    (choose : List Sym → Sym := defaultChoose) (maxElab : Nat := 100) : St :=
  s.cycleFrom (env.input s.dc s.output) pm choose maxElab

/-- Reinforcement learning when the agent halts: rewards present are collected and the last
RL operator of each state is updated, with a future Q-value of 0.

> "Reward is also collected when the agent is halted or a state is retracted." — [Man] §5.2

The manual does not say how the halt update is made. Checked against Soar 9.6.5
(2026-10-29): both the expected current reward and the expected future reward are updated
(unlike state retraction, which updates only the expected current reward). -/
def St.rlHalt (s : St) (updEfr : Bool := true) : St :=
  if !s.rl.learning then s else
  let s := s.rlTabulate
  s.goals.foldl (fun (s : St) g => s.rlUpdate g.id 0 true updEfr) s

def St.run (s : St) (pm : List Production) (env : Env := {}) (n : Nat)
    (choose : List Sym → Sym := defaultChoose) : St :=
  match n with
  | 0 => s
  | k + 1 =>
    if s.halted || s.stopped then s else
    let s' := s.cycle pm env choose s.maxElab
    if s'.halted then s'.rlHalt else if s'.stopped then s' else s'.run pm env k choose

/-- `St.run` without the reinforcement-learning update at a halt: the cycles that `n` CMC cycles
of the Soar instance perform (`Conform.runCMC_pst`). -/
def St.runN (s : St) (pm : List Production) (env : Env := {}) (n : Nat)
    (choose : List Sym → Sym := defaultChoose) : St :=
  match n with
  | 0 => s
  | k + 1 =>
    if s.halted || s.stopped then s else
    (s.cycle pm env choose s.maxElab).runN pm env k choose

theorem St.runN_stopped (pm : List Production) (env : Env) (choose : List Sym → Sym) (s : St)
    (h : (s.halted || s.stopped) = true) : ∀ n, s.runN pm env n choose = s := by
  intro n; cases n <;> simp [St.runN, h]

/-- Until the agent halts, `St.run` is `St.runN`. -/
theorem St.run_eq_runN (pm : List Production) (env : Env) (choose : List Sym → Sym) :
    ∀ (n : Nat) (s : St), (s.runN pm env n choose).halted = false →
      s.run pm env n choose = s.runN pm env n choose
  | 0, s, _ => rfl
  | k + 1, s, h => by
    unfold St.run St.runN at *
    by_cases h1 : (s.halted || s.stopped) = true
    · simp [h1]
    · simp only [h1, Bool.false_eq_true, ite_false] at h ⊢
      generalize s.cycle pm env choose s.maxElab = s' at h ⊢
      by_cases h2 : s'.halted = true
      · cases k <;> simp [St.runN, h2] at h
      · simp only [h2, Bool.false_eq_true, ite_false]
        by_cases h3 : s'.stopped = true
        · cases k <;> simp [St.runN, h3]
        · simp only [h3, Bool.false_eq_true, ite_false]
          exact St.run_eq_runN pm env choose k s' (by simpa [St.runN, h2, h3] using h)

end Soar
