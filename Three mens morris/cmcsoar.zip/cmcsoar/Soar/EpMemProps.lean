import Soar.Cycle
/-!
# Soar 9.6 — properties of episodic memory

* Responding to a command (any retrieval) changes no stored episode — the store is not
  touched at all — and changes no architecture-created element or the goal stack.
* Recording an episode changes only the `^present-id` elements among the architecture-created
  ones, and never the goal stack.
* Recording an episode never changes an earlier episode: the store only grows at the present.
-/

namespace Soar

/-- **Retrieval changes no stored episode.** Episodic memory's response to a state's command
— a retrieval by number, by temporal neighbour or by cue — leaves the episode store exactly as
it was, and changes neither architecture-created elements nor the goal stack.

This is the CMC's requirement that retrieval only read declarative memory. (Unlike semantic
memory's, an episodic retrieval does not even change metadata in the store: the only thing
remembered is the state's last retrieved episode, for `^next` and `^previous`.) -/
theorem St.epState_store (s : St) (g : Goal) :
    (s.epState g).ep = s.ep ∧ (s.epState g).arch = s.arch ∧ (s.epState g).goals = s.goals :=
  ⟨rfl, rfl, rfl⟩

/-- **Recording an episode changes only `^present-id`.** Among architecture-created elements,
recording changes only the value of each state's `^present-id`; the goal stack is unchanged. -/
theorem St.epStore_arch (s : St) :
    (s.epStore).arch.map (fun w => (w.id, w.attr)) = s.arch.map (fun w => (w.id, w.attr)) ∧
    (∀ w ∈ (s.epStore).arch, w.attr ≠ .str "present-id" → w ∈ s.arch) ∧
    (s.epStore).goals = s.goals := by
  unfold St.epStore
  dsimp only
  split
  · exact ⟨rfl, fun w hw _ => hw, rfl⟩
  · refine ⟨?_, ?_, rfl⟩
    · simp only [List.map_map]
      congr 1; funext w; simp only [Function.comp, presentIs]; split <;> rfl
    · intro w hw hne
      simp only [List.mem_map] at hw
      obtain ⟨w', hw', rfl⟩ := hw
      unfold presentIs at hne ⊢
      split
      · rename_i h; simp only [beq_iff_eq] at h; simp [h] at hne
      · exact hw'

/-! ## Recording never changes the past -/

namespace EpDB

def sig (e : EEdge) : Nat × Sym × EVal := (e.parent, e.attr, e.child)

/-- Two edge lists record the same episodes before `T`. -/
def Same (T : Nat) (l l' : List EEdge) : Prop :=
  ∀ t, t < T → (l'.filter (·.at t)).map sig = (l.filter (·.at t)).map sig

theorem Same.refl (T : Nat) (l : List EEdge) : Same T l l := fun _ _ => rfl

theorem Same.trans {T : Nat} {a b c : List EEdge} (h₁ : Same T a b) (h₂ : Same T b c) : Same T a c :=
  fun t ht => (h₂ t ht).trans (h₁ t ht)

theorem Same.push {T : Nat} (l : List EEdge) (e : EEdge) (h : ∀ t, t < T → e.at t = false) :
    Same T l (l ++ [e]) := by
  intro t ht
  simp [List.filter_append, h t ht]

/-- An edge change that keeps an edge's identity and its presence in every episode before `T`. -/
def Agrees (T : Nat) (f : EEdge → EEdge) : Prop :=
  ∀ e, sig (f e) = sig e ∧ ∀ t, t < T → (f e).at t = e.at t

theorem Same.modAt {T : Nat} {f : EEdge → EEdge} (hf : Agrees T f) :
    ∀ (l : List EEdge) (i : Nat), Same T l (Soar.EpDB.modAt f l i)
  | [], _ => Same.refl T []
  | e :: l, 0 => by
    intro t ht
    obtain ⟨h1, h2⟩ := hf e
    simp only [Soar.EpDB.modAt, List.filter_cons, h2 t ht]
    split <;> simp [h1]
  | e :: l, i + 1 => by
    intro t ht
    have ih := Same.modAt hf l i t ht
    simp only [Soar.EpDB.modAt, List.filter_cons]
    split <;> simp [ih]

theorem agrees_openAt (T : Nat) : Agrees T (openAt T) := by
  intro e
  unfold openAt
  split
  · exact ⟨rfl, fun _ _ => rfl⟩
  · rename_i h
    refine ⟨rfl, fun t ht => ?_⟩
    simp only [EEdge.at, h]
    have : decide (T ≤ t) = false := by simp; omega
    simp [this]

theorem agrees_openAt' (T : Nat) : Agrees T (fun e => { openAt T e with lastEp := epInf }) := by
  intro e
  obtain ⟨h1, h2⟩ := agrees_openAt T e
  exact ⟨h1, fun t ht => h2 t ht⟩

theorem agrees_closeAt (T : Nat) : Agrees T (closeAt T) := by
  intro e
  unfold closeAt
  split
  · rename_i s h
    refine ⟨rfl, fun t ht => ?_⟩
    simp only [EEdge.at, h, List.any_cons]
    by_cases hs : s ≤ t
    · have : t ≤ T - 1 := by omega
      simp [hs, this]
    · simp [hs]
  · exact ⟨rfl, fun _ _ => rfl⟩

theorem agrees_closeAt' (T : Nat) (k : Int) : Agrees T (fun e => { closeAt T e with lastEp := k }) := by
  intro e
  obtain ⟨h1, h2⟩ := agrees_closeAt T e
  exact ⟨h1, fun t ht => h2 t ht⟩

theorem agrees_openLti (T l : Nat) : Agrees T (fun e => { openLti T l e with lastEp := epInf }) := by
  intro e
  refine ⟨?_, fun t ht => ?_⟩
  · cases hn : e.now <;> simp [openLti, hn, sig]
  · cases hn : e.now with
    | some s => simp [openLti, hn, EEdge.at]
    | none =>
      have : decide (T ≤ t) = false := by simp; omega
      simp [openLti, hn, EEdge.at, this]

theorem agrees_closeLti (T l : Nat) (k : Int) : Agrees T (fun e => { closeLti T l e with lastEp := k }) := by
  intro e
  refine ⟨?_, fun t ht => ?_⟩
  · cases hn : e.now <;> simp [closeLti, hn, sig]
  · cases hn : e.now with
    | none => simp [closeLti, hn, EEdge.at]
    | some s =>
      simp only [closeLti, hn, EEdge.at, List.any_cons]
      by_cases hs : s ≤ t
      · have : t ≤ T - 1 := by omega
        simp [hs, this]
      · simp [hs]

theorem agrees_unmax (T : Nat) : Agrees T (fun e => { e with maxed := false }) :=
  fun _ => ⟨rfl, fun _ _ => rfl⟩

/-- `db'` records the same episodes before `T` as `db`. -/
def Keeps (T : Nat) (db db' : EpDB) : Prop := Same T db.wis db'.wis ∧ Same T db.wcs db'.wcs

theorem Keeps.refl (T : Nat) (db : EpDB) : Keeps T db db := ⟨Same.refl _ _, Same.refl _ _⟩

theorem Keeps.trans {T : Nat} {a b c : EpDB} (h₁ : Keeps T a b) (h₂ : Keeps T b c) : Keeps T a c :=
  ⟨h₁.1.trans h₂.1, h₁.2.trans h₂.2⟩

theorem Keeps.ofEq {T : Nat} {a b : EpDB} (h₁ : b.wis = a.wis) (h₂ : b.wcs = a.wcs) : Keeps T a b := by
  unfold Keeps; rw [h₁, h₂]; exact Keeps.refl T a

theorem takePool_edges (db : EpDB) (k : Nat × Sym) (p : Nat × Nat → Bool) :
    (db.takePool k p).1.wis = db.wis ∧ (db.takePool k p).1.wcs = db.wcs := by
  unfold takePool; dsimp only; split_rfl

theorem reserve_edges (pid : Nat) (acc : StoreAcc) (w : WME) :
    (reserve pid acc w).db.wis = acc.db.wis ∧ (reserve pid acc w).db.wcs = acc.db.wcs := by
  unfold reserve
  split
  · exact ⟨rfl, rfl⟩
  · split
    · split
      · split
        · exact ⟨rfl, rfl⟩
        · exact takePool_edges _ _ _
      · exact ⟨rfl, rfl⟩
    · exact ⟨rfl, rfl⟩

theorem reuseKnown_edges (acc : StoreAcc) (w : WME) (key : Nat × Sym) (n : Nat) :
    (reuseKnown acc w key n).1.db.wis = acc.db.wis ∧ (reuseKnown acc w key n).1.db.wcs = acc.db.wcs := by
  unfold reuseKnown
  split
  · split_rfl
  · dsimp only
    split <;> exact takePool_edges _ _ _

theorem reuseNew_edges (acc : StoreAcc) (x : Nat) (key : Nat × Sym) :
    (reuseNew acc x key).1.db.wis = acc.db.wis ∧ (reuseNew acc x key).1.db.wcs = acc.db.wcs := by
  unfold reuseNew
  dsimp only
  split <;> exact takePool_edges _ _ _

theorem ensureNode_edges (db : EpDB) (x : Nat) : (ensureNode db x).wis = db.wis ∧ (ensureNode db x).wcs = db.wcs := by
  unfold ensureNode; split_rfl

theorem fresh_new (e : EEdge) (h₁ : e.now = none) (h₂ : e.closed = []) : ∀ t, e.at t = false := by
  intro t; simp [EEdge.at, h₁, h₂]

theorem addIdEdge_keeps (T pid : Nat) (ltiOf : Nat → Nat) (acc : StoreAcc) (w : WME) (x : Nat)
    (key : Nat × Sym) (wid : Option Nat) : Keeps T acc.db (addIdEdge pid ltiOf acc w x key wid).db := by
  unfold addIdEdge
  split
  · dsimp only
    obtain ⟨h1, h2⟩ := ensureNode_edges acc.db x
    refine ⟨?_, ?_⟩
    · show Same T acc.db.wis ((ensureNode acc.db x).wis ++ _)
      rw [h1]; exact Same.push _ _ (fun t _ => fresh_new _ rfl rfl t)
    · show Same T acc.db.wcs (ensureNode acc.db x).wcs
      rw [h2]; exact Same.refl _ _
  · dsimp only
    split
    · exact ⟨Same.modAt (agrees_unmax T) _ _, Same.refl _ _⟩
    · exact Keeps.refl _ _

theorem noteId_edges (acc : StoreAcc) (w : WME) (x : Nat) :
    (noteId acc w x).db.wis = acc.db.wis ∧ (noteId acc w x).db.wcs = acc.db.wcs := by
  unfold noteId
  dsimp only
  by_cases h : acc.newIds.contains x = true
  · simp only [h, ite_true]; split_rfl
  · simp only [h, ite_false, Bool.false_eq_true]; split_rfl

theorem storeConst_keeps (T pid : Nat) (acc : StoreAcc) (w : WME) (c : Sym) :
    Keeps T acc.db (storeConst pid acc w c).db := by
  unfold storeConst
  dsimp only
  split
  · split
    · exact ⟨Same.refl _ _, Same.modAt (agrees_unmax T) _ _⟩
    · exact Keeps.refl _ _
  · exact ⟨Same.refl _ _, Same.push _ _ (fun t _ => fresh_new _ rfl rfl t)⟩

theorem storeOne_keeps (T pid : Nat) (ltiOf : Nat → Nat) (acc : StoreAcc) (w : WME) :
    Keeps T acc.db (storeOne pid ltiOf acc w).db := by
  unfold storeOne
  split
  · exact Keeps.refl _ _
  · split
    · exact Keeps.refl _ _
    · split
      · rename_i x _
        dsimp only
        have key : ∀ r : StoreAcc × Option Nat, r.1.db.wis = acc.db.wis ∧ r.1.db.wcs = acc.db.wcs →
            Keeps T acc.db (noteId (addIdEdge pid ltiOf r.1 w x (pid, hashOf w) r.2) w x).db := by
          intro r hr'
          obtain ⟨n1, n2⟩ := noteId_edges (addIdEdge pid ltiOf r.1 w x (pid, hashOf w) r.2) w x
          exact Keeps.trans (Keeps.ofEq hr'.1 hr'.2)
            (Keeps.trans (addIdEdge_keeps T pid ltiOf r.1 w x (pid, hashOf w) r.2) (Keeps.ofEq n1 n2))
        apply key
        split
        · exact reuseKnown_edges _ _ _ _
        · exact reuseNew_edges _ _ _
      · exact storeConst_keeps _ _ _ _ _

theorem foldl_reserve_edges (pid : Nat) (ws : List WME) (acc : StoreAcc) :
    (ws.foldl (reserve pid) acc).db.wis = acc.db.wis ∧ (ws.foldl (reserve pid) acc).db.wcs = acc.db.wcs :=
  foldl_rel (fun a b : StoreAcc => b.db.wis = a.db.wis ∧ b.db.wcs = a.db.wcs)
    (fun _ _ _ h1 h2 => ⟨h2.1.trans h1.1, h2.2.trans h1.2⟩) (fun _ => ⟨rfl, rfl⟩)
    (reserve pid) (fun acc w => reserve_edges pid acc w) ws acc

theorem foldl_storeOne_keeps (T pid : Nat) (ltiOf : Nat → Nat) (ws : List WME) (acc : StoreAcc) :
    Keeps T acc.db (ws.foldl (storeOne pid ltiOf) acc).db :=
  foldl_rel (fun a b : StoreAcc => Keeps T a.db b.db) (fun _ _ _ => Keeps.trans) (fun a => Keeps.refl _ _)
    (storeOne pid ltiOf) (fun acc w => storeOne_keeps T pid ltiOf acc w) ws acc

theorem storeLevel_keeps (T pid : Nat) (ltiOf : Nat → Nat) (acc : StoreAcc) (ws : List WME) :
    Keeps T acc.db (storeLevel pid ltiOf acc ws).db := by
  unfold storeLevel
  obtain ⟨a, b⟩ := foldl_reserve_edges pid ws acc
  exact (Keeps.ofEq a b).trans (foldl_storeOne_keeps T pid ltiOf ws _)

theorem storeBfs_keeps (T : Nat) (augs : Nat → List WME) (ltiOf : Nat → Nat) :
    ∀ (f : Nat) (acc : StoreAcc), Keeps T acc.db (storeBfs augs ltiOf f acc).db
  | 0, acc => Keeps.refl _ _
  | f + 1, acc => by
    unfold storeBfs
    split
    · exact Keeps.refl _ _
    · dsimp only
      split
      · exact storeBfs_keeps T augs ltiOf f _
      · refine Keeps.trans ?_ (storeBfs_keeps T augs ltiOf f _)
        split
        · exact Keeps.refl _ _
        · exact storeLevel_keeps T _ ltiOf _ _

theorem storeAll_keeps (T : Nat) (db : EpDB) (augs : Nat → List WME) (ltiOf : Nat → Nat) (fuel : Nat) :
    Keeps T db (db.storeAll augs ltiOf fuel).db := by
  unfold storeAll
  suffices h : ∀ (ps : List Nat) (acc : StoreAcc), Keeps T acc.db (ps.foldl (fun (acc : StoreAcc) p =>
      match acc.db.nodeOf p with
      | some n => storeBfs augs ltiOf fuel { acc with queue := [(p, n)] }
      | none => acc) acc).db from h _ _
  intro ps
  induction ps with
  | nil => intro acc; exact Keeps.refl _ _
  | cons p ps ih =>
    intro acc
    simp only [List.foldl_cons]
    refine Keeps.trans ?_ (ih _)
    split
    · exact storeBfs_keeps T augs ltiOf fuel _
    · exact Keeps.refl _ _

theorem foldl_modWc_keeps (T : Nat) (f : EEdge → EEdge) (hf : Agrees T f) (is : List Nat) (db : EpDB) :
    Keeps T db (is.foldl (fun db i => db.modWc i f) db) :=
  foldl_rel (Keeps T) (fun _ _ _ => Keeps.trans) (fun a => Keeps.refl _ _) _
    (fun db i => (⟨Same.refl _ _, Same.modAt hf _ _⟩ : Keeps T db (db.modWc i f))) is db

theorem foldl_modWi_keeps (T : Nat) (f : EEdge → EEdge) (hf : Agrees T f) (is : List Nat) (db : EpDB) :
    Keeps T db (is.foldl (fun db i => db.modWi i f) db) :=
  foldl_rel (Keeps T) (fun _ _ _ => Keeps.trans) (fun a => Keeps.refl _ _) _
    (fun db i => (⟨Same.modAt hf _ _, Same.refl _ _⟩ : Keeps T db (db.modWi i f))) is db

theorem foldl_openWi_keeps (T : Nat) (is : List (Nat × Nat)) (db : EpDB) :
    Keeps T db (is.foldl (fun db (x : Nat × Nat) => db.modWi x.1 (fun e => { openLti T x.2 e with lastEp := epInf })) db) :=
  foldl_rel (Keeps T) (fun _ _ _ => Keeps.trans) (fun a => Keeps.refl _ _)
    (fun db (x : Nat × Nat) => db.modWi x.1 (fun e => { openLti T x.2 e with lastEp := epInf }))
    (fun db i => ⟨Same.modAt (agrees_openLti T i.2) _ _, Same.refl _ _⟩) is db

theorem openAll_keeps (T : Nat) (nq : List Nat) (eq : List (Nat × Nat)) (db : EpDB) : Keeps T db (openAll T nq eq db) := by
  unfold openAll
  exact (foldl_modWc_keeps T _ (agrees_openAt T) nq db).trans (foldl_openWi_keeps T eq _)

theorem foldl_closeWc_keeps (T : Nat) (ps : List (Nat × Bool)) (db : EpDB) :
    Keeps T db (ps.foldl (fun db p => if p.2 then db.modWc p.1 (closeAt T) else db) db) :=
  foldl_rel (Keeps T) (fun _ _ _ => Keeps.trans) (fun a => Keeps.refl _ _) _
    (fun db p => by
      split
      · exact ⟨Same.refl _ _, Same.modAt (agrees_closeAt T) _ _⟩
      · exact Keeps.refl _ _) ps db

theorem foldl_closeWi_keeps (T : Nat) (ps : List (Nat × Bool)) (db : EpDB) :
    Keeps T db (ps.foldl (fun db p =>
      if p.2 then db.modWi p.1 (fun e => { closeLti T ((db.remLti[p.1]?).getD 0) e with lastEp := (T : Int) - 1 }) else db) db) :=
  foldl_rel (Keeps T) (fun _ _ _ => Keeps.trans) (fun a => Keeps.refl _ _) _
    (fun db p => by
      split
      · exact ⟨Same.modAt (agrees_closeLti T _ _) _ _, Same.refl _ _⟩
      · exact Keeps.refl _ _) ps db

theorem closeAll_keeps (T : Nat) (db : EpDB) : Keeps T db (closeAll T db) := by
  unfold closeAll
  exact (foldl_closeWc_keeps T _ db).trans (foldl_closeWi_keeps T _ _)

theorem newEpisode_keeps (db : EpDB) (augs : Nat → List WME) (ltiOf : Nat → Nat) (fuel : Nat) :
    Keeps db.time db (db.newEpisode augs ltiOf fuel) := by
  unfold newEpisode
  exact (storeAll_keeps _ db augs ltiOf fuel).trans
    ((openAll_keeps _ _ _ _).trans (closeAll_keeps _ _))

/-- An episode's edges without the LTIs of their values. -/
def shape (es : List (Nat × Sym × EVal × Nat)) : List (Nat × Sym × EVal) := es.map fun (p, a, c, _) => (p, a, c)

/-- **Recording an episode never changes an earlier one** — apart from the LTIs of identifier
values. After episode `db.time` is recorded, every earlier episode has exactly the edges it
had: the store only grows at the present. The LTI shown for an identifier value can change,
because Soar 9.6.5 gives a closed interval the LTI its value had when the interval closed, so an
identifier that changed its LTI shows the new one in earlier episodes too (Section 11 of the
report).

This is what makes the store a record of the agent's past: what episodic memory holds about
episode `t` is fixed once `t` is recorded. -/
theorem newEpisode_past (db : EpDB) (augs : Nat → List WME) (ltiOf : Nat → Nat) (fuel : Nat)
    (t : Nat) (ht : t < db.time) : shape ((db.newEpisode augs ltiOf fuel).episode t) = shape (db.episode t) := by
  obtain ⟨h1, h2⟩ := newEpisode_keeps db augs ltiOf fuel
  unfold episode shape
  have e1 := h1 t ht
  have e2 := h2 t ht
  have m (l : List EEdge) (g : EEdge → Nat) :
      ((l.filter (·.at t)).map (fun e => (e.parent, e.attr, e.child, g e))).map
        (fun (x : Nat × Sym × EVal × Nat) => (x.1, x.2.1, x.2.2.1)) = (l.filter (·.at t)).map sig := by
    simp [List.map_map, Function.comp, sig]
  simp only [List.map_append]
  rw [m _ (fun e => e.ltiAt t), m _ (fun _ => 0), m _ (fun e => e.ltiAt t), m _ (fun _ => 0), e1, e2]

end EpDB

end Soar
