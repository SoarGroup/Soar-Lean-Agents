import Soar.Prefs
import Soar.Rand
/-!
# Soar 9.6 — exploration: choosing among mutually indifferent operators

When preference resolution ends with several mutually indifferent candidates, Soar picks one
by the policy set with `decide indifferent-selection` ([Man] §5.4 and the `decide` command;
Soar 9.6.5 `exploration.cpp`):

* `--first`, `--last`: the first or the last candidate;
* `--softmax` (the default): at random, in proportion to the candidates' positive values (at
  random with equal probability if none is positive);
* `--epsilon-greedy`: with probability ε at random, otherwise one with the highest value;
* `--boltzmann`: at random with probability proportional to exp(value / temperature).

A candidate's value combines its numeric-indifferent preferences and the numbers referred to
by its binary-indifferent preferences (`decide numeric-indifferent-mode`, sum by default, or
the average). ε and the temperature can be reduced after each decision phase
(`--auto-reduce`, exponentially or linearly).

Every policy here is checked against Soar 9.6.5 with the same seed (`srand`).
-/

namespace Soar

/-! ## Where resolution calls `choose` -/

/-- The candidates `resolve` hands to `choose`, if it does: the final candidates, when there are
at least two and they are mutually indifferent. (`tie5` … `tie2` follow `stage5` … `stage2`.) -/
def tie5 (ps : List Pref) (c₅ : List Sym) : Option (List Sym) :=
  match c₅ with
  | [] => none
  | [_] => none
  | _ => if mutuallyIndifferent ps c₅ then some c₅ else none

def tie4 (ps : List Pref) (c₄ : List Sym) : Option (List Sym) :=
  match c₄ with
  | [] => none
  | [_] => none
  | _ => tie5 ps (afterWorst ps c₄)

def tie3 (ps : List Pref) (c₂ : List Sym) : Option (List Sym) :=
  match afterBetterWorse ps c₂ with
  | [] => none
  | [_] => none
  | c₃ => tie4 ps (afterBest ps c₃)

def tie2 (ps : List Pref) : Option (List Sym) :=
  match afterReject ps with
  | [] => none
  | [_] => none
  | c₂ => tie3 ps c₂

def tieCands (ps : List Pref) : Option (List Sym) :=
  match required ps with
  | [] => tie2 ps
  | _ => none

section
variable {ps : List Pref} {f g : List Sym → Sym}

theorem stage5_none {c : List Sym} (h : tie5 ps c = none) : stage5 f ps c = stage5 g ps c := by
  unfold tie5 at h; unfold stage5
  rcases c with _ | ⟨a, _ | ⟨b, t⟩⟩
  · rfl
  · rfl
  · simp only at h ⊢; split
    · rename_i hm; simp [hm] at h
    · rfl

theorem stage5_some {c d : List Sym} (h : tie5 ps c = some d) : stage5 f ps c = .winner (f d) := by
  unfold tie5 at h; unfold stage5
  rcases c with _ | ⟨a, _ | ⟨b, t⟩⟩
  · simp at h
  · simp at h
  · simp only at h ⊢; split
    · rename_i hm; simp [hm] at h; rw [h]
    · rename_i hm; simp [hm] at h

theorem stage4_none {c : List Sym} (h : tie4 ps c = none) : stage4 f ps c = stage4 g ps c := by
  unfold tie4 at h; unfold stage4
  rcases c with _ | ⟨a, _ | ⟨b, t⟩⟩
  · rfl
  · rfl
  · exact stage5_none h

theorem stage4_some {c d : List Sym} (h : tie4 ps c = some d) : stage4 f ps c = .winner (f d) := by
  unfold tie4 at h; unfold stage4
  rcases c with _ | ⟨a, _ | ⟨b, t⟩⟩
  · simp at h
  · simp at h
  · exact stage5_some h

theorem stage3_none {c : List Sym} (h : tie3 ps c = none) : stage3 f ps c = stage3 g ps c := by
  unfold tie3 at h; unfold stage3
  generalize afterBetterWorse ps c = l at h ⊢
  rcases l with _ | ⟨a, _ | ⟨b, t⟩⟩
  · rfl
  · rfl
  · exact stage4_none h

theorem stage3_some {c d : List Sym} (h : tie3 ps c = some d) : stage3 f ps c = .winner (f d) := by
  unfold tie3 at h; unfold stage3
  generalize afterBetterWorse ps c = l at h ⊢
  rcases l with _ | ⟨a, _ | ⟨b, t⟩⟩
  · simp at h
  · simp at h
  · exact stage4_some h

theorem stage2_none (h : tie2 ps = none) : stage2 f ps = stage2 g ps := by
  unfold tie2 at h; unfold stage2
  generalize afterReject ps = l at h ⊢
  rcases l with _ | ⟨a, _ | ⟨b, t⟩⟩
  · rfl
  · rfl
  · exact stage3_none h

theorem stage2_some {d : List Sym} (h : tie2 ps = some d) : stage2 f ps = .winner (f d) := by
  unfold tie2 at h; unfold stage2
  generalize afterReject ps = l at h ⊢
  rcases l with _ | ⟨a, _ | ⟨b, t⟩⟩
  · simp at h
  · simp at h
  · exact stage3_some h

/-- **Resolution consults `choose` only on `tieCands`**: if it hands `choose` no candidates, any
`choose` gives the same decision. -/
theorem resolve_none (h : tieCands ps = none) : resolve f ps = resolve g ps := by
  unfold tieCands at h; unfold resolve
  generalize hr : required ps = l at h ⊢
  rcases l with _ | ⟨a, _ | ⟨b, t⟩⟩
  · exact stage2_none h
  · rfl
  · rfl

/-- **The policy picks the winner**: if resolution hands `choose` the candidates `d`, the winner
is `choose d`. -/
theorem resolve_some {d : List Sym} (h : tieCands ps = some d) : resolve f ps = .winner (f d) := by
  unfold tieCands at h; unfold resolve
  generalize hr : required ps = l at h ⊢
  rcases l with _ | ⟨a, _ | ⟨b, t⟩⟩
  · exact stage2_some h
  · simp at h
  · simp at h

end

/-! ## Exploration parameters -/

inductive Policy where
  | first | last | softmax | epsilonGreedy | boltzmann
  deriving DecidableEq, Repr, Inhabited

inductive Reduction where
  | exponential | linear
  deriving DecidableEq, Repr, Inhabited

/-- One reducible parameter (ε or the temperature): its value, the reduction policy in force,
and the rates of both policies. -/
structure Reducible where
  value  : Float
  policy : Reduction := .exponential
  expRate : Float := 1
  linRate : Float := 0
  deriving Repr, Inhabited

/-- The settings of `decide indifferent-selection` and `decide numeric-indifferent-mode`, with
Soar 9.6.5's defaults. -/
structure ExploreCfg where
  policy : Policy := .softmax
  epsilon : Reducible := { value := 0.1 }
  temperature : Reducible := { value := 25 }
  autoReduce : Bool := false
  /-- `numeric-indifferent-mode --avg` rather than `--sum`. -/
  avg : Bool := false
  deriving Repr, Inhabited

/-- One reduction step (Soar 9.6.5 `exploration_reduce_exponential`, `..._linear`), kept only if
the result is valid (ε in [0, 1], temperature above 0). -/
def Reducible.reduce (r : Reducible) (valid : Float → Bool) : Reducible :=
  let v := match r.policy with
    | .exponential => if r.expRate != 1 then r.value * r.expRate else r.value
    | .linear => if r.value > 0 && r.linRate != 0 then max (r.value - r.linRate) 0 else r.value
  if valid v then { r with value := v } else r

/-- After each decision phase (Soar 9.6.5 `exploration_update_parameters`). -/
def ExploreCfg.update (c : ExploreCfg) : ExploreCfg :=
  if !c.autoReduce then c else
  { c with epsilon := c.epsilon.reduce (fun v => v ≥ 0 && v ≤ 1),
           temperature := c.temperature.reduce (· > 0) }

/-! ## Candidate values and the policies -/

/-- A candidate's value (Soar 9.6.5 `exploration_compute_value_of_candidate`): the numbers of
its numeric-indifferent preferences and of the referents of its binary-indifferent ones
(0 for a referent that is not a number), summed or averaged; 0 if it has none. -/
def candValue (avg : Bool) (ps : List Pref) (o : Sym) : Float :=
  let mine := ps.filter fun p => p.op == o && (p.kind == .numericIndiff || p.kind == .binaryIndiff)
  let num (p : Pref) : Float :=
    (if p.kind == .numericIndiff then p.num else p.other).bind Sym.num? |>.getD 0
  match mine with
  | [] => 0
  | _ =>
    let total := mine.foldl (fun a p => a + num p) 0
    if avg then total / mine.length.toFloat else total

/-- `exploration_randomly_select`. -/
def pickRandom (c : List Sym) (r : MT) : Sym × MT :=
  let (i, r) := MT.randIntN (c.length - 1).toUInt32 r
  (c.getD i.toNat .nil, r)

/-- The first candidate whose running total (over the candidates `w` gives a weight) reaches
`x`. -/
def pickCumulative (cv : List (Sym × Float)) (w : Float → Option Float) (x : Float) : Sym :=
  let rec go : List (Sym × Float) → Float → Sym
    | [], _ => .nil
    | (o, v) :: rest, sum =>
      match w v with
      | none => go rest sum
      | some wv => if x ≤ sum + wv then o else go rest (sum + wv)
  go cv 0

/-- `exploration_softmax_select`. -/
def pickSoftmax (cv : List (Sym × Float)) (r : MT) : Sym × MT :=
  let total := cv.foldl (fun a (_, v) => if v > 0 then a + v else a) 0
  if total == 0 then pickRandom (cv.map (·.1)) r else
  let (u, r) := r.rand
  (pickCumulative cv (fun v => if v > 0 then some v else none) (u * total), r)

/-- `exploration_get_highest_q_value_pref`: a random one among those with the highest value. -/
def pickGreedy (cv : List (Sym × Float)) (r : MT) : Sym × MT :=
  match cv with
  | [] => (.nil, r)
  | (_, v₀) :: _ =>
    let top := cv.foldl (fun a (_, v) => if v > a then v else a) v₀
    let best := (cv.filter (·.2 == top)).map (·.1)
    match best with
    | [o] => (o, r)
    | _ => pickRandom best r

/-- `exploration_epsilon_greedy_select`. -/
def pickEpsilonGreedy (eps : Float) (cv : List (Sym × Float)) (r : MT) : Sym × MT :=
  let (u, r) := r.rand
  if u < eps then pickRandom (cv.map (·.1)) r else pickGreedy cv r

/-- `exploration_boltzmann_select`. -/
def pickBoltzmann (t : Float) (cv : List (Sym × Float)) (r : MT) : Sym × MT :=
  match cv with
  | [] => (.nil, r)
  | (_, v₀) :: _ =>
    let maxq := cv.foldl (fun a (_, v) => if v > a then v else a) v₀
    let total := cv.foldl (fun a (_, v) => a + Float.exp ((v - maxq) / t)) 0
    let (u, r) := r.rand
    (pickCumulative cv (fun v => some (Float.exp ((v - maxq) / t))) (u * total), r)

/-- Choose among the mutually indifferent candidates `c` by the policy in force. `first` stands
for `--first` (the head of the candidates, or a replay of Soar's choice). -/
def ExploreCfg.select (cfg : ExploreCfg) (first : List Sym → Sym) (ps : List Pref) (c : List Sym)
    (r : MT) : Sym × MT :=
  let cv := c.map fun o => (o, candValue cfg.avg ps o)
  match cfg.policy with
  | .first => (first c, r)
  | .last => (c.getLastD .nil, r)
  | .softmax => pickSoftmax cv r
  | .epsilonGreedy => pickEpsilonGreedy cfg.epsilon.value cv r
  | .boltzmann => pickBoltzmann cfg.temperature.value cv r

end Soar

namespace Soar

/-- The importance-sampling ratio of the chosen candidate for off-policy GQ(λ) (Soar 9.6.5
`exploration_choose_according_to_policy` and the selection functions, which divide each
candidate's `rl_rho`): the greedy policy's probability of it over the policy's. -/
def ExploreCfg.rho (cfg : ExploreCfg) (cv : List (Sym × Float)) (o : Sym) : Float :=
  match cfg.policy with
  | .first | .last => 1
  | _ =>
  match cv with
  | [] => 1
  | (_, v₀) :: _ =>
    let top := cv.foldl (fun a (_, v) => if v > a then v else a) v₀
    let nTop := (cv.filter (·.2 == top)).length.toFloat
    let v := ((alGet cv o)).getD 0
    let r0 := if v == top then 1.0 / nTop else 0
    let n := cv.length.toFloat
    match cfg.policy with
    | .softmax =>
      let total := cv.foldl (fun a (_, x) => if x > 0 then a + x else a) 0
      if total == 0 then r0 / (1.0 / n)
      else if v != 0 then r0 / (v / total)
      else if r0 > 0 then 1.7976931348623157e308 else r0
    | .epsilonGreedy => r0 / ((1 - cfg.epsilon.value) * r0 + cfg.epsilon.value / n)
    | .boltzmann =>
      let t := cfg.temperature.value
      let maxq := top
      let total := cv.foldl (fun a (_, x) => a + Float.exp ((x - maxq) / t)) 0
      r0 / (Float.exp ((v - maxq) / t) / total)
    | _ => 1

end Soar
