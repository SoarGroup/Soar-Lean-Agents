import Soar.Match

/-!
# The join order keeps the conditions

`joinOrder` (Soar/Match.lean) chooses the order in which a rule's conditions are matched. This
file proves that it returns the rule's own conditions, reordered: the result is a permutation
of the input once relational tests are set aside (`Cond.strip`). The exception is real:
when every remaining positive condition tests a variable not yet bound (a cycle of relational
tests), `moveRel` moves those tests, inverted, onto the conditions that bind the variables, as
Soar 9.6.5's reorderer does; the conditions are then the same except where their relational
tests sit.

With `matchPats_perm` (Soar/MatchComplete.lean), which shows that the order of positive
patterns does not change the matches when relational tests follow their bindings, this
covers reordering for rules whose order needs no tests moved.
-/

namespace Soar

/-- A relational test (`<`, `>`, `<>`, … or `@`, `!@`) against a term. -/
def STest.isRel : STest → Bool
  | .rel _ _ => true
  | .ltiRel _ _ => true
  | _ => false

/-- A test without its relational tests. -/
def Test.strip (t : Test) : Test := t.filter (fun st => !st.isRel)

/-- A pattern without its relational tests. -/
def Pat.strip (p : Pat) : Pat :=
  { p with id := Test.strip p.id, attr := Test.strip p.attr, val := Test.strip p.val }

/-- A condition without the relational tests of a positive pattern. -/
def Cond.strip : Cond → Cond
  | .pos p => .pos p.strip
  | c => c

/-! ## Splitting a test -/

theorem splitRelStep_strip (ok : String → Bool) (me : Term) (acc : Test × List (String × STest))
    (st : STest) :
    Test.strip (splitRelStep ok me acc st).1 = Test.strip acc.1 ++ Test.strip [st] := by
  unfold splitRelStep
  split
  · split <;> simp [Test.strip, STest.isRel]
  · split <;> simp [Test.strip, STest.isRel]
  · simp [Test.strip]

theorem splitRelStep_moved (ok : String → Bool) (me : Term) (acc : Test × List (String × STest))
    (st : STest) (h : ∀ m ∈ acc.2, m.2.isRel = true) :
    ∀ m ∈ (splitRelStep ok me acc st).2, m.2.isRel = true := by
  unfold splitRelStep
  split
  · split
    · exact h
    · intro m hm; simp only [List.mem_append, List.mem_singleton] at hm
      rcases hm with hm | rfl
      · exact h m hm
      · rfl
  · split
    · exact h
    · intro m hm; simp only [List.mem_append, List.mem_singleton] at hm
      rcases hm with hm | rfl
      · exact h m hm
      · rfl
  · exact h

theorem foldl_splitRelStep_strip (ok : String → Bool) (me : Term) :
    ∀ (t : Test) (acc : Test × List (String × STest)),
      Test.strip (t.foldl (splitRelStep ok me) acc).1 = Test.strip acc.1 ++ Test.strip t
  | [], acc => by simp [Test.strip]
  | st :: t, acc => by
    rw [List.foldl_cons, foldl_splitRelStep_strip ok me t, splitRelStep_strip]
    by_cases h : st.isRel <;> simp [Test.strip, List.filter_cons, h]

theorem foldl_splitRelStep_moved (ok : String → Bool) (me : Term) :
    ∀ (t : Test) (acc : Test × List (String × STest)), (∀ m ∈ acc.2, m.2.isRel = true) →
      ∀ m ∈ (t.foldl (splitRelStep ok me) acc).2, m.2.isRel = true
  | [], _, h => h
  | st :: t, acc, h => by
    rw [List.foldl_cons]
    exact foldl_splitRelStep_moved ok me t _ (splitRelStep_moved ok me acc st h)

/-- Splitting keeps every test but the relational ones it takes out. -/
theorem splitRel_strip (ok : String → Bool) (t : Test) :
    Test.strip (splitRel ok t).1 = Test.strip t := by
  unfold splitRel
  split
  · rfl
  · rw [foldl_splitRelStep_strip]; simp [Test.strip]

/-- The tests taken out are relational. -/
theorem splitRel_moved (ok : String → Bool) (t : Test) :
    ∀ m ∈ (splitRel ok t).2, m.2.isRel = true := by
  unfold splitRel
  split
  · simp
  · exact foldl_splitRelStep_moved ok _ t _ (by simp)

/-! ## Placing a moved test -/

theorem addFor_strip {y : String} {st : STest} {p q : Pat} (hst : st.isRel = true)
    (h : p.addFor y st = some q) : q.strip = p.strip := by
  unfold Pat.addFor at h
  dsimp only at h
  split at h
  · cases h; simp [Pat.strip, Test.strip, List.filter_append, hst]
  · split at h
    · cases h; simp [Pat.strip, Test.strip, List.filter_append, hst]
    · split at h
      · cases h; simp [Pat.strip, Test.strip, List.filter_append, hst]
      · cases h

theorem placeStep_strip {m : String × STest} (hm : m.2.isRel = true) (acc : List Cond × Bool)
    (c : Cond) : (placeStep m acc c).1.map Cond.strip = acc.1.map Cond.strip ++ [c.strip] := by
  unfold placeStep
  split
  · simp
  · split
    · rename_i q
      split
      · rename_i q' hq
        simp [Cond.strip, addFor_strip hm hq]
      · simp
    · simp

theorem foldl_placeStep_strip {m : String × STest} (hm : m.2.isRel = true) :
    ∀ (cs : List Cond) (acc : List Cond × Bool),
      (cs.foldl (placeStep m) acc).1.map Cond.strip = acc.1.map Cond.strip ++ cs.map Cond.strip
  | [], acc => by simp
  | c :: cs, acc => by
    rw [List.foldl_cons, foldl_placeStep_strip hm cs, placeStep_strip hm]
    simp

/-- Placing a relational test changes no condition but where its relational tests sit. -/
theorem placeRel_strip {m : String × STest} (hm : m.2.isRel = true) (cs : List Cond) :
    (placeRel cs m).1.map Cond.strip = cs.map Cond.strip := by
  unfold placeRel; rw [foldl_placeStep_strip hm]; simp

theorem foldl_placeAllStep_strip :
    ∀ (ms : List (String × STest)) (acc : List Cond × Bool), (∀ m ∈ ms, m.2.isRel = true) →
      (ms.foldl placeAllStep acc).1.map Cond.strip = acc.1.map Cond.strip
  | [], _, _ => rfl
  | m :: ms, acc, h => by
    rw [List.foldl_cons, foldl_placeAllStep_strip ms _ (fun m' hm' => h m' (by simp [hm']))]
    unfold placeAllStep
    exact placeRel_strip (h m (by simp)) acc.1

/-- Moving relational tests changes no condition but where its relational tests sit. -/
theorem moveRel_strip (bound : List String) (best : Cond) (rest : List Cond) :
    (moveRel bound best rest).1.strip = best.strip ∧
      (moveRel bound best rest).2.map Cond.strip = rest.map Cond.strip := by
  unfold moveRel
  split
  · rename_i p
    simp only
    split
    · constructor
      · simp only [Cond.strip, Pat.strip, splitRel_strip]
      · apply foldl_placeAllStep_strip
        intro m hm
        simp only [List.mem_append] at hm
        rcases hm with (hm | hm) | hm <;> exact splitRel_moved _ _ m hm
    · exact ⟨rfl, rfl⟩
  · exact ⟨rfl, rfl⟩

/-! ## Choosing the next condition -/

theorem pickBest_mem (multi : List (String × Nat)) (bound : List String) (b c : Cond) :
    pickBest multi bound b c = b ∨ pickBest multi bound b c = c := by
  unfold pickBest
  split
  · simp only
    split
    · exact Or.inr rfl
    · exact Or.inl rfl
  · exact Or.inl rfl

theorem foldl_pickBest_mem (multi : List (String × Nat)) (bound : List String) :
    ∀ (l : List Cond) (b : Cond), l.foldl (pickBest multi bound) b ∈ b :: l
  | [], b => by simp
  | c :: l, b => by
    rw [List.foldl_cons]
    have ih := foldl_pickBest_mem multi bound l (pickBest multi bound b c)
    generalize List.foldl (pickBest multi bound) (pickBest multi bound b c) l = r at ih ⊢
    simp only [List.mem_cons] at ih ⊢
    rcases pickBest_mem multi bound b c with h | h <;> rw [h] at ih
    · rcases ih with ih | ih
      · exact Or.inl ih
      · exact Or.inr (Or.inr ih)
    · rcases ih with ih | ih
      · exact Or.inr (Or.inl ih)
      · exact Or.inr (Or.inr ih)

theorem perm_eraseIdx_idxOf {a : Cond} {l : List Cond} (h : a ∈ l) :
    l.Perm (a :: l.eraseIdx (l.idxOf a)) := by
  induction l with
  | nil => simp at h
  | cons x l ih =>
    by_cases hx : x = a
    · subst hx; simp [List.idxOf_cons_self]
    · have ha : a ∈ l := by
        rcases List.mem_cons.mp h with h | h
        · exact absurd h.symm hx
        · exact h
      have hidx : (x :: l).idxOf a = l.idxOf a + 1 := by
        simp [List.idxOf_cons, beq_iff_eq, hx]
      rw [hidx, List.eraseIdx_cons_succ]
      exact ((ih ha).cons x).trans (List.Perm.swap a x _)

/-- Taking out the conditions that are ready, then the rest, is a permutation. -/
theorem ready_perm (P : Cond → Bool) (l : List Cond) :
    (l.filter P ++ l.filter (fun c => !(l.filter P).any fun r => decide (r = c))).Perm l := by
  have h : l.filter (fun c => !(l.filter P).any fun r => decide (r = c)) = l.filter (fun c => !P c) := by
    apply List.filter_congr
    intro c hc
    congr 1
    rw [Bool.eq_iff_iff, List.any_eq_true]
    constructor
    · rintro ⟨r, hr, hrc⟩
      have := of_decide_eq_true hrc; subst this
      exact (List.mem_filter.mp hr).2
    · intro hp; exact ⟨c, List.mem_filter.mpr ⟨hc, hp⟩, by simp⟩
  rw [h]; exact List.filter_append_perm P l

/-! ## The join order -/

/-- One greedy step of the join order: the chosen condition, with relational tests possibly
moved, followed by the others. -/
theorem joinStep_strip (multi : List (String × Nat)) (acc rest pool : List Cond) (c₀ : Cond)
    (hsub : ∀ x ∈ pool, x ∈ rest) (hc : c₀ ∈ pool) (b : Bool) (bound : List String)
    (F : Cond → List Cond → List Cond)
    (hF : ∀ c r, ((F c r).map Cond.strip).Perm ((acc ++ [c] ++ r).map Cond.strip)) :
    ((F (if b then moveRel bound (pool.foldl (pickBest multi bound) c₀)
            (rest.eraseIdx (rest.idxOf (pool.foldl (pickBest multi bound) c₀)))
          else (pool.foldl (pickBest multi bound) c₀,
            rest.eraseIdx (rest.idxOf (pool.foldl (pickBest multi bound) c₀)))).1
        (if b then moveRel bound (pool.foldl (pickBest multi bound) c₀)
            (rest.eraseIdx (rest.idxOf (pool.foldl (pickBest multi bound) c₀)))
          else (pool.foldl (pickBest multi bound) c₀,
            rest.eraseIdx (rest.idxOf (pool.foldl (pickBest multi bound) c₀)))).2).map
        Cond.strip).Perm ((acc ++ rest).map Cond.strip) := by
  generalize hb : pool.foldl (pickBest multi bound) c₀ = best
  have hbest : best ∈ rest := by
    rw [← hb]
    rcases List.mem_cons.mp (foldl_pickBest_mem multi bound pool c₀) with h | h
    · rw [h]; exact hsub _ hc
    · exact hsub _ h
  have hperm : ((best :: rest.eraseIdx (rest.idxOf best)).map Cond.strip).Perm (rest.map Cond.strip) :=
    (List.Perm.map _ (perm_eraseIdx_idxOf hbest)).symm
  generalize rest.eraseIdx (rest.idxOf best) = rest' at hperm
  have hmr : ∀ mr : Cond × List Cond, mr.1.strip = best.strip → mr.2.map Cond.strip = rest'.map Cond.strip →
      ((F mr.1 mr.2).map Cond.strip).Perm ((acc ++ rest).map Cond.strip) := by
    intro mr h1 h2
    refine (hF mr.1 mr.2).trans ?_
    rw [List.append_assoc, List.map_append, List.map_append, List.map_append]
    refine List.Perm.append_left _ ?_
    rw [← List.map_append, List.singleton_append, List.map_cons, h1, h2]
    simpa using hperm
  cases b
  · exact hmr _ rfl rfl
  · exact hmr _ (moveRel_strip bound best rest').1 (moveRel_strip bound best rest').2

theorem joinOrder_go_strip (multi : List (String × Nat)) (pv : List String) :
    ∀ (n : Nat) (rest : List Cond) (bound : List String) (acc : List Cond),
      ((joinOrder.go multi n rest bound acc pv).map Cond.strip).Perm
        ((acc ++ rest).map Cond.strip)
  | 0, rest, bound, acc => by simp [joinOrder.go]
  | n + 1, rest, bound, acc => by
    unfold joinOrder.go
    simp only
    split
    · rename_i he
      have : rest = [] := List.isEmpty_iff.mp he
      subst this; simp
    · split
      · -- the ready negations go first
        rename_i hr
        refine (joinOrder_go_strip multi pv n _ bound _).trans ?_
        rw [List.append_assoc]
        exact List.Perm.map _ (List.Perm.append_left _ (ready_perm _ _))
      · split
        · rfl
        · rename_i pool c₀ tl hpool
          refine joinStep_strip multi acc rest _ c₀ ?_ ?_ _ bound
            (fun c r => joinOrder.go multi n r (bindNext bound c) (acc ++ [c]) pv)
            (fun c r => joinOrder_go_strip multi pv n r _ _)
          · intro x hx
            split at hx <;> exact (List.mem_filter.mp hx).1
          · rw [hpool]; exact List.mem_cons_self

/-- `joinOrder` returns the rule's conditions reordered, up to where relational tests sit. -/
theorem joinOrder_strip (cs : List Cond) (multi : List (String × Nat)) :
    ((joinOrder cs multi).map Cond.strip).Perm (cs.map Cond.strip) := by
  unfold joinOrder
  simpa using joinOrder_go_strip multi _ (cs.length + 1) cs [] []

/-- The join order keeps the number of conditions. -/
theorem joinOrder_length (cs : List Cond) (multi : List (String × Nat)) :
    (joinOrder cs multi).length = cs.length := by
  simpa using (joinOrder_strip cs multi).length_eq

/-! ## Without relational tests between variables, an exact permutation -/

/-- A relational test against a variable, the kind `moveRel` can move. -/
def STest.isVarRel : STest → Bool
  | .rel _ (.var _) => true
  | .ltiRel _ (.var _) => true
  | _ => false

/-- A condition with no relational test between variables (negations count as none). -/
def Cond.NoVarRel : Cond → Prop
  | .pos p => ∀ st ∈ p.id ++ p.attr ++ p.val, st.isVarRel = false
  | _ => True

theorem splitRelStep_plain (ok : String → Bool) (me : Term) (acc : Test × List (String × STest))
    (st : STest) (h : st.isVarRel = false) : splitRelStep ok me acc st = (acc.1 ++ [st], acc.2) := by
  unfold splitRelStep
  split
  · simp [STest.isVarRel] at h
  · simp [STest.isVarRel] at h
  · rfl

theorem foldl_splitRelStep_plain (ok : String → Bool) (me : Term) :
    ∀ (t : Test) (acc : Test × List (String × STest)), (∀ st ∈ t, st.isVarRel = false) →
      t.foldl (splitRelStep ok me) acc = (acc.1 ++ t, acc.2)
  | [], acc, _ => by simp
  | st :: t, acc, h => by
    rw [List.foldl_cons, splitRelStep_plain ok me acc st (h st (by simp)),
      foldl_splitRelStep_plain ok me t _ (fun x hx => h x (by simp [hx]))]
    simp

theorem splitRel_plain (ok : String → Bool) (t : Test) (h : ∀ st ∈ t, st.isVarRel = false) :
    splitRel ok t = (t, []) := by
  unfold splitRel
  split
  · rfl
  · rw [foldl_splitRelStep_plain ok _ t _ h]; simp

/-- With no relational test between variables there is nothing to move. -/
theorem moveRel_plain (bound : List String) (best : Cond) (rest : List Cond)
    (h : best.NoVarRel) : moveRel bound best rest = (best, rest) := by
  unfold moveRel
  split
  · rename_i p
    simp only [Cond.NoVarRel, List.mem_append] at h
    dsimp only
    rw [splitRel_plain _ p.id (fun st hs => h st (Or.inl (Or.inl hs))),
      splitRel_plain _ p.attr (fun st hs => h st (Or.inl (Or.inr hs))),
      splitRel_plain _ p.val (fun st hs => h st (Or.inr hs))]
    simp
  · rfl

theorem joinStep_perm (multi : List (String × Nat)) (acc rest pool : List Cond) (c₀ : Cond)
    (hsub : ∀ x ∈ pool, x ∈ rest) (hc : c₀ ∈ pool) (b : Bool) (bound : List String)
    (hplain : ∀ c ∈ rest, c.NoVarRel)
    (F : Cond → List Cond → List Cond)
    (hF : ∀ c r, (∀ x ∈ r, x.NoVarRel) → (F c r).Perm (acc ++ [c] ++ r)) :
    (F (if b then moveRel bound (pool.foldl (pickBest multi bound) c₀)
            (rest.eraseIdx (rest.idxOf (pool.foldl (pickBest multi bound) c₀)))
          else (pool.foldl (pickBest multi bound) c₀,
            rest.eraseIdx (rest.idxOf (pool.foldl (pickBest multi bound) c₀)))).1
        (if b then moveRel bound (pool.foldl (pickBest multi bound) c₀)
            (rest.eraseIdx (rest.idxOf (pool.foldl (pickBest multi bound) c₀)))
          else (pool.foldl (pickBest multi bound) c₀,
            rest.eraseIdx (rest.idxOf (pool.foldl (pickBest multi bound) c₀)))).2).Perm
        (acc ++ rest) := by
  generalize hb : pool.foldl (pickBest multi bound) c₀ = best
  have hbest : best ∈ rest := by
    rw [← hb]
    rcases List.mem_cons.mp (foldl_pickBest_mem multi bound pool c₀) with h | h
    · rw [h]; exact hsub _ hc
    · exact hsub _ h
  have hperm := perm_eraseIdx_idxOf hbest
  generalize rest.eraseIdx (rest.idxOf best) = rest' at hperm
  have hr' : ∀ x ∈ rest', x.NoVarRel := fun x hx =>
    hplain x (hperm.mem_iff.mpr (List.mem_cons_of_mem _ hx))
  have hmr : (if b then moveRel bound best rest' else (best, rest')) = (best, rest') := by
    cases b
    · rfl
    · exact moveRel_plain bound best rest' (hplain best hbest)
  rw [hmr]
  refine (hF best rest' hr').trans ?_
  rw [List.append_assoc, List.singleton_append]
  exact List.Perm.append_left _ hperm.symm

theorem joinOrder_go_perm (multi : List (String × Nat)) (pv : List String) :
    ∀ (n : Nat) (rest : List Cond) (bound : List String) (acc : List Cond),
      (∀ c ∈ rest, c.NoVarRel) →
      (joinOrder.go multi n rest bound acc pv).Perm (acc ++ rest)
  | 0, rest, bound, acc, _ => by simp [joinOrder.go]
  | n + 1, rest, bound, acc, hplain => by
    unfold joinOrder.go
    simp only
    split
    · rename_i he
      have : rest = [] := List.isEmpty_iff.mp he
      subst this; simp
    · split
      · refine (joinOrder_go_perm multi pv n _ bound _
          (fun c hc => hplain c (List.mem_filter.mp hc).1)).trans ?_
        rw [List.append_assoc]
        exact List.Perm.append_left _ (ready_perm _ _)
      · split
        · rfl
        · rename_i pool c₀ tl hpool
          refine joinStep_perm multi acc rest _ c₀ ?_ ?_ _ bound hplain
            (fun c r => joinOrder.go multi n r (bindNext bound c) (acc ++ [c]) pv)
            (fun c r hr => joinOrder_go_perm multi pv n r _ _ hr)
          · intro x hx
            split at hx <;> exact (List.mem_filter.mp hx).1
          · rw [hpool]; exact List.mem_cons_self

/-- **For a rule with no relational test between variables, `joinOrder` is a permutation of
its conditions.** With `matchPats_perm` (Soar/MatchComplete.lean), the matches of its
positive patterns are then the same in either order. -/
theorem joinOrder_perm (cs : List Cond) (multi : List (String × Nat))
    (h : ∀ c ∈ cs, c.NoVarRel) : (joinOrder cs multi).Perm cs := by
  unfold joinOrder
  simpa using joinOrder_go_perm multi _ (cs.length + 1) cs [] [] h

/-! ## When moving a relational test keeps its meaning

Moving `x op y` to the condition that binds `y` turns it into `y op⁻¹ x`. That keeps the test's
meaning between two numbers and between two identifiers (`RelOp.holds_inv_num`,
`RelOp.holds_inv_id`), but not between values of different types: Soar 9.6.5 counts a value of
another type as less, in either direction (`compare_symbols`), so `foo < 5` holds and its
inversion `5 > foo` does not (`RelOp.holds_inv_mixed`). Matches can then depend on where the
test is placed, in Soar as in the model (kernel defect 6); no theorem that moving tests
preserves matches holds without a restriction on the types compared. With the restriction,
Soar/JoinOrderSem.lean proves that they do (`joinOrder_matches`). -/

theorem RelOp.holds_inv_num (r : RelOp) (a b : Sym) (ha : a.num?.isSome) (hb : b.num?.isSome) :
    r.holds a b = r.inv.holds b a := by
  cases a <;> cases b <;> simp [Sym.num?] at ha hb <;> cases r <;>
    simp [RelOp.holds, RelOp.inv, Sym.num?, Sym.typeTag, bne_comm, Bool.beq_comm] <;> omega

theorem RelOp.holds_inv_id (r : RelOp) (x y : Nat) :
    r.holds (.id x) (.id y) = r.inv.holds (.id y) (.id x) := by
  cases r <;> simp [RelOp.holds, RelOp.inv, Sym.num?, Sym.typeTag, bne_comm] <;> omega

theorem RelOp.holds_inv_mixed :
    RelOp.lt.holds (.str "foo") (.int 5) = true ∧ RelOp.lt.inv.holds (.int 5) (.str "foo") = false := by
  decide

end Soar
