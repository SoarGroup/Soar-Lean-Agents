import Soar.JoinOrder
import Soar.MatchComplete
/-!
# Moving relational tests keeps the matches

Soar's reorderer and the model's join order move a relational test `x op y`, where `y` is not
bound yet, to the condition that binds `y`, as `y op⁻¹ x` (`moveRel`). `JoinOrder.lean` shows
that the conditions stay the same but for where their relational tests sit, and that the move
keeps its meaning between two numbers or between two identifiers but not between values of
different types (kernel defect 6). This file shows that, when every relational test between
variables compares values of one kind (a number with a number, an identifier with an
identifier), the positive patterns of the join order hold under the same bindings as the
rule's own (`joinOrder_posSat`), and so the matcher finds the same instantiations
(`joinOrder_matches`).

SCOPE. The theorems are about the rule's positive patterns without `@`/`!@` tests; negated
conditions are never changed by a move. A relational test between a string and a string is
not covered (the proof for numbers and identifiers is what Soar's tests need).
-/

namespace Soar

/-! ## Values of one kind -/

/-- The kind of a value for which a relational test can be inverted: 1 a number, 2 an
identifier, 0 anything else (a string). -/
def Sym.kind : Sym → Nat
  | .id _ => 2
  | .int _ => 1
  | .float _ => 1
  | .str _ => 0

/-- A relational test between two values of one kind keeps its meaning when inverted. -/
theorem RelOp.holds_inv_kind (r : RelOp) (a b : Sym) (h : a.kind = b.kind) (h0 : a.kind ≠ 0) :
    r.holds a b = r.inv.holds b a := by
  rcases a with x | s | i | f <;> rcases b with y | t | j | g <;> simp [Sym.kind] at h h0
  · exact RelOp.holds_inv_id r x y
  all_goals exact RelOp.holds_inv_num r _ _ (by simp [Sym.num?]) (by simp [Sym.num?])

/-! ## Tests that hold under bindings that bind every variable -/

/-- A test that is not a long-term-identifier test. -/
def STest.noLti : STest → Bool
  | .lti _ => false
  | .ltiRel _ _ => false
  | _ => true

/-- What a simple test requires of a value `s`, under bindings `β`. -/
def STest.sat (β : Binding) (s : Sym) : STest → Prop
  | .var v => β.get v = some s
  | .const c => c = s
  | .rel r t => ∃ x, t.value β = some x ∧ r.holds s x = true
  | .disj cs => cs.contains s = true
  | .lti _ => False
  | .ltiRel _ _ => False

def Test.sat (β : Binding) (s : Sym) (t : Test) : Prop := ∀ st ∈ t, st.sat β s

def Test.noLti (t : Test) : Bool := List.all t STest.noLti

def Test.bound (β : Binding) (t : Test) : Prop := ∀ v ∈ Test.binds t, (β.get v).isSome

theorem STest.run_beta {β : Binding} {s : Sym} {st : STest} (hn : st.noLti = true)
    (hb : ∀ v ∈ st.eqVars, (β.get v).isSome) :
    (∀ b', st.run β s = some b' → b' = β) ∧ (st.run β s = some β ↔ st.sat β s) := by
  cases st with
  | var v =>
    have hv := hb v (by simp [STest.eqVars])
    cases hg : β.get v with
    | none => rw [hg] at hv; simp at hv
    | some x =>
      simp only [STest.run, STest.sat, hg]
      by_cases hx : x = s
      · subst hx; simp
      · simp [hx]
  | const c =>
    simp only [STest.run, STest.sat]
    by_cases hc : c = s <;> simp [hc]
  | rel r t =>
    simp only [STest.run, STest.sat]
    cases ht : t.value β with
    | none => simp
    | some x =>
      by_cases hr : r.holds s x = true <;> simp [hr]
  | disj cs =>
    simp only [STest.run, STest.sat]
    by_cases hc : cs.contains s = true <;> simp [hc]
  | lti p => simp [STest.noLti] at hn
  | ltiRel p t => simp [STest.noLti] at hn

theorem runTest_beta {β : Binding} {s : Sym} : ∀ {ts : Test}, Test.noLti ts = true →
    (∀ v ∈ Test.binds ts, (β.get v).isSome) → (runTest β s ts = some β ↔ Test.sat β s ts)
  | [], _, _ => by simp [runTest, Test.sat]
  | st :: ts, hn, hb => by
    have hn' : st.noLti = true ∧ Test.noLti ts = true := by simpa [Test.noLti] using hn
    have hbs : ∀ v ∈ st.eqVars, (β.get v).isSome := fun v hv =>
      hb v (by unfold Test.binds; exact List.mem_flatMap.mpr ⟨st, List.mem_cons_self .., hv⟩)
    have hbt : ∀ v ∈ Test.binds ts, (β.get v).isSome := fun v hv =>
      hb v (by
        unfold Test.binds at hv ⊢
        obtain ⟨a, ha, hva⟩ := List.mem_flatMap.mp hv
        exact List.mem_flatMap.mpr ⟨a, List.mem_cons_of_mem _ ha, hva⟩)
    obtain ⟨h1, h2⟩ := STest.run_beta (s := s) hn'.1 hbs
    have ih := runTest_beta (s := s) hn'.2 hbt
    unfold runTest
    cases hr : st.run β s with
    | none =>
      simp only
      constructor
      · intro h; cases h
      · intro h
        have := (h2.mpr (h st (by simp)))
        rw [hr] at this; cases this
    | some b' =>
      have := h1 b' hr; subst this
      simp only
      rw [ih]
      constructor
      · intro h st' hst'
        rcases List.mem_cons.mp hst' with rfl | hst'
        · exact h2.mp hr
        · exact h st' hst'
      · intro h st' hst'; exact h st' (List.mem_cons_of_mem _ hst')

theorem runTest_ret {β : Binding} {s : Sym} : ∀ {ts : Test}, Test.noLti ts = true →
    (∀ v ∈ Test.binds ts, (β.get v).isSome) → ∀ b', runTest β s ts = some b' → b' = β
  | [], _, _, b', h => by simp [runTest] at h; exact h.symm
  | st :: ts, hn, hb, b', h => by
    have hn' : st.noLti = true ∧ Test.noLti ts = true := by simpa [Test.noLti] using hn
    have hbs : ∀ v ∈ st.eqVars, (β.get v).isSome := fun v hv =>
      hb v (by unfold Test.binds; exact List.mem_flatMap.mpr ⟨st, List.mem_cons_self .., hv⟩)
    have hbt : ∀ v ∈ Test.binds ts, (β.get v).isSome := fun v hv =>
      hb v (by
        unfold Test.binds at hv ⊢
        obtain ⟨a, ha, hva⟩ := List.mem_flatMap.mp hv
        exact List.mem_flatMap.mpr ⟨a, List.mem_cons_of_mem _ ha, hva⟩)
    obtain ⟨h1, _⟩ := STest.run_beta (s := s) hn'.1 hbs
    unfold runTest at h
    cases hr : st.run β s with
    | none => rw [hr] at h; cases h
    | some b₁ =>
      rw [hr] at h
      have := h1 b₁ hr; subst this
      exact runTest_ret (s := s) hn'.2 hbt b' h

/-- What a pattern requires of an element, under bindings `β`. -/
def Pat.sat (β : Binding) (p : Pat) (w : WME) : Prop :=
  w.acc = p.acc ∧ Test.sat β (.id w.id) p.id ∧ Test.sat β w.attr p.attr ∧ Test.sat β w.val p.val

def Pat.noLti (p : Pat) : Bool := Test.noLti p.id && Test.noLti p.attr && Test.noLti p.val

theorem Pat.run_beta {β : Binding} {p : Pat} (w : WME) (hn : p.noLti = true)
    (hb : ∀ v ∈ p.eqVars, (β.get v).isSome) : p.run β w = some β ↔ Pat.sat β p w := by
  have hn3 : Test.noLti p.id = true ∧ Test.noLti p.attr = true ∧ Test.noLti p.val = true := by
    simpa [Pat.noLti, Bool.and_eq_true, and_assoc] using hn
  rw [Pat.eqVars_eq] at hb
  have hb1 : ∀ v ∈ Test.binds p.id, (β.get v).isSome := fun v hv =>
    hb v (by simp [hv])
  have hb2 : ∀ v ∈ Test.binds p.attr, (β.get v).isSome := fun v hv =>
    hb v (by simp [hv])
  have hb3 : ∀ v ∈ Test.binds p.val, (β.get v).isSome := fun v hv =>
    hb v (by simp [hv])
  unfold Pat.run Pat.sat
  by_cases ha : w.acc = p.acc
  · simp only [ha, if_true, true_and]
    constructor
    · intro h
      cases h1 : runTest β (.id w.id) p.id with
      | none => rw [h1] at h; simp at h
      | some b₁ =>
        rw [h1] at h
        have e1 := runTest_ret hn3.1 hb1 _ h1
        rw [e1] at h
        simp only at h
        cases h2 : runTest β w.attr p.attr with
        | none => rw [h2] at h; simp at h
        | some b₂ =>
          rw [h2] at h
          have e2 := runTest_ret hn3.2.1 hb2 _ h2
          rw [e2] at h
          exact ⟨(runTest_beta hn3.1 hb1).mp (by rw [h1, e1]), (runTest_beta hn3.2.1 hb2).mp (by rw [h2, e2]),
            (runTest_beta hn3.2.2 hb3).mp h⟩
    · rintro ⟨s1, s2, s3⟩
      rw [(runTest_beta hn3.1 hb1).mpr s1]
      simp only
      rw [(runTest_beta hn3.2.1 hb2).mpr s2]
      exact (runTest_beta hn3.2.2 hb3).mpr s3
  · simp [ha]

/-! ## Splitting a test keeps its meaning when the kinds agree -/

def Term.kind (κ : String → Nat) : Term → Nat
  | .var x => κ x
  | .sym c => c.kind

/-- The variables take values of the kinds `κ` gives them. -/
def Respects (κ : String → Nat) (β : Binding) : Prop := ∀ v s, β.get v = some s → s.kind = κ v

/-- Every relational test against a variable in a test compares values of one kind (a number
with a number, an identifier with an identifier). -/
def Test.Typed (κ : String → Nat) (t : Test) : Prop :=
  ∀ me, eqTerm? t = some me → ∀ st ∈ t, ∀ r y, st = .rel r (.var y) → me.kind κ = κ y ∧ κ y ≠ 0

theorem Term.value_kind {κ : String → Nat} {β : Binding} (h : Respects κ β) {me : Term} {x : Sym}
    (hv : me.value β = some x) : x.kind = me.kind κ := by
  cases me with
  | var v => exact h v x hv
  | sym c => simp [Term.value] at hv; subst hv; rfl

theorem eqTerm_spec : ∀ {t : Test} {me : Term}, eqTerm? t = some me →
    ∃ st ∈ t, (∃ v, st = .var v ∧ me = .var v) ∨ (∃ c, st = .const c ∧ me = .sym c)
  | [], me, h => by simp [eqTerm?] at h
  | st :: t, me, h => by
    unfold eqTerm? at h
    rw [List.findSome?_cons] at h
    cases st with
    | var v => simp at h; exact ⟨.var v, by simp, Or.inl ⟨v, rfl, h.symm⟩⟩
    | const c => simp at h; exact ⟨.const c, by simp, Or.inr ⟨c, rfl, h.symm⟩⟩
    | rel r u => simp at h; obtain ⟨st', h1, h2⟩ := eqTerm_spec (t := t) h; exact ⟨st', by simp [h1], h2⟩
    | disj u => simp at h; obtain ⟨st', h1, h2⟩ := eqTerm_spec (t := t) h; exact ⟨st', by simp [h1], h2⟩
    | lti u => simp at h; obtain ⟨st', h1, h2⟩ := eqTerm_spec (t := t) h; exact ⟨st', by simp [h1], h2⟩
    | ltiRel u v => simp at h; obtain ⟨st', h1, h2⟩ := eqTerm_spec (t := t) h; exact ⟨st', by simp [h1], h2⟩

theorem eqTerm_value {β : Binding} {s : Sym} {t : Test} {me : Term} (h : eqTerm? t = some me)
    (hs : Test.sat β s t) : me.value β = some s := by
  obtain ⟨st, hst, hc⟩ := eqTerm_spec h
  have := hs st hst
  rcases hc with ⟨v, rfl, rfl⟩ | ⟨c, rfl, rfl⟩
  · exact this
  · simp [STest.sat] at this; simp [Term.value, this]

/-- A test moved to the condition that binds `y`, holds of the value `y` has. -/
def MovedSat (β : Binding) (m : String × STest) : Prop :=
  ∃ sy, β.get m.1 = some sy ∧ m.2.sat β sy

/-- Which tests splitting keeps. -/
def keepSt (ok : String → Bool) : STest → Bool
  | .rel _ (.var y) => ok y
  | .ltiRel _ (.var y) => ok y
  | _ => true

/-- What splitting takes out of a test. -/
def moveSt (ok : String → Bool) (me : Term) : STest → Option (String × STest)
  | .rel r (.var y) => if ok y then none else some (y, .rel r.inv me)
  | .ltiRel b (.var y) => if ok y then none else some (y, .ltiRel b me)
  | _ => none

theorem foldl_split (ok : String → Bool) (me : Term) :
    ∀ (l : Test) (acc : Test × List (String × STest)),
      l.foldl (splitRelStep ok me) acc =
        (acc.1 ++ l.filter (keepSt ok), acc.2 ++ l.filterMap (moveSt ok me))
  | [], acc => by simp
  | st :: l, acc => by
    rw [List.foldl_cons, foldl_split ok me l]
    cases st with
    | rel r u =>
      cases u with
      | var y =>
        by_cases hy : ok y = true
        · simp [splitRelStep, keepSt, moveSt, hy, List.filter_cons, List.filterMap_cons]
        · simp [splitRelStep, keepSt, moveSt, hy, List.filter_cons, List.filterMap_cons]
      | sym c => simp [splitRelStep, keepSt, moveSt, List.filter_cons, List.filterMap_cons]
    | ltiRel b u =>
      cases u with
      | var y =>
        by_cases hy : ok y = true
        · simp [splitRelStep, keepSt, moveSt, hy, List.filter_cons, List.filterMap_cons]
        · simp [splitRelStep, keepSt, moveSt, hy, List.filter_cons, List.filterMap_cons]
      | sym c => simp [splitRelStep, keepSt, moveSt, List.filter_cons, List.filterMap_cons]
    | var v => simp [splitRelStep, keepSt, moveSt, List.filter_cons, List.filterMap_cons]
    | const c => simp [splitRelStep, keepSt, moveSt, List.filter_cons, List.filterMap_cons]
    | disj c => simp [splitRelStep, keepSt, moveSt, List.filter_cons, List.filterMap_cons]
    | lti b => simp [splitRelStep, keepSt, moveSt, List.filter_cons, List.filterMap_cons]

theorem moved_iff {κ : String → Nat} {β : Binding} (hr : Respects κ β) {me : Term} {s : Sym}
    (hme : me.value β = some s) {r : RelOp} {y : String} (hk : me.kind κ = κ y) (hk0 : κ y ≠ 0) :
    (STest.rel r (.var y)).sat β s ↔ MovedSat β (y, .rel r.inv me) := by
  have hs : s.kind = κ y := by rw [Term.value_kind hr hme, hk]
  have hv : ∀ y, (Term.var y).value β = β.get y := fun _ => rfl
  simp only [STest.sat, MovedSat, hv]
  constructor
  · rintro ⟨x, hx, h⟩
    refine ⟨x, hx, s, hme, ?_⟩
    rw [← RelOp.holds_inv_kind r s x (by rw [hs, hr y x hx]) (by rw [hs]; exact hk0)]; exact h
  · rintro ⟨sy, hsy, x', hx', h⟩
    rw [hme] at hx'; cases hx'
    refine ⟨sy, hsy, ?_⟩
    rw [RelOp.holds_inv_kind r s sy (by rw [hs, hr y sy hsy]) (by rw [hs]; exact hk0)]; exact h

theorem not_keep {ok : String → Bool} {st : STest} (hn : st.noLti = true) (h : keepSt ok st = false) :
    ∃ r y, st = .rel r (.var y) ∧ ok y = false := by
  cases st with
  | rel r u =>
    cases u with
    | var y => exact ⟨r, y, rfl, by simpa [keepSt] using h⟩
    | sym c => simp [keepSt] at h
  | ltiRel b u => simp [STest.noLti] at hn
  | var v => simp [keepSt] at h
  | const c => simp [keepSt] at h
  | disj c => simp [keepSt] at h
  | lti b => simp [STest.noLti] at hn

/-- **Splitting a test.** Under bindings that respect the kinds, a test with its relational
tests against unbound variables taken out holds of a value exactly when the moved tests hold
where they are put. -/
theorem splitRel_sat (ok : String → Bool) (t : Test) (hn : Test.noLti t = true)
    {κ : String → Nat} {β : Binding} (hr : Respects κ β) (ht : Test.Typed κ t) (s : Sym) :
    Test.sat β s t ↔ Test.sat β s (splitRel ok t).1 ∧ ∀ m ∈ (splitRel ok t).2, MovedSat β m := by
  have hnl : ∀ st ∈ t, st.noLti = true := fun st hst => by
    unfold Test.noLti at hn; exact List.all_eq_true.mp hn st hst
  unfold splitRel
  cases heq : eqTerm? t with
  | none => simp
  | some me =>
    simp only
    rw [foldl_split]
    simp only [List.nil_append]
    constructor
    · intro hs
      have hme := eqTerm_value heq hs
      refine ⟨fun st hst => hs st (List.mem_filter.mp hst).1, fun m hm => ?_⟩
      obtain ⟨st, hst, hm⟩ := List.mem_filterMap.mp hm
      cases st with
      | rel r u =>
        cases u with
        | var y =>
          by_cases hy : ok y = true
          · simp [moveSt, hy] at hm
          · simp [moveSt, hy] at hm
            subst hm
            obtain ⟨hk, hk0⟩ := ht me heq _ hst r y rfl
            exact (moved_iff hr hme hk hk0).mp (hs _ hst)
        | sym c => simp [moveSt] at hm
      | ltiRel b u => have := hnl _ hst; simp [STest.noLti] at this
      | var v => simp [moveSt] at hm
      | const c => simp [moveSt] at hm
      | disj c => simp [moveSt] at hm
      | lti b => simp [moveSt] at hm
    · rintro ⟨h1, h2⟩
      have hme : me.value β = some s := by
        obtain ⟨st, hst, hc⟩ := eqTerm_spec heq
        have hk : st ∈ t.filter (keepSt ok) := by
          rcases hc with ⟨v, rfl, _⟩ | ⟨c, rfl, _⟩ <;> exact List.mem_filter.mpr ⟨hst, by simp [keepSt]⟩
        have := h1 st hk
        rcases hc with ⟨v, rfl, rfl⟩ | ⟨c, rfl, rfl⟩
        · exact this
        · simp [STest.sat] at this; simp [Term.value, this]
      intro st hst
      cases hk : keepSt ok st
      · obtain ⟨r, y, rfl, hy⟩ := not_keep (hnl st hst) hk
        obtain ⟨hk1, hk0⟩ := ht me heq _ hst r y rfl
        have hm : (y, STest.rel r.inv me) ∈ t.filterMap (moveSt ok me) :=
          List.mem_filterMap.mpr ⟨_, hst, by simp [moveSt, hy]⟩
        exact (moved_iff hr hme hk1 hk0).mpr (h2 _ hm)
      · exact h1 st (List.mem_filter.mpr ⟨hst, hk⟩)

/-! ## Splitting and placing in patterns -/

def Pat.Typed (κ : String → Nat) (p : Pat) : Prop :=
  Test.Typed κ p.id ∧ Test.Typed κ p.attr ∧ Test.Typed κ p.val

/-- The tests a pattern gives up when its relational tests against unbound variables move. -/
def Pat.movedOf (ok : String → Bool) (p : Pat) : List (String × STest) :=
  (splitRel ok p.id).2 ++ (splitRel ok p.attr).2 ++ (splitRel ok p.val).2

def Pat.splitOf (ok : String → Bool) (p : Pat) : Pat :=
  { p with id := (splitRel ok p.id).1, attr := (splitRel ok p.attr).1, val := (splitRel ok p.val).1 }

theorem Pat.splitOf_sat (ok : String → Bool) {p : Pat} (hn : p.noLti = true) {κ : String → Nat}
    {β : Binding} (hr : Respects κ β) (ht : Pat.Typed κ p) (w : WME) :
    Pat.sat β p w ↔ Pat.sat β (Pat.splitOf ok p) w ∧ ∀ m ∈ Pat.movedOf ok p, MovedSat β m := by
  have hn3 : Test.noLti p.id = true ∧ Test.noLti p.attr = true ∧ Test.noLti p.val = true := by
    simpa [Pat.noLti, Bool.and_eq_true, and_assoc] using hn
  have e1 := splitRel_sat ok p.id hn3.1 hr ht.1 (.id w.id)
  have e2 := splitRel_sat ok p.attr hn3.2.1 hr ht.2.1 w.attr
  have e3 := splitRel_sat ok p.val hn3.2.2 hr ht.2.2 w.val
  unfold Pat.sat Pat.splitOf Pat.movedOf
  simp only [List.mem_append]
  rw [e1, e2, e3]
  constructor
  · rintro ⟨ha, ⟨a1, b1⟩, ⟨a2, b2⟩, ⟨a3, b3⟩⟩
    exact ⟨⟨ha, a1, a2, a3⟩, fun m hm => by
      rcases hm with (hm | hm) | hm
      · exact b1 m hm
      · exact b2 m hm
      · exact b3 m hm⟩
  · rintro ⟨⟨ha, a1, a2, a3⟩, hm⟩
    exact ⟨ha, ⟨a1, fun m h => hm m (Or.inl (Or.inl h))⟩, ⟨a2, fun m h => hm m (Or.inl (Or.inr h))⟩,
      ⟨a3, fun m h => hm m (Or.inr h)⟩⟩

theorem fieldAdd {β : Binding} {t : Test} {y : String} {st : STest} {s : Sym}
    (h : eqTerm? t = some (.var y)) :
    Test.sat β s (t ++ [st]) ↔ Test.sat β s t ∧ MovedSat β (y, st) := by
  unfold Test.sat MovedSat
  simp only [List.mem_append, List.mem_singleton]
  constructor
  · intro hs
    have ht : ∀ x ∈ t, x.sat β s := fun x hx => hs x (Or.inl hx)
    have hy := eqTerm_value h ht
    exact ⟨ht, s, hy, hs st (Or.inr rfl)⟩
  · rintro ⟨ht, sy, hsy, hst⟩ x hx
    rcases hx with hx | rfl
    · exact ht x hx
    · have hy := eqTerm_value (β := β) (s := s) h ht
      simp [Term.value] at hy
      rw [hy] at hsy; cases hsy; exact hst

theorem addFor_sat {β : Binding} {y : String} {st : STest} {p q : Pat} (h : p.addFor y st = some q)
    (w : WME) : Pat.sat β q w ↔ Pat.sat β p w ∧ MovedSat β (y, st) := by
  unfold Pat.addFor at h
  dsimp only at h
  split at h
  · rename_i hv
    cases h
    have hv' : eqTerm? p.val = some (.var y) := by simpa using hv
    unfold Pat.sat
    rw [fieldAdd hv']
    simp only
    constructor
    · rintro ⟨a, b, c, d, e⟩; exact ⟨⟨a, b, c, d⟩, e⟩
    · rintro ⟨⟨a, b, c, d⟩, e⟩; exact ⟨a, b, c, d, e⟩
  · split at h
    · rename_i hv hi
      cases h
      have hv' : eqTerm? p.id = some (.var y) := by simpa using hi
      unfold Pat.sat
      rw [fieldAdd hv']
      simp only
      constructor
      · rintro ⟨a, ⟨b, e⟩, c, d⟩; exact ⟨⟨a, b, c, d⟩, e⟩
      · rintro ⟨⟨a, b, c, d⟩, e⟩; exact ⟨a, ⟨b, e⟩, c, d⟩
    · split at h
      · rename_i hv hi ha
        cases h
        have hv' : eqTerm? p.attr = some (.var y) := by simpa using ha
        unfold Pat.sat
        rw [fieldAdd hv']
        simp only
        constructor
        · rintro ⟨a, b, ⟨c, e⟩, d⟩; exact ⟨⟨a, b, c, d⟩, e⟩
        · rintro ⟨⟨a, b, c, d⟩, e⟩; exact ⟨a, b, ⟨c, e⟩, d⟩
      · cases h

/-! ## Placing moved tests -/

/-- Every positive pattern of the conditions matches some element under the bindings `β`. -/
def PosSat (wm : List WME) (β : Binding) (cs : List Cond) : Prop :=
  ∀ c ∈ cs, ∀ p, c = .pos p → ∃ w ∈ wm, Pat.sat β p w

theorem posSat_append {wm : List WME} {β : Binding} {l₁ l₂ : List Cond} :
    PosSat wm β (l₁ ++ l₂) ↔ PosSat wm β l₁ ∧ PosSat wm β l₂ := by
  unfold PosSat
  constructor
  · intro h; exact ⟨fun c hc => h c (List.mem_append_left _ hc), fun c hc => h c (List.mem_append_right _ hc)⟩
  · rintro ⟨h1, h2⟩ c hc
    rcases List.mem_append.mp hc with hc | hc
    · exact h1 c hc
    · exact h2 c hc

theorem posSat_pos {wm : List WME} {β : Binding} {q : Pat} :
    PosSat wm β [.pos q] ↔ ∃ w ∈ wm, Pat.sat β q w := by
  unfold PosSat
  constructor
  · intro h; exact h (.pos q) (by simp) q rfl
  · intro h c hc p hp
    simp at hc; subst hc; cases hp; exact h

theorem posSat_other {wm : List WME} {β : Binding} {c : Cond} (h : ∀ p, c ≠ .pos p) :
    PosSat wm β [c] := by
  intro c' hc' p hp
  simp at hc'; subst hc'; exact absurd hp (h p)

theorem foldl_placeStep_sat {wm : List WME} {β : Binding} (m : String × STest) :
    ∀ (cs pre : List Cond) (f : Bool), ((cs.foldl (placeStep m) (pre, f)).2 = true) →
      (PosSat wm β (cs.foldl (placeStep m) (pre, f)).1 ↔
        PosSat wm β (pre ++ cs) ∧ (f = true ∨ MovedSat β m))
  | [], pre, f, h => by
    simp only [List.foldl_nil] at h ⊢
    simp [h]
  | c :: cs, pre, f, h => by
    rw [List.foldl_cons] at h ⊢
    by_cases hf : f = true
    · have e : placeStep m (pre, f) c = (pre ++ [c], true) := by simp [placeStep, hf]
      rw [e] at h ⊢
      rw [foldl_placeStep_sat m cs _ _ h]
      simp [hf, List.append_assoc]
    · have hf' : f = false := by simpa using hf
      subst hf'
      cases c with
      | pos q =>
        cases hq : q.addFor m.1 m.2 with
        | none =>
          have e : placeStep m (pre, false) (.pos q) = (pre ++ [.pos q], false) := by
            simp [placeStep, hq]
          rw [e] at h ⊢
          rw [foldl_placeStep_sat m cs _ _ h]
          simp [List.append_assoc]
        | some q' =>
          have e : placeStep m (pre, false) (.pos q) = (pre ++ [.pos q'], true) := by
            simp [placeStep, hq]
          rw [e] at h ⊢
          rw [foldl_placeStep_sat m cs _ _ h]
          simp only [true_or, and_true, List.append_assoc, List.singleton_append, Bool.false_eq_true,
            false_or]
          have hs : PosSat wm β [.pos q'] ↔ PosSat wm β [.pos q] ∧ MovedSat β m := by
            rw [posSat_pos, posSat_pos]
            constructor
            · rintro ⟨w, hw, hs⟩
              have := (addFor_sat hq w).mp hs
              exact ⟨⟨w, hw, this.1⟩, this.2⟩
            · rintro ⟨⟨w, hw, hs⟩, hm⟩
              exact ⟨w, hw, (addFor_sat hq w).mpr ⟨hs, hm⟩⟩
          have e1 : pre ++ .pos q' :: cs = pre ++ [.pos q'] ++ cs := by simp
          have e2 : pre ++ .pos q :: cs = pre ++ [.pos q] ++ cs := by simp
          rw [e1, e2, posSat_append, posSat_append, posSat_append, posSat_append, hs]
          constructor
          · rintro ⟨⟨a, b, c⟩, d⟩; exact ⟨⟨⟨a, b⟩, d⟩, c⟩
          · rintro ⟨⟨⟨a, b⟩, d⟩, c⟩; exact ⟨⟨a, b, c⟩, d⟩
      | neg ps =>
        have e : placeStep m (pre, false) (.neg ps) = (pre ++ [.neg ps], false) := by simp [placeStep]
        rw [e] at h ⊢
        rw [foldl_placeStep_sat m cs _ _ h]
        simp [List.append_assoc]
      | ncc ps ns =>
        have e : placeStep m (pre, false) (.ncc ps ns) = (pre ++ [.ncc ps ns], false) := by simp [placeStep]
        rw [e] at h ⊢
        rw [foldl_placeStep_sat m cs _ _ h]
        simp [List.append_assoc]
      | nccg ns =>
        have e : placeStep m (pre, false) (.nccg ns) = (pre ++ [.nccg ns], false) := by simp [placeStep]
        rw [e] at h ⊢
        rw [foldl_placeStep_sat m cs _ _ h]
        simp [List.append_assoc]

theorem placeRel_sat {wm : List WME} {β : Binding} (cs : List Cond) (m : String × STest)
    (h : (placeRel cs m).2 = true) :
    PosSat wm β (placeRel cs m).1 ↔ PosSat wm β cs ∧ MovedSat β m := by
  unfold placeRel at h ⊢
  rw [foldl_placeStep_sat m cs [] false h]
  simp

theorem foldl_placeAll_sat {wm : List WME} {β : Binding} :
    ∀ (ms : List (String × STest)) (acc : List Cond × Bool), (ms.foldl placeAllStep acc).2 = true →
      acc.2 = true ∧ (PosSat wm β (ms.foldl placeAllStep acc).1 ↔
        PosSat wm β acc.1 ∧ ∀ m ∈ ms, MovedSat β m)
  | [], acc, h => by simp at h ⊢; exact h
  | m :: ms, acc, h => by
    rw [List.foldl_cons] at h ⊢
    obtain ⟨h1, h2⟩ := foldl_placeAll_sat ms _ h
    have h1' : acc.2 = true ∧ (placeRel acc.1 m).2 = true := by
      simpa [placeAllStep] using h1
    refine ⟨h1'.1, ?_⟩
    rw [h2]
    have := placeRel_sat (wm := wm) (β := β) acc.1 m h1'.2
    simp only [placeAllStep] at this ⊢
    rw [this]
    constructor
    · rintro ⟨⟨a, b⟩, c⟩; exact ⟨a, fun m' hm' => by
        rcases List.mem_cons.mp hm' with rfl | hm'
        · exact b
        · exact c m' hm'⟩
    · rintro ⟨a, b⟩; exact ⟨⟨a, b m (by simp)⟩, fun m' hm' => b m' (List.mem_cons_of_mem _ hm')⟩

/-! ## The invariant: no `@` tests, relational tests between variables of one kind -/

def Cond.Good (κ : String → Nat) : Cond → Prop
  | .pos p => p.noLti = true ∧ Pat.Typed κ p
  | _ => True

def AllGood (κ : String → Nat) (cs : List Cond) : Prop := ∀ c ∈ cs, Cond.Good κ c

/-- A moved test relates variables of one kind. -/
def MovedTyped (κ : String → Nat) (m : String × STest) : Prop :=
  m.2.noLti = true ∧ ∀ r z, m.2 = .rel r (.var z) → κ z = κ m.1 ∧ κ m.1 ≠ 0

theorem findSome_filter_keep {ok : String → Bool} : ∀ (t : Test),
    (t.filter (keepSt ok)).findSome? (fun st => match st with
      | .var v => some (Term.var v) | .const c => some (Term.sym c) | _ => none) =
    t.findSome? (fun st => match st with
      | .var v => some (Term.var v) | .const c => some (Term.sym c) | _ => none)
  | [] => rfl
  | st :: t => by
    have ih := findSome_filter_keep (ok := ok) t
    cases st with
    | rel r u =>
      cases u with
      | var y =>
        by_cases hy : ok y = true
        · simp [List.filter_cons, keepSt, hy, List.findSome?_cons, ih]
        · simp [List.filter_cons, keepSt, hy, List.findSome?_cons, ih]
      | sym c => simp [List.filter_cons, keepSt, List.findSome?_cons, ih]
    | ltiRel b u =>
      cases u with
      | var y =>
        by_cases hy : ok y = true
        · simp [List.filter_cons, keepSt, hy, List.findSome?_cons, ih]
        · simp [List.filter_cons, keepSt, hy, List.findSome?_cons, ih]
      | sym c => simp [List.filter_cons, keepSt, List.findSome?_cons, ih]
    | var v => simp [List.filter_cons, keepSt, List.findSome?_cons]
    | const c => simp [List.filter_cons, keepSt, List.findSome?_cons]
    | disj c => simp [List.filter_cons, keepSt, List.findSome?_cons, ih]
    | lti c => simp [List.filter_cons, keepSt, List.findSome?_cons, ih]

theorem splitRel_none (ok : String → Bool) {t : Test} (h : eqTerm? t = none) :
    splitRel ok t = (t, []) := by
  unfold splitRel; rw [h]

theorem splitRel_some (ok : String → Bool) {t : Test} {me : Term} (h : eqTerm? t = some me) :
    splitRel ok t = (t.filter (keepSt ok), t.filterMap (moveSt ok me)) := by
  unfold splitRel; rw [h]; simp only; rw [foldl_split]; simp

theorem splitRel_typed (ok : String → Bool) {κ : String → Nat} {t : Test} (hn : Test.noLti t = true)
    (ht : Test.Typed κ t) :
    Test.noLti (splitRel ok t).1 = true ∧ Test.Typed κ (splitRel ok t).1 ∧
      ∀ m ∈ (splitRel ok t).2, MovedTyped κ m := by
  cases heq : eqTerm? t with
  | none => rw [splitRel_none ok heq]; exact ⟨hn, ht, by simp⟩
  | some me =>
    rw [splitRel_some ok heq]
    refine ⟨?_, ?_, ?_⟩
    · unfold Test.noLti at hn ⊢
      exact List.all_eq_true.mpr fun st hst => List.all_eq_true.mp hn st (List.mem_filter.mp hst).1
    · intro me' hme' st hst r y hsy
      have e : eqTerm? (t.filter (keepSt ok)) = eqTerm? t := findSome_filter_keep t
      rw [e, heq] at hme'; cases hme'
      exact ht me heq st (List.mem_filter.mp hst).1 r y hsy
    · intro m hm
      obtain ⟨st, hst, hm⟩ := List.mem_filterMap.mp hm
      cases st with
      | rel r u =>
        cases u with
        | var y =>
          by_cases hy : ok y = true
          · simp [moveSt, hy] at hm
          · simp [moveSt, hy] at hm
            subst hm
            obtain ⟨hk, hk0⟩ := ht me heq _ hst r y rfl
            refine ⟨by simp [STest.noLti], fun r' z hz => ?_⟩
            simp only [STest.rel.injEq] at hz
            obtain ⟨_, hz⟩ := hz
            subst hz
            exact ⟨hk, hk0⟩
        | sym c => simp [moveSt] at hm
      | ltiRel b u =>
        have := List.all_eq_true.mp hn _ hst; simp [STest.noLti] at this
      | var v => simp [moveSt] at hm
      | const c => simp [moveSt] at hm
      | disj c => simp [moveSt] at hm
      | lti b => simp [moveSt] at hm

theorem fieldAdd_good {κ : String → Nat} {t : Test} {y : String} {st : STest}
    (h : eqTerm? t = some (.var y)) (hn : Test.noLti t = true) (ht : Test.Typed κ t)
    (hm : MovedTyped κ (y, st)) :
    Test.noLti (t ++ [st]) = true ∧ Test.Typed κ (t ++ [st]) := by
  constructor
  · unfold Test.noLti at hn ⊢
    simp only [List.all_append, List.all_cons, List.all_nil, Bool.and_true, Bool.and_eq_true]
    exact ⟨hn, hm.1⟩
  · have e : eqTerm? (t ++ [st]) = eqTerm? t := by
      unfold eqTerm?
      rw [List.findSome?_append]
      unfold eqTerm? at h
      rw [h]; rfl
    intro me hme st' hst' r z hz
    rw [e, h] at hme; cases hme
    rcases List.mem_append.mp hst' with hst' | hst'
    · exact ht _ h st' hst' r z hz
    · simp at hst'; subst hst'
      obtain ⟨a, b⟩ := hm.2 r z hz
      exact ⟨a.symm, by rw [a]; exact b⟩

theorem addFor_good {κ : String → Nat} {y : String} {st : STest} {p q : Pat}
    (h : p.addFor y st = some q) (hn : p.noLti = true) (ht : Pat.Typed κ p)
    (hm : MovedTyped κ (y, st)) : q.noLti = true ∧ Pat.Typed κ q := by
  have hn3 : Test.noLti p.id = true ∧ Test.noLti p.attr = true ∧ Test.noLti p.val = true := by
    simpa [Pat.noLti, Bool.and_eq_true, and_assoc] using hn
  unfold Pat.addFor at h
  dsimp only at h
  split at h
  · rename_i hv
    cases h
    have hv' : eqTerm? p.val = some (.var y) := by simpa using hv
    obtain ⟨a, b⟩ := fieldAdd_good hv' hn3.2.2 ht.2.2 hm
    exact ⟨by simp [Pat.noLti, hn3.1, hn3.2.1, a], ht.1, ht.2.1, b⟩
  · split at h
    · rename_i hv hi
      cases h
      have hv' : eqTerm? p.id = some (.var y) := by simpa using hi
      obtain ⟨a, b⟩ := fieldAdd_good hv' hn3.1 ht.1 hm
      exact ⟨by simp [Pat.noLti, hn3.2.1, hn3.2.2, a], b, ht.2.1, ht.2.2⟩
    · split at h
      · rename_i hv hi ha
        cases h
        have hv' : eqTerm? p.attr = some (.var y) := by simpa using ha
        obtain ⟨a, b⟩ := fieldAdd_good hv' hn3.2.1 ht.2.1 hm
        exact ⟨by simp [Pat.noLti, hn3.1, hn3.2.2, a], ht.1, b, ht.2.2⟩
      · cases h

theorem foldl_placeStep_good {κ : String → Nat} (m : String × STest) (hm : MovedTyped κ m) :
    ∀ (cs pre : List Cond) (f : Bool), AllGood κ pre → AllGood κ cs →
      AllGood κ (cs.foldl (placeStep m) (pre, f)).1
  | [], pre, f, hp, hc => by simpa using hp
  | c :: cs, pre, f, hp, hc => by
    rw [List.foldl_cons]
    have hcs : AllGood κ cs := fun x hx => hc x (List.mem_cons_of_mem _ hx)
    have hc0 : Cond.Good κ c := hc c (by simp)
    have key : AllGood κ (placeStep m (pre, f) c).1 := by
      unfold placeStep
      split
      · intro x hx
        rcases List.mem_append.mp hx with hx | hx
        · exact hp x hx
        · simp at hx; subst hx; exact hc0
      · split
        · rename_i q
          split
          · rename_i q' hq
            intro x hx
            rcases List.mem_append.mp hx with hx | hx
            · exact hp x hx
            · simp at hx; subst hx
              exact addFor_good hq hc0.1 hc0.2 hm
          · intro x hx
            rcases List.mem_append.mp hx with hx | hx
            · exact hp x hx
            · simp at hx; subst hx; exact hc0
        · intro x hx
          rcases List.mem_append.mp hx with hx | hx
          · exact hp x hx
          · simp at hx; subst hx; exact hc0
    exact foldl_placeStep_good m hm cs _ _ key hcs

theorem foldl_placeAll_good {κ : String → Nat} :
    ∀ (ms : List (String × STest)) (acc : List Cond × Bool), (∀ m ∈ ms, MovedTyped κ m) →
      AllGood κ acc.1 → AllGood κ (ms.foldl placeAllStep acc).1
  | [], acc, _, h => h
  | m :: ms, acc, hm, h => by
    rw [List.foldl_cons]
    refine foldl_placeAll_good ms _ (fun m' hm' => hm m' (List.mem_cons_of_mem _ hm')) ?_
    unfold placeAllStep placeRel
    exact foldl_placeStep_good m (hm m (by simp)) acc.1 [] false (fun _ hx => by simp at hx) h

theorem moveRel_pos (bound : List String) (p : Pat) (rest : List Cond) :
    moveRel bound (.pos p) rest =
      (if ((Pat.movedOf (fun y => bound.contains y || p.eqVars.contains y) p).foldl placeAllStep
            (rest, true)).2 = true
       then (.pos (Pat.splitOf (fun y => bound.contains y || p.eqVars.contains y) p),
          ((Pat.movedOf (fun y => bound.contains y || p.eqVars.contains y) p).foldl placeAllStep
            (rest, true)).1)
       else (.pos p, rest)) := rfl

theorem moveRel_good {κ : String → Nat} (bound : List String) (best : Cond) (rest : List Cond)
    (hb : Cond.Good κ best) (hr : AllGood κ rest) :
    Cond.Good κ (moveRel bound best rest).1 ∧ AllGood κ (moveRel bound best rest).2 := by
  cases best with
  | pos p =>
    rw [moveRel_pos]
    split
    · rename_i hf
      have hn3 : Test.noLti p.id = true ∧ Test.noLti p.attr = true ∧ Test.noLti p.val = true := by
        simpa [Pat.noLti, Bool.and_eq_true, and_assoc] using hb.1
      obtain ⟨n1, t1, m1⟩ := splitRel_typed (fun y => bound.contains y || p.eqVars.contains y) hn3.1 hb.2.1
      obtain ⟨n2, t2, m2⟩ := splitRel_typed (fun y => bound.contains y || p.eqVars.contains y) hn3.2.1 hb.2.2.1
      obtain ⟨n3, t3, m3⟩ := splitRel_typed (fun y => bound.contains y || p.eqVars.contains y) hn3.2.2 hb.2.2.2
      refine ⟨⟨?_, t1, t2, t3⟩, ?_⟩
      · simp only [Pat.noLti, Pat.splitOf]; rw [n1, n2, n3]; rfl
      · refine foldl_placeAll_good _ _ ?_ hr
        intro m hm
        unfold Pat.movedOf at hm
        simp only [List.mem_append] at hm
        rcases hm with (hm | hm) | hm
        · exact m1 m hm
        · exact m2 m hm
        · exact m3 m hm
    · exact ⟨hb, hr⟩
  | neg ps => exact ⟨hb, hr⟩
  | ncc ps ns => exact ⟨hb, hr⟩
  | nccg ns => exact ⟨hb, hr⟩

/-- **Moving relational tests keeps the matches (one step).** When the tests of a condition
that `moveRel` moves compare values of one kind, the positive patterns hold under the same
bindings before and after the move. -/
theorem moveRel_sat {wm : List WME} {κ : String → Nat} {β : Binding} (hr : Respects κ β)
    (bound : List String) (best : Cond) (rest : List Cond) (hb : Cond.Good κ best) :
    PosSat wm β ((moveRel bound best rest).1 :: (moveRel bound best rest).2) ↔
      PosSat wm β (best :: rest) := by
  cases best with
  | pos p =>
    rw [moveRel_pos]
    split
    · rename_i hf
      obtain ⟨_, h2⟩ := foldl_placeAll_sat (wm := wm) (β := β)
        (Pat.movedOf (fun y => bound.contains y || p.eqVars.contains y) p) (rest, true) hf
      change PosSat wm β ([Cond.pos (Pat.splitOf _ p)] ++ _) ↔ PosSat wm β ([Cond.pos p] ++ rest)
      rw [posSat_append, posSat_append, posSat_pos, posSat_pos, h2]
      simp only
      have e := Pat.splitOf_sat (fun y => bound.contains y || p.eqVars.contains y) hb.1 hr hb.2
      constructor
      · rintro ⟨⟨w, hw, hs⟩, hrest, hm⟩
        exact ⟨⟨w, hw, (e w).mpr ⟨hs, hm⟩⟩, hrest⟩
      · rintro ⟨⟨w, hw, hs⟩, hrest⟩
        obtain ⟨hs', hm⟩ := (e w).mp hs
        exact ⟨⟨w, hw, hs'⟩, hrest, hm⟩
    · exact Iff.rfl
  | neg ps => exact Iff.rfl
  | ncc ps ns => exact Iff.rfl
  | nccg ns => exact Iff.rfl

/-! ## The join order -/

theorem posSat_perm {wm : List WME} {β : Binding} {l₁ l₂ : List Cond} (hp : l₁.Perm l₂) :
    PosSat wm β l₁ ↔ PosSat wm β l₂ := by
  unfold PosSat
  constructor
  · intro h c hc; exact h c (hp.mem_iff.mpr hc)
  · intro h c hc; exact h c (hp.mem_iff.mp hc)

theorem posSat_acc_cons {wm : List WME} {β : Binding} (acc : List Cond) (c : Cond) (r : List Cond) :
    PosSat wm β (acc ++ [c] ++ r) ↔ PosSat wm β acc ∧ PosSat wm β (c :: r) := by
  rw [List.append_assoc, posSat_append]; rfl

theorem allGood_append {κ : String → Nat} {l₁ l₂ : List Cond} :
    AllGood κ (l₁ ++ l₂) ↔ AllGood κ l₁ ∧ AllGood κ l₂ := by
  unfold AllGood
  constructor
  · intro h; exact ⟨fun c hc => h c (List.mem_append_left _ hc), fun c hc => h c (List.mem_append_right _ hc)⟩
  · rintro ⟨h1, h2⟩ c hc
    rcases List.mem_append.mp hc with hc | hc
    · exact h1 c hc
    · exact h2 c hc

theorem allGood_perm {κ : String → Nat} {l₁ l₂ : List Cond} (hp : l₁.Perm l₂) :
    AllGood κ l₁ ↔ AllGood κ l₂ := by
  unfold AllGood
  constructor
  · intro h c hc; exact h c (hp.mem_iff.mpr hc)
  · intro h c hc; exact h c (hp.mem_iff.mp hc)

/-- One greedy step of the join order keeps the positive patterns' holding. -/
theorem joinStep_sat {wm : List WME} {κ : String → Nat} {β : Binding} (hr : Respects κ β)
    (multi : List (String × Nat)) (acc rest pool : List Cond) (c₀ : Cond)
    (hsub : ∀ x ∈ pool, x ∈ rest) (hc : c₀ ∈ pool) (b : Bool) (bound : List String)
    (Φ Ψ : Cond → List Cond → Prop)
    (hΦ : ∀ c r, AllGood κ (acc ++ [c] ++ r) → (Φ c r ↔ PosSat wm β (acc ++ [c] ++ r)))
    (hΨ : ∀ c r, AllGood κ (acc ++ [c] ++ r) → Ψ c r)
    (hgood : AllGood κ (acc ++ rest)) :
    (Φ (if b then moveRel bound (pool.foldl (pickBest multi bound) c₀)
            (rest.eraseIdx (rest.idxOf (pool.foldl (pickBest multi bound) c₀)))
          else (pool.foldl (pickBest multi bound) c₀,
            rest.eraseIdx (rest.idxOf (pool.foldl (pickBest multi bound) c₀)))).1
        (if b then moveRel bound (pool.foldl (pickBest multi bound) c₀)
            (rest.eraseIdx (rest.idxOf (pool.foldl (pickBest multi bound) c₀)))
          else (pool.foldl (pickBest multi bound) c₀,
            rest.eraseIdx (rest.idxOf (pool.foldl (pickBest multi bound) c₀)))).2
      ↔ PosSat wm β (acc ++ rest)) ∧
    Ψ (if b then moveRel bound (pool.foldl (pickBest multi bound) c₀)
            (rest.eraseIdx (rest.idxOf (pool.foldl (pickBest multi bound) c₀)))
          else (pool.foldl (pickBest multi bound) c₀,
            rest.eraseIdx (rest.idxOf (pool.foldl (pickBest multi bound) c₀)))).1
        (if b then moveRel bound (pool.foldl (pickBest multi bound) c₀)
            (rest.eraseIdx (rest.idxOf (pool.foldl (pickBest multi bound) c₀)))
          else (pool.foldl (pickBest multi bound) c₀,
            rest.eraseIdx (rest.idxOf (pool.foldl (pickBest multi bound) c₀)))).2 := by
  generalize hb : pool.foldl (pickBest multi bound) c₀ = best
  have hbest : best ∈ rest := by
    rw [← hb]
    rcases List.mem_cons.mp (foldl_pickBest_mem multi bound pool c₀) with h | h
    · rw [h]; exact hsub _ hc
    · exact hsub _ h
  have hperm : (best :: rest.eraseIdx (rest.idxOf best)).Perm rest :=
    (perm_eraseIdx_idxOf hbest).symm
  generalize rest.eraseIdx (rest.idxOf best) = rest' at hperm
  have hga := (allGood_append.mp hgood).1
  have hgr : AllGood κ rest := (allGood_append.mp hgood).2
  have hgbest : Cond.Good κ best := hgr best hbest
  have hgr' : AllGood κ rest' := fun x hx => hgr x (hperm.mem_iff.mp (List.mem_cons_of_mem _ hx))
  have hmr : ∀ mr : Cond × List Cond, Cond.Good κ mr.1 → AllGood κ mr.2 →
      (PosSat wm β (mr.1 :: mr.2) ↔ PosSat wm β (best :: rest')) →
      (Φ mr.1 mr.2 ↔ PosSat wm β (acc ++ rest)) ∧ Ψ mr.1 mr.2 := by
    intro mr g1 g2 hs
    have hg : AllGood κ (acc ++ [mr.1] ++ mr.2) := by
      rw [List.append_assoc, allGood_append]
      refine ⟨hga, fun c hc => ?_⟩
      rcases List.mem_cons.mp hc with rfl | hc
      · exact g1
      · exact g2 c hc
    refine ⟨?_, hΨ _ _ hg⟩
    rw [hΦ _ _ hg, posSat_acc_cons, hs, ← posSat_acc_cons (acc := acc) (c := best) (r := rest')]
    exact posSat_perm (by rw [List.append_assoc]; exact List.Perm.append_left acc hperm)
  cases b
  · exact hmr _ hgbest hgr' Iff.rfl
  · obtain ⟨g1, g2⟩ := moveRel_good bound best rest' hgbest hgr'
    exact hmr _ g1 g2 (moveRel_sat hr bound best rest' hgbest)

theorem joinOrder_go_sat {wm : List WME} {κ : String → Nat} {β : Binding} (hr : Respects κ β)
    (multi : List (String × Nat)) (pv : List String) :
    ∀ (n : Nat) (rest : List Cond) (bound : List String) (acc : List Cond),
      AllGood κ (acc ++ rest) →
      (PosSat wm β (joinOrder.go multi n rest bound acc pv) ↔ PosSat wm β (acc ++ rest)) ∧
      AllGood κ (joinOrder.go multi n rest bound acc pv)
  | 0, rest, bound, acc, hg => by simpa [joinOrder.go] using hg
  | n + 1, rest, bound, acc, hg => by
    unfold joinOrder.go
    simp only
    split
    · rename_i he
      have : rest = [] := List.isEmpty_iff.mp he
      subst this; simpa using hg
    · split
      · rename_i hr'
        refine (fun key => ⟨key.1.trans ?_, key.2⟩) (joinOrder_go_sat hr multi pv n _ bound _ ?_)
        · rw [List.append_assoc]
          exact (allGood_perm (List.Perm.append_left acc (ready_perm _ _).symm)).mp hg
        · rw [List.append_assoc]
          exact posSat_perm (List.Perm.append_left acc (ready_perm _ _))
      · split
        · exact ⟨Iff.rfl, hg⟩
        · rename_i pool c₀ tl hpool
          refine joinStep_sat hr multi acc rest _ c₀ ?_ ?_ _ bound
            (fun c r => PosSat wm β (joinOrder.go multi n r (bindNext bound c) (acc ++ [c]) pv))
            (fun c r => AllGood κ (joinOrder.go multi n r (bindNext bound c) (acc ++ [c]) pv))
            (fun c r hgd => (joinOrder_go_sat hr multi pv n r _ _ hgd).1)
            (fun c r hgd => (joinOrder_go_sat (wm := wm) hr multi pv n r _ _ hgd).2) hg
          · intro x hx
            split at hx <;> exact (List.mem_filter.mp hx).1
          · rw [hpool]; exact List.mem_cons_self

theorem joinOrder_good {κ : String → Nat} (cs : List Cond) (multi : List (String × Nat))
    (hg : AllGood κ cs) : AllGood κ (joinOrder cs multi) := by
  unfold joinOrder
  exact (joinOrder_go_sat (wm := []) (β := []) (κ := κ) (fun v s h => by simp [Binding.get] at h)
    multi _ (cs.length + 1) cs [] [] (by simpa using hg)).2

/-- **The join order keeps the matches.** If the positive patterns of a rule have no `@` test
and every relational test between variables compares values of one kind (a number with a
number, an identifier with an identifier) under bindings `β`, then the positive patterns of
`joinOrder cs` match elements of working memory under `β` exactly when those of `cs` do. -/
theorem joinOrder_posSat {wm : List WME} {κ : String → Nat} {β : Binding} (hr : Respects κ β)
    (cs : List Cond) (multi : List (String × Nat)) (hg : AllGood κ cs) :
    PosSat wm β (joinOrder cs multi) ↔ PosSat wm β cs := by
  unfold joinOrder
  simpa using (joinOrder_go_sat hr multi _ (cs.length + 1) cs [] [] (by simpa using hg)).1

/-! ## From the semantic statement to the matcher -/

theorem mem_positives : ∀ {cs : List Cond} {p : Pat}, p ∈ positives cs ↔ Cond.pos p ∈ cs
  | [], p => by simp [positives]
  | .pos q :: cs, p => by
    simp only [positives, List.mem_cons, Cond.pos.injEq, mem_positives]
  | .neg _ :: cs, p => by simp [positives, mem_positives]
  | .ncc _ _ :: cs, p => by simp [positives, mem_positives]
  | .nccg _ :: cs, p => by simp [positives, mem_positives]

theorem Test.binds_strip (t : Test) : Test.binds (Test.strip t) = Test.binds t := by
  unfold Test.binds Test.strip
  induction t with
  | nil => rfl
  | cons st t ih =>
    cases st <;> simp [List.filter_cons, List.flatMap_cons, STest.isRel, STest.eqVars] at ih ⊢ <;> exact ih

theorem Pat.eqVars_strip (p : Pat) : p.strip.eqVars = p.eqVars := by
  rw [Pat.eqVars_eq, Pat.eqVars_eq]
  simp only [Pat.strip, Test.binds_strip]

/-- Reordering keeps the variables that patterns bind. -/
theorem eqVars_of_perm {c₁ c₂ : List Cond} (hp : (c₁.map Cond.strip).Perm (c₂.map Cond.strip))
    {p : Pat} (hp1 : p ∈ positives c₁) : ∃ q ∈ positives c₂, q.eqVars = p.eqVars := by
  have h1 : Cond.pos p ∈ c₁ := mem_positives.mp hp1
  have h2 : Cond.pos p.strip ∈ c₂.map Cond.strip :=
    hp.mem_iff.mp (List.mem_map.mpr ⟨_, h1, rfl⟩)
  obtain ⟨c, hc, hce⟩ := List.mem_map.mp h2
  cases c with
  | pos q =>
    simp only [Cond.strip, Cond.pos.injEq] at hce
    exact ⟨q, mem_positives.mpr hc, by rw [← Pat.eqVars_strip q, hce, Pat.eqVars_strip]⟩
  | neg _ => simp [Cond.strip] at hce
  | ncc _ _ => simp [Cond.strip] at hce
  | nccg _ => simp [Cond.strip] at hce

theorem pats_hold {wm : List WME} {κ : String → Nat} {cs : List Cond} (hg : AllGood κ cs)
    {b b' : Binding} (h : b' ∈ matchPats wm (positives cs) b) :
    PosSat wm b' cs ∧ ∀ p ∈ positives cs, ∀ v ∈ p.eqVars, (b'.get v).isSome := by
  obtain ⟨_, hall⟩ := matchPats_sound h
  have hb := matchPats_bound (bd := []) h (fun v hv => by simp at hv)
  have hbd : ∀ p ∈ positives cs, ∀ v ∈ p.eqVars, (b'.get v).isSome := fun p hp v hv =>
    hb v (by simp only [List.nil_append, List.mem_flatMap]; exact ⟨p, hp, hv⟩)
  refine ⟨fun c hc p hcp => ?_, hbd⟩
  subst hcp
  have hp : p ∈ positives cs := mem_positives.mpr hc
  obtain ⟨w, hw, hrun⟩ := hall p hp
  exact ⟨w, hw, (Pat.run_beta w (hg _ hc).1 (hbd p hp)).mp hrun⟩

theorem matchPats_of_posSat {wm : List WME} {κ : String → Nat} {cs : List Cond}
    (hg : AllGood κ cs) {b b' : Binding} {bd : List String}
    (hP : PosSat wm b' cs) (hbound : ∀ p ∈ positives cs, ∀ v ∈ p.eqVars, (b'.get v).isSome)
    (he : Extends b b') (hl : LinksIn b b') (hs : PatsSafe bd (positives cs)) (hbd : Bound bd b) :
    ∃ b'' ∈ matchPats wm (positives cs) b, Extends b'' b' := by
  refine matchPats_complete (fun p hp => ?_) he hl hs hbd
  have hc := mem_positives.mp hp
  obtain ⟨w, hw, hsat⟩ := hP _ hc p rfl
  exact ⟨w, hw, (Pat.run_beta w (hg _ hc).1 (hbound p hp)).mpr hsat⟩

/-- **The join order keeps the matches.** Let the positive patterns of a rule have no `@` test
and compare, in every relational test between variables, values of one kind (a number with a
number, an identifier with an identifier). Then every instantiation of the rule's own order
whose bindings respect those kinds is found, up to variables the reordered patterns do not
bind, by the matcher on the join order, if the join order is a safe one. -/
theorem joinOrder_matches {wm : List WME} {κ : String → Nat} (cs : List Cond)
    (multi : List (String × Nat)) (hg : AllGood κ cs) {b b' : Binding} {bd : List String}
    (h : b' ∈ matchPats wm (positives cs) b) (hr : Respects κ b') (hv : VarsOk (positives cs))
    (hs : PatsSafe bd (positives (joinOrder cs multi))) (hbd : Bound bd b) :
    ∃ b'' ∈ matchPats wm (positives (joinOrder cs multi)) b, Extends b'' b' := by
  obtain ⟨hP, hbound⟩ := pats_hold hg h
  have hperm := joinOrder_strip cs multi
  refine matchPats_of_posSat (joinOrder_good cs multi hg) ((joinOrder_posSat hr cs multi hg).mpr hP)
    (fun p hp v hv' => ?_) (matchPats_sound h).1 (matchPats_links h hv) hs hbd
  obtain ⟨q, hq, hqe⟩ := eqVars_of_perm hperm hp
  exact hbound q hq v (by rw [hqe]; exact hv')

/-- The converse: every instantiation found on the join order is found, up to variables the
rule's own order does not bind, on the rule's own order, if that is a safe order. -/
theorem joinOrder_matches_rev {wm : List WME} {κ : String → Nat} (cs : List Cond)
    (multi : List (String × Nat)) (hg : AllGood κ cs) {b b' : Binding} {bd : List String}
    (h : b' ∈ matchPats wm (positives (joinOrder cs multi)) b) (hr : Respects κ b')
    (hv : VarsOk (positives cs)) (hs : PatsSafe bd (positives cs)) (hbd : Bound bd b) :
    ∃ b'' ∈ matchPats wm (positives cs) b, Extends b'' b' := by
  have hperm := joinOrder_strip cs multi
  have hv' : VarsOk (positives (joinOrder cs multi)) := by
    intro p hp v hv'' s
    obtain ⟨q, hq, hqe⟩ := eqVars_of_perm hperm hp
    exact hv q hq v (by rw [hqe]; exact hv'') s
  obtain ⟨hP, hbound⟩ := pats_hold (joinOrder_good cs multi hg) h
  refine matchPats_of_posSat hg ((joinOrder_posSat hr cs multi hg).mp hP)
    (fun p hp v hv'' => ?_) (matchPats_sound h).1 (matchPats_links h hv') hs hbd
  obtain ⟨q, hq, hqe⟩ := eqVars_of_perm hperm.symm hp
  exact hbound q hq v (by rw [hqe]; exact hv'')

end Soar
