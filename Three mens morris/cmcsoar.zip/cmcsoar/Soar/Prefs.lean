import Soar.Syntax
/-!
# Soar 9.6 — preference memory and the decision procedure

> "Preferences are held in a separate preference memory where they cannot be tested by
> productions. There is one notable exception. … acceptable preferences are made available in
> working memory as well." — [Man] §2.2

DECIDED (Laird, 2026-10-28): preference memory is internal state of the procedural module,
not examinable by rules (only acceptable preferences appear in working memory). This matches
the CMC decision that numeric metadata is never examinable while architecture-defined
symbolic signals in buffers are.
-/

namespace Soar

/-- A preference for the operator of a state ([Man] §3.2). -/
structure Pref where
  state : Nat
  op    : Sym
  kind  : PrefKind
  other : Option Sym := none
  num   : Option Sym := none
  deriving DecidableEq, Repr

/-- The impasse types.

> "There are four types of impasses that can arise from the preference scheme. Tie … Conflict
> … Constraint-failure … No-change … There are two types of no-change impasses: state
> no-change and operator no-change" — [Man] §2.7.1 -/
inductive Impasse where
  | tie | conflict | constraintFailure | stateNoChange | operatorNoChange
  deriving DecidableEq, Repr

/-- The outcome of preference resolution for one state: a winner, or an impasse with the
candidates involved. -/
inductive Decision where
  | winner  : Sym → Decision
  | impasse : Impasse → List Sym → Decision
  deriving DecidableEq, Repr

/-- Remove duplicates, keeping the last occurrence. -/
def dedup : List Sym → List Sym
  | [] => []
  | x :: xs => if xs.contains x then dedup xs else x :: dedup xs

theorem mem_dedup {o : Sym} {l : List Sym} : o ∈ dedup l ↔ o ∈ l := by
  induction l with
  | nil => simp [dedup]
  | cons x xs ih =>
    simp only [dedup]
    split
    · rename_i hx
      rw [ih]; simp only [List.mem_cons]
      constructor
      · exact Or.inr
      · rintro (rfl | h)
        · simpa using hx
        · exact h
    · simp [ih]

section
variable (ps : List Pref)

def has (k : PrefKind) (o : Sym) : Bool := ps.any fun p => p.kind == k && p.op == o

def hasBin (k : PrefKind) (o o₂ : Sym) : Bool :=
  ps.any fun p => p.kind == k && p.op == o && p.other == some o₂

/-- `o` is worse than `o₂`: `o₂ > o` or `o < o₂`. Better and worse are inverses
([Man] §2.4.1). -/
def worseThan (o o₂ : Sym) : Bool := o != o₂ && (hasBin ps .better o₂ o || hasBin ps .worse o o₂)

/-- The operators with a preference of kind `k`, without duplicates, in the order their first
preference was created. Soar's `indifferent-selection --first` picks the earliest (checked
against Soar 9.6.5, 2026-10-28). -/
def opsOf (k : PrefKind) : List Sym := (dedup ((ps.filter (fun p => p.kind == k)).map (·.op)).reverse).reverse

def mutuallyIndifferent (cs : List Sym) : Bool :=
  cs.all fun o => has ps .unaryIndiff o || has ps .numericIndiff o ||
    cs.all fun o₂ => o₂ == o || hasBin ps .binaryIndiff o o₂ || hasBin ps .binaryIndiff o₂ o

/-- RequireTest, AcceptableCollect, ProhibitFilter, RejectFilter. -/
def required : List Sym := opsOf ps .require
def acceptables : List Sym := opsOf ps .acceptable
def afterReject : List Sym :=
  ((acceptables ps).filter fun o => !has ps .prohibit o).filter fun o => !has ps .reject o
def afterBetterWorse (c : List Sym) : List Sym := c.filter fun o => !(c.any fun o₂ => worseThan ps o o₂)
def afterBest (c : List Sym) : List Sym :=
  if (c.filter (has ps .best)).isEmpty then c else c.filter (has ps .best)
def afterWorst (c : List Sym) : List Sym :=
  if (c.filter (fun o => !has ps .worst o)).isEmpty then c else c.filter (fun o => !has ps .worst o)
end

/-- **Preference resolution**, in the eight steps of [Man] §2.4.2 (Figure 2.8). `choose`
picks among mutually indifferent candidates.

NOT FORMALIZED: the exploration policies and numeric-indifferent combination
(`decide indifferent-selection`, [Man] §9); `choose` stands for whichever is in force. -/
def stage5 (choose : List Sym → Sym) (ps : List Pref) (c₅ : List Sym) : Decision :=
  match c₅ with
  | [] => .impasse .stateNoChange []                        -- Exit point 4
  | [o] => .winner o
  | _ => if mutuallyIndifferent ps c₅ then .winner (choose c₅)
         else .impasse .tie c₅                               -- IndifferentFilter

def stage4 (choose : List Sym → Sym) (ps : List Pref) (c₄ : List Sym) : Decision :=
  match c₄ with
  | [] => .impasse .stateNoChange []                        -- Exit point 3
  | [o] => .winner o
  | _ => stage5 choose ps (afterWorst ps c₄)

def stage3 (choose : List Sym → Sym) (ps : List Pref) (c₂ : List Sym) : Decision :=
  match afterBetterWorse ps c₂ with
  | [] => .impasse .conflict c₂                             -- Exit point 2
  | [o] => .winner o
  | c₃ => stage4 choose ps (afterBest ps c₃)

def stage2 (choose : List Sym → Sym) (ps : List Pref) : Decision :=
  match afterReject ps with
  | [] => .impasse .stateNoChange []                        -- Exit point 1
  | [o] => .winner o
  | c₂ => stage3 choose ps c₂

/-- **Preference resolution**, in the eight steps of [Man] §2.4.2 (Figure 2.8). `choose`
picks among mutually indifferent candidates.

NOT FORMALIZED: the exploration policies and numeric-indifferent combination
(`decide indifferent-selection`, [Man] §9); `choose` stands for whichever is in force. -/
def resolve (choose : List Sym → Sym) (ps : List Pref) : Decision :=
  match required ps with
  | [o] => if has ps .prohibit o then .impasse .constraintFailure [o] else .winner o
  | [] => stage2 choose ps
  | _ => .impasse .constraintFailure (required ps)

/-! ## Properties of the decision procedure -/

theorem two_le_of (l : List Sym) (h1 : ∀ o, l = [o] → False) (h2 : l = [] → False) :
    2 ≤ l.length := by
  match l with
  | [] => exact absurd rfl h2
  | [a] => exact absurd rfl (h1 a)
  | _ :: _ :: _ => simp

section Props
variable {ps : List Pref} {choose : List Sym → Sym}

theorem mem_opsOf {k : PrefKind} {o : Sym} (h : o ∈ opsOf ps k) : has ps k o = true := by
  simp only [opsOf, List.mem_reverse, mem_dedup, List.mem_map, List.mem_filter] at h
  obtain ⟨p, ⟨hp, hk⟩, rfl⟩ := h
  simp only [has, List.any_eq_true, Bool.and_eq_true, beq_iff_eq]
  exact ⟨p, hp, by simpa using hk, rfl⟩

theorem mem_afterReject {o : Sym} (h : o ∈ afterReject ps) :
    has ps .acceptable o = true ∧ has ps .prohibit o = false ∧ has ps .reject o = false := by
  simp only [afterReject, List.mem_filter, Bool.not_eq_true'] at h
  obtain ⟨⟨ha, hp⟩, hr⟩ := h
  exact ⟨mem_opsOf ha, hp, hr⟩

theorem afterBetterWorse_sub {c : List Sym} {o : Sym} (h : o ∈ afterBetterWorse ps c) : o ∈ c :=
  (List.mem_filter.mp h).1

theorem afterBest_sub {c : List Sym} {o : Sym} (h : o ∈ afterBest ps c) : o ∈ c := by
  unfold afterBest at h; split at h
  · exact h
  · exact (List.mem_filter.mp h).1

theorem afterWorst_sub {c : List Sym} {o : Sym} (h : o ∈ afterWorst ps c) : o ∈ c := by
  unfold afterWorst at h; split at h
  · exact h
  · exact (List.mem_filter.mp h).1

theorem stage5_winner (hc : ∀ l : List Sym, l ≠ [] → choose l ∈ l) {c : List Sym} {o : Sym}
    (h : stage5 choose ps c = .winner o) : o ∈ c := by
  unfold stage5 at h
  split at h
  · cases h
  · cases h; simp
  · split at h
    · cases h; exact hc _ (by rename_i hn _ _; intro e; subst e; simp at hn)
    · cases h

theorem stage4_winner (hc : ∀ l : List Sym, l ≠ [] → choose l ∈ l) {c : List Sym} {o : Sym}
    (h : stage4 choose ps c = .winner o) : o ∈ c := by
  unfold stage4 at h
  split at h
  · cases h
  · cases h; simp
  · exact afterWorst_sub (stage5_winner hc h)

theorem stage3_winner (hc : ∀ l : List Sym, l ≠ [] → choose l ∈ l) {c : List Sym} {o : Sym}
    (h : stage3 choose ps c = .winner o) : o ∈ c := by
  unfold stage3 at h
  split at h
  · cases h
  · cases h; rename_i heq; exact afterBetterWorse_sub (by rw [heq]; simp)
  · exact afterBetterWorse_sub (afterBest_sub (stage4_winner hc h))

theorem stage2_winner (hc : ∀ l : List Sym, l ≠ [] → choose l ∈ l) {o : Sym}
    (h : stage2 choose ps = .winner o) : o ∈ afterReject ps := by
  unfold stage2 at h
  split at h
  · cases h
  · cases h; rename_i heq; rw [heq]; simp
  · exact stage3_winner hc h

/-- **Only candidates win.** A winner either carries a require preference and no prohibit
preference, or carries an acceptable preference and neither a prohibit nor a reject
preference.

> "All values, except those with require preferences, must have an acceptable preference in
> order to be selected." — [Man] §2.4.1 -/
theorem winner_is_candidate (hc : ∀ l : List Sym, l ≠ [] → choose l ∈ l) {o : Sym}
    (h : resolve choose ps = .winner o) :
    (has ps .require o = true ∧ has ps .prohibit o = false) ∨
    (has ps .acceptable o = true ∧ has ps .prohibit o = false ∧ has ps .reject o = false) := by
  unfold resolve at h
  split at h
  · rename_i o' hreq
    split at h
    · cases h
    · cases h
      refine Or.inl ⟨mem_opsOf (k := .require) (by
        show o ∈ required ps
        rw [hreq]; simp), ?_⟩
      simpa using (by assumption : ¬has ps .prohibit o = true)
  · exact Or.inr (mem_afterReject (stage2_winner hc h))
  · cases h

/-- The impasses that the stages from `stage2` on can end in (the cascade that the three
impasse-cause theorems share): a conflict, with the candidates left after rejection and none
left after the better/worse filter; a tie among at least two candidates that are not all
mutually indifferent; or a state no-change. -/
theorem stage2_impasse {k : Impasse} {items : List Sym}
    (h : stage2 choose ps = .impasse k items) :
    (k = .conflict ∧ items = afterReject ps ∧ afterBetterWorse ps (afterReject ps) = []) ∨
    (k = .tie ∧ 2 ≤ items.length ∧ mutuallyIndifferent ps items = false) ∨
    k = .stateNoChange := by
  unfold stage2 at h
  split at h
  · cases h; exact Or.inr (Or.inr rfl)
  · cases h
  · unfold stage3 at h
    split at h
    · rename_i hbw
      cases h
      exact Or.inl ⟨rfl, rfl, hbw⟩
    · cases h
    · unfold stage4 at h
      split at h
      · cases h; exact Or.inr (Or.inr rfl)
      · cases h
      · unfold stage5 at h
        split at h
        · cases h; exact Or.inr (Or.inr rfl)
        · cases h
        · rename_i hn2 hn1
          split at h
          · cases h
          · cases h
            exact Or.inr (Or.inl ⟨rfl, two_le_of _ hn1 hn2,
              by simpa using (by assumption : ¬mutuallyIndifferent ps _ = true)⟩)

/-- **Constraint failure** arises only from more than one required value, or a required value
that is also prohibited ([Man] §2.7.1). -/
theorem constraintFailure_cause {items : List Sym}
    (h : resolve choose ps = .impasse .constraintFailure items) :
    (2 ≤ (required ps).length) ∨ (∃ o, required ps = [o] ∧ has ps .prohibit o = true) := by
  unfold resolve at h
  split at h
  · rename_i o hreq
    split at h
    · exact Or.inr ⟨o, hreq, by assumption⟩
    · cases h
  · exfalso
    rcases stage2_impasse h with ⟨hk, _⟩ | ⟨hk, _⟩ | hk <;> cases hk
  · rename_i hn1 hn2
    exact Or.inl (two_le_of _ hn1 hn2)

/-- **Conflict**: every operator in a conflict impasse is worse than another of them, and no
value is required.

> "A conflict impasse arises if at least two values have conflicting better or worse
> preferences … and neither one is rejected, prohibited, or required." — [Man] §2.7.1 -/
theorem conflict_cause {items : List Sym} (h : resolve choose ps = .impasse .conflict items) :
    required ps = [] ∧ items = afterReject ps ∧
    ∀ o ∈ items, ∃ o₂ ∈ items, worseThan ps o o₂ = true := by
  unfold resolve at h
  split at h
  · split at h <;> cases h
  · rename_i hreq
    rcases stage2_impasse h with ⟨_, hit, hbw⟩ | ⟨hk, _⟩ | hk
    · refine ⟨hreq, hit, fun o ho => ?_⟩
      have : o ∉ afterBetterWorse ps (afterReject ps) := by rw [hbw]; simp
      subst hit
      simp only [afterBetterWorse, List.mem_filter, ho, true_and, Bool.not_eq_true',
        Bool.not_eq_false'] at this
      simpa [List.any_eq_true] using this
    · cases hk
    · cases hk
  · cases h

/-- **Tie**: a tie impasse involves at least two operators that are not all mutually
indifferent, and none is required. -/
theorem tie_cause {items : List Sym} (h : resolve choose ps = .impasse .tie items) :
    required ps = [] ∧ 2 ≤ items.length ∧ mutuallyIndifferent ps items = false := by
  unfold resolve at h
  split at h
  · split at h <;> cases h
  · rename_i hreq
    rcases stage2_impasse h with ⟨hk, _⟩ | ⟨_, h2, h3⟩ | hk
    · cases hk
    · exact ⟨hreq, h2, h3⟩
    · cases hk
  · cases h

/-- **State no-change**: if nothing is required and every acceptable operator is prohibited or
rejected, no operator is selected.

> "A state no-change impasse occurs when there are no acceptable (or require) preferences to
> suggest operators for the current state (or all the acceptable values have also been
> rejected)." — [Man] §2.7.1 -/
theorem stateNoChange_of_none (hreq : required ps = []) (hnone : afterReject ps = []) :
    resolve choose ps = .impasse .stateNoChange [] := by
  unfold resolve; rw [hreq]; simp only; unfold stage2; rw [hnone]

/-- **A single unprohibited required operator always wins**, whatever the other
preferences. -/
theorem require_wins {o : Sym} (hreq : required ps = [o]) (hp : has ps .prohibit o = false) :
    resolve choose ps = .winner o := by
  unfold resolve; rw [hreq]; simp [hp]

end Props
/-! ## Operator selection knowledge

> "add-osk … When this setting is on, the chunker will include preferences that were used to
> select the operator … in the explanation" — [Man] §4.6 (`chunk add-osk`; Soar 9.6.5 has it
> on by default, though the manual says off)

The preferences of a state's operator that decided its selection: the operator selection
knowledge (OSK) that chunking backtraces through (Soar 9.6.5 `run_preference_semantics`,
`add_to_OSK`). Each preference is paired with what made it. -/

/-- Soar 9.6.5's equivalence of preferences in an OSK set (`add_to_OSK`): better and worse
with the same operators in the same relative places, binary indifference either way round,
otherwise the same kind and operator. -/
def oskEquiv (p q : Pref) : Bool :=
  let bw (k : PrefKind) : Bool := k == .better || k == .worse
  if bw p.kind && bw q.kind then
    if p.kind == q.kind then p.op == q.op && p.other == q.other
    else some p.op == q.other && p.other == some q.op
  else if p.kind == .binaryIndiff && q.kind == .binaryIndiff then
    (p.op == q.op && p.other == q.other) || (some p.op == q.other && p.other == some q.op)
  else p.op == q.op && p.kind == q.kind

/-- Add to an OSK set unless present (`unique`: or an equivalent preference). -/
def oskAdd {α : Type} [BEq α] (unique : Bool) (acc : List (Pref × α)) (x : Pref × α) : List (Pref × α) :=
  if acc.any (fun y => (y.1 == x.1 && y.2 == x.2) || (unique && oskEquiv y.1 x.1)) then acc else acc ++ [x]

/-- The OSK set for the selection of `w` from the preferences `objs` (in Soar's order of the
slot's preference lists). Requires are not included (they are backtraced anyway); prohibits
and rejects are when there are any; then the better and worse preferences of the remaining
candidates, the best preferences of the best candidates, the worst preferences of the worst
candidates when some candidate is not worst, and the indifferent preferences of the winner
(numeric ones all, binary ones unless between two numerically rated operators; unary
indifference is left out, as in Soar 9.6.5). -/
def oskSelect {α : Type} [BEq α] (objs : List (Pref × α)) (w : Sym) : List (Pref × α) :=
  let ps := objs.map (·.1)
  let of (k : PrefKind) := objs.filter (·.1.kind == k)
  let add (u : Bool) (acc xs : List (Pref × α)) := xs.foldl (oskAdd u) acc
  if !(required ps).isEmpty then [] else
  let o₁ := add true [] (of .prohibit ++ of .reject)
  let c₂ := afterReject ps
  if c₂.length ≤ 1 then o₁ else
  let c₃ := afterBetterWorse ps c₂
  let o₂ := c₃.foldl (fun a c => add true a ((of .better).filter (·.1.op == c) ++
    (of .worse).filter (·.1.other == some c))) o₁
  if c₃.length ≤ 1 then o₂ else
  let c₄ := afterBest ps c₃
  let o₃ := c₃.foldl (fun a c => if has ps .best c then add true a ((of .best).filter (·.1.op == c)) else a) o₂
  if c₄.length ≤ 1 then o₃ else
  let c₅ := afterWorst ps c₄
  let o₄ := if c₄.any (fun c => !has ps .worst c) then
      c₄.foldl (fun a c => if has ps .worst c then add true a ((of .worst).filter (·.1.op == c)) else a) o₃
    else o₃
  if c₅.length ≤ 1 then o₄ else
  let num (o : Sym) : Bool := has ps .numericIndiff o
  let bin := (of .binaryIndiff).filter (fun x => x.1.op == w || x.1.other == some w)
  if c₅.any num then
    add true (add false o₄ ((of .numericIndiff).filter (·.1.op == w)))
      (bin.filter (fun x => !num x.1.op || !(x.1.other.map num).getD false))
  else add true o₄ bin

theorem mem_oskAdd {α : Type} [BEq α] {u : Bool} {acc : List (Pref × α)} {x y : Pref × α}
    (h : y ∈ oskAdd u acc x) : y ∈ acc ∨ y = x := by
  unfold oskAdd at h
  split at h
  · exact Or.inl h
  · simp only [List.mem_append, List.mem_singleton] at h; exact h

theorem mem_foldl_oskAdd {α : Type} [BEq α] {u : Bool} {objs : List (Pref × α)} :
    ∀ {xs acc : List (Pref × α)} {y : Pref × α}, (∀ z ∈ acc, z ∈ objs) → (∀ z ∈ xs, z ∈ objs) →
      y ∈ xs.foldl (oskAdd u) acc → y ∈ objs
  | [], _, _, ha, _, h => ha _ h
  | x :: xs, acc, y, ha, hx, h => by
    simp only [List.foldl_cons] at h
    refine mem_foldl_oskAdd (acc := oskAdd u acc x) ?_ (fun z hz => hx z (List.mem_cons_of_mem _ hz)) h
    intro z hz
    rcases mem_oskAdd hz with h1 | rfl
    · exact ha _ h1
    · exact hx _ (List.mem_cons_self)


end Soar
