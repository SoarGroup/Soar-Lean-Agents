/-!
# Soar 9.6 — random numbers

Soar 9.6.5 draws every random number from one Mersenne Twister generator (`soar_rand.h`,
`MTRand`, Wagner's implementation of Matsumoto and Nishimura's MT19937), seeded by `srand`.
The generator serves operator selection by the exploration policies and the right-hand-side
functions `rand-int` and `rand-float`. `MT` reproduces it bit for bit: `MT.seed` is
`MTRand::seed(uint32)`, `MT.randInt` is `randInt()`, `MT.randIntN` is `randInt(n)` (an
integer in [0, n]), and `MT.rand` is `rand()` (a real number in [0, 1]).

Soar's generator is one per process, shared by all agents in a kernel; the model has one per
agent. Without `srand` Soar seeds from the operating system; the model then uses seed 0.
-/

namespace Soar

/-- The state of the generator: 624 words and the position of the next one to use. -/
structure MT where
  st  : Array UInt32
  idx : Nat
  deriving Inhabited

instance : Repr MT := ⟨fun m _ => s!"MT(idx := {m.idx})"⟩

namespace MT

def N : Nat := 624
def M : Nat := 397

/-- `MTRand::twist`. -/
@[inline] def twist (m s0 s1 : UInt32) : UInt32 :=
  let mix := (s0 &&& 0x80000000) ||| (s1 &&& 0x7fffffff)
  m ^^^ (mix >>> 1) ^^^ ((0 - (s1 &&& 1)) &&& 0x9908b0df)

/-- `MTRand::reload`: make the next 624 words. -/
def reload (a : Array UInt32) : Array UInt32 := Id.run do
  let mut a := a
  for i in [0:N - M] do
    a := a.set! i (twist a[i + M]! a[i]! a[i + 1]!)
  for i in [N - M:N - 1] do
    a := a.set! i (twist a[i + M - N]! a[i]! a[i + 1]!)
  a := a.set! (N - 1) (twist a[M - 1]! a[N - 1]! a[0]!)
  return a

/-- `MTRand::seed(uint32)`: `initialize` then `reload`. -/
def seed (s : UInt32) : MT := Id.run do
  let mut a : Array UInt32 := Array.mkEmpty N
  a := a.push s
  for i in [1:N] do
    let r := a[i - 1]!
    a := a.push ((1812433253 : UInt32) * (r ^^^ (r >>> 30)) + i.toUInt32)
  return { st := reload a, idx := 0 }

/-- `MTRand::randInt()`: the next 32-bit word, tempered. -/
def randInt (m : MT) : UInt32 × MT :=
  let m := if m.idx ≥ N then { st := reload m.st, idx := 0 } else m
  let y := m.st[m.idx]!
  let y := y ^^^ (y >>> 11)
  let y := y ^^^ ((y <<< 7) &&& 0x9d2c5680)
  let y := y ^^^ ((y <<< 15) &&& 0xefc60000)
  (y ^^^ (y >>> 18), { m with idx := m.idx + 1 })

/-- `MTRand::randInt(n)`: an integer in [0, n], by masking and rejecting. -/
def randIntN (n : UInt32) (m : MT) : UInt32 × MT := Id.run do
  let mut used := n
  used := used ||| (used >>> 1)
  used := used ||| (used >>> 2)
  used := used ||| (used >>> 4)
  used := used ||| (used >>> 8)
  used := used ||| (used >>> 16)
  let mut m := m
  -- the loop ends with probability 1; 64 tries bound it for the definition
  let mut out : UInt32 := 0
  for _ in [0:64] do
    let (i, m') := m.randInt
    m := m'
    out := i &&& used
    if out ≤ n then break
  return (out, m)

/-- `MTRand::rand()`: a real number in [0, 1]. -/
def rand (m : MT) : Float × MT :=
  let (i, m) := m.randInt
  (i.toNat.toFloat * (1.0 / 4294967295.0), m)

end MT

end Soar
