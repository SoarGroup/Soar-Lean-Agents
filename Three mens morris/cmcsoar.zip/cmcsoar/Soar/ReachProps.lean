import Soar.Cycle
/-!
# Soar 9.6 — correctness of `reach`

`mem_reach_iff`: an identifier is in `reach wm roots` exactly when it is reachable from the roots
through the elements of `wm` (the definition of linked to a state in [Man] §2.2).
-/

namespace Soar

/-- Reachability: a root, or an identifier of an element whose identifier is reachable. -/
inductive Reach (wm : List WME) (roots : List Nat) : Nat → Prop
  | root {i : Nat} : i ∈ roots → Reach wm roots i
  | step {j i : Nat} {w : WME} : Reach wm roots j → w ∈ wm → w.id = j → i ∈ wmeIds w →
      Reach wm roots i

theorem enum_mem_of_mem {wm : List WME} {w : WME} (h : w ∈ wm) : ∃ k, (k, w) ∈ wm.enum := by
  obtain ⟨i, hi⟩ := List.mem_iff_getElem?.mp h
  refine ⟨i, ?_⟩
  unfold List.enum
  exact List.mem_map.mpr ⟨(w, i), List.mem_zipIdx_iff_getElem?.mpr hi, rfl⟩

theorem adj_foldl (i : Nat) : ∀ (L : List (Nat × WME)) (m : Std.HashMap Nat (List (Nat × WME)))
    (p : Nat × WME),
    p ∈ (L.foldl (fun m (kw : Nat × WME) => m.insert kw.2.id ((kw.1, kw.2) :: m.getD kw.2.id [])) m).getD i []
      ↔ (p ∈ L ∧ p.2.id = i) ∨ p ∈ m.getD i []
  | [], m, p => by simp
  | (k, w) :: L, m, p => by
    rw [List.foldl_cons, adj_foldl i L]
    simp only [Std.HashMap.getD_insert, List.mem_cons]
    by_cases h : w.id = i
    · subst h; simp
      constructor
      · rintro (⟨h1, h2⟩ | h1 | h1)
        · exact Or.inl ⟨Or.inr h1, h2⟩
        · exact Or.inl ⟨Or.inl h1, by rw [h1]⟩
        · exact Or.inr h1
      · rintro (⟨h1 | h1, h2⟩ | h1)
        · exact Or.inr (Or.inl h1)
        · exact Or.inl ⟨h1, h2⟩
        · exact Or.inr (Or.inr h1)
    · have : ¬ (w.id == i) = true := by simpa using h
      simp [this]
      constructor
      · rintro (⟨h1, h2⟩ | h1)
        · exact Or.inl ⟨Or.inr h1, h2⟩
        · exact Or.inr h1
      · rintro (⟨h1 | h1, h2⟩ | h1)
        · subst h1; exact absurd h2 h
        · exact Or.inl ⟨h1, h2⟩
        · exact Or.inr h1

theorem adj_mem (wm : List WME) (i : Nat) (p : Nat × WME) :
    p ∈ (wm.enum.foldl (fun m (kw : Nat × WME) => m.insert kw.2.id ((kw.1, kw.2) :: m.getD kw.2.id [])) ({} : Std.HashMap Nat (List (Nat × WME)))).getD i []
      ↔ p ∈ wm.enum ∧ p.2.id = i := by
  rw [adj_foldl]; simp

/-- Membership in the fold that collects the found pairs. -/
theorem found_mem (adj : Std.HashMap Nat (List (Nat × WME))) (frontier : Std.HashSet Nat)
    (x : Nat × WME) :
    x ∈ frontier.fold (fun acc i => (adj.getD i []).foldl (fun a p => p :: a) acc) []
      ↔ ∃ i, frontier.contains i = true ∧ x ∈ adj.getD i [] := by
  rw [Std.HashSet.fold_eq_foldl_toList]
  have key : ∀ (l : List Nat) (init : List (Nat × WME)),
      x ∈ l.foldl (fun acc i => (adj.getD i []).foldl (fun a p => p :: a) acc) init
        ↔ x ∈ init ∨ ∃ i ∈ l, x ∈ adj.getD i [] := by
    intro l
    induction l with
    | nil => intro init; simp
    | cons a l ih =>
      intro init
      rw [List.foldl_cons, ih]
      have inner : ∀ (ys init : List (Nat × WME)),
          x ∈ ys.foldl (fun a p => p :: a) init ↔ x ∈ init ∨ x ∈ ys := by
        intro ys; induction ys with
        | nil => intro init; simp
        | cons y ys ih2 =>
          intro init; rw [List.foldl_cons, ih2]
          simp only [List.mem_cons]
          constructor
          · rintro ((h | h) | h)
            · exact Or.inr (Or.inl h)
            · exact Or.inl h
            · exact Or.inr (Or.inr h)
          · rintro (h | h | h)
            · exact Or.inl (Or.inr h)
            · exact Or.inl (Or.inl h)
            · exact Or.inr h
      rw [inner]
      constructor
      · rintro ((h | h) | ⟨i, hi, hx⟩)
        · exact Or.inl h
        · exact Or.inr ⟨a, List.mem_cons_self .., h⟩
        · exact Or.inr ⟨i, List.mem_cons_of_mem _ hi, hx⟩
      · rintro (h | ⟨i, hi, hx⟩)
        · exact Or.inl (Or.inl h)
        · rcases List.mem_cons.mp hi with rfl | hi
          · exact Or.inl (Or.inr hx)
          · exact Or.inr ⟨i, hi, hx⟩
  rw [key]
  simp only [List.not_mem_nil, false_or]
  constructor
  · rintro ⟨i, hi, hx⟩
    exact ⟨i, Std.HashSet.contains_iff_mem.mpr (Std.HashSet.mem_toList.mp hi), hx⟩
  · rintro ⟨i, hi, hx⟩
    exact ⟨i, Std.HashSet.mem_toList.mpr (Std.HashSet.contains_iff_mem.mp hi), hx⟩

/-- The fold that removes the identifiers already seen and repeats. -/
theorem new_fold (seenS : Std.HashSet Nat) : ∀ (next : List Nat) (l : List Nat)
    (s : Std.HashSet Nat),
    (∀ x, s.contains x = true ↔ x ∈ l) → (∀ x ∈ l, seenS.contains x = false) →
    (∀ x, x ∈ (next.foldl (fun (acc : List Nat × Std.HashSet Nat) i =>
        if seenS.contains i || acc.2.contains i then acc else (i :: acc.1, acc.2.insert i)) (l, s)).1
        ↔ x ∈ l ∨ (x ∈ next ∧ seenS.contains x = false)) ∧
    (∀ x, (next.foldl (fun (acc : List Nat × Std.HashSet Nat) i =>
        if seenS.contains i || acc.2.contains i then acc else (i :: acc.1, acc.2.insert i)) (l, s)).2.contains x = true
        ↔ x ∈ (next.foldl (fun (acc : List Nat × Std.HashSet Nat) i =>
        if seenS.contains i || acc.2.contains i then acc else (i :: acc.1, acc.2.insert i)) (l, s)).1)
    ∧ (∀ x ∈ (next.foldl (fun (acc : List Nat × Std.HashSet Nat) i =>
        if seenS.contains i || acc.2.contains i then acc else (i :: acc.1, acc.2.insert i)) (l, s)).1,
        seenS.contains x = false)
  | [], l, s, h1, h2 => ⟨fun x => by simp, h1, h2⟩
  | i :: next, l, s, h1, h2 => by
    rw [List.foldl_cons]
    by_cases hc : (seenS.contains i || s.contains i) = true
    · simp only [hc, ite_true]
      have ih := new_fold seenS next l s h1 h2
      refine ⟨fun x => ?_, ih.2.1, ih.2.2⟩
      rw [ih.1 x]
      simp only [List.mem_cons]
      constructor
      · rintro (h | ⟨h, h'⟩)
        · exact Or.inl h
        · exact Or.inr ⟨Or.inr h, h'⟩
      · rintro (h | ⟨h | h, h'⟩)
        · exact Or.inl h
        · subst h
          simp [Bool.or_eq_true] at hc
          rcases hc with hc | hc
          · simp [hc] at h'
          · exact Or.inl ((h1 x).mp hc)
        · exact Or.inr ⟨h, h'⟩
    · simp only [hc, Bool.false_eq_true, ↓reduceIte]
      have hs : seenS.contains i = false := by
        cases h : seenS.contains i <;> simp_all
      have hs' : s.contains i = false := by
        cases h : s.contains i <;> simp_all
      have ih := new_fold seenS next (i :: l) (s.insert i)
        (by
          intro x
          rw [Std.HashSet.contains_insert]
          have := h1 x
          simp only [List.mem_cons, Bool.or_eq_true, beq_iff_eq]
          constructor
          · rintro (h | h)
            · exact Or.inl h.symm
            · exact Or.inr (this.mp h)
          · rintro (h | h)
            · exact Or.inl h.symm
            · exact Or.inr (this.mpr h))
        (by
          intro x hx
          rcases List.mem_cons.mp hx with h | h
          · subst h; exact hs
          · exact h2 x h)
      refine ⟨fun x => ?_, ih.2.1, ih.2.2⟩
      rw [ih.1 x]
      simp only [List.mem_cons]
      constructor
      · rintro ((h | h) | ⟨hn, hs'⟩)
        · exact Or.inr ⟨Or.inl h, by rw [h]; exact hs⟩
        · exact Or.inl h
        · exact Or.inr ⟨Or.inr hn, hs'⟩
      · rintro (h | ⟨h | h, h'⟩)
        · exact Or.inl (Or.inr h)
        · exact Or.inl (Or.inl h)
        · exact Or.inr ⟨h, h'⟩

theorem ins_fold (S : Std.HashSet Nat) (T : Std.HashSet Nat) (x : Nat) :
    (T.fold (·.insert ·) S).contains x = true ↔ S.contains x = true ∨ T.contains x = true := by
  rw [Std.HashSet.fold_eq_foldl_toList]
  have key : ∀ (l : List Nat) (S : Std.HashSet Nat),
      (l.foldl (·.insert ·) S).contains x = true ↔ S.contains x = true ∨ x ∈ l := by
    intro l
    induction l with
    | nil => intro S; simp
    | cons a l ih =>
      intro S; rw [List.foldl_cons, ih, Std.HashSet.contains_insert]
      simp only [Bool.or_eq_true, beq_iff_eq, List.mem_cons]
      constructor
      · rintro ((h | h) | h)
        · exact Or.inr (Or.inl h.symm)
        · exact Or.inl h
        · exact Or.inr (Or.inr h)
      · rintro (h | h | h)
        · exact Or.inl (Or.inr h)
        · exact Or.inl (Or.inl h.symm)
        · exact Or.inr h
  rw [key, Std.HashSet.mem_toList, Std.HashSet.mem_iff_contains]

theorem countP_lt_of {α : Type} {p q : α → Bool} (w : α) :
    ∀ (l : List α), (∀ x ∈ l, q x = true → p x = true) → w ∈ l → p w = true → q w = false →
    l.countP q < l.countP p
  | [], _, h, _, _ => by simp at h
  | a :: l, hall, hw, hp, hq => by
    rw [List.countP_cons, List.countP_cons]
    have hle : l.countP q ≤ l.countP p :=
      List.countP_mono_left (fun x hx => hall x (List.mem_cons_of_mem _ hx))
    rcases List.mem_cons.mp hw with rfl | hw
    · simp [hp, hq]; omega
    · have := countP_lt_of w l (fun x hx => hall x (List.mem_cons_of_mem _ hx)) hw hp hq
      have hqa := hall a (List.mem_cons_self ..)
      by_cases h1 : q a = true
      · simp [h1, hqa h1]; omega
      · simp [h1]; split <;> omega

theorem next_mem (wm : List WME) (adj : Std.HashMap Nat (List (Nat × WME)))
    (hadj : ∀ i p, p ∈ adj.getD i [] ↔ p ∈ wm.enum ∧ p.2.id = i) (frontier : Std.HashSet Nat)
    (i : Nat) :
    i ∈ ((frontier.fold (fun acc i => (adj.getD i []).foldl (fun a p => p :: a) acc) []).mergeSort
        (fun a b => a.1 ≤ b.1)).flatMap (fun x => wmeIds x.2)
      ↔ ∃ w ∈ wm, frontier.contains w.id = true ∧ i ∈ wmeIds w := by
  rw [List.mem_flatMap]
  simp only [List.mem_mergeSort]
  constructor
  · rintro ⟨⟨k, w⟩, hp, hi⟩
    simp only at hi
    obtain ⟨j, hj, hpj⟩ := (found_mem adj frontier _).mp hp
    have := (hadj j _).mp hpj
    refine ⟨w, List.enum_snd_mem this.1, ?_, hi⟩
    have h2 : w.id = j := this.2
    rw [h2]; exact hj
  · rintro ⟨w, hw, hf, hi⟩
    obtain ⟨k, hk⟩ := enum_mem_of_mem hw
    exact ⟨(k, w), (found_mem adj frontier _).mpr ⟨w.id, hf, (hadj _ _).mpr ⟨hk, rfl⟩⟩, hi⟩

/-- The measure of the search: the elements whose identifier is not yet finished. -/
def reachCnt (wm : List WME) (seenS frontier : Std.HashSet Nat) : Nat :=
  wm.countP (fun w => !(seenS.contains w.id && !frontier.contains w.id))

/-- The identifiers found at this level (the `next` of `reach.go`). -/
def nextOf (adj : Std.HashMap Nat (List (Nat × WME))) (frontier : Std.HashSet Nat) : List Nat :=
  ((frontier.fold (fun acc i => (adj.getD i []).foldl (fun a p => p :: a) acc) []).mergeSort
        (fun a b => a.1 ≤ b.1)).flatMap (fun x => wmeIds x.2)

/-- The identifiers not seen yet, with their set. -/
def foldNew (seenS : Std.HashSet Nat) (nx : List Nat) : List Nat × Std.HashSet Nat :=
  nx.foldl (fun (acc : List Nat × Std.HashSet Nat) i =>
      if seenS.contains i || acc.2.contains i then acc else (i :: acc.1, acc.2.insert i)) ([], {})

theorem go_succ (adj : Std.HashMap Nat (List (Nat × WME))) (n : Nat) (seen : List Nat)
    (seenS frontier : Std.HashSet Nat) :
    reach.go adj (n + 1) seen seenS frontier =
      if (foldNew seenS (nextOf adj frontier)).1.reverse.isEmpty then seen
      else reach.go adj n (seen ++ (foldNew seenS (nextOf adj frontier)).1.reverse)
        ((foldNew seenS (nextOf adj frontier)).2.fold (·.insert ·) seenS)
        (foldNew seenS (nextOf adj frontier)).2 := by
  rw [reach.go]; rfl

theorem go_spec (wm : List WME) (roots : List Nat) (adj : Std.HashMap Nat (List (Nat × WME)))
    (hadj : ∀ i p, p ∈ adj.getD i [] ↔ p ∈ wm.enum ∧ p.2.id = i) :
    ∀ (n : Nat) (seen : List Nat) (seenS frontier : Std.HashSet Nat),
    (∀ x, seenS.contains x = true ↔ x ∈ seen) →
    (∀ x ∈ seen, Reach wm roots x) →
    (∀ x, frontier.contains x = true → x ∈ seen) →
    (∀ j ∈ seen, frontier.contains j = false → ∀ w ∈ wm, w.id = j → ∀ i ∈ wmeIds w, i ∈ seen) →
    (∀ x ∈ roots, x ∈ seen) →
    reachCnt wm seenS frontier < n →
    (∀ x ∈ reach.go adj n seen seenS frontier, Reach wm roots x) ∧
    (∀ x ∈ roots, x ∈ reach.go adj n seen seenS frontier) ∧
    (∀ w ∈ wm, w.id ∈ reach.go adj n seen seenS frontier → ∀ i ∈ wmeIds w,
      i ∈ reach.go adj n seen seenS frontier) := by
  intro n
  induction n with
  | zero => intro _ _ _ _ _ _ _ _ hn; exact absurd hn (Nat.not_lt_zero _)
  | succ n ih =>
    intro seen seenS frontier H1 H2 H3 H4 H5 hn
    rw [go_succ]
    have hnx : ∀ i, i ∈ nextOf adj frontier ↔ ∃ w ∈ wm, frontier.contains w.id = true ∧ i ∈ wmeIds w :=
      fun i => next_mem wm adj hadj frontier i
    have P := new_fold seenS (nextOf adj frontier) [] {} (by simp) (by simp)
    unfold foldNew at *
    generalize (nextOf adj frontier).foldl (fun (acc : List Nat × Std.HashSet Nat) i =>
      if seenS.contains i || acc.2.contains i then acc else (i :: acc.1, acc.2.insert i)) ([], {}) = r at P ⊢
    obtain ⟨new, newS⟩ := r
    obtain ⟨P1, P2, P3⟩ := P
    simp only [List.not_mem_nil, false_or] at P1
    have hmem : ∀ x, x ∈ new.reverse ↔ x ∈ nextOf adj frontier ∧ seenS.contains x = false := by
      intro x; rw [List.mem_reverse]; exact P1 x
    by_cases hne : new.reverse.isEmpty = true
    · simp only [hne, ↓reduceIte]
      have hnil : new.reverse = [] := List.isEmpty_iff.mp hne
      have hseen : ∀ i ∈ nextOf adj frontier, i ∈ seen := by
        intro i hi
        by_cases hc : seenS.contains i = true
        · exact (H1 i).mp hc
        · have hc' : seenS.contains i = false := by simpa using hc
          have := (hmem i).mpr ⟨hi, hc'⟩
          rw [hnil] at this; simp at this
      refine ⟨H2, H5, ?_⟩
      intro w hw hid i hi
      by_cases hf : frontier.contains w.id = true
      · exact hseen i ((hnx i).mpr ⟨w, hw, hf, hi⟩)
      · exact H4 w.id hid (by simpa using hf) w hw rfl i hi
    · have hne' : ¬ new.reverse.isEmpty = true := hne
      simp only [hne', Bool.false_eq_true, ↓reduceIte]
      have hnotS : ∀ y, seenS.contains y = true → newS.contains y = false := by
        intro y hy
        cases hc : newS.contains y with
        | false => rfl
        | true =>
          have := P3 y ((P2 y).mp hc)
          rw [hy] at this; exact absurd this (by simp)
      have H1' : ∀ x, ((newS.fold (·.insert ·) seenS).contains x = true) ↔ x ∈ seen ++ new.reverse := by
        intro x
        rw [ins_fold, List.mem_append, H1, P2 x, List.mem_reverse]
      have H3' : ∀ x, newS.contains x = true → x ∈ seen ++ new.reverse := by
        intro x hx
        exact List.mem_append_right _ (List.mem_reverse.mpr ((P2 x).mp hx))
      -- a witness that the level found something
      obtain ⟨x0, hx0⟩ : ∃ x0, x0 ∈ new.reverse := by
        cases hl : new.reverse with
        | nil => rw [hl] at hne'; simp at hne'
        | cons a l => exact ⟨a, by simp⟩
      obtain ⟨w0, hw0, hf0, -⟩ := (hnx x0).mp ((hmem x0).mp hx0).1
      have hfuel : reachCnt wm (newS.fold (·.insert ·) seenS) newS < n := by
        have hlt := countP_lt_of (p := fun w : WME => !(seenS.contains w.id && !frontier.contains w.id))
          (q := fun w : WME => !((newS.fold (·.insert ·) seenS).contains w.id && !newS.contains w.id))
          w0 wm ?_ hw0 ?_ ?_
        · unfold reachCnt at *; omega
        · intro x hx hq
          by_cases hs : seenS.contains x.id = true
          · by_cases hfr : frontier.contains x.id = true
            · simp [hfr]
            · exfalso
              have h1 : (newS.fold (·.insert ·) seenS).contains x.id = true :=
                (ins_fold _ _ _).mpr (Or.inl hs)
              have h2 := hnotS _ hs
              simp [h1, h2] at hq
          · simp [hs]
        · simp [hf0]
        · have hs : seenS.contains w0.id = true := (H1 _).mpr (H3 _ hf0)
          have h1 : (newS.fold (·.insert ·) seenS).contains w0.id = true := (ins_fold _ _ _).mpr (Or.inl hs)
          simp [h1, hnotS _ hs]
      refine ih (seen ++ new.reverse) _ newS H1' ?_ H3' ?_ ?_ hfuel
      · intro x hx
        rcases List.mem_append.mp hx with h | h
        · exact H2 x h
        · obtain ⟨w, hw, hf, hi⟩ := (hnx x).mp ((hmem x).mp h).1
          exact Reach.step (H2 _ (H3 _ hf)) hw rfl hi
      · intro j hj hjn w hw hid i hi
        rcases List.mem_append.mp hj with h | h
        · by_cases hf : frontier.contains j = true
          · have hi' : i ∈ nextOf adj frontier := (hnx i).mpr ⟨w, hw, by rw [hid]; exact hf, hi⟩
            by_cases hs : seenS.contains i = true
            · exact List.mem_append_left _ ((H1 i).mp hs)
            · exact List.mem_append_right _ ((hmem i).mpr ⟨hi', by simpa using hs⟩)
          · exact List.mem_append_left _ (H4 j h (by simpa using hf) w hw hid i hi)
        · have := (P2 j).mpr (List.mem_reverse.mp h)
          rw [hjn] at this; exact absurd this (by simp)
      · intro x hx; exact List.mem_append_left _ (H5 x hx)

/-- `reach` is correct: an identifier is in `reach wm roots` exactly when it is reachable from the
roots through the elements of `wm` (the definition of "linked to a state", [Man] §2.2). -/
theorem mem_reach_iff (wm : List WME) (roots : List Nat) (i : Nat) :
    i ∈ reach wm roots ↔ Reach wm roots i := by
  have hg := go_spec wm roots _ (fun i p => adj_mem wm i p) (wm.length + 1) roots
    (Std.HashSet.ofList roots) (Std.HashSet.ofList roots)
    (by intro x; simp [Std.HashSet.contains_ofList])
    (fun x hx => Reach.root hx)
    (by intro x hx; simpa [Std.HashSet.contains_ofList] using hx)
    (by intro j hj hf; simp [Std.HashSet.contains_ofList, hj] at hf)
    (fun x hx => hx)
    (by unfold reachCnt; have := @List.countP_le_length _ (fun w : WME =>
          !((Std.HashSet.ofList roots).contains w.id && !(Std.HashSet.ofList roots).contains w.id)) wm
        omega)
  constructor
  · intro h; exact hg.1 i h
  · intro h
    induction h with
    | root hr => exact hg.2.1 _ hr
    | step hj hw hid hi ih => exact hg.2.2 _ hw (hid ▸ ih) _ hi

end Soar
