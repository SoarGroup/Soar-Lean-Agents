import Soar.Match
import Soar.Rand
/-!
# Soar 9.6 — right-hand-side values

Evaluation of right-hand-side values and functions (used by the decision cycle and by chunking).
-/

namespace Soar

/-- A right-hand-side function of Soar 9.6.5, in the one table that lists them. -/
structure RhsFn where
  name : String
  /-- Registered by the kernel when an agent is made (`init_built_in_rhs_functions`,
  `init_built_in_rhs_math_functions`): each is a symbol made after the predefined ones. -/
  kernel : Bool := true
  /-- Registered with `literalize_arguments` true (`add_rhs_function`): the mathematical functions
  of `rhs_functions_math.cpp` and `string`. (Until 2026-10-30 the model listed only the
  arithmetic ones and missed `compute-range`, which the graph-search demonstration agent
  uses.) -/
  literalizes : Bool := false
  /-- Returns a value, and the model evaluates it. -/
  value : Bool := false

/-- The right-hand-side functions, in the order the kernel registers them. `concat` is evaluated
by the model but is not a kernel function. -/
def rhsFunctions : List RhsFn := [
  { name := "count" },
  { name := "dont-learn" },
  { name := "force-learn" },
  { name := "halt" },
  { name := "link-stm-to-ltm" },
  { name := "wait" },
  { name := "write" },
  { name := "trace" },
  { name := "log" },
  { name := "@" },
  { name := "capitalize-symbol", value := true },
  { name := "crlf" },
  { name := "dc", value := true },
  { name := "make-constant-symbol", value := true },
  { name := "strlen", value := true },
  { name := "timestamp", value := true },
  { name := "trim", value := true },
  { name := "string", literalizes := true, value := true },
  { name := "accept" },
  { name := "deep-copy", value := true },
  { name := "ifeq", value := true },
  { name := "from-st-xml" },
  { name := "+", literalizes := true, value := true },
  { name := "*", literalizes := true, value := true },
  { name := "-", literalizes := true, value := true },
  { name := "/", literalizes := true, value := true },
  { name := "div", literalizes := true, value := true },
  { name := "size", literalizes := true, value := true },
  { name := "sum", literalizes := true, value := true },
  { name := "product", literalizes := true, value := true },
  { name := "mod", literalizes := true, value := true },
  { name := "min", literalizes := true, value := true },
  { name := "max", literalizes := true, value := true },
  { name := "set-count", literalizes := true, value := true },
  { name := "set-sum", literalizes := true, value := true },
  { name := "set-multiply", literalizes := true, value := true },
  { name := "set-min", literalizes := true, value := true },
  { name := "set-max", literalizes := true, value := true },
  { name := "set-range", literalizes := true, value := true },
  { name := "set-mean", literalizes := true, value := true },
  { name := "set-stdev", literalizes := true, value := true },
  { name := "sin", literalizes := true, value := true },
  { name := "cos", literalizes := true, value := true },
  { name := "atan2", literalizes := true, value := true },
  { name := "sqrt", literalizes := true, value := true },
  { name := "abs", literalizes := true, value := true },
  { name := "int", literalizes := true, value := true },
  { name := "float", literalizes := true, value := true },
  { name := "round-off-heading", literalizes := true, value := true },
  { name := "round-off", literalizes := true, value := true },
  { name := "compute-heading", literalizes := true, value := true },
  { name := "compute-range", literalizes := true, value := true },
  { name := "extrapolate-x-position", literalizes := true, value := true },
  { name := "extrapolate-y-position", literalizes := true, value := true },
  { name := "select-point-closest-to-vector", literalizes := true, value := true },
  { name := "haversine", literalizes := true, value := true },
  { name := "compute-dice-probability", literalizes := true, value := true },
  { name := "rand-int", literalizes := true, value := true },
  { name := "rand-float", literalizes := true, value := true },
  { name := "concat", kernel := false, value := true }
]


/-! ## Instantiating actions -/

/-- C's `int64_t` arithmetic: wrap to 64 bits. -/
def wrap64 (i : Int) : Int := (i + 9223372036854775808) % 18446744073709551616 - 9223372036854775808

/-- One step of `+`, `*` and `-` as Soar 9.6.5 does them (`plus_rhs_function_code`,
`times_rhs_function_code`, `minus_rhs_function_code`): integers combine in 64 bits until the
first real, which is combined with the integer so far; after it everything is real. -/
def arithStep (op : Int → Int → Int) (fop : Float → Float → Float) :
    Int × Float × Bool → Sym → Int × Float × Bool
  | (i, f, found), .int a => if found then (i, fop f (Float.ofInt a), true) else (wrap64 (op i a), f, false)
  | (i, f, found), .float b =>
    let x := Float.ofBits b
    if found then (i, fop f x, true) else (i, fop (Float.ofInt i) x, true)
  | st, _ => st

/-- Apply a right-hand-side function to evaluated arguments ([Man] §3.3.6.6).

> "+, -, *, / … will take either integer or real-number arguments. The first three functions
> return an integer when all arguments are integers and otherwise return a real number, and
> the last two functions always return a real number." — [Man] §3.3.6.6

The passage lists four functions but speaks of "the first three" and "the last two"; it is
read here as: `+ - *` return an integer when all arguments are integers, and `/` always
returns a real number. -/
def applyFn (f : String) (args : List Sym) : Option Sym :=
  let ints := args.filterMap fun a => match a with | .int i => some i | _ => none
  let allInt := ints.length == args.length
  let nums := args.filterMap Sym.num?
  let allNum := nums.length == args.length
  let real (x : Float) : Option Sym := some (Sym.ofFloat x)
  match f, args with
  | "+", _ => if !allNum then none else
    let (i, x, found) := args.foldl (arithStep (· + ·) (· + ·)) (0, 0, false)
    if found then real x else some (.int i)
  | "*", _ => if !allNum then none else
    let (i, x, found) := args.foldl (arithStep (· * ·) (· * ·)) (1, 0, false)
    if found then real x else some (.int i)
  | "-", [a] => match a with
    | .int i => some (.int (-i))
    | x => x.num?.bind fun v => real (-v)
  | "-", a :: rest => if !allNum then none else
    let init : Int × Float × Bool := match a with
      | .int i => (i, 0, false)
      | x => (0, (x.num?.getD 0), true)
    let (i, x, found) := rest.foldl (arithStep (· - ·) (· - ·)) init
    if found then real x else some (.int i)
  -- division by zero gives no value (Soar 9.6.5 `fp_divide_rhs_function_code`: "attempt to
  -- divide ('/') by zero")
  | "/", [a] => a.num?.bind fun v => if v == 0 then none else real (1 / v)
  | "/", _ :: _ => if allNum then match nums with
      | x :: rest => if rest.any (· == 0) then none else real (rest.foldl (· / ·) x)
      | [] => none
    else none
  | "div", [.int a, .int b] => if b == 0 then none else some (.int (a.tdiv b))
  | "mod", [.int a, .int b] => if b == 0 then none else some (.int (a.tmod b))
  | "abs", [.int a] => some (.int a.natAbs)
  | "abs", [x] => x.num?.bind fun v => real v.abs
  | "sqrt", [x] => x.num?.bind fun v => real v.sqrt
  | "sin", [x] => x.num?.bind fun v => real v.sin
  | "cos", [x] => x.num?.bind fun v => real v.cos
  | "atan2", [x, y] => match x.num?, y.num? with
    | some a, some b => real (Float.atan2 a b)
    | _, _ => none
  | "int", [.int a] => some (.int a)
  | "int", [x] => x.num?.map fun v =>
      .int (if v < 0 then -(Int.ofNat (-v).toUInt64.toNat) else Int.ofNat v.toUInt64.toNat)
  | "float", [x] => x.num?.bind real
  -- Soar 9.6.5 `compute-range x₁ y₁ x₂ y₂`: the distance, truncated to an integer
  | "compute-range", [a, b, c, d] => match a.num?, b.num?, c.num?, d.num? with
    | some x₁, some y₁, some x₂, some y₂ =>
      some (.int (Int.ofNat (((x₁ - x₂) * (x₁ - x₂) + (y₁ - y₂) * (y₁ - y₂)).sqrt.toUInt64.toNat)))
    | _, _, _, _ => none
  | "crlf", [] => some (.str "\n")
  | "concat", _ => some (.str (String.join (args.map fun a => match a with
      | .str s => s | x => x.toSoar)))
  | _, _ => none

/-! ## The rest of Soar 9.6.5's right-hand-side function library

Pure functions of their arguments (`rhs_functions.cpp`, `rhs_functions_math.cpp`). -/

/-- C's `trunc` (`modf`'s integer part, `static_cast<int64_t>`). -/
def ftrunc (x : Float) : Float := if x < 0 then Float.ceil x else Float.floor x

/-- `static_cast<int64_t>(x)` for a finite `x`. -/
def fToInt (x : Float) : Int :=
  let t := ftrunc x
  if t < 0 then -(Int.ofNat (-t).toUInt64.toNat) else Int.ofNat t.toUInt64.toNat

/-- A number as an integer: an integer as it is, a real number truncated (Soar's
`(arg->symbol_type == INT_CONSTANT_SYMBOL_TYPE) ? arg->ic->value : static_cast<int64_t>(arg->fc->value)`). -/
def Sym.asInt? : Sym → Option Int
  | .int i => some i
  | .float b => some (fToInt (Float.ofBits b))
  | _ => none

/-- Wrap to a 32-bit signed integer (C's `int`). -/
def wrap32 (i : Int) : Int :=
  let m := i % 4294967296
  if m ≥ 2147483648 then m - 4294967296 else m

/-- How Soar prints a symbol (`Symbol::to_string`, not rereadable): a string without bars, a
real number with six digits after the point. An identifier is printed by the model's name for
it, which need not be Soar's. -/
def Sym.plain : Sym → String
  | .str s => s
  | .int i => toString i
  | .float b => fixedStrBits b 6
  | .id n => s!"#ID{n}"

def PI_SOAR : Float := 3.141592653589

/-- `normalize_heading_int`, `normalize_heading_float`. -/
def normHeadingI (n : Int) : Int :=
  let r := n % 360   -- Euclidean, in [0, 360)
  if r > 180 then r - 360 else r
def normHeadingF (n : Float) : Float := Id.run do
  let mut n := n
  for _ in [0:100000] do
    if n ≤ -180.0 then n := n + 360.0 else break
  for _ in [0:100000] do
    if n > 180.0 then n := n - 360.0 else break
  return n

/-- `round_off_heading_int`: `m · ((n ± m/2) / m)` with C's integer division. -/
def roundOffI (n m : Int) : Option Int :=
  if m == 0 then none else
  some (if n < 0 then m * ((n - m.tdiv 2).tdiv m) else m * ((n + m.tdiv 2).tdiv m))

/-- `round_off_heading_float`: the same on tenths. -/
def roundOffF (n m : Float) : Float :=
  let n10 := ftrunc (n * 10.0)
  let m10 := ftrunc (m * 10.0)
  let half := ftrunc (m10 / 2.0)
  let u := if n10 < 0.0 then m10 * ftrunc ((n10 - half) / m10) else m10 * ftrunc ((n10 + half) / m10)
  u / 10.0

/-- `heading_to_point`: the compass heading from one point to another, in whole degrees. -/
def headingToPoint (cx cy x y : Int) : Int :=
  let dx := Float.ofInt (x - cx)
  let dy := Float.ofInt (y - cy)
  let mag := (dx * dx + dy * dy).sqrt
  let (nx, ny) := if mag < 0.01 then (1.0, 0.0) else (dx / mag, dy / mag)
  -- convert_to_soar_angle
  let h := Float.atan2 ny nx - PI_SOAR / 2
  let h := if h < 0.0 then h + 2 * PI_SOAR else h
  let h := 2 * PI_SOAR - h
  let h := if h > PI_SOAR then h - 2 * PI_SOAR else h
  -- bracket_rad_to_deg: air_soar_round_off_angle (n, 1)
  let n := fToInt ((h * 180) / PI_SOAR)
  let b := n.tmod 360
  let b := if b > 180 then b - 360 else b
  if b ≤ -180 then b + 360 else b

/-- `compute_x_point`, `compute_y_point`. -/
def extrapolate (c heading speed elapsed : Int) (useSin : Bool) : Int :=
  let rad := Float.ofInt heading * PI_SOAR / 180.0
  let dist := Float.ofInt (speed * elapsed)
  let v := dist * (if useSin then rad.sin else rad.cos)
  c + wrap32 (fToInt v.round)

def haversine (lat1 lon1 lat2 lon2 : Float) : Float :=
  let k := PI_SOAR / 180.0
  let (a1, o1, a2, o2) := (lat1 * k, lon1 * k, lat2 * k, lon2 * k)
  let dLat := a2 - a1
  let dLon := o2 - o1
  let a := (dLat / 2).sin * (dLat / 2).sin + a1.cos * a2.cos * (dLon / 2).sin * (dLon / 2).sin
  6371.0 * (2 * Float.atan2 a.sqrt (1 - a).sqrt)

/-- `_dice_binom`, with Soar's 64-bit unsigned arithmetic. -/
def diceBinom (n m : Nat) : UInt64 := Id.run do
  let mut b : Array UInt64 := Array.replicate (n + 1) 0
  b := b.set! 0 1
  for i in [1:n + 1] do
    b := b.set! i 1
    let mut j := i - 1
    while j > 0 do
      b := b.set! j (b[j]! + b[j - 1]!)
      j := j - 1
  return b[m]!

def diceExact (dice sides count : Int) : Float :=
  if dice < 0 || count < 0 || sides < 1 then 0 else
  if dice == 0 then (if count == 0 then 1 else 0) else
  if count > dice then 0 else
  let p1kd := Float.pow (Float.ofInt sides) (Float.ofInt count)
  let p2nkn := Float.pow (Float.ofInt (sides - 1)) (Float.ofInt (dice - count))
  let p2nkd := Float.pow (Float.ofInt sides) (Float.ofInt (dice - count))
  let r := (diceBinom dice.toNat count.toNat).toNat.toFloat
  let r := r * (1.0 / p1kd)
  r * (p2nkn / p2nkd)

def diceAtLeast (dice sides count : Int) : Float :=
  if dice < 0 || count < 0 || sides < 1 then 0 else
  ((List.range (dice - count + 1).toNat).map (fun (i : Nat) => diceExact dice sides (count + (i : Int)))).foldl (· + ·) 0

def diceZero (x : Float) : Float := if x.abs ≤ 0.00001 then 0 else x

/-- `dice_prob_rhs_function_code`. -/
def diceProb (dice sides count : Int) (pred : String) : Option Float :=
  let ex := diceExact dice sides count
  let al := diceAtLeast dice sides count
  match pred with
  | "eq" => some (if count < 0 || count > dice then 0 else diceZero ex)
  | "ne" => some (if count < 0 || count > dice then 1 else diceZero (1 - ex))
  | "lt" => some (if count ≤ 0 then 0 else if count > dice then 1 else diceZero (1 - al))
  | "gt" => some (if count < 0 then 1 else if count ≥ dice then 0 else diceZero (al - ex))
  | "le" => some (if count < 0 then 0 else if count ≥ dice then 1 else diceZero ((1 - al) + ex))
  | "ge" => some (if count ≤ 0 then 1 else if count > dice then 0 else diceZero al)
  | _ => none

/-- C's `strtoll(s, NULL, 10)`: leading white space, a sign and the digits that follow; 0 if
there are none; `none` (errno set) if the value does not fit in 64 bits. -/
def strtoll (t : String) : Option Int :=
  let cs := t.toList.dropWhile (fun c => c == ' ' || c == '\t' || c == '\n' || c == '\r' || c == '\x0b' || c == '\x0c')
  let (neg, cs) := match cs with
    | '-' :: r => (true, r) | '+' :: r => (false, r) | r => (false, r)
  let ds := cs.takeWhile Char.isDigit
  let v : Nat := ds.foldl (fun a c => a * 10 + (c.toNat - '0'.toNat)) 0
  let i : Int := if neg then -(v : Int) else v
  if i > 9223372036854775807 || i < -9223372036854775808 then none else some i

/-- The decimal part of `strtod`, after white space and the sign. -/
def strtodDec (cs : List Char) (sgn : Float → Float) : Option Float :=
  let ip := cs.takeWhile Char.isDigit
  let r1 := cs.drop ip.length
  let (fp, r2) := match r1 with
    | '.' :: r => let f := r.takeWhile Char.isDigit; (f, r.drop f.length)
    | r => ([], r)
  if ip.isEmpty && fp.isEmpty then some (sgn 0) else
  let ex : Int := match r2 with
    | c :: r => if c == 'e' || c == 'E' then
        let (en, r) := match r with | '-' :: q => (true, q) | '+' :: q => (false, q) | q => (false, q)
        let ed := r.takeWhile Char.isDigit
        if ed.isEmpty then 0 else
        let v : Int := ed.foldl (fun a c => a * 10 + ((c.toNat - '0'.toNat : Nat) : Int)) 0
        if en then -v else v
      else 0
    | [] => 0
  let m : Nat := (ip ++ fp).foldl (fun a c => a * 10 + (c.toNat - '0'.toNat)) 0
  let e : Int := ex - fp.length
  let mag : Int := e + (toString m).length
  if m != 0 && (mag > 330 || mag < -360) then none else
  let x : Float := if m == 0 then 0 else
    if e ≥ 0 then Float.ofScientific m false e.toNat else Float.ofScientific m true (-e).toNat
  if m != 0 && (x.isInf || x.abs < 2.2250738585072014e-308) then none else some (sgn x)

/-- C's `strtod(s, NULL)` for decimal input: leading white space, a sign, digits with an
optional point, an optional exponent; `inf`, `infinity` and `nan` in any case. 0 if no number
begins the string; `none` (errno set) if the value overflows or underflows. Hexadecimal input
(`0x…`, with an optional point and binary exponent `p`) is read as glibc reads it; SIMPLIFIED:
a hexadecimal mantissa of more than 53 bits is rounded by the conversion of a natural number. -/
def strtod (t : String) : Option Float :=
  let cs := t.toList.dropWhile (fun c => c == ' ' || c == '\t' || c == '\n' || c == '\r' || c == '\x0b' || c == '\x0c')
  let (neg, cs) := match cs with
    | '-' :: r => (true, r) | '+' :: r => (false, r) | r => (false, r)
  let sgn (x : Float) := if neg then -x else x
  let low := String.ofList (cs.take 8 |>.map Char.toLower)
  if low.startsWith "inf" then some (sgn Float.inf)
  else if low.startsWith "nan" then some (sgn (0.0 / 0.0))
  else
  let hexv (c : Char) : Option Nat :=
    if c.isDigit then some (c.toNat - '0'.toNat)
    else if 'a' ≤ c.toLower && c.toLower ≤ 'f' then some (c.toLower.toNat - 'a'.toNat + 10) else none
  let isHex (c : Char) : Bool := (hexv c).isSome
  match cs with
  | '0' :: x :: rest =>
    if (x == 'x' || x == 'X') && (rest.head?.map isHex == some true ||
        (rest.head? == some '.' && (rest.drop 1).head?.map isHex == some true)) then
      let ip := rest.takeWhile isHex
      let r1 := rest.drop ip.length
      let (fp, r2) := match r1 with
        | '.' :: r => let f := r.takeWhile isHex; (f, r.drop f.length)
        | r => ([], r)
      let ex : Int := match r2 with
        | c :: r => if c == 'p' || c == 'P' then
            let (en, r) := match r with | '-' :: q => (true, q) | '+' :: q => (false, q) | q => (false, q)
            let ed := r.takeWhile Char.isDigit
            if ed.isEmpty then 0 else
            let v : Int := ed.foldl (fun a c => a * 10 + ((c.toNat - '0'.toNat : Nat) : Int)) 0
            if en then -v else v
          else 0
        | [] => 0
      let m : Nat := (ip ++ fp).foldl (fun a c => a * 16 + ((hexv c).getD 0)) 0
      let x : Float := if m == 0 then 0 else Float.scaleB (Float.ofNat m) (ex - 4 * fp.length)
      if m != 0 && (x.isInf || x.abs < 2.2250738585072014e-308) then none else some (sgn x)
    else strtodDec cs sgn
  | _ => strtodDec cs sgn

/-- `min`, `max`: an integer if every argument is one, else a real number. -/
def minMax (isMin : Bool) (args : List Sym) : Option Sym :=
  if !args.all (fun a => a.num?.isSome) then none else
  let better (x y : Float) := if isMin then x < y else x > y
  if args.all (fun a => match a with | .int _ => true | _ => false) then
    let is := args.filterMap fun a => match a with | .int i => some i | _ => none
    match is with
    | [] => some (.int 0)
    | i :: r => some (.int (r.foldl (fun m x => if (if isMin then x < m else x > m) then x else m) i))
  else
    let fs := args.filterMap Sym.num?
    match fs with
    | [] => some (.int 0)
    | x :: r => some (Sym.ofFloat (r.foldl (fun m y => if better y m then y else m) x))

/-- The pure functions of the library that `applyFn` does not cover. -/
def applyFn2 (f : String) (args : List Sym) : Option Sym :=
  let real (x : Float) : Option Sym := some (Sym.ofFloat x)
  let allNum := args.all (fun a => a.num?.isSome)
  match f, args with
  | "int", [.str t] => (strtoll t).map Sym.int
  | "float", [.str t] => (strtod t).map Sym.ofFloat
  | "min", _ => minMax true args
  | "max", _ => minMax false args
  | "ifeq", [a, b, c, d] => some (if a == b then c else d)
  | "ifeq", [a, b, c] => if a == b then some c else none
  | "strlen", [.id _] => none
  -- Soar counts bytes of the UTF-8 string (`strlen`)
  | "strlen", [a] => some (.int a.plain.utf8ByteSize)
  | "string", [.float x] => some (.str (fixedStrBits x 17))
  | "string", [.id _] => none
  | "string", [a] => some (.str a.plain)
  | "trim", [.str t] =>
    let ws (c : Char) := c == ' ' || c == '\t' || c == '\n'
    some (.str (String.ofList ((t.toList.dropWhile ws).reverse.dropWhile ws).reverse))
  | "capitalize-symbol", [.str t] =>
    some (.str (match t.toList with | c :: r => String.ofList (c.toUpper :: r) | [] => ""))
  -- a first argument that is not a number counts as 0 (Soar 9.6.5 `round_off_air_rhs_function_code`
  -- leaves `n` at 0)
  | "round-off", [n, m] => match (n.num?.getD 0 : Float) |> some, m with
    | some nv, .float mb => real (roundOffF nv (Float.ofBits mb))
    | some nv, .int mi => (roundOffI (fToInt nv) mi).map Sym.int
    | _, _ => none
  | "round-off-heading", [n, m] => match (n.num?.getD 0 : Float) |> some, m with
    | some nv, .float mb => real (normHeadingF (roundOffF nv (Float.ofBits mb)))
    | some nv, .int mi => (roundOffI (fToInt nv) mi).map (Sym.int ∘ normHeadingI)
    | _, _ => none
  | "compute-heading", [a, b, c, d] =>
    if !allNum then none else
    match a.asInt?, b.asInt?, c.asInt?, d.asInt? with
    | some x₁, some y₁, some x₂, some y₂ => some (.int (headingToPoint x₁ y₁ x₂ y₂))
    | _, _, _, _ => none
  | "extrapolate-x-position", [.int x, .int h, .int v, .int t] => some (.int (extrapolate x h v t true))
  | "extrapolate-y-position", [.int y, .int h, .int v, .int t] => some (.int (-(extrapolate (-y) h v t false)))
  | "haversine", [a, b, c, d] => match a.num?, b.num?, c.num?, d.num? with
    | some w, some x, some y, some z => real (haversine w x y z)
    | _, _, _, _ => none
  | "compute-dice-probability", [a, b, c, .str pr] => match a.asInt?, b.asInt?, c.asInt? with
    | some d, some sd, some ct => (diceProb d sd ct pr).bind real
    | _, _, _ => none
  | _, _ => none

/-! ## Functions that read the agent's state -/

/-- What the right-hand-side functions that read the agent's state see. -/
structure RhsCtx where
  /-- An identifier's slots, most recently made first, each with its values, most recent first
  (Soar's `id->slots` and `s->wmes`, both kept newest first; acceptable-preference elements
  are not in them). -/
  slots : Nat → List (Sym × List Sym) := fun _ => []
  /-- The number of decision phases so far (`decide_phases_count`). -/
  dc : Nat := 0
  /-- Whether a string constant exists in the symbol table (for `make-constant-symbol`). -/
  known : String → Bool := fun _ => false
  /-- The long-term identifier an identifier is linked to (for `@`). -/
  lti : Nat → Option Nat := fun _ => none

/-- The state right-hand-side functions change: the random-number generator and
`make-constant-symbol`'s counter and the constants it has made. -/
structure RState where
  rng  : MT := default
  mcs  : Nat := 1
  made : List String := []
  /-- The real number zero already in the symbol table, if any: Soar finds a real-number
  constant by `==` (`find_float_constant`), so 0.0 and -0.0 are one symbol, the one made
  first. -/
  zero : Option Float := none
  deriving Repr, Inhabited

/-- A real-number result as the symbol table gives it back: a zero takes the sign of the zero
constant already there. -/
def RState.canon (st : RState) : Option Sym → Option Sym × RState
  | some (.float b) =>
    let x := Float.ofBits b
    -- a NaN is the x86-64 default NaN, which has the sign bit set (printed -nan)
    if x.isNaN then (some (.float 0xfff8000000000000), st) else
    if x != 0 then (some (.float b), st) else
    match st.zero with
    | some z => (some (Sym.ofFloat z), st)
    | none => (some (.float b), { st with zero := some x })
  | v => (v, st)

def RhsCtx.valuesOf (ctx : RhsCtx) (v : Sym) (attr : Sym) : List Sym :=
  match v with
  | .id n => ((ctx.slots n).find? (·.1 == attr)).map (·.2) |>.getD []
  | _ => []

/-- `set_reduce`: the values reached from an identifier through one to three attributes. -/
def RhsCtx.setValues (ctx : RhsCtx) : List Sym → Option (List Sym)
  | .id n :: a :: rest =>
    let l1 := ctx.valuesOf (.id n) a
    some (match rest with
      | [] => l1
      | b :: rest2 =>
        let l2 := l1.flatMap fun v => ctx.valuesOf v b
        match rest2 with
        | [] => l2
        | c :: _ => l2.flatMap fun v => ctx.valuesOf v c)
  | [.id _] => some []
  | _ => none

/-- C's `static_cast<int>(w->value->ic->value)` for `sum` and `product`: an integer's value, or
for a real number the low 32 bits of its representation, which is what that reads. -/
def icValue : Sym → Option Int
  | .int i => some (wrap32 i)
  | .float b => some (wrap32 (Int.ofNat (b &&& 0xffffffff).toNat))
  | _ => none

def applyCtxFn (ctx : RhsCtx) (f : String) (args : List Sym) (st : RState) : Option (Option Sym × RState) :=
  let nan : Sym := .str "NaN"
  let setErr : Sym := .str "|ERROR: First parameter needs to be an identifier.|"
  let nums (vs : List Sym) := vs.filterMap Sym.num?
  let ret (x : Option Sym) := some (x, st)
  match f, args with
  | "dc", [] => ret (some (.int ctx.dc))
  -- `(@ <x>)`: the number of the long-term identifier `<x>` is linked to
  | "@", [.id n] => ret ((ctx.lti n).map fun l => .int l)
  | "@", [_] => ret none
  | "size", [.id n] => ret (some (.int ((ctx.slots n).foldl (fun a (_, vs) => a + vs.length) 0)))
  | "size", [_] => ret none
  | "sum", [.id n] =>
    let vs := (ctx.slots n).flatMap (·.2)
    ret ((vs.mapM icValue).map fun is => .int (is.foldl (fun a x => wrap32 (a + x)) 0))
  | "product", [.id n] =>
    let vs := (ctx.slots n).flatMap (·.2)
    ret ((vs.mapM icValue).map fun is => .int (is.foldl (fun a x => wrap32 (a * x)) 1))
  | "set-count", _ => ret (match ctx.setValues args with
    | some vs => some (.int vs.length) | none => some setErr)
  | "set-sum", _ => ret (match ctx.setValues args with
    | some vs => let xs := nums vs; some (if xs.isEmpty then nan else Sym.ofFloat (xs.foldl (· + ·) 0))
    | none => some setErr)
  | "set-multiply", _ => ret (match ctx.setValues args with
    | some vs => let xs := nums vs; some (if xs.isEmpty then nan else Sym.ofFloat (xs.foldl (· * ·) 1))
    | none => some setErr)
  | "set-min", _ => ret (match ctx.setValues args with
    | some vs => (match nums vs with
      | [] => some nan | x :: r => some (Sym.ofFloat (r.foldl (fun m y => if y < m then y else m) x)))
    | none => some setErr)
  | "set-max", _ => ret (match ctx.setValues args with
    | some vs => (match nums vs with
      | [] => some nan | x :: r => some (Sym.ofFloat (r.foldl (fun m y => if y > m then y else m) x)))
    | none => some setErr)
  | "set-range", _ => ret (match ctx.setValues args with
    | some vs => (match nums vs with
      | [] => some nan
      | x :: r => some (Sym.ofFloat (r.foldl (fun m y => if y > m then y else m) x - r.foldl (fun m y => if y < m then y else m) x)))
    | none => some setErr)
  | "set-mean", _ => ret (match ctx.setValues args with
    | some vs => let xs := nums vs; some (if xs.isEmpty then nan else Sym.ofFloat (xs.foldl (· + ·) 0 / xs.length.toFloat))
    | none => some setErr)
  | "set-stdev", _ => ret (match ctx.setValues args with
    | some vs =>
      let xs := nums vs
      if xs.isEmpty then some nan else
      let mean := xs.foldl (· + ·) 0 / xs.length.toFloat
      let ss := xs.foldl (fun a x => a + (x - mean) * (x - mean)) 0
      some (Sym.ofFloat (ss / xs.length.toFloat).sqrt)
    | none => some setErr)
  | "select-point-closest-to-vector", [.int x, .int y, .int h, .id pts] =>
    -- the points are the values of the identifier's first slot
    let ps := match ctx.slots pts with | (_, vs) :: _ => vs | [] => []
    let pointOf (p : Sym) : Option (Int × Int × String) := do
      let px ← (ctx.valuesOf p (.str "x")).head?.bind Sym.asInt?
      let py ← (ctx.valuesOf p (.str "y")).head?.bind Sym.asInt?
      let pid ← (ctx.valuesOf p (.str "id")).head?
      if !p.isId then none
      return (px, -py, pid.plain)
    match ps.mapM pointOf with
    | none => ret none
    | some pts' =>
      let sx := x; let sy := -y
      let angle (p : Int × Int × String) : Float :=
        let d := Float.atan2 (Float.ofInt (p.2.1 - sy)) (Float.ofInt (p.1 - sx)) * 180 / PI_SOAR
        let d := 90 - d
        if d < 0 then d + 360 else d
      let adiff (a : Float) : Float := let d := (Float.ofInt h - a).abs; if d > 180 then 360 - d else d
      let dist (p : Int × Int × String) : Float :=
        let dx := wrap32 (p.1 - sx); let dy := wrap32 (p.2.1 - sy)
        Float.ofInt (wrap32 (wrap32 (dx * dx) + wrap32 (dy * dy))) |>.sqrt
      let start : Int × Int × String := (1000, 1000, "no_valid_point")
      let (_, best) := pts'.foldl (fun (acc : Float × (Int × Int × String)) p =>
        let (md, b) := acc
        let ad := adiff (angle p)
        let (md, b) := if ad < md then (ad, p) else (md, b)
        if ad == md && dist p < dist b then (ad, p) else (md, b)) (Float.inf, start)
      ret (some (.str best.2.2))
  | "make-constant-symbol", _ =>
    let pre := if args.isEmpty then "constant" else String.join (args.map Sym.plain)
    let exists' (t : String) := ctx.known t || st.made.contains t
    if args.isEmpty && !exists' pre then some (some (.str pre), { st with made := pre :: st.made }) else
    let rec gen (fuel k : Nat) : Nat := match fuel with
      | 0 => k
      | f + 1 => if exists' (pre ++ toString k) then gen f (k + 1) else k
    let k := gen 100000 st.mcs
    let t := pre ++ toString k
    some (some (.str t), { st with mcs := k + 1, made := t :: st.made })
  -- Soar prints the local time; the model has no clock and gives a fixed time
  | "timestamp", [] => ret (some (.str "1970-01-01 00:00:00.000"))
  -- `(accept)` reads a symbol from standard input (Soar 9.6.5 `accept_rhs_function_code`); the
  -- model has no standard input and behaves as Soar does at end of input: no value. Soar does
  -- not allow it as a stand-alone action, and neither does the parser.
  -- SIMPLIFIED: input is not read.
  | "accept", [] => ret none
  | _, _ => none

/-- Evaluate a right-hand-side value under the bindings, with new identifiers for unbound
variables. -/
partial def RVal.eval (b : Binding) (fresh : List (String × Nat)) : RVal → Option Sym
  | .var v => match b.get v with
    | some x => some x
    | none => (fresh.find? (·.1 == v)).map (fun p => .id p.2)
  | .sym x => some x
  | .call f args => (args.mapM (RVal.eval b fresh)) >>= fun vs => (applyFn f vs).orElse (fun _ => applyFn2 f vs)

/-- The functions that draw on the random-number generator (Soar 9.6.5
`rand_int_rhs_function_code`, `rand_float_rhs_function_code`): `(rand-int n)` is an integer in
[0, n] for n > 0 (a real argument is truncated), and any 32-bit unsigned integer without an
argument or for n ≤ 0; `(rand-float x)` is a real number in [0, x] for x > 0, and in [0, 1]
without an argument or for x ≤ 0. A non-number argument gives no value. -/
def applyRandFn (f : String) (args : List Sym) (r : MT) : Option (Option Sym × MT) :=
  let full (r : MT) : Option Sym × MT := let (i, r) := r.randInt; (some (.int (Int.ofNat i.toNat)), r)
  match f, args with
  | "rand-int", [] => some (full r)
  -- Soar uses the first argument and ignores the rest
  | "rand-int", a :: _ =>
    let n? : Option Int := match a with
      | .int i => some i
      | .float _ => a.num?.map fun v => if v < 0 then -(Int.ofNat (-v).toUInt64.toNat) else Int.ofNat v.toUInt64.toNat
      | _ => none
    match n? with
    | none => some (none, r)
    | some n =>
      if n > 0 then
        let (i, r) := MT.randIntN n.toNat.toUInt32 r
        some (some (.int (Int.ofNat i.toNat)), r)
      else some (full r)
  | "rand-float", [] => let (x, r) := r.rand; some (some (Sym.ofFloat x), r)
  | "rand-float", a :: _ => match a.num? with
    | some v => let (x, r) := r.rand; some (some (Sym.ofFloat (if v > 0 then x * v else x)), r)
    | none => some (none, r)
  | _, _ => none

/-- `RVal.eval` with the agent's state: arguments are evaluated left to right; `rand-int` and
`rand-float` draw from the generator, and the functions that read working memory or the
decision count, or make constants, see `ctx`. -/
partial def RVal.evalR (ctx : RhsCtx) (b : Binding) (fresh : List (String × Nat)) : RVal → RState → Option Sym × RState
  | .call f args, st =>
    let (vs, st) := args.foldl (fun (acc : Option (List Sym) × RState) a =>
      let (v, st) := RVal.evalR ctx b fresh a acc.2
      ((acc.1.bind fun l => v.map (l ++ [·])), st)) (some [], st)
    match vs with
    | none => (none, st)
    | some vs =>
      let (v, st) := match applyRandFn f vs st.rng with
        | some (v, r) => (v, { st with rng := r })
        | none => match applyCtxFn ctx f vs st with
          | some res => res
          | none => ((applyFn f vs).orElse (fun _ => applyFn2 f vs), st)
      st.canon v
  | x, st => (RVal.eval b fresh x, st)

partial def RVal.vars : RVal → List String
  | .var v => [v]
  | .sym _ => []
  | .call _ args => args.flatMap RVal.vars

def actionVars : Action → List String
  | .make i a v => i :: a.vars ++ v.vars
  | .remove i a v => i :: a.vars ++ v.vars
  | .pref s o _ o₂ _ => s :: o.vars ++ (o₂.map RVal.vars).getD []
  | .halt => []
  | .write vs => vs.flatMap RVal.vars
  | .cmd _ => []


end Soar
