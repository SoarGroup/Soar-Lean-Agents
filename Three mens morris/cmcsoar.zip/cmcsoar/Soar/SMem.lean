import Soar.Syntax
/-!
# Soar 9.6 — semantic memory: the long-term store

Semantic memory ([Man] chapter 6) as a store of long-term identifiers (LTIs) with
augmentations, and the store's three operations: storing an LTI, a cue-based query, and
reading an LTI's augmentations. How commands are read from working memory and how results
are placed there is in `Soar.Cycle`.

The store is modelled on Soar 9.6.5's SQLite schema (checked against the 9.6.5 source,
`semantic_memory/*.cpp`, 2026-10-29), because the order in which a query considers candidates
— which decides between equally activated matches — follows that schema: each augmentation
is a row with a row number and an activation value, and a query walks the rows of its most
selective cue element in order of decreasing activation, and among equal activations, of
decreasing row number.

Activation is recency (the default), frequency or base-level (with the stable, naive and
incremental update policies, the ten-entry access history and its approximation, and
prohibits), as Soar 9.6.5's `lti_activate` and `lti_calc_base` compute them
(`smem_activation.cpp`). An LTI with `thresh` (100) or more augmentations has its
augmentations at the highest activation, and a query takes such LTIs in the order of their own
activation (Soar's `plentiful_parents`).

Spreading activation (`smem --set spreading on`) is in the section of that name below: each LTI
with an element in working memory spreads, along the edge weights of the store, to the LTIs it
can reach, and an LTI that receives spread is ordered in queries by its base activation plus
the log of the spread it receives (`smem_activation.cpp` `calc_spread`, `trajectory_construction`,
`child_spread`).
-/

namespace Soar

/-- The value of a long-term augmentation: a constant or another LTI.

> "Currently semantic memory only supports attributes that are symbolic constants (string,
> integer, or decimal), but not attributes that are identifiers" — [Man] §6.2 -/
inductive LVal where
  | const : Sym → LVal
  | lti   : Nat → LVal
  deriving DecidableEq, Repr

/-- A long-term augmentation `(@lti ^attr val)`, with its row number and activation. -/
structure Edge where
  row  : Nat
  lti  : Nat
  attr : Sym
  val  : LVal
  act  : Float
  /-- The edge weight (`edge_weight`) of an LTI-valued augmentation: 1 / (the number of the
  LTI's LTI-valued augmentations) when written, changed by edge updating. -/
  weight : Float := 0
  deriving Repr

/-- Soar's activation value for augmentations never activated (`SMEM_ACT_LOW`). -/
def actLow : Float := -1000000000

/-- `base-update-policy`: when base-level activations are recomputed. -/
inductive BaseUpdate where
  | stable | naive | incremental
  deriving Repr, BEq, DecidableEq, Inhabited

/-- The row of an LTI receiving spread (`smem_current_spread_activations`): its base
activation (raw), the spread it receives, and its activation for queries. -/
structure Fake where
  base   : Float
  spread : Float
  value  : Float
  deriving Repr, Inhabited

/-- Spreading activation's state (Soar 9.6.5's in-memory maps and spreading tables):
* `inWm`: per LTI, the number of working-memory elements whose identifier stands for it
  (`smem_in_wmem`); `snap`: those elements, by timetag, as last seen;
* `adds`, `rems`: the sources added and removed since spread was last computed
  (`smem_context_additions`, `smem_context_removals`);
* `traj`: per source, its recorded paths (at most eleven LTIs each), each with its valid bit
  (`smem_likelihood_trajectories`); `like`: per source, the spread it gives each LTI it reaches
  (`smem_likelihoods`); `trajNum`: per source, their sum (`smem_trajectory_num`);
* `cur`: the fingerprints of the sources in context, by (source, recipient)
  (`smem_current_spread`); `recips`, `recipCnt`, `spreadTo`: the bookkeeping maps
  (`smem_recipients_of_source`, `smem_recipient`, `smem_spreaded_to`); `fake`: the rows of the
  LTIs receiving spread;
* `edgeUpd`: per parent LTI, the edge updates recorded by working-memory activation
  (`smem_edges_to_update`); `invalid`: parents whose paths are to be invalidated
  (`smem_invalid_parents`), and the position of Soar's never-reset check on them. -/
structure Spread where
  inWm     : List (Nat × Nat) := []
  snap     : List (Nat × Nat) := []
  adds     : List Nat := []
  rems     : List Nat := []
  traj     : List (Nat × List (List Nat × Bool)) := []
  like     : List (Nat × List (Nat × Float)) := []
  trajNum  : List (Nat × Float) := []
  cur      : List ((Nat × Nat) × (Float × Float)) := []
  recips   : List (Nat × List Nat) := []
  recipCnt : List (Nat × Nat) := []
  spreadTo : List Nat := []
  fake     : List (Nat × Fake) := []
  edgeUpd  : List (Nat × List (Nat × Float × Nat)) := []
  invalid  : List Nat := []
  invCursor : Option Nat := none
  deriving Repr, Inhabited

/-- The semantic store. -/
structure SMemDB where
  edges    : List Edge := []
  ltis     : List Nat := []
  /-- The last LTI number assigned. -/
  counter  : Nat := 0
  /-- The activation clock (`smem_max_cycle`), starting at 1. -/
  clock    : Nat := 1
  /-- Symbols the store has seen (Soar's symbol hash table). -/
  syms     : List Sym := []
  /-- The activation recorded for each activated LTI (what `print @` shows). -/
  ltiAct   : List (Nat × Float) := []
  /-- Parameters: `activate-on-query` (default on), `activate-on-add` (default off). -/
  activateOnQuery : Bool := true
  activateOnAdd   : Bool := false
  /-- `activation-mode`: recency (default) or frequency. -/
  frequency : Bool := false
  /-- Accesses of each LTI (for frequency activation). -/
  accesses : List (Nat × Nat) := []
  /-- LTI aliases (`@name` in `smem --add`). -/
  aliases : List (String × Nat) := []
  /-- `activation-mode base-level`, with `base-decay`, `base-update-policy`,
  `base-incremental-threshes`, `base-unused-age-offset` and `base-inhibition`; and `thresh`. -/
  baseLevel : Bool := false
  baseDecay : Float := 0.5
  baseUpdate : BaseUpdate := .stable
  baseThreshes : List Nat := [10]
  baseOffset : Nat := 0
  baseInhibition : Bool := false
  thresh : Nat := 100
  /-- Per LTI: the times of its last and first accesses (`activations_last`,
  `activations_first`). -/
  accTimes : List (Nat × Nat × Nat) := []
  /-- Per LTI with a history row: its access times, most recent first, at most ten
  (`smem_activation_history`; every access here is one touch). -/
  history : List (Nat × List Nat) := []
  /-- Prohibited LTIs, each with whether its prohibit is dirty (`smem_prohibited`). -/
  prohib : List (Nat × Bool) := []
  /-- The LTIs with a row in `smem_prohibited`: those written by `LTM_to_DB` (stored, or added
  with augmentations by `smem --add`). Only these can be prohibited. -/
  prohibRows : List Nat := []
  /-- `smem_lti.activation_base_level` per LTI (raw, before the age default; 0 when never
  set). -/
  ltiBase : List (Nat × Float) := []
  /-- Spreading: `spreading`, `spreading-baseline`, `spreading-continue-probability`,
  `spreading-limit`, `spreading-depth-limit`, `spreading-loop-avoidance`,
  `spreading-wma-source`, `spreading-edge-updating`, `spreading-edge-update-factor`. -/
  spreading : Bool := false
  spBaseline : Float := 0.0001
  spContinue : Float := 0.9
  spLimit : Nat := 300
  spDepth : Nat := 10
  spLoop : Bool := false
  spWmaSource : Bool := false
  spEdgeUpd : Bool := false
  spEdgeFactor : Float := 0.99
  spread : Spread := {}
  deriving Repr

namespace SMemDB

def nextRow (db : SMemDB) : Nat := (db.edges.map (·.row)).foldl max 0 + 1

/-- A new LTI: the next unused number. -/
def newLti (db : SMemDB) : SMemDB × Nat :=
  let rec go (fuel n : Nat) : Nat :=
    match fuel with
    | 0 => n
    | f + 1 => if db.ltis.contains n then go f (n + 1) else n
  let n := go (db.ltis.length + 1) (db.counter + 1)
  ({ db with counter := n, ltis := db.ltis ++ [n] }, n)

def ensureLti (db : SMemDB) (n : Nat) : SMemDB :=
  if db.ltis.contains n then db else { db with ltis := db.ltis ++ [n] }

def edgesOf (db : SMemDB) (n : Nat) : List Edge := db.edges.filter (·.lti == n)

/-- Soar's `SMEM_ACT_MAX` (2^63 − 1 as a double): the activation of the augmentations of an LTI
with `thresh` or more of them. -/
def actMax : Float := (9223372036854775807 : Nat).toFloat

/-- Give every augmentation of LTI `n` activation `a` (Soar's `act_set`). -/
def setActs (db : SMemDB) (n : Nat) (a : Float) : SMemDB :=
  { db with edges := db.edges.map fun e => if e.lti == n then { e with act := a } else e }

/-- The floor of a spread contribution (`calc_spread`, `lti_activate`): the baseline divided
by p(1+p)^D, computed as Soar does, for continue probability p and depth limit D. -/
def spOffset (db : SMemDB) : Float :=
  let p := db.spContinue
  let bd := (List.range db.spDepth).foldl (fun bd _ => bd + bd * p) p
  db.spBaseline / bd

/-- The activation of an LTI with no base-level information: one access at the agent's
creation, `base-unused-age-offset` earlier, at clock `t`. -/
def ageBase (db : SMemDB) (t : Nat) : Float :=
  let x := Float.pow (t + db.baseOffset).toFloat (-db.baseDecay)
  Float.log (x / (1 + x))

end SMemDB

namespace SMemDB

/-- The row of an LTI's access history, most recent first. -/
def histOf (db : SMemDB) (n : Nat) : Option (List Nat) := (alGet db.history n)
def setHist (db : SMemDB) (n : Nat) (h : List Nat) : SMemDB :=
  { db with history := (alPut db.history n h) }
/-- `history_add`: a new row, if the LTI has none (the insert fails otherwise). -/
def histAdd (db : SMemDB) (n t : Nat) : SMemDB :=
  match db.histOf n with | some _ => db | none => db.setHist n [t]
/-- `history_push`: the access becomes the most recent of the row's ten entries. -/
def histPush (db : SMemDB) (n t : Nat) : SMemDB :=
  match db.histOf n with | some h => db.setHist n ((t :: h).take 10) | none => db
/-- `history_remove`: the most recent entry is dropped. -/
def histRemove (db : SMemDB) (n : Nat) : SMemDB :=
  match db.histOf n with | some h => db.setHist n h.tail | none => db
/-- The touches of the most recent entry (`touch1`). -/
def histHead (db : SMemDB) (n : Nat) : Nat :=
  match db.histOf n with | some (_ :: _) => 1 | _ => 0
def prohibOf (db : SMemDB) (n : Nat) : Option Bool := (alGet db.prohib n)
/-- An LTI's access record: number of accesses, last and first access time. -/
def accOf (db : SMemDB) (n : Nat) : Nat × Nat × Nat :=
  let c := ((alGet db.accesses n)).getD 0
  let (l, f) := ((alGet db.accTimes n)).getD (0, 0)
  (c, l, f)
def setAcc (db : SMemDB) (n c l f : Nat) : SMemDB :=
  { db with accesses := (alPut db.accesses n c),
            accTimes := (alPut db.accTimes n (l, f)) }

/-- Base-level activation (Soar 9.6.5 `lti_calc_base`): the sum over the access history of
(t_now − t_i)^(−d), as log(sum / (1 + sum)) (the approximation of accesses beyond the last
ten is in the code but never reached); `SMEM_ACT_LOW` if the sum is not positive. With `base-inhibition`,
the log odds of (1 + (recent/10)^−1)^−1 are added, recent being the age of the latest access.

> "base-level activation … ln(Σ t_j^(-d))" — [Man] §6.4.2.1 (Soar 9.6.5 computes the log
> odds, log(s / (1 + s)), not the log). -/
def calcBase (db : SMemDB) (n timeNow nAcc first : Nat) : Float :=
  let d := db.baseDecay
  let hist := (db.histOf n).getD []
  -- Soar counts the history's entries by reading t1, t2, … until a 0; when all ten are used it
  -- reads on into touch1…touch10 (each 1) and stops past the last column, so a full history
  -- counts as 20 entries and the approximation below, which needs exactly ten, is never made
  -- (Section 11 of the report)
  let avail := if hist.length == 10 then 20 else hist.length
  let sum0 := hist.foldl (fun s t => s + Float.pow (timeNow - t).toFloat (-d)) 0
  let recent := match hist with | t :: _ => if nAcc > 0 then timeNow - t else 0 | [] => 0
  let sum := if nAcc > avail && avail == 10 then
      let tn := timeNow - first
      let tk := timeNow - hist.getLast!
      if tn != tk then
        sum0 + ((nAcc - 10).toFloat * (Float.pow tn.toFloat (1 - d) - Float.pow tk.toFloat (1 - d))) /
          ((1 - d) * (tn - tk).toFloat)
      else sum0 + (nAcc - avail).toFloat * Float.pow tn.toFloat (-d)
    else sum0
  if sum > 0 then
    let b := Float.log (sum / (1 + sum))
    if recent != 0 && db.baseInhibition then
      let odds := Float.pow (1 + Float.pow (recent.toFloat / 10) (-1)) (-1)
      b + Float.log (odds / (1 + odds))
    else b
  else actLow

/-- The access history after an activation: with base-level activation, an access adds the
time (a new row if the LTI has none and no prohibit took one back). -/
def finishHist (db : SMemDB) (n timeNow prev1 : Nat) (access prohibited : Bool) : SMemDB :=
  if db.baseLevel && access then
    (if prev1 == 0 && !prohibited then db.histAdd n timeNow else db.histPush n timeNow)
  else db

/-- The new activation `v` of LTI `n` (recency, frequency or base-level; none gives the age
default) is recorded, and its augmentations are given it. An LTI receiving spread keeps its
spread: its row in the spread table takes the new base, and its augmentations are left as
they are. -/
def finishTail (db : SMemDB) (n : Nat) (v : Float) (numEdges : Nat) : SMemDB × Float :=
  let base := if v == actLow || v == 0 then
      let b := Float.pow (db.clock + db.baseOffset).toFloat (-db.baseDecay)
      Float.log (b / (1 + b))
    else v
  if db.spreading && db.spread.spreadTo.contains n then
    let sp := ((db.spread.fake.find? (·.1 == n)).map (·.2.spread)).getD 0
    let off := db.spOffset
    let m := if sp == 0 || sp < off then 0 else Float.log sp - Float.log off
    ({ db with spread := { db.spread with fake := db.spread.fake.map fun (k, f) => if k == n then (k, { base := v, spread := sp, value := base + m }) else (k, f) } },
     base + m)
  else
  let db : SMemDB := { db with ltiAct := (alPut db.ltiAct n base),
                               ltiBase := (alPut db.ltiBase n v) }
  (db.setActs n (if numEdges < db.thresh then base else SMemDB.actMax), base)

/-- The end of `lti_activate`: the access record, the history (base-level), the new activation
(recency: the time; frequency: the number of accesses; base-level: `calcBase`), with no
history Soar's assumption of one access at the agent's creation, and the activation of the
LTI's augmentations (`actMax` with `thresh` or more). -/
def finish (db : SMemDB) (n timeNow prevN prevT prev1 : Nat) (access prohibited : Bool)
    (numEdges : Nat) : SMemDB × Float :=
  let nNew := prevN + (if access then 1 else 0)
  let db := db.setAcc n nNew (if access then timeNow else prevT)
    (if prevN == 0 then (if access then timeNow else 0) else prev1)
  let db := db.finishHist n timeNow prev1 access prohibited
  let v : Float :=
    if db.baseLevel then db.calcBase n (timeNow + (if access then 1 else 0)) nNew prev1
    else if db.frequency then nNew.toFloat
    else timeNow.toFloat
  db.finishTail n v numEdges

/-- `lti_activate` without an access: a dirty prohibit takes back the latest access. -/
def activateNA (db : SMemDB) (n numEdges : Nat) : SMemDB × Float :=
  let (prevN0, prevT, prev1) := db.accOf n
  let (db, prevN, prohibited) : SMemDB × Nat × Bool := match db.prohibOf n with
    | some true =>
      let k := db.histHead n
      let db := db.histRemove n
      ({ db with prohib := (alPut db.prohib n false) }, prevN0 - k, true)
    | some false => (db, prevN0, true)
    | none => (db, prevN0, false)
  db.finish n db.clock prevN prevT prev1 false prohibited numEdges

/-- With the incremental base-level update policy, LTIs last accessed exactly one of
`base-incremental-threshes` ago are recomputed (`lti_activate`). -/
def refreshIncr (db : SMemDB) (timeNow : Nat) : SMemDB :=
  if db.baseLevel && db.baseUpdate == .incremental then
    db.baseThreshes.foldl (fun db b =>
      if b > 0 && timeNow > b then
        let ids := ((db.accTimes.filter (·.2.1 == timeNow - b)).map (·.1)).toArray.qsort (· < ·)
        ids.toList.foldl (fun db m => (db.activateNA m (db.edgesOf m).length).1) db
      else db) db
  else db

/-- `lti_activate` with an access: the clock advances; a prohibit is cleared (a dirty one
taking back the latest access); with the incremental policy, LTIs last accessed exactly one
of `base-incremental-threshes` ago are recomputed first. -/
def activateA (db : SMemDB) (n numEdges : Nat) : SMemDB × Float :=
  let (prevN0, prevT, prev1) := db.accOf n
  let timeNow := db.clock
  let (db, prevN, prohibited) : SMemDB × Nat × Bool := match db.prohibOf n with
    | some dirty =>
      let k := if dirty then db.histHead n else 0
      let db := if dirty then db.histRemove n else db
      ({ db with prohib := db.prohib.filter (·.1 != n) }, prevN0 - k, true)
    | none => (db, prevN0, false)
  let db := { db with clock := timeNow + 1 }
  (db.refreshIncr timeNow).finish n timeNow prevN prevT prev1 true prohibited numEdges

/-- Activate an LTI (Soar 9.6.5 `lti_activate`), with or without an access.

> "Recency activation attaches a time-stamp to each LTI and records the time of last
> retrieval." — [Man] §6.4.2.1 -/
def activate (db : SMemDB) (n : Nat) (access : Bool) (numEdges : Nat) : SMemDB × Float :=
  if access then db.activateA n numEdges else db.activateNA n numEdges

/-- Give every augmentation of LTI `n` the lowest activation (`SMEM_ACT_LOW`). -/
def lowAct (db : SMemDB) (n : Nat) : SMemDB :=
  { db with edges := db.edges.map fun e => if e.lti == n then { e with act := actLow } else e }

/-- Add one augmentation `xv` to LTI `n` with activation `a`, in the next row. -/
def appendEdge (n : Nat) (a : Float) (db : SMemDB) (xv : Sym × LVal) : SMemDB :=
  { db with edges := db.edges ++ [{ row := db.nextRow, lti := n, attr := xv.1, val := xv.2, act := a }] }

def _root_.Soar.LVal.isLti : LVal → Bool | .lti _ => true | _ => false

/-- Set the weight of the augmentations satisfying `p` to `w`. -/
def setWeights (db : SMemDB) (p : Edge → Bool) (w : Float) : SMemDB :=
  { db with edges := db.edges.map fun e => if p e then { e with weight := w } else e }

/-- Mark invalid every recorded path in which LTI `p` is followed by another LTI
(`trajectory_invalidate_from_lti`). -/
def invalidateFrom (db : SMemDB) (p : Nat) : SMemDB :=
  let follows (path : List Nat) : Bool :=
    ((path.take 10).zip (List.range 10)).any fun (x, i) => x == p && i + 1 < path.length
  { db with spread := { db.spread with traj := db.spread.traj.map fun (src, rows) =>
      (src, rows.map fun (path, v) => (path, v && !follows path)) } }

def invalidateIf (db : SMemDB) (c : Bool) (p : Nat) : SMemDB := if c then db.invalidateFrom p else db

/-- Write augmentations of LTI `n` (Soar's `LTM_to_DB`). With `removeOld` the LTI's previous
augmentations are replaced; otherwise the new ones are added to them. With `act` the LTI is
activated (without an access unless `activate-on-add` is on). -/
def write (db : SMemDB) (n : Nat) (aug : List (Sym × LVal)) (removeOld act : Bool) : SMemDB :=
  let db₁ := ensureLti db n
  let db₂ := if removeOld then { db₁ with edges := db₁.edges.filter (·.lti != n) } else db₁
  let existing := db₂.edgesOf n
  -- edge weights (`LTM_to_DB`): new LTI-valued augmentations get 1 / (the LTI's LTI-valued
  -- augmentations), and when any LTI value is written all of them are reset to that
  let addedEdges := aug.any (·.2.isLti)
  let existingLti := (existing.filter (·.val.isLti)).length
  let aug := aug.eraseDups.filter fun (a, v) => !existing.any (fun e => e.attr == a && e.val == v)
  let newLti := (aug.filter (·.2.isLti)).length
  let fan : Float := 1.0 / (existingLti + newLti).toFloat
  -- constants first, then LTI values (as Soar inserts them)
  let aug := aug.filter (fun x => match x.2 with | .const _ => true | _ => false) ++
             aug.filter (fun x => match x.2 with | .lti _ => true | _ => false)
  let total := existing.length + aug.length
  let above := total ≥ db.thresh
  let db₃ := if existing.length < db.thresh && above then lowAct db₂ n else db₂
  let pa := if act then db₃.activate n db₃.activateOnAdd total else (db₃, actLow)
  let webAct := if act && !above then pa.2 else actLow
  let syms := aug.flatMap fun (x, v) => match v with | .const c => [x, c] | _ => [x]
  let rows := if pa.1.prohibRows.contains n then pa.1.prohibRows else pa.1.prohibRows ++ [n]
  let db₄ := { pa.1 with syms := pa.1.syms ++ syms.filter (!pa.1.syms.contains ·), prohibRows := rows }
  let db₅ := aug.foldl (appendEdge n webAct) db₄
  let db₅ := db₅.setWeights (fun e => e.lti == n && e.val.isLti && (addedEdges || existing.all (·.row != e.row))) fan
  -- with spreading, paths through this LTI are invalidated when it gains LTI children
  let db₅ := db₅.invalidateIf (db₅.spreading && newLti > 0) n
  let lv := aug.filterMap fun (_, v) => match v with | .lti m => some m | _ => none
  lv.foldl ensureLti db₅

end SMemDB

/-! ## Queries ([Man] §6.4.2) -/

/-- A mathematical condition on a cue attribute ([Man] §6.4.2: `math-query`). -/
inductive MathCond where
  | less (v : Float) | greater (v : Float) | lessEq (v : Float) | greaterEq (v : Float)
  | max | min
  deriving Repr

/-- What a cue element requires of a candidate LTI's augmentations with its attribute.

> "A cue WME with a constant value denotes an exact match of both attribute and value. A cue
> WME with an LTI-linked identifier as its value denotes an exact match of attribute and
> linked LTI. A cue WME with a short-term identifier as its value denotes an exact match of
> attribute, but with any value" — [Man] §6.4.2 -/
inductive CueKind where
  | any
  | const (c : Sym)
  | lti (n : Nat)
  | math (m : MathCond)
  deriving Repr, Inhabited

structure CueEl where
  attr : Sym
  kind : CueKind
  pos  : Bool
  deriving Repr, Inhabited

namespace SMemDB

/-- How selective a cue element is (the statistics Soar keeps): the number of LTIs with the
attribute, or of augmentations with the attribute and value. -/
def weight (db : SMemDB) (el : CueEl) : Nat :=
  match el.kind with
  | .const c => (db.edges.filter fun e => e.attr == el.attr && e.val == .const c).length
  | .lti n => (db.edges.filter fun e => e.attr == el.attr && e.val == .lti n).length
  | _ => (dedupFirst ((db.edges.filter (·.attr == el.attr)).map (·.lti))).length

def rowsFor (db : SMemDB) (el : CueEl) : List Edge :=
  db.edges.filter fun e => e.attr == el.attr && match el.kind with
    | .const c => e.val == .const c
    | .lti n => e.val == .lti n
    | _ => true

def hasFeature (db : SMemDB) (cand : Nat) (el : CueEl) : Bool :=
  (db.rowsFor el).any (·.lti == cand)

/-- The LTIs having a feature, as a hash set: `query` builds it once per cue element rather than
filtering the rows again for every candidate. -/
def featureSet (db : SMemDB) (el : CueEl) : Std.HashSet Nat :=
  Std.HashSet.ofList ((db.rowsFor el).map (·.lti))

theorem hasFeature_eq (db : SMemDB) (cand : Nat) (el : CueEl) :
    db.hasFeature cand el = (db.featureSet el).contains cand := by
  rw [Bool.eq_iff_iff]
  simp [hasFeature, featureSet, Std.HashSet.contains_ofList, List.any_eq_true]

/-- The numeric values of a candidate's augmentations with an attribute. -/
def numsOf (db : SMemDB) (cand : Nat) (attr : Sym) : List Float :=
  (db.edges.filter fun e => e.lti == cand && e.attr == attr).filterMap fun e =>
    match e.val with | .const c => c.num? | _ => none

/-- Row order for a query: decreasing activation, then decreasing row number (the order of
Soar's SQLite index scan). -/
def ordered (rows : List Edge) : List Edge :=
  (rows.toArray.qsort fun a b => a.act > b.act || (a.act == b.act && a.row > b.row)).toList

/-- libstdc++'s binary heap, as `std::priority_queue` uses it (`push_heap`, `pop_heap`), for a
comparison `lt` (`lt a b`: `a` has lower priority). Soar's queues of cue elements and of
activated LTIs are such heaps, so elements of equal priority leave them in libstdc++'s order. -/
def heapUp {α} [Inhabited α] (lt : α → α → Bool) (h : Array α) (hole0 top : Nat) (v : α) : Array α := Id.run do
  let mut h := h
  let mut hole := hole0
  for _ in [0:64] do
    if hole > top then
      let parent := (hole - 1) / 2
      if lt h[parent]! v then
        h := h.set! hole h[parent]!
        hole := parent
      else break
    else break
  return h.set! hole v

def heapPush {α} [Inhabited α] (lt : α → α → Bool) (h : Array α) (v : α) : Array α :=
  heapUp lt (h.push v) h.size 0 v

/-- `pop_heap` then `pop_back`: the top element and the rest. -/
def heapPop {α} [Inhabited α] (lt : α → α → Bool) (h : Array α) : Option (α × Array α) :=
  if h.size == 0 then none else
  let top := h[0]!
  if h.size == 1 then some (top, #[]) else
  let len := h.size - 1
  let v := h[len]!
  let h0 := h.set! len top
  let (h1, hole) := Id.run do
    let mut h := h0
    let mut hole := 0
    let mut second := 0
    for _ in [0:64] do
      if second < (len - 1) / 2 then
        second := 2 * (second + 1)
        if lt h[second]! h[second - 1]! then second := second - 1
        h := h.set! hole h[second]!
        hole := second
      else break
    if len % 2 == 0 && second == (len - 2) / 2 then
      second := 2 * (second + 1)
      h := h.set! hole h[second - 1]!
      hole := second - 1
    return (h, hole)
  some (top, (heapUp lt h1 hole 0 v).pop)

/-- Everything pushed, in the order it leaves the heap. -/
def heapOrder {α} [Inhabited α] (lt : α → α → Bool) (xs : List α) : List α :=
  let h := xs.foldl (heapPush lt) #[]
  let rec go : Nat → Array α → List α
    | 0, _ => []
    | f + 1, h => match heapPop lt h with
      | some (x, h') => x :: go f h'
      | none => []
  go (xs.length + 1) h

/-- Soar's `smem_compare_activated_lti`: the higher activation on top. -/
def actLess (x y : Float × Nat) : Bool := y.1 > x.1

/-- The cue elements in the order Soar 9.6.5 takes them from its priority queue of weighted
cue elements (`smem_prioritized_weighted_cue`, least weight on top), pushed in the order given:
positive elements, math elements, negative elements. -/
def weighted (db : SMemDB) (els : List CueEl) : List CueEl :=
  (heapOrder (fun (a b : Nat × CueEl) => a.1 > b.1) (els.map fun e => (db.weight e, e))).map (·.2)

/-- The order in which a query considers candidates (Soar 9.6.5 `process_query`): the rows of
the cue element in `ordered` order; the leading rows at `actMax` (LTIs with `thresh` or more
augmentations) go into a priority queue on the LTI's own activation, which is merged with the
remaining rows, a row being taken when its activation is higher than the queue's top. -/
def candOrder (db : SMemDB) (rows : List Edge) : List Nat :=
  let rows := ordered rows
  -- with spreading, the LTIs receiving spread are taken from the queue, on their spread
  -- activation, pushed in increasing order of their rows' activation and row number
  let fakeOf (l : Nat) : Option Fake := (alGet db.spread.fake l)
  let spRows := if db.spreading then (rows.filter fun e => (fakeOf e.lti).isSome).reverse else []
  let rows := if db.spreading then rows.filter fun e => (fakeOf e.lti).isNone else rows
  let big := rows.takeWhile (·.act == actMax)
  let rest := rows.drop big.length
  let q := big.foldl (fun q e => heapPush actLess q (((alGet db.ltiAct e.lti)).getD 0, e.lti)) #[]
  let q := spRows.foldl (fun q e => heapPush actLess q (((fakeOf e.lti).map (·.value)).getD 0, e.lti)) q
  let fuel := rows.length + spRows.length + 1
  let rec go : Nat → List Edge → Array (Float × Nat) → List Nat
    | 0, _, _ => []
    | f + 1, rs, q => match rs, heapPop actLess q with
      | [], none => []
      | r :: rs', none => r.lti :: go f rs' q
      | [], some (t, q') => t.2 :: go f [] q'
      | r :: rs', some (t, q') => if r.act > t.1 then r.lti :: go f rs' q else t.2 :: go f rs q'
  go fuel rest q

/-- State of a `max`/`min` condition during a query: committed and staged bounds, as in
Soar's `MathQueryMax`/`MathQueryMin`. -/
structure Bound where
  committed : Option Float := none
  staged    : Option Float := none

def bestAbove (isMax : Bool) (v : Float) : Option Float → Bool
  | none => true
  | some b => if isMax then v > b else v < b

def stage (isMax : Bool) (v : Float) : Option Float → Option Float
  | none => some v
  | some b => if (if isMax then v > b else v < b) then some v else some b

/-- A cue-based query ([Man] §6.4.2). Returns the retrieved LTI, if any.

The candidates are the rows of the most selective positive cue element, in row order
(`ordered`); the first candidate, not prohibited, that satisfies every other element is
retrieved — the most activated match. With a `max` or `min` condition (`full`) every
candidate is examined and the last one accepted is retrieved — also when that condition was
dropped because the store has no instance of its attribute (as in Soar 9.6.5, where the
search mode is set before the condition is checked). -/
def query (db : SMemDB) (els : List CueEl) (prohibit : List Nat) (full : Bool) : Option Nat :=
  let sorted := db.weighted els
  match sorted.findIdx? (·.pos) with
  | none => none
  | some ci =>
    let cs := sorted[ci]!
    let cands := db.candOrder (db.rowsFor cs)
    let feats : Array (Std.HashSet Nat) := (sorted.map db.featureSet).toArray
    -- walk the candidates; `bounds` holds max/min state per element index
    let step (acc : List Nat × Option Nat × List Nat × Bool × List (Nat × Bound)) (cand : Nat) :=
      let (matched, king, prohib, first, bounds) := acc
      if (!full && !matched.isEmpty) || prohib.contains cand then acc else
      -- check elements in order, stopping at the first failure
      let (good, bounds') := (sorted.zip (List.range sorted.length)).foldl
        (fun (st : Bool × List (Nat × Bound)) (el, i) =>
          let (ok, bs) := st
          if !ok then st else
          let isMath := match el.kind with | .math _ => true | _ => false
          if i == ci && !isMath then st else
          match el.kind with
          | .math m =>
            let vs := db.numsOf cand el.attr
            let b := (alGet bs i) |>.getD {}
            let (met, b') := vs.foldl (fun (r : Bool × Bound) v =>
              let (met, b) := r
              match m with
              | .less x => (met || v < x, b)
              | .greater x => (met || v > x, b)
              | .lessEq x => (met || v ≤ x, b)
              | .greaterEq x => (met || v ≥ x, b)
              | .max => if bestAbove true v b.committed then (true, { b with staged := stage true v b.staged }) else (met, b)
              | .min => if bestAbove false v b.committed then (true, { b with staged := stage false v b.staged }) else (met, b))
              (false, b)
            (met, (alPut bs i b'))
          | _ => (if el.pos then feats[i]!.contains cand else !feats[i]!.contains cand, bs))
        (true, bounds)
      if good then
        let bounds'' := bounds'.map fun (i, b) => (i, { b with committed := b.staged })
        (matched ++ [cand], some cand, prohib ++ [cand], true, bounds'')
      else if first then
        (matched, king, prohib, first, bounds'.map fun (i, b) => (i, { b with staged := b.committed }))
      else (matched, king, prohib, first, bounds')
    let (_, king, _, _, _) := cands.foldl step ([], none, prohibit, false, [])
    king

/-- The cue element whose rows a query walks: the most selective positive one. -/
def candElem (db : SMemDB) (els : List CueEl) : Option CueEl :=
  let sorted := db.weighted els
  (sorted.findIdx? (·.pos)).map (sorted[·]!)

/-- What a query does to activation before its search (Soar 9.6.5 `process_query`): each
prohibited LTI not yet prohibited is marked, dirty; with base-level activation and the naive
policy, every LTI among the candidates is recomputed, in order of LTI number. -/
def markProhibits (db : SMemDB) (ps : List Nat) : SMemDB :=
  ps.foldl (fun db p =>
    if db.prohibRows.contains p && !db.prohib.any (·.1 == p) then { db with prohib := db.prohib ++ [(p, true)] }
    else db) db

def naiveUpdate (db : SMemDB) (els : List CueEl) : SMemDB :=
  if db.baseLevel && db.baseUpdate == .naive then
    match db.candElem els with
    | some cs =>
      let ids := (((db.rowsFor cs).map (·.lti)).eraseDups.toArray.qsort (· < ·)).toList
      ids.foldl (fun d m => (d.activateNA m (d.edgesOf m).length).1) db
    | none => db
  else db

/-- The augmentations of an LTI, in row order. -/
def expand (db : SMemDB) (n : Nat) : List (Sym × LVal) :=
  (db.edgesOf n).map fun e => (e.attr, e.val)

/-! ## Spreading activation

Followed from Soar 9.6.5's `smem_activation.cpp` (`calc_spread`, `trajectory_construction`,
`child_spread`), `smem_query.cpp` and the working-memory hooks in `working_memory.cpp`
(2026-10-30). Order dependencies are reproduced: children are read in the order SQLite returns
them (by child, weight and row), the traversal's queue is libstdc++'s heap, maps are walked in
increasing key order, and sums are SQLite 3.40's left-to-right sums. -/

/-- Association lists kept in increasing key order (`std::map`). -/
def mset (m : List (Nat × Float)) (k : Nat) (v : Float) : List (Nat × Float) :=
  if m.any (·.1 == k) then m.map fun (a, b) => if a == k then (a, v) else (a, b)
  else (m.filter (·.1 < k)) ++ [(k, v)] ++ (m.filter (·.1 > k))

/-- An LTI's children for spreading (`web_val_child`): its LTI-valued augmentations, by child,
weight and row. -/
def spChildren (db : SMemDB) (x : Nat) : List (Nat × Float) :=
  let rows := db.edges.filterMap fun e => match e.val with
    | .lti c => if e.lti == x then some (c, e.weight, e.row) else none
    | _ => none
  (rows.toArray.qsort fun a b => a.1 < b.1 || (a.1 == b.1 && (a.2.1 < b.2.1 || (a.2.1 == b.2.1 && a.2.2 < b.2.2)))).toList.map
    fun (c, w, _) => (c, w)

/-- Apply the edge updates recorded for parent `p` (`child_spread`, done the first time `p` is
expanded after them): per decision cycle of the updates, each touched child's weight moves
toward 1 by a geometric series in the update factor, the others decay by the factor to the
number of touches, and the weights are renormalized. -/
def applyEdgeUpd (db : SMemDB) (p : Nat) : SMemDB :=
  match db.spread.edgeUpd.find? (·.1 == p) with
  | none => db
  | some (_, us) =>
    let u := db.spEdgeFactor
    let fin (old upd : List (Nat × Float)) (tt : Float) : List (Nat × Float) :=
      let (old, sum) := old.foldl (fun (acc : List (Nat × Float) × Float) (ch, w) =>
        let w' := match alGet upd ch with | none => Float.pow u tt * w | some d => w + d
        (acc.1 ++ [(ch, w')], acc.2 + w')) ([], 0)
      old.map fun (ch, w) => (ch, w / sum)
    let kids := db.spChildren p
    let (old, upd, tt, _, _) := us.foldl (fun (acc : List (Nat × Float) × List (Nat × Float) × Float × Bool × Nat) (ch, n, t) =>
      let (old, upd, tt, first, prevT) := acc
      let (old, upd, tt) := if t != prevT && !first then (fin old upd tt, [], 0) else (old, upd, tt)
      let (old, upd) := if first then kids.foldl (fun (o : List (Nat × Float) × List (Nat × Float)) (c, w) => (mset o.1 c w, mset o.2 c 0)) (old, upd) else (old, upd)
      let tt := tt + n
      let (old, upd) := (List.range (n.toUInt64.toNat + 1)).foldl (fun (o : List (Nat × Float) × List (Nat × Float)) k =>
        let (old, upd) := o
        let k := k + 1
        if k.toFloat ≤ n then
          let oldv := (alGet old ch).getD 0
          let old := if (alGet old ch).isSome then old else mset old ch 0
          match alGet upd ch with
          | some d => (old, mset upd ch (d + ((1 - oldv) * (1 - u)) * Float.pow u (k.toFloat - 1)))
          | none => (old, mset upd ch (0 + (1 - oldv) * (1 - u)))
        else (old, upd)) (old, upd)
      (old, upd, tt, false, t)) ([], [], 0, true, 0)
    let old := fin old upd tt
    let upd1 (e : Edge) : Edge := match e.val with
      | LVal.lti c => if e.lti == p then (match alGet old c with | some w => { e with weight := w } | none => e) else e
      | _ => e
    let db := { db with edges := db.edges.map upd1 }
    { db with spread := { db.spread with edgeUpd := db.spread.edgeUpd.filter (·.1 != p) } }

/-- A source's fingerprint (`trajectory_construction`): a best-first walk from the source along
edge weights, each step multiplied by the continue probability, recording up to
`spreading-limit` paths of at most `spreading-depth-limit` edges and the spread each LTI
reaches receives. -/
def construct (db : SMemDB) (s : Nat) : SMemDB :=
  let p := db.spContinue
  let b := db.spBaseline
  let dl := db.spDepth
  let lm := db.spLimit
  let lt := fun (x y : Float × List (Nat × Float)) => decide (y.1 > x.1)
  let rec walk : Nat → SMemDB × Array (Float × List (Nat × Float)) × Nat × List (Nat × Float) × List (List Nat) →
      SMemDB × Nat × List (Nat × Float) × List (List Nat)
    | 0, (db, _, c, sp, rows) => (db, c, sp, rows)
    | f + 1, (db, h, count, sp, rows) =>
      if h.size == 0 || count ≥ lm then (db, count, sp, rows) else
      let (prio, path) := h[0]!
      let cur := (path.getLast?.map (·.1)).getD s
      let db := db.applyEdgeUpd cur
      let kids := db.spChildren cur
      let ia := p * prio
      let h := ((heapPop lt h).map (·.2)).getD #[]
      let r := kids.foldl (fun (acc : Array (Float × List (Nat × Float)) × Nat × List (Nat × Float) × List (List Nat) × Bool)
          (c, w) =>
        let (h, count, sp, rows, stop) := acc
        if stop || !(count < lm && ia > b) then (h, count, sp, rows, true) else
        let good := if db.spLoop then !path.any (fun (i, x) => i == c && x == w) else c != 0 && !(w < b)
        if !good then acc else
        let newp := path ++ [(c, w)]
        let contrib := ia * w
        let sp := match alGet sp c with | some v => mset sp c (v + contrib) | none => mset sp c contrib
        let rows := rows ++ [(newp.map (·.1)).take 11]
        let count := count + 1
        let h := if newp.length < dl + 1 && count < lm && (p * ia) * w > b then heapPush lt h (ia * w, newp) else h
        (h, count, sp, rows, false)) (h, count, sp, rows, false)
      walk f (db, r.1, r.2.1, r.2.2.1, r.2.2.2.1)
  let w := walk (lm + 2) (db, #[(1.0, [(s, 1.0)])], 0, [], [])
  let db := w.1
  let sp := w.2.2.1
  let rows := w.2.2.2
  let rows := if rows.isEmpty then [([s], true)] else rows.map (·, true)
  { db with spread := { db.spread with traj := (alPut db.spread.traj s rows), like := (alPut db.spread.like s sp) } }

/-- The batched invalidations of a spread computation, through Soar's check statement, which
is never reset (`calc_spread`). -/
def spInvalidate (db : SMemDB) : SMemDB :=
  -- batched invalidations, through Soar's check statement, which is never reset
  let sp := db.spread
  let invSorted := (sp.invalid.toArray.qsort (· < ·)).toList
  let next := match sp.invCursor with
    | some k => invSorted.find? (· > k)
    | none => invSorted.head?
  let db := match next with
    | some k =>
      let db := invSorted.foldl invalidateFrom db
      { db with spread := { db.spread with invalid := [], invCursor := some k } }
    | none => { db with spread := { db.spread with invCursor := none } }
  db

/-- The sources added since the last computation, in increasing order. -/
def spAdds (db : SMemDB) : List Nat := (db.spread.adds.toArray.qsort (· < ·)).toList

/-- A source whose fingerprint is to be rebuilt loses its recorded numbers (`calc_spread`). -/
def spFpClear (db : SMemDB) (s : Nat) : SMemDB :=
  { db with spread := { db.spread with like := db.spread.like.filter (·.1 != s), trajNum := db.spread.trajNum.filter (·.1 != s) } }

/-- A rebuilt fingerprint's total (`calc_spread`). -/
def spFpNum (db : SMemDB) (s : Nat) : SMemDB :=
  let lk := ((alGet db.spread.like s)).getD []
  if lk.isEmpty then db else
  { db with spread := { db.spread with trajNum := (alPut db.spread.trajNum s (lk.foldl (fun a (_, v) => a + v) 0)) } }

/-- Give one added source its fingerprint: built anew if it has none or it was invalidated
(`calc_spread`). -/
def spFingerprint1 (db : SMemDB) (s : Nat) : SMemDB :=
  let rows := ((alGet db.spread.traj s)).getD []
  let wasInvalid := rows.any (!·.2)
  let noTraj := !rows.any (·.2)
  if wasInvalid || noTraj then
    spFpNum ((if wasInvalid then spFpClear db s else db).construct s) s
  else db

/-- Give each added source its fingerprint (`calc_spread`). -/
def spFingerprints (db : SMemDB) (adds : List Nat) : SMemDB := adds.foldl spFingerprint1 db

/-- One recorded path row of source `s` enters the context (`calc_spread`). -/
def spEnterRow (s : Nat) (nN : Float) (db : SMemDB) (x : Nat × Float) : SMemDB :=
  let r := x.1
  let n := x.2
  let sp := db.spread
  let cur := if sp.cur.any (·.1 == (s, r)) then sp.cur else sp.cur ++ [((s, r), (n, nN))]
  let rs := ((alGet sp.recips s)).getD []
  let recips := (alPut sp.recips s (if rs.contains r then rs else rs ++ [r]))
  let c := ((alGet sp.recipCnt r)).getD 0
  { db with spread := { sp with cur := cur, recips := recips, recipCnt := (alPut sp.recipCnt r (c + 1)) } }

/-- An added source enters the context (`calc_spread`). -/
def spEnter1 (db : SMemDB) (s : Nat) : SMemDB :=
  match db.spread.trajNum.find? (·.1 == s) with
  | none => db
  | some (_, nN) =>
    let lk := ((alGet db.spread.like s)).getD []
    lk.foldl (spEnterRow s nN) db

/-- The added sources enter the context (`calc_spread`). -/
def spEnter (db : SMemDB) (adds : List Nat) : SMemDB :=
  let db := adds.foldl spEnter1 db
  { db with spread := { db.spread with adds := [] } }

/-- An LTI no source reaches any more returns to its base (`calc_spread`). -/
def spMigrate (db : SMemDB) (r : Nat) (augs : Bool) : SMemDB :=
  let pb := ((db.spread.fake.find? (·.1 == r)).map (·.2.base)).getD 0
  let db := { db with spread := { db.spread with fake := db.spread.fake.filter (·.1 != r), spreadTo := db.spread.spreadTo.filter (· != r) }, ltiBase := (alPut db.ltiBase r (if pb == 0 then actLow else pb)), ltiAct := (alPut db.ltiAct r pb) }
  if augs then db.setActs r pb else db

/-- A removed source stops reaching one LTI (`calc_spread`). -/
def spRemoveReach (s : Nat) (db : SMemDB) (r : Nat) : SMemDB :=
  let c := ((db.spread.recipCnt.find? (fun (x : Nat × Nat) => x.1 == r)).map (fun (x : Nat × Nat) => x.2)).getD 0
  if c == 1 then
    let db := { db with spread := { db.spread with recipCnt := db.spread.recipCnt.filter (·.1 != r) } }
    if db.spread.spreadTo.contains r then spMigrate db r true else db
  else { db with spread := { db.spread with recipCnt := db.spread.recipCnt.map fun (k, v) => if k == r then (k, v - 1) else (k, v) } }

/-- A source leaves the context (`calc_spread`). -/
def spRemove1 (db : SMemDB) (s : Nat) : SMemDB :=
  let db := match db.spread.recips.find? (·.1 == s) with
    | none => db
    | some ((_ : Nat), (rs : List Nat)) =>
      let db := ((rs.toArray.qsort (· < ·)).toList).foldl (spRemoveReach s) db
      { db with spread := { db.spread with recips := db.spread.recips.filter (·.1 != s) } }
  { db with spread := { db.spread with cur := db.spread.cur.filter (·.1.1 != s) } }

/-- Removed sources leave the context (`calc_spread`). -/
def spRemove (db : SMemDB) : SMemDB :=
  let rems := (db.spread.rems.toArray.qsort (· < ·)).toList
  let db := rems.foldl spRemove1 db
  { db with spread := { db.spread with rems := [] } }

/-- One source's contribution to a candidate's spread (`calc_spread`). -/
def spCandRow (c : Nat) (off age : Float) (fOf : Nat → Float) (acc : SMemDB × Bool × Bool)
    (x : (Nat × Nat) × Float × Float) : SMemDB × Bool × Bool :=
  let s := x.1.1
  let n := x.2.1
  let nN := x.2.2
  let db := acc.1
  let stop := acc.2.1
  let updated := acc.2.2
      if stop || n == 0 then (db, true, updated) else
      let (prevBase, spr0) : Float × Float := if db.spread.spreadTo.contains c then
          (((db.spread.fake.find? (·.1 == c)).map (·.2.base)).getD 0, ((db.spread.fake.find? (·.1 == c)).map (·.2.spread)).getD 0)
        else (((alGet db.ltiBase c)).getD 0, 0)
      let spr0 := if updated then spr0 else 0
      let raw := fOf s * (n / nN)
      let add := if raw > off then raw else off
      let spr := if spr0 == 0 then add else add + spr0
      let m := Float.log spr - Float.log off
      let nb := if prevBase == actLow || prevBase == 0 then age else prevBase
      let stored := if prevBase == 0 then actLow else prevBase
      let f : Fake := { base := stored, spread := spr, value := m + nb }
      let sp := db.spread
      ({ db with spread := { sp with spreadTo := if sp.spreadTo.contains c then sp.spreadTo else sp.spreadTo ++ [c], fake := (alPut sp.fake c f) } }, false, true)

/-- A candidate's spread, from the sources reaching it (`calc_spread`). -/
def spCand1 (off age : Float) (fOf : Nat → Float) (db : SMemDB) (c : Nat) : SMemDB :=
  let db := if db.spread.spreadTo.contains c then spMigrate db c false else db
  let rows := ((db.spread.cur.filter (·.1.2 == c)).toArray.qsort (fun a b => a.1.1 < b.1.1)).toList
  (rows.foldl (spCandRow c off age fOf) (db, false, false)).1

/-- The candidates' spread, from the sources reaching each (`calc_spread`). `pre` gives a
source's working-memory activation sum when `spreading-wma-source` uses it. -/
def spCands (db : SMemDB) (cands : List Nat) (pre : Nat → Option Float) : SMemDB :=
  let off := db.spOffset
  let age := db.ageBase db.clock
  let fOf (s : Nat) : Float := match pre s with
    | some x => if x == 0 then (let y := Float.pow (db.clock + db.baseOffset).toFloat (-db.baseDecay); y / (1 + y)) else x / (1 + x)
    | none => let y := Float.pow (db.clock + db.baseOffset).toFloat (-db.baseDecay); y / (1 + y)
  let cands := (cands.eraseDups.toArray.qsort (· < ·)).toList
  cands.foldl (spCand1 off age fOf) db

/-- Spread computation for a query (`calc_spread`): apply the pending invalidations; give each
source added since the last computation its fingerprint (built anew if it has none or it was
invalidated) and enter it into the context; take out the sources removed; then recompute each
candidate's spread from the sources reaching it, in increasing order of source. `pre` gives a
source's working-memory activation sum when `spreading-wma-source` uses it. -/
def calcSpread (db : SMemDB) (cands : List Nat) (pre : Nat → Option Float) : SMemDB :=
  let db := db.spInvalidate
  let adds := db.spAdds
  let db := db.spFingerprints adds
  let db := db.spEnter adds
  let db := db.spRemove
  db.spCands cands pre

/-- Before a query's search, with spreading on (`process_query`): the rows of the first
positive cue element, by activation, up to 400; with two or more, spread is computed, for the
LTIs of those rows, or with 400, for the LTIs in context that match that element. -/
def spreadPrep (db : SMemDB) (els : List CueEl) (pre : Nat → Option Float) : SMemDB :=
  if !db.spreading then db else
  match db.candElem els with
  | none => db
  | some cs =>
    let rows := (ordered (db.rowsFor cs)).take 400
    if rows.length ≥ 400 then
      db.calcSpread ((db.spread.cur.map (·.1.2)).filter (db.hasFeature · cs)) pre
    else if rows.length ≥ 2 then db.calcSpread (rows.map (·.lti)) pre
    else db

/-- The working-memory hooks (`do_buffered_wm_changes`): `now` lists every element in working
memory by timetag with its identifier, and `ltiOf` gives the LTI an identifier stands for now
(0 if none). Elements that
arrived count for the LTI their identifier stands for when they arrive, and elements that left
for the LTI it stands for when they leave, as in Soar (so an identifier stored after its
elements arrived becomes a source only when a further element arrives). A source is added when
its count leaves 0 and removed when it returns to 0; arrivals are processed before departures,
as Soar processes one set of changes. -/
def spSync (db : SMemDB) (now : List (Nat × Nat)) (ltiOf : Nat → Nat) : SMemDB :=
  let sp := db.spread
  let nowS := (now.toArray.qsort (fun a b => a.1 < b.1)).toList
  -- merge of two lists sorted by timetag: (arrived, departed)
  let rec diff : Nat → List (Nat × Nat) → List (Nat × Nat) → List (Nat × Nat) × List (Nat × Nat)
    | 0, _, _ => ([], [])
    | _ + 1, [], ys => ([], ys)
    | _ + 1, xs, [] => (xs, [])
    | f + 1, x :: xs, y :: ys =>
      if x.1 == y.1 then diff f xs ys
      else if x.1 < y.1 then let r := diff f xs (y :: ys); (x :: r.1, r.2)
      else let r := diff f (x :: xs) ys; (r.1, y :: r.2)
  let (added, removed) := diff (nowS.length + sp.snap.length + 1) nowS sp.snap
  if added.isEmpty && removed.isEmpty then db else
  let cnt (sp : Spread) (l : Nat) : Nat := ((alGet sp.inWm l)).getD 0
  let sp := added.foldl (fun sp (_, i) =>
    let l := ltiOf i
    if l == 0 then sp else
    let c := cnt sp l
    if c == 0 then
      { sp with inWm := sp.inWm ++ [(l, 1)], adds := if sp.adds.contains l then sp.adds else sp.adds ++ [l],
                rems := sp.rems.filter (· != l) }
    else { sp with inWm := sp.inWm.map fun (k, v) => if k == l then (k, v + 1) else (k, v) }) sp
  let sp := removed.foldl (fun sp (_, i) =>
    let l := ltiOf i
    if l == 0 then sp else
    let c := cnt sp l
    if c == 0 then sp
    else if c == 1 then
      let sp := { sp with inWm := sp.inWm.filter (·.1 != l) }
      if sp.adds.contains l then { sp with adds := sp.adds.filter (· != l) }
      else { sp with rems := if sp.rems.contains l then sp.rems else sp.rems ++ [l] }
    else { sp with inWm := sp.inWm.map fun (k, v) => if k == l then (k, v - 1) else (k, v) }) sp
  { db with spread := { sp with snap := nowS } }

end SMemDB

/-! ## Adding knowledge from the command line ([Man] §6.3.3: `smem --add`) -/

/-- A reference in an `smem --add` clause: a variable, a numbered LTI `@n`, or a constant. -/
inductive AddRef where
  | var (v : String)
  | lti (n : Nat)
  | alias (a : String)
  | const (c : Sym)
  deriving DecidableEq, Repr

/-- One clause `(<id> ^attr v₁ v₂ … ^a.b v …)`: its identifier and its augmentations as
(parent, attribute, value) triples, in textual order; a dot path `^a.b v` contributes
`(id ^a <a#k>)` and `(<a#k> ^b v)` with a new intermediate variable `<a#k>`. -/
structure AddClause where
  id   : AddRef
  augs : List (AddRef × Sym × AddRef)
  deriving Repr

/-- Process `smem --add` clauses as Soar 9.6.5 does (`CLI_add`): clause by clause, new
variables become new LTIs in order of appearance (the clause's identifier first), and the
augmentations are added to each LTI's existing ones, without activation (the clause's
identifier first, then intermediate objects).

> "Unlike agent storage, declarative storage is automatically recursive." — [Man] §6.3.3 -/
def SMemDB.addClauses (db : SMemDB) (cls : List AddClause) : SMemDB :=
  let r := cls.foldl (fun (acc : SMemDB × List (String × Nat)) cl =>
    let (db, names) := acc
    let refs := cl.id :: cl.augs.flatMap (fun (p, _, v) => [p, v])
    -- aliases are resolved while the clause is read, new variables after it (as in Soar)
    let db := refs.foldl (fun (db : SMemDB) r =>
      match r with
      | .alias a => if db.aliases.any (·.1 == a) then db else
          let (db, n) := db.newLti
          { db with aliases := db.aliases ++ [(a, n)] }
      | _ => db) db
    let (db, names) := refs.foldl (fun (acc : SMemDB × List (String × Nat)) r =>
      let (db, names) := acc
      match r with
      | .var v => if names.any (·.1 == v) then acc else
          let (db, n) := db.newLti
          (db, names ++ [(v, n)])
      | .lti n => (db.ensureLti n, names)
      | _ => acc) (db, names)
    let resolve (r : AddRef) : Option LVal := match r with
      | .var v => (names.find? (·.1 == v)).map (fun p => LVal.lti p.2)
      | .lti n => some (.lti n)
      | .alias a => (db.aliases.find? (·.1 == a)).map (fun p => LVal.lti p.2)
      | .const c => some (.const c)
    let parents := (cl.augs.map (·.1)).eraseDups
    let db := parents.foldl (fun (db : SMemDB) par =>
      match resolve par with
      | some (.lti n) =>
        let augs := (cl.augs.filter (·.1 == par)).filterMap fun (_, a, v) => (resolve v).map (a, ·)
        db.write n augs false false
      | _ => db) db
    (db, names)) (db, [])
  r.1

/-! ## Removing knowledge and querying from the command line (`smem --remove`, `smem --query`) -/

/-- A value in an `smem --remove` or `smem --query` clause. -/
inductive CliVal where
  | any
  | const (c : Sym)
  | lti (n : Nat)
  | alias (a : String)
  deriving DecidableEq, Repr

/-- A command-line operation on the store, in the order of the source file. -/
inductive SMemOp where
  | add (cls : List AddClause)
  /-- `smem --remove {(@n ^a v … ^b …)}`: the values given, or every value of an attribute
  given without values; with no attributes, all of the LTI's augmentations. -/
  | remove (lti : CliVal) (attrs : List (Sym × List CliVal))
  /-- `smem --query {(<c> ^a v …)}`: the cue elements (attribute, value, positive). -/
  | query (els : List (Sym × CliVal × Bool))
  /-- `smem --clear`: the store emptied (`SMem_Manager::clear`), if it is open. -/
  | clear
  /-- `smem --backup F`: a copy of the store written to `F` (`SMem_Manager::backup_db`), if it
  is open; written by the program, the store is unchanged. -/
  | backup (file : String)
  /-- `smem --init`: with a file database, closing and reopening it (`SMem_Manager::reinit`).
  Before the agent runs this changes nothing the model holds: reopening keeps the store and
  empties only what a run fills (the current spread and the maps of working memory). -/
  | init
  deriving Repr

namespace SMemDB

def cliLti (db : SMemDB) : CliVal → Option Nat
  | .lti n => some n
  | .alias a => (alGet db.aliases a)
  | _ => none

/-- `smem --remove` as Soar 9.6.5 does it (`CLI_remove`): the LTI's augmentations are read, the
named values or attributes taken out (a value that is not there is reported and skipped; an
attribute the agent has never seen is an error, which leaves the store unchanged), and the LTI
is written again with what remains, without activation (`LTM_to_DB`). -/
def cliRemove (db : SMemDB) (r : CliVal) (attrs : List (Sym × List CliVal)) : SMemDB :=
  match db.cliLti r with
  | none => db
  | some n =>
    if !db.ltis.contains n then db else
    let r := attrs.foldl (fun (acc : Option (List (Sym × LVal))) (a, vs) => acc.bind fun ch =>
        if !db.syms.contains a && !ch.any (·.1 == a) then none
        else if vs.isEmpty then some (ch.filter (·.1 != a))
        else some (vs.foldl (fun ch v => match v with
          | .const c => ch.erase (a, .const c)
          | v => match db.cliLti v with
            | some m => ch.erase (a, .lti m)
            | none => ch) ch)) (some (if attrs.isEmpty then [] else db.expand n))
    match r with
    | some ch => db.write n ch true false
    | none => db

/-- The effect of `smem --query` on the store (`CLI_query`: a search with no retrieval and no
activation): only the naive base-level policy's recomputation of the candidates. The model does
not print the LTIs found. -/
def cliQuery (db : SMemDB) (els : List (Sym × CliVal × Bool)) : SMemDB :=
  let known (x : Sym) : Bool := db.syms.contains x
  let el (a : Sym) (v : CliVal) (pos : Bool) : Option CueEl := match v with
    | .any => some { attr := a, kind := .any, pos }
    | .const c => some { attr := a, kind := .const c, pos }
    | v => (db.cliLti v).map fun m => { attr := a, kind := .lti m, pos }
  let posEls := (els.filter (·.2.2)).map fun (a, v, _) => (el a v true).filter fun e => known a && db.weight e > 0
  if posEls.isEmpty || posEls.any (·.isNone) then db else
  let negEls := (els.filter (!·.2.2)).filterMap fun (a, v, _) => (el a v false).filter fun e =>
    known a && (match e.kind with | .const c => known c | _ => true) && db.weight e > 0
  db.naiveUpdate (posEls.filterMap id ++ negEls)

/-- The store emptied by `smem --clear` (Soar 9.6.5 `SMem_Manager::clear`: closing the database
and opening it with `append` off), with the same settings; the parents marked for invalidation
remain (`reopenEmpty`, kernel defect 29). -/
def clearStore (db : SMemDB) : SMemDB :=
  { db with edges := [], ltis := [], counter := 0, clock := 1, syms := [], ltiAct := [],
            accesses := [], aliases := [], accTimes := [], history := [], prohib := [],
            prohibRows := [], ltiBase := [], spread := { invalid := db.spread.invalid } }

/-- A command-line operation on the store. Soar opens the store at the first `--add`, `--remove`
or `--query` (`attach`); `--clear` and `--backup` act only on an open store, so the parser keeps
them only after one of those. -/
def runOp (db : SMemDB) : SMemOp → SMemDB
  | .add cls => db.addClauses cls
  | .remove r attrs => db.cliRemove r attrs
  | .query els => db.cliQuery els
  | .clear => db.clearStore
  | .backup _ => db
  | .init => db


/-! ## A store kept in a file between agents -/

/-- The store a new agent finds in an existing file database with `append` on (Soar 9.6.5
`SMem_Manager::init_db`, `reset_id_counters`, `close`/`store_globals_in_db`). `stored` is the
store as the earlier agent left it and `fresh` the new agent's empty store with its own settings.
What Soar keeps in the database is kept: the long-term identifiers and their augmentations, with
their row order, activations, access counts and times, histories and prohibitions, the symbol
table, aliases, the activation clock (`smem_max_cycle`), and the spreading tables of paths and
their counts (`smem_likelihood_trajectories`, `smem_likelihoods`, `smem_trajectory_num`,
`smem_invalid_parents`). `init_db` empties `smem_current_spread` and
`smem_current_spread_activations`. The stored `thresh` and `activation-mode` replace the new
agent's settings. Everything Soar keeps only in memory starts empty: the counts of elements in
working memory (`smem_in_wmem`), the context changes, the recipients' maps
(`smem_recipients_of_source`, `smem_recipient`, `smem_spreaded_to`) and the edge updates. -/
def reopen (stored fresh : SMemDB) : SMemDB :=
  { fresh with
    edges := stored.edges, ltis := stored.ltis, counter := stored.counter, clock := stored.clock,
    syms := stored.syms, ltiAct := stored.ltiAct, accesses := stored.accesses,
    aliases := stored.aliases, accTimes := stored.accTimes, history := stored.history,
    prohib := stored.prohib, prohibRows := stored.prohibRows, ltiBase := stored.ltiBase,
    thresh := stored.thresh, frequency := stored.frequency, baseLevel := stored.baseLevel,
    spread := { traj := stored.spread.traj, like := stored.spread.like,
                trajNum := stored.spread.trajNum, invalid := stored.spread.invalid } }

/-- The store a new agent finds in an existing file database with `append` off (Soar 9.6.5
`smem_statement_container::drop_tables`): empty, except that `drop_tables` does not drop
`smem_invalid_parents` (nor `smem_constants_store` and `smem_to_delete`, which hold nothing the
model needs), so the parents marked for invalidation remain (kernel defect 29). -/
def reopenEmpty (stored fresh : SMemDB) : SMemDB :=
  { fresh with spread := { fresh.spread with invalid := stored.spread.invalid } }

/-- Reopening keeps the long-term store: the same identifiers and augmentations. -/
theorem reopen_store (stored fresh : SMemDB) :
    (reopen stored fresh).edges = stored.edges ∧ (reopen stored fresh).ltis = stored.ltis := ⟨rfl, rfl⟩

end SMemDB

end Soar
