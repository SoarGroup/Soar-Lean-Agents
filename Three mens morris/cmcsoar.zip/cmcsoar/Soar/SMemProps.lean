import Soar.Cycle
/-!
# Soar 9.6 — properties of semantic memory

* Retrieval (cue-based or not) changes no stored knowledge: only activation.
* Storing an LTI changes no other LTI's augmentations.
* Semantic memory's processing never changes architecture-created elements or the goal stack.
-/

namespace Soar

/-- The stored content of an augmentation, without its activation. -/
def Edge.content (e : Edge) : Nat × Nat × Sym × LVal := (e.row, e.lti, e.attr, e.val)

def SMemDB.content (db : SMemDB) : List (Nat × Nat × Sym × LVal) := db.edges.map Edge.content

/-- Same stored knowledge: the same augmentations (rows, LTIs, attributes, values) and LTIs. -/
def SMemDB.Keeps (a b : SMemDB) : Prop := a.content = b.content ∧ a.ltis = b.ltis

theorem SMemDB.Keeps.refl (a : SMemDB) : a.Keeps a := ⟨rfl, rfl⟩

theorem SMemDB.Keeps.trans {a b c : SMemDB} (h : a.Keeps b) (h' : b.Keeps c) : a.Keeps c :=
  ⟨h.1.trans h'.1, h.2.trans h'.2⟩

theorem SMemDB.keeps_fold {α : Type} (f : SMemDB → α → SMemDB) (hf : ∀ (d : SMemDB) (a : α), d.Keeps (f d a))
    (l : List α) (d : SMemDB) : d.Keeps (l.foldl f d) :=
  foldl_rel SMemDB.Keeps (fun _ _ _ => SMemDB.Keeps.trans) SMemDB.Keeps.refl f hf l d

theorem SMemDB.keeps_edges_map (d : SMemDB) (f : Edge → Edge) (hf : ∀ e, (f e).content = e.content) :
    d.Keeps { d with edges := d.edges.map f } := by
  refine ⟨?_, rfl⟩
  unfold SMemDB.content
  simp only [List.map_map]
  congr 1
  funext e
  exact (hf e).symm

theorem SMemDB.Keeps.of_fields {d b r : SMemDB} (h : d.Keeps b) (he : r.edges = b.edges)
    (hl : r.ltis = b.ltis) : d.Keeps r := by
  refine ⟨?_, ?_⟩
  · unfold SMemDB.content; rw [he]; exact h.1
  · rw [hl]; exact h.2

theorem SMemDB.setActs_keeps (d : SMemDB) (n : Nat) (a : Float) : d.Keeps (d.setActs n a) :=
  SMemDB.keeps_edges_map d _ (fun e => by split <;> rfl)

theorem map_act_content (es : List Edge) (n : Nat) (a : Float) :
    (es.map fun e => if (e.lti == n) = true then { e with act := a } else e).map Edge.content =
      es.map Edge.content := by
  induction es with
  | nil => rfl
  | cons e es ih => simp only [List.map_cons, ih]; split <;> rfl

theorem SMemDB.setActs_content (db : SMemDB) (n : Nat) (a : Float) :
    (db.setActs n a).content = db.content ∧ (db.setActs n a).ltis = db.ltis := by
  unfold SMemDB.setActs SMemDB.content
  exact ⟨map_act_content _ _ _, rfl⟩

theorem foldl_setActs_content (l : List (Nat × Float)) (d : SMemDB) :
    (l.foldl (fun db (x : Nat × Float) => db.setActs x.1 x.2) d).content = d.content ∧
    (l.foldl (fun db (x : Nat × Float) => db.setActs x.1 x.2) d).ltis = d.ltis :=
  foldl_rel (fun a b : SMemDB => b.content = a.content ∧ b.ltis = a.ltis)
    (fun _ _ _ h1 h2 => ⟨h2.1.trans h1.1, h2.2.trans h1.2⟩) (fun _ => ⟨rfl, rfl⟩) _
    (fun db x => SMemDB.setActs_content db x.1 x.2) l d

theorem SMemDB.setHist_keeps (db : SMemDB) (n : Nat) (h : List Nat) : db.Keeps (db.setHist n h) := ⟨rfl, rfl⟩

theorem SMemDB.histAdd_keeps (db : SMemDB) (n t : Nat) : db.Keeps (db.histAdd n t) := by
  unfold SMemDB.histAdd; split <;> exact ⟨rfl, rfl⟩

theorem SMemDB.histPush_keeps (db : SMemDB) (n t : Nat) : db.Keeps (db.histPush n t) := by
  unfold SMemDB.histPush; split <;> exact ⟨rfl, rfl⟩

theorem SMemDB.histRemove_keeps (db : SMemDB) (n : Nat) : db.Keeps (db.histRemove n) := by
  unfold SMemDB.histRemove; split <;> exact ⟨rfl, rfl⟩

theorem SMemDB.finishHist_keeps (db : SMemDB) (n timeNow prev1 : Nat) (access prohibited : Bool) :
    db.Keeps (db.finishHist n timeNow prev1 access prohibited) := by
  unfold SMemDB.finishHist
  split
  · split
    · exact SMemDB.histAdd_keeps _ _ _
    · exact SMemDB.histPush_keeps _ _ _
  · exact ⟨rfl, rfl⟩

theorem SMemDB.finishTail_keeps (db : SMemDB) (n : Nat) (v : Float) (numEdges : Nat) :
    db.Keeps (db.finishTail n v numEdges).1 := by
  unfold SMemDB.finishTail
  dsimp only
  by_cases hs : (db.spreading && db.spread.spreadTo.contains n) = true
  · simp only [hs, ↓reduceIte]; exact ⟨rfl, rfl⟩
  · simp only [hs, ↓reduceIte]
    refine SMemDB.Keeps.trans ?_ (SMemDB.setActs_keeps _ _ _)
    exact ⟨rfl, rfl⟩

theorem SMemDB.finish_keeps (db : SMemDB) (n timeNow prevN prevT prev1 : Nat) (access prohibited : Bool)
    (numEdges : Nat) : db.Keeps (db.finish n timeNow prevN prevT prev1 access prohibited numEdges).1 := by
  unfold SMemDB.finish
  dsimp only
  refine SMemDB.Keeps.trans ?_ (SMemDB.finishTail_keeps _ _ _ _)
  exact SMemDB.Keeps.trans (b := db.setAcc n (prevN + if access = true then 1 else 0)
      (if access = true then timeNow else prevT)
      (if (prevN == 0) = true then if access = true then timeNow else 0 else prev1)) ⟨rfl, rfl⟩
    (SMemDB.finishHist_keeps _ _ _ _ _ _)

theorem SMemDB.activateNA_keeps (db : SMemDB) (n numEdges : Nat) : db.Keeps (db.activateNA n numEdges).1 := by
  unfold SMemDB.activateNA
  dsimp only
  rcases hp : db.prohibOf n with _ | b
  · simp only [hp]
    exact SMemDB.finish_keeps _ _ _ _ _ _ _ _ _
  · cases b
    · simp only [hp]
      exact SMemDB.finish_keeps _ _ _ _ _ _ _ _ _
    · simp only [hp]
      refine SMemDB.Keeps.trans ?_ (SMemDB.finish_keeps _ _ _ _ _ _ _ _ _)
      exact SMemDB.histRemove_keeps _ _

theorem SMemDB.refreshIncr_keeps (db : SMemDB) (timeNow : Nat) : db.Keeps (db.refreshIncr timeNow) := by
  unfold SMemDB.refreshIncr
  split
  · refine SMemDB.keeps_fold _ ?_ _ db
    intro d b
    split
    · exact SMemDB.keeps_fold _ (fun d m => SMemDB.activateNA_keeps d m _) _ d
    · exact ⟨rfl, rfl⟩
  · exact ⟨rfl, rfl⟩

theorem SMemDB.activateA_keeps (db : SMemDB) (n numEdges : Nat) : db.Keeps (db.activateA n numEdges).1 := by
  unfold SMemDB.activateA
  dsimp only
  refine SMemDB.Keeps.trans ?_ (SMemDB.finish_keeps _ _ _ _ _ _ _ _ _)
  refine SMemDB.Keeps.trans ?_ (SMemDB.refreshIncr_keeps _ _)
  rcases hp : db.prohibOf n with _ | b
  · exact ⟨rfl, rfl⟩
  · cases b
    · exact ⟨rfl, rfl⟩
    · exact SMemDB.Keeps.trans (SMemDB.histRemove_keeps _ _) ⟨rfl, rfl⟩

theorem SMemDB.activate_content (db : SMemDB) (n : Nat) (a : Bool) (k : Nat) :
    (db.activate n a k).1.content = db.content ∧ (db.activate n a k).1.ltis = db.ltis := by
  unfold SMemDB.activate
  split
  · exact ⟨(SMemDB.activateA_keeps db n k).1.symm, (SMemDB.activateA_keeps db n k).2.symm⟩
  · exact ⟨(SMemDB.activateNA_keeps db n k).1.symm, (SMemDB.activateNA_keeps db n k).2.symm⟩

theorem SMemDB.markProhibits_content (db : SMemDB) (ps : List Nat) :
    (db.markProhibits ps).content = db.content ∧ (db.markProhibits ps).ltis = db.ltis := by
  unfold SMemDB.markProhibits
  induction ps generalizing db with
  | nil => exact ⟨rfl, rfl⟩
  | cons p ps ih =>
    simp only [List.foldl_cons]
    have step : ∀ d : SMemDB, d.content = db.content → d.ltis = db.ltis →
        ((ps.foldl (fun db p => if db.prohibRows.contains p && !db.prohib.any (·.1 == p) then
          { db with prohib := db.prohib ++ [(p, true)] } else db) d).content = db.content ∧
         (ps.foldl (fun db p => if db.prohibRows.contains p && !db.prohib.any (·.1 == p) then
          { db with prohib := db.prohib ++ [(p, true)] } else db) d).ltis = db.ltis) := by
      intro d h1 h2
      obtain ⟨h3, h4⟩ := ih d
      exact ⟨h3.trans h1, h4.trans h2⟩
    apply step <;> split <;> rfl

theorem SMemDB.naiveUpdate_content (db : SMemDB) (els : List CueEl) :
    (db.naiveUpdate els).content = db.content ∧ (db.naiveUpdate els).ltis = db.ltis := by
  unfold SMemDB.naiveUpdate
  split
  · split
    · exact ⟨(SMemDB.keeps_fold _ (fun d m => SMemDB.activateNA_keeps d m _) _ db).1.symm,
        (SMemDB.keeps_fold _ (fun d m => SMemDB.activateNA_keeps d m _) _ db).2.symm⟩
    · exact ⟨rfl, rfl⟩
  · exact ⟨rfl, rfl⟩

theorem SMemDB.spInvalidate_keeps (d : SMemDB) : d.Keeps d.spInvalidate := by
  unfold SMemDB.spInvalidate
  simp only []
  split
  · exact (SMemDB.keeps_fold invalidateFrom (fun _ _ => ⟨rfl, rfl⟩) _ d).trans ⟨rfl, rfl⟩
  · exact ⟨rfl, rfl⟩

theorem SMemDB.spMigrate_keeps (d : SMemDB) (r : Nat) (augs : Bool) : d.Keeps (d.spMigrate r augs) := by
  unfold SMemDB.spMigrate
  simp only []
  split
  · exact SMemDB.Keeps.trans ⟨rfl, rfl⟩ (SMemDB.setActs_keeps _ _ _)
  · exact ⟨rfl, rfl⟩

theorem SMemDB.applyEdgeUpd_keeps (d : SMemDB) (p : Nat) : d.Keeps (d.applyEdgeUpd p) := by
  unfold SMemDB.applyEdgeUpd
  split
  · exact ⟨rfl, rfl⟩
  · refine ⟨?_, rfl⟩
    simp only [SMemDB.content, List.map_map]
    congr 1
    funext e
    simp only [Function.comp]
    repeat' split
    all_goals rfl

theorem SMemDB.construct_walk_keeps (lt : Float × List (Nat × Float) → Float × List (Nat × Float) → Bool)
    (s : Nat) (p b : Float) (dl lm : Nat) : ∀ (f : Nat) (st : SMemDB × Array (Float × List (Nat × Float)) × Nat × List (Nat × Float) × List (List Nat)),
    st.1.Keeps (SMemDB.construct.walk s p b dl lm lt f st).1 := by
  intro f
  induction f with
  | zero => intro st; exact ⟨rfl, rfl⟩
  | succ f ih =>
    intro st
    obtain ⟨d, h, count, sp, rows⟩ := st
    unfold SMemDB.construct.walk
    split
    · exact ⟨rfl, rfl⟩
    · split
      dsimp only
      refine SMemDB.Keeps.trans ?_ (ih _)
      exact SMemDB.applyEdgeUpd_keeps d _

theorem SMemDB.construct_keeps (d : SMemDB) (s : Nat) : d.Keeps (d.construct s) := by
  unfold SMemDB.construct
  dsimp only
  exact SMemDB.Keeps.trans (b := (SMemDB.construct.walk s d.spContinue d.spBaseline d.spDepth d.spLimit
      (fun x y => decide (y.fst > x.fst)) (d.spLimit + 2) (d, #[(1.0, [(s, 1.0)])], 0, [], [])).1)
    (SMemDB.construct_walk_keeps _ s d.spContinue d.spBaseline d.spDepth d.spLimit (d.spLimit + 2)
      (d, #[(1.0, [(s, 1.0)])], 0, [], [])) ⟨rfl, rfl⟩

theorem SMemDB.spFpNum_keeps (d : SMemDB) (s : Nat) : d.Keeps (d.spFpNum s) := by
  unfold SMemDB.spFpNum
  dsimp only
  split_rfl

theorem SMemDB.spFingerprint1_keeps (d : SMemDB) (s : Nat) : d.Keeps (d.spFingerprint1 s) := by
  unfold SMemDB.spFingerprint1
  dsimp only
  split
  · refine SMemDB.Keeps.trans ?_ ((SMemDB.construct_keeps _ s).trans (SMemDB.spFpNum_keeps _ s))
    split_rfl
  · exact ⟨rfl, rfl⟩

theorem SMemDB.spFingerprints_keeps (d : SMemDB) (adds : List Nat) : d.Keeps (d.spFingerprints adds) :=
  SMemDB.keeps_fold SMemDB.spFingerprint1 SMemDB.spFingerprint1_keeps adds d

theorem SMemDB.spEnter1_keeps (d : SMemDB) (s : Nat) : d.Keeps (d.spEnter1 s) := by
  unfold SMemDB.spEnter1
  split
  · exact ⟨rfl, rfl⟩
  · exact SMemDB.keeps_fold (SMemDB.spEnterRow _ _) (fun _ _ => ⟨rfl, rfl⟩) _ _

theorem SMemDB.spEnter_keeps (d : SMemDB) (adds : List Nat) : d.Keeps (d.spEnter adds) := by
  unfold SMemDB.spEnter
  exact SMemDB.Keeps.of_fields (SMemDB.keeps_fold SMemDB.spEnter1 SMemDB.spEnter1_keeps adds d) rfl rfl

theorem SMemDB.spRemoveReach_keeps (s : Nat) (d : SMemDB) (r : Nat) : d.Keeps (SMemDB.spRemoveReach s d r) := by
  unfold SMemDB.spRemoveReach
  dsimp only
  split
  · split
    · refine SMemDB.Keeps.trans ?_ (SMemDB.spMigrate_keeps _ r true)
      exact ⟨rfl, rfl⟩
    · exact ⟨rfl, rfl⟩
  · exact ⟨rfl, rfl⟩

theorem SMemDB.spRemove1_keeps (d : SMemDB) (s : Nat) : d.Keeps (d.spRemove1 s) := by
  unfold SMemDB.spRemove1
  dsimp only
  refine SMemDB.Keeps.of_fields ?_ rfl rfl
  split
  · exact ⟨rfl, rfl⟩
  · exact SMemDB.Keeps.of_fields (SMemDB.keeps_fold (SMemDB.spRemoveReach s) (SMemDB.spRemoveReach_keeps s) _ d) rfl rfl

theorem SMemDB.spRemove_keeps (d : SMemDB) : d.Keeps d.spRemove := by
  unfold SMemDB.spRemove
  dsimp only
  exact SMemDB.Keeps.of_fields (SMemDB.keeps_fold SMemDB.spRemove1 SMemDB.spRemove1_keeps _ d) rfl rfl

theorem SMemDB.spCandRow_keeps (c : Nat) (off age : Float) (fOf : Nat → Float) (acc : SMemDB × Bool × Bool)
    (x : (Nat × Nat) × Float × Float) : acc.1.Keeps (SMemDB.spCandRow c off age fOf acc x).1 := by
  unfold SMemDB.spCandRow
  dsimp only
  split
  · exact ⟨rfl, rfl⟩
  · exact ⟨rfl, rfl⟩

theorem SMemDB.spCand1_keeps (off age : Float) (fOf : Nat → Float) (d : SMemDB) (c : Nat) :
    d.Keeps (SMemDB.spCand1 off age fOf d c) := by
  unfold SMemDB.spCand1
  dsimp only
  have key := foldl_rel (fun (a b : SMemDB × Bool × Bool) => a.1.Keeps b.1)
    (fun _ _ _ h h' => SMemDB.Keeps.trans h h') (fun a => SMemDB.Keeps.refl _)
    (SMemDB.spCandRow c off age fOf) (fun acc x => SMemDB.spCandRow_keeps c off age fOf acc x)
  refine SMemDB.Keeps.trans ?_ (key _ _)
  split <;> first | exact ⟨rfl, rfl⟩ | exact SMemDB.spMigrate_keeps _ _ _

theorem SMemDB.spCands_keeps (d : SMemDB) (cands : List Nat) (pre : Nat → Option Float) :
    d.Keeps (d.spCands cands pre) := by
  unfold SMemDB.spCands
  dsimp only
  exact SMemDB.keeps_fold _ (fun d c => SMemDB.spCand1_keeps _ _ _ d c) _ d

/-- **Computing spread changes no stored knowledge** (the augmentations' rows, LTIs, attributes
and values, and the LTIs): only activations, weights and the spread bookkeeping. -/
theorem SMemDB.calcSpread_keeps (d : SMemDB) (cands : List Nat) (pre : Nat → Option Float) :
    d.Keeps (d.calcSpread cands pre) := by
  unfold SMemDB.calcSpread
  dsimp only
  exact (SMemDB.spInvalidate_keeps d).trans ((SMemDB.spFingerprints_keeps _ _).trans
    ((SMemDB.spEnter_keeps _ _).trans ((SMemDB.spRemove_keeps _).trans (SMemDB.spCands_keeps _ _ _))))

/-- **Computing spread changes no stored knowledge**: only activations and edge weights. -/
theorem SMemDB.spreadPrep_content (db : SMemDB) (els : List CueEl) (pre : Nat → Option Float) :
    (db.spreadPrep els pre).content = db.content ∧ (db.spreadPrep els pre).ltis = db.ltis := by
  unfold SMemDB.spreadPrep
  split
  · exact ⟨rfl, rfl⟩
  · split
    · exact ⟨rfl, rfl⟩
    · simp only []
      split
      · exact ⟨(SMemDB.calcSpread_keeps _ _ _).1.symm, (SMemDB.calcSpread_keeps _ _ _).2.symm⟩
      · split
        · exact ⟨(SMemDB.calcSpread_keeps _ _ _).1.symm, (SMemDB.calcSpread_keeps _ _ _).2.symm⟩
        · exact ⟨rfl, rfl⟩

/-- Preparing a query changes only activation bookkeeping. -/
theorem St.prepQuery_content (s : St) (c : Cmd) (q : Nat) :
    (s.prepQuery c q).smem.content = s.smem.content ∧ (s.prepQuery c q).smem.ltis = s.smem.ltis := by
  unfold St.prepQuery
  obtain ⟨h1, h2⟩ := SMemDB.markProhibits_content s.smem (c.prohibits.filterMap s.ltiOf?)
  split
  · obtain ⟨h5, h6⟩ := SMemDB.spreadPrep_content (s.smem.markProhibits (c.prohibits.filterMap s.ltiOf?)) _ s.spPre
    obtain ⟨h3, h4⟩ := SMemDB.naiveUpdate_content ((s.smem.markProhibits (c.prohibits.filterMap s.ltiOf?)).spreadPrep _ s.spPre) _
    exact ⟨h3.trans (h5.trans h1), h4.trans (h6.trans h2)⟩
  · exact ⟨h1, h2⟩

theorem St.stiFor_smem (s : St) (tbl : List (Nat × Nat)) (m : Nat) : (s.stiFor tbl m).1.smem = s.smem := by
  unfold St.stiFor; split <;> rfl

theorem installStep_smem (x d : Nat) (acc : InstAcc) (av : Sym × LVal) :
    (installStep x d acc av).1.smem = acc.1.smem := by
  obtain ⟨s, tbl, ws, q⟩ := acc
  obtain ⟨a, v⟩ := av
  unfold installStep
  cases v with
  | const c => rfl
  | lti m' =>
    simp only
    have h := St.stiFor_smem s tbl m'
    revert h
    generalize s.stiFor tbl m' = p
    obtain ⟨s', y, tbl'⟩ := p
    intro h; exact h

theorem foldl_installStep_smem (x d : Nat) (l : List (Sym × LVal)) (acc : InstAcc) :
    (l.foldl (installStep x d) acc).1.smem = acc.1.smem :=
  foldl_rel (fun a b : InstAcc => b.1.smem = a.1.smem) (fun _ _ _ h1 h2 => h2.trans h1) (fun _ => rfl)
    (installStep x d) (fun acc a => installStep_smem _ _ _ _) l acc

theorem installOne_smem (acc : InstAcc) (x m d : Nat) : (installOne acc x m d).1.smem = acc.1.smem := by
  unfold installOne; exact foldl_installStep_smem _ _ _ _

theorem installBfs_smem (r : Nat) : ∀ (f : Nat) (s : St) tbl ws «meta» queue visited,
    (installBfs r f s tbl ws «meta» queue visited).1.smem = s.smem
  | 0, _, _, _, _, _, _ => by simp [installBfs]
  | _ + 1, _, _, _, _, [], _ => by simp [installBfs]
  | f + 1, s, tbl, ws, «meta», (y, m, d) :: rest, visited => by
    simp only [installBfs]
    split
    · exact installBfs_smem r f s tbl ws «meta» rest visited
    · rw [installBfs_smem r f]
      have := installOne_smem (s, tbl, ws, []) y m d
      simpa using this

/-- Placing an LTI in working memory changes semantic memory's content not at all (only, if
asked, the LTI's activation). -/
theorem St.install_smem (s : St) (r n : Nat) (g : Option Nat) (a : Bool) (d : Nat) :
    (s.install r n g a d).1.smem =
      if a = true then (s.smem.activate n true (s.smem.edgesOf n).length).1 else s.smem := by
  unfold St.install; rfl

theorem St.install_content (s : St) (r n : Nat) (g : Option Nat) (a : Bool) (d : Nat) :
    (s.install r n g a d).1.smem.content = s.smem.content ∧
    (s.install r n g a d).1.smem.ltis = s.smem.ltis := by
  rw [St.install_smem]
  split
  · exact SMemDB.activate_content _ _ _ _
  · exact ⟨rfl, rfl⟩

theorem St.runQuery_smem (s : St) (r : Nat) (c : Cmd) (q : Nat) :
    (s.runQuery r c q).1.smem = match (s.prepQuery c q).queryResult c q with
      | some n => ((s.prepQuery c q).install r n none (s.prepQuery c q).smem.activateOnQuery c.depth).1.smem
      | none => (s.prepQuery c q).smem := by
  unfold St.runQuery
  generalize s.prepQuery c q = s'
  dsimp only
  generalize s'.queryResult c q = o
  cases o <;> rfl

/-- **Retrieval changes no stored knowledge.** A retrieval command, cue-based or not, leaves
the content of semantic memory unchanged; at most the retrieved LTI's activation changes.

This is the CMC's requirement that retrieval only touch the metadata of declarative memory
("retrieveTouch_symbolic" in `CMC.Proc`). -/
theorem St.runCmd_retrieval_content (s : St) (r cid : Nat) (c : Cmd)
    (h : c.path = .query ∨ c.path = .retrieve) :
    (s.runCmd r cid c).1.smem.content = s.smem.content ∧
    (s.runCmd r cid c).1.smem.ltis = s.smem.ltis := by
  rcases h with h | h
  · simp only [St.runCmd, h]
    split
    · exact ⟨rfl, rfl⟩
    · rename_i q _
      have hp := St.prepQuery_content s c q
      rw [St.runQuery_smem]
      split
      · rename_i n _
        obtain ⟨h1, h2⟩ := St.install_content (s.prepQuery c q) r n none (s.prepQuery c q).smem.activateOnQuery c.depth
        exact ⟨h1.trans hp.1, h2.trans hp.2⟩
      · exact hp
  · simp only [St.runCmd, h]
    split
    · exact ⟨rfl, rfl⟩
    · rename_i x _
      cases hx : s.ltiOf? x with
      | none => simp only [St.runRetrieve, hx]; exact ⟨trivial, trivial⟩
      | some n => simp only [St.runRetrieve, hx]; exact St.install_content _ _ _ _ _ _

section WriteOther
variable (m : Nat)

/-- The stored augmentations of LTI `m`. -/
def SMemDB.of (db : SMemDB) : List (Nat × Nat × Sym × LVal) := (db.edgesOf m).map Edge.content

theorem SMemDB.ensureLti_of (db : SMemDB) (n : Nat) : (db.ensureLti n).of m = db.of m := by
  unfold SMemDB.ensureLti; split <;> rfl

theorem foldl_ensureLti_of (l : List Nat) (db : SMemDB) : (l.foldl SMemDB.ensureLti db).of m = db.of m :=
  foldl_rel (fun a b : SMemDB => b.of m = a.of m) (fun _ _ _ h1 h2 => h2.trans h1) (fun _ => rfl)
    SMemDB.ensureLti (fun db a => SMemDB.ensureLti_of _ _ _) l db

theorem filter_map_frame (es : List Edge) (f : Edge → Edge) (hl : ∀ e, (f e).lti = e.lti)
    (hf : ∀ e, e.lti = m → f e = e) :
    ((es.map f).filter (·.lti == m)).map Edge.content = (es.filter (·.lti == m)).map Edge.content := by
  induction es with
  | nil => rfl
  | cons e es ih =>
    rw [List.map_cons, List.filter_cons, List.filter_cons, hl e]
    by_cases h : e.lti = m
    · rw [hf e h]; simp only [h, beq_self_eq_true, ite_true, List.map_cons]; rw [ih]
    · have : (e.lti == m) = false := by simp [h]
      simp only [this, Bool.false_eq_true, ite_false]; exact ih

theorem filter_map_act (es : List Edge) (n : Nat) (a : Float) (hm : m ≠ n) :
    ((es.map fun e => if (e.lti == n) = true then { e with act := a } else e).filter (·.lti == m)).map Edge.content =
      (es.filter (·.lti == m)).map Edge.content := by
  apply filter_map_frame
  · intro e; split <;> rfl
  · intro e he
    have : (e.lti == n) = false := by simp [he, hm]
    simp only [this, Bool.false_eq_true, ite_false]

theorem SMemDB.lowAct_of (db : SMemDB) (n : Nat) (hm : m ≠ n) : (db.lowAct n).of m = db.of m :=
  filter_map_act m _ _ _ hm

theorem ite_lowAct_of (c : Prop) [Decidable c] (db : SMemDB) (n : Nat) (hm : m ≠ n) :
    SMemDB.of m (if c then db.lowAct n else db) = db.of m := by
  split
  · exact SMemDB.lowAct_of m _ _ hm
  · rfl

theorem filter_lti_content (es : List Edge) :
    (es.filter (·.lti == m)).map Edge.content = (es.map Edge.content).filter (fun c => c.2.1 == m) := by
  induction es with
  | nil => rfl
  | cons e es ih =>
    rw [List.filter_cons, List.map_cons, List.filter_cons]
    show _ = (if (e.lti == m) = true then _ else _)
    split <;> simp [ih]

/-- An LTI's stored augmentations are determined by the store's content. -/
theorem SMemDB.of_of_content (db db' : SMemDB) (h : db'.content = db.content) : db'.of m = db.of m := by
  unfold SMemDB.of SMemDB.edgesOf
  rw [filter_lti_content, filter_lti_content]
  unfold SMemDB.content at h
  rw [h]

theorem SMemDB.activate_of (db : SMemDB) (n : Nat) (b : Bool) (k : Nat) (_hm : m ≠ n) :
    (db.activate n b k).1.of m = db.of m :=
  SMemDB.of_of_content m _ _ (SMemDB.activate_content db n b k).1

theorem SMemDB.appendEdge_of (n : Nat) (a : Float) (db : SMemDB) (xv : Sym × LVal) (hm : m ≠ n) :
    (SMemDB.appendEdge n a db xv).of m = db.of m := by
  unfold SMemDB.appendEdge SMemDB.of SMemDB.edgesOf
  simp only [List.filter_append, List.map_append]
  have : ([({ row := db.nextRow, lti := n, attr := xv.1, val := xv.2, act := a } : Edge)].filter (·.lti == m)) = [] := by
    simp [Ne.symm hm]
  rw [this]; simp

theorem foldl_appendEdge_of (n : Nat) (a : Float) (l : List (Sym × LVal)) (db : SMemDB) (hm : m ≠ n) :
    (l.foldl (SMemDB.appendEdge n a) db).of m = db.of m :=
  foldl_rel (fun a b : SMemDB => b.of m = a.of m) (fun _ _ _ h1 h2 => h2.trans h1) (fun _ => rfl)
    (SMemDB.appendEdge n a) (fun _ _ => SMemDB.appendEdge_of m _ _ _ _ hm) l db

theorem filter_ne_of (es : List Edge) (n : Nat) (hm : m ≠ n) :
    ((es.filter (·.lti != n)).filter (·.lti == m)).map Edge.content = (es.filter (·.lti == m)).map Edge.content := by
  rw [List.filter_filter]
  congr 1
  apply List.filter_congr
  intro e _
  by_cases h : e.lti = m
  · simp [h, hm]
  · simp [h]

theorem SMemDB.setWeights_content (db : SMemDB) (p : Edge → Bool) (w : Float) :
    (db.setWeights p w).content = db.content := by
  unfold SMemDB.setWeights SMemDB.content
  simp only [List.map_map]
  congr 1
  funext e
  simp only [Function.comp]
  split <;> rfl

theorem SMemDB.setWeights_of (db : SMemDB) (p : Edge → Bool) (w : Float) :
    (db.setWeights p w).of m = db.of m :=
  SMemDB.of_of_content m _ _ (SMemDB.setWeights_content db p w)

theorem SMemDB.invalidateIf_of (db : SMemDB) (c : Bool) (n : Nat) : (db.invalidateIf c n).of m = db.of m := by
  unfold SMemDB.invalidateIf; split <;> rfl

/-- **Storing an LTI changes no other LTI.** Writing the augmentations of LTI `n` leaves the
stored augmentations of every other LTI as they were. -/
theorem SMemDB.write_other (db : SMemDB) (n : Nat) (aug : List (Sym × LVal)) (ro a : Bool)
    (hm : m ≠ n) : (db.write n aug ro a).of m = db.of m := by
  unfold SMemDB.write
  simp only []
  rw [foldl_ensureLti_of, SMemDB.invalidateIf_of, SMemDB.setWeights_of, foldl_appendEdge_of m _ _ _ _ hm]
  rw [show ∀ (d : SMemDB) (x : List Sym) (y : List Nat), SMemDB.of m { d with syms := x, prohibRows := y } = SMemDB.of m d from fun _ _ _ => rfl]
  have h₂ : (if ro = true then ({ db.ensureLti n with edges := (db.ensureLti n).edges.filter (·.lti != n) } : SMemDB)
      else db.ensureLti n).of m = db.of m := by
    split
    · show ((((db.ensureLti n).edges.filter (·.lti != n)).filter (·.lti == m)).map Edge.content) = _
      rw [filter_ne_of m _ _ hm]; exact SMemDB.ensureLti_of m db n
    · exact SMemDB.ensureLti_of m db n
  split
  · rw [SMemDB.activate_of m _ _ _ _ hm, ite_lowAct_of m _ _ _ hm]; exact h₂
  · show SMemDB.of m (if _ then SMemDB.lowAct _ n else _) = _
    rw [ite_lowAct_of m _ _ _ hm]; exact h₂

end WriteOther

/-- **Semantic memory never changes architecture-created elements or the goal stack.** -/
theorem St.smemState_arch (s : St) (b : Bool) (g : Goal) :
    (s.smemState b g).arch = s.arch ∧ (s.smemState b g).goals = s.goals := ⟨rfl, rfl⟩

theorem St.smemRun_arch (s : St) (b : Bool) :
    (s.smemRun b).arch = s.arch ∧ (s.smemRun b).goals = s.goals := by
  unfold St.smemRun
  generalize (s.goals.toArray.qsort (fun a b => a.level > b.level)).toList = gs
  induction gs generalizing s with
  | nil => exact ⟨rfl, rfl⟩
  | cons g gs ih =>
    simp only [List.foldl_cons]
    obtain ⟨h1, h2⟩ := ih (s.smemState b g)
    obtain ⟨h3, h4⟩ := St.smemState_arch s b g
    exact ⟨h1.trans h3, h2.trans h4⟩

end Soar
