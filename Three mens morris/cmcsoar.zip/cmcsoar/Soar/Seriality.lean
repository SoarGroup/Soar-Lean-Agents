import Soar.Props

/-!
# At most one selected operator per state, over whole runs

`decide_selects_at_most_one` (Soar/Props.lean) shows that one decision phase adds at most one
operator selection. This file extends that to whole runs: if every state has at most one
selected operator at the start (the initial state has none), then after any number of decision
cycles every state still has at most one (`run_selUnique`). The decision phase selects an
operator only for a state that has none (`St.decidable`); every other phase only removes
architecture-created elements or adds ones that are not selections.
-/

namespace Soar

/-- At most one operator selected per state: two operator selections of the same state are
the same element. -/
def SelUnique (A : List WME) : Prop :=
  ∀ w ∈ A, ∀ w' ∈ A, isSel w = true → isSel w' = true → w.id = w'.id → w = w'

/-- Every operator selection of `t` is one of `s`. -/
def SelSub (s t : St) : Prop := ∀ w ∈ t.arch, isSel w = true → w ∈ s.arch

theorem SelSub.refl (s : St) : SelSub s s := fun _ hw _ => hw

theorem SelSub.trans {s t u : St} (h₁ : SelSub s t) (h₂ : SelSub t u) : SelSub s u :=
  fun w hw hs => h₁ w (h₂ w hw hs) hs

theorem SelSub.of_arch {s t : St} (h : t.arch = s.arch) : SelSub s t :=
  fun w hw _ => h ▸ hw

theorem SelSub.of_drop {s t : St} (h : ArchDrop s t) : SelSub s t :=
  fun w hw _ => h.2.1 w hw

theorem SelUnique.of_sub {s t : St} (h : SelUnique s.arch) (hs : SelSub s t) : SelUnique t.arch :=
  fun w hw w' hw' h1 h2 he => h w (hs w hw h1) w' (hs w' hw' h2) h1 h2 he

/-! ## The phases other than the decision -/

theorem presentIs_sel {k : Nat} {w : WME} (h : isSel (presentIs k w) = true) : presentIs k w = w := by
  unfold presentIs at *
  split
  · rename_i ha
    simp only [isSel, isOpAttr, Bool.and_eq_true] at h
    have h1 := h.1
    simp only [beq_iff_eq] at ha h1
    rw [ha] at h1; simp at h1
  · rfl

theorem epStore_sub (s : St) : SelSub s s.epStore := by
  unfold St.epStore
  dsimp only
  split
  · exact SelSub.of_arch rfl
  · intro w hw hs
    simp only [List.mem_map] at hw
    obtain ⟨w₀, h₀, rfl⟩ := hw
    rw [presentIs_sel hs]; exact h₀

theorem foldl_epState_arch (gs : List Goal) (s : St) : (gs.foldl St.epState s).arch = s.arch :=
  foldl_rel (fun a b : St => b.arch = a.arch) (fun _ _ _ h1 h2 => h2.trans h1) (fun _ => rfl)
    St.epState (fun _ _ => rfl) gs s

theorem epPass_sub (s : St) : SelSub s s.epPass := by
  unfold St.epPass
  split
  · exact SelSub.refl s
  · intro w hw hs
    have h4 := SelSub.of_drop (ArchDrop.spSync (ArchDrop.wmaS (wmPhase_drop _ _) _)) w hw hs
    have h5 : w ∈ s.epStore.arch := by
      simp only [St.setWma] at h4; rwa [foldl_epState_arch] at h4
    exact epStore_sub s w h5 hs

theorem wmaForgetDrop_sub (s : St) (vs : List WME) : SelSub s (s.wmaForgetDrop vs) := by
  unfold St.wmaForgetDrop
  split
  · exact SelSub.refl s
  · dsimp only
    split
    · exact SelSub.refl s
    · intro w hw hs
      have h1 := SelSub.of_drop (ArchDrop.spSync (ArchDrop.wmaS (wmPhase_drop _ _) _)) w hw hs
      simp only [St.setWma] at h1
      rwa [(dropPrefs_same s _ _).1] at h1

theorem wmaForget_sub (s : St) : SelSub s s.wmaForget := by
  unfold St.wmaForget
  split
  · exact SelSub.refl s
  · intro w hw hs
    exact wmaForgetDrop_sub (s.setWma s.wmaForgetVictims.1) s.wmaForgetVictims.2 w hw hs

theorem foldl_rlUpdate_arch (s : St) (u : Bool) :
    ∀ (gs : List Goal) (t : St), t.arch = s.arch →
      (gs.foldl (fun (t : St) g => t.rlUpdate g.id 0 true u) t).arch = s.arch :=
  fun gs t h => (foldl_rel (fun a b : St => b.arch = a.arch) (fun _ _ _ h1 h2 => h2.trans h1)
    (fun _ => rfl) _ (fun t g => (rlUpdate_frame t g.id 0 true u).1) gs t).trans h

theorem rlHalt_arch (s : St) (u : Bool) : (s.rlHalt u).arch = s.arch := by
  unfold St.rlHalt
  split
  · rfl
  · exact foldl_rlUpdate_arch s u _ _ rfl

/-! ## The decision phase -/

/-- No operator is selected for `g` in `s`: no operator selection of `g` in its elements. -/
theorem selected_none {s : St} {g : Nat} (h : s.selected g = none) :
    ∀ w ∈ s.arch, isSel w = true → w.id ≠ g := by
  intro w hw hs he
  unfold St.selected at h
  rw [Option.map_eq_none_iff, List.find?_eq_none] at h
  have := h w hw
  simp only [isSel, Bool.and_eq_true] at hs
  simp [he, hs.1, hs.2] at this

theorem SelUnique.of_within {s : St} {B : List WME} (hu : SelUnique s.arch)
    (h : SelWithin s.arch B none) : SelUnique B :=
  fun w hw w' hw' h1 h2 he => by
    have a := h w hw h1
    have b := h w' hw' h2
    simp only [reduceCtorEq, or_false] at a b
    exact hu w a w' b h1 h2 he

theorem decideSelect_unique (s : St) (g : Goal) (o : Sym) (hu : SelUnique s.arch)
    (hn : s.selected g.id = none) : SelUnique (s.decideSelect g o).arch := by
  have hsub : ∀ w ∈ ((s.rlSelect g.id o).removeGoalsFrom (g.level + 1)).arch, w ∈ s.arch := by
    intro w hw
    have := removeGoalsFrom_arch_sub _ _ w hw
    rwa [St.rlSelect_arch] at this
  have hnot := selected_none hn
  unfold St.decideSelect
  intro w hw w' hw' h1 h2 he
  simp only [List.mem_append, List.mem_singleton] at hw hw'
  rcases hw with hw | rfl <;> rcases hw' with hw' | rfl
  · exact hu w (hsub w hw) w' (hsub w' hw') h1 h2 he
  · exact absurd he (hnot w (hsub w hw) h1)
  · exact absurd he.symm (hnot w' (hsub w' hw') h2)
  · rfl

theorem decideSlot_unique (s : St) (choose : List Sym → Sym) (g : Goal) (child : Option Goal)
    (dec : Bool) (hu : SelUnique s.arch) (hdec : dec = true → s.selected g.id = none) :
    SelUnique (Sum.elim id id (s.decideSlot choose g child dec)).arch := by
  have hw0 : SelWithin s.arch s.arch none := fun w hw _ => Or.inl hw
  unfold St.decideSlot
  split
  · split <;> exact hu.of_within (decideImpasse_none _ _ _ _ _ _ hw0)
  · rename_i hd
    have hd : dec = true := by simpa using hd
    have ha := St.pickTie_arch s choose (s.prefsFor g.id) g.id
    have hw1 : SelWithin s.arch (s.pickTie choose (s.prefsFor g.id) g.id).1.arch none := by
      rw [ha]; exact hw0
    simp only
    split
    · have hu' : SelUnique (s.pickTie choose (s.prefsFor g.id) g.id).1.arch := by rw [ha]; exact hu
      have hn : (s.pickTie choose (s.prefsFor g.id) g.id).1.selected g.id = none := by
        unfold St.selected; rw [ha]; exact hdec hd
      exact decideSelect_unique _ _ _ hu' hn
    · exact hu.of_within (decideImpasse_none _ _ _ _ _ _ hw1)
    · exact hu.of_within (decideImpasse_none _ _ _ _ _ _ hw1)

theorem decide_go_unique (choose : List Sym → Sym) :
    ∀ (fuel lv : Nat) (s : St), SelUnique s.arch → SelUnique (St.decide.go choose fuel lv s).arch
  | 0, lv, s, h => by simpa [St.decide.go] using h
  | fuel + 1, lv, s, h => by
    unfold St.decide.go
    split
    · exact h
    · rename_i g _
      split
      · exact decide_go_unique choose fuel _ _ h
      · have hs := decideSlot_unique ({ s with ctxChanged := s.ctxChanged.filter (· != g.id) } : St)
          choose g (s.goals.find? (·.level == lv + 1)) (s.decidable g) h (by
            intro hd
            unfold St.decidable at hd
            simp only [Bool.and_eq_true, Option.isNone_iff_eq_none] at hd
            exact hd.1)
        split
        · rename_i t ht; rw [ht] at hs; exact hs
        · rename_i t ht; rw [ht] at hs; exact decide_go_unique choose fuel _ _ hs

theorem decide_unique (s : St) (choose : List Sym → Sym) (h : SelUnique s.arch) :
    SelUnique (s.decide choose).arch := by
  unfold St.decide
  exact decide_go_unique choose _ _ s h

/-! ## Whole cycles and runs -/

theorem cycleElab_unique (s : St) (inp : List WME) (pm : List Production) (choose : List Sym → Sym)
    (maxElab : Nat) (h : SelUnique s.arch) : SelUnique (s.cycleElab inp pm choose maxElab).arch := by
  unfold St.cycleElab
  extract_lets s0 s1 s2 s3 s4
  have h1 : SelUnique s1.arch := by simp only [s1]; exact h
  have h2 : SelUnique s2.arch := by
    simp only [s2]
    exact h1.of_sub (SelSub.of_drop (ArchDrop.trans (gc_drop s1) (gdsCheck_drop _)))
  have h3 : SelUnique s3.arch := by
    simp only [s3]
    split
    · rw [(soarRetag_same s2 s0 []).1]; exact h2
    · exact h2
  have h4 : SelUnique s4.arch := by
    simp only [s4]; exact h3.of_sub (SelSub.of_drop (ArchDrop.spSync (ArchDrop.refl s3)))
  exact h4.of_sub (SelSub.of_drop (propose_drop _ _ _ _))

theorem cycleDec_unique (s : St) (pm : List Production) (choose : List Sym → Sym)
    (h : SelUnique s.arch) : SelUnique (s.cycleDec pm choose).arch := by
  unfold St.cycleDec
  extract_lets s6 s7
  have h6 : SelUnique s6.arch := by
    simp only [s6]
    split
    · exact h
    · exact h
  have h7 : SelUnique s7.arch := by
    have a := decide_unique s6 choose h6
    have b : SelSub (s6.decide choose) (((s6.decide choose).wmPhase s6).spSync) :=
      SelSub.of_drop (ArchDrop.spSync (s := s6.decide choose) (t := (s6.decide choose).wmPhase s6)
        (wmPhase_drop (s6.decide choose) s6))
    simp only [s7]
    exact a.of_sub b
  exact h7

theorem cycleApply_unique (s : St) (pm : List Production) (choose : List Sym → Sym)
    (maxElab : Nat) (h : SelUnique s.arch) : SelUnique (s.cycleApply pm choose maxElab).arch := by
  unfold St.cycleApply
  split
  · exact h
  · extract_lets s9 s10
    have h9 : SelUnique s9.arch := by
      simp only [s9]
      split
      · exact h.of_sub (epPass_sub s)
      · exact h
    have h10 : SelUnique s10.arch := by
      simp only [s10]; exact h9.of_sub (SelSub.of_drop (apply_drop _ _ _ _))
    split
    · exact h10
    · rename_i s11 s12 w13 s14 s15 w16 s17 s18 s19 w20 hn
      have h11 : SelUnique s11.arch := by
        simp only [s11]; exact h10.of_sub (SelSub.of_drop (smemPass_drop _ _))
      have h12 : SelUnique s12.arch := by simp only [s12, St.setWma]; exact h11
      have h17 : SelUnique s17.arch := by
        simp only [s17]
        split
        · exact h12
        · have h14 : SelUnique s14.arch := by simp only [s14, St.setWma]; exact h12
          have h15 : SelUnique s15.arch := by simp only [s15]; exact h14.of_sub (epPass_sub s14)
          simp only [St.setWma]; exact h15
      have h18 : SelUnique s18.arch := by simp only [s18, St.setWma]; exact h17
      have h19 : SelUnique s19.arch := by simp only [s19]; exact h18.of_sub (wmaForget_sub s18)
      simp only [St.setWma]; exact h19

theorem cycle_unique (s : St) (pm : List Production) (env : Env) (choose : List Sym → Sym)
    (maxElab : Nat) (h : SelUnique s.arch) : SelUnique (s.cycle pm env choose maxElab).arch := by
  unfold St.cycle St.cycleFrom
  have he := cycleElab_unique s (env.input s.dc s.output) pm choose maxElab h
  generalize s.cycleElab (env.input s.dc s.output) pm choose maxElab = e at he ⊢
  dsimp only
  split
  · exact he
  · exact cycleApply_unique _ _ _ _ (cycleDec_unique _ _ _ he)

/-- **At most one selected operator per state, over whole runs.** If every state has at most
one selected operator at the start, it has at most one after any number of decision cycles.

> "Procedural memory induces the selection of a single deliberate act per cycle" — [LLR17] -/
theorem run_selUnique (s : St) (pm : List Production) (env : Env) (n : Nat)
    (choose : List Sym → Sym) (h : SelUnique s.arch) :
    SelUnique (s.run pm env n choose).arch := by
  induction n generalizing s with
  | zero => exact h
  | succ k ih =>
    unfold St.run
    split
    · exact h
    · dsimp only
      have hc := cycle_unique s pm env choose s.maxElab h
      split
      · rw [rlHalt_arch]; exact hc
      · split
        · exact hc
        · exact ih _ hc

/-- The initial state has no operator selected. -/
theorem init_selUnique : SelUnique St.init.arch := by
  have hall : St.init.arch.all (fun w => !isSel w) = true := by
    simp [St.init, stateLinks, isSel, isOpAttr]
  intro w hw _ _ h1
  have := List.all_eq_true.mp hall w hw
  rw [h1] at this; cases this

/-- From the initial state, every state has at most one selected operator after any number of
decision cycles. -/
theorem run_init_selUnique (pm : List Production) (env : Env) (n : Nat) (choose : List Sym → Sym) :
    SelUnique (St.init.run pm env n choose).arch :=
  run_selUnique St.init pm env n choose init_selUnique

end Soar
