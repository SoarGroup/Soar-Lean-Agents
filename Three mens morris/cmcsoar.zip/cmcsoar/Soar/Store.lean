import Soar.SMem
import Soar.EpMem

/-!
# Writing the semantic and episodic stores to a file

`smem --set database file` and `epmem --set database file` keep a store in a file at `path`
between agents. Soar 9.6.5 keeps it in SQLite; soar-lean writes the parts of `SMemDB` and `EpDB`
that Soar keeps in its database as a list of space-separated tokens: numbers in decimal, real
numbers as the bits of their IEEE 754 value, strings as the hexadecimal of their UTF-8 bytes. Which
parts a new agent takes from the file is decided by `SMemDB.reopen` and `EpDB.reopen`; this
file only reads and writes them. The format is soar-lean's own and is not compatible with
Soar's databases.
-/

namespace Soar.Store

/-- A value written as tokens and read back from them. -/
class Ser (α : Type) where
  put : α → Array String → Array String
  get : List String → Option (α × List String)

open Ser

instance : Ser Nat where
  put n a := a.push (toString n)
  get | t :: r => t.toNat?.map (·, r) | [] => none

instance : Ser Int where
  put n a := a.push (toString n)
  get | t :: r => t.toInt?.map (·, r) | [] => none

instance : Ser Bool where
  put b a := a.push (if b then "1" else "0")
  get | "1" :: r => some (true, r) | "0" :: r => some (false, r) | _ => none

instance : Ser UInt64 where
  put n a := a.push (toString n.toNat)
  get | t :: r => t.toNat?.map (fun n => (UInt64.ofNat n, r)) | [] => none

instance : Ser Float where
  put f a := a.push (toString f.toBits.toNat)
  get | t :: r => t.toNat?.map (fun n => (Float.ofBits (UInt64.ofNat n), r)) | [] => none

def hexDigit (n : Nat) : Char := "0123456789abcdef".toList.getD n '0'

def hexVal (c : Char) : Option Nat :=
  if '0' ≤ c && c ≤ '9' then some (c.toNat - '0'.toNat)
  else if 'a' ≤ c && c ≤ 'f' then some (c.toNat - 'a'.toNat + 10) else none

/-- A string as the hexadecimal of its bytes, with a leading `x` so that the empty string is a token. -/
def hexOf (s : String) : String :=
  "x" ++ String.mk (s.toUTF8.toList.flatMap fun b => [hexDigit (b.toNat / 16), hexDigit (b.toNat % 16)])

def unhex (t : String) : Option String := do
  let cs := (t.toList.drop 1)
  let rec bytes : List Char → Option (List UInt8)
    | a :: b :: r => do let x ← hexVal a; let y ← hexVal b; let rest ← bytes r; pure (UInt8.ofNat (x * 16 + y) :: rest)
    | [] => some []
    | _ => none
  let bs ← bytes cs
  String.fromUTF8? (ByteArray.mk bs.toArray)

instance : Ser String where
  put s a := a.push (hexOf s)
  get | t :: r => (unhex t).map (·, r) | [] => none

instance [Ser α] : Ser (Option α) where
  put o a := match o with | none => a.push "N" | some x => put x (a.push "S")
  get
    | "N" :: r => some (none, r)
    | "S" :: r => (get r).map fun (x, r) => (some x, r)
    | _ => none

instance [Ser α] [Ser β] : Ser (α × β) where
  put p a := put p.2 (put p.1 a)
  get ts := do let (x, r) ← get ts; let (y, r) ← get r; pure ((x, y), r)

/-- A list: its length, then its elements. -/
def getList [Ser α] : Nat → List String → Option (List α × List String)
  | 0, r => some ([], r)
  | n + 1, ts => do
    let (x, r) ← (get ts : Option (α × List String))
    let (xs, r) ← getList n r
    pure (x :: xs, r)

instance [Ser α] : Ser (List α) where
  put l a := l.foldl (fun a x => put x a) (a.push (toString l.length))
  get ts := do let (n, r) ← (get ts : Option (Nat × List String)); getList n r

instance : Ser Sym where
  put y a := match y with
    | .id n => put n (a.push "i") | .str s => put s (a.push "s")
    | .int n => put n (a.push "n") | .float b => put b (a.push "f")
  get
    | "i" :: r => (get r).map fun (n, r) => (Sym.id n, r)
    | "s" :: r => (get r).map fun (s, r) => (Sym.str s, r)
    | "n" :: r => (get r).map fun (n, r) => (Sym.int n, r)
    | "f" :: r => (get r).map fun (b, r) => (Sym.float b, r)
    | _ => none

instance : Ser LVal where
  put v a := match v with | .const c => put c (a.push "c") | .lti n => put n (a.push "l")
  get
    | "c" :: r => (get r).map fun (c, r) => (LVal.const c, r)
    | "l" :: r => (get r).map fun (n, r) => (LVal.lti n, r)
    | _ => none

instance : Ser EVal where
  put v a := match v with | .const c => put c (a.push "c") | .node n => put n (a.push "n")
  get
    | "c" :: r => (get r).map fun (c, r) => (EVal.const c, r)
    | "n" :: r => (get r).map fun (n, r) => (EVal.node n, r)
    | _ => none

instance : Ser Edge where
  put e a := put e.weight (put e.act (put e.val (put e.attr (put e.lti (put e.row a)))))
  get ts := do
    let (row, r) ← get ts; let (lti, r) ← get r; let (attr, r) ← get r
    let (val, r) ← get r; let (act, r) ← get r; let (weight, r) ← get r
    pure ({ row, lti, attr, val, act, weight }, r)

instance : Ser Fake where
  put f a := put f.value (put f.spread (put f.base a))
  get ts := do
    let (base, r) ← get ts; let (spread, r) ← get r; let (value, r) ← get r
    pure ({ base, spread, value }, r)

instance : Ser EEdge where
  put e a := put e.closedLti (put e.lti (put e.maxed (put e.lastEp (put e.now (put e.closed
    (put e.child (put e.attr (put e.parent a))))))))
  get ts := do
    let (parent, r) ← get ts; let (attr, r) ← get r; let (child, r) ← get r
    let (closed, r) ← get r; let (now, r) ← get r; let (lastEp, r) ← get r
    let (maxed, r) ← get r; let (lti, r) ← get r; let (closedLti, r) ← get r
    pure ({ parent, attr, child, closed, now, lastEp, maxed, lti, closedLti }, r)

/-- The parts of a semantic store that Soar keeps in its database (those `SMemDB.reopen` reads). -/
def putSMem (db : SMemDB) : Array String :=
  let a := #["soar-lean-smem", "1"]
  let a := put db.edges a; let a := put db.ltis a; let a := put db.counter a
  let a := put db.clock a; let a := put db.syms a; let a := put db.ltiAct a
  let a := put db.accesses a; let a := put db.aliases a; let a := put db.accTimes a
  let a := put db.history a; let a := put db.prohib a; let a := put db.prohibRows a
  let a := put db.ltiBase a; let a := put db.thresh a; let a := put db.frequency a
  let a := put db.baseLevel a
  let sp := db.spread
  let a := put sp.traj a; let a := put sp.like a; let a := put sp.trajNum a
  put sp.invalid a

def getSMem (ts : List String) : Option SMemDB := do
  let r ← match ts with | "soar-lean-smem" :: "1" :: r => some r | _ => none
  let (edges, r) ← get r; let (ltis, r) ← get r; let (counter, r) ← get r
  let (clock, r) ← get r; let (syms, r) ← get r; let (ltiAct, r) ← get r
  let (accesses, r) ← get r; let (aliases, r) ← get r; let (accTimes, r) ← get r
  let (history, r) ← get r; let (prohib, r) ← get r; let (prohibRows, r) ← get r
  let (ltiBase, r) ← get r; let (thresh, r) ← get r; let (frequency, r) ← get r
  let (baseLevel, r) ← get r
  let (traj, r) ← get r; let (like, r) ← get r; let (trajNum, r) ← get r
  let (invalid, _) ← get r
  pure { edges, ltis, counter, clock, syms, ltiAct, accesses, aliases, accTimes, history, prohib,
         prohibRows, ltiBase, thresh, frequency, baseLevel,
         spread := { traj, like, trajNum, invalid } }

/-- The parts of an episodic store that Soar keeps in its database (those `EpDB.reopen` reads). -/
def putEp (db : EpDB) : Array String :=
  let a := #["soar-lean-epmem", "1"]
  let a := put db.wcs a; let a := put db.wis a; let a := put db.time a
  put db.nextNode a

def getEp (ts : List String) : Option EpDB := do
  let r ← match ts with | "soar-lean-epmem" :: "1" :: r => some r | _ => none
  let (wcs, r) ← get r; let (wis, r) ← get r; let (time, r) ← get r
  let (nextNode, _) ← get r
  pure { wcs, wis, time, nextNode }

def tokens (s : String) : List String :=
  ((s.replace "\n" " ").splitOn " ").filter (· != "")

/-- Tokens written ten to a line. -/
def render (a : Array String) : String :=
  "\n".intercalate ((List.range ((a.size + 9) / 10)).map fun i =>
    " ".intercalate ((a.toList.drop (i * 10)).take 10))

end Soar.Store
