import Soar.Cycle
/-!
# Soar 9.6 — the Rete's o-support agrees with `oSupported` for a single match

`St.reteSupport` follows Soar 9.6.5's Rete (`p_node_left_addition`), which looks at every
current match of a production; `St.oSupported` is the manual's rule for one instantiation.
With no other match, and for a rule with no preference action, the two give the same answer
(`reteSupport_nil`). They differ for a rule whose actions include preferences, and, in
`reteSupport`, when another match of the same production selects another operator.
-/

namespace Soar

theorem inner_fold (o : Sym) : ∀ (ids : List (Option Sym)) (acc : Bool × Bool),
    ids.foldl (fun (acc : Bool × Bool) i => if i == some o then (acc.1, true) else (true, acc.2)) acc =
      (acc.1 || ids.any (fun i => !(i == some o)), acc.2 || ids.any (fun i => i == some o))
  | [], acc => by simp
  | i :: ids, acc => by
    rw [List.foldl_cons, inner_fold o ids]
    by_cases h : (i == some o) = true
    · simp [h]
    · have h' : (i == some o) = false := by simpa using h
      simp [h']

theorem outer_fold (ids : List (Option Sym)) : ∀ (os : List Sym) (acc : Bool × Bool),
    os.foldl (fun (acc : Bool × Bool) o =>
        ids.foldl (fun (acc : Bool × Bool) i => if i == some o then (acc.1, true) else (true, acc.2)) acc) acc =
      (acc.1 || os.any (fun o => ids.any (fun i => !(i == some o))),
       acc.2 || os.any (fun o => ids.any (fun i => i == some o)))
  | [], acc => by simp
  | o :: os, acc => by
    rw [List.foldl_cons, outer_fold ids os, inner_fold]
    simp [Bool.or_assoc]

theorem ab_eq (selOps : List Sym) (ids : List (Option Sym)) :
    (selOps.any (fun o => ids.any (fun i => !(i == some o))) &&
      !selOps.any (fun o => ids.any (fun i => i == some o))) =
    (!selOps.isEmpty && ids.any (fun _ => true) &&
      !ids.any (fun i => match i with | some x => selOps.contains x | none => false)) := by
  rw [Bool.eq_iff_iff]
  simp [List.any_eq_true, List.isEmpty_iff]
  constructor
  · rintro ⟨⟨o, ho, i, hi, hne⟩, hno⟩
    refine ⟨⟨fun h => by simp [h] at ho, i, hi⟩, ?_⟩
    intro x hx
    cases x with
    | none => rfl
    | some y =>
      simp only [decide_eq_false_iff_not]
      intro hy
      exact hno y hy hx
  · rintro ⟨⟨hne, i, hi⟩, hall⟩
    refine ⟨?_, ?_⟩
    · cases hs : selOps with
      | nil => exact absurd hs hne
      | cons o os =>
        refine ⟨o, by simp, i, hi, ?_⟩
        intro hio
        have := hall i hi
        rw [hio] at this
        simp [hs] at this
    · intro y hy hyi
      have := hall _ hyi
      simp [hy] at this

theorem acts_any_eq (b : Binding) (P : Option Sym → Bool) : ∀ acts : List Action,
    (∀ a ∈ acts, ∀ sv o k o₂ n, a ≠ Action.pref sv o k o₂ n) →
    acts.any (fun a => match a with | .make i _ _ | .remove i _ _ => P (b.get i) | _ => false) =
    (acts.filterMap fun a => match a with
      | .make i _ _ | .remove i _ _ | .pref i _ _ _ _ => some (b.get i) | _ => none).any P
  | [], _ => rfl
  | a :: as, h => by
    have ih := acts_any_eq b P as (fun x hx => h x (List.mem_cons_of_mem _ hx))
    have ha := h a (List.mem_cons_self ..)
    cases a with
    | make i x v => simp [ih]
    | remove i x v => simp [ih]
    | pref sv o k o₂ n => exact absurd rfl (ha sv o k o₂ n)
    | halt => simpa using ih
    | write _ => simpa using ih
    | cmd _ => simpa using ih

/-- **With no other match, and no preference action, the Rete's o-support is the manual's.** -/
theorem reteSupport_nil (s : St) (p : Production) (b : Binding) (ws : List WME)
    (hp : ∀ a ∈ p.acts, ∀ sv o k o₂ n, a ≠ Action.pref sv o k o₂ n) :
    s.reteSupport p b ws [] = s.oSupported p b ws := by
  unfold St.reteSupport St.oSupported
  cases hs : p.support with
  | some x => simp
  | none =>
    simp only [List.foldl_cons, List.foldl_nil]
    rw [outer_fold]
    generalize hsel : s.selectedOps ws = selOps
    generalize hids : (p.acts.filterMap fun a => match a with
        | .make i _ _ | .remove i _ _ | .pref i _ _ _ _ => some (b.get i)
        | _ => none) = ids
    have h1 : p.changesWM = ids.any (fun _ => true) := by
      rw [← hids]; exact acts_any_eq b (fun _ => true) p.acts hp
    have h2 : p.augments b selOps =
        ids.any (fun i => match i with | some x => selOps.contains x | none => false) := by
      rw [← hids]
      exact acts_any_eq b (fun i => match i with | some x => selOps.contains x | none => false) p.acts hp
    rw [h1, h2]
    have h3 := ab_eq selOps ids
    cases hpr : p.proposes s b
    · simp only [Bool.false_eq_true, ite_false, Bool.not_false, Bool.true_and, Bool.false_or]
      rw [← h3]
      generalize (selOps.any fun o => ids.any fun i => !i == some o) = A
      generalize (selOps.any fun o => ids.any fun i => i == some o) = B
      cases A <;> cases B <;> simp
    · simp

end Soar
