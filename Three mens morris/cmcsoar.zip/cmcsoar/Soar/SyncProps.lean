import Soar.Cycle
/-!
# Soar 9.6 — synchronising working memory with preference memory is idempotent

`St.sync` brings the elements made from preference memory (`slots`) in line with what the
preferences require (`desired`) and then gives the elements their timetags (`retag`). This file
shows that doing it again changes nothing once it has finished (`sync_fixed`, `sync_settles`):
the elements `desired` lists have no repeats, so a state whose slots hold exactly the desired
elements is a fixed point, and `retag` of a state whose table lists the elements of working
memory in order is the state itself. It justifies skipping the second `sync` in `St.gc` when no
preference was removed (S23 in the code review).
-/

namespace Soar

/-! ## `dedupW` keeps the elements, once each -/

theorem dedupW_fold (l : List WME) : ∀ (acc : List WME) (S : Std.HashSet WME),
    (∀ x, S.contains x = true ↔ x ∈ acc) → acc.Nodup →
    ((l.foldl (fun (a : List WME × Std.HashSet WME) w =>
        if a.2.contains w then a else (w :: a.1, a.2.insert w)) (acc, S)).1.Nodup ∧
     (∀ x, (l.foldl (fun (a : List WME × Std.HashSet WME) w =>
        if a.2.contains w then a else (w :: a.1, a.2.insert w)) (acc, S)).2.contains x = true ↔
        x ∈ (l.foldl (fun (a : List WME × Std.HashSet WME) w =>
        if a.2.contains w then a else (w :: a.1, a.2.insert w)) (acc, S)).1) ∧
     (∀ x, x ∈ (l.foldl (fun (a : List WME × Std.HashSet WME) w =>
        if a.2.contains w then a else (w :: a.1, a.2.insert w)) (acc, S)).1 ↔ x ∈ acc ∨ x ∈ l)) := by
  induction l with
  | nil => intro acc S h hn; exact ⟨hn, h, by simp⟩
  | cons w l ih =>
    intro acc S h hn
    rw [List.foldl_cons]
    by_cases hc : S.contains w = true
    · simp only [hc, ite_true]
      obtain ⟨a, b, c⟩ := ih acc S h hn
      refine ⟨a, b, fun x => ?_⟩
      rw [c x]
      constructor
      · rintro (h1 | h1)
        · exact Or.inl h1
        · exact Or.inr (List.mem_cons_of_mem _ h1)
      · rintro (h1 | h1)
        · exact Or.inl h1
        · rcases List.mem_cons.mp h1 with rfl | h1
          · exact Or.inl ((h _).mp hc)
          · exact Or.inr h1
    · have hc' : S.contains w = false := by simpa using hc
      simp only [hc', Bool.false_eq_true, ite_false]
      have hw : w ∉ acc := fun hm => by have := (h w).mpr hm; rw [hc'] at this; simp at this
      obtain ⟨a, b, c⟩ := ih (w :: acc) (S.insert w)
        (by
          intro x
          rw [Std.HashSet.contains_insert, List.mem_cons]
          simp only [Bool.or_eq_true, beq_iff_eq]
          constructor
          · rintro (h1 | h1)
            · exact Or.inl h1.symm
            · exact Or.inr ((h x).mp h1)
          · rintro (h1 | h1)
            · exact Or.inl h1.symm
            · exact Or.inr ((h x).mpr h1))
        (List.nodup_cons.mpr ⟨hw, hn⟩)
      refine ⟨a, b, fun x => ?_⟩
      rw [c x, List.mem_cons, List.mem_cons]
      constructor
      · rintro ((h1 | h1) | h1)
        · exact Or.inr (Or.inl h1)
        · exact Or.inl h1
        · exact Or.inr (Or.inr h1)
      · rintro (h1 | h1 | h1)
        · exact Or.inl (Or.inr h1)
        · exact Or.inl (Or.inl h1)
        · exact Or.inr h1

theorem dedupW_nodup (ws : List WME) : (dedupW ws).Nodup := by
  unfold dedupW
  exact (dedupW_fold ws.reverse [] {} (fun x => by simp) List.nodup_nil).1

theorem mem_dedupW (ws : List WME) (x : WME) : x ∈ dedupW ws ↔ x ∈ ws := by
  unfold dedupW
  rw [(dedupW_fold ws.reverse [] {} (fun x => by simp) List.nodup_nil).2.2 x]
  simp

/-! ## `retag` -/

/-- `t` is `s` with another timetag table and symbol numbering. -/
def TagFr (s t : St) : Prop :=
  ∃ (tt : List (WME × Nat)) (n : Nat) (a : _) (b : _),
    t = { s with tt := tt, tNext := n, symIx := a, symRank := b }

theorem foldl_symfr {X : Type} (f : St → X → St) (hf : ∀ s x, ∃ a b, f s x = { s with symIx := a, symRank := b }) :
    ∀ (l : List X) (s : St), ∃ a b, l.foldl f s = { s with symIx := a, symRank := b }
  | [], s => ⟨s.symIx, s.symRank, rfl⟩
  | x :: l, s => by
    rw [List.foldl_cons]
    obtain ⟨a, b, h⟩ := hf s x
    obtain ⟨a', b', h'⟩ := foldl_symfr f hf l (f s x)
    rw [h] at h'
    exact ⟨a', b', by rw [h]; exact h'⟩

theorem noteSyms_fr (ws : List WME) (s : St) : ∃ a b, s.noteSyms ws = { s with symIx := a, symRank := b } := by
  unfold St.noteSyms
  apply foldl_symfr
  intro s w
  apply foldl_symfr
  intro s y
  split
  · exact ⟨s.symIx, s.symRank, rfl⟩
  · exact ⟨_, _, rfl⟩

theorem retag_fr (s : St) : TagFr s s.retag := by
  unfold St.retag
  exact (noteSyms_fr _ _).elim fun a h => h.elim fun b h => ⟨_, _, a, b, h⟩

theorem TagFr.raw {s t : St} (h : TagFr s t) : t.raw = s.raw := by
  obtain ⟨_, _, _, _, rfl⟩ := h; rfl

theorem TagFr.slots {s t : St} (h : TagFr s t) : t.slots = s.slots := by
  obtain ⟨_, _, _, _, rfl⟩ := h; rfl

theorem TagFr.prefs {s t : St} (h : TagFr s t) : t.prefs = s.prefs := by
  obtain ⟨_, _, _, _, rfl⟩ := h; rfl

theorem TagFr.goals {s t : St} (h : TagFr s t) : t.goals = s.goals := by
  obtain ⟨_, _, _, _, rfl⟩ := h; rfl

theorem TagFr.arch {s t : St} (h : TagFr s t) : t.arch = s.arch := by
  obtain ⟨_, _, _, _, rfl⟩ := h; rfl

/-- The map `retag` builds from the old table. -/
def insTab (L : List (WME × Nat)) : Std.HashMap WME Nat :=
  L.foldl (fun m (w, t) => m.insert w t) {}

theorem ins_notmem (k : WME) : ∀ (L : List (WME × Nat)) (m : Std.HashMap WME Nat),
    k ∉ L.map (·.1) → (L.foldl (fun m (w, t) => m.insert w t) m)[k]? = m[k]?
  | [], m, _ => rfl
  | (w, t) :: L, m, h => by
    rw [List.foldl_cons, ins_notmem k L _ (fun hk => h (List.mem_cons_of_mem _ hk))]
    have hne : ¬ (w == k) = true := by
      intro hb
      have := LawfulBEq.eq_of_beq hb
      subst this
      exact h (by simp)
    simp [Std.HashMap.getElem?_insert, hne]

theorem ins_mem (k : WME) (t : Nat) : ∀ (L : List (WME × Nat)) (m : Std.HashMap WME Nat),
    (L.map (·.1)).Nodup → (k, t) ∈ L → (L.foldl (fun m (w, t) => m.insert w t) m)[k]? = some t
  | [], m, _, h => by simp at h
  | (w, t0) :: L, m, hn, h => by
    rw [List.foldl_cons]
    rcases List.mem_cons.mp h with he | hm
    · have e1 : k = w := (Prod.mk.inj he).1
      have e2 : t = t0 := (Prod.mk.inj he).2
      subst e1; subst e2
      rw [ins_notmem k L _ (List.nodup_cons.mp (by simpa using hn)).1]
      simp [Std.HashMap.getElem?_insert]
    · exact ins_mem k t L _ (List.nodup_cons.mp (by simpa using hn)).2 hm

/-- One step of `retag`. -/
def tagStep (old : Std.HashMap WME Nat) (acc : List (WME × Nat) × Nat) (w : WME) :
    List (WME × Nat) × Nat :=
  match old.get? w with
  | some t => ((w, t) :: acc.1, acc.2)
  | none => ((w, acc.2) :: acc.1, acc.2 + 1)

theorem retag_eq (s : St) :
    s.retag = (({ s with tt := (s.raw.foldl (tagStep (insTab s.tt)) ([], s.tNext)).1.reverse,
                         tNext := (s.raw.foldl (tagStep (insTab s.tt)) ([], s.tNext)).2 } : St).noteSyms
        (s.raw.filter (!(insTab s.tt).contains ·))) := rfl

theorem tag_fold_keys (old : Std.HashMap WME Nat) : ∀ (r : List WME) (acc : List (WME × Nat) × Nat),
    ((r.foldl (tagStep old) acc).1.reverse.map (·.1)) = acc.1.reverse.map (·.1) ++ r
  | [], acc => by simp
  | w :: r, acc => by
    rw [List.foldl_cons, tag_fold_keys old r]
    unfold tagStep
    cases old.get? w <;> simp

theorem tag_fold_known (old : Std.HashMap WME Nat) : ∀ (r : List WME) (acc : List (WME × Nat) × Nat),
    (∀ w ∈ r, ∃ t, old.get? w = some t) →
    r.foldl (tagStep old) acc = ((r.map fun w => (w, (old.get? w).getD 0)).reverse ++ acc.1, acc.2)
  | [], acc, _ => by simp
  | w :: r, acc, h => by
    obtain ⟨t, ht⟩ := h w (by simp)
    have ht' : old[w]? = some t := ht
    rw [List.foldl_cons]
    have : tagStep old acc w = ((w, t) :: acc.1, acc.2) := by simp [tagStep, ht']
    rw [this, tag_fold_known old r _ (fun x hx => h x (List.mem_cons_of_mem _ hx))]
    simp [ht']

/-- A table that lists the elements of working memory, in order, is not changed by `retag`. -/
theorem retag_fixed (s : St) (h : s.tt.map (·.1) = s.raw) : s.retag = s := by
  have hn : (s.tt.map (·.1)).Nodup := by rw [h]; exact dedupW_nodup _
  have hget : ∀ p ∈ s.tt, (insTab s.tt).get? p.1 = some p.2 := fun p hp => by
    unfold insTab
    exact ins_mem p.1 p.2 s.tt {} hn hp
  have hr : ∀ w ∈ s.raw, ∃ t, (insTab s.tt).get? w = some t := by
    intro w hw
    rw [← h] at hw
    obtain ⟨p, hp, rfl⟩ := List.mem_map.mp hw
    exact ⟨p.2, hget p hp⟩
  have hmap : s.raw.map (fun w => (w, ((insTab s.tt).get? w).getD 0)) = s.tt := by
    rw [← h, List.map_map]
    exact (List.map_congr_left (g := id) (fun p hp => by
      simp only [Function.comp, hget p hp, Option.getD_some, id])).trans (List.map_id _)
  have hfold : s.raw.foldl (tagStep (insTab s.tt)) ([], s.tNext) = (s.tt.reverse, s.tNext) := by
    rw [tag_fold_known _ _ _ hr, hmap]
    simp
  have hfilt : s.raw.filter (!(insTab s.tt).contains ·) = [] := by
    rw [List.filter_eq_nil_iff]
    intro w hw
    obtain ⟨t, ht⟩ := hr w hw
    have ht' : (insTab s.tt)[w]? = some t := ht
    simp [Std.HashMap.contains_eq_isSome_getElem?, ht']
  rw [retag_eq, hfold, hfilt]
  unfold St.noteSyms
  simp only [List.foldl_nil, List.reverse_reverse]

/-- The table `retag` builds lists the elements of working memory, in order. -/
theorem retag_keys (s : St) : (s.retag).tt.map (·.1) = s.raw := by
  obtain ⟨a, b, h⟩ := noteSyms_fr (s.raw.filter (!(insTab s.tt).contains ·))
    ({ s with tt := (s.raw.foldl (tagStep (insTab s.tt)) ([], s.tNext)).1.reverse,
              tNext := (s.raw.foldl (tagStep (insTab s.tt)) ([], s.tNext)).2 } : St)
  rw [retag_eq, h]
  simp only
  rw [tag_fold_keys]
  simp

/-- `retag` twice is `retag` once. -/
theorem retag_idem (s : St) : s.retag.retag = s.retag := by
  apply retag_fixed
  rw [retag_keys, (retag_fr s).raw]

/-! ## The desired elements have no repeats -/

theorem desired_aux {V : Type} (L : List ((Nat × Sym × Sym) × V))
    (hL : L.Pairwise (fun a b => (a.1 == b.1) = false))
    (k : ((Nat × Sym × Sym) × V) → Option (Nat × WEnt))
    (hk : ∀ e x, k e = some x → x.2.w.id = e.1.1 ∧ x.2.w.attr = e.1.2.1 ∧ x.2.w.val = e.1.2.2)
    (le : (Nat × WEnt) → (Nat × WEnt) → Bool) :
    ((((L.filterMap k).mergeSort le).map (·.2)).map (·.w)).Nodup := by
  have hp : (((L.filterMap k).mergeSort le).map (fun x => x.2.w)).Nodup := by
    refine ((List.mergeSort_perm _ le).map _).nodup_iff.mpr ?_
    unfold List.Nodup
    rw [List.pairwise_map]
    refine List.Pairwise.filterMap k ?_ hL
    intro a a' hr b hb b' hb' heq
    have h1 := hk a b hb
    have h2 := hk a' b' hb'
    have : a.1 = a'.1 := by
      rcases a with ⟨⟨i, att, v⟩, _⟩
      rcases a' with ⟨⟨i', att', v'⟩, _⟩
      simp only at h1 h2 ⊢
      rw [← h1.1, ← h1.2.1, ← h1.2.2, ← h2.1, ← h2.2.1, ← h2.2.2, heq]
    rw [this] at hr
    simp at hr
  rw [List.map_map]
  exact hp

theorem desired_nodup (s : St) : (s.desired.map (·.w)).Nodup := by
  unfold St.desired
  refine desired_aux _ Std.HashMap.distinct_keys_toList _ ?_ _
  intro e x h
  rcases e with ⟨⟨i, att, v⟩, f, rj, a, r⟩
  simp only [Option.map_eq_some_iff] at h
  obtain ⟨q, _, rfl⟩ := h
  simp

/-! ## The synchronisation step -/

theorem filterMap_self {α : Type} (f : α → Option α) :
    ∀ (l : List α), (∀ x ∈ l, f x = some x) → l.filterMap f = l
  | [], _ => rfl
  | x :: l, h => by
    rw [List.filterMap_cons, h x (by simp), filterMap_self f l (fun y hy => h y (List.mem_cons_of_mem _ hy))]

theorem insW_notmem (k : WME) : ∀ (L : List WEnt) (m : Std.HashMap WME WEnt),
    k ∉ L.map (·.w) → (L.foldl (fun m e => m.insert e.w e) m)[k]? = m[k]?
  | [], m, _ => rfl
  | e :: L, m, h => by
    rw [List.foldl_cons, insW_notmem k L _ (fun hk => h (List.mem_cons_of_mem _ hk))]
    have hne : ¬ (e.w == k) = true := by
      intro hb
      have := LawfulBEq.eq_of_beq hb
      subst this
      exact h (by simp)
    simp [Std.HashMap.getElem?_insert, hne]

theorem insW_mem (e : WEnt) : ∀ (L : List WEnt) (m : Std.HashMap WME WEnt),
    (L.map (·.w)).Nodup → e ∈ L → (L.foldl (fun m e => m.insert e.w e) m)[e.w]? = some e
  | [], m, _, h => by simp at h
  | x :: L, m, hn, h => by
    rw [List.foldl_cons]
    rcases List.mem_cons.mp h with rfl | hm
    · rw [insW_notmem e.w L _ (List.nodup_cons.mp (by simpa using hn)).1]
      simp [Std.HashMap.getElem?_insert]
    · exact insW_mem e L _ (List.nodup_cons.mp (by simpa using hn)).2 hm

theorem insW_some (k : WME) (e : WEnt) : ∀ (L : List WEnt) (m : Std.HashMap WME WEnt),
    (L.foldl (fun m e => m.insert e.w e) m)[k]? = some e → e ∈ L ∨ m[k]? = some e
  | [], m, h => Or.inr h
  | x :: L, m, h => by
    rw [List.foldl_cons] at h
    rcases insW_some k e L _ h with h1 | h1
    · exact Or.inl (List.mem_cons_of_mem _ h1)
    · rw [Std.HashMap.getElem?_insert] at h1
      by_cases hb : (x.w == k) = true
      · simp [hb] at h1; subst h1; exact Or.inl (by simp)
      · simp [hb] at h1; exact Or.inr h1

theorem insW_present (k : WME) : ∀ (L : List WEnt) (m : Std.HashMap WME WEnt),
    k ∈ L.map (·.w) → ((L.foldl (fun m e => m.insert e.w e) m)[k]?).isSome = true
  | [], m, h => by simp at h
  | x :: L, m, h => by
    rw [List.foldl_cons]
    by_cases hk : k ∈ L.map (·.w)
    · exact insW_present k L _ hk
    · have hx : x.w = k := by
        rcases List.mem_map.mp h with ⟨y, hy, rfl⟩
        rcases List.mem_cons.mp hy with rfl | hy
        · rfl
        · exact absurd (List.mem_map.mpr ⟨y, hy, rfl⟩) hk
      rw [insW_notmem k L _ hk]
      simp [Std.HashMap.getElem?_insert, hx]

theorem olds_contains (k : WME) : ∀ (L : List WEnt) (S : Std.HashSet WME),
    (L.foldl (fun m e => m.insert e.w) S).contains k = true ↔ S.contains k = true ∨ k ∈ L.map (·.w)
  | [], S => by simp
  | e :: L, S => by
    rw [List.foldl_cons, olds_contains k L, Std.HashSet.contains_insert]
    simp only [Bool.or_eq_true, beq_iff_eq, List.map_cons, List.mem_cons]
    constructor
    · rintro ((h | h) | h)
      · exact Or.inr (Or.inl h.symm)
      · exact Or.inl h
      · exact Or.inr (Or.inr h)
    · rintro (h | h | h)
      · exact Or.inl (Or.inr h)
      · exact Or.inl (Or.inl h.symm)
      · exact Or.inr h

/-- The slots hold exactly the elements preference memory requires. -/
def Settled (s : St) : Prop := (∀ e ∈ s.slots, e ∈ s.desired) ∧ (∀ e ∈ s.desired, e ∈ s.slots)

theorem dm_get (s : St) (e : WEnt) (he : e ∈ s.desired) :
    (s.desired.foldl (fun m e => m.insert e.w e) ({} : Std.HashMap WME WEnt))[e.w]? = some e :=
  insW_mem e _ _ (desired_nodup s) he

theorem syncPlan_settled {t : St} (h : Settled t) : t.syncPlan = (t.slots, [], []) := by
  unfold St.syncPlan
  simp only
  have hk : t.slots.filterMap (fun e => (t.desired.foldl (fun m e => m.insert e.w e)
      ({} : Std.HashMap WME WEnt)).get? e.w) = t.slots :=
    filterMap_self _ _ (fun e he => dm_get t e (h.1 e he))
  have hn : t.desired.filter (fun e => !(t.slots.foldl (fun m e => m.insert e.w) ({} : Std.HashSet WME)).contains e.w) = [] := by
    rw [List.filter_eq_nil_iff]
    intro e he
    have := (olds_contains e.w t.slots {}).mpr (Or.inr (List.mem_map.mpr ⟨e, h.2 e he, rfl⟩))
    simp [this]
  have hg : t.slots.filter (fun e => !(t.desired.foldl (fun m e => m.insert e.w e)
      ({} : Std.HashMap WME WEnt)).contains e.w) = [] := by
    rw [List.filter_eq_nil_iff]
    intro e he
    have := dm_get t e (h.1 e he)
    simp [Std.HashMap.contains_eq_isSome_getElem?, this]
  rw [hk, hn, hg]

theorem sync_settled {t : St} (hS : Settled t) (hC : t.tt.map (·.1) = t.raw) (m : Nat) :
    t.sync (m + 1) = t := by
  rw [St.sync]
  simp only [syncPlan_settled hS]
  have hstep : t.syncStep (t.slots, [], []) = t := by
    unfold St.syncStep; simp
  rw [hstep]
  have hl : St.syncLost t [] = none := by simp [St.syncLost]
  rw [hl]
  exact retag_fixed t hC

theorem desired_fr {s t : St} (h : TagFr s t) : t.desired = s.desired := by
  obtain ⟨_, _, _, _, rfl⟩ := h; rfl

theorem settled_step (s : St) : Settled (s.syncStep s.syncPlan) := by
  have hd : (s.syncStep s.syncPlan).desired = s.desired := rfl
  have hs : (s.syncStep s.syncPlan).slots = s.syncPlan.1 ++ s.syncPlan.2.1 := rfl
  unfold Settled
  rw [hd, hs]
  unfold St.syncPlan
  simp only
  constructor
  · intro e he
    rcases List.mem_append.mp he with h1 | h1
    · obtain ⟨a, _, ha⟩ := List.mem_filterMap.mp h1
      rcases insW_some a.w e s.desired {} ha with h2 | h2
      · exact h2
      · simp at h2
    · exact (List.mem_filter.mp h1).1
  · intro e he
    by_cases hc : (s.slots.foldl (fun m e => m.insert e.w) ({} : Std.HashSet WME)).contains e.w = true
    · apply List.mem_append_left
      obtain ⟨a, ha, haw⟩ := List.mem_map.mp (((olds_contains e.w s.slots {}).mp hc).resolve_left (by simp))
      refine List.mem_filterMap.mpr ⟨a, ha, ?_⟩
      have := dm_get s e he
      rw [haw]
      exact this
    · apply List.mem_append_right
      exact List.mem_filter.mpr ⟨he, by simpa using hc⟩

theorem settled_retag {s : St} (h : Settled s) : Settled s.retag := by
  have fr := retag_fr s
  unfold Settled
  rw [fr.slots, desired_fr fr]
  exact h

/-- `sync` has finished within `n` steps: the operator cascade ends before the fuel does. -/
def St.syncDone : St → Nat → Prop
  | _, 0 => False
  | s, n + 1 =>
    match St.syncLost (s.syncStep s.syncPlan) s.syncPlan.2.2 with
    | none => True
    | some g => ((s.syncStep s.syncPlan).removeOperator g).syncDone n

theorem sync_result : ∀ (n : Nat) (s : St), s.syncDone (n + 1) →
    Settled (s.sync (n + 1)) ∧ (s.sync (n + 1)).tt.map (·.1) = (s.sync (n + 1)).raw
  | n, s, h => by
    have heq : s.sync (n + 1) = match St.syncLost (s.syncStep s.syncPlan) s.syncPlan.2.2 with
        | some g => ((s.syncStep s.syncPlan).removeOperator g).sync n
        | none => (s.syncStep s.syncPlan).retag := rfl
    unfold St.syncDone at h
    cases hl : St.syncLost (s.syncStep s.syncPlan) s.syncPlan.2.2 with
    | none =>
      rw [heq, hl]
      simp only
      refine ⟨settled_retag (settled_step s), ?_⟩
      rw [retag_keys, (retag_fr _).raw]
    | some g =>
      rw [heq, hl]
      simp only
      rw [hl] at h
      cases n with
      | zero => exact absurd h (by simp [St.syncDone])
      | succ k => exact sync_result k _ h

/-- **Synchronising twice is synchronising once.** If the first `sync` finishes (the cascade of
operator removals ends within its fuel), a second `sync`, with any fuel, changes nothing: the
slots already hold exactly the desired elements, and the table of timetags already lists the
elements of working memory in order. -/
theorem sync_idem (s : St) (n m : Nat) (h : s.syncDone (n + 1)) :
    (s.sync (n + 1)).sync (m + 1) = s.sync (n + 1) := by
  obtain ⟨h1, h2⟩ := sync_result n s h
  exact sync_settled h1 h2 m

end Soar
