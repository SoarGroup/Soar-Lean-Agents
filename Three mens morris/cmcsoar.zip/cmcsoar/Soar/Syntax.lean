import Std.Data.HashSet
/-!
# Soar 9.6 — working memory and the production language

Source: J. E. Laird et al., *The Soar Cognitive Architecture Manual*, version 9.6 ("[Man]").
Section numbers below refer to it. The Introduction to Soar ("[Intro]") is cited where it
states the functional view more directly.

Conventions are those of the CMC files: every definition quotes the passage it formalizes;
`DECIDED` marks a clarification by John Laird (dated); `SIMPLIFIED` marks a deliberate
restriction of this first version; `NOT FORMALIZED` marks a feature recorded but not modelled.
-/

/-- The elements of a list paired with their positions, position first. Lean 4.15's
`List.enum`, which later Lean versions dropped for `List.zipIdx` (position second); kept here
so the specification reads as before. -/
def List.enum (l : List α) : List (Nat × α) := l.zipIdx.map fun (a, i) => (i, a)

theorem List.enum_snd_mem {l : List α} {x : Nat × α} (h : x ∈ l.enum) : x.2 ∈ l := by
  unfold List.enum at h
  obtain ⟨⟨a, i⟩, hm, rfl⟩ := List.mem_map.mp h
  exact List.mem_of_getElem? (List.mem_zipIdx_iff_getElem?.mp hm)

namespace Soar

/-- Loop of `dedupFirst`: `seen` holds the elements of `acc`. -/
def dedupLoop [BEq α] [Hashable α] : List α → Std.HashSet α → List α → List α
  | [], _, acc => acc.reverse
  | x :: xs, seen, acc =>
    if seen.contains x then dedupLoop xs seen acc else dedupLoop xs (seen.insert x) (x :: acc)

/-- First-occurrence de-duplication through a hash set: `List.eraseDups` in linear time
(`dedupFirst_eq`). -/
def dedupFirst [BEq α] [Hashable α] (l : List α) : List α := dedupLoop l {} []

theorem dedupLoop_eq [BEq α] [Hashable α] [EquivBEq α] [LawfulHashable α] :
    ∀ (l : List α) (seen : Std.HashSet α) (acc : List α),
    (∀ y, seen.contains y = acc.any (fun z => y == z)) →
    dedupLoop l seen acc = List.eraseDupsBy.loop (· == ·) l acc
  | [], seen, acc, _ => by simp [dedupLoop, List.eraseDupsBy.loop]
  | x :: xs, seen, acc, h => by
    unfold dedupLoop List.eraseDupsBy.loop
    have hx := h x
    cases hc : seen.contains x
    · rw [hc] at hx
      simp only [Bool.false_eq_true, ite_false, ← hx]
      apply dedupLoop_eq
      intro y
      rw [Std.HashSet.contains_insert, h y]
      simp only [List.any_cons]
      rw [BEq.comm (a := x) (b := y)]
    · rw [hc] at hx
      simp only [ite_true, ← hx]
      exact dedupLoop_eq xs seen acc h

theorem dedupFirst_eq [BEq α] [Hashable α] [EquivBEq α] [LawfulHashable α] (l : List α) :
    dedupFirst l = l.eraseDups := by
  unfold dedupFirst List.eraseDups List.eraseDupsBy
  exact dedupLoop_eq l {} [] (by simp)


/-! ## Symbols and working-memory elements -/

/-- Symbols.

> "Soar distinguishes between two types of working memory symbols: identifiers and
> constants. … There are three types of constants: integers, floating-point, and symbolic
> constants" — [Man] §3.1.1

Identifiers are numbered; Soar's letter-plus-number names (`S1`, `O3`) are a printing
convention. A floating-point constant is stored as the bit pattern of its IEEE double, so
symbols keep decidable equality. -/
inductive Sym where
  | id  : Nat → Sym
  | str : String → Sym
  | int : Int → Sym
  | float : UInt64 → Sym
  deriving DecidableEq, Repr, Inhabited, Hashable

def Sym.ofFloat (f : Float) : Sym := .float f.toBits

/-- The numeric value of a number. -/
def Sym.num? : Sym → Option Float
  | .int i => some (Float.ofInt i)
  | .float b => some (Float.ofBits b)
  | _ => none

def Sym.isId : Sym → Bool
  | .id _ => true
  | _ => false

def Sym.nil : Sym := .str "nil"

instance : Coe String Sym := ⟨Sym.str⟩

/-- A working-memory element: an identifier–attribute–value triple. Acceptable preferences
for operators also appear in working memory, as quadruples marked `+` (`acc := true`).

> "each WME is an identifier-attribute-value triple, and all WMEs with the same identifier
> are part of the same object." — [Man] §2.2
>
> "The acceptable preferences for operators appear in working memory as
> identifier-attribute-value-preference quadruples. No other preferences appear in working
> memory." — [Man] §3.1.4

NOT FORMALIZED here: timetags ([Man] §3.1.3). Working memory is a set of triples in this
structure; a WME that is removed and re-created is the same element. The Rete model
(Soar/Rete.lean) assigns timetags, as Soar does. -/
structure WME where
  id   : Nat
  attr : Sym
  val  : Sym
  acc  : Bool := false
  deriving DecidableEq, Repr, Inhabited, Hashable

/-! ## Conditions -/

/-- Relational predicates usable in tests.

> "There are six general predicates that can be used: <>, <=>, <, <=, >=, >." — [Man]
> §3.3.5.3

Equality is expressed by a variable or constant test. NOT FORMALIZED: the long-term
identifier predicates `@`, `!@`, `@+`, `@-` (they belong to semantic memory). -/
inductive RelOp where
  | ne | sameType | lt | le | ge | gt
  deriving DecidableEq, Repr

/-- A term in a production: a variable or a constant. Identifiers never appear literally.

> "Because the identifiers of objects are determined at runtime, literal identifiers cannot
> appear in productions." — [Man] §2.3.1.1 -/
inductive Term where
  | var : String → Term
  | sym : Sym → Term
  deriving DecidableEq, Repr

/-- One simple test on a symbol. -/
inductive STest where
  /-- A variable: binds on first occurrence, must agree thereafter. -/
  | var  : String → STest
  /-- A constant. -/
  | const : Sym → STest
  /-- A relational test against a term. -/
  | rel  : RelOp → Term → STest
  /-- A disjunction of constants, `<< a b c >>`. -/
  | disj : List Sym → STest
  /-- `@+` (`true`): the value is an identifier linked to a long-term identifier; `@-`
  (`false`): it is not. -/
  | lti : Bool → STest
  /-- `@ x` (`true`): the value and `x` are linked to the same long-term identifier (or `x` is
  its number); `!@ x` (`false`): they are not. -/
  | ltiRel : Bool → Term → STest
  deriving DecidableEq, Repr

/-- A test is a conjunction of simple tests (`{ … }`); the empty conjunction matches any
symbol.

> "<conjunctive_test> ::= "{" <simple_test>+ "}"" — [Man] §3.3.7.1 -/
abbrev Test := List STest

/-- A pattern for one working-memory element. `acc` selects the acceptable-preference form
`(<s> ^operator <o> +)`.

SIMPLIFIED: attribute-path notation and multi-attribute shorthand ([Man] §3.3.5.8–11) are
syntactic sugar for several patterns and are written out. -/
structure Pat where
  id   : Test
  attr : Test
  val  : Test
  acc  : Bool := false
  /-- The identifier must be a state (the `state` keyword, Soar's goal test). -/
  goal : Bool := false
  deriving DecidableEq, Repr

/-- A negated conjunction: its positive patterns and its inner negated conjunctions. -/
inductive NegTree where
  | node : List Pat → List NegTree → NegTree

instance : Inhabited NegTree := ⟨.node [] []⟩

/-- A negated conjunction written as its nodes in preorder, each with its depth (0 for the
outermost): the children of a node are the nodes after it one level deeper, up to the next
node at its level or above. -/
abbrev NegNodes := List (Nat × List Pat)

/-- The tree of a preorder list of nodes. -/
partial def NegNodes.tree (ns : NegNodes) : NegTree :=
  match ns with
  | [] => .node [] []
  | (d, ps) :: rest =>
    -- the children: maximal runs starting at depth d + 1
    let body := rest.takeWhile (·.1 > d)
    let rec kids (xs : NegNodes) (acc : List NegTree) : List NegTree :=
      match xs with
      | [] => acc.reverse
      | x :: xr =>
        let sub := xr.takeWhile (·.1 > x.1)
        kids (xr.drop sub.length) ((NegNodes.tree (x :: sub)) :: acc)
    .node ps (kids body [])

/-- Every pattern of a negated conjunction, at any depth. -/
def NegNodes.pats (ns : NegNodes) : List Pat := ns.flatMap (·.2)
/-- A condition: a positive pattern, or a negated conjunction of patterns (a single negated
condition is a one-element conjunction).

> "A negated condition will be matched only if there does not exist a working memory element
> consistent with its tests and variable bindings." — [Man] §3.3.5.6
>
> "Conditions can be grouped into conjunctive sets … This grouping allows for negated tests
> of more than one working memory element at a time." — [Man] §3.3.5.7

SIMPLIFIED: negations inside a negated conjunction do not nest further (the matcher's
completeness is proved for one level of inner negations; see STATUS.md). -/
inductive Cond where
  | pos : Pat → Cond
  | neg : List Pat → Cond
  /-- A negated conjunction that itself contains negations, `-{ P₁ … -(Q …) … }`: it succeeds
  when no extension of the bindings matching the positive patterns makes every inner negation
  succeed. (One level of nesting.) -/
  | ncc : List Pat → List (List Pat) → Cond
  /-- A negated conjunction nested to any depth (Soar allows any; `ncc` covers one level):
  `-{ P₁ … Pₙ N₁ … Nₖ }` with positive patterns `Pᵢ` and inner negations `Nⱼ`, themselves of
  the same form. -/
  | nccg : NegNodes → Cond
  deriving DecidableEq, Repr

/-- Every pattern of a condition: a positive one's, a negated conjunction's, and those of the
negations inside it. -/
def Cond.pats : Cond → List Pat
  | .pos p => [p]
  | .neg ps => ps
  | .ncc ps ns => ps ++ ns.flatten
  | .nccg ns => ns.pats

/-- Apply `f` to every pattern of a condition, keeping its shape. -/
def Cond.mapPats (f : Pat → Pat) : Cond → Cond
  | .pos p => .pos (f p)
  | .neg ps => .neg (ps.map f)
  | .ncc ps ns => .ncc (ps.map f) (ns.map (·.map f))
  | .nccg ns => .nccg (ns.map fun (d, ps) => (d, ps.map f))

/-! ## Actions -/

/-- The eleven preference types ([Man] §2.4.1, §3.3.6.4). Numeric-indifferent values are
integers here (SIMPLIFIED: Soar uses floating point). -/
inductive PrefKind where
  | acceptable | reject | require | prohibit
  | best | worst | better | worse
  | unaryIndiff | binaryIndiff | numericIndiff
  deriving DecidableEq, Repr

/-- A value on the right-hand side: a variable, a constant, or a call of a right-hand-side
function. A variable not bound by the conditions denotes a new identifier, created once per
instantiation.

> "(<s> ^block <*b>) (<*b> ^color red)" — [Man] §3.3.6.2 (new identifiers on the RHS)
>
> "Right-hand side functions allow productions to create side effects other than changing
> working memory." — [Man] §3.3.6.6

Supported functions: `+ - * div mod abs int concat crlf` (values) and `write`, `halt`
(actions). SIMPLIFIED: floating-point arithmetic and `/` are not included. -/
inductive RVal where
  | var  : String → RVal
  | sym  : Sym → RVal
  | call : String → List RVal → RVal
  deriving Repr, Inhabited, BEq

/-- An action.

> "Generally, actions of a production either create preferences for operator selection, or
> create/remove working memory elements." — [Man] §2.3.3

-/
inductive Action where
  /-- `(<id> ^attr val)` -/
  | make   : String → RVal → RVal → Action
  /-- `(<id> ^attr val -)`: removal (a reject of a WME). -/
  | remove : String → RVal → RVal → Action
  /-- `(<s> ^operator <o> k [<o2> | n])`: a preference for an operator of state `<s>`. -/
  | pref   : String → RVal → PrefKind → Option RVal → Option Sym → Action
  /-- `(halt)` -/
  | halt   : Action
  /-- `(write …)`: text output. -/
  | write  : List RVal → Action
  /-- `(cmd …)`: a command-line command, as its words (only `epmem --set` is acted on). -/
  | cmd    : List String → Action
  deriving Repr, BEq

/-- A production.

> "Each production has three required components: a name, a set of conditions (also called
> the left-hand side, or LHS), and a set of actions (also called the right-hand side, or
> RHS)." — [Man] §3.3
>
> "The first condition in a production must match against a state in working memory." —
> [Man] §3.3.5.1 -/
structure Production where
  name  : String
  conds : List Cond
  acts  : List Action
  /-- Variables marked `$` (or `$$`): chunking makes them constants in a learned rule
  (Laird, 2026-10-29; Soar 9.6.5 "constant match literalization"). -/
  lits  : List String := []
  /-- `:o-support` (`some true`) or `:i-support` (`some false`) declared in the production. -/
  support : Option Bool := none
  /-- `:template`: an RL template ([Man] §5.4.2), which makes RL rules instead of firing. -/
  template : Bool := false
  deriving Repr

/-! ## Printing productions as Soar source

The same productions can be loaded into a Soar 9.6 kernel, which lets the formal model be
checked against the reference implementation run by run. -/

/-- Characters other than letters and digits that Soar reads as part of a symbol. -/
def extraConstituents : List Char := "$%&*+-/:<=>?_@".toList

/-- Does a symbolic constant need `|…|` quoting to be read back as itself? Soar 9.6.5's rule
(`make_string_rereadable`, `determine_possible_symbol_types_for_string`): quote unless every
character is a constituent (letters, digits and the characters of `extraConstituents`), the string could not be read as
a number, variable or identifier, and it is all letters and digits, or longer than three
characters, or `*`. -/
def needsQuote (t : String) : Bool :=
  let cs := t.toList
  let constituent (c : Char) : Bool := c.isAlphanum || extraConstituents.contains c
  let allC := cs.all constituent
  let allAlnum := cs.all Char.isAlphanum
  let rereadable := allC && (allAlnum || cs.length > 3 || t == "*")
  let body := match cs with
    | c :: r => if c == '+' || c == '-' then r else cs
    | [] => []
  let digits := body.takeWhile Char.isDigit
  let rest := body.drop digits.length
  let numStart := match cs with
    | c :: _ => c == '+' || c == '-' || c == '.' || c.isDigit
    | [] => false
  let possibleInt := numStart && rest.isEmpty && !digits.isEmpty
  let possibleFloat := numStart && match rest with
    | '.' :: r =>
      let r := r.dropWhile Char.isDigit
      let r := match r with
        | 'e' :: r' | 'E' :: r' =>
          let r' := match r' with | '+' :: x | '-' :: x => x | x => x
          r'.dropWhile Char.isDigit
        | r => r
      r.isEmpty
    | _ => false
  let possibleVar := allC && cs.head? == some '<' && cs.getLast? == some '>'
  let possibleId := allC && match cs with
    | c :: r => c.isAlpha && !r.isEmpty && r.all Char.isDigit
    | [] => false
  t.isEmpty || !allC || possibleVar || possibleInt || possibleFloat || possibleId || !rereadable

/-- A double printed as C++'s `std::fixed` with `p` digits after the point (exactly, ties to
even, as glibc does). Soar prints real numbers this way: 6 digits by default
(`Symbol::to_string`), 17 for `string`. -/
def fixedStrBits (bits : UInt64) (p : Nat) : String :=
  let x := Float.ofBits bits
  if ((bits >>> 52) &&& 0x7ff) == 0x7ff && (bits &&& 0xfffffffffffff) != 0 then
    (if bits >>> 63 == 1 then "-nan" else "nan")
  else if x.isInf then (if x < 0 then "-inf" else "inf") else
  let neg := bits >>> 63 == 1
  let e := ((bits >>> 52) &&& 0x7ff).toNat
  let f := (bits &&& 0xfffffffffffff).toNat
  -- |x| = m · 2^(ex), ex possibly negative
  let (m, ex) : Nat × Int := if e == 0 then (f, -1074) else (f + 2 ^ 52, (e : Int) - 1075)
  let scaled := m * 10 ^ p
  let q : Nat :=
    if ex ≥ 0 then scaled * 2 ^ ex.toNat
    else
      let d := 2 ^ (-ex).toNat
      let q₀ := scaled / d
      let r := scaled % d
      if 2 * r > d || (2 * r == d && q₀ % 2 == 1) then q₀ + 1 else q₀
  let digits := toString q
  let digits := if digits.length ≤ p then String.ofList (List.replicate (p + 1 - digits.length) '0') ++ digits else digits
  let ip := digits.take (digits.length - p)
  let fp := digits.drop (digits.length - p)
  (if neg then "-" else "") ++ ip.toString ++ (if p == 0 then "" else "." ++ fp.toString)

def Sym.toSoar : Sym → String
  | .id n => s!"#ID{n}"
  -- quoted with bars, a bar or backslash inside escaped (Soar's `string_to_escaped_string`)
  | .str s => if needsQuote s then "|" ++ String.join (s.toList.map fun c =>
      if c == '|' || c == '\\' then "\\" ++ c.toString else c.toString) ++ "|" else s
  | .int i => toString i
  | .float b => fixedStrBits b 6

def RelOp.toSoar : RelOp → String
  | .ne => "<>" | .sameType => "<=>" | .lt => "<" | .le => "<=" | .ge => ">=" | .gt => ">"

def Term.toSoar : Term → String
  | .var v => s!"<{v}>"
  | .sym s => s.toSoar

def STest.toSoar : STest → String
  | .var v => s!"<{v}>"
  | .const c => c.toSoar
  | .rel r t => s!"{r.toSoar} {t.toSoar}"
  | .disj cs => "<< " ++ " ".intercalate (cs.map Sym.toSoar) ++ " >>"
  | .lti b => if b then "@+" else "@-"
  | .ltiRel b t => (if b then "@ " else "!@ ") ++ t.toSoar

/-- Print a test; the empty test needs a placeholder variable. -/
def testToSoar (fresh : String) : Test → String
  | [] => s!"<{fresh}>"
  | [t] => t.toSoar
  | ts => "{ " ++ " ".intercalate (ts.map STest.toSoar) ++ " }"

def Pat.toSoar (k : Nat) (first : Bool) (p : Pat) : String :=
  let st := if first then "state " else ""
  s!"({st}{testToSoar s!"_i{k}" p.id} ^{testToSoar s!"_a{k}" p.attr} " ++
    s!"{testToSoar s!"_v{k}" p.val}{if p.acc then " +" else ""})"

def Cond.toSoar (k : Nat) (first : Bool) : Cond → String
  | .pos p => p.toSoar k first
  | .neg [p] => "-" ++ p.toSoar k false
  | .neg ps => "-{ " ++ " ".intercalate ((ps.zip (List.range ps.length)).map
      (fun (p, i) => p.toSoar (100 * (k + 1) + i) false)) ++ " }"
  | .ncc ps ns => "-{ " ++ " ".intercalate ((ps.zip (List.range ps.length)).map
      (fun (p, i) => p.toSoar (100 * (k + 1) + i) false)) ++ " " ++ " ".intercalate ((ns.zip (List.range ns.length)).map
      (fun (n, j) => "-{ " ++ " ".intercalate ((n.zip (List.range n.length)).map
        (fun (p, i) => p.toSoar (10000 * (k + 1) + 100 * j + i) false)) ++ " }")) ++ " }"
  | .nccg ns =>
    -- each node opens a `-{`, closed when the next node is no deeper
    let rec go (xs : NegNodes) (j : Nat) (open' : List Nat) : String :=
      match xs with
      | [] => String.join (open'.map fun _ => " }")
      | (d, ps) :: r =>
        let closing := open'.takeWhile (· ≥ d)
        String.join (closing.map fun _ => " }") ++ " -{ " ++
          " ".intercalate ((ps.zip (List.range ps.length)).map (fun (p, i) => p.toSoar (1000000 * (k + 1) + 100 * j + i) false)) ++
          go r (j + 1) (d :: open'.drop closing.length)
    (go ns 0 []).trimAscii.toString

def PrefKind.toSoar : PrefKind → String
  | .acceptable => "+" | .reject => "-" | .require => "!" | .prohibit => "~"
  | .best => ">" | .worst => "<" | .better => ">" | .worse => "<"
  | .unaryIndiff => "=" | .binaryIndiff => "=" | .numericIndiff => "="

partial def RVal.toSoar : RVal → String
  | .var v => s!"<{v}>"
  | .sym s => s.toSoar
  | .call f args => "(" ++ " ".intercalate (f :: args.map RVal.toSoar) ++ ")"

def Action.toSoar : Action → String
  | .make i a v => s!"(<{i}> ^{a.toSoar} {v.toSoar})"
  | .remove i a v => s!"(<{i}> ^{a.toSoar} {v.toSoar} -)"
  | .pref s o k other num =>
      let tail := match other, num with
        | some o2, _ => " " ++ o2.toSoar
        | none, some n => " " ++ n.toSoar
        | none, none => ""
      s!"(<{s}> ^operator {o.toSoar} {k.toSoar}{tail})"
  | .halt => "(halt)"
  | .write vs => "(write " ++ " ".intercalate (vs.map RVal.toSoar) ++ ")"
  | .cmd ("link-stm-to-ltm" :: ws) => "(link-stm-to-ltm " ++ " ".intercalate ws ++ ")"
  | .cmd ws => "(cmd " ++ " ".intercalate ws ++ ")"

def Production.toSoar (p : Production) : String :=
  let cs := (p.conds.zip (List.range p.conds.length)).map (fun (c, i) => c.toSoar i (i == 0))
  "sp {" ++ p.name ++ "\n   " ++ "\n   ".intercalate cs ++ "\n-->\n   " ++
    "\n   ".intercalate (p.acts.map Action.toSoar) ++ "\n}"

/-! ## A small notation for writing productions in Lean -/

namespace DSL
/-- `v "x"` is the variable `<x>`; `c "red"` the constant `red`. -/
def v (s : String) : Test := [.var s]
def c (s : String) : Test := [.const (.str s)]
def ci (n : Int) : Test := [.const (.int n)]
def any : Test := []
def pat (i a val : Test) : Cond := .pos { id := i, attr := a, val := val }
def acc (i a val : Test) : Cond := .pos { id := i, attr := a, val := val, acc := true }
def nopat (i a val : Test) : Cond := .neg [{ id := i, attr := a, val := val }]
def rv (s : String) : RVal := .var s
def rc (s : String) : RVal := .sym (.str s)
def ri (n : Int) : RVal := .sym (.int n)
end DSL

/-- A relation that is reflexive-by-nil and transitive, and holds for each step of a fold, holds
for the whole fold. One lemma for the inductions over `foldl` in the proofs. -/
theorem foldl_rel {α β : Type} (R : β → β → Prop) (htrans : ∀ a b c, R a b → R b c → R a c)
    (hrefl : ∀ a, R a a) (f : β → α → β) (hf : ∀ s a, R s (f s a)) :
    ∀ (l : List α) (s : β), R s (l.foldl f s)
  | [], s => hrefl s
  | a :: l, s => htrans _ _ _ (hf s a) (foldl_rel R htrans hrefl f hf l _)

/-! ### Association lists

The tables of the model that are small and whose order is read (or compared with Soar's) are
association lists; these are the one set of operations on them. -/

/-- The value of key `k`. -/
def alGet {α β : Type} [BEq α] (l : List (α × β)) (k : α) : Option β := (l.find? (·.1 == k)).map (·.2)
/-- Set key `k` to `v`, moving it to the front. -/
def alSet {α β : Type} [BEq α] (l : List (α × β)) (k : α) (v : β) : List (α × β) := (k, v) :: l.filter (·.1 != k)
/-- Set key `k` to `v`, moving it to the end (the order in which Soar's tables are appended to). -/
def alPut {α β : Type} [BEq α] (l : List (α × β)) (k : α) (v : β) : List (α × β) := (l.filter (·.1 != k)) ++ [(k, v)]
/-- Remove key `k`. -/
def alErase {α β : Type} [BEq α] (l : List (α × β)) (k : α) : List (α × β) := l.filter (·.1 != k)

/-- Closes a goal of the form `⟨_ = _, _ = _⟩` that holds by `rfl` in every branch of the `if`s
and `match`es the goal contains (the shape of the `_same` frame lemmas). -/
syntax "split_rfl" : tactic
macro_rules
  | `(tactic| split_rfl) => `(tactic| first | (split <;> split_rfl) | exact ⟨rfl, rfl⟩)

end Soar
