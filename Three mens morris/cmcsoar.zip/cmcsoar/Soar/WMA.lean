import Soar.Syntax
import Std.Data.HashMap
/-!
# Soar 9.6 — working-memory activation: decay elements and their arithmetic

Working-memory activation (Soar 9.6.5 `working_memory_activation.cpp`; [Man] §9.3.2.1 `wma`)
gives each o-supported working-memory element a *decay element*: a history of the decision
cycles in which it was referenced and how often. Its activation in cycle `t` is

  log Σᵢ nᵢ · (t − tᵢ)^d

over the history (at most ten entries, `d` the decay rate, −0.5 by default), and an element
whose activation falls below the decay threshold can be forgotten. This file holds the data
and the arithmetic; when elements are referenced, and forgetting, are in `Soar.Cycle`.
-/

namespace Soar

/-- `wma --set forgetting`: off, naive (a sweep every cycle), bsearch (the cycle an element
falls below the threshold, found by binary search) and on (`approx`: estimated first). -/
inductive WForget where
  | off | naive | bsearch | approx
  deriving Repr, BEq, DecidableEq, Inhabited

structure WmaParams where
  on         : Bool := false
  /-- `decay-rate`, stored negated as Soar stores it (`wma_decay_param`). -/
  decay      : Float := -0.5
  /-- `decay-thresh`, stored negated. -/
  thresh     : Float := -2.0
  petrov     : Bool := false
  forgetting : WForget := .off
  /-- `forget-wme lti`: forget only elements of identifiers linked to an LTI, and only all of an
  identifier's o-supported elements together. -/
  forgetLti  : Bool := false
  fake       : Bool := false
  deriving Repr, Inhabited

/-- `WMA_DECAY_HISTORY`, `WMA_REFERENCES_PER_DECISION`, `WMA_ACTIVATION_LOW`,
`WMA_ACTIVATION_NONE`, `WMA_TIME_SUM_NONE`. -/
def wmaHistory : Nat := 10
def wmaRefsPerDecision : Nat := 50
def wmaLow : Float := -1000000000
def wmaNone : Float := 1.0
def wmaTimeSumNone : Float := 2.71828182845905

/-- A decay element (`wma_decay_element`). -/
structure WDecay where
  /-- References made since the last history update (`num_references`). -/
  refs        : Nat := 0
  /-- The history, most recent first: (decision cycle, references). -/
  hist        : List (Nat × Nat) := []
  /-- References in the history, in all, and the cycle of the first one. -/
  histRefs    : Nat := 0
  total       : Nat := 0
  first       : Nat := 0
  justCreated : Bool := true
  /-- The cycle at which forgetting looks at it (`forget_cycle`); `none` is Soar's −1, `some 0`
  marks an element found to be forgotten. -/
  forgetCycle : Option Nat := none
  /-- The LTI the element's identifier stood for when the decay element was made (0 if none;
  Soar's `smem_wmas`), the order in which decay elements were made, and the number of history
  updates (which fixes the ring-buffer position of each entry). -/
  lti         : Nat := 0
  born        : Nat := 0
  recs        : Nat := 0
  deriving Repr, Inhabited

namespace WmaParams

/-- `wma_pow`: Soar's power cache holds 0 for a difference of 0. -/
def wpow (p : WmaParams) (diff : Nat) : Float :=
  if diff == 0 then 0 else Float.pow diff.toFloat p.decay

/-- Subtraction of cycles as Soar's unsigned 64-bit `wma_d_cycle` does it. -/
def cycSub (a b : Nat) : Nat := (UInt64.ofNat a - UInt64.ofNat b).toNat

/-- `cycSub` as arithmetic on natural numbers (what it was written as before the 64-bit form, which
avoids big-number arithmetic for every history entry). -/
theorem cycSub_eq (a b : Nat) : cycSub a b = (a + 2 ^ 64 - b % 2 ^ 64) % 2 ^ 64 := by
  unfold cycSub
  rw [UInt64.toNat_sub, UInt64.toNat_ofNat', UInt64.toNat_ofNat']
  have h : (2:Nat)^64 = 18446744073709551616 := by decide
  simp only [h]
  omega

/-- `wma_sum_history`: newest entry first, with Petrov's approximation of the references
beyond the history if `petrov-approx` is on (with decay rate 1 this divides 0 by 0, as in
Soar). -/
def sumHist (p : WmaParams) (e : WDecay) (cur : Nat) : Float :=
  let (sum, last) := e.hist.foldl (fun (acc : Float × Nat) (dc, n) =>
    (acc.1 + n.toFloat * p.wpow (cycSub cur dc), cycSub cur dc)) (0, 0)
  if p.petrov && e.total > e.histRefs then
    let dInv := 1 + p.decay
    sum + ((e.total - e.histRefs).toFloat * (Float.pow (cycSub cur e.first).toFloat dInv - Float.pow last.toFloat dInv)) /
      (dInv * (cycSub (cycSub cur e.first) last).toFloat)
  else sum

/-- `wma_calculate_decay_activation`. -/
def decayAct (p : WmaParams) (e : WDecay) (cur : Nat) (logResult : Bool) : Float :=
  if e.hist.isEmpty then (if logResult then wmaLow else 0) else
  let s := p.sumHist e cur
  if !logResult then s else if s > 0 then Float.log s else wmaLow

/-- `exp(decay-thresh)`, the threshold for time sums. -/
def threshExp (p : WmaParams) : Float := Float.exp p.thresh

/-- `wma_approx_array`: the cycles after which `i` references alone fall below the threshold. -/
def approx (p : WmaParams) (i : Nat) : Nat :=
  if i == 0 then 0 else (Float.ceil (Float.exp ((p.thresh - Float.log i.toFloat) / p.decay))).toUInt64.toNat

/-- `wma_forgetting_estimate_cycle`: the cycle at which an element's activation will have
fallen below the threshold, from cycle `cur`. With `approx` and a fresh reference the estimate
adds, per history entry, the cycles its references alone would last; otherwise (or if that adds
nothing) the cycle is found by doubling and binary search, in Soar's unsigned 64-bit cycles (an
element with very many references — see `St.wmaBoost` — overflows the doubling to 0, and is
estimated to fall below the threshold now). -/
def estimate (p : WmaParams) (e : WDecay) (cur : Nat) (fresh : Bool) : Nat := Id.run do
  let mut ret := cur
  if fresh && p.forgetting == .approx then
    let toAdd := e.hist.foldl (fun acc (dc, n) =>
      let diff := ret - dc
      let a := p.approx (if n < wmaRefsPerDecision then n else wmaRefsPerDecision - 1)
      if a > diff then acc + (a - diff) else acc) 0
    ret := ret + toAdd
  if ret == cur then
    let th := p.threshExp
    let mut toAdd := 1
    let mut act := p.decayAct e ((ret + toAdd) % 2 ^ 64) false
    if act ≥ th then
      for _ in [0:70] do
        if act ≥ th then
          toAdd := (toAdd * 2) % 2 ^ 64
          act := p.decayAct e ((ret + toAdd) % 2 ^ 64) false
        else break
      let upper0 := toAdd
      let mut upper := upper0
      let mut lower := if toAdd < 4 then upper0 else toAdd / 2
      for _ in [0:128] do
        if lower != upper then
          let mid := (lower + upper) / 2
          let a := p.decayAct e ((ret + mid) % 2 ^ 64) false
          if a < th then
            upper := mid
            if upper - lower ≤ 1 then lower := mid
          else
            lower := mid
            if upper - lower ≤ 1 then lower := upper
        else break
      toAdd := upper
    ret := ret + toAdd
  return ret

end WmaParams

/-- `wma_update_decay_histories` for one element at cycle `cur`: its new references become
the newest history entry (the oldest of ten is dropped). -/
def WDecay.record (e : WDecay) (cur : Nat) : WDecay :=
  let dropped := if e.hist.length == wmaHistory then (e.hist.getLast?.map (·.2)).getD 0 else 0
  { e with histRefs := e.histRefs + e.refs - dropped,
           hist := ((cur, e.refs) :: e.hist).take wmaHistory,
           first := if e.total == 0 then cur else e.first,
           total := e.total + e.refs, refs := 0, recs := e.recs + 1 }

/-- The state of working-memory activation: the activation clock (`wma_d_cycle_count`), the
decay elements by timetag, the elements referenced since the last history update
(`wma_touched_elements`), each i-supported preference's set of o-supported elements it depends
on (`wma_o_set`, by timetag), references to slot values not yet in working memory
(`wma_val_references`), the slots changed in the current elaboration cycle, and the forgetting
queue (cycle ↦ timetags). -/
structure WmaSt where
  cycle    : Nat := 1
  els      : Std.HashMap Nat WDecay := {}
  touched  : List Nat := []
  osets    : List (Nat × List Nat) := []
  slotRefs : List ((Nat × Sym × Sym) × Nat) := []
  changed  : List (Nat × Sym) := []
  pq       : List (Nat × List Nat) := []
  /-- Reads, in Soar, of the preference of an element no longer in working memory, whose
  preference has been freed (see `St.wmaStale`): where these occur, Soar's result depends on
  how its memory pool reuses the preference. -/
  stale    : Nat := 0
  /-- Decay elements made so far, and edge updates recorded for spreading activation's
  `spreading-edge-updating` (parent LTI, child LTI, references, cycle), not yet passed to
  semantic memory. -/
  born     : Nat := 0
  edgeLog  : List (Nat × Nat × Float × Nat) := []
  deriving Repr, Inhabited

namespace WmaSt
def el (a : WmaSt) (tt : Nat) : Option WDecay := a.els.get? tt
def setEl (a : WmaSt) (tt : Nat) (e : WDecay) : WmaSt :=
  { a with els := a.els.insert tt e }
def touch (a : WmaSt) (tt : Nat) : WmaSt :=
  if a.touched.contains tt then a else { a with touched := a.touched ++ [tt] }
/-- Add `n` references to element `tt`, if it has a decay element. -/
def addRefs (a : WmaSt) (tt n : Nat) : WmaSt :=
  match a.el tt with
  | some e => (a.setEl tt { e with refs := e.refs + n }).touch tt
  | none => a
def markStale (a : WmaSt) : WmaSt := { a with stale := a.stale + 1 }
/-- Move element `tt` in the forgetting queue to cycle `c`. -/
def requeue (a : WmaSt) (tt c : Nat) : WmaSt :=
  let pq := a.pq.map (fun (k, ts) => (k, ts.filter (· != tt)))
  let pq := if pq.any (·.1 == c) then pq.map (fun (k, ts) => if k == c then (k, ts ++ [tt]) else (k, ts))
    else pq ++ [(c, [tt])]
  { a with pq := pq.filter (!·.2.isEmpty) }
end WmaSt

/-- C's `%0.2g`: two significant digits, the shorter of fixed and exponent notation, trailing
zeros dropped (how `print` shows an element's activation). -/
def fmtG2 (x : Float) : String :=
  if x == 0 then "0" else
  let neg := x < 0
  let a := if neg then -x else x
  -- exponent of the value rounded to two significant digits
  let e0 := (Float.floor (Float.log10 a)).toInt64.toInt
  let r := Float.round (a / Float.pow 10 (Float.ofInt (e0 - 1)))
  let (r, e) := if r ≥ 100 then (Float.round (r / 10), e0 + 1) else (r, e0)
  let digits := r.toUInt64.toNat   -- two digits, 10..99
  let d1 := digits / 10
  let d2 := digits % 10
  let body :=
    if e < -4 || e ≥ 2 then
      let mant := if d2 == 0 then s!"{d1}" else s!"{d1}.{d2}"
      let es := if e < 0 then s!"-{if -e < 10 then "0" else ""}{-e}" else s!"+{if e < 10 then "0" else ""}{e}"
      s!"{mant}e{es}"
    else if e == 1 then s!"{digits}"
    else if e == 0 then (if d2 == 0 then s!"{d1}" else s!"{d1}.{d2}")
    else
      -- e < 0: 0.00dd
      let zeros := String.ofList (List.replicate ((-e - 1).toNat) '0')
      if d2 == 0 then s!"0.{zeros}{d1}" else s!"0.{zeros}{d1}{d2}"
  if neg then "-" ++ body else body

end Soar
