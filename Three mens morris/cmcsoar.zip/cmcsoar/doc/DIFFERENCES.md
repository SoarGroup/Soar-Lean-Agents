# Remaining differences from Soar 9.6.5, and how each was diagnosed

As of October 31, 2026, every program in tests/ matches Soar 9.6.5 except those below. Each is
traced to Soar's undefined or address-dependent behaviour, not to the specification. The kernel
defects named are described, with source locations and fixes, in
doc/Soar-9.6.5-Kernel-Defects.docx.

## epwma f014 (episodic memory with working-memory activation)

- **What differs:** episodes 17–21 (21 decisions, 1551 elements).
- **Cause:** with the default `graph-match-ordering undefined`, Soar sorts the cue's literals
  by their memory addresses before the graph match (`epmem_process_query`, kernel defect 4).
  The cue unifies with an episode in more than one way, and Soar's choice of mapping, copied
  into working memory by the program, depends on the addresses.
- **Evidence:** with `epmem --set graph-match-ordering dfs` the program matches. The model
  takes the literals in the order they are made.

## epfuzz2 f229 (episodic memory, graph match)

- **What differs:** the last episode (15 decisions, about 3,330 elements), and with it four
  elements copied from a retrieval. The program matched in earlier regression runs on October
  31 and differs in later ones, with Soar's own working memory changing size between runs
  (3,332 and 3,336 elements), the model's run unchanged.
- **Cause:** the same as f014: `graph-match-ordering undefined` sorts the cue's literals by
  memory address (kernel defect 4), and the cue unifies with the episode in more than one way.
  Which mapping Soar returns depends on the addresses the allocator hands out, so the result
  varies between processes.
- **Evidence:** with `epmem --set graph-match-ordering dfs` added to the program it matches.

## realsmem SMemFunctionalTests_testSpreadingActivation_AlphabetAgentAllOn

- **What differs:** four working-memory activations; decisions, working memory and the store
  match (60 decisions).
- **Cause:** Soar reads freed preferences when it builds o-sets and initial boosts (kernel
  defect 22). What it reads depends on which preference the pool has put in the freed memory.
- **Evidence:** `soar-lean --wma-debug F` counts each read of a freed preference that Soar
  would make (the `stale` count), and the agent makes such reads. The mechanism is shown in
  isolation by bugs/wma-stale-preference.soar, where the model gives the references the rules
  call for and Soar one more.

## Spreading activation with edge updating (9 of 30 generated programs, not in tests/)

- **What differs:** edge weights after updating, and the spread values that use them.
- **Cause:** Soar records an edge update for an element whose value is a constant, reading
  the constant as an identifier past the end of its memory (kernel defect 24). Whether a
  phantom update happens depends on that memory.
- **Evidence:** an edge of weight 1 became 0.980 in a program whose only LTI-valued element on
  that identifier was to its real child. The model records updates only for identifier values.

## Resolved October 31: 8 spreading-activation programs (smemspread)

- **What differed:** an element of a log entry recording a bad command started with 25
  activation references in the model and 26 in Soar.
- **How it was found:**
  - `wma --history` in Soar and `--wma-debug` in the model showed the histories agreed up to
    the decision the log entry was made.
  - So the difference was in the initial boost, the mean activation of the elements the
    creating rule tested and of the o-sets behind them.
  - A temporary trace of `St.wmaBoost` listed the elements averaged. The bad-command result's
    instantiation included one element of a neg-query, which Soar's does not have: for a
    malformed command Soar's cue is only the command's top-level elements (`respond_to_cmd`).
- **Fix:** the model's test for a bad command looked for a `^status bad-cmd` element, while the
  status element is `^bad-cmd <c>`. With the test corrected all 8 programs match.
