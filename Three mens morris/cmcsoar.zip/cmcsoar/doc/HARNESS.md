# Comparison harness: versions and run times

## Versions

| Component | Version |
| --- | --- |
| Lean | 4.35.0 (`lean-toolchain`), core library only |
| Soar | 9.6.5, the Python bindings `soar-sml==9.6.5` from PyPI; the kernel source cited in the code and the documents is the Soar repository at tag `releases/9.6.5` (commit d726fbc) |
| Python | 3.13 |
| Report builder | Node.js with the `docx` package (`doc/build_soar.js`); LibreOffice for the PDF |

## How a comparison runs

`tools/diff.py DIR OPTIONS` loads each `.soar` file in DIR into a Soar 9.6.5 kernel through
soar_sml and runs it for the number of decisions in the matching `.n` file, with
`decide indifferent-selection --first` and `srand 0` (RL sets: epsilon-greedy, epsilon 0.3,
seed 42). It records the decision trace and the final working memory, and as the options ask,
learned rules, RL values, the semantic store and every episode. It then runs `soar-lean` on the
same file with the same settings and compares, with identifiers, LTIs and episode nodes matched
up to renaming. With `--replay` (and RL sets by default) the model follows Soar's choices among
indifferent operators, recorded as a `.hints` file; with `--exe` or `--noreplay` it makes its
own. Each program prints one line, `== name MATCH (…)` or `== name DIFF (…)` with the first
differences.

**Two runs.** When `X.pre.soar` (with `X.pre.n`) exists beside `X.soar`, the files named by
`--set path` and `--backup` in either program are deleted, `X.pre.soar` runs in an agent of its
own that is then destroyed (Soar commits and closes its databases then), and `X.soar` runs in a
new agent that opens the file the first left. soar-lean does the same with two runs whose stores
are kept in `DIR/.lean-db` (`--db-dir`). `tests/dbfile` uses this for the memory databases on
disk.

## Run times

Measured on October 31, 2026, on a two-core cloud machine with 7 GB of memory, three groups in
parallel (`tools/run_all.sh` groups; wall-clock minutes, including Soar's own runs):

| Group | Sets | Minutes |
| --- | --- | --- |
| A | decision cycle, real agents, RL (with replay) | 2 |
| E | input, RL variants, LTI, exploration, function library, settings, parser; the sets again without replay | 3 |
| B | semantic memory | 5 |
| D | chunking (chunkdemo about 3.5) | 4 |
| W | working-memory activation, spreading activation | 7 |
| C | episodic memory (epfuzz about 10, epfuzz2 about 26) | 37 |
| All, three in parallel | | about 45 |

Building: `lake build` about 2 minutes from scratch, `lake build soar-lean` about 1 more.
Timings of individual agents against the C++ kernel are in the report, Appendix E.

## Known quirks

- Soar 9.6.5's Towers of Hanoi test agent (tests/real) exhausts memory after decision 32; it is
  run for 31 decisions. See the kernel defects document, defect 1.
- A few programs need Soar's behaviour on undefined reads (freed preferences in working-memory
  activation, constants read as identifiers in spreading's edge updating); those are listed in
  doc/DIFFERENCES.md and do not match.
- Generated sets (tools/gen_*.py) take a random seed; the
  programs in tests/ are the generated files themselves, so regenerating is not needed to rerun.
