const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch();
  const p = await b.newPage({ viewport: { width: 1300, height: 1000 }, deviceScaleFactor: 2 });
  await p.goto('file://' + __dirname + '/cycle.html');
  await p.waitForTimeout(300);
  const el = await p.$('#fig');
  await el.screenshot({ path: __dirname + '/cycle.png' });
  const bb = await el.boundingBox(); console.log(bb.width, bb.height);
  await b.close();
})();
