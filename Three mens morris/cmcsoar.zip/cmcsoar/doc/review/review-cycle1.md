# Review: Soar/Cycle.lean lines 1–1670

Scope: architecture state, working memory and links, preference memory, backtracing, RL, goal
removal and the working-memory phase, matching, the Rete's order and match cache, results and
justifications. Soar/Syntax.lean read for the data types. All "unused" claims checked with grep
over Soar/, CMC/, Main.lean. Costs are per call unless stated; |WM| = elements in `St.raw`
(typically hundreds to a few thousand), |prefs| ≈ |WM|, |insts| = kept instantiations.

Per elaboration cycle the slice is entered as: `wmPhase` → `sync 4` → `gc` (`relevel`, `reach`,
`sync 4`) → `gdsCheck` (`wm`) → `notePush`; then (3925–3928) `retag` → `reteSync` →
`reteCache` → `pending` (`curMatches`, `wm`) → `reteNote` → `reteOrder`.

## A. Speed wins with low behaviour risk

A1. `St.reteSync` (1495–1527), line 1507: `for p in s.chunks ++ s.rlGen do Rete.addProd p.name (conds p) …`.
`conds p` = `placeGoals (soarCondOrder …(reteConds p.conds))` is evaluated for every learned
rule on every call (every elaboration cycle), although `Rete.addProd` (Rete.lean 941) returns at
once when the name is already in `names`. Cost: one full Soar reordering per chunk per cycle, plus
an O(|names|) list scan each. With 100 chunks that is 100 reorderings per cycle for the rest of
the run. Fix: `for p in (s.chunks ++ s.rlGen).filter (fun p => !net.names.contains p.name)` (or
keep the number of rules already added and take `drop`). Safe: `addProd` ignores those rules
anyway. 15 min.

A2. `St.pending` (1472–1481), `keys.contains m.key` and `mkeys.contains i.key`: list membership
over `(String × List Nat)` keys, O(|live insts| × |matches|) key comparisons per cycle; the two
are usually the same size, so quadratic in the match set (50–500 → 10^3–10^5 comparisons per
cycle, each a string compare). Fix: `Std.HashSet (String × List Nat)` (already `Hashable`; `mcache`
uses this key). Safe. The two quiescence proofs (Props.lean 784–814) use `List.contains_iff_mem`
on these; they need `Std.HashSet.contains_ofList`-style rewriting (see C2). 30 min.

A3. `St.curMatches` (1453–1462), line 1461: `s.matches (pm.filter (·.usesLti))` is evaluated
even when no rule uses LTI tests (the normal case). `St.matches` (1317) computes
`WmIndex.ofList s.wm` and `s.ttMap` before its `flatMap`, so every cycle pays one `St.wm`
(dedup of `raw` + `reach`, ≈ (depth + 2) × |WM| hash operations) plus an index build and a
timetag map, for nothing. Fix: `let lti := pm.filter (·.usesLti); if lti.isEmpty then [] else
s.matches lti` (or make `St.matches` return `[]` on `[]` before building the index). Safe. 10 min.

A4. `St.gdsCheck` (1255–1268), line 1257: for every GDS entry of every substate,
`wm.contains w` (O(|WM|)) and `s.ttOf w` (O(|tt|) = O(|WM|)). Cost O(Σ|gds| × |WM|) per cycle;
GDSs of long-lived substates reach hundreds of entries, so 10^5–10^6 comparisons per cycle. Fix:
`let wmS := Std.HashSet.ofList wm; let tm := s.ttMap` and test `wmS.contains w && tm.getD w 0 == t`
(both are needed: `tt` covers unlinked elements in `raw`, `wm` only linked ones). Safe. 15 min.

A5. `St.pending` again, line 1480: for each live justification, `wm.contains w` and `s.ttOf w`
per matched element: O(|justs| × |ws| × |WM|) per cycle. Same fix as A4, and compute `s.wm` only
when `live.any Inst.just` (today `let wm := s.wm` runs every cycle even with no justification).
Safe. 15 min.

A6. `reach` (408–421): each BFS level filters the whole `wm` (`wm.filter (frontier.contains w.id …)`),
so O(depth × |WM|); called from `St.wm` (every `wm`), `St.gc`, `reachAll`, `St.output`,
Conform.locate. Fix: build `Std.HashMap Nat (List WME)` by id once, then expand frontiers by
lookup: O(|WM|). All five callers use the result only through `contains`/`HashSet.ofList`, so the
order of the returned list does not matter. Also `skip` is `[]` at every call site → drop the
parameter. Probably safe (set equality is clear; no theorem mentions `reach`). 45 min. Related:
`St.output` (3995) uses `ids.contains` on the returned List per element — O(|WM| × |ids|) per
output phase; return or convert to a `HashSet` there.

A7. `St.ttOf` (434) is a linear scan of `s.tt`. Inside the slice it is called per element in
`gdsCheck` (A4), `pending` (A5), `matchesWithin` 1345, `supportResults` 1569, `addGds` 1669.
Outside the slice the costly callers are `spSync` 2570 (`s.wm.map (s.ttOf ·)`: O(|WM|²) per
WM-phase when spreading is on), `wmaForgetVictims` 2819 (O(|WM|²) per cycle with naive
forgetting), the sort comparators in `pushOrder` 1710/1741, and `newInst` 2376, which builds a
fresh `s.ttMap` (O(|WM|) inserts) for every rule firing. Fix without touching the `tt`
representation: give each of these a `tm := s.ttMap` computed once and use `tm.getD w 0`
(`ttOf` = `ttMap.getD w 0`, provable in a line from `find?` on a list with distinct keys — see
C3). Safe. 1 h for all sites. Longer-term: hold `tt` as `Std.HashMap WME Nat` plus `tNext`
(order of the list is never used: `reteSync` sorts by timetag, `soarRetag` maps over it,
Main sorts) — 2–3 h, touches ~15 sites, probably safe.

A8. `St.ttMap` is rebuilt 3–4 times per cycle (`curMatches` 1456, `reteNote` 1532, `reteOrder`
1543, `reteCache` 1427 under `--check-match`, plus `retag`'s `old` 451 and `reteSync`'s `cur` 1509).
Compute once in the caller (3925–3928) and pass it. Safe, minor gain (3 × |WM| inserts per
cycle). 20 min.

A9. `St.reteOrder` (1541–1548): `seq`/`gone` are evaluated inside the `mergeSort` comparators,
so `reteKey` (which runs every positive pattern against every matched element, O(|conds|²))
plus a hash of `(String × List Nat)` is recomputed O(n log n) times. Fix: `ms.map (fun m => (seq m, m))`,
sort on the first component, map back. `mergeSort` is stable and the comparator is the same, so
the result is identical. Safe. 10 min.

A10. `St.backtrace` (807–832): the queue is `rest ++ i.ws` and the output `out ++ [w]`, both
O(length) per step → quadratic in the elements visited (hundreds per call; called per result
and per new o-supported substate element via `addGds`). Fix: accumulate `out` reversed and
`reverse` before `dedupW` (dedupW keeps the last occurrence, so reverse first); use a two-list
queue for `rest`. Also `St.supportOf` (786) does `s.slots.find?` + `s.prefs.find?` +
`s.insts.filter (i.made.contains w)` per visited element: O(|slots| + |prefs| + Σ|made|) each.
Build `HashMap WME PRec` (slot → supporting pref) and `HashMap Nat Inst` once per backtrace
call and pass them. Both changes preserve the visiting order. Probably safe (order-preserving;
provable, see C4). 1–1.5 h.

A11. `St.resultSet` (1588–1615), line 1593: `walked := wm.filter fun w => !s.arch.contains w || …`
— `s.arch.contains` is a list scan, O(|raw| × |arch|) per new substate instantiation. Use
`Std.HashSet.ofList s.arch`. Also `prefsOn n` (1598) scans all preferences and `valsOn n`
(1599) all of `walked` per identifier visited; a `HashMap Nat (List PRec)` of `prefs ++ own` and
of `walked` by id, built once per call, keeps the orders and makes the walk linear. Safe.
30 min.

A12. `St.addPref` (706–712): `s.prefs ++ [q]` per preference and the `dupTop` scan `s.prefs.any`
(only for level-1 o-supported acceptables), so `assertPrefs` costs O(k × |prefs|) per pass for k
new preferences. Fix: in `assertPrefs` fold the kept preferences into a reversed accumulator and
append once; `markCtx`/`markSlot` must still be called in the same order. Probably safe (the
dupTop test must see earlier preferences of the same batch — `assertFresh` 2510–2512 already
filters batch duplicates when `reteOn`). 45 min; a lemma that the batch equals the fold is
straightforward (C5).

A13. `St.relevel` (482–503), `walk`: `rest ++ next` queue append, quadratic in the identifiers
reached from one goal. Two-list queue; the level assigned does not depend on visiting order
within a goal (all get `l`; `seen` is shared across goals in level order). Safe. 15 min.

A14. RL (only when `rl.learning`): `St.rlUpdate` 1084–1087 does `s.insts.find?` per
numeric-indifferent preference (O(|prefs| × |insts|) per selection); `rlStore` 1095, `qValue`
1110/1112 filter `s.prefs` three times for one slot. Build an `iid → Inst` map once in
`rlSelect`. Safe. 30 min.

## B. Simplifications

B1. `effPrefs` (730–739) and `St.resultPrefs` (1554–1562) build the same 6-tuple list and turn
it into `PRec`s with the same fields. One helper `mkPRecs (xs) (pid iid level goal) (osup)`
removes ~12 lines and one source of divergence. Safe. 20 min.

B2. Dead code (grep-checked): field `St.pushAdd` (388) — declared only, never read or written
(`pushRem` does the work; the docstring at 386–387 still says "added and removed");
`Pend.anyI` (1486) — never used; `Goal.rlQ` (151) — written at 1101–1102, never read;
`reach`'s `skip` parameter (A6). Remove. Safe. 10 min.

B3. `St.reteSupport` (569–590): `others : List (Binding × List WME)` but only `t.2` is read;
`reteCache` 1422–1423 fabricates `([], tts…)` to fit. Make it `List (List WME)` and in
`St.matches` 1329 pass `(all.eraseIdx k).reverse.map (·.2)`. Safe. 20 min. (Keep the fold: its
result is "the classification of the last match in the list that has a selected operator", a
Soar quirk the tests depend on; see D2.)

B4. RL per-rule tables `rlRules`, `rlValues`, `rlCounts`, `rlAux`, `rlRef` (266–277) are five
association lists keyed by rule name, updated in step with `filter (·.1 != r) ++ [...]` patterns
in `rlStep` (1040–1061) and `rlUpdate` (1082). One `Std.HashMap String RLRec` (init, ecr, efr,
count, gq, beta, h, ref : Option Float) replaces ~25 lines of list plumbing. Lookup order is never
used (Main 251–255 iterates the rules in production order); `rlTraces` must stay a list
(`combined` is the last updated rule, 1037–1039). Probably safe. 1.5 h.

B5. `St.symRank` (350) and `St.symIx` (352) hold the same data twice; `symRank` is read only for
`.length` (445), `find? isZero` (1961) and `contains` (1979). Replace with `symN : Nat` and
derive `find? isZero` as the zero with the smallest index in `symIx` (a fold). Safe. 30 min.

B6. `St.backtrace` 818: `s.idLevel w.id != 0 &&` is always true (`idLevel` returns a goal level
≥ 1, a `dcLevels` level ≥ 1, or 1000000), and the comment above it ("has no level here")
describes the earlier `getD n 0` convention. Drop the conjunct and fix the comment. Safe. 5 min.

B7. `St.pending` 1479: `fresh.filter (!·.osup)` / `fresh.filter (·.osup)` → one `partition`.
Trivial.

B8. Docstrings that no longer match the code: `reteSupport` 567–568 "With no other match this
is `St.oSupported`'s rule" — not exact: `reteSupport` counts `pref` actions among the
identifiers acted on and `oSupported` does not (`changesWM`, `augmentsOp` look at make/remove
only), so a rule testing the operator whose only action is a non-acceptable operator preference
is o-supported by one and i-supported by the other (see C1). Syntax.lean: `WME` 64–65 "NOT
FORMALIZED: timetags" (modelled by `St.tt`); `Cond` 170 "negations do not nest" (`ncc`, `nccg`
exist); `PrefKind` 187 "Numeric-indifferent values are integers here" (floats via
`Sym.ofFloat`); `RVal` 204 "floating-point arithmetic and `/` are not included" (Rhs.lean 60–78
has them). 20 min.

B9. `St.makeResults` (1651) takes `_pre` unused; kept so `results` 2294–2297 can call
`makeResults` and `learnResults` alike. Leave, or drop and adjust `results` and
`makeResults_same` (Props 155). Minor.

## C. Proof opportunities

C1. `theorem reteSupport_nil (h : ∀ a ∈ p.acts, a matches .make | .remove) :
s.reteSupport p b ws [] = s.oSupported p b ws`. Under the hypothesis the fold at 583–590 over a
single match reduces to "some action identifier differs from the selected operator and none
equals it", which is `changesWM && !augmentsOp`; `testsOp` is `selOps ≠ []`; `proposal` and
`support` agree syntactically. Documents exactly where the two definitions diverge (B8) and
protects `matchesWithin` 1345 and the chunk code (2219, 2233), which still use `oSupported`.
1–2 h (fold over `selOps × ids`).

C2. If A2 is done: `(Std.HashSet.ofList keys).contains k = keys.contains k` (from
`Std.HashSet.contains_ofList`, with `LawfulBEq`/`LawfulHashable` for `String × List Nat`),
then the two quiescence proofs change one `simpa` each. 30 min.

C3. `s.ttMap.getD w 0 = s.ttOf w` given `s.tt` has distinct first components (true: `retag`
builds it from `dedupW`'d `raw`). Short induction on `tt` with `Std.HashMap.getD_insert`. Makes
A7 a provable rewrite. 45 min.

C4. For A10: `backtrace.go` with a two-list queue and reversed accumulator equals the present
`go` — standard queue-simulation lemma by induction on fuel. 1–2 h. Without the proof, A10 is
still covered by the regression (justification and chunk condition orders are compared with
Soar).

C5. For A12: `assertPrefs`-batch = fold of `addPref`. 1 h.

C6. Existing proofs: `St.rlUpdate_arch`…`St.rlRetract_arch` (Cycle 1154–1185) and
`rlUpdate_stack`…`rlRetract_stack` (Props 65–91) are two parallel families with two separate
`foldl` inductions (`foldl_rlRetractOne_arch`, `foldl_rlRetractOne_stack`). One family proving
`arch = ∧ stack =` and one generic `foldl` lemma (Props already has `foldl_same` for
`arch ∧ goals`) removes ~15 lines. Minor.

## D. Risks — do not attempt

D1. Orders that tests depend on: `prefBefore`/`aseq`/`pid` (676–679, 124–127); `effPrefs`'s
adds → rems → prefs order (its pids become `aseq`s); `St.desired`'s "first made" sort by minimum
pid (769); `reteSync`'s `adds` newest-first, `rOthers ++ rRanked` (1514–1521) and `initOrder`;
`reteOrder`'s descending `live`/`gone` steps; `backtrace`'s output order (justification and
chunk conditions). Any list→map change must keep these as explicit sorts (as A2, A4, A6 do).

D2. `St.reteSupport`'s fold (583–590) reproduces `p_node_left_addition` as observed 2026-10-30
(an operator elaboration is o-supported when another match has a different selected operator).
Its result is the classification of the last match in `(b, ws) :: others` that has a selected
operator; `others` is passed newest-first (`.reverse`, 1329; `sup` lists, 1422). Do not replace
by a set-based check.

D3. `St.rlStep` 1037–1039: `combined` is the last traced rule's value, assigned to every traced
rule's preferences (Soar's `new_combined` left-over, report Section 11). Trace order matters;
keep `rlTraces` a list (B4).

D4. `St.addPref`'s `dupTop` (707–708) and `assertFresh`'s batch filter (2510–2512) choose which
duplicate top-level o-supported acceptable preference survives by position in `prefs`; A12 must
keep the fold order.

D5. `St.sync` (1222–1237): the fuel case `| 0 => s` returns without `retag`; with more than four
cascaded operator removals the new elements carry no timetags until the next cycle's `retag`
(3925). Rare (each removal clears all lower states) but a latent inconsistency between
`gdsCheck`/`notePush` and `tt`. A safe change is `| 0 => s.retag` or fuel `s.goals.length + 1`;
it changes behaviour only in the cut-off case. Flagging, not recommending, without a test.

D6. `St.relevel`: the `dcLevels` exception in `idLevel` (469–474) and "first goal, in level
order, wins" are Soar-defect reproductions (observed 2026-10-29); A13 keeps both.

## Outside the slice, noticed in passing

- `St.wmPhase` 1845: `s.slots.filter fun e => !pre.slots.any (·.w == e.w)` is O(|slots|²) per
  working-memory phase (≈ |WM|², 10^6 for 1000 elements) — probably the largest non-matching
  cost per cycle. `St.pushOrder` 1708–1710 computes the same `new` with a `HashSet`; reuse it.
  Safe. 10 min.
- `St.newInst` 2376 builds `s.ttMap` per firing (A7).
- `St.spSync` 2570 and `wmaForgetVictims` 2819: O(|WM|²) through `ttOf` (A7).
