# Review: Soar/Cycle.lean 1670–4059 and Main.lean

Scope: chunking hooks and learning from results, the elaboration cycle, working-memory
activation (WMA) hooks, the semantic- and episodic-memory command interfaces, the decision
procedure, input/output and the cycle; plus Main.lean. "Per cycle" below means per
elaboration cycle unless stated. |wm| = elements in working memory, |prefs| = preference
records, |slots| = `St.slots` (≈ |wm|), |tt| = `St.tt` (≈ |raw|).

Safety labels: **safe** = no behaviour change, provable equal; **probably safe** = same
result by inspection, no proof sketched; **risky** = could change orders or timetags the
tests compare.

## (a) Speed wins with low behaviour risk

1. **`St.wmPhase` (1843–1853): `new := s.slots.filter fun e => !pre.slots.any (·.w == e.w)`**
   is O(|slots|²) WME comparisons every cycle (also every `smemPass`, `epPass`,
   `wmaForgetDrop`, each of which calls `wmPhase`). `St.pushOrder` (1707–1709) already
   builds `preW : HashSet WME` for the same set. Build the set once in `wmPhase` (or compute
   `new` once and pass it to `notePush`/`pushOrder`). Same pattern: `St.wmaNewWmes` 2780
   (`pre.slots.any`), `St.viewWith` 2306 (`s.slots.any`), `learnFrom` `R.prefWmes` 2141.
   Safe (set membership equals `any (· == ·)`); 30 min.

2. **`St.trackSlots` (2961–2969)**, every cycle when smem or epmem is on (about 1,500 of
   the 2,900 programs): `present.contains` / `kept.contains` (O(|slots|²)),
   `keptE := s.elemSeq.filter fun p => wm.contains p.1` (O(|elemSeq|·|wm|)) and
   `wm.filter fun w => !keptE.any (·.1 == w)` (O(|wm|²)). Replace the membership tests with
   `HashSet WME` / `HashSet (Nat × Sym)` built once; keep the list orders exactly (`slotSeq`
   order decides command validity — docstring). Safe; 30 min.

3. **`St.soarOrder` (2976–2986)** via `St.epAugs` is called once per identifier of working
   memory by `EpDB.newEpisode`/`storeBfs` (EpMem.lean 348–364) every decision when epmem is
   on, and by `St.augs` for each smem command. Each call does `wm.filter (·.id == n)`
   (O(|wm|)), `pos` = `s.slotSeq.findIdx?` inside the qsort comparator (O(|slotSeq|) per
   comparison), and `born` = `s.elemSeq.find?` per element (O(|elemSeq|)). Per episode this
   is O(|wm|·(|wm| + |slotSeq| + |elemSeq|)) ≈ O(|wm|²). Sketch: a `St.orderIx` record
   (`HashMap (Nat × Sym) Nat` of slot positions, `HashMap WME Nat` of births, `HashMap Nat
   (List WME)` grouping `wm` by identifier, order preserved) built once in `epStore`,
   `epDelta`, `smemDelta`, and a `soarOrderIx` that takes it; `soarOrder` stays as the
   specification. Safe (indexes only; the sort keys are unchanged); 1–2 h. Proof
   opportunity: `soarOrderIx (orderIx s wm) ws = soarOrder s ws`.

4. **`St.deepCopy` (1911–1947) computes `s.wm` (= `raw` + `reach`) unconditionally** at
   line 1913, and is called for every fired match: twice in `St.newInst` (2363 via
   `instantiateM`, 2385 for `dcLevels`) and once more in `St.xRecord` (1995) when learning,
   which also repeats `instantiate` (1997). So each firing costs 2–3 extra O(|wm|) walks
   plus a second RHS evaluation. Sketch: (i) in `deepCopy`, return `(p, b, next, [], [],
   [])` at once unless `p.acts.any` is a `.make _ _ (.call "deep-copy" _)` — provable by
   induction on `acts` (every other arm returns `acc`); (ii) have `newInst` call `deepCopy`
   once and pass `(p, b, n₀, dcs, js, ls)` and `eff` to `xRecord` (new parameters; `xRecord`
   keeps its signature as a wrapper or is inlined). Safe; 45 min. Note `St.rstate` is fine:
   `<|>` on `Option` is lazy, so `s.raw.find?` runs only when needed.

5. **`St.newInst` 2376: `rkey := (s.reteKey s.ttMap m).2`** builds a `HashMap` over all of
   `tt` per fired match (O(|tt|)). `m.tts` already pairs with `m.ws` (`St.matches` 1328,
   `curMatches` 1460), so `reteKey` can take a lookup `WME → Option Nat` and `newInst` can
   pass `fun w => (m.ws.zip m.tts).find? (·.1 == w) |>.map (·.2)` (≤ 10 elements). Equal
   when `m.tts` came from the same `ttMap`, which holds for every match reaching `newInst`
   (both are made after the same `retag` in `St.determine`). Probably safe; 20 min. If
   preferred, build `ttMap` once in `fireLevel` and thread it — safe, 30 min.

6. **`St.gdsCheck` (1255–1268)**: `g.gds.any (fun (w, t) => !wm.contains w || s.ttOf w != t)`
   — `wm.contains` is O(|wm|) and `St.ttOf` (434) is a linear `find?` over `tt`, so the
   check is O(|gds|·(|wm| + |tt|)) at every `wmPhase` and at the start of each decision. GDS
   lists reach hundreds in the real agents. Sketch: `let tm := s.ttMap; let wmS :=
   HashSet.ofList wm; ... (tm.get? w != some t || !wmS.contains w)`. Safe; 15 min.

7. **`St.wmaPrefs` (2743–2763)**, every cycle when WMA is on (~450 programs):
   `gone := pre.prefs.filter fun p => !s.prefs.any (·.pid == p.pid)` and `added` likewise
   are O(|prefs|²). Build `HashSet Nat` of pids on each side. Also `wmOf.any ...` (2756)
   per added preference is O(|slots|); a `HashSet (Nat × Sym × Sym)` of
   non-acceptable `pre.slots` keys makes it O(1). Safe; 20 min.

8. **`St.wmaNewWmes` (2778–2792)**: `live := s.tt.map (·.2) ++ s.insts.flatMap (·.tts) ++
   a.osets.flatMap (·.2)` then `live.contains t` for every decay element, touched tag and
   queue entry: O((|els| + |touched| + |pq|)·|live|) with |live| in the thousands. Make
   `live` a `HashSet Nat`. Safe; 10 min. `a.osets.filter fun (pid, _) => s.prefs.any
   (·.pid == pid)` is O(|osets|·|prefs|); same fix with a pid set.

9. **`St.pushOrder` (1706–1742)**, every cycle with the Rete on (the default):
   - `slotPrefs k` filters all of `s.prefs` per marked slot: O(|marks|·|prefs|). Group
     `s.prefs` once by `(id, attr)` into a `HashMap`.
   - `gone.mergeSort (fun a b => pre.ttOf a ≥ pre.ttOf b)` (1710) and `archGone` (1741):
     each comparison is a linear `find?` over `pre.tt`; use `pre.ttMap` once.
   - `gcd w` (1729) does `pre.slots.find?`, `pre.prefs.find?`, `s.prefs.any` per removed
     element; `rems.contains w` (1738) and `adds.contains` (1742) are quadratic in the
     batch. Index `pre.slots` by WME and both pref lists by pid.
   - `pre.wm.contains w` (1741) sits inside the lambda, so `pre.wm` (raw + reach) is
     recomputed for every `pre.arch` element not in `s.arch` (only when a substate went).
     Hoist `let preWm := pre.wm` out of the lambda.
   All of these keep the result lists in the same order. Safe; 1 h total.

10. **`St.creationKey` (1773–1816)**: `let ord := ... s.candOrder u.id items` (1791) is
    evaluated for every goal of level ≥ 2 and every newly tagged element before the
    `if w.id == n` test, and `candOrder` filters and sorts all operator preferences. Move
    `ord`/`pos` under the `w.id == n` branch (only the `item`/`non-numeric` arms use it).
    Safe (pure `let` floated into its use); 10 min.

11. **`St.gc` (1244–1247) runs `sync 4` after `relevel` even when no preference was
    removed.** In `wmPhase` the state has just been `sync`ed, so when `prefs` is unchanged
    the second `sync` recomputes `desired` (fold over all prefs), the slot diff and
    `retag` (fold over `raw`) for nothing: one full `desired` + `retag` per cycle.
    Sketch: `let gone := s.prefs.any (fun p => p.osup && !ids.contains p.id); if !gone then
    s else {…}.sync 4`. Needs `relevel` to be independent of `sync` (it is: it only sets
    `lv`). Correctness rests on `sync` being idempotent when `prefs`, `arch`, `input` are
    unchanged: `desired` is the same, `kept = slots`, `new = []`, `lost = none`, and
    `retag` on an unchanged `raw` rebuilds the same `tt` (every element is in `old`).
    Probably safe; proof opportunity (c3); 30 min code, 1–2 h proof.

12. **`St.resultsOf` (2312–2314)** builds `s.viewWith ps` (a `desired` over `ps` and a
    `s.slots.any` filter per element) before `results` tests `L ≥ 2`. Test `L ≥ 2` first.
    Safe; 5 min. `St.learnDelta` / `makeResults` also do `s.prefs.filter (·.inst == i.iid)`
    (O(|prefs|)) per firing although `newInst` has just computed `myPs` — pass them.

13. **`St.epStore` / `St.epConsider` (3449–3471)** compute `s.wm` twice per decision;
    `St.smemDelta` (3335) computes it once per state per cycle right after `trackSlots`
    did. Pass `wm` down. Safe; 15 min.

14. Adjacent (lines 1472–1481, outside the slice but on the same path): `St.pending`
    compares match keys with `keys.contains m.key` and `mkeys.contains i.key` — lists of
    `(String × List Nat)`, O(|ms|·|live|) structural comparisons per cycle. A `HashSet`
    of keys fixes it; safe.

## (b) Simplifications

1. **`St.fireMatch` (2480–2482) duplicates `St.fireOneBase` (2474–2477)** minus the
   template branch. Its only caller is `fireOne` (2500), on matches of rules made by
   `Production.fromTemplate`, whose `template` field is the default `false` (905–929). So
   `fireMatch pre r t L acc x = fireOneBase pre r t L acc x` there. Replace, delete
   `fireMatch`, and in Props.lean replace `fireMatch_same`/`foldl_fireMatch_same` (350–368)
   with a fold lemma over `fireOneBase_same`. Safe (provable by `unfold; simp [h]` with
   `h : x.prod.template = false`, or just reuse `fireOneBase_same`, which needs no
   hypothesis); 30 min.

2. **Dead code** (grep over Soar/, CMC/, Main.lean, tools/): `keyRank` (1878, 0 uses),
   `St.dcLevelsOf` (1988, only itself), `St.xRecords` (2011, only itself), `Pend.anyI`
   (1486, 0 uses), the unused `_deselected` parameter of `St.apply` (3962; `cycle` passes
   `none`, `apply_drop` in Props.lean 615 would need its signature updated), the dead
   locals `ct`/`let _ := ct` in `St.spPre` (2588, 2591), and the `_pre` parameter of
   `St.lenv` (2067), whose docstring says levels are "taken before the elaboration cycle's
   changes" but the body uses `s.idLevel`. Safe; 20 min.

3. **`St.smemLinks` (2997) and `St.epLinks` (3417) are the same function** with the
   attribute `"smem"`/`"epmem"`. One `St.memLinks (a : String)`. Also `smemDelta` matches
   `s.smemLinks g.id` twice (3332 binds `_` for the link id, 3369 recomputes it to build
   `links`) — bind `l` once. Safe; 10 min.

4. **`uidOf`** — `(s.instById p.inst).bind fun i => if i.uid != "" then some i.uid else none`
   — is written out in `prefObjs` 1861, `oskCopy` 1874, `traceOf` 1890 and (as a Bool)
   `prefCreator` 2061. One `St.uidOf (p : PRec) : Option String`. Safe; 10 min.

5. **`St.ltiOf?` (2991)** exists but 1980, 2077, 2571, 2683, 2816 and Main.lean inline
   `(s.ltiOf.find? (·.1 == n)).map (·.2)`. Move the definition up and use it. Safe; 10 min.
   (Do not turn `ltiOf` itself into a `HashMap`: `reteSync` 1498 hands the list to the Rete
   and `ltiBindings` 1315 maps over it — order could matter there.)

6. **`SMemDelta` (3271) and `EpDelta` (3474)** carry the same nine fields plus three each
   of their own; `St.delta`/`withDelta`/`epDelta0`/`epState` are four copies of the same
   field shuffle. One `MemDelta` with all fifteen fields, one `St.memDelta`/`withMemDelta`,
   and `smemDelta`/`epDelta` return it. The proofs `smemState_arch` (SMemProps 332) and
   `foldl_epState_arch` (Seriality 60) stay `rfl`. Safe; 30 min, −40 lines.

7. **`St.wmaSupport` (2602)** is `s.wentOf w` with an `opPref` fallback; write it as
   `(s.wentOf w) <|> (…opPref…)`. Safe; 5 min.

8. **Main.lean option parsing**: `opts` (125–152) threads an 11-tuple through a recursive
   match and skips twelve options whose values are then re-read by
   `(args.zip (args.drop 1)).findSome?` scans (173, 224, 227, 257, 276, 289, 296) and a
   separate `let rec chunkFile` (307); flags use `args.contains` (202). One helper
   `optVal (name : String) : Option String` and `hasFlag`, plus `file := the first argument
   that is neither an option nor an option's value`, removes `opts` and `chunkFile` (~35
   lines). Behaviour is identical for well-formed command lines (the only difference: an
   unknown `--x` now must be listed as value-taking or not). Probably safe; 45 min.

9. **`St.creationKey` top-state arms (1776–1781)** hard-code identifiers 1, 2, 5, 8 that
   `St.init` (3984–3991) and `stateLinks 1 5` define. Derive them from `topIO`, `St.init`
   or name them (`topEp := 5`, `topSmem := 8`) next to `topIO`. Safe; 15 min.

10. `St.learnDelta` (2247) is `partial` but not recursive; `St.learnFrom` (2128) is
    `partial` though its recursion is on `fuel` with `fuel > 0` guarding `fuel - 1` — a
    `termination_by fuel` with `decreasing_by omega` after rewriting the guard as a match
    makes both total. No proof depends on unfolding them (`learnResults_same` goes through
    `withLearn`). Safe; 30 min.

11. `St.fireOneBase`'s docstring (2471) says "one step of `St.fireLevel`", but `fireLevel`
    folds `fireOne` (2526); `fireOne`'s docstring repeats `fireOneBase`'s first sentences.
    5 min.

## (c) Proof opportunities

1. `fireOneBase_eq_fireMatch`: `x.prod.template = false → fireOneBase … x = fireMatch … x`
   (needed only if `fireMatch` is kept); one `unfold; simp [h]`. 10 min.
2. For each HashSet rewrite in (a1), (a2), (a6)–(a9): `(HashSet.ofList l).contains x =
   l.contains x` is `Std.HashSet.contains_ofList` (core `Std.Data.HashSet.Lemmas`, needs
   `LawfulBEq WME`, which the derived `DecidableEq` gives); then each rewritten filter is
   equal by `List.filter_congr`. 15 min each.
3. `sync_idem`: `(s.sync 4).sync 4 = s.sync 4` when … — as sketched in (a11); the pieces
   are `desired` depending only on `prefs`/`goals`, `retag` idempotent when `raw` is
   unchanged (`old` covers every element, so the fold rebuilds `tt` with the same tags in
   `raw` order, and `noteSyms []` is the identity). 1–2 h. This also documents that
   `retag` reorders `tt` to `raw` order, which (d3) relies on.
4. `deepCopy_noop`: no `deep-copy` action → `deepCopy s p b next = (p, b, next, [], [], [])`
   by induction on `p.acts` (every other arm returns `acc`). 20 min.
5. `creationKey_ord_floated`: trivially `rfl` after moving the `let`; not worth a theorem.
6. Existing proofs that could be shorter: `fireOne_same`/`fireOnes_same`/
   `foldl_fireMatch_same` (Props 350–396) are three copies of a `foldl_same`-shaped
   argument; `foldl_same` (Props 118) already states it for `St → α → St`, a variant for
   `St × Nat` accumulators replaces all three. 20 min.

## (d) Minor

1. `St.cycle` 4012–4014 rebuilds `rlRules` from `pm` every decision when RL is on
   (O(|pm| + |rlGen|·|rlRules|)); `pm` is constant and `addTemplateRule` already appends
   the generated rules, so this could run once (first cycle). Cheap in practice; probably
   safe (RL learning cannot be switched on mid-run — `runCmdLine` has no such command).
2. `St.retract` 2532–2543: `ids.contains` and `s.prefs.any (·.inst == i.iid)` per
   retracted instantiation; small lists, a `HashSet` of iids if it ever shows.
3. `St.assertFresh` 2512: `(ps.drop (k + 1)).any …` is quadratic in the pass's new
   preferences; passes are small.
4. `St.wmaForgetVictims` naive branch 2819: `s.wm.filter … a.el (s.ttOf w)` is
   O(|wm|·(|tt| + |els|)) per decision; naive is not the default.
5. `St.spSync` 2570: `s.wm.map fun w => (s.ttOf w, w.id)` is O(|wm|·|tt|) per cycle with
   spreading on (150 programs); use `ttMap`.
6. Main.lean `smemInit` (116–122) copies 19 settings from `Parse.SMemConfig` into `SMemDB`
   field by field — two structures that must be kept in step. Embedding the config
   (`SMemDB.cfg`) touches SMem.lean widely; not worth it unless SMem.lean is being reworked.
7. Main.lean: `wmLines st` is computed twice with both `--wm` and `--wm-file` (244–248).

## Risks — do not attempt

1. **Timetag order.** `St.soarRetag` (1820–1830) breaks ties among input/other elements
   by their position in `s.tt` (`(3, 0, raw)` in `creationKey`), and `St.retag` (449–456)
   rebuilds `tt` in `raw` order. Any change to the order of `raw`, the `retag` fold, or
   `dedupW` ("keep the last occurrence") changes timetags, which `tools/ttcmp.py` and
   the Rete's firing order compare. `St.decideImpasse` 3747 deliberately drops the count
   elements from `tt` so they get new tags (defect reproduction: `update_impasse_items`
   always remakes the counts).
2. **Push order.** `St.pushOrder` is the Rete's add/remove order and so the firing order
   (`assertFresh` dup filtering 2510–2513 also depends on `fresh` order). Index it, but
   keep every `mergeSort`/`filter` and the `adds ++ new.filter …` / `rems ++ archGone ++
   gone.filter gcd` concatenations as they are.
3. **`slotSeq`/`elemSeq` order** (trackSlots/soarOrder) decides whether an smem command
   is well formed (docstring 2957–2960) and the episode's edge order.
4. **`St.candOrder`** has two orders (`reteOn` or not); `creationKey` and `pickTie`
   depend on it. Do not unify.
5. **Defect reproductions in the slice** that look like bugs: `learnFrom` 2192–2212
   (`placed`/`keep`: the reorderer's unrestored `chunk_inst_identity`), `dropFresh`
   (duplicate chunk deallocation), `wmaBoost` NaN → 2^63 (2672–2675), `wmaS.stale`
   accounting for freed preferences (2625–2633), `dcLevels` (deep-copy identifiers never
   promoted), `smemDelta`'s set comparison marked SIMPLIFIED (do not "fix" to timetags),
   `installBfs`'s `visited ++ [m]` order (depth-retrieved order), `St.runRetrieve` placing
   the LTI on a new identifier, `choicesName .constraintFailure = "none"`.
6. **`WmaSt` lists** (WMA.lean 161–198, outside the slice): `setEl` moves an element to
   the end of `els`; before replacing `els`/`osets`/`pq` with maps, check that no reader
   observes `els` order (`spPre` re-sorts by `born`; `wmaForgetVictims` iterates `s.wm`;
   `wmaHistories` iterates `touched`) — probably none, but `pq` and `touched` orders are
   observed (`touched` order sets the order of `requeue` calls; `pq` per-cycle lists are
   processed in order in `wmaForgetVictims`).
7. **`Delta` structures** (`LDelta`, `SMemDelta`, `EpDelta`) exist so that
   `learnResults_same`, `smemState_arch` and `foldl_epState_arch` are `rfl`; merging them
   per (b6) is fine, removing them is not.
