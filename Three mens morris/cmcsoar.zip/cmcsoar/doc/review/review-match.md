# Review: Soar/Match.lean, MatchComplete.lean, JoinOrder.lean, Rete.lean, Syntax.lean, Prefs.lean

Read-only review. Line numbers refer to the files as of 2026-10-31. "Proved definition" means a
definition that a theorem in Match/MatchComplete/JoinOrder/Prefs unfolds; changes to those are
flagged. The Rete is on by default (`St.reteOn := true`, Cycle.lean:367), so Rete.lean is the hot
matcher; `St.matches` (Match.lean's `matchCondsIx`) runs each cycle only for rules with LTI tests,
for `--no-rete`, and after the token limit trips.

## (a) Speed wins with low behaviour risk

### a1. `joinOrder` and `soarCondOrder` are recomputed per match and per firing
- Match.lean:828-853 (`joinOrder`), 1003-1040 (`soarCondOrder`), 960-968 (`Reorder.order`),
  929-958 (`Reorder.choose`). Callers: Cycle.lean:1396 (`St.reteMatchOf`: `s.condOrder p.conds`
  for every match the Rete adds, every cycle), 1954-1955 (`St.soarPairs`: both `condOrder` and
  `soarOrder` per instantiation, i.e. per firing), 2438 (`soarCondOrder` per match), 1323, 1337,
  1994, 2189.
- Cost: `joinOrder` is O(c²) list work per rule (filters, `idxOf`, `eraseIdx`, `acc ++ [x]`);
  `soarCondOrder` is O(c³) (`choose` evaluates `look` for every tied item over every other item)
  plus `restore`/`strip` folds with `++ [x]`, roughly 50-200 µs for a 10-condition rule. With tens
  of firings and new matches per cycle this is several ms per cycle, all redundant.
- Both depend only on `p.conds`, `s.multi` and `s.rank`. `multi` is set once from the source
  (Main.lean:222); `rank` of a constant never changes once assigned (Cycle.lean:444-445 only
  appends), and a rule's constants are numbered by the time the rule exists.
- Change: compute once per production (a `Std.HashMap String (List Cond × List (Option Nat × Cond))`
  in `St`, filled when rules are loaded or learned, or two fields on `Production`), and have
  `St.condOrder`, `St.soarPairs`, Cycle.lean:2438 and `St.reteSync` read it.
- Safety: probably safe. The one observable difference: Soar runs its reorderer at load time with
  the `multi-attributes` then in force; the model today uses the current `s.multi`. Caching at load
  matches Soar better. Verify with any test whose `multi-attributes` follows an `sp`.
- Effort: 1-2 h. No proved definition changes (`joinOrder` itself stays).

### a2. `Rete.gone` grows without bound
- Rete.lean:166 (`gone`), 596 (only insertion; never erased). Read only at Cycle.lean:1547
  (`St.reteOrder`, `gone.get? (i.name, i.rkey)`).
- Every retraction over the whole run leaves a `(String × List Nat) ↦ Nat` entry: a 10k-decision
  run with ~50 retractions a decision holds ~500k keys, each a copied rule name plus a list, and
  every `gone.insert` works on a map that only grows (rehashing included).
- Change: drop entries once the retraction has been ordered. Simplest: in `St.reteSync` keep only
  the entries whose key is still an `inMs` instantiation (`s.insts.filter (·.inMs)` keys), or clear
  `gone` where `sup` is cleared (Cycle.lean:1425) after checking that every retraction is ordered
  in the cycle whose sync removed its match.
- Safety: probably safe (clearing where `sup` is cleared is safe only if the second condition
  holds; the filter version is safe). Effort: 30 min plus one regression group with retractions.

### a3. `St.matches` builds the index and timetag map even with no rules to match
- Cycle.lean:1317-1320: `WmIndex.ofList s.wm` (Match.lean:514) and `s.ttMap` are computed before
  `pm.flatMap`. `St.curMatches` (Cycle.lean:1461) calls it every cycle with `pm.filter (·.usesLti)`,
  usually `[]`. Cost per cycle: `s.wm` (a `reach` closure over working memory) + O(|wm|) hash
  inserts with `Array.push` + O(|wm|) `ttMap` inserts, for nothing.
- Change: `if pm.isEmpty then [] else …` at the top of `St.matches`. Safe (the result is `[]`
  either way). Effort: 5 min.

### a4. `WmIndex.ofList` copies each identifier's array on every push
- Match.lean:515: `m.insert w.id ((m.getD w.id #[]).push w)`. `getD` returns the array still held
  by the map (refcount 2), so `push` copies it: O(k) per element of an identifier with k elements,
  O(Σ k²) for the table. An input link or a state with 1,000 attributes costs ~500k element copies
  per build.
- Change: `m.alter w.id (fun | none => some #[w] | some a => some (a.push w))` (or build
  `List`s by cons and keep `Array`-free), and reprove `WmIndex.fold_ok` (Match.lean:496-512) with
  `Std.HashMap.getD_alter`/`getElem?_alter`. The `@[csimp]` route (`onId_eq_onIdTable`) is kept.
- Safety: safe once `fold_ok` is reproved (the `ok` field forces agreement). Touches a proved
  definition (`WmIndex.ofList`). Effort: 45-60 min. Value is limited to the cases in a3.

### a5. `St.reteCache` diffs the whole `live` map every cycle
- Cycle.lean:1415-1417: `mcache.filter (live.contains ·)` and `live.fold … kept.contains k` are
  O(#live matches) hash lookups per cycle on `(String × List Nat)` keys (each lookup hashes the
  rule name's bytes and the list). Rete.lean:164 `live`, 513 and 596 insert/erase.
- Change: have the Rete record deltas alongside `live`: `added : List (String × List Nat)` and
  `removed : List (String × List Nat)` appended at Rete.lean:513 and 596 and cleared where `sup`
  is cleared (Cycle.lean:1425). `reteCache` then processes O(#changes) keys. `live` stays for
  `reteOrder`/`reteNote`.
- Safety: probably safe (`added` must be deduplicated against `removed` within one sync: a key
  removed and re-added in the same sync is "kept" today only if its `live` entry exists; the
  delta version must give the same result; `live.contains` at consumption settles it).
  Effort: 1 h.

### a6. `pLeft` walks every token of the production node for each new match
- Rete.lean:502-513: when `needSup`, `matchKey` (354-370: a walk up `d` tokens with a hash lookup
  per level, then a `mergeSort`) is run for every existing token of the node; `sup` stores all the
  keys. For a rule with m current matches each new match costs O(m·d) lookups and O(m·d) memory;
  m new matches in one cycle cost O(m²·d). `removeTree` (595) recomputes the key once more.
- Change: store each production token's key in its `Tok` when `newTok` makes it (a field
  `key : Option (List Nat)`), so `pLeft`'s loop and `removeTree` read it: O(m) per new match.
- Safety: safe (the key of a token never changes). Effort: 30 min.

### a7. `allW.erase` on every removal
- Rete.lean:159 (`allW : List Nat`), 666 (`allW.erase tt`): O(|wm in Rete|) per removed element.
  `allW` is read only in `amFor` (712) when a memory with no more general one is created.
- Change: `allW : Std.TreeMap Nat Nat` keyed by an insertion counter (value = timetag); iterate it
  in descending key order in `amFor`. Same order as the list (cons = descending insertion).
  Safe. Effort: 20 min. (Do not key it by timetag: a sync adds elements newest-first, so the
  list's order within a batch is ascending timetag; keying by timetag would reverse it and change
  the fill order of new alpha memories for learned rules.)

### a8. `reteOrder` recomputes each match's key inside the sort comparator
- Cycle.lean:1544-1545: `seq m` calls `s.reteKey tm m` (Cycle.lean:1379-1381: `positives … find?
  … p.run`) and `live.get?` for every comparison, O(n log n) times. Change: map to `(seq m, m)`
  first, sort, project. Safe; 5 min. (Cycle.lean, but caused by the key type.)

## (b) Simplifications

### b1. One accessor for the patterns of a negated condition
- The three negated constructors (Syntax.lean:171-182: `neg`, `ncc`, `nccg`) are handled by three
  near-identical arms in `Cond.needs` (Match.lean:713-721), `soarCondOrder` items
  (Match.lean:1029-1033), `Production.usesLti` (Cycle.lean:1310-1311), Cycle.lean:875, 2431,
  `toRC` (Rete.lean:931-936), `Cond.toSoar` (Syntax.lean:362-379).
- Change: `def Cond.negPats : Cond → List Pat` (`neg ps ↦ ps`, `ncc ps ns ↦ ps ++ ns.flatten`,
  `nccg ns ↦ ns.pats`, `pos _ ↦ []`) and one arm `| c => … c.negPats …` where only the pattern
  list matters (needs, items, usesLti, 875, 2431). About 25 lines removed.
- Safety: safe. `joinOrder_strip`/`joinOrder_perm` do not unfold `Cond.needs` (the `ready` filter
  is handled abstractly by `ready_perm`), so the proofs stand. Effort: 30 min.

### b2. `neg ps` is `ncc ps []` (flagged: touches proved definitions)
- `matchConds wm (.neg ps :: cs) b = matchConds wm (.ncc ps [] :: cs) b` holds (`ns.all` over
  `[]` is `true`, so `any` = `!isEmpty`). Removing `Cond.neg` would delete ~31 arms project-wide
  (`matchConds`, `matchCondsIx`, `positives`, `Cond.needs`, `toRC`, `Cond.toSoar`,
  `soarCondOrder`, `CondsOk`, Chunk.lean, Cycle.lean, Parse.lean:289/355).
- Cost: `match_sound`, `matchConds_extends`, `matchCondsIx_eq`, `matchConds_complete_neg` and
  `CondsOk` all have a `neg` arm to delete and an `ncc` arm that must cover `ns = []`; the `neg`
  arm of `CondsOk` has weaker hypotheses (no `VarsOk ps`), so the merged theorem is slightly
  weaker for simple negations unless `ncc`'s `VarsOk` is made conditional on `ns ≠ []`.
  `Cond.toSoar` must still print `.ncc [p] []` as `-(p)` (chunk files are compared with Soar).
- Verdict: real but 3-4 h and it reproves five theorems; do only if the file is being reworked.
  Merging `ncc` into `nccg` is not advisable: `nccg` has no completeness theorem and
  `NegTree.holds` is `partial`.

### b3. Duplicate variable-collection functions
- `STest.eqVars` (Match.lean:697) ≡ `STest.binds` (MatchComplete.lean:34); `STest.useVars`
  (Match.lean:701) ≡ `STest.uses` (MatchComplete.lean:39); `Pat.eqVars` (Match.lean:706) equals
  `Pat.binds` (MatchComplete.lean:51) by `List.flatMap_append`; `Reorder.Item.vars` (912) is
  `Pat.eqVars`; `Reorder.eqOf` (871) is `eqTerm?`.
- Change: keep the Match.lean names, define the MatchComplete ones as them (`abbrev STest.binds :=
  STest.eqVars`), or state `Pat.binds = Pat.eqVars` once and use it. The `simp [STest.binds]`
  calls at MatchComplete.lean:237, 244, 391, 551 then need `STest.eqVars` instead. Inline `eqOf`.
- Safety: safe (definitional). Effort: 30 min.

### b4. Rete: duplicated join loops and manual list walk
- Rete.lean:406-410 and 423-427 (`posLeft`/`mpLeft`), 525-528 and 540-543 (`posRight`/`mpRight`)
  are the same loop; a `joinLeft node t ref`/`joinRight node wt tokRef` helper removes ~10 lines.
- Rete.lean:391-396 (`memLeft`): the `cur`/`head!`/`tail!` walk over a snapshot is exactly
  `for c in (← gN node).linked do posLeft c t ref` (the snapshot is taken once either way).
- Rete.lean:831 `sameHash h₁ h₂ := h₁ == h₂`: inline.
- Safe; 20 min together.

### b5. Fuel counters inside `partial def`s
- Rete.lean:471-477 (`fuel := 1000`), 489-494, 552-557, 569-578 (`1000000`, `100000`), 650-653,
  679-681. The definitions are already `partial`; the counters add state and, if ever reached,
  silently truncate a removal (e.g. 100,000 children at 489-494). Drop all but 471-477
  (`while temp != pp`), which guards against a non-ancestor `pp`; replace that one by stopping
  at the dummy token (`tk == 0`).
- Safety: safe as long as no test hits a limit; each loop makes progress (`removeTree` erases the
  child it took). Effort: 20 min.

### b6. Prefs: small rewrites
- Prefs.lean:77 `opsOf`: `(dedup (… ).reverse).reverse` keeps first occurrences; equals
  `(… ).eraseDups`. `mem_opsOf` (148) then uses `List.mem_eraseDups` (core) instead of
  `mem_dedup`; `dedup` and `mem_dedup` (43-60) go. Probably safe (check the core lemma name).
- 86-87 `afterReject`: one filter with `&&`; 89-92 `afterBest`/`afterWorst`: `let r := c.filter f`
  (filter computed once). `mem_afterReject`, `afterBest_sub`, `afterWorst_sub` adjust by a
  line each. Safe.
- 95-99 duplicates the docstring of `resolve` (125-129) on `stage5`. Drop one.
- Effort: 30 min total.

### b7. Dead or stale
- Syntax.lean:324 `fixedStr`: no use anywhere (grep Soar/, CMC/, Main.lean, tools/). Remove.
- Syntax.lean:64-65 (`WME` docstring: "NOT FORMALIZED: timetags … a WME that is removed and
  re-created is the same element"): timetags are modelled (`St.tt`, `St.retag`, `Match.tts`,
  the Rete keys). Reword to say where.
- Match.lean:161-164 (`RelOp.holds` int/int arms) look redundant with the `num?` arm but are
  not: they compare exactly where `Float.ofInt` would round above 2⁵³, as Soar's int64 compare
  does. Add one comment so nobody deletes them.
- Rete.lean:161 `names : List String` duplicates `prods.map (·.name)`; `names.contains` (941)
  is O(#rules) per `addProd`. Keep one (a `Std.HashSet String`, or `prods.any`). Minor.
- Syntax.lean:16 `List.enum` (`zipIdx` then `map`): two traversals per use, 25 uses. Fine to
  keep for readability; not hot.

## (c) Proof opportunities

### c1. Factor the impasse-cause proofs in Prefs.lean
- `constraintFailure_cause` (232-260), `conflict_cause` (267-297), `tie_cause` (301-329) each
  unfold `stage2`…`stage5` with the same cascade of `split at h; cases h`. A lemma
  `stage2_impasse : stage2 choose ps = .impasse k items → (k = .stateNoChange ∧ items = []) ∨
  (k = .conflict ∧ items = afterReject ps ∧ afterBetterWorse ps items = []) ∨ (k = .tie ∧
  2 ≤ items.length ∧ mutuallyIndifferent ps items = false)` (one cascade) makes each of the three
  about five lines. Saves ~40 lines. 1 h.

### c2. `joinStep_strip`/`joinStep_perm` statements
- JoinOrder.lean:231-263 and 355-386 repeat the 8-line `if b then moveRel … else (…)` term four
  times. Define in Match.lean `def joinPick (multi) (bound) (rest pool : List Cond) (c₀) (move : Bool)
  : Cond × List Cond` and use it in `joinOrder.go` (Match.lean:850-853); the two theorems become
  statements about `joinPick`, and `joinOrder_go_strip`/`joinOrder_go_perm` lose their
  `generalize` steps. Touches a proved definition (`joinOrder.go`) but by a definitional
  refactor (`rfl`). 1-2 h.

### c3. Reuse `runTest_bound`/`Pat.run_bound`
- MatchComplete.lean:259-263 builds the `Bound` fact that `runTest_bound` (682-696) proves;
  `Pat.run_complete` (271-296) likewise duplicates `Pat.run_bound` (698-710). Move the two
  `_bound` lemmas above `runTest_complete` and use them: ~15 lines shorter. 30 min.

### c4. Theorems worth adding (short)
- `Pat.binds = Pat.eqVars` (b3), `matchConds_neg_eq_ncc` (the equation in b2, even if the
  constructor is kept: it documents that `neg` is the special case), and
  `Cond.needs`/`negPats` agreement if b1 is done. Each under 10 lines.
- After a4: `WmIndex.fold_ok` for the `alter` form is the whole proof obligation; nothing else.
- After a1: `St.condOrder s cs = joinOrder cs s.multi` is `rfl` if the cache is filled by the
  same function; state it so the theorems about `joinOrder` still describe what runs.

### c5. Totality
- `NegTree.holds` (Match.lean:225) is `partial` only because of the nested inductive; with
  `ns.attach` and `termination_by sizeOf` it is total, which is the precondition for ever
  extending `matchConds_complete_neg` to `nccg`. 1 h.
- `NegNodes.tree` (Syntax.lean:145-157): total by well-founded recursion on `ns.length`
  (`x :: sub` is shorter than `ns`). 30-60 min; low value by itself.
- `joinOrder.go` fuel `cs.length + 1` could become recursion on `rest.length` (both branches
  shrink `rest`), removing the `0 ⇒ acc ++ rest` arm; but `joinOrder_go_strip/perm` induct on
  the fuel and would be rewritten. 1-2 h; only with c2.
- `Reorder.order` (Match.lean:960): keep `partial` — totality needs `choose … < rest.length`.

## (d) Minor

- Rete.lean:203-208, 210-216, 307-310, 444-449, 701-707, 778-782, 884-888 use
  `let n ← get; … set { n with … }`. With `modify fun n => …` the state is passed uniquely by
  construction; with `get`/`set` it relies on the compiler dropping the second reference before
  `n.ams.modify`/`n.toks.insert` run. If it does not, every `amAdd` copies the `ams` array and
  `rmTT` buckets and every `newTok` copies the `toks` buckets. Rewrite as `modify`; safe,
  20 min; measure with tools/bench.py before and after.
- Rete.lean:307-317 (`newTok`): five separate state rebuilds (a 25-field structure each); one
  `modify` doing all four map updates halves the allocation per token. Safe, 15 min.
- Rete.lean:189-192 (`mT`): `toks.get?` then `toks.insert`; `Std.HashMap.modify` does one hash.
  Also `tsIns`/`tsDel` (195-200). Safe, 10 min.
- Rete.lean:220-226 (`amElems`): `desc` materialises the whole set (`toList.reverse`) and then
  `filterMap rmTT.get?` on every activation of an unhashed join. Storing `AM.seqs` as a
  `Std.TreeMap Nat Nat` (seq ↦ timetag) removes the `rmTT` lookups, and a descending fold (if the
  toolchain's `Std.TreeMap` has `foldr`/`foldrM`) removes the list. Safe, 30 min.
- Rete.lean:650-662 (`addWme` successor walk): `idxOf?` on the live `beta` list per successor is
  O(|beta|²) per (element, memory); the general memory `{none, none}` can have many joins. Only
  worth a doubly-linked representation if profiling shows it.
- Rete.lean:453-456 (`cnLeft`) and 479-483 (`cnpLeft`): linear scans of a node's tokens for one
  with the same `(parent, w)`; Soar does the same, but a `HashMap (Nat × Option Nat) Nat` per CN
  node makes it O(1) without changing which token is found (there is at most one). 30 min.
- `(String × List Nat)` keys (Rete.lean:164-172, Cycle.lean `mcache`, `reteKey`): each lookup
  hashes the rule name's bytes. Interning the name as the production's index in `prods`
  (Rete already has it) gives `(Nat × List Nat)`; Cycle would need a name ↦ index map. 1-2 h,
  moderate gain; a5 and a8 matter more.
- Match.lean:20-23 `Binding` as an association list with `find?`: do not change. `FrontExt`
  (MatchComplete.lean:476-478) and `get_append` rely on the list representation (`n ++ b`),
  and `Extends`, `get_cons_self`, `markLti` are the base of every matcher proof. Bindings are
  short; the cost is small.
- Match.lean:758-797 (`splitRelStep`, `placeStep`, `placeAllStep`) use `acc ++ [x]`: quadratic
  but on test lists of length < 10, and only at reorder time (once per rule after a1).

## Risks: do not attempt
- Any change to the order of `Rete.desc`, `AM.beta`, `Node.children`, `Node.linked`, `allW`
  (a7 explains), `keysFor`, or to `step` numbering: `St.reteOrder` sorts firings and retractions
  by them and the test corpus compares firing order with Soar 9.6.5.
- `RelOp.holds` mixed-type arms (Match.lean:168-177) reproduce `compare_symbols` (kernel
  defect 6, `RelOp.holds_inv_mixed`); `joinOrder`'s `moveRel` inversion depends on it.
- `Reorder.choose`'s tie-breaking (Match.lean:933-958: "most recently found first") and
  `Reorder.restore`'s "most recently taken first" (1005-1018) decide which condition carries a
  relational test in chunks; chunk files are compared textually.
- `Pref`/`opsOf` order (Prefs.lean:74-77): `indifferent-selection --first` picks the earliest.
- `pLeft`'s `sup` ordering (newest first, new match first) feeds `St.reteSupport`.
