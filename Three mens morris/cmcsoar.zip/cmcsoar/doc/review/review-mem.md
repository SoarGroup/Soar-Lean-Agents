# Review: memories, chunking, RHS, parsing (Soar/SMem, EpMem, Store, WMA, Chunk, Rhs, Parse, Explore, Rand)

Scope: read-only review of the nine files named in the brief, with grep over Soar/, CMC/ and
Main.lean for uses. Line numbers are those of the current files.

## Where the association lists cost, and where they do not

The three memories keep every table as `List (k × v)` with `alGet`/`alSet` (EpMem.lean 38–40),
`find?`/`filter ++ [..]` (SMem.lean, WMA.lean). What this costs depends on which hooks run every
cycle:

| Store | Runs every decision cycle? | Per-cycle cost today |
|---|---|---|
| `EpDB.sync` + `newEpisode` (EpMem 196, 402) | yes, when `epmem` is on with the default `dc` trigger | O(\|wm\|²): see E1, E2 |
| `WmaSt` (WMA 161–198) | every *elaboration* cycle when `wma` is on | O(#references × \|els\|): see W1, W3 |
| `SMemDB.spSync` (SMem 882) | only with `spreading on` (gated in Cycle.lean 2569) | sorted merge, O(\|wm\| log \|wm\|) plus the O(\|wm\|²) `ttOf` map built by the caller (Cycle 2570) |
| `SMemDB.query`, `write`, `activate`, `spreadPrep` | only when a command appears or changes | per-query O(#cands × #cue × \|edges\|): see S1–S3 |
| `EpDB.respond` (query/retrieve) | only when a command changes | O(endpoints × #uedges) in `popMax`: see E4 |
| Chunk.lean | when a result is created | O(#grounds × \|par\|) finds on String keys: see C1–C3 |
| Parse.lean | once per run | eight line passes; `symbolOrder` three times with `eraseDups`: see P1 |

For agents without memories on, nothing in this slice runs per cycle; the alists then cost
nothing. Rand.lean and Explore.lean run only at decisions and are fine as they are.

## (a) Speed wins with low behaviour risk

**E1. `EpDB.sync` diff is quadratic** — EpMem.lean 200–201:
`added := wm.filter (!db.prevWM.contains ·)`, `removed := db.prevWM.filter (!wm.contains ·)`.
Two O(|wm|²) `WME` comparisons every cycle an episode is considered (every cycle under `dc`).
At |wm| = 300 that is ~180k structural comparisons per cycle, before anything is stored.
Change: build `Std.HashSet WME` of each side (WME derives `Hashable`, Syntax.lean 71) and filter
the original lists through it; the order of `added`/`removed`, which fixes node numbering through
`adds`, is unchanged. Safe (provably equal: `filter` through a set with the same membership).
10 minutes.

**E2. Encoder alists on the per-episode walk** — `enc : List (WME × Nat)` (EpMem 95) is looked
up for every element of every identifier the BFS visits (`storeOne` 332, `reserve` 244); `known`
(93) for every identifier (`nodeOf` 131); `refs` (97) per identifier-valued element. `storeBfs`
visits everything reachable from an identifier with a new element (a new element on the top
state means the whole state), so a cycle costs O(|wm| × |enc|) ≈ O(|wm|²) on top of E1. Grep
shows `enc`, `known`, `refs`, `repl`, `remLti` are only ever read by key, never iterated
(`enc.length`, `known.length` appear only as fuel at 191 and 954). Change them to
`Std.HashMap`; `alGet/alSet/alErase` become `get?/insert/erase`. The `Repr`/`Inhabited`
derivations still work. `nodeRem`/`edgeRem` are iterated by `closeAll` (396–398) but the fold
applies commuting edits at distinct indices, so a map works there too; however
`foldl_closeWc_keeps` and `foldl_closeWi_keeps` (EpMemProps 360–383) are stated over those
lists and would need restating. Recommendation: convert the five key-only maps (safe, 45 min);
leave `nodeRem`/`edgeRem` unless the proofs are being revisited (probably safe, +1 h of proof).
Note the fuel at 191/954 then needs `size` instead of `length`.

**E3. `epAugs` per identifier on the walk** — `storeBfs` calls `augs x` (Cycle.lean 3412
`St.epAugs`) for each visited identifier; that filters all of `wm` and runs `soarOrder`, whose
`born` does `elemSeq.find?` (|elemSeq| ≈ |wm|) per element. Another O(|wm|²) per cycle. Not in
this slice's files but entirely driven by `newEpisode`'s call pattern: build one
`HashMap Nat (List WME)` of `wm` by identifier per cycle (and `elemSeq` by WME) and pass a
lookup as `augs`. Safe; ordering inside `soarOrder` is untouched. 30 minutes, in Cycle.lean.

**W1. `WmaSt.els` as an alist** — WMA.lean 181–183: `el` is `find?`, `setEl` is
`filter ++ [..]`. `wmaActivate` (Cycle 2726) does `el`+`setEl`+`touch` per reference, and
`wmaTested` (Cycle 2768) references every condition of every pending match every elaboration
cycle: O(#conditions × |els|) per elaboration cycle. Grep: `els` is never read in order (Cycle
2585 sorts by `born`, 2790 filters). `Std.HashMap Nat WDecay` is a drop-in. Safe. 20 minutes.
`touched` (185) must stay an ordered list (its order fixes `pq` bucket order and hence victim
order); add a `HashSet` beside it for the `contains` if `touched` grows large.

**W2. `cycSub` allocates bignums** — WMA.lean 75: `(a + 2 ^ 64 - b % 2 ^ 64) % 2 ^ 64` leaves
the 63-bit small-Nat range on every call, so each call is three GMP operations. It is called per
history entry in `sumHist` (82), which `estimate` (108) calls ~70 + ~128 times per element in the
doubling and bisection, and `wmaForgetVictims` with `naive` calls it for every element every
cycle. Same for `(ret + toAdd) % 2 ^ 64` and `(toAdd * 2) % 2 ^ 64` at 119–124. Change:
`cycSub a b := (a.toUInt64 - b.toUInt64).toNat` and do the loop arithmetic in `UInt64`. Safe,
and a short theorem `cycSub a b = (a.toUInt64 - b.toUInt64).toNat` for `a b < 2^64` pins it.
20 minutes plus 20 for the proof.

**W3. `requeue` touches every bucket** — WMA.lean 193–197 maps a `filter` over every bucket of
`pq` to remove one timetag, per touched element per cycle when forgetting is `bsearch`/`on`.
Keep `forgetCycle` (already in `WDecay`) as the bucket to remove from: filter only that bucket.
Probably safe: the content and order of every bucket is unchanged; the result differs only if a
timetag could be in two buckets, which `requeue` already prevents. 30 minutes.

**S1. `query` recomputes `rowsFor` per candidate** — SMem.lean 625: `db.hasFeature cand el`
(468) filters all `edges` for every candidate × every cue element; `numsOf` (472) likewise.
Compute `rowsOf := sorted.map db.rowsFor` once before the fold (`db` does not change inside it)
and test `rowsOf[i].any (·.lti == cand)`. Provably equal by unfolding. Per query the cost drops
from O(#cands × #cue × |edges|) to O(#cue × |edges| + #cands × #cue × |rows|). 15 minutes.

**S2. `weight` for `.any`/`.math` cues** — SMem.lean 460: `eraseDups` on the LTIs of every row
with the attribute, O(m²) for m rows; a `^name` cue over a 1 000-LTI store is 10⁶ steps per cue
element per query (and `cliQuery` 1043–1046 calls `weight` again per element). Count distinct
LTIs with a `HashSet`. Only the length is used: safe. 5 minutes. Same at 653 (`naiveUpdate`)
and 831 (`calcSpread`), where the result is sorted afterwards so a set-then-sort is equal.

**S3. `keepEdges` is quadratic** — SMem.lean 855–858: `new.edges.find? (·.row == e.row)` per
edge, O(|edges|²) per `spreadPrep` (every query with spreading on). Index `new.edges` by row in
a `HashMap` first. Safe (`keepEdges_content` in SMemProps 77 keeps proving). 10 minutes. The
better change is the proof in (c) P-C3, which removes `keepEdges` entirely.

**S4. `write` appends edges one at a time** — SMem.lean 375–376, 416: `nextRow` folds over all
edges and `edges ++ [e]` copies them, per augmentation written: O(k × |edges|) per store. Compute
`nextRow` once and append the new edges as one list (`edges ++ aug.map ...` with rows
`r, r+1, …`). Equal by induction on `aug`. 15 minutes. A `maxRow` field would also work but
touches `Store.putSMem/getSMem` and `reopen`; not worth it.

**E4. `popMax` is a linear scan** — EpMem.lean 630–637, used for both priority queues of the
interval walk (`pedgeLoop` 778, `ivInner` 813). Every interval endpoint is popped and most
re-pushed, so a query costs O(endpoints × |ipq|) with |ipq| ≤ 2 × #uedges; on long runs with a
query each cycle (tests/epfuzz) this dominates `respond`. The key `(time, isEnd, index)` is a
total order, so any heap gives the same sequence. `SMemDB.heapPush/heapPop` (SMem 484–524) can
be reused with `lt a b := key a < key b`. Probably safe (equal pop order follows from the key
being total; the proof is a standard heap invariant, 1–2 h if wanted). 1 hour.

**P1. `symbolOrder` is computed three times and dedups quadratically** — Main.lean 209, 222
(twice) call `Parse.symbolOrder src`; each tokenizes every line and ends with `eraseDups` on all
constants (Parse 1129), O(n²) in the number of constant tokens (a few thousand on the 1 600-line
agents): roughly 10⁷ `Sym` comparisons, three times, per program start, over 2 900 programs.
Compute it once in Main and dedup through a `HashSet` keeping first occurrences. Safe; a
10-line theorem `dedupFirst l = l.eraseDups` (induction on `l`) makes it provable. 20 minutes.

## (b) Simplifications

**C1. Chunk.lean union–find on String alists** — `UF` (164–186): `par : List (Ident × Ident)`
with `find?` per step, no compression; `lits : List Ident` with `contains`. `UF.find` is called
three times per ground in `eqs` (663–668), three more in `opCond` (671–674), once per constraint
(680–693), per negated test, per RHS term. Each `Ident` is built by `XInst.ident` (200) as
`s!"{x.key}:{v}"`, so every identity use allocates a string and compares strings. Change `par`
and `lits` to `HashMap Ident Ident` / `HashSet Ident`: `par` is never iterated (grep), so this
is safe and removes the 100 000 fuel (169). 30 minutes. Replacing `Ident` by a pair or an
interned `Nat` would remove the string building but ripples through `F{w.id}:id` (381),
`r ++ "#neg"` (487) and `s!"F{g}:val"` (661): 2 h, probably safe, lower priority.

**C2. Three passes over `bt.grounds` compute the same identities** — Chunk.lean 663–668 (`eqs`:
`condId` + `find` per element), 671–674 (`opCond`: `condId` + `find` per element again), 695–700
(`pos`: `extraTests` + `more`). One fold producing, per ground, the triple of equality tests and
the triple of roots gives `eqs`, `opCond` and `pos` from the same data; `opCond` keeps its
first-seen semantics by folding the roots in the same `[2, 1, 0]` order. Equal by construction.
30 minutes. Likewise `mergeConds` (623–630) computes `key q` for every `out` element twice
(`any` then `map`); a single pass with `findIdx?` then `modify` halves it.

**C3. `addGround` and `btInst` appends** — Chunk.lean 340 `bt.grounds.find? (w' == w)` then
`grounds ++ [g]` (341, 359); `btInst` 365 `negs ++`, 395 `cons ++`; `seen.contains` 364 over
strings. All O(n) per ground, O(n²) per rule. Keep a `HashMap WME Nat` (element ↦ first ground
index) beside `grounds`, and `seen` as a `HashSet`. Order of `grounds`, `negs`, `cons` is
unchanged (they stay lists). Probably safe. 30 minutes.

**C4. Dead conditional and duplicated arm** — Chunk.lean 507:
`| some (.id _), none => if x.fresh.contains v then (ts, vs) else (ts, vs)` — both branches are
identical; write `(ts, vs)`. `rhsAction` 553–562: the `.make` and `.remove` arms are the same
code with `rem` forced true; merge them (`| .make i aa v | .remove i aa v => … if rem || isRemove`).
Safe. 5 minutes.

**C5. `valTerm`/`idTerm` recompute `actFor`** — Chunk.lean 655–660: for each result wme,
`rs.wmes.find?` then `actFor` on both, O(|wmes|²) action evaluations; results are small, so (d).

**S5. `ActState` duplicates eight `SMemDB` fields** — SMem.lean 206–216, 348–358: `actState`
copies them out, `withAct` copies them back, and `sets` replays `setActs`. Activation could act
on `SMemDB` directly (the `ActState` functions take `db` already), deleting ~25 lines and the
two copies. `SMemProps.activate_content` (46) and `withAct_content` would be restated as one
lemma over the new function. Probably safe; 1 h including proofs. Not a speed matter.

**S6. Helpers duplicated between SMem and EpMem** — `mget/mset` (SMem 671–674, sorted alist)
and `alGet/alSet` (EpMem 38–40, unsorted) plus the hand-written `find?/filter ++ [..]` idiom in
`ActState` (220–243) and `WmaSt` (181–183) are four spellings of one thing. If the maps become
`HashMap`s (E2, W1, C1) most of these go away; the sorted `mset` must stay sorted (it is
iterated in key order in `applyEdgeUpd` 695 and `construct` 752) or become a sort at use.

**P2. Three brace scanners** — Parse.lean `spBlocks.scan` (564–583), `expandGp.find.scan`
(666–676) and `braceScan` (784–793) each skip `|…|`, `#` comments and nested braces, but differ:
`braceScan` does not honour `\|` inside bars (788) while the other two do (572, 669). One
scanner with a flag for keeping comments would be a single source of truth. Changing
`braceScan`'s escape handling could alter how an `smem --add` block containing `\|` is cut:
check tests/smemcli before unifying. 45 minutes.

**P3. Eight passes over the source, one per settings family** — `smemConfig`, `wmaConfig`,
`epConfig`, `multiAttributes`, `symbolOrder`, `chunkConfig`, `exploreConfig`, `agentConfig`
each do `src.splitOn "\n"` and per line `trimAscii … splitOn " " … filter`. One `lines : List
(List String)` computed once and passed to each would remove seven splits. Load time on the test
files is milliseconds, so this is tidiness only; P1 is the load-time item. Also `smemConfig`
re-joins the rest of the file per `--add`/`--remove`/`--query` (967, 984: `"\n".intercalate
(l :: rest)` then `splitOn "\n"` on the remainder) — O(#commands × |src|), harmless at the ≤ 8
commands per file in tests/.

**R1. Rhs.lean dead locals and split function tables** — `applyFn` 37–38: `ints` and `allInt`
are computed and never used (grep: only their definitions). `(applyFn f vs).orElse (fun _ =>
applyFn2 f vs)` appears twice (533, 578); one `applyPure`. The function name lists
`literalizingFn` (Chunk 243), `valueFns` (Parse 126) and `rhsFunctionSyms` (Parse 1094) are
three hand-kept lists that must agree with the `match` arms of `applyFn/applyFn2/applyCtxFn/
applyRandFn`; they do today (checked name by name; `accept` and `@` are deliberately absent from
`valueFns`). A single table `(name, literalizes, returnsValue)` would make the agreement
structural. 45 minutes, safe.

**Dead code** — only `Parse.peek2` (172) is unused across Soar/, CMC/ and Main.lean. The
`isFirst` parameter of `parseCondParen`/`parseCond`/`parseCondPositive` (314–365) is threaded
through and discarded (`let _ := isFirst`, 327). `Explore.rho` 292: `r0 < 0` cannot hold
(`r0` is `1/nTop` or `0`), so that arm is dead.

**Partial defs that could be total** — `RVal.eval`, `RVal.evalR`, `RVal.vars` (Rhs 528–585)
and `XInst.litArgs` (Chunk 251) recurse structurally on a nested inductive (`RVal` with
`List RVal`); `termination_by sizeOf` with `List.attach` makes them total, which would let
`RVal.eval` appear in theorems. `UF.find`'s fuel (169) disappears with C1. `Store.unhex.bytes`
is already structural. 1 h for the four.

**Docstrings** — SMem.lean 369–371 documents `write` but sits above `lowAct` (372); move it.
Chunk.lean 361 "aa goal level" → "at". EpMem.lean 24–27 says the hooks run "once per output
phase" while `St.epConsider` also runs them after decision with `phase selection` (EpDB 117);
say "once per pass".

## (c) Proof opportunities

**P-C1.** `cycSub` as `UInt64` subtraction (W2): `∀ a b < 2^64, cycSub a b = (a.toUInt64 -
b.toUInt64).toNat`. Short (`UInt64.sub` is `(a + 2^64 - b) % 2^64` by definition). 20 minutes.

**P-C2.** `List.eraseDups` equals a first-occurrence dedup through a set (P1, S2); one induction.
20 minutes. Reusable wherever `eraseDups` is replaced.

**P-C3.** `calcSpread` changes only `act` and `weight`: `(db.calcSpread cs pre).content =
db.content ∧ ltis = db.ltis`. The body only ever rebuilds `edges` through `setActs`
(`migrate` 810) and `applyEdgeUpd` 720 (`upd1` keeps `row, lti, attr, val`). With it,
`keepEdges` (855) and `keepEdges_content` become unnecessary and `spreadPrep` simplifies to
`db.calcSpread …`. The proof is a chain of `content`-preservation lemmas through the folds;
2–3 h because `calcSpread` is 80 lines of nested folds. Worth it: it removes a quadratic step
(S3) and a "fix-up" definition whose only reason is that the preservation was not proved.

**P-C4.** `markProhibits_content` (SMemProps 51–66) and `foldl_setActs_content` (29–38) both
prove "a fold of a content-preserving step preserves content" by hand. One lemma
`foldl_pres_content : (∀ d x, (f d x).content = d.content ∧ …) → …` (as `foldl_pres` already
does for `St` in EpMemProps 18) shortens both to one line each. 20 minutes.

**P-C5.** For S1: `query_rowsOf : hasFeature db cand el = (db.rowsFor el).any (·.lti == cand)`
is `rfl`; the rewritten `query` is then definitionally the old one after `let`-floating.
Stating `query' = query` by `funext; simp [query, query']` should close. 20 minutes.

**P-C6.** For E4, a heap whose pop equals `popMax` on a total key: `heapPop_eq_popMax`. The
libstdc++ heap in SMem.lean exists to reproduce tie behaviour; here ties cannot occur, so a
simpler heap with a proved invariant is enough. 2 h; optional.

## (d) Minor

- `Store.render` (Store.lean 181–183): `a.toList.drop (i * 10)` per line is O(n²/10) in tokens;
  fold over the array in tens. Safe, 10 minutes. Only matters for large `database file` stores.
- `EpDB.install` (EpMem 422–450): `alGet ids` over the node ↦ identifier list per edge and
  `ws ++ [..]` per element, O(n²) per retrieval; a `HashMap` for `ids` keeps the `ids` list for
  the result. 20 minutes.
- `Walk.uedgesAt` (EpMem 532–536) filters and sorts the whole `ucache` per call; an index
  `(isId, parent, attr) ↦ List` would avoid it. 30 minutes, probably safe (sort key is total).
- `spChildren` (SMem 678) filters all edges per expanded node in `construct` (up to
  `spreading-limit` = 300 nodes per source) and `applyEdgeUpd` 699 again: an index of edges by
  LTI (row order kept) serves `edgesOf`, `expand`, `numsOf`, `spChildren` at once. Changing
  `SMemDB.edges` itself touches `Store`, `reopen`, `SMemProps.content`; a derived index built
  per query is the cheap form. 1 h.
- `Rhs.applyFn` computes four argument filters eagerly before the `match` (37–40) for every
  function call including `concat`/`crlf`; move them under the arithmetic arms.
- `Rand.randInt` (55): `reload m.st` should update in place when `m` is unique; worth one
  `bench.py` check that the 624-word array is not copied per reload.

## Risks: what not to change

- **Order of `added`/`removed` in `EpDB.sync`** (E1) and of `adds` (EpMem 148): fixes node and
  edge numbering, which `install` and the identity-based retrieval depend on. Filter, never
  rebuild from a set.
- **`StoreAcc.queue`, `visited`, `reserve` order** (EpMem 243–358): Soar's BFS and reservation
  order; leave the lists.
- **`pools` inner-list order** (EpMem 99, 161, 239): `takePool` takes the first match; the alist
  key order is free, the pool order is not.
- **`EpDB.reopen` pool rebuild order** (1076–1079) and the closing of open intervals: tests in
  tests/dbfile depend on them.
- **`Store` file layout**: `Ser (List α)` writes list order (Store 87–89). Converting any
  serialized `SMemDB.spread.traj/like/trajNum`, `history`, `accTimes` etc. to maps changes the
  file bytes unless written in a canonical order; `getSMem`/`putSMem` and the `.pre.soar` tests
  would need a format version bump. Convert only unserialized tables (E2's `enc/known/refs/
  repl/remLti`, W1's `els`, C1's `UF`).
- **`SMemDB.heapOrder/heapPush/heapPop`** (484–534) reproduce libstdc++'s heap tie order for
  `weighted` and `candOrder`; do not replace with a cleaner heap there (E4 is a different
  queue, with a total key).
- **`spSync` arrivals before departures** (SMem 897–914) and `diff`'s timetag merge; and
  `invCursor` (SMem 770–778, kernel defect "never-reset check").
- **Chunk order dependencies**: `grounds` reversed at 642, `opCond` first-seen in `[2,1,0]`
  order, `negsU` dedup order, `mergeConds` left-to-right, `repairPath`'s `pushed.reverse ++
  rest` DFS (856); every speed change above keeps these lists and adds an index beside them.
- **`WmaSt.touched` order and `pq` bucket order** (W1, W3): victim order feeds `dropPrefs`
  and so working-memory order; `els` alone is order-free.
- **`WmaSt.stale` counting** (`markStale`): used to compare with Soar; keep every call site.
- **`Parse.braceScan` escape handling** (P2): unifying scanners changes where an `smem --add`
  block ends if it contains `\|`.
- **`symbolOrder`'s `splitOn "#"`** (1122) truncates lines at a `#` inside bars: documented
  SIMPLIFIED; changing it changes `symRank` ties in chunk condition order (tests/chunk*).

## Suggested order

1. E1, W1, W2, S1, S2, P1 (together under 2 h; all safe, each a measurable per-cycle or
   per-program saving). 2. E2, E3 (1.5 h; the remaining |wm|² per cycle in episodic memory).
3. C1–C4 (1.5 h; chunking). 4. P-C3 with S3 removed (half a day). 5. E4, W3, S4 (2 h).
