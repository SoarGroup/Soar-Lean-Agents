# Review: proof files and the CMC layer

Slice: Soar/Props.lean, Soar/Seriality.lean, Soar/SMemProps.lean, Soar/EpMemProps.lean,
Soar/Conform.lean, Soar/Examples.lean, Soar/Fuzz.lean, CMC/Base.lean, CMC/Meta.lean,
CMC/Proc.lean. Read-only; nothing was built. Line numbers are from the files as of 2026-10-31.
"Safe" below means no change to `soar-lean`'s behaviour is possible (the item touches only
theorems, or definitions that `Main.lean` does not import: Main imports Soar.Cycle, Soar.Parse
and Soar.Store only, so Conform/Examples/Fuzz are off the executable path).

## (a) Speed

Nothing in this slice runs in `soar-lean`. One note for completeness:

- Soar/Conform.lean:89-105 `locate`/`view`. `view s w ℓ` filters `s.wm` once per managed
  location (4 of them) and `locate` recomputes `s.wm` and `reach s.wm [] [outputLink]` for
  *every* element, so one `view` is O(4·|wm|·(|wm| + reach)) — cubic-ish per CMC cycle. Only
  `Soar.Conform.runCMC` (used solely by Examples.lean, see below) pays it. If the CMC
  correspondence check in item C1 is made real, compute `wm`, the output ids and `locate` as a
  `HashMap WME Lc` once per `view`. Safe. 20 min.

## (b) Simplifications

### B1. One `foldl` invariant lemma instead of ~22 inductions (safe, 1.5 h)

Every proof file re-proves, by induction on a list, "a reflexive–transitive relation preserved by
each step is preserved by `foldl`". A single lemma (core only, no Mathlib):

```lean
theorem List.foldl_rel {α β} {R : β → β → Prop} (hr : ∀ b, R b b)
    (ht : ∀ {a b c}, R a b → R b c → R a c) {f : β → α → β} (hf : ∀ b a, R b (f b a)) :
    ∀ (l : List α) (b : β), R b (l.foldl f b)
```

replaces, each with a one-line application (R and the step lemma named):

| File | Lemma (lines) | R |
|---|---|---|
| Props | `foldl_same` 118-127, `foldl_fireMatch_same` 359-368, `fireOnes_same` 385-396, `foldl_rlRetractOne_stack` 82-86 | `.arch`/`.goals` equal (on `St` or on `(St × Nat).1`) |
| Props | `foldl_addGds_drop` 293-297, `foldl_drop` 440-444, `foldl_elabStep_drop` 463-468 | `ArchDrop` |
| Seriality | `foldl_epState_arch` 60-62, `foldl_rlUpdate_arch` 93-99 | `.arch` equal |
| Cycle | `foldl_rlRetractOne_arch` 1176-1180 | `.arch` equal |
| SMemProps | `foldl_setActs_content` 29-38, `markProhibits_content` 51-66, `foldl_installStep_smem` 131-135, `foldl_ensureLti_of` 215-218, `foldl_appendEdge_of` 278-282, `smemRun_arch` 335-345 | content/ltis equal, `.of m` equal, smem equal |
| EpMemProps | `foldl_pres` 18-27, `epRespond_store` 40-49, `foldl_reserve_edges` 274-282, `foldl_storeOne_keeps` 284-290, inner induction of `storeAll_keeps` 316-329, `foldl_modWc_keeps` 331-337, `foldl_modWi_keeps` 339-345, `foldl_openWi_keeps` 347-354, `foldl_closeWc_keeps` 360-369, `foldl_closeWi_keeps` 371-381 | `Keeps T` or edge-lists equal |

About 130 lines become about 25. `markProhibits_content` (SMemProps 51-66) is the clearest win:
its `step` helper is `foldl_rel` written inline.

### B2. A `Same` relation and a closing tactic for the `_same` lemmas (safe, 1 h)

Props.lean has 35 `theorem *_same : (f s).arch = s.arch ∧ (f s).goals = s.goals` and 16
occurrences of `split <;> exact ⟨rfl, rfl⟩` (EpMemProps has 5 more on `wis`/`wcs`). Define

```lean
def Same (s t : St) : Prop := t.arch = s.arch ∧ t.goals = s.goals
theorem Same.refl / Same.trans / Same.foldl (from B1)
macro "same" : tactic => `(tactic| repeat (first | exact ⟨rfl, rfl⟩ | exact ⟨rfl, rfl, rfl⟩ | split))
```

Then `markCtx_same` 93-95, `markSlot_same` 97-101, `learnResults_same` 165-168,
`runEpCmd_same` 178-180, `runCmdLine_same` 182-189, `logFirings_same` 405-407, `bumpX_same`
413-414, `trackSlots_same` 483-484, `soarRetag_same` 299-301, `reteCache_same` 553-557,
`reteSync_same` 559-565, `reteNote_same` 567-572, `Cycle.addTemplateRule_same` 2464-2468 and
EpMemProps `takePool_edges` 181-183, `reserve_edges` 185-196, `reuseKnown_edges` 198-204,
`reuseNew_edges` 206-210, `ensureNode_edges` 212-213 each become `by unfold f; simp only; same`.
The hand-written transitivity chains (`markCtxSlot_same` 103-108 and `addPref_same` 110-116
contain the same 2-line `⟨(…).1.trans (…).1, (…).2.trans (…).2⟩` twice; `assertFresh_same`
398-403, `fireLevel_same` 418-431, `fireOneBase_same` 335-348) become `Same.trans` chains.
`ArchDrop.ofSame` (210) already consumes this shape, so `ArchDrop.same` (34) and `ArchDrop.ofSame`
collapse into one.

### B3. Dead and duplicated theorems (safe, 20 min)

Checked by grep over Soar/, CMC/, Main.lean and tools/ (no tool reads Lean theorem names):

- Props `foldl_drop` 440-444 is character-for-character `foldl_addGds_drop` 293-297 and is never
  used. Delete.
- Props `Next.st_ite` 509-510: never used. Delete.
- EpMemProps `foldl_pres` 18-27: never used, although `epRespond_store` 40-49 (also unused, and
  itself a copy of the same induction) is exactly `foldl_pres gs St.epState St.epState_store s`.
- EpMemProps `St.linkLti_ep` 14-16: never used.
- Seriality `foldl_epState_arch` 60-62 re-proves `epRespond_store.2.1`. Seriality does not import
  EpMemProps (Soar.lean imports both, but `Props` imports only `SMemProps`). Import EpMemProps
  from Seriality (or Props) and drop the duplicate.
- Props `rlUpdate_stack` 65-71, `rlRetractOne_stack` 73-80, `foldl_rlRetractOne_stack` 82-86,
  `rlRetract_stack` 88-91 mirror Cycle `St.rlUpdate_arch`…`St.rlRetract_arch` 1154-1185 lemma
  for lemma, and `rlUpdate_only_values` 824-841 re-unfolds `rlUpdate` a third time. One lemma
  `rlUpdate_frame : Same s (s.rlUpdate …) ∧ insts = ∧ slots = ∧ prefs.map skel =` (stack follows
  from goals via `stack_map_goals`) with the `_arch`/`_stack` versions as projections.
- Props `decideImpasse_ok` 707-717 and Seriality `decideImpasse_none` 119-130 are the same proof
  with different conclusions. `decideImpasse_ok`'s `.inl` branch already proves the stronger
  `SelWithin … none` (via `append_nonsel`), so state `decideImpasse_none` once (in Props) and get
  `SlotOk` from it; `decideSlot_ok` 732-743 needs a one-line adjustment.
- `fireMatch` (Cycle 2480) is `fireOneBase` (2474) for a non-template rule;
  `fireMatch_same` 350-357 can be `fireOneBase_same` after `fireMatch_eq_fireOneBase` (C3).

### B4. Theorems living in Cycle.lean (safe, 15 min)

Cycle.lean (4059 lines) holds 11 theorems: `St.rlUpdate_arch`…`St.rlRetract_arch` 1154-1185,
`St.addTemplateRule_same` 2464, `St.pickTie_arch` 3695. Nothing in Cycle.lean uses them except
each other. Move them to Props.lean so Cycle.lean is definitions only (and Props has the `Same`
machinery they would use). `isSel` (Props 15) is the pattern `isOpAttr w.attr && !w.acc` written
out at Cycle 539, 586 and Conform 90; move `isSel` to Cycle.lean and use it there.

### B5. Examples.lean, Fuzz.lean, Fuzz2.lean are not built and not checked (probably safe, 30 min)

- Not imported by Soar.lean, so `lake build` neither type-checks nor runs them. The only runner is
  `lake env lean Soar/Examples.lean` (README). Their `#eval`s write `tests/{test,fuzz,fuzz2}/*.soar`,
  `.lean.trace`, `.lean.wm`, `.n`.
- The `.soar`/`.n` outputs are committed and are what the regression runs. The `.lean.trace`/
  `.lean.wm` files (411 pairs) are consumed only by `tools/diff.py` *without* `--exe`
  (diff.py 127); `tools/run_all.sh` always passes `--exe`/`--replay`/…, so that path is never
  exercised. The `.lean.*` files date from Oct 29-30 while the `.exe.*` files are Oct 31; after
  identifier abstraction all 411 pairs still agree, so they are stale but not yet wrong.
- Fuzz.lean (278 KB) and Fuzz2.lean (251 KB) are generated by tools/gen_fuzz.py and
  gen_fuzz2.py from a seed; the generated `.soar` files are committed. Keeping the Lean copies
  buys nothing. Proposal: delete Fuzz.lean, Fuzz2.lean and the `.lean.trace`/`.lean.wm` files;
  make gen_fuzz*.py emit `.soar` directly (they already contain the Soar-source templates via
  `Production.toSoar`, so this needs a small `soar-lean --emit` or a Python port of `toSoar`);
  drop the no-`--exe` branch of diff.py (other reviewer's slice).
- Examples.lean's last block (263-270) is the only check that running Soar through the CMC
  instance (`Soar.Conform.runCMC`) gives the same decisions as `St.run`. It is not run by anything
  and, by inspection, is now false for some tasks (see C1). Risk of deletion: none for tests;
  the eleven hand-written tasks in Examples.lean are the source of tests/test/*.soar, so keep that
  file (or just its `.soar` outputs) and move the CMC check to C1.
- The toolchain is not installed in this environment (elan cannot download), so none of these
  files could be type-checked here.

## (c) Proof opportunities

### C1. Make the Soar-on-CMC instance mean something: `CMC.Proc.cycle soarArch = St.cycle` (safe, 2 h)

Conform.lean 144-160: `elaborate` runs `st.gc.propose`, `select` runs `p.decide` then
`d.apply`. Cycle.lean 4002-4035 `St.cycle` runs `gc.gdsCheck`, `soarRetag`, `spSync`, `propose`,
RL-rule refresh, `(decide).wmPhase`, `spSync`, `explore.update`, `epPass`, `apply`, `smemPass`,
WMA passes. So the state threaded through `runCMC` diverges from `St.run` from the first cycle
with a GDS, with RL, with semantic/episodic memory or with WMA — and nothing checks it (B5).
Fix: split `St.cycle` into three named pieces with no change of meaning,

```lean
def St.cycleIn    (s : St) (pm) (env) (choose) (maxElab) : St   -- lines 4004-4010 (input … propose)
def St.cycleDecide (s pre : St) (choose) : St                   -- 4012-4021 (decide, wmPhase, explore, epPass)
def St.cycleApply (s : St) (pm) (choose) (maxElab) : St          -- 4022-4035 (apply … WMA)
theorem St.cycle_eq : s.cycle pm env choose maxElab = … (the three composed with the halt checks) := rfl
```

and have `soarArch.elaborate`/`select` call them. Then prove

```lean
theorem cycle_pst (pm) (p : St) (w) : (CMC.Proc.cycle (soarArch env choose maxElab) pm p w).2 = p.cycle pm env choose maxElab
theorem runCMC_pst (pm) (n) : (runCMC pm n env).pst = St.init.run pm env n
```

both by unfolding (the `halted`/`stopped` early exits need a `split`). This turns the
`Conform` file from an unverified mapping into a theorem that Soar *is* the CMC instance, which
is the project's stated point. `Keeps`-type obligations stay as they are (see W1).
Behaviour risk: none; `St.cycle_eq` is `rfl`, and Main uses `St.run`.

### C2. `St.wm`, `St.raw`, `dedupW`: specifications of the working-memory functions (safe, 1-4 h)

No theorem mentions `St.wm`, `St.raw`, `dedupW` or `reach` (Cycle 394-431), the definitions the
quotation from [Man] §2.2 is attached to. In increasing cost:

- `wm_sub_raw : w ∈ s.wm → w ∈ s.raw` and `output_sub_wm` (Cycle 3993): `List.mem_filter`. 10 min.
- `mem_dedupW : w ∈ dedupW ws ↔ w ∈ ws` and `dedupW_nodup : (dedupW ws).Nodup`. Needs
  `Std.HashSet.contains_insert`/`mem_insert` (in Std since 4.12; available in 4.35 core). 1 h.
  Consequence: `raw_nodup`, hence (via `retag`, Cycle 449-456) `tt_keys_nodup`, hence
  `ttMap_getD_eq_ttOf : s.ttMap.getD w 0 = s.ttOf w` — `St.matches` (1328) uses `ttMap`, while
  `St.matchesWithin` (1345) and `St.pending` (1480) use `ttOf`; this is a fast/slow pair that is
  currently equal only by an unstated invariant. 1 h more.
- `mem_reach_iff : i ∈ reach wm skip roots ↔ Reachable wm skip roots i` with `Reachable` an
  inductive. Soundness is a fold invariant; completeness needs the fuel argument (each level
  that adds an identifier consumes at least one distinct WME, so `wm.length + 1` levels suffice).
  3-4 h; the HashSet bookkeeping in `reach.go` makes this the slowest item here. Worth it only if
  `reach` is rewritten for speed (other slice): then the theorem is the equality of old and new.

### C3. Small equalities between paths (safe, 5-15 min each)

- `fireMatch_eq_fireOneBase (h : m.prod.template = false)` (Cycle 2474-2483): `by simp [h]`.
- `curMatches_off : s.reteOn = false → s.curMatches pm = s.matches pm` (Cycle 1453): `by simp`.
  The interesting equality — `mcache` against `matches` when `reteOn` — is what `--check-match`
  tests at run time and is **not** provable from the current definitions (the Rete model is an
  approximation; misses are counted at 1437-1443). Say so in the docstring at 1445-1447 rather
  than leave "which the theorems are about" implying otherwise.
- `St.setWma_arch`, `setWma_goals`, `setFiring_*`: `rfl` lemmas marked `@[simp]`, so the
  `simp only [St.setWma]` steps in Seriality 71, 83, 243, 248, 250, 251 disappear.
- `epStore_arch` (EpMemProps 53-70) is the one place architecture elements change outside the
  decision; a corollary `epStore_sel : ∀ w ∈ s.epStore.arch, isSel w → w ∈ s.arch` would replace
  Seriality's `presentIs_sel` + `epStore_sub` 40-58 (15 lines) with 3.

### C4. One theorem for RL's frame (safe, 30 min)

See B3: `rlUpdate_frame` covering arch, goals (hence stack), insts, slots, `prefs.map skel`,
from which `St.rlUpdate_arch`, `rlUpdate_stack`, `rlUpdate_only_values`, `foldl_rlUpdate_arch`
(Seriality 93-99) and `rlHalt_arch` 101-105 follow by projection and `foldl_rel`.

## (w) Theorems that are stated but weak

- W1. Conform.lean `elaborate_keeps` 161-166, `select_keeps` 167-177, `soar_core_strict`
  204-215. All three hold because `view` (104-105) leaves unmanaged locations untouched and every
  `archWritten` location other than `procProcess` is unmanaged (`archWritten_unmanaged`). They
  say nothing about Soar. `select_keeps` and `soar_core_strict` are also the same proof twice;
  `select_keeps` should be `fun … h ℓ ha hℓ e he => (soar_core_strict … h ℓ ha hℓ) ▸ he`. The
  file header already records this as OPEN; C1 is the way to give the instance content.
- W2. Conform 158 `.act (fun w' => view a w')` ignores its argument: the "act" is a constant
  function, so `cycle_serial`/`cycle_keeps` in CMC.Proc are vacuous for this instance.
- W3. Props `quiescence_ie` 784-800, `quiescence_pe` 804-814 unfold `St.pending` (1472-1481)
  and read off its filters; they restate the definition. They would carry weight if stated
  against `St.matches` (the slow path) rather than `curMatches`, or if `pending` were proved
  to characterise `fireLevel` doing nothing (`fireLevel_same` + `pending = {}` → state equal up
  to logs).
- W4. `cycle_independent_of_decl` in CMC/Base 623, Meta 535, Proc 232 is `rw [hw, hp]`: true of
  any function of `pm` and `wm`. The documented content ("no direct access") is already carried
  by the *type* of `select`; keep one of the three with a docstring saying it is a type-level
  fact, or drop them.
- W5. `St.epState_store` (EpMemProps 36-38), `St.smemState_arch` (SMemProps 332-333),
  `newInst_same`, `supportResults_same`, `linkLti_ep`: `rfl`. Fine as regression guards, but they
  should be `@[simp]`-tagged one-liners rather than carry the headline docstrings ("Retrieval
  changes no stored episode" sits on a `rfl`). The non-trivial content for episodic retrieval is
  that `epDelta` (Cycle 3528-3531) does not touch `ep`; `rfl` proves exactly that, so the
  docstring is right but a reader cannot tell.
- W6. `decide_selects_at_most_one` (Props 770) existentially quantifies the new selection and
  does not say it is a selection *for a state with none*; `run_selUnique` (Seriality) supplies
  that. A one-line corollary combining them (`∃ x, SelWithin … ∧ (∀ w, some w = x → s.selected w.id = none)`)
  would make Props self-contained; or just point from the Props docstring to Seriality.

## (d) Minor

- Props 42-45 `ArchDrop.spSync`: `split <;> exact h`.
- Props 249-254 `removeOperator_drop`: the same `simp only […] at hn` is run in both bullets;
  run it once before `refine`.
- Props 56-61 `stack_map_goals` is `List.map_map` + `List.map_congr_left`; keep as a named lemma
  but prove it in one line.
- CMC/Base 34-41 and CMC/Meta 42-55 define `upd`, `upd_same`, `upd_other` (and Meta `upd_comm`
  duplicates Base 775-778) twice because Meta does not import Base. Importing Base from Meta for
  the utilities only (Meta's `Sig`, `Loc`, `Arch` are deliberately separate) removes 20 lines.
  Safe, 10 min.
- CMC/Proc `exec_agree` 241-256 and CMC/Meta `exec_agree` 822-837 and Base 1011-1026: same
  proof three times over three `exec`s; unavoidable while the three layers stay independent,
  but the `AgreeExceptDM` + `decl_influence_requires_retrieval` pair could be stated once over
  an abstract "exec that does not read `dm`" and instantiated. 1 h; low value.
- CMC/Base `proc_change_is_learning` 875-892 and Meta 772-780 differ only in the
  `Step`-vs-`Label` form; fine.
- Conform 133-136 `newImpasse` uses `after.goals.getLast?` and `before.goals.any`; with
  `max-goal-depth` a halt leaves goals unchanged and `newImpasse` says `none`, so `select`
  reports `.act` for a halted decision. Only matters once C1 is done.

## Risks (do not attempt without care)

- Nothing in this slice is on the `soar-lean` path, so no regression test can change. The two
  things that *would* change behaviour if done carelessly: (1) refactoring `St.cycle` for C1 —
  keep the three pieces literally the lines they replace and make `St.cycle_eq` `rfl`; the
  order `soarRetag` → `spSync` → `propose` and the `wmPhase` right after `decide` are what the
  Rete-order and WMA tests depend on; (2) removing Examples.lean — keep tests/test/*.soar (and
  the `.hints`/`.n` files), which were emitted from it.
- `Std.HashSet`/`HashMap` lemma names changed between 4.15 and 4.35; C2's `dedupW` proofs should
  be written against the 4.35 Std API (`Std.HashSet.mem_insert`, `contains_iff_mem`,
  `mem_ofList`), not older names.
