import Lake
open Lake DSL

package cmcsoar

@[default_target]
lean_lib CMC

@[default_target]
lean_lib Soar

lean_exe «soar-lean» where
  root := `Main
