# a one-dimensional world: the agent starts at 0 and the goal is 4; a move command moves it east
state = {'x': 0, 'done': set()}
def step(k, output):
    ch = []
    if k == 1:
        return ['+ I2 ^x 0', '+ I2 ^goal 4']
    moves = [v for (i, a, v) in output if a == 'move']
    for m in moves:
        if m in state['done']: continue
        state['done'].add(m)
        ch += [f"- I2 ^x {state['x']}", f"+ I2 ^x {state['x'] + 1}"]
        state['x'] += 1
    return ch
