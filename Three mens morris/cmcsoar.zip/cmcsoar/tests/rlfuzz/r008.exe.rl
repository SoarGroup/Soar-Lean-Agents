rl*op0*x0 0 -0.250000
rl*op0*any 2 3.805662
rl*op1*x1 12 0.697311
rl*op1*any 12 3.697311