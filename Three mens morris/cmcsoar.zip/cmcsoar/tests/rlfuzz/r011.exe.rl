rl*op0*x0 2 -1.167653
rl*op0*any 14 1.596448
rl*op1*any 2 1.250996
rl*op2*x0 0 0.750000
rl*op2*x1 1 0.936660
rl*op2*any 1 -0.063340