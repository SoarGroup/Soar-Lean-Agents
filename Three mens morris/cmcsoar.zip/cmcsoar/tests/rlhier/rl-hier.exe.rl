rl*task 0 0.700000
rl*other 0 0.100000
sub*rl*x 1 0.400000
sub*rl*y 0 -0.200000