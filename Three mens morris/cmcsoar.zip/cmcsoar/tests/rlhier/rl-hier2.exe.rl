rl*task 3 9.963331
rl*other 2 3.118621
sub*rl*x 10 1.163073
sub*rl*y 2 0.905305