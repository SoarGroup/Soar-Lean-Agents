rl*task 3 4.761912
rl*other 2 2.227858
sub*rl*x 10 0.962970
sub*rl*y 2 0.811212