rl*sub*rl*template*1 1 0.500000
rl*sub*rl*template*2 0 0.500000