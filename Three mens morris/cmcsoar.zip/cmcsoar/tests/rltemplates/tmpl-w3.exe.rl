rl*sub*rl*template*n*1 0 -0.100000
rl*sub*rl*template*v*2 0 0.200000
rl*sub*rl*template*n*3 0 -0.100000
rl*sub*rl*template*v*4 0 0.200000
rl*sub*rl*template*n*5 0 -0.100000