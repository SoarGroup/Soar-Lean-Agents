rl*sub*rl*template*v*1 0 0.200000
rl*sub*rl*template*v*2 1 0.200000