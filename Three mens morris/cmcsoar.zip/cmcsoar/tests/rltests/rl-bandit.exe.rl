rl*left 23 3.168988
rl*right 6 1.373209