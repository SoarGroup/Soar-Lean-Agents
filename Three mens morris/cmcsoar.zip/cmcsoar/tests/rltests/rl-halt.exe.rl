rl*go 0 0.250000
rl*stay 5 7.002718