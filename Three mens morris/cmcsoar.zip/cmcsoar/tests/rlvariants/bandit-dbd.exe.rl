rl*left 23 1.683445
rl*right 6 0.088657