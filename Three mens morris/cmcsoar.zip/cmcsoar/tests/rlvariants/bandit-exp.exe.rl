rl*left 23 2.674644
rl*right 6 1.316233