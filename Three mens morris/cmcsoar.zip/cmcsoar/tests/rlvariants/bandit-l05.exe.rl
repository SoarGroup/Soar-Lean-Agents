rl*left 29 3.792445
rl*right 26 2.012510