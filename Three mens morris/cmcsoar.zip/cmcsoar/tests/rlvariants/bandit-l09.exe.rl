rl*left 29 -0.602517
rl*right 26 -0.696806