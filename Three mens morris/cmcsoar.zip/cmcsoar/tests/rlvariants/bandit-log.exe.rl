rl*left 23 3.686827
rl*right 6 2.128836