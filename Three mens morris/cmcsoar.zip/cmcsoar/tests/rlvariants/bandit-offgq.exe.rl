rl*left 28 1.798863
rl*right 25 -2.436925