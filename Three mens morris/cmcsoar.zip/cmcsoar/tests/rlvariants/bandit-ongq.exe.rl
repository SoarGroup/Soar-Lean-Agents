rl*left 29 1.897656
rl*right 26 -0.556016