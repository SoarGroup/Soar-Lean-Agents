rl*left 23 5.285089
rl*right 6 2.675905