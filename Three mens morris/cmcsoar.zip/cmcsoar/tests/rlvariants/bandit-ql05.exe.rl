rl*left 23 6.641930
rl*right 26 3.833911