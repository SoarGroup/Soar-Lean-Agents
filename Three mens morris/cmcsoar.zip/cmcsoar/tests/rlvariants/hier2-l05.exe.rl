rl*task 5 13.649364
rl*other 3 7.779485
sub*rl*x 11 1.418519
sub*rl*y 4 1.028083