rl*task 5 22.215821
rl*other 3 13.056122
sub*rl*x 11 1.683677
sub*rl*y 4 1.134835