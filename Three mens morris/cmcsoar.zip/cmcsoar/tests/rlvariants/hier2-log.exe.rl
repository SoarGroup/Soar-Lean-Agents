rl*task 3 17.050549
rl*other 2 8.564193
sub*rl*x 4 0.541067
sub*rl*y 8 3.227486