rl*task 4 11.120512
rl*other 3 5.687138
sub*rl*x 11 0.835129
sub*rl*y 4 0.346869