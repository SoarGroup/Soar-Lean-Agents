rl*task 5 13.171095
rl*other 3 7.372259
sub*rl*x 11 1.119852
sub*rl*y 4 0.702771