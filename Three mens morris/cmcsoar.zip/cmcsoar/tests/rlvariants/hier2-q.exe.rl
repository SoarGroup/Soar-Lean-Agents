rl*task 3 10.350681
rl*other 2 4.347518
sub*rl*x 10 1.334184
sub*rl*y 2 0.952933