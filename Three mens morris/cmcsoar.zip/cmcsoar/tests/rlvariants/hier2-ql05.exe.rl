rl*task 3 12.294254
rl*other 3 7.183732
sub*rl*x 10 1.481102
sub*rl*y 4 1.044188