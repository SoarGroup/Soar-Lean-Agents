"""Time the same agents in Soar 9.6.5 (C++ kernel, via soar-sml) and in soar-lean.
Usage: bench.py N agent.soar ...   (N decisions; best of 3 runs each)"""
import soar_sml as sml, subprocess, sys, time, os, re
EXE = os.environ.get('SOAR_LEAN', os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '.lake', 'build', 'bin', 'soar-lean'))
n = int(sys.argv[1])
k = sml.Kernel.CreateKernelInCurrentThread(True, 0)
def soar_time(f):
    best = None; dec = None
    for _ in range(3):
        a = k.CreateAgent("b")
        a.ExecuteCommandLine("chunk never"); a.ExecuteCommandLine("decide indifferent-selection --first")
        a.ExecuteCommandLine("watch 0")
        a.ExecuteCommandLine("source " + f)
        t = time.perf_counter(); a.ExecuteCommandLine(f"run {n} -d"); el = time.perf_counter() - t
        st = a.ExecuteCommandLine("stats")
        m = re.search(r'(\d+) decisions', st); dec = int(m.group(1)) if m else None
        k.DestroyAgent(a)
        best = el if best is None else min(best, el)
    return best, dec
def lean_time(f, nd):
    def run(d):
        h = f[:-5] + '.hints'
        extra = ['--hints', h] if os.path.exists(h) else []
        t = time.perf_counter(); r = subprocess.run([EXE, f, '-d', str(d)] + extra, capture_output=True, text=True); return time.perf_counter() - t, r
    base = min(run(0)[0] for _ in range(3))           # start-up and parsing only
    full = []; out = None
    for _ in range(3):
        el, r = run(nd); full.append(el); out = r.stdout
    decs = len(re.findall(r'^\d+: (?:O:|==>S:)', out, re.M))
    return min(full) - base, base, decs
print(f"{'agent':45s} {'dec':>4s} {'Soar C++ (s)':>12s} {'Lean (s)':>10s} {'ratio':>8s} {'Lean parse (s)':>14s}")
for f in sys.argv[2:]:
    st, sd = soar_time(f)
    lt, lb, ld = lean_time(f, n)
    name = os.path.basename(f)[:-5]
    ratio = lt / st if st > 0 else float('inf')
    print(f"{name:45s} {ld:4d} {st:12.4f} {lt:10.3f} {ratio:8.0f} {lb:14.3f}", flush=True)
