"""Compare learned rules (chunks) printed by Soar 9.6.5 and by soar-lean, up to renaming of
variables and the order of conditions and actions.

canon(text) parses one rule in Soar syntax and returns a canonical string; two rules are taken
as the same when their canonical strings are equal. Variables are renamed by colour refinement
(Weisfeiler–Leman) over the conditions and actions they occur in.
"""
import re

TOK = re.compile(r'\|[^|]*\||-->|<<|>>|<=>|<>|<=|>=|-\{|[(){}^]|<[^<>\s()]+>|[^\s(){}^]+')


def tokens(text):
    return TOK.findall(text)


def isvar(t):
    return t.startswith('<') and t.endswith('>') and len(t) > 2 and t not in ('<<', '>>', '<>', '<=>', '<=')


RELOPS = ('<>', '<=>', '<', '<=', '>=', '>')


class P:
    def __init__(self, toks):
        self.t, self.i = toks, 0

    def peek(self, k=0):
        return self.t[self.i + k] if self.i + k < len(self.t) else None

    def next(self):
        x = self.t[self.i]; self.i += 1; return x


def norm_const(c):
    c = c.strip('|') if c.startswith('|') else c
    try:
        if re.match(r'^-?\d+\.\d*(e-?\d+)?$', c):
            return repr(round(float(c), 6))
    except ValueError:
        pass
    return c


def simple(p):
    t = p.next()
    if t == '<<':
        cs = []
        while p.peek() != '>>':
            cs.append(norm_const(p.next()))
        p.next()
        return ('disj', tuple(sorted(cs)))
    if t in RELOPS:
        r = p.next()
        return ('rel', t, r if isvar(r) else norm_const(r))
    if isvar(t):
        return ('var', t)
    return ('const', norm_const(t))


def test(p):
    if p.peek() == '{':
        p.next(); ts = []
        while p.peek() != '}':
            ts.append(simple(p))
        p.next()
        return ts
    return [simple(p)]


def cond(p, neg=False):
    """Parse '(' [state] id ^a v [+] ... ')' into a list of patterns."""
    assert p.next() == '('
    goal = False
    if p.peek() == 'state':
        p.next(); goal = True
    idt = test(p)
    pats = []
    while p.peek() != ')':
        neg_attr = False
        if p.peek() == '-':
            p.next(); neg_attr = True
        assert p.next() == '^'
        at = test(p)
        vals = []
        while p.peek() not in (')', '^', '-'):
            v = test(p)
            acc = False
            if p.peek() == '+':
                p.next(); acc = True
            vals.append((v, acc))
        if not vals:
            vals = [([('var', '<_anon%d>' % p.i)], False)]
        for v, acc in vals:
            pats.append(('neg' if neg or neg_attr else 'pos', goal, idt, at, v, acc))
    p.next()
    return pats


MARKS = ('+', '-', '!', '~', '@', '>', '<', '=', '&')


def rhsval(p):
    t = p.peek()
    if t == '(':
        p.next(); f = norm_const(p.next()); args = []
        while p.peek() != ')':
            args.append(rhsval(p))
        p.next()
        return ('call', f, tuple(args))
    t = p.next()
    return ('var', t) if isvar(t) else ('const', norm_const(t))


def action(p):
    assert p.next() == '('
    if p.peek() not in (None,) and not isvar(p.peek()):
        # a function-call action such as (write ...)
        f = p.next(); args = []
        while p.peek() != ')':
            args.append(rhsval(p))
        p.next()
        return [('fun', f, tuple(args))]
    i = p.next(); acts = []
    while p.peek() != ')':
        assert p.next() == '^'
        a = rhsval(p); v = rhsval(p)
        marks = []
        while p.peek() in MARKS:
            m = p.next()
            if m in ('>', '<', '=', '&') and p.peek() not in MARKS + (')', '^'):
                marks.append((m, rhsval(p)))
            else:
                marks.append((m, None))
        if not marks:
            marks = [('+', None)]
        for m in marks:
            acts.append(('act', ('var', i), a, v, m[0], m[1]))
    p.next()
    return acts


def ncc_body(p):
    """The conditions of a negated conjunction, after '-{' and up to its '}'; a negated
    conjunction inside it (any depth) is a ('ncc', ...) item of its own."""
    inner = []
    while p.peek() != '}':
        if p.peek() == '-{':
            p.next(); inner.append(('ncc', ncc_body(p)))
        elif p.peek() == '-':
            p.next(); inner.append(('nn', cond(p)))
        else:
            inner.extend(('n', x) for x in cond(p))
    p.next()
    return inner


def single_neg(inner):
    """A negated conjunction of one pattern, which Soar prints as a negated attribute
    (`(<a> -^b <c>)`), as that negated pattern; None if it is not of that form."""
    pats = [x for tag, x in inner if tag == 'n']
    if len(inner) == 1 and len(pats) == 1 and pats[0][0] == 'pos':
        return ('neg',) + tuple(pats[0][1:])
    if len(inner) == 1 and inner[0][0] == 'nn' and len(inner[0][1]) == 1 and inner[0][1][0][0] == 'pos':
        return ('neg',) + tuple(inner[0][1][0][1:])
    return None


def flatten_ncc(inner):
    """Replace each negated conjunction of one pattern inside `inner` by the negated pattern."""
    out = []
    for tag, x in inner:
        if tag == 'ncc':
            x = flatten_ncc(x)
            g = single_neg(x)
            out.append(('n', g) if g else ('ncc', x))
        else:
            out.append((tag, x))
    return out


def parse(text):
    toks = tokens(text)
    p = P(toks)
    assert p.next() == 'sp'
    assert p.next() == '{'
    name = p.next()
    while p.peek() is not None and p.peek().startswith(':'):
        p.next()
    conds = []
    while p.peek() != '-->':
        if p.peek() == '-{':
            p.next()
            conds.append(('ncc', flatten_ncc(ncc_body(p))))
        elif p.peek() == '-':
            p.next()
            for x in cond(p, neg=True):
                conds.append(x)
        else:
            for x in cond(p):
                conds.append(x)
    p.next()
    acts = []
    while p.peek() == '(':
        acts.extend(action(p))
    return name, conds, acts


def vars_of(x, out):
    if isinstance(x, tuple):
        if len(x) == 2 and x[0] == 'var':
            out.append(x[1])
        else:
            for y in x:
                vars_of(y, out)
    elif isinstance(x, list):
        for y in x:
            vars_of(y, out)
    return out


def subst(x, lab):
    if isinstance(x, tuple):
        if len(x) == 2 and x[0] == 'var':
            return ('var', lab.get(x[1], x[1]))
        if len(x) == 3 and x[0] == 'rel' and isvar(x[2]):
            return ('rel', x[1], lab.get(x[2], x[2]))
        return tuple(subst(y, lab) for y in x)
    if isinstance(x, list):
        return tuple(sorted((subst(y, lab) for y in x), key=repr))
    return x


def rel_vars(x, out):
    if isinstance(x, tuple):
        if len(x) == 3 and x[0] == 'rel' and isvar(x[2]):
            out.append(x[2])
        for y in x:
            rel_vars(y, out)
    elif isinstance(x, list):
        for y in x:
            rel_vars(y, out)
    return out


def canon(text):
    name, conds, acts = parse(text)
    # a state test belongs to the identifier, whichever of its conditions carries it
    goals = set()
    for c in conds:
        if c[0] == 'pos' and c[1]:
            goals.add(('goal', tuple(c[2])))
    conds = [(c[0], False) + tuple(c[2:]) if c[0] in ('pos', 'neg') else c for c in conds]
    # a relational test between two variables of positive conditions is a constraint of the
    # rule, whichever condition carries it
    flip = {'<': ('lt', 0), '>': ('lt', 1), '<=': ('le', 0), '>=': ('le', 1), '<>': ('ne', 2), '<=>': ('st', 2)}
    extra = []
    def pull(t):
        eqv = next((x[1] for x in t if x[0] == 'var'), None)
        keep = []
        for x in t:
            if eqv and x[0] == 'rel' and isvar(x[2]) and x[1] in flip:
                op, k = flip[x[1]]
                a, b = (eqv, x[2]) if k == 0 else (x[2], eqv)
                if k == 2: a, b = sorted((eqv, x[2]))
                extra.append(('vrel', op, ('var', a), ('var', b)) if k != 2 else ('vrels', op, frozenset()) )
                if k == 2: extra[-1] = ('vrels', op, [('var', a), ('var', b)])
            else:
                keep.append(x)
        return keep
    conds = [(c[0], c[1], pull(c[2]), pull(c[3]), pull(c[4]), c[5]) if c[0] == 'pos' else c for c in conds]
    conds = conds + extra
    # the same inside a negated conjunction
    def ncc_norm(c):
        if c[0] != 'ncc':
            return c
        nonlocal extra
        out = []
        for tag, x in c[1]:
            if tag == 'ncc':
                out.append((tag, ncc_norm(('ncc', x))[1]))
            elif tag == 'n' and x[0] == 'pos':
                extra = []
                out.append((tag, (x[0], False, pull(x[2]), pull(x[3]), pull(x[4]), x[5])))
                out.extend(('n', e) for e in extra)
            else:
                out.append((tag, x))
        return ('ncc', out)
    conds = [ncc_norm(c) for c in conds]
    items_extra = None
    items = conds + acts + sorted(goals)
    # Soar prints a repeated condition or test once
    seen, uniq = set(), []
    for it in items:
        k = repr(subst(it, {}))
        if k not in seen:
            seen.add(k); uniq.append(it)
    items = uniq
    vs = set()
    for it in items:
        vs.update(vars_of(it, [])); vs.update(rel_vars(it, []))
    lab = {v: 'V' for v in vs}
    for _ in range(6):
        new = {}
        for v in vs:
            sig = []
            for it in items:
                if v in vars_of(it, []) or v in rel_vars(it, []):
                    l2 = dict(lab); l2[v] = '*'
                    sig.append(repr(subst(it, l2)))
            new[v] = str(hash((lab[v], tuple(sorted(sig)))))
        lab = new
    body = sorted(repr(subst(it, lab)) for it in items)
    # merge duplicate conditions (Soar prints each once)
    return name, '\n'.join(sorted(set(body)))


def split_rules(text):
    """Split a printout into rule texts."""
    out = []
    for m in re.finditer(r'sp \{', text):
        depth = 0; j = m.start()
        for k in range(m.start(), len(text)):
            if text[k] == '{':
                depth += 1
            elif text[k] == '}':
                depth -= 1
                if depth == 0:
                    j = k + 1; break
        # braces inside |...| are not expected in these tests
        out.append(text[m.start():j])
    return out
