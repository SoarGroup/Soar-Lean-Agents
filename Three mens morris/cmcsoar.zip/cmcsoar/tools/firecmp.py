"""Compare the order in which rules fire in Soar 9.6.5 and in soar-lean.

usage: python3 tools/firecmp.py agent.soar N [settings] [soar-lean] [extra soar-lean options]

Runs N decisions in both (settings separated by ';', default the regression's --first and
srand 0), takes the sequence of rule firings with a mark between elaboration cycles (Soar's
trace 3, soar-lean's --watch), and prints the first place where they differ, with the firings
around it, or "same". Names only: two instantiations of one rule are not told apart (use
tools/ttcmp.py for that)."""
import sys, subprocess, re, os
f, n = sys.argv[1], sys.argv[2]
S = sys.argv[3] if len(sys.argv) > 3 else 'decide indifferent-selection --first;srand 0'
lean = sys.argv[4] if len(sys.argv) > 4 else os.environ.get('SOAR_LEAN', os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '.lake', 'build', 'bin', 'soar-lean'))
extra = sys.argv[5:]
import soar_sml as sml
k = sml.Kernel.CreateKernelInNewThread(); a = k.CreateAgent("a")
out = []
a.RegisterForPrintEvent(sml.smlEVENT_PRINT, lambda *x: out.append(x[-1]), None)
for c in S.split(';'):
    if c: a.ExecuteCommandLine(c)
a.ExecuteCommandLine("source {%s}" % os.path.abspath(f))
a.ExecuteCommandLine("trace 3")
a.ExecuteCommandLine("run %s" % n)
st = "".join(out).splitlines()
def norm_s(lines):
    r = []; dc = 0
    for l in lines:
        m = re.match(r'\s*(\d+):\s+[O=]', l)
        if m: dc = int(m.group(1)); r.append((dc, 'DECIDE')); continue
        if 'Inner Elaboration Phase' in l: r.append((dc, '|')); continue
        m = re.match(r'\s*Firing (\S+)', l)
        if m: r.append((dc, m.group(1)))
    return r
lo = subprocess.run([lean, f, '-d', n, '--settings', S, '--watch'] + extra, capture_output=True, text=True).stdout.splitlines()
def norm_l(lines):
    r = []; dc = 0
    for l in lines:
        m = re.match(r'(\d+) selected', l)
        if m: dc = int(m.group(1)); r.append((dc, 'DECIDE')); continue
        if re.match(r'\d+ L\d+ (IE|PE)', l): r.append((dc, '|')); continue
        m = re.match(r'\s*Firing (\S+)', l)
        if m: r.append((dc, m.group(1)))
    return r
A, B = [z for z in norm_s(st) if z[1] != 'DECIDE'], [z for z in norm_l(lo) if z[1] != 'DECIDE']
A=[z[1] for z in A]; B=[z[1] for z in B]
def squeeze(x):
    r=[]
    for z in x:
        if z=='|' and r and r[-1]=='|': continue
        r.append(z)
    return r
A=squeeze(A); B=squeeze(B)
for i, (x, y) in enumerate(zip(A, B)):
    if x != y:
        print(f"first difference at firing {i}: soar {x} lean {y}")
        print("  soar:", A[max(0,i-12):i+25])
        print("  lean:", B[max(0,i-12):i+25])
        break
else:
    print(f"same ({len(A)} soar, {len(B)} lean firings)")
