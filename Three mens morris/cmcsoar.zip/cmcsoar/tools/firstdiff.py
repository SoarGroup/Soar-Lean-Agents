"""Run diff.py on one directory and report, per differing agent, the first decision that differs."""
import re, subprocess, sys
out = subprocess.run(['python3', __import__('os').path.join(__import__('os').path.dirname(__import__('os').path.abspath(__file__)), 'diff.py')] + sys.argv[1:], capture_output=True, text=True).stdout
for blk in out.split('\n=='):
    head = blk.strip().splitlines()[0] if blk.strip() else ''
    if 'DIFF' not in head: continue
    ms, ml = re.search(r"soar: (\[.*\])", blk), re.search(r"lean: (\[.*\])", blk)
    print('==', head)
    if ms and ml:
        s, l = eval(ms.group(1)), eval(ml.group(1))
        i = next((i for i, (x, y) in enumerate(zip(s, l)) if x != y), min(len(s), len(l)))
        print('   first difference at', i, ':', s[i] if i < len(s) else None, '|', l[i] if i < len(l) else None)
    for m in re.findall(r"(only (?:soar|lean): .{0,300})", blk): print('  ', m)
