"""Random episodic-memory programs for comparison with Soar 9.6.5 (tools/diff.py --epmem).

Each program records an episode every decision cycle while a random script changes the top
state: attribute values change, objects are replaced by new objects in the same place, objects
gain and lose sub-objects, and objects become shared by two attributes. At random steps a
command is issued: cue-based queries (constant and identifier cue elements, nested and shared
identifiers, negative cues, ^before, ^after, ^prohibit), retrievals by episode number, and
next/previous retrievals. What each step retrieves is logged in working memory, so the final
working memory records every result, and the harness compares every stored episode.
"""
import random, sys, os

COLORS = ['red', 'blue', 'green']
SHAPES = ['round', 'square']
SLOTS = ['a', 'b', 'c']


def obj_rhs(rnd, var):
    acts = [f"^color {rnd.choice(COLORS)}"]
    if rnd.random() < 0.6: acts.append(f"^shape {rnd.choice(SHAPES)}")
    if rnd.random() < 0.4: acts.append(f"^size {rnd.randint(1, 3)}")
    return f"({var} " + " ".join(acts) + ")"


def change(rnd, n):
    """A rule that changes the state when step n is applied."""
    head = f"(state <s> ^operator.n {n}"
    k = rnd.choices(['recolor', 'replace', 'addsub', 'delsub', 'share', 'unshare', 'reshape', 'none'],
                    [4, 2, 2, 1, 1, 1, 2, 2])[0]
    sl = rnd.choice(SLOTS)
    if k == 'recolor':
        return f"sp {{ch*{n} {head} ^{sl} <x>) (<x> ^color <c>) --> (<x> ^color <c> - ^color {rnd.choice(COLORS)})}}"
    if k == 'reshape':
        return f"sp {{ch*{n} {head} ^{sl} <x>) --> (<x> ^shape {rnd.choice(SHAPES)})}}"
    if k == 'replace':
        return f"sp {{ch*{n} {head} ^{sl} <x>) --> (<s> ^{sl} <x> - ^{sl} <y>) {obj_rhs(rnd, '<y>')}}}"
    if k == 'addsub':
        return f"sp {{ch*{n} {head} ^{sl} <x>) --> (<x> ^part <p>) (<p> ^kind {rnd.choice(['kx', 'ky'])})}}"
    if k == 'delsub':
        return f"sp {{ch*{n} {head} ^{sl} <x>) (<x> ^part <p>) --> (<x> ^part <p> -)}}"
    if k == 'share':
        return f"sp {{ch*{n} {head} ^{sl} <x>) --> (<s> ^d <x>)}}"
    if k == 'unshare':
        return f"sp {{ch*{n} {head} ^d <x>) --> (<s> ^d <x> -)}}"
    return None


def cue(rnd, steps):
    """The actions building a query cue on <q>, and extra conditions."""
    acts = []
    conds = ""
    used = rnd.sample(SLOTS + ['step', 'd'], rnd.randint(1, 3))
    vi = 0
    for el in used:
        if el == 'step':
            acts.append(f"(<q> ^step {rnd.randint(0, steps)})")
        elif el == 'd':
            acts.append("(<q> ^d <dd>)" + (f" (<dd> ^color {rnd.choice(COLORS)})" if rnd.random() < 0.6 else ""))
        else:
            vi += 1
            v = f"<v{vi}>"
            parts = []
            if rnd.random() < 0.7: parts.append(f"^color {rnd.choice(COLORS)}")
            if rnd.random() < 0.4: parts.append(f"^shape {rnd.choice(SHAPES)}")
            if rnd.random() < 0.25: parts.append("^part <pp>")
            acts.append(f"(<q> ^{el} {v})" + (f" ({v} " + " ".join(parts) + ")" if parts else ""))
            if rnd.random() < 0.15:
                acts.append(f"(<q> ^d {v})")   # a shared identifier in the cue
    return conds, acts


def command(rnd, n, steps):
    kind = rnd.choices(['query', 'retrieve', 'next', 'prev', 'bad'], [7, 2, 1, 1, 1])[0]
    head = f"sp {{cmd*{n} (state <s> ^operator.n {n} ^epmem.command <c>"
    if kind == 'query':
        conds, acts = cue(rnd, steps)
        acts = ["(<c> ^query <q>)"] + acts
        if rnd.random() < 0.25:
            sl = rnd.choice(SLOTS)
            acts.append(f"(<c> ^neg-query <nq>) (<nq> ^{sl} <nx>) (<nx> ^color {rnd.choice(COLORS)})")
        if rnd.random() < 0.2: acts.append(f"(<c> ^before {rnd.randint(1, n + 2)})")
        if rnd.random() < 0.2: acts.append(f"(<c> ^after {rnd.randint(0, n)})")
        if rnd.random() < 0.2:
            for _ in range(rnd.randint(1, 2)):
                acts.append(f"(<c> ^prohibit {rnd.randint(1, n + 1)})")
        return head + ")" + conds + " --> " + " ".join(acts) + "}"
    if kind == 'retrieve':
        return head + f") --> (<c> ^retrieve {rnd.randint(0, n + 2)})}}"
    if kind in ('next', 'prev'):
        return head + f") --> (<c> ^{'next' if kind == 'next' else 'previous'} <z>)}}"
    return head + ") --> (<c> ^retrieve 1 ^query <q>) (<q> ^step 1)}"


LOG = """sp {log*meta (state <s> ^operator <o> ^epmem.result <r>) (<o> ^name step ^n <n>) (<r> ^{ <at> << status memory-id match-score match-cardinality graph-match cue-size normalized-match-score present-id >> } <v>) --> (<s> ^log <l>) (<l> ^n <n> ^attr <at> ^val <v>)}
sp {log*nomem (state <s> ^operator <o> ^epmem.result <r>) (<o> ^name step ^n <n>) (<r> ^retrieved no-memory) --> (<s> ^log <l>) (<l> ^n <n> ^nomem yes)}
sp {log*status (state <s> ^operator <o> ^epmem.result <r>) (<o> ^name step ^n <n>) (<r> ^{ <at> << success failure >> } <v>) --> (<s> ^log <l>) (<l> ^n <n> ^status <at>)}
sp {log*ret (state <s> ^operator <o> ^epmem.result.retrieved <x>) (<o> ^name step ^n <n>) (<x> ^<a> <v>) --> (<s> ^log <l>) (<l> ^n <n> ^rattr <a>)}
sp {log*ret2 (state <s> ^operator <o> ^epmem.result.retrieved <x>) (<o> ^name step ^n <n>) (<x> ^{ <a> << a b c d step >> } <y>) (<y> ^<b> <v>) --> (<s> ^log <l>) (<l> ^n <n> ^rattr <a> ^battr <b> ^bval <v>)}
sp {log*step (state <s> ^operator <o> ^epmem.result.retrieved <x>) (<o> ^name step ^n <n>) (<x> ^step <v>) --> (<s> ^log <l>) (<l> ^n <n> ^rstep <v>)}
sp {log*map (state <s> ^operator <o> ^epmem.result.mapping.node <nn>) (<o> ^name step ^n <n>) (<nn> ^retrieved <rv>) (<rv> ^<a> <v>) --> (<s> ^log <l>) (<l> ^n <n> ^mattr <a> ^mval <v>)}
"""


def gen(seed, steps=10):
    rnd = random.Random(seed)
    out = ["epmem --set learning on"]
    if rnd.random() < 0.15: out.append("epmem --set graph-match off")
    out.append("sp {init (state <s> ^superstate nil -^step) --> (<s> ^operator <o> + =) (<o> ^name init)}")
    objs = " ".join(f"^{sl} <w{i}>" for i, sl in enumerate(SLOTS))
    out.append(f"sp {{apply*init (state <s> ^operator.name init) --> (<s> ^step 0 {objs}) "
               + " ".join(obj_rhs(rnd, f"<w{i}>") for i in range(len(SLOTS))) + "}")
    out.append(f"sp {{propose (state <s> ^step <n> < {steps}) --> (<s> ^operator <o> + =) (<o> ^name step ^n <n>)}}")
    out.append("sp {apply*step (state <s> ^operator <o> ^step <n>) (<o> ^name step) --> (<s> ^step <n> - ^step (+ <n> 1))}")
    out.append("sp {apply*clear (state <s> ^operator.name step ^epmem.command <c>) (<c> ^<a> <v>) --> (<c> ^<a> <v> -)}")
    for n in range(steps):
        for _ in range(rnd.randint(0, 2)):
            r = change(rnd, n)
            if r: out.append(r.replace(f"ch*{n}", f"ch*{n}*{rnd.randrange(10**6)}"))
        if n >= 1 and rnd.random() < 0.75:
            out.append(command(rnd, n, steps))
    out.append(LOG)
    return "\n".join(out) + "\n", steps + 2


if __name__ == '__main__':
    d = sys.argv[1]; n = int(sys.argv[2]); start = int(sys.argv[3]) if len(sys.argv) > 3 else 0
    os.makedirs(d, exist_ok=True)
    for i in range(start, start + n):
        src, k = gen(i)
        open(os.path.join(d, f"e{i:03d}.soar"), 'w').write(src)
        open(os.path.join(d, f"e{i:03d}.n"), 'w').write(str(k))
