"""Random episodic-memory programs, second generator (tools/diff.py --epmem).

Beyond gen_epfuzz.py: several objects under one multi-valued attribute (so cues can match
different objects for different features and graph match matters), cues with shared and
deeper identifiers and with the operator, commands issued from operator no-change substates,
next/previous after queries, and random settings: graph match off, graph-match ordering, the
output trigger (with output-link commands), and exclusions.
"""
import random, sys, os

COLORS = ['red', 'blue', 'green']
SHAPES = ['round', 'square']


def obj(rnd, var):
    acts = [f"^color {rnd.choice(COLORS)}"]
    if rnd.random() < 0.7: acts.append(f"^shape {rnd.choice(SHAPES)}")
    if rnd.random() < 0.3: acts.append(f"^size {rnd.randint(1, 3)}")
    return f"({var} " + " ".join(acts) + ")"


def change(rnd, n, k):
    head = f"sp {{ch*{n}*{k} (state <s> ^operator.n {n}"
    c = rnd.choices(['recolor', 'reshape', 'additem', 'delitem', 'replace', 'addpart', 'share', 'unshare', 'out'],
                    [4, 2, 2, 1, 2, 1, 1, 1, 1])[0]
    if c == 'recolor':
        return f"{head} ^item <x>) (<x> ^color <c> ^id {rnd.randint(0, 3)}) --> (<x> ^color <c> - ^color {rnd.choice(COLORS)})}}"
    if c == 'reshape':
        return f"{head} ^item <x>) (<x> ^id {rnd.randint(0, 3)}) --> (<x> ^shape {rnd.choice(SHAPES)})}}"
    if c == 'additem':
        return f"{head}) --> (<s> ^item <y>) {obj(rnd, '<y>')} (<y> ^id {rnd.randint(0, 3)})}}"
    if c == 'delitem':
        return f"{head} ^item <x>) (<x> ^id {rnd.randint(0, 3)}) --> (<s> ^item <x> -)}}"
    if c == 'replace':
        return f"{head} ^item <x>) (<x> ^id {rnd.randint(0, 3)}) --> (<s> ^item <x> - ^item <y>) {obj(rnd, '<y>')} (<y> ^id {rnd.randint(0, 3)})}}"
    if c == 'addpart':
        return f"{head} ^item <x>) (<x> ^id {rnd.randint(0, 3)}) --> (<x> ^part <p>) (<p> ^kind {rnd.choice(['kx', 'ky'])})}}"
    if c == 'share':
        return f"{head} ^item <x>) (<x> ^id {rnd.randint(0, 3)}) --> (<s> ^focus <x>)}}"
    if c == 'unshare':
        return f"{head} ^focus <x>) --> (<s> ^focus <x> -)}}"
    return f"{head} ^io.output-link <ol>) --> (<ol> ^move <m>) (<m> ^dir {rnd.choice(['up', 'down'])})}}"


def cue_acts(rnd, steps):
    acts = []
    for k in range(rnd.randint(1, 3)):
        el = rnd.choices(['item', 'focus', 'step', 'op', 'shared', 'deep'], [5, 2, 1, 1, 1, 1])[0]
        v = f"<i{k}>"
        if el == 'item':
            parts = []
            if rnd.random() < 0.7: parts.append(f"^color {rnd.choice(COLORS)}")
            if rnd.random() < 0.5: parts.append(f"^shape {rnd.choice(SHAPES)}")
            acts.append(f"(<q> ^item {v})" + (f" ({v} " + " ".join(parts) + ")" if parts else ""))
        elif el == 'focus':
            acts.append(f"(<q> ^focus {v}) ({v} ^color {rnd.choice(COLORS)})")
        elif el == 'step':
            acts.append(f"(<q> ^step {rnd.randint(0, steps)})")
        elif el == 'op':
            acts.append(f"(<q> ^{rnd.choice(['operator', 'operator*'])} {v}) ({v} ^name step)")
        elif el == 'shared':
            acts.append(f"(<q> ^item {v} ^focus {v}) ({v} ^color {rnd.choice(COLORS)})")
        else:
            acts.append(f"(<q> ^item {v}) ({v} ^part <pp{k}>) (<pp{k}> ^kind {rnd.choice(['kx', 'ky'])})")
    return acts


def command(rnd, n, steps, c="<c>"):
    kind = rnd.choices(['query', 'retrieve', 'next', 'prev', 'bad'], [8, 2, 2, 2, 1])[0]
    if kind == 'query':
        acts = [f"({c} ^query <q>)"] + cue_acts(rnd, steps)
        if rnd.random() < 0.2:
            acts.append(f"({c} ^neg-query <nq>) (<nq> ^item <nx>) (<nx> ^color {rnd.choice(COLORS)})")
        if rnd.random() < 0.15: acts.append(f"({c} ^before {rnd.randint(1, n + 2)})")
        if rnd.random() < 0.15: acts.append(f"({c} ^after {rnd.randint(0, n)})")
        if rnd.random() < 0.15: acts.append(f"({c} ^prohibit {rnd.randint(1, n + 1)})")
        return " ".join(acts)
    if kind == 'retrieve':
        return f"({c} ^retrieve {rnd.randint(0, n + 2)})"
    if kind in ('next', 'prev'):
        return f"({c} ^{'next' if kind == 'next' else 'previous'} <z>)"
    return f"({c} ^next <z> ^previous <z>)"


LOG = """sp {log*meta (state <s> ^operator <o> ^epmem.result <r>) (<o> ^n <n>) (<r> ^{ <at> << status memory-id match-score match-cardinality graph-match cue-size normalized-match-score present-id >> } <v>) --> (<s> ^log <l>) (<l> ^n <n> ^attr <at> ^val <v>)}
sp {log*nomem (state <s> ^operator <o> ^epmem.result <r>) (<o> ^n <n>) (<r> ^retrieved no-memory) --> (<s> ^log <l>) (<l> ^n <n> ^nomem yes)}
sp {log*status (state <s> ^operator <o> ^epmem.result <r>) (<o> ^n <n>) (<r> ^{ <at> << success failure >> } <v>) --> (<s> ^log <l>) (<l> ^n <n> ^status <at>)}
sp {log*ret (state <s> ^operator <o> ^epmem.result.retrieved <x>) (<o> ^n <n>) (<x> ^<a> <v>) --> (<s> ^log <l>) (<l> ^n <n> ^rattr <a>)}
sp {log*ret2 (state <s> ^operator <o> ^epmem.result.retrieved <x>) (<o> ^n <n>) (<x> ^{ <a> << item focus step >> } <y>) (<y> ^<b> <v>) --> (<s> ^log <l>) (<l> ^n <n> ^rattr <a> ^battr <b> ^bval <v>)}
sp {log*map (state <s> ^operator <o> ^epmem.result.mapping.node <nn>) (<o> ^n <n>) (<nn> ^retrieved <rv>) (<rv> ^<a> <v>) --> (<s> ^log <l>) (<l> ^n <n> ^mattr <a> ^mval <v>)}
sp {sub*log (state <ss> ^operator <o> ^superstate <s> ^epmem.result <r>) (<o> ^k <k>) (<s> ^step <n>) (<r> ^{ <at> << status memory-id match-score match-cardinality graph-match success failure >> } <v>) --> (<s> ^slog <l>) (<l> ^n <n> ^k <k> ^attr <at>)}
sp {sub*log-ret (state <ss> ^operator <o> ^superstate <s> ^epmem.result.retrieved <x>) (<o> ^k <k>) (<s> ^step <n>) (<x> ^item <y>) (<y> ^<b> <v>) --> (<s> ^slog <l>) (<l> ^n <n> ^k <k> ^battr <b> ^bval <v>)}
"""


def gen(seed, steps=10):
    rnd = random.Random(seed)
    out = ["epmem --set learning on"]
    if rnd.random() < 0.1: out.append("epmem --set graph-match off")
    if rnd.random() < 0.2: out.append(f"epmem --set graph-match-ordering {rnd.choice(['dfs', 'mcv'])}")
    if rnd.random() < 0.15: out.append("epmem --set trigger output")
    if rnd.random() < 0.15: out.append(f"epmem --set exclusions {rnd.choice(['focus', 'step', 'part'])}")
    out.append("sp {init (state <s> ^superstate nil -^step) --> (<s> ^operator <o> + =) (<o> ^name init)}")
    items = rnd.randint(2, 4)
    out.append(f"sp {{apply*init (state <s> ^operator.name init ^io.output-link <ol>) --> (<s> ^step 0 " +
               " ".join(f"^item <w{i}>" for i in range(items)) + ") (<ol> ^start yes) " +
               " ".join(obj(rnd, f"<w{i}>") + f" (<w{i}> ^id {i})" for i in range(items)) + "}")
    deep = set(n for n in range(2, steps) if rnd.random() < 0.3)
    for n in range(steps):
        out.append(f"sp {{propose*{n} (state <s> ^superstate nil ^step {n}) --> (<s> ^operator <o> + =) (<o> ^name {'deep' if n in deep else 'step'} ^n {n})}}")
    out.append("sp {apply*step (state <s> ^operator <o> ^step <n>) (<o> ^name step) --> (<s> ^step <n> - ^step (+ <n> 1))}")
    out.append("sp {apply*clear (state <s> ^operator.name << step deep >> ^epmem.command <c>) (<c> ^<a> <v>) --> (<c> ^<a> <v> -)}")
    for n in range(steps):
        for k in range(rnd.randint(0, 2)):
            out.append(change(rnd, n, k))
        if n >= 1 and rnd.random() < 0.7:
            out.append(f"sp {{cmd*{n} (state <s> ^operator.n {n} ^epmem.command <c>) --> {command(rnd, n, steps)}}}")
    # the substate of a deep operator: two sub-steps issuing commands on its own link, then a result
    out.append("sp {sub*init (state <ss> ^superstate <s> ^impasse no-change -^sstep) (<s> ^operator.name deep) --> (<ss> ^operator <o> + =) (<o> ^name sinit)}")
    out.append("sp {sub*apply-init (state <ss> ^operator.name sinit) --> (<ss> ^sstep 0)}")
    out.append("sp {sub*propose (state <ss> ^sstep <k> < 2) --> (<ss> ^operator <o> + =) (<o> ^name sstep ^k <k>)}")
    out.append("sp {sub*apply (state <ss> ^operator <o> ^sstep <k>) (<o> ^name sstep) --> (<ss> ^sstep <k> - ^sstep (+ <k> 1))}")
    out.append("sp {sub*clear (state <ss> ^operator.name sstep ^epmem.command <c>) (<c> ^<a> <v>) --> (<c> ^<a> <v> -)}")
    for k in range(2):
        if rnd.random() < 0.8:
            out.append(f"sp {{sub*cmd*{k} (state <ss> ^operator.k {k} ^epmem.command <c>) --> {command(rnd, 3, steps)}}}")
    out.append("sp {sub*finish (state <ss> ^sstep 2 ^superstate <s>) (<s> ^operator.name deep ^step <n>) --> (<s> ^step <n> - ^step (+ <n> 1))}")
    out.append(LOG)
    return "\n".join(out) + "\n", steps + 3 * len(deep) + 2


if __name__ == '__main__':
    d = sys.argv[1]; n = int(sys.argv[2]); start = int(sys.argv[3]) if len(sys.argv) > 3 else 0
    os.makedirs(d, exist_ok=True)
    for i in range(start, start + n):
        src, k = gen(i)
        open(os.path.join(d, f"f{i:03d}.soar"), 'w').write(src)
        open(os.path.join(d, f"f{i:03d}.n"), 'w').write(str(k))
