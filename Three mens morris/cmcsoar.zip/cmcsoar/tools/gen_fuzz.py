import random, sys
random.seed(int(sys.argv[1]) if len(sys.argv)>1 else 1)
N=int(sys.argv[2]) if len(sys.argv)>2 else 300
names="abcd"
def prop(x, req):
    acts=[f'.pref "s" (rv "o") .acceptable none none', f'.make "o" (rc "name") (rc "{x}")']
    if req: acts.insert(1, f'.pref "s" (rv "o") .require none none')
    return f'{{ name := "propose*{x}", conds := [pat (v "s") (c "superstate") (c "nil")], acts := [{", ".join(acts)}] }}'
def unary(i,x,k):
    return (f'{{ name := "unary-pref-{i}", conds := [acc (v "s") (c "operator") (v "x"), pat (v "x") (c "name") (c "{x}")], '
            f'acts := [.pref "s" (rv "x") .{k} none none] }}')
def binary(i,x,y,k):
    return (f'{{ name := "binary-pref-{i}", conds := [acc (v "s") (c "operator") (v "x"), pat (v "x") (c "name") (c "{x}"), '
            f'acc (v "s") (c "operator") (v "y"), pat (v "y") (c "name") (c "{y}")], '
            f'acts := [.pref "s" (rv "x") .{k} (some (rv "y")) none] }}')
progs=[]
for t in range(N):
    k=random.randint(1,4); ops=random.sample(names,k)
    rules=[prop(x, random.random()<0.08) for x in ops]
    for i in range(random.randint(0,5)):
        r=random.random()
        if r<0.5 and len(ops)>=2:
            x,y=random.sample(ops,2); kind=random.choice(["better","worse","better","worse","binaryIndiff"])
            rules.append(binary(i,x,y,kind))
        else:
            x=random.choice(ops); kind=random.choice(["reject","prohibit","best","worst","best","worst","unaryIndiff"])
            rules.append(unary(i,x,kind))
    progs.append(f'("f{t:03d}", [{", ".join(rules)}], 2)')
print("import Soar.Conform\nnamespace Soar.Fuzz\nopen Soar.DSL\n")
print("def tasks : List (String × List Production × Nat) := [\n  " + ",\n  ".join(progs) + "]\n")
print('''def emit : IO Unit := do
  for (n, pm, k) in tasks do
    IO.FS.writeFile s!"tests/fuzz/{n}.soar" ("\\n".intercalate (pm.map Production.toSoar))
    let st := St.init.run pm {} k
    IO.FS.writeFile s!"tests/fuzz/{n}.lean.trace" ("\\n".intercalate st.log)
    IO.FS.writeFile s!"tests/fuzz/{n}.n" (toString k)
    IO.FS.writeFile s!"tests/fuzz/{n}.lean.wm"
      ("\\n".intercalate (st.wm.map fun w => s!"{w.id} {w.attr.toSoar} {w.val.toSoar}{if w.acc then " +" else ""}"))
#eval emit
end Soar.Fuzz''')
