import random, sys
seed=int(sys.argv[1]) if len(sys.argv)>1 else 1
N=int(sys.argv[2]) if len(sys.argv)>2 else 100
random.seed(seed)
V=["x","y"]; VALS=[0,1,2]
def pat(i,a,v): return f'pat ({i}) ({a}) ({v})'
def prog(t):
    rules=[]
    # init
    rules.append('{ name := "propose-init", conds := [pat (v "s") (c "superstate") (c "nil"), nopat (v "s") (c "x") any], '
                 'acts := [.pref "s" (rv "o") .acceptable none none, .make "o" (rc "name") (rc "init")] }')
    rules.append('{ name := "apply-init", conds := [pat (v "s") (c "operator") (v "o"), pat (v "o") (c "name") (c "init")], '
                 f'acts := [.make "s" (rc "x") (ri {random.choice(VALS)}), .make "s" (rc "y") (ri {random.choice(VALS)})] }}')
    # elaborations
    nflags=random.randint(1,3)
    for k in range(nflags):
        var=random.choice(V); val=random.choice(VALS)
        conds=[f'pat (v "s") (c "{var}") (ci {val})']
        if random.random()<0.5:
            var2=random.choice(V); val2=random.choice(VALS)
            conds.append(f'nopat (v "s") (c "{var2}") (ci {val2})')
        if k>0 and random.random()<0.4:
            conds.append(f'pat (v "s") (c "flag{k-1}") (c "yes")')
        rules.append(f'{{ name := "elab-flag{k}", conds := [{", ".join(conds)}], acts := [.make "s" (rc "flag{k}") (rc "yes")] }}')
    # operators
    nops=random.randint(2,4); ops=[f"op{k}" for k in range(nops)]
    for o in ops:
        conds=['pat (v "s") (c "x") (v "xv")', 'pat (v "s") (c "y") (v "yv")']
        r=random.random()
        if r<0.4: conds.append(f'pat (v "s") (c "flag{random.randrange(nflags)}") (c "yes")')
        elif r<0.7: conds.append(f'nopat (v "s") (c "flag{random.randrange(nflags)}") (c "yes")')
        else:
            var=random.choice(V); conds.append(f'pat (v "s") (c "{var}") (sval [.rel .ne (.sym (.int {random.choice(VALS)}))])')
        rules.append(f'{{ name := "propose-{o}", conds := [{", ".join(conds)}], acts := [.pref "s" (rv "o") .acceptable none none, .make "o" (rc "name") (rc "{o}")] }}')
        var=random.choice(V); new=random.choice(VALS)
        rules.append(f'{{ name := "apply-{o}", conds := [pat (v "s") (c "operator") (v "o"), pat (v "o") (c "name") (c "{o}"), pat (v "s") (c "{var}") (v "old")], '
                     f'acts := [.remove "s" (rc "{var}") (rv "old"), .make "s" (rc "{var}") (ri {new})] }}')
    # preferences (no indifference: keeps selection deterministic)
    for i in range(random.randint(1,5)):
        if random.random()<0.6:
            a,b=random.sample(ops,2); kind=random.choice(["better","worse"])
            rules.append(f'{{ name := "pref-binary-{i}", conds := [acc (v "s") (c "operator") (v "a"), pat (v "a") (c "name") (c "{a}"), acc (v "s") (c "operator") (v "b"), pat (v "b") (c "name") (c "{b}")], '
                         f'acts := [.pref "s" (rv "a") .{kind} (some (rv "b")) none] }}')
        else:
            a=random.choice(ops); kind=random.choice(["best","worst","reject"])
            extra=f', pat (v "s") (c "flag{random.randrange(nflags)}") (c "yes")' if random.random()<0.5 else ''
            rules.append(f'{{ name := "pref-unary-{i}", conds := [acc (v "s") (c "operator") (v "a"), pat (v "a") (c "name") (c "{a}"){extra}], '
                         f'acts := [.pref "s" (rv "a") .{kind} none none] }}')
    return f'("g{t:03d}", [{", ".join(rules)}], 8)'
progs=[prog(t) for t in range(N)]
print("import Soar.Conform\nnamespace Soar.Fuzz2\nopen Soar.DSL\ndef sval (ts : List STest) : Test := ts\n")
print("def tasks : List (String × List Production × Nat) := [\n  " + ",\n  ".join(progs) + "]\n")
print('''def emit : IO Unit := do
  for (n, pm, k) in tasks do
    IO.FS.writeFile s!"tests/fuzz2/{n}.soar" ("\\n".intercalate (pm.map Production.toSoar))
    let st := St.init.run pm {} k
    IO.FS.writeFile s!"tests/fuzz2/{n}.lean.trace" ("\\n".intercalate st.log)
    IO.FS.writeFile s!"tests/fuzz2/{n}.n" (toString k)
    IO.FS.writeFile s!"tests/fuzz2/{n}.lean.wm"
      ("\\n".intercalate (st.wm.map fun w => s!"{w.id} {w.attr.toSoar} {w.val.toSoar}{if w.acc then " +" else ""}"))
#eval emit
end Soar.Fuzz2''')
