"""Random programs calling Soar 9.6.5's right-hand-side functions on random arguments.
Each result is also turned into a string with `string`, which prints real numbers with 17
digits, so results are compared to full precision. Writes tests/rhsfuzz/hNNN.soar and .n."""
import random, os, sys
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'tests', 'rhsfuzz')
os.makedirs(OUT, exist_ok=True)
N = int(sys.argv[1]) if len(sys.argv) > 1 else 100
def num(r):
    k = r.random()
    if k < 0.45: return str(r.randint(-400, 400))
    if k < 0.9: return f"{r.uniform(-400, 400):.{r.randint(1, 6)}f}"
    return r.choice(['0', '1', '-1', '0.0', '180', '-180', '360', '0.5', '2.5', '-2.5'])
def intv(r): return str(r.randint(-400, 400))
def call(r):
    f = r.choice(['min', 'max', 'round-off', 'round-off-heading', 'compute-heading', 'compute-range',
                  'extrapolate-x-position', 'extrapolate-y-position', 'haversine', 'dice', 'abs', 'sqrt',
                  'sin', 'cos', 'atan2', 'int', 'float', '+', '-', '*', '/', 'div', 'mod', 'strlen', 'ifeq', 'trim', 'cap'])
    if f in ('min', 'max', '+', '-', '*'): return f"({f} {' '.join(num(r) for _ in range(r.randint(1, 4)))})"
    if f in ('round-off', 'round-off-heading'):
        m = r.choice([intv(r), num(r), str(r.randint(1, 30)), f"{r.uniform(0.1, 20):.2f}"])
        return f"({f} {num(r)} {m})"
    if f in ('compute-heading', 'compute-range', 'haversine'): return f"({f} {num(r)} {num(r)} {num(r)} {num(r)})"
    if f.startswith('extrapolate'): return f"({f} {intv(r)} {intv(r)} {r.randint(0, 30)} {r.randint(0, 30)})"
    if f == 'dice': return f"(compute-dice-probability {r.randint(0, 12)} {r.randint(1, 8)} {r.randint(-1, 13)} {r.choice(['eq','ne','lt','gt','le','ge'])})"
    if f in ('abs', 'int', 'float', 'sin', 'cos'): return f"({f} {num(r)})"
    if f == 'sqrt': return f"(sqrt {abs(float(num(r)))})"
    if f == 'atan2': return f"(atan2 {num(r)} {num(r)})"
    if f == '/': return f"(/ {num(r)} {r.choice(['3', '7.5', '-2', '0.25'])})"
    if f in ('div', 'mod'): return f"({f} {intv(r)} {r.choice(['3', '7', '-2', '11'])})"
    if f == 'strlen': return f"(strlen {num(r)})"
    if f == 'ifeq': a = num(r); return f"(ifeq {a} {r.choice([a, num(r)])} {num(r)} {num(r)})"
    if f == 'trim': return f"(trim |{' ' * r.randint(0, 3)}x{r.randint(0, 9)}{' ' * r.randint(0, 3)}|)"
    return f"(capitalize-symbol |{r.choice(['abc', 'zed', '1x', 'Q'])}|)"
for i in range(N):
    r = random.Random(1000 + i)
    acts = []
    for j in range(25):
        c = call(r)
        acts.append(f"^v{j} {c} ^s{j} (string {c})")
    src = ("sp {propose*go (state <s> ^superstate nil -^done) --> (<s> ^operator <o> +) (<o> ^name go)}\n"
           "sp {apply*go (state <s> ^operator.name go) --> (<s> ^done yes ^r <r>) (<r> " + " ".join(acts) + ")}\n")
    open(os.path.join(OUT, f"h{i:03d}.soar"), 'w').write(src)
    open(os.path.join(OUT, f"h{i:03d}.n"), 'w').write("2\n")
