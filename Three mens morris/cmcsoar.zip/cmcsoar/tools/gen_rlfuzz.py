"""Random reinforcement-learning programs, written as Soar source."""
import random, sys, os
seed, N, out = int(sys.argv[1]), int(sys.argv[2]), sys.argv[3]
random.seed(seed); os.makedirs(out, exist_ok=True)
def val(): return random.choice([0, 0.5, -0.25, 1, 0.75, 2, -1, 0.1])
for t in range(N):
    k = random.randint(2, 3); ops = [f"op{i}" for i in range(k)]
    X = random.randint(2, 4); steps = random.randint(8, 20)
    R = []
    R.append("sp {propose*init (state <s> ^superstate nil -^step) --> (<s> ^operator <o> +) (<o> ^name init)}")
    R.append(f"sp {{apply*init (state <s> ^operator.name init) --> (<s> ^step 0 ^x {random.randrange(X)})}}")
    for o in ops:
        R.append(f"sp {{propose*{o} (state <s> ^step < {steps} -^pause) --> (<s> ^operator <o> + =) (<o> ^name {o})}}")
        for x in range(X):
            if random.random() < 0.8:
                R.append(f"sp {{rl*{o}*x{x} (state <s> ^operator <o> + ^x {x}) (<o> ^name {o}) --> (<s> ^operator <o> = {val()})}}")
        if random.random() < 0.4:
            R.append(f"sp {{rl*{o}*any (state <s> ^operator <o> +) (<o> ^name {o}) --> (<s> ^operator <o> = {val()})}}")
        nxt = [random.randrange(X) for _ in range(X)]
        for x in range(X):
            R.append(f"sp {{apply*{o}*x{x} (state <s> ^operator <o> ^x {x} ^step <t>) (<o> ^name {o}) --> "
                     f"(<s> ^x {x} - ^x {nxt[x]} ^step <t> - ^step (+ <t> 1) ^last {o})}}")
        R.append(f"sp {{apply*{o}*forget (state <s> ^operator <o> ^last {{ <> {o} <l> }}) (<o> ^name {o}) --> (<s> ^last <l> -)}}")
        for x in range(X):
            if random.random() < 0.5:
                R.append(f"sp {{reward*{o}*x{x} (state <s> ^reward-link <r> ^last {o} ^x {x}) --> (<r> ^reward.value {random.choice([1, -1, 0.5, 2, -0.5])})}}")
    # occasional gaps: a non-RL pause operator
    if random.random() < 0.6:
        px = random.randrange(X)
        R.append(f"sp {{elab*pause (state <s> ^x {px} ^last <l> -^paused <t> ^step <t>) --> (<s> ^pause yes)}}")
        R.append("sp {propose*pause (state <s> ^pause yes) --> (<s> ^operator <o> +) (<o> ^name pause)}")
        R.append("sp {apply*pause (state <s> ^operator.name pause ^step <t>) --> (<s> ^paused <t>)}")
    if random.random() < 0.5:
        R.append(f"sp {{finish (state <s> ^step {steps} ^reward-link <r>) --> (<r> ^reward.value 5) (halt)}}")
    name = f"r{t:03d}"
    open(f"{out}/{name}.soar", "w").write("\n".join(R) + "\n")
    open(f"{out}/{name}.n", "w").write("30")
