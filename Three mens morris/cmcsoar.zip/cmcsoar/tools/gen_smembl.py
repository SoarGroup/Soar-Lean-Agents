"""Random semantic-memory programs with base-level activation, for comparison with Soar 9.6.5
(tools/diff.py --smem).

The programs are those of gen_smemfuzz.py, with more steps (so that LTIs are accessed more
than the ten times Soar's history keeps) and random activation settings: base-level (mostly),
recency or frequency; base-update-policy stable, naive or incremental, with random
base-incremental-threshes; base-decay; base-unused-age-offset; base-inhibition;
activate-on-query and activate-on-add; and a small thresh, so that LTIs with thresh or more
augmentations, ordered by their own activation, occur.
"""
import random, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from gen_smemfuzz import gen as gen_base


def gen(seed):
    rnd = random.Random(10000 + seed)
    steps = rnd.choice([12, 16, 24, 30])
    src, k = gen_base(seed + 5000, steps)
    mode = rnd.choices(['base-level', 'recency', 'frequency'], [6, 1, 1])[0]
    st = [f"smem --set activation-mode {mode}"]
    if mode == 'base-level':
        pol = rnd.choice(['stable', 'naive', 'incremental'])
        st.append(f"smem --set base-update-policy {pol}")
        if pol == 'incremental' and rnd.random() < 0.7:
            th = sorted(rnd.sample(range(1, 12), rnd.randint(1, 3)))
            st.append("smem --set base-incremental-threshes " + ",".join(map(str, th)))
        if rnd.random() < 0.4:
            st.append(f"smem --set base-decay {rnd.choice(['0.3', '0.8', '0.5', '1.2'])}")
        if rnd.random() < 0.3:
            st.append(f"smem --set base-unused-age-offset {rnd.choice([1, 5, 20])}")
        if rnd.random() < 0.3:
            st.append("smem --set base-inhibition on")
    if rnd.random() < 0.2:
        st.append("smem --set activate-on-query off")
    if rnd.random() < 0.3:
        st.append("smem --set activate-on-add on")
    if rnd.random() < 0.5:
        st.append(f"smem --set thresh {rnd.choice([2, 3])}")
    return "\n".join(st) + "\n" + src, k


if __name__ == '__main__':
    d = sys.argv[1]; n = int(sys.argv[2]); start = int(sys.argv[3]) if len(sys.argv) > 3 else 0
    os.makedirs(d, exist_ok=True)
    for i in range(start, start + n):
        src, k = gen(i)
        open(os.path.join(d, f"b{i:03d}.soar"), 'w').write(src)
        open(os.path.join(d, f"b{i:03d}.n"), 'w').write(str(k))
