"""Random semantic-memory programs for comparison with Soar 9.6.5 (tools/diff.py --smem).

Each program loads random facts with `smem --add`, builds a few objects in working memory, and
then issues one random semantic-memory command per step: store, store-new, cue-based queries
(with any-value, constant and LTI-valued cue elements, prohibits, negative cues, math queries,
depth, link-to-ltm), non-cue-based retrievals, and malformed commands. What each step
retrieves is logged in working memory, so the final working memory records every result.
"""
import random, sys, os

ATTRS = ['color', 'shape', 'size', 'kind']
VALS = {'color': ['red', 'blue', 'green'], 'shape': ['round', 'square'],
        'size': [1, 2, 3, 4], 'kind': ['a', 'b']}

LOGGER = """sp {log*retrieved (state <s> ^operator <o> ^smem.result.retrieved <x>) (<o> ^name step ^n <n>) (<x> ^<a> <v>) --> (<s> ^log <l>) (<l> ^n <n> ^attr <a> ^val <v>)}
sp {log*status (state <s> ^operator <o> ^smem.result <r>) (<o> ^name step ^n <n>) (<r> ^{ <st> << success failure bad-cmd >> } <v>) --> (<s> ^log <l>) (<l> ^n <n> ^status <st>)}
sp {log*depth (state <s> ^operator <o> ^smem.result.depth-retrieved <x>) (<o> ^name step ^n <n>) (<x> ^<a> <v>) --> (<s> ^log <l>) (<l> ^n <n> ^dattr <a> ^dval <v>)}
sp {keep*last (state <s> ^operator.name step ^smem.result.retrieved <x>) --> (<s> ^last <x>)}
"""


def val(a, rnd):
    return rnd.choice(VALS[a])


def gen(seed, steps=10):
    rnd = random.Random(seed)
    out = ["smem --enable"]
    # facts
    nf = rnd.randint(2, 6)
    clauses = []
    for i in range(nf):
        augs = [f"^{a} {val(a, rnd)}" for a in rnd.sample(ATTRS, rnd.randint(1, 3))]
        if i > 0 and rnd.random() < 0.4:
            augs.append(f"^link <f{rnd.randrange(i)}>")
        clauses.append(f"  (<f{i}> " + " ".join(augs) + ")")
    out.append("smem --add {\n" + "\n".join(clauses) + "\n}")
    out.append("sp {init (state <s> ^superstate nil -^step) --> (<s> ^operator <o> + =) (<o> ^name init)}")
    # working-memory objects
    objs = []
    for j in range(3):
        augs = [f"^{a} {val(a, rnd)}" for a in rnd.sample(ATTRS, rnd.randint(1, 3))]
        if j > 0 and rnd.random() < 0.5:
            augs.append(f"^link <w{rnd.randrange(j)}>")
        objs.append(f"(<w{j}> " + " ".join(augs) + ")")
    out.append("sp {apply*init (state <s> ^operator.name init) --> (<s> ^step 0 ^obj <w0> <w1> <w2>) "
               + " ".join(objs) + " (<w0> ^id 0) (<w1> ^id 1) (<w2> ^id 2)}")
    out.append(f"sp {{propose (state <s> ^step <n> < {steps}) --> (<s> ^operator <o> + =) (<o> ^name step ^n <n>)}}")
    out.append("sp {apply*step (state <s> ^operator <o> ^step <n>) (<o> ^name step) --> (<s> ^step <n> - ^step (+ <n> 1))}")
    # each step clears the command and issues a new one
    out.append("sp {apply*clear (state <s> ^operator.name step ^smem.command <c>) (<c> ^<a> <v>) --> (<c> ^<a> <v> -)}")
    for n in range(steps):
        kind = rnd.choices(['store', 'store-new', 'query', 'retrieve', 'bad', 'none'],
                           [3, 1, 6, 2, 1, 1])[0]
        head = f"sp {{cmd*{n} (state <s> ^operator.n {n} ^smem.command <c>"
        if kind == 'store':
            ids = rnd.sample(range(3), rnd.randint(1, 2))
            conds = "".join(f" ^obj <x{i}>)(<x{i}> ^id {i})" for i in ids)
            # conditions must be (state ...) then object conditions
            body = head + ")" + "".join(f" (<s> ^obj <x{i}>) (<x{i}> ^id {i})" for i in ids)
            body += " --> (<c> " + " ".join(f"^store <x{i}>" for i in ids) + ")"
            # sometimes change an object before storing it
            if rnd.random() < 0.4:
                i = ids[0]; a = rnd.choice(ATTRS)
                body += f" (<x{i}> ^{a} {val(a, rnd)})"
            out.append(body + "}")
        elif kind == 'store-new':
            i = rnd.randrange(3)
            body = head + f") (<s> ^obj <x>) (<x> ^id {i}) --> (<c> ^store-new <x>"
            if rnd.random() < 0.5:
                body += f" ^link-to-new-ltm {rnd.choice(['yes', 'no'])}"
            out.append(body + ")}")
        elif kind == 'query':
            attrs = rnd.sample(ATTRS + ['link'], rnd.randint(1, 3))
            cue = []
            extra = []
            for a in attrs:
                if a == 'link' or rnd.random() < 0.3:
                    cue.append(f"^{a} <any{a}>")
                else:
                    cue.append(f"^{a} {val(a, rnd)}")
            body = head + ")"
            acts = [f"(<c> ^query <q>)", "(<q> " + " ".join(cue) + ")"]
            if rnd.random() < 0.3:
                body += " (<s> ^last <p>)"
                acts.append("(<c> ^prohibit <p>)")
            if rnd.random() < 0.25:
                a = rnd.choice(ATTRS)
                acts.append(f"(<c> ^neg-query <nq>) (<nq> ^{a} {val(a, rnd)})")
            if rnd.random() < 0.25:
                cond = rnd.choice(['max <mx>', 'min <mn>', 'less 3', 'greater 2', 'less-or-equal 2', 'greater-or-equal 3'])
                acts.append(f"(<c> ^math-query <m>) (<m> ^size <mz>) (<mz> ^{cond})")
            if rnd.random() < 0.25:
                acts.append(f"(<c> ^depth {rnd.randint(2, 3)})")
            if rnd.random() < 0.15:
                acts.append("(<c> ^link-to-ltm no)")
            out.append(body + " --> " + " ".join(acts) + "}")
        elif kind == 'retrieve':
            if rnd.random() < 0.5:
                out.append(head + f") (<s> ^last <p>) --> (<c> ^retrieve <p>)}}")
            else:
                i = rnd.randrange(3)
                out.append(head + f") (<s> ^obj <x>) (<x> ^id {i}) --> (<c> ^retrieve <x>)}}")
        elif kind == 'bad':
            out.append(head + ") (<s> ^obj <x>) (<x> ^id 0) --> (<c> ^store <x> ^query <q>) (<q> ^color red)}")
    out.append(LOGGER)
    return "\n".join(out) + "\n", steps + 2


if __name__ == '__main__':
    d = sys.argv[1]; n = int(sys.argv[2]); start = int(sys.argv[3]) if len(sys.argv) > 3 else 0
    os.makedirs(d, exist_ok=True)
    for i in range(start, start + n):
        src, k = gen(i)
        open(os.path.join(d, f"m{i:03d}.soar"), 'w').write(src)
        open(os.path.join(d, f"m{i:03d}.n"), 'w').write(str(k))
