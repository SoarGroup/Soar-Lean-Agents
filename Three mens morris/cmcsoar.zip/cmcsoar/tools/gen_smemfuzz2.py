"""Random semantic-memory programs with substates and i-supported commands
(tools/diff.py --smem).

Like gen_smemfuzz.py, plus: some top-level steps are `deep` operators with no application,
so an operator no-change substate issues semantic-memory commands on its own link and returns
a result that ends the impasse; and some commands are created by i-supported elaboration rules
rather than by operator application.
"""
import random, sys, os

ATTRS = ['color', 'shape', 'size', 'kind']
VALS = {'color': ['red', 'blue', 'green'], 'shape': ['round', 'square'],
        'size': [1, 2, 3, 4], 'kind': ['a', 'b']}


def val(a, rnd):
    return rnd.choice(VALS[a])


def command(rnd, name, lhs, objs, last):
    """A rule creating one random command. `lhs` binds <c> (the command) and anything else;
    `objs` is the state variable holding ^obj; `last` the one holding ^last."""
    kind = rnd.choices(['store', 'store-new', 'query', 'retrieve', 'bad'], [3, 1, 6, 2, 1])[0]
    if kind == 'store':
        ids = rnd.sample(range(3), rnd.randint(1, 2))
        conds = "".join(f" ({objs} ^obj <x{i}>) (<x{i}> ^id {i})" for i in ids)
        acts = "(<c> " + " ".join(f"^store <x{i}>" for i in ids) + ")"
        return f"sp {{{name} {lhs}{conds} --> {acts}}}"
    if kind == 'store-new':
        i = rnd.randrange(3)
        extra = f" ^link-to-new-ltm {rnd.choice(['yes', 'no'])}" if rnd.random() < 0.5 else ""
        return f"sp {{{name} {lhs} ({objs} ^obj <x>) (<x> ^id {i}) --> (<c> ^store-new <x>{extra})}}"
    if kind == 'query':
        attrs = rnd.sample(ATTRS + ['link'], rnd.randint(1, 3))
        cue = [f"^{a} <any{a}>" if a == 'link' or rnd.random() < 0.3 else f"^{a} {val(a, rnd)}" for a in attrs]
        conds = ""
        acts = ["(<c> ^query <q>)", "(<q> " + " ".join(cue) + ")"]
        if rnd.random() < 0.3:
            conds += f" ({last} ^last <p>)"
            acts.append("(<c> ^prohibit <p>)")
        if rnd.random() < 0.25:
            a = rnd.choice(ATTRS)
            acts.append(f"(<c> ^neg-query <nq>) (<nq> ^{a} {val(a, rnd)})")
        if rnd.random() < 0.25:
            cond = rnd.choice(['max <mx>', 'min <mn>', 'less 3', 'greater 2'])
            acts.append(f"(<c> ^math-query <m>) (<m> ^size <mz>) (<mz> ^{cond})")
        if rnd.random() < 0.25:
            acts.append(f"(<c> ^depth {rnd.randint(2, 3)})")
        if rnd.random() < 0.15:
            acts.append("(<c> ^link-to-ltm no)")
        return f"sp {{{name} {lhs}{conds} --> " + " ".join(acts) + "}"
    if kind == 'retrieve':
        if rnd.random() < 0.5:
            return f"sp {{{name} {lhs} ({last} ^last <p>) --> (<c> ^retrieve <p>)}}"
        return f"sp {{{name} {lhs} ({objs} ^obj <x>) (<x> ^id {rnd.randrange(3)}) --> (<c> ^retrieve <x>)}}"
    return f"sp {{{name} {lhs} ({objs} ^obj <x>) (<x> ^id 0) --> (<c> ^store <x> ^query <q>) (<q> ^color red)}}"


def gen(seed, steps=8):
    rnd = random.Random(seed)
    out = ["smem --enable"]
    clauses = []
    for i in range(rnd.randint(2, 6)):
        augs = [f"^{a} {val(a, rnd)}" for a in rnd.sample(ATTRS, rnd.randint(1, 3))]
        if i > 0 and rnd.random() < 0.4:
            augs.append(f"^link <f{rnd.randrange(i)}>")
        clauses.append(f"  (<f{i}> " + " ".join(augs) + ")")
    out.append("smem --add {\n" + "\n".join(clauses) + "\n}")
    out.append("sp {init (state <s> ^superstate nil -^step) --> (<s> ^operator <o> + =) (<o> ^name init)}")
    objs = []
    for j in range(3):
        augs = [f"^{a} {val(a, rnd)}" for a in rnd.sample(ATTRS, rnd.randint(1, 3))]
        if j > 0 and rnd.random() < 0.5:
            augs.append(f"^link <w{rnd.randrange(j)}>")
        objs.append(f"(<w{j}> " + " ".join(augs) + ")")
    out.append("sp {apply*init (state <s> ^operator.name init) --> (<s> ^step 0 ^obj <w0> <w1> <w2>) "
               + " ".join(objs) + " (<w0> ^id 0) (<w1> ^id 1) (<w2> ^id 2)}")
    deep = set(n for n in range(1, steps) if rnd.random() < 0.35)
    for n in range(steps):
        opname = 'deep' if n in deep else 'step'
        out.append(f"sp {{propose*{n} (state <s> ^superstate nil ^step {n}) --> (<s> ^operator <o> + =) (<o> ^name {opname} ^n {n})}}")
    out.append("sp {apply*step (state <s> ^operator <o> ^step <n>) (<o> ^name step) --> (<s> ^step <n> - ^step (+ <n> 1))}")
    out.append("sp {apply*clear (state <s> ^operator.name << step deep >> ^smem.command <c>) (<c> ^<a> <v>) --> (<c> ^<a> <v> -)}")
    for n in range(steps):
        if rnd.random() < 0.2:
            continue
        if rnd.random() < 0.3:
            # an i-supported command, present while the state is at this step
            out.append(command(rnd, f"elab*cmd*{n}", f"(state <s> ^superstate nil ^step {n} ^smem.command <c>)", "<s>", "<s>"))
        else:
            out.append(command(rnd, f"cmd*{n}", f"(state <s> ^operator.n {n} ^smem.command <c>)", "<s>", "<s>"))
    # rules that remove retrieved augmentations and status elements
    for n in range(steps):
        if rnd.random() < 0.15:
            a = rnd.choice(ATTRS)
            # (removing a status element as well triggers a use-after-free in Soar 9.6.5: semantic
            # memory later removes an unrelated preference; see the report)
            out.append(f"sp {{zap*{n} (state <s> ^operator.n {n} ^smem.result <r>) (<r> ^retrieved <x>) (<x> ^{a} <v>) --> (<x> ^{a} <v> -)}}")
    # the substate of a deep operator: three sub-steps with commands on its own link, then a result
    out.append("sp {sub*init (state <ss> ^superstate <s> ^impasse no-change -^sstep) (<s> ^operator.name deep) --> (<ss> ^operator <o> + =) (<o> ^name sinit)}")
    out.append("sp {sub*apply-init (state <ss> ^operator.name sinit) --> (<ss> ^sstep 0)}")
    out.append("sp {sub*propose (state <ss> ^sstep <k> < 3) --> (<ss> ^operator <o> + =) (<o> ^name sstep ^k <k>)}")
    out.append("sp {sub*apply (state <ss> ^operator <o> ^sstep <k>) (<o> ^name sstep) --> (<ss> ^sstep <k> - ^sstep (+ <k> 1))}")
    out.append("sp {sub*clear (state <ss> ^operator.name sstep ^smem.command <c>) (<c> ^<a> <v>) --> (<c> ^<a> <v> -)}")
    for k in range(3):
        if rnd.random() < 0.2:
            continue
        out.append(command(rnd, f"sub*cmd*{k}", f"(state <ss> ^operator.k {k} ^smem.command <c> ^superstate <s>)", "<s>", "<ss>"))
    out.append("sp {sub*finish (state <ss> ^sstep 3 ^superstate <s>) (<s> ^operator.name deep ^step <n>) --> (<s> ^step <n> - ^step (+ <n> 1))}")
    out.append("""sp {log*retrieved (state <s> ^operator <o> ^smem.result.retrieved <x>) (<o> ^n <n>) (<x> ^<a> <v>) --> (<s> ^log <l>) (<l> ^n <n> ^attr <a> ^val <v>)}
sp {log*status (state <s> ^operator <o> ^smem.result <r>) (<o> ^n <n>) (<r> ^{ <st> << success failure bad-cmd >> } <v>) --> (<s> ^log <l>) (<l> ^n <n> ^status <st>)}
sp {log*depth (state <s> ^operator <o> ^smem.result.depth-retrieved <x>) (<o> ^n <n>) (<x> ^<a> <v>) --> (<s> ^log <l>) (<l> ^n <n> ^dattr <a> ^dval <v>)}
sp {keep*last (state <s> ^superstate nil ^operator.n <n> ^smem.result.retrieved <x>) --> (<s> ^last <x>)}
sp {sub*log (state <ss> ^operator <o> ^superstate <s> ^smem.result <r>) (<o> ^name sstep ^k <k>) (<s> ^step <n>) (<r> ^{ <st> << success failure bad-cmd >> } <v>) --> (<s> ^slog <l>) (<l> ^n <n> ^k <k> ^status <st>)}
sp {sub*log-ret (state <ss> ^operator <o> ^superstate <s> ^smem.result.retrieved <x>) (<o> ^name sstep ^k <k>) (<s> ^step <n>) (<x> ^<a> <v>) --> (<s> ^slog <l>) (<l> ^n <n> ^k <k> ^attr <a> ^val <v>)}
sp {sub*keep (state <ss> ^operator.name sstep ^smem.result.retrieved <x>) --> (<ss> ^last <x>)}
""")
    return "\n".join(out) + "\n", steps * 4 + 2


if __name__ == '__main__':
    d = sys.argv[1]; n = int(sys.argv[2]); start = int(sys.argv[3]) if len(sys.argv) > 3 else 0
    os.makedirs(d, exist_ok=True)
    for i in range(start, start + n):
        src, k = gen(i)
        open(os.path.join(d, f"d{i:03d}.soar"), 'w').write(src)
        open(os.path.join(d, f"d{i:03d}.n"), 'w').write(str(k))
