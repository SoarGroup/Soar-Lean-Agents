"""Random semantic-memory programs with spreading activation, for comparison with Soar 9.6.5
(tools/diff.py --smem).

The programs are those of gen_smemfuzz.py, with a larger store added first: a random graph of
LTIs with the same attributes as the program's objects and ^link edges among them (so that
fingerprints have several levels and equal fan weights), and random spreading settings:
continue probability, baseline, depth limit, spreading limit (small values make the limit bind),
loop avoidance, and, with working-memory activation on, spreading-wma-source. Activation is base-level
(which spreading requires), with a random update policy. Edge updating is left off: in Soar 9.6.5 it reads an
identifier field of constant values (undefined behaviour; report Section 12). LTIs are added
with explicit numbers, because Soar numbers the new LTIs of one smem --add in an order that
varies from run to run, and with spreading the numbers decide the order of the walk.
"""
import random, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from gen_smemfuzz import gen as gen_base

EDGE = os.environ.get('EDGE') == '1'
KINDS = ['a', 'b']
SHAPES = ['round', 'square']
COLORS = ['red', 'green', 'blue']


def graph(rnd):
    n = rnd.randint(4, 10)
    lines = []
    for i in range(n):
        aug = [f"^kind {rnd.choice(KINDS)}"]
        if rnd.random() < 0.7: aug.append(f"^shape {rnd.choice(SHAPES)}")
        if rnd.random() < 0.5: aug.append(f"^color {rnd.choice(COLORS)}")
        if rnd.random() < 0.5: aug.append(f"^size {rnd.randint(1, 4)}")
        for j in rnd.sample(range(n), rnd.randint(0, 3)):
            aug.append(f"^link @{j + 1}")
        lines.append(f"  (@{i + 1} " + " ".join(aug) + ")")
    return "smem --add {\n" + "\n".join(lines) + "\n}\n", n


def gen(seed):
    rnd = random.Random(30000 + seed)
    steps = rnd.choice([16, 24, 30])
    src, k = gen_base(seed + 7000, steps)
    # spreading needs base-level activation, set first; its parameters are set before it is on
    st = ["smem --set activation-mode base-level"]
    if rnd.random() < 0.5:
        st.append(f"smem --set spreading-continue-probability {rnd.choice(['0.5', '0.8', '0.9', '0.95'])}")
    if rnd.random() < 0.4:
        st.append(f"smem --set spreading-baseline {rnd.choice(['0.01', '0.001', '0.0001', '0.05'])}")
    if rnd.random() < 0.5:
        st.append(f"smem --set spreading-depth-limit {rnd.choice([1, 2, 3, 5, 10])}")
    if rnd.random() < 0.4:
        st.append(f"smem --set spreading-limit {rnd.choice([3, 5, 10, 50, 300])}")
    if rnd.random() < 0.3:
        st.append("smem --set spreading-loop-avoidance on")
    st.append(f"smem --set base-update-policy {rnd.choice(['stable', 'naive', 'incremental'])}")
    if rnd.random() < 0.3:
        st.append(f"smem --set base-unused-age-offset {rnd.choice([5, 100, 500])}")
    if rnd.random() < (1.0 if EDGE else 0.4):
        st.insert(0, "wma --set activation on")
        if rnd.random() < 0.7:
            st.append("smem --set spreading-wma-source on")
    st.append("smem --set spreading on")
    if EDGE and 'wma --set activation on' in st:
        st.append("smem --set spreading-edge-updating on")
        if rnd.random() < 0.5:
            st.append(f"smem --set spreading-edge-update-factor {rnd.choice(['0.5', '0.9', '0.99'])}")
    g, n = graph(rnd)
    # the program's own smem --add uses explicit LTI numbers too: Soar 9.6.5 numbers the new
    # LTIs of one smem --add in the order of a set of pointers, which varies from run to run,
    # and with spreading the numbers decide the order in which children are walked
    import re
    src = re.sub(r'<f(\d+)>', lambda m: f"@{n + 1 + int(m.group(1))}", src)
    lines = src.split("\n")
    # the graph is added right after smem --enable
    out = [lines[0]] + st + [g] + lines[1:]
    return "\n".join(out), k


if __name__ == '__main__':
    d = sys.argv[1]; n = int(sys.argv[2]); start = int(sys.argv[3]) if len(sys.argv) > 3 else 0
    os.makedirs(d, exist_ok=True)
    for i in range(start, start + n):
        src, k = gen(i)
        open(os.path.join(d, f"p{i:03d}.soar"), 'w').write(src)
        open(os.path.join(d, f"p{i:03d}.n"), 'w').write(str(k))
