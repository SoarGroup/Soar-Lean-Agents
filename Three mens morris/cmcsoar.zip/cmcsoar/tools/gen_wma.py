"""Random programs with working-memory activation, for comparison with Soar 9.6.5
(tools/diff.py; the final working memory carries each element's activation).

Each program runs a counter-driven operator loop over a few o-supported objects: application
rules add, change and remove attributes of the objects (some multi-valued), i-supported
elaborations (some on other elaborations) test the objects and the counter, and some rules test
the same element twice. Settings are random: decay rate and threshold, Petrov's approximation,
and forgetting (naive, bsearch or on, sometimes fake), so that elements decay below the
threshold and are forgotten. Elaborations make a fresh value for each counter value, so an
i-supported element is not kept across a change of the o-supported element its instantiation
tested (where Soar reads a freed preference; see `WmaSt.stale`). By default no rule makes the
same o-supported value twice in one cycle and no two instantiations of one rule make the same
i-supported element; with DUPS=1 such rules are added (which preference Soar keeps, or which
supports the element, follows the order of the Rete and of preference assertion, both modeled;
tests/wmadup).
"""
import random, sys, os

# DUPS=1: also make the duplicate preferences avoided above (two instantiations of one rule
# making the same o-supported value in one cycle, or the same i-supported element), whose
# handling follows the Rete's token order (now modeled, Soar/Rete.lean)
DUPS = os.environ.get('DUPS') == '1'

ATTRS = ['p', 'q', 'r']
VALS = ['v1', 'v2', 'v3']


def gen(seed):
    rnd = random.Random(20000 + seed)
    nobj = rnd.randint(1, 3)
    steps = rnd.choice([10, 15, 20, 30])
    st = ["wma --set activation on"]
    if rnd.random() < 0.7:
        st.insert(0, f"wma --set decay-rate {rnd.choice(['0.3', '0.5', '0.7', '0.9', '1'])}")
    if rnd.random() < 0.7:
        st.insert(0, f"wma --set decay-thresh {rnd.choice(['0.1', '0.3', '0.5', '1', '2'])}")
    if rnd.random() < 0.3:
        st.insert(0, "wma --set petrov-approx on")
    fm = rnd.choices(['off', 'naive', 'bsearch', 'on'], [2, 2, 2, 3])[0]
    if fm != 'off':
        st.insert(0, f"wma --set forgetting {fm}")
        if rnd.random() < 0.2:
            st.insert(0, "wma --set fake-forgetting on")
    rules = []
    inits = " ".join(f"^obj <o{i}>" for i in range(nobj))
    objs = " ".join(f"(<o{i}> ^id {i} ^{rnd.choice(ATTRS)} {rnd.choice(VALS)})" for i in range(nobj))
    rules.append("sp {propose*init (state <s> ^superstate nil -^count) --> (<s> ^operator <o> + =) (<o> ^name init)}")
    rules.append(f"sp {{apply*init (state <s> ^operator.name init) --> (<s> ^count 0 {inits}) {objs}}}")
    rules.append(f"sp {{propose*step (state <s> ^count {{<c> < {steps}}}) --> (<s> ^operator <o> + =) (<o> ^name step)}}")
    rules.append("sp {apply*step (state <s> ^operator.name step ^count <c>) --> (<s> ^count <c> - ^count (+ <c> 1))}")
    for k in range(rnd.randint(2, 6)):
        i = rnd.randint(0, nobj - 1)
        a = rnd.choice(ATTRS)
        cond = f"(state <s> ^operator.name step ^count <c> ^obj <x>) (<x> ^id {i})"
        if rnd.random() < 0.5:
            cond += f" (<s> ^count {{> {rnd.randint(0, steps // 2)}}})"
        kind = rnd.choices(['add', 'set', 'del', 'touch', 'mv'], [2, 3, 1, 2, 2])[0]
        if kind == 'add':
            rules.append(f"sp {{apply*add{k} {cond} --> (<x> ^{a} {rnd.choice(VALS)})}}")
        elif kind == 'set':
            rules.append(f"sp {{apply*set{k} {cond} (<x> ^{a} <old>) --> (<x> ^{a} <old> - ^{a} {rnd.choice(VALS)})}}")
        elif kind == 'del':
            rules.append(f"sp {{apply*del{k} {cond} (<x> ^{a} <old>) --> (<x> ^{a} <old> -)}}")
        elif kind == 'touch':
            b = rnd.choice(ATTRS)
            rules.append(f"sp {{apply*touch{k} {cond} (<x> ^{a} <v> ^{b} <w>) --> (<x> ^seen <n>) (<n> ^c <c> ^v <v>)}}")
        else:
            rules.append(f"sp {{apply*mv{k} {cond} --> (<x> ^m (+ <c> {k}))}}")
    for k in range(rnd.randint(1, 5)):
        i = rnd.randint(0, nobj - 1)
        a = rnd.choice(ATTRS)
        kind = rnd.choices(['plain', 'count', 'twice', 'chain'], [3, 2, 1, 2])[0]
        if kind == 'plain':
            rules.append(f"sp {{elab{k} (state <s> ^obj <x>) (<x> ^id {i} ^{a} <v>) --> (<s> ^e{k} <v>)}}")
        elif kind == 'count':
            rules.append(f"sp {{elab{k} (state <s> ^count <c> ^obj <x>) (<x> ^id {i} ^{a} <v>) --> (<s> ^e{k} <n>) (<n> ^c <c> ^v <v>)}}")
        elif kind == 'twice':
            rules.append(f"sp {{elab{k} (state <s> ^count <c> {{> 0}}) --> (<s> ^e{k} (+ <c> 100))}}")
        else:
            rules.append(f"sp {{elab{k} (state <s> ^count <c> ^obj <x>) (<x> ^id {i}) (<s> ^e{max(0, k - 1)} <z>) --> (<s> ^e{k} <n>) (<n> ^c <c> ^z <z>)}}")
    if DUPS:
        for k in range(rnd.randint(1, 3)):
            a = rnd.choice(ATTRS); v = rnd.choice(VALS)
            if rnd.random() < 0.5:
                # o-supported: every object's instantiation makes the same value
                rules.append(f"sp {{apply*dup{k} (state <s> ^operator.name step ^count <c> ^obj <x>) (<x> ^id <i>) --> (<s> ^d{k} {v})}}")
            else:
                # i-supported: one element from every object's instantiation
                rules.append(f"sp {{elab*dup{k} (state <s> ^obj <x>) (<x> ^{a} <w>) --> (<s> ^f{k} {v})}}")
    return "\n".join(st + rules) + "\n", steps + 2


if __name__ == '__main__':
    d = sys.argv[1]; n = int(sys.argv[2]); start = int(sys.argv[3]) if len(sys.argv) > 3 else 0
    os.makedirs(d, exist_ok=True)
    for i in range(start, start + n):
        src, k = gen(i)
        open(os.path.join(d, f"w{i:03d}.soar"), 'w').write(src)
        open(os.path.join(d, f"w{i:03d}.n"), 'w').write(str(k))
