"""Compare the i- or o-support of semantic- and episodic-memory result elements (those on a
state's ^smem.result or ^epmem.result) between Soar 9.6.5 and soar-lean, after each program's
decision cycles. Usage: memsupport.py DIR [settings...]"""
import soar_sml as sml, re, sys, glob, os, subprocess
EXE = os.environ.get('SOAR_LEAN', os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '.lake', 'build', 'bin', 'soar-lean'))
d = sys.argv[1]; os.chdir(d)
k = sml.Kernel.CreateKernelInCurrentThread(True, 0)
SET = ["decide indifferent-selection --first", "srand 0"]
ok = tot = 0
for f in sorted(glob.glob(os.environ.get('ONLY', '') and f"*{os.environ['ONLY']}*.soar" or '*.soar')):
    name = f[:-5]
    if not os.path.exists(name + '.n'): continue
    n = open(name + '.n').read().strip()
    a = k.CreateAgent(name)
    a.ExecuteCommandLine("chunk never")
    for c in SET: a.ExecuteCommandLine(c)
    a.ExecuteCommandLine("source " + f)
    a.ExecuteCommandLine(f"run {n} -d")
    a.ExecuteCommandLine("run 2 -p")   # finish the last cycle, as diff.py does
    soar = []
    ids = set(re.findall(r'\^(?:smem|epmem) (\w+)', a.ExecuteCommandLine("print --depth 1 s1")))
    states = set(['S1'])
    out = a.ExecuteCommandLine("print --stack")
    states |= set(re.findall(r'(S\d+)', out))
    for st in states:
        for mem in ('smem', 'epmem'):
            r = a.ExecuteCommandLine(f"print {st} --depth 1")
            m = re.search(rf'\^{mem} (\w+)', r)
            if not m: continue
            r2 = a.ExecuteCommandLine(f"print {m.group(1)} --depth 1")
            m2 = re.search(r'\^result (\w+)', r2)
            if not m2: continue
            r3 = a.ExecuteCommandLine(f"print {m2.group(1)} --depth 1")
            for at in set(re.findall(r'\^([\w-]+)', r3)):
                p = a.ExecuteCommandLine(f"preferences {m2.group(1)} {at} --names")
                # only the memory system's own preferences ("From |Memory System Recall|" or no source)
                for sup, src in re.findall(r'\)\s+(:[IO])[^\n]*\n(?:\s+From ([^\n]*))?', p):
                    if not src or 'Memory System' in src: soar.append(f"{at} {sup}")
    k.DestroyAgent(a)
    subprocess.run([EXE, f, '-d', n, '--settings', ';'.join(SET), '--mem-support', name + '.exe.ms'], capture_output=True, text=True, timeout=600)
    lean = open(name + '.exe.ms').read().split('\n') if os.path.exists(name + '.exe.ms') else []
    lean = sorted(x for x in lean if x)
    tot += 1
    if sorted(soar) == lean: ok += 1; print("==", name, "MATCH", len(lean))
    else: print("==", name, "DIFF soar", sorted(soar), "lean", lean)
print(f"## {ok} / {tot}")
