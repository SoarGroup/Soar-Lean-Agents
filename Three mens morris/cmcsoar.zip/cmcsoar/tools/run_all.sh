#!/bin/bash
# Compare every test set in tests/ with Soar 9.6.5, with the options each set needs.
# Usage: tools/run_all.sh [OUTFILE]
# Needs: lake build soar-lean; pip install soar-sml==9.6.5. Takes several hours on one core;
# the groups below are independent and can be run in parallel (GROUP=A tools/run_all.sh ...).
cd "$(dirname "$0")/.."
OUT=${1:-results.txt}; : > "$OUT"
T=tools/diff.py
run() { dir=$1; shift; r=$(python3 $T tests/$dir "$@" 2>&1); tot=$(echo "$r" | grep -c '^== '); ok=$(echo "$r" | grep -c '^== .* MATCH'); echo "## $dir $* : $ok / $tot" | tee -a "$OUT"; echo "$r" | grep '^== ' | grep -v MATCH >> "$OUT"; }
g() { [ -z "$GROUP" ] || [ "$GROUP" = "$1" ]; }
# A: decision cycle, real agents, reinforcement learning (with Soar's choices replayed)
g A && { run rlsettings --rl --explore; run test --replay; run fuzz --replay; run fuzz2 --replay; run real --replay
         run rl --rl --explore; run rltests --rl --explore; run rlhier --rl --explore; run rlfuzz --rl --explore; }
# B: semantic memory
g B && { run smemcli --smem; run smembl --smem; run smem --smem; run smemextra --smem; run smemfuzz --smem
         run smemfuzz2 --smem; run realsmem --smem; run epsem --epmem; }
# C: episodic memory
g C && { run epltichange --epmem --smem; run epsettings --epmem; run epfuzz --epmem; run epfuzz2 --epmem
         run realep --epmem --replay
         run dbfile --smem --epmem; }
# W: working-memory activation and spreading activation
g W && { run wma --exe; run realwma --exe --epmem --replay; run wmafuzz --exe; run wmadup --exe; run epwma --epmem
         run smemwma --smem; run smemspread --smem; }
# D: chunking
g D && [ -z "$NOCHUNK" ] && { run chunkmem --chunk --epmem --smem; run chunkall --chunk; run chunkextra --chunk; run chunkdeep --chunk
         run chunkdemo --chunk --replay; }
# E: the rest, and the sets run again without replaying Soar's choices
g E && { run input --exe; run rlvariants --rl --explore; run rltemplates --rl --explore; run lti --smem
         run explore --exe; run rhslib --exe; run rhsfuzz --exe; run settings --exe; run parser --exe
         run rlsettings --rl --explore --noreplay; run rl --rl --explore --noreplay
         run rltests --rl --explore --noreplay; run rlhier --rl --explore --noreplay
         run rlfuzz --rl --explore --noreplay; run rlvariants --rl --explore --noreplay
         run rltemplates --rl --explore --noreplay; run real --exe; run test --exe; run fuzz --exe; run fuzz2 --exe; }
echo DONE >> "$OUT"
