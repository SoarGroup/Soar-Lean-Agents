"""Input from an environment, for comparisons with Soar 9.6.5.

An input script (X.input) lists changes to the input link, one per line:

    K + ID ^attr VALUE      add an element before the input phase of decision cycle K
    K - ID ^attr VALUE      remove it

ID is I2 (the input link) or #name, a new identifier the script names; VALUE is #name for an
identifier, else a constant as in Soar source (integers, real numbers, symbols, |quoted|).

A reactive environment (X.env.py) defines step(k, output), called before the input phase of
cycle K with the output link's elements as (id, attr, value) strings, returning changes in the
same form ("+ I2 ^a 3", ...). Its changes are recorded to X.input.rec, which soar-lean replays
with --input.
"""
import re, importlib.util, soar_sml as sml

def parse_line(l):
    l = re.split(r'(?:^|\s)# ', l, 1)[0]
    m = re.match(r'\s*(\d+)\s+([+-])\s+(\S+)\s+\^(\S+)\s+(.+?)\s*$', l)
    if not m: return None
    return int(m.group(1)), m.group(2), m.group(3), m.group(4).strip('|'), m.group(5)

def const(v):
    if v.startswith('|') and v.endswith('|'): return ('s', v[1:-1])
    if re.match(r'^[+-]?\d+$', v): return ('i', int(v))
    if re.match(r'^[+-]?(\d+\.\d*|\.\d+)$', v): return ('f', float(v))
    return ('s', v)

class Driver:
    def __init__(self, agent, lines=None, envmod=None, rec=None, maxk=None):
        self.a = agent; self.k = 0; self.ids = {}; self.wmes = {}
        self.lines = lines or []; self.env = envmod; self.rec = rec; self.maxk = maxk
        self.cb = agent.RegisterForRunEvent(sml.smlEVENT_BEFORE_INPUT_PHASE, self.on_input, None)
    def ident(self, name):
        if name in ('I2', 'input-link'): return self.a.GetInputLink()
        return self.ids[name]
    def apply(self, op, idn, attr, val):
        parent = self.ident(idn)
        key = (idn, attr, val)
        if op == '+':
            if val.startswith('#'):
                w = self.a.CreateIdWME(parent, attr); self.ids[val] = w
            else:
                t, x = const(val)
                w = (self.a.CreateIntWME(parent, attr, x) if t == 'i' else
                     self.a.CreateFloatWME(parent, attr, x) if t == 'f' else
                     self.a.CreateStringWME(parent, attr, x))
            self.wmes.setdefault(key, []).append(w)
        else:
            ws = self.wmes.get(key)
            if ws: self.a.DestroyWME(ws.pop(0))
    def output(self):
        out = []
        ol = self.a.GetOutputLink()
        if ol is None: return out
        def walk(idf, seen):
            for i in range(idf.GetNumberChildren()):
                c = idf.GetChild(i)
                out.append((idf.GetValueAsString(), c.GetAttribute(), c.GetValueAsString()))
                if c.IsIdentifier() and c.GetValueAsString() not in seen:
                    seen.add(c.GetValueAsString()); walk(c.ConvertToIdentifier(), seen)
        walk(ol, set())
        return out
    def on_input(self, *args):
        self.k += 1
        if self.maxk is not None and self.k > self.maxk: return
        changes = [l for l in self.lines if l[0] == self.k]
        if self.env is not None:
            for c in self.env.step(self.k, self.output()) or []:
                p = parse_line(f"{self.k} {c}")
                if p: changes.append(p)
                if self.rec is not None: self.rec.write(f"{self.k} {c}\n")
        for (_, op, idn, attr, val) in changes:
            self.apply(op, idn, attr, val)
        self.a.Commit()

def load(name, agent, maxk):
    import os
    if os.path.exists(name + '.env.py'):
        spec = importlib.util.spec_from_file_location(name + '_env', name + '.env.py')
        mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
        rec = open(name + '.input.rec', 'w')
        return Driver(agent, envmod=mod, rec=rec, maxk=maxk), name + '.input.rec'
    if os.path.exists(name + '.input'):
        lines = [p for p in (parse_line(l) for l in open(name + '.input')) if p]
        return Driver(agent, lines=lines, maxk=maxk), name + '.input'
    return None, None
