"""Compare the final working memory of Soar 9.6.5 and soar-lean element by element, timetags
included.

usage: python3 tools/ttcmp.py agent.soar N [settings] [soar-lean]

Runs N decisions in both (Soar finishes the last cycle, as tools/diff.py does) and compares
every element with its timetag; identifiers are matched as they first appear in timetag order.
Equal timetags mean the two made the same elements in the same order, which is what the Rete's
order depends on. TTRANGE=lo-hi prints the elements with timetags in that range."""
import sys, subprocess, re, os
f, n = sys.argv[1], sys.argv[2]
S = sys.argv[3] if len(sys.argv) > 3 else 'decide indifferent-selection --first;srand 0'
lean = sys.argv[4] if len(sys.argv) > 4 else os.environ.get('SOAR_LEAN', os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '.lake', 'build', 'bin', 'soar-lean'))
import soar_sml as sml
k = sml.Kernel.CreateKernelInNewThread(); a = k.CreateAgent("a")
for c in S.split(';'):
    if c: a.ExecuteCommandLine(c)
a.ExecuteCommandLine("source {%s}" % os.path.abspath(f))
a.ExecuteCommandLine("run %s -d" % n); a.ExecuteCommandLine("run 2 -p")
out = a.ExecuteCommandLine("print --internal (* ^* *)")
sw = {}
isid_s = lambda x: re.fullmatch(r'[A-Z]\d+', x) is not None
for m in re.finditer(r'\((\d+): (\S+) \^(\S+) (.*?)( \+)?\)', out):
    tt, i, at, v, acc = m.groups(); v = re.sub(r' \[[^\]]*\]$', '', v); sw[int(tt)] = (i, at, v, bool(acc))
import tempfile
rd = os.path.join(tempfile.mkdtemp(), 'tt.rete')
subprocess.run([lean, f, '-d', n, '--settings', S, '--rete-debug', rd], capture_output=True)
lw = {}
for l in open(rd):
    m = re.match(r'(\d+): (\d+) (\S+) (.*?)( \+)?$', l.strip())
    if m:
        tt, i, at, v, acc = m.groups(); lw[int(tt)] = ('#ID' + i, at, v, bool(acc))
isid_l = lambda x: x.startswith('#ID')
mp = {'S1': '#ID1'}; rev = {'#ID1': 'S1'}
def same(x, y):
    if isid_s(x) and isid_l(y):
        if x in mp: return mp[x] == y
        if y in rev: return False
        mp[x] = y; rev[y] = x; return True
    return x == y and not isid_s(x) and not isid_l(y)
bad = []
for t in sorted(set(sw) | set(lw)):
    s_, l_ = sw.get(t), lw.get(t)
    if s_ is None or l_ is None:
        bad.append((t, s_, l_)); continue
    ok = same(s_[0], l_[0]) and same(s_[1], l_[1]) and same(s_[2], l_[2]) and s_[3] == l_[3]
    if not ok: bad.append((t, s_, l_))
print(f"soar {len(sw)} lean {len(lw)} elements; {len(bad)} differ")
for b in bad[:10]: print("  ", b, flush=True)
if os.environ.get("TTRANGE"):
    lo,hi=map(int,os.environ["TTRANGE"].split("-"))
    for t in range(lo,hi+1): print(t, sw.get(t), "|", lw.get(t))
