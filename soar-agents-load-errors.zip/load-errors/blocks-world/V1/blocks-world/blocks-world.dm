28
SOAR_ID 0
ENUMERATION 1 1 state
ENUMERATION 2 1 nil
ENUMERATION 3 1 blocks-world
SOAR_ID 4
ENUMERATION 5 1 move-block
SOAR_ID 6
SOAR_ID 7
SOAR_ID 8
SOAR_ID 9
ENUMERATION 10 2 A C
ENUMERATION 11 1 table
ENUMERATION 12 1 table
SOAR_ID 13
SOAR_ID 14
SOAR_ID 15
ENUMERATION 16 1 initialize-blocks-world
ENUMERATION 17 4 A B C table
ENUMERATION 18 2 block table
SOAR_ID 19
ENUMERATION 20 1 nothing
SOAR_ID 21
ENUMERATION 22 1 state
ENUMERATION 23 1 move-block
ENUMERATION 24 1 put-down
SOAR_ID 25
ENUMERATION 26 1 pick-up
SOAR_ID 27
35
0 clear 14
0 desired 7
0 gripper 19
0 last-moved-block 14
0 name 3
0 object 14
0 ontop 6
0 operator 4
0 operator 15
0 superstate 2
0 type 1
4 destination 14
4 moving-block 14
4 name 5
6 bottom-block 9
6 top-block 8
7 ontop 13
8 name 10
9 name 11
9 type 12
13 bottom-block 14
13 top-block 14
14 name 17
14 type 18
15 name 16
19 holding 20
19 holding 14
21 name 23
21 operator 25
21 operator 27
21 superstate 0
21 top-state 0
21 type 22
25 name 24
27 name 26
