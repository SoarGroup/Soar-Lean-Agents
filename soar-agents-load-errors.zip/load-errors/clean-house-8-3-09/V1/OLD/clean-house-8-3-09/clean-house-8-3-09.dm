346
SOAR_ID 0
SOAR_ID 1
SOAR_ID 2
SOAR_ID 3
ENUMERATION 4 2 goto-area state
ENUMERATION 5 1 nil
ENUMERATION 6 3 accepted complete error
SOAR_ID 7
STRING 8
ENUMERATION 9 2 operator state
ENUMERATION 10 2 multiple none
ENUMERATION 11 2 no-change tie
ENUMERATION 12 2 evaluate-operator robot
SOAR_ID 13
ENUMERATION 14 1 wait
SOAR_ID 15
SOAR_ID 16
SOAR_ID 17
INTEGER_RANGE 18 0 2147483647
SOAR_ID 19
INTEGER_RANGE 20 0 2147483647
INTEGER_RANGE 21 0 2147483647
SOAR_ID 22
INTEGER_RANGE 23 0 2147483647
INTEGER_RANGE 24 0 2147483647
FLOAT_RANGE 25 0.0 Infinity
FLOAT_RANGE 26 0.0 Infinity
ENUMERATION 27 4 east north south west
SOAR_ID 28
FLOAT_RANGE 29 0.0 Infinity
FLOAT_RANGE 30 0.0 Infinity
INTEGER_RANGE 31 0 2147483647
SOAR_ID 32
ENUMERATION 33 2 false true
ENUMERATION 34 2 false true
FLOAT_RANGE 35 0.0 Infinity
FLOAT_RANGE 36 0.0 Infinity
SOAR_ID 37
FLOAT_RANGE 38 -180.0 180.0
ENUMERATION 39 3 accepted complete error
ENUMERATION 40 2 complete error
INTEGER_RANGE 41 -2147483648 2147483647
ENUMERATION 42 4 east north south west
SOAR_ID 43
INTEGER_RANGE 44 -2147483648 2147483647
ENUMERATION 45 1 block
SOAR_ID 46
INTEGER_RANGE 47 -2147483648 2147483647
INTEGER_RANGE 48 -2147483648 2147483647
ENUMERATION 49 1 block
FLOAT_RANGE 50 -Infinity Infinity
ENUMERATION 51 2 no yes
FLOAT_RANGE 52 -Infinity Infinity
FLOAT_RANGE 53 -Infinity Infinity
SOAR_ID 54
SOAR_ID 55
INTEGER_RANGE 56 -2147483648 2147483647
INTEGER_RANGE 57 -2147483648 2147483647
ENUMERATION 58 2 complete error
ENUMERATION 59 2 complete error
SOAR_ID 60
ENUMERATION 61 1 grasp-block
SOAR_ID 62
FLOAT_RANGE 63 -Infinity Infinity
SOAR_ID 64
ENUMERATION 65 1 stop
SOAR_ID 66
ENUMERATION 67 1 state
INTEGER_RANGE 68 -2147483648 2147483647
SOAR_ID 69
ENUMERATION 70 1 pickup-block
INTEGER_RANGE 71 -2147483648 2147483647
ENUMERATION 72 1 pickup-block
ENUMERATION 73 1 spin
SOAR_ID 74
SOAR_ID 75
ENUMERATION 76 1 find-block-in-area
SOAR_ID 77
ENUMERATION 78 1 record-area
SOAR_ID 79
ENUMERATION 80 1 init-robot
SOAR_ID 81
INTEGER_RANGE 82 -2147483648 2147483647
SOAR_ID 83
ENUMERATION 84 1 state
ENUMERATION 85 1 find-block-in-area
ENUMERATION 86 1 record-area-direction
SOAR_ID 87
ENUMERATION 88 4 east north south west
ENUMERATION 89 4 east north south west
ENUMERATION 90 1 spin
SOAR_ID 91
ENUMERATION 92 1 note-turning
SOAR_ID 93
SOAR_ID 94
ENUMERATION 95 1 stop-spin
SOAR_ID 96
ENUMERATION 97 1 yes
SOAR_ID 98
SOAR_ID 99
ENUMERATION 100 1 goto-unvisited-area
ENUMERATION 101 2 x y
ENUMERATION 102 2 neg pos
INTEGER_RANGE 103 -2147483648 2147483647
FLOAT_RANGE 104 -Infinity Infinity
FLOAT_RANGE 105 -Infinity Infinity
ENUMERATION 106 1 yes
SOAR_ID 107
ENUMERATION 108 1 get-block
SOAR_ID 109
ENUMERATION 110 1 state
ENUMERATION 111 1 get-block
ENUMERATION 112 1 goto-not-clean-area
SOAR_ID 113
SOAR_ID 114
ENUMERATION 115 1 deposit-block
SOAR_ID 116
ENUMERATION 117 1 finished-cleaning
INTEGER_RANGE 118 -2147483648 2147483647
SOAR_ID 119
ENUMERATION 120 1 state
ENUMERATION 121 1 deposit-block
ENUMERATION 122 1 goto-storage-area
SOAR_ID 123
ENUMERATION 124 1 move-to-wall
SOAR_ID 125
ENUMERATION 126 2 go-to-area goto-area
ENUMERATION 127 1 go-to-area
ENUMERATION 128 4 east north south west
SOAR_ID 129
ENUMERATION 130 1 state
ENUMERATION 131 1 move-to-wall
ENUMERATION 132 1 turn-to-wall
SOAR_ID 133
ENUMERATION 134 1 move-forward
SOAR_ID 135
ENUMERATION 136 2 false true
ENUMERATION 137 1 drop-block
SOAR_ID 138
INTEGER_RANGE 139 -2147483648 2147483647
SOAR_ID 140
ENUMERATION 141 1 clean-house
SOAR_ID 142
STRING 143
ENUMERATION 144 2 no yes
ENUMERATION 145 1 yes
SOAR_ID 146
ENUMERATION 147 1 state
ENUMERATION 148 1 Impasse__Operator_Tie
ENUMERATION 149 1 evaluate-operator
SOAR_ID 150
SOAR_ID 151
ENUMERATION 152 1 state
ENUMERATION 153 1 evaluate-operator
ENUMERATION 154 1 goto-gateway
SOAR_ID 155
ENUMERATION 156 1 turn-from-block
SOAR_ID 157
SOAR_ID 158
ENUMERATION 159 1 record-block
SOAR_ID 160
SOAR_ID 161
SOAR_ID 162
INTEGER_RANGE 163 -2147483648 2147483647
INTEGER_RANGE 164 -2147483648 2147483647
INTEGER_RANGE 165 -2147483648 2147483647
SOAR_ID 166
SOAR_ID 167
ENUMERATION 168 4 east north south west
ENUMERATION 169 2 col row
ENUMERATION 170 2 col row
ENUMERATION 171 1 yes
ENUMERATION 172 1 detect-no-storage-area
SOAR_ID 173
ENUMERATION 174 1 t
ENUMERATION 175 1 t
ENUMERATION 176 1 tie
FLOAT_RANGE 177 -Infinity Infinity
ENUMERATION 178 2 no yes
FLOAT_RANGE 179 -Infinity Infinity
FLOAT_RANGE 180 -Infinity Infinity
SOAR_ID 181
ENUMERATION 182 1 chase
SOAR_ID 183
ENUMERATION 184 1 state
ENUMERATION 185 1 chase
ENUMERATION 186 1 move-to-player
SOAR_ID 187
SOAR_ID 188
ENUMERATION 189 1 record-unconnected-area
SOAR_ID 190
ENUMERATION 191 2 no yes
SOAR_ID 192
INTEGER_RANGE 193 -2147483648 2147483647
INTEGER_RANGE 194 -2147483648 2147483647
STRING 195
SOAR_ID 196
INTEGER_RANGE 197 -180 180
SOAR_ID 198
FLOAT_RANGE 199 -Infinity Infinity
ENUMERATION 200 2 block player
STRING 201
INTEGER_RANGE 202 -2147483648 2147483647
SOAR_ID 203
FLOAT_RANGE 204 -180.0 180.0
FLOAT_RANGE 205 -0.5 0.5
SOAR_ID 206
SOAR_ID 207
STRING 208
FLOAT_RANGE 209 -Infinity Infinity
FLOAT_RANGE 210 -Infinity Infinity
SOAR_ID 211
SOAR_ID 212
SOAR_ID 213
STRING 214
STRING 215
SOAR_ID 216
SOAR_ID 217
ENUMERATION 218 1 nil
SOAR_ID 219
STRING 220
SOAR_ID 221
SOAR_ID 222
STRING 223
FLOAT_RANGE 224 -Infinity Infinity
FLOAT_RANGE 225 -Infinity Infinity
FLOAT_RANGE 226 -Infinity Infinity
FLOAT_RANGE 227 -Infinity Infinity
FLOAT_RANGE 228 -Infinity Infinity
FLOAT_RANGE 229 -Infinity Infinity
FLOAT_RANGE 230 -Infinity Infinity
FLOAT_RANGE 231 -Infinity Infinity
FLOAT_RANGE 232 -Infinity Infinity
FLOAT_RANGE 233 -Infinity Infinity
FLOAT_RANGE 234 -Infinity Infinity
FLOAT_RANGE 235 -Infinity Infinity
FLOAT_RANGE 236 -Infinity Infinity
FLOAT_RANGE 237 -Infinity Infinity
FLOAT_RANGE 238 -Infinity Infinity
FLOAT_RANGE 239 -Infinity Infinity
FLOAT_RANGE 240 -Infinity Infinity
FLOAT_RANGE 241 -Infinity Infinity
ENUMERATION 242 1 go-to
SOAR_ID 243
SOAR_ID 244
ENUMERATION 245 1 state
ENUMERATION 246 1 go-to
ENUMERATION 247 1 set-waypoint
SOAR_ID 248
ENUMERATION 249 1 abandon-waypoint
SOAR_ID 250
ENUMERATION 251 1 initialize-progress
SOAR_ID 252
ENUMERATION 253 1 record-progress
SOAR_ID 254
ENUMERATION 255 1 turn-to-waypoint
SOAR_ID 256
ENUMERATION 257 1 move-forward
SOAR_ID 258
ENUMERATION 259 2 false true
FLOAT_RANGE 260 -Infinity Infinity
FLOAT_RANGE 261 -Infinity Infinity
SOAR_ID 262
INTEGER_RANGE 263 0 2147483647
FLOAT_RANGE 264 0.0 Infinity
FLOAT_RANGE 265 0.0 Infinity
FLOAT_RANGE 266 -Infinity Infinity
FLOAT_RANGE 267 -Infinity Infinity
FLOAT_RANGE 268 -Infinity Infinity
FLOAT_RANGE 269 -Infinity Infinity
FLOAT_RANGE 270 -Infinity Infinity
FLOAT_RANGE 271 -Infinity Infinity
FLOAT_RANGE 272 -Infinity Infinity
SOAR_ID 273
ENUMERATION 274 2 immediate true
ENUMERATION 275 2 false true
SOAR_ID 276
INTEGER_RANGE 277 0 2147483647
FLOAT_RANGE 278 0.0 Infinity
FLOAT_RANGE 279 0.0 Infinity
FLOAT_RANGE 280 -Infinity Infinity
FLOAT_RANGE 281 -Infinity Infinity
FLOAT_RANGE 282 -Infinity Infinity
FLOAT_RANGE 283 -Infinity Infinity
ENUMERATION 284 2 smem wm
ENUMERATION 285 2 smem wm
SOAR_ID 286
ENUMERATION 287 1 retrieve-current-area-smem
FLOAT_RANGE 288 -Infinity Infinity
INTEGER_RANGE 289 -2147483648 2147483647
INTEGER_RANGE 290 -2147483648 2147483647
INTEGER_RANGE 291 -2147483648 2147483647
FLOAT_RANGE 292 -Infinity Infinity
FLOAT_RANGE 293 -Infinity Infinity
SOAR_ID 294
ENUMERATION 295 1 retrieve-current-area-smem
SOAR_ID 296
ENUMERATION 297 1 state
ENUMERATION 298 1 retrieve-current-area-smem
ENUMERATION 299 1 add-gateways
SOAR_ID 300
ENUMERATION 301 1 create-current-area
SOAR_ID 302
ENUMERATION 303 1 retrieve-current-area
SOAR_ID 304
ENUMERATION 305 1 store-current-area
SOAR_ID 306
SOAR_ID 307
SOAR_ID 308
SOAR_ID 309
ENUMERATION 310 2 failure success
ENUMERATION 311 1 area
ENUMERATION 312 2 attempted failure
ENUMERATION 313 1 yes
ENUMERATION 314 1 yes
ENUMERATION 315 1 yes
ENUMERATION 316 1 store
SOAR_ID 317
SOAR_ID 318
ENUMERATION 319 1 yes
INTEGER_RANGE 320 -2147483648 2147483647
FLOAT_RANGE 321 -Infinity Infinity
FLOAT_RANGE 322 -Infinity Infinity
ENUMERATION 323 2 no yes
ENUMERATION 324 1 go-to
SOAR_ID 325
FLOAT_RANGE 326 -Infinity Infinity
ENUMERATION 327 2 no yes
FLOAT_RANGE 328 -Infinity Infinity
ENUMERATION 329 1 yes
ENUMERATION 330 2 no yes
ENUMERATION 331 1 go-to-area
SOAR_ID 332
SOAR_ID 333
ENUMERATION 334 2 go-to-area state
ENUMERATION 335 2 evaluate-operator go-to-area
ENUMERATION 336 1 go-to
SOAR_ID 337
ENUMERATION 338 1 go-to-next-area
SOAR_ID 339
SOAR_ID 340
ENUMERATION 341 1 state
ENUMERATION 342 1 go-to-next-area
ENUMERATION 343 1 go-to
SOAR_ID 344
INTEGER_RANGE 345 -2147483648 2147483647
452
0 areas 98
0 attribute 9
0 blocks 160
0 choices 10
0 current-area 81
0 desired 142
0 destination-waypoint 273
0 direction 89
0 directions 94
0 impasse 11
0 io 1
0 name 12
0 no-storage-area 171
0 numbers 161
0 operator 13
0 operator 77
0 operator 79
0 operator 99
0 operator 107
0 operator 114
0 operator 116
0 operator 158
0 operator 181
0 operator 188
0 operator 243
0 operator 286
0 operator 294
0 operator 332
0 parameters 62
0 problem-space 140
0 quiescence 175
0 smem 307
0 superstate 5
0 superstate 0
0 tight-direction 89
0 top-state 0
0 type 4
0 wall-obstacle 166
1 input-link 2
1 output-link 3
2 area-description 16
2 object 190
2 self 15
2 time 192
3 add-waypoint 207
3 clear-message 221
3 configure 222
3 disable-waypoint 212
3 drop 55
3 enable-waypoint 212
3 estop 206
3 get 54
3 remove-message 219
3 remove-waypoint 211
3 send-message 213
3 set-heading 37
3 set-heading-linear 318
3 set-velocity 203
3 stop 206
3 stop-sim 7
7 status 40
7 true 8
13 actions 3
13 name 14
15 area 41
15 carry 43
15 collision 32
15 name 195
15 pose 196
15 stopped 330
15 waypoints 198
16 gateway 28
16 id 202
16 wall 17
17 direction 27
17 id 18
17 left 19
17 right 22
17 stored 315
17 x 25
17 y 26
17 yaw 179
19 col 20
19 row 21
22 col 24
22 row 23
28 direction 42
28 id 31
28 range 105
28 stored 314
28 to 320
28 x 29
28 y 30
28 yaw 180
32 x 34
32 y 33
37 status 39
37 yaw 38
43 id 44
43 type 45
46 area 47
46 id 48
46 range 50
46 type 49
46 visible 51
46 x 52
46 y 53
46 yaw 177
54 id 57
54 status 58
55 id 56
55 status 59
60 actions 3
60 name 61
62 areas-held-in 284
62 high-angular-velocity 228
62 high-linear-velocity 228
62 low-angular-velocity 226
62 low-linear-velocity 226
62 max-angular-distance 260
62 medium-angular-velocity 227
62 medium-linear-velocity 227
62 message-update-time 289
62 min-angular-distance 261
62 min-progress-distance 269
62 objects-held-in 285
62 pickup-range 63
62 progress-update-time 270
62 range-tolerance 290
62 rotation-tolerance 291
62 waypoint-tolerance 288
64 actions 3
64 name 65
66 block-id 68
66 io 1
66 name 72
66 object 190
66 object-in-range-lined-up 323
66 object-lined-up 178
66 operator 60
66 operator 74
66 operator 325
66 quiescence 175
66 stopped 329
66 superstate 109
66 top-state 0
66 type 67
69 id 71
69 name 70
74 name 73
75 name 76
77 area 81
77 name 78
79 name 80
81 cleaned 106
81 gateway 28
81 gateway-area 145
81 id 82
81 next 81
81 previous-area 81
81 search-start-direction 88
81 turning 319
81 type 311
81 visited 97
81 wall 17
81 x 321
81 y 322
83 current-area 81
83 io 1
83 name 85
83 operator 87
83 operator 91
83 operator 93
83 operator 96
83 quiescence 175
83 superstate 109
83 top-state 0
83 type 84
87 name 86
91 actions 3
91 name 90
93 name 92
94 ene 234
94 ese 237
94 heading 104
94 move-in-rectangle 101
94 move-in-rectangle-delta 102
94 move-in-rectangle-num 103
94 ne 229
94 nne 233
94 nnw 235
94 nw 230
94 opposite 89
94 se 231
94 sse 238
94 ssw 240
94 sw 232
94 value 89
94 wnw 236
94 wsw 239
96 name 95
98 area 81
99 area 81
99 name 100
99 type 126
107 name 108
109 current-area 81
109 io 1
109 name 111
109 operator 113
109 operator 69
109 operator 75
109 quiescence 175
109 superstate 0
109 top-state 0
109 type 110
113 area 81
113 name 112
113 type 127
114 name 115
116 name 117
119 current-area 81
119 io 1
119 name 121
119 operator 123
119 operator 125
119 operator 173
119 quiescence 175
119 superstate 0
119 top-state 0
119 type 120
123 area 81
123 name 122
123 type 127
125 name 124
125 wall-direction 128
129 collision 136
129 collision-distance 139
129 io 1
129 name 131
129 operator 133
129 operator 135
129 operator 138
129 operator 157
129 quiescence 174
129 superstate 119
129 top-state 0
129 type 130
133 name 132
135 name 134
138 actions 3
138 name 137
140 default-state-copy 144
140 name 141
140 one-level-attributes 143
142 storage-area-id 118
146 impasse 176
146 name 148
146 operator 150
146 quiescence 175
146 superstate 0
146 top-state 0
146 type 147
150 name 149
151 current-area 81
151 desired 142
151 destination-area 81
151 failure 142
151 indifferent 142
151 name 153
151 operator 155
151 partial-failure 142
151 quiescence 175
151 success 142
151 superstate 146
151 top-state 0
151 type 152
151 visited-area 81
155 gateway 28
155 name 154
157 name 156
158 block 46
158 name 159
160 block 46
161 number 162
162 one-less 165
162 one-more 164
162 value 163
166 info 167
167 against-wall 168
167 direction 168
167 equal-dimension 169
167 one-greater-than 170
167 one-less-than 170
173 name 172
181 name 182
181 player 190
183 io 1
183 name 185
183 operator 187
183 superstate 0
183 top-state 0
183 type 184
187 actions 3
187 name 186
188 name 189
190 abs-relative-bearing 293
190 distance 105
190 id 31
190 name 201
190 relative-bearing 292
190 type 200
190 visible 191
190 x 29
190 y 30
190 yaw 241
192 microseconds 194
192 seconds 193
196 x 35
196 x-velocity 199
196 y 36
196 y-velocity 199
196 yaw 197
196 yaw-velocity 199
196 z 35
198 waypoint 276
203 angular-velocity 204
203 linear-velocity 205
203 status 6
206 status 39
207 id 208
207 status 39
207 x 209
207 y 210
211 id 208
211 status 39
212 id 208
212 status 39
213 destination 214
213 first 216
213 next 216
213 status 39
213 word 215
216 next 217
216 next 218
219 id 220
219 status 39
221 status 39
222 offset-x 224
222 offset-y 225
222 status 39
222 yaw-format 223
243 destination 28
243 name 242
243 range 328
244 destination 262
244 destination-in-range 327
244 name 246
244 operator 248
244 operator 250
244 operator 252
244 operator 254
244 operator 256
244 operator 258
244 operator 64
244 set-waypoint 275
244 superstate 0
244 top-state 0
244 type 245
244 waypoint-data 276
244 yaw-aligned 259
248 name 247
250 name 249
252 name 251
254 name 253
256 actions 3
256 name 255
258 actions 3
258 name 257
262 distance 267
262 id 263
262 x 264
262 y 265
262 yaw 266
273 give-up 274
273 last-distance 271
273 next-update-time 268
273 progress 272
273 waypoint 262
276 abs-relative-bearing 283
276 distance 281
276 id 277
276 relative-bearing 282
276 x 278
276 y 279
276 yaw 280
286 name 287
294 name 295
296 added-gateways 313
296 area 81
296 name 298
296 operator 300
296 operator 302
296 operator 304
296 operator 306
296 operator 317
296 retrieve 312
296 smem 307
296 superstate 0
296 top-state 0
296 type 297
300 gateway 28
300 name 299
302 name 301
304 name 303
306 name 305
307 command 308
307 result 309
308 query 81
308 retrieve 81
308 store 81
309 retrieved 81
309 status 310
317 name 316
317 object 28
318 linear-velocity 205
318 status 39
318 yaw 38
325 destination 190
325 name 324
325 range 326
332 name 331
333 current-area 81
333 destination-area 81
333 name 335
333 operator 337
333 operator 339
333 superstate 0
333 top-state 0
333 type 334
337 destination 81
337 name 336
339 name 338
339 next-waypoint 81
340 name 342
340 operator 344
340 superstate 333
340 top-state 0
340 type 341
344 destination 28
344 gateway-area-id 345
344 name 343
