351
SOAR_ID 0
SOAR_ID 1
SOAR_ID 2
SOAR_ID 3
ENUMERATION 4 2 goto-area state
ENUMERATION 5 1 nil
ENUMERATION 6 3 accepted complete error
SOAR_ID 7
STRING 8
ENUMERATION 9 2 operator state
ENUMERATION 10 2 multiple none
ENUMERATION 11 2 no-change tie
ENUMERATION 12 2 evaluate-operator robot
SOAR_ID 13
ENUMERATION 14 1 wait
SOAR_ID 15
SOAR_ID 16
SOAR_ID 17
INTEGER_RANGE 18 0 2147483647
SOAR_ID 19
INTEGER_RANGE 20 0 2147483647
INTEGER_RANGE 21 0 2147483647
SOAR_ID 22
INTEGER_RANGE 23 0 2147483647
INTEGER_RANGE 24 0 2147483647
FLOAT_RANGE 25 0.0 Infinity
FLOAT_RANGE 26 0.0 Infinity
ENUMERATION 27 4 east north south west
SOAR_ID 28
FLOAT_RANGE 29 0.0 Infinity
FLOAT_RANGE 30 0.0 Infinity
INTEGER_RANGE 31 0 2147483647
SOAR_ID 32
ENUMERATION 33 2 false true
ENUMERATION 34 2 false true
FLOAT_RANGE 35 0.0 Infinity
FLOAT_RANGE 36 0.0 Infinity
SOAR_ID 37
FLOAT_RANGE 38 -180.0 180.0
ENUMERATION 39 3 accepted complete error
ENUMERATION 40 2 complete error
INTEGER_RANGE 41 -2147483648 2147483647
ENUMERATION 42 4 east north south west
SOAR_ID 43
INTEGER_RANGE 44 -2147483648 2147483647
ENUMERATION 45 1 block
SOAR_ID 46
INTEGER_RANGE 47 -2147483648 2147483647
INTEGER_RANGE 48 -2147483648 2147483647
ENUMERATION 49 1 block
FLOAT_RANGE 50 -Infinity Infinity
ENUMERATION 51 2 no yes
FLOAT_RANGE 52 -Infinity Infinity
FLOAT_RANGE 53 -Infinity Infinity
SOAR_ID 54
SOAR_ID 55
INTEGER_RANGE 56 -2147483648 2147483647
INTEGER_RANGE 57 -2147483648 2147483647
ENUMERATION 58 2 complete error
ENUMERATION 59 2 complete error
SOAR_ID 60
ENUMERATION 61 1 grasp-block
SOAR_ID 62
FLOAT_RANGE 63 -Infinity Infinity
SOAR_ID 64
ENUMERATION 65 1 stop
SOAR_ID 66
ENUMERATION 67 1 state
INTEGER_RANGE 68 -2147483648 2147483647
SOAR_ID 69
ENUMERATION 70 1 pickup-block
INTEGER_RANGE 71 -2147483648 2147483647
ENUMERATION 72 1 pickup-block
ENUMERATION 73 1 spin
SOAR_ID 74
SOAR_ID 75
ENUMERATION 76 1 find-block-in-area
SOAR_ID 77
ENUMERATION 78 1 record-area
SOAR_ID 79
ENUMERATION 80 1 init-robot
SOAR_ID 81
INTEGER_RANGE 82 -2147483648 2147483647
SOAR_ID 83
ENUMERATION 84 1 state
ENUMERATION 85 1 find-block-in-area
ENUMERATION 86 1 record-area-direction
SOAR_ID 87
ENUMERATION 88 4 east north south west
ENUMERATION 89 4 east north south west
ENUMERATION 90 1 spin
SOAR_ID 91
ENUMERATION 92 1 note-turning
SOAR_ID 93
SOAR_ID 94
ENUMERATION 95 1 stop-spin
SOAR_ID 96
ENUMERATION 97 1 yes
SOAR_ID 98
SOAR_ID 99
ENUMERATION 100 1 goto-unvisited-area
SOAR_ID 101
ENUMERATION 102 2 go-to-area state
ENUMERATION 103 1 goto-unvisited-area
ENUMERATION 104 2 x y
ENUMERATION 105 2 neg pos
INTEGER_RANGE 106 -2147483648 2147483647
FLOAT_RANGE 107 -Infinity Infinity
FLOAT_RANGE 108 -Infinity Infinity
ENUMERATION 109 1 yes
SOAR_ID 110
ENUMERATION 111 1 get-block
SOAR_ID 112
ENUMERATION 113 1 state
ENUMERATION 114 1 get-block
ENUMERATION 115 1 goto-not-clean-area
SOAR_ID 116
SOAR_ID 117
ENUMERATION 118 1 deposit-block
SOAR_ID 119
ENUMERATION 120 1 finished-cleaning
INTEGER_RANGE 121 -2147483648 2147483647
SOAR_ID 122
ENUMERATION 123 1 state
ENUMERATION 124 1 deposit-block
ENUMERATION 125 1 goto-storage-area
SOAR_ID 126
ENUMERATION 127 1 move-to-wall
SOAR_ID 128
ENUMERATION 129 2 go-to-area goto-area
ENUMERATION 130 1 go-to-area
ENUMERATION 131 4 east north south west
SOAR_ID 132
ENUMERATION 133 1 state
ENUMERATION 134 1 move-to-wall
ENUMERATION 135 1 turn-to-wall
SOAR_ID 136
ENUMERATION 137 1 move-forward
SOAR_ID 138
ENUMERATION 139 2 false true
ENUMERATION 140 1 drop-block
SOAR_ID 141
INTEGER_RANGE 142 -2147483648 2147483647
SOAR_ID 143
ENUMERATION 144 1 clean-house
SOAR_ID 145
STRING 146
ENUMERATION 147 2 no yes
ENUMERATION 148 1 yes
SOAR_ID 149
ENUMERATION 150 1 state
ENUMERATION 151 1 Impasse__Operator_Tie
ENUMERATION 152 1 evaluate-operator
SOAR_ID 153
SOAR_ID 154
ENUMERATION 155 1 state
ENUMERATION 156 1 evaluate-operator
ENUMERATION 157 1 goto-gateway
SOAR_ID 158
ENUMERATION 159 1 turn-from-block
SOAR_ID 160
SOAR_ID 161
ENUMERATION 162 1 record-block
SOAR_ID 163
SOAR_ID 164
SOAR_ID 165
INTEGER_RANGE 166 -2147483648 2147483647
INTEGER_RANGE 167 -2147483648 2147483647
INTEGER_RANGE 168 -2147483648 2147483647
SOAR_ID 169
SOAR_ID 170
ENUMERATION 171 4 east north south west
ENUMERATION 172 2 col row
ENUMERATION 173 2 col row
ENUMERATION 174 1 yes
ENUMERATION 175 1 detect-no-storage-area
SOAR_ID 176
ENUMERATION 177 1 t
ENUMERATION 178 1 t
ENUMERATION 179 1 tie
FLOAT_RANGE 180 -Infinity Infinity
ENUMERATION 181 2 no yes
FLOAT_RANGE 182 -Infinity Infinity
FLOAT_RANGE 183 -Infinity Infinity
SOAR_ID 184
ENUMERATION 185 1 chase
SOAR_ID 186
ENUMERATION 187 1 state
ENUMERATION 188 1 chase
ENUMERATION 189 1 move-to-player
SOAR_ID 190
SOAR_ID 191
ENUMERATION 192 1 record-unconnected-area
SOAR_ID 193
ENUMERATION 194 2 no yes
SOAR_ID 195
INTEGER_RANGE 196 -2147483648 2147483647
INTEGER_RANGE 197 -2147483648 2147483647
STRING 198
SOAR_ID 199
INTEGER_RANGE 200 -180 180
SOAR_ID 201
FLOAT_RANGE 202 -Infinity Infinity
ENUMERATION 203 2 block player
STRING 204
INTEGER_RANGE 205 -2147483648 2147483647
SOAR_ID 206
FLOAT_RANGE 207 -180.0 180.0
FLOAT_RANGE 208 -0.5 0.5
SOAR_ID 209
SOAR_ID 210
STRING 211
FLOAT_RANGE 212 -Infinity Infinity
FLOAT_RANGE 213 -Infinity Infinity
SOAR_ID 214
SOAR_ID 215
SOAR_ID 216
STRING 217
STRING 218
SOAR_ID 219
SOAR_ID 220
ENUMERATION 221 1 nil
SOAR_ID 222
STRING 223
SOAR_ID 224
SOAR_ID 225
STRING 226
FLOAT_RANGE 227 -Infinity Infinity
FLOAT_RANGE 228 -Infinity Infinity
FLOAT_RANGE 229 -Infinity Infinity
FLOAT_RANGE 230 -Infinity Infinity
FLOAT_RANGE 231 -Infinity Infinity
FLOAT_RANGE 232 -Infinity Infinity
FLOAT_RANGE 233 -Infinity Infinity
FLOAT_RANGE 234 -Infinity Infinity
FLOAT_RANGE 235 -Infinity Infinity
FLOAT_RANGE 236 -Infinity Infinity
FLOAT_RANGE 237 -Infinity Infinity
FLOAT_RANGE 238 -Infinity Infinity
FLOAT_RANGE 239 -Infinity Infinity
FLOAT_RANGE 240 -Infinity Infinity
FLOAT_RANGE 241 -Infinity Infinity
FLOAT_RANGE 242 -Infinity Infinity
FLOAT_RANGE 243 -Infinity Infinity
FLOAT_RANGE 244 -Infinity Infinity
ENUMERATION 245 1 go-to
SOAR_ID 246
SOAR_ID 247
ENUMERATION 248 1 state
ENUMERATION 249 1 go-to
ENUMERATION 250 1 set-waypoint
SOAR_ID 251
ENUMERATION 252 1 abandon-waypoint
SOAR_ID 253
ENUMERATION 254 1 initialize-progress
SOAR_ID 255
ENUMERATION 256 1 record-progress
SOAR_ID 257
ENUMERATION 258 1 turn-to-waypoint
SOAR_ID 259
ENUMERATION 260 1 move-forward
SOAR_ID 261
ENUMERATION 262 2 false true
FLOAT_RANGE 263 -Infinity Infinity
FLOAT_RANGE 264 -Infinity Infinity
SOAR_ID 265
INTEGER_RANGE 266 0 2147483647
FLOAT_RANGE 267 0.0 Infinity
FLOAT_RANGE 268 0.0 Infinity
FLOAT_RANGE 269 -Infinity Infinity
FLOAT_RANGE 270 -Infinity Infinity
FLOAT_RANGE 271 -Infinity Infinity
FLOAT_RANGE 272 -Infinity Infinity
FLOAT_RANGE 273 -Infinity Infinity
FLOAT_RANGE 274 -Infinity Infinity
FLOAT_RANGE 275 -Infinity Infinity
SOAR_ID 276
ENUMERATION 277 2 immediate true
ENUMERATION 278 2 false true
SOAR_ID 279
INTEGER_RANGE 280 0 2147483647
FLOAT_RANGE 281 0.0 Infinity
FLOAT_RANGE 282 0.0 Infinity
FLOAT_RANGE 283 -Infinity Infinity
FLOAT_RANGE 284 -Infinity Infinity
FLOAT_RANGE 285 -Infinity Infinity
FLOAT_RANGE 286 -Infinity Infinity
ENUMERATION 287 1 go-to
SOAR_ID 288
ENUMERATION 289 2 smem wm
ENUMERATION 290 2 smem wm
SOAR_ID 291
ENUMERATION 292 1 retrieve-current-area-smem
FLOAT_RANGE 293 -Infinity Infinity
INTEGER_RANGE 294 -2147483648 2147483647
INTEGER_RANGE 295 -2147483648 2147483647
INTEGER_RANGE 296 -2147483648 2147483647
FLOAT_RANGE 297 -Infinity Infinity
FLOAT_RANGE 298 -Infinity Infinity
SOAR_ID 299
ENUMERATION 300 1 retrieve-current-area-smem
SOAR_ID 301
ENUMERATION 302 1 state
ENUMERATION 303 1 retrieve-current-area-smem
ENUMERATION 304 1 add-gateways
SOAR_ID 305
ENUMERATION 306 1 create-current-area
SOAR_ID 307
ENUMERATION 308 1 retrieve-current-area
SOAR_ID 309
ENUMERATION 310 1 store-current-area
SOAR_ID 311
SOAR_ID 312
SOAR_ID 313
SOAR_ID 314
ENUMERATION 315 2 failure success
ENUMERATION 316 1 area
ENUMERATION 317 2 attempted failure
ENUMERATION 318 1 yes
ENUMERATION 319 1 yes
ENUMERATION 320 1 yes
ENUMERATION 321 1 store
SOAR_ID 322
SOAR_ID 323
ENUMERATION 324 1 yes
INTEGER_RANGE 325 -2147483648 2147483647
FLOAT_RANGE 326 -Infinity Infinity
FLOAT_RANGE 327 -Infinity Infinity
ENUMERATION 328 2 no yes
ENUMERATION 329 1 go-to
SOAR_ID 330
FLOAT_RANGE 331 -Infinity Infinity
ENUMERATION 332 2 no yes
FLOAT_RANGE 333 -Infinity Infinity
ENUMERATION 334 1 yes
ENUMERATION 335 2 no yes
ENUMERATION 336 1 go-to-area
SOAR_ID 337
SOAR_ID 338
ENUMERATION 339 1 state
ENUMERATION 340 2 evaluate-operator go-to-area
ENUMERATION 341 1 go-to-gateway
SOAR_ID 342
ENUMERATION 343 1 go-to-next-area
SOAR_ID 344
SOAR_ID 345
ENUMERATION 346 1 state
ENUMERATION 347 1 go-to-next-area
ENUMERATION 348 1 go-to
SOAR_ID 349
INTEGER_RANGE 350 -2147483648 2147483647
461
0 areas 98
0 attribute 9
0 blocks 163
0 choices 10
0 current-area 81
0 desired 145
0 destination-waypoint 276
0 direction 89
0 directions 94
0 impasse 11
0 io 1
0 name 12
0 no-storage-area 174
0 numbers 164
0 operator 13
0 operator 77
0 operator 79
0 operator 99
0 operator 110
0 operator 117
0 operator 119
0 operator 161
0 operator 184
0 operator 191
0 operator 246
0 operator 291
0 operator 299
0 operator 337
0 parameters 62
0 problem-space 143
0 quiescence 178
0 smem 312
0 superstate 5
0 superstate 0
0 tight-direction 89
0 top-state 0
0 type 4
0 wall-obstacle 169
1 input-link 2
1 output-link 3
2 area-description 16
2 object 193
2 self 15
2 time 195
3 add-waypoint 210
3 clear-message 224
3 configure 225
3 disable-waypoint 215
3 drop 55
3 enable-waypoint 215
3 estop 209
3 get 54
3 remove-message 222
3 remove-waypoint 214
3 send-message 216
3 set-heading 37
3 set-heading-linear 323
3 set-velocity 206
3 stop 209
3 stop-sim 7
7 status 40
7 true 8
13 actions 3
13 name 14
15 area 41
15 carry 43
15 collision 32
15 name 198
15 pose 199
15 stopped 335
15 waypoints 201
16 gateway 28
16 id 205
16 wall 17
17 direction 27
17 id 18
17 left 19
17 right 22
17 stored 320
17 x 25
17 y 26
17 yaw 182
19 col 20
19 row 21
22 col 24
22 row 23
28 direction 42
28 id 31
28 range 108
28 stored 319
28 to 325
28 x 29
28 y 30
28 yaw 183
32 x 34
32 y 33
37 status 39
37 yaw 38
43 id 44
43 type 45
46 area 47
46 id 48
46 range 50
46 type 49
46 visible 51
46 x 52
46 y 53
46 yaw 180
54 id 57
54 status 58
55 id 56
55 status 59
60 actions 3
60 name 61
62 areas-held-in 289
62 high-angular-velocity 231
62 high-linear-velocity 231
62 low-angular-velocity 229
62 low-linear-velocity 229
62 max-angular-distance 263
62 medium-angular-velocity 230
62 medium-linear-velocity 230
62 message-update-time 294
62 min-angular-distance 264
62 min-progress-distance 272
62 objects-held-in 290
62 pickup-range 63
62 progress-update-time 273
62 range-tolerance 295
62 rotation-tolerance 296
62 waypoint-tolerance 293
64 actions 3
64 name 65
66 block-id 68
66 io 1
66 name 72
66 object 193
66 object-in-range-lined-up 328
66 object-lined-up 181
66 operator 60
66 operator 74
66 operator 330
66 quiescence 178
66 stopped 334
66 superstate 112
66 top-state 0
66 type 67
69 id 71
69 name 70
74 name 73
75 name 76
77 area 81
77 name 78
79 name 80
81 cleaned 109
81 gateway 28
81 gateway-area 148
81 id 82
81 next 81
81 previous-area 81
81 search-start-direction 88
81 turning 324
81 type 316
81 visited 97
81 wall 17
81 x 326
81 y 327
83 current-area 81
83 io 1
83 name 85
83 operator 87
83 operator 91
83 operator 93
83 operator 96
83 quiescence 178
83 superstate 112
83 top-state 0
83 type 84
87 name 86
91 actions 3
91 name 90
93 name 92
94 ene 237
94 ese 240
94 heading 107
94 move-in-rectangle 104
94 move-in-rectangle-delta 105
94 move-in-rectangle-num 106
94 ne 232
94 nne 236
94 nnw 238
94 nw 233
94 opposite 89
94 se 234
94 sse 241
94 ssw 243
94 sw 235
94 value 89
94 wnw 239
94 wsw 242
96 name 95
98 area 81
99 area 81
99 name 100
99 type 129
101 connected-gateway 28
101 current-area 81
101 destination-area 81
101 io 1
101 name 103
101 operator 288
101 quiescence 177
101 superstate 0
101 top-state 0
101 type 102
110 name 111
112 current-area 81
112 io 1
112 name 114
112 operator 116
112 operator 69
112 operator 75
112 quiescence 178
112 superstate 0
112 top-state 0
112 type 113
116 area 81
116 name 115
116 type 130
117 name 118
119 name 120
122 current-area 81
122 io 1
122 name 124
122 operator 126
122 operator 128
122 operator 176
122 quiescence 178
122 superstate 0
122 top-state 0
122 type 123
126 area 81
126 name 125
126 type 130
128 name 127
128 wall-direction 131
132 collision 139
132 collision-distance 142
132 io 1
132 name 134
132 operator 136
132 operator 138
132 operator 141
132 operator 160
132 quiescence 177
132 superstate 122
132 top-state 0
132 type 133
136 name 135
138 name 137
141 actions 3
141 name 140
143 default-state-copy 147
143 name 144
143 one-level-attributes 146
145 storage-area-id 121
149 impasse 179
149 name 151
149 operator 153
149 quiescence 178
149 superstate 0
149 top-state 0
149 type 150
153 name 152
154 current-area 81
154 desired 145
154 destination-area 81
154 failure 145
154 indifferent 145
154 name 156
154 operator 158
154 partial-failure 145
154 quiescence 178
154 success 145
154 superstate 149
154 top-state 0
154 type 155
154 visited-area 81
158 gateway 28
158 name 157
160 name 159
161 block 46
161 name 162
163 block 46
164 number 165
165 one-less 168
165 one-more 167
165 value 166
169 info 170
170 against-wall 171
170 direction 171
170 equal-dimension 172
170 one-greater-than 173
170 one-less-than 173
176 name 175
184 name 185
184 player 193
186 io 1
186 name 188
186 operator 190
186 superstate 0
186 top-state 0
186 type 187
190 actions 3
190 name 189
191 name 192
193 abs-relative-bearing 298
193 distance 108
193 id 31
193 name 204
193 relative-bearing 297
193 type 203
193 visible 194
193 x 29
193 y 30
193 yaw 244
195 microseconds 197
195 seconds 196
199 x 35
199 x-velocity 202
199 y 36
199 y-velocity 202
199 yaw 200
199 yaw-velocity 202
199 z 35
201 waypoint 279
206 angular-velocity 207
206 linear-velocity 208
206 status 6
209 status 39
210 id 211
210 status 39
210 x 212
210 y 213
214 id 211
214 status 39
215 id 211
215 status 39
216 destination 217
216 first 219
216 next 219
216 status 39
216 word 218
219 next 220
219 next 221
222 id 223
222 status 39
224 status 39
225 offset-x 227
225 offset-y 228
225 status 39
225 yaw-format 226
246 destination 28
246 name 245
246 range 333
247 destination 265
247 destination-in-range 332
247 name 249
247 operator 251
247 operator 253
247 operator 255
247 operator 257
247 operator 259
247 operator 261
247 operator 64
247 set-waypoint 278
247 superstate 0
247 top-state 0
247 type 248
247 waypoint-data 279
247 yaw-aligned 262
251 name 250
253 name 252
255 name 254
257 name 256
259 actions 3
259 name 258
261 actions 3
261 name 260
265 distance 270
265 id 266
265 x 267
265 y 268
265 yaw 269
276 give-up 277
276 last-distance 274
276 next-update-time 271
276 progress 275
276 waypoint 265
279 abs-relative-bearing 286
279 distance 284
279 id 280
279 relative-bearing 285
279 x 281
279 y 282
279 yaw 283
288 destination 28
288 name 287
291 name 292
299 name 300
301 added-gateways 318
301 area 81
301 name 303
301 operator 305
301 operator 307
301 operator 309
301 operator 311
301 operator 322
301 retrieve 317
301 smem 312
301 superstate 0
301 top-state 0
301 type 302
305 gateway 28
305 name 304
307 name 306
309 name 308
311 name 310
312 command 313
312 result 314
313 query 81
313 retrieve 81
313 store 81
314 retrieved 81
314 status 315
322 name 321
322 object 28
323 linear-velocity 208
323 status 39
323 yaw 38
330 destination 193
330 name 329
330 range 331
337 name 336
338 name 340
338 operator 342
338 operator 344
338 superstate 0
338 top-state 0
338 type 339
342 name 341
344 name 343
344 next-waypoint 81
345 name 347
345 operator 349
345 superstate 338
345 top-state 0
345 type 346
349 destination 28
349 gateway-area-id 350
349 name 348
