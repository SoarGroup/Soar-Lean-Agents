615
SOAR_ID 0
SOAR_ID 1
SOAR_ID 2
SOAR_ID 3
ENUMERATION 4 2 goto-area state
ENUMERATION 5 1 nil
ENUMERATION 6 3 accepted complete error
ENUMERATION 7 2 operator state
ENUMERATION 8 2 multiple none
ENUMERATION 9 2 no-change tie
ENUMERATION 10 2 evaluate-operator robot
SOAR_ID 11
ENUMERATION 12 1 wait
SOAR_ID 13
SOAR_ID 14
SOAR_ID 15
SOAR_ID 16
INTEGER_RANGE 17 0 2147483647
INTEGER_RANGE 18 0 2147483647
SOAR_ID 19
INTEGER_RANGE 20 0 2147483647
INTEGER_RANGE 21 0 2147483647
FLOAT_RANGE 22 -Infinity Infinity
FLOAT_RANGE 23 -Infinity Infinity
ENUMERATION 24 4 east north south west
SOAR_ID 25
FLOAT_RANGE 26 -Infinity Infinity
FLOAT_RANGE 27 -Infinity Infinity
INTEGER_RANGE 28 0 2147483647
FLOAT_RANGE 29 -Infinity Infinity
FLOAT_RANGE 30 -Infinity Infinity
SOAR_ID 31
FLOAT_RANGE 32 -180.0 180.0
ENUMERATION 33 4 accepted complete error interrupted
INTEGER_RANGE 34 -2147483648 2147483647
ENUMERATION 35 4 east north south west
SOAR_ID 36
INTEGER_RANGE 37 -2147483648 2147483647
INTEGER_RANGE 38 -2147483648 2147483647
ENUMERATION 39 4 ball block brick ied
FLOAT_RANGE 40 -Infinity Infinity
ENUMERATION 41 2 no yes
FLOAT_RANGE 42 -Infinity Infinity
FLOAT_RANGE 43 -Infinity Infinity
SOAR_ID 44
SOAR_ID 45
INTEGER_RANGE 46 -2147483648 2147483647
INTEGER_RANGE 47 -2147483648 2147483647
ENUMERATION 48 2 complete error
ENUMERATION 49 2 complete error
SOAR_ID 50
ENUMERATION 51 1 grasp-block
SOAR_ID 52
FLOAT_RANGE 53 -Infinity Infinity
SOAR_ID 54
ENUMERATION 55 1 stop
SOAR_ID 56
ENUMERATION 57 1 state
INTEGER_RANGE 58 -2147483648 2147483647
SOAR_ID 59
ENUMERATION 60 1 pickup-block
INTEGER_RANGE 61 -2147483648 2147483647
ENUMERATION 62 1 pickup-block
ENUMERATION 63 1 spin
SOAR_ID 64
SOAR_ID 65
ENUMERATION 66 1 find-block-in-area
SOAR_ID 67
ENUMERATION 68 1 record-area
SOAR_ID 69
ENUMERATION 70 1 init-robot
SOAR_ID 71
INTEGER_RANGE 72 -2147483648 2147483647
SOAR_ID 73
ENUMERATION 74 1 state
ENUMERATION 75 1 find-block-in-area
ENUMERATION 76 1 record-area-direction
SOAR_ID 77
ENUMERATION 78 4 east north south west
ENUMERATION 79 4 east north south west
ENUMERATION 80 1 spin
SOAR_ID 81
ENUMERATION 82 1 note-turning
SOAR_ID 83
SOAR_ID 84
ENUMERATION 85 1 stop-spin
SOAR_ID 86
ENUMERATION 87 2 no yes
SOAR_ID 88
SOAR_ID 89
ENUMERATION 90 1 goto-unvisited-area
FLOAT_RANGE 91 -Infinity Infinity
ENUMERATION 92 2 no yes
SOAR_ID 93
ENUMERATION 94 1 get-block
SOAR_ID 95
ENUMERATION 96 1 state
ENUMERATION 97 1 get-block
ENUMERATION 98 1 goto-not-clean-area
SOAR_ID 99
SOAR_ID 100
ENUMERATION 101 1 deposit-block
SOAR_ID 102
ENUMERATION 103 1 finished-cleaning
INTEGER_RANGE 104 -2147483648 2147483647
SOAR_ID 105
ENUMERATION 106 1 state
ENUMERATION 107 1 deposit-block
ENUMERATION 108 1 goto-storage-area
SOAR_ID 109
ENUMERATION 110 1 move-to-wall
SOAR_ID 111
ENUMERATION 112 2 go-to-area goto-area
ENUMERATION 113 1 go-to-area
ENUMERATION 114 4 east north south west
SOAR_ID 115
ENUMERATION 116 1 state
ENUMERATION 117 1 move-to-wall
ENUMERATION 118 1 turn-to-wall
SOAR_ID 119
ENUMERATION 120 1 move-forward
SOAR_ID 121
ENUMERATION 122 2 false true
ENUMERATION 123 1 drop-block
SOAR_ID 124
INTEGER_RANGE 125 -2147483648 2147483647
SOAR_ID 126
ENUMERATION 127 1 clean-house
SOAR_ID 128
STRING 129
ENUMERATION 130 2 no yes
SOAR_ID 131
ENUMERATION 132 1 state
ENUMERATION 133 2 Impasse__Operator_Tie selection
ENUMERATION 134 1 evaluate-operator
SOAR_ID 135
SOAR_ID 136
ENUMERATION 137 1 state
ENUMERATION 138 1 evaluate-operator
ENUMERATION 139 1 go-to-next-area
SOAR_ID 140
ENUMERATION 141 1 turn-from-block
SOAR_ID 142
SOAR_ID 143
ENUMERATION 144 1 record-block
SOAR_ID 145
SOAR_ID 146
SOAR_ID 147
INTEGER_RANGE 148 -2147483648 2147483647
INTEGER_RANGE 149 -2147483648 2147483647
INTEGER_RANGE 150 -2147483648 2147483647
ENUMERATION 151 1 yes
ENUMERATION 152 1 detect-no-storage-area
SOAR_ID 153
ENUMERATION 154 1 t
ENUMERATION 155 1 t
ENUMERATION 156 1 tie
FLOAT_RANGE 157 -Infinity Infinity
ENUMERATION 158 2 no yes
SOAR_ID 159
ENUMERATION 160 1 chase
SOAR_ID 161
ENUMERATION 162 1 state
ENUMERATION 163 1 chase
ENUMERATION 164 1 move-to-player
SOAR_ID 165
SOAR_ID 166
ENUMERATION 167 1 record-unconnected-area
SOAR_ID 168
ENUMERATION 169 2 no yes
SOAR_ID 170
INTEGER_RANGE 171 -2147483648 2147483647
INTEGER_RANGE 172 -2147483648 2147483647
STRING 173
SOAR_ID 174
INTEGER_RANGE 175 -2147483648 2147483647
SOAR_ID 176
FLOAT_RANGE 177 -Infinity Infinity
ENUMERATION 178 5 ball block brick ied player
STRING 179
INTEGER_RANGE 180 -2147483648 2147483647
SOAR_ID 181
FLOAT_RANGE 182 -180.0 180.0
FLOAT_RANGE 183 -0.5 0.5
SOAR_ID 184
SOAR_ID 185
STRING 186
FLOAT_RANGE 187 -Infinity Infinity
FLOAT_RANGE 188 -Infinity Infinity
SOAR_ID 189
SOAR_ID 190
SOAR_ID 191
STRING 192
SOAR_ID 193
SOAR_ID 194
ENUMERATION 195 1 nil
SOAR_ID 196
STRING 197
SOAR_ID 198
SOAR_ID 199
FLOAT_RANGE 200 -Infinity Infinity
FLOAT_RANGE 201 -Infinity Infinity
FLOAT_RANGE 202 -Infinity Infinity
FLOAT_RANGE 203 -Infinity Infinity
FLOAT_RANGE 204 -Infinity Infinity
FLOAT_RANGE 205 -Infinity Infinity
FLOAT_RANGE 206 -Infinity Infinity
FLOAT_RANGE 207 -Infinity Infinity
FLOAT_RANGE 208 -Infinity Infinity
FLOAT_RANGE 209 -Infinity Infinity
FLOAT_RANGE 210 -Infinity Infinity
FLOAT_RANGE 211 -Infinity Infinity
FLOAT_RANGE 212 -Infinity Infinity
FLOAT_RANGE 213 -Infinity Infinity
FLOAT_RANGE 214 -Infinity Infinity
ENUMERATION 215 1 go-to
SOAR_ID 216
SOAR_ID 217
ENUMERATION 218 1 state
ENUMERATION 219 1 go-to
ENUMERATION 220 1 set-waypoint
SOAR_ID 221
ENUMERATION 222 1 abandon-waypoint
SOAR_ID 223
ENUMERATION 224 1 initialize-progress
SOAR_ID 225
ENUMERATION 226 1 record-progress
SOAR_ID 227
ENUMERATION 228 1 turn-to-waypoint
SOAR_ID 229
ENUMERATION 230 1 move-forward
SOAR_ID 231
ENUMERATION 232 2 false true
FLOAT_RANGE 233 -Infinity Infinity
FLOAT_RANGE 234 -Infinity Infinity
SOAR_ID 235
INTEGER_RANGE 236 0 2147483647
FLOAT_RANGE 237 0.0 Infinity
FLOAT_RANGE 238 0.0 Infinity
FLOAT_RANGE 239 -Infinity Infinity
FLOAT_RANGE 240 -Infinity Infinity
FLOAT_RANGE 241 -Infinity Infinity
FLOAT_RANGE 242 -Infinity Infinity
FLOAT_RANGE 243 -Infinity Infinity
FLOAT_RANGE 244 -Infinity Infinity
FLOAT_RANGE 245 -Infinity Infinity
SOAR_ID 246
ENUMERATION 247 2 immediate true
ENUMERATION 248 2 false true
SOAR_ID 249
INTEGER_RANGE 250 -2147483648 2147483647
FLOAT_RANGE 251 0.0 Infinity
FLOAT_RANGE 252 0.0 Infinity
FLOAT_RANGE 253 -Infinity Infinity
ENUMERATION 254 2 smem wm
ENUMERATION 255 3 epmem smem wm
SOAR_ID 256
ENUMERATION 257 1 record-smem-current-area
FLOAT_RANGE 258 -Infinity Infinity
INTEGER_RANGE 259 -2147483648 2147483647
INTEGER_RANGE 260 -2147483648 2147483647
INTEGER_RANGE 261 -2147483648 2147483647
SOAR_ID 262
SOAR_ID 263
SOAR_ID 264
ENUMERATION 265 1 yes
ENUMERATION 266 1 yes
SOAR_ID 267
ENUMERATION 268 1 yes
FLOAT_RANGE 269 -Infinity Infinity
FLOAT_RANGE 270 -Infinity Infinity
ENUMERATION 271 2 no yes
ENUMERATION 272 1 go-to
SOAR_ID 273
FLOAT_RANGE 274 -Infinity Infinity
ENUMERATION 275 2 no yes
FLOAT_RANGE 276 -Infinity Infinity
ENUMERATION 277 1 yes
ENUMERATION 278 2 no yes
ENUMERATION 279 1 go-to-area
SOAR_ID 280
ENUMERATION 281 1 go-to-next-area
SOAR_ID 282
ENUMERATION 283 2 door room
ENUMERATION 284 2 door room
ENUMERATION 285 1 yes
ENUMERATION 286 1 yes
SOAR_ID 287
ENUMERATION 288 1 turn-through-doorway
SOAR_ID 289
SOAR_ID 290
INTEGER_RANGE 291 -2147483648 2147483647
INTEGER_RANGE 292 -2147483648 2147483647
INTEGER_RANGE 293 -2147483648 2147483647
ENUMERATION 294 1 go-to-seen-block
SOAR_ID 295
ENUMERATION 296 4 east north south west
FLOAT_RANGE 297 -Infinity Infinity
SOAR_ID 298
FLOAT_RANGE 299 -Infinity Infinity
INTEGER_RANGE 300 -2147483648 2147483647
INTEGER_RANGE 301 -2147483648 2147483647
FLOAT_RANGE 302 -Infinity Infinity
FLOAT_RANGE 303 -Infinity Infinity
SOAR_ID 304
ENUMERATION 305 1 record-smem-new-gateway-area
ENUMERATION 306 2 no yes
SOAR_ID 307
ENUMERATION 308 1 retrieve-current-area-walls
SOAR_ID 309
ENUMERATION 310 1 retrieve-current-area-gateways
ENUMERATION 311 1 yes
ENUMERATION 312 1 retrieve-blocks
SOAR_ID 313
ENUMERATION 314 1 yes
ENUMERATION 315 1 block
ENUMERATION 316 2 no yes
ENUMERATION 317 1 block
ENUMERATION 318 2 no yes
SOAR_ID 319
ENUMERATION 320 1 record-storage-area
SOAR_ID 321
ENUMERATION 322 1 re-record-block
ENUMERATION 323 1 wall
ENUMERATION 324 1 gateway
SOAR_ID 325
ENUMERATION 326 1 retrieve-neighbor-area
SOAR_ID 327
SOAR_ID 328
ENUMERATION 329 1 go-to-area
SOAR_ID 330
ENUMERATION 331 1 go-to
ENUMERATION 332 2 no yes
INTEGER_RANGE 333 -2147483648 2147483647
SOAR_ID 334
ENUMERATION 335 1 store-area
ENUMERATION 336 1 goto-unvisited-area
SOAR_ID 337
ENUMERATION 338 1 yes
ENUMERATION 339 1 true
SOAR_ID 340
SOAR_ID 341
ENUMERATION 342 1 go-to
INTEGER_RANGE 343 -2147483648 2147483647
ENUMERATION 344 2 no yes
ENUMERATION 345 2 no yes
ENUMERATION 346 1 find-block-in-area
SOAR_ID 347
SOAR_ID 348
ENUMERATION 349 1 state
ENUMERATION 350 1 msg
ENUMERATION 351 1 msg-bad
SOAR_ID 352
ENUMERATION 353 1 all
SOAR_ID 354
ENUMERATION 355 1 instr-all
SOAR_ID 356
SOAR_ID 357
ENUMERATION 358 1 state
ENUMERATION 359 1 instr-all
ENUMERATION 360 1 all-do
SOAR_ID 361
ENUMERATION 362 1 instr-stop
SOAR_ID 363
ENUMERATION 364 1 instr-label
SOAR_ID 365
SOAR_ID 366
ENUMERATION 367 1 state
ENUMERATION 368 1 instr-label
ENUMERATION 369 1 label-do
SOAR_ID 370
ENUMERATION 371 1 label-done
SOAR_ID 372
ENUMERATION 373 1 label-prior
SOAR_ID 374
SOAR_ID 375
ENUMERATION 376 1 record-label
ENUMERATION 377 1 true
STRING 378
STRING 379
SOAR_ID 380
SOAR_ID 381
STRING 382
STRING 383
STRING 384
SOAR_ID 385
STRING 386
INTEGER_RANGE 387 -2147483648 2147483647
SOAR_ID 388
ENUMERATION 389 1 state
ENUMERATION 390 1 grasp-block
ENUMERATION 391 1 grasp-confirm
SOAR_ID 392
ENUMERATION 393 1 grasp-diffuse
SOAR_ID 394
ENUMERATION 395 1 grasp-get
SOAR_ID 396
ENUMERATION 397 1 instr-confirmed
SOAR_ID 398
ENUMERATION 399 1 go-to-unseen-block-in-room
SOAR_ID 400
ENUMERATION 401 1 instr-goto
SOAR_ID 402
SOAR_ID 403
ENUMERATION 404 1 state
ENUMERATION 405 1 instr-goto
ENUMERATION 406 1 goto-do
SOAR_ID 407
SOAR_ID 408
ENUMERATION 409 1 force-go
ENUMERATION 410 1 instr-allow
SOAR_ID 411
ENUMERATION 412 1 instr-avoid
SOAR_ID 413
SOAR_ID 414
ENUMERATION 415 1 record-avoid
ENUMERATION 416 1 instr-connected
SOAR_ID 417
SOAR_ID 418
ENUMERATION 419 1 state
ENUMERATION 420 1 instr-connected
ENUMERATION 421 1 connected-do
SOAR_ID 422
ENUMERATION 423 1 goto-done
SOAR_ID 424
ENUMERATION 425 1 connected-done
SOAR_ID 426
ENUMERATION 427 1 true
ENUMERATION 428 1 instr-patrol
SOAR_ID 429
ENUMERATION 430 11 all allow avoid circuit-patrol confirmed connected goto initiate label linear-patrol terminate
SOAR_ID 431
ENUMERATION 432 1 msg
STRING 433
SOAR_ID 434
ENUMERATION 435 1 nil
SOAR_ID 436
SOAR_ID 437
SOAR_ID 438
ENUMERATION 439 1 true
ENUMERATION 440 1 nil
STRING 441
ENUMERATION 442 1 true
SOAR_ID 443
ENUMERATION 444 2 circuit-patrol linear-patrol
STRING 445
SOAR_ID 446
STRING 447
STRING 448
INTEGER_RANGE 449 -2147483648 2147483647
ENUMERATION 450 1 instr-initiate
SOAR_ID 451
ENUMERATION 452 1 instr-terminate
SOAR_ID 453
SOAR_ID 454
ENUMERATION 455 2 circuit-patrol linear-patrol
ENUMERATION 456 4 executing initiated suspended terminated
STRING 457
ENUMERATION 458 1 patrol
ENUMERATION 459 1 instr-circuit-patrol
SOAR_ID 460
SOAR_ID 461
ENUMERATION 462 1 execute-mission
SOAR_ID 463
ENUMERATION 464 1 state
ENUMERATION 465 1 execute-mission
ENUMERATION 466 1 patrol
SOAR_ID 467
SOAR_ID 468
INTEGER_RANGE 469 -2147483648 2147483647
ENUMERATION 470 1 nil
SOAR_ID 471
ENUMERATION 472 1 state
ENUMERATION 473 1 instr-patrol
ENUMERATION 474 1 init-list-copy
SOAR_ID 475
ENUMERATION 476 1 terminate-list-copy
SOAR_ID 477
ENUMERATION 478 1 copy-list-element
SOAR_ID 479
ENUMERATION 480 1 nil
SOAR_ID 481
INTEGER_RANGE 482 -2147483648 2147483647
SOAR_ID 483
ENUMERATION 484 1 nil
ENUMERATION 485 1 nil
SOAR_ID 486
ENUMERATION 487 1 state
ENUMERATION 488 1 patrol
ENUMERATION 489 1 goto-next-area
SOAR_ID 490
ENUMERATION 491 1 go-to-area
ENUMERATION 492 1 next-area
SOAR_ID 493
ENUMERATION 494 1 restart-patrol-first-area
SOAR_ID 495
ENUMERATION 496 1 true
INTEGER_RANGE 497 -2147483648 2147483647
FLOAT_RANGE 498 -Infinity Infinity
INTEGER_RANGE 499 -2147483648 2147483647
INTEGER_RANGE 500 -2147483648 2147483647
INTEGER_RANGE 501 -2147483648 2147483647
FLOAT_RANGE 502 -Infinity Infinity
INTEGER_RANGE 503 -2147483648 2147483647
INTEGER_RANGE 504 -2147483648 2147483647
FLOAT_RANGE 505 -Infinity Infinity
INTEGER_RANGE 506 -2147483648 2147483647
SOAR_ID 507
ENUMERATION 508 2 float int
ENUMERATION 509 2 degrees radians
SOAR_ID 510
FLOAT_RANGE 511 -Infinity Infinity
FLOAT_RANGE 512 -Infinity Infinity
FLOAT_RANGE 513 -Infinity Infinity
FLOAT_RANGE 514 -Infinity Infinity
ENUMERATION 515 2 feet meters
SOAR_ID 516
SOAR_ID 517
SOAR_ID 518
SOAR_ID 519
FLOAT_RANGE 520 -Infinity Infinity
FLOAT_RANGE 521 -Infinity Infinity
FLOAT_RANGE 522 -Infinity Infinity
FLOAT_RANGE 523 -Infinity Infinity
SOAR_ID 524
FLOAT_RANGE 525 -Infinity Infinity
FLOAT_RANGE 526 -Infinity Infinity
FLOAT_RANGE 527 -Infinity Infinity
ENUMERATION 528 3 feet_per_sec meters_per_sec miles_per_hour
SOAR_ID 529
SOAR_ID 530
FLOAT_RANGE 531 0.0 Infinity
INTEGER_RANGE 532 -2 2
INTEGER_RANGE 533 -2147483648 2147483647
SOAR_ID 534
INTEGER_RANGE 535 -2147483648 2147483647
INTEGER_RANGE 536 -2147483648 2147483647
FLOAT_RANGE 537 -Infinity Infinity
INTEGER_RANGE 538 -2147483648 2147483647
SOAR_ID 539
SOAR_ID 540
SOAR_ID 541
SOAR_ID 542
STRING 543
INTEGER_RANGE 544 -2147483648 2147483647
ENUMERATION 545 1 nil
STRING 546
INTEGER_RANGE 547 -2147483648 2147483647
FLOAT_RANGE 548 0.0 Infinity
FLOAT_RANGE 549 -Infinity Infinity
INTEGER_RANGE 550 -2147483648 2147483647
INTEGER_RANGE 551 -2147483648 2147483647
INTEGER_RANGE 552 -2147483648 2147483647
FLOAT_RANGE 553 -Infinity Infinity
STRING 554
INTEGER_RANGE 555 -2147483648 2147483647
ENUMERATION 556 2 float int
ENUMERATION 557 2 degrees radians
ENUMERATION 558 2 feet meters
SOAR_ID 559
ENUMERATION 560 3 feet_per_sec meters_per_sec miles_per_hour
FLOAT_RANGE 561 -Infinity Infinity
FLOAT_RANGE 562 -Infinity Infinity
FLOAT_RANGE 563 -Infinity Infinity
INTEGER_RANGE 564 -2147483648 2147483647
INTEGER_RANGE 565 -2147483648 2147483647
STRING 566
SOAR_ID 567
INTEGER_RANGE 568 -2147483648 2147483647
INTEGER_RANGE 569 -2147483648 2147483647
INTEGER_RANGE 570 -2147483648 2147483647
ENUMERATION 571 1 true
INTEGER_RANGE 572 -2147483648 2147483647
SOAR_ID 573
ENUMERATION 574 2 false true
FLOAT_RANGE 575 -Infinity Infinity
ENUMERATION 576 2 false true
SOAR_ID 577
ENUMERATION 578 5 -1 -2 0 1 2
ENUMERATION 579 2 false true
SOAR_ID 580
ENUMERATION 581 1 turn-around-object
ENUMERATION 582 2 no yes
SOAR_ID 583
FLOAT_RANGE 584 -Infinity Infinity
FLOAT_RANGE 585 -Infinity Infinity
FLOAT_RANGE 586 -Infinity Infinity
FLOAT_RANGE 587 -Infinity Infinity
INTEGER_RANGE 588 -2147483648 2147483647
INTEGER_RANGE 589 -2147483648 2147483647
INTEGER_RANGE 590 -2147483648 2147483647
INTEGER_RANGE 591 -2147483648 2147483647
ENUMERATION 592 1 grasp-help
SOAR_ID 593
ENUMERATION 594 1 grasp-plan
SOAR_ID 595
ENUMERATION 596 1 grasp-warn
SOAR_ID 597
ENUMERATION 598 1 instr-diffuse-wire
SOAR_ID 599
ENUMERATION 600 1 instr-heuristic
SOAR_ID 601
ENUMERATION 602 1 label-done
SOAR_ID 603
ENUMERATION 604 1 label-first
SOAR_ID 605
ENUMERATION 606 1 label-next
SOAR_ID 607
SOAR_ID 608
ENUMERATION 609 1 state
ENUMERATION 610 1 record-label
ENUMERATION 611 1 record-label-first
SOAR_ID 612
ENUMERATION 613 1 record-label-next
SOAR_ID 614
760
0 all-visited 339
0 areas 88
0 attribute 7
0 avoids 443
0 blocks 145
0 choices 8
0 current-location 71
0 current-mission 454
0 desired 128
0 destination-waypoint 246
0 direction 79
0 directions 84
0 epmem 262
0 gateway-directions 287
0 gotos 567
0 impasse 9
0 io 1
0 labels 380
0 name 10
0 no-storage-area 151
0 numbers 146
0 operator 11
0 operator 67
0 operator 69
0 operator 89
0 operator 93
0 operator 100
0 operator 102
0 operator 143
0 operator 159
0 operator 166
0 operator 216
0 operator 256
0 operator 280
0 operator 304
0 operator 307
0 operator 309
0 operator 319
0 operator 321
0 operator 325
0 operator 334
0 operator 375
0 operator 408
0 operator 414
0 operator 431
0 operator 461
0 parameters 52
0 path-cost 297
0 patrol 446
0 pending 573
0 problem-space 126
0 quiescence 155
0 reading 434
0 reading 435
0 smem 262
0 storage-area 71
0 superstate 5
0 superstate 0
0 tight-direction 79
0 top-state 0
0 type 4
1 input-link 2
1 output-link 3
2 area-description 14
2 configuration 507
2 lidar 529
2 objects 534
2 received-messages 539
2 self 13
2 time 170
2 waypoints 176
3 add-waypoint 185
3 clear-message 198
3 configure 199
3 disable-waypoint 190
3 drop-object 45
3 enable-waypoint 190
3 estop 184
3 get-object 44
3 remove-message 196
3 remove-waypoint 189
3 send-message 191
3 set-heading 31
3 set-heading-linear 267
3 set-velocity 181
3 stop 184
11 actions 3
11 name 12
13 area 34
13 carry 547
13 name 173
13 pose 174
13 stopped 278
14 gateway 25
14 id 180
14 type 284
14 wall 15
15 abs-relative-bearing 503
15 direction 24
15 left 16
15 relative-bearing 504
15 right 19
15 stored 266
15 type 323
15 x 22
15 y 23
15 yaw 506
15 z 505
16 col 17
16 row 18
19 col 21
19 row 20
25 abs-relative-bearing 497
25 connected 306
25 direction 35
25 distance 498
25 id 28
25 range 91
25 relative-bearing 499
25 stored 265
25 to 500
25 type 324
25 x 26
25 y 27
25 yaw 501
25 z 502
31 status 33
31 yaw 32
36 area 37
36 class 315
36 color 379
36 id 38
36 ied 377
36 in-storage-room 316
36 range 40
36 type 39
36 visible 41
36 x 42
36 y 43
36 yaw 157
44 id 47
44 status 48
45 id 46
45 status 49
50 actions 3
50 name 51
52 areas-held-in 254
52 collision-range 575
52 high-angular-velocity 202
52 high-linear-velocity 202
52 increased-angular-tolerance-multiplier 587
52 increased-angular-tolerance-range 586
52 look-ahead-planning 344
52 low-angular-velocity 200
52 low-linear-velocity 200
52 max-angular-distance 233
52 medium-angular-velocity 201
52 medium-linear-velocity 201
52 message-update-time 259
52 min-angular-distance 234
52 min-progress-distance 242
52 objects-held-in 255
52 pickup-range 53
52 progress-update-time 243
52 range-tolerance 260
52 rotation-tolerance 261
52 search-control-go-to-gateway 345
52 waypoint-tolerance 258
54 actions 3
54 name 55
56 block-id 58
56 io 1
56 name 62
56 object 168
56 object-in-range-lined-up 271
56 object-lined-up 158
56 operator 50
56 operator 64
56 operator 273
56 quiescence 155
56 stopped 277
56 superstate 95
56 top-state 0
56 type 57
59 id 61
59 name 60
64 name 63
65 name 66
67 area 71
67 name 68
69 name 70
71 avoid 427
71 class 317
71 cleaned 92
71 gateway 25
71 gateway-x 300
71 gateway-y 301
71 id 72
71 in-storage-room 318
71 neighbor-area 71
71 next 71
71 previous-area 71
71 search-start-direction 78
71 storage-area 311
71 store 338
71 turning 268
71 type 283
71 visited 87
71 wall 15
71 x 269
71 y 270
73 current-location 71
73 io 1
73 name 75
73 operator 77
73 operator 81
73 operator 83
73 operator 86
73 quiescence 155
73 superstate 95
73 top-state 0
73 type 74
77 name 76
81 actions 3
81 name 80
83 name 82
84 ene 208
84 ese 211
84 ne 203
84 nne 207
84 nnw 209
84 nw 204
84 opposite 296
84 se 205
84 sse 212
84 ssw 214
84 sw 206
84 value 296
84 wnw 210
84 wsw 213
86 name 85
88 area 71
89 area 71
89 name 90
89 type 112
93 name 94
95 area 71
95 current-location 71
95 epmem 262
95 io 1
95 name 97
95 operator 99
95 operator 59
95 operator 65
95 operator 295
95 operator 313
95 operator 337
95 operator 400
95 parameters 52
95 quiescence 155
95 retrieved-blocks 314
95 smem 262
95 superstate 0
95 top-state 0
95 type 96
99 area 71
99 name 98
99 type 113
100 name 101
102 name 103
105 area 71
105 current-location 71
105 io 1
105 name 107
105 operator 109
105 operator 111
105 operator 153
105 operator 347
105 quiescence 155
105 smem 262
105 superstate 0
105 top-state 0
105 type 106
109 area 71
109 name 108
109 type 113
111 name 110
111 wall-direction 114
115 collision 122
115 collision-distance 125
115 io 1
115 name 117
115 operator 119
115 operator 121
115 operator 124
115 operator 142
115 quiescence 154
115 superstate 105
115 top-state 0
115 type 116
119 name 118
121 name 120
124 actions 3
124 name 123
126 default-state-copy 130
126 name 127
126 one-level-attributes 129
128 location 71
128 storage-area-id 104
131 evaluation 298
131 impasse 156
131 name 133
131 operator 135
131 quiescence 155
131 superstate 0
131 top-state 0
131 type 132
135 name 134
136 current-location 71
136 desired 128
136 destination-area 71
136 failure 128
136 indifferent 128
136 name 138
136 operator 140
136 partial-failure 128
136 quiescence 155
136 success 128
136 superstate 131
136 top-state 0
136 type 137
136 visited-area 71
140 name 139
140 next-waypoint 25
142 name 141
143 block 36
143 name 144
145 block 36
146 number 147
147 one-less 150
147 one-more 149
147 value 148
153 name 152
159 name 160
159 player 168
161 io 1
161 name 163
161 operator 165
161 superstate 0
161 top-state 0
161 type 162
165 actions 3
165 name 164
166 name 167
168 abs-relative-bearing 535
168 color 378
168 distance 91
168 id 28
168 name 179
168 relative-bearing 536
168 type 178
168 visible 169
168 x 26
168 y 27
168 yaw 538
168 z 537
170 microseconds 172
170 seconds 171
174 magnitude 548
174 x 29
174 x-velocity 177
174 y 30
174 y-velocity 177
174 yaw 175
174 yaw-velocity 177
174 z 29
174 z-velocity 549
176 waypoint 249
181 angular-velocity 182
181 linear-velocity 183
181 status 6
184 status 33
185 id 186
185 id 555
185 status 33
185 x 187
185 y 188
189 id 186
189 id 565
189 status 33
190 id 186
190 id 564
190 status 33
191 destination 192
191 first 193
191 status 33
193 next 194
193 next 195
193 word 566
196 id 197
196 status 33
198 status 33
199 angle-resolution 556
199 angle-units 557
199 length-units 558
199 pose-translation 559
199 speed-units 560
199 status 33
216 cross-doorway 286
216 destination 25
216 name 215
216 range 276
217 angular-tolerances 583
217 clear 577
217 cross-doorway 285
217 destination 25
217 destination-in-range 275
217 front-clear 576
217 io 1
217 name 219
217 obstacle 574
217 operator 221
217 operator 223
217 operator 225
217 operator 227
217 operator 229
217 operator 231
217 operator 54
217 operator 289
217 operator 580
217 set-waypoint 248
217 superstate 0
217 top-state 0
217 type 218
217 waypoint-data 249
217 yaw-aligned 232
221 name 220
223 name 222
225 name 224
227 name 226
229 actions 3
229 name 228
231 actions 3
231 name 230
235 distance 240
235 id 236
235 x 237
235 y 238
235 yaw 239
246 give-up 247
246 last-distance 244
246 next-update-time 241
246 progress 245
246 waypoint 235
249 abs-relative-bearing 550
249 distance 253
249 id 250
249 id 554
249 relative-bearing 551
249 x 251
249 y 252
249 yaw 552
249 z 553
256 name 257
262 command 263
262 result 264
263 neg-query 71
263 neg-query 327
263 query 71
263 query 327
263 retrieve 71
263 store 71
264 failure 71
264 retrieved 71
264 retrieved 327
264 success 71
267 linear-velocity 183
267 status 33
267 yaw 32
273 destination 168
273 name 272
273 range 274
280 current-location 71
280 desired 340
280 destination-area 71
280 name 279
280 operator 330
280 superstate 95
280 top-state 0
280 type 329
282 name 281
282 next-waypoint 71
282 operator 341
282 superstate 0
282 top-state 0
287 east 290
287 north 290
287 south 290
287 west 290
289 name 288
290 max 293
290 max-neg 588
290 max-pos 590
290 min 292
290 min-neg 589
290 min-pos 591
290 value 291
295 name 294
298 current-location 71
298 estimated-cost 303
298 path-cost 299
298 total-estimated-cost 302
304 gateway 25
304 name 305
307 name 308
307 wall 15
309 gateway 25
309 name 310
313 name 312
319 name 320
321 name 322
325 name 326
327 blocks 328
328 block 71
330 cross-doorway 332
330 destination 25
330 gateway-area-id 333
330 name 331
334 name 335
337 name 336
340 location 71
341 destination 25
341 gateway-area-id 343
341 name 342
347 name 346
348 message 385
348 name 350
348 operator 352
348 operator 354
348 operator 356
348 operator 363
348 operator 365
348 operator 398
348 operator 402
348 operator 411
348 operator 413
348 operator 417
348 operator 429
348 operator 451
348 operator 453
348 operator 460
348 operator 599
348 operator 601
348 superstate 0
348 supported 430
348 top-state 0
348 type 349
352 name 351
354 name 353
356 done 442
356 label 441
356 name 355
357 name 359
357 operator 361
357 superstate 348
357 top-state 0
357 type 358
361 name 360
363 name 362
365 name 364
366 name 368
366 operator 370
366 operator 372
366 operator 374
366 operator 603
366 operator 605
366 operator 607
366 superstate 348
366 top-state 0
366 type 367
370 name 369
372 name 371
374 name 373
375 block 36
375 label 384
375 name 376
380 label 381
381 attr 382
381 label 384
381 value 383
385 first 385
385 from 433
385 id 387
385 next 385
385 next 440
385 word 386
388 name 390
388 operator 392
388 operator 394
388 operator 396
388 operator 593
388 operator 595
388 operator 597
388 superstate 56
388 top-state 0
388 type 389
392 name 391
394 name 393
396 name 395
398 name 397
400 name 399
402 name 401
403 name 405
403 operator 407
403 operator 424
403 superstate 348
403 top-state 0
403 type 404
407 name 406
408 loc 569
408 name 409
408 priority 570
411 name 410
411 room 449
413 name 412
414 id 572
414 name 415
417 name 416
418 name 420
418 operator 422
418 operator 426
418 superstate 348
418 top-state 0
418 type 419
422 name 421
424 name 423
426 name 425
429 area-list 385
429 name 428
429 patrol-name 445
429 patrol-type 444
431 message 385
431 name 432
431 processed 439
434 first 436
434 next 438
434 word 437
443 avoid 571
446 first-area 481
446 patrol-name 447
446 patrol-type 448
451 name 450
451 type 458
453 name 452
454 first-area 468
454 name 457
454 next-area 468
454 status 456
454 type 455
460 name 459
461 name 462
463 name 465
463 operator 467
463 superstate 0
463 top-state 0
463 type 464
467 name 466
468 id 469
468 next 468
468 next 470
471 copy-destination 481
471 copy-destination 484
471 copy-source 385
471 copy-source 480
471 name 473
471 operator 475
471 operator 477
471 operator 479
471 superstate 348
471 top-state 0
471 type 472
475 name 474
477 name 476
479 name 478
481 id 482
481 next 483
481 next 485
486 achieved-area 496
486 name 488
486 operator 490
486 operator 493
486 operator 495
486 superstate 463
486 top-state 0
486 type 487
490 area 71
490 name 489
490 type 491
493 name 492
495 name 494
507 angle-resolution 508
507 angle-units 509
507 geometry 510
507 length-units 515
507 limits 516
507 pose-translation 524
507 speed-units 528
510 height 511
510 length 512
510 wheelbase 513
510 width 514
516 velocity 517
517 angular 518
517 linear 519
518 maximum 521
518 minimum 520
519 maximum 523
519 minimum 522
524 x 525
524 y 526
524 z 527
529 range 530
530 distance 531
530 id 532
530 relative-bearing 533
534 object 168
539 message 540
540 first 541
540 from 543
540 id 544
541 next 542
541 next 545
541 word 546
559 x 561
559 y 562
559 z 563
567 priority 568
577 clear 579
577 id 578
580 id 578
580 name 581
580 short-turn 582
583 max 584
583 min 585
593 name 592
595 name 594
597 name 596
599 name 598
601 name 600
603 name 602
605 name 604
607 name 606
608 name 610
608 operator 612
608 operator 614
608 superstate 0
608 top-state 0
608 type 609
612 name 611
614 name 613
