629
SOAR_ID 0
SOAR_ID 1
SOAR_ID 2
SOAR_ID 3
ENUMERATION 4 2 goto-area state
ENUMERATION 5 1 nil
ENUMERATION 6 3 accepted complete error
SOAR_ID 7
STRING 8
ENUMERATION 9 2 operator state
ENUMERATION 10 2 multiple none
ENUMERATION 11 2 no-change tie
ENUMERATION 12 4 deposit-block evaluate-operator goto-storage-area robot
SOAR_ID 13
ENUMERATION 14 1 wait
SOAR_ID 15
SOAR_ID 16
SOAR_ID 17
INTEGER_RANGE 18 0 2147483647
SOAR_ID 19
INTEGER_RANGE 20 0 2147483647
INTEGER_RANGE 21 0 2147483647
SOAR_ID 22
INTEGER_RANGE 23 0 2147483647
INTEGER_RANGE 24 0 2147483647
FLOAT_RANGE 25 0.0 Infinity
FLOAT_RANGE 26 0.0 Infinity
ENUMERATION 27 4 east north south west
SOAR_ID 28
FLOAT_RANGE 29 0.0 Infinity
FLOAT_RANGE 30 0.0 Infinity
INTEGER_RANGE 31 0 2147483647
SOAR_ID 32
ENUMERATION 33 2 false true
ENUMERATION 34 2 false true
FLOAT_RANGE 35 0.0 Infinity
FLOAT_RANGE 36 0.0 Infinity
SOAR_ID 37
FLOAT_RANGE 38 -180.0 180.0
ENUMERATION 39 4 accepted complete error interrupted
ENUMERATION 40 2 complete error
INTEGER_RANGE 41 -2147483648 2147483647
ENUMERATION 42 4 east north south west
SOAR_ID 43
INTEGER_RANGE 44 -2147483648 2147483647
ENUMERATION 45 1 block
SOAR_ID 46
INTEGER_RANGE 47 -2147483648 2147483647
INTEGER_RANGE 48 -2147483648 2147483647
FLOAT_RANGE 49 -Infinity Infinity
ENUMERATION 50 2 no yes
FLOAT_RANGE 51 -Infinity Infinity
FLOAT_RANGE 52 -Infinity Infinity
SOAR_ID 53
SOAR_ID 54
INTEGER_RANGE 55 -2147483648 2147483647
INTEGER_RANGE 56 -2147483648 2147483647
ENUMERATION 57 2 complete error
ENUMERATION 58 2 complete error
SOAR_ID 59
ENUMERATION 60 1 grasp-block
SOAR_ID 61
FLOAT_RANGE 62 -Infinity Infinity
SOAR_ID 63
ENUMERATION 64 1 stop
SOAR_ID 65
ENUMERATION 66 1 state
INTEGER_RANGE 67 -2147483648 2147483647
SOAR_ID 68
ENUMERATION 69 1 pickup-block
INTEGER_RANGE 70 -2147483648 2147483647
ENUMERATION 71 1 pickup-block
ENUMERATION 72 1 spin
SOAR_ID 73
SOAR_ID 74
ENUMERATION 75 1 find-block-in-area
SOAR_ID 76
ENUMERATION 77 1 record-area
SOAR_ID 78
ENUMERATION 79 1 init-robot
SOAR_ID 80
INTEGER_RANGE 81 -2147483648 2147483647
SOAR_ID 82
ENUMERATION 83 1 state
ENUMERATION 84 1 find-block-in-area
ENUMERATION 85 1 record-area-direction
SOAR_ID 86
ENUMERATION 87 4 east north south west
ENUMERATION 88 4 east north south west
ENUMERATION 89 1 spin
SOAR_ID 90
ENUMERATION 91 1 note-turning
SOAR_ID 92
SOAR_ID 93
ENUMERATION 94 1 stop-spin
SOAR_ID 95
ENUMERATION 96 2 no yes
SOAR_ID 97
SOAR_ID 98
ENUMERATION 99 1 goto-unvisited-area
FLOAT_RANGE 100 -Infinity Infinity
ENUMERATION 101 2 no yes
SOAR_ID 102
ENUMERATION 103 1 get-block
SOAR_ID 104
ENUMERATION 105 1 state
ENUMERATION 106 1 get-block
ENUMERATION 107 1 goto-not-clean-area
SOAR_ID 108
SOAR_ID 109
ENUMERATION 110 1 deposit-block
SOAR_ID 111
ENUMERATION 112 1 finished-cleaning
INTEGER_RANGE 113 -2147483648 2147483647
SOAR_ID 114
ENUMERATION 115 1 state
ENUMERATION 116 1 deposit-block
ENUMERATION 117 1 goto-storage-area
SOAR_ID 118
ENUMERATION 119 1 move-to-wall
SOAR_ID 120
ENUMERATION 121 2 go-to-area goto-area
ENUMERATION 122 1 go-to-area
ENUMERATION 123 4 east north south west
SOAR_ID 124
ENUMERATION 125 1 state
ENUMERATION 126 1 move-to-wall
ENUMERATION 127 1 turn-to-wall
SOAR_ID 128
ENUMERATION 129 1 move-forward
SOAR_ID 130
ENUMERATION 131 2 false true
ENUMERATION 132 1 drop-block
SOAR_ID 133
INTEGER_RANGE 134 -2147483648 2147483647
SOAR_ID 135
ENUMERATION 136 1 clean-house
SOAR_ID 137
STRING 138
ENUMERATION 139 2 no yes
SOAR_ID 140
ENUMERATION 141 1 state
ENUMERATION 142 2 Impasse__Operator_Tie selection
ENUMERATION 143 1 evaluate-operator
SOAR_ID 144
SOAR_ID 145
ENUMERATION 146 1 state
ENUMERATION 147 1 evaluate-operator
ENUMERATION 148 1 go-to-next-area
SOAR_ID 149
ENUMERATION 150 1 turn-from-block
SOAR_ID 151
SOAR_ID 152
ENUMERATION 153 1 record-block
SOAR_ID 154
SOAR_ID 155
SOAR_ID 156
INTEGER_RANGE 157 -2147483648 2147483647
INTEGER_RANGE 158 -2147483648 2147483647
INTEGER_RANGE 159 -2147483648 2147483647
ENUMERATION 160 1 yes
ENUMERATION 161 1 detect-no-storage-area
SOAR_ID 162
ENUMERATION 163 1 t
ENUMERATION 164 1 t
ENUMERATION 165 1 tie
FLOAT_RANGE 166 -Infinity Infinity
ENUMERATION 167 2 no yes
FLOAT_RANGE 168 -Infinity Infinity
FLOAT_RANGE 169 -Infinity Infinity
SOAR_ID 170
ENUMERATION 171 1 chase
SOAR_ID 172
ENUMERATION 173 1 state
ENUMERATION 174 1 chase
ENUMERATION 175 1 move-to-player
SOAR_ID 176
SOAR_ID 177
ENUMERATION 178 1 record-unconnected-area
SOAR_ID 179
ENUMERATION 180 2 no yes
SOAR_ID 181
INTEGER_RANGE 182 -2147483648 2147483647
INTEGER_RANGE 183 -2147483648 2147483647
STRING 184
SOAR_ID 185
INTEGER_RANGE 186 -180 180
SOAR_ID 187
FLOAT_RANGE 188 -Infinity Infinity
STRING 189
INTEGER_RANGE 190 -2147483648 2147483647
SOAR_ID 191
FLOAT_RANGE 192 -180.0 180.0
FLOAT_RANGE 193 -0.5 0.5
SOAR_ID 194
SOAR_ID 195
STRING 196
FLOAT_RANGE 197 -Infinity Infinity
FLOAT_RANGE 198 -Infinity Infinity
SOAR_ID 199
SOAR_ID 200
SOAR_ID 201
STRING 202
STRING 203
SOAR_ID 204
ENUMERATION 205 1 nil
SOAR_ID 206
STRING 207
SOAR_ID 208
SOAR_ID 209
STRING 210
FLOAT_RANGE 211 -Infinity Infinity
FLOAT_RANGE 212 -Infinity Infinity
FLOAT_RANGE 213 -Infinity Infinity
FLOAT_RANGE 214 -Infinity Infinity
FLOAT_RANGE 215 -Infinity Infinity
FLOAT_RANGE 216 -Infinity Infinity
FLOAT_RANGE 217 -Infinity Infinity
FLOAT_RANGE 218 -Infinity Infinity
FLOAT_RANGE 219 -Infinity Infinity
FLOAT_RANGE 220 -Infinity Infinity
FLOAT_RANGE 221 -Infinity Infinity
FLOAT_RANGE 222 -Infinity Infinity
FLOAT_RANGE 223 -Infinity Infinity
FLOAT_RANGE 224 -Infinity Infinity
FLOAT_RANGE 225 -Infinity Infinity
FLOAT_RANGE 226 -Infinity Infinity
FLOAT_RANGE 227 -Infinity Infinity
FLOAT_RANGE 228 -Infinity Infinity
ENUMERATION 229 1 go-to
SOAR_ID 230
SOAR_ID 231
ENUMERATION 232 1 state
ENUMERATION 233 1 go-to
ENUMERATION 234 1 set-waypoint
SOAR_ID 235
ENUMERATION 236 1 abandon-waypoint
SOAR_ID 237
ENUMERATION 238 1 initialize-progress
SOAR_ID 239
ENUMERATION 240 1 record-progress
SOAR_ID 241
ENUMERATION 242 1 turn-to-waypoint
SOAR_ID 243
ENUMERATION 244 1 move-forward
SOAR_ID 245
ENUMERATION 246 2 false true
FLOAT_RANGE 247 -Infinity Infinity
FLOAT_RANGE 248 -Infinity Infinity
SOAR_ID 249
INTEGER_RANGE 250 0 2147483647
FLOAT_RANGE 251 0.0 Infinity
FLOAT_RANGE 252 0.0 Infinity
FLOAT_RANGE 253 -Infinity Infinity
FLOAT_RANGE 254 -Infinity Infinity
FLOAT_RANGE 255 -Infinity Infinity
FLOAT_RANGE 256 -Infinity Infinity
FLOAT_RANGE 257 -Infinity Infinity
FLOAT_RANGE 258 -Infinity Infinity
FLOAT_RANGE 259 -Infinity Infinity
SOAR_ID 260
ENUMERATION 261 2 immediate true
ENUMERATION 262 2 false true
SOAR_ID 263
INTEGER_RANGE 264 0 2147483647
FLOAT_RANGE 265 0.0 Infinity
FLOAT_RANGE 266 0.0 Infinity
FLOAT_RANGE 267 -Infinity Infinity
FLOAT_RANGE 268 -Infinity Infinity
FLOAT_RANGE 269 -Infinity Infinity
FLOAT_RANGE 270 -Infinity Infinity
ENUMERATION 271 2 smem wm
ENUMERATION 272 3 epmem smem wm
SOAR_ID 273
ENUMERATION 274 1 record-smem-current-area
FLOAT_RANGE 275 -Infinity Infinity
INTEGER_RANGE 276 -2147483648 2147483647
INTEGER_RANGE 277 -2147483648 2147483647
INTEGER_RANGE 278 -2147483648 2147483647
FLOAT_RANGE 279 -Infinity Infinity
FLOAT_RANGE 280 -Infinity Infinity
SOAR_ID 281
SOAR_ID 282
SOAR_ID 283
ENUMERATION 284 1 yes
ENUMERATION 285 1 yes
SOAR_ID 286
ENUMERATION 287 1 yes
INTEGER_RANGE 288 -2147483648 2147483647
FLOAT_RANGE 289 -Infinity Infinity
FLOAT_RANGE 290 -Infinity Infinity
ENUMERATION 291 2 no yes
ENUMERATION 292 1 go-to
SOAR_ID 293
FLOAT_RANGE 294 -Infinity Infinity
ENUMERATION 295 2 no yes
FLOAT_RANGE 296 -Infinity Infinity
ENUMERATION 297 1 yes
ENUMERATION 298 2 no yes
ENUMERATION 299 1 go-to-area
SOAR_ID 300
ENUMERATION 301 1 go-to-next-area
SOAR_ID 302
ENUMERATION 303 2 door room
ENUMERATION 304 2 door room
ENUMERATION 305 1 yes
ENUMERATION 306 1 yes
SOAR_ID 307
ENUMERATION 308 1 turn-through-doorway
SOAR_ID 309
SOAR_ID 310
INTEGER_RANGE 311 -2147483648 2147483647
INTEGER_RANGE 312 -2147483648 2147483647
INTEGER_RANGE 313 -2147483648 2147483647
ENUMERATION 314 1 go-to-seen-block
SOAR_ID 315
ENUMERATION 316 4 east north south west
FLOAT_RANGE 317 -Infinity Infinity
SOAR_ID 318
FLOAT_RANGE 319 -Infinity Infinity
INTEGER_RANGE 320 -2147483648 2147483647
INTEGER_RANGE 321 -2147483648 2147483647
FLOAT_RANGE 322 -Infinity Infinity
FLOAT_RANGE 323 -Infinity Infinity
SOAR_ID 324
ENUMERATION 325 1 record-smem-new-gateway-area
ENUMERATION 326 2 no yes
SOAR_ID 327
ENUMERATION 328 1 retrieve-current-area-walls
SOAR_ID 329
ENUMERATION 330 1 retrieve-current-area-gateways
ENUMERATION 331 1 yes
ENUMERATION 332 1 retrieve-blocks
SOAR_ID 333
ENUMERATION 334 1 yes
ENUMERATION 335 1 block
ENUMERATION 336 2 no yes
ENUMERATION 337 1 block
ENUMERATION 338 2 no yes
SOAR_ID 339
ENUMERATION 340 1 record-storage-area
SOAR_ID 341
ENUMERATION 342 1 re-record-block
ENUMERATION 343 1 wall
ENUMERATION 344 1 gateway
SOAR_ID 345
ENUMERATION 346 1 retrieve-neighbor-area
SOAR_ID 347
SOAR_ID 348
ENUMERATION 349 1 go-to-area
SOAR_ID 350
ENUMERATION 351 1 go-to
ENUMERATION 352 2 no yes
INTEGER_RANGE 353 -2147483648 2147483647
SOAR_ID 354
ENUMERATION 355 1 store-area
ENUMERATION 356 1 goto-unvisited-area
SOAR_ID 357
ENUMERATION 358 1 yes
ENUMERATION 359 1 true
SOAR_ID 360
SOAR_ID 361
ENUMERATION 362 1 go-to
INTEGER_RANGE 363 -2147483648 2147483647
ENUMERATION 364 2 no yes
ENUMERATION 365 2 no yes
ENUMERATION 366 1 find-block-in-area
SOAR_ID 367
SOAR_ID 368
ENUMERATION 369 1 state
ENUMERATION 370 1 msg
ENUMERATION 371 1 msg-bad
SOAR_ID 372
ENUMERATION 373 1 all
SOAR_ID 374
ENUMERATION 375 1 instr-all
SOAR_ID 376
SOAR_ID 377
ENUMERATION 378 1 state
ENUMERATION 379 1 instr-all
ENUMERATION 380 1 all-do
SOAR_ID 381
ENUMERATION 382 1 instr-stop
SOAR_ID 383
ENUMERATION 384 1 instr-label
SOAR_ID 385
SOAR_ID 386
ENUMERATION 387 1 state
ENUMERATION 388 1 instr-label
ENUMERATION 389 1 label-first
SOAR_ID 390
ENUMERATION 391 1 label-done
SOAR_ID 392
ENUMERATION 393 1 label-prior
SOAR_ID 394
SOAR_ID 395
ENUMERATION 396 1 record-label
ENUMERATION 397 1 true
STRING 398
STRING 399
SOAR_ID 400
SOAR_ID 401
STRING 402
SOAR_ID 403
SOAR_ID 404
STRING 405
INTEGER_RANGE 406 -2147483648 2147483647
SOAR_ID 407
ENUMERATION 408 1 state
ENUMERATION 409 1 grasp-block
ENUMERATION 410 1 grasp-confirm
SOAR_ID 411
ENUMERATION 412 1 grasp-diffuse
SOAR_ID 413
ENUMERATION 414 1 grasp-get
SOAR_ID 415
ENUMERATION 416 1 instr-confirmed
SOAR_ID 417
ENUMERATION 418 1 go-to-unseen-block-in-room
SOAR_ID 419
ENUMERATION 420 1 instr-goto
SOAR_ID 421
SOAR_ID 422
ENUMERATION 423 1 state
ENUMERATION 424 1 instr-goto
ENUMERATION 425 1 goto-do
SOAR_ID 426
SOAR_ID 427
ENUMERATION 428 1 force-go
ENUMERATION 429 1 instr-allow
SOAR_ID 430
ENUMERATION 431 1 instr-avoid
SOAR_ID 432
SOAR_ID 433
ENUMERATION 434 1 record-avoid
ENUMERATION 435 1 instr-connected
SOAR_ID 436
SOAR_ID 437
ENUMERATION 438 1 state
ENUMERATION 439 1 instr-connected
ENUMERATION 440 1 connected-do
SOAR_ID 441
ENUMERATION 442 1 goto-done
SOAR_ID 443
ENUMERATION 444 1 connected-done
SOAR_ID 445
ENUMERATION 446 1 true
ENUMERATION 447 1 instr-patrol
SOAR_ID 448
ENUMERATION 449 14 all allow avoid circuit-patrol confirmed connected diffuse-wire goto heuristic initiate label linear-patrol saw terminate
SOAR_ID 450
ENUMERATION 451 1 msg
STRING 452
SOAR_ID 453
ENUMERATION 454 1 nil
SOAR_ID 455
SOAR_ID 456
SOAR_ID 457
ENUMERATION 458 1 true
ENUMERATION 459 1 nil
STRING 460
ENUMERATION 461 1 true
SOAR_ID 462
ENUMERATION 463 2 circuit-patrol linear-patrol
STRING 464
SOAR_ID 465
STRING 466
STRING 467
INTEGER_RANGE 468 -2147483648 2147483647
ENUMERATION 469 1 instr-initiate
SOAR_ID 470
ENUMERATION 471 1 instr-terminate
SOAR_ID 472
SOAR_ID 473
ENUMERATION 474 2 circuit-patrol linear-patrol
ENUMERATION 475 4 executing initiated suspended terminated
STRING 476
ENUMERATION 477 1 patrol
ENUMERATION 478 1 instr-circuit-patrol
SOAR_ID 479
SOAR_ID 480
ENUMERATION 481 1 execute-mission
SOAR_ID 482
ENUMERATION 483 1 state
ENUMERATION 484 1 execute-mission
ENUMERATION 485 1 patrol
SOAR_ID 486
SOAR_ID 487
INTEGER_RANGE 488 -2147483648 2147483647
ENUMERATION 489 1 nil
SOAR_ID 490
ENUMERATION 491 1 state
ENUMERATION 492 1 instr-patrol
ENUMERATION 493 1 init-list-copy
SOAR_ID 494
ENUMERATION 495 1 terminate-list-copy
SOAR_ID 496
ENUMERATION 497 1 copy-list-element
SOAR_ID 498
ENUMERATION 499 1 nil
SOAR_ID 500
INTEGER_RANGE 501 -2147483648 2147483647
SOAR_ID 502
ENUMERATION 503 1 nil
ENUMERATION 504 1 nil
SOAR_ID 505
ENUMERATION 506 1 state
ENUMERATION 507 1 patrol
ENUMERATION 508 1 goto-next-area
SOAR_ID 509
ENUMERATION 510 1 go-to-area
ENUMERATION 511 1 next-area
SOAR_ID 512
ENUMERATION 513 1 restart-patrol-first-area
SOAR_ID 514
ENUMERATION 515 1 true
SOAR_ID 516
INTEGER_RANGE 517 -2147483648 2147483647
SOAR_ID 518
SOAR_ID 519
ENUMERATION 520 1 true
INTEGER_RANGE 521 -2147483648 2147483647
INTEGER_RANGE 522 -2147483648 2147483647
INTEGER_RANGE 523 -2147483648 2147483647
INTEGER_RANGE 524 -2147483648 2147483647
INTEGER_RANGE 525 -2147483648 2147483647
STRING 526
STRING 527
ENUMERATION 528 1 no
ENUMERATION 529 2 received waiting
INTEGER_RANGE 530 -2147483648 2147483647
INTEGER_RANGE 531 -2147483648 2147483647
INTEGER_RANGE 532 -2147483648 2147483647
INTEGER_RANGE 533 -2147483648 2147483647
STRING 534
SOAR_ID 535
STRING 536
ENUMERATION 537 1 nil
SOAR_ID 538
STRING 539
ENUMERATION 540 1 nil
SOAR_ID 541
INTEGER_RANGE 542 -2147483648 2147483647
ENUMERATION 543 2 false true
STRING 544
STRING 545
SOAR_ID 546
INTEGER_RANGE 547 -2147483648 2147483647
ENUMERATION 548 3 blue green red
STRING 549
STRING 550
ENUMERATION 551 1 label-next
SOAR_ID 552
ENUMERATION 553 1 label-done
SOAR_ID 554
INTEGER_RANGE 555 -2147483648 2147483647
SOAR_ID 556
STRING 557
STRING 558
ENUMERATION 559 1 nil
SOAR_ID 560
STRING 561
STRING 562
ENUMERATION 563 1 nil
SOAR_ID 564
STRING 565
STRING 566
ENUMERATION 567 1 nil
STRING 568
SOAR_ID 569
STRING 570
ENUMERATION 571 1 nil
ENUMERATION 572 1 nil
ENUMERATION 573 2 match tried
SOAR_ID 574
ENUMERATION 575 1 state
ENUMERATION 576 1 record-label
ENUMERATION 577 1 record-label-first
SOAR_ID 578
ENUMERATION 579 1 record-label-next
SOAR_ID 580
ENUMERATION 581 1 nil
STRING 582
STRING 583
STRING 584
STRING 585
STRING 586
STRING 587
SOAR_ID 588
ENUMERATION 589 1 instr-heuristic
SOAR_ID 590
SOAR_ID 591
STRING 592
STRING 593
STRING 594
STRING 595
INTEGER_RANGE 596 -2147483648 2147483647
INTEGER_RANGE 597 -2147483648 2147483647
ENUMERATION 598 1 grasp-help
SOAR_ID 599
ENUMERATION 600 1 grasp-plan
SOAR_ID 601
STRING 602
ENUMERATION 603 1 instr-diffuse-wire
SOAR_ID 604
STRING 605
STRING 606
STRING 607
STRING 608
ENUMERATION 609 1 grasp-warn
SOAR_ID 610
ENUMERATION 611 1 true
ENUMERATION 612 1 instr-saw
SOAR_ID 613
INTEGER_RANGE 614 -2147483648 2147483647
SOAR_ID 615
INTEGER_RANGE 616 -2147483648 2147483647
SOAR_ID 617
ENUMERATION 618 1 state
ENUMERATION 619 1 instr-saw
ENUMERATION 620 1 saw-init
SOAR_ID 621
ENUMERATION 622 2 new old
ENUMERATION 623 1 true
ENUMERATION 624 1 nil
ENUMERATION 625 1 saw-next
SOAR_ID 626
ENUMERATION 627 1 saw-done
SOAR_ID 628
787
0 all-visited 359
0 areas 97
0 attribute 9
0 avoids 462
0 blocks 154
0 choices 10
0 current-location 80
0 current-mission 473
0 desired 137
0 destination-waypoint 260
0 diffusing 588
0 direction 88
0 directions 93
0 epmem 281
0 gateway-directions 307
0 gotos 516
0 impasse 11
0 io 1
0 labels 400
0 name 12
0 no-storage-area 160
0 numbers 155
0 operator 13
0 operator 76
0 operator 78
0 operator 98
0 operator 102
0 operator 109
0 operator 111
0 operator 152
0 operator 170
0 operator 177
0 operator 230
0 operator 273
0 operator 300
0 operator 324
0 operator 327
0 operator 329
0 operator 339
0 operator 341
0 operator 345
0 operator 354
0 operator 395
0 operator 427
0 operator 433
0 operator 450
0 operator 480
0 parameters 61
0 path-cost 317
0 patrol 465
0 problem-space 135
0 quiescence 164
0 reading 453
0 reading 454
0 smem 281
0 storage-area 80
0 superstate 5
0 superstate 0
0 tight-direction 88
0 top-state 0
0 type 4
1 input-link 2
1 output-link 3
2 area-description 16
2 object 179
2 self 15
2 time 181
3 add-waypoint 195
3 clear-message 208
3 configure 209
3 diffuse-object 541
3 diffuse-object-by-wire 546
3 disable-waypoint 200
3 drop-object 54
3 enable-waypoint 200
3 estop 194
3 get-object 53
3 remove-message 206
3 remove-waypoint 199
3 send-message 201
3 set-heading 37
3 set-heading-linear 286
3 set-velocity 191
3 stop 194
3 stop-sim 7
7 status 40
7 true 8
13 actions 3
13 name 14
15 area 41
15 carry 43
15 collision 32
15 name 184
15 pose 185
15 received-messages 403
15 stopped 298
15 waypoints 187
16 gateway 28
16 id 190
16 type 304
16 wall 17
17 direction 27
17 id 18
17 left 19
17 right 22
17 stored 285
17 type 343
17 x 25
17 y 26
17 yaw 168
19 col 20
19 row 21
22 col 24
22 row 23
28 connected 326
28 direction 42
28 id 31
28 range 100
28 stored 284
28 to 288
28 type 344
28 x 29
28 y 30
28 yaw 169
32 x 34
32 y 33
37 status 39
37 yaw 38
43 id 44
43 type 45
46 area 47
46 class 335
46 color 399
46 confirmation 529
46 height 587
46 id 48
46 ied 397
46 in-storage-room 336
46 range 49
46 shape 585
46 smell 586
46 type 545
46 visible 50
46 x 51
46 y 52
46 yaw 166
53 id 56
53 status 57
54 id 55
54 status 58
59 actions 3
59 id 531
59 name 60
61 areas-held-in 271
61 high-angular-velocity 215
61 high-linear-velocity 215
61 look-ahead-planning 364
61 low-angular-velocity 213
61 low-linear-velocity 213
61 max-angular-distance 247
61 medium-angular-velocity 214
61 medium-linear-velocity 214
61 message-update-time 276
61 min-angular-distance 248
61 min-progress-distance 256
61 objects-held-in 272
61 pickup-range 62
61 progress-update-time 257
61 range-tolerance 277
61 rotation-tolerance 278
61 search-control-go-to-gateway 365
61 waypoint-tolerance 275
63 actions 3
63 name 64
65 block-id 67
65 io 1
65 name 71
65 object 179
65 object-in-range-lined-up 291
65 object-lined-up 167
65 operator 59
65 operator 73
65 operator 293
65 quiescence 164
65 stopped 297
65 superstate 104
65 top-state 0
65 type 66
68 id 70
68 name 69
73 name 72
74 name 75
76 area 80
76 name 77
78 name 79
80 avoid 446
80 class 337
80 cleaned 101
80 gateway 28
80 gateway-x 320
80 gateway-y 321
80 id 81
80 in-storage-room 338
80 neighbor-area 80
80 next 80
80 previous-area 80
80 search-start-direction 87
80 storage-area 331
80 store 358
80 turning 287
80 type 303
80 visited 96
80 wall 17
80 x 289
80 y 290
82 current-location 80
82 io 1
82 name 84
82 operator 86
82 operator 90
82 operator 92
82 operator 95
82 quiescence 164
82 superstate 104
82 top-state 0
82 type 83
86 name 85
90 actions 3
90 name 89
92 name 91
93 ene 221
93 ese 224
93 ne 216
93 nne 220
93 nnw 222
93 nw 217
93 opposite 316
93 se 218
93 sse 225
93 ssw 227
93 sw 219
93 value 316
93 wnw 223
93 wsw 226
95 name 94
97 area 80
98 area 80
98 name 99
98 type 121
102 name 103
104 area 80
104 current-location 80
104 epmem 281
104 io 1
104 name 106
104 operator 108
104 operator 68
104 operator 74
104 operator 315
104 operator 333
104 operator 357
104 operator 419
104 operator 230
104 parameters 61
104 quiescence 164
104 retrieved-blocks 334
104 smem 281
104 superstate 0
104 top-state 0
104 type 105
108 area 80
108 name 107
108 storage-area 528
108 type 122
109 name 110
111 name 112
114 area 80
114 current-location 80
114 io 1
114 name 116
114 operator 118
114 operator 120
114 operator 162
114 operator 367
114 quiescence 164
114 smem 281
114 superstate 0
114 top-state 0
114 type 115
118 area 80
118 name 117
118 type 122
120 name 119
120 wall-direction 123
124 collision 131
124 collision-distance 134
124 io 1
124 name 126
124 operator 128
124 operator 130
124 operator 133
124 operator 151
124 quiescence 163
124 superstate 114
124 top-state 0
124 type 125
128 name 127
130 name 129
133 actions 3
133 name 132
135 default-state-copy 139
135 name 136
135 one-level-attributes 138
137 location 80
137 storage-area-id 113
140 evaluation 318
140 impasse 165
140 name 142
140 operator 144
140 quiescence 164
140 superstate 0
140 top-state 0
140 type 141
144 name 143
145 current-location 80
145 desired 137
145 destination-area 80
145 failure 137
145 indifferent 137
145 name 147
145 operator 149
145 partial-failure 137
145 quiescence 164
145 success 137
145 superstate 140
145 top-state 0
145 type 146
145 visited-area 80
149 name 148
149 next-waypoint 28
151 name 150
152 block 46
152 name 153
154 block 46
155 number 156
156 one-less 159
156 one-more 158
156 value 157
162 name 161
170 name 171
170 player 179
172 io 1
172 name 174
172 operator 176
172 superstate 0
172 top-state 0
172 type 173
176 actions 3
176 name 175
177 name 178
179 abs-relative-bearing 280
179 color 398
179 diffuse-wire 608
179 diffused 543
179 distance 100
179 height 582
179 id 31
179 name 189
179 relative-bearing 279
179 shape 583
179 smell 584
179 type 544
179 visible 180
179 x 29
179 y 30
179 yaw 228
181 microseconds 183
181 seconds 182
185 x 35
185 x-velocity 188
185 y 36
185 y-velocity 188
185 yaw 186
185 yaw-velocity 188
185 z 35
187 waypoint 263
191 angular-velocity 192
191 linear-velocity 193
191 message 526
191 status 6
194 message 527
194 status 39
195 id 196
195 status 39
195 x 197
195 y 198
199 id 196
199 status 39
200 id 196
200 status 39
201 destination 202
201 first 204
201 next 204
201 status 39
201 word 203
204 next 205
204 next 535
204 word 534
206 id 207
206 status 39
208 status 39
209 offset-x 211
209 offset-y 212
209 status 39
209 yaw-format 210
230 cross-doorway 306
230 destination 28
230 name 229
230 range 296
231 cross-doorway 305
231 destination 249
231 destination-in-range 295
231 name 233
231 operator 235
231 operator 237
231 operator 239
231 operator 241
231 operator 243
231 operator 245
231 operator 63
231 operator 309
231 set-waypoint 262
231 superstate 0
231 top-state 0
231 type 232
231 waypoint-data 263
231 yaw-aligned 246
235 name 234
237 name 236
239 name 238
241 name 240
243 actions 3
243 name 242
245 actions 3
245 name 244
249 distance 254
249 id 250
249 x 251
249 y 252
249 yaw 253
260 give-up 261
260 last-distance 258
260 next-update-time 255
260 progress 259
260 waypoint 249
263 abs-relative-bearing 270
263 distance 268
263 id 264
263 relative-bearing 269
263 x 265
263 y 266
263 yaw 267
273 name 274
281 command 282
281 result 283
282 neg-query 80
282 neg-query 347
282 query 80
282 query 347
282 retrieve 80
282 store 80
283 failure 80
283 retrieved 80
283 retrieved 347
283 success 80
286 linear-velocity 193
286 status 39
286 yaw 38
293 destination 179
293 name 292
293 range 294
300 current-location 80
300 desired 360
300 destination-area 80
300 name 299
300 operator 350
300 superstate 104
300 top-state 0
300 type 349
302 name 301
302 next-waypoint 80
302 operator 361
302 superstate 0
302 top-state 0
307 east 310
307 north 310
307 south 310
307 west 310
309 name 308
310 max 313
310 max-neg 524
310 max-pos 523
310 min 312
310 min-neg 525
310 min-pos 522
310 value 311
315 name 314
318 current-location 80
318 estimated-cost 323
318 path-cost 319
318 total-estimated-cost 322
324 gateway 28
324 name 325
327 name 328
327 wall 17
329 gateway 28
329 name 330
333 name 332
339 name 340
341 name 342
345 name 346
347 blocks 348
348 block 80
350 cross-doorway 352
350 destination 28
350 gateway-area-id 353
350 name 351
354 name 355
357 name 356
360 location 80
361 destination 28
361 gateway-area-id 363
361 name 362
367 name 366
368 message 404
368 name 370
368 operator 372
368 operator 374
368 operator 376
368 operator 383
368 operator 385
368 operator 417
368 operator 421
368 operator 430
368 operator 432
368 operator 436
368 operator 448
368 operator 470
368 operator 472
368 operator 479
368 operator 590
368 operator 604
368 operator 613
368 superstate 0
368 supported 449
368 top-state 0
368 type 369
372 name 371
374 name 373
376 done 461
376 label 460
376 name 375
377 name 379
377 operator 381
377 superstate 368
377 top-state 0
377 type 378
381 name 380
383 name 382
385 conds 569
385 label 568
385 name 384
386 input 404
386 input 572
386 name 388
386 operator 390
386 operator 392
386 operator 394
386 operator 552
386 operator 554
386 output 560
386 prev 560
386 prev 571
386 superstate 368
386 top-state 0
386 type 387
390 name 389
392 name 391
394 name 393
395 label 401
395 name 396
395 status 573
400 label 401
400 unique 606
401 first 556
401 name 402
401 tried 555
403 message 404
404 first 404
404 from 452
404 id 406
404 next 404
404 next 459
404 word 405
407 block 46
407 clear 611
407 name 409
407 operator 411
407 operator 413
407 operator 415
407 operator 599
407 operator 601
407 operator 610
407 superstate 65
407 top-state 0
407 type 408
411 name 410
413 name 412
415 name 414
417 name 416
419 name 418
421 area 80
421 id 530
421 name 420
422 area-id 532
422 name 424
422 operator 426
422 operator 443
422 priority 533
422 superstate 368
422 top-state 0
422 type 423
426 name 425
427 loc 518
427 name 428
427 priority 519
430 name 429
430 room 468
432 name 431
433 id 521
433 name 434
436 name 435
437 name 439
437 operator 441
437 operator 445
437 superstate 368
437 top-state 0
437 type 438
441 name 440
443 name 442
445 name 444
448 area-list 404
448 name 447
448 patrol-name 464
448 patrol-type 463
450 message 404
450 name 451
450 processed 458
453 first 455
453 next 457
453 word 456
462 id 520
465 first-area 500
465 patrol-name 466
465 patrol-type 467
470 name 469
470 type 477
472 name 471
473 first-area 487
473 name 476
473 next-area 487
473 status 475
473 type 474
479 name 478
480 name 481
482 name 484
482 operator 486
482 superstate 0
482 top-state 0
482 type 483
486 name 485
487 id 488
487 next 487
487 next 489
490 copy-destination 500
490 copy-destination 503
490 copy-source 404
490 copy-source 499
490 name 492
490 operator 494
490 operator 496
490 operator 498
490 superstate 368
490 top-state 0
490 type 491
494 name 493
496 name 495
498 name 497
500 id 501
500 next 502
500 next 504
505 achieved-area 515
505 name 507
505 operator 509
505 operator 512
505 operator 514
505 superstate 482
505 top-state 0
505 type 506
509 area 80
509 name 508
509 type 510
512 name 511
514 name 513
516 loc 517
535 next 537
535 next 538
535 word 536
538 next 540
538 next 535
538 word 539
541 id 542
541 status 550
546 color 548
546 id 547
546 status 549
552 name 551
554 name 553
556 attr 557
556 next 559
556 next 560
556 value 558
560 attr 561
560 next 563
560 next 564
560 value 562
564 attr 565
564 next 567
564 next 560
564 value 566
569 next 404
569 word 570
574 block 46
574 cond 560
574 cond 581
574 name 576
574 operator 578
574 operator 580
574 superstate 0
574 top-state 0
574 type 575
578 name 577
580 name 579
588 force 607
588 heuristic 591
588 unique 605
590 label 594
590 name 589
590 strength 597
590 wire 595
591 label 592
591 strength 596
591 wire 593
599 name 598
601 name 600
601 wire 602
604 name 603
610 name 609
613 area 616
613 features 615
613 id 614
613 name 612
613 processed 623
617 features 404
617 features 624
617 name 619
617 operator 621
617 operator 626
617 operator 628
617 superstate 368
617 target 46
617 top-state 0
617 type 618
621 name 620
621 status 622
626 name 625
628 name 627
