717
SOAR_ID 0
SOAR_ID 1
SOAR_ID 2
SOAR_ID 3
ENUMERATION 4 2 goto-area state
ENUMERATION 5 1 nil
ENUMERATION 6 3 accepted complete error
ENUMERATION 7 2 operator state
ENUMERATION 8 2 multiple none
ENUMERATION 9 2 no-change tie
ENUMERATION 10 5 deposit-object evaluate-operator go-to-area goto-storage-area robot
SOAR_ID 11
ENUMERATION 12 1 wait
SOAR_ID 13
SOAR_ID 14
SOAR_ID 15
SOAR_ID 16
INTEGER_RANGE 17 0 2147483647
INTEGER_RANGE 18 0 2147483647
SOAR_ID 19
INTEGER_RANGE 20 0 2147483647
INTEGER_RANGE 21 0 2147483647
FLOAT_RANGE 22 -Infinity Infinity
FLOAT_RANGE 23 -Infinity Infinity
ENUMERATION 24 4 east north south west
SOAR_ID 25
FLOAT_RANGE 26 -Infinity Infinity
FLOAT_RANGE 27 -Infinity Infinity
INTEGER_RANGE 28 0 2147483647
FLOAT_RANGE 29 -Infinity Infinity
FLOAT_RANGE 30 -Infinity Infinity
SOAR_ID 31
FLOAT_RANGE 32 -180.0 180.0
ENUMERATION 33 4 accepted complete error interrupted
INTEGER_RANGE 34 -2147483648 2147483647
ENUMERATION 35 4 east north south west
SOAR_ID 36
INTEGER_RANGE 37 -2147483648 2147483647
INTEGER_RANGE 38 -2147483648 2147483647
ENUMERATION 39 6 ball block brick ied player robot
FLOAT_RANGE 40 -Infinity Infinity
ENUMERATION 41 2 no yes
FLOAT_RANGE 42 -Infinity Infinity
FLOAT_RANGE 43 -Infinity Infinity
SOAR_ID 44
SOAR_ID 45
INTEGER_RANGE 46 -2147483648 2147483647
INTEGER_RANGE 47 -2147483648 2147483647
ENUMERATION 48 2 complete error
ENUMERATION 49 2 complete error
SOAR_ID 50
ENUMERATION 51 1 grasp-ied
SOAR_ID 52
FLOAT_RANGE 53 -Infinity Infinity
SOAR_ID 54
ENUMERATION 55 1 stop
SOAR_ID 56
ENUMERATION 57 1 state
INTEGER_RANGE 58 -2147483648 2147483647
SOAR_ID 59
ENUMERATION 60 1 pickup-block
INTEGER_RANGE 61 -2147483648 2147483647
ENUMERATION 62 1 pickup-block
ENUMERATION 63 1 spin
SOAR_ID 64
SOAR_ID 65
ENUMERATION 66 1 find-block-in-area
SOAR_ID 67
ENUMERATION 68 1 record-area
SOAR_ID 69
ENUMERATION 70 1 init-robot
SOAR_ID 71
INTEGER_RANGE 72 -2147483648 2147483647
SOAR_ID 73
ENUMERATION 74 1 state
ENUMERATION 75 1 find-block-in-area
ENUMERATION 76 1 record-area-direction
SOAR_ID 77
ENUMERATION 78 4 east north south west
ENUMERATION 79 4 east north south west
ENUMERATION 80 1 spin
SOAR_ID 81
ENUMERATION 82 1 note-turning
SOAR_ID 83
SOAR_ID 84
ENUMERATION 85 1 stop-spin
SOAR_ID 86
ENUMERATION 87 2 no yes
SOAR_ID 88
SOAR_ID 89
ENUMERATION 90 1 goto-unvisited-area
FLOAT_RANGE 91 -Infinity Infinity
ENUMERATION 92 2 no yes
SOAR_ID 93
ENUMERATION 94 1 get-object
SOAR_ID 95
ENUMERATION 96 1 state
ENUMERATION 97 1 get-object
ENUMERATION 98 1 goto-not-clean-area
SOAR_ID 99
SOAR_ID 100
ENUMERATION 101 1 deposit-object
SOAR_ID 102
ENUMERATION 103 1 finished-cleaning
INTEGER_RANGE 104 -2147483648 2147483647
SOAR_ID 105
ENUMERATION 106 1 state
ENUMERATION 107 1 deposit-object
ENUMERATION 108 1 goto-storage-area
SOAR_ID 109
ENUMERATION 110 1 move-to-room-center
SOAR_ID 111
ENUMERATION 112 2 go-to-area goto-area
ENUMERATION 113 1 go-to-area
ENUMERATION 114 4 east north south west
SOAR_ID 115
ENUMERATION 116 1 state
ENUMERATION 117 1 move-to-room-center
ENUMERATION 118 1 turn-to-wall
SOAR_ID 119
ENUMERATION 120 1 move-forward
SOAR_ID 121
ENUMERATION 122 2 false true
ENUMERATION 123 1 drop-block
SOAR_ID 124
INTEGER_RANGE 125 -2147483648 2147483647
SOAR_ID 126
ENUMERATION 127 1 clean-house
SOAR_ID 128
STRING 129
ENUMERATION 130 2 no yes
SOAR_ID 131
ENUMERATION 132 1 state
ENUMERATION 133 2 Impasse__Operator_Tie selection
ENUMERATION 134 1 evaluate-operator
SOAR_ID 135
SOAR_ID 136
ENUMERATION 137 1 state
ENUMERATION 138 1 evaluate-operator
ENUMERATION 139 1 go-to-next-area
SOAR_ID 140
ENUMERATION 141 1 turn-from-block
SOAR_ID 142
SOAR_ID 143
ENUMERATION 144 1 record-object
SOAR_ID 145
SOAR_ID 146
SOAR_ID 147
INTEGER_RANGE 148 -2147483648 2147483647
INTEGER_RANGE 149 -2147483648 2147483647
INTEGER_RANGE 150 -2147483648 2147483647
ENUMERATION 151 1 yes
ENUMERATION 152 1 detect-no-storage-area
SOAR_ID 153
ENUMERATION 154 1 t
ENUMERATION 155 1 t
ENUMERATION 156 1 tie
FLOAT_RANGE 157 -Infinity Infinity
ENUMERATION 158 2 no yes
SOAR_ID 159
ENUMERATION 160 1 chase
SOAR_ID 161
ENUMERATION 162 1 state
ENUMERATION 163 1 chase
ENUMERATION 164 1 move-to-player
SOAR_ID 165
SOAR_ID 166
ENUMERATION 167 1 record-unconnected-area
SOAR_ID 168
ENUMERATION 169 2 false true
SOAR_ID 170
INTEGER_RANGE 171 -2147483648 2147483647
INTEGER_RANGE 172 -2147483648 2147483647
STRING 173
SOAR_ID 174
INTEGER_RANGE 175 -2147483648 2147483647
SOAR_ID 176
FLOAT_RANGE 177 -Infinity Infinity
ENUMERATION 178 6 ball block brick ied player robot
STRING 179
INTEGER_RANGE 180 -2147483648 2147483647
SOAR_ID 181
FLOAT_RANGE 182 -180.0 180.0
FLOAT_RANGE 183 -0.5 0.5
SOAR_ID 184
SOAR_ID 185
STRING 186
FLOAT_RANGE 187 -Infinity Infinity
FLOAT_RANGE 188 -Infinity Infinity
SOAR_ID 189
SOAR_ID 190
SOAR_ID 191
STRING 192
SOAR_ID 193
ENUMERATION 194 1 nil
SOAR_ID 195
STRING 196
SOAR_ID 197
SOAR_ID 198
FLOAT_RANGE 199 -Infinity Infinity
FLOAT_RANGE 200 -Infinity Infinity
FLOAT_RANGE 201 -Infinity Infinity
FLOAT_RANGE 202 -Infinity Infinity
FLOAT_RANGE 203 -Infinity Infinity
FLOAT_RANGE 204 -Infinity Infinity
FLOAT_RANGE 205 -Infinity Infinity
FLOAT_RANGE 206 -Infinity Infinity
FLOAT_RANGE 207 -Infinity Infinity
FLOAT_RANGE 208 -Infinity Infinity
FLOAT_RANGE 209 -Infinity Infinity
FLOAT_RANGE 210 -Infinity Infinity
FLOAT_RANGE 211 -Infinity Infinity
FLOAT_RANGE 212 -Infinity Infinity
FLOAT_RANGE 213 -Infinity Infinity
ENUMERATION 214 1 go-to
SOAR_ID 215
SOAR_ID 216
ENUMERATION 217 1 state
ENUMERATION 218 1 go-to
ENUMERATION 219 1 set-waypoint
SOAR_ID 220
ENUMERATION 221 1 abandon-waypoint
SOAR_ID 222
ENUMERATION 223 1 initialize-progress
SOAR_ID 224
ENUMERATION 225 1 record-progress
SOAR_ID 226
ENUMERATION 227 1 turn-to-waypoint
SOAR_ID 228
ENUMERATION 229 1 move-forward
SOAR_ID 230
ENUMERATION 231 2 false true
FLOAT_RANGE 232 -Infinity Infinity
FLOAT_RANGE 233 -Infinity Infinity
SOAR_ID 234
INTEGER_RANGE 235 0 2147483647
FLOAT_RANGE 236 0.0 Infinity
FLOAT_RANGE 237 0.0 Infinity
FLOAT_RANGE 238 -Infinity Infinity
FLOAT_RANGE 239 -Infinity Infinity
FLOAT_RANGE 240 -Infinity Infinity
FLOAT_RANGE 241 -Infinity Infinity
FLOAT_RANGE 242 -Infinity Infinity
FLOAT_RANGE 243 -Infinity Infinity
FLOAT_RANGE 244 -Infinity Infinity
SOAR_ID 245
ENUMERATION 246 2 immediate true
ENUMERATION 247 2 false true
SOAR_ID 248
INTEGER_RANGE 249 -2147483648 2147483647
FLOAT_RANGE 250 0.0 Infinity
FLOAT_RANGE 251 0.0 Infinity
FLOAT_RANGE 252 -Infinity Infinity
ENUMERATION 253 2 smem wm
ENUMERATION 254 3 epmem smem wm
SOAR_ID 255
ENUMERATION 256 1 record-smem-current-area
FLOAT_RANGE 257 -Infinity Infinity
INTEGER_RANGE 258 -2147483648 2147483647
INTEGER_RANGE 259 -2147483648 2147483647
INTEGER_RANGE 260 -2147483648 2147483647
SOAR_ID 261
SOAR_ID 262
SOAR_ID 263
ENUMERATION 264 1 yes
ENUMERATION 265 1 yes
SOAR_ID 266
ENUMERATION 267 1 yes
FLOAT_RANGE 268 -Infinity Infinity
FLOAT_RANGE 269 -Infinity Infinity
ENUMERATION 270 2 no yes
ENUMERATION 271 1 go-to
SOAR_ID 272
FLOAT_RANGE 273 -Infinity Infinity
ENUMERATION 274 2 no yes
FLOAT_RANGE 275 -Infinity Infinity
ENUMERATION 276 1 yes
ENUMERATION 277 2 no yes
ENUMERATION 278 2 evaluate-operator go-to-area
SOAR_ID 279
ENUMERATION 280 4 go-to-next-area go-to-seen-block goto-not-clean-area goto-storage-area
SOAR_ID 281
ENUMERATION 282 2 door room
ENUMERATION 283 2 door room
ENUMERATION 284 1 yes
ENUMERATION 285 1 yes
SOAR_ID 286
ENUMERATION 287 1 turn-through-doorway
SOAR_ID 288
SOAR_ID 289
INTEGER_RANGE 290 -2147483648 2147483647
INTEGER_RANGE 291 -2147483648 2147483647
INTEGER_RANGE 292 -2147483648 2147483647
ENUMERATION 293 1 go-to-seen-block
SOAR_ID 294
ENUMERATION 295 4 east north south west
FLOAT_RANGE 296 -Infinity Infinity
SOAR_ID 297
FLOAT_RANGE 298 -Infinity Infinity
INTEGER_RANGE 299 -2147483648 2147483647
INTEGER_RANGE 300 -2147483648 2147483647
FLOAT_RANGE 301 -Infinity Infinity
FLOAT_RANGE 302 -Infinity Infinity
SOAR_ID 303
ENUMERATION 304 1 record-smem-new-gateway-area
ENUMERATION 305 2 no yes
SOAR_ID 306
ENUMERATION 307 1 retrieve-current-area-walls
SOAR_ID 308
ENUMERATION 309 1 retrieve-current-area-gateways
ENUMERATION 310 1 yes
ENUMERATION 311 1 retrieve-objects
SOAR_ID 312
ENUMERATION 313 2 failed success
ENUMERATION 314 1 object
ENUMERATION 315 2 no yes
ENUMERATION 316 1 object
ENUMERATION 317 2 no yes
SOAR_ID 318
ENUMERATION 319 1 record-storage-area
SOAR_ID 320
ENUMERATION 321 1 re-record-object
ENUMERATION 322 1 wall
ENUMERATION 323 1 gateway
SOAR_ID 324
ENUMERATION 325 1 retrieve-neighbor-area
SOAR_ID 326
SOAR_ID 327
ENUMERATION 328 1 go-to-area
SOAR_ID 329
ENUMERATION 330 1 go-to
ENUMERATION 331 2 no yes
INTEGER_RANGE 332 -2147483648 2147483647
SOAR_ID 333
ENUMERATION 334 1 store-area
ENUMERATION 335 1 goto-unvisited-area
SOAR_ID 336
ENUMERATION 337 1 yes
ENUMERATION 338 1 true
SOAR_ID 339
SOAR_ID 340
ENUMERATION 341 1 go-to
INTEGER_RANGE 342 -2147483648 2147483647
ENUMERATION 343 2 no yes
ENUMERATION 344 2 no yes
ENUMERATION 345 1 find-block-in-area
SOAR_ID 346
SOAR_ID 347
ENUMERATION 348 1 state
ENUMERATION 349 1 msg
ENUMERATION 350 1 msg-bad
SOAR_ID 351
ENUMERATION 352 1 all
SOAR_ID 353
ENUMERATION 354 1 instr-all
SOAR_ID 355
SOAR_ID 356
ENUMERATION 357 1 state
ENUMERATION 358 1 instr-all
ENUMERATION 359 1 all-do
SOAR_ID 360
ENUMERATION 361 1 instr-stop
SOAR_ID 362
ENUMERATION 363 1 instr-label
SOAR_ID 364
SOAR_ID 365
ENUMERATION 366 1 state
ENUMERATION 367 1 instr-label
ENUMERATION 368 1 label-do
SOAR_ID 369
ENUMERATION 370 1 label-done
SOAR_ID 371
ENUMERATION 372 1 label-prior
SOAR_ID 373
SOAR_ID 374
ENUMERATION 375 1 record-label
STRING 376
STRING 377
SOAR_ID 378
SOAR_ID 379
STRING 380
STRING 381
STRING 382
SOAR_ID 383
STRING 384
INTEGER_RANGE 385 -2147483648 2147483647
SOAR_ID 386
ENUMERATION 387 1 state
ENUMERATION 388 1 grasp-ied
ENUMERATION 389 1 grasp-confirm
SOAR_ID 390
ENUMERATION 391 1 grasp-diffuse
SOAR_ID 392
ENUMERATION 393 1 grasp-get
SOAR_ID 394
ENUMERATION 395 1 instr-confirmed
SOAR_ID 396
ENUMERATION 397 2 go-to go-to-unseen-block-in-room
SOAR_ID 398
ENUMERATION 399 1 instr-goto
SOAR_ID 400
SOAR_ID 401
ENUMERATION 402 1 state
ENUMERATION 403 1 instr-goto
ENUMERATION 404 1 goto-do
SOAR_ID 405
SOAR_ID 406
ENUMERATION 407 1 force-go
ENUMERATION 408 1 instr-allow
SOAR_ID 409
ENUMERATION 410 1 instr-avoid
SOAR_ID 411
SOAR_ID 412
ENUMERATION 413 1 record-avoid
ENUMERATION 414 1 instr-connected
SOAR_ID 415
SOAR_ID 416
ENUMERATION 417 1 state
ENUMERATION 418 1 instr-connected
ENUMERATION 419 1 connected-do
SOAR_ID 420
ENUMERATION 421 1 goto-done
SOAR_ID 422
ENUMERATION 423 1 connected-done
SOAR_ID 424
ENUMERATION 425 1 true
ENUMERATION 426 1 instr-patrol
SOAR_ID 427
ENUMERATION 428 13 all allow avoid circuit-patrol confirmed connected diffuse-wire goto heuristic initiate label linear-patrol terminate
SOAR_ID 429
ENUMERATION 430 1 msg
STRING 431
SOAR_ID 432
ENUMERATION 433 1 nil
SOAR_ID 434
SOAR_ID 435
SOAR_ID 436
ENUMERATION 437 1 true
ENUMERATION 438 1 nil
STRING 439
ENUMERATION 440 1 true
SOAR_ID 441
ENUMERATION 442 2 circuit-patrol linear-patrol
STRING 443
SOAR_ID 444
STRING 445
STRING 446
INTEGER_RANGE 447 -2147483648 2147483647
ENUMERATION 448 1 instr-initiate
SOAR_ID 449
ENUMERATION 450 1 instr-terminate
SOAR_ID 451
SOAR_ID 452
ENUMERATION 453 3 circuit-patrol get-object linear-patrol
ENUMERATION 454 6 executing initiated proposed suspended terminated urgent
STRING 455
ENUMERATION 456 1 patrol
ENUMERATION 457 1 instr-circuit-patrol
SOAR_ID 458
SOAR_ID 459
ENUMERATION 460 1 select-mission
SOAR_ID 461
INTEGER_RANGE 462 -2147483648 2147483647
ENUMERATION 463 1 nil
SOAR_ID 464
ENUMERATION 465 1 state
ENUMERATION 466 1 instr-patrol
ENUMERATION 467 1 init-list-copy
SOAR_ID 468
ENUMERATION 469 1 terminate-list-copy
SOAR_ID 470
ENUMERATION 471 1 copy-list-element
SOAR_ID 472
ENUMERATION 473 1 nil
SOAR_ID 474
INTEGER_RANGE 475 -2147483648 2147483647
SOAR_ID 476
ENUMERATION 477 1 nil
ENUMERATION 478 1 nil
SOAR_ID 479
ENUMERATION 480 1 state
ENUMERATION 481 1 patrol
ENUMERATION 482 1 goto-next-area
SOAR_ID 483
ENUMERATION 484 1 go-to-area
ENUMERATION 485 1 next-area
SOAR_ID 486
ENUMERATION 487 1 restart-patrol-first-area
SOAR_ID 488
ENUMERATION 489 1 true
INTEGER_RANGE 490 -2147483648 2147483647
FLOAT_RANGE 491 -Infinity Infinity
INTEGER_RANGE 492 -2147483648 2147483647
INTEGER_RANGE 493 -2147483648 2147483647
INTEGER_RANGE 494 -2147483648 2147483647
FLOAT_RANGE 495 -Infinity Infinity
INTEGER_RANGE 496 -2147483648 2147483647
INTEGER_RANGE 497 -2147483648 2147483647
FLOAT_RANGE 498 -Infinity Infinity
INTEGER_RANGE 499 -2147483648 2147483647
SOAR_ID 500
ENUMERATION 501 2 float int
ENUMERATION 502 2 degrees radians
SOAR_ID 503
FLOAT_RANGE 504 -Infinity Infinity
FLOAT_RANGE 505 -Infinity Infinity
FLOAT_RANGE 506 -Infinity Infinity
FLOAT_RANGE 507 -Infinity Infinity
ENUMERATION 508 2 feet meters
SOAR_ID 509
SOAR_ID 510
SOAR_ID 511
SOAR_ID 512
FLOAT_RANGE 513 -Infinity Infinity
FLOAT_RANGE 514 -Infinity Infinity
FLOAT_RANGE 515 -Infinity Infinity
FLOAT_RANGE 516 -Infinity Infinity
SOAR_ID 517
FLOAT_RANGE 518 -Infinity Infinity
FLOAT_RANGE 519 -Infinity Infinity
FLOAT_RANGE 520 -Infinity Infinity
ENUMERATION 521 3 feet_per_sec meters_per_sec miles_per_hour
SOAR_ID 522
SOAR_ID 523
FLOAT_RANGE 524 0.0 Infinity
INTEGER_RANGE 525 -2 2
INTEGER_RANGE 526 -2147483648 2147483647
SOAR_ID 527
INTEGER_RANGE 528 -2147483648 2147483647
INTEGER_RANGE 529 -2147483648 2147483647
FLOAT_RANGE 530 -Infinity Infinity
INTEGER_RANGE 531 -2147483648 2147483647
SOAR_ID 532
SOAR_ID 533
SOAR_ID 534
SOAR_ID 535
STRING 536
INTEGER_RANGE 537 -2147483648 2147483647
ENUMERATION 538 1 nil
STRING 539
INTEGER_RANGE 540 -2147483648 2147483647
FLOAT_RANGE 541 0.0 Infinity
FLOAT_RANGE 542 -Infinity Infinity
INTEGER_RANGE 543 -2147483648 2147483647
INTEGER_RANGE 544 -2147483648 2147483647
INTEGER_RANGE 545 -2147483648 2147483647
FLOAT_RANGE 546 -Infinity Infinity
STRING 547
INTEGER_RANGE 548 -2147483648 2147483647
ENUMERATION 549 2 float int
ENUMERATION 550 2 degrees radians
ENUMERATION 551 2 feet meters
SOAR_ID 552
ENUMERATION 553 3 feet_per_sec meters_per_sec miles_per_hour
FLOAT_RANGE 554 -Infinity Infinity
FLOAT_RANGE 555 -Infinity Infinity
FLOAT_RANGE 556 -Infinity Infinity
INTEGER_RANGE 557 -2147483648 2147483647
INTEGER_RANGE 558 -2147483648 2147483647
STRING 559
SOAR_ID 560
INTEGER_RANGE 561 -2147483648 2147483647
INTEGER_RANGE 562 -2147483648 2147483647
INTEGER_RANGE 563 -2147483648 2147483647
ENUMERATION 564 1 true
INTEGER_RANGE 565 -2147483648 2147483647
SOAR_ID 566
ENUMERATION 567 2 false true
FLOAT_RANGE 568 -Infinity Infinity
ENUMERATION 569 2 false true
SOAR_ID 570
ENUMERATION 571 5 -1 -2 0 1 2
ENUMERATION 572 2 false true
SOAR_ID 573
ENUMERATION 574 1 turn-around-object
ENUMERATION 575 2 no yes
SOAR_ID 576
FLOAT_RANGE 577 -Infinity Infinity
FLOAT_RANGE 578 -Infinity Infinity
FLOAT_RANGE 579 -Infinity Infinity
FLOAT_RANGE 580 -Infinity Infinity
INTEGER_RANGE 581 -2147483648 2147483647
INTEGER_RANGE 582 -2147483648 2147483647
INTEGER_RANGE 583 -2147483648 2147483647
INTEGER_RANGE 584 -2147483648 2147483647
ENUMERATION 585 1 grasp-help
SOAR_ID 586
ENUMERATION 587 1 grasp-plan
SOAR_ID 588
ENUMERATION 589 1 grasp-warn
SOAR_ID 590
ENUMERATION 591 1 instr-diffuse-wire
SOAR_ID 592
ENUMERATION 593 1 instr-heuristic
SOAR_ID 594
ENUMERATION 595 1 label-done
SOAR_ID 596
ENUMERATION 597 1 label-first
SOAR_ID 598
ENUMERATION 599 1 label-next
SOAR_ID 600
SOAR_ID 601
ENUMERATION 602 1 state
ENUMERATION 603 1 record-label
ENUMERATION 604 1 record-label-first
SOAR_ID 605
ENUMERATION 606 1 record-label-next
SOAR_ID 607
INTEGER_RANGE 608 -2147483648 2147483647
FLOAT_RANGE 609 -Infinity Infinity
STRING 610
ENUMERATION 611 2 block sphere
STRING 612
STRING 613
STRING 614
INTEGER_RANGE 615 -2147483648 2147483647
ENUMERATION 616 2 match tried
SOAR_ID 617
SOAR_ID 618
SOAR_ID 619
SOAR_ID 620
SOAR_ID 621
INTEGER_RANGE 622 -2147483648 2147483647
FLOAT_RANGE 623 -Infinity Infinity
FLOAT_RANGE 624 -Infinity Infinity
SOAR_ID 625
SOAR_ID 626
INTEGER_RANGE 627 -2147483648 2147483647
INTEGER_RANGE 628 -2147483648 2147483647
STRING 629
INTEGER_RANGE 630 -2147483648 2147483647
ENUMERATION 631 1 grasp-block
SOAR_ID 632
SOAR_ID 633
SOAR_ID 634
ENUMERATION 635 1 patrol
FLOAT_RANGE 636 -Infinity Infinity
ENUMERATION 637 2 no yes
ENUMERATION 638 2 received waiting
STRING 639
STRING 640
INTEGER_RANGE 641 -2147483648 2147483647
INTEGER_RANGE 642 -2147483648 2147483647
SOAR_ID 643
SOAR_ID 644
SOAR_ID 645
STRING 646
STRING 647
ENUMERATION 648 1 nil
ENUMERATION 649 1 yes
ENUMERATION 650 1 yes
SOAR_ID 651
ENUMERATION 652 1 area-search
ENUMERATION 653 1 yes
STRING 654
STRING 655
SOAR_ID 656
ENUMERATION 657 1 go-to-next-area
INTEGER_RANGE 658 -2147483648 2147483647
INTEGER_RANGE 659 -2147483648 2147483647
ENUMERATION 660 1 nil
ENUMERATION 661 1 nil
SOAR_ID 662
ENUMERATION 663 1 random-walk
SOAR_ID 664
ENUMERATION 665 1 state
ENUMERATION 666 2 patrol random-walk
ENUMERATION 667 1 go-to
SOAR_ID 668
ENUMERATION 669 2 false true
SOAR_ID 670
ENUMERATION 671 2 block ied
ENUMERATION 672 3 blue green red
ENUMERATION 673 2 no yes
SOAR_ID 674
SOAR_ID 675
STRING 676
STRING 677
ENUMERATION 678 2 false true
SOAR_ID 679
INTEGER_RANGE 680 -2147483648 2147483647
STRING 681
SOAR_ID 682
INTEGER_RANGE 683 -2147483648 2147483647
STRING 684
ENUMERATION 685 1 true
ENUMERATION 686 2 false true
SOAR_ID 687
ENUMERATION 688 1 remove-object
SOAR_ID 689
SOAR_ID 690
ENUMERATION 691 1 halt
FLOAT_RANGE 692 -Infinity Infinity
ENUMERATION 693 1 retrieve-next-area
SOAR_ID 694
SOAR_ID 695
ENUMERATION 696 1 update-object-data
FLOAT_RANGE 697 -Infinity Infinity
ENUMERATION 698 1 go-to
SOAR_ID 699
SOAR_ID 700
FLOAT_RANGE 701 -Infinity Infinity
FLOAT_RANGE 702 -Infinity Infinity
INTEGER_RANGE 703 -2147483648 2147483647
ENUMERATION 704 1 stop
SOAR_ID 705
SOAR_ID 706
FLOAT_RANGE 707 -Infinity Infinity
FLOAT_RANGE 708 -Infinity Infinity
FLOAT_RANGE 709 -Infinity Infinity
FLOAT_RANGE 710 -Infinity Infinity
ENUMERATION 711 1 yes
INTEGER_RANGE 712 -2147483648 2147483647
INTEGER_RANGE 713 -2147483648 2147483647
SOAR_ID 714
INTEGER_RANGE 715 -2147483648 2147483647
INTEGER_RANGE 716 -2147483648 2147483647
884
0 all-visited 338
0 areas 88
0 attribute 7
0 avoidance-turning 625
0 avoids 441
0 choices 8
0 current-location 71
0 current-mission 452
0 desired 128
0 destination-waypoint 245
0 diffusing 617
0 direction 79
0 directions 84
0 epmem 261
0 gateway-directions 286
0 gotos 560
0 impasse 9
0 io 1
0 labels 378
0 last-destination 713
0 missions 633
0 name 10
0 no-storage-area 151
0 numbers 146
0 objects 145
0 operator 11
0 operator 67
0 operator 69
0 operator 89
0 operator 93
0 operator 100
0 operator 102
0 operator 143
0 operator 159
0 operator 166
0 operator 215
0 operator 255
0 operator 279
0 operator 303
0 operator 306
0 operator 308
0 operator 318
0 operator 320
0 operator 324
0 operator 333
0 operator 374
0 operator 406
0 operator 412
0 operator 429
0 operator 459
0 operator 634
0 operator 662
0 operator 687
0 operator 690
0 operator 695
0 parameters 52
0 path-cost 296
0 patrol 444
0 pending 566
0 problem-space 126
0 quiescence 155
0 reading 432
0 reading 433
0 second-last-destination 712
0 smem 261
0 storage-area 71
0 superstate 5
0 superstate 0
0 tight-direction 79
0 top-state 0
0 type 4
1 input-link 2
1 output-link 3
2 area-description 14
2 configuration 500
2 lidar 522
2 objects 527
2 received-messages 532
2 self 13
2 time 170
2 waypoints 176
3 add-waypoint 185
3 clear-message 197
3 configure 198
3 diffuse-object-by-wire 682
3 disable-waypoint 190
3 drop-object 45
3 enable-waypoint 190
3 estop 184
3 get-object 44
3 remove-message 195
3 remove-waypoint 189
3 send-message 191
3 set-heading 31
3 set-heading-linear 266
3 set-velocity 181
3 stop 184
11 actions 3
11 name 12
13 area 34
13 carry 540
13 name 173
13 pose 174
13 stopped 277
14 gateway 25
14 id 180
14 type 283
14 wall 15
15 abs-relative-bearing 496
15 direction 24
15 left 16
15 relative-bearing 497
15 right 19
15 stored 265
15 type 322
15 x 22
15 y 23
15 yaw 499
15 z 498
16 col 17
16 row 18
19 col 21
19 row 20
25 abs-relative-bearing 490
25 connected 305
25 direction 35
25 distance 491
25 id 28
25 range 91
25 relative-bearing 492
25 stored 264
25 to 493
25 type 323
25 x 26
25 y 27
25 yaw 494
25 z 495
31 status 33
31 yaw 32
36 area 37
36 class 314
36 color 377
36 confirmation 638
36 height 697
36 id 38
36 in-storage-room 315
36 range 40
36 shape 613
36 smell 612
36 type 39
36 visible 41
36 weight 692
36 x 42
36 y 43
36 yaw 157
44 id 47
44 status 48
45 id 46
45 status 49
50 actions 3
50 id 630
50 name 51
52 areas-held-in 253
52 collision-range 568
52 communication 686
52 default-storage-area-id 608
52 default-storage-displacement 706
52 delete-old-areas 669
52 high-angular-velocity 201
52 high-linear-velocity 201
52 increased-angular-tolerance-multiplier 580
52 increased-angular-tolerance-range 579
52 look-ahead-planning 343
52 low-angular-velocity 199
52 low-linear-velocity 199
52 max-angular-distance 232
52 medium-angular-velocity 200
52 medium-linear-velocity 200
52 message-update-time 258
52 min-angular-distance 233
52 min-progress-distance 241
52 objects-held-in 254
52 pickup-range 53
52 progress-update-time 242
52 range-tolerance 259
52 rotation-tolerance 260
52 search-control-go-to-gateway 344
52 stopped-dead-zone-squared 636
52 waypoint-tolerance 257
54 actions 3
54 name 55
56 io 1
56 name 62
56 object 168
56 object-id 58
56 object-in-range-lined-up 270
56 object-lined-up 158
56 operator 50
56 operator 64
56 operator 272
56 operator 632
56 quiescence 155
56 stopped 276
56 superstate 95
56 top-state 0
56 type 57
59 id 61
59 name 60
64 name 63
65 name 66
67 area 71
67 name 68
69 name 70
71 avoid 425
71 class 316
71 cleaned 92
71 gateway 25
71 gateway-x 299
71 gateway-y 300
71 id 72
71 in-storage-room 317
71 neighbor-area 71
71 next 71
71 previous-area 71
71 search-start-direction 78
71 storage-area 310
71 store 337
71 turning 267
71 type 282
71 visited 87
71 wall 15
71 x 268
71 y 269
73 current-location 71
73 io 1
73 name 75
73 operator 77
73 operator 81
73 operator 83
73 operator 86
73 quiescence 155
73 superstate 95
73 top-state 0
73 type 74
77 name 76
81 actions 3
81 name 80
83 name 82
84 ene 207
84 ese 210
84 ne 202
84 nne 206
84 nnw 208
84 nw 203
84 opposite 295
84 se 204
84 sse 211
84 ssw 213
84 sw 205
84 value 295
84 wnw 209
84 wsw 212
86 name 85
88 area 71
89 area 71
89 name 90
89 type 112
93 name 94
93 pickup-block 650
95 area 71
95 current-location 71
95 epmem 261
95 io 1
95 name 97
95 object 36
95 operator 99
95 operator 59
95 operator 65
95 operator 294
95 operator 312
95 operator 336
95 operator 398
95 parameters 52
95 quiescence 155
95 retrieved-objects 313
95 smem 261
95 superstate 0
95 top-state 0
95 type 96
99 area 71
99 name 98
99 storage-area 637
99 type 113
100 name 101
102 name 103
105 area 71
105 current-location 71
105 io 1
105 name 107
105 operator 109
105 operator 111
105 operator 153
105 operator 346
105 quiescence 155
105 smem 261
105 superstate 0
105 top-state 0
105 type 106
109 area 71
109 name 108
109 type 113
111 name 110
111 wall-direction 114
115 collision 122
115 collision-distance 125
115 io 1
115 name 117
115 operator 119
115 operator 121
115 operator 124
115 operator 142
115 operator 699
115 operator 705
115 quiescence 154
115 superstate 105
115 top-state 0
115 type 116
119 name 118
121 name 120
124 actions 3
124 name 123
126 default-state-copy 130
126 name 127
126 one-level-attributes 129
128 location 71
128 storage-area-id 104
131 evaluation 297
131 impasse 156
131 name 133
131 operator 135
131 quiescence 155
131 superstate 0
131 top-state 0
131 type 132
135 name 134
136 current-location 71
136 desired 128
136 destination-area 71
136 failure 128
136 indifferent 128
136 name 138
136 operator 140
136 partial-failure 128
136 quiescence 155
136 success 128
136 superstate 131
136 top-state 0
136 type 137
136 visited-area 71
140 name 139
140 next-waypoint 25
142 name 141
143 name 144
143 object 36
145 object 36
146 number 147
147 one-less 150
147 one-more 149
147 value 148
153 name 152
159 name 160
159 player 168
161 io 1
161 name 163
161 operator 165
161 superstate 0
161 top-state 0
161 type 162
165 actions 3
165 name 164
166 name 167
168 abs-relative-bearing 528
168 color 376
168 diffuse-wire 679
168 diffused 678
168 distance 91
168 height 609
168 id 28
168 name 179
168 relative-bearing 529
168 shape 611
168 smell 610
168 type 178
168 visible 169
168 x 26
168 y 27
168 yaw 531
168 z 530
170 microseconds 172
170 seconds 171
174 magnitude 541
174 x 29
174 x-velocity 177
174 y 30
174 y-velocity 177
174 yaw 175
174 yaw-velocity 177
174 z 29
174 z-velocity 542
176 waypoint 248
181 angular-velocity 182
181 linear-velocity 183
181 message 629
181 status 6
184 message 629
184 status 33
185 id 186
185 id 548
185 status 33
185 x 187
185 y 188
189 id 186
189 id 558
189 status 33
190 id 186
190 id 557
190 status 33
191 destination 192
191 first 193
191 status 33
193 next 194
193 next 193
193 word 559
195 id 196
195 status 33
197 status 33
198 angle-resolution 549
198 angle-units 550
198 length-units 551
198 pose-translation 552
198 speed-units 553
198 status 33
215 cross-doorway 285
215 destination 25
215 name 214
215 range 275
216 angular-tolerances 576
216 clear 570
216 cross-doorway 284
216 destination 25
216 destination-in-range 274
216 front-clear 569
216 io 1
216 name 218
216 obstacle 567
216 operator 220
216 operator 222
216 operator 224
216 operator 226
216 operator 228
216 operator 230
216 operator 54
216 operator 288
216 operator 573
216 set-waypoint 247
216 superstate 0
216 top-state 0
216 type 217
216 waypoint-data 248
216 yaw-aligned 231
220 name 219
222 name 221
224 name 223
226 name 225
228 actions 3
228 name 227
230 actions 3
230 name 229
234 distance 239
234 id 235
234 x 236
234 y 237
234 yaw 238
245 give-up 246
245 last-distance 243
245 next-update-time 240
245 progress 244
245 waypoint 234
248 abs-relative-bearing 543
248 distance 252
248 id 249
248 id 547
248 relative-bearing 544
248 x 250
248 y 251
248 yaw 545
248 z 546
255 name 256
261 command 262
261 result 263
262 neg-query 71
262 neg-query 326
262 query 71
262 query 689
262 query 36
262 retrieve 71
262 store 71
263 failure 71
263 graph-match 709
263 retrieved 71
263 retrieved 326
263 success 71
266 linear-velocity 183
266 status 33
266 yaw 32
272 destination 168
272 name 271
272 pickup-block 649
272 range 273
279 current-location 71
279 desired 339
279 destination-area 71
279 name 278
279 operator 329
279 operator 656
279 operator 694
279 problem-space 651
279 smem 261
279 superstate 95
279 top-state 0
279 type 328
281 name 280
281 next-waypoint 71
281 operator 340
281 superstate 0
281 superstate 279
281 top-state 0
286 east 289
286 north 289
286 south 289
286 west 289
288 name 287
289 max 292
289 max-neg 581
289 max-pos 583
289 min 291
289 min-neg 582
289 min-pos 584
289 value 290
289 x-displace 623
289 y-displace 624
294 name 293
297 current-location 71
297 estimated-cost 302
297 path-cost 298
297 total-estimated-cost 301
303 gateway 25
303 name 304
306 name 307
306 wall 15
308 gateway 25
308 name 309
312 name 311
318 name 319
320 name 321
324 name 325
326 objects 327
327 object 71
329 cross-doorway 331
329 destination 25
329 gateway-area-id 332
329 name 330
333 name 334
336 name 335
339 location 71
340 destination 25
340 gateway-area-id 342
340 name 341
346 name 345
347 message 383
347 name 349
347 operator 351
347 operator 353
347 operator 355
347 operator 362
347 operator 364
347 operator 396
347 operator 400
347 operator 409
347 operator 411
347 operator 415
347 operator 427
347 operator 449
347 operator 451
347 operator 458
347 operator 592
347 operator 594
347 superstate 0
347 supported 428
347 top-state 0
347 type 348
351 name 350
353 name 352
355 done 440
355 label 439
355 name 354
356 name 358
356 operator 360
356 superstate 347
356 top-state 0
356 type 357
360 name 359
362 name 361
364 conds 644
364 label 643
364 name 363
365 input 660
365 input 674
365 name 367
365 operator 369
365 operator 371
365 operator 373
365 operator 596
365 operator 598
365 operator 600
365 output 383
365 prev 383
365 prev 661
365 superstate 347
365 top-state 0
365 type 366
369 name 368
371 name 370
373 name 372
374 block 36
374 label 379
374 name 375
374 status 616
378 label 379
378 unique 379
379 attr 380
379 first 379
379 label 382
379 name 614
379 next 379
379 tried 615
379 value 381
383 attr 676
383 first 383
383 from 431
383 id 385
383 next 383
383 next 438
383 value 677
383 word 384
386 clear 685
386 name 388
386 object 36
386 operator 390
386 operator 392
386 operator 394
386 operator 586
386 operator 588
386 operator 590
386 superstate 56
386 top-state 0
386 type 387
390 name 389
392 name 391
394 name 393
396 name 395
398 destination 621
398 name 397
398 range 622
400 area 71
400 id 641
400 name 399
401 area-id 658
401 name 403
401 operator 405
401 operator 422
401 priority 659
401 superstate 347
401 top-state 0
401 type 402
405 name 404
406 loc 562
406 name 407
406 priority 563
409 name 408
409 room 447
411 name 410
412 id 565
412 name 413
415 name 414
416 name 418
416 operator 420
416 operator 424
416 superstate 347
416 top-state 0
416 type 417
420 name 419
422 name 421
424 name 423
427 area-list 383
427 name 426
427 patrol-name 443
427 patrol-type 442
429 message 383
429 name 430
429 processed 437
432 first 434
432 next 436
432 word 435
441 avoid 564
444 first-area 474
444 patrol-name 445
444 patrol-type 446
449 name 448
449 type 456
451 name 450
452 first-area 461
452 name 455
452 next-area 461
452 object 670
452 status 454
452 type 453
458 name 457
459 mission 452
459 name 460
461 id 462
461 next 461
461 next 463
464 copy-destination 474
464 copy-destination 477
464 copy-source 383
464 copy-source 473
464 name 466
464 operator 468
464 operator 470
464 operator 472
464 superstate 347
464 top-state 0
464 type 465
468 name 467
470 name 469
472 name 471
474 id 475
474 next 476
474 next 478
479 achieved-area 489
479 name 481
479 operator 483
479 operator 486
479 operator 488
479 superstate 0
479 top-state 0
479 type 480
483 area 71
483 name 482
483 type 484
486 name 485
488 name 487
500 angle-resolution 501
500 angle-units 502
500 geometry 503
500 length-units 508
500 limits 509
500 pose-translation 517
500 speed-units 521
503 height 504
503 length 505
503 wheelbase 506
503 width 507
509 velocity 510
510 angular 511
510 linear 512
511 maximum 514
511 minimum 513
512 maximum 516
512 minimum 515
517 x 518
517 y 519
517 z 520
522 range 523
523 distance 524
523 id 525
523 relative-bearing 526
527 object 168
532 message 533
533 first 534
533 from 536
533 id 537
534 next 535
534 next 538
534 word 539
552 x 554
552 y 555
552 z 556
560 priority 561
570 clear 572
570 id 571
573 id 571
573 name 574
573 short-turn 575
576 max 577
576 min 578
586 name 585
588 name 587
588 wire 681
590 name 589
592 name 591
592 wire 639
594 name 593
594 strength 642
596 name 595
598 name 597
600 name 599
601 cond 645
601 cond 648
601 name 603
601 object 36
601 operator 605
601 operator 607
601 superstate 0
601 top-state 0
601 type 602
605 name 604
607 name 606
617 force 640
617 heuristic 619
617 unique 618
619 label 643
619 strength 680
619 wire 620
625 item 626
626 id 627
626 turn 628
632 name 631
633 mission 452
634 name 635
645 attr 646
645 next 645
645 value 647
651 default-state-copy 653
651 name 652
651 one-level-attributes 654
651 two-level-attributes 655
656 name 657
656 next-waypoint 71
662 name 663
664 name 666
664 operator 668
664 superstate 0
664 top-state 0
664 type 665
668 cross-doorway 673
668 destination 714
668 name 667
670 color 672
670 type 671
674 next 674
674 word 675
682 color 684
682 id 683
687 name 688
687 object 36
689 objects 145
690 name 691
694 area 71
694 name 693
695 name 696
699 destination 700
699 name 698
699 pickup-block 711
699 range 710
700 id 703
700 x 701
700 y 702
705 name 704
706 x 707
706 y 708
714 id 715
714 to 716
