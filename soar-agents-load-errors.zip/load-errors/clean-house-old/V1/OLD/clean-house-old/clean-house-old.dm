292
SOAR_ID 0
SOAR_ID 1
SOAR_ID 2
SOAR_ID 3
ENUMERATION 4 2 goto-area state
ENUMERATION 5 1 nil
SOAR_ID 6
ENUMERATION 7 2 complete error
SOAR_ID 8
ENUMERATION 9 3 backward forward stop
ENUMERATION 10 2 complete error
ENUMERATION 11 3 left right stop
SOAR_ID 12
STRING 13
ENUMERATION 14 2 operator state
ENUMERATION 15 2 multiple none
ENUMERATION 16 2 no-change tie
ENUMERATION 17 1 robot
SOAR_ID 18
ENUMERATION 19 1 wait
SOAR_ID 20
SOAR_ID 21
FLOAT_RANGE 22 -Infinity Infinity
SOAR_ID 23
SOAR_ID 24
INTEGER_RANGE 25 0 2147483647
SOAR_ID 26
INTEGER_RANGE 27 0 2147483647
INTEGER_RANGE 28 0 2147483647
SOAR_ID 29
INTEGER_RANGE 30 0 2147483647
INTEGER_RANGE 31 0 2147483647
SOAR_ID 32
FLOAT_RANGE 33 0.0 Infinity
FLOAT_RANGE 34 0.0 Infinity
FLOAT_RANGE 35 -Infinity Infinity
ENUMERATION 36 4 east north south west
SOAR_ID 37
SOAR_ID 38
FLOAT_RANGE 39 0.0 Infinity
FLOAT_RANGE 40 0.0 Infinity
INTEGER_RANGE 41 0 2147483647
SOAR_ID 42
INTEGER_RANGE 43 0 2147483647
INTEGER_RANGE 44 0 2147483647
SOAR_ID 45
INTEGER_RANGE 46 0 2147483647
INTEGER_RANGE 47 0 2147483647
INTEGER_RANGE 48 0 2147483647
SOAR_ID 49
ENUMERATION 50 2 false true
ENUMERATION 51 2 false true
INTEGER_RANGE 52 0 2147483647
INTEGER_RANGE 53 -2147483648 2147483647
SOAR_ID 54
FLOAT_RANGE 55 0.0 Infinity
FLOAT_RANGE 56 0.0 Infinity
INTEGER_RANGE 57 0 2147483647
INTEGER_RANGE 58 0 2147483647
FLOAT_RANGE 59 0.0 1.0
FLOAT_RANGE 60 0.0 Infinity
SOAR_ID 61
FLOAT_RANGE 62 0.0 Infinity
FLOAT_RANGE 63 -Infinity Infinity
FLOAT_RANGE 64 -Infinity Infinity
SOAR_ID 65
SOAR_ID 66
FLOAT_RANGE 67 -Infinity Infinity
FLOAT_RANGE 68 -Infinity Infinity
ENUMERATION 69 2 complete error
ENUMERATION 70 2 complete error
ENUMERATION 71 2 complete error
INTEGER_RANGE 72 -2147483648 2147483647
ENUMERATION 73 4 east north south west
SOAR_ID 74
INTEGER_RANGE 75 -2147483648 2147483647
ENUMERATION 76 1 block
SOAR_ID 77
INTEGER_RANGE 78 -2147483648 2147483647
INTEGER_RANGE 79 -2147483648 2147483647
ENUMERATION 80 1 block
SOAR_ID 81
FLOAT_RANGE 82 -Infinity Infinity
ENUMERATION 83 2 no yes
FLOAT_RANGE 84 -Infinity Infinity
FLOAT_RANGE 85 -Infinity Infinity
INTEGER_RANGE 86 -2147483648 2147483647
INTEGER_RANGE 87 -2147483648 2147483647
SOAR_ID 88
SOAR_ID 89
INTEGER_RANGE 90 -2147483648 2147483647
INTEGER_RANGE 91 -2147483648 2147483647
ENUMERATION 92 2 complete error
ENUMERATION 93 2 complete error
SOAR_ID 94
ENUMERATION 95 1 grasp-block
SOAR_ID 96
ENUMERATION 97 1 move-forward
SOAR_ID 98
FLOAT_RANGE 99 -Infinity Infinity
FLOAT_RANGE 100 -Infinity Infinity
FLOAT_RANGE 101 -Infinity Infinity
SOAR_ID 102
ENUMERATION 103 1 stop
SOAR_ID 104
ENUMERATION 105 1 turn
SOAR_ID 106
ENUMERATION 107 1 state
INTEGER_RANGE 108 -2147483648 2147483647
ENUMERATION 109 1 none
INTEGER_RANGE 110 -2147483648 2147483647
SOAR_ID 111
ENUMERATION 112 1 pickup-block
INTEGER_RANGE 113 -2147483648 2147483647
ENUMERATION 114 1 pickup-block
ENUMERATION 115 1 spin
SOAR_ID 116
SOAR_ID 117
ENUMERATION 118 1 find-block-in-area
SOAR_ID 119
ENUMERATION 120 1 record-area
SOAR_ID 121
ENUMERATION 122 1 init-robot
SOAR_ID 123
INTEGER_RANGE 124 -2147483648 2147483647
SOAR_ID 125
ENUMERATION 126 1 state
ENUMERATION 127 1 find-block-in-area
ENUMERATION 128 1 record-area-direction
SOAR_ID 129
ENUMERATION 130 4 east north south west
ENUMERATION 131 4 east north south west
ENUMERATION 132 1 spin
SOAR_ID 133
ENUMERATION 134 1 note-turning
SOAR_ID 135
ENUMERATION 136 1 yes
SOAR_ID 137
ENUMERATION 138 1 stop-spin
SOAR_ID 139
ENUMERATION 140 1 yes
SOAR_ID 141
SOAR_ID 142
ENUMERATION 143 1 goto-unvisited-area
SOAR_ID 144
ENUMERATION 145 2 goto-area state
ENUMERATION 146 1 goto-unvisited-area
ENUMERATION 147 1 goto-gateway
SOAR_ID 148
SOAR_ID 149
FLOAT_RANGE 150 -Infinity Infinity
SOAR_ID 151
ENUMERATION 152 1 state
ENUMERATION 153 1 goto-gateway
ENUMERATION 154 1 move-around-wall
SOAR_ID 155
ENUMERATION 156 2 x y
ENUMERATION 157 2 false true
ENUMERATION 158 2 neg pos
SOAR_ID 159
INTEGER_RANGE 160 -2147483648 2147483647
INTEGER_RANGE 161 -2147483648 2147483647
INTEGER_RANGE 162 -2147483648 2147483647
ENUMERATION 163 4 east north south west
SOAR_ID 164
ENUMERATION 165 1 state
ENUMERATION 166 1 move-around-wall
ENUMERATION 167 1 turn-absolute
SOAR_ID 168
FLOAT_RANGE 169 -Infinity Infinity
ENUMERATION 170 4 east north south west
ENUMERATION 171 1 move-directly-to-gateway
SOAR_ID 172
SOAR_ID 173
ENUMERATION 174 1 state
ENUMERATION 175 1 move-directly-to-gateway
ENUMERATION 176 1 turn-to-gateway
SOAR_ID 177
ENUMERATION 178 1 move-forward
SOAR_ID 179
ENUMERATION 180 2 no yes
FLOAT_RANGE 181 -Infinity Infinity
ENUMERATION 182 1 yes
SOAR_ID 183
ENUMERATION 184 1 move-forward
FLOAT_RANGE 185 -Infinity Infinity
SOAR_ID 186
ENUMERATION 187 1 get-block
SOAR_ID 188
ENUMERATION 189 1 state
ENUMERATION 190 1 get-block
ENUMERATION 191 1 goto-not-clean-area
SOAR_ID 192
SOAR_ID 193
ENUMERATION 194 1 deposit-block
SOAR_ID 195
ENUMERATION 196 1 finished-cleaning
INTEGER_RANGE 197 -2147483648 2147483647
SOAR_ID 198
ENUMERATION 199 1 state
ENUMERATION 200 1 deposit-block
ENUMERATION 201 1 goto-storage-area
SOAR_ID 202
ENUMERATION 203 1 move-to-wall
SOAR_ID 204
ENUMERATION 205 1 goto-area
ENUMERATION 206 1 goto-area
ENUMERATION 207 4 east north south west
SOAR_ID 208
ENUMERATION 209 1 state
ENUMERATION 210 1 move-to-wall
ENUMERATION 211 1 turn-to-wall
SOAR_ID 212
ENUMERATION 213 1 move-forward
SOAR_ID 214
ENUMERATION 215 2 false true
ENUMERATION 216 1 drop-block
SOAR_ID 217
INTEGER_RANGE 218 -2147483648 2147483647
SOAR_ID 219
ENUMERATION 220 1 clean-house
SOAR_ID 221
STRING 222
ENUMERATION 223 2 no yes
ENUMERATION 224 1 yes
SOAR_ID 225
ENUMERATION 226 1 state
ENUMERATION 227 1 Impasse__Operator_Tie
ENUMERATION 228 1 evaluate-operator
SOAR_ID 229
SOAR_ID 230
ENUMERATION 231 1 state
ENUMERATION 232 1 evaluate-operator
ENUMERATION 233 1 goto-gateway
SOAR_ID 234
ENUMERATION 235 1 turn-from-block
SOAR_ID 236
SOAR_ID 237
ENUMERATION 238 1 record-block
SOAR_ID 239
SOAR_ID 240
INTEGER_RANGE 241 -2147483648 2147483647
FLOAT_RANGE 242 -Infinity Infinity
ENUMERATION 243 1 yes
ENUMERATION 244 1 turn-around-object
SOAR_ID 245
INTEGER_RANGE 246 -2147483648 2147483647
SOAR_ID 247
SOAR_ID 248
INTEGER_RANGE 249 -2147483648 2147483647
INTEGER_RANGE 250 -2147483648 2147483647
INTEGER_RANGE 251 -2147483648 2147483647
SOAR_ID 252
SOAR_ID 253
ENUMERATION 254 4 east north south west
ENUMERATION 255 2 col row
ENUMERATION 256 2 col row
ENUMERATION 257 1 yes
ENUMERATION 258 4 east north south west
ENUMERATION 259 1 detect-no-storage-area
SOAR_ID 260
ENUMERATION 261 1 t
ENUMERATION 262 1 t
ENUMERATION 263 1 tie
SOAR_ID 264
FLOAT_RANGE 265 -Infinity Infinity
ENUMERATION 266 2 no yes
SOAR_ID 267
SOAR_ID 268
FLOAT_RANGE 269 -Infinity Infinity
SOAR_ID 270
FLOAT_RANGE 271 -Infinity Infinity
SOAR_ID 272
FLOAT_RANGE 273 -Infinity Infinity
SOAR_ID 274
STRING 275
SOAR_ID 276
STRING 277
STRING 278
INTEGER_RANGE 279 -2147483648 2147483647
SOAR_ID 280
STRING 281
INTEGER_RANGE 282 -2147483648 2147483647
SOAR_ID 283
ENUMERATION 284 1 chase
SOAR_ID 285
ENUMERATION 286 1 state
ENUMERATION 287 1 chase
ENUMERATION 288 1 move-to-player
SOAR_ID 289
SOAR_ID 290
ENUMERATION 291 1 record-unconnected-area
374
0 areas 141
0 attribute 14
0 blocks 239
0 choices 15
0 closest-block-id 108
0 closest-block-id 109
0 current-area 123
0 desired 221
0 direction 131
0 directions 137
0 impasse 16
0 io 1
0 name 17
0 no-storage-area 257
0 numbers 247
0 operator 18
0 operator 119
0 operator 121
0 operator 142
0 operator 186
0 operator 193
0 operator 195
0 operator 237
0 operator 283
0 operator 290
0 parameters 98
0 problem-space 219
0 quiescence 262
0 superstate 5
0 superstate 0
0 tight-direction 131
0 top-state 0
0 type 4
0 wall-obstacle 252
1 input-link 2
1 output-link 3
2 area-description 23
2 object 77
2 player 274
2 self 20
3 communicate 280
3 drop 89
3 get 88
3 move 6
3 rotate 8
3 rotate-absolute 65
3 rotate-relative 66
3 stop-sim 12
6 direction 9
6 status 7
8 direction 11
8 status 10
12 status 71
12 true 13
18 actions 3
18 name 19
20 angle 21
20 area 72
20 carry 74
20 collision 49
20 cycle 52
20 position 54
20 random 59
20 score 53
20 time 60
20 velocity 61
21 yaw 22
23 gateway 37
23 wall 24
24 center 32
24 direction 36
24 id 25
24 left 26
24 right 29
26 col 27
26 row 28
29 col 31
29 row 30
32 angle-off 267
32 angle-off 268
32 angle-off 270
32 x 33
32 y 34
37 center 38
37 direction 73
37 id 41
37 left 42
37 right 45
37 to 48
38 angle-off 272
38 range 181
38 x 39
38 y 40
42 col 43
42 row 44
45 col 46
45 row 47
49 x 51
49 y 50
54 col 58
54 row 57
54 x 55
54 y 56
61 dx 63
61 dy 64
61 rotation 185
61 speed 62
65 status 69
65 yaw 67
66 status 70
66 yaw 68
74 id 75
74 type 76
77 angle-off 264
77 area 78
77 id 79
77 position 81
77 range 82
77 type 80
77 visible 83
81 col 87
81 row 86
81 x 84
81 y 85
88 id 91
88 status 92
89 id 90
89 status 93
94 actions 3
94 name 95
96 actions 3
96 name 97
98 pickup-angle-off-neg 99
98 pickup-angle-off-pos 101
98 pickup-range 100
102 actions 3
102 name 103
104 actions 3
104 name 105
106 block-id 110
106 io 1
106 name 114
106 object-lined-up 266
106 operator 104
106 operator 94
106 operator 96
106 operator 102
106 operator 116
106 quiescence 262
106 superstate 188
106 top-state 0
106 type 107
111 id 113
111 name 112
116 name 115
117 name 118
119 area 123
119 name 120
121 name 122
123 cleaned 182
123 gateway 37
123 gateway-area 224
123 id 124
123 search-start-direction 130
123 turning 136
123 visited 140
123 wall 24
125 current-area 123
125 io 1
125 name 127
125 operator 129
125 operator 133
125 operator 135
125 operator 139
125 quiescence 262
125 superstate 188
125 top-state 0
125 type 126
129 name 128
133 actions 3
133 name 132
135 name 134
137 heading 169
137 move-in-rectangle 156
137 move-in-rectangle-delta 158
137 move-in-rectangle-num 162
137 opposite 131
137 value 131
139 name 138
141 area 123
142 area 123
142 name 143
142 type 205
144 connected-gateway 37
144 current-area 123
144 destination-area 123
144 gateway-distance 149
144 io 1
144 name 146
144 operator 148
144 quiescence 261
144 superstate 0
144 top-state 0
144 type 145
148 gateway 37
148 name 147
149 distance 150
149 gateway 37
151 current-gateway 37
151 io 1
151 move-direct-gateway 157
151 move-direction 163
151 name 153
151 new-destination 159
151 operator 155
151 operator 172
151 quiescence 261
151 superstate 144
151 top-state 0
151 type 152
155 direction 170
155 name 154
159 x 160
159 y 161
164 name 166
164 operator 168
164 operator 183
164 quiescence 261
164 superstate 151
164 top-state 0
164 type 165
168 actions 3
168 name 167
172 gateway 37
172 name 171
173 current-area 123
173 current-gateway 37
173 io 1
173 lined-up 180
173 name 175
173 object-gateway-diff 240
173 operator 177
173 operator 179
173 operator 245
173 quiescence 261
173 superstate 151
173 top-state 0
173 type 174
177 name 176
179 actions 3
179 name 178
183 actions 3
183 name 184
186 name 187
188 current-area 123
188 io 1
188 name 190
188 operator 192
188 operator 111
188 operator 117
188 quiescence 262
188 superstate 0
188 top-state 0
188 type 189
192 area 123
192 name 191
192 type 206
193 name 194
195 name 196
198 current-area 123
198 io 1
198 name 200
198 operator 202
198 operator 204
198 operator 260
198 quiescence 262
198 superstate 0
198 top-state 0
198 type 199
202 area 123
202 name 201
202 type 206
204 name 203
204 wall-direction 207
208 collision 215
208 collision-distance 218
208 io 1
208 name 210
208 operator 212
208 operator 214
208 operator 217
208 operator 236
208 quiescence 261
208 superstate 198
208 top-state 0
208 type 209
212 name 211
214 name 213
217 actions 3
217 name 216
219 default-state-copy 223
219 name 220
219 one-level-attributes 222
221 storage-area-id 197
225 impasse 263
225 name 227
225 operator 229
225 quiescence 262
225 superstate 0
225 top-state 0
225 type 226
229 name 228
230 current-area 123
230 desired 221
230 destination-area 123
230 failure 221
230 indifferent 221
230 name 232
230 operator 234
230 partial-failure 221
230 quiescence 262
230 success 221
230 superstate 225
230 top-state 0
230 type 231
230 visited-area 123
234 gateway 37
234 name 233
236 name 235
237 block 77
237 name 238
239 block 77
240 against-wall 258
240 difference 242
240 id 241
240 obstacle 243
245 name 244
245 object-id 246
247 number 248
248 one-less 251
248 one-more 250
248 value 249
252 info 253
253 against-wall 254
253 direction 254
253 equal-dimension 255
253 one-greater-than 256
253 one-less-than 256
260 name 259
264 yaw 265
267 yaw 35
268 yaw 269
270 yaw 271
272 yaw 273
274 angle-off 264
274 area 78
274 message 276
274 name 275
274 position 81
274 range 82
276 cycle 279
276 from 278
276 message 277
280 cycle 282
280 message 281
283 name 284
285 io 1
285 name 287
285 operator 289
285 superstate 0
285 top-state 0
285 type 286
289 name 288
290 name 291
