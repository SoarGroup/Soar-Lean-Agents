47
SOAR_ID 0
SOAR_ID 1
SOAR_ID 2
SOAR_ID 3
SOAR_ID 4
ENUMERATION 5 1 state
ENUMERATION 6 1 nil
ENUMERATION 7 1 cozmohack
ENUMERATION 8 1 initialize-cozmohack
SOAR_ID 9
ENUMERATION 10 1 execute-task
SOAR_ID 11
ENUMERATION 12 1 next-task
SOAR_ID 13
ENUMERATION 14 1 state
ENUMERATION 15 1 execute-task
ENUMERATION 16 1 execute-subtask
SOAR_ID 17
ENUMERATION 18 1 next-subtask
SOAR_ID 19
ENUMERATION 20 1 end-subtask
SOAR_ID 21
SOAR_ID 22
ENUMERATION 23 1 end-agent
SOAR_ID 24
ENUMERATION 25 1 record-led-cube
SOAR_ID 26
ENUMERATION 27 1 record-original-pose
SOAR_ID 28
ENUMERATION 29 1 color-cube
SOAR_ID 30
ENUMERATION 31 1 find-cube
SOAR_ID 32
ENUMERATION 33 1 pickup-cube
SOAR_ID 34
ENUMERATION 35 1 move-to
SOAR_ID 36
ENUMERATION 37 1 state
ENUMERATION 38 1 move-to
ENUMERATION 39 1 turn-to
SOAR_ID 40
ENUMERATION 41 1 turn-to-object
SOAR_ID 42
ENUMERATION 43 1 move-forward
SOAR_ID 44
SOAR_ID 45
ENUMERATION 46 1 put-down
49
0 io 1
0 name 7
0 operator 4
0 operator 9
0 operator 11
0 operator 22
0 operator 24
0 operator 26
0 operator 28
0 operator 30
0 operator 32
0 operator 34
0 operator 45
0 superstate 6
0 top-state 0
0 type 5
1 input-link 2
1 output-link 3
4 name 8
9 name 10
11 name 12
13 name 15
13 operator 17
13 operator 19
13 operator 21
13 superstate 0
13 top-state 0
13 type 14
17 name 16
19 name 18
21 name 20
22 name 23
24 name 25
26 name 27
28 name 29
30 name 31
32 name 33
34 name 35
36 name 38
36 operator 40
36 operator 42
36 operator 44
36 superstate 0
36 top-state 0
36 type 37
40 name 39
42 name 41
44 name 43
45 name 46
