61
SOAR_ID 0
SOAR_ID 1
SOAR_ID 2
SOAR_ID 3
ENUMERATION 4 1 state
ENUMERATION 5 1 nil
ENUMERATION 6 1 eater-default
SOAR_ID 7
ENUMERATION 8 1 complete
ENUMERATION 9 4 east north south west
SOAR_ID 10
ENUMERATION 11 5 bonusfood eater empty normalfood wall
SOAR_ID 12
ENUMERATION 13 4 east north south west
ENUMERATION 14 5 black blue purple red yellow
INTEGER_RANGE 15 -2147483648 2147483647
INTEGER_RANGE 16 -2147483648 2147483647
INTEGER_RANGE 17 -2147483648 2147483647
SOAR_ID 18
ENUMERATION 19 1 initialize-input-map
SOAR_ID 20
SOAR_ID 21
ENUMERATION 22 1 state
ENUMERATION 23 1 Initialize-input-map
ENUMERATION 24 1 complete-input-map
SOAR_ID 25
ENUMERATION 26 1 true
ENUMERATION 27 1 record-input-attribute
SOAR_ID 28
SOAR_ID 29
SOAR_ID 30
ENUMERATION 31 1 state
ENUMERATION 32 1 record-input-attribute
ENUMERATION 33 1 record-input-attribute
SOAR_ID 34
SOAR_ID 35
ENUMERATION 36 1 initialize-output-action-list
SOAR_ID 37
ENUMERATION 38 1 state
ENUMERATION 39 1 Impasse__State_No-Change
ENUMERATION 40 1 propose-action-operator
SOAR_ID 41
SOAR_ID 42
ENUMERATION 43 1 record-state-changes
SOAR_ID 44
ENUMERATION 45 1 task-operator
SOAR_ID 46
ENUMERATION 47 1 state
ENUMERATION 48 1 Impasse__Operator_Tie
ENUMERATION 49 1 insufficient-data-indifferent
SOAR_ID 50
SOAR_ID 51
ENUMERATION 52 1 analyze-state-changes
SOAR_ID 53
ENUMERATION 54 1 generate-RL-rules
ENUMERATION 55 1 generate-RL-rules
SOAR_ID 56
ENUMERATION 57 1 attend
SOAR_ID 58
ENUMERATION 59 1 generate-RL-rule
SOAR_ID 60
70
0 input-link 29
0 input-map 20
0 io 1
0 name 6
0 operator 18
0 operator 35
0 operator 42
0 operator 44
0 operator 51
0 operator 53
0 superstate 5
0 top-state 0
0 type 4
1 input-link 2
1 output-link 3
2 eater 12
2 my-location 10
3 jump 7
3 move 7
7 direction 9
7 status 8
10 content 11
10 east 10
10 north 10
10 south 10
10 west 10
12 direction 13
12 name 14
12 score 15
12 x 16
12 y 17
18 name 19
20 complete 26
21 name 23
21 operator 25
21 operator 28
21 superstate 0
21 top-state 0
21 type 22
25 name 24
28 name 27
30 name 32
30 operator 34
30 superstate 21
30 top-state 0
30 type 31
34 name 33
35 name 36
37 name 39
37 operator 41
37 superstate 0
37 top-state 0
37 type 38
41 name 40
42 name 43
44 name 45
46 name 48
46 operator 50
46 operator 56
46 operator 58
46 operator 60
46 superstate 0
46 top-state 0
46 type 47
50 name 49
51 name 52
53 name 54
56 name 55
58 name 57
60 name 59
