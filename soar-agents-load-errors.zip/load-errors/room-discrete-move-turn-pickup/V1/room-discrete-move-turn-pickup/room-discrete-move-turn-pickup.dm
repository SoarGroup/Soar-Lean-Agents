118
SOAR_ID 0
SOAR_ID 1
SOAR_ID 2
SOAR_ID 3
ENUMERATION 4 1 state
ENUMERATION 5 1 nil
SOAR_ID 6
ENUMERATION 7 2 complete error
SOAR_ID 8
ENUMERATION 9 3 backward forward stop
ENUMERATION 10 2 complete error
ENUMERATION 11 3 left right stop
SOAR_ID 12
STRING 13
ENUMERATION 14 2 operator state
ENUMERATION 15 2 multiple none
ENUMERATION 16 2 no-change tie
ENUMERATION 17 1 robot
SOAR_ID 18
ENUMERATION 19 1 wait
ENUMERATION 20 1 elaboration
SOAR_ID 21
SOAR_ID 22
FLOAT_RANGE 23 -Infinity Infinity
SOAR_ID 24
ENUMERATION 25 2 false true
ENUMERATION 26 2 false true
INTEGER_RANGE 27 0 2147483647
INTEGER_RANGE 28 -2147483648 2147483647
SOAR_ID 29
FLOAT_RANGE 30 0.0 Infinity
FLOAT_RANGE 31 0.0 Infinity
INTEGER_RANGE 32 0 2147483647
INTEGER_RANGE 33 0 2147483647
FLOAT_RANGE 34 0.0 1.0
FLOAT_RANGE 35 0.0 Infinity
SOAR_ID 36
FLOAT_RANGE 37 0.0 Infinity
FLOAT_RANGE 38 -Infinity Infinity
FLOAT_RANGE 39 -Infinity Infinity
SOAR_ID 40
SOAR_ID 41
FLOAT_RANGE 42 -Infinity Infinity
FLOAT_RANGE 43 -Infinity Infinity
ENUMERATION 44 2 complete error
ENUMERATION 45 2 complete error
ENUMERATION 46 2 complete error
INTEGER_RANGE 47 -2147483648 2147483647
SOAR_ID 48
INTEGER_RANGE 49 -2147483648 2147483647
ENUMERATION 50 1 block
SOAR_ID 51
INTEGER_RANGE 52 -2147483648 2147483647
INTEGER_RANGE 53 -2147483648 2147483647
ENUMERATION 54 1 block
SOAR_ID 55
FLOAT_RANGE 56 -Infinity Infinity
ENUMERATION 57 2 no yes
FLOAT_RANGE 58 -Infinity Infinity
FLOAT_RANGE 59 -Infinity Infinity
INTEGER_RANGE 60 -2147483648 2147483647
INTEGER_RANGE 61 -2147483648 2147483647
SOAR_ID 62
SOAR_ID 63
INTEGER_RANGE 64 -2147483648 2147483647
INTEGER_RANGE 65 -2147483648 2147483647
ENUMERATION 66 2 complete error
ENUMERATION 67 2 complete error
SOAR_ID 68
ENUMERATION 69 1 pickup-block
SOAR_ID 70
ENUMERATION 71 1 move-forward
SOAR_ID 72
FLOAT_RANGE 73 -Infinity Infinity
FLOAT_RANGE 74 -Infinity Infinity
FLOAT_RANGE 75 -Infinity Infinity
SOAR_ID 76
ENUMERATION 77 1 turn
SOAR_ID 78
ENUMERATION 79 1 spin
SOAR_ID 80
FLOAT_RANGE 81 -Infinity Infinity
SOAR_ID 82
SOAR_ID 83
SOAR_ID 84
SOAR_ID 85
ENUMERATION 86 4 east north south west
INTEGER_RANGE 87 0 2147483647
SOAR_ID 88
SOAR_ID 89
INTEGER_RANGE 90 0 2147483647
FLOAT_RANGE 91 -Infinity Infinity
INTEGER_RANGE 92 0 2147483647
INTEGER_RANGE 93 0 2147483647
INTEGER_RANGE 94 0 2147483647
INTEGER_RANGE 95 0 2147483647
ENUMERATION 96 2 false true
SOAR_ID 97
SOAR_ID 98
INTEGER_RANGE 99 -2147483648 2147483647
STRING 100
FLOAT_RANGE 101 -Infinity Infinity
ENUMERATION 102 4 east north south west
SOAR_ID 103
ENUMERATION 104 2 false true
SOAR_ID 105
ENUMERATION 106 1 record-object
SOAR_ID 107
SOAR_ID 108
ENUMERATION 109 1 remove-recorded-object
SOAR_ID 110
SOAR_ID 111
FLOAT_RANGE 112 -Infinity Infinity
ENUMERATION 113 3 front left right
SOAR_ID 114
ENUMERATION 115 1 move-forward-to-wall
SOAR_ID 116
ENUMERATION 117 1 drop-block
136
0 attribute 14
0 choices 15
0 impasse 16
0 io 1
0 name 17
0 object-direction 113
0 operator 18
0 operator 68
0 operator 70
0 operator 76
0 operator 78
0 operator 105
0 operator 108
0 operator 114
0 operator 116
0 parameters 72
0 recorded-object 107
0 reward-link 110
0 superstate 5
0 top-state 0
0 type 4
1 input-link 2
1 output-link 3
2 area-description 82
2 continuous 96
2 object 51
2 player 97
2 self 21
3 drop 63
3 get 62
3 move 6
3 rotate 8
3 rotate-absolute 40
3 rotate-relative 41
3 stop-sim 12
6 direction 9
6 status 7
8 direction 11
8 status 10
12 status 46
12 true 13
18 actions 3
18 name 19
18 random 20
21 angle 22
21 area 47
21 blocked 103
21 carry 48
21 collision 24
21 cycle 27
21 position 29
21 random 34
21 score 28
21 time 35
21 velocity 36
22 direction 102
22 yaw 23
24 x 26
24 y 25
29 col 33
29 row 32
29 x 30
29 y 31
36 speed 37
36 x 38
36 y 39
40 status 44
40 yaw 42
41 amount 43
41 status 45
48 id 49
48 type 50
51 angle-off 80
51 area 52
51 id 53
51 position 55
51 range 56
51 type 54
51 visible 57
55 col 61
55 row 60
55 x 58
55 y 59
62 id 65
62 status 66
63 id 64
63 status 67
68 block-id 65
68 name 69
70 name 71
72 pickup-angle-off-neg 73
72 pickup-angle-off-pos 75
72 pickup-range 74
76 name 77
76 object 51
78 name 79
80 yaw 81
82 gateway 83
82 wall 84
83 center 85
83 direction 86
83 id 87
83 left 88
83 right 89
83 to 90
84 center 85
84 direction 86
84 id 87
84 left 88
84 right 89
85 angle-off 80
85 range 91
88 col 92
88 row 95
89 col 93
89 row 94
97 angle-off 98
97 area 99
97 name 100
97 position 29
97 range 101
98 yaw 23
103 backward 104
103 forward 104
103 left 104
103 right 104
105 name 106
107 area 52
107 id 53
107 position 55
107 type 54
108 name 109
110 reward 111
111 value 112
114 name 115
116 name 117
