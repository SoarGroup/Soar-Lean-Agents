46
SOAR_ID 0
SOAR_ID 1
SOAR_ID 2
SOAR_ID 3
ENUMERATION 4 1 state
ENUMERATION 5 1 nil
SOAR_ID 6
ENUMERATION 7 1 initialize-taxi
ENUMERATION 8 5 maxget maxnavigate maxput maxrefuel taxi
SOAR_ID 9
SOAR_ID 10
INTEGER_RANGE 11 -2147483648 2147483647
SOAR_ID 12
SOAR_ID 13
SOAR_ID 14
SOAR_ID 15
SOAR_ID 16
SOAR_ID 17
SOAR_ID 18
SOAR_ID 19
INTEGER_RANGE 20 -2147483648 2147483647
ENUMERATION 21 2 false true
SOAR_ID 22
SOAR_ID 23
SOAR_ID 24
SOAR_ID 25
SOAR_ID 26
SOAR_ID 27
ENUMERATION 28 1 alternate
SOAR_ID 29
SOAR_ID 30
SOAR_ID 31
SOAR_ID 32
SOAR_ID 33
SOAR_ID 34
SOAR_ID 35
ENUMERATION 36 1 pickup
SOAR_ID 37
SOAR_ID 38
SOAR_ID 39
SOAR_ID 40
INTEGER_RANGE 41 -2147483648 2147483647
SOAR_ID 42
ENUMERATION 43 1 true
ENUMERATION 44 1 yes
SOAR_ID 45
46
0 alternator 21
0 condition 22
0 counter 9
0 counter 11
0 fuel 24
0 fuelmm 25
0 fuelmmmm 26
0 io 1
0 map 18
0 name 8
0 operator 6
0 operator 27
0 operator 35
0 position 19
0 reward-link 14
0 reward-total 20
0 superstate 5
0 superstate 38
0 top-state 0
0 type 4
1 input-link 2
1 output-link 3
2 cell 34
2 self 13
2 view 10
6 actions 12
6 name 7
12 pickup 37
13 fuel 23
13 reward 15
13 reward 41
14 reward 16
16 reward 17
16 value 42
22 direction 29
27 name 28
29 east 32
29 north 30
29 south 31
29 west 33
34 passenger 43
35 name 36
37 attempt 44
38 operator 39
38 top-state 40
39 name 45
