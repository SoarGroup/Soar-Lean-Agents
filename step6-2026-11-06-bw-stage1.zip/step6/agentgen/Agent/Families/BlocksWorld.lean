import Agent.DSL
import Agent.Sem

/-!
# Family: Blocks World

75 originals (step 6, `families/blocks-world`). The task: blocks on a table, each on the table or
on one other block; move a clear block onto the table or onto another clear block until the
desired stacking holds. The methods vary: simple search-control preferences (BW-Simple,
blocks-world-simple), one-step and deeper look-ahead with the selection library (BW-LA,
blocks-world-lookahead, the look-ahead demos), look-ahead with state evaluation and RL (BW-LA-state-
eval), hierarchical operators (move-block carried out by pick-up/put-down with a gripper;
BW-Hierarchical, blocks-world-hierarchical, hierarchical look-ahead), operator subgoaling (means-
ends analysis; BW-Op-Subgoal, blocks-world-operator-subgoaling, ±RL), RL (BW-RL, blocks-world-RL),
hierarchical RL, episodic memory. This file has the task and the variants built so far.

Representation: one object type for the blocks and the table, each with a `name`, `table` (1 for
the table) and a changing link `on` (what it rests on; the table rests on nothing). The originals
keep separate `^ontop` objects (`^top-block`, `^bottom-block`); `move-block` changes the bottom
block, here the moved block's `on`.
-/

namespace Agent.BlocksWorld

def obj : String := "object"

def schema (task : String) : Schema where
  task := task
  stateAttrs := [{ name := "object", ty := .obj obj, multi := true, doc := "The blocks and the table." }]
  types := [{
    name := obj, key := some "name",
    attrs := [
      { name := "name", ty := .sym [], doc := "the block's name (A, B, …) or table" },
      { name := "table", ty := .int, doc := "1 for the table, 0 for a block" },
      { name := "on", ty := .obj obj, doc := "what it rests on (changes as blocks move; the table has none)" }] }]

/-- Nothing is on `p`. -/
def clear (p : String) : Guard := .noneSuch obj [("on", .eq, .obj p)]

/-- Move a clear block onto the table or onto another clear block. -/
def moveBlock : Operator where
  name := "move-block"
  params := [("block", obj), ("dest", obj)]
  propose := [
    .cmp "block" "table" .eq (.lit 0),
    clear "block",
    .distinct "block" "dest",
    .cmp "block" "on" .ne (.obj "dest")]
  proposeOr := [
    [.cmp "dest" "table" .eq (.lit 1)],
    [.cmp "dest" "table" .eq (.lit 0), clear "dest"]]
  apply := [{ effects := [{ obj := "block", attr := "on", val := .obj "dest" }] }]
  doc := "Move a clear block onto the table or onto another clear block."

/-- An instance: blocks with what each starts on, and the desired `on` of each block. -/
structure Instance where
  start : List (String × String)
  goal : List (String × String)

/-- The originals' three-block instance: C on A, A and B on the table; goal A on B on C. -/
def three : Instance := { start := [("A", "table"), ("B", "table"), ("C", "A")],
                          goal := [("A", "B"), ("B", "C"), ("C", "table")] }

/-- The search control of the look-ahead originals: never move the same block twice in a row. -/
def notTwice : List Pref := [
  { name := "reject-twice", op := "move-block", value := .reject, sameAsLast := [("block", "block")],
    inLookahead := true, doc := "In look-ahead, do not move the block just moved." }]

def assumptions : List Assumption := [
  { id := "A1", text := "Representation: one object type for blocks and the table, with `name`, `table` (1 for the table) and a changing link `on`. The originals keep `^ontop` objects (`^top-block`, `^bottom-block`) and `^type block/table`; `move-block` changes an ontop's bottom block, here the moved block's `on` (a changing link, `block.on := dest`)." },
  { id := "A2", text := "move-block(block, dest): proposed when the block is clear and not already on dest, and dest is the table or another clear block (two proposal rules, disjoint). The originals elaborate `^clear` (blocks with nothing on them, and always the table) and propose from it." },
  { id := "A3", text := "Goal: the desired `on` of every block, as `^desired` links to the task's own objects (the originals' desired ontops); success halts at the top state." },
  { id := "A4", text := "Look-ahead variant: the selection library, no duplicate-state detection (the originals have none), chunking on. As in the originals, moving the block just moved is rejected inside look-ahead states only (at the top state it may be the only move)." }]

def mk (task : String) (inst : Instance) (method : Method) (prefs : List Pref) (learning : Learning) : Agent where
  schema := schema task
  init := []
  objs := { holder := "object", name := "table", vals := [("table", 1)] } ::
    inst.start.map fun (b, on) => { holder := "object", name := b, vals := [("table", 0)], links := [("on", on)] }
  derive := []
  ops := [moveBlock]
  goal := { ty := obj, vals := [], links := inst.goal.map fun (b, on) => (b, "on", on) }
  constraints := []
  prefs := prefs
  method := method
  learning := learning
  assumptions := assumptions

def variants : List (String × Agent × List String) := [
  ("blocks-world-look-ahead", mk "blocks-world" three (.lookahead [] none .off) notTwice (.chunk []),
    ["blocks-world-lookahead V1–V4", "BW-LA V1, V2", "BW-LA-X V1", "blocks-world-look-ahead V1, V2",
     "ChunkingDemoTests_Demo_Blocks_World_Look_Ahead V1", "FunctionalTests_testBlocksWorldLookAhead V1"])]

/-- Every variant obeys the conventions. -/
theorem conventions : variants.all (fun v => check v.2.1 == []) = true := by decide

/-- The three-block instance: three moves (C to the table, B onto C, A onto B), no fewer. -/
theorem three_shortest : ((mk "bw" three .random [] .none).bfs 4).1.map List.length = some 3 := by native_decide

end Agent.BlocksWorld
