# Blocks World — step 6 (in progress)

Lean: `agentgen/Agent/Families/BlocksWorld.lean`. 75 originals, flattened in `task/`, all run in Soar 9.6.5 (`results/orig`, 10 seeds, cap 2000 decisions; summary in `compare.csv`).

## Stage 1 (6 Nov 2026): changing links, and the look-ahead variant

### New general DSL features
- **Changing links.** An operator may set an object-valued attribute to one of its object parameters (`Expr.obj p`: `block.on := obj dest`); the semantics keeps such links in the state (as the target's index); `check` types them. Static links (e.g. cells' neighbours) are unchanged.
- **Comparing with an object**: `Atom.obj p` (`block.on ≠ obj dest`; inside `noneSuch`: "nothing is on `p`").
- **Goal by links** (`Goal.links`): named objects linked as desired (A on B …); `^desired` links to the task's own objects, and the success test compares the targets by name (look-ahead copies point to copies).
- **Proposal disjunction** (`Operator.proposeOr`): one proposal rule per disjoint alternative ("dest is the table" / "dest is a clear block").
- **Look-ahead-only preferences** (`Pref.inLookahead`), and links are optional on named objects (the table rests on nothing).

### Variant `blocks-world-look-ahead` (3 blocks: C on A, A and B on the table → A on B on C)

Replaces blocks-world-lookahead V1–V4, BW-LA V1/V2, BW-LA-X V1, blocks-world-look-ahead V1/V2, ChunkingDemoTests_Demo_Blocks_World_Look_Ahead V1, FunctionalTests_testBlocksWorldLookAhead V1.

| Agent | Solved (10 seeds) | Median decisions | Chunks |
|---|---|---|---|
| blocks-world-lookahead V1, V3; BW-LA V1, V2; BW-LA-X V1 (book versions) | 4/10 | 2000 (loops) | 9–11 |
| blocks-world-look-ahead V1 / V2 | 6/10 / 10/10 | 51 / 30 | 6 / 5 |
| ChunkingDemo Look_Ahead V1 | 10/10 | 43 | 6 |
| FunctionalTests LookAhead V1 | 10/10 | 51.5 | 0 (chunking off) |
| blocks-world-lookahead V2, V4 | 0/10 | — | (V4 never moves) |
| **generated blocks-world-look-ahead** | **5/10** | — (5 loop to the cap) | 7 |

The generated agent behaves like the book versions: when it does not solve, it loops (chunks lock a cycle, as in M&C). **Why the demo solves 10/10:** its copy of the selection library is edited — `selection*pass-back-success` passes back only `required-success` (the book library also passes back `success`/`partial-success`), and the look-ahead operator is required with all others rejected. Passing back success from a deeper level is exactly what made M&C's look-ahead chunks loop ("success" = goal still reachable). This bears on the M&C chunk question.

Soar 9.6.5 vs soar-lean: MATCH (`leancmp/chunk.out`: 23 decisions, 54 WMEs, 7 chunks).

Theorems: `conventions`; `three_shortest` (3 moves, no fewer).

### Assumptions (A1–A4, in BlocksWorld.lean)
- A1 representation: one object type for blocks and table with `name`, `table` (1 for the table) and a changing link `on`, instead of `^ontop` objects and `^type`.
- A2 move-block(block, dest): two disjoint proposal rules (dest = table / dest = clear block), instead of an elaborated `^clear`.
- A3 goal: desired `on` of every block (`^desired` links), success halts.
- A4 look-ahead: library as is, no duplicate detection, chunking; moving the block just moved is rejected only in look-ahead (as the originals).

## Still to do in this family
- `blocks-world-simple` (5 blocks; search-control heuristics with a recursive "in place" elaboration and a binary better preference).
- Look-ahead with state evaluation (+RL), hierarchical (pick-up/put-down, gripper) and hierarchical look-ahead, operator subgoaling (means-ends; ±RL), RL, HRL.
- Not replaced (to confirm): blocks-world-epmem, count-blocks, cube-stack, opsub-core, blocksworld V1–V3, blocks-opsub, the `_expected` chunk files.
- Some 0/10 originals need a closer look (e.g. blocks-world-simple V3/V4, blocks-world-hierarchical V4: possibly the harness's reading of their desired state).
- Revisit Pyramid A5 (object creation).
