"""Task-level runs of Blocks World agents in Soar 9.6.5 (soar_sml).

usage: harness.py DIR LOADFILE [--cap N] [--seeds a-b]

Sources the agent, sets srand SEED after loading, runs up to the cap (or until halt), and
records: halted, decisions, the top-level operators selected (by name), chunks, RL rules, and the
final "on" relation read from the top state, in either representation: the originals' ^ontop
objects (^top-block / ^bottom-block, each with ^name) or generated agents' objects with ^name and
an ^on link. `solved` = every desired relation (the ^desired structure, same two forms) holds."""
import argparse, json, os, re
from collections import Counter
import soar_sml as sml

TOP_OP = re.compile(r'^\s*\d+:    O: \S+ \(([^)]+)\)', re.M)

def objs(a, root='s1', depth=4):
    t = a.ExecuteCommandLine(f'print --depth {depth} {root}')
    d = {}
    for m in re.finditer(r'\((\S+)([^()]*)\)', t):
        for x in re.finditer(r'\^(\S+)\s+([^\s)^]+)', m.group(2)):
            d.setdefault(m.group(1), []).append((x.group(1), x.group(2).strip('|')))
    return d

def name(d, i):
    return dict(d.get(i, [])).get('name', i)

def rel(d, root):
    """set of (top, bottom) names under identifier root"""
    out = set()
    for k, v in d.get(root, []):
        o = dict(d.get(v, []))
        if k == 'ontop' and 'top-block' in o and 'bottom-block' in o:
            out.add((name(d, o['top-block']), name(d, o['bottom-block'])))
        if 'on' in o and 'name' in o:
            out.add((o['name'], name(d, o['on'])))
    return out

def run(d, load, cap, seed):
    k = sml.Kernel.CreateKernelInCurrentThread(True, 0)
    a = k.CreateAgent('h'); out = []
    a.RegisterForPrintEvent(sml.smlEVENT_PRINT, lambda *x: out.append(x[-1]), None)
    os.chdir(d); a.ExecuteCommandLine('cd ' + d)
    src = a.ExecuteCommandLine('source ' + load)
    a.ExecuteCommandLine(f'srand {seed}'); a.ExecuteCommandLine('watch 1')
    n = 0; halted = False; ops = Counter()
    while n < cap:
        out.clear(); r = a.ExecuteCommandLine('run 50 -d'); n += 50
        txt = ''.join(out) + r
        ops.update(TOP_OP.findall(txt))
        if 'halted' in txt.lower() or 'interrupt' in txt.lower():
            halted = True; break
    m = re.search(r'(\d+) decisions', a.ExecuteCommandLine('stats'))
    dec = int(m.group(1)) if m else n
    dd = objs(a)
    s1 = dict(dd.get('S1', []))
    cur = rel(dd, 'S1'); des = rel(dd, s1.get('desired', ''))
    chunks = len(re.findall(r'^chunk', a.ExecuteCommandLine('print --chunks'), re.M))
    rlr = len(re.findall(r'^\S', a.ExecuteCommandLine('print --rl'), re.M))
    k.Shutdown()
    return dict(seed=seed, decisions=dec, halted=halted, ops=dict(ops), chunks=chunks, rl_rules=rlr,
                solved=bool(des) and des <= cur, on=sorted(cur), desired=sorted(des),
                source_errors='rror' in src)

if __name__ == '__main__':
    p = argparse.ArgumentParser(); p.add_argument('dir'); p.add_argument('load')
    p.add_argument('--cap', type=int, default=2000); p.add_argument('--seeds', default='1-5')
    o = p.parse_args(); d = os.path.abspath(o.dir); lo, hi = map(int, o.seeds.split('-'))
    for s in range(lo, hi + 1): print(json.dumps(run(d, o.load, o.cap, s)), flush=True)
