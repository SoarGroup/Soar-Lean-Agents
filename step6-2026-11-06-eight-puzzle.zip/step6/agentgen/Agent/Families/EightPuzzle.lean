import Agent.DSL
import Agent.Sem

/-!
# Family: Eight and Fifteen Puzzle

Originals (step 6, `families/eight-puzzle`): eight-puzzle V1–V5, eight-puzzle-desired-binding V1,
FunctionalTests_testEightPuzzle V1, ChunkingDemoTests_Demo_Eight_Puzzle V1, fifteen-puzzle V1–V4.
All share one design: a board of cells (each linked to its neighbours) holding tiles and a
blank; one operator, move-tile, slides a tile next to the blank into it; a tie among the moves is
resolved by one-step look-ahead with Soar's selection library, evaluating the state after a move
numerically by the moved tile (+1 if it is now in its desired cell, −1 if it left its desired cell,
0 otherwise); the move that would put the last moved tile back is rejected; chunking is on. The
instances: eight puzzle (3×3, one start), fifteen puzzle (4×4, one start). Differences among the
originals are representation or settings: eight-puzzle-desired-binding elaborates each cell's
desired tile; eight-puzzle V2 gives an expected value (numeric-indifferent preferences) instead of
a numeric value and a reward at the goal, with RL off.

Not replaced: ChunkingDemoTests_Demo_Eight_Puzzle_expected V1 (a file of expected chunks, not an
agent), load-8p V1 (a language-comprehension agent that reads the words "eight puzzle", misfiled).
-/

namespace Agent.EightPuzzle

def tile : String := "tile"
def cell : String := "cell"

def schema (task : String) : Schema where
  task := task
  stateAttrs := [
    { name := "tile", ty := .obj tile, multi := true, doc := "The tiles and the blank (tile 0)." },
    { name := "cell", ty := .obj cell, multi := true, doc := "The cells of the board." }]
  types := [
    { name := tile, key := some "number",
      attrs := [
        { name := "number", ty := .int, doc := "the tile's number; 0 is the blank" },
        { name := "cell", ty := .int, doc := "the cell it is in (row × 10 + column)" }] },
    { name := cell, key := some "id",
      attrs := [
        { name := "name", ty := .sym [], doc := "the cell's name (c11, …)" },
        { name := "id", ty := .int, doc := "row × 10 + column" },
        { name := "neighbor", ty := .obj cell, multi := true, doc := "the cells next to it" }] }]

/-- Slide `tile`, in cell `from`, into the blank's cell `to`, next to it; the blank moves to `from`. -/
def moveTile : Operator where
  name := "move-tile"
  params := [("tile", tile), ("blank", tile), ("from", cell), ("to", cell)]
  propose := [
    .cmp "tile" "number" .ne (.lit 0),
    .cmp "blank" "number" .eq (.lit 0),
    .cmp "tile" "cell" .eq (.get "from" "id"),
    .cmp "blank" "cell" .eq (.get "to" "id"),
    .link "from" "neighbor" "to"]
  apply := [{ effects := [
    { obj := "tile", attr := "cell", val := .get "to" "id" },
    { obj := "blank", attr := "cell", val := .get "from" "id" }] }]
  doc := "Slide a tile next to the blank into the blank's cell."

/-- The cells of an `n`×`n` board, named `c<row><column>`, each linked to its neighbours. -/
def cells (n : Nat) : List Named :=
  let ids := (List.range n).flatMap fun r => (List.range n).map fun c => (r + 1, c + 1)
  ids.map fun (r, c) =>
    let nb := [(r - 1, c), (r + 1, c), (r, c - 1), (r, c + 1)].filter fun (r', c') =>
      1 ≤ r' && r' ≤ n && 1 ≤ c' && c' ≤ n && (r', c') != (r, c)
    { holder := "cell", name := s!"c{r}{c}", vals := [("id", (r * 10 + c : Nat))],
      links := nb.map fun (r', c') => ("neighbor", s!"c{r'}{c'}") }

/-- A board as rows of tile numbers (0 the blank) → tiles with their cells. -/
def tiles (rows : List (List Nat)) : List (String × ObjPat) :=
  (rows.zip (List.range rows.length)).flatMap fun (row, r) =>
    (row.zip (List.range row.length)).map fun (t, c) =>
      ("tile", [("number", (t : Int)), ("cell", ((r + 1) * 10 + (c + 1) : Nat))])

/-- The originals' eight-puzzle start and goal (rows c1x, c2x, c3x). -/
def eightStart : List (List Nat) := [[2, 1, 7], [8, 6, 0], [3, 4, 5]]
def eightGoal : List (List Nat) := [[1, 8, 7], [2, 0, 6], [3, 4, 5]]
/-- The originals' fifteen-puzzle start and goal. -/
def fifteenStart : List (List Nat) := [[2, 1, 7, 8], [6, 15, 3, 4], [5, 9, 10, 11], [12, 13, 14, 0]]
def fifteenGoal : List (List Nat) := [[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12], [13, 14, 15, 0]]

/-- The originals' evaluation of a tried move, by the moved tile. -/
def byMovedTile : Score :=
  { ty := tile, delta := some { op := "move-tile", obj := "tile", attr := "cell", old := ("from", "id") } }

/-- The originals' search control: never move back the tile just moved. -/
def rejectInverse : List Pref := [
  { name := "reject-inverse", op := "move-tile", value := .reject, sameAsLast := [("tile", "tile")],
    doc := "Do not slide the tile just moved straight back." }]

def assumptions : List Assumption := [
  { id := "A1", text := "Representation: tiles (the blank is tile 0) each with a number and the cell it is in, as an integer row × 10 + column; cells as named objects (c11 …) with that id and static `neighbor` links. The originals use `^binding` objects that pair a cell with a tile, a `^blank-cell` on the state, and tiles named by number." },
  { id := "A2", text := "One operator, move-tile(tile, blank, from, to): the tile in `from` slides into the blank's cell `to`, a neighbour of `from`. The originals' operator names only the two cells (`^tile-cell`, `^blank-cell`); the tile and the blank are found from the bindings when applying it." },
  { id := "A3", text := "The goal is the originals' desired board (every tile, the blank included, in its desired cell), a `^desired` structure with one object per tile; success halts at the top state (the originals' top-goal*halt*success)." },
  { id := "A4", text := "Search control: the move that slides the tile just moved straight back is rejected (the originals reject an operator whose tile-cell is the state's `^tile-cell`, the cell the last tile came from — the same move). This uses the last-move record (`^last-move`) instead of `^tile-cell`." },
  { id := "A5", text := "Look-ahead: one step, Soar's selection library; the tried state is evaluated by the moved tile: +1 if it is now in its desired cell, −1 if it was in its desired cell before the move, 0 otherwise (the originals' three evaluation rules; their 0 rule is stated more indirectly). No duplicate-state detection (the originals have none)." },
  { id := "A6", text := "eight-puzzle V2 gives the evaluation as `^expected-value` (numeric-indifferent preferences, a probabilistic choice) and a reward of 1 at the goal, with RL off; it is replaced by the numeric-value variant (open: keep an expected-value variant?)." },
  { id := "A7", text := "Chunking on (`chunk always`); the fifteen-puzzle V3 singleton declarations (cell, tile, blank-cell, tile-cell, problem-space) are dropped (singletons are the default in 9.6.5); the harness sets the random seed after loading (several originals set srand 1)." }]

/-- The family: board size, start and goal boards. -/
def mk (task : String) (n : Nat) (start goal : List (List Nat)) : Agent where
  schema := schema task
  init := tiles start
  objs := cells n
  derive := []
  ops := [moveTile]
  goal := { ty := tile, vals := [], each := (tiles goal).map (·.2) }
  constraints := [
    { ty := tile, guard := [.cmp "self" "cell" .ge (.lit 11), .cmp "self" "cell" .le (.lit ((n * 10 + n : Nat)))],
      doc := "every tile is on the board" }]
  prefs := rejectInverse
  method := .lookahead [] none .off (some byMovedTile)
  learning := .chunk []
  assumptions := assumptions

def variants : List (String × Agent × List String) := [
  ("eight-puzzle", mk "eight-puzzle" 3 eightStart eightGoal,
    ["eight-puzzle V1", "eight-puzzle V2", "eight-puzzle V3", "eight-puzzle V4", "eight-puzzle V5",
     "eight-puzzle-desired-binding V1", "FunctionalTests_testEightPuzzle V1",
     "ChunkingDemoTests_Demo_Eight_Puzzle V1"]),
  ("fifteen-puzzle", mk "fifteen-puzzle" 4 fifteenStart fifteenGoal,
    ["fifteen-puzzle V1", "fifteen-puzzle V2", "fifteen-puzzle V3", "fifteen-puzzle V4"])]

/-- Every variant obeys the conventions. -/
theorem conventions : variants.all (fun v => check v.2.1 == []) = true := by decide

/-- The eight-puzzle instance: the shortest solution has 5 moves (the originals and the
regenerated agent take 5–9). -/
theorem eight_shortest : ((mk "eight-puzzle" 3 eightStart eightGoal).bfs 6).1.map List.length = some 5 := by
  native_decide


end Agent.EightPuzzle
