"""Task-level runs of Eight/Fifteen Puzzle agents in Soar 9.6.5 (soar_sml).

usage: harness.py DIR LOADFILE [--cap N] [--seeds a-b]

Sources the agent, sets srand SEED after loading (overriding an srand in the agent), runs up to
the cap (or until halt) and records: halted, decisions, top-level move-tile operators selected,
chunks, and whether the final board equals the desired board. The board is read from the top
state in either representation: originals (^binding objects with ^cell.name and ^tile.name) or
generated agents (^tile objects with ^number and ^cell, an integer row*10+column)."""
import argparse, json, os, re
import soar_sml as sml

TOP_OP = re.compile(r'^\s*\d+:    O: \S+ \((move-tile)\)', re.M)

def objs(a, depth=4):
    t = a.ExecuteCommandLine(f'print --depth {depth} s1')
    d = {}
    for m in re.finditer(r'\((\S+)([^()]*)\)', t):
        for x in re.finditer(r'\^(\S+)\s+([^\s)^]+)', m.group(2)):
            d.setdefault(m.group(1), []).append((x.group(1), x.group(2).strip('|').strip()))
    return d

def board(d, root):
    """{cell: tile} for the bindings / tiles under identifier `root`"""
    out = {}
    for k, v in d.get(root, []):
        o = dict(d.get(v, []))
        if k == 'binding' and 'cell' in o and 'tile' in o:
            c = dict(d.get(o['cell'], [])).get('name', o['cell']).lower().lstrip('c')
            t = dict(d.get(o['tile'], [])).get('name', o['tile'])
            out[c] = t
        if k == 'tile' and 'number' in o and 'cell' in o:
            out[o['cell']] = o['number']
    return out

def run(d, load, cap, seed):
    k = sml.Kernel.CreateKernelInCurrentThread(True, 0)
    a = k.CreateAgent('h'); out = []
    a.RegisterForPrintEvent(sml.smlEVENT_PRINT, lambda *x: out.append(x[-1]), None)
    os.chdir(d); a.ExecuteCommandLine('cd ' + d)
    src = a.ExecuteCommandLine('source ' + load)
    a.ExecuteCommandLine(f'srand {seed}'); a.ExecuteCommandLine('watch 1')
    n = 0; halted = False; moves = 0
    while n < cap:
        out.clear(); r = a.ExecuteCommandLine('run 50 -d'); n += 50
        txt = ''.join(out) + r
        moves += len(TOP_OP.findall(txt))
        if 'halted' in txt.lower() or 'interrupt' in txt.lower():
            halted = True; break
    m = re.search(r'(\d+) decisions', a.ExecuteCommandLine('stats'))
    dec = int(m.group(1)) if m else n
    dd = objs(a)
    s1 = dict((kk, vv) for kk, vv in dd.get('S1', []))
    cur = board(dd, 'S1'); des = board(dd, s1.get('desired', ''))
    chunks = len(re.findall(r'^chunk', a.ExecuteCommandLine('print --chunks'), re.M))
    k.Shutdown()
    return dict(seed=seed, decisions=dec, halted=halted, moves=moves, chunks=chunks,
                solved=bool(cur) and cur == des, board=cur, source_errors='rror' in src)

if __name__ == '__main__':
    p = argparse.ArgumentParser(); p.add_argument('dir'); p.add_argument('load')
    p.add_argument('--cap', type=int, default=2000); p.add_argument('--seeds', default='1-5')
    o = p.parse_args(); d = os.path.abspath(o.dir); lo, hi = map(int, o.seeds.split('-'))
    for s in range(lo, hi + 1): print(json.dumps(run(d, o.load, o.cap, s)), flush=True)
