# fifteen-puzzle

## The task

The task state holds several values of `tile`, each a tile. The tiles and the blank (tile 0).
The task state holds several values of `cell`, each a cell. The cells of the board.

A tile has `number` (an integer), `cell` (an integer).

A cell has `name` (one of ), `id` (an integer), `neighbor` (a cell).

Initially the task state has:
- a `tile` with number 2 and cell 11
- a `tile` with number 1 and cell 12
- a `tile` with number 7 and cell 13
- a `tile` with number 8 and cell 14
- a `tile` with number 6 and cell 21
- a `tile` with number 15 and cell 22
- a `tile` with number 3 and cell 23
- a `tile` with number 4 and cell 24
- a `tile` with number 5 and cell 31
- a `tile` with number 9 and cell 32
- a `tile` with number 10 and cell 33
- a `tile` with number 11 and cell 34
- a `tile` with number 12 and cell 41
- a `tile` with number 13 and cell 42
- a `tile` with number 14 and cell 43
- a `tile` with number 0 and cell 44
- a `cell` named c11 with id 11; its `neighbor` is c21; its `neighbor` is c12
- a `cell` named c12 with id 12; its `neighbor` is c22; its `neighbor` is c11; its `neighbor` is c13
- a `cell` named c13 with id 13; its `neighbor` is c23; its `neighbor` is c12; its `neighbor` is c14
- a `cell` named c14 with id 14; its `neighbor` is c24; its `neighbor` is c13
- a `cell` named c21 with id 21; its `neighbor` is c11; its `neighbor` is c31; its `neighbor` is c22
- a `cell` named c22 with id 22; its `neighbor` is c12; its `neighbor` is c32; its `neighbor` is c21; its `neighbor` is c23
- a `cell` named c23 with id 23; its `neighbor` is c13; its `neighbor` is c33; its `neighbor` is c22; its `neighbor` is c24
- a `cell` named c24 with id 24; its `neighbor` is c14; its `neighbor` is c34; its `neighbor` is c23
- a `cell` named c31 with id 31; its `neighbor` is c21; its `neighbor` is c41; its `neighbor` is c32
- a `cell` named c32 with id 32; its `neighbor` is c22; its `neighbor` is c42; its `neighbor` is c31; its `neighbor` is c33
- a `cell` named c33 with id 33; its `neighbor` is c23; its `neighbor` is c43; its `neighbor` is c32; its `neighbor` is c34
- a `cell` named c34 with id 34; its `neighbor` is c24; its `neighbor` is c44; its `neighbor` is c33
- a `cell` named c41 with id 41; its `neighbor` is c31; its `neighbor` is c42
- a `cell` named c42 with id 42; its `neighbor` is c32; its `neighbor` is c41; its `neighbor` is c43
- a `cell` named c43 with id 43; its `neighbor` is c33; its `neighbor` is c42; its `neighbor` is c44
- a `cell` named c44 with id 44; its `neighbor` is c34; its `neighbor` is c43
Links between objects never change.

**Constraint (part of the task).** Every tile always has self.cell ≥ 11 and self.cell ≤ 44 (with `self` the tile); every operator must preserve this.

**Goal.** Some tile has . When the goal holds in the task state, the agent reports success and halts.

## Operators

An operator's changes are made together: every value on the right is read before any change.

**move-tile(tile: tile, blank: tile, from: cell, to: cell).** Proposed when tile.number ≠ 0 and blank.number = 0 and tile.cell = from.id and blank.cell = to.id and from.neighbor is to. Slide a tile next to the blank into the blank's cell.
- Effect: tile.cell := to.id; blank.cell := from.id.

## Choosing among proposed operators

When several operators are proposed, the agent tries each one in an internal copy of the state (look-ahead search, Soar's default selection library) and prefers those that lead to the goal. Returning to an earlier state is not detected.
Each state tried is given the value 0 of the tile (with `self` that tile); higher is better.

The agent remembers the last task operator applied (its name and parameters). Search-control preferences:
- **reject-inverse**: a proposed move-tile whose tile equals the last move-tile's tile is rejected. Do not slide the tile just moved straight back.

## Learning

Chunking on (`chunk always`).

## Assumptions (added; not in the task description)

- **A1** [open] Representation: tiles (the blank is tile 0) each with a number and the cell it is in, as an integer row × 10 + column; cells as named objects (c11 …) with that id and static `neighbor` links. The originals use `^binding` objects that pair a cell with a tile, a `^blank-cell` on the state, and tiles named by number.
- **A2** [open] One operator, move-tile(tile, blank, from, to): the tile in `from` slides into the blank's cell `to`, a neighbour of `from`. The originals' operator names only the two cells (`^tile-cell`, `^blank-cell`); the tile and the blank are found from the bindings when applying it.
- **A3** [open] The goal is the originals' desired board (every tile, the blank included, in its desired cell), a `^desired` structure with one object per tile; success halts at the top state (the originals' top-goal*halt*success).
- **A4** [open] Search control: the move that slides the tile just moved straight back is rejected (the originals reject an operator whose tile-cell is the state's `^tile-cell`, the cell the last tile came from — the same move). This uses the last-move record (`^last-move`) instead of `^tile-cell`.
- **A5** [open] Look-ahead: one step, Soar's selection library; the tried state is evaluated by the moved tile: +1 if it is now in its desired cell, −1 if it was in its desired cell before the move, 0 otherwise (the originals' three evaluation rules; their 0 rule is stated more indirectly). No duplicate-state detection (the originals have none).
- **A6** [open] eight-puzzle V2 gives the evaluation as `^expected-value` (numeric-indifferent preferences, a probabilistic choice) and a reward of 1 at the goal, with RL off; it is replaced by the numeric-value variant (open: keep an expected-value variant?).
- **A7** [open] Chunking on (`chunk always`); the fifteen-puzzle V3 singleton declarations (cell, tile, blank-cell, tile-cell, problem-space) are dropped (singletons are the default in 9.6.5); the harness sets the random seed after loading (several originals set srand 1).
