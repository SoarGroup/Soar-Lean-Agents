# pyramid

## The task

The task state holds several values of `pyramid`, each a pyramid. The problem.

A pyramid has `term` (an integer), `height` (an integer), `sum` (an integer).

Initially the task state has:
- a `pyramid` with term 5 and height 10 and sum 0

**Constraint (part of the task).** Every pyramid always has self.height ≥ -1 and self.height ≤ 10 (with `self` the pyramid); every operator must preserve this.

**Goal.** Some pyramid has height -1. When the goal holds in the task state, the agent reports success and halts. Before halting it writes "The answer is ⟨self.sum⟩." (with `self` the pyramid).

## Operators

An operator's changes are made together: every value on the right is read before any change.

**add-next-term(pyramid: pyramid).** Proposed when pyramid.height ≥ 0. Add the next term to the sum.
- Effect: pyramid.sum := pyramid.sum + pyramid.term; pyramid.term := pyramid.term − 1; pyramid.height := pyramid.height − 1; writes " + ⟨pyramid.term⟩".

## Choosing among proposed operators

Any proposed operator may be chosen; the choice is random.

## Learning

None.

## Assumptions (added; not in the task description)

- **A1** [open] The task: base $ height = the sum of height + 1 terms, from base down by one (all four originals agree on height + 1 terms: pyramid V1 adds while height ≥ 0, pyramid-anderson adds the base and then height more terms).
- **A2** [open] Representation: one `pyramid` object with the next term, the height left and the sum. pyramid V1 kept them on the state (`^base` was the next term); pyramid-anderson kept the term, a count up to the height, and `^sum nil` before starting; pyramid-hierarchical kept a linked list of terms (`^expansion`) and a final sum.
- **A3** [open] Goal: height = −1 (all terms added), a `^desired` structure; at the goal the agent writes "The answer is N." (the originals' terminate operator) and halts. The originals' typo "asnwer" is corrected.
- **A4** [open] Each added term is written as " + N" (pyramid V1, pyramid-jel, pyramid-hierarchical's expansion); pyramid-anderson wrote nothing per term.
- **A5** [open] pyramid-hierarchical: its two phases (write the terms as a list, then sum the list) become one operator, sum-pyramid, carried out in its substate by add-next-term, whose changes to the task state are results. The list of terms is dropped (the DSL does not create objects); its effect is stated in closed form and proved equal to what the sub-operator does.
- **A6** [open] pyramid-anderson's separate start operator (sum := base, term := base) is part of the initial state here (sum 0, term base: the first add-next-term adds the base).
