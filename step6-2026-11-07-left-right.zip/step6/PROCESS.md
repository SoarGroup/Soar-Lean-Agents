# Normalizing a Soar task family (plan step 6) — brief for each family

Owner: John Laird (JL). Pilot: Water Jug (done; do not redo). This brief is the process to follow
for every other family. Read it fully before starting.

## Goal per family
1. Read every task-agent version of the family; find what really varies (task, method, learning,
   representation) and what is incidental (names, monitors, local library copies).
2. Write ONE parameterized Lean description of the family in the agent DSL, with named variants
   that together replace the originals. Originals that are broken or inconsistent are not replaced;
   say why in the module docstring.
3. Regenerate the variants as VisualSoar projects.
4. Check: (a) conventions (`check … = [] := by decide`); (b) task properties in Lean (reachability /
   shortest solution / constraints over reachable states, where the task is finite); (c) Soar 9.6.5
   vs soar-lean on every regenerated agent (must MATCH); (d) task-level comparison with the
   originals (solve rate, solution length over 20 seeds, cap 500 decisions; same seeds for both).
5. Record recovered intent and common-sense additions as named `Assumption`s (status "open") for
   JL to review. Do not decide them yourself.
6. Write `REPORT.md` for the family (≤ 1 page): variants → originals table, comparison table,
   theorems, assumptions, anything surprising (bugs found in originals, behaviours that differ).

## Where things are
- Lean Soar spec: /home/claude/src/cmcsoar/cmcsoar (lake package `cmcsoar`; `soar-lean` exe built;
  tools/flatten.py flattens a load file; tools/diff.py compares Soar 9.6.5 vs soar-lean on a
  directory of .soar files each with a .n file (decision count): `python3 tools/diff.py DIR --replay
  [--chunk] [--rl --explore]`).
- Agent DSL package: /home/claude/src/agentgen (Lean 4.35; `source ~/.elan/env; lake build; lake build
  agentgen`). Files: Agent/DSL.lean (types + `check`), Agent/Sem.lean (task-level interpreter: bfs,
  invariant, constraintsHold, refinesSub), Agent/Compile.lean (→ Soar.Production + VisualSoar
  layout), Agent/English.lean (template English), Agent/Families/WaterJug.lean (the worked example —
  read it first), AgentGen.lean (exe: `agentgen FAMILY OUT.json`; add your family to `main`),
  tools/vsproject.py (JSON → VisualSoar projects; `python3 -I tools/vsproject.py GEN.json OUTDIR
  DEFAULT_DIR`).
- Originals: /home/claude/src/agents/working/<agent>/<version>/ (load file per MANIFEST.csv);
  corpus classification /home/claude/work/classified.json (fields agent, version, load, family,
  category, rules, …).
- Task-level harness: /home/claude/work/harness.py is Water-Jug specific (reads jugs). Write a
  family-specific harness next to it (copy and adapt: goal test, state snapshot) as
  /home/claude/work/<family>/harness.py. Run originals and regenerated with the same seeds
  (`srand SEED` after sourcing), 20 seeds, cap 500 decisions.
- Default Soar libraries (selection etc.): use the `default/` folder from
  /home/claude/src/agents/working/water-jug-look-ahead-failure-states/V1/default.
- Python: soar_sml (Soar 9.6.5) is installed. Run Python that reads agent files with `-I`.

## DSL rules
- Extend the DSL when a family needs it (e.g. value parameters, relations between objects,
  objects created/removed, variable attribute names, failure states, search-control preference
  rules — hand-written preference rules ARE allowed, EVA-022 was dropped). Keep extensions general,
  documented, and checked by `check`. Every existing theorem must still build, and Water Jug's
  generated Soar must stay byte-identical except english.md (verify with a diff of
  `agentgen water-jug` output before/after).
- Conventions decided by JL (6 Nov 2026), apply them:
  - Changing a single-valued attribute: one application rule adds the new value and removes the
    old; a separate rule adds a value only when none exists.
  - Proposals encode relevance; styles: precondition style, goal (means-ends) style; heuristic
    restrictions allowed.
  - All impasse types allowed.
  - ^io copied into no-change substates only (simple.soar); rules for the top state test its name.
  - Goals as ^desired + success rule; halt at the top state.
  - Look-ahead uses the default selection library as is; duplicate-state tests with positive
    conditions only (nested negations over ancestors make chunking over-general).
  - No hand-declared chunking singletons (Soar 9.6.5 creates them automatically).
  - RL rules test operator name and non-derived parameter attributes; multi-episode training is
    the harness's job; agents halt at the goal.
- Do not write to /home/claude/src/cmcsoar except reading; do not modify originals.

## Task-specific vs general (JL, 6 Nov 2026)
- All task-specific Lean goes in the family's own file Agent/Families/<Family>.lean. Nothing
  task-specific in DSL.lean, Compile.lean, Sem.lean or English.lean.
- A new general convention (one any Soar agent should follow) goes in the general files: a type or a
  `check` rule in Agent/DSL.lean, added to the convention list in DSL.lean's module docstring with a
  one-line rationale. Also list it in REPORT.md under "New general conventions" (statement, level
  L0–L6, subject, rationale) so it is added to the conventions spreadsheet.

## Output
Everything for family F under /home/claude/work/families/F/: generated projects (projects/),
results (results/orig, results/gen), harness, REPORT.md. Lean in agentgen/Agent/Families/F.lean.
