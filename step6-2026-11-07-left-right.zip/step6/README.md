# Step 6 — current state

- `agentgen/` — the Lean package (DSL, semantics, compiler to Soar/VisualSoar, English, family files in `Agent/Families/`). Build: `lake build` (theorems) and `lake build agentgen` (the generator exe). Needs `../cmcsoar/cmcsoar` (the Lean Soar spec) beside it, as in `lakefile.lean`.
- `families/<family>/` — per family: `REPORT.md` (results, assumptions and decisions), `gen/` (generated JSON), `projects/` (generated VisualSoar projects), `results/` (task-level runs of originals and generated agents), `harness.py`, `compare.csv`, Soar 9.6.5 vs soar-lean comparisons (`leancmp*`).
  - `water-jug/` — the pilot (`package/` holds its README, DECISIONS, round-trip material).
  - `mac/` — Missionaries & Cannibals (A1–A10 decided; final numbers at the end of REPORT.md; chunk-loop diagnosis; Soar RL-template bug).
  - `hello-world/`, `counting/`, `pyramid/` — done (count-and-die rebuilt with a substate-local count; pyramid-hierarchical deferred).
  - `graph-search/`, `hrl-navigation/` — task only / not replaced (reasons in REPORT.md).
  - `toh/` — skipped; originals' runs only.
  - `eight-puzzle/` — Eight and Fifteen Puzzle (2 variants replace 12 originals).
  - `blocks-world/` — six variants (simple, simple-3, operator-subgoaling, operator-subgoaling-chunk, look-ahead); the RL, hierarchical-with-I/O and HRL/epmem groups remain.
  - `wizards/` — `wizards` replaces wizards V1 and V2 (nested belief views, assumptions, derived deductions; same 18 decisions; assumptions A1–A7 open).
  - `kenken/` — sixteen variants (one per V1 board) replace kenken V1 and V2; candidates and cage tuples, look-ahead guesses; chunking open; assumptions A1–A6 open.
  - `knights/` — `knights-6` and `knights-8` replace knights V2 and V1 (depth-first search with backtracking; sets, linked counts, binary preferences; assumptions A1–A6 open).
  - `arithmetic/` — `arithmetic` replaces V5, V6 and the chunking demo (nested sub-operators; assumptions A1–A7 open).
  - `hello-world/`, `counting/`, `pyramid/` also hold their later revisions (pyramid-hierarchical is replaced again).
  - `small-before/`, `small-baseline/`, `mac/agentgen-before/`, `toh/agentgen-before/` — snapshots used for regression checks.
- `PROCESS.md` — the family brief. `classified.json` — the triaged corpus. `Soar-Conventions.xlsx` — the conventions (new: ELB-014, OPR-017, IO-016; proposed: SUB-013).
