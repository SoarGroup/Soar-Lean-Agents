import Agent.DSL
import Agent.Sem
/-!
# Arithmetic — multi-column addition and subtraction by fact retrieval, in nested substates

Derived on 7 November 2026 from the 14 Arithmetic task agents in the agent library. The family
core (arithmetic V3–V6, V9–V11, arithmetic-save, the chunking demo and its expected chunks):
generate random three-column addition and subtraction problems, then solve each column by
column in an operator no-change substate of `process-column`, retrieving digit facts (sums with
carries, differences, digit + 10) from fact objects instead of computing; carries and borrows
are themselves done in deeper substates (V5: `get-digit1` adds the carry; a borrow subtracts one
from the next column, recursively). Chunking learns the column results.

One variant (`arithmetic`) is modelled on arithmetic V5 (the version the chunking demo copies).
-/
namespace Agent.Arithmetic

def prob : String := "problem"
def col : String := "column"
def digitT : String := "digit"
def addF : String := "add-fact"
def subF : String := "sub-fact"
def incF : String := "inc-fact"
def tenF : String := "ten-fact"

def schema (task : String) (v5 : Bool := false) : Schema where
  task := task
  stateAttrs := [
    { name := "problem", ty := .obj prob, multi := true, doc := "The problem being worked on." },
    { name := "column", ty := .obj col, multi := true, doc := "The columns of the problem (ones first)." },
    { name := "digit", ty := .obj digitT, multi := true, doc := "The digits 0–9, to choose from at random." },
    { name := "add-fact", ty := .obj addF, multi := true, doc := "Addition facts." },
    { name := "sub-fact", ty := .obj subF, multi := true, doc := "Subtraction facts." },
    { name := "inc-fact", ty := .obj incF, multi := true, doc := "Successor facts (n + 1)." },
    { name := "ten-fact", ty := .obj tenF, multi := true, doc := "Add-ten facts (n + 10)." }]
  types := [
    { name := prob,
      attrs := [
        { name := "operation", ty := .int, doc := "0 none yet, 1 addition, 2 subtraction" },
        { name := "carry", ty := .int, doc := "the carry (addition) or borrow (subtraction) into the current column" },
        { name := "count", ty := .int, doc := "problems still to do" },
        { name := "pid", ty := .int, doc := "the number of the current problem" },
        { name := "digits", ty := .int, doc := "digits generated for the current problem" }] },
    { name := col, key := some "pos",
      attrs := [
        { name := "pos", ty := .int, doc := "1 ones, 2 tens, 3 hundreds" },
        { name := "last", ty := .int, doc := "1 for the leftmost column" },
        { name := "digit1", ty := .int, doc := "the top digit" }] ++
        (if v5 then [{ name := "newd1", ty := .int, doc := "the top digit after borrows from it (V5's new-digit1)" }] else []) ++ [
        { name := "digit2", ty := .int, doc := "the bottom digit" },
        { name := "result", ty := .int, doc := "the answer digit" },
        { name := "gen1", ty := .int, doc := "the problem whose top digit this is" },
        { name := "gen2", ty := .int, doc := "the problem whose bottom digit this is" },
        { name := "done", ty := .int, doc := "the problem whose answer digit this is" }] },
    { name := digitT, key := some "val", attrs := [{ name := "val", ty := .int, doc := "0–9" }] },
    { name := addF, attrs := [
        { name := "d1", ty := .int, doc := "0–9" }, { name := "d2", ty := .int, doc := "0–10" },
        { name := "sum", ty := .int, doc := "(d1 + d2) mod 10" }, { name := "carry", ty := .int, doc := "(d1 + d2) div 10" }] },
    { name := subF, attrs := [
        { name := "d1", ty := .int, doc := "0–19" }, { name := "d2", ty := .int, doc := "0–10, at most d1" },
        { name := "diff", ty := .int, doc := "d1 − d2" }] },
    { name := incF, attrs := [{ name := "n", ty := .int, doc := "0–9" }, { name := "next", ty := .int, doc := "n + 1" }] },
    { name := tenF, attrs := [{ name := "n", ty := .int, doc := "0–9" }, { name := "plus10", ty := .int, doc := "n + 10" }] }]

def g (o a : String) : Expr := .get o a
def eff (o a : String) (v : Expr) : Effect := { obj := o, attr := a, val := v }

/-- Choose the operation of a new problem at random (V5 generate-operation). -/
def chooseOperation : Operator where
  name := "choose-operation"
  params := [("p", prob)]
  vparams := [("k", [1, 2])]
  propose := [.cmp "p" "operation" .eq (.lit 0), .cmp "p" "count" .gt (.lit 0)]
  apply := [{ effects := [eff "p" "operation" (.val "k"), eff "p" "carry" (.lit 0)] }]
  doc := "Choose addition or subtraction for the next problem, at random."

/-- Subtraction problems have a positive answer: the leftmost top digit is not 0, and the leftmost
bottom digit is smaller than it (V5's reject and worst preferences). -/
def genAlts (leftmost : Guard) : List (List Guard) :=
  [[.cmp "p" "operation" .eq (.lit 1)],
   [.cmp "p" "operation" .eq (.lit 2), .cmp "c" "last" .eq (.lit 0)],
   [.cmp "p" "operation" .eq (.lit 2), .cmp "c" "last" .eq (.lit 1), leftmost]]

def generateDigit1 (v5 : Bool := false) : Operator where
  name := "generate-digit1"
  params := [("p", prob), ("c", col), ("d", digitT)]
  propose := [.cmp "p" "operation" .ne (.lit 0), .cmp "c" "gen1" .ne (.get "p" "pid")]
  proposeOr := genAlts (.cmp "d" "val" .gt (.lit 0))
  apply := [{ effects := [eff "c" "digit1" (g "d" "val"), eff "c" "gen1" (g "p" "pid"),
    eff "p" "digits" (.add (g "p" "digits") (.lit 1))] ++ (if v5 then [eff "c" "newd1" (g "d" "val")] else []) }]
  doc := "Choose a column's top digit at random."

def generateDigit2 : Operator where
  name := "generate-digit2"
  params := [("p", prob), ("c", col), ("d", digitT)]
  propose := [.cmp "p" "operation" .ne (.lit 0), .cmp "c" "gen1" .eq (.get "p" "pid"),
    .cmp "c" "gen2" .ne (.get "p" "pid")]
  proposeOr := genAlts (.cmp "d" "val" .lt (.get "c" "digit1"))
  apply := [{ effects := [eff "c" "digit2" (g "d" "val"), eff "c" "gen2" (g "p" "pid"),
    eff "p" "digits" (.add (g "p" "digits") (.lit 1))] }]
  doc := "Choose a column's bottom digit at random (after its top digit)."

/-- The library of nested sub-operators: each works in the substate of a sub-operator of
`process-column` and changes that substate's locals (`up`). -/
def subLib : List SubOp := [
  { name := "increment-digit2", params := [("i", incF)],
    propose := [.cmp "i" "n" .eq (.get "up" "d2")],
    apply := [{ effects := [eff "up" "d2" (g "i" "next"), eff "up" "adj" (.lit 1)] }],
    doc := "Retrieve the successor of the bottom digit." },
  { name := "add-ten", params := [("t", tenF)],
    propose := [.cmp "t" "n" .eq (.get "up" "d1")],
    apply := [{ effects := [eff "up" "d1" (g "t" "plus10"), eff "up" "ten" (.lit 1), eff "up" "cout" (.lit 1)] }],
    doc := "Retrieve the top digit plus ten; the column borrows from the next one." }]

/-- The column's answer digit and the carry (borrow) out of it, from its digits and the carry in. -/
def x (op : Int) : Expr :=
  if op == 1 then .add (.add (g "c" "digit1") (g "c" "digit2")) (g "p" "carry")
  else .sub (.sub (g "c" "digit1") (g "c" "digit2")) (g "p" "carry")

def processColumn (n : Nat) : Operator where
  name := "process-column"
  params := [("p", prob), ("c", col)]
  propose := [.cmp "p" "digits" .eq (.lit ((2 * n : Nat) : Int)), .cmp "c" "done" .ne (.get "p" "pid"),
    .noneSuch col [("pos", .lt, .get "c" "pos"), ("done", .ne, .get "p" "pid")]]
  apply := [
    { guard := [.cmp "p" "operation" .eq (.lit 1)],
      effects := [eff "c" "result" (.sub (x 1) (.mul (.div (x 1) (.lit 10)) (.lit 10))),
        eff "p" "carry" (.div (x 1) (.lit 10)), eff "c" "done" (g "p" "pid")] },
    { guard := [.cmp "p" "operation" .eq (.lit 2)],
      effects := [eff "c" "result" (.add (x 2) (.mul (.div (.sub (.lit 9) (x 2)) (.lit 10)) (.lit 10))),
        eff "p" "carry" (.div (.sub (.lit 9) (x 2)) (.lit 10)), eff "c" "done" (g "p" "pid")] }]
  locals := [("d1", g "c" "digit1"), ("d2", g "c" "digit2"), ("adj", .sub (.lit 1) (g "p" "carry")),
    ("r", .lit (-1)), ("cout", .lit 0), ("ten", .lit 0)]
  impl := .sub [
    { name := "get-digit2", propose := [.cmp "local" "adj" .eq (.lit 0)], apply := [],
      subs := ["increment-digit2"],
      doc := "Add the carry (borrow) in to the bottom digit, in a substate." },
    { name := "add-digits", params := [("f", addF)],
      propose := [.cmp "p" "operation" .eq (.lit 1), .cmp "local" "adj" .eq (.lit 1), .cmp "local" "r" .eq (.lit (-1)),
        .cmp "f" "d1" .eq (.get "local" "d1"), .cmp "f" "d2" .eq (.get "local" "d2")],
      apply := [{ effects := [eff "local" "r" (g "f" "sum"), eff "local" "cout" (g "f" "carry")] }],
      doc := "Retrieve the sum of the digits and its carry." },
    { name := "borrow", propose := [.cmp "p" "operation" .eq (.lit 2), .cmp "local" "adj" .eq (.lit 1),
        .cmp "local" "ten" .eq (.lit 0), .cmp "local" "d1" .lt (.get "local" "d2")], apply := [],
      subs := ["add-ten"],
      doc := "The top digit is smaller: borrow ten, in a substate." },
    { name := "subtract-digits", params := [("f", subF)],
      propose := [.cmp "p" "operation" .eq (.lit 2), .cmp "local" "adj" .eq (.lit 1), .cmp "local" "r" .eq (.lit (-1)),
        .cmp "f" "d1" .eq (.get "local" "d1"), .cmp "f" "d2" .eq (.get "local" "d2")],
      apply := [{ effects := [eff "local" "r" (g "f" "diff")] }],
      doc := "Retrieve the difference of the digits." },
    { name := "write-result", propose := [.cmp "local" "r" .ne (.lit (-1))],
      apply := [{
        effects := [eff "c" "result" (g "local" "r"), eff "p" "carry" (g "local" "cout"),
          eff "c" "done" (g "p" "pid")],
        write := [.text "column ", .val (g "c" "pos"), .text " op ", .val (g "p" "operation"), .text ": ",
          .val (g "c" "digit1"), .text " ", .val (g "c" "digit2"), .text " -> ", .val (g "local" "r"),
          .text " carry ", .val (g "local" "cout")] }],
      doc := "Write the answer digit and pass the carry (borrow) to the next column (the results)." }]
  doc := "Work out one column, right to left, in a substate."

/-! ## V5's carries and borrows (JL, 7 Nov 2026: keep as an alternative approach)

A carry into a column is added to its top digit, in a substate (V5's get-digit1). A borrow is
taken from the next column in a substate (V5's compute-subtraction-borrow-result): that column's
top digit is decremented (`newd1`), borrowing in turn from the column after it when it is 0, and
then ten is added to the borrowing column's top digit. -/

/-- Add the carry to the top digit (a substate of get-digit1). -/
def addCarry : SubOp where
  name := "add-carry"
  params := [("f", addF)]
  propose := [.cmp "f" "d1" .eq (.get "up" "d1"), .cmp "f" "d2" .eq (.lit 1)]
  apply := [{ effects := [eff "up" "d1" (g "f" "sum"), eff "up" "cout" (g "f" "carry"), eff "up" "got1" (.lit 1)] }]
  doc := "Retrieve the top digit plus one."

/-- Borrow from column `m` (the next one): its own substate decrements m's top digit, borrowing
from the column after it first when that is 0, then adds ten to the borrowing level's top digit. -/
def borrowFrom : SubOp where
  name := "borrow-from"
  params := [("m", col)]
  propose := [.cmp "local" "issub" .eq (.lit 1), .cmp "local" "ten" .eq (.lit 0),
    .cmp "local" "d1" .lt (.get "local" "d2"), .cmp "m" "pos" .eq (.get "local" "nxt")]
  apply := []
  subs := ["borrow-from", "take-one", "write-borrow", "add-ten-up"]
  -- the lending column's original top digit: a column lends at most once per problem, and reading
  -- `newd1` (which write-borrow changes) made the learned chunk fire again on its own result
  locals := [("d1", g "m" "digit1"), ("d2", .lit 1), ("ten", .lit 0), ("nxt", .add (g "m" "pos") (.lit 1)),
    ("issub", .lit 1), ("r", .lit (-1)), ("wrote", .lit 0)]
  doc := "Borrow one from the next column (recursively)."

def takeOne : SubOp where
  name := "take-one"
  params := [("f", subF)]
  propose := [.cmp "local" "r" .eq (.lit (-1)), .cmp "f" "d1" .eq (.get "local" "d1"), .cmp "f" "d2" .eq (.get "local" "d2")]
  apply := [{ effects := [eff "local" "r" (g "f" "diff")] }]
  doc := "Retrieve the column's top digit minus one."

def writeBorrow : SubOp where
  name := "write-borrow"
  propose := [.cmp "local" "r" .ne (.lit (-1)), .cmp "local" "wrote" .eq (.lit 0)]
  apply := [{ effects := [eff "m" "newd1" (g "local" "r"), eff "local" "wrote" (.lit 1)] }]
  doc := "The column lent one: its top digit is now one less."

def addTenUp : SubOp where
  name := "add-ten-up"
  params := [("t", tenF)]
  propose := [.cmp "local" "wrote" .eq (.lit 1), .cmp "t" "n" .eq (.get "up" "d1")]
  apply := [{ effects := [eff "up" "d1" (g "t" "plus10"), eff "up" "ten" (.lit 1)] }]
  doc := "Retrieve the borrowing column's top digit plus ten."

def subLibV5 : List SubOp := [addCarry, borrowFrom, takeOne, writeBorrow, addTenUp]

/-- x of a column in V5's approach (from its top digit after borrows). -/
def x5 (op : Int) : Expr :=
  if op == 1 then .add (.add (g "c" "newd1") (g "c" "digit2")) (g "p" "carry")
  else .sub (g "c" "newd1") (g "c" "digit2")

def processColumnV5 (n : Nat) : Operator where
  name := "process-column"
  params := [("p", prob), ("c", col)]
  propose := [.cmp "p" "digits" .eq (.lit ((2 * n : Nat) : Int)), .cmp "c" "done" .ne (.get "p" "pid"),
    .noneSuch col [("pos", .lt, .get "c" "pos"), ("done", .ne, .get "p" "pid")]]
  -- the answer digit and the carry; a borrow changes the next columns (not stated here: specOwn)
  apply := [
    { guard := [.cmp "p" "operation" .eq (.lit 1)],
      effects := [eff "c" "result" (.sub (x5 1) (.mul (.div (x5 1) (.lit 10)) (.lit 10))),
        eff "p" "carry" (.div (x5 1) (.lit 10)), eff "c" "done" (g "p" "pid")] },
    { guard := [.cmp "p" "operation" .eq (.lit 2)],
      effects := [eff "c" "result" (.add (x5 2) (.mul (.div (.sub (.lit 9) (x5 2)) (.lit 10)) (.lit 10))),
        eff "c" "done" (g "p" "pid")] }]
  specOwn := true
  locals := [("d1", g "c" "newd1"), ("d2", g "c" "digit2"), ("got1", .sub (.lit 1) (g "p" "carry")),
    ("r", .lit (-1)), ("cout", .lit 0), ("ten", .lit 0), ("nxt", .add (g "c" "pos") (.lit 1)),
    ("issub", .sub (g "p" "operation") (.lit 1))]
  impl := .sub [
    { name := "get-digit1", propose := [.cmp "local" "got1" .eq (.lit 0)], apply := [], subs := ["add-carry"],
      doc := "Add the carry into the column to its top digit, in a substate." },
    { name := "add-digits", params := [("f", addF)],
      propose := [.cmp "p" "operation" .eq (.lit 1), .cmp "local" "got1" .eq (.lit 1), .cmp "local" "r" .eq (.lit (-1)),
        .cmp "f" "d1" .eq (.get "local" "d1"), .cmp "f" "d2" .eq (.get "local" "d2")],
      apply := [{ effects := [eff "local" "r" (g "f" "sum"), eff "local" "cout" (.add (g "local" "cout") (g "f" "carry"))] }],
      doc := "Retrieve the sum of the digits and its carry." },
    borrowFrom,
    { name := "subtract-digits", params := [("f", subF)],
      propose := [.cmp "p" "operation" .eq (.lit 2), .cmp "local" "r" .eq (.lit (-1)),
        .cmp "f" "d1" .eq (.get "local" "d1"), .cmp "f" "d2" .eq (.get "local" "d2")],
      apply := [{ effects := [eff "local" "r" (g "f" "diff")] }],
      doc := "Retrieve the difference of the digits (the top digit is no smaller)." },
    { name := "write-result", propose := [.cmp "local" "r" .ne (.lit (-1))],
      apply := [{
        effects := [eff "c" "result" (g "local" "r"), eff "p" "carry" (g "local" "cout"),
          eff "c" "done" (g "p" "pid")],
        write := [.text "column ", .val (g "c" "pos"), .text " op ", .val (g "p" "operation"), .text ": ",
          .val (g "c" "digit1"), .text " ", .val (g "c" "digit2"), .text " -> ", .val (g "local" "r"),
          .text " carry ", .val (g "local" "cout")] }],
      doc := "Write the answer digit and pass the carry to the next column (the results)." }]
  doc := "Work out one column, right to left, in a substate (V5's carries and borrows)."

def finishProblem (n : Nat) : Operator :=
  let cs := (List.range n).map fun i => s!"c{i + 1}"
  let row (a : String) : List Msg := (cs.reverse.map fun c => Msg.val (g c a))
  { name := "finish-problem"
    params := ("p", prob) :: cs.map (·, col)
    propose := [.cmp "p" "digits" .eq (.lit ((2 * n : Nat) : Int)), .noneSuch col [("done", .ne, .get "p" "pid")]] ++
      (cs.zip (List.range n)).map (fun (c, i) => .cmp c "pos" .eq (.lit ((i + 1 : Nat) : Int)))
    apply := [{
      effects := [eff "p" "count" (.sub (g "p" "count") (.lit 1)), eff "p" "pid" (.add (g "p" "pid") (.lit 1)),
        eff "p" "digits" (.lit 0), eff "p" "operation" (.lit 0)],
      write := [.text "problem op ", .val (g "p" "operation"), .text " top "] ++ row "digit1" ++
        [.text " bottom "] ++ row "digit2" ++ [.text " answer "] ++ row "result" ++ [.text " carry ", .val (g "p" "carry")] }]
    doc := "All columns have answers: write the problem and its answer, count it, and start the next." }

/-- The fact objects. -/
def facts : List (String × ObjPat) :=
  let r (k : Nat) : List Int := (List.range k).map (fun (i : Nat) => (i : Int))
  (r 10).map (fun d => ("digit", [("val", d)])) ++
  ((r 10).flatMap fun a => (r 11).map fun b =>
    ("add-fact", [("d1", a), ("d2", b), ("sum", (a + b) % 10), ("carry", (a + b) / 10)])) ++
  ((r 20).flatMap fun a => ((r 11).filter (· ≤ a)).map fun b =>
    ("sub-fact", [("d1", a), ("d2", b), ("diff", a - b)])) ++
  (r 10).map (fun d => ("inc-fact", [("n", d), ("next", d + 1)])) ++
  (r 10).map (fun d => ("ten-fact", [("n", d), ("plus10", d + 10)]))

def assumptions : List Assumption := [
  { id := "A1", text := "The task: generate random n-column addition or subtraction problems (subtraction answers positive), solve each column right to left by retrieving digit facts, count the problems; halt when the count reaches 0 (V5 count 10000 and stop-arithmetic). Variant `arithmetic`: 3 columns, 10000 problems." },
  { id := "A2", text := "Problem generation is done by top-level operators chosen at random (choose-operation, generate-digit1, generate-digit2), not in V5's generate-problem substate: a substate whose sub-operators are chosen at random has no specified effect to refine (the problem made is random). Same choices, one fewer decision per problem and no generation chunks." },
  { id := "A3", text := "The columns are three fixed objects reused for every problem (`gen1`/`gen2`/`done` hold the number of the problem they belong to), instead of a new linked column structure per problem (V5 generate-operation). The order of columns comes from `pos`." },
  { id := "A4", text := "The carry (borrow) into a column is a problem attribute, added to the bottom digit in a nested substate (`get-digit2` → `increment-digit2`). V5 adds a carry to the top digit (`get-digit1` substate) and does subtraction borrows by changing the next column's top digit, recursively (compute-subtraction-borrow-result). Here a borrow adds ten to the top digit in a nested substate (`borrow` → `add-ten`) and passes a borrow of 1 to the next column: the same answers, no recursion through columns." },
  { id := "A5", text := "Facts are the task's own objects (add-fact with bottom digit 0–10, sub-fact with top digit 0–19, inc-fact, ten-fact), made at initialization, instead of V5's generate-facts operator. The bottom digit after a carry or borrow can be 10, so the addition and subtraction tables include d2 = 10." },
  { id := "A6", text := "Operations are numbers (1 addition, 2 subtraction) and unset values are problem numbers rather than missing attributes. A carry out of the leftmost column is written but not given a new column (V5 new-column)." },
  { id := "A7", text := "Correctness is checked in Lean (every 2-column problem and a sample of 3-column problems) and by the harness from the problem and answer that finish-problem writes (as V5's finish-problem does), instead of V5's elaborations that recompute the answer and halt on a mismatch." }]

/-- The family: task name, columns, problems. -/
def mk (task : String) (n count : Nat) (v5 : Bool := false) : Agent where
  schema := schema task v5
  init := [("problem", [("operation", 0), ("carry", 0), ("count", (count : Int)), ("pid", 1), ("digits", 0)])] ++
    (List.range n).map (fun i => ("column", [("pos", ((i + 1 : Nat) : Int)), ("last", if i + 1 == n then 1 else 0),
      ("digit1", 0), ("digit2", 0), ("result", 0), ("gen1", 0), ("gen2", 0), ("done", 0)] ++
      (if v5 then [("newd1", 0)] else []))) ++ facts
  derive := []
  ops := [chooseOperation, generateDigit1 v5, generateDigit2, if v5 then processColumnV5 n else processColumn n, finishProblem n]
  subLib := if v5 then subLibV5 else subLib
  goal := { ty := prob, vals := [("count", 0)] }
  method := .random
  learning := .chunk []
  assumptions := assumptions

def variants : List (String × Agent × List String) := [
  ("arithmetic", mk "arithmetic" 3 10000, ["arithmetic V5", "arithmetic V6", "ChunkingDemoTests_Demo_Arithmetic V1"]),
  ("arithmetic-v5", mk "arithmetic" 3 10000 true, ["arithmetic V5 (its carries and borrows)"])]

/-- Every variant obeys the conventions. -/
theorem conventions : variants.all (fun v => check v.2.1 == []) = true := by native_decide

/-- One given problem (digits, ones first) with a carry (borrow) into the ones column: the
problem generated, ready to solve. -/
def given (n : Nat) (op : Int) (top bot : List Nat) (cin : Int := 0) (v5 : Bool := false) : Agent :=
  let a := mk "arithmetic" n 1 v5
  { a with init := [("problem", [("operation", op), ("carry", cin), ("count", 1), ("pid", 1), ("digits", ((2 * n : Nat) : Int))])] ++
    ((List.range n).zip (top.zip bot)).map (fun (i, t, b) => ("column", [("pos", ((i + 1 : Nat) : Int)), ("last", if i + 1 == n then 1 else 0),
      ("digit1", (t : Int)), ("digit2", (b : Int)), ("result", 0), ("gen1", 1), ("gen2", 1), ("done", 0)] ++
      (if v5 then [("newd1", (t : Int))] else []))) ++ facts }

/-- Solve a given problem concretely (every process-column carried out by its sub-operators,
nested ones included, and checked against its specified effect); the answer read off the columns
and the final carry (borrow). -/
def solve (n : Nat) (op : Int) (top bot : List Nat) (cin : Int := 0) (v5 : Bool := false) : Option Int :=
  ((given n op top bot cin v5).runConcrete (n + 2) 40).map fun st =>
    let res := (List.range n).map fun i =>
      ((st.find? fun ob => ob.lookup "pos" == some ((i + 1 : Nat) : Int) && (ob.lookup "done").isSome).bind (·.lookup "result")).getD 0
    let carry := ((st.find? fun ob => (ob.lookup "pid").isSome).bind (·.lookup "carry")).getD 0
    let v : Int := res.foldr (fun d acc => acc * 10 + d) 0
    if op == 1 then v + carry * (10 ^ n : Nat) else v - carry * (10 ^ n : Nat)

def digitsOf (n k : Nat) : List Nat := (List.range n).map fun i => k / 10 ^ i % 10

/-- Every column, complete: for every top and bottom digit and every carry (borrow) in, of either
operation, process-column's sub-operators (with the nested carry and borrow substates) give its
specified effect, and the answer digit with the carry (borrow) out is the right one:
d1 + d2 + c = r + 10·c' and d1 − d2 − c = r − 10·b'. -/
theorem every_column : ((List.range 10).all fun d1 => (List.range 10).all fun d2 => [0, 1].all fun c =>
    solve 1 1 [d1] [d2] c == some ((d1 + d2 : Nat) + c) &&
    solve 1 2 [d1] [d2] c == some ((d1 : Int) - d2 - c)) = true := by
  native_decide

/-- Whole problems: every two-column addition with a top number that is a multiple of 3, and
every two-column subtraction the generator can make with a top number that is a multiple of 3, is
solved correctly (3300 problems). -/
theorem two_columns : ((List.range 34).all fun i => (List.range 100).all fun b =>
    solve 2 1 (digitsOf 2 (3 * i)) (digitsOf 2 b) == some ((3 * i + b : Nat) : Int) &&
    (!(3 * i / 10 > b / 10) || solve 2 2 (digitsOf 2 (3 * i)) (digitsOf 2 b) == some (((3 * i : Nat) : Int) - b))) = true := by
  native_decide

/-- Three-column problems: a sample (top numbers every 37th, bottom numbers every 41st) is solved
correctly. -/
theorem three_columns : ((List.range 28).all fun i => (List.range 25).all fun j =>
    solve 3 1 (digitsOf 3 (37 * i)) (digitsOf 3 (41 * j)) == some ((37 * i + 41 * j : Nat) : Int) &&
    (!(37 * i / 100 > 41 * j / 100) ||
      solve 3 2 (digitsOf 3 (37 * i)) (digitsOf 3 (41 * j)) == some (((37 * i : Nat) : Int) - (41 * j : Nat)))) = true := by
  native_decide

/-- V5's approach: every three-column subtraction the generator can make with a top number that is
a multiple of 7 and a bottom number a multiple of 11 (borrows across zeros included, e.g. 700 −
11), and the same additions, are solved correctly. -/
theorem v5_three_columns : ((List.range 143).all fun i => (List.range 91).all fun j =>
    solve 3 1 (digitsOf 3 (7 * i)) (digitsOf 3 (11 * j)) 0 true == some ((7 * i + 11 * j : Nat) : Int) &&
    (!(7 * i / 100 > 11 * j / 100) ||
      solve 3 2 (digitsOf 3 (7 * i)) (digitsOf 3 (11 * j)) 0 true == some (((7 * i : Nat) : Int) - (11 * j : Nat)))) = true := by
  native_decide

end Agent.Arithmetic
