import Agent.DSL
import Agent.Sem

/-!
# Family: Blocks World

75 originals (step 6, `families/blocks-world`). The task: blocks on a table, each on the table or
on one other block; move a clear block onto the table or onto another clear block until the
desired stacking holds. The methods vary: simple search-control preferences (BW-Simple,
blocks-world-simple), one-step and deeper look-ahead with the selection library (BW-LA,
blocks-world-lookahead, the look-ahead demos), look-ahead with state evaluation and RL (BW-LA-state-
eval), hierarchical operators (move-block carried out by pick-up/put-down with a gripper;
BW-Hierarchical, blocks-world-hierarchical, hierarchical look-ahead), operator subgoaling (means-
ends analysis; BW-Op-Subgoal, blocks-world-operator-subgoaling, ±RL), RL (BW-RL, blocks-world-RL),
hierarchical RL, episodic memory. This file has the task and the variants built so far.

Representation: one object type for the blocks and the table, each with a `name`, `table` (1 for
the table) and a changing link `on` (what it rests on; the table rests on nothing). The originals
keep separate `^ontop` objects (`^top-block`, `^bottom-block`); `move-block` changes the bottom
block, here the moved block's `on`.
-/

namespace Agent.BlocksWorld

def obj : String := "object"

/-- Nothing is on `p`. -/
def clear (p : String) : Guard := .noneSuch obj [("on", .eq, .obj p)]

def clearAttr : AttrDecl where
  name := "clear"
  ty := .int
  derived := true
  doc := "1 when something can be put on it: the table, or a block with nothing on it"

def objAttrs (withClear : Bool) : List AttrDecl :=
  [{ name := "name", ty := .sym [], doc := "the block's name (A, B, …) or table" },
   { name := "table", ty := .int, doc := "1 for the table, 0 for a block" },
   { name := "on", ty := .obj obj, doc := "what it rests on (changes as blocks move; the table has none)" },
   { name := "in-place", ty := .int, derived := true,
     doc := "1 when it is where the goal wants it all the way down (the table always)" }] ++
  (if withClear then [clearAttr] else [])

def schema (task : String) (withClear : Bool := false) : Schema where
  task := task
  stateAttrs := [{ name := "object", ty := .obj obj, multi := true, doc := "The blocks and the table." }]
  types := [{ name := obj, key := some "name", attrs := objAttrs withClear }]

/-- "Clear" (the operator-subgoaling originals' `^clear`): the table, or an object with nothing on it. -/
def clearFlags : List Flag := [
  { ty := obj, attr := "clear", base := [.cmp "self" "table" .eq (.lit 1)], doc := "the table is clear" },
  { ty := obj, attr := "clear", base := [clear "self"], doc := "nothing is on it" }]

/-- "In place" (the originals' `^inplace-object`): the table is; a block is when it is on what the
goal puts it on and that is in place. -/
def inPlace : Flag where
  ty := obj
  attr := "in-place"
  base := [.cmp "self" "table" .eq (.lit 1)]
  via := "on"
  step := [.desired "self" "on" "below"]
  doc := "in place: the table, or on its desired object which is in place"

/-- Move a clear block onto the table or onto another clear block. -/
def moveBlock : Operator where
  name := "move-block"
  params := [("block", obj), ("dest", obj)]
  propose := [
    .cmp "block" "table" .eq (.lit 0),
    clear "block",
    .distinct "block" "dest",
    .cmp "block" "on" .ne (.obj "dest")]
  proposeOr := [
    [.cmp "dest" "table" .eq (.lit 1)],
    [.cmp "dest" "table" .eq (.lit 0), clear "dest"]]
  apply := [{ effects := [{ obj := "block", attr := "on", val := .obj "dest" }] }]
  doc := "Move a clear block onto the table or onto another clear block."

/-- move-block for operator subgoaling (the operator-subgoaling originals): proposed whenever it is
relevant (a block, a different destination it is not already on); its preconditions — the block
and the destination are clear — are what its substate works on. -/
def moveBlockOpSub : Operator where
  name := "move-block"
  params := [("block", obj), ("dest", obj)]
  propose := [.cmp "block" "table" .eq (.lit 0), .distinct "block" "dest", .cmp "block" "on" .ne (.obj "dest")]
  pre := [.flag "block" "clear" true, .flag "dest" "clear" true]
  pregoals := [("clear", "block"), ("clear", "dest")]
  apply := [{ effects := [{ obj := "block", attr := "on", val := .obj "dest" }] }]
  doc := "Move a block onto the table or onto another block; both must be clear."

/-- The operator-subgoaling originals' search control (wants: the substate's goals). -/
def opSubControl : List Pref := [
  { name := "avoid-clobbering", op := "move-block", value := .worst, sameAsLast := [],
    guard := [.wants "clear" "dest" none], doc := "Do not put a block on something the subgoal wants clear." },
  { name := "prefer-ontop", op := "move-block", value := .best, sameAsLast := [],
    guard := [.desired "block" "on" "dest"], doc := "Prefer a move the goal asks for." },
  { name := "prefer-clearing", op := "move-block", value := .best, sameAsLast := [],
    guard := [.wants "clear" "block" (some "on")], doc := "Prefer moving the block that is on something the subgoal wants clear." }]

/-- An instance: blocks with what each starts on, and the desired `on` of each block. -/
structure Instance where
  start : List (String × String)
  goal : List (String × String)

/-- The operator-subgoaling originals' instance: A on B, B and C on the table; goal A on B on C. -/
def threeOpSub : Instance := { start := [("A", "B"), ("B", "table"), ("C", "table")],
                               goal := [("A", "B"), ("B", "C"), ("C", "table")] }

/-- The originals' three-block instance: C on A, A and B on the table; goal A on B on C. -/
def three : Instance := { start := [("A", "table"), ("B", "table"), ("C", "A")],
                          goal := [("A", "B"), ("B", "C"), ("C", "table")] }

/-- The originals' five-block instance (BW-Simple, blocks-world-simple): C on A, A and D on the
table, E on D, B on E; goal A on B on C on D on E. -/
def five : Instance := { start := [("A", "table"), ("B", "E"), ("C", "A"), ("D", "table"), ("E", "D")],
                         goal := [("A", "B"), ("B", "C"), ("C", "D"), ("D", "E"), ("E", "table")] }

/-- The search control of the simple originals (P6, P7): moving a block that is not in place
onto the table is best; moving a block onto the in-place object the goal puts it on is better
than any other move. -/
def simpleControl : List Pref := [
  { name := "out-of-place-to-table", op := "move-block", value := .best, sameAsLast := [],
    guard := [.flag "block" "in-place" false, .cmp "dest" "table" .eq (.lit 1)],
    doc := "Move a block that is not in place to the table." },
  { name := "onto-desired-in-place", op := "move-block", value := .better, sameAsLast := [],
    guard := [.flag "dest" "in-place" true, .desired "block" "on" "dest"],
    doc := "Move a block onto what the goal puts it on, when that is in place." }]

/-- The search control of the look-ahead originals: never move the same block twice in a row. -/
def notTwice : List Pref := [
  { name := "reject-twice", op := "move-block", value := .reject, sameAsLast := [("block", "block")],
    inLookahead := true, doc := "In look-ahead, do not move the block just moved." }]

def assumptions : List Assumption := [
  { id := "A1", text := "Representation: one object type for blocks and the table, with `name`, `table` (1 for the table) and a changing link `on`. The originals keep `^ontop` objects (`^top-block`, `^bottom-block`) and `^type block/table`; `move-block` changes an ontop's bottom block, here the moved block's `on` (a changing link, `block.on := dest`)." },
  { id := "A2", text := "move-block(block, dest): proposed when the block is clear and not already on dest, and dest is the table or another clear block (two proposal rules, disjoint). The originals elaborate `^clear` (blocks with nothing on them, and always the table) and propose from it." },
  { id := "A3", text := "Goal: the desired `on` of every block, as `^desired` links to the task's own objects (the originals' desired ontops); success halts at the top state." },
  { id := "A5", text := "Simple variants: the originals' P6 (moving a block that is not in place to the table is best) and P7 (moving a block onto the in-place object the goal puts it on is better than every other move, binary preferences); \"in place\" is a derived flag (elaborated recursively along `on`, as the originals' `^inplace-object`). The originals elaborate success from in-place objects; here the goal is the desired links. blocks-world V2 also has three RL template rules with no reward or RL settings; they are dropped." },
  { id := "A4", text := "Look-ahead variant: the selection library, no duplicate-state detection (the originals have none), chunking on. As in the originals, moving the block just moved is rejected inside look-ahead states only (at the top state it may be the only move)." }]

def mk (task : String) (inst : Instance) (method : Method) (prefs : List Pref) (learning : Learning)
    (opsub : Bool := false) : Agent where
  schema := schema task opsub
  init := []
  objs := { holder := "object", name := "table", vals := [("table", 1)] } ::
    inst.start.map fun (b, on) => { holder := "object", name := b, vals := [("table", 0)], links := [("on", on)] }
  derive := []
  ops := [if opsub then moveBlockOpSub else moveBlock]
  goal := { ty := obj, vals := [], links := inst.goal.map fun (b, on) => (b, "on", on) }
  constraints := []
  flags := inPlace :: (if opsub then clearFlags else [])
  subgoaling := opsub
  prefs := prefs
  method := method
  learning := learning
  assumptions := assumptions

def variants : List (String × Agent × List String) := [
  ("blocks-world-operator-subgoaling", mk "blocks-world" threeOpSub .random opSubControl .none true,
    ["blocks-world-operator-subgoaling V1, V3, V6", "BW-Op-Subgoal V1", "FunctionalTests_testBlocksWorldOperatorSubgoaling V1"]),
  ("blocks-world-operator-subgoaling-chunk", mk "blocks-world" threeOpSub .random opSubControl (.chunk []) true,
    ["blocks-world-operator-subgoaling V4", "ChunkingDemoTests_Demo_Blocks_World_Operator_Subgoaling V1"]),
  ("blocks-world-simple", mk "blocks-world" five .random simpleControl .none,
    ["BW-Simple V1, V2", "blocks-world-simple V2–V4"]),
  ("blocks-world-simple-3", mk "blocks-world" three .random simpleControl .none,
    ["blocks-world V2, V3"]),
  ("blocks-world-look-ahead", mk "blocks-world" three (.lookahead [] none .off) notTwice (.chunk []),
    ["blocks-world-lookahead V1–V4", "BW-LA V1, V2", "BW-LA-X V1", "blocks-world-look-ahead V1, V2",
     "ChunkingDemoTests_Demo_Blocks_World_Look_Ahead V1", "FunctionalTests_testBlocksWorldLookAhead V1"])]

/-- Every variant obeys the conventions. -/
theorem conventions : variants.all (fun v => check v.2.1 == []) = true := by decide

/-- The three-block instance: three moves (C to the table, B onto C, A onto B), no fewer. -/
theorem three_shortest : ((mk "bw" three .random [] .none).bfs 4).1.map List.length = some 3 := by native_decide

/-- The five-block instance: six moves at least (C, B and E must leave their places first). -/
theorem five_shortest : ((mk "bw" five .random [] .none).bfs 7).1.map List.length = some 6 := by native_decide

/-- Operator subgoaling decides every step of its three-block instance: 3 moves (A to the table,
B onto C, A onto B), each choice left unique by the preferences. -/
theorem opsub_three : (mk "bw" threeOpSub .random opSubControl .none true).runOpSub 30 = some 3 := by native_decide

/-- The simple control decides every step of the three-block instance: following it, the goal is
reached in 3 moves with no random choice. -/
theorem simple_three : (mk "bw" three .random simpleControl .none).runPrefs 10 = some 3 := by native_decide

end Agent.BlocksWorld
