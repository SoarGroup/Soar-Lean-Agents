import Agent.DSL
import Agent.Sem

/-!
# Family: Eight and Fifteen Puzzle

Originals (step 6, `families/eight-puzzle`): eight-puzzle V1–V5, eight-puzzle-desired-binding V1,
FunctionalTests_testEightPuzzle V1, ChunkingDemoTests_Demo_Eight_Puzzle V1, fifteen-puzzle V1–V4.
All share one design: a board of cells (each linked to its neighbours) holding tiles and a
blank; one operator, move-tile, slides a tile next to the blank into it; a tie among the moves is
resolved by one-step look-ahead with Soar's selection library, evaluating the state after a move
numerically by the moved tile (+1 if it is now in its desired cell, −1 if it left its desired cell,
0 otherwise); the move that would put the last moved tile back is rejected; chunking is on. The
instances: eight puzzle (3×3, one start), fifteen puzzle (4×4, one start). Differences among the
originals are representation or settings: eight-puzzle-desired-binding elaborates each cell's
desired tile; eight-puzzle V2 gives an expected value (numeric-indifferent preferences) instead of
a numeric value and a reward at the goal, with RL off.

Not replaced: ChunkingDemoTests_Demo_Eight_Puzzle_expected V1 (a file of expected chunks, not an
agent), load-8p V1 (a language-comprehension agent that reads the words "eight puzzle", misfiled).
-/

namespace Agent.EightPuzzle

def tile : String := "tile"
def cell : String := "cell"

def binding : String := "binding"

def schema (task : String) : Schema where
  task := task
  stateAttrs := [
    { name := "tile", ty := .obj tile, multi := true, doc := "The tiles and the blank (tile 0)." },
    { name := "cell", ty := .obj cell, multi := true, doc := "The cells of the board." },
    { name := "binding", ty := .obj binding, multi := true, doc := "Which tile is in which cell: one per cell." }]
  types := [
    { name := tile, key := some "number",
      attrs := [
        { name := "name", ty := .sym [], doc := "the tile's name (t0 the blank, t1, …)" },
        { name := "number", ty := .int, doc := "the tile's number; 0 is the blank" }] },
    { name := cell, key := some "id",
      attrs := [
        { name := "name", ty := .sym [], doc := "the cell's name (c11, …)" },
        { name := "id", ty := .int, doc := "row × 10 + column" },
        { name := "neighbor", ty := .obj cell, multi := true, doc := "the cells next to it" }] },
    { name := binding, key := some "id",
      attrs := [
        { name := "name", ty := .sym [], doc := "the binding's name (b11, …)" },
        { name := "id", ty := .int, doc := "its cell's id" },
        { name := "cell", ty := .obj cell, doc := "the cell" },
        { name := "tile", ty := .obj tile, doc := "the tile in it (changed by moves)" }] }]

/-- Slide tile `t`, bound to cell `from`, into the blank's cell `to`, next to it: the two bindings
swap their tiles. -/
def moveTile : Operator where
  name := "move-tile"
  params := [("t", tile), ("k", tile), ("bt", binding), ("bb", binding), ("from", cell), ("to", cell)]
  propose := [
    .cmp "t" "number" .ne (.lit 0),
    .cmp "k" "number" .eq (.lit 0),
    .link "bt" "tile" "t", .link "bb" "tile" "k",
    .link "bt" "cell" "from", .link "bb" "cell" "to",
    .link "from" "neighbor" "to"]
  apply := [{ effects := [
    { obj := "bt", attr := "tile", val := .obj "k" },
    { obj := "bb", attr := "tile", val := .obj "t" }] }]
  doc := "Slide a tile next to the blank into the blank's cell."

def cname (r c : Nat) : String := s!"c{r}{c}"

/-- The cells of an `n`×`n` board, named `c<row><column>`, each linked to its neighbours. -/
def cells (n : Nat) : List Named :=
  let ids := (List.range n).flatMap fun r => (List.range n).map fun c => (r + 1, c + 1)
  ids.map fun (r, c) =>
    let nb := [(r - 1, c), (r + 1, c), (r, c - 1), (r, c + 1)].filter fun (r', c') =>
      1 ≤ r' && r' ≤ n && 1 ≤ c' && c' ≤ n && (r', c') != (r, c)
    { holder := "cell", name := cname r c, vals := [("id", (r * 10 + c : Nat))],
      links := nb.map fun (r', c') => ("neighbor", cname r' c') }

/-- The tiles `t0` (the blank) … `t<n²−1>`. -/
def tileObjs (n : Nat) : List Named :=
  (List.range (n * n)).map fun (k : Nat) => { holder := "tile", name := s!"t{k}", vals := [("number", (k : Int))] }

/-- A board as rows of tile numbers (0 the blank) → (binding name, tile name) per cell. -/
def placements (rows : List (List Nat)) : List (String × String) :=
  (rows.zip (List.range rows.length)).flatMap fun (row, r) =>
    (row.zip (List.range row.length)).map fun (t, c) => (s!"b{r + 1}{c + 1}", s!"t{t}")

/-- The bindings of a start board. -/
def bindings (rows : List (List Nat)) : List Named :=
  (rows.zip (List.range rows.length)).flatMap fun (row, r) =>
    (row.zip (List.range row.length)).map fun (t, c) =>
      { holder := "binding", name := s!"b{r + 1}{c + 1}", vals := [("id", ((r + 1) * 10 + (c + 1) : Nat))],
        links := [("cell", cname (r + 1) (c + 1)), ("tile", s!"t{t}")] }

/-- The originals' eight-puzzle start and goal (rows c1x, c2x, c3x). -/
def eightStart : List (List Nat) := [[2, 1, 7], [8, 6, 0], [3, 4, 5]]
def eightGoal : List (List Nat) := [[1, 8, 7], [2, 0, 6], [3, 4, 5]]
/-- The originals' fifteen-puzzle start and goal. -/
def fifteenStart : List (List Nat) := [[2, 1, 7, 8], [6, 15, 3, 4], [5, 9, 10, 11], [12, 13, 14, 0]]
def fifteenGoal : List (List Nat) := [[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12], [13, 14, 15, 0]]

/-- The originals' evaluation of a tried move, by the moved tile: the binding it moved into now
holds its desired tile (+1), or the binding it left held it as desired (−1). -/
def byMovedTile (expected : Bool := false) : Score :=
  { ty := binding, delta := some { op := "move-tile", obj := "bb", attr := "tile", old := ("bt", "t"), links := true },
    expected := expected }

/-- The originals' search control: never move back the tile just moved. -/
def rejectInverse : List Pref := [
  { name := "reject-inverse", op := "move-tile", value := .reject, sameAsLast := [("t", "t")],
    doc := "Do not slide the tile just moved straight back." }]

def assumptions : List Assumption := [
  { id := "A1", text := "Representation as the originals (JL, 7 Nov 2026: relations that operators change are explicit on the state, pointing to their arguments — STA-030): one binding per cell (`^binding`) pointing to its cell and to the tile in it; cells are named objects with static `neighbor` links; tiles are named objects (t0 the blank) with their number. The originals also keep `^blank-cell` and name tiles by number." },
  { id := "A2", text := "One operator, move-tile(t, k, bt, bb, from, to): tile t (in binding bt, cell from) and the blank k (in bb, cell to, a neighbour of from) swap bindings. The originals' operator names only the two cells (`^tile-cell`, `^blank-cell`) and finds the bindings when applying it." },
  { id := "A3", text := "The goal is the originals' desired board (every binding holds its desired tile, the blank included), a `^desired` structure of bindings; success halts at the top state (the originals' top-goal*halt*success)." },
  { id := "A4", text := "Search control: the move that slides the tile just moved straight back is rejected (the originals reject an operator whose tile-cell is the state's `^tile-cell`, the cell the last tile came from — the same move). This uses the last-move record (`^last-move`) instead of `^tile-cell`." },
  { id := "A5", text := "Look-ahead: one step, Soar's selection library; the tried state is evaluated by the moved tile: +1 if it is now in its desired cell, −1 if it was in its desired cell before the move, 0 otherwise (the originals' three evaluation rules; their 0 rule is stated more indirectly). No duplicate-state detection (the originals have none)." },
  { id := "A6", text := "eight-puzzle V2 gives the evaluation as `^expected-value` (numeric-indifferent preferences, a probabilistic choice; what RL rules are later made from) instead of `^numeric-value` (compared values, binary preferences): variant eight-puzzle-expected-value (JL, 7 Nov 2026: keep it). V2's reward of 1 at the goal, with RL off, is left out." },
  { id := "A7", text := "Chunking on (`chunk always`); the fifteen-puzzle V3 singleton declarations (cell, tile, blank-cell, tile-cell, problem-space) are dropped (singletons are the default in 9.6.5); the harness sets the random seed after loading (several originals set srand 1)." }]

/-- The family: board size, start and goal boards; `expected`: evaluations as expected values. -/
def mk (task : String) (n : Nat) (start goal : List (List Nat)) (expected : Bool := false) : Agent where
  schema := schema task
  init := []
  objs := cells n ++ tileObjs n ++ bindings start
  derive := []
  ops := [moveTile]
  goal := { ty := binding, vals := [], links := (placements goal).map fun (b, t) => (b, "tile", t) }
  prefs := rejectInverse
  method := .lookahead [] none .off (some (byMovedTile expected))
  learning := .chunk []
  assumptions := assumptions

def variants : List (String × Agent × List String) := [
  ("eight-puzzle", mk "eight-puzzle" 3 eightStart eightGoal,
    ["eight-puzzle V1", "eight-puzzle V3", "eight-puzzle V4", "eight-puzzle V5",
     "eight-puzzle-desired-binding V1", "FunctionalTests_testEightPuzzle V1",
     "ChunkingDemoTests_Demo_Eight_Puzzle V1"]),
  ("eight-puzzle-expected-value", mk "eight-puzzle" 3 eightStart eightGoal true, ["eight-puzzle V2"]),
  ("fifteen-puzzle", mk "fifteen-puzzle" 4 fifteenStart fifteenGoal,
    ["fifteen-puzzle V1", "fifteen-puzzle V2", "fifteen-puzzle V3", "fifteen-puzzle V4"])]

/-- Every variant obeys the conventions. -/
theorem conventions : variants.all (fun v => check v.2.1 == []) = true := by native_decide

/-- The eight-puzzle instance: the shortest solution has 5 moves (the originals and the
regenerated agent take 5–9). -/
theorem eight_shortest : ((mk "eight-puzzle" 3 eightStart eightGoal).bfs 6).1.map List.length = some 5 := by
  native_decide


end Agent.EightPuzzle
