import Agent.DSL
import Agent.Sem
/-!
# Graph search — the task, without generated variants

Derived on 6 November 2026 from the 5 Graph search task agents in the agent library: graph-search
V2, V3, graph-search-smem V1, V2, and Soar's chunking demo ChunkingDemoTests_Demo_Graph_Search.

The task: a robot at waypoint W1 of a map of 21 waypoints (coordinates in metres, directed `^next`
links) must visit a mission's waypoints in order. graph-search V2: W14, W16, W20 (69 links).
graph-search V3 and the chunking demo: a tour of 23 locations (W10, W14, W11, …, W14, W1), V3 with
2 more links (W12 → W14, W12 → W18). The smem versions keep the map and the mission in semantic
memory.

The method, in all of them: one `go-to-location` operator per mission leg, carried out in its
operator no-change substate by `go-to-waypoint` operators (one per outgoing link of the current
waypoint); their tie is resolved by look-ahead with an A*-style evaluation (path cost so far plus
straight-line distance to the target, `compute-range` on float coordinates, estimates revised and
passed up), through a locally modified selection library (70 of its 73 rules differ from the
9.6.5 library); chunking; an RL reward when a leg's target is reached (RL is never turned on).

No original is replaced. A faithful variant needs constructs the DSL does not have, none small:
* sub-operators with their own parameters (go-to-waypoint's next waypoint); `Impl.sub`
  sub-operators only have their parent's parameters;
* float values and the `compute-range` RHS function (the DSL is integer only);
* an A*-style look-ahead evaluation (path cost accumulated over the look-ahead, a heuristic
  estimate, comparison of total estimates across tied operators, revision of a superstate's
  estimate): the DSL's look-ahead is the 9.6.5 library as is, with symbolic or numeric state
  evaluations only (JL: the default library as is);
* for the smem versions, a semantic-memory construct (the map and mission stored and retrieved).
A depth-first look-ahead variant over the same map could be generated, but it would be a
different method, not a replacement.

Behaviour in Soar 9.6.5 (3000 decisions): graph-search V2 completes its mission and halts (195
decisions); V3 does not finish its 23 legs within 3000 decisions (15 legs started); the chunking
demo runs (search traced) without finishing within 400; graph-search-smem V1 and V2 never start
the mission: state no-changes nest until Soar's goal-depth limit (107 decisions) and it halts.

What is here: the task as data (links as `edge` objects, the mission as `leg` objects), so the
task's properties are proved and a later variant can use it.
-/
namespace Agent.GraphSearch

/-- The links of graph-search V2 (and the chunking demo): (from, to) waypoint numbers. -/
def edgesV2 : List (Int × Int) := [(1, 2), (1, 3), (1, 13), (2, 1), (2, 3), (2, 5), (2, 8), (2, 11), (2, 13),
  (3, 1), (3, 2), (3, 4), (3, 5), (3, 8), (4, 3), (4, 5), (5, 2), (5, 3), (5, 4), (5, 6), (5, 7), (5, 8),
  (6, 5), (6, 7), (7, 5), (7, 6), (7, 8), (8, 2), (8, 3), (8, 5), (8, 7), (8, 9), (8, 11), (8, 14), (9, 8),
  (9, 10), (9, 11), (10, 9), (10, 11), (11, 2), (11, 8), (11, 9), (11, 10), (11, 12), (11, 13), (12, 11),
  (12, 13), (13, 1), (13, 2), (13, 8), (13, 11), (13, 12), (14, 8), (14, 15), (14, 21), (15, 14), (15, 16),
  (16, 15), (16, 17), (17, 16), (17, 18), (18, 17), (18, 19), (19, 18), (19, 20), (20, 19), (20, 21),
  (21, 14), (21, 20)]

/-- graph-search V3 has two more links. -/
def edgesV3 : List (Int × Int) := edgesV2 ++ [(12, 14), (12, 18)]

def missionV2 : List Int := [14, 16, 20]
/-- graph-search V3 and the chunking demo. -/
def missionTour : List Int := [10, 14, 11, 5, 14, 7, 8, 9, 2, 11, 12, 13, 8, 14, 10, 14, 17, 18, 15, 20, 21, 14, 1]
/-- The chunking demo's tour differs from V3's in two legs (W16 for V3's second W14, W12 for W15). -/
def missionDemo : List Int := [10, 14, 11, 5, 14, 7, 8, 9, 2, 11, 12, 13, 8, 14, 10, 16, 17, 18, 12, 20, 21, 14, 1]

def schema : Schema where
  task := "graph-search"
  stateAttrs := [
    { name := "robot", ty := .obj "robot", multi := true, doc := "The robot." },
    { name := "edge", ty := .obj "edge", multi := true, doc := "The links of the map." },
    { name := "leg", ty := .obj "leg", multi := true, doc := "The mission, one leg per location." }]
  types := [
    { name := "robot", attrs := [
        { name := "at", ty := .int, doc := "the waypoint the robot is at" },
        { name := "legs-done", ty := .int, doc := "mission legs completed" },
        { name := "next-leg", ty := .int, derived := true, doc := "the leg being travelled" }] },
    { name := "edge", attrs := [
        { name := "from", ty := .int, doc := "waypoint" }, { name := "to", ty := .int, doc := "waypoint" }] },
    { name := "leg", attrs := [
        { name := "order", ty := .int, doc := "position in the mission" },
        { name := "target", ty := .int, doc := "the waypoint to reach" }] }]

/-- Move along a link; when it reaches the current leg's target, that leg is done. -/
def goToWaypoint : Operator where
  name := "go-to-waypoint"
  params := [("robot", "robot"), ("edge", "edge"), ("leg", "leg")]
  propose := [.cmp "edge" "from" .eq (.get "robot" "at"), .cmp "leg" "order" .eq (.get "robot" "next-leg")]
  apply := [
    { guard := [.cmp "edge" "to" .eq (.get "leg" "target")],
      effects := [{ obj := "robot", attr := "at", val := .get "edge" "to" },
                  { obj := "robot", attr := "legs-done", val := .add (.get "robot" "legs-done") (.lit 1) }] },
    { guard := [.cmp "edge" "to" .ne (.get "leg" "target")],
      effects := [{ obj := "robot", attr := "at", val := .get "edge" "to" }] }]

def assumptions : List Assumption := [
  { id := "A1", text := "The task: start at W1; visit the mission's waypoints in order by moving along the map's directed links; done when every leg is done. A waypoint passed before its turn does not count (the originals' go-to-location tests only its own target).", status := "accepted" },
  { id := "A2", text := "Representation for the task only: waypoints by number, links as `edge` objects, the mission as `leg` objects with their order; coordinates are left out (only needed for the A* evaluation, which is not modelled).", status := "accepted" }]

def task (edges : List (Int × Int)) (mission : List Int) : Agent where
  schema := schema
  init := [("robot", [("at", 1), ("legs-done", 0)])] ++
    edges.map (fun (f, t) => ("edge", [("from", f), ("to", t)])) ++
    (mission.zip (List.range mission.length)).map (fun (w, i) => ("leg", [("order", (i : Int) + 1), ("target", w)]))
  derive := [{ ty := "robot", attr := "next-leg", val := .add (.get "self" "legs-done") (.lit 1) }]
  ops := [goToWaypoint]
  goal := { ty := "robot", vals := [("legs-done", mission.length)] }
  method := .random
  assumptions := assumptions

/-- The task descriptions obey the conventions (no variant is generated from them). -/
theorem conventions : [task edgesV2 missionV2, task edgesV3 missionTour, task edgesV2 missionDemo].all
    (fun a => check a == []) = true := by decide

/-- graph-search V2's mission W14, W16, W20 from W1 takes at least 9 moves (W1 → W2 → W8 → W14 →
W15 → W16 → W17 → W18 → W19 → W20 is 9). -/
theorem v2_shortest : ((task edgesV2 missionV2).bfs 12).1.map List.length = some 9 := by native_decide

/-- V3's 23-location tour takes at least 44 moves with V3's map. -/
theorem v3_shortest : ((task edgesV3 missionTour).bfs 60).1.map List.length = some 44 := by native_decide

/-- The chunking demo's tour takes at least 50 moves. -/
theorem demo_shortest : ((task edgesV2 missionDemo).bfs 60).1.map List.length = some 50 := by native_decide

end Agent.GraphSearch
