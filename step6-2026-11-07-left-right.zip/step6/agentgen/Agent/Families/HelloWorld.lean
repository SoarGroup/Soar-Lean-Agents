import Agent.DSL
import Agent.Sem
/-!
# Hello world — one description for the family

Derived on 6 November 2026 from the 4 Hello world agents in the agent library (Soar Tutorial
chapters 2–3): hello-world-operator V1/V2 (an operator, proposed on any state, whose apply rule
writes "Hello World" and halts) and hello-world-rule V1/V2 (one rule that writes and halts on any
state, no operator). V1 and V2 of each differ only in comments and blank lines.

The task is the same in all four: write "Hello World" once, then stop. Here it is written in the
conventions: the greeting is a task object whose `written` flag the operator sets while writing
the message; the goal is that the message has been written, and the agent halts at the top state
through the usual success rule. The rule versions are replaced too: writing and halting from an
elaboration rule (no operator) is not something the conventions allow (persistent effects and
actions come from operator application), and their task is the operator versions' task (A2).
-/
namespace Agent.HelloWorld

def schema : Schema where
  task := "hello-world"
  stateAttrs := [{ name := "greeting", ty := .obj "greeting", multi := true, doc := "The greeting to give." }]
  types := [{
    name := "greeting",
    attrs := [{ name := "written", ty := .int, doc := "1 once the greeting has been written, else 0" }] }]

/-- The one task operator: write the greeting. -/
def helloWorld : Operator where
  name := "hello-world"
  params := [("greeting", "greeting")]
  propose := [.cmp "greeting" "written" .eq (.lit 0)]
  apply := [{ effects := [{ obj := "greeting", attr := "written", val := .lit 1 }],
              write := [.text "Hello World"] }]
  doc := "Write \"Hello World\"."

def assumptions : List Assumption := [
  { id := "A1", text := "The task: write \"Hello World\" once and stop. The originals halt in the apply rule (operator versions) or in the rule itself; here the operator records that the greeting was written (`written` 0 → 1) and the goal (written = 1, a `^desired` structure) halts the agent at the top state, which also writes \"The problem has been solved.\"", status := "accepted" },
  { id := "A2", text := "hello-world-rule V1/V2 (a rule that writes and halts, no operator) are replaced by the operator variant: same task, and an action from an elaboration rule is outside the conventions. If JL wants the rule-only version kept as a teaching example, it needs an escape hatch (`Agent.raw`).", status := "accepted" },
  { id := "A3", text := "Representation: a `greeting` object with a `written` flag, needed because a goal is a pattern over task objects. The originals' proposal tested only `^type state` (any state, so also substates); here it tests the task state's name (convention).", status := "accepted" }]

def agent : Agent where
  schema := schema
  init := [("greeting", [("written", 0)])]
  derive := []
  ops := [helloWorld]
  goal := { ty := "greeting", vals := [("written", 1)] }
  constraints := [{ ty := "greeting", guard := [.cmp "self" "written" .ge (.lit 0), .cmp "self" "written" .le (.lit 1)], doc := "written is a flag" }]
  method := .random
  assumptions := assumptions

def variants : List (String × Agent × List String) := [
  ("hello-world", agent,
    ["hello-world-operator V1", "hello-world-operator V2", "hello-world-rule V1", "hello-world-rule V2"])]

/-- Every variant obeys the conventions. -/
theorem conventions : variants.all (fun v => check v.2.1 == []) = true := by decide

/-- One operator solves the task. -/
theorem shortest : (agent.bfs 3).1.map List.length = some 1 := by native_decide

/-- The greeting is written at most once: the flag stays 0 or 1 in every reachable state. -/
theorem constraints_hold : agent.constraintsHold 5 = true := by native_decide

end Agent.HelloWorld
