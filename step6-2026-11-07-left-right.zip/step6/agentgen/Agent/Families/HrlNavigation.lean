import Agent.DSL
/-!
# HRL navigation (taxi) — not replaced

Derived on 6 November 2026 from the 9 HRL navigation task agents in the agent library, all from
the taxi domain (knights-tour.zip, taxi/inheritance/taxi/…): flat-all, flat-phase,
flat-phase-regions, flat-smart, hrl-nav, hrl-nav-general, hrl-nav-max, hrl-nav-max-general and
hrl-full-max (V1 each).

The task (from the rules): a taxi with fuel on a grid picks up a passenger, carries it to its
destination and puts it down, refuelling when fuel is below 5. The agent senses through the
input link (`^view` per direction, `^self` with position, fuel, passenger, destination, `^cell`
with type and passenger), acts through output-link commands (`move ^direction`, `pickup`,
`putdown`, `fillup`) and is rewarded through the input link (`^self.reward` copied to the reward
link). All nine learn by RL over operator templates; they differ in the state abstraction the
templates test (flat-all: every feature; flat-phase: a derived phase — find/get passenger,
find/at destination, find fuel, fuel up; flat-smart: per action, the features relevant to it;
flat-phase-regions: phase plus quadrant/side/hemisphere templates for moves) and in task
hierarchy (hrl-nav and hrl-nav-general: get, put and refuel operators carried out in substates
with a shared navigate subtask; hrl-nav-max, hrl-nav-max-general and hrl-full-max: MAXQ-style,
with a `max` operator and its termination proposals).

No variant is generated and no original is replaced:
* The environment is not in the corpus. Everything the task is made of — the grid and its walls,
  where the passenger, destination and fuel station are, the effect of each command, fuel use and
  the rewards — lives in the simulator, which these agents only see through the input link. In
  Soar 9.6.5 without it the input link is empty: no move is ever proposed; the flat agents tie
  among pickup, putdown and fillup (no preferences without RL values) and the hierarchical ones
  have no proposal at all, and state no-changes nest until the run ends (101 decisions measured),
  so no task-level comparison is possible either.
* The DSL has no I/O construct yet (input-link perception, output-link commands with status, a
  reward from the environment); "Fixed I/O protocol" is reserved in DSL.lean.
* RL learning is not turned on in any of their sources (no `rl --set learning on`): the
  environment's harness must have set it.
What is needed: the taxi simulator (or its specification, to write one in the harness) and an I/O
construct; then the variants are the abstraction (which features RL templates test) and the
hierarchy (flat, get/put/refuel + navigate, MAXQ).
-/
namespace Agent.HrlNavigation

/-- No variants (see the module docstring). -/
def variants : List (String × Agent × List String) := []

end Agent.HrlNavigation
