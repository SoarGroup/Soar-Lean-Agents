import Agent.DSL
import Agent.Sem
/-!
# Knight's tour — counting closed tours by depth-first search with backtracking

Derived on 7 November 2026 from knights V1 and V2 (John Laird's experiments with search-control
strategies). A knight starts on square 23 of an n × n board and moves to unused squares a
knight's move away; when every square is used and the last one is a knight's move from the first,
a closed tour is found and counted. The search is depth-first: a dead end (no untried, unused
square to move to) backs up one move, marking the square left as tried from the square below.
Strategies add search control: prefer moves to squares with fewer exits (their degree, the number
of unused squares a move away), prefer a square with one exit, and back up early when two squares
next to the knight have one exit each (no tour can use both).

Variants: `knights-6` (6 × 6, V2's strategy level-5) and `knights-8` (8 × 8, V1's level-3).
-/
namespace Agent.Knights

def sq : String := "square"
def tourT : String := "tour"

def schema : Schema where
  task := "knights"
  stateAttrs := [
    { name := "square", ty := .obj sq, multi := true, doc := "The squares of the board." },
    { name := "tour", ty := .obj tourT, multi := true, doc := "The tour being built." }]
  types := [
    { name := sq, key := some "coord",
      attrs := [
        { name := "name", ty := .sym [], doc := "the square's name (b11, …)" },
        { name := "coord", ty := .int, doc := "row × 10 + column" },
        { name := "used", ty := .int, doc := "1 when the knight has been on it in the current path" },
        { name := "degree", ty := .int, doc := "its exits: unused squares a knight's move away" },
        { name := "odeg", ty := .int, doc := "its squares a knight's move away (the degree at the start)" },
        { name := "visit", ty := .int, doc := "the number of the move that reached it (each move has a new number)" },
        { name := "tried", ty := .int, multi := true, doc := "the visits of the squares on the path it was tried from and backed out of (a set)" },
        { name := "move", ty := .obj sq, multi := true, doc := "the squares a knight's move away" },
        { name := "prev", ty := .obj sq, doc := "the square the knight came from" }] },
    { name := tourT,
      attrs := [
        { name := "name", ty := .sym [], doc := "tour" },
        { name := "depth", ty := .int, doc := "squares in the current path" },
        { name := "moves", ty := .int, doc := "moves made so far (knight moves and backups)" },
        { name := "frame", ty := .int, doc := "the number of the last move (for visits)" },
        { name := "solutions", ty := .int, doc := "closed tours found" },
        { name := "goal", ty := .int, doc := "1 just after a tour is found (back up to look for the next)" },
        { name := "done", ty := .int, doc := "1 when the run is over" },
        { name := "at", ty := .obj sq, doc := "the knight's square" },
        { name := "first", ty := .obj sq, doc := "the starting square" }] }]

def g (o a : String) : Expr := .get o a
def eff (o a : String) (v : Expr) : Effect := { obj := o, attr := a, val := v }

/-- A search-control strategy (the originals' flags). -/
structure Strategy where
  /-- keep degrees up to date as squares are used and freed (degree-update-by-move) -/
  update : Bool
  /-- prefer the move whose square has the lower degree (select-operator-heuristic-based-on-degree-positive) -/
  lowDegree : Bool
  /-- prefer the move whose square had the lower degree at the start (V1's level-3) -/
  lowOriginal : Bool
  /-- a move to a square (not the first) with one exit is best; once it has been tried, back up
  (select-operator-prefer-degree-one) -/
  degreeOne : Bool
  /-- back up when two unused squares a move away have one exit each (multiple-connected-moves-degree-1) -/
  pruneTwo : Bool
  deriving DecidableEq, Repr

/-- Every square a knight's move from `src` gains `d` exits. -/
def degreeEach (src : String) (d : Int) : Each :=
  { var := "z", src := src, link := "move", effects := [eff "z" "degree" (.add (g "z" "degree") (.lit d))] }

def knightMove (st : Strategy) : Operator where
  name := "knight-move"
  params := [("t", tourT), ("c", sq), ("y", sq)]
  propose := [.cmp "t" "done" .eq (.lit 0), .link "t" "at" "c", .link "c" "move" "y",
    .cmp "y" "used" .eq (.lit 0), .cmp "y" "tried" .lacks (.get "c" "visit")]
  apply := [{
    effects := [eff "t" "at" (.obj "y"), eff "y" "used" (.lit 1), eff "y" "prev" (.obj "c"),
      eff "y" "visit" (.add (g "t" "frame") (.lit 1)), eff "t" "frame" (.add (g "t" "frame") (.lit 1)),
      eff "t" "depth" (.add (g "t" "depth") (.lit 1)), eff "t" "moves" (.add (g "t" "moves") (.lit 1))],
    each := if st.update then [degreeEach "y" (-1)] else [] }]
  doc := "Move the knight to an unused square a knight's move away, not yet tried from here."

/-- Backing up from `c`: its neighbours gain an exit (with degree updates) and lose the marks of
having been tried from `c`. -/
def freeEach (st : Strategy) : Each where
  var := "z"
  src := "c"
  link := "move"
  effects := (if st.update then [eff "z" "degree" (.add (g "z" "degree") (.lit 1))] else []) ++
    [{ obj := "z", attr := "tried", val := g "c" "visit", mode := .remove }]

def backup (n : Nat) (st : Strategy) : Operator where
  name := "backup"
  params := [("t", tourT), ("c", sq), ("p", sq)]
  propose := [.cmp "t" "done" .eq (.lit 0), .link "t" "at" "c", .link "c" "prev" "p", .distinct "c" "p"]
  proposeOr :=
    [[.linked "c" "move" sq [("used", .eq, .lit 0), ("tried", .lacks, .get "c" "visit")] 0],
     [.cmp "t" "goal" .eq (.lit 1)]] ++
    (if st.pruneTwo then [[.cmp "t" "depth" .lt (.lit ((n * n : Nat) : Int)),
      .linked "c" "move" sq [("used", .eq, .lit 0), ("degree", .eq, .lit 1)] 2]] else []) ++
    (if st.degreeOne then [[.linked "c" "move" sq [("tried", .eq, .get "c" "visit"), ("degree", .eq, .lit 1)] 1]] else [])
  apply := [{
    effects := [eff "t" "at" (.obj "p"), eff "c" "used" (.lit 0),
      { obj := "c", attr := "tried", val := g "p" "visit", mode := .add },
      eff "t" "depth" (.sub (g "t" "depth") (.lit 1)), eff "t" "moves" (.add (g "t" "moves") (.lit 1)),
      eff "t" "goal" (.lit 0)],
    -- the squares tried from here are free to be tried again on another path
    each := [freeEach st] }]
  doc := "Back up one move: free the knight's square and mark it tried from the square below."

def detectGoal (n : Nat) : Operator where
  name := "detect-goal"
  params := [("t", tourT), ("c", sq), ("f", sq)]
  propose := [.cmp "t" "done" .eq (.lit 0), .cmp "t" "goal" .eq (.lit 0),
    .cmp "t" "depth" .eq (.lit ((n * n : Nat) : Int)),
    .link "t" "at" "c", .link "t" "first" "f", .link "c" "move" "f"]
  apply := [{
    effects := [eff "t" "solutions" (.add (g "t" "solutions") (.lit 1)), eff "t" "goal" (.lit 1)],
    write := [.text "Success! ", .val (.add (g "t" "solutions") (.lit 1)), .text " ", .val (g "c" "coord")] }]
  doc := "Every square is used and the first is a knight's move away: a closed tour; count it."

def exhausted : Operator where
  name := "exhausted"
  params := [("t", tourT), ("c", sq)]
  propose := [.cmp "t" "done" .eq (.lit 0), .link "t" "at" "c", .link "t" "first" "c",
    .linked "c" "move" sq [("used", .eq, .lit 0), ("tried", .lacks, .get "c" "visit")] 0]
  apply := [{
    effects := [eff "t" "done" (.lit 1)],
    write := [.text "Search complete: ", .val (g "t" "solutions"), .text " solutions"] }]
  doc := "Back at the first square with nothing left to try: every tour has been found."

def finish (budget : Nat) : Operator where
  name := "finish-run"
  params := [("t", tourT)]
  propose := [.cmp "t" "done" .eq (.lit 0), .cmp "t" "moves" .ge (.lit (budget : Int))]
  apply := [{
    effects := [eff "t" "done" (.lit 1)],
    write := [.text "Run over: ", .val (g "t" "solutions"), .text " solutions"] }]
  doc := "The move budget is spent: end the run."

/-- A square (not the first) with one exit must be visited now or never. -/
def degreeOnePref : Pref where
  name := "degree-one"
  op := "knight-move"
  sameAsLast := []
  guard := [.cmp "y" "degree" .eq (.lit 1), .cmp "y" "coord" .ne (.lit 23)]
  value := .best

def bin (nm op : String) (than : List String) (versus : List Guard := []) (doc := "") : Pref :=
  { name := nm, op := op, sameAsLast := [], value := .better, than := than, versus := versus, doc := doc }

def prefs (st : Strategy) : List Pref :=
  [bin "finish-first" "finish-run" ["knight-move", "backup", "detect-goal"] [] "The run ends as soon as the budget is spent.",
   bin "goal-before-backup" "detect-goal" ["knight-move", "backup"],
   bin "backup-before-move" "backup" ["knight-move"]] ++
  (if st.lowDegree then [bin "lower-degree" "knight-move" ["knight-move"]
     [.cmp "y" "degree" .lt (.get "other-y" "degree")] "Warnsdorff's rule: fewer exits first."] else []) ++
  (if st.lowOriginal then [bin "lower-original-degree" "knight-move" ["knight-move"]
     [.cmp "y" "odeg" .lt (.get "other-y" "odeg")]] else []) ++
  (if st.degreeOne then [degreeOnePref] else [])

/-- The squares a knight's move from (r, c) on an n × n board. -/
def jumps (n r c : Nat) : List (Nat × Nat) :=
  let ds : List (Int × Int) := [(-2, -1), (-2, 1), (-1, -2), (-1, 2), (1, -2), (1, 2), (2, -1), (2, 1)]
  ds.filterMap fun (dr, dc) =>
    let r' := (r : Int) + dr; let c' := (c : Int) + dc
    if r' ≥ 1 && r' ≤ n && c' ≥ 1 && c' ≤ n then some (r'.toNat, c'.toNat) else none

def name (r c : Nat) : String := s!"b{r}{c}"

/-- The board: square 23 is the first, used. A degree counts the unused squares a move away and
the first square (the last move of a closed tour returns to it). -/
def board (n : Nat) : List Named :=
  ((List.range n).flatMap fun i => (List.range n).map fun j => (i + 1, j + 1)).map fun (r, c) =>
    let js := jumps n r c
    { holder := "square", name := name r c,
      vals := [("coord", ((r * 10 + c : Nat) : Int)), ("used", if (r, c) == (2, 3) then 1 else 0),
        ("degree", (js.length : Int)), ("odeg", (js.length : Int)), ("visit", if (r, c) == (2, 3) then 1 else 0),
],
      -- `prev` starts at the square itself (a link must exist to be replaced)
      links := js.map (fun (r', c') => ("move", name r' c')) ++ [("prev", name r c)] }

def assumptions : List Assumption := [
  { id := "A1", text := "The task: count closed knight's tours from square 23 of an n × n board by depth-first search with backtracking, within a budget of moves (knight moves and backups; V1/V2 move-count-max 1000000). Backtracking is the task's method, as the originals' backup operator; it is not the recovery from a failure state that ELB-014 rules out." },
  { id := "A2", text := "One run with one strategy per agent (a variant), instead of the originals' runs-per-level and chain of strategies (level-0 … level-6) in one agent. Repeated runs are the harness's seeds." },
  { id := "A3", text := "Every square's `prev` starts at itself (a link is replaced, never added), so backup needs prev ≠ the square. A move tried from a square and backed out of is remembered on the square tried, in its set `tried` of the visit numbers of the squares it was tried from (each move gets a new number), instead of the originals' `^moved` set of squares on the square tried from; the marks from a square are removed when the search backs up from it, as the originals do. The path is the squares' `prev` links instead of a `^move-sequence` stack. (A single `blocked` value instead of the set lost the mark of an earlier square on the path and found the same two tours over and over.)" },
  { id := "A4", text := "A square's degree counts the unused squares a move away and the first square, as in the originals (degrees start at the number of moves although the first square is used): for a closed tour the first square is the last move's exit, so its neighbours keep it as an exit. (Counting only unused squares, tried first, found no tours in 20000 decisions.) The originals' 6 × 6 board lists b52 twice for b44 (b56 missing) and their 8 × 8 board maps ^82 to b62; the board is computed here, correctly." },
  { id := "A5", text := "Pruning and search control are the originals' flags: V2's level-5 (degree update, lower degree first, a one-exit square best and back up once it has been tried, two one-exit squares next to the knight back up); V1's level-3 (degree update, lower original degree first, two one-exit squares back up). Rules for flags neither variant uses (multiple-moves-degree-1 over the board, distance-2, final-move-degree-0, degree-negative) are left out." },
  { id := "A6", text := "The search ends when the budget is spent (finish-run) or the first square has nothing left to try (exhausted); both write the count and halt. The originals print a summary per run and halt after the last strategy." }]

def tourObj : Named where
  holder := "tour"
  name := "tour"
  vals := [("depth", 1), ("moves", 0), ("frame", 1), ("solutions", 0), ("goal", 0), ("done", 0)]
  links := [("at", name 2 3), ("first", name 2 3)]

def mk (task : String) (n budget : Nat) (st : Strategy) : Agent where
  schema := { schema with task := task }
  init := []
  objs := board n ++ [tourObj]
  derive := []
  ops := [knightMove st, backup n st, detectGoal n, exhausted, finish budget]
  goal := { ty := tourT, vals := [("done", 1)] }
  prefs := prefs st
  method := .random
  assumptions := assumptions

def level5 : Strategy := { update := true, lowDegree := true, lowOriginal := false, degreeOne := true, pruneTwo := true }
def level3 : Strategy := { update := true, lowDegree := false, lowOriginal := true, degreeOne := false, pruneTwo := true }

def variants : List (String × Agent × List String) := [
  ("knights-6", mk "knights" 6 1000000 level5, ["knights V2"]),
  ("knights-8", mk "knights" 8 1000000 level3, ["knights V1"])]



/-! ## Checking the description: a run with ties broken by the first candidate -/

/-- Follow the preferences, breaking a tie by taking the first remaining candidate; the states
just after each closed tour is counted, and the final state. -/
def runFirst (ag : Agent) : Nat → TState → List TState → List TState × TState
  | 0, st, acc => (acc.reverse, st)
  | k + 1, st, acc =>
    if ag.isGoal st then (acc.reverse, st) else
    match ag.prefCands st none with
    | (o, _, st') :: _ => runFirst ag k st' (if o.name == "detect-goal" then st' :: acc else acc)
    | [] => (acc.reverse, st)

/-- A state holds a closed tour: following `prev` from the knight's square visits every square
once, each step a knight's move, and the last square is a knight's move from the first. -/
def validTour (n : Nat) (ag : Agent) (st : TState) : Bool :=
  let sqs := (ag.objsOf st sq)
  let coordOf (i : Nat) : Int := (((st[i]?).bind (·.lookup "coord")).getD 0)
  let tour := (st.find? fun ob => (ob.lookup "solutions").isSome).getD []
  let atI := ((tour.lookup "at").getD 0).toNat
  let rec walk : Nat → Nat → List Int → List Int
    | 0, _, acc => acc
    | k + 1, i, acc => match (st[i]?).bind (·.lookup "prev") with
      | some j => if coordOf i == 23 then coordOf i :: acc else walk k j.toNat (coordOf i :: acc)
      | none => coordOf i :: acc
  let path := walk (n * n + 1) atI []
  let knight (a b : Int) : Bool :=
    let dr := (a / 10 - b / 10).natAbs; let dc := (a % 10 - b % 10).natAbs
    (dr == 1 && dc == 2) || (dr == 2 && dc == 1)
  path.length == n * n && path.eraseDups.length == n * n && path.head? == some 23 &&
    (path.zip path.tail).all (fun (a, b) => knight a b) &&
    (match path.getLast? with | some l => knight l 23 | none => false) &&
    sqs.all (fun x => x.lookup "used" == some 1)

def conventionsOk : Bool := variants.all (fun v => check v.2.1 == [])

theorem conventions : conventionsOk = true := by native_decide

def sixCheck : Bool :=
  let ag := mk "knights" 6 1000000 level5
  let found := (runFirst ag 400 ag.initial []).1
  found.length > 0 && found.all (validTour 6 ag)

theorem six_finds_valid_tours : sixCheck = true := by
  native_decide

end Agent.Knights
