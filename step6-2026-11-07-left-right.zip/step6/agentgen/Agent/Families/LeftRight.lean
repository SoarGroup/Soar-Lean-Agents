import Agent.DSL
import Agent.Sem
/-!
# Left-right — a one-step reinforcement-learning task

Derived on 7 November 2026 from left-right V1 (John Laird, 22 January 2026, "Simple example of RL
with choosing left (−1) and right (+1)"). From the start the agent moves left or right once; moving
left gives reward −1 and moving right +1, and the agent halts. Over repeated runs (`init-soar`
between them, keeping the RL values) it learns to prefer right.
-/
namespace Agent.LeftRight

def agentT : String := "agent"

def schema : Schema where
  task := "left-right"
  stateAttrs := [{ name := "agent", ty := .obj agentT, multi := true, doc := "The agent's position." }]
  types := [{
    name := agentT,
    attrs := [
      { name := "location", ty := .int, doc := "0 at the start, −1 after moving left, 1 after moving right" },
      { name := "moved", ty := .int, doc := "1 once the agent has moved" }] }]

/-- Move left (−1) or right (+1) from the start. -/
def move : Operator where
  name := "move"
  params := [("agent", agentT)]
  vparams := [("direction", [-1, 1])]
  propose := [.cmp "agent" "location" .eq (.lit 0)]
  apply := [{ effects := [{ obj := "agent", attr := "location", val := .val "direction" },
                          { obj := "agent", attr := "moved", val := .lit 1 }],
              write := [.text "Moved: ", .val (.val "direction")] }]
  doc := "Move from the start in a direction: −1 left, 1 right."

def assumptions : List Assumption := [
  { id := "A1", text := "The task: from the start, move left or right once and halt; moving left gives reward −1, right +1. Learning runs over repeated runs with `init-soar` between them, which keep the RL values (V1's readme shows 12 runs)." },
  { id := "A2", text := "Directions are the values −1 (left) and 1 (right) of the move's value parameter `direction`, instead of V1's direction objects with a name and a reward; the agent's location is 0 at the start and the direction after the move, instead of V1's symbols start, left and right." },
  { id := "A3", text := "Rewards are the variant's (a location of −1 gives −1, of 1 gives +1), given by reward rules on the agent's location, instead of being read from V1's direction objects. V1's values are those, so the rewards are the same." },
  { id := "A4", text := "The goal is that the agent has moved (`moved` = 1), which halts it, as V1's done elaboration halts once the location is not start. `moved` is added because a goal is a set of values, not a test that a value differs from one." },
  { id := "A5", text := "RL: Soar's defaults, as V1 (learning on, learning rate 0.3, discount 0.9, epsilon-greedy with epsilon 0.1). One RL template over the move's direction makes one rule per direction with initial value 0, as V1's two hand-written RL rules." }]

def agent : Agent where
  schema := schema
  init := [("agent", [("location", 0), ("moved", 0)])]
  derive := []
  ops := [move]
  goal := { ty := agentT, vals := [("moved", 1)] }
  constraints := [{ ty := agentT, guard := [.cmp "self" "location" .ge (.lit (-1)), .cmp "self" "location" .le (.lit 1)], doc := "the agent is at the start, left or right" }]
  method := .rl [({ ty := agentT, objs := [[("location", -1)]] }, -1), ({ ty := agentT, objs := [[("location", 1)]] }, 1)]
  learning := .rl 300 900
  assumptions := assumptions

def variants : List (String × Agent × List String) := [
  ("left-right", agent, ["left-right V1"])]

def conventionsOk : Bool := variants.all (fun v => check v.2.1 == [])
theorem conventions : conventionsOk = true := by native_decide

/-- One move reaches the goal. -/
theorem one_move : (agent.bfs 3).1.map List.length = some 1 := by native_decide

end Agent.LeftRight
