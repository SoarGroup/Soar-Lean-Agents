import Agent.DSL
import Agent.Sem
/-!
# Missionaries & Cannibals — one parameterized description for the family

Derived on 6 November 2026 from the 15 Missionaries & Cannibals task agents in the agent library:
mac V1–V3, mac1, mac2, mac-planning V1–V3, mac1-planning, mac1-planning-numeric, mac3-planning,
mac-look-ahead, mac-lookahead-RL, mac-substate-RL and Soar's chunking demo
ChunkingDemoTests_Demo_MaC_Planning (its `_expected` file is a unit-test output, not an agent).

They share one task: three missionaries, three cannibals and a boat for two on the left bank; get
everyone to the right bank; a bank where the missionaries are outnumbered by cannibals is a failure
state. They differ in the method (random choice with "undo the last move" preferences, look-ahead
with the selection library and failure states, look-ahead with a numeric evaluation, RL), in
learning, and in representation. The representations (banks as objects with counts and a boat
count; the same named mice and cats; the boat as a state attribute; one object per type with
`^left`/`^right` counts; `holds` objects per type and side) are not task differences: here banks
are objects with counts, a boat count and a static link to the other bank, as in mac V2.

Three originals are not replaced:
* mac-planning V2: a second top-state initialization (`initialize-selection`) ties with the task's
  own; look-ahead over the two nests state no-changes until Soar halts at its goal-depth limit, and
  the task is never initialized (0 of 20).
* mac-lookahead-RL: RL learning is never turned on (it has rewards and `learn --on` only, no
  `rl --set learning on`). In Soar 9.6.5 it solves 0 of 17 seeds and crashes Soar on 3 more: it
  stays in its first look-ahead, moves back and forth, or moves into a failure state and halts.
* mac3-planning: its duplicate-state rule only catches states in which a side has no missionaries
  and no cannibals in both states, so repeated states are not pruned; the depth-first look-ahead
  nests 100+ substates and Soar halts before the first move (0 of 20).

mac-planning V3 and mac1-planning (look-ahead that sometimes moves into a failure state at the top
and halts) and mac1-planning-numeric (greedy numeric look-ahead that moves back and forth) are
replaced: their intent is clear; the differences are in families/mac/REPORT.md.
-/
namespace Agent.Mac

def bank : String := "bank"

def schema : Schema where
  task := "mac"
  stateAttrs := [{ name := "bank", ty := .obj "bank", multi := true, doc := "The two river banks." }]
  types := [{
    name := "bank", key := some "name",
    attrs := [
      { name := "name", ty := .sym ["left", "right"], doc := "which bank" },
      { name := "missionaries", ty := .int, doc := "missionaries on this bank" },
      { name := "cannibals", ty := .int, doc := "cannibals on this bank" },
      { name := "boat", ty := .int, doc := "1 if the boat is at this bank, else 0" },
      { name := "other-bank", ty := .obj "bank", doc := "the bank across the river" }] }]

def g (o a : String) : Expr := .get o a
def v (p : String) : Expr := .val p

/-- The one task operator: cross with `missionaries` missionaries and `cannibals` cannibals (one or
two people in all) from the bank with the boat to the other bank. -/
def moveBoat : Operator where
  name := "move-boat"
  params := [("from", bank), ("to", bank)]
  vparams := [("missionaries", [0, 1, 2]), ("cannibals", [0, 1, 2])]
  propose := [
    .vcmp (.add (v "missionaries") (v "cannibals")) .ge 1,
    .vcmp (.add (v "missionaries") (v "cannibals")) .le 2,
    .link "from" "other-bank" "to",
    .cmp "from" "boat" .eq (.lit 1),
    .cmp "from" "missionaries" .ge (.val "missionaries"),
    .cmp "from" "cannibals" .ge (.val "cannibals")]
  apply := [{ effects := [
    { obj := "from", attr := "missionaries", val := .sub (g "from" "missionaries") (v "missionaries") },
    { obj := "to", attr := "missionaries", val := .add (g "to" "missionaries") (v "missionaries") },
    { obj := "from", attr := "cannibals", val := .sub (g "from" "cannibals") (v "cannibals") },
    { obj := "to", attr := "cannibals", val := .add (g "to" "cannibals") (v "cannibals") },
    { obj := "from", attr := "boat", val := .lit 0 },
    { obj := "to", attr := "boat", val := .lit 1 }] }]
  doc := "Row across with one or two people; the boat goes with them."

/-- Failure states: on some bank the missionaries are outnumbered (and there is at least one). -/
def outnumbered : Failure where
  ty := bank
  guard := [.cmp "self" "missionaries" .gt (.lit 0), .cmp "self" "missionaries" .lt (.get "self" "cannibals")]
  doc := "The missionaries on that bank are lost."

/-- Task constraints: counts stay in range. -/
def inRange : List Constraint := [
  { ty := bank, guard := [.cmp "self" "missionaries" .ge (.lit 0), .cmp "self" "missionaries" .le (.lit 3)],
    doc := "0 to 3 missionaries on a bank" },
  { ty := bank, guard := [.cmp "self" "cannibals" .ge (.lit 0), .cmp "self" "cannibals" .le (.lit 3)],
    doc := "0 to 3 cannibals on a bank" },
  { ty := bank, guard := [.cmp "self" "boat" .ge (.lit 0), .cmp "self" "boat" .le (.lit 1)],
    doc := "the boat is at a bank or not" }]

/-- The search control of mac V2 (also mac V3, mac1, mac2, mac-substate-RL), minus its undo after
a failure state (a failure state now halts, A2): avoid taking the last move back. The undo is the
same crossing in the other direction (same numbers, from the bank the last move went to). -/
def undo : List Pref := [
  { name := "avoid-undo", op := "move-boat", value := .worst,
    sameAsLast := [("missionaries", "missionaries"), ("cannibals", "cannibals"), ("from", "to")],
    doc := "Do not take the last move back unless nothing else is proposed." }]

/-- The look-ahead evaluation of mac1-planning-numeric: the number of people on the right bank. -/
def onRight : Score := { ty := bank, name := some "right", val := .add (g "self" "missionaries") (g "self" "cannibals") }

/-- Recovered intent and common-sense knowledge, for review. -/
def assumptions : List Assumption := [
  { id := "A1", text := "The task: 3 missionaries, 3 cannibals and the boat on the left bank; the goal is all 6 on the right bank (the boat is then there too). A crossing carries 1 or 2 people, any mix, and the boat; this is the five proposal rules of every original.", status := "accepted" },
  { id := "A2", text := "A failure state is a bank with at least one missionary and more cannibals than missionaries (all originals). It is a task constraint, but it is not built into the proposals (that would give the agent too much knowledge): moves into a failure state are proposed, and entering one at the top state is a task failure and halts. Look-ahead evaluates it as a failure (the move is rejected); RL gives reward −1 and the episode ends. The originals’ undo after entering a failure state is dropped (JL, 6 Nov 2026).", status := "accepted" },
  { id := "A3", text := "Representation: banks are objects `^bank` with `^name left|right`, missionary, cannibal and boat counts, and a static `^other-bank` link (mac V2). The originals used `^left-bank`/`^right-bank` (or `^left`/`^right`) state attributes, mice and cats (mac V3, mac-look-ahead, mac-substate-RL), the boat as a state attribute (mac-planning V1, chunking demo, mac V3), or per-type objects (mac2, mac3-planning). Counts stay in range (declared constraints, proved).", status := "accepted" },
  { id := "A4", text := "move-boat has object parameters from/to (from has the boat; to is its other bank) and value parameters missionaries, cannibals ∈ {0,1,2} with 1 ≤ sum ≤ 2. The originals' operators named only the bank (or neither) and gave the counts, some omitting zero counts, and added bookkeeping (`^types`, `^boat 1`).", status := "accepted" },
  { id := "A5", text := "No undo heuristic: the originals (mac V2 and relatives) remembered the last move (`^last-move`) and made its reverse worst (and best after a failure state); both are dropped (JL, 6 Nov 2026). The random agent is a pure random walk, and RL must learn not to undo.", status := "accepted" },
  { id := "A6", text := "Goal: `^desired` with the right bank's 3 and 3 and a success rule; halt at the top state (all originals halted at success; mac1, mac2 and mac1-planning initialized by elaboration instead of an operator, which is dropped).", status := "accepted" },
  { id := "A7", text := "Look-ahead (mac-planning V1, mac-look-ahead, chunking demo, mac-planning V3, mac1-planning): default selection library as is; a failure state is a failure evaluation; a state equal to any ancestor (top state included) is a failure, not a partial failure, as in all these originals. mac-look-ahead and the chunking demo compared only with the states one and two moves back; mac-planning V1 compared with every state on the stack. The originals' own state no-change failure rule is dropped: the library marks a state with no acceptable operator as a failure (one decision later).", status := "accepted" },
  { id := "A8", text := "Numeric look-ahead (mac1-planning-numeric): each tried state is evaluated by the number of people on the right bank, higher is better, with failure states and duplicates still failures. This is greedy one-step look-ahead; it is kept as a variant although in Soar 9.6.5 the original never solves the task (it moves back and forth).", status := "accepted" },
  { id := "A9", text := "RL (mac-substate-RL): its RL rules were made by chunking over a look-ahead that gave every operator expected value 0 at once; here RL templates with initial value 0 on the operator, its counts and both banks’ names and counts (all non-derived, non-link attributes). Rewards −1 in a failure state (which halts; the original’s two reward rules gave −2), +1 at the goal, and a cost of −0.01 per move (JL, 6 Nov 2026); learning rate 0.1, discount 0.5, epsilon-greedy (as in the original); no undo heuristic (A5).", status := "accepted" },
  { id := "A10", text := "Chunking: `chunk always`, no singletons declared (R16). The chunking demo declared 21 singletons and used srand 3 (its comment: srand 1 loops forever); the harness sets the seed after loading. The demo’s 21 singleton declarations are removed (JL, 6 Nov 2026).", status := "accepted" }]

/-- The family. -/
def mk (method : Method) (prefs : List Pref := []) (learning : Learning := .none) : Agent where
  schema := schema
  init := []
  objs := [
    { holder := "bank", name := "left", vals := [("missionaries", 3), ("cannibals", 3), ("boat", 1)],
      links := [("other-bank", "right")] },
    { holder := "bank", name := "right", vals := [("missionaries", 0), ("cannibals", 0), ("boat", 0)],
      links := [("other-bank", "left")] }]
  derive := []
  ops := [moveBoat]
  goal := { ty := bank, vals := [("missionaries", 3), ("cannibals", 3)], name := some "right" }
  constraints := inRange
  failure := [outnumbered]
  prefs := prefs
  method := method
  learning := learning
  assumptions := assumptions

/-- The variants: name, agent, and the originals each one replaces. -/
def variants : List (String × Agent × List String) := [
  ("mac", mk .random,
    ["mac V1", "mac V2", "mac V3", "mac1 V1", "mac2 V1"]),
  ("mac-rl", mk (.rl [] (some (-1)) (some 1) (some (-10))) [] (.rl 100 500),
    ["mac-substate-RL V1"]),
  ("mac-look-ahead", mk (.lookahead [] none .failure) [] (.chunk []),
    ["mac-planning V1", "mac-planning V3", "mac1-planning V1", "mac-look-ahead V1",
     "ChunkingDemoTests_Demo_MaC_Planning V1"]),
  ("mac-look-ahead-numeric", mk (.lookahead [] none .failure (some onRight)) [] (.chunk []),
    ["mac1-planning-numeric V1"])]

/-! ## Checks before any Soar is generated

`conventions` is checked by the kernel (`decide`); the task properties by evaluation
(`native_decide`, as for Water Jug). -/

/-- Every variant obeys the conventions. -/
theorem conventions : variants.all (fun v => check v.2.1 == []) = true := by decide

/-- The task: the shortest solution that never enters a failure state has 11 crossings. -/
theorem shortest_safe : ((mk .random).bfsSafe 12).1.map List.length = some 11 := by native_decide

/-- No shorter one: within 10 crossings the goal cannot be reached without a failure state. -/
theorem none_shorter_safe : ((mk .random).bfsSafe 11).1 = none := by native_decide

/-- Without the failure states, 9 crossings would do: the failure states are what makes the
task hard. -/
theorem shortest_ignoring_failure : ((mk .random).bfs 12).1.map List.length = some 9 := by native_decide

/-- The task constraints (counts in range) hold in every reachable state, failure states
included, for every variant (the search exhausts the state space within 30 crossings). -/
theorem constraints_hold : variants.all (fun v => v.2.1.constraintsHold 30) = true := by native_decide

/-- Nobody is created or lost and there is one boat: in every reachable state the banks hold 3
missionaries, 3 cannibals and 1 boat in all. -/
theorem conserved : (mk .random).invariantS 30 (fun st =>
    let tot (a : String) := (st.map fun ob => (ob.lookup a).getD 0).foldl (· + ·) 0
    tot "missionaries" == 3 && tot "cannibals" == 3 && tot "boat" == 1) = true := by native_decide

end Agent.Mac
