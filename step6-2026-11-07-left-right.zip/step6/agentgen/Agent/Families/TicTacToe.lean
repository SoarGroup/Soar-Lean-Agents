import Agent.DSL
import Agent.Sem
/-!
# Tic-Tac-Toe — one description for the family

Derived on 7 November 2026 from TicTacToe V1 (John Laird): both sides play at random on a 3 × 3
board, X first; the game ends when one side has three in a row (it won) or the board is full
(a draw), and the agent halts. A monitor prints the board after every move.

TicTacToe V1's folder also holds an Eight Puzzle look-ahead (`Impasse__Operator_Tie~`,
`eight-puzzle_source.soar`, `initialize.soar`) left over from the project it was copied from;
the load file does not source it, so it is not part of the agent.
-/
namespace Agent.TicTacToe

def cellT : String := "cell"
def lineT : String := "line"
def gameT : String := "game"

def schema : Schema where
  task := "TicTacToe"
  stateAttrs := [
    { name := "cell", ty := .obj cellT, multi := true, doc := "The nine cells of the board." },
    { name := "line", ty := .obj lineT, multi := true, doc := "The eight lines: three rows, three columns, two diagonals." },
    { name := "game", ty := .obj gameT, multi := true, doc := "The game." }]
  types := [
    { name := cellT, key := some "xy",
      attrs := [
        { name := "name", ty := .sym [], doc := "c<x><y>" },
        { name := "xy", ty := .int, doc := "x × 10 + y" },
        { name := "x", ty := .int, doc := "the column, 1–3" },
        { name := "y", ty := .int, doc := "the row, 1–3" },
        { name := "content", ty := .int, doc := "0 empty, 1 X, 2 O" }] },
    { name := lineT,
      attrs := [
        { name := "name", ty := .sym [], doc := "row<y>, column<x>, diagonal1, diagonal2" },
        { name := "cell", ty := .obj cellT, multi := true, doc := "its three cells" }] },
    { name := gameT,
      attrs := [
        { name := "name", ty := .sym [], doc := "game" },
        { name := "turn", ty := .int, doc := "the side to move: 1 X, 2 O" },
        { name := "winner", ty := .int, doc := "0 none (yet, or a draw), 1 X, 2 O" },
        { name := "over", ty := .int, doc := "1 once the game has ended" }] }]

def g (o a : String) : Expr := .get o a
def eff (o a : String) (v : Expr) : Effect := { obj := o, attr := a, val := v }

/-- The side to move marks an empty cell; the other side moves next. -/
def mark : Operator where
  name := "mark"
  params := [("cell", cellT), ("game", gameT)]
  propose := [.cmp "cell" "content" .eq (.lit 0), .cmp "game" "over" .eq (.lit 0)]
  apply := [{ effects := [eff "cell" "content" (g "game" "turn"), eff "game" "turn" (.sub (.lit 3) (g "game" "turn"))] }]
  doc := "Put the mark of the side to move in an empty cell."

/-- A side has three in a row: it has won. -/
def wins (side : Int) (label : String) : Operator where
  name := s!"{label.toLower}-wins"
  params := [("line", lineT), ("game", gameT)]
  propose := [.cmp "game" "over" .eq (.lit 0), .linked "line" "cell" cellT [("content", .eq, .lit side)] 3]
  apply := [{ effects := [eff "game" "over" (.lit 1), eff "game" "winner" (.lit side)],
              write := [.text s!"Side {label} won."] }]
  doc := s!"{label} has three in a row: the game is over and {label} has won."

/-- The board is full and nobody has three in a row: a draw. -/
def draw : Operator where
  name := "detect-draw"
  params := [("game", gameT)]
  propose := [.cmp "game" "over" .eq (.lit 0), .noneSuch cellT [("content", .eq, .lit 0)]]
  apply := [{ effects := [eff "game" "over" (.lit 1)], write := [.text "Draw."] }]
  doc := "The board is full: the game is a draw."

def cellName (x y : Nat) : String := s!"c{x}{y}"

def cells : List Named :=
  ((List.range 3).flatMap fun i => (List.range 3).map fun j => (j + 1, i + 1)).map fun (x, y) =>
    { holder := "cell", name := cellName x y,
      vals := [("xy", ((x * 10 + y : Nat) : Int)), ("x", (x : Int)), ("y", (y : Int)), ("content", 0)] }

def lines : List Named :=
  let l (n : String) (cs : List (Nat × Nat)) : Named :=
    { holder := "line", name := n, vals := [], links := cs.map fun (x, y) => ("cell", cellName x y) }
  ((List.range 3).map fun i => l s!"row{i+1}" [(1, i+1), (2, i+1), (3, i+1)]) ++
  ((List.range 3).map fun i => l s!"column{i+1}" [(i+1, 1), (i+1, 2), (i+1, 3)]) ++
  [l "diagonal1" [(1, 1), (2, 2), (3, 3)], l "diagonal2" [(3, 1), (2, 2), (1, 3)]]

def gameObj : Named where
  holder := "game"
  name := "game"
  vals := [("turn", 1), ("winner", 0), ("over", 0)]

def shownRules : String :=
  let r (v : Nat) (sym : String) : String :=
    s!"sp \{TicTacToe*elaborate*cell*shown*{v}
   (state <s> ^name TicTacToe ^cell <c>)
   (<c> ^content {v})
-->
   (<c> ^shown |{sym}|)
}
"
  r 0 " " ++ r 1 "X" ++ r 2 "O"

def boardRule : String :=
  let row (y : Nat) : String :=
    s!"   (write |     \\|| | | <v1{y}> | | |\\|| | | <v2{y}> | | |\\|| | | <v3{y}> | | |\\|| (crlf))\n"
  let conds := ((List.range 3).flatMap fun i => (List.range 3).map fun j => (j + 1, i + 1)).map fun (x, y) =>
    s!"   (<c{x}{y}> ^x {x} ^y {y} ^shown <v{x}{y}>)\n"
  "sp {TicTacToe*monitor*board\n   (state <s> ^name TicTacToe ^cell <c11> <c21> <c31> <c12> <c22> <c32> <c13> <c23> <c33>)\n" ++
  String.join conds ++ "-->\n   (write (crlf) |     -------------| (crlf))\n" ++
  row 1 ++ "   (write |     \\|---\\|---\\|---\\|| (crlf))\n" ++ row 2 ++
  "   (write |     \\|---\\|---\\|---\\|| (crlf))\n" ++ row 3 ++ "   (write |     -------------| (crlf))\n}\n"

def monitorRaw : Raw where
  file := "elaborations/monitor"
  why := "Monitor (trace output only), as TicTacToe V1's tictactoe*monitor*state: prints the board after every change, with X, O and blank for the cells' contents (`^shown`, an attribute used only by the monitor). Written by hand (JL, 6 Nov 2026: monitors are allowed as Raw)."
  text := shownRules ++ boardRule

def assumptions : List Assumption := [
  { id := "A1", text := "The task: two sides, X first, alternately mark an empty cell of a 3 × 3 board, both at random (V1 has no search control); the game ends when a side has three in a row (it won) or the board is full (a draw), and the agent halts after writing the result." },
  { id := "A2", text := "The board's lines (three rows, three columns, two diagonals) are task objects linked to their three cells, and a win is a line whose three cells all hold the same side's mark. V1 instead has four elaborations over cell coordinates (rows, columns and both diagonals), each matching any three cells with the right coordinates." },
  { id := "A3", text := "Detecting the end is done by operators (`x-wins`, `o-wins`, `detect-draw`) that set the game's `over` (and `winner`), and the goal is `over` = 1. V1 detects three in a row with elaborations that set `^success` and halt as soon as they fire, and a draw with an operator. A win operator is best, so it is chosen before any further mark; with `over` = 1 no mark is proposed." },
  { id := "A4", text := "The sides are 1 (X) and 2 (O) and an empty cell holds 0, instead of V1's symbols X, O and | |; the side to move is the game's `turn` (the other is 3 − turn) instead of V1's `^current-side`/`^other-side` pair, which the mark's apply swaps. The monitor prints X, O and blank." },
  { id := "A5", text := "V1's monitor prints the board after every change (it is an elaboration over all nine contents). It is kept, by hand, as a Raw rule; it uses `^shown` elaborations for the symbols." },
  { id := "A6", text := "V1's three-in-a-row elaborations write which row, column or diagonal; here the win operator writes only the side (`Side X won.`). The line is the operator's parameter, so the trace shows it." }]

def agent : Agent where
  schema := schema
  init := []
  objs := cells ++ lines ++ [gameObj]
  derive := []
  ops := [mark, wins 1 "X", wins 2 "O", draw]
  goal := { ty := gameT, vals := [("over", 1)] }
  constraints := [{ ty := cellT, guard := [.cmp "self" "content" .ge (.lit 0), .cmp "self" "content" .le (.lit 2)], doc := "a cell is empty, X or O" }]
  prefs := [
    { name := "x-wins-best", op := "x-wins", sameAsLast := [], value := .best, doc := "a win ends the game before another mark" },
    { name := "o-wins-best", op := "o-wins", sameAsLast := [], value := .best, doc := "a win ends the game before another mark" }]
  method := .random
  assumptions := assumptions
  raw := [monitorRaw]

def variants : List (String × Agent × List String) := [
  ("tictactoe", agent, ["TicTacToe V1"])]

def conventionsOk : Bool := variants.all (fun v => check v.2.1 == [])
theorem conventions : conventionsOk = true := by native_decide

/-! ## Checking the description: every game ends, in at most nine marks and one end operator -/

/-- The shortest game: X wins after five marks and the win operator. -/
def endsCheck : Bool := match (agent.bfs 11).1 with
  | some p => p.length == 6
  | none => false

theorem game_ends : endsCheck = true := by native_decide

end Agent.TicTacToe
