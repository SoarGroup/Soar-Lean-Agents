import Agent.DSL
import Agent.Sem
/-!
# Three wizards — reasoning about what others know, with nested models and assumptions

Derived on 7 November 2026 from wizards V1 and V2 (John Laird; after Newell, McDermott and Forgy,
*Artificial Intelligence: a self-paced introductory course*, CMU 1977, pp. 36–40). A king pastes a
black or white spot on each of three wizards' foreheads (at least one white; in fact all white).
Each sees the others' spots, not his own; nobody has guessed yet. Wizard A works out that his spot
is white.

A builds a model of what B knows, and within it a model of what C knows (views). In his own view a
wizard's spot is unknown: a variable with untried values. Assume another's unknown spot black
(black first). Deductions retract by themselves when their grounds go: a wizard who sees two black
spots knows his is white; a wizard who knows his colour guesses it; what a modelled wizard knows or
would guess is known in the view that models him; a wizard predicted to guess who has not guessed
(or with two guesses) is a contradiction. On a contradiction the assumption that led to it is
replaced by the other value (complement). A halts when he would guess his own spot.

One variant, `wizards` (V2 casts V1's deduction operators as elaborations; the same behaviour).
Wizards are numbered A = 1, B = 2, C = 3; colours white = 1, black = 2; guess 0 = has not guessed.
-/
namespace Agent.Wizards

def viewT : String := "view"
def recT : String := "rec"
def mvT : String := "markvar"
def worldT : String := "world"

def schema : Schema where
  task := "wizards"
  stateAttrs := [
    { name := "view", ty := .obj viewT, multi := true, doc := "The views: A's, and models of others' within them." },
    { name := "rec", ty := .obj recT, multi := true, doc := "What a view holds about each wizard." },
    { name := "markvar", ty := .obj mvT, multi := true, doc := "Unknown spots: variables with untried values." },
    { name := "world", ty := .obj worldT, multi := true, doc := "Whether A has guessed." }]
  types := [
    { name := worldT, attrs := [
        { name := "name", ty := .sym [], doc := "world" },
        { name := "done", ty := .int, doc := "1 once A guesses" },
        { name := "nviews", ty := .int, doc := "views made (to number them)" }] },
    { name := viewT, key := some "vid", attrs := [
        { name := "name", ty := .sym [], doc := "the top view's name" },
        { name := "vid", ty := .int, doc := "its number" },
        { name := "owner", ty := .int, doc := "whose view (1 A, 2 B, 3 C)" },
        { name := "depth", ty := .int, doc := "1 for A's own view" },
        { name := "parent", ty := .obj viewT, doc := "the view that models this one" }] },
    { name := recT, attrs := [
        { name := "name", ty := .sym [], doc := "the top view's records' names" },
        { name := "wiz", ty := .int, doc := "the wizard (1 A, 2 B, 3 C)" },
        { name := "mark", ty := .int, doc := "his spot, known as such: 0 not known, 1 white, 2 black" },
        { name := "var", ty := .int, doc := "1 when his spot is an unknown (a markvar)" },
        { name := "modeled", ty := .int, doc := "1 once a view models him from this view" },
        { name := "aguess", ty := .int, multi := true, doc := "his guesses as observed (0: has not guessed)" },
        { name := "view", ty := .obj viewT, doc := "the view it belongs to" },
        { name := "sib", ty := .obj recT, multi := true, doc := "the view's other records" },
        { name := "sub", ty := .obj recT, multi := true, doc := "the same wizard's records in the views this view models" },
        { name := "mv", ty := .obj mvT, multi := true, doc := "his unknown spot (at most one)" },
        { name := "own", ty := .int, derived := true, doc := "1: the record of the view's owner" },
        { name := "white", ty := .int, derived := true, doc := "1: his spot is known to be white" },
        { name := "black", ty := .int, derived := true, doc := "1: his spot is known to be black" },
        { name := "blackish", ty := .int, derived := true, doc := "1: his spot is known or assumed black" },
        { name := "gwhite", ty := .int, derived := true, doc := "1: he guesses (or would guess) white" },
        { name := "gblack", ty := .int, derived := true, doc := "1: he guesses (or would guess) black" },
        { name := "contra", ty := .int, derived := true, doc := "1: incompatible guesses" }] },
    { name := mvT, attrs := [
        { name := "value", ty := .int, doc := "the value assumed: 0 none, 1 white, 2 black" },
        { name := "assigned", ty := .int, doc := "the view that assumed it (its vid)" },
        { name := "untried", ty := .int, multi := true, doc := "values not yet assumed" }] }]

def g (o a : String) : Expr := .get o a
def eff (o a : String) (v : Expr) : Effect := { obj := o, attr := a, val := v }
def add (o a : String) (v : Expr) : Effect := { obj := o, attr := a, val := v, mode := .add }
def notContra : List Guard := [.flag "below" "contra" false]

/-- The deductions: derived flags on records, recomputed as their grounds change. -/
def flags : List Flag := [
  { ty := recT, attr := "own", base := [.linked "self" "view" viewT [("owner", .eq, .get "self" "wiz")] 1],
    doc := "the record of the view's owner" },
  -- known spots: given, deduced (sees two black spots), or known in a view modelling him
  { ty := recT, attr := "white", base := [.cmp "self" "mark" .eq (.lit 1)] },
  { ty := recT, attr := "white", base := [.flag "self" "own" true, .linked "self" "sib" recT [("blackish", .eq, .lit 1)] 2],
    doc := "deduce-bbw: the others' spots are black, so his is white" },
  { ty := recT, attr := "white", via := "sub", step := notContra, doc := "knows-own-mind (mark)" },
  { ty := recT, attr := "black", base := [.cmp "self" "mark" .eq (.lit 2)] },
  { ty := recT, attr := "black", via := "sub", step := notContra },
  -- black for deducing: known, or assumed
  { ty := recT, attr := "blackish", base := [.flag "self" "black" true] },
  { ty := recT, attr := "blackish", base := [.linked "self" "mv" mvT [("value", .eq, .lit 2)] 1] },
  -- guesses: one who knows his spot guesses it; observed guesses; guesses known in a model of him
  { ty := recT, attr := "gwhite", base := [.flag "self" "own" true, .flag "self" "white" true], doc := "guess-own-mark" },
  { ty := recT, attr := "gwhite", base := [.cmp "self" "aguess" .eq (.lit 1)] },
  { ty := recT, attr := "gwhite", via := "sub", step := notContra, doc := "knows-own-mind (guess)" },
  { ty := recT, attr := "gblack", base := [.flag "self" "own" true, .flag "self" "black" true] },
  { ty := recT, attr := "gblack", base := [.cmp "self" "aguess" .eq (.lit 2)] },
  { ty := recT, attr := "gblack", via := "sub", step := notContra },
  -- incompatible guesses
  { ty := recT, attr := "contra", base := [.cmp "self" "aguess" .eq (.lit 0), .flag "self" "gwhite" true],
    doc := "predicted to guess, observed not to have guessed" },
  { ty := recT, attr := "contra", base := [.cmp "self" "aguess" .eq (.lit 0), .flag "self" "gblack" true] },
  { ty := recT, attr := "contra", base := [.flag "self" "gwhite" true, .flag "self" "gblack" true] }]

/-- In his own view a wizard's spot is unknown: a variable with both values untried. -/
def selfUnknown : Operator where
  name := "self-unknown"
  params := [("r", recT)]
  propose := [.flag "r" "own" true, .cmp "r" "mark" .eq (.lit 0), .cmp "r" "var" .eq (.lit 0),
    .flag "r" "white" false, .flag "r" "black" false]
  apply := [{
    creates := [{ var := "m", holder := "markvar", vals := [("value", .lit 0), ("assigned", .lit 0), ("untried", .lit 1), ("untried", .lit 2)] }],
    effects := [add "r" "mv" (.obj "m"), eff "r" "var" (.lit 1)],
    write := [.text "In the view of wizard ", .val (g "r" "wiz"), .text ", his own spot is unknown."] }]

/-- From view `k`, model what wizard `w` knows: a new view owned by `w`, with a record per wizard. -/
def considerKnows : Operator where
  name := "consider-knows"
  params := [("wd", worldT), ("k", viewT), ("w", recT), ("a1", recT), ("a2", recT), ("a3", recT)]
  propose := [.link "w" "view" "k", .flag "w" "own" false, .cmp "w" "modeled" .eq (.lit 0),
    .link "a1" "view" "k", .cmp "a1" "wiz" .eq (.lit 1), .link "a2" "view" "k", .cmp "a2" "wiz" .eq (.lit 2),
    .link "a3" "view" "k", .cmp "a3" "wiz" .eq (.lit 3)]
  apply := [{
    creates := [
      { var := "v", holder := "view", vals := [("vid", .add (g "wd" "nviews") (.lit 1)), ("owner", g "w" "wiz"),
          ("depth", .add (g "k" "depth") (.lit 1))] },
      { var := "r1", holder := "rec", vals := [("wiz", .lit 1), ("mark", .lit 0), ("var", .lit 0), ("modeled", .lit 0)] },
      { var := "r2", holder := "rec", vals := [("wiz", .lit 2), ("mark", .lit 0), ("var", .lit 0), ("modeled", .lit 0)] },
      { var := "r3", holder := "rec", vals := [("wiz", .lit 3), ("mark", .lit 0), ("var", .lit 0), ("modeled", .lit 0)] }],
    effects := [eff "wd" "nviews" (.add (g "wd" "nviews") (.lit 1)), eff "w" "modeled" (.lit 1),
      add "v" "parent" (.obj "k"),
      add "r1" "view" (.obj "v"), add "r2" "view" (.obj "v"), add "r3" "view" (.obj "v"),
      add "r1" "sib" (.obj "r2"), add "r1" "sib" (.obj "r3"), add "r2" "sib" (.obj "r1"),
      add "r2" "sib" (.obj "r3"), add "r3" "sib" (.obj "r1"), add "r3" "sib" (.obj "r2"),
      add "a1" "sub" (.obj "r1"), add "a2" "sub" (.obj "r2"), add "a3" "sub" (.obj "r3")],
    write := [.text "In the view of wizard ", .val (g "k" "owner"), .text ", model what wizard ", .val (g "w" "wiz"), .text " knows."] }]

/-- A modelled wizard sees what the modelling view knows of the others' spots and guesses. -/
def ascribeMark : Operator where
  name := "ascribe-mark"
  params := [("x1", recT), ("x2", recT)]
  propose := [.link "x1" "sub" "x2", .flag "x2" "own" false, .cmp "x1" "mark" .ne (.lit 0), .cmp "x2" "mark" .eq (.lit 0)]
  apply := [{ effects := [eff "x2" "mark" (g "x1" "mark")] }]

def ascribeUnknown : Operator where
  name := "ascribe-unknown"
  params := [("x1", recT), ("x2", recT), ("m", mvT)]
  propose := [.link "x1" "sub" "x2", .flag "x2" "own" false, .link "x1" "mv" "m", .cmp "x2" "var" .eq (.lit 0)]
  apply := [{ effects := [add "x2" "mv" (.obj "m"), eff "x2" "var" (.lit 1)] }]

def ascribeGuess : Operator where
  name := "ascribe-guess"
  params := [("x1", recT), ("x2", recT)]
  vparams := [("gv", [0, 1, 2])]
  propose := [.link "x1" "sub" "x2", .flag "x2" "own" false, .cmp "x1" "aguess" .eq (.val "gv"),
    .cmp "x2" "aguess" .lacks (.val "gv")]
  apply := [{ effects := [add "x2" "aguess" (.val "gv")] }]

/-- Assume another wizard's unknown spot black (white once black has been tried). -/
def assume (v : Nat) : Operator where
  name := if v == 2 then "assume-black" else "assume-white"
  params := [("k", viewT), ("r", recT), ("m", mvT)]
  propose := [.link "r" "view" "k", .flag "r" "own" false, .link "r" "mv" "m", .cmp "m" "value" .eq (.lit 0),
    .cmp "m" "untried" .eq (.lit (v : Int))] ++ (if v == 1 then [.cmp "m" "untried" .lacks (.lit 2)] else [])
  apply := [{
    effects := [eff "m" "value" (.lit (v : Int)), { obj := "m", attr := "untried", val := .lit (v : Int), mode := .remove },
      eff "m" "assigned" (g "k" "vid")],
    write := [.text "In the view of wizard ", .val (g "k" "owner"), .text ", assume wizard ", .val (g "r" "wiz"),
      .text (if v == 2 then "'s spot is black." else "'s spot is white.")] }]

/-- A contradiction in view `k1`: the assumption a view it models made is replaced by the other value. -/
def complement : Operator where
  name := "complement"
  params := [("k1", viewT), ("w1", recT), ("k2", viewT), ("w2", recT), ("m", mvT)]
  vparams := [("u", [1, 2])]
  propose := [.link "w1" "view" "k1", .flag "w1" "contra" true, .link "k2" "parent" "k1", .link "w2" "view" "k2",
    .link "w2" "mv" "m", .cmp "m" "assigned" .eq (.get "k2" "vid"), .cmp "m" "untried" .eq (.val "u")]
  apply := [{
    effects := [eff "w2" "mark" (.val "u"), { obj := "w2", attr := "mv", val := .obj "m", mode := .remove },
      eff "w2" "var" (.lit 0)],
    write := [.text "Contradiction in the view of wizard ", .val (g "k1" "owner"), .text ": in the view of wizard ",
      .val (g "k2" "owner"), .text ", wizard ", .val (g "w2" "wiz"), .text "'s spot must be ", .val (.val "u")] }]

/-- A, in his own view, would guess: he guesses. -/
def detect (white : Bool) : Operator where
  name := if white then "guess-white" else "guess-black"
  params := [("wd", worldT), ("k", viewT), ("r", recT)]
  propose := [.cmp "wd" "done" .eq (.lit 0), .cmp "k" "depth" .eq (.lit 1), .link "r" "view" "k",
    .flag "r" "own" true, .flag "r" (if white then "gwhite" else "gblack") true]
  apply := [{
    effects := [eff "wd" "done" (.lit 1)],
    write := [.text "Wizard ", .val (g "r" "wiz"), .text (if white then " guesses his spot is white." else " guesses his spot is black.")] }]

def pref (nm op : String) (guard : List Guard) (v : HVal) (than : List String := []) (versus : List Guard := []) : Pref :=
  { name := nm, op := op, sameAsLast := [], guard := guard, value := v, than := than, versus := versus }

def prefs : List Pref := [
  pref "self-unknown-first" "self-unknown" [.cmp "r" "var" .eq (.lit 0)] .best,
  pref "complement-first" "complement" [.flag "w1" "contra" true] .best,
  pref "guess-first" "guess-white" [.cmp "wd" "done" .eq (.lit 0)] .best,
  pref "guess-black-first" "guess-black" [.cmp "wd" "done" .eq (.lit 0)] .best,
  pref "consider-last" "consider-knows" [.cmp "w" "modeled" .eq (.lit 0)] .worst,
  pref "assume-black-late" "assume-black" [.cmp "m" "value" .eq (.lit 0)] .worst,
  pref "assume-white-late" "assume-white" [.cmp "m" "value" .eq (.lit 0)] .worst,
  pref "assume-before-consider" "assume-black" [] .better ["consider-knows"],
  pref "assume-white-before-consider" "assume-white" [] .better ["consider-knows"],
  -- prefer the deeper model; prefer to model a wizard who has no model yet
  pref "prefer-deeper" "consider-knows" [] .reject ["consider-knows"] [.link "other-k" "parent" "k"],
  pref "prefer-new-names" "consider-knows" [] .reject ["consider-knows"]
    [.noneSuch viewT [("owner", .eq, .get "other-w" "wiz")], .someSuch viewT [("owner", .eq, .get "w" "wiz")]]]

def initial : List Named := [
  { holder := "world", name := "world", vals := [("done", 0), ("nviews", 1)] },
  { holder := "view", name := "A-view", vals := [("vid", 1), ("owner", 1), ("depth", 1)] },
  { holder := "rec", name := "A", vals := [("wiz", 1), ("mark", 0), ("var", 0), ("modeled", 0), ("aguess", 0)],
    links := [("view", "A-view"), ("sib", "B"), ("sib", "C")] },
  { holder := "rec", name := "B", vals := [("wiz", 2), ("mark", 1), ("var", 0), ("modeled", 0), ("aguess", 0)],
    links := [("view", "A-view"), ("sib", "A"), ("sib", "C")] },
  { holder := "rec", name := "C", vals := [("wiz", 3), ("mark", 1), ("var", 0), ("modeled", 0), ("aguess", 0)],
    links := [("view", "A-view"), ("sib", "A"), ("sib", "B")] }]

def assumptions : List Assumption := [
  { id := "A1", text := "Wizards and colours are numbers (A 1, B 2, C 3; white 1, black 2; 0 = has not guessed) and the trace writes them as numbers; the originals write names and colours." },
  { id := "A2", text := "Views and their records are objects made at run time (consider-knows), as in the originals; each record links to the other records of its view (`sib`) and to the same wizard's records in the views modelled from it (`sub`), and an unknown spot is a shared variable object (`markvar`), as the originals share mark objects between views." },
  { id := "A3", text := "The deductions are derived flags that retract when their grounds go (V2's elaborations): own record; white / black (given, deduced from two black spots seen, or known in the model of him and not contradicted there); blackish (black or assumed black, for deducing); guess white / black (own known spot, observed guess, or the guess in the model of him); contradiction (predicted to guess but observed not to have guessed, or two guesses)." },
  { id := "A4", text := "Ascribing knowledge copies known spots, unknown-spot variables and observed guesses (only) into a modelled view, for the wizards other than its owner; the originals' ascribe-knowledge also copies derived guesses." },
  { id := "A5", text := "Assume-black and assume-white are two operators (white only once black is tried) instead of one assign operator with a preference for black." },
  { id := "A6", text := "Complement does not remove the contradicting record's guess and contradiction (they are derived and retract once the assumption is replaced); the originals remove them explicitly." },
  { id := "A7", text := "Search control as in the originals: self-unknown, complement and the final guess best; consider-knows and assume worst; assuming before modelling; reject modelling from a shallower view when a deeper one can be modelled, and modelling a wizard who already has a model when one without can be." }]

def agent : Agent where
  schema := schema
  init := []
  objs := initial
  derive := []
  flags := flags
  ops := [selfUnknown, considerKnows, ascribeMark, ascribeUnknown, ascribeGuess, assume 2, assume 1, complement,
    detect true, detect false]
  goal := { ty := worldT, vals := [("done", 1)] }
  prefs := prefs
  method := .random
  assumptions := assumptions

def variants : List (String × Agent × List String) := [("wizards", agent, ["wizards V1", "wizards V2"])]

def conventionsOk : Bool := variants.all (fun v => check v.2.1 == [])
theorem conventions : conventionsOk = true := by native_decide

/-! ## Every run guesses white -/

/-- Follow every choice the preferences leave (Soar chooses among them at random), level by level,
for at most `n` decisions (equal states merged): `true` when every run reaches the goal and no
state ever proposes guessing black. -/
def allRunsWhite (ag : Agent) : Nat → List TState → Bool
  | _, [] => true
  | 0, _ => false
  | k + 1, sts =>
    let open_ := sts.filter (!ag.isGoal ·)
    let nexts := open_.map fun st => ag.prefCands st none
    !(nexts.any (·.isEmpty)) &&
    !(nexts.any (·.any (·.1.name == "guess-black"))) &&
    let succ := nexts.flatMap (·.map (·.2.2))
    let uniq := succ.foldl (fun acc st => if acc.any (norm · == norm st) then acc else acc ++ [st]) []
    allRunsWhite ag k uniq

/-- Whatever Soar chooses among tied operators, A guesses white within 20 decisions, and guessing
black is never proposed. -/
theorem always_white : allRunsWhite agent 20 [agent.initial] = true := by native_decide

end Agent.Wizards
