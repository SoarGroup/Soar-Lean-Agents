import Agent.Families.WaterJug
import Agent.RoundTrip.WaterJugReform
/-!
# Round trip for the Water Jug family

`WaterJugReform.lean` was written by a separate model from the blind English review alone
(review/blind-review.md), without the Lean description or the original agents. Here it is
compared with the description the English came from.
-/
namespace Agent.RoundTrip

/-- For each variant: the parts that differ (empty = structurally equal, docs and assumptions
aside; tie heuristics compared by meaning). -/
def report : List (String × List String) :=
  WaterJug.variants.map fun (n, a, _) =>
    match (Reform.WaterJug.variants.find? (·.1 == n)) with
    | some (_, b) => (n, diffCore a b)
    | none => (n, ["missing in the re-formalization"])


/-- Parts changed by decisions made after the round trip of 5 November 2026: the task constraint
(A2) and `holding` in the schema, hierarchical fill as real sub-operators (A5), and no chunking
singletons in water-jug-tie-chunk (R16), all decided
6 November. -/
def changedSince : List String := ["schema", "constraints", "operator fill", "learning"]

/-- The round trip is exact for every variant except in the parts changed since (above). Rerun the
blind back-translation and re-formalization to close this. -/
theorem water_jug_round_trip : report.all (fun r => r.2.all (changedSince.contains ·)) = true := by decide

end Agent.RoundTrip
