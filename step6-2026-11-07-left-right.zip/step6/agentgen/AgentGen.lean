import Agent
import Lean.Data.Json
/-! `agentgen FAMILY OUT.json`: the generated projects of a family as JSON (files with Soar text,
commands, the English, and which originals each variant replaces). `tools/vsproject.py` writes
them out as VisualSoar projects. -/
open Agent Lean

def schemaJson (s : Schema) : Json :=
  let attr (d : AttrDecl) : Json := Json.mkObj [("name", d.name), ("multi", d.multi), ("derived", d.derived),
    ("doc", d.doc), ("type", match d.ty with
      | .int => Json.mkObj [("kind", "int")]
      | .sym cs => Json.mkObj [("kind", "sym"), ("choices", Json.arr (cs.map Json.str).toArray)]
      | .obj t => Json.mkObj [("kind", "obj"), ("type", t)])]
  Json.mkObj [("task", s.task), ("state", Json.arr (s.stateAttrs.map attr).toArray),
    ("types", Json.arr (s.types.map fun t => Json.mkObj [("name", t.name), ("doc", t.doc),
      ("attrs", Json.arr (t.attrs.map attr).toArray)]).toArray)]

/-- Soar text of a production. `Soar.Production.toSoar` does not print the `:template` flag, so an
RL template is loaded as an ordinary RL rule (one value for all its matches). With `templates`
the flag is printed after the name. Water Jug used the old text until 6 Nov 2026, when JL decided
to regenerate water-jug-rl with real templates. -/
def prodText (templates : Bool) (p : Soar.Production) : String :=
  let s := p.toSoar
  if templates && p.template then
    match s.splitOn "\n" with
    | first :: rest => "\n".intercalate (first :: "   :template" :: rest)
    | [] => s
  else s

def variantJson (name : String) (a : Agent) (replaces : List String) (templates : Bool := false) : Json :=
  let files := (compile a).map fun f => Json.mkObj [("path", f.path), ("kind", f.kind),
    ("rules", Json.arr (f.prods.map fun p => Json.str (prodText templates p)).toArray),
    ("cmds", Json.arr (f.cmds.map Json.str).toArray)]
  Json.mkObj [("name", name), ("task", a.schema.task), ("replaces", Json.arr (replaces.map Json.str).toArray),
    ("selection", needsSelection a), ("check", Json.arr ((check a).map Json.str).toArray),
    ("english", english a), ("schema", schemaJson a.schema),
    ("ops", Json.arr (a.ops.map fun o => Json.str o.name).toArray),
    ("files", Json.arr files.toArray)]

def main (args : List String) : IO Unit := do
  match args with
  | ["water-jug", out] =>
    let vs := WaterJug.variants.map fun (n, a, r) => variantJson n a r (templates := true)
    IO.FS.writeFile out (Json.arr vs.toArray).pretty
    IO.println s!"{vs.length} variants written to {out}"
  | ["mac", out] =>
    let vs := Mac.variants.map fun (n, a, r) => variantJson n a r (templates := true)
    IO.FS.writeFile out (Json.arr vs.toArray).pretty
    IO.println s!"{vs.length} variants written to {out}"
  | [fam, out] =>
    -- the small families of 6 Nov 2026 (RL templates printed with `:template`)
    let fams : List (String × List (String × Agent × List String)) :=
      [("hello-world", HelloWorld.variants), ("counting", Counting.variants), ("pyramid", Pyramid.variants), ("eight-puzzle", EightPuzzle.variants), ("blocks-world", BlocksWorld.variants), ("arithmetic", Arithmetic.variants), ("knights", Knights.variants), ("kenken", KenKen.variants), ("wizards", Wizards.variants), ("tictactoe", TicTacToe.variants), ("left-right", LeftRight.variants)]
    match fams.lookup fam with
    | some vs0 =>
      let vs := vs0.map fun (n, a, r) => variantJson n a r (templates := true)
      IO.FS.writeFile out (Json.arr vs.toArray).pretty
      IO.println s!"{vs.length} variants written to {out}"
    | none => IO.eprintln "usage: agentgen (water-jug | mac | hello-world | counting | pyramid | eight-puzzle | blocks-world) OUT.json"
  | _ => IO.eprintln "usage: agentgen (water-jug | mac | hello-world | counting | pyramid | eight-puzzle | blocks-world) OUT.json"
