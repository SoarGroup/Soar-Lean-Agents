# Arithmetic — step 6

Lean: `agentgen/Agent/Families/Arithmetic.lean`.

Variant:
- `arithmetic` (3 columns, 10000 problems, chunking on) replaces arithmetic V5, arithmetic V6 and ChunkingDemoTests_Demo_Arithmetic V1 (a copy of V5).

The task: generate random three-column addition or subtraction problems (subtraction answers positive), solve each column right to left by retrieving digit facts, and count the problems; halt at count 0.

## Structure

Top-level operators:
- `choose-operation`, `generate-digit1`, `generate-digit2`: chosen at random.
- `process-column` (one column, right to left): carried out in a substate. Its sub-operators:
  - `get-digit2`: nested substate; `increment-digit2` adds the carry or borrow into the column to the bottom digit, from an inc-fact.
  - `add-digits`: retrieves the sum and carry from an add-fact.
  - `borrow`: nested substate; `add-ten` adds ten to the top digit, from a ten-fact, and borrows from the next column.
  - `subtract-digits`: retrieves the difference from a sub-fact.
  - `write-result`: writes the answer digit and the carry or borrow out; these are the results.
- `finish-problem`: writes the problem and its answer, then counts it.

New general DSL features:
- **Nested sub-operators.** `SubOp.subs` names sub-operators in the library `Agent.subLib`. Each nested level has its own substate and locals (`local`); `up` is its parent substate.
  - In Soar, a nested level is a high-level operator whose folder sits under its parent's. Its substate gets `^task-state`.
  - In the semantics, `Agent.runNested` runs a nested level.
- A sub-operator that has sub-operators needs no apply case.

The outputs of all earlier families are byte-identical after these changes (water-jug, mac, hello-world, counting, pyramid, eight-puzzle, blocks-world).

New convention (proposed, open): **SUB-013**, nested substates reach the task through `^task-state`, and a nested level's results go to its parent substate.

## Results (Soar 9.6.5, 5 seeds, 3000 decisions)

| Agent | Problems | Chunks | Wrong |
|---|---|---|---|
| arithmetic V5 / ChunkingDemo V1 | 148–149 | 28–29 | 0 |
| arithmetic V6 | 149–150 | 27–30 | 0 |
| `arithmetic` (regenerated) | 269 | 8 | 0 of 1345 checked |
| `arithmetic`, chunking off | 104–110 | 0 | 0 of 536 checked |

Correctness was checked by the harness from the problem and answer that `finish-problem` writes. The originals were checked by their own "Results Incorrect" elaborations.

The regenerated agent solves more problems for two reasons:
- Generation takes one fewer decision per problem (no substate, A2).
- Its chunks are more general than V5's. Each chunk tests the fact objects through variables, so 8 chunks (one per case: add or subtract, carry or borrow in or not, borrow out or not) cover all digit pairs; V5's 29 are more specific.

Soar vs soar-lean (`leancmp/`):
- With chunking: MATCH (200 decisions, 1635 WMEs, 3 chunks).
- Without chunking: MATCH (200 decisions, 1391 WMEs).

## Theorems

- `conventions`, by `native_decide`: the fact list is too large for kernel `decide`.
- `every_column`: every top digit, bottom digit, carry or borrow in, and operation (400 cases). Run concretely through process-column's sub-operators, including the nested `get-digit2` and `borrow` substates, each case gives process-column's specified effect and the right answer digit with the carry or borrow out.
- `two_columns`: 3,300 whole two-column problems solved correctly.
- `three_columns`: 1,400 three-column problems (a sample) solved correctly.

The family takes about 4 minutes to build, almost all of it these runs.

## Assumptions (open, for JL)

- **A1. The task.** Random 3-column addition or subtraction, with positive subtraction answers. Each column is solved by fact retrieval. Halt at count 0 (V5 uses count 10000 and stop-arithmetic).
- **A2. Generation at the top level.** Generation is done by top-level operators chosen at random, not in V5's generate-problem substate. A substate whose sub-operators are chosen at random has no specified effect to refine. The choices are the same; each problem takes one fewer decision and there are no generation chunks.
- **A3. Reused columns.** The three column objects are reused for every problem; `gen1`, `gen2` and `done` hold the problem number. V5 instead builds a new linked column structure per problem.
- **A4. Carries and borrows.** The carry or borrow into a column is a problem attribute, added to the bottom digit in a nested substate.
  - V5 adds a carry to the top digit (`get-digit1` substate).
  - V5 borrows by decrementing the next column's top digit, recursively.
  - Here, a borrow adds ten to the top digit (nested `borrow` substate) and passes 1 to the next column. The answers are the same, with no recursion through columns.
- **A5. Facts.** The facts are task objects made at initialization, not made by V5's generate-facts operator. The tables include a bottom digit of 10, which can occur after a carry or borrow.
- **A6. Representation.** Operations are numbers. Unset values are represented by problem numbers. A carry out of the leftmost column is written, but no new column is made for it (V5 new-column).
- **A7. Checking.** Correctness is checked in Lean and by the harness, not by V5's check-and-halt elaborations.

## Not replaced

- **arithmetic V3, V11:** facts are in semantic memory (`smem --add`, retrieval); this needs a semantic-memory construct.
- **arithmetic V4, V9, V10, arithmetic-save V1:** the same task with other counts and learning settings, and other column procedures:

  | Original | Problems in 3000 decisions | Chunks |
  |---|---|---|
  | V4 | 72–75 | 0 |
  | V9 | 50–55 | 0 |
  | V10 | 135 | about 385 |
  | arithmetic-save V1 | 69–75 | 0 |

  These could be parameters of `mk` (count, learning) only if their procedures are the same, which is not yet checked.
- **arithmetic-solve-problem V1:** 10 problems with chunking, then halt. It is a likely `mk` variant (count 10), not yet checked against its procedure.
- **addition, subtraction, multiplication V1:** one fixed problem each (about 30 decisions, then halt). Multiplication needs a multiplication procedure.
- **algebra V3:** equation solving; a different task.
- **ChunkingDemo _expected V1:** the demo's expected chunks, as a data file.

## Minor

- Soar warns "two equality tests in one conjunctive test" for `finish-problem`'s column bindings (`{ <c1-pos> 1 }`). The variable is unused, so this is harmless.
- The compiler could drop the variable when an equality constant is present. That would change every family's output, so it is left for now.
