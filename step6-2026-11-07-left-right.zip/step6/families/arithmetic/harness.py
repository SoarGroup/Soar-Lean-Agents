"""Task-level runs of Arithmetic agents in Soar 9.6.5 (soar_sml).

usage: harness.py DIR LOADFILE [--cap N] [--seeds a-b]

Sources the agent, sets srand SEED after loading, runs up to the cap (or until halt), and
records: halted, decisions, problems finished (top-level finish-problem / finish-* operators
selected), problems reported incorrect (the agents' own check: "Results Incorrect"), the
operations seen (addition / subtraction in the output), chunks, and the last answer written."""
import argparse, json, os, re
from collections import Counter
import soar_sml as sml

TOP_OP = re.compile(r'^\s*\d+:    O: \S+ \(([^)]+)\)', re.M)

def run(d, load, cap, seed):
    k = sml.Kernel.CreateKernelInCurrentThread(True, 0)
    a = k.CreateAgent('h'); out = []
    a.RegisterForPrintEvent(sml.smlEVENT_PRINT, lambda *x: out.append(x[-1]), None)
    os.chdir(d); a.ExecuteCommandLine('cd ' + d)
    src = a.ExecuteCommandLine('source ' + load)
    a.ExecuteCommandLine(f'srand {seed}'); a.ExecuteCommandLine('watch 1')
    n = 0; halted = False; ops = Counter(); text = []
    while n < cap:
        out.clear(); r = a.ExecuteCommandLine('run 100 -d'); n += 100
        txt = ''.join(out) + r
        ops.update(TOP_OP.findall(txt)); text.append(txt)
        if 'halted' in txt.lower() or 'interrupt' in txt.lower():
            halted = True; break
    alltxt = ''.join(text)
    m = re.search(r'(\d+) decisions', a.ExecuteCommandLine('stats'))
    dec = int(m.group(1)) if m else n
    chunks = len(re.findall(r'^chunk', a.ExecuteCommandLine('print --chunks'), re.M))
    k.Shutdown()
    finished = sum(v for kk, v in ops.items() if kk.startswith('finish-problem') and 'generation' not in kk)
    # generated agents: finish-problem writes "problem op K top D.. bottom D.. answer D.. carry C"
    gen_ok = gen_bad = 0
    for m in re.finditer(r'problem op (\d) top ([\d ]+?) bottom ([\d ]+?) answer ([\d ]+?) carry (\d)', alltxt):
        k = int(m.group(1)); num = lambda g: int(g.replace(' ', ''))
        t, b, r, c = num(m.group(2)), num(m.group(3)), num(m.group(4)), int(m.group(5))
        n = len(m.group(4).replace(' ', ''))
        got = r + c * 10 ** n if k == 1 else r - c * 10 ** n
        want = t + b if k == 1 else t - b
        if got == want: gen_ok += 1
        else: gen_bad += 1
    return dict(seed=seed, checked=gen_ok, wrong=gen_bad, decisions=dec, halted=halted, finished=finished,
                incorrect=alltxt.count('Results Incorrect'), ops=dict(ops), chunks=chunks,
                additions=alltxt.count('addition'), subtractions=alltxt.count('subtraction'),
                tail=alltxt[-300:], source_errors='rror' in src)

if __name__ == '__main__':
    p = argparse.ArgumentParser(); p.add_argument('dir'); p.add_argument('load')
    p.add_argument('--cap', type=int, default=3000); p.add_argument('--seeds', default='1-5')
    o = p.parse_args(); d = os.path.abspath(o.dir); lo, hi = map(int, o.seeds.split('-'))
    for s in range(lo, hi + 1): print(json.dumps(run(d, o.load, o.cap, s)), flush=True)
