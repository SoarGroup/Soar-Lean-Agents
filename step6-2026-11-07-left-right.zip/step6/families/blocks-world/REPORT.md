# Blocks World — step 6 (in progress)

Lean: `agentgen/Agent/Families/BlocksWorld.lean`. 75 originals, flattened in `task/`, all run in Soar 9.6.5 (`results/orig`, 10 seeds, cap 2000 decisions; summary in `compare.csv`).

## Stage 1 (6 Nov 2026): changing links, and the look-ahead variant

### New general DSL features
- **Changing links.** An operator may set an object-valued attribute to one of its object parameters (`Expr.obj p`: `block.on := obj dest`); the semantics keeps such links in the state (as the target's index); `check` types them. Static links (e.g. cells' neighbours) are unchanged.
- **Comparing with an object**: `Atom.obj p` (`block.on ≠ obj dest`; inside `noneSuch`: "nothing is on `p`").
- **Goal by links** (`Goal.links`): named objects linked as desired (A on B …); `^desired` links to the task's own objects, and the success test compares the targets by name (look-ahead copies point to copies).
- **Proposal disjunction** (`Operator.proposeOr`): one proposal rule per disjoint alternative ("dest is the table" / "dest is a clear block").
- **Look-ahead-only preferences** (`Pref.inLookahead`), and links are optional on named objects (the table rests on nothing).

### Variant `blocks-world-look-ahead` (3 blocks: C on A, A and B on the table → A on B on C)

Replaces blocks-world-lookahead V1–V4, BW-LA V1/V2, BW-LA-X V1, blocks-world-look-ahead V1/V2, ChunkingDemoTests_Demo_Blocks_World_Look_Ahead V1, FunctionalTests_testBlocksWorldLookAhead V1.

| Agent | Solved (10 seeds) | Median decisions | Chunks |
|---|---|---|---|
| blocks-world-lookahead V1, V3; BW-LA V1, V2; BW-LA-X V1 (book versions) | 4/10 | 2000 (loops) | 9–11 |
| blocks-world-look-ahead V1 / V2 | 6/10 / 10/10 | 51 / 30 | 6 / 5 |
| ChunkingDemo Look_Ahead V1 | 10/10 | 43 | 6 |
| FunctionalTests LookAhead V1 | 10/10 | 51.5 | 0 (chunking off) |
| blocks-world-lookahead V2, V4 | 0/10 | — | (V4 never moves) |
| **generated blocks-world-look-ahead** | **5/10** | — (5 loop to the cap) | 7 |

The generated agent behaves like the book versions: when it does not solve, it loops (chunks lock a cycle, as in M&C). **Why the demo solves 10/10:** its copy of the selection library is edited — `selection*pass-back-success` passes back only `required-success` (the book library also passes back `success`/`partial-success`), and the look-ahead operator is required with all others rejected. Passing back success from a deeper level is exactly what made M&C's look-ahead chunks loop ("success" = goal still reachable). This bears on the M&C chunk question.

Soar 9.6.5 vs soar-lean: MATCH (`leancmp/chunk.out`: 23 decisions, 54 WMEs, 7 chunks).

Theorems: `conventions`; `three_shortest` (3 moves, no fewer).

### Assumptions (A1–A4, in BlocksWorld.lean)
- A1 representation: one object type for blocks and table with `name`, `table` (1 for the table) and a changing link `on`, instead of `^ontop` objects and `^type`.
- A2 move-block(block, dest): two disjoint proposal rules (dest = table / dest = clear block), instead of an elaborated `^clear`.
- A3 goal: desired `on` of every block (`^desired` links), success halts.
- A4 look-ahead: library as is, no duplicate detection, chunking; moving the block just moved is rejected only in look-ahead (as the originals).

## Stage 2 (6–7 Nov 2026): simple control and operator subgoaling

### New general DSL features
- **Recursive derived flags** (`Agent.flags`): a 0/1 attribute elaborated from base cases and along a link (Blocks World's "in place": the table; a block on what the goal puts it on, which is in place). Several `Flag`s with one attribute give alternative base cases ("clear": the table, or nothing on it).
- **Goal-link guard** (`Guard.desired o attr t`): the goal puts `o` on `t` (compared by name, so it also works in look-ahead copies).
- **Flag guard** (`Guard.flag`) and **binary "better than every other" preference** (`HVal.better`, Soar `o > o2`); the semantics applies better before best/worst, as Soar's decision procedure.
- **Operator subgoaling** (`Operator.pre`, `pregoals`, `Agent.subgoaling`, `Guard.wants`): proposals say when an operator is relevant; its preconditions are required only by the apply rules; selected without them, it gets a substate named like the task that shares the task's objects and has the preconditions as `^desired`; preferences can test what the substate wants. `Agent.runOpSub` follows this deterministically (outermost pending operator applies as soon as its preconditions hold).

### Variants

| Variant | Replaces | Original | Generated |
|---|---|---|---|
| blocks-world-simple (5 blocks) | BW-Simple V1/V2, blocks-world-simple V2–V4 | 10/10, 7–8 decisions | 20/20, 6–7 moves, 7–8 decisions |
| blocks-world-simple-3 | blocks-world V2, V3 | 10/10, 4 decisions | 20/20, 3 moves, 4 decisions |
| blocks-world-operator-subgoaling | blocks-world-operator-subgoaling V1, V3, V6; BW-Op-Subgoal V1; FunctionalTests OperatorSubgoaling V1 | 10/10, 5 decisions | 20/20, 5 decisions |
| blocks-world-operator-subgoaling-chunk | blocks-world-operator-subgoaling V4; ChunkingDemo Operator_Subgoaling V1 | 10/10, 5 decisions, 1 chunk | 20/20, 3 decisions, 3 chunks |

All four MATCH soar-lean (`leancmp/plain.out`, `leancmp/chunk.out`). Theorems: `five_shortest` (6 moves), `simple_three` (the simple control decides every step: 3 moves), `opsub_three` (operator subgoaling decides every step: 3 moves).

Harness fix: several originals keep their blocks under `^world` (blocks-world-simple V3/V4, blocks-world-lookahead V2, blocks-world-hierarchical V4, operator-subgoaling V3, RL V3, …); they were scored 0/10 by mistake and are 10/10 (`compare.csv` updated).

### Assumptions added
- A5 simple variants: P6 (best: an out-of-place block to the table) and P7 (better: onto the in-place object the goal puts it on); "in place" as a recursive flag; blocks-world V2's three stray RL template rules dropped.
- A6 operator subgoaling: move-block proposed when relevant (a block, a different destination it is not on); preconditions block clear and destination clear (a "clear" flag: the table, or nothing on it); substate goals `^clear` both; the originals' three preferences (avoid clobbering what the subgoal wants clear: worst; a move the goal asks for: best; moving the block that sits on something the subgoal wants clear: best).

## Still to do in this family
- Look-ahead with state evaluation (+RL), operator subgoaling with RL, RL, hierarchical (pick-up/put-down with a gripper simulated through the output link — needs I/O), hierarchical look-ahead, HRL.
- Not replaced (to confirm): blocks-world-epmem, count-blocks, cube-stack, opsub-core, blocksworld V1–V3, blocks-opsub, the `_expected` chunk files.
