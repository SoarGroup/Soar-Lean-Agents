# blocks-world

## The task

The task state holds several values of `object`, each a object. The blocks and the table.

A object has `name` (one of ), `table` (an integer), `on` (a object).

Initially the task state has:
- a `object` named table with table 1
- a `object` named A with table 0; its `on` is table
- a `object` named B with table 0; its `on` is table
- a `object` named C with table 0; its `on` is A
Links between objects never change.

**Goal.** Some object has . When the goal holds in the task state, the agent reports success and halts.

## Operators

An operator's changes are made together: every value on the right is read before any change.

**move-block(block: object, dest: object).** Proposed when block.table = 0 and no object has on = block and block and dest are different objects and block.on ≠ dest. Move a clear block onto the table or onto another clear block.
- and when one of these holds: dest.table = 1; or dest.table = 0 and no object has on = dest.
- Effect: block.on := dest.

## Choosing among proposed operators

Any proposed operator may be chosen; the choice is random.

The agent remembers the last task operator applied (its name and parameters). Search-control preferences:
- **out-of-place-to-table**: a proposed move-block whose  is best. Move a block that is not in place to the table.
- **onto-desired-in-place**: a proposed move-block whose  is better than every other proposed operator. Move a block onto what the goal puts it on, when that is in place.

## Learning

None.

## Assumptions (added; not in the task description)

- **A1** [open] Representation: one object type for blocks and the table, with `name`, `table` (1 for the table) and a changing link `on`. The originals keep `^ontop` objects (`^top-block`, `^bottom-block`) and `^type block/table`; `move-block` changes an ontop's bottom block, here the moved block's `on` (a changing link, `block.on := dest`).
- **A2** [open] move-block(block, dest): proposed when the block is clear and not already on dest, and dest is the table or another clear block (two proposal rules, disjoint). The originals elaborate `^clear` (blocks with nothing on them, and always the table) and propose from it.
- **A3** [open] Goal: the desired `on` of every block, as `^desired` links to the task's own objects (the originals' desired ontops); success halts at the top state.
- **A5** [open] Simple variants: the originals' P6 (moving a block that is not in place to the table is best) and P7 (moving a block onto the in-place object the goal puts it on is better than every other move, binary preferences); "in place" is a derived flag (elaborated recursively along `on`, as the originals' `^inplace-object`). The originals elaborate success from in-place objects; here the goal is the desired links. blocks-world V2 also has three RL template rules with no reward or RL settings; they are dropped.
- **A4** [open] Look-ahead variant: the selection library, no duplicate-state detection (the originals have none), chunking on. As in the originals, moving the block just moved is rejected inside look-ahead states only (at the top state it may be the only move).
