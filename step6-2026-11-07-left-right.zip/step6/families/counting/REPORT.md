# Counting — step 6

Lean: `agentgen/Agent/Families/Counting.lean`.

Variants:
- `count-up` (counts to 100 at the top state) replaces counter V1.
- `count-in-substate` (counts 1 → 75000 through an `increment` sub-operator) replaces count-and-die V1.

Not replaced:
- count V1: retrieves successor facts from semantic memory; needs an smem construct.
- count-epmem V1: an episodic-memory test.
- count-test V1–V3: architecture regression test; six of its nine tests use mechanisms the conventions exclude (monotonic counting, superstate operators proposed from state no-changes, preferences made in tie substates).

| Variant | Original | Regenerated |
|---|---|---|
| count-up vs counter V1 | 20/20 reach 100, at decision 4 | 20/20, decision 101, then halts |
| count-in-substate vs count-and-die V1, cap 500 | 0/20 | 0/20 |
| same, cap 80000 | 20/20, halts at 75005 | 20/20, halts at 75002 |

Bug in counter V1: its `count` operator is never re-selected, so the apply rule refires 50 times per decision (max-elaborations); impasses nest until the goal-depth limit halts Soar at decision 102 with count 5000.

Soar vs soar-lean: MATCH (count-in-substate compared over 2000 decisions; the full 75002-decision run timed out in soar-lean).

Theorems: `conventions`, `count_up_shortest` (100), `count_up_constraints`, `in_substate_shortest` (1 abstract operator), `in_substate_refines` (all 74999 increments give exactly the operator's effect), `constraints_hold`.

Open assumptions:
- A1: (see Counting.lean)
- A2: the limit of 100 for counter V1 is a choice; the original never halts.
- A3: count-and-die's substate-local count and phases become a task-object count changed by results.
- A4: the hierarchical operator is proposed through a relevance elaboration.
- A5: limits are Lean constants.

Conventions used: "hierarchical operators keep their identity" (new, proposed L3).

## After A3 revised (JL, 6 Nov 2026): the count is local to the substate

`count-to-limit` now keeps its count in its own substate: `init-local` makes `^count` from the counter's value, `increment` adds one there (no result), `done` gives the final count to the task counter (one result), and the count is removed with the substate. New DSL feature: `Operator.locals` (substate-local integer attributes, `local.<attr>` in sub-operators; `refinesSub` models them).

Runs (cap 80000, seeds 1–4): 4/4 solved, halt at decision 75004 (original count-and-die V1: 75005; previous variant with a result per increment: 75002). Soar vs soar-lean: MATCH (2000 decisions, 43 WMEs). `in_substate_refines` re-proved (74999 local increments + done give the operator's effect).
