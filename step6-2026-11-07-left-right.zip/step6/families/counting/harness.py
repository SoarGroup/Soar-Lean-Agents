"""Task-level runs of Counting agents in Soar 9.6.5 (soar_sml).

usage: harness.py DIR LOADFILE --target N [--cap N] [--seeds a-b] [--step K]
For each seed: source the agent, `srand SEED`, run K decisions at a time (default 1) up to the cap,
and record when a count first equals the target: the originals keep it as `^count` (counter V1 on
the top state, count-and-die V1 on the substate of `one`), the regenerated agents as `^value` of a
`^counter` object. Also: whether the agent halted, the largest count seen, decisions, and whether Soar hit its goal-depth limit (impasses nested until it halts). Prints one
JSON object per run. With --step K > 1, a halt after a count within K of the target counts
as reaching it (checked only every K decisions).
"""
import argparse, json, os, re
import soar_sml as sml

def counts(a):
    """Counts held now: `^count` on any state (originals), or `^value` of the top state's `^counter`
    objects (regenerated; not the `^desired` copy, which holds the target)."""
    vals = [int(x) for x in re.findall(r'\^count (-?\d+)', a.ExecuteCommandLine('print (* ^count *)'))]
    for c in re.findall(r'\^counter (\S+?)[\s)]', a.ExecuteCommandLine('print s1')):
        vals += [int(x) for x in re.findall(r'\^value (-?\d+)', a.ExecuteCommandLine(f'print {c}'))]
    return vals

def run(d, load, cap, seed, target, step):
    k = sml.Kernel.CreateKernelInCurrentThread(True, 0)
    a = k.CreateAgent('h')
    out = []
    a.RegisterForPrintEvent(sml.smlEVENT_PRINT, lambda *x: out.append(x[-1]), None)
    a.ExecuteCommandLine('cd ' + d)
    src = a.ExecuteCommandLine('source ' + load)
    a.ExecuteCommandLine(f'srand {seed}')
    reached, halted, best, n, depth_limit = None, False, None, 0, False
    while n < cap:
        out.clear()
        a.RunSelf(min(step, cap - n))
        m = re.search(r'(\d+) decisions', a.ExecuteCommandLine('stats'))
        n = int(m.group(1)) if m else n + step
        cs = counts(a)
        if cs: best = max(cs) if best is None else max(best, max(cs))
        if reached is None and target in cs: reached = n
        txt = ''.join(out)
        if 'infinite loop' in txt: depth_limit = True
        if 'halted' in txt or 'Soar must halt' in txt or 'This Agent halted' in txt:
            halted = True
            # with --step K > 1 the target may be passed between checks: a halt after a count within
            # K of the target counts as reaching it (the originals halt only after the count)
            if reached is None and best is not None and target - step <= best <= target: reached = n
            break
    k.Shutdown()
    return dict(seed=seed, decisions=n, halted=halted, solved=reached is not None,
                decisions_to_target=reached, max_count=best, goal_depth_limit=depth_limit, source_errors='rror' in src)

if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('dir'); p.add_argument('load')
    p.add_argument('--target', type=int, required=True)
    p.add_argument('--cap', type=int, default=500)
    p.add_argument('--seeds', default='1-20')
    p.add_argument('--step', type=int, default=1)
    o = p.parse_args()
    d = os.path.abspath(o.dir)
    lo, hi = map(int, o.seeds.split('-'))
    for s in range(lo, hi + 1):
        print(json.dumps(run(d, o.load, o.cap, s, o.target, o.step)), flush=True)
