# count-up

## The task

The task state holds several values of `counter`, each a counter. The counter.

A counter has `value` (an integer).

Initially the task state has:
- a `counter` with value 0

**Constraint (part of the task).** Every counter always has self.value ≥ 0 and self.value ≤ 100 (with `self` the counter); every operator must preserve this.

**Goal.** Some counter has value 100. When the goal holds in the task state, the agent reports success and halts.

## Operators

An operator's changes are made together: every value on the right is read before any change.

**count(counter: counter).** Proposed when counter.value < 100. Add one to the count.
- Effect: counter.value := counter.value + 1.

## Choosing among proposed operators

Any proposed operator may be chosen; the choice is random.

## Learning

None.

## Assumptions (added; not in the task description)

- **A1** [accepted] The task: a counter starts at a value and is increased by one until it reaches a limit; then the agent halts (goal as `^desired`, success rule, halt at the top state).
- **A2** [accepted] counter V1 counts from 0 forever and never halts. Here it stops at 100 (a limit chosen for the comparison, not in the original; the harness measures the decisions to reach 100 in both).
- **A3** [revised] count-and-die V1 counts from 1 to 75000 with a local count in the substate of `one`, then moves the top state from phase one to two, and `two` halts. Here the count is a task object: the sub-operator `increment` changes it in the task state (a result each time), the substate ends when the count reaches the limit, and the goal halts. The phases are bookkeeping and are dropped; so is the substate-local count (its point in the original, if any, was to make a large substate that is then removed — 'die'). REVISED (JL, 6 Nov 2026): the original structure is kept: the count is local to the substate of `count-to-limit` (made by `init-local` from the counter's value, increased by `increment`, removed with the substate); `done` gives the final count to the task counter (one result). The phases are still dropped (the goal halts).
- **A4** [accepted] Operators carried out by sub-operators that change what their proposal tests are proposed through a relevance elaboration (`^count-to-limit-relevant`), so they keep their identity across the substate's results (new general compile rule, see DSL.lean).
- **A5** [accepted] Limits are constants of the variant (Lean parameters), not `^max` attributes as in count-and-die: the limit is not changed by any operator.
