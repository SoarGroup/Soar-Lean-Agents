# Eight / Fifteen Puzzle — step 6

Lean: `agentgen/Agent/Families/EightPuzzle.lean`. Generated: `gen/eight-puzzle.json`, `projects/`.

## Variants

| Variant | Replaces |
|---|---|
| `eight-puzzle` (3×3, the originals' start and goal) | eight-puzzle V1–V5, eight-puzzle-desired-binding V1, FunctionalTests_testEightPuzzle V1, ChunkingDemoTests_Demo_Eight_Puzzle V1 |
| `fifteen-puzzle` (4×4, the originals' start and goal) | fifteen-puzzle V1–V4 |

Both use the originals' method: one-step look-ahead with the selection library, the tried state evaluated by the moved tile (+1 into its desired cell, −1 out of it, 0 otherwise), the move that puts the last tile straight back rejected, chunking on.

Not replaced: ChunkingDemoTests_Demo_Eight_Puzzle_expected V1 (a file of expected chunks), load-8p V1 (a language-comprehension agent that reads "eight puzzle"; misfiled).

## Task-level comparison (20 seeds, cap 3000 decisions; `compare.csv`)

| Agent | Solved | Moves | Median decisions | Median chunks |
|---|---|---|---|---|
| eight-puzzle V3, V4, V5, ChunkingDemo | 20/20 | 5–9 (median 7) | 24 | 8.5 |
| eight-puzzle-desired-binding V1 | 20/20 | 5–9 (median 7) | 21.5 | 8 |
| FunctionalTests_testEightPuzzle V1 | 20/20 | 5–9 (median 7) | 52.5 | 0 (no chunking) |
| eight-puzzle V2 (expected-value, no RL) | 13/20 | 5–1767 (median 5) | 18 | 8 |
| eight-puzzle V1, fifteen-puzzle V1 | 0/20 | — | — | — (old selection library: state no-changes nest until the goal-depth limit halts Soar at decision 108) |
| fifteen-puzzle V2–V4 | 0/20 | — | — | 10 (hill-climbing loops; never solves within 3000) |
| **generated eight-puzzle** | **20/20** | **5–9 (median 7)** | **21.5** | **6** |
| **generated fifteen-puzzle** | **0/20** | — | — | 8 |

The generated eight puzzle reproduces the originals' behaviour (same range and median of moves); it learns 2.5 fewer chunks (no `^tile-cell`/`^blank-cell` bookkeeping to chunk over). The fifteen puzzle fails exactly as its originals do: one-step look-ahead with this evaluation is greedy and loops.

Soar 9.6.5 vs soar-lean: both MATCH (`leancmp/chunk.out`: eight-puzzle 23 decisions, 159 WMEs, 6 chunks; fifteen-puzzle 60 decisions, 233 WMEs, 8 chunks).

## Theorems

- `conventions` (both variants).
- `eight_shortest`: the eight-puzzle instance's shortest solution has 5 moves (the agents take 5–9).
- No constraint theorem: `constraintsHold` explores the whole reachable space (181,440 states), too large here.

## DSL features added for this family (general)

- Multi-valued static links (a cell's `neighbor`s); `Agent.linkOf` returns all targets.
- `Goal.each`: several desired objects, each matched by its key (every tile in its cell).
- `FailKind.off`: look-ahead without duplicate detection.
- `HVal.reject`: a preference rule can reject.
- `ScoreDelta`: look-ahead evaluation by the moved object (+1 / −1 / 0 against its desired value).
- Look-ahead copies only object types some operator changes (two-level); unchanged ones (cells) are shared one-level.
- Compiler fix: an equality between two values (`tile.cell = from.id`) now compiles to one shared variable (Soar allows one equality test per conjunctive test; the earlier form was silently weakened by Soar).

## Open assumptions (A1–A7, in EightPuzzle.lean)

- A1 representation: tiles (blank = tile 0) with a number and an integer cell (row×10+column); cells named c11… with an id and `neighbor` links. Originals: `^binding` objects pairing a cell and a tile, `^blank-cell` on the state.
- A2 operator move-tile(tile, blank, from, to); the originals name only the two cells.
- A3 goal: the originals' desired board, one desired object per tile (blank included); success halts.
- A4 reject the move that slides the last-moved tile straight back, via `^last-move` instead of `^tile-cell`.
- A5 evaluation by the moved tile (+1/−1/0); no duplicate detection (as the originals).
- A6 eight-puzzle V2's expected-value form (probabilistic choice, 13/20) is replaced by the numeric-value variant — keep an expected-value variant?
- A7 chunking on; fifteen-puzzle V3's singleton declarations dropped; the harness sets the seed after loading.

## Revision, 7 November 2026 (JL review)

### Bindings (A1)

The representation is back to the originals' bindings: one `^binding` per cell, pointing to its cell and to the tile in it. `move-tile` swaps the tile and the blank between two bindings whose cells are neighbours.

This applies JL's general rule: relations changed by operators are explicit on the state, pointing to their arguments, not numeric codes or static links. It is now convention STA-030 (Should), because learning generalizes better over pointers.

The look-ahead evaluation by moved tile now compares the bindings' tile links with the desired ones by name (`ScoreDelta.links`).

### Expected-value variant (A6, decided: keep)

`eight-puzzle-expected-value` replaces V2. It gives the evaluation as `^expected-value` (`Score.expected`), and Soar's choice is then probabilistic.

### Results (Soar 9.6.5, seeds 1–20, cap 3000 decisions)

| Agent | Solved | Moves | Median decisions | Median chunks |
|---|---|---|---|---|
| `eight-puzzle` (bindings) | 20/20 | 5–9, median 7 | 21.5 | 7 |
| `eight-puzzle`, previous tile-cell version | 20/20 | 5–9, median 7 | 21.5 | 6 |
| `eight-puzzle-expected-value` | 10/20 | 5–2207, median 5 | 2610 | 6 |
| eight-puzzle V2 (original) | 13/20 | 5–1767, median 5 | 768 | 8 |
| `fifteen-puzzle` | 0/20 | — | — | 8 |

The fifteen-puzzle originals also solve 0/20.

Soar vs soar-lean (`leancmp3/`), all MATCH:
- `eight-puzzle`: 23 decisions, to the goal.
- `eight-puzzle-expected-value`: 60 decisions.
- `fifteen-puzzle`: 60 decisions.

Theorems: `conventions` and `eight_shortest` (5 moves) hold for the binding representation.

The harness now reads the desired bindings by name. The earlier tile-cell results are kept in `results/gen-tilecell/`.
