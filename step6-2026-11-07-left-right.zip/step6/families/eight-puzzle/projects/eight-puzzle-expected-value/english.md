# eight-puzzle

## The task

The task state holds several values of `tile`, each a tile. The tiles and the blank (tile 0).
The task state holds several values of `cell`, each a cell. The cells of the board.
The task state holds several values of `binding`, each a binding. Which tile is in which cell: one per cell.

A tile has `name` (one of ), `number` (an integer).

A cell has `name` (one of ), `id` (an integer), `neighbor` (a cell).

A binding has `name` (one of ), `id` (an integer), `cell` (a cell), `tile` (a tile).

Initially the task state has:
- a `cell` named c11 with id 11; its `neighbor` is c21; its `neighbor` is c12
- a `cell` named c12 with id 12; its `neighbor` is c22; its `neighbor` is c11; its `neighbor` is c13
- a `cell` named c13 with id 13; its `neighbor` is c23; its `neighbor` is c12
- a `cell` named c21 with id 21; its `neighbor` is c11; its `neighbor` is c31; its `neighbor` is c22
- a `cell` named c22 with id 22; its `neighbor` is c12; its `neighbor` is c32; its `neighbor` is c21; its `neighbor` is c23
- a `cell` named c23 with id 23; its `neighbor` is c13; its `neighbor` is c33; its `neighbor` is c22
- a `cell` named c31 with id 31; its `neighbor` is c21; its `neighbor` is c32
- a `cell` named c32 with id 32; its `neighbor` is c22; its `neighbor` is c31; its `neighbor` is c33
- a `cell` named c33 with id 33; its `neighbor` is c23; its `neighbor` is c32
- a `tile` named t0 with number 0
- a `tile` named t1 with number 1
- a `tile` named t2 with number 2
- a `tile` named t3 with number 3
- a `tile` named t4 with number 4
- a `tile` named t5 with number 5
- a `tile` named t6 with number 6
- a `tile` named t7 with number 7
- a `tile` named t8 with number 8
- a `binding` named b11 with id 11; its `cell` is c11; its `tile` is t2
- a `binding` named b12 with id 12; its `cell` is c12; its `tile` is t1
- a `binding` named b13 with id 13; its `cell` is c13; its `tile` is t7
- a `binding` named b21 with id 21; its `cell` is c21; its `tile` is t8
- a `binding` named b22 with id 22; its `cell` is c22; its `tile` is t6
- a `binding` named b23 with id 23; its `cell` is c23; its `tile` is t0
- a `binding` named b31 with id 31; its `cell` is c31; its `tile` is t3
- a `binding` named b32 with id 32; its `cell` is c32; its `tile` is t4
- a `binding` named b33 with id 33; its `cell` is c33; its `tile` is t5
Links between objects never change.

**Goal.** Some binding has . When the goal holds in the task state, the agent reports success and halts.

## Operators

An operator's changes are made together: every value on the right is read before any change.

**move-tile(t: tile, k: tile, bt: binding, bb: binding, from: cell, to: cell).** Proposed when t.number ≠ 0 and k.number = 0 and bt.tile is t and bb.tile is k and bt.cell is from and bb.cell is to and from.neighbor is to. Slide a tile next to the blank into the blank's cell.
- Effect: bt.tile := k; bb.tile := t.

## Choosing among proposed operators

When several operators are proposed, the agent tries each one in an internal copy of the state (look-ahead search, Soar's default selection library) and prefers those that lead to the goal. Returning to an earlier state is not detected.
Each state tried is given the value 0 of the binding (with `self` that binding); higher is better.

The agent remembers the last task operator applied (its name and parameters). Search-control preferences:
- **reject-inverse**: a proposed move-tile whose t equals the last move-tile's t is rejected. Do not slide the tile just moved straight back.

## Learning

Chunking on (`chunk always`).

## Assumptions (added; not in the task description)

- **A1** [open] Representation as the originals (JL, 7 Nov 2026: relations that operators change are explicit on the state, pointing to their arguments — STA-030): one binding per cell (`^binding`) pointing to its cell and to the tile in it; cells are named objects with static `neighbor` links; tiles are named objects (t0 the blank) with their number. The originals also keep `^blank-cell` and name tiles by number.
- **A2** [open] One operator, move-tile(t, k, bt, bb, from, to): tile t (in binding bt, cell from) and the blank k (in bb, cell to, a neighbour of from) swap bindings. The originals' operator names only the two cells (`^tile-cell`, `^blank-cell`) and finds the bindings when applying it.
- **A3** [open] The goal is the originals' desired board (every binding holds its desired tile, the blank included), a `^desired` structure of bindings; success halts at the top state (the originals' top-goal*halt*success).
- **A4** [open] Search control: the move that slides the tile just moved straight back is rejected (the originals reject an operator whose tile-cell is the state's `^tile-cell`, the cell the last tile came from — the same move). This uses the last-move record (`^last-move`) instead of `^tile-cell`.
- **A5** [open] Look-ahead: one step, Soar's selection library; the tried state is evaluated by the moved tile: +1 if it is now in its desired cell, −1 if it was in its desired cell before the move, 0 otherwise (the originals' three evaluation rules; their 0 rule is stated more indirectly). No duplicate-state detection (the originals have none).
- **A6** [open] eight-puzzle V2 gives the evaluation as `^expected-value` (numeric-indifferent preferences, a probabilistic choice; what RL rules are later made from) instead of `^numeric-value` (compared values, binary preferences): variant eight-puzzle-expected-value (JL, 7 Nov 2026: keep it). V2's reward of 1 at the goal, with RL off, is left out.
- **A7** [open] Chunking on (`chunk always`); the fifteen-puzzle V3 singleton declarations (cell, tile, blank-cell, tile-cell, problem-space) are dropped (singletons are the default in 9.6.5); the harness sets the random seed after loading (several originals set srand 1).
