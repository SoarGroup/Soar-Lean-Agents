# Graph search — step 6

No replacement; the task only, in `agentgen/Agent/Families/GraphSearch.lean` (links as edge objects, the mission as leg objects). A faithful variant needs constructs that are not small: sub-operators with their own parameters; floats and the `compute-range` RHS function; an A*-style look-ahead through a modified selection library (70 of its 73 rules differ from the 9.6.5 library); semantic memory for the smem versions.

Behaviour in 9.6.5 (3000 decisions):
- graph-search V2 completes its mission (195 decisions).
- V3 does not finish its 23-leg tour.
- The chunking demo does not finish within 400 decisions.
- graph-search-smem V1/V2 never start: state no-changes nest until the goal-depth limit halts Soar at decision 107.

Missions: V2 visits W14, W16, W20; V3 and the demo have 23-leg tours that differ in two legs, and V3 has two extra links.

Theorems: `conventions`; shortest missions in moves: V2 9, V3 44, demo 50 (agree with an independent Python BFS).

Open assumptions: A1–A2 (see GraphSearch.lean).
