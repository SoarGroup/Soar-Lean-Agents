# Hello world — step 6

Lean: `agentgen/Agent/Families/HelloWorld.lean`. Variant `hello-world` replaces hello-world-operator V1/V2 and hello-world-rule V1/V2 (V1/V2 differ only in comments).

Comparison (20 seeds): all originals and the regenerated agent solve 20/20 and write "Hello World" once. Decisions: operator originals 1, rule originals 0 (the rule fires before the first decision), regenerated 2 (initialize, hello-world). Soar vs soar-lean: MATCH.

Theorems: `conventions`, `shortest` (1 operator), `constraints_hold` (the `written` flag stays 0/1).

Open assumptions:
- A1: goal is `written = 1` instead of halting in the apply rule.
- A2: the rule-only versions are replaced (keeping them as a teaching example would need the escape hatch).
- A3: a greeting object is needed, because goals are patterns over task objects.

Conventions used: messages; "output only from operators" (new, proposed L1).
