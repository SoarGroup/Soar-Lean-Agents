"""Task-level runs of Hello world agents in Soar 9.6.5 (soar_sml).

usage: harness.py DIR LOADFILE [--cap N] [--seeds a-b]
For each seed: source the agent, `srand SEED`, run decision by decision up to the cap (a run of
0 decisions is tried first, since a rule can write and halt before the first decision); record
whether "Hello World" was written, how often, whether the agent halted, and the decisions.
Prints one JSON object per run.
"""
import argparse, json, os, re
import soar_sml as sml

def run(d, load, cap, seed):
    k = sml.Kernel.CreateKernelInCurrentThread(True, 0)
    a = k.CreateAgent('h')
    out = []
    a.RegisterForPrintEvent(sml.smlEVENT_PRINT, lambda *x: out.append(x[-1]), None)
    a.ExecuteCommandLine('cd ' + d)
    src = a.ExecuteCommandLine('source ' + load)
    a.ExecuteCommandLine(f'srand {seed}')
    halted, text = False, ''
    for n in range(0, cap + 1):
        out.clear(); a.RunSelf(1) if n else a.ExecuteCommandLine('run 1 -p')
        txt = ''.join(out); text += txt
        if 'halted' in txt or 'This Agent halted' in txt:
            halted = True; break
    dec = int(re.search(r'(\d+) decisions', a.ExecuteCommandLine('stats')).group(1))
    k.Shutdown()
    c = text.count('Hello World')
    return dict(seed=seed, decisions=dec, halted=halted, hello=c, solved=halted and c == 1,
                source_errors='rror' in src)

if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('dir'); p.add_argument('load')
    p.add_argument('--cap', type=int, default=500)
    p.add_argument('--seeds', default='1-20')
    o = p.parse_args()
    lo, hi = map(int, o.seeds.split('-'))
    for s in range(lo, hi + 1):
        print(json.dumps(run(os.path.abspath(o.dir), o.load, o.cap, s)), flush=True)
