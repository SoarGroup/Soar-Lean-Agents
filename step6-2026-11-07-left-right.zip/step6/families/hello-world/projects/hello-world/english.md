# hello-world

## The task

The task state holds several values of `greeting`, each a greeting. The greeting to give.

A greeting has `written` (an integer).

Initially the task state has:
- a `greeting` with written 0

**Constraint (part of the task).** Every greeting always has self.written ≥ 0 and self.written ≤ 1 (with `self` the greeting); every operator must preserve this.

**Goal.** Some greeting has written 1. When the goal holds in the task state, the agent reports success and halts.

## Operators

An operator's changes are made together: every value on the right is read before any change.

**hello-world(greeting: greeting).** Proposed when greeting.written = 0. Write "Hello World".
- Effect: greeting.written := 1; writes "Hello World".

## Choosing among proposed operators

Any proposed operator may be chosen; the choice is random.

## Learning

None.

## Assumptions (added; not in the task description)

- **A1** [accepted] The task: write "Hello World" once and stop. The originals halt in the apply rule (operator versions) or in the rule itself; here the operator records that the greeting was written (`written` 0 → 1) and the goal (written = 1, a `^desired` structure) halts the agent at the top state, which also writes "The problem has been solved."
- **A2** [accepted] hello-world-rule V1/V2 (a rule that writes and halts, no operator) are replaced by the operator variant: same task, and an action from an elaboration rule is outside the conventions. If JL wants the rule-only version kept as a teaching example, it needs an escape hatch (`Agent.raw`).
- **A3** [accepted] Representation: a `greeting` object with a `written` flag, needed because a goal is a pattern over task objects. The originals' proposal tested only `^type state` (any state, so also substates); here it tests the task state's name (convention).
