# HRL navigation (taxi) — step 6

No replacement; a docstring-only `agentgen/Agent/Families/HrlNavigation.lean`.

- The taxi environment is not in the corpus. Without it the input link is empty and no move is proposed: the flat agents tie among pickup/putdown/fillup, the hierarchical ones have no proposal, and state no-changes nest.
- The DSL has no I/O construct.
- RL learning is turned on in none of the sources.

What would vary: the RL state abstraction (all features, phase, per-action features, regions) and the hierarchy (flat; get/put/refuel with a shared navigate; MAXQ).

No theorems or comparison.
