# KenKen — step 6

Lean: `agentgen/Agent/Families/KenKen.lean`.

Sixteen variants, `kenken-<size>-<number>`, one per board of kenken V1:
- seven 4 × 4 boards;
- five 5 × 5 boards;
- four 6 × 6 boards.

All 16 boards were extracted from V1's board-definitions-4/5/6 (`puzzles.json`), and each has a unique solution. Together the variants replace kenken V1. V2 is covered by A6.

## Structure

Each cell has one candidate object per number. Each cage has the tuples of numbers that satisfy it as objects; a tuple links to the candidates it uses.

Propagation operators (proposed indifferent):
- `assign`: decide a cell. Either it has one live candidate, or no other cell of its row (or column) can take the number.
- `cleanup`: drop a decided cell's other candidates.
- `eliminate`: drop a decided number from the cell's row and column.
- `drop-tuple`: drop a tuple that uses a dropped candidate.
- `prune`: drop a candidate that no live tuple uses.

Guessing, when propagation stops:
- `choose-cell` picks a cell with two live candidates; `choose-cell-3` picks one with three. Both are worst; two is better than three.
- `guess` then ties over the cell's numbers, and look-ahead decides, using Soar's selection library with chunking.

Failure states:
- an undecided cell with no live candidate;
- a decided cell whose number has been dropped.

New general features:
- `Guard.fewer`: fewer than k linked objects satisfy the conditions.
- `Operator.indifferent`: proposed `=` under a look-ahead method, so that only the guesses tie.
- `Agent.chunkLocalNegations := false`: V1's `chunk allow-local-negations off`.
- Failure guards now compile in full (`linked`/`noneSuch` were dropped before).

Every earlier family's output is unchanged.

## Results (Soar 9.6.5, seeds 1–5)

The generated agents solve all 16 boards on every seed, with every cell correct. Correctness was checked against each board's unique solution, using the top state's marks at the end of the run.

| Board | V1 decisions | Generated decisions | Guesses |
|---|---|---|---|
| 4-1 | 90–101 | 90–94 | 0 |
| 4-2 | 61–69 | 89–92 | 0 |
| 4-3 | 102–111 | 94–98 | 0 |
| 4-4 | 79–86 | 94–95 | 0 |
| 4-5 | 102–124 | 125–148 | 1 |
| 4-6 | 68–73 | 85–90 | 0 |
| 4-7 | 111–127 | 90–92 | 0 |
| 5-1 | 131–142 | 172–173 | 0 |
| 5-2 | 115–123 | 168–174 | 0 |
| 5-3 | 104–117 | 169–172 | 0 |
| 5-4 | 120–127 | 165–170 | 0 |
| 5-5 | 139–148 | 181–185 | 0 |
| 6-1 | 211–242 | 405–430 | 1 |
| 6-2 | 672–878 | 639–1067 | 3–5 |
| 6-3 | 733–1055 | 482–596 | 1 |
| 6-4 | 255–343 | 461–467 | 0 |

Totals over the 16 boards:

| | Decisions per seed | Chunks per seed | Boards solved |
|---|---|---|---|
| V1 | 3271–3557 | 83–93 | 16, except seed 4: board 6-3 not solved |
| Generated | 3645–4228 | 0 | 16 on every seed; every board printed and the agent halts |

V1 was run from its own project, so its `_firstload` settings (chunking) load. The flattened corpus copy drops them; without chunking V1 takes 23171 decisions. V1's decisions per board include its board setup and printing.

Board printing (JL N5, 7 Nov: keep it). The Soar default library halts when the top state has `^success`, which ended the run before `print-row` could fire. The compiler now handles `Goal.after` in three rules:
- When the goal holds at the top state, it sets `^goal-reached`.
- `print-row` (atGoal) is proposed only once `^goal-reached` is set.
- `^success` is set once every row has been printed (`printed` = n).
Look-ahead substates still get `^success` directly. The printing costs about 6 decisions per board (previous runs kept in `results/gen-prev/`). No other family's generated Soar changed.

Soar vs soar-lean (`leancmp2/`, after the change; `leancmp/` before):
- Board 4-1 (propagation only): MATCH (97 decisions: to the goal, the board printed, halt).
- Board 4-5 (with a guess and look-ahead): MATCH (45 decisions, 2,290 WMEs). The comparison over 200 decisions timed out in soar-lean.

Theorems:
- `conventions`.
- `propagation_solves`: the six 4 × 4 boards that propagation solves alone reach the goal with a valid grid, with ties broken by the first candidate. Valid means rows and columns are permutations and every cage holds.
  - It takes 3.5 minutes to build.
  - The 5 × 5 boards ran for over 20 minutes, because the semantics enumerates all parameter combinations, so they were left out.

## Chunking (JL, 7 Nov: option b, recast the negated tests as positive counts so chunks can form; to do)

The generated agents learn no chunks; V1 learns 83–93.
- With local negations allowed (Soar's default), building the first look-ahead chunk on 4-5 did not finish.
- With V1's setting, `chunk allow-local-negations off`, Soar learns no chunks for these results, because they depend on negated tests.

These negated tests are the generalised propagation ("no live tuple uses it", "no other cell can take it"). Options:
- (a) accept no learning;
- (b) recast the negated tests as positive counts;
- (c) put chunk conditions over the tuples in a form that can be learned.

## Assumptions (open, for JL)

- **A1. One variant per board.** Each variant solves one puzzle, instead of V1's one agent that works through the boards in turn. The harness runs them in V1's order.
- **A2. Candidates and propagation.**
  - Cells have candidate objects (alive or dropped) instead of a set of legal values, and a decided cell has a mark.
  - The propagation rules are V1's: mark-single-value, notice-single-column-row-value and remove-column-row-values.
- **A3. Cage arithmetic.**
  - Each cage's satisfying tuples are computed and made objects, as V1's number tables are written out.
  - This replaces V1's check-group substate, its subgroups and its linear-sum groups.
  - It is complete for each cage on its own, so it can narrow more than V1. That is why no 5 × 5 board needs a guess.
- **A4. Guessing.**
  - As in V1: a cell with two (else three) candidates, then look-ahead over its numbers.
  - Two failure states are needed. The second (a decided cell whose number has been dropped) caught a wrong guess that otherwise reached the goal with 12 wrong cells.
  - No duplicate-state check: propagation never repeats a state.
- **A5. Output.** Decided cells are written; board printing is left out.
- **A6. V2.** V2 (one 4 × 4 board, no guessing; it loops after solving) is covered by `kenken-4-3`.
