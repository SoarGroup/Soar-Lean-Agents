"""KenKen harness. Generated agents: one project per board; run to a cap, check every decided cell
(Set cell / Guess lines) against the board's unique solution. The original V1: one run through
its sixteen boards; decisions per board from the trace (watch 1), boards solved from its output."""
import soar_sml as sml, sys, os, re, json, time, itertools, math
P = json.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'puzzles.json')))
def ok(op, v, vals):
    return {'add': lambda: sum(vals) == v, 'multiply': lambda: math.prod(vals) == v, 'equal': lambda: vals[0] == v,
            'subtract': lambda: abs(vals[0]-vals[1]) == v, 'divide': lambda: max(vals) == v*min(vals)}[op]()
def solve(p):
    n = p['size']; G = [(op, v, [(int(c[1]), int(c[2])) for c in cs]) for op, v, cs in p['groups']]
    T = [[t for t in itertools.product(range(1, n+1), repeat=len(pos)) if ok(op, v, t)] for op, v, pos in G]
    sol = {}
    def bt(i, a):
        if i == len(G): sol.update(a); return True
        for t in T[i]:
            if all(not any((q[0] == x[0] or q[1] == x[1]) and a[q] == val for q in a) for x, val in zip(G[i][2], t)) and \
               all(not ((x[0] == y[0] or x[1] == y[1]) and t[j] == t[k]) for j, x in enumerate(G[i][2]) for k, y in enumerate(G[i][2]) if j < k):
                b = dict(a); b.update(zip(G[i][2], t))
                if bt(i+1, b): return True
        return False
    bt(0, {}); return sol
def kernel():
    k = sml.Kernel.CreateKernelInCurrentThread(True, 0); a = k.CreateAgent('h'); out = []
    a.RegisterForPrintEvent(sml.smlEVENT_PRINT, lambda *x: out.append(x[-1]), None); return k, a, out
def gen(proj, cap, seed, only=None):
    res = []
    for p in P:
        if only and f"kenken-{p['size']}-{p['num']}" != only: continue
        name = f"kenken-{p['size']}-{p['num']}"; f = os.path.join(proj, name, name + '.soar')
        k, a, out = kernel()
        r = a.ExecuteCommandLine('source ' + os.path.abspath(f))
        a.ExecuteCommandLine(f'srand {seed}'); a.ExecuteCommandLine('watch 0'); t = time.time()
        a.ExecuteCommandLine(f'run {cap}')
        st = a.ExecuteCommandLine('stats'); txt = ''.join(out)
        dec = int(re.search(r'(\d+) decisions', st).group(1))
        cm = re.search(r'(\d+) chunks', st); chunks = int(cm.group(1)) if cm else 0
        sol = solve(p)
        # the top state's cells, as they are at the end
        marks = []
        for cid in re.findall(r'\^cell (\w+)', a.ExecuteCommandLine('print s1')):
            x = a.ExecuteCommandLine('print ' + cid)
            c = int(re.search(r'\^coord (\d+)', x).group(1)); v = int(re.search(r'\^mark (\d+)', x).group(1))
            if v: marks.append((c, v))
        wrong = sum(1 for c, v in marks if sol[(c // 10, c % 10)] != v)
        res.append(dict(board=name, decisions=dec, solved='has been solved' in txt, failed='has failed' in txt,
                        marks=len(marks), wrong=wrong, guesses=txt.count('Guess cell'), printed=len(re.findall(r'(?:\| \d+ )+\|', txt)), chunks=chunks, secs=round(time.time()-t, 1)))
        k.Shutdown()
    return res
def orig(path, cap, seed):
    k, a, out = kernel()
    a.ExecuteCommandLine('source ' + os.path.abspath(path))
    a.ExecuteCommandLine(f'srand {seed}'); a.ExecuteCommandLine('watch 1'); t = time.time()
    a.ExecuteCommandLine(f'run {cap}'); txt = ''.join(out)
    starts = []; last = 0
    for m in re.finditer(r'(?m)^\s*(\d+):|--- Board (\d)-(\d+)', txt):
        if m.group(1): last = int(m.group(1))
        else: starts.append((f"kenken-{m.group(2)}-{m.group(3)}", last))
    st = a.ExecuteCommandLine('stats'); dec = int(re.search(r'(\d+) decisions', st).group(1))
    succ = re.findall(r'Succeeded: Size: (\d), Number: (\d+)', txt)
    res = []
    for i, (b, d0) in enumerate(starts):
        d1 = starts[i+1][1] if i + 1 < len(starts) else dec
        res.append(dict(board=b, decisions=d1 - d0, solved=(b.split('-')[1], b.split('-')[2]) in succ))
    cm = re.search(r'(\d+) chunks', st); chunks = int(cm.group(1)) if cm else 0
    k.Shutdown()
    return dict(total=dec, chunks=chunks, secs=round(time.time()-t, 1), boards=res)
if __name__ == '__main__':
    mode, path, cap, seed = sys.argv[1], sys.argv[2], int(sys.argv[3]), int(sys.argv[4])
    only = sys.argv[5] if len(sys.argv) > 5 else None
    print(json.dumps(gen(path, cap, seed, only) if mode == 'gen' else orig(path, cap, seed)))
