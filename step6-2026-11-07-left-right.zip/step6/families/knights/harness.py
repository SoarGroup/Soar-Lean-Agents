"""Knight's tour harness: run an agent for a decision cap with a seed; count the closed tours it
reports ("Success!" lines), whether it halted, and the time."""
import soar_sml as sml, sys, os, re, json, time
def run(path, cap, seed):
    k = sml.Kernel.CreateKernelInCurrentThread(True, 0); a = k.CreateAgent('h'); out = []
    a.RegisterForPrintEvent(sml.smlEVENT_PRINT, lambda *x: out.append(x[-1]), None)
    a.ExecuteCommandLine('cd ' + os.path.dirname(os.path.abspath(path)))
    a.ExecuteCommandLine('source ' + os.path.basename(path))
    a.ExecuteCommandLine('srand %d' % seed); a.ExecuteCommandLine('watch 0')
    t = time.time(); a.ExecuteCommandLine('run %d' % cap)
    st = a.ExecuteCommandLine('stats'); txt = ''.join(out)
    dec = int(re.search(r'(\d+) decisions', st).group(1)) if re.search(r'(\d+) decisions', st) else cap
    r = dict(agent=os.path.basename(path), seed=seed, decisions=dec, tours=txt.count('Success!'),
             halted='halted' in txt.lower() or 'System halted' in txt, secs=round(time.time() - t, 1),
             tail=txt[-200:])
    k.Shutdown(); return r
if __name__ == '__main__':
    path, cap, seeds = sys.argv[1], int(sys.argv[2]), sys.argv[3]
    lo, hi = map(int, seeds.split('-'))
    for s in range(lo, hi + 1): print(json.dumps(run(path, cap, s)), flush=True)
