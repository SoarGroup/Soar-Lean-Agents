# knights

## The task

The task state holds several values of `square`, each a square. The squares of the board.
The task state holds several values of `tour`, each a tour. The tour being built.

A square has `name` (one of ), `coord` (an integer), `used` (an integer), `degree` (an integer), `odeg` (an integer), `visit` (an integer), `tried` (an integer), `move` (a square), `prev` (a square).

A tour has `name` (one of ), `depth` (an integer), `moves` (an integer), `frame` (an integer), `solutions` (an integer), `goal` (an integer), `done` (an integer), `at` (a square), `first` (a square).

Initially the task state has:
- a `square` named b11 with coord 11 and used 0 and degree 2 and odeg 2 and visit 0; its `move` is b23; its `move` is b32; its `prev` is b11
- a `square` named b12 with coord 12 and used 0 and degree 3 and odeg 3 and visit 0; its `move` is b24; its `move` is b31; its `move` is b33; its `prev` is b12
- a `square` named b13 with coord 13 and used 0 and degree 4 and odeg 4 and visit 0; its `move` is b21; its `move` is b25; its `move` is b32; its `move` is b34; its `prev` is b13
- a `square` named b14 with coord 14 and used 0 and degree 4 and odeg 4 and visit 0; its `move` is b22; its `move` is b26; its `move` is b33; its `move` is b35; its `prev` is b14
- a `square` named b15 with coord 15 and used 0 and degree 4 and odeg 4 and visit 0; its `move` is b23; its `move` is b27; its `move` is b34; its `move` is b36; its `prev` is b15
- a `square` named b16 with coord 16 and used 0 and degree 4 and odeg 4 and visit 0; its `move` is b24; its `move` is b28; its `move` is b35; its `move` is b37; its `prev` is b16
- a `square` named b17 with coord 17 and used 0 and degree 3 and odeg 3 and visit 0; its `move` is b25; its `move` is b36; its `move` is b38; its `prev` is b17
- a `square` named b18 with coord 18 and used 0 and degree 2 and odeg 2 and visit 0; its `move` is b26; its `move` is b37; its `prev` is b18
- a `square` named b21 with coord 21 and used 0 and degree 3 and odeg 3 and visit 0; its `move` is b13; its `move` is b33; its `move` is b42; its `prev` is b21
- a `square` named b22 with coord 22 and used 0 and degree 4 and odeg 4 and visit 0; its `move` is b14; its `move` is b34; its `move` is b41; its `move` is b43; its `prev` is b22
- a `square` named b23 with coord 23 and used 1 and degree 6 and odeg 6 and visit 1; its `move` is b11; its `move` is b15; its `move` is b31; its `move` is b35; its `move` is b42; its `move` is b44; its `prev` is b23
- a `square` named b24 with coord 24 and used 0 and degree 6 and odeg 6 and visit 0; its `move` is b12; its `move` is b16; its `move` is b32; its `move` is b36; its `move` is b43; its `move` is b45; its `prev` is b24
- a `square` named b25 with coord 25 and used 0 and degree 6 and odeg 6 and visit 0; its `move` is b13; its `move` is b17; its `move` is b33; its `move` is b37; its `move` is b44; its `move` is b46; its `prev` is b25
- a `square` named b26 with coord 26 and used 0 and degree 6 and odeg 6 and visit 0; its `move` is b14; its `move` is b18; its `move` is b34; its `move` is b38; its `move` is b45; its `move` is b47; its `prev` is b26
- a `square` named b27 with coord 27 and used 0 and degree 4 and odeg 4 and visit 0; its `move` is b15; its `move` is b35; its `move` is b46; its `move` is b48; its `prev` is b27
- a `square` named b28 with coord 28 and used 0 and degree 3 and odeg 3 and visit 0; its `move` is b16; its `move` is b36; its `move` is b47; its `prev` is b28
- a `square` named b31 with coord 31 and used 0 and degree 4 and odeg 4 and visit 0; its `move` is b12; its `move` is b23; its `move` is b43; its `move` is b52; its `prev` is b31
- a `square` named b32 with coord 32 and used 0 and degree 6 and odeg 6 and visit 0; its `move` is b11; its `move` is b13; its `move` is b24; its `move` is b44; its `move` is b51; its `move` is b53; its `prev` is b32
- a `square` named b33 with coord 33 and used 0 and degree 8 and odeg 8 and visit 0; its `move` is b12; its `move` is b14; its `move` is b21; its `move` is b25; its `move` is b41; its `move` is b45; its `move` is b52; its `move` is b54; its `prev` is b33
- a `square` named b34 with coord 34 and used 0 and degree 8 and odeg 8 and visit 0; its `move` is b13; its `move` is b15; its `move` is b22; its `move` is b26; its `move` is b42; its `move` is b46; its `move` is b53; its `move` is b55; its `prev` is b34
- a `square` named b35 with coord 35 and used 0 and degree 8 and odeg 8 and visit 0; its `move` is b14; its `move` is b16; its `move` is b23; its `move` is b27; its `move` is b43; its `move` is b47; its `move` is b54; its `move` is b56; its `prev` is b35
- a `square` named b36 with coord 36 and used 0 and degree 8 and odeg 8 and visit 0; its `move` is b15; its `move` is b17; its `move` is b24; its `move` is b28; its `move` is b44; its `move` is b48; its `move` is b55; its `move` is b57; its `prev` is b36
- a `square` named b37 with coord 37 and used 0 and degree 6 and odeg 6 and visit 0; its `move` is b16; its `move` is b18; its `move` is b25; its `move` is b45; its `move` is b56; its `move` is b58; its `prev` is b37
- a `square` named b38 with coord 38 and used 0 and degree 4 and odeg 4 and visit 0; its `move` is b17; its `move` is b26; its `move` is b46; its `move` is b57; its `prev` is b38
- a `square` named b41 with coord 41 and used 0 and degree 4 and odeg 4 and visit 0; its `move` is b22; its `move` is b33; its `move` is b53; its `move` is b62; its `prev` is b41
- a `square` named b42 with coord 42 and used 0 and degree 6 and odeg 6 and visit 0; its `move` is b21; its `move` is b23; its `move` is b34; its `move` is b54; its `move` is b61; its `move` is b63; its `prev` is b42
- a `square` named b43 with coord 43 and used 0 and degree 8 and odeg 8 and visit 0; its `move` is b22; its `move` is b24; its `move` is b31; its `move` is b35; its `move` is b51; its `move` is b55; its `move` is b62; its `move` is b64; its `prev` is b43
- a `square` named b44 with coord 44 and used 0 and degree 8 and odeg 8 and visit 0; its `move` is b23; its `move` is b25; its `move` is b32; its `move` is b36; its `move` is b52; its `move` is b56; its `move` is b63; its `move` is b65; its `prev` is b44
- a `square` named b45 with coord 45 and used 0 and degree 8 and odeg 8 and visit 0; its `move` is b24; its `move` is b26; its `move` is b33; its `move` is b37; its `move` is b53; its `move` is b57; its `move` is b64; its `move` is b66; its `prev` is b45
- a `square` named b46 with coord 46 and used 0 and degree 8 and odeg 8 and visit 0; its `move` is b25; its `move` is b27; its `move` is b34; its `move` is b38; its `move` is b54; its `move` is b58; its `move` is b65; its `move` is b67; its `prev` is b46
- a `square` named b47 with coord 47 and used 0 and degree 6 and odeg 6 and visit 0; its `move` is b26; its `move` is b28; its `move` is b35; its `move` is b55; its `move` is b66; its `move` is b68; its `prev` is b47
- a `square` named b48 with coord 48 and used 0 and degree 4 and odeg 4 and visit 0; its `move` is b27; its `move` is b36; its `move` is b56; its `move` is b67; its `prev` is b48
- a `square` named b51 with coord 51 and used 0 and degree 4 and odeg 4 and visit 0; its `move` is b32; its `move` is b43; its `move` is b63; its `move` is b72; its `prev` is b51
- a `square` named b52 with coord 52 and used 0 and degree 6 and odeg 6 and visit 0; its `move` is b31; its `move` is b33; its `move` is b44; its `move` is b64; its `move` is b71; its `move` is b73; its `prev` is b52
- a `square` named b53 with coord 53 and used 0 and degree 8 and odeg 8 and visit 0; its `move` is b32; its `move` is b34; its `move` is b41; its `move` is b45; its `move` is b61; its `move` is b65; its `move` is b72; its `move` is b74; its `prev` is b53
- a `square` named b54 with coord 54 and used 0 and degree 8 and odeg 8 and visit 0; its `move` is b33; its `move` is b35; its `move` is b42; its `move` is b46; its `move` is b62; its `move` is b66; its `move` is b73; its `move` is b75; its `prev` is b54
- a `square` named b55 with coord 55 and used 0 and degree 8 and odeg 8 and visit 0; its `move` is b34; its `move` is b36; its `move` is b43; its `move` is b47; its `move` is b63; its `move` is b67; its `move` is b74; its `move` is b76; its `prev` is b55
- a `square` named b56 with coord 56 and used 0 and degree 8 and odeg 8 and visit 0; its `move` is b35; its `move` is b37; its `move` is b44; its `move` is b48; its `move` is b64; its `move` is b68; its `move` is b75; its `move` is b77; its `prev` is b56
- a `square` named b57 with coord 57 and used 0 and degree 6 and odeg 6 and visit 0; its `move` is b36; its `move` is b38; its `move` is b45; its `move` is b65; its `move` is b76; its `move` is b78; its `prev` is b57
- a `square` named b58 with coord 58 and used 0 and degree 4 and odeg 4 and visit 0; its `move` is b37; its `move` is b46; its `move` is b66; its `move` is b77; its `prev` is b58
- a `square` named b61 with coord 61 and used 0 and degree 4 and odeg 4 and visit 0; its `move` is b42; its `move` is b53; its `move` is b73; its `move` is b82; its `prev` is b61
- a `square` named b62 with coord 62 and used 0 and degree 6 and odeg 6 and visit 0; its `move` is b41; its `move` is b43; its `move` is b54; its `move` is b74; its `move` is b81; its `move` is b83; its `prev` is b62
- a `square` named b63 with coord 63 and used 0 and degree 8 and odeg 8 and visit 0; its `move` is b42; its `move` is b44; its `move` is b51; its `move` is b55; its `move` is b71; its `move` is b75; its `move` is b82; its `move` is b84; its `prev` is b63
- a `square` named b64 with coord 64 and used 0 and degree 8 and odeg 8 and visit 0; its `move` is b43; its `move` is b45; its `move` is b52; its `move` is b56; its `move` is b72; its `move` is b76; its `move` is b83; its `move` is b85; its `prev` is b64
- a `square` named b65 with coord 65 and used 0 and degree 8 and odeg 8 and visit 0; its `move` is b44; its `move` is b46; its `move` is b53; its `move` is b57; its `move` is b73; its `move` is b77; its `move` is b84; its `move` is b86; its `prev` is b65
- a `square` named b66 with coord 66 and used 0 and degree 8 and odeg 8 and visit 0; its `move` is b45; its `move` is b47; its `move` is b54; its `move` is b58; its `move` is b74; its `move` is b78; its `move` is b85; its `move` is b87; its `prev` is b66
- a `square` named b67 with coord 67 and used 0 and degree 6 and odeg 6 and visit 0; its `move` is b46; its `move` is b48; its `move` is b55; its `move` is b75; its `move` is b86; its `move` is b88; its `prev` is b67
- a `square` named b68 with coord 68 and used 0 and degree 4 and odeg 4 and visit 0; its `move` is b47; its `move` is b56; its `move` is b76; its `move` is b87; its `prev` is b68
- a `square` named b71 with coord 71 and used 0 and degree 3 and odeg 3 and visit 0; its `move` is b52; its `move` is b63; its `move` is b83; its `prev` is b71
- a `square` named b72 with coord 72 and used 0 and degree 4 and odeg 4 and visit 0; its `move` is b51; its `move` is b53; its `move` is b64; its `move` is b84; its `prev` is b72
- a `square` named b73 with coord 73 and used 0 and degree 6 and odeg 6 and visit 0; its `move` is b52; its `move` is b54; its `move` is b61; its `move` is b65; its `move` is b81; its `move` is b85; its `prev` is b73
- a `square` named b74 with coord 74 and used 0 and degree 6 and odeg 6 and visit 0; its `move` is b53; its `move` is b55; its `move` is b62; its `move` is b66; its `move` is b82; its `move` is b86; its `prev` is b74
- a `square` named b75 with coord 75 and used 0 and degree 6 and odeg 6 and visit 0; its `move` is b54; its `move` is b56; its `move` is b63; its `move` is b67; its `move` is b83; its `move` is b87; its `prev` is b75
- a `square` named b76 with coord 76 and used 0 and degree 6 and odeg 6 and visit 0; its `move` is b55; its `move` is b57; its `move` is b64; its `move` is b68; its `move` is b84; its `move` is b88; its `prev` is b76
- a `square` named b77 with coord 77 and used 0 and degree 4 and odeg 4 and visit 0; its `move` is b56; its `move` is b58; its `move` is b65; its `move` is b85; its `prev` is b77
- a `square` named b78 with coord 78 and used 0 and degree 3 and odeg 3 and visit 0; its `move` is b57; its `move` is b66; its `move` is b86; its `prev` is b78
- a `square` named b81 with coord 81 and used 0 and degree 2 and odeg 2 and visit 0; its `move` is b62; its `move` is b73; its `prev` is b81
- a `square` named b82 with coord 82 and used 0 and degree 3 and odeg 3 and visit 0; its `move` is b61; its `move` is b63; its `move` is b74; its `prev` is b82
- a `square` named b83 with coord 83 and used 0 and degree 4 and odeg 4 and visit 0; its `move` is b62; its `move` is b64; its `move` is b71; its `move` is b75; its `prev` is b83
- a `square` named b84 with coord 84 and used 0 and degree 4 and odeg 4 and visit 0; its `move` is b63; its `move` is b65; its `move` is b72; its `move` is b76; its `prev` is b84
- a `square` named b85 with coord 85 and used 0 and degree 4 and odeg 4 and visit 0; its `move` is b64; its `move` is b66; its `move` is b73; its `move` is b77; its `prev` is b85
- a `square` named b86 with coord 86 and used 0 and degree 4 and odeg 4 and visit 0; its `move` is b65; its `move` is b67; its `move` is b74; its `move` is b78; its `prev` is b86
- a `square` named b87 with coord 87 and used 0 and degree 3 and odeg 3 and visit 0; its `move` is b66; its `move` is b68; its `move` is b75; its `prev` is b87
- a `square` named b88 with coord 88 and used 0 and degree 2 and odeg 2 and visit 0; its `move` is b67; its `move` is b76; its `prev` is b88
- a `tour` named tour with depth 1 and moves 0 and frame 1 and solutions 0 and goal 0 and done 0; its `at` is b23; its `first` is b23
Links between objects never change.

**Goal.** Some tour has done 1. When the goal holds in the task state, the agent reports success and halts.

## Operators

An operator's changes are made together: every value on the right is read before any change.

**knight-move(t: tour, c: square, y: square).** Proposed when t.done = 0 and t.at is c and c.move is y and y.used = 0 and y.tried does not contain c.visit. Move the knight to an unused square a knight's move away, not yet tried from here.
- Effect: t.at := y; y.used := 1; y.prev := c; y.visit := t.frame + 1; t.frame := t.frame + 1; t.depth := t.depth + 1; t.moves := t.moves + 1; for every z that y.move points to: z.degree := z.degree + -1.

**backup(t: tour, c: square, p: square).** Proposed when t.done = 0 and t.at is c and c.prev is p and c and p are different objects. Back up one move: free the knight's square and mark it tried from the square below.
- and when one of these holds: no square that c.move points to have used = 0 and tried does not contain c.visit; or t.goal = 1; or t.depth < 64 and at least 2 squares that c.move points to have used = 0 and degree = 1.
- Effect: t.at := p; c.used := 0; c.tried := p.visit; t.depth := t.depth − 1; t.moves := t.moves + 1; t.goal := 0; for every z that c.move points to: z.degree := z.degree + 1; z.tried := c.visit.

**detect-goal(t: tour, c: square, f: square).** Proposed when t.done = 0 and t.goal = 0 and t.depth = 64 and t.at is c and t.first is f and c.move is f. Every square is used and the first is a knight's move away: a closed tour; count it.
- Effect: t.solutions := t.solutions + 1; t.goal := 1; writes "Success! ⟨t.solutions + 1⟩ ⟨c.coord⟩".

**exhausted(t: tour, c: square).** Proposed when t.done = 0 and t.at is c and t.first is c and no square that c.move points to have used = 0 and tried does not contain c.visit. Back at the first square with nothing left to try: every tour has been found.
- Effect: t.done := 1; writes "Search complete: ⟨t.solutions⟩ solutions".

**finish-run(t: tour).** Proposed when t.done = 0 and t.moves ≥ 1000000. The move budget is spent: end the run.
- Effect: t.done := 1; writes "Run over: ⟨t.solutions⟩ solutions".

## Choosing among proposed operators

Any proposed operator may be chosen; the choice is random.

The agent remembers the last task operator applied (its name and parameters). Search-control preferences:
- **finish-first**: a proposed finish-run whose  is better than a proposed knight-move or backup or detect-goal. The run ends as soon as the budget is spent.
- **goal-before-backup**: a proposed detect-goal whose  is better than a proposed knight-move or backup.
- **backup-before-move**: a proposed backup whose  is better than a proposed knight-move.
- **lower-original-degree**: a proposed knight-move whose  is better than a proposed knight-move when y.odeg < other-y.odeg.

## Learning

None.

## Assumptions (added; not in the task description)

- **A1** [open] The task: count closed knight's tours from square 23 of an n × n board by depth-first search with backtracking, within a budget of moves (knight moves and backups; V1/V2 move-count-max 1000000). Backtracking is the task's method, as the originals' backup operator; it is not the recovery from a failure state that ELB-014 rules out.
- **A2** [open] One run with one strategy per agent (a variant), instead of the originals' runs-per-level and chain of strategies (level-0 … level-6) in one agent. Repeated runs are the harness's seeds.
- **A3** [open] Every square's `prev` starts at itself (a link is replaced, never added), so backup needs prev ≠ the square. A move tried from a square and backed out of is remembered on the square tried, in its set `tried` of the visit numbers of the squares it was tried from (each move gets a new number), instead of the originals' `^moved` set of squares on the square tried from; the marks from a square are removed when the search backs up from it, as the originals do. The path is the squares' `prev` links instead of a `^move-sequence` stack. (A single `blocked` value instead of the set lost the mark of an earlier square on the path and found the same two tours over and over.)
- **A4** [open] A square's degree counts the unused squares a move away and the first square, as in the originals (degrees start at the number of moves although the first square is used): for a closed tour the first square is the last move's exit, so its neighbours keep it as an exit. (Counting only unused squares, tried first, found no tours in 20000 decisions.) The originals' 6 × 6 board lists b52 twice for b44 (b56 missing) and their 8 × 8 board maps ^82 to b62; the board is computed here, correctly.
- **A5** [open] Pruning and search control are the originals' flags: V2's level-5 (degree update, lower degree first, a one-exit square best and back up once it has been tried, two one-exit squares next to the knight back up); V1's level-3 (degree update, lower original degree first, two one-exit squares back up). Rules for flags neither variant uses (multiple-moves-degree-1 over the board, distance-2, final-move-degree-0, degree-negative) are left out.
- **A6** [open] The search ends when the budget is spent (finish-run) or the first square has nothing left to try (exhausted); both write the count and halt. The originals print a summary per run and halt after the last strategy.
