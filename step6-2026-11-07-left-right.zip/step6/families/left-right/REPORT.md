# Left-right — step 6

Lean: `agentgen/Agent/Families/LeftRight.lean`.

Variant: `left-right` replaces left-right V1.

The task: from the start the agent moves left or right once and halts. Moving left gives reward −1; moving right gives +1. Over repeated runs, with `init-soar` between them keeping the RL values, the agent learns to prefer right.

## Structure

- One agent object: location (0 start, −1 left, 1 right) and moved.
- One operator, `move`, with value parameter `direction` ∈ {−1, 1}. It is proposed at the start.
- Rewards are rules on the location: −1 at −1, +1 at 1.
- Goal: moved = 1, which halts the agent.
- RL: Soar's defaults, as in V1. Learning on, learning rate 0.3, discount 0.9, epsilon-greedy with epsilon 0.1. One RL template over the move.

No new DSL features.

## Assumptions

- A1: the task as above, with learning over repeated runs (V1's readme shows 12).
- A2: directions are the values −1 and 1 of a value parameter. V1 has direction objects with a name and a reward, and location symbols.
- A3: the rewards are the variant's, by rules on the location. V1 reads them from the direction objects; the values are the same.
- A4: the goal is moved = 1. V1 halts once the location is not start. A goal is a set of values, so it cannot test that a value differs.
- A5: RL is Soar's defaults. A template makes one rule per direction, where V1 has two hand-written RL rules.

## Results (Soar 9.6.5, seeds 1–100, 12 runs each, init-soar between runs)

| Agent | Right chosen | Choice sequences equal to V1's | Final RL values equal to V1's |
|---|---|---|---|
| left-right V1 | 91.1% | | |
| `left-right` | 91.1% | 100 of 100 | 100 of 100 |

- On seed 1 both agents choose L R R L R R R R L R R R. This is the sequence in V1's readme.
- Both end with right 0.959646 (9 updates) and left −0.657 (3 updates), as the readme lists.

The template instantiates 4 to 6 extra RL rules that are never used and stay at 0. The template tests the agent's location and moved. It fires again while the move's apply changes them, before the proposal retracts, so it makes rules for locations −1 and 1, where no move is ever proposed. They do not affect selection or learning. This is not Soar defect 28: the rules that are used survive `init-soar` and go on learning.

Soar vs soar-lean (`leancmp/`, with RL and exploration): MATCH. 2 decisions, 23 WMEs; RL rule counts and values equal.

Theorems:
- `conventions`.
- `one_move`: one move reaches the goal.
