"""left-right harness: R runs per seed in one Soar agent with init-soar between them (as V1's readme),
or, with 'fresh', each run in a new agent that sources the RL rules (with their values) printed at
the end of the previous run (Soar defect 28: after init-soar, RL templates instantiate malformed rules).
Per seed: the directions chosen, and the final RL values."""
import soar_sml as sml, sys, os, re, json
def rl_values(a):
    t = a.ExecuteCommandLine('print --rl')
    return {m.group(1): (float(m.group(2)), float(m.group(3))) for m in re.finditer(r'^(\S+)\s+([\d.]+)\s+(-?[\d.]+)', t, re.M)}
def rl_text(a):
    names = re.findall(r'^(\S+)\s+[\d.]+\s+-?[\d.]+', a.ExecuteCommandLine('print --rl'), re.M)
    return '\n'.join(a.ExecuteCommandLine('print ' + n) for n in names if not n.endswith('*move'))
def one(a, out):
    n0 = len(out); a.ExecuteCommandLine('run 10'); txt = ''.join(out[n0:])
    m = re.search(r'Moved: (\S+)', txt); return {'left': 'L', 'right': 'R', '-1': 'L', '1': 'R'}.get(m.group(1) if m else '', '?')
def run(path, seed, runs, fresh):
    k = sml.Kernel.CreateKernelInCurrentThread(True, 0); ch = []; saved = ''
    if not fresh:
        a = k.CreateAgent('t'); out = []; a.RegisterForPrintEvent(sml.smlEVENT_PRINT, lambda *x: out.append(x[-1]), None)
        a.ExecuteCommandLine('source ' + os.path.abspath(path)); a.ExecuteCommandLine(f'srand {seed}')
        for r in range(runs):
            if r: a.ExecuteCommandLine('init-soar')
            ch.append(one(a, out))
        vals = rl_values(a)
    else:
        for r in range(runs):
            a = k.CreateAgent(f't{r}'); out = []; a.RegisterForPrintEvent(sml.smlEVENT_PRINT, lambda *x: out.append(x[-1]), None)
            a.ExecuteCommandLine('source ' + os.path.abspath(path))
            if saved:
                f = f'/tmp/_lr_{os.getpid()}.soar'; open(f, 'w').write(saved); a.ExecuteCommandLine('source ' + f)
            a.ExecuteCommandLine(f'srand {seed * 1009 + r}'); ch.append(one(a, out))
            vals = rl_values(a); saved = rl_text(a); k.DestroyAgent(a)
    k.Shutdown()
    return dict(seed=seed, choices=''.join(ch), values={n: v for n, v in vals.items() if not n.endswith('*move')})
if __name__ == '__main__':
    path, seeds, runs, fresh = sys.argv[1], int(sys.argv[2]), int(sys.argv[3]), len(sys.argv) > 4
    for s in range(1, seeds + 1): print(json.dumps(run(path, s, runs, fresh)), flush=True)
