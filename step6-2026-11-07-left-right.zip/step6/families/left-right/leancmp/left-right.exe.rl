rl*left-right*rl*move*1 1 0.300000
rl*left-right*rl*move*2 0 0.000000
rl*left-right*rl*move*3 0 0.000000
rl*left-right*rl*move*4 0 0.000000