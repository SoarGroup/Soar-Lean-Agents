# left-right

## The task

The task state holds several values of `agent`, each a agent. The agent's position.

A agent has `location` (an integer), `moved` (an integer).

Initially the task state has:
- a `agent` with location 0 and moved 0

**Constraint (part of the task).** Every agent always has self.location ≥ -1 and self.location ≤ 1 (with `self` the agent); every operator must preserve this.

**Goal.** Some agent has moved 1. When the goal holds in the task state, the agent reports success and halts.

## Operators

An operator's changes are made together: every value on the right is read before any change.

**move(agent: agent, direction ∈ {-1, 1}).** Proposed when agent.location = 0. Move from the start in a direction: −1 left, 1 right.
- Effect: agent.location := direction; agent.moved := 1; writes "Moved: ⟨direction⟩".

## Choosing among proposed operators

The agent learns by reinforcement which operator to choose, from the operator and the attribute values of its parameter objects. Rewards:
- -1 for a state with a agent with location -1
- 1 for a state with a agent with location 1

## Learning

Reinforcement learning on: learning rate 0.300000, discount 0.900000, epsilon-greedy exploration.

## Assumptions (added; not in the task description)

- **A1** [open] The task: from the start, move left or right once and halt; moving left gives reward −1, right +1. Learning runs over repeated runs with `init-soar` between them, which keep the RL values (V1's readme shows 12 runs).
- **A2** [open] Directions are the values −1 (left) and 1 (right) of the move's value parameter `direction`, instead of V1's direction objects with a name and a reward; the agent's location is 0 at the start and the direction after the move, instead of V1's symbols start, left and right.
- **A3** [open] Rewards are the variant's (a location of −1 gives −1, of 1 gives +1), given by reward rules on the agent's location, instead of being read from V1's direction objects. V1's values are those, so the rewards are the same.
- **A4** [open] The goal is that the agent has moved (`moved` = 1), which halts it, as V1's done elaboration halts once the location is not start. `moved` is added because a goal is a set of values, not a test that a value differs from one.
- **A5** [open] RL: Soar's defaults, as V1 (learning on, learning rate 0.3, discount 0.9, epsilon-greedy with epsilon 0.1). One RL template over the move's direction makes one rule per direction with initial value 0, as V1's two hand-written RL rules.
