# Missionaries & Cannibals — plan step 6 (6 November 2026)

Lean: `agentgen/Agent/Families/Mac.lean` (4 variants). Projects: `projects/`. Runs: `results/orig`, `results/gen` (20 seeds, cap 500 decisions, seed set after loading; `harness.py`); table `compare.csv`.

## Variants → originals
| Variant | Method / learning | Replaces |
|---|---|---|
| mac | random + undo preferences | mac V1, V2, V3, mac1, mac2 |
| mac-rl | RL (−1 failure, +1 goal) + undo preferences | mac-substate-RL |
| mac-look-ahead | look-ahead, failure states and duplicates = failure; chunking | mac-planning V1, V3, mac1-planning, mac-look-ahead, ChunkingDemo MaC_Planning |
| mac-look-ahead-numeric | same + numeric evaluation (people on right bank) | mac1-planning-numeric |

Not replaced: mac-planning V2 (two top initializations tie; never starts), mac-lookahead-RL (RL never on; 0/17 solved, Soar 9.6.5 segfaults on seeds 4, 15, 16), mac3-planning (duplicate rule does not prune; Soar halts at goal-depth limit). Reasons in the module docstring.

## Comparison (solved/20, median crossings; optimum 11)
| Variant | Originals | Regenerated |
|---|---|---|
| mac | V1, V2, mac1: 20/20, 95; V3: 20/20, 120; mac2: 20/20, 67 | 20/20, 119 |
| mac-rl | substate-RL: 20/20, 72 | 20/20, 62 |
| mac-look-ahead | planning V1: 20/20, 11; V3: 3/19; mac1-planning: 3/19; look-ahead: 7/20; demo: 12/20 (all 11 when solved) | **3/20**, 11 |
| mac-look-ahead-numeric | 0/20 (oscillates) | 20/20, 15 |

Seed 19 of mac-planning V3 and mac1-planning was killed (out of memory). V3 and mac1-planning moved into a failure state at the top in 4 runs and halted; the regenerated agents never did. Random variants differ only by the spread of a random walk.

## Theorems (Mac.lean; all build)
`conventions` (every variant passes `check`, decide); `shortest_safe` / `none_shorter_safe` (shortest solution avoiding failure states: 11 crossings); `shortest_ignoring_failure` (9 without failure states); `constraints_hold` (counts 0–3, boat 0–1 in every reachable state); `conserved` (always 3 M, 3 C, 1 boat in total). Water Jug theorems and round trip still build; Water Jug output byte-identical (english.md too).

## Soar 9.6.5 vs soar-lean
All four MATCH (`leancmp/*.out`): mac 60 decisions; mac-look-ahead 30 chunks; numeric 62 chunks; mac-rl 48 decisions, 167 RL rules, values equal.

## Assumptions (open; A1–A10 in Mac.lean)
A1 task; A2 failure = missionaries outnumbered, not a constraint; A3 representation; A4 from/to + value parameters; A5 undo = exact reverse of last move; A6 goal/halt, elaboration-initialization dropped; A7 duplicates of any ancestor = failure, library no-operator failure replaces the task rule; A8 numeric variant kept although its original never solves; A9 RL templates instead of chunked RL rules, −1 (original −2); A10 no singletons, demo's srand overridden.

## DSL extensions (general, optional)
Value parameters (`Operator.vparams`, `Expr/Atom.val`, static `Guard.vcmp`); named objects with static links (`Agent.objs`, `Guard.link`, `Goal.name`); failure states (`Agent.failure` → `^failure <desired>`); preference rules against a `^last-move` record (`Agent.prefs`); look-ahead `dup := .failure` and numeric `Score`; RL `failureReward`/`goalReward`; Sem `bfsSafe`, `invariantS`, links/names/values. `check` covers all.

## New general conventions
The brief does not define L0–L6; levels below are proposals for JL.
| Statement | Level (proposed) | Subject | Rationale |
|---|---|---|---|
| Failure states declared once, marked by one elaboration `^failure <desired>`; every method uses it | L3? | failure states | one definition, methods cannot disagree |
| Object-valued (link) attributes are static; duplicate tests and RL templates exclude them | L2? | representation | identifiers differ between state copies |
| Value parameters: one proposal per value combination, constants on the operator; apply reads them from the operator | L2? | operators | precondition style; instances distinguishable for preferences, chunking, RL |
| Preferences about the previous operator compare with a `^last-move` record (name + parameters), changed by the single-valued rule pair | L3? | search control | "undo" needs the parameters |
| RL templates are written with `:template` | L1? | RL | without it, one shared value for all matches |

## Problems and surprises
1. **Bug in the Water Jug pilot:** `Soar.Production.toSoar` omits `:template`, so water-jug-rl has three ordinary RL rules (one value per operator). MaC prints the flag via `agentgen`; Water Jug left byte-identical as required — JL to decide on regenerating it.
2. **mac-look-ahead 3/20 vs mac-planning V1 20/20:** after the first search, chunks make path moves "best", but rejections of going back depend on ancestors that no longer exist at the top. A later top-level search also finds "success" for moving back, and chunks lock in [3,1|0,2] ↔ [1,1|2,2]. Same library and structure as the original; the cause of the original's success is not found. Duplicates as partial failure: 5/20. Open: top-level path memory or iterative deepening (R12).
3. **Numeric variant better than its original** (20/20 vs 0/20); cause not isolated.
4. Originals' local selection libraries equal the 9.6.5 library (mac-planning V1 behaves the same with the default library).

## After A2 (JL, 6 Nov 2026): failure states halt

A failure state is a task constraint, not built into the proposals; entering one at the top state halts (new rule `mac*halt*failure`; convention ELB-014). The undo-after-failure preference is dropped; avoid-undo stays (A5). Runs in `results/gen-a2` (20 seeds, cap 500):

| variant | before (results/gen) | after |
|---|---|---|
| mac (random) | 20/20 solved | 0/20 — every random walk enters a failure state and halts |
| mac-rl, 1 episode | 20/20 | — |
| mac-rl, 100 episodes (last episode) | — | 0/20 |
| mac-rl, 500 episodes, seeds 1–3, last 100 | — | 0, 3, 64 solved |
| mac-look-ahead | 3/20 | 3/20 (unchanged; chunk problem, to fix later) |
| mac-look-ahead-numeric | 20/20 | 20/20 |

RL: with a −1 terminal reward, +1 at the goal and discount 0.5 (from the original), the goal's reward is about 0.5^10 by the time it reaches the first moves, so the agent mostly learns to avoid failures and loops. Bears on A9.

## After A5 (JL, 6 Nov 2026): no undo heuristic

`results/gen-a5`: mac (pure random walk) 0/20 solved (mean 5 decisions before a failure halt); mac-rl, 500 episodes, 20 seeds: 0 solved in the last 100 episodes of every seed (with avoid-undo, seeds 1–3 gave 0, 3, 64). Bears on A9 (discount 0.5, rewards).

## After A9 (JL, 6 Nov 2026): cost per move; a Soar bug in RL templates

Cost −0.01 per move added (`mac*reward*step`). With episodes run by `init-soar` it still learned nothing — because of a **Soar 9.6.5 bug**: after `init-soar`, RL templates instantiate malformed rules with merged identifier variables, e.g. `(<x1> ^to <x1> ^boat 0 ^cannibals 1 ^cannibals 0 … ^name move-boat ^name right)`, which never match (after 5 episodes 129 of 158 RL rules were malformed). All earlier multi-episode M&C RL numbers (gen-a2, gen-a5, gen-a9/mac-rl.jsonl) are invalid. Workaround in the harness (`--fresh`): each episode in a fresh kernel agent, carrying the RL rules and their values over as text (no malformed rules; 99 rules after 8 episodes, all well-formed). Water Jug RL runs were single episodes, so unaffected.

With `--fresh`, 500 episodes (12 of 20 seeds finished within the time limit; `results/gen-a9/mac-rl-fresh.jsonl`): solved in the last 100 episodes per seed 2, 10, 43, 0, 17, 13, 38, 25, 10, 0, 1, 6; shortest solution found 11 crossings (the optimum) in 8 seeds. Learning is slow (epsilon 0.1, discount 0.5).

All 20 seeds (500 episodes each, `--fresh`): solved in the last 100 episodes 2, 10, 43, 23, 0, 0, 1, 6, 0, 13, 0, 17, 13, 40, 5, 38, 25, 10, 8, 12 (mean 13.3); every seed solved at least once; 12 seeds found an 11-crossing solution in the last 100.

## Why mac-look-ahead (with chunking) solves 3/20 — diagnosis (for JL)

Evidence (seed 2):
1. Without chunking the same agent solves 5 of 6 seeds (11–21 crossings, 860–2200 decisions); mac-planning V1 without chunking behaves the same (5 of 6). So the search is fine; chunking is what locks the loop.
2. The first top-level search (73 decisions, 52 chunks) learns a success→best chunk at the start state, (3,3,L): move 2 cannibals (t72-26). That is right.
3. At the next top state, (3,1,R), no chunk from the first search applies. In that search, "move the 2 cannibals back" from (3,1,R) was a duplicate of an ancestor — the top state (3,3,L) — so it was rejected by a failure, and the chunk that rejects it tests the ancestor. At the real top, (3,3,L) is no longer an ancestor (the top state has no memory of states it has left), so the reject does not fire, and there is a new tie.
4. In the new look-ahead from (3,1,R), going back to (3,3,L) is a genuine success: the goal is still reachable from there. The selection library takes the first success it finds; when "go back" is evaluated first, chunking learns `success-evaluation-becomes-best` for it (t78-2: from 0M2C with the boat, to 3M1C, move 2C, best).
5. Now (3,3,L) → 2C is best and (3,1,R) → 2C back is best, both permanently: a two-state cycle that never needs another tie. Each chunk is correct as a statement ("the goal can be reached through this move"); together they loop because "success" only means reachable, and the knowledge that made the first search avoid going back (the ancestor duplicate) is path-relative and not available at the top.

Ruled out: the static `^other-bank` links (removed in a test copy: still 3/20).

Why mac-planning V1 does not loop (checked, seed 2): its first search learns a best chunk for every step of the path (e.g. at (3,1,R), "move 1 cannibal", t69-23), so after the first search no top-level tie remains (90 decisions in all). The generated agent's first search learns best chunks for only 9 of its steps — none at (3,1,R). The difference is the duplicate rule:
- Generated: the duplicate test goes through `^ancestor` links, so chunking turns each duplicate failure into a reject chunk that tests the ancestor (e.g. t63-2: "reject 1C from 0M3C to 3M0C when an ancestor has 0M2C / 3M1C with the boat"). Inside later look-ahead states these chunks fire before any tie, leaving one acceptable operator, so no tie and no best chunk is learned for that step. At the real top the ancestor is missing, the reject does not fire, and a new search runs — and there "go back" is a genuine success (step 4).
- V1: its duplicate rule matches the deepest state against any other state with a negated test on the substate (`-(state <s3> ^superstate <s2>)`); no reject chunks for duplicates are learned (its 9 reject chunks are all for real failure states and test no other state). Duplicates are re-detected by search every time, every step of the path has a tie, and every step gets a best chunk.

So the chunks are not wrong in what they say; the problem is the combination: path-relative knowledge (a duplicate of an ancestor) chunked into reject rules that pre-empt ties in the look-ahead, while the top state has no record of visited states. Possible remedies (JL to decide; nothing changed): (a) keep duplicate failures out of chunks, as V1 does; (b) give the top state a record of visited states, so a return to a visited state is a duplicate at the top too; (c) iterative deepening or a numeric (distance) evaluation instead of first-success.

## Final state (6 Nov 2026, all ten assumptions decided)

Task level, current projects (`results/gen-final`, 20 seeds, cap 500):

| variant | solved | notes |
|---|---|---|
| mac (random walk, no undo heuristic) | 0/20 | every walk enters a failure state and halts |
| mac-rl (500 episodes, fresh agent per episode) | mean 13.3 of last 100 episodes | every seed solved at least once; 12 seeds found 11 crossings |
| mac-look-ahead | 3/20 (11 crossings) | chunk loop, diagnosed above; remedy for JL |
| mac-look-ahead-numeric | 20/20 (11–39 crossings) | |

Soar 9.6.5 vs soar-lean on the current projects: `leancmp2/*.out`.
