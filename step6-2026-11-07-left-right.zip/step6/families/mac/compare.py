"""Comparison table: each regenerated variant against the originals it replaces (and the
originals not replaced). Moves = boat crossings to the goal (optimal 11)."""
import json, os, csv
from summarize import summ
vs = json.load(open('gen/mac.json'))
def fmt(s):
    if not s: return 'no runs'
    m = f"median {s['med']} moves (min {s['mn']})" if s['solved'] else 'no solution'
    return f"{s['solved']}/{s['n']} solved; {m}; halted {s['halted']}; entered failure {s['fail']}; chunks {s['chunks']}; RL rules {s['rl']}"
rows = []
for v in vs:
    g = summ(f"results/gen/{v['name']}.jsonl")
    for o in v['replaces']:
        a, ver = o.split()
        rows.append([v['name'], o, fmt(summ(f"results/orig/{a}-{ver}.jsonl")), fmt(g)])
for o in ['mac-planning V2', 'mac-lookahead-RL V1', 'mac3-planning V1']:
    a, ver = o.split()
    rows.append(['(not replaced)', o, fmt(summ(f"results/orig/{a}-{ver}.jsonl")), ''])
with open('compare.csv', 'w', newline='') as f:
    w = csv.writer(f); w.writerow(['regenerated', 'original', 'original (20 seeds, 500 decisions)', 'regenerated (same seeds)']); w.writerows(rows)
for r in rows: print(' | '.join(r))
