"""Task-level runs of Missionaries & Cannibals agents in Soar 9.6.5 (soar_sml).

usage: harness.py DIR LOADFILE [--cap N] [--seeds a-b] [--episodes K]
For each seed: source the agent, then `srand SEED` (overriding the agent's own srand), run decision
by decision up to the cap, and record: whether the top state reached the goal (3 missionaries and
3 cannibals on the right bank), the number of boat crossings and top-level operators before that,
whether the agent halted, whether a failure state (missionaries outnumbered on a bank) was entered
at the top, and chunks / RL rules. The state is read from every representation in the family:
banks as objects (^left-bank/^right-bank with missionaries/cannibals, or ^left/^right with mice/cats),
counts per type (^missionaries ^left ^right), `holds` objects, and the generated agents' ^bank
objects. A state is (missionaries left, cannibals left, boat side). With --episodes K the agent is
run K times in the same kernel agent (init-soar between runs keeps learned rules and RL values);
only the last episode is reported (and a summary of all). Prints one JSON object per run.
"""
import argparse, json, os, re
import soar_sml as sml

TOP_OP = re.compile(r'^\s*\d+:    O: \S+ \(([^)]+)\)', re.M)
SKIP = ('evaluate-operator', 'create-preferences', 'wait')

def wm(a, depth=3):
    t = a.ExecuteCommandLine(f'print --depth {depth} s1')
    objs = {}
    for m in re.finditer(r'\((\S+)([^()]*)\)', t):
        d = objs.setdefault(m.group(1), [])
        for x in re.finditer(r'\^(\S+)\s+([^\s)^]+)', m.group(2)):
            d.append((x.group(1), x.group(2)))
    return objs

def get(o, attr):
    return [v for k, v in o if k == attr]

def num(xs):
    try: return int(float(xs[0]))
    except Exception: return None

def snapshot(a):
    """(missionaries left, cannibals left, missionaries right, cannibals right, boat 'L'/'R') or None."""
    w = wm(a); s = w.get('S1', [])
    side = None
    # generated: ^bank objects with ^name left/right, ^missionaries ^cannibals ^boat
    banks = {}
    for b in get(s, 'bank') + get(s, 'left-bank') + get(s, 'right-bank') + get(s, 'left') + get(s, 'right'):
        o = w.get(b)
        if not o: continue
        nm = get(o, 'name')
        key = nm[0] if nm and nm[0] in ('left', 'right') else None
        if key is None:
            key = 'left' if b in get(s, 'left-bank') + get(s, 'left') else 'right' if b in get(s, 'right-bank') + get(s, 'right') else None
        if key is None: continue
        m = num(get(o, 'missionaries') or get(o, 'mice')); c = num(get(o, 'cannibals') or get(o, 'cats'))
        if m is None or c is None: continue
        bt = num(get(o, 'boat'))
        banks[key] = (m, c, bt)
    if 'left' in banks and 'right' in banks:
        L, R = banks['left'], banks['right']
        if L[2] is not None and R[2] is not None:
            side = 'L' if L[2] == 1 else 'R' if R[2] == 1 else '?'
        else:
            bs = get(s, 'boat') or get(s, 'bank')
            if bs: side = 'L' if bs[0] in ('left-bank', 'left') else 'R' if bs[0] in ('right-bank', 'right') else '?'
        return (L[0], L[1], R[0], R[1], side)
    # mac2: ^missionaries M (^left ^right), ^cannibals, ^boat
    ms, cs, bs = get(s, 'missionaries'), get(s, 'cannibals'), get(s, 'boat')
    if ms and cs and ms[0] in w and cs[0] in w:
        M, C = w[ms[0]], w[cs[0]]
        B = w.get(bs[0], []) if bs else []
        side = 'L' if num(get(B, 'left')) == 1 else 'R' if num(get(B, 'right')) == 1 else '?'
        return (num(get(M, 'left')), num(get(C, 'left')), num(get(M, 'right')), num(get(C, 'right')), side)
    # mac3: ^holds (^type ^number ^side) and ^boat <bank> (^name leftbank)
    hs = get(s, 'holds')
    if hs:
        cnt = {}
        for h in hs:
            o = w.get(h, [])
            t, n, sd = get(o, 'type'), num(get(o, 'number')), get(o, 'side')
            if t and sd and n is not None:
                nm = get(w.get(sd[0], []), 'name')
                cnt[(t[0], nm[0] if nm else sd[0])] = n
        b = bs[0] if bs else None
        nm = get(w.get(b, []), 'name') if b else []
        side = 'L' if nm and nm[0] == 'leftbank' else 'R' if nm and nm[0] == 'rightbank' else '?'
        g = lambda t, sd: cnt.get((t, sd))
        return (g('missionaries', 'leftbank'), g('cannibals', 'leftbank'), g('missionaries', 'rightbank'), g('cannibals', 'rightbank'), side)
    return None

def failure(st):
    if not st or None in st[:4]: return False
    ml, cl, mr, cr, _ = st
    return (0 < ml < cl) or (0 < mr < cr)

def episode(a, cap, out):
    ops, goal_ops, goal_moves, halted, path, entered_failure = [], None, None, False, [], False
    n = 0
    for n in range(1, cap + 1):
        out.clear()
        a.RunSelf(1)
        txt = ''.join(out)
        ops += [o for o in TOP_OP.findall(txt) if o not in SKIP]
        st = snapshot(a)
        if st and (not path or path[-1] != st):
            path.append(st)
            entered_failure |= failure(st)
        if goal_ops is None and st and st[2:4] == (3, 3):
            goal_ops = len(ops); goal_moves = len(path) - 1
        if 'halted' in txt or 'Soar must halt' in txt:
            halted = True
            break
        if 'This Agent halted' in txt: halted = True; break
    return dict(decisions=n, halted=halted, solved=goal_ops is not None, ops_to_goal=goal_ops,
                moves_to_goal=goal_moves, entered_failure=entered_failure,
                path=[list(p) for p in path[:40]], ops=ops[:40])

def rl_text(a):
    names = re.findall(r'^(rl\*\S+)', a.ExecuteCommandLine('print --rl'), re.M)
    return '\n'.join(a.ExecuteCommandLine('print ' + n) for n in names)

def run_fresh(d, load, cap, seed, episodes):
    """Episodes in fresh kernel agents, carrying the RL rules (with their values) over as text.
    Works around Soar 9.6.5: after init-soar, RL templates instantiate malformed rules
    (identifier variables merged, e.g. `(<x1> ^to <x1> ^name move-boat ^name right)`) that never
    match, so nothing is learned."""
    k = sml.Kernel.CreateKernelInCurrentThread(True, 0)
    os.chdir(d); saved = ''; eps = []; src = ''
    for e in range(episodes):
        a = k.CreateAgent(f'h{e}'); out = []
        a.RegisterForPrintEvent(sml.smlEVENT_PRINT, lambda *x: out.append(x[-1]), None)
        a.ExecuteCommandLine('cd ' + d); src += a.ExecuteCommandLine('source ' + load)
        if saved:
            open('/tmp/_rl_saved_%d.soar' % os.getpid(), 'w').write(saved)
            a.ExecuteCommandLine('source /tmp/_rl_saved_%d.soar' % os.getpid())
        a.ExecuteCommandLine(f'srand {seed * 10007 + e}'); a.ExecuteCommandLine('watch 1')
        eps.append(episode(a, cap, out)); saved = rl_text(a)
        rlr = saved.count('sp {'); k.DestroyAgent(a)
    k.Shutdown()
    r = eps[-1]; r.update(seed=seed, chunks=0, rl_rules=rlr, source_errors='rror' in src)
    r['episodes'] = [dict(solved=x['solved'], ops=x['ops_to_goal'], moves=x['moves_to_goal'], decisions=x['decisions']) for x in eps]
    return r

def run(d, load, cap, seed, episodes=1):
    k = sml.Kernel.CreateKernelInCurrentThread(True, 0)
    a = k.CreateAgent('h')
    out = []
    a.RegisterForPrintEvent(sml.smlEVENT_PRINT, lambda *x: out.append(x[-1]), None)
    os.chdir(d); a.ExecuteCommandLine('cd ' + d)
    src = a.ExecuteCommandLine('source ' + load)
    a.ExecuteCommandLine(f'srand {seed}')
    a.ExecuteCommandLine('watch 1')
    eps = []
    for e in range(episodes):
        if e: a.ExecuteCommandLine('init-soar')
        eps.append(episode(a, cap, out))
    r = eps[-1]
    m = re.search(r'(\d+) decisions', a.ExecuteCommandLine('stats'))
    chunks = len(re.findall(r'^\S', a.ExecuteCommandLine('print --chunks'), re.M))
    rlr = len([l for l in a.ExecuteCommandLine('print --rl').splitlines() if l.strip() and not l.startswith(' ')])
    k.Shutdown()
    r.update(seed=seed, chunks=chunks, rl_rules=rlr, source_errors='rror' in src)
    if episodes > 1:
        r['episodes'] = [dict(solved=x['solved'], ops=x['ops_to_goal'], moves=x['moves_to_goal'], decisions=x['decisions']) for x in eps]
    return r

if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('dir'); p.add_argument('load')
    p.add_argument('--cap', type=int, default=500)
    p.add_argument('--seeds', default='1-20')
    p.add_argument('--episodes', type=int, default=1)
    p.add_argument('--fresh', action='store_true', help='each episode in a fresh agent (RL rules carried over)')
    o = p.parse_args()
    d = os.path.abspath(o.dir)
    lo, hi = map(int, o.seeds.split('-'))
    for s in range(lo, hi + 1):
        print(json.dumps((run_fresh if o.fresh else run)(d, o.load, o.cap, s, o.episodes)), flush=True)
