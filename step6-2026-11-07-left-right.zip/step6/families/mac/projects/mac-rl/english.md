# mac

## The task

The task state holds several values of `bank`, each a bank. The two river banks.

A bank has `name` (one of left, right), `missionaries` (an integer), `cannibals` (an integer), `boat` (an integer), `other-bank` (a bank).

Initially the task state has:
- a `bank` named left with missionaries 3 and cannibals 3 and boat 1; its `other-bank` is right
- a `bank` named right with missionaries 0 and cannibals 0 and boat 0; its `other-bank` is left
Links between objects never change.

**Failure state.** A state is a failure state when some bank has self.missionaries > 0 and self.missionaries < self.cannibals (with `self` the bank). The missionaries on that bank are lost.

**Constraint (part of the task).** Every bank always has self.missionaries ≥ 0 and self.missionaries ≤ 3 (with `self` the bank); every operator must preserve this.

**Constraint (part of the task).** Every bank always has self.cannibals ≥ 0 and self.cannibals ≤ 3 (with `self` the bank); every operator must preserve this.

**Constraint (part of the task).** Every bank always has self.boat ≥ 0 and self.boat ≤ 1 (with `self` the bank); every operator must preserve this.

**Goal.** The bank named right has missionaries 3 and cannibals 3. When the goal holds in the task state, the agent reports success and halts.

## Operators

An operator's changes are made together: every value on the right is read before any change.

**move-boat(from: bank, to: bank, missionaries ∈ {0, 1, 2}, cannibals ∈ {0, 1, 2}).** Proposed when missionaries + cannibals ≥ 1 and missionaries + cannibals ≤ 2 and from.other-bank is to and from.boat = 1 and from.missionaries ≥ missionaries and from.cannibals ≥ cannibals. Row across with one or two people; the boat goes with them.
- Effect: from.missionaries := from.missionaries − missionaries; to.missionaries := to.missionaries + missionaries; from.cannibals := from.cannibals − cannibals; to.cannibals := to.cannibals + cannibals; from.boat := 0; to.boat := 1.

## Choosing among proposed operators

The agent learns by reinforcement which operator to choose, from the operator and the attribute values of its parameter objects. Rewards:
- -1 for a failure state
- 1 when the goal holds
- -0.010000 for every move (a cost per move)

## Learning

Reinforcement learning on: learning rate 0.100000, discount 0.500000, epsilon-greedy exploration.

## Assumptions (added; not in the task description)

- **A1** [accepted] The task: 3 missionaries, 3 cannibals and the boat on the left bank; the goal is all 6 on the right bank (the boat is then there too). A crossing carries 1 or 2 people, any mix, and the boat; this is the five proposal rules of every original.
- **A2** [accepted] A failure state is a bank with at least one missionary and more cannibals than missionaries (all originals). It is a task constraint, but it is not built into the proposals (that would give the agent too much knowledge): moves into a failure state are proposed, and entering one at the top state is a task failure and halts. Look-ahead evaluates it as a failure (the move is rejected); RL gives reward −1 and the episode ends. The originals’ undo after entering a failure state is dropped (JL, 6 Nov 2026).
- **A3** [accepted] Representation: banks are objects `^bank` with `^name left|right`, missionary, cannibal and boat counts, and a static `^other-bank` link (mac V2). The originals used `^left-bank`/`^right-bank` (or `^left`/`^right`) state attributes, mice and cats (mac V3, mac-look-ahead, mac-substate-RL), the boat as a state attribute (mac-planning V1, chunking demo, mac V3), or per-type objects (mac2, mac3-planning). Counts stay in range (declared constraints, proved).
- **A4** [accepted] move-boat has object parameters from/to (from has the boat; to is its other bank) and value parameters missionaries, cannibals ∈ {0,1,2} with 1 ≤ sum ≤ 2. The originals' operators named only the bank (or neither) and gave the counts, some omitting zero counts, and added bookkeeping (`^types`, `^boat 1`).
- **A5** [accepted] No undo heuristic: the originals (mac V2 and relatives) remembered the last move (`^last-move`) and made its reverse worst (and best after a failure state); both are dropped (JL, 6 Nov 2026). The random agent is a pure random walk, and RL must learn not to undo.
- **A6** [accepted] Goal: `^desired` with the right bank's 3 and 3 and a success rule; halt at the top state (all originals halted at success; mac1, mac2 and mac1-planning initialized by elaboration instead of an operator, which is dropped).
- **A7** [accepted] Look-ahead (mac-planning V1, mac-look-ahead, chunking demo, mac-planning V3, mac1-planning): default selection library as is; a failure state is a failure evaluation; a state equal to any ancestor (top state included) is a failure, not a partial failure, as in all these originals. mac-look-ahead and the chunking demo compared only with the states one and two moves back; mac-planning V1 compared with every state on the stack. The originals' own state no-change failure rule is dropped: the library marks a state with no acceptable operator as a failure (one decision later).
- **A8** [accepted] Numeric look-ahead (mac1-planning-numeric): each tried state is evaluated by the number of people on the right bank, higher is better, with failure states and duplicates still failures. This is greedy one-step look-ahead; it is kept as a variant although in Soar 9.6.5 the original never solves the task (it moves back and forth).
- **A9** [accepted] RL (mac-substate-RL): its RL rules were made by chunking over a look-ahead that gave every operator expected value 0 at once; here RL templates with initial value 0 on the operator, its counts and both banks’ names and counts (all non-derived, non-link attributes). Rewards −1 in a failure state (which halts; the original’s two reward rules gave −2), +1 at the goal, and a cost of −0.01 per move (JL, 6 Nov 2026); learning rate 0.1, discount 0.5, epsilon-greedy (as in the original); no undo heuristic (A5).
- **A10** [accepted] Chunking: `chunk always`, no singletons declared (R16). The chunking demo declared 21 singletons and used srand 3 (its comment: srand 1 loops forever); the harness sets the seed after loading. The demo’s 21 singleton declarations are removed (JL, 6 Nov 2026).
