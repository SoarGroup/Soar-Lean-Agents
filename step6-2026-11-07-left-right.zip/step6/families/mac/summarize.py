import json,glob,os,statistics as st,sys
def summ(f):
    rs=[json.loads(l) for l in open(f)] if os.path.exists(f) else []
    if not rs: return None
    sol=[r for r in rs if r['solved']]
    mv=[r['moves_to_goal'] for r in sol]
    return dict(n=len(rs),solved=len(sol),halted=sum(r['halted'] for r in rs),
        med=st.median(mv) if mv else None, mn=min(mv) if mv else None,
        dec=st.median([r['decisions'] for r in sol]) if sol else None,
        fail=sum(r['entered_failure'] for r in rs),
        chunks=st.median([r['chunks'] for r in rs]), rl=st.median([r['rl_rules'] for r in rs]))
if __name__=='__main__':
    for d in ['orig','gen']:
        for f in sorted(glob.glob(f'results/{d}/*.jsonl')):
            print(d, os.path.basename(f)[:-6], summ(f))
