/^sp \{(evaluate-operator|selection|top-goal|duplicate-desired|monitor)/{skip=1; next}
/^sp \{/{skip=0}
/^# CHANGED/{next}
/^# /{next}
!skip
