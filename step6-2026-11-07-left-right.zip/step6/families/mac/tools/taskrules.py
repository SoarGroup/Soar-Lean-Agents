"""Split flattened agents into task rules and selection-library rules; report library rules that
differ from the default library. usage: taskrules.py DEFAULT_DIR FLAT_DIR OUT_DIR"""
import re, sys, os, glob
def rules(text):
    out = {}; i = 0
    for m in re.finditer(r'^sp \{(\S+)', text, re.M):
        start = m.start(); depth = 0; j = text.index('{', start)
        for k in range(j, len(text)):
            if text[k] == '{': depth += 1
            elif text[k] == '}':
                depth -= 1
                if depth == 0: break
        out[m.group(1)] = text[start:k+1]
    return out
def norm(r): return re.sub(r'\s+', ' ', re.sub(r'"[^"]*"', '', r)).strip()
dd, fd, od = sys.argv[1:4]
lib = {}
for f in glob.glob(dd + '/**/*.soar', recursive=True): lib.update(rules(open(f).read()))
os.makedirs(od, exist_ok=True)
for f in sorted(glob.glob(fd + '/*.soar')):
    t = open(f).read(); rs = rules(t)
    task = {n: r for n, r in rs.items() if n not in lib}
    changed = [n for n, r in rs.items() if n in lib and norm(r) != norm(lib[n])]
    missing = [n for n in lib if n not in rs]
    cmds = [l for l in t.splitlines() if l and not l[0].isspace() and not l.startswith(('sp', '}', '#'))]
    with open(os.path.join(od, os.path.basename(f)), 'w') as o:
        o.write('# commands: ' + ' | '.join(cmds) + '\n')
        o.write(f'# library rules: {len(rs)-len(task)} (changed: {changed}; missing: {len(missing)} {missing[:8]})\n\n')
        for n in changed: o.write('# CHANGED LIBRARY RULE\n' + rs[n] + '\n\n')
        o.write('\n\n'.join(task.values()) + '\n')
    print(os.path.basename(f), len(rs), 'task', len(task), 'changed', changed, 'missing', len(missing))
