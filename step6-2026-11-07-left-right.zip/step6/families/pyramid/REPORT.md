# Pyramid — step 6

Lean: `agentgen/Agent/Families/Pyramid.lean`.

Variants:
- `pyramid` (base 5, height 10) replaces pyramid V1 and pyramid-jel V1.
- `pyramid-anderson` (5, 2) replaces pyramid-anderson V1.
- `pyramid-hierarchical` (10, 6) replaces pyramid-hierarchical V1; `sum-pyramid` is carried out by an `add-next-term` sub-operator, its effect stated in closed form.

Not replaced: the 10 instruct agents. They interpret procedures given as working-memory data and create lists at run time; the DSL has neither. Their `^smem.retrieve` interface does not exist in 9.6.5, so retrieval takes the `failed-smem` path (V3, instruct-01-03-05) or never runs. instruct V2, V5, V6 crash Soar 9.6.5 through the Python SML print callback.

| Original | Answer | Decisions (original → regenerated) |
|---|---|---|
| pyramid V1, pyramid-jel V1 | 0 | 14 → 13 |
| pyramid-anderson V1 | 12 | 6 → 5 |
| pyramid-hierarchical V1 | 49 | 23 → 11 |

All 20/20. Soar vs soar-lean: MATCH.

Theorems: `conventions`; `answers` (0, 12, 49); `lengths` (11, 3, 1); `deterministic`; `constraints_hold`; `hierarchical_refines`; `closed_form` (closed form = term-by-term sum for bases −20..20, heights 0..20).

Open assumptions:
- A1: height + 1 terms.
- A2: one problem object.
- A3: goal `height = −1`, with the report "The answer is N." (the originals' typo "asnwer" fixed).
- A4: per-term " + N" output.
- A5: the hierarchical list is dropped.
- A6: anderson's `start` operator is folded into the initial state.

Conventions used: messages, `Goal.report`, mul/div; "hierarchical operators keep their identity".

## Decisions (JL, 6 Nov 2026)

A1–A4 and A6 accepted. A5 deferred: pyramid-hierarchical V1 keeps its two phases (build the terms as a linked list, then sum the list with a pointer in a substate). That needs run-time object creation and mutable links in the DSL, which will be built for Blocks World; until then **pyramid-hierarchical V1 is not replaced** and the `pyramid-hierarchical` variant is removed (its earlier results above are superseded). The one-operator version stays in Pyramid.lean only for the `hierarchical_refines` and `closed_form` theorems.

## Pyramid A5 revisited (6 Nov 2026): pyramid-hierarchical with its two phases

New general DSL features: **run-time object creation** (`Case.creates`: an operator's application makes objects held by the task state, values computed from the state before the change) and **sub-operators with their own object parameters** (`SubOp.params`). Semantics: created objects are appended to the state (their holder recorded); `Agent.runConcrete` runs an agent through its sub-operators and checks each hierarchical operator's result against its specified effect on the objects that existed before.

`pyramid-hierarchical` (replaces pyramid-hierarchical V1 again):
- expand-pyramid writes the terms out: its sub-operator expand-next-term makes one `term` object (index, value) per step, held by the task state, and writes " + N";
- sum-terms sums them: add-term (bound to the term whose index is next) and final-sum, with the running sum and the next index local to the substate;
- goal: summed (the original's `^final-sum`), report "The answer is 49."

Results: 20/20 solved, answer 49, 22 decisions (original 23). Soar vs soar-lean: MATCH (`leancmp/plain.out`, 21 decisions, 45 WMEs). Theorem `hierarchical_two_phases`: the concrete run writes 7 terms and sums them to 49, both phases agreeing with their specified effects. (The earlier one-operator version's results are kept as `results/gen/pyramid-hierarchical.one-operator.jsonl`.)

Difference from the original (A5 revised, A7): the terms are task objects found by index, not a linked list walked with a pointer; the goal is "summed" rather than height = −1.
