"""Task-level runs of Pyramid agents in Soar 9.6.5 (soar_sml).

usage: harness.py DIR LOADFILE --answer N [--cap N] [--seeds a-b]
For each seed: source the agent, `srand SEED`, run decision by decision up to the cap; record
whether it halted, the answer it wrote ("The answer is N" / "The asnwer is N"; pyramid-anderson:
"The problem has been solved.  The answer is N"), whether that is the expected answer, the
decisions to the halt, and the top-level task operators. Prints one JSON object per run.
"""
import argparse, json, os, re
import soar_sml as sml

TOP_OP = re.compile(r'^\s*\d+:    O: \S+ \(([^)]+)\)', re.M)

def run(d, load, cap, seed, answer):
    k = sml.Kernel.CreateKernelInCurrentThread(True, 0)
    a = k.CreateAgent('h')
    out = []
    a.RegisterForPrintEvent(sml.smlEVENT_PRINT, lambda *x: out.append(x[-1]), None)
    a.ExecuteCommandLine('cd ' + d)
    src = a.ExecuteCommandLine('source ' + load)
    a.ExecuteCommandLine(f'srand {seed}'); a.ExecuteCommandLine('watch 1')
    halted, n, text = False, 0, ''
    for n in range(1, cap + 1):
        out.clear(); a.RunSelf(1); txt = ''.join(out); text += txt
        if 'halted' in txt or 'This Agent halted' in txt:
            halted = True; break
    k.Shutdown()
    m = re.findall(r'The a(?:ns|sn)wer is (-?\d+)', text)
    got = int(m[-1]) if m else None
    ops = [o for o in TOP_OP.findall(text) if not o.startswith('initialize')]
    return dict(seed=seed, decisions=n, halted=halted, answer=got, solved=halted and got == answer,
                top_ops=len(ops), source_errors='rror' in src)

if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('dir'); p.add_argument('load')
    p.add_argument('--answer', type=int, required=True)
    p.add_argument('--cap', type=int, default=500)
    p.add_argument('--seeds', default='1-20')
    o = p.parse_args()
    lo, hi = map(int, o.seeds.split('-'))
    for s in range(lo, hi + 1):
        print(json.dumps(run(os.path.abspath(o.dir), o.load, o.cap, s, o.answer)), flush=True)
