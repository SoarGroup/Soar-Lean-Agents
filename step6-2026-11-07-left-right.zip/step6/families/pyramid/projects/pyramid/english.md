# pyramid

## The task

The task state holds several values of `pyramid`, each a pyramid. The problem.

A pyramid has `term` (an integer), `height` (an integer), `sum` (an integer).

Initially the task state has:
- a `pyramid` with term 5 and height 10 and sum 0

**Constraint (part of the task).** Every pyramid always has self.height ≥ -1 and self.height ≤ 10 (with `self` the pyramid); every operator must preserve this.

**Goal.** Some pyramid has height -1. When the goal holds in the task state, the agent reports success and halts. Before halting it writes "The answer is ⟨self.sum⟩." (with `self` the pyramid).

## Operators

An operator's changes are made together: every value on the right is read before any change.

**add-next-term(pyramid: pyramid).** Proposed when pyramid.height ≥ 0. Add the next term to the sum.
- Effect: pyramid.sum := pyramid.sum + pyramid.term; pyramid.term := pyramid.term − 1; pyramid.height := pyramid.height − 1; writes " + ⟨pyramid.term⟩".

## Choosing among proposed operators

Any proposed operator may be chosen; the choice is random.

## Learning

None.

## Assumptions (added; not in the task description)

- **A1** [accepted] The task: base $ height = the sum of height + 1 terms, from base down by one (all four originals agree on height + 1 terms: pyramid V1 adds while height ≥ 0, pyramid-anderson adds the base and then height more terms).
- **A2** [accepted] Representation: one `pyramid` object with the next term, the height left and the sum. pyramid V1 kept them on the state (`^base` was the next term); pyramid-anderson kept the term, a count up to the height, and `^sum nil` before starting; pyramid-hierarchical kept a linked list of terms (`^expansion`) and a final sum.
- **A3** [accepted] Goal: height = −1 (all terms added), a `^desired` structure; at the goal the agent writes "The answer is N." (the originals' terminate operator) and halts. The originals' typo "asnwer" is corrected.
- **A4** [accepted] Each added term is written as " + N" (pyramid V1, pyramid-jel, pyramid-hierarchical's expansion); pyramid-anderson wrote nothing per term.
- **A5** [revised] pyramid-hierarchical V1 keeps its two phases (JL, 6 Nov 2026): expand-pyramid writes the terms out — its sub-operator expand-next-term makes one `term` object (index, value) per step, held by the task state — and then sum-terms sums them — its sub-operators add-term (bound to the term whose index is next) and final-sum, with the running sum and the next index local to the substate. The original keeps the terms as a linked list (`^expansion` with `^first`/`^current`, terms with `^value`/`^next`) and walks it with a pointer; here the terms are task objects found by index (no linked list, no pointer).
- **A7** [open] pyramid-hierarchical's goal is that the terms have been summed (`summed` = 1, the original's `^final-sum`), not height = −1 (reached after the first phase); the report is the same.
- **A6** [accepted] pyramid-anderson's separate start operator (sum := base, term := base) is part of the initial state here (sum 0, term base: the first add-next-term adds the base).
