# Tic-Tac-Toe — step 6

Lean: `agentgen/Agent/Families/TicTacToe.lean`.

Variant: `tictactoe` replaces TicTacToe V1.

The task: X and O, both playing at random, alternately mark an empty cell of a 3 × 3 board, X first. The game ends when a side has three in a row (it won) or the board is full (a draw). The agent writes the result and halts. A monitor prints the board after every move.

V1's folder also holds an Eight Puzzle look-ahead (`Impasse__Operator_Tie~`, `eight-puzzle_source.soar`, `initialize.soar`), left over from the project it was copied from. The load file does not source it, so it is not part of the agent.

## Structure

Objects:
- 9 cells: x, y, content (0 empty, 1 X, 2 O).
- 8 lines: 3 rows, 3 columns, 2 diagonals, each linked to its three cells.
- The game: turn (1 X, 2 O), winner, over.

Operators:
- `mark`: the side to move marks an empty cell; the turn passes to the other side.
- `x-wins` / `o-wins` (best): a line has three of that side's marks. Sets `over` and `winner` and writes "Side X won." or "Side O won."
- `detect-draw`: no empty cell. Sets `over` and writes "Draw."

Goal: the game's `over` = 1, which halts the agent.

Monitor: V1's board printout, kept by hand as a Raw rule. It prints X, O and blank, via `^shown` elaborations used only by the monitor.

New general feature: **Raw rules are now compiled**, each into its own file headed by the reason it is written by hand. Raw was declared in the DSL but never written out; no earlier family used it. Every other family's output is unchanged.

## Assumptions

- A1: the task as above. V1 has no search control.
- A2: lines are task objects linked to their cells. V1 instead has four elaborations over cell coordinates.
- A3: the end of the game is detected by operators that set `over`.
  - V1 detects three in a row with elaborations that set `^success` and halt at once, and detects a draw with an operator.
  - Here the win operator is best, so it is chosen before any further mark.
  - This adds one decision per game.
- A4: sides are 1 and 2 and empty is 0, where V1 uses the symbols X, O and `| |`. The side to move is the game's `turn`; V1 swaps a `^current-side`/`^other-side` pair instead.
- A5: the monitor is kept as Raw.
- A6: the win message names the side only. V1's also names the row, column or diagonal; here the line is the operator's parameter.

## Results (Soar 9.6.5, 3,000 games each, seeds 1–3000)

| Agent | X won | O won | Draw | Mean marks | Mean decisions | Invalid final boards |
|---|---|---|---|---|---|---|
| TicTacToe V1 | 57.6% | 28.1% | 14.3% | 7.68 | 8.82 | 0 |
| `tictactoe` | 58.6% | 28.9% | 12.5% | 7.65 | 9.65 | 0 |
| Random play, exact | 58.5% | 28.8% | 12.7% | 7.62 | | |

A final board is checked as valid when:
- the marks alternate (X has as many as O, or one more);
- a reported win has a full line of that side's marks;
- a draw has a full board with no full line.

Decisions per game:
- V1: the marks plus initialize. It halts in the elaboration phase.
- Generated: one more, for the win or draw operator.

Open observation: V1's draw rate is 1.6 points above the exact value for random play. That is 2.6 standard deviations over 3,000 games, and it was there in the first 1,000 games as well. Every V1 draw board is a real draw. The generated agent matches the exact rates. The cause is not established; one possibility is how V1's mark proposals are ordered for Soar's random selection.

Soar vs soar-lean (`leancmp/`): MATCH (9 decisions to halt, 126 WMEs).

Theorems:
- `conventions`.
- `game_ends`: the shortest game ends in six operators: five marks and `x-wins`.
