"""Tic-Tac-Toe harness: play N games (seeds 1..N) with the original V1 and with the generated agent;
count the outcomes (X won, O won, draw) and decisions, and check every final board: a reported
win has a full line of that side's marks, a draw a full board with none, and the marks alternate
(X has as many marks as O, or one more)."""
import soar_sml as sml, sys, os, re, json
LINES = [[(x, y) for x in (1, 2, 3)] for y in (1, 2, 3)] + [[(x, y) for y in (1, 2, 3)] for x in (1, 2, 3)] + \
        [[(1, 1), (2, 2), (3, 3)], [(3, 1), (2, 2), (1, 3)]]
def board_from(a, gen):
    b = {}
    for cid in re.findall(r'\^cell (\w+)', a.ExecuteCommandLine('print s1')):
        t = a.ExecuteCommandLine('print ' + cid)
        x = int(re.search(r'\^x (\d)', t).group(1)); y = int(re.search(r'\^y (\d)', t).group(1))
        c = re.search(r'\^content (\S+)', t).group(1)
        b[(x, y)] = {'0': '', '1': 'X', '2': 'O', '|': '', '||': '', 'X': 'X', 'O': 'O'}.get(c.strip('|').strip() or '0', c)
    return b
def play(path, seed, gen):
    k = sml.Kernel.CreateKernelInCurrentThread(True, 0); a = k.CreateAgent('t'); out = []
    a.RegisterForPrintEvent(sml.smlEVENT_PRINT, lambda *x: out.append(x[-1]), None)
    a.ExecuteCommandLine('source ' + os.path.abspath(path)); a.ExecuteCommandLine(f'srand {seed}')
    a.ExecuteCommandLine('watch 0'); a.ExecuteCommandLine('run 100')
    txt = ''.join(out); dec = int(re.search(r'(\d+) decisions', a.ExecuteCommandLine('stats')).group(1))
    b = board_from(a, gen); k.Shutdown()
    m = re.search(r'Side (\w) won', txt)
    res = 'X' if m and m.group(1) == 'X' else 'O' if m else 'draw' if 'Draw' in txt else 'none'
    full = [s for s in 'XO' if any(all(b.get(c) == s for c in l) for l in LINES)]
    nx = sum(v == 'X' for v in b.values()); no = sum(v == 'O' for v in b.values())
    ok = nx - no in (0, 1) and (full == [res] if res in 'XO' else res == 'draw' and not full and nx + no == 9)
    return dict(seed=seed, result=res, decisions=dec, marks=nx + no, valid=ok)
if __name__ == '__main__':
    path, n, gen = sys.argv[1], int(sys.argv[2]), sys.argv[3] == 'gen'
    for s in range(int(sys.argv[4]) if len(sys.argv) > 4 else 1, n + 1): print(json.dumps(play(path, s, gen)), flush=True)
