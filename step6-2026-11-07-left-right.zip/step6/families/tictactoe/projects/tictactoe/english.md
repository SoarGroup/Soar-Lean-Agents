# TicTacToe

## The task

The task state holds several values of `cell`, each a cell. The nine cells of the board.
The task state holds several values of `line`, each a line. The eight lines: three rows, three columns, two diagonals.
The task state holds several values of `game`, each a game. The game.

A cell has `name` (one of ), `xy` (an integer), `x` (an integer), `y` (an integer), `content` (an integer).

A line has `name` (one of ), `cell` (a cell).

A game has `name` (one of ), `turn` (an integer), `winner` (an integer), `over` (an integer).

Initially the task state has:
- a `cell` named c11 with xy 11 and x 1 and y 1 and content 0
- a `cell` named c21 with xy 21 and x 2 and y 1 and content 0
- a `cell` named c31 with xy 31 and x 3 and y 1 and content 0
- a `cell` named c12 with xy 12 and x 1 and y 2 and content 0
- a `cell` named c22 with xy 22 and x 2 and y 2 and content 0
- a `cell` named c32 with xy 32 and x 3 and y 2 and content 0
- a `cell` named c13 with xy 13 and x 1 and y 3 and content 0
- a `cell` named c23 with xy 23 and x 2 and y 3 and content 0
- a `cell` named c33 with xy 33 and x 3 and y 3 and content 0
- a `line` named row1 with ; its `cell` is c11; its `cell` is c21; its `cell` is c31
- a `line` named row2 with ; its `cell` is c12; its `cell` is c22; its `cell` is c32
- a `line` named row3 with ; its `cell` is c13; its `cell` is c23; its `cell` is c33
- a `line` named column1 with ; its `cell` is c11; its `cell` is c12; its `cell` is c13
- a `line` named column2 with ; its `cell` is c21; its `cell` is c22; its `cell` is c23
- a `line` named column3 with ; its `cell` is c31; its `cell` is c32; its `cell` is c33
- a `line` named diagonal1 with ; its `cell` is c11; its `cell` is c22; its `cell` is c33
- a `line` named diagonal2 with ; its `cell` is c31; its `cell` is c22; its `cell` is c13
- a `game` named game with turn 1 and winner 0 and over 0
Links between objects never change.

**Constraint (part of the task).** Every cell always has self.content ≥ 0 and self.content ≤ 2 (with `self` the cell); every operator must preserve this.

**Goal.** Some game has over 1. When the goal holds in the task state, the agent reports success and halts.

## Operators

An operator's changes are made together: every value on the right is read before any change.

**mark(cell: cell, game: game).** Proposed when cell.content = 0 and game.over = 0. Put the mark of the side to move in an empty cell.
- Effect: cell.content := game.turn; game.turn := 3 − game.turn.

**x-wins(line: line, game: game).** Proposed when game.over = 0 and at least 3 cells that line.cell points to have content = 1. X has three in a row: the game is over and X has won.
- Effect: game.over := 1; game.winner := 1; writes "Side X won.".

**o-wins(line: line, game: game).** Proposed when game.over = 0 and at least 3 cells that line.cell points to have content = 2. O has three in a row: the game is over and O has won.
- Effect: game.over := 1; game.winner := 2; writes "Side O won.".

**detect-draw(game: game).** Proposed when game.over = 0 and no cell has content = 0. The board is full: the game is a draw.
- Effect: game.over := 1; writes "Draw.".

## Choosing among proposed operators

Any proposed operator may be chosen; the choice is random.

The agent remembers the last task operator applied (its name and parameters). Search-control preferences:
- **x-wins-best**: a proposed x-wins whose  is best. a win ends the game before another mark
- **o-wins-best**: a proposed o-wins whose  is best. a win ends the game before another mark

## Learning

None.

## Assumptions (added; not in the task description)

- **A1** [open] The task: two sides, X first, alternately mark an empty cell of a 3 × 3 board, both at random (V1 has no search control); the game ends when a side has three in a row (it won) or the board is full (a draw), and the agent halts after writing the result.
- **A2** [open] The board's lines (three rows, three columns, two diagonals) are task objects linked to their three cells, and a win is a line whose three cells all hold the same side's mark. V1 instead has four elaborations over cell coordinates (rows, columns and both diagonals), each matching any three cells with the right coordinates.
- **A3** [open] Detecting the end is done by operators (`x-wins`, `o-wins`, `detect-draw`) that set the game's `over` (and `winner`), and the goal is `over` = 1. V1 detects three in a row with elaborations that set `^success` and halt as soon as they fire, and a draw with an operator. A win operator is best, so it is chosen before any further mark; with `over` = 1 no mark is proposed.
- **A4** [open] The sides are 1 (X) and 2 (O) and an empty cell holds 0, instead of V1's symbols X, O and | |; the side to move is the game's `turn` (the other is 3 − turn) instead of V1's `^current-side`/`^other-side` pair, which the mark's apply swaps. The monitor prints X, O and blank.
- **A5** [open] V1's monitor prints the board after every change (it is an elaboration over all nine contents). It is kept, by hand, as a Raw rule; it uses `^shown` elaborations for the symbols.
- **A6** [open] V1's three-in-a-row elaborations write which row, column or diagonal; here the win operator writes only the side (`Side X won.`). The line is the operator's parameter, so the trace shows it.

## Outside the conventions (unverified)

- `elaborations/monitor`: Monitor (trace output only), as TicTacToe V1's tictactoe*monitor*state: prints the board after every change, with X, O and blank for the cells' contents (`^shown`, an attribute used only by the monitor). Written by hand (JL, 6 Nov 2026: monitors are allowed as Raw).
