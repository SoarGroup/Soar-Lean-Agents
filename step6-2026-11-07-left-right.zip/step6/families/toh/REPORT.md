# Towers of Hanoi — skipped (JL, 6 Nov 2026: "it will just take a long time")

Originals run as they are (`results/orig`, 3 seeds, cap 30000 decisions):

- ChunkingDemoTests_Demo_ToH_Recursive-V1: no result (out of memory or over the 20-minute limit)
- ChunkingDemoTests_Demo_ToH_Recursive_expected-V1: 0/3 solved; 0 disks, 100 decisions, 0 top-level moves
- FunctionalTests_testTowersOfHanoi-V1: 3/3 solved; 11 disks, 2048 decisions, 2047 top-level moves
- FunctionalTests_testTowersOfHanoiFast-V1: 3/3 solved; 11 disks, 2047 decisions, 2047 top-level moves
- interpret-game-state-tower-change-V1: 0/3 solved; 0 disks, 100 decisions, 0 top-level moves
- tower-of-hanoi-search-V1: no result (out of memory or over the 20-minute limit)
- towers-of-hanoi-V1: 3/3 solved; 11 disks, 2048 decisions, 2047 top-level moves
- towers-of-hanoi-V2: 3/3 solved; 11 disks, 2048 decisions, 2047 top-level moves
- towers-of-hanoi-fast-V1: 3/3 solved; 11 disks, 2047 decisions, 2047 top-level moves
- towers-of-hanoi-fast-V2: 3/3 solved; 11 disks, 2047 decisions, 2047 top-level moves
- towers-of-hanoi-faster-V1: 3/3 solved; 11 disks, 2047 decisions, 2047 top-level moves
- towers-of-hanoi-faster-V2: 3/3 solved; 11 disks, 2047 decisions, 2047 top-level moves
- towers-of-hanoi-no-ops-V1: 3/3 solved; 11 disks, 1 decisions, 1 top-level moves
- towers-of-hanoi-recur-V1: 3/3 solved; 7 disks, 190 decisions, 7 top-level moves
- towers-of-hanoi-recursive-V1: 3/3 solved; 11 disks, 3071 decisions, 11 top-level moves
- towers-of-hanoi-recursive-V2: 3/3 solved; 11 disks, 3071 decisions, 11 top-level moves

Not ToH agents: interpret-game-state-tower-change (dialog agent), ChunkingDemoTests_Demo_ToH_Recursive_expected (a file of chunks).

DSL features added while starting this family (kept, general): `Guard.noneSuch` (negated conjunction over task objects), `Goal.all` (every object of a type has the values), `Pref.guard` / `Pref.lastGuard` (preferences on the candidate and on the last operator's objects), and `Agent.runPrefs` (follow the preferences deterministically, as Soar's decision procedure would). No ToH variant was written.
