/-!
# Agent DSL v0 — a constrained description of Soar task agents

An agent is described here, not as productions. `Agent/Compile.lean` turns a description into
productions of the Soar specification (`Soar.Production`, Soar/Syntax.lean), and from there into
Soar source. The conventions of the English → Lean → Soar plan (5 November 2026) are built into
the types and into `Agent.check`:

* **Declared state schema.** Every object type and attribute is declared (`Schema`); which
  attributes are multi-valued, which are derived. Nothing else can be written or tested.
* **One operator template.** `Operator`: name, typed parameters, proposal guards, apply cases
  (guard + effects). Only operator application makes persistent changes.
* **Stratified elaborations.** Derived attributes (`Derive`) are computed only from
  non-derived attributes of the same object, so elaboration has a unique fixed point.
* **Restricted preferences.** No preference is written by hand: they come from the selection
  method (`Method`).
* **Sanctioned impasses only.** Operator no-change (`Impl.steps`: an operator carried out in a
  substate) and tie (`Method.tieHeuristic`, `Method.lookahead`). Any other impasse is a bug.
* **Explicit goals.** `Goal` becomes a standard `^desired` structure plus a success rule.
* **Fixed I/O protocol.** Not used by this family (no input or output link); reserved.
* **Escape hatch.** `Agent.raw`: productions written directly, outside the guarantees.

Extensions of 6 November 2026, all optional, so a description that does not use them compiles
exactly as before:

* **Value parameters** (`Operator.vparams`): an operator parameter that is a small integer from a
  declared range, not an object. Each combination of values that satisfies the operator's static
  guards (`Guard.vcmp`, over value parameters only) gets its own proposal rule, with the values
  as constants on the operator; apply rules read them from the operator as variables.
* **Named objects and static relations** (`Agent.objs`): initial objects with a symbolic `^name`
  and links to other named objects (object-valued attributes, never changed by an operator);
  `Guard.link` tests a link. A goal may name its object (`Goal.name`).
* **Failure states** (`Agent.failure`): a state is a failure state when some object satisfies a
  guard; it then has `^failure <desired>` (an elaboration). Look-ahead evaluates such a state as a
  failure (the selection library rejects the operator), RL can reward it (`Method.rl`), and
  preference rules can test it.
* **Search-control preference rules** (`Agent.prefs`): hand-written preferences over the proposed
  operators that compare a candidate with the last task operator applied (kept as `^last-move`, a
  record of its name and parameters), optionally only in (or out of) failure states.
* **Look-ahead options**: duplicates of an ancestor as `failure` instead of partial failure, and a
  numeric state evaluation (`Score`).

General conventions added with them (6 November 2026; one-line rationale each):

* **One failure mark.** Failure states are declared (`Agent.failure`) and marked by one
  elaboration, `^failure <desired>` on any task state; every method uses that mark (look-ahead:
  failure evaluation; RL: reward; preferences: tests). Rationale: one definition of failure, so the
  methods cannot disagree about it. `check`: preferences or rewards that use failure states need
  declared failure states.
* **Failure halts (ELB-014, JL 6 Nov 2026).** A failure state violates a task constraint, but the
  constraint is not built into the proposals (too much knowledge for the agent): moves into it are
  proposed, and entering one at the top state is a task failure and halts (generated with the
  failure mark). Look-ahead: failure evaluation; RL: terminal reward. No recovery (undo) rules.
* **Static links.** Object-valued attributes of objects are set at initialization and never
  changed by an operator (`check`: effects write integer attributes only); duplicate-state tests
  and RL templates leave them out. Rationale: identifiers differ between copies of a state, so
  comparing them makes every copy different.
* **Value parameters as constants in proposals.** One proposal rule per combination of values that
  passes the static guards, with the values as constants on the operator; apply rules read them
  from the operator. Rationale: proposals stay in precondition style and every instance is
  distinguishable for preferences, chunking and RL.
* **Last move as a record.** Preferences about the previous operator compare with `^last-move`, a
  record of its name and parameters, changed by the single-valued-attribute convention (one rule
  replaces, one adds the first). Rationale: search control about "undo" needs the parameters, not
  only the name.
* **RL templates are marked.** A rule meant as an RL template is written with `:template`.
  Rationale: without it Soar loads one ordinary RL rule whose single value is shared by every
  match. (Printed by the `agentgen` executable; `Soar.Production.toSoar` omits the flag.)

Extensions of 6 November 2026 for the small families (Hello world, Counting, Pyramid, Graph
search), all optional and additive:

* **Messages** (`Case.write`, `Goal.report`): text and expression values written to the trace
  (Soar `write`) when an operator case is applied, or at the goal before halting (expressions over
  the goal object as `self`, e.g. a computed answer). `check`: references are parameters' integer
  attributes (the goal object's for a report).
* **Multiplication and integer division** (`Expr.mul`, `Expr.div`; Soar `*`, `div`, rounded
  towards zero), e.g. to state the effect of an operator carried out by sub-operators in closed
  form.
* **Typed parameters in the task semantics** (`Sem`): each parameter ranges over objects of its
  type only (before, over all objects; the same for one-type tasks).

General conventions added with them (6 November 2026):

* **Output only from operators.** Messages are written by operator application (`Case.write`) or
  by the halt at the goal (`Goal.report`), never by elaborations. Rationale: elaborations fire
  again whenever their match changes and retract, so an elaboration's output can repeat or come
  at any time (hello-world-rule wrote and halted from one).
* **Hierarchical operators keep their identity.** An operator carried out by sub-operators
  (`Impl.sub`) is proposed through a relevance elaboration (`^<op>-relevant <p>`), as operators
  with alternative proposals already were, never by a proposal rule that tests values its
  sub-operators change. Rationale: such a proposal rule retracts and fires again after every
  result, making a new operator and ending (and re-creating) the substate after every step.
  (Generated for `Impl.sub` operators with one object parameter and no value parameters.)

Common-sense knowledge an LLM adds beyond a task description is kept as named
`Assumption`s, separate from what the description states.
-/
namespace Agent

/-! ## Schema -/

/-- The type of an attribute's values. -/
inductive VType where
  | int
  | sym (choices : List String)
  | obj (ty : String)
  deriving DecidableEq, Repr

/-- One declared attribute. `derived` attributes are i-supported and computed by a `Derive`. -/
structure AttrDecl where
  name : String
  ty : VType
  multi : Bool := false
  derived : Bool := false
  doc : String := ""
  deriving DecidableEq, Repr

/-- An object type. `key` names an attribute that identifies an object of this type among its
siblings (used to compare whole states, e.g. for duplicate detection in look-ahead). -/
structure ObjType where
  name : String
  attrs : List AttrDecl
  key : Option String := none
  doc : String := ""
  deriving DecidableEq, Repr

structure Schema where
  /-- The task name, which is also the value of the top state's `^name`. -/
  task : String
  /-- Attributes of the task state. Objects of a type are reached through a multi-valued state
  attribute of that type. -/
  stateAttrs : List AttrDecl
  types : List ObjType
  deriving DecidableEq, Repr

/-! ## Expressions, guards, effects -/

/-- Integer expressions over attributes of named objects (operator parameters, or `self` in a
derivation). -/
inductive Expr where
  | lit (n : Int)
  | get (obj attr : String)
  | add (a b : Expr)
  | sub (a b : Expr)
  /-- the value of a value parameter of the operator -/
  | val (p : String)
  /-- product (Soar `*`) -/
  | mul (a b : Expr)
  /-- integer quotient, rounded towards zero (Soar `div`) -/
  | div (a b : Expr)
  deriving DecidableEq, Repr

/-- A part of a message written to the trace (Soar `write`): text, or the value of an expression. -/
inductive Msg where
  | text (s : String)
  | val (e : Expr)
  deriving DecidableEq, Repr

inductive Cmp where
  | eq | ne | lt | le | gt | ge
  deriving DecidableEq, Repr

/-- The right side of a comparison: Soar conditions can compare with a constant or with another
bound value, not with computed values. -/
inductive Atom where
  | lit (n : Int)
  | get (obj attr : String)
  /-- the value of a value parameter -/
  | val (p : String)
  deriving DecidableEq, Repr

inductive Guard where
  /-- `obj.attr op atom` -/
  | cmp (obj attr : String) (op : Cmp) (rhs : Atom)
  /-- two parameters denote different objects -/
  | distinct (a b : String)
  /-- the task state's single-valued object attribute `attr` is the object `p` -/
  | holds (attr p : String)
  /-- the task state's attribute `attr` has no value -/
  | unset (attr : String)
  /-- parameter `a`'s object-valued (static) attribute `attr` is the object `b` -/
  | link (a attr b : String)
  /-- an expression over value parameters only, compared with a constant: decided per combination
  of values when the agent is compiled (no Soar condition) -/
  | vcmp (e : Expr) (op : Cmp) (n : Int)
  deriving DecidableEq, Repr

/-- `obj.attr := e` (a persistent change, made only when an operator is applied). All effects of
a case are simultaneous: every value on the right is read in the state before any change (Soar
binds right-hand-side values from the match). -/
structure Effect where
  obj : String
  attr : String
  val : Expr
  deriving DecidableEq, Repr

/-- One case of an operator's application: when the guard holds, make these changes. -/
structure Case where
  guard : List Guard := []
  effects : List Effect
  /-- changes to single-valued object attributes of the task state: `(attr, some p)` sets it to
  parameter `p`, `(attr, none)` removes its value -/
  stateEffects : List (String × Option String) := []
  /-- a message written to the trace when the case is applied (Soar `write`; not a change of the
  state) -/
  write : List Msg := []
  deriving DecidableEq, Repr

/-! ## Operators -/

/-- A sub-operator of an operator carried out in its operator no-change substate. It has the
parent's parameters; its guards and effects refer to them and to the task state (the superstate),
so its changes are results. -/
structure SubOp where
  name : String
  propose : List Guard
  apply : List Case
  doc : String := ""
  deriving DecidableEq, Repr

/-- How an operator is carried out. `atomic`: by apply rules in the state where it is selected.
`steps`: in an operator no-change substate, by a fixed sequence of sub-operators; the last step
makes the operator's changes (as results). -/
inductive Impl where
  | atomic
  /-- bookkeeping steps only (markers local to the substate); the last makes the changes -/
  | steps (names : List String)
  /-- real sub-operators that change the task state; together they must produce the operator's
  `apply` effect (checked by `Agent.refinesSub`) -/
  | sub (ops : List SubOp)
  deriving DecidableEq, Repr

structure Operator where
  name : String
  /-- (parameter, object type) -/
  params : List (String × String)
  /-- value parameters: (parameter, the values it ranges over). On the operator in working
  memory as `^parameter value`. -/
  vparams : List (String × List Int) := []
  propose : List Guard
  /-- further, alternative proposal conditions (each a separate proposal rule); they should be
  disjoint from `propose` and from each other -/
  proposeAlt : List (List Guard) := []
  apply : List Case
  impl : Impl := .atomic
  doc : String := ""
  deriving DecidableEq, Repr

/-- A derived attribute: `T.attr := e`, with `e` over `self`. -/
structure Derive where
  ty : String
  attr : String
  val : Expr
  deriving DecidableEq, Repr

/-- An object pattern: attribute values that one object must have. -/
abbrev ObjPat := List (String × Int)

/-- A goal: some object of type `ty` has these attribute values. It becomes a `^desired` structure;
any state of the task with a matching object gets `^success`; at the top state that halts the
agent (a look-ahead copy reaching it only counts as a successful evaluation). -/
structure Goal where
  ty : String
  vals : ObjPat
  /-- the goal object must be this named object (`Agent.objs`) -/
  name : Option String := none
  /-- a message written when the goal holds at the top state, before halting; expressions refer to
  the goal object as `self` (e.g. the answer of a computation) -/
  report : List Msg := []
  deriving DecidableEq, Repr

/-- A whole-state pattern: for each listed object pattern, some object of type `ty` matches it. -/
structure StatePat where
  ty : String
  objs : List ObjPat
  deriving DecidableEq, Repr

/-! ## Selection methods -/

inductive HVal where
  | best | worst | equal
  deriving DecidableEq, Repr

/-- A heuristic: when the last operator applied was one of `last` (`none` before the first),
candidates named in `cands` get `value`. -/
structure Heur where
  last : List String
  cands : List String
  value : HVal
  deriving DecidableEq, Repr

/-- How a duplicate of an ancestor is evaluated in look-ahead. -/
inductive FailKind where
  /-- `partial-failure`: the selection library makes the operator worst -/
  | partialFailure
  /-- `failure`: the selection library rejects the operator -/
  | failure
  deriving DecidableEq, Repr

/-- A numeric evaluation of look-ahead states: `val` (over `self`) for the object of type `ty`
(the named object `name`, if given); `higher` says whether higher values are better. -/
structure Score where
  ty : String
  name : Option String := none
  val : Expr
  higher : Bool := true
  deriving DecidableEq, Repr

/-- How operators are chosen among the proposed ones. -/
inductive Method where
  /-- uniformly at random (all proposals indifferent) -/
  | random
  /-- tie impasse, resolved in a tie substate by evaluating each tied operator with heuristics:
  `best` becomes best + indifferent preferences, `worst` worst + indifferent, `equal`
  indifferent; Soar then chooses at random among the remaining equals. `check` requires exactly
  one heuristic for each (last operator or `none`, candidate). -/
  | tieHeuristic (hs : List Heur)
  /-- tie impasse, resolved by look-ahead search with Soar's default selection library; states
  equal to an ancestor state are partial failures; states matching `avoid` are partial failures,
  or, with `avoidValue`, get that numeric evaluation -/
  | lookahead (avoid : List StatePat) (avoidValue : Option Int := none)
      (dup : FailKind := .partialFailure) (score : Option Score := none)
  /-- reinforcement learning over operator and parameter-object attributes (RL templates with
  initial value 0), with rewards for states matching patterns, given whenever such a state holds
  (Soar's reward link). Algorithm and exploration are set by `Learning.rl`. A look-ahead variant
  with RL learning (`Learning.chunkRl`) needs no rewards: chunking over numeric evaluations makes
  the RL rules. -/
  | rl (rewards : List (StatePat × Int)) (failureReward : Option Int := none)
      (goalReward : Option Int := none)
      -- stepCost: a reward on every decision, in thousandths (−10 = −0.01 per move)
      (stepCost : Option Int := none)
  deriving DecidableEq, Repr

/-- Learning. -/
inductive Learning where
  | none
  /-- `chunk always`; `singletons` are attributes declared singletons for chunking -/
  | chunk (singletons : List String)
  /-- `rl` on with these parameters (learning rate and discount ×1000) and epsilon-greedy
  exploration -/
  | rl (rate discount : Nat)  -- Soar's default RL algorithm (SARSA); epsilon-greedy, epsilon 0.1
  /-- both -/
  | chunkRl (singletons : List String) (rate discount : Nat)
  deriving DecidableEq, Repr

/-- A task constraint: every object of type `ty` satisfies `guard` (over `self`) in every reachable
state. Part of the task, not a consequence of particular operators: every variant, and any operator
added later, must preserve it. -/
structure Constraint where
  ty : String
  guard : List Guard
  doc : String := ""
  deriving DecidableEq, Repr

/-- An initial object with an identity: `^name name`, attribute values, and links (object-valued
attributes) to other named objects, by name. Links never change. -/
structure Named where
  holder : String
  name : String
  vals : ObjPat
  links : List (String × String) := []
  deriving DecidableEq, Repr

/-- A failure state: some object of type `ty` satisfies `guard` (over `self`). -/
structure Failure where
  ty : String
  guard : List Guard
  doc : String := ""
  deriving DecidableEq, Repr

/-- A search-control preference rule: when the task operator last applied was `op`, a proposed
`op` whose fields equal the last one's as listed (`(candidate field, last field)`, fields being
parameters and value parameters) gets `value` (`best`: `>`, `worst`: `<`, `equal`: `=`).
`failure`: only in failure states (`some true`), only outside them (`some false`), or always. -/
structure Pref where
  name : String
  op : String
  sameAsLast : List (String × String)
  failure : Option Bool := none
  value : HVal
  doc : String := ""
  deriving DecidableEq, Repr

/-- Common-sense knowledge added to a description, kept separate and reviewable. -/
structure Assumption where
  id : String
  text : String
  /-- `accepted`, `rejected`, `revised`, or `open` -/
  status : String := "open"
  deriving DecidableEq, Repr

/-- A raw production (escape hatch): outside the conventions and their checks. -/
structure Raw where
  file : String
  text : String
  why : String
  deriving DecidableEq, Repr

/-- An agent. -/
structure Agent where
  schema : Schema
  /-- initial objects: (state attribute, attribute values) -/
  init : List (String × ObjPat)
  /-- initial objects with names and links (after those of `init`) -/
  objs : List Named := []
  derive : List Derive
  ops : List Operator
  goal : Goal
  constraints : List Constraint := []
  failure : List Failure := []
  prefs : List Pref := []
  method : Method
  learning : Learning := .none
  assumptions : List Assumption := []
  raw : List Raw := []
  deriving Repr, DecidableEq

/-! ## The conventions as checks

`check a` lists every violation; a well-formed agent has none. Families state
`theorem … : check a = [] := by decide` for each variant, so a variant that breaks a convention
does not compile. -/

def Schema.type? (s : Schema) (t : String) : Option ObjType := s.types.find? (·.name == t)

def Schema.attr? (s : Schema) (t a : String) : Option AttrDecl :=
  (s.type? t).bind fun ty => ty.attrs.find? (·.name == a)

/-- The state attribute through which objects of type `t` are reached. -/
def Schema.holder? (s : Schema) (t : String) : Option AttrDecl :=
  s.stateAttrs.find? fun d => d.ty == .obj t && d.multi

def Expr.refs : Expr → List (String × String)
  | .lit _ => []
  | .get o a => [(o, a)]
  | .add a b => a.refs ++ b.refs
  | .sub a b => a.refs ++ b.refs
  | .val _ => []
  | .mul a b => a.refs ++ b.refs
  | .div a b => a.refs ++ b.refs

def Msg.refs : Msg → List (String × String)
  | .text _ => []
  | .val e => e.refs


def Atom.refs : Atom → List (String × String)
  | .lit _ => []
  | .get o a => [(o, a)]
  | .val _ => []

def Guard.refs : Guard → List (String × String)
  | .cmp o a _ r => (o, a) :: r.refs
  | .distinct _ _ => []
  | .holds _ _ => []
  | .unset _ => []
  | .link _ _ _ => []
  | .vcmp _ _ _ => []

/-- Value parameters an expression refers to. -/
def Expr.vrefs : Expr → List String
  | .val p => [p]
  | .add a b => a.vrefs ++ b.vrefs
  | .sub a b => a.vrefs ++ b.vrefs
  | .mul a b => a.vrefs ++ b.vrefs
  | .div a b => a.vrefs ++ b.vrefs
  | _ => []

def Msg.vrefs : Msg → List String
  | .text _ => []
  | .val e => e.vrefs

def Atom.vrefs : Atom → List String
  | .val p => [p]
  | _ => []

def Guard.vrefs : Guard → List String
  | .cmp _ _ _ r => r.vrefs
  | .vcmp e _ _ => e.vrefs
  | _ => []

/-- A guard decided at compile time (over value parameters only). -/
def Guard.isStatic : Guard → Bool
  | .vcmp .. => true
  | _ => false

/-- Every combination of values of the value parameters, in order. -/
def combos : List (String × List Int) → List (List (String × Int))
  | [] => [[]]
  | (p, vs) :: rest => vs.flatMap fun v => (combos rest).map ((p, v) :: ·)

def Expr.evalV (vals : List (String × Int)) : Expr → Int
  | .lit n => n
  | .val p => (vals.lookup p).getD 0
  | .add a b => a.evalV vals + b.evalV vals
  | .sub a b => a.evalV vals - b.evalV vals
  | .mul a b => a.evalV vals * b.evalV vals
  | .div a b => Int.tdiv (a.evalV vals) (b.evalV vals)
  | .get _ _ => 0

def Cmp.test : Cmp → Int → Int → Bool
  | .eq, a, b => a == b | .ne, a, b => a != b | .lt, a, b => a < b
  | .le, a, b => a ≤ b | .gt, a, b => a > b | .ge, a, b => a ≥ b

/-- The combinations of value-parameter values that pass the static guards. -/
def Operator.combos (o : Operator) : List (List (String × Int)) :=
  (Agent.combos o.vparams).filter fun vals =>
    (o.propose.filter Guard.isStatic).all fun g => match g with
      | .vcmp e op n => op.test (e.evalV vals) n
      | _ => true

/-- `(obj, attr)` must name a parameter of `params` and an int attribute of its type. -/
def checkRef (s : Schema) (params : List (String × String)) (ctx : String) (r : String × String) :
    List String :=
  match params.find? (·.1 == r.1) with
  | none => [s!"{ctx}: {r.1} is not a parameter"]
  | some (_, t) =>
    match s.attr? t r.2 with
    | none => [s!"{ctx}: {t} has no attribute {r.2}"]
    | some d => if d.ty == .int then [] else [s!"{ctx}: {t}.{r.2} is not an integer"]

def checkGuardV (s : Schema) (ps : List (String × String)) (vps : List String) (ctx : String) (g : Guard) :
    List String :=
  (g.vrefs.filterMap fun v => if vps.contains v then none else some s!"{ctx}: {v} is not a value parameter") ++
  match g with
  | .link a attr b =>
    match ps.lookup a, ps.lookup b with
    | some ta, some tb =>
      match s.attr? ta attr with
      | some { ty := .obj t, .. } => if t == tb then [] else [s!"{ctx}: {ta}.{attr} links to a {t}, {b} is a {tb}"]
      | some _ => [s!"{ctx}: {ta}.{attr} is not an object-valued attribute"]
      | none => [s!"{ctx}: {ta} has no attribute {attr}"]
    | _, _ => [s!"{ctx}: link between non-parameters {a}, {b}"]
  | .vcmp e _ _ => if e.refs.isEmpty then [] else [s!"{ctx}: a static guard refers to objects"]
  | g => checkGuard0 s ps ctx g
where
  checkGuard0 (s : Schema) (ps : List (String × String)) (ctx : String) (g : Guard) : List String :=
  match g with
  | .distinct a b =>
    (if ps.any (·.1 == a) then [] else [s!"{ctx}: {a} is not a parameter"]) ++
    (if ps.any (·.1 == b) then [] else [s!"{ctx}: {b} is not a parameter"])
  | .holds attr p =>
    match s.stateAttrs.find? (·.name == attr), ps.lookup p with
    | some { ty := .obj t, multi := false, .. }, some t' =>
      if t == t' then [] else [s!"{ctx}: {attr} holds a {t}, {p} is a {t'}"]
    | some _, some _ => [s!"{ctx}: {attr} is not a single-valued object attribute of the state"]
    | none, _ => [s!"{ctx}: no state attribute {attr}"]
    | _, none => [s!"{ctx}: {p} is not a parameter"]
  | .unset attr => if s.stateAttrs.any (·.name == attr) then [] else [s!"{ctx}: no state attribute {attr}"]
  | g => g.refs.flatMap (checkRef s ps ctx)

def checkGuard (s : Schema) (ps : List (String × String)) (ctx : String) (g : Guard) : List String :=
  checkGuardV s ps [] ctx g

def checkStateEffects (s : Schema) (ps : List (String × String)) (ctx : String) (c : Case) : List String :=
  c.stateEffects.flatMap fun (attr, v) =>
    checkGuard s ps ctx (match v with | some p => .holds attr p | none => .unset attr)

def checkOp (s : Schema) (o : Operator) : List String :=
  let ctx := s!"operator {o.name}"
  let paramErrs := o.params.flatMap fun (p, t) =>
    match s.type? t, s.holder? t with
    | none, _ => [s!"{ctx}: parameter {p}: no type {t}"]
    | _, none => [s!"{ctx}: parameter {p}: no multi-valued state attribute holds {t}"]
    | _, _ => []
  let vps := o.vparams.map (·.1)
  let vparamErrs :=
    (if (o.params.map (·.1) ++ vps).eraseDups.length != o.params.length + vps.length
     then [s!"{ctx}: repeated parameter name"] else []) ++
    (o.vparams.filterMap fun (p, vs) => if vs.isEmpty then some s!"{ctx}: value parameter {p} has no values" else none) ++
    (if !vps.isEmpty && o.combos.isEmpty then [s!"{ctx}: no combination of values passes the static guards"] else []) ++
    (if !vps.isEmpty && (o.impl != .atomic || !o.proposeAlt.isEmpty) then
      [s!"{ctx}: value parameters need an atomic operator with one proposal"] else []) ++
    ((o.proposeAlt.flatten ++ o.apply.flatMap (·.guard)).filterMap fun g =>
      if g.isStatic then some s!"{ctx}: static guards belong in propose" else none)
  let guardErrs := (o.propose ++ o.proposeAlt.flatten ++ o.apply.flatMap (·.guard)).flatMap (checkGuardV s o.params vps ctx) ++
    o.apply.flatMap (checkStateEffects s o.params ctx)
  let writeErrs := o.apply.flatMap (·.write) |>.flatMap fun m =>
    m.refs.flatMap (checkRef s o.params ctx) ++
    (Msg.vrefs m).filterMap fun v => if vps.contains v then none else some s!"{ctx}: {v} is not a value parameter"
  let effErrs := o.apply.flatMap (·.effects) |>.flatMap fun e =>
    checkRef s o.params ctx (e.obj, e.attr) ++ e.val.refs.flatMap (checkRef s o.params ctx) ++
    (e.val.vrefs.filterMap fun v => if vps.contains v then none else some s!"{ctx}: {v} is not a value parameter") ++
    match (o.params.find? (·.1 == e.obj)).bind (fun (_, t) => s.attr? t e.attr) with
    | some d => if d.derived then [s!"{ctx}: effect writes derived attribute {e.attr}"] else []
    | none => []
  let reserved := ["evaluate-operator", "create-preferences", "initialize-" ++ s.task]
  let nameErr := if reserved.contains o.name then [s!"{ctx}: reserved name"] else []
  let implErr := match o.impl with
    | .atomic => []
    | .steps ns => if ns.isEmpty then [s!"{ctx}: no steps"] else
        if ns.eraseDups.length != ns.length then [s!"{ctx}: repeated step"] else []
    | .sub so =>
      (if so.isEmpty then [s!"{ctx}: no sub-operators"] else []) ++
      (if (so.map (·.name)).eraseDups.length != so.length then [s!"{ctx}: repeated sub-operator"] else []) ++
      so.flatMap fun x =>
        let c := s!"{ctx}/{x.name}"
        (x.propose ++ x.apply.flatMap (·.guard)).flatMap (checkGuard s o.params c) ++
        x.apply.flatMap (checkStateEffects s o.params c) ++
        (x.apply.flatMap (·.effects)).flatMap (fun e => checkRef s o.params c (e.obj, e.attr) ++ e.val.refs.flatMap (checkRef s o.params c)) ++
        (x.apply.flatMap (·.write)).flatMap (fun m => m.refs.flatMap (checkRef s o.params c)) ++
        (if x.apply.isEmpty then [s!"{c}: no apply case"] else [])
  let caseErr := if o.apply.isEmpty then [s!"{ctx}: no apply case"] else []
  let altErr := if !o.proposeAlt.isEmpty && o.params.length != 1 then [s!"{ctx}: alternative proposals need exactly one parameter (v0)"] else []
  paramErrs ++ vparamErrs ++ guardErrs ++ writeErrs ++ effErrs ++ nameErr ++ implErr ++ caseErr ++ altErr

def checkDerive (s : Schema) (d : Derive) : List String :=
  let ctx := s!"derive {d.ty}.{d.attr}"
  (match s.attr? d.ty d.attr with
   | none => [s!"{ctx}: undeclared"]
   | some a => if a.derived then [] else [s!"{ctx}: attribute is not declared derived"]) ++
  -- stratified: only non-derived attributes of the same object
  d.val.refs.flatMap fun (o, a) =>
    if o != "self" then [s!"{ctx}: refers to {o}"] else
    match s.attr? d.ty a with
    | none => [s!"{ctx}: {d.ty} has no attribute {a}"]
    | some x => if x.derived then [s!"{ctx}: depends on derived {a} (not stratified)"] else []

def checkObjPat (s : Schema) (t ctx : String) (p : ObjPat) : List String :=
  p.flatMap fun (a, _) =>
    match s.attr? t a with
    | none => [s!"{ctx}: {t} has no attribute {a}"]
    | some d => if d.ty == .int then [] else [s!"{ctx}: {t}.{a} is not an integer"]

def checkStatePat (s : Schema) (ctx : String) (p : StatePat) : List String :=
  (if (s.holder? p.ty).isSome then [] else [s!"{ctx}: no state attribute holds {p.ty}"]) ++
  p.objs.flatMap (checkObjPat s p.ty ctx)

/-- Named objects: holder, values, a declared symbolic `name`, unique names, links to named objects
of the declared type. -/
def checkObjs (a : Agent) : List String :=
  let s := a.schema
  let names := a.objs.map (·.name)
  (if names.eraseDups.length != names.length then ["objects: repeated name"] else []) ++
  a.objs.flatMap fun o =>
    let ctx := s!"object {o.name}"
    match s.stateAttrs.find? (·.name == o.holder) with
    | some { ty := .obj t, multi := true, .. } =>
      checkObjPat s t ctx o.vals ++
      (match s.attr? t "name" with
       | some { ty := .sym _, derived := false, .. } => []
       | _ => [s!"{ctx}: {t} declares no symbolic attribute name"]) ++
      (((s.type? t).map (fun ty => ty.attrs.filter (fun d => !d.derived && d.name != "name" &&
          !o.vals.any (·.1 == d.name) && !o.links.any (·.1 == d.name))
        |>.map fun d => s!"{ctx}: missing {d.name}")).getD []) ++
      o.links.flatMap fun (attr, target) =>
        match s.attr? t attr, a.objs.find? (·.name == target) with
        | some { ty := .obj t', .. }, some x =>
          match s.stateAttrs.find? (·.name == x.holder) with
          | some { ty := .obj tx, .. } => if tx == t' then [] else [s!"{ctx}: {attr} links to a {t'}, {target} is a {tx}"]
          | _ => [s!"{ctx}: {target} has no holder"]
        | some _, some _ => [s!"{ctx}: {attr} is not object-valued"]
        | none, _ => [s!"{ctx}: {t} has no attribute {attr}"]
        | _, none => [s!"{ctx}: no object {target}"]
    | _ => [s!"{ctx}: {o.holder} is not a multi-valued object attribute of the state"]

/-- The object type of a named object. -/
def Agent.namedType? (a : Agent) (n : String) : Option String :=
  (a.objs.find? (·.name == n)).bind fun o =>
    match (a.schema.stateAttrs.find? (·.name == o.holder)).map (·.ty) with
    | some (VType.obj t) => some t
    | _ => none

def checkExtras (a : Agent) : List String :=
  let s := a.schema
  let goalName := match a.goal.name with
    | none => []
    | some n => if a.namedType? n == some a.goal.ty then [] else [s!"goal: no {a.goal.ty} named {n}"]
  let failErrs := a.failure.flatMap fun f =>
    if (s.holder? f.ty).isNone then [s!"failure: no state attribute holds {f.ty}"] else
    f.guard.flatMap (checkGuard s [("self", f.ty)] s!"failure on {f.ty}")
  let prefErrs := a.prefs.flatMap fun p =>
    match a.ops.find? (·.name == p.op) with
    | none => [s!"preference {p.name}: no operator {p.op}"]
    | some o =>
      let fields := o.params.map (·.1) ++ o.vparams.map (·.1)
      p.sameAsLast.flatMap fun (x, y) =>
        (if fields.contains x then [] else [s!"preference {p.name}: {x} is not a field of {p.op}"]) ++
        (if fields.contains y then [] else [s!"preference {p.name}: {y} is not a field of {p.op}"])
  let prefNames := a.prefs.map (·.name)
  let prefDup := if prefNames.eraseDups.length != prefNames.length then ["repeated preference name"] else []
  let failNeeded := if a.prefs.any (·.failure.isSome) && a.failure.isEmpty then
    ["preferences test failure states, but none are declared"] else []
  let scoreErrs := match a.method with
    | .lookahead _ _ _ (some sc) =>
      (if (s.holder? sc.ty).isNone then [s!"score: no state attribute holds {sc.ty}"] else []) ++
      (match sc.name with
       | some n => if a.namedType? n == some sc.ty then [] else [s!"score: no {sc.ty} named {n}"]
       | none => []) ++
      (if sc.val.vrefs.isEmpty then [] else ["score: refers to value parameters"]) ++
      sc.val.refs.flatMap (checkRef s [("self", sc.ty)] "score")
    | _ => []
  let rewardErrs := match a.method with
    | .rl _ (some _) _ _ => if a.failure.isEmpty then ["failure reward, but no failure states are declared"] else []
    | _ => []
  let reportErrs := a.goal.report.flatMap fun m =>
    m.refs.flatMap (checkRef s [("self", a.goal.ty)] "goal report") ++
    (if (Msg.vrefs m).isEmpty then [] else ["goal report: refers to value parameters"])
  checkObjs a ++ goalName ++ reportErrs ++ failErrs ++ prefErrs ++ prefDup ++ failNeeded ++ scoreErrs ++ rewardErrs

def check (a : Agent) : List String :=
  let s := a.schema
  let opNames := a.ops.map (·.name)
  let dupOps := if opNames.eraseDups.length != opNames.length then ["repeated operator name"] else []
  let initErrs := a.init.flatMap fun (attr, vals) =>
    match s.stateAttrs.find? (·.name == attr) with
    | some { ty := .obj t, multi := true, .. } =>
      checkObjPat s t s!"init {attr}" vals ++
      ((s.type? t).map (fun ty => ty.attrs.filter (fun d => !d.derived && !vals.any (·.1 == d.name))
        |>.map fun d => s!"init {attr}: missing {d.name}")).getD []
    | _ => [s!"init: {attr} is not a multi-valued object attribute of the state"]
  let derivedCovered := s.types.flatMap fun t => t.attrs.filter (·.derived) |>.flatMap fun d =>
    if a.derive.any (fun x => x.ty == t.name && x.attr == d.name) then [] else
      [s!"derived {t.name}.{d.name} has no derivation"]
  let keyErrs := s.types.flatMap fun t => match t.key with
    | some k =>
      (if t.attrs.any (·.name == k) then [] else [s!"{t.name}: key {k} undeclared"]) ++
      -- key values are unique among the initial objects, and no operator changes the key
      (let ks := a.init.filterMap fun (h, vals) =>
          if (s.stateAttrs.find? (·.name == h)).map (·.ty) == some (.obj t.name) then vals.lookup k else none
       if ks.eraseDups.length == ks.length then [] else [s!"{t.name}: key {k} not unique initially"]) ++
      (a.ops.flatMap fun o => o.apply.flatMap (·.effects) |>.filterMap fun e =>
        if e.attr == k && (o.params.lookup e.obj) == some t.name then some s!"operator {o.name} changes key {k}" else none)
    | none => []
  let methodErrs := match a.method with
    | .random => []
    | .tieHeuristic hs =>
      (hs.flatMap fun h => (h.last ++ h.cands).flatMap fun n =>
        if n == "none" || opNames.contains n then [] else [s!"heuristic: no operator {n}"]) ++
      -- the evaluation is total and single-valued: exactly one heuristic for each
      -- (last operator, candidate)
      (("none" :: opNames).flatMap fun l => opNames.flatMap fun c =>
        match (hs.filter fun h => h.last.contains l && h.cands.contains c).length with
        | 1 => []
        | 0 => [s!"heuristic: nothing evaluates {c} after {l}"]
        | _ => [s!"heuristic: several values for {c} after {l}"])
    | .lookahead av _ _ _ => av.flatMap (checkStatePat s "avoid") ++
        (s.types.filter (fun t => (s.holder? t.name).isSome && t.key.isNone)).map
          (fun t => s!"look-ahead needs a key for {t.name}")
    | .rl rs _ _ _ => rs.flatMap (fun (p, _) => checkStatePat s "reward" p)
  let learnErrs := match a.method, a.learning with
    | .rl .., .rl _ _ | .rl .., .chunkRl _ _ _ => []
    | .rl .., _ => ["method rl needs rl learning"]
    | _, _ => []
  let consErrs := a.constraints.flatMap fun c =>
    if (s.type? c.ty).isNone then [s!"constraint: no type {c.ty}"] else
    c.guard.flatMap (checkGuard s [("self", c.ty)] s!"constraint on {c.ty}")
  dupOps ++ consErrs ++ a.ops.flatMap (checkOp s) ++ a.derive.flatMap (checkDerive s) ++ initErrs ++
    derivedCovered ++ keyErrs ++ checkObjPat s a.goal.ty "goal" a.goal.vals ++
    (if (s.holder? a.goal.ty).isSome then [] else ["goal: no state attribute holds the type"]) ++
    methodErrs ++ learnErrs ++ checkExtras a

/-! ## Comparing two descriptions (round trip)

Used to compare a description with one re-formalized from its English: which parts differ.
Documentation strings and assumptions are not compared. -/

def Operator.core (o : Operator) : Operator := { o with doc := "" }
def Schema.core (s : Schema) : Schema :=
  { s with stateAttrs := s.stateAttrs.map ({ · with doc := "" }),
           types := s.types.map fun t => { t with doc := "", attrs := t.attrs.map ({ · with doc := "" }) } }

/-- The evaluation a heuristic list gives each (last operator or `none`, candidate): its meaning,
independent of how the entries are grouped or ordered. -/
def heurTable (ops : List String) (hs : List Heur) : List (String × String × Option HVal) :=
  ("none" :: ops).flatMap fun l => ops.map fun c =>
    (l, c, (hs.find? fun h => h.last.contains l && h.cands.contains c).map (·.value))

/-- Methods compared by meaning: tie heuristics by their table. -/
def methodEquiv (ops : List String) : Method → Method → Bool
  | .tieHeuristic h1, .tieHeuristic h2 => heurTable ops h1 == heurTable ops h2
  | m1, m2 => m1 == m2

def diffCore (a b : Agent) : List String :=
  (if a.schema.core == b.schema.core then [] else ["schema"]) ++
  (if a.init == b.init then [] else ["init"]) ++
  (if a.derive == b.derive then [] else ["derive"]) ++
  ((a.ops.zip b.ops).filterMap fun (x, y) => if x.core == y.core then none else some s!"operator {x.name}") ++
  (if a.ops.length == b.ops.length then [] else ["number of operators"]) ++
  (if a.goal == b.goal then [] else ["goal"]) ++
  (if (a.constraints.map fun c => (c.ty, c.guard)) == (b.constraints.map fun c => (c.ty, c.guard)) then [] else ["constraints"]) ++
  (if methodEquiv (a.ops.map (·.name)) a.method b.method then [] else ["method"]) ++
  (if a.learning == b.learning then [] else ["learning"])

end Agent
