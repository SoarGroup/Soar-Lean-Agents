import Agent.DSL
import Agent.Sem
/-!
# Counting — one parameterized description for the family

Derived on 6 November 2026 from the 7 Counting task agents in the agent library: counter V1
(eaters tutorial: count up from 0 at the top state, forever), count-and-die V1 (Soar unit test of
the Cozmo demo: an operator `one` whose operator no-change substate counts from 1 to 75000 with
local `^count`/`^max`, then ends the substate by changing the top state's phase; `two` halts),
count V1 (epmem tutorial: add 9 + 9 by counting, with successor facts in semantic memory),
count-epmem V1 (stores 100 episodes of a counter in episodic memory, then queries them back),
and count-test V1–V3 (Soar's functional count test: nine ways to count down from 10, or 10000 in
V2/V3, each exercising one architectural mechanism).

What varies is where the counting is done (top state, or in an operator's substate) and the limit;
the rest (phase bookkeeping, monitors) is incidental. Two variants replace two originals:
`count-up` (counter V1) and `count-in-substate` (count-and-die V1).

Not replaced:
* count V1: the method is retrieval of successor facts from semantic memory (`smem --add` of the
  digits 0–9 with `^next`, cue-based query, retrieve of `^next`, then return to the superstate);
  without semantic memory it is ordinary arithmetic. It needs a semantic-memory construct (query,
  retrieve, result handling in a substate), which is not small; left for later.
* count-epmem V1: a test of episodic memory (record 100 episodes on output, then query each and
  check the graph match); episodic memory is the point. Needs an epmem construct.
* count-test V1–V3: an architecture regression test. Six of its nine tests exercise mechanisms the
  conventions exclude on purpose: monotonic counting (test 3: new `^count` values never removed),
  operators for the superstate proposed from a state no-change substate (tests 5, 6), preferences
  for superstate operators made in tie substates (tests 7, 8, 9). Rewriting it in the conventions
  would remove what it tests. (Tests 1 and 4 are the two variants here.)
-/
namespace Agent.Counting

def counter : String := "counter"

def schema (task : String) : Schema where
  task := task
  stateAttrs := [{ name := "counter", ty := .obj counter, multi := true, doc := "The counter." }]
  types := [{
    name := counter,
    attrs := [{ name := "value", ty := .int, doc := "the current count" }] }]

/-- Count by one at the top state (counter V1, count-test test 1). -/
def countOp (limit : Int) : Operator where
  name := "count"
  params := [("counter", counter)]
  propose := [.cmp "counter" "value" .lt (.lit limit)]
  apply := [{ effects := [{ obj := "counter", attr := "value", val := .add (.get "counter" "value") (.lit 1) }] }]
  doc := "Add one to the count."

/-- Count to the limit in the substate of one operator (count-and-die V1, count-test test 4): the
operator's effect is the count reaching the limit; its sub-operator adds one at a time. -/
def countToLimit (limit : Int) : Operator where
  name := "count-to-limit"
  params := [("counter", counter)]
  propose := [.cmp "counter" "value" .lt (.lit limit)]
  apply := [{ effects := [{ obj := "counter", attr := "value", val := .lit limit }] }]
  impl := .sub [
    { name := "increment", propose := [.cmp "counter" "value" .lt (.lit limit)],
      apply := [{ effects := [{ obj := "counter", attr := "value", val := .add (.get "counter" "value") (.lit 1) }] }],
      doc := "Add one to the count." }]
  doc := "Count up to the limit, one at a time, in a substate."

def assumptions : List Assumption := [
  { id := "A1", text := "The task: a counter starts at a value and is increased by one until it reaches a limit; then the agent halts (goal as `^desired`, success rule, halt at the top state)." },
  { id := "A2", text := "counter V1 counts from 0 forever and never halts. Here it stops at 100 (a limit chosen for the comparison, not in the original; the harness measures the decisions to reach 100 in both)." },
  { id := "A3", text := "count-and-die V1 counts from 1 to 75000 with a local count in the substate of `one`, then moves the top state from phase one to two, and `two` halts. Here the count is a task object: the sub-operator `increment` changes it in the task state (a result each time), the substate ends when the count reaches the limit, and the goal halts. The phases are bookkeeping and are dropped; so is the substate-local count (its point in the original, if any, was to make a large substate that is then removed — 'die')." },
  { id := "A4", text := "Operators carried out by sub-operators that change what their proposal tests are proposed through a relevance elaboration (`^count-to-limit-relevant`), so they keep their identity across the substate's results (new general compile rule, see DSL.lean)." },
  { id := "A5", text := "Limits are constants of the variant (Lean parameters), not `^max` attributes as in count-and-die: the limit is not changed by any operator." }]

/-- The family: task name, start value, limit, how counting is done. -/
def mk (task : String) (start limit : Int) (sub : Bool) : Agent where
  schema := schema task
  init := [("counter", [("value", start)])]
  derive := []
  ops := [if sub then countToLimit limit else countOp limit]
  goal := { ty := counter, vals := [("value", limit)] }
  constraints := [{ ty := counter, guard := [.cmp "self" "value" .ge (.lit start), .cmp "self" "value" .le (.lit limit)], doc := "the count stays between its start and the limit" }]
  method := .random
  assumptions := assumptions

def variants : List (String × Agent × List String) := [
  ("count-up", mk "count-up" 0 100 false, ["counter V1"]),
  ("count-in-substate", mk "count-in-substate" 1 75000 true, ["count-and-die V1"])]

/-- Every variant obeys the conventions. -/
theorem conventions : variants.all (fun v => check v.2.1 == []) = true := by decide

/-- count-up: 100 counts reach the goal, no fewer. -/
theorem count_up_shortest : ((mk "count-up" 0 100 false).bfs 102).1.map List.length = some 100 := by native_decide

/-- count-up: the count stays in 0..100 in every reachable state. -/
theorem count_up_constraints : (mk "count-up" 0 100 false).constraintsHold 105 = true := by native_decide

/-- count-in-substate, abstractly: one `count-to-limit` reaches the goal. -/
theorem in_substate_shortest : ((mk "count-in-substate" 1 75000 true).bfs 3).1.map List.length = some 1 := by
  native_decide

/-- count-in-substate: the sub-operator `increment` refines `count-to-limit`: from every reachable
state, run to the end (74999 increments), it gives exactly the operator's effect. -/
theorem in_substate_refines : (mk "count-in-substate" 1 75000 true).refinesSub 3 75000 = true := by native_decide

/-- The constraint (count between start and limit) holds for both variants. -/
theorem constraints_hold : variants.all (fun v => v.2.1.constraintsHold 105) = true := by native_decide

end Agent.Counting
