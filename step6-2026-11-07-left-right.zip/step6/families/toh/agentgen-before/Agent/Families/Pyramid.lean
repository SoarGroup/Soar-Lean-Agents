import Agent.DSL
import Agent.Sem
/-!
# Pyramid — one parameterized description for the family

Derived on 6 November 2026 from the 14 Pyramid task agents in the agent library: pyramid V1,
pyramid-jel V1, pyramid-anderson V1, pyramid-hierarchical V1, instruct V1–V3, V5–V10 and
instruct-01-03-05 V1.

A pyramid problem (Anderson's "base $ height"): add `height + 1` terms, starting at `base` and
going down by one each time (5 $ 2 = 5 + 4 + 3 = 12). pyramid V1 and pyramid-jel V1 (base 5,
height 10) add one term per operator at the top state; they differ only in indifferent
preferences on the proposals. pyramid-anderson V1 (base 5, height 2) counts up to the height
instead of down and adds the first term in a separate `start` operator. pyramid-hierarchical V1
(base 10, height 6) first writes the terms out as a linked list in one operator's substate, then
sums the list in another's. What varies is the instance and whether the sum is computed at the top
state or in a substate; here: `pyramid`, `pyramid-anderson` (same method, its instance) and
`pyramid-hierarchical` (one operator carried out by the term-adding sub-operator).

Not replaced: the 10 instruct agents. They are interpreters of instructions given as data: the
procedure (steps, actions with commands set/add/write/goal-test/decrement/increment, a loop back to
a step), the problem syntax (`base $ height = answer`) and term definitions are working-memory
structures built at initialization, and the agent encodes each of ~20 problems from a list of
symbols, solves unknown bases or heights by abstract reasoning and guessing, describes series
written as sums, and in V1/V9 reflects on its results. The DSL has no construct for procedures as
data (an interpreter of declarative instructions) or for objects created at run time (lists).
Semantic memory is not what blocks them: their `smem-retrieve` operator uses a `^smem.retrieve`
structure that Soar 9.6.5 does not have, so in 9.6.5 it always takes its `failed-smem` path
(V3, instruct-01-03-05) or is never selected (the others); nothing is retrieved. A later
smem construct would not be enough; they need an instruction-interpretation construct.
(instruct V2, V5, V6 crash Soar 9.6.5 through the Python SML print callback here: a non-UTF-8 byte
in a `write`; soar-lean runs them.)
-/
namespace Agent.Pyramid

def pyr : String := "pyramid"

def schema (task : String) : Schema where
  task := task
  stateAttrs := [{ name := "pyramid", ty := .obj pyr, multi := true, doc := "The problem." }]
  types := [{
    name := pyr,
    attrs := [
      { name := "term", ty := .int, doc := "the next term to add" },
      { name := "height", ty := .int, doc := "terms still to add, minus one (−1: done)" },
      { name := "sum", ty := .int, doc := "the sum so far" }] }]

def g (a : String) : Expr := .get "pyramid" a

/-- Add the next term (pyramid V1's add-next-base): sum += term; term and height go down by one. -/
def addEffects : List Effect := [
  { obj := "pyramid", attr := "sum", val := .add (g "sum") (g "term") },
  { obj := "pyramid", attr := "term", val := .sub (g "term") (.lit 1) },
  { obj := "pyramid", attr := "height", val := .sub (g "height") (.lit 1) }]

def addNextTerm : Operator where
  name := "add-next-term"
  params := [("pyramid", pyr)]
  propose := [.cmp "pyramid" "height" .ge (.lit 0)]
  apply := [{ effects := addEffects, write := [.text " + ", .val (g "term")] }]
  doc := "Add the next term to the sum."

/-- add-next-term as the sub-operator of sum-pyramid. -/
def addSub : SubOp where
  name := "add-next-term"
  propose := [.cmp "pyramid" "height" .ge (.lit 0)]
  apply := [{ effects := addEffects, write := [.text " + ", .val (g "term")] }]
  doc := "Add the next term to the sum."

/-- The whole sum in one operator, carried out in its substate by adding term after term. Its
effect is the closed form: with n = height + 1 terms, sum += n·term − n(n−1)/2. -/
def sumPyramid : Operator where
  name := "sum-pyramid"
  params := [("pyramid", pyr)]
  propose := [.cmp "pyramid" "height" .ge (.lit 0)]
  apply := [{ effects := [
    { obj := "pyramid", attr := "sum", val := .sub (.add (g "sum") (.mul (.add (g "height") (.lit 1)) (g "term")))
        (.div (.mul (.add (g "height") (.lit 1)) (g "height")) (.lit 2)) },
    { obj := "pyramid", attr := "term", val := .sub (g "term") (.add (g "height") (.lit 1)) },
    { obj := "pyramid", attr := "height", val := .lit (-1) }] }]
  impl := .sub [addSub]
  doc := "Sum the pyramid in a substate."

def assumptions : List Assumption := [
  { id := "A1", text := "The task: base $ height = the sum of height + 1 terms, from base down by one (all four originals agree on height + 1 terms: pyramid V1 adds while height ≥ 0, pyramid-anderson adds the base and then height more terms)." },
  { id := "A2", text := "Representation: one `pyramid` object with the next term, the height left and the sum. pyramid V1 kept them on the state (`^base` was the next term); pyramid-anderson kept the term, a count up to the height, and `^sum nil` before starting; pyramid-hierarchical kept a linked list of terms (`^expansion`) and a final sum." },
  { id := "A3", text := "Goal: height = −1 (all terms added), a `^desired` structure; at the goal the agent writes \"The answer is N.\" (the originals' terminate operator) and halts. The originals' typo \"asnwer\" is corrected." },
  { id := "A4", text := "Each added term is written as \" + N\" (pyramid V1, pyramid-jel, pyramid-hierarchical's expansion); pyramid-anderson wrote nothing per term." },
  { id := "A5", text := "pyramid-hierarchical: its two phases (write the terms as a list, then sum the list) become one operator, sum-pyramid, carried out in its substate by add-next-term, whose changes to the task state are results. The list of terms is dropped (the DSL does not create objects); its effect is stated in closed form and proved equal to what the sub-operator does." },
  { id := "A6", text := "pyramid-anderson's separate start operator (sum := base, term := base) is part of the initial state here (sum 0, term base: the first add-next-term adds the base)." }]

def mk (task : String) (base height : Int) (hier : Bool) : Agent where
  schema := schema task
  init := [("pyramid", [("term", base), ("height", height), ("sum", 0)])]
  derive := []
  ops := [if hier then sumPyramid else addNextTerm]
  goal := { ty := pyr, vals := [("height", -1)],
            report := [.text "The answer is ", .val (.get "self" "sum"), .text "."] }
  constraints := [{ ty := pyr, guard := [.cmp "self" "height" .ge (.lit (-1)), .cmp "self" "height" .le (.lit height)], doc := "the height goes from its start down to −1" }]
  method := .random
  assumptions := assumptions

def variants : List (String × Agent × List String) := [
  ("pyramid", mk "pyramid" 5 10 false, ["pyramid V1", "pyramid-jel V1"]),
  ("pyramid-anderson", mk "pyramid" 5 2 false, ["pyramid-anderson V1"]),
  ("pyramid-hierarchical", mk "pyramid" 10 6 true, ["pyramid-hierarchical V1"])]

/-- Every variant obeys the conventions. -/
theorem conventions : variants.all (fun v => check v.2.1 == []) = true := by decide

/-- The sum in the goal state. -/
def answer (a : Agent) (n : Nat) : Option Int :=
  (a.bfsGoal n).bind fun st => (st.head?.bind (·.lookup "sum"))

/-- The answers: 5 $ 10 = 0, 5 $ 2 = 12, 10 $ 6 = 49 (in Soar 9.6.5 the originals write 0, 12, 49). -/
theorem answers : variants.map (fun v => answer v.2.1 20) = [some 0, some 12, some 49] := by native_decide

/-- Solution lengths: height + 1 term additions; one sum-pyramid for the hierarchical variant. -/
theorem lengths : variants.map (fun v => (v.2.1.bfs 20).1.map List.length) = [some 11, some 3, some 1] := by
  native_decide

/-- Deterministic: in every reachable state at most one operator instance is proposed. -/
theorem deterministic : variants.all (fun v => v.2.1.invariantS 20 (fun st => (v.2.1.succ st).length ≤ 1)) = true := by
  native_decide

/-- The height stays in range in every reachable state. -/
theorem constraints_hold : variants.all (fun v => v.2.1.constraintsHold 20) = true := by native_decide

/-- The sub-operator refines sum-pyramid: run term by term it gives exactly the closed form. -/
theorem hierarchical_refines : (mk "pyramid" 10 6 true).refinesSub 3 10 = true := by native_decide

/-- The closed form agrees with the term-by-term sum for every base in −20..20 and height 0..20. -/
theorem closed_form : ((List.range 41).all fun b => (List.range 21).all fun h =>
    answer (mk "p" (b - 20 : Int) h true) 3 == answer (mk "p" (b - 20 : Int) h false) 25) = true := by native_decide

end Agent.Pyramid
