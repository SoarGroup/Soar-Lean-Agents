# water-jug

## The task

The task state holds several values of `jug`, each a jug. The jugs.
The task state holds one value of `holding`, each a jug. The jug in hand, if any (hierarchical fill).

A jug has `volume` (an integer), `contents` (an integer).
Its `free` is derived: self.volume − self.contents (with `self` the jug). It is recomputed whenever those values change and is never set directly.

Initially the task state has:
- a `jug` with volume 3 and contents 0
- a `jug` with volume 5 and contents 0

**Constraint (part of the task).** Every jug always has self.contents ≥ 0 and self.contents ≤ self.volume (with `self` the jug); every operator must preserve this.

**Goal.** Some jug has volume 3 and contents 1. When the goal holds in the task state, the agent reports success and halts.

## Operators

An operator's changes are made together: every value on the right is read before any change.

**fill(jug: jug).** Proposed when jug.free > 0. Fill a jug from the source, to its volume.
- Effect: jug.contents := jug.volume.

**empty(jug: jug).** Proposed when jug.contents > 0. Pour a jug out onto the ground.
- Effect: jug.contents := 0.

**pour(from: jug, to: jug).** Proposed when from and to are different objects and to.free > 0 and from.contents > 0. Pour one jug into another until the first is empty or the second is full.
- If from.contents > to.free: from.contents := from.contents − to.free; to.contents := to.volume.
- If from.contents ≤ to.free: from.contents := 0; to.contents := to.contents + from.contents.

## Choosing among proposed operators

The agent learns by reinforcement which operator to choose, from the operator and the attribute values of its parameter objects. Rewards:
- -1 for a state with a jug with volume 3 and contents 0; a jug with volume 5 and contents 0
- 1 for a state with a jug with volume 3 and contents 1

## Learning

Reinforcement learning on: learning rate 0.100000, discount 0.500000, epsilon-greedy exploration.

## Assumptions (added; not in the task description)

- **A1** [accepted] Pouring moves as much water as fits: the amount is the smaller of the source's contents and the target's free room; the source keeps what does not fit, and nothing overflows. (All originals; stated in code, not in any description.)
- **A2** [accepted] Contents stay between 0 and the jug's volume. Part of the task: a declared constraint every operator must preserve (`constraints_hold`).
- **A3** [accepted] The goal is that some jug of volume 3 holds 1, written as a `^desired` structure in every variant (one success rule; halt at the top state). Most originals tested for it directly in a rule, without `^desired`.
- **A4** [accepted] In the tie heuristic, `none` means before the first task operator; the initialize operator does not count as a last operator. (Checked: water-jug-tie behaves the same way, because its recording rule tests `^name water-jug`, which the initialize operator itself creates.)
- **A5** [accepted] Hierarchical fill picks up the jug (the task state's `holding` := jug; only when holding nothing), fills it (only while holding it and it is not full), and puts it down (only while holding it). fill stays proposed while its jug is held, so the substate ends after put-down; pour and empty do not depend on the hand. The originals used local bookkeeping markers on the jug and set the contents at put-down.
- **A6** [accepted] Look-ahead: a state is a duplicate of an ancestor (any state from the top state down to its parent) when every jug has a jug in the ancestor with the same volume and contents, and every task-state attribute an operator of the agent can change (here `holding`) agrees: the same object by key, or unset in both. The originals compared exactly the 3- and 5-litre jugs.
- **A7** [accepted] Every variant halts when the goal holds at the top state; the RL variant's reward is delivered first. One run is one episode: multi-episode RL training is done by the harness (run, init-soar keeping learned values, repeat). (water-jug-look-ahead-RL never halted.)
- **A8** [accepted] Names: the derived room left is `free` (originals: `empty`, which is also an operator's name); pour's parameters are `from` and `to` (originals: `empty-jug`/`fill-jug`, or `jug`/`into`).
