chunk*selection*evaluation*expected-values*OpNoChange*t17-2 0 -1.000000
chunk*selection*evaluation*expected-values*OpNoChange*t17-5 0 -0.900000
chunk*selection*evaluation*expected-values*OpNoChange*t17-8 1 -0.764847
chunk*selection*evaluation*expected-values*t17-11 4 -0.617796
chunk*selection*evaluation*expected-values*t22-2 9 -0.452906
chunk*selection*evaluation*expected-values*t27-2 5 -0.555132
chunk*selection*evaluation*expected-values*t30-2 0 -0.900000
chunk*selection*evaluation*expected-values*t49-2 1 -0.729000