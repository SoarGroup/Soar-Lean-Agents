# Water Jug: review decisions (John Laird, 6 November 2026)

| Item | Decision | Effect |
|---|---|---|
| A1 pour amount | Accepted: moves what fits; source keeps the rest; no overflow | — |
| A2 0 ≤ contents ≤ volume | Part of the task | New DSL construct `Constraint`; theorem `constraints_hold` for all 9 variants |
| A3 goal | `^desired` in every variant | — |
| A4 `none` in tie heuristic | Accepted (same as original water-jug-tie, checked) | — |
| A5 hierarchical fill | "In hand" is part of the task: `^holding`; pick-up / fill-jug / put-down are real sub-operators; fill stays proposed while its jug is held; pour and empty do not depend on the hand | New DSL constructs (task-state tests and effects, alternative proposals, sub-operators); theorem `fill_refines`; Soar 9.6.5 = soar-lean; task level comparable to originals |
| A6 duplicates | Any ancestor from the top state; compare all non-derived task attributes (incl. `holding` when an operator can change it) | Look-ahead rules unchanged |
| A7 halting | Halt at the goal everywhere; multi-episode RL is the harness's job | — |
| A8 names | `free`; pour `from`/`to` | — |
| R10 heuristic | Operator names only | — |
| R12 look-ahead | Default library, no depth limit; iterative deepening likely later | On the to-do list |
| R14 RL | −1 meant for returning to the start (rule left as is); RL rules do not test `free` | — |
| R17 limits | Left to the harness | — |
| R16 singletons | None declared: Soar 9.6.5 creates them automatically | tie-chunk unchanged (20/20, median 14, 5 chunks); soar-lean matches |

Open: rerun the blind round trip (the theorem now allows the parts changed since 5 Nov).
