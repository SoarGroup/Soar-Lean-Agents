# Water Jug family: review of the Lean description

Source: `Agent.WaterJug` (WaterJug.lean) over `Agent` DSL v0 (DSL.lean), checked against the nine
`template-*.md` renderings. Identifiers in backticks are Lean names. `Agent/Sem.lean` and
`Agent/Compile.lean` are imported or referenced but were not provided; anything that depends on
them is marked as such in section 5.

## 1. The task

The top state (`^name water-jug`, `schema.task`) holds the jugs through the multi-valued state
attribute `jug`. Each `jug` object has integer attributes `volume` and `contents`, plus the derived
attribute `free := self.volume − self.contents` (`mk.derive`); `free` is i-supported, is recomputed
whenever `volume` or `contents` changes, and no operator may write it (`checkOp`). Initially there are
two jugs, `volume 3, contents 0` and `volume 5, contents 0` (`mk.init`). The goal is that some `jug` has
`volume 3` and `contents 1` (`mk.goal`), compiled to a `^desired` structure plus a success rule (DSL
header, "Explicit goals"). The DSL does not say when the agent stops. That comes only from assumption
`A7`: every variant halts when the goal is reached, and the RL variant first gives its reward. All
nine variants share the same schema, initial state, derivation, operator guards and effects, and goal
(`mk`). They differ only in `method`, in how `fill` is carried out (`fillImpl`), and in `learning`.

## 2. Operators

Operator changes are persistent and are made only by operator application (DSL header, `Effect`).
The templates say that all effects of a case happen together, so every right-hand side is read in
the pre-application state. DSL.lean does not state this (see R1). `free` in a guard or effect is the
value derived from the pre-application state.

- **`fill(jug)`**
  - Proposed when `jug.free > 0`.
  - Effect: `jug.contents := jug.volume`. It has one case and no case guard.
  - `impl` is `fillImpl`. With `.atomic`, apply rules in the selected state make the change. With
    `hierarchical = .steps ["pick-up", "fill-jug", "put-down"]`, an operator no-change substate runs
    those sub-operators in that order, and the last step makes the change as a result (`Impl`).
- **`empty(jug)`**
  - Proposed when `jug.contents > 0`.
  - Effect: `jug.contents := 0`. It has one case.
  - Always `.atomic`.
- **`pour(from, to)`**
  - Proposed when `from` and `to` are distinct objects (`.distinct`), `to.free > 0`, and
    `from.contents > 0`.
  - Case 1, `from.contents > to.free`: `from.contents := from.contents − to.free` and
    `to.contents := to.volume`.
  - Case 2, `from.contents ≤ to.free`: `from.contents := 0` and
    `to.contents := to.contents + from.contents`.
  - The two case guards compare the same pair of values with `>` and `≤`, so over `Int` exactly one
    of them holds in any state. The cases are exhaustive and disjoint.
  - Case 2 needs simultaneous effects: `to.contents` must add the pre-application `from.contents`.
  - Together the cases move `min(from.contents, to.free)`, as `A1` states.
  - Always `.atomic`.

## 3. The variants

| Variant (`variants`) | Selection (`method`) | `fill` carried out | Learning | Look-ahead `avoid` states | How avoided states are scored |
|---|---|---|---|---|---|
| `water-jug` | `.random` | `.atomic` | `.none` | – | – |
| `water-jug-rl` | `.rl [(emptyBoth, -1), (goalPat, 1)]` | `.atomic` | `.rl 100 500` (rate 0.1, discount 0.5, ε-greedy) | – | – (RL rewards: `emptyBoth` −1, `goalPat` +1) |
| `water-jug-tie` | `.tieHeuristic alternate` | `.atomic` | `.none` | – | – |
| `water-jug-tie-chunk` | `.tieHeuristic alternate` | `.atomic` | `.chunk ["contents", "volume"]` (`chunk always`, singletons `contents`, `volume`) | – | – |
| `water-jug-hierarchy` | `.random` | `hierarchical` | `.none` | – | – |
| `water-jug-hierarchy-chunk` | `.random` | `hierarchical` | `.chunk []` | – | – |
| `water-jug-look-ahead` | `.lookahead []` | `.atomic` | `.chunk []` | none (only ancestor duplicates) | – |
| `water-jug-look-ahead-failure-states` | `.lookahead [full, emptyBoth]` | `.atomic` | `.chunk []` | `full` = jugs (3,3) and (5,5); `emptyBoth` = jugs (3,0) and (5,0) | partial failure (`avoidValue = none`) |
| `water-jug-look-ahead-rl` | `.lookahead [full, emptyBoth] (some (-1))` | `.atomic` | `.chunkRl [] 100 500` (chunking + RL, rate 0.1, discount 0.5) | `full`, `emptyBoth` | numeric evaluation −1 |

The (volume, contents) pairs are the `StatePat` object patterns. A state matches a `StatePat` when
each listed object pattern is matched by some `jug`. `goalPat` is jug (3,1).

**`.random`.** No impasse occurs. All proposed operators are indifferent, and one is chosen uniformly at random.

**`.tieHeuristic alternate`.** A tie impasse arises when several operators are proposed. In the tie
substate each tied operator gets a value from the operator applied last (`none` before the first
task operator; see `A4`):

| Before / after | `fill` | `empty` | `pour` |
|---|---|---|---|
| `none` | `equal` | `equal` | `equal` |
| `pour` | `equal` | `equal` | `worst` |
| `fill` or `empty` | `worst` | `worst` | `best` |

In words: start with no preference. After a `pour`, avoid another `pour`. After a `fill` or an
`empty`, prefer a `pour` and avoid another `fill` or `empty`. Heuristics refer only to operator names,
so the value does not depend on which jug the operator is applied to. `check` enforces that exactly
one heuristic covers each pair (last ∈ `none :: opNames`, candidate ∈ `opNames`).

**`.lookahead avoid avoidValue`.** A tie impasse is resolved by look-ahead search using Soar's default
selection library. A state equal to an ancestor state is a partial failure. Equality is judged through
the type `key`, here `volume` (`ObjType.key`, `A6`). A state matching an `avoid` pattern is a partial
failure, or, if `avoidValue = some v`, receives the numeric evaluation `v`.

**`.rl rewards`.** Reinforcement learning runs over the operator and its parameter objects'
attributes. A state matching a pattern receives that pattern's reward. `check` requires `.rl` or
`.chunkRl` learning with this method.

## 4. Assumptions

All eight have `status := "open"` (the default) in `assumptions`.

| Id | Restatement | Reviewer decision |
|---|---|---|
| A1 | Pour moves min(source `contents`, target `free`). It is stated in the originals' code but in no description. | ☐ accept ☐ reject ☐ revise |
| A2 | `contents` stays within 0..`volume`. Checked by `contents_in_range` (bounded, see R4). | ☐ accept ☐ reject ☐ revise |
| A3 | The goal is "some jug of volume 3 holds 1" as `^desired`. Most originals tested it directly in a rule. | ☐ accept ☐ reject ☐ revise |
| A4 | In the tie heuristic `none` means before the first task operator, and initialize is not a last operator. This differs from water-jug-tie, where no heuristic applied at the first tie. | ☐ accept ☐ reject ☐ revise |
| A5 | In hierarchical `fill`, `pick-up`, `fill-jug` and `put-down` are bookkeeping, and only the last step changes `contents`. The step markers stay in the substate rather than being returned as results on the jug. | ☐ accept ☐ reject ☐ revise |
| A6 | A look-ahead duplicate is a state where every jug matches a jug of the ancestor on `volume` and `contents`. The originals compared exactly the 3- and 5-litre jugs. | ☐ accept ☐ reject ☐ revise |
| A7 | Every variant halts at the goal, and the RL variant gives its reward first. | ☐ accept ☐ reject ☐ revise |
| A8 | Naming: derived room is `free` (originals used `empty`, which clashes with the operator name). Pour's parameters are `from`/`to`. | ☐ accept ☐ reject ☐ revise |

## 5. Points a reviewer should check

Tags: **[Settled]** means the provided Lean text decides it. **[Open]** means it is not decided by
DSL.lean or WaterJug.lean, and may live in the unprovided `Sem.lean`/`Compile.lean` or be left to
Soar defaults. **[Partly]** means some of it is settled and some is not.

**Operator semantics**

- **R1. Simultaneity of effects. [Open]** No docstring in DSL.lean says that a case's effects are
  simultaneous. `Case` says only "make these changes". The templates assert it ("every value on the
  right is read before any change"). `pour` case 2 depends on it: read sequentially,
  `to.contents := to.contents + from.contents` would add 0, and `pour` case 1 would read a recomputed
  `to.free`. Confirm against `Sem.lean`/`Compile.lean`.
- **R2. Pour cases exhaustive and disjoint. [Settled for `pour`; Open in general]** The `>`/`≤` pair
  makes this so for `pour`. However, `checkOp` only requires at least one case. The DSL says nothing
  about an operator whose case guards all fail, or where two case guards hold at once.
- **R3. Can `free` be negative? [Partly]** The `int` type has no bounds in the schema. With this
  initial state and these effects, `contents ≤ volume` is preserved (`fill` and `pour` case 1 set it
  to `volume`, and case 2 adds at most `to.free`), so `free ≥ 0`. `contents_in_range` checks that bound.
  Nothing prevents a different `init` from starting a jug over full.
- **R4. Strength of the checked properties. [Partly]** `conventions` is kernel-checked (`decide`).
  `shortest`, `none_shorter` and `contents_in_range` are `native_decide` (they trust the compiler) and
  are run only on `mk .random`. They carry over to the other variants because `mk` varies only
  `method`, `impl` and `learning`. `contents_in_range` is bounded to 20 steps. The claim that this
  covers the whole state space is a comment, not a theorem. The bound arguments of `bfs` (8, and 4 for
  "within 3 steps") have their meaning defined in `Sem.lean`, which was not provided.

**Goal and stopping**

- **R5. Halting. [Open]** No DSL construct expresses halting. It rests entirely on `A7`, but the
  templates state "reports success and halts" as if the DSL defined it.
- **R6. Goal test on the top state only? [Open]** The templates say "when the goal holds in the task
  state". The DSL specifies only `^desired` plus a success rule. In the look-ahead variants the goal
  will be reached in evaluation copies of the state. The success/halt rule must fire on the top state
  only, while the selection library treats goal attainment in a copy as success. Check the compiled
  rule.

**Tie heuristic**

- **R7. `none`. [Partly]** The `Heur` docstring defines `none` as "before the first" operator, and
  `check` treats the string `"none"` specially. Whether initialize counts as a last operator is
  decided only by `A4`, and A4 changes behaviour relative to water-jug-tie. Do not confuse this `none`
  with `Learning.none` or with `avoidValue := none` (`Option.none`, which means "partial failure").
- **R8. What if no heuristic applies? [Settled within its domain]** `check` requires exactly one
  heuristic per (last, candidate) over `none` and the three task operators. It cannot apply if the
  recorded last operator is anything else, for example initialize (`A4`). It is also silent on how
  the last operator is recorded, which is a state attribute not declared in `schema`.
- **R9. Meaning of `best`/`worst`/`equal` and tie-breaking. [Open]** The DSL does not map `HVal` to
  Soar preferences or numeric values. The templates' "best over neutral over worst; ties among equals
  broken at random" is not in the Lean. One reachable case deserves a check: after `fill` into state
  (3,5), reached by `fill` 5 then `fill` 3, `pour` is not proposed and both candidates are
  `empty` = `worst`. The outcome then depends on Soar's handling of all-worst ties.
- **R10. Heuristics ignore parameters. [Settled]** Heuristics match operator names only. For example,
  both `fill` candidates after `none` get the same value. Confirm that this is intended.

**Look-ahead**

- **R11. Look-ahead duplicate detection. [Partly]** `key = volume` identifies a jug among its
  siblings. The DSL does not say which attributes are compared after matching on the key (`A6` says
  `volume` and `contents`), nor that keys are unique (nothing enforces distinct volumes). "Ancestor"
  versus the templates' "on the path from the task state" leaves open whether the top state counts.
  A6's "every jug has a jug in the ancestor" is one-directional.
- **R12. Look-ahead search parameters. [Open]** There is no depth limit, and nothing says how success
  and partial-failure are ranked.
- **R13. `water-jug-look-ahead-rl` combines look-ahead with `chunkRl` but declares no rewards. [Open]**
  `Method.rl` is not used, so it is unclear what RL updates and from what reward. `check` permits this
  combination, since it only enforces rl method ⇒ rl learning. It is also unclear how the numeric −1
  for avoided states combines with the selection library's success/failure values.

**Reinforcement learning**

- **R14. RL details. [Open]** Epsilon is not given. The RL algorithm and initial values are not given.
  It is not stated whether `free` (derived) is among the "parameter-object attributes" in RL rules. It
  is not stated when a reward is delivered: `emptyBoth` (−1) matches the initial state, so it is
  unclear whether reward is given at initialization. With `A7` halting at the goal, the Lean does not
  say how learning carries across runs.

**Hierarchical fill and chunking**

- **R15. Hierarchical `fill` steps. [Open]** The proposal conditions, parameters, and any changes of
  `pick-up`, `fill-jug` and `put-down` are not given. The markers in `A5` are not in `schema`, which
  sits uneasily with "Nothing else can be written or tested". Step names are not checked against
  reserved names. `fill-jug` is distinct from `fill`, but the names are close.
- **R16. Chunking singletons. [Open]** `.chunk ["contents", "volume"]` gives bare attribute names.
  The DSL does not say how these become Soar `chunk singleton` declarations, or why only
  `water-jug-tie-chunk` declares any.

**Random selection, coverage and templates**

- **R17. No termination bound under `.random`. [Open]** Selection is a random walk with no step
  limit. Halting relies on eventually reaching the goal.
- **R18. Coverage of the originals. [Settled, unexplained]** The module docstring lists 20 originals,
  but the `variants` lists name 18. `water-jug V1` and `water-jug-hierarchy V1` are replaced by no
  variant.
- **R19. Template headings. [Settled]** Every template is titled `# water-jug` (`schema.task`), not
  the variant name, so the templates are distinguishable only by file name.
