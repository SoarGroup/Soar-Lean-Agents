# Three wizards — step 6

Lean: `agentgen/Agent/Families/Wizards.lean`.

Variant: `wizards` replaces wizards V1 and V2. V2 casts V1's deduction operators as elaborations; the two behave the same.

The task: A sees that B and C have white spots and that nobody has guessed. He reasons about what B knows of what C knows, and concludes that his own spot is white.

## Structure

Views and records:
- A view is a wizard's knowledge; models of other wizards' views are made at run time, nested.
- Each view holds one record per wizard. A record links to the other records of its view (`sib`) and to the same wizard's records in the views modelled from it (`sub`).
- An unknown spot is a shared variable object (`markvar`) with untried values.

Operators:
- `self-unknown`
- `consider-knows`: make a model of another wizard's view.
- `ascribe-mark`, `ascribe-unknown`, `ascribe-guess`
- `assume-black` / `assume-white`
- `complement`: on a contradiction, replace the assumption with the other value.
- `guess-white` / `guess-black`

Deductions are derived flags that retract when their grounds go, as V2's elaborations do:
- own record;
- white / black: given, deduced from two black spots seen, or known in the model of the wizard and not contradicted there;
- blackish;
- guess white / black;
- contradiction.

New general features:
- **Set-valued links:** add and remove effects on object links. Link tests, linked counts and flag recursion now follow every stored link.
- **`Guard.someSuch`:** some object of a type satisfies the conditions.
- **Reject preferences against another operator** (`Pref.than` with `reject`): the originals' "prefer the deeper model" and "prefer a wizard not yet modelled".
- **Flag semantics:** each round now recomputes every flag from the previous round's flags until nothing changes, as Soar's i-support retracts. Before, flags were only added, which is wrong once a flag's grounds include a negation ("not contradicted"). Every earlier family's theorems still pass.

Every earlier family's output is unchanged.

## Results (Soar 9.6.5, seeds 1–20)

| Agent | Decisions | A guesses |
|---|---|---|
| wizards V1 | 18 | white |
| wizards V2 | 18 | white |
| `wizards` | 18 | white |

The operator sequence matches the originals:
1. initialize;
2. self-unknown;
3. consider-knows (A models B);
4. self-unknown;
5. four ascriptions;
6. assume black;
7. consider-knows (B models C);
8. self-unknown;
9. three ascriptions;
10. assume black;
11. complement (C's model of B: white);
12. complement (B's model of A: white);
13. guess white.

Soar vs soar-lean (`leancmp/`): MATCH (18 decisions, to the halt).

Theorems:
- `conventions`.
- `always_white`: every state reachable along any choice among the operators the preferences leave was followed, with equal states merged. Every run reaches A's guess within 20 decisions, and guessing black is never proposed.

## Assumptions (open, for JL)

- **A1. Numbers.** Wizards and colours are numbers, and the trace writes them as numbers: A 1, B 2, C 3; white 1, black 2; 0 means has not guessed.
- **A2. Views and records.** Views and records are made at run time, as in the originals. An unknown spot is a variable object shared between views, as the originals share mark objects.
- **A3. Deductions.** The deductions are derived flags, as V2's elaborations are.
- **A4. Ascribing.** Ascribing copies known spots, unknown-spot variables and observed guesses only. The originals also copy derived guesses.
- **A5. Assuming.** Assuming is two operators (white only once black has been tried), instead of one assign operator with a preference for black.
- **A6. Complement.** Complement leaves the contradicting record's guess and contradiction alone; they are derived and retract once the assumption is replaced. The originals remove them explicitly.
- **A7. Search control.** As in the originals:
  - best: self-unknown, complement and the final guess;
  - worst: consider-knows and assume;
  - assume is preferred to modelling;
  - modelling from a shallower view is rejected when a deeper view can be modelled;
  - modelling a wizard who already has a model is rejected when one without a model can be modelled.

Your readme notes that the originals' ascribing of knowledge is specific to this problem. Here it is general within the description: a view copies whatever its parent knows about the wizards other than the view's owner.
