"""Wizards harness: decisions to the halt, and A's guess."""
import soar_sml as sml, sys, os, re, json
def run(path, seed):
    k = sml.Kernel.CreateKernelInCurrentThread(True, 0); a = k.CreateAgent('h'); out = []
    a.RegisterForPrintEvent(sml.smlEVENT_PRINT, lambda *x: out.append(x[-1]), None)
    a.ExecuteCommandLine('source ' + os.path.abspath(path)); a.ExecuteCommandLine(f'srand {seed}')
    a.ExecuteCommandLine('watch 0'); a.ExecuteCommandLine('run 500'); txt = ''.join(out)
    dec = int(re.search(r'(\d+) decisions', a.ExecuteCommandLine('stats')).group(1))
    m = re.search(r'Wizard (A|1) guesses (it has|his spot is) (white|black)', txt)
    k.Shutdown()
    return dict(seed=seed, decisions=dec, guess=m.group(3) if m else None, halted='halted' in txt.lower())
if __name__ == '__main__':
    for s in range(1, int(sys.argv[2]) + 1): print(json.dumps(run(sys.argv[1], s)))
