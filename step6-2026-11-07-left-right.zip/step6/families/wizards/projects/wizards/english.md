# wizards

## The task

The task state holds several values of `view`, each a view. The views: A's, and models of others' within them.
The task state holds several values of `rec`, each a rec. What a view holds about each wizard.
The task state holds several values of `markvar`, each a markvar. Unknown spots: variables with untried values.
The task state holds several values of `world`, each a world. Whether A has guessed.

A world has `name` (one of ), `done` (an integer), `nviews` (an integer).

A view has `name` (one of ), `vid` (an integer), `owner` (an integer), `depth` (an integer), `parent` (a view).

A rec has `name` (one of ), `wiz` (an integer), `mark` (an integer), `var` (an integer), `modeled` (an integer), `aguess` (an integer), `view` (a view), `sib` (a rec), `sub` (a rec), `mv` (a markvar).

A markvar has `value` (an integer), `assigned` (an integer), `untried` (an integer).

Initially the task state has:
- a `world` named world with done 0 and nviews 1
- a `view` named A-view with vid 1 and owner 1 and depth 1
- a `rec` named A with wiz 1 and mark 0 and var 0 and modeled 0 and aguess 0; its `view` is A-view; its `sib` is B; its `sib` is C
- a `rec` named B with wiz 2 and mark 1 and var 0 and modeled 0 and aguess 0; its `view` is A-view; its `sib` is A; its `sib` is C
- a `rec` named C with wiz 3 and mark 1 and var 0 and modeled 0 and aguess 0; its `view` is A-view; its `sib` is A; its `sib` is B
Links between objects never change.

**Goal.** Some world has done 1. When the goal holds in the task state, the agent reports success and halts.

## Operators

An operator's changes are made together: every value on the right is read before any change.

**self-unknown(r: rec).** Proposed when r is own and r.mark = 0 and r.var = 0 and r is not white and r is not black.
- Effect: r.mv := m; r.var := 1; writes "In the view of wizard ⟨r.wiz⟩, his own spot is unknown.".

**consider-knows(wd: world, k: view, w: rec, a1: rec, a2: rec, a3: rec).** Proposed when w.view is k and w is not own and w.modeled = 0 and a1.view is k and a1.wiz = 1 and a2.view is k and a2.wiz = 2 and a3.view is k and a3.wiz = 3.
- Effect: wd.nviews := wd.nviews + 1; w.modeled := 1; v.parent := k; r1.view := v; r2.view := v; r3.view := v; r1.sib := r2; r1.sib := r3; r2.sib := r1; r2.sib := r3; r3.sib := r1; r3.sib := r2; a1.sub := r1; a2.sub := r2; a3.sub := r3; writes "In the view of wizard ⟨k.owner⟩, model what wizard ⟨w.wiz⟩ knows.".

**ascribe-mark(x1: rec, x2: rec).** Proposed when x1.sub is x2 and x2 is not own and x1.mark ≠ 0 and x2.mark = 0.
- Effect: x2.mark := x1.mark.

**ascribe-unknown(x1: rec, x2: rec, m: markvar).** Proposed when x1.sub is x2 and x2 is not own and x1.mv is m and x2.var = 0.
- Effect: x2.mv := m; x2.var := 1.

**ascribe-guess(x1: rec, x2: rec, gv ∈ {0, 1, 2}).** Proposed when x1.sub is x2 and x2 is not own and x1.aguess = gv and x2.aguess does not contain gv.
- Effect: x2.aguess := gv.

**assume-black(k: view, r: rec, m: markvar).** Proposed when r.view is k and r is not own and r.mv is m and m.value = 0 and m.untried = 2.
- Effect: m.value := 2; m.untried := 2; m.assigned := k.vid; writes "In the view of wizard ⟨k.owner⟩, assume wizard ⟨r.wiz⟩'s spot is black.".

**assume-white(k: view, r: rec, m: markvar).** Proposed when r.view is k and r is not own and r.mv is m and m.value = 0 and m.untried = 1 and m.untried does not contain 2.
- Effect: m.value := 1; m.untried := 1; m.assigned := k.vid; writes "In the view of wizard ⟨k.owner⟩, assume wizard ⟨r.wiz⟩'s spot is white.".

**complement(k1: view, w1: rec, k2: view, w2: rec, m: markvar, u ∈ {1, 2}).** Proposed when w1.view is k1 and w1 is contra and k2.parent is k1 and w2.view is k2 and w2.mv is m and m.assigned = k2.vid and m.untried = u.
- Effect: w2.mark := u; w2.mv := m; w2.var := 0; writes "Contradiction in the view of wizard ⟨k1.owner⟩: in the view of wizard ⟨k2.owner⟩, wizard ⟨w2.wiz⟩'s spot must be ⟨u⟩".

**guess-white(wd: world, k: view, r: rec).** Proposed when wd.done = 0 and k.depth = 1 and r.view is k and r is own and r is gwhite.
- Effect: wd.done := 1; writes "Wizard ⟨r.wiz⟩ guesses his spot is white.".

**guess-black(wd: world, k: view, r: rec).** Proposed when wd.done = 0 and k.depth = 1 and r.view is k and r is own and r is gblack.
- Effect: wd.done := 1; writes "Wizard ⟨r.wiz⟩ guesses his spot is black.".

## Choosing among proposed operators

Any proposed operator may be chosen; the choice is random.

The agent remembers the last task operator applied (its name and parameters). Search-control preferences:
- **self-unknown-first**: a proposed self-unknown whose  is best.
- **complement-first**: a proposed complement whose  is best.
- **guess-first**: a proposed guess-white whose  is best.
- **guess-black-first**: a proposed guess-black whose  is best.
- **consider-last**: a proposed consider-knows whose  is worst.
- **assume-black-late**: a proposed assume-black whose  is worst.
- **assume-white-late**: a proposed assume-white whose  is worst.
- **assume-before-consider**: a proposed assume-black whose  is better than a proposed consider-knows.
- **assume-white-before-consider**: a proposed assume-white whose  is better than a proposed consider-knows.
- **prefer-deeper**: a proposed consider-knows whose  is rejected when there is a proposed consider-knows when other-k.parent is k.
- **prefer-new-names**: a proposed consider-knows whose  is rejected when there is a proposed consider-knows when no view has owner = other-w.wiz and some view has owner = w.wiz.

## Learning

None.

## Assumptions (added; not in the task description)

- **A1** [open] Wizards and colours are numbers (A 1, B 2, C 3; white 1, black 2; 0 = has not guessed) and the trace writes them as numbers; the originals write names and colours.
- **A2** [open] Views and their records are objects made at run time (consider-knows), as in the originals; each record links to the other records of its view (`sib`) and to the same wizard's records in the views modelled from it (`sub`), and an unknown spot is a shared variable object (`markvar`), as the originals share mark objects between views.
- **A3** [open] The deductions are derived flags that retract when their grounds go (V2's elaborations): own record; white / black (given, deduced from two black spots seen, or known in the model of him and not contradicted there); blackish (black or assumed black, for deducing); guess white / black (own known spot, observed guess, or the guess in the model of him); contradiction (predicted to guess but observed not to have guessed, or two guesses).
- **A4** [open] Ascribing knowledge copies known spots, unknown-spot variables and observed guesses (only) into a modelled view, for the wizards other than its owner; the originals' ascribe-knowledge also copies derived guesses.
- **A5** [open] Assume-black and assume-white are two operators (white only once black is tried) instead of one assign operator with a preference for black.
- **A6** [open] Complement does not remove the contradicting record's guess and contradiction (they are derived and retract once the assumption is replaced); the originals remove them explicitly.
- **A7** [open] Search control as in the originals: self-unknown, complement and the final guess best; consider-knows and assume worst; assuming before modelling; reject modelling from a shallower view when a deeper one can be modelled, and modelling a wizard who already has a model when one without can be.
