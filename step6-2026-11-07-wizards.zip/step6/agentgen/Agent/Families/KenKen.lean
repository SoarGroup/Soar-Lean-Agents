import Agent.DSL
import Agent.Sem
/-!
# KenKen — constraint propagation over candidate values, with look-ahead guesses

Derived on 7 November 2026 from kenken V1 and V2 (John Laird, 2026). An n × n grid takes the
numbers 1 … n once in every row and column; each cage of cells must give its value under its
operation (add, subtract, multiply, divide; one-cell cages are equal). The originals keep each
cell's legal values and narrow them by constraint propagation (row and column marks, single legal
values, a value only one cell of a row or column can take, cage arithmetic from tables of
numbers); when propagation stops, they choose a cell with two (else three) legal values and guess
its value by look-ahead in the selection space, with chunking.

Here each cell has a candidate object per value (alive or not), and each cage the tuples of values
that satisfy it (computed from the cage, as the originals' number tables are): a candidate no live
tuple of its cage uses is dropped. One variant per puzzle of V1 (sixteen: seven 4 × 4, five 5 × 5,
four 6 × 6).
-/
namespace Agent.KenKen

/-- The originals' puzzles (kenken V1, board-definitions-4/5/6): size, number, and cages (operation, value, cells as (column, row)). -/
def puzzles : List (Nat × Nat × List (String × Nat × List (Nat × Nat))) := [
  (4, 1, [("subtract", 1, [(1, 1), (2, 1)]), ("divide", 2, [(3, 1), (4, 1)]), ("subtract", 1, [(1, 2), (2, 2)]), ("add", 5, [(3, 2), (4, 2)]), ("multiply", 8, [(1, 3), (1, 4), (2, 4)]), ("subtract", 2, [(2, 3), (3, 3)]), ("equal", 2, [(4, 3)]), ("subtract", 1, [(3, 4), (4, 4)])]),
  (4, 2, [("subtract", 1, [(1, 1), (1, 2)]), ("subtract", 3, [(2, 1), (3, 1)]), ("add", 8, [(4, 1), (3, 2), (4, 2)]), ("add", 5, [(2, 2), (2, 3)]), ("equal", 4, [(1, 3)]), ("subtract", 1, [(3, 3), (3, 4)]), ("subtract", 1, [(4, 3), (4, 4)]), ("subtract", 3, [(1, 4), (2, 4)])]),
  (4, 3, [("add", 8, [(1, 1), (2, 1), (2, 2)]), ("add", 7, [(3, 1), (4, 1), (3, 2)]), ("add", 5, [(1, 2), (1, 3)]), ("equal", 1, [(4, 2)]), ("add", 11, [(2, 3), (3, 3), (4, 3), (4, 4)]), ("add", 8, [(1, 4), (2, 4), (3, 4)])]),
  (4, 4, [("add", 9, [(1, 1), (2, 1), (2, 2), (2, 3)]), ("subtract", 1, [(3, 1), (3, 2)]), ("divide", 2, [(4, 1), (4, 2)]), ("multiply", 8, [(1, 2), (1, 3), (1, 4)]), ("equal", 4, [(2, 4)]), ("divide", 2, [(3, 3), (3, 4)]), ("subtract", 2, [(4, 3), (4, 4)])]),
  (4, 5, [("add", 5, [(1, 1), (2, 1)]), ("add", 5, [(3, 1), (4, 1)]), ("add", 6, [(1, 2), (2, 2)]), ("add", 4, [(3, 2), (4, 2)]), ("add", 5, [(1, 3), (1, 4)]), ("add", 5, [(2, 3), (3, 3)]), ("add", 9, [(4, 3), (4, 4), (3, 4)]), ("equal", 1, [(2, 4)])]),
  (4, 6, [("divide", 2, [(1, 1), (2, 1)]), ("add", 6, [(3, 1), (4, 1), (4, 2)]), ("subtract", 2, [(1, 2), (1, 3)]), ("multiply", 24, [(2, 2), (2, 3), (3, 3)]), ("equal", 1, [(3, 2)]), ("equal", 4, [(4, 3)]), ("divide", 2, [(1, 4), (2, 4)]), ("subtract", 1, [(3, 4), (4, 4)])]),
  (4, 7, [("subtract", 2, [(1, 1), (2, 1)]), ("multiply", 24, [(3, 1), (4, 1), (3, 2)]), ("add", 7, [(1, 2), (1, 3), (2, 3)]), ("equal", 2, [(2, 2)]), ("multiply", 12, [(4, 2), (4, 3), (4, 4)]), ("divide", 2, [(3, 3), (3, 4)]), ("subtract", 1, [(1, 4), (2, 4)])]),
  (5, 1, [("divide", 2, [(1, 1), (2, 1)]), ("multiply", 60, [(3, 1), (4, 1), (5, 1)]), ("add", 5, [(1, 2), (1, 3)]), ("subtract", 2, [(2, 2), (2, 3)]), ("add", 9, [(3, 2), (4, 2)]), ("equal", 2, [(5, 2)]), ("add", 7, [(3, 3), (3, 4), (4, 4)]), ("subtract", 4, [(4, 3), (5, 3)]), ("subtract", 1, [(1, 4), (2, 4)]), ("subtract", 2, [(5, 4), (5, 5)]), ("equal", 4, [(1, 5)]), ("add", 10, [(2, 5), (3, 5), (4, 5)])]),
  (5, 2, [("equal", 3, [(1, 1)]), ("add", 6, [(2, 1), (2, 2)]), ("add", 9, [(3, 1), (3, 2)]), ("divide", 2, [(4, 1), (4, 2)]), ("add", 4, [(5, 1), (5, 2)]), ("subtract", 1, [(1, 2), (1, 3)]), ("equal", 2, [(2, 3)]), ("subtract", 2, [(3, 3), (4, 3)]), ("subtract", 1, [(5, 3), (5, 4)]), ("subtract", 1, [(1, 4), (1, 5)]), ("subtract", 1, [(2, 4), (2, 5)]), ("subtract", 1, [(3, 4), (4, 4)]), ("equal", 1, [(3, 5)]), ("multiply", 6, [(4, 5), (5, 5)])]),
  (5, 3, [("subtract", 2, [(1, 1), (2, 1)]), ("subtract", 1, [(3, 1), (3, 2)]), ("add", 5, [(4, 1), (5, 1)]), ("equal", 1, [(1, 2)]), ("multiply", 16, [(2, 2), (1, 3), (2, 3)]), ("subtract", 1, [(4, 2), (4, 3)]), ("subtract", 4, [(5, 2), (5, 3)]), ("subtract", 1, [(3, 3), (3, 4)]), ("subtract", 2, [(1, 4), (2, 4)]), ("equal", 5, [(4, 4)]), ("subtract", 1, [(5, 4), (5, 5)]), ("add", 9, [(1, 5), (2, 5)]), ("divide", 2, [(3, 5), (4, 5)])]),
  (5, 4, [("subtract", 1, [(1, 1), (1, 2)]), ("add", 3, [(2, 1), (3, 1)]), ("subtract", 1, [(4, 1), (4, 2)]), ("subtract", 4, [(5, 1), (5, 2)]), ("subtract", 1, [(2, 2), (3, 2)]), ("multiply", 40, [(1, 3), (2, 3), (2, 4)]), ("equal", 5, [(3, 3)]), ("subtract", 2, [(4, 3), (5, 3)]), ("subtract", 4, [(1, 4), (1, 5)]), ("subtract", 2, [(3, 4), (3, 5)]), ("add", 5, [(4, 4), (4, 5)]), ("divide", 2, [(5, 4), (5, 5)]), ("equal", 4, [(2, 5)])]),
  (5, 5, [("multiply", 180, [(1, 1), (1, 2), (1, 3), (2, 3)]), ("subtract", 1, [(2, 1), (3, 1)]), ("subtract", 4, [(4, 1), (4, 2)]), ("divide", 2, [(5, 1), (5, 2)]), ("equal", 4, [(2, 2)]), ("subtract", 4, [(3, 2), (3, 3)]), ("add", 8, [(4, 3), (3, 4), (4, 4)]), ("add", 9, [(5, 3), (5, 4), (5, 5)]), ("equal", 1, [(1, 4)]), ("add", 8, [(1, 5), (2, 5), (2, 4)]), ("subtract", 1, [(3, 5), (4, 5)])]),
  (6, 1, [("add", 13, [(1, 1), (1, 2), (1, 3)]), ("subtract", 3, [(2, 1), (3, 1)]), ("add", 6, [(4, 1), (4, 2)]), ("divide", 3, [(5, 1), (6, 1)]), ("divide", 2, [(2, 2), (3, 2)]), ("multiply", 30, [(5, 2), (6, 2), (5, 3)]), ("divide", 2, [(2, 3), (3, 3)]), ("multiply", 24, [(4, 3), (4, 4)]), ("multiply", 15, [(6, 3), (6, 4), (6, 5)]), ("subtract", 1, [(1, 4), (1, 5)]), ("multiply", 60, [(2, 4), (2, 5), (3, 4)]), ("equal", 4, [(5, 4)]), ("add", 9, [(3, 5), (4, 5), (3, 6)]), ("multiply", 72, [(5, 5), (4, 6), (5, 6), (6, 6)]), ("add", 11, [(1, 6), (2, 6)])]),
  (6, 2, [("multiply", 20, [(1, 1), (1, 2), (1, 3)]), ("multiply", 96, [(2, 1), (2, 2), (3, 2), (3, 3)]), ("add", 7, [(3, 1), (4, 1)]), ("subtract", 3, [(5, 1), (6, 1)]), ("divide", 2, [(4, 2), (5, 2)]), ("subtract", 1, [(6, 2), (6, 3)]), ("subtract", 5, [(2, 3), (2, 4)]), ("add", 12, [(4, 3), (5, 3), (5, 4)]), ("equal", 6, [(1, 4)]), ("subtract", 4, [(3, 4), (3, 5)]), ("subtract", 3, [(4, 4), (4, 5)]), ("add", 13, [(6, 4), (6, 5), (5, 5)]), ("multiply", 60, [(1, 5), (2, 5), (1, 6), (2, 6)]), ("subtract", 1, [(3, 6), (4, 6)]), ("add", 7, [(5, 6), (6, 6)])]),
  (6, 3, [("multiply", 12, [(1, 1), (2, 1), (1, 2)]), ("add", 9, [(3, 1), (4, 1), (3, 2)]), ("multiply", 150, [(4, 2), (5, 2), (5, 1), (6, 1)]), ("divide", 2, [(2, 2), (2, 3)]), ("divide", 2, [(6, 2), (6, 3)]), ("subtract", 2, [(1, 3), (1, 4)]), ("subtract", 5, [(3, 3), (3, 4)]), ("subtract", 1, [(4, 3), (5, 3)]), ("equal", 5, [(2, 4)]), ("add", 7, [(4, 4), (5, 4), (6, 4)]), ("subtract", 3, [(1, 5), (1, 6)]), ("divide", 2, [(2, 5), (2, 6)]), ("subtract", 1, [(3, 5), (3, 6)]), ("add", 11, [(4, 5), (5, 5), (6, 5), (6, 6)]), ("divide", 3, [(4, 6), (5, 6)])]),
  (6, 4, [("multiply", 12, [(1, 1), (2, 1)]), ("add", 14, [(3, 1), (3, 2), (4, 2), (4, 3)]), ("add", 11, [(4, 1), (5, 1)]), ("add", 4, [(6, 1), (6, 2), (5, 2)]), ("add", 14, [(1, 2), (1, 3), (1, 4)]), ("subtract", 5, [(2, 2), (2, 3)]), ("add", 14, [(3, 3), (3, 4), (3, 5), (2, 4)]), ("add", 10, [(5, 3), (5, 4), (4, 4)]), ("subtract", 2, [(6, 3), (6, 4)]), ("divide", 2, [(1, 5), (2, 5)]), ("divide", 3, [(4, 5), (4, 6)]), ("multiply", 48, [(5, 5), (5, 6), (6, 6)]), ("equal", 6, [(6, 5)]), ("multiply", 60, [(1, 6), (2, 6), (3, 6)])])]

def cellT : String := "cell"
def candT : String := "cand"
def tupleT : String := "tuple"
def puzT : String := "puzzle"

def schema : Schema where
  task := "kenken"
  stateAttrs := [
    { name := "cell", ty := .obj cellT, multi := true, doc := "The cells of the grid." },
    { name := "cand", ty := .obj candT, multi := true, doc := "Candidate values: one per cell and value." },
    { name := "tuple", ty := .obj tupleT, multi := true, doc := "The value tuples that satisfy each cage." },
    { name := "puzzle", ty := .obj puzT, multi := true, doc := "The puzzle being solved." }]
  types := [
    { name := cellT, key := some "coord",
      attrs := [
        { name := "name", ty := .sym [], doc := "c<column><row>" },
        { name := "coord", ty := .int, doc := "column × 10 + row" },
        { name := "row", ty := .int, doc := "1 … n" },
        { name := "col", ty := .int, doc := "1 … n" },
        { name := "mark", ty := .int, doc := "its number once decided; 0 before" },
        { name := "cand", ty := .obj candT, multi := true, doc := "its candidates" }] },
    { name := candT, key := some "cid",
      attrs := [
        { name := "cid", ty := .int, doc := "coordinate × 10 + value" },
        { name := "name", ty := .sym [], doc := "v<column><row><value>" },
        { name := "coord", ty := .int, doc := "its cell's coordinate" },
        { name := "row", ty := .int, doc := "its cell's row" },
        { name := "col", ty := .int, doc := "its cell's column" },
        { name := "value", ty := .int, doc := "the number" },
        { name := "alive", ty := .int, doc := "1 while the cell may still take the number" },
        { name := "in", ty := .obj tupleT, multi := true, doc := "the cage tuples that give its cell this number" }] },
    { name := tupleT, key := some "tid",
      attrs := [
        { name := "tid", ty := .int, doc := "its number" },
        { name := "name", ty := .sym [], doc := "t<k>" },
        { name := "alive", ty := .int, doc := "1 while every candidate it uses is alive" },
        { name := "uses", ty := .obj candT, multi := true, doc := "its candidates, one per cell of the cage" }] },
    { name := puzT, key := some "pid",
      attrs := [
        { name := "pid", ty := .int, doc := "1" },
        { name := "name", ty := .sym [], doc := "puzzle" },
        { name := "marks", ty := .int, doc := "cells decided" },
        { name := "gcell", ty := .int, doc := "the coordinate of the cell chosen for a guess; 0 none" }] }]

def g (o a : String) : Expr := .get o a
def eff (o a : String) (v : Expr) : Effect := { obj := o, attr := a, val := v }

/-- Decide a cell: its only live candidate, or a number no other cell of its row (column) can take. -/
def assign : Operator where
  name := "assign"
  params := [("p", puzT), ("c", cellT), ("x", candT)]
  propose := [.cmp "c" "mark" .eq (.lit 0), .link "c" "cand" "x", .cmp "x" "alive" .eq (.lit 1)]
  proposeOr := [
    [.linked "c" "cand" candT [("alive", .eq, .lit 1), ("value", .ne, .get "x" "value")] 0],
    [.noneSuch candT [("row", .eq, .get "c" "row"), ("value", .eq, .get "x" "value"), ("alive", .eq, .lit 1),
      ("coord", .ne, .get "c" "coord")]],
    [.noneSuch candT [("col", .eq, .get "c" "col"), ("value", .eq, .get "x" "value"), ("alive", .eq, .lit 1),
      ("coord", .ne, .get "c" "coord")]]]
  apply := [{
    effects := [eff "c" "mark" (g "x" "value"), eff "p" "marks" (.add (g "p" "marks") (.lit 1))],
    write := [.text "Set cell: ", .val (g "c" "coord"), .text " to ", .val (g "x" "value")] }]
  indifferent := true
  doc := "Decide a cell's number."

/-- A decided cell's other candidates are dropped. -/
def cleanup : Operator where
  name := "cleanup"
  params := [("c", cellT), ("z", candT)]
  propose := [.cmp "c" "mark" .ne (.lit 0), .link "c" "cand" "z", .cmp "z" "alive" .eq (.lit 1),
    .cmp "z" "value" .ne (.get "c" "mark")]
  apply := [{ effects := [eff "z" "alive" (.lit 0)] }]
  indifferent := true

/-- A decided cell's number is dropped from the other cells of its row and column. -/
def eliminate : Operator where
  name := "eliminate"
  params := [("c1", cellT), ("c2", cellT), ("y", candT)]
  propose := [.cmp "c1" "mark" .ne (.lit 0), .distinct "c1" "c2", .link "c2" "cand" "y",
    .cmp "y" "alive" .eq (.lit 1), .cmp "y" "value" .eq (.get "c1" "mark")]
  proposeOr := [[.cmp "c2" "row" .eq (.get "c1" "row")], [.cmp "c2" "col" .eq (.get "c1" "col")]]
  apply := [{ effects := [eff "y" "alive" (.lit 0)] }]
  indifferent := true

/-- A cage tuple that uses a dropped candidate is dropped. -/
def dropTuple : Operator where
  name := "drop-tuple"
  params := [("t", tupleT), ("x", candT)]
  propose := [.cmp "t" "alive" .eq (.lit 1), .link "t" "uses" "x", .cmp "x" "alive" .eq (.lit 0)]
  apply := [{ effects := [eff "t" "alive" (.lit 0)] }]
  indifferent := true

/-- A candidate no live tuple of its cage uses is dropped (the cage arithmetic). -/
def prune : Operator where
  name := "prune"
  params := [("x", candT)]
  propose := [.cmp "x" "alive" .eq (.lit 1), .linked "x" "in" tupleT [("alive", .eq, .lit 1)] 0]
  apply := [{ effects := [eff "x" "alive" (.lit 0)] }]
  indifferent := true

/-- When nothing else applies: choose an undecided cell with `k` live candidates to guess. -/
def chooseCell (k : Nat) : Operator where
  name := if k == 2 then "choose-cell" else s!"choose-cell-{k}"
  params := [("p", puzT), ("c", cellT)]
  propose := [.cmp "p" "gcell" .eq (.lit 0), .cmp "c" "mark" .eq (.lit 0),
    .linked "c" "cand" candT [("alive", .eq, .lit 1)] k, .fewer "c" "cand" candT [("alive", .eq, .lit 1)] (k + 1)]
  apply := [{
    effects := [eff "p" "gcell" (g "c" "coord")],
    write := [.text "Guess cell: ", .val (g "c" "coord")] }]
  indifferent := true

/-- Guess the chosen cell's number: the guesses tie, and look-ahead evaluates them. -/
def guess : Operator where
  name := "guess"
  params := [("p", puzT), ("c", cellT), ("x", candT)]
  propose := [.cmp "p" "gcell" .eq (.get "c" "coord"), .link "c" "cand" "x", .cmp "x" "alive" .eq (.lit 1)]
  apply := [{
    effects := [eff "c" "mark" (g "x" "value"), eff "p" "marks" (.add (g "p" "marks") (.lit 1)), eff "p" "gcell" (.lit 0)],
    write := [.text "Guess: ", .val (g "c" "coord"), .text " is ", .val (g "x" "value")] }]

def worstPref (op : String) : Pref :=
  { name := op ++ "-last", op := op, sameAsLast := [], guard := [.cmp "p" "gcell" .eq (.lit 0)], value := .worst,
    doc := "Only when propagation has stopped." }

def prefs : List Pref :=
  [worstPref "choose-cell", worstPref "choose-cell-3",
   { name := "two-before-three", op := "choose-cell", sameAsLast := [], value := .better, than := ["choose-cell-3"] }]

/-- A cell that is undecided with no live candidate: the guesses so far are wrong. -/
def noCandidate : Failure where
  ty := cellT
  guard := [.cmp "self" "mark" .eq (.lit 0), .linked "self" "cand" candT [("alive", .eq, .lit 1)] 0]
  doc := "an undecided cell has no candidate left"

/-- A decided cell whose number has been dropped (two cells of a row or column decided the same,
or a cage without tuples): a contradiction. -/
def markDropped : Failure where
  ty := cellT
  guard := [.cmp "self" "mark" .ne (.lit 0),
    .linked "self" "cand" candT [("value", .eq, .get "self" "mark"), ("alive", .eq, .lit 1)] 0]
  doc := "a decided cell's number has been dropped"

/-! ## Cages and their tuples -/

def holds (op : String) (v : Nat) (vals : List Nat) : Bool :=
  match op, vals with
  | "add", _ => vals.foldl (· + ·) 0 == v
  | "multiply", _ => vals.foldl (· * ·) 1 == v
  | "equal", [a] => a == v
  | "subtract", [a, b] => a + v == b || b + v == a
  | "divide", [a, b] => a * v == b || b * v == a
  | _, _ => false

/-- Every assignment of 1 … n to the cells. -/
def assignments (n : Nat) : Nat → List (List Nat)
  | 0 => [[]]
  | k + 1 => (assignments n k).flatMap fun rest => (List.range n).map fun v => (v + 1) :: rest

/-- The tuples of a cage: the values that satisfy it, no number twice in a row or column. -/
def tuplesOf (n : Nat) (op : String) (v : Nat) (cells : List (Nat × Nat)) : List (List Nat) :=
  (assignments n cells.length).filter fun vals =>
    holds op v vals &&
    let cv := cells.zip vals
    cv.all fun ((c, r), x) => cv.all fun ((c', r'), x') => (c, r) == (c', r') || !((c == c' || r == r') && x == x')

def cname (c r : Nat) : String := s!"c{c}{r}"
def vname (c r v : Nat) : String := s!"v{c}{r}{v}"

/-- The named objects of a puzzle: cells, candidates, the cage tuples, and the puzzle. -/
def objects (n : Nat) (cages : List (String × Nat × List (Nat × Nat))) : List Named :=
  let tups : List (List ((Nat × Nat) × Nat)) := cages.flatMap fun (op, v, cells) =>
    (tuplesOf n op v cells).map (cells.zip ·)
  let tnames := (List.range tups.length).map (s!"t{·}")
  let grid := (List.range n).flatMap fun i => (List.range n).map fun j => (i + 1, j + 1)
  (grid.map fun (c, r) =>
    { holder := "cell", name := cname c r,
      vals := [("coord", ((c * 10 + r : Nat) : Int)), ("row", (r : Int)), ("col", (c : Int)), ("mark", 0)],
      links := (List.range n).map fun v => ("cand", vname c r (v + 1)) }) ++
  (grid.flatMap fun (c, r) => (List.range n).map fun v0 =>
    let v := v0 + 1
    { holder := "cand", name := vname c r v,
      vals := [("cid", (((c * 10 + r) * 10 + v : Nat) : Int)), ("coord", ((c * 10 + r : Nat) : Int)), ("row", (r : Int)),
        ("col", (c : Int)), ("value", (v : Int)), ("alive", 1)],
      links := ((tups.zip tnames).filter (fun (t, _) => t.contains ((c, r), v))).map fun (_, tn) => ("in", tn) }) ++
  (((tups.zip tnames).zip (List.range tups.length)).map fun ((t, tn), k) =>
    { holder := "tuple", name := tn, vals := [("tid", (k : Int)), ("alive", 1)],
      links := t.map fun ((c, r), v) => ("uses", vname c r v) }) ++
  [{ holder := "puzzle", name := "puzzle", vals := [("pid", 1), ("marks", 0), ("gcell", 0)] }]

def assumptions : List Assumption := [
  { id := "A1", text := "The task: solve one KenKen puzzle (an n × n Latin square whose cages give their values under their operations); one variant per puzzle of V1 (its sixteen boards), instead of V1's one agent that works through the boards in turn. The harness runs them in V1's order." },
  { id := "A2", text := "Each cell has one candidate object per number (alive or dropped) instead of a set of legal values; a decided cell has a mark. Propagation: decide a cell with one live candidate or with a number no other cell of its row or column can take (the originals' mark-single-value and notice-single-column-row-value); drop the other candidates of a decided cell; drop a decided number from the cell's row and column (remove-column-row-values)." },
  { id := "A3", text := "Cage arithmetic: each cage's tuples of values that satisfy it are computed from the cage and made objects (as the originals' number tables are written out); a tuple that uses a dropped candidate is dropped, and a candidate no live tuple of its cage uses is dropped. This replaces the originals' check-group substate (two-cell cages against the number tables), the subgroups made when a cell of a larger cage is decided, and the linear-sum groups; it is complete for each cage on its own (generalised arc consistency), so it can narrow more than the originals." },
  { id := "A4", text := "Guessing as in V1: when propagation stops, choose an undecided cell with two live candidates (else three), then guess its number; the guesses tie and look-ahead in the selection space evaluates them (Soar's default library), a state with an undecided cell without candidates, or a decided cell whose number has been dropped, being a failure (without the second, two cells of a row decided the same number went unnoticed, a wrong guess reached the goal, and one run of 6-3 ended with 12 wrong cells). Chunking is on, with V1's `chunk allow-local-negations off` (with local negations on, building the first look-ahead chunk did not finish). Duplicate states are not checked (propagation never repeats a state)." },
  { id := "A5", text := "Output: each decided cell is written (Set cell / Guess); the originals' board printing (print-board, print-row) is left out." },
  { id := "A6", text := "V2 (one 4 × 4 board, the same propagation without guessing, check-group with a substate) is not given its own variant: it loops after solving (state no-change at the goal, no halt). Its board is V1's 4-3, variant kenken-4-3." }]

def mk (n : Nat) (cages : List (String × Nat × List (Nat × Nat))) : Agent where
  schema := schema
  init := []
  objs := objects n cages
  derive := []
  ops := [assign, cleanup, eliminate, dropTuple, prune, chooseCell 2, chooseCell 3, guess]
  goal := { ty := puzT, vals := [("marks", ((n * n : Nat) : Int))] }
  failure := [noCandidate, markDropped]
  prefs := prefs
  method := .lookahead [] none .off
  learning := .chunk []
  chunkLocalNegations := false
  assumptions := assumptions

def variants : List (String × Agent × List String) :=
  puzzles.map fun (n, k, cages) => (s!"kenken-{n}-{k}", mk n cages, [s!"kenken V1 (board {n}-{k})"])

def conventionsOk : Bool := variants.all (fun v => check v.2.1 == [])
theorem conventions : conventionsOk = true := by native_decide

/-! ## Checking the description on the boards propagation solves -/

/-- Follow the preferences, breaking ties by the first candidate, for at most `k` operators; the
final state when the goal holds. -/
def runFirst (ag : Agent) : Nat → TState → Option TState
  | 0, _ => none
  | k + 1, st => if ag.isGoal st then some st else
    match ag.prefCands st none with
    | (_, _, st') :: _ => runFirst ag k st'
    | [] => none

/-- The decided grid is a solution: every row and column has 1 … n once, and every cage holds. -/
def validGrid (n : Nat) (cages : List (String × Nat × List (Nat × Nat))) (ag : Agent) (st : TState) : Bool :=
  let cells := ag.objsOf st cellT
  let markOf (c r : Nat) : Nat :=
    (((cells.find? fun x => x.lookup "coord" == some ((c * 10 + r : Nat) : Int)).bind (·.lookup "mark")).getD 0).toNat
  let ns := (List.range n).map (· + 1)
  let perm (xs : List Nat) : Bool := ns.all (xs.contains ·)
  ns.all (fun r => perm (ns.map (markOf · r))) && ns.all (fun c => perm (ns.map (markOf c ·))) &&
  cages.all fun (op, v, cs) => holds op v (cs.map fun (c, r) => markOf c r)

/-- The 4 × 4 boards that propagation solves without a guess (all but 4-5): with ties
broken by the first candidate, the description reaches the goal and the grid is a solution. -/
def propagationOk : Bool :=
  (puzzles.filter fun (n, k, _) => n == 4 && k != 5).all fun (n, _, cages) =>
    let ag := mk n cages
    match runFirst ag 300 ag.initial with
    | some st => validGrid n cages ag st
    | none => false

theorem propagation_solves : propagationOk = true := by native_decide

end Agent.KenKen
