# kenken

## The task

The task state holds several values of `cell`, each a cell. The cells of the grid.
The task state holds several values of `cand`, each a cand. Candidate values: one per cell and value.
The task state holds several values of `tuple`, each a tuple. The value tuples that satisfy each cage.
The task state holds several values of `puzzle`, each a puzzle. The puzzle being solved.

A cell has `name` (one of ), `coord` (an integer), `row` (an integer), `col` (an integer), `mark` (an integer), `cand` (a cand).

A cand has `cid` (an integer), `name` (one of ), `coord` (an integer), `row` (an integer), `col` (an integer), `value` (an integer), `alive` (an integer), `in` (a tuple).

A tuple has `tid` (an integer), `name` (one of ), `alive` (an integer), `uses` (a cand).

A puzzle has `pid` (an integer), `name` (one of ), `marks` (an integer), `gcell` (an integer).

Initially the task state has:
- a `cell` named c11 with coord 11 and row 1 and col 1 and mark 0; its `cand` is v111; its `cand` is v112; its `cand` is v113; its `cand` is v114
- a `cell` named c12 with coord 12 and row 2 and col 1 and mark 0; its `cand` is v121; its `cand` is v122; its `cand` is v123; its `cand` is v124
- a `cell` named c13 with coord 13 and row 3 and col 1 and mark 0; its `cand` is v131; its `cand` is v132; its `cand` is v133; its `cand` is v134
- a `cell` named c14 with coord 14 and row 4 and col 1 and mark 0; its `cand` is v141; its `cand` is v142; its `cand` is v143; its `cand` is v144
- a `cell` named c21 with coord 21 and row 1 and col 2 and mark 0; its `cand` is v211; its `cand` is v212; its `cand` is v213; its `cand` is v214
- a `cell` named c22 with coord 22 and row 2 and col 2 and mark 0; its `cand` is v221; its `cand` is v222; its `cand` is v223; its `cand` is v224
- a `cell` named c23 with coord 23 and row 3 and col 2 and mark 0; its `cand` is v231; its `cand` is v232; its `cand` is v233; its `cand` is v234
- a `cell` named c24 with coord 24 and row 4 and col 2 and mark 0; its `cand` is v241; its `cand` is v242; its `cand` is v243; its `cand` is v244
- a `cell` named c31 with coord 31 and row 1 and col 3 and mark 0; its `cand` is v311; its `cand` is v312; its `cand` is v313; its `cand` is v314
- a `cell` named c32 with coord 32 and row 2 and col 3 and mark 0; its `cand` is v321; its `cand` is v322; its `cand` is v323; its `cand` is v324
- a `cell` named c33 with coord 33 and row 3 and col 3 and mark 0; its `cand` is v331; its `cand` is v332; its `cand` is v333; its `cand` is v334
- a `cell` named c34 with coord 34 and row 4 and col 3 and mark 0; its `cand` is v341; its `cand` is v342; its `cand` is v343; its `cand` is v344
- a `cell` named c41 with coord 41 and row 1 and col 4 and mark 0; its `cand` is v411; its `cand` is v412; its `cand` is v413; its `cand` is v414
- a `cell` named c42 with coord 42 and row 2 and col 4 and mark 0; its `cand` is v421; its `cand` is v422; its `cand` is v423; its `cand` is v424
- a `cell` named c43 with coord 43 and row 3 and col 4 and mark 0; its `cand` is v431; its `cand` is v432; its `cand` is v433; its `cand` is v434
- a `cell` named c44 with coord 44 and row 4 and col 4 and mark 0; its `cand` is v441; its `cand` is v442; its `cand` is v443; its `cand` is v444
- a `cand` named v111 with cid 111 and coord 11 and row 1 and col 1 and value 1 and alive 1; its `in` is t5; its `in` is t7
- a `cand` named v112 with cid 112 and coord 11 and row 1 and col 1 and value 2 and alive 1; its `in` is t2
- a `cand` named v113 with cid 113 and coord 11 and row 1 and col 1 and value 3 and alive 1; its `in` is t1; its `in` is t4; its `in` is t6
- a `cand` named v114 with cid 114 and coord 11 and row 1 and col 1 and value 4 and alive 1; its `in` is t0; its `in` is t3
- a `cand` named v121 with cid 121 and coord 12 and row 2 and col 1 and value 1 and alive 1; its `in` is t19
- a `cand` named v122 with cid 122 and coord 12 and row 2 and col 1 and value 2 and alive 1; its `in` is t18
- a `cand` named v123 with cid 123 and coord 12 and row 2 and col 1 and value 3 and alive 1; its `in` is t17
- a `cand` named v124 with cid 124 and coord 12 and row 2 and col 1 and value 4 and alive 1; its `in` is t16
- a `cand` named v131 with cid 131 and coord 13 and row 3 and col 1 and value 1 and alive 1; its `in` is t16
- a `cand` named v132 with cid 132 and coord 13 and row 3 and col 1 and value 2 and alive 1; its `in` is t17
- a `cand` named v133 with cid 133 and coord 13 and row 3 and col 1 and value 3 and alive 1; its `in` is t18
- a `cand` named v134 with cid 134 and coord 13 and row 3 and col 1 and value 4 and alive 1; its `in` is t19
- a `cand` named v141 with cid 141 and coord 14 and row 4 and col 1 and value 1 and alive 1; its `in` is t36; its `in` is t38
- a `cand` named v142 with cid 142 and coord 14 and row 4 and col 1 and value 2 and alive 1
- a `cand` named v143 with cid 143 and coord 14 and row 4 and col 1 and value 3 and alive 1; its `in` is t34; its `in` is t37
- a `cand` named v144 with cid 144 and coord 14 and row 4 and col 1 and value 4 and alive 1; its `in` is t33; its `in` is t35
- a `cand` named v211 with cid 211 and coord 21 and row 1 and col 2 and value 1 and alive 1; its `in` is t3; its `in` is t6
- a `cand` named v212 with cid 212 and coord 21 and row 1 and col 2 and value 2 and alive 1; its `in` is t4
- a `cand` named v213 with cid 213 and coord 21 and row 1 and col 2 and value 3 and alive 1; its `in` is t0; its `in` is t7
- a `cand` named v214 with cid 214 and coord 21 and row 1 and col 2 and value 4 and alive 1; its `in` is t1; its `in` is t2; its `in` is t5
- a `cand` named v221 with cid 221 and coord 22 and row 2 and col 2 and value 1 and alive 1; its `in` is t0; its `in` is t1
- a `cand` named v222 with cid 222 and coord 22 and row 2 and col 2 and value 2 and alive 1; its `in` is t2
- a `cand` named v223 with cid 223 and coord 22 and row 2 and col 2 and value 3 and alive 1; its `in` is t3; its `in` is t4; its `in` is t5
- a `cand` named v224 with cid 224 and coord 22 and row 2 and col 2 and value 4 and alive 1; its `in` is t6; its `in` is t7
- a `cand` named v231 with cid 231 and coord 23 and row 3 and col 2 and value 1 and alive 1; its `in` is t28; its `in` is t32
- a `cand` named v232 with cid 232 and coord 23 and row 3 and col 2 and value 2 and alive 1; its `in` is t22; its `in` is t24; its `in` is t30
- a `cand` named v233 with cid 233 and coord 23 and row 3 and col 2 and value 3 and alive 1; its `in` is t23; its `in` is t26; its `in` is t27
- a `cand` named v234 with cid 234 and coord 23 and row 3 and col 2 and value 4 and alive 1; its `in` is t21; its `in` is t25; its `in` is t29; its `in` is t31
- a `cand` named v241 with cid 241 and coord 24 and row 4 and col 2 and value 1 and alive 1; its `in` is t35; its `in` is t37
- a `cand` named v242 with cid 242 and coord 24 and row 4 and col 2 and value 2 and alive 1
- a `cand` named v243 with cid 243 and coord 24 and row 4 and col 2 and value 3 and alive 1; its `in` is t33; its `in` is t38
- a `cand` named v244 with cid 244 and coord 24 and row 4 and col 2 and value 4 and alive 1; its `in` is t34; its `in` is t36
- a `cand` named v311 with cid 311 and coord 31 and row 1 and col 3 and value 1 and alive 1; its `in` is t12; its `in` is t13; its `in` is t15
- a `cand` named v312 with cid 312 and coord 31 and row 1 and col 3 and value 2 and alive 1; its `in` is t9; its `in` is t14
- a `cand` named v313 with cid 313 and coord 31 and row 1 and col 3 and value 3 and alive 1; its `in` is t11
- a `cand` named v314 with cid 314 and coord 31 and row 1 and col 3 and value 4 and alive 1; its `in` is t8; its `in` is t10
- a `cand` named v321 with cid 321 and coord 32 and row 2 and col 3 and value 1 and alive 1; its `in` is t8; its `in` is t9
- a `cand` named v322 with cid 322 and coord 32 and row 2 and col 3 and value 2 and alive 1; its `in` is t10; its `in` is t11; its `in` is t12
- a `cand` named v323 with cid 323 and coord 32 and row 2 and col 3 and value 3 and alive 1; its `in` is t13
- a `cand` named v324 with cid 324 and coord 32 and row 2 and col 3 and value 4 and alive 1; its `in` is t14; its `in` is t15
- a `cand` named v331 with cid 331 and coord 33 and row 3 and col 3 and value 1 and alive 1; its `in` is t27; its `in` is t31
- a `cand` named v332 with cid 332 and coord 33 and row 3 and col 3 and value 2 and alive 1; its `in` is t21; its `in` is t23; its `in` is t29
- a `cand` named v333 with cid 333 and coord 33 and row 3 and col 3 and value 3 and alive 1; its `in` is t24; its `in` is t25; its `in` is t28
- a `cand` named v334 with cid 334 and coord 33 and row 3 and col 3 and value 4 and alive 1; its `in` is t22; its `in` is t26; its `in` is t30; its `in` is t32
- a `cand` named v341 with cid 341 and coord 34 and row 4 and col 3 and value 1 and alive 1; its `in` is t33; its `in` is t34
- a `cand` named v342 with cid 342 and coord 34 and row 4 and col 3 and value 2 and alive 1
- a `cand` named v343 with cid 343 and coord 34 and row 4 and col 3 and value 3 and alive 1; its `in` is t35; its `in` is t36
- a `cand` named v344 with cid 344 and coord 34 and row 4 and col 3 and value 4 and alive 1; its `in` is t37; its `in` is t38
- a `cand` named v411 with cid 411 and coord 41 and row 1 and col 4 and value 1 and alive 1; its `in` is t10; its `in` is t14
- a `cand` named v412 with cid 412 and coord 41 and row 1 and col 4 and value 2 and alive 1; its `in` is t8; its `in` is t11; its `in` is t15
- a `cand` named v413 with cid 413 and coord 41 and row 1 and col 4 and value 3 and alive 1; its `in` is t13
- a `cand` named v414 with cid 414 and coord 41 and row 1 and col 4 and value 4 and alive 1; its `in` is t9; its `in` is t12
- a `cand` named v421 with cid 421 and coord 42 and row 2 and col 4 and value 1 and alive 1; its `in` is t20
- a `cand` named v422 with cid 422 and coord 42 and row 2 and col 4 and value 2 and alive 1
- a `cand` named v423 with cid 423 and coord 42 and row 2 and col 4 and value 3 and alive 1
- a `cand` named v424 with cid 424 and coord 42 and row 2 and col 4 and value 4 and alive 1
- a `cand` named v431 with cid 431 and coord 43 and row 3 and col 4 and value 1 and alive 1; its `in` is t25; its `in` is t26; its `in` is t29; its `in` is t30
- a `cand` named v432 with cid 432 and coord 43 and row 3 and col 4 and value 2 and alive 1; its `in` is t31; its `in` is t32
- a `cand` named v433 with cid 433 and coord 43 and row 3 and col 4 and value 3 and alive 1; its `in` is t21; its `in` is t22
- a `cand` named v434 with cid 434 and coord 43 and row 3 and col 4 and value 4 and alive 1; its `in` is t23; its `in` is t24; its `in` is t27; its `in` is t28
- a `cand` named v441 with cid 441 and coord 44 and row 4 and col 4 and value 1 and alive 1
- a `cand` named v442 with cid 442 and coord 44 and row 4 and col 4 and value 2 and alive 1; its `in` is t21; its `in` is t22; its `in` is t23; its `in` is t24
- a `cand` named v443 with cid 443 and coord 44 and row 4 and col 4 and value 3 and alive 1; its `in` is t25; its `in` is t26; its `in` is t27; its `in` is t28
- a `cand` named v444 with cid 444 and coord 44 and row 4 and col 4 and value 4 and alive 1; its `in` is t29; its `in` is t30; its `in` is t31; its `in` is t32
- a `tuple` named t0 with tid 0 and alive 1; its `uses` is v114; its `uses` is v213; its `uses` is v221
- a `tuple` named t1 with tid 1 and alive 1; its `uses` is v113; its `uses` is v214; its `uses` is v221
- a `tuple` named t2 with tid 2 and alive 1; its `uses` is v112; its `uses` is v214; its `uses` is v222
- a `tuple` named t3 with tid 3 and alive 1; its `uses` is v114; its `uses` is v211; its `uses` is v223
- a `tuple` named t4 with tid 4 and alive 1; its `uses` is v113; its `uses` is v212; its `uses` is v223
- a `tuple` named t5 with tid 5 and alive 1; its `uses` is v111; its `uses` is v214; its `uses` is v223
- a `tuple` named t6 with tid 6 and alive 1; its `uses` is v113; its `uses` is v211; its `uses` is v224
- a `tuple` named t7 with tid 7 and alive 1; its `uses` is v111; its `uses` is v213; its `uses` is v224
- a `tuple` named t8 with tid 8 and alive 1; its `uses` is v314; its `uses` is v412; its `uses` is v321
- a `tuple` named t9 with tid 9 and alive 1; its `uses` is v312; its `uses` is v414; its `uses` is v321
- a `tuple` named t10 with tid 10 and alive 1; its `uses` is v314; its `uses` is v411; its `uses` is v322
- a `tuple` named t11 with tid 11 and alive 1; its `uses` is v313; its `uses` is v412; its `uses` is v322
- a `tuple` named t12 with tid 12 and alive 1; its `uses` is v311; its `uses` is v414; its `uses` is v322
- a `tuple` named t13 with tid 13 and alive 1; its `uses` is v311; its `uses` is v413; its `uses` is v323
- a `tuple` named t14 with tid 14 and alive 1; its `uses` is v312; its `uses` is v411; its `uses` is v324
- a `tuple` named t15 with tid 15 and alive 1; its `uses` is v311; its `uses` is v412; its `uses` is v324
- a `tuple` named t16 with tid 16 and alive 1; its `uses` is v124; its `uses` is v131
- a `tuple` named t17 with tid 17 and alive 1; its `uses` is v123; its `uses` is v132
- a `tuple` named t18 with tid 18 and alive 1; its `uses` is v122; its `uses` is v133
- a `tuple` named t19 with tid 19 and alive 1; its `uses` is v121; its `uses` is v134
- a `tuple` named t20 with tid 20 and alive 1; its `uses` is v421
- a `tuple` named t21 with tid 21 and alive 1; its `uses` is v234; its `uses` is v332; its `uses` is v433; its `uses` is v442
- a `tuple` named t22 with tid 22 and alive 1; its `uses` is v232; its `uses` is v334; its `uses` is v433; its `uses` is v442
- a `tuple` named t23 with tid 23 and alive 1; its `uses` is v233; its `uses` is v332; its `uses` is v434; its `uses` is v442
- a `tuple` named t24 with tid 24 and alive 1; its `uses` is v232; its `uses` is v333; its `uses` is v434; its `uses` is v442
- a `tuple` named t25 with tid 25 and alive 1; its `uses` is v234; its `uses` is v333; its `uses` is v431; its `uses` is v443
- a `tuple` named t26 with tid 26 and alive 1; its `uses` is v233; its `uses` is v334; its `uses` is v431; its `uses` is v443
- a `tuple` named t27 with tid 27 and alive 1; its `uses` is v233; its `uses` is v331; its `uses` is v434; its `uses` is v443
- a `tuple` named t28 with tid 28 and alive 1; its `uses` is v231; its `uses` is v333; its `uses` is v434; its `uses` is v443
- a `tuple` named t29 with tid 29 and alive 1; its `uses` is v234; its `uses` is v332; its `uses` is v431; its `uses` is v444
- a `tuple` named t30 with tid 30 and alive 1; its `uses` is v232; its `uses` is v334; its `uses` is v431; its `uses` is v444
- a `tuple` named t31 with tid 31 and alive 1; its `uses` is v234; its `uses` is v331; its `uses` is v432; its `uses` is v444
- a `tuple` named t32 with tid 32 and alive 1; its `uses` is v231; its `uses` is v334; its `uses` is v432; its `uses` is v444
- a `tuple` named t33 with tid 33 and alive 1; its `uses` is v144; its `uses` is v243; its `uses` is v341
- a `tuple` named t34 with tid 34 and alive 1; its `uses` is v143; its `uses` is v244; its `uses` is v341
- a `tuple` named t35 with tid 35 and alive 1; its `uses` is v144; its `uses` is v241; its `uses` is v343
- a `tuple` named t36 with tid 36 and alive 1; its `uses` is v141; its `uses` is v244; its `uses` is v343
- a `tuple` named t37 with tid 37 and alive 1; its `uses` is v143; its `uses` is v241; its `uses` is v344
- a `tuple` named t38 with tid 38 and alive 1; its `uses` is v141; its `uses` is v243; its `uses` is v344
- a `puzzle` named puzzle with pid 1 and marks 0 and gcell 0
Links between objects never change.

**Failure state.** A state is a failure state when some cell has self.mark = 0 and no cand that self.cand points to have alive = 1 (with `self` the cell). an undecided cell has no candidate left

**Failure state.** A state is a failure state when some cell has self.mark ≠ 0 and no cand that self.cand points to have value = self.mark and alive = 1 (with `self` the cell). a decided cell's number has been dropped

**Goal.** Some puzzle has marks 16. When the goal holds in the task state, the agent reports success and halts.

## Operators

An operator's changes are made together: every value on the right is read before any change.

**assign(p: puzzle, c: cell, x: cand).** Proposed when c.mark = 0 and c.cand is x and x.alive = 1. Decide a cell's number.
- and when one of these holds: no cand that c.cand points to have alive = 1 and value ≠ x.value; or no cand has row = c.row and value = x.value and alive = 1 and coord ≠ c.coord; or no cand has col = c.col and value = x.value and alive = 1 and coord ≠ c.coord.
- Effect: c.mark := x.value; p.marks := p.marks + 1; writes "Set cell: ⟨c.coord⟩ to ⟨x.value⟩".

**cleanup(c: cell, z: cand).** Proposed when c.mark ≠ 0 and c.cand is z and z.alive = 1 and z.value ≠ c.mark.
- Effect: z.alive := 0.

**eliminate(c1: cell, c2: cell, y: cand).** Proposed when c1.mark ≠ 0 and c1 and c2 are different objects and c2.cand is y and y.alive = 1 and y.value = c1.mark.
- and when one of these holds: c2.row = c1.row; or c2.col = c1.col.
- Effect: y.alive := 0.

**drop-tuple(t: tuple, x: cand).** Proposed when t.alive = 1 and t.uses is x and x.alive = 0.
- Effect: t.alive := 0.

**prune(x: cand).** Proposed when x.alive = 1 and no tuple that x.in points to have alive = 1.
- Effect: x.alive := 0.

**choose-cell(p: puzzle, c: cell).** Proposed when p.gcell = 0 and c.mark = 0 and at least 2 cands that c.cand points to have alive = 1 and fewer than 3 cands that c.cand points to have alive = 1.
- Effect: p.gcell := c.coord; writes "Guess cell: ⟨c.coord⟩".

**choose-cell-3(p: puzzle, c: cell).** Proposed when p.gcell = 0 and c.mark = 0 and at least 3 cands that c.cand points to have alive = 1 and fewer than 4 cands that c.cand points to have alive = 1.
- Effect: p.gcell := c.coord; writes "Guess cell: ⟨c.coord⟩".

**guess(p: puzzle, c: cell, x: cand).** Proposed when p.gcell = c.coord and c.cand is x and x.alive = 1.
- Effect: c.mark := x.value; p.marks := p.marks + 1; p.gcell := 0; writes "Guess: ⟨c.coord⟩ is ⟨x.value⟩".

## Choosing among proposed operators

When several operators are proposed, the agent tries each one in an internal copy of the state (look-ahead search, Soar's default selection library) and prefers those that lead to the goal. Returning to an earlier state is not detected.
A failure state reached in look-ahead is a failure: the operator leading to it is rejected.

The agent remembers the last task operator applied (its name and parameters). Search-control preferences:
- **choose-cell-last**: a proposed choose-cell whose  is worst. Only when propagation has stopped.
- **choose-cell-3-last**: a proposed choose-cell-3 whose  is worst. Only when propagation has stopped.
- **two-before-three**: a proposed choose-cell whose  is better than a proposed choose-cell-3.

## Learning

Chunking on (`chunk always`).

## Assumptions (added; not in the task description)

- **A1** [open] The task: solve one KenKen puzzle (an n × n Latin square whose cages give their values under their operations); one variant per puzzle of V1 (its sixteen boards), instead of V1's one agent that works through the boards in turn. The harness runs them in V1's order.
- **A2** [open] Each cell has one candidate object per number (alive or dropped) instead of a set of legal values; a decided cell has a mark. Propagation: decide a cell with one live candidate or with a number no other cell of its row or column can take (the originals' mark-single-value and notice-single-column-row-value); drop the other candidates of a decided cell; drop a decided number from the cell's row and column (remove-column-row-values).
- **A3** [open] Cage arithmetic: each cage's tuples of values that satisfy it are computed from the cage and made objects (as the originals' number tables are written out); a tuple that uses a dropped candidate is dropped, and a candidate no live tuple of its cage uses is dropped. This replaces the originals' check-group substate (two-cell cages against the number tables), the subgroups made when a cell of a larger cage is decided, and the linear-sum groups; it is complete for each cage on its own (generalised arc consistency), so it can narrow more than the originals.
- **A4** [open] Guessing as in V1: when propagation stops, choose an undecided cell with two live candidates (else three), then guess its number; the guesses tie and look-ahead in the selection space evaluates them (Soar's default library), a state with an undecided cell without candidates, or a decided cell whose number has been dropped, being a failure (without the second, two cells of a row decided the same number went unnoticed, a wrong guess reached the goal, and one run of 6-3 ended with 12 wrong cells). Chunking is on, with V1's `chunk allow-local-negations off` (with local negations on, building the first look-ahead chunk did not finish). Duplicate states are not checked (propagation never repeats a state).
- **A5** [open] Output: each decided cell is written (Set cell / Guess); the originals' board printing (print-board, print-row) is left out.
- **A6** [open] V2 (one 4 × 4 board, the same propagation without guessing, check-group with a substate) is not given its own variant: it loops after solving (state no-change at the goal, no halt). Its board is V1's 4-3, variant kenken-4-3.
