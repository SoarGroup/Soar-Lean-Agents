# kenken

## The task

The task state holds several values of `cell`, each a cell. The cells of the grid.
The task state holds several values of `cand`, each a cand. Candidate values: one per cell and value.
The task state holds several values of `tuple`, each a tuple. The value tuples that satisfy each cage.
The task state holds several values of `puzzle`, each a puzzle. The puzzle being solved.

A cell has `name` (one of ), `coord` (an integer), `row` (an integer), `col` (an integer), `mark` (an integer), `cand` (a cand).

A cand has `cid` (an integer), `name` (one of ), `coord` (an integer), `row` (an integer), `col` (an integer), `value` (an integer), `alive` (an integer), `in` (a tuple).

A tuple has `tid` (an integer), `name` (one of ), `alive` (an integer), `uses` (a cand).

A puzzle has `pid` (an integer), `name` (one of ), `marks` (an integer), `gcell` (an integer).

Initially the task state has:
- a `cell` named c11 with coord 11 and row 1 and col 1 and mark 0; its `cand` is v111; its `cand` is v112; its `cand` is v113; its `cand` is v114; its `cand` is v115; its `cand` is v116
- a `cell` named c12 with coord 12 and row 2 and col 1 and mark 0; its `cand` is v121; its `cand` is v122; its `cand` is v123; its `cand` is v124; its `cand` is v125; its `cand` is v126
- a `cell` named c13 with coord 13 and row 3 and col 1 and mark 0; its `cand` is v131; its `cand` is v132; its `cand` is v133; its `cand` is v134; its `cand` is v135; its `cand` is v136
- a `cell` named c14 with coord 14 and row 4 and col 1 and mark 0; its `cand` is v141; its `cand` is v142; its `cand` is v143; its `cand` is v144; its `cand` is v145; its `cand` is v146
- a `cell` named c15 with coord 15 and row 5 and col 1 and mark 0; its `cand` is v151; its `cand` is v152; its `cand` is v153; its `cand` is v154; its `cand` is v155; its `cand` is v156
- a `cell` named c16 with coord 16 and row 6 and col 1 and mark 0; its `cand` is v161; its `cand` is v162; its `cand` is v163; its `cand` is v164; its `cand` is v165; its `cand` is v166
- a `cell` named c21 with coord 21 and row 1 and col 2 and mark 0; its `cand` is v211; its `cand` is v212; its `cand` is v213; its `cand` is v214; its `cand` is v215; its `cand` is v216
- a `cell` named c22 with coord 22 and row 2 and col 2 and mark 0; its `cand` is v221; its `cand` is v222; its `cand` is v223; its `cand` is v224; its `cand` is v225; its `cand` is v226
- a `cell` named c23 with coord 23 and row 3 and col 2 and mark 0; its `cand` is v231; its `cand` is v232; its `cand` is v233; its `cand` is v234; its `cand` is v235; its `cand` is v236
- a `cell` named c24 with coord 24 and row 4 and col 2 and mark 0; its `cand` is v241; its `cand` is v242; its `cand` is v243; its `cand` is v244; its `cand` is v245; its `cand` is v246
- a `cell` named c25 with coord 25 and row 5 and col 2 and mark 0; its `cand` is v251; its `cand` is v252; its `cand` is v253; its `cand` is v254; its `cand` is v255; its `cand` is v256
- a `cell` named c26 with coord 26 and row 6 and col 2 and mark 0; its `cand` is v261; its `cand` is v262; its `cand` is v263; its `cand` is v264; its `cand` is v265; its `cand` is v266
- a `cell` named c31 with coord 31 and row 1 and col 3 and mark 0; its `cand` is v311; its `cand` is v312; its `cand` is v313; its `cand` is v314; its `cand` is v315; its `cand` is v316
- a `cell` named c32 with coord 32 and row 2 and col 3 and mark 0; its `cand` is v321; its `cand` is v322; its `cand` is v323; its `cand` is v324; its `cand` is v325; its `cand` is v326
- a `cell` named c33 with coord 33 and row 3 and col 3 and mark 0; its `cand` is v331; its `cand` is v332; its `cand` is v333; its `cand` is v334; its `cand` is v335; its `cand` is v336
- a `cell` named c34 with coord 34 and row 4 and col 3 and mark 0; its `cand` is v341; its `cand` is v342; its `cand` is v343; its `cand` is v344; its `cand` is v345; its `cand` is v346
- a `cell` named c35 with coord 35 and row 5 and col 3 and mark 0; its `cand` is v351; its `cand` is v352; its `cand` is v353; its `cand` is v354; its `cand` is v355; its `cand` is v356
- a `cell` named c36 with coord 36 and row 6 and col 3 and mark 0; its `cand` is v361; its `cand` is v362; its `cand` is v363; its `cand` is v364; its `cand` is v365; its `cand` is v366
- a `cell` named c41 with coord 41 and row 1 and col 4 and mark 0; its `cand` is v411; its `cand` is v412; its `cand` is v413; its `cand` is v414; its `cand` is v415; its `cand` is v416
- a `cell` named c42 with coord 42 and row 2 and col 4 and mark 0; its `cand` is v421; its `cand` is v422; its `cand` is v423; its `cand` is v424; its `cand` is v425; its `cand` is v426
- a `cell` named c43 with coord 43 and row 3 and col 4 and mark 0; its `cand` is v431; its `cand` is v432; its `cand` is v433; its `cand` is v434; its `cand` is v435; its `cand` is v436
- a `cell` named c44 with coord 44 and row 4 and col 4 and mark 0; its `cand` is v441; its `cand` is v442; its `cand` is v443; its `cand` is v444; its `cand` is v445; its `cand` is v446
- a `cell` named c45 with coord 45 and row 5 and col 4 and mark 0; its `cand` is v451; its `cand` is v452; its `cand` is v453; its `cand` is v454; its `cand` is v455; its `cand` is v456
- a `cell` named c46 with coord 46 and row 6 and col 4 and mark 0; its `cand` is v461; its `cand` is v462; its `cand` is v463; its `cand` is v464; its `cand` is v465; its `cand` is v466
- a `cell` named c51 with coord 51 and row 1 and col 5 and mark 0; its `cand` is v511; its `cand` is v512; its `cand` is v513; its `cand` is v514; its `cand` is v515; its `cand` is v516
- a `cell` named c52 with coord 52 and row 2 and col 5 and mark 0; its `cand` is v521; its `cand` is v522; its `cand` is v523; its `cand` is v524; its `cand` is v525; its `cand` is v526
- a `cell` named c53 with coord 53 and row 3 and col 5 and mark 0; its `cand` is v531; its `cand` is v532; its `cand` is v533; its `cand` is v534; its `cand` is v535; its `cand` is v536
- a `cell` named c54 with coord 54 and row 4 and col 5 and mark 0; its `cand` is v541; its `cand` is v542; its `cand` is v543; its `cand` is v544; its `cand` is v545; its `cand` is v546
- a `cell` named c55 with coord 55 and row 5 and col 5 and mark 0; its `cand` is v551; its `cand` is v552; its `cand` is v553; its `cand` is v554; its `cand` is v555; its `cand` is v556
- a `cell` named c56 with coord 56 and row 6 and col 5 and mark 0; its `cand` is v561; its `cand` is v562; its `cand` is v563; its `cand` is v564; its `cand` is v565; its `cand` is v566
- a `cell` named c61 with coord 61 and row 1 and col 6 and mark 0; its `cand` is v611; its `cand` is v612; its `cand` is v613; its `cand` is v614; its `cand` is v615; its `cand` is v616
- a `cell` named c62 with coord 62 and row 2 and col 6 and mark 0; its `cand` is v621; its `cand` is v622; its `cand` is v623; its `cand` is v624; its `cand` is v625; its `cand` is v626
- a `cell` named c63 with coord 63 and row 3 and col 6 and mark 0; its `cand` is v631; its `cand` is v632; its `cand` is v633; its `cand` is v634; its `cand` is v635; its `cand` is v636
- a `cell` named c64 with coord 64 and row 4 and col 6 and mark 0; its `cand` is v641; its `cand` is v642; its `cand` is v643; its `cand` is v644; its `cand` is v645; its `cand` is v646
- a `cell` named c65 with coord 65 and row 5 and col 6 and mark 0; its `cand` is v651; its `cand` is v652; its `cand` is v653; its `cand` is v654; its `cand` is v655; its `cand` is v656
- a `cell` named c66 with coord 66 and row 6 and col 6 and mark 0; its `cand` is v661; its `cand` is v662; its `cand` is v663; its `cand` is v664; its `cand` is v665; its `cand` is v666
- a `cand` named v111 with cid 111 and coord 11 and row 1 and col 1 and value 1 and alive 1; its `in` is t3; its `in` is t5
- a `cand` named v112 with cid 112 and coord 11 and row 1 and col 1 and value 2 and alive 1
- a `cand` named v113 with cid 113 and coord 11 and row 1 and col 1 and value 3 and alive 1
- a `cand` named v114 with cid 114 and coord 11 and row 1 and col 1 and value 4 and alive 1; its `in` is t1; its `in` is t4
- a `cand` named v115 with cid 115 and coord 11 and row 1 and col 1 and value 5 and alive 1; its `in` is t0; its `in` is t2
- a `cand` named v116 with cid 116 and coord 11 and row 1 and col 1 and value 6 and alive 1
- a `cand` named v121 with cid 121 and coord 12 and row 2 and col 1 and value 1 and alive 1; its `in` is t2; its `in` is t4
- a `cand` named v122 with cid 122 and coord 12 and row 2 and col 1 and value 2 and alive 1
- a `cand` named v123 with cid 123 and coord 12 and row 2 and col 1 and value 3 and alive 1
- a `cand` named v124 with cid 124 and coord 12 and row 2 and col 1 and value 4 and alive 1; its `in` is t0; its `in` is t5
- a `cand` named v125 with cid 125 and coord 12 and row 2 and col 1 and value 5 and alive 1; its `in` is t1; its `in` is t3
- a `cand` named v126 with cid 126 and coord 12 and row 2 and col 1 and value 6 and alive 1
- a `cand` named v131 with cid 131 and coord 13 and row 3 and col 1 and value 1 and alive 1; its `in` is t0; its `in` is t1
- a `cand` named v132 with cid 132 and coord 13 and row 3 and col 1 and value 2 and alive 1
- a `cand` named v133 with cid 133 and coord 13 and row 3 and col 1 and value 3 and alive 1
- a `cand` named v134 with cid 134 and coord 13 and row 3 and col 1 and value 4 and alive 1; its `in` is t2; its `in` is t3
- a `cand` named v135 with cid 135 and coord 13 and row 3 and col 1 and value 5 and alive 1; its `in` is t4; its `in` is t5
- a `cand` named v136 with cid 136 and coord 13 and row 3 and col 1 and value 6 and alive 1
- a `cand` named v141 with cid 141 and coord 14 and row 4 and col 1 and value 1 and alive 1
- a `cand` named v142 with cid 142 and coord 14 and row 4 and col 1 and value 2 and alive 1
- a `cand` named v143 with cid 143 and coord 14 and row 4 and col 1 and value 3 and alive 1
- a `cand` named v144 with cid 144 and coord 14 and row 4 and col 1 and value 4 and alive 1
- a `cand` named v145 with cid 145 and coord 14 and row 4 and col 1 and value 5 and alive 1
- a `cand` named v146 with cid 146 and coord 14 and row 4 and col 1 and value 6 and alive 1; its `in` is t74
- a `cand` named v151 with cid 151 and coord 15 and row 5 and col 1 and value 1 and alive 1; its `in` is t117; its `in` is t119; its `in` is t124; its `in` is t126; its `in` is t130; its `in` is t132; its `in` is t139; its `in` is t141; its `in` is t143; its `in` is t145; its `in` is t149; its `in` is t151
- a `cand` named v152 with cid 152 and coord 15 and row 5 and col 1 and value 2 and alive 1; its `in` is t109; its `in` is t111; its `in` is t114; its `in` is t116; its `in` is t136; its `in` is t144; its `in` is t147; its `in` is t150
- a `cand` named v153 with cid 153 and coord 15 and row 5 and col 1 and value 3 and alive 1; its `in` is t105; its `in` is t108; its `in` is t128; its `in` is t131; its `in` is t135; its `in` is t138; its `in` is t142
- a `cand` named v154 with cid 154 and coord 15 and row 5 and col 1 and value 4 and alive 1; its `in` is t103; its `in` is t107; its `in` is t121; its `in` is t125; its `in` is t134; its `in` is t140
- a `cand` named v155 with cid 155 and coord 15 and row 5 and col 1 and value 5 and alive 1; its `in` is t101; its `in` is t102; its `in` is t104; its `in` is t110; its `in` is t113; its `in` is t118; its `in` is t120; its `in` is t122; its `in` is t123; its `in` is t127; its `in` is t129; its `in` is t146; its `in` is t148
- a `cand` named v156 with cid 156 and coord 15 and row 5 and col 1 and value 6 and alive 1; its `in` is t100; its `in` is t106; its `in` is t112; its `in` is t115; its `in` is t133; its `in` is t137
- a `cand` named v161 with cid 161 and coord 16 and row 6 and col 1 and value 1 and alive 1; its `in` is t112; its `in` is t113; its `in` is t120; its `in` is t121; its `in` is t127; its `in` is t128; its `in` is t133; its `in` is t134; its `in` is t135; its `in` is t136; its `in` is t146; its `in` is t147
- a `cand` named v162 with cid 162 and coord 16 and row 6 and col 1 and value 2 and alive 1; its `in` is t100; its `in` is t101; its `in` is t122; its `in` is t137; its `in` is t138; its `in` is t139; its `in` is t148; its `in` is t149
- a `cand` named v163 with cid 163 and coord 16 and row 6 and col 1 and value 3 and alive 1; its `in` is t102; its `in` is t103; its `in` is t114; its `in` is t129; its `in` is t130; its `in` is t140; its `in` is t141
- a `cand` named v164 with cid 164 and coord 16 and row 6 and col 1 and value 4 and alive 1; its `in` is t104; its `in` is t105; its `in` is t123; its `in` is t124; its `in` is t142; its `in` is t143
- a `cand` named v165 with cid 165 and coord 16 and row 6 and col 1 and value 5 and alive 1; its `in` is t106; its `in` is t107; its `in` is t108; its `in` is t109; its `in` is t115; its `in` is t116; its `in` is t117; its `in` is t125; its `in` is t126; its `in` is t131; its `in` is t132; its `in` is t150; its `in` is t151
- a `cand` named v166 with cid 166 and coord 16 and row 6 and col 1 and value 6 and alive 1; its `in` is t110; its `in` is t111; its `in` is t118; its `in` is t119; its `in` is t144; its `in` is t145
- a `cand` named v211 with cid 211 and coord 21 and row 1 and col 2 and value 1 and alive 1; its `in` is t21
- a `cand` named v212 with cid 212 and coord 21 and row 1 and col 2 and value 2 and alive 1; its `in` is t9; its `in` is t11; its `in` is t17; its `in` is t19; its `in` is t22
- a `cand` named v213 with cid 213 and coord 21 and row 1 and col 2 and value 3 and alive 1; its `in` is t16
- a `cand` named v214 with cid 214 and coord 21 and row 1 and col 2 and value 4 and alive 1; its `in` is t6; its `in` is t8; its `in` is t10; its `in` is t12; its `in` is t14; its `in` is t15; its `in` is t18; its `in` is t20; its `in` is t23
- a `cand` named v215 with cid 215 and coord 21 and row 1 and col 2 and value 5 and alive 1
- a `cand` named v216 with cid 216 and coord 21 and row 1 and col 2 and value 6 and alive 1; its `in` is t7; its `in` is t13
- a `cand` named v221 with cid 221 and coord 22 and row 2 and col 2 and value 1 and alive 1; its `in` is t20; its `in` is t23
- a `cand` named v222 with cid 222 and coord 22 and row 2 and col 2 and value 2 and alive 1; its `in` is t7; its `in` is t10; its `in` is t12; its `in` is t18
- a `cand` named v223 with cid 223 and coord 22 and row 2 and col 2 and value 3 and alive 1; its `in` is t8; its `in` is t15
- a `cand` named v224 with cid 224 and coord 22 and row 2 and col 2 and value 4 and alive 1; its `in` is t11; its `in` is t13; its `in` is t16; its `in` is t19; its `in` is t21; its `in` is t22
- a `cand` named v225 with cid 225 and coord 22 and row 2 and col 2 and value 5 and alive 1
- a `cand` named v226 with cid 226 and coord 22 and row 2 and col 2 and value 6 and alive 1; its `in` is t6; its `in` is t9; its `in` is t14; its `in` is t17
- a `cand` named v231 with cid 231 and coord 23 and row 3 and col 2 and value 1 and alive 1; its `in` is t53
- a `cand` named v232 with cid 232 and coord 23 and row 3 and col 2 and value 2 and alive 1
- a `cand` named v233 with cid 233 and coord 23 and row 3 and col 2 and value 3 and alive 1
- a `cand` named v234 with cid 234 and coord 23 and row 3 and col 2 and value 4 and alive 1
- a `cand` named v235 with cid 235 and coord 23 and row 3 and col 2 and value 5 and alive 1
- a `cand` named v236 with cid 236 and coord 23 and row 3 and col 2 and value 6 and alive 1; its `in` is t52
- a `cand` named v241 with cid 241 and coord 24 and row 4 and col 2 and value 1 and alive 1; its `in` is t52
- a `cand` named v242 with cid 242 and coord 24 and row 4 and col 2 and value 2 and alive 1
- a `cand` named v243 with cid 243 and coord 24 and row 4 and col 2 and value 3 and alive 1
- a `cand` named v244 with cid 244 and coord 24 and row 4 and col 2 and value 4 and alive 1
- a `cand` named v245 with cid 245 and coord 24 and row 4 and col 2 and value 5 and alive 1
- a `cand` named v246 with cid 246 and coord 24 and row 4 and col 2 and value 6 and alive 1; its `in` is t53
- a `cand` named v251 with cid 251 and coord 25 and row 5 and col 2 and value 1 and alive 1; its `in` is t115; its `in` is t118; its `in` is t123; its `in` is t125; its `in` is t129; its `in` is t131; its `in` is t137; its `in` is t140; its `in` is t142; its `in` is t144; its `in` is t148; its `in` is t150
- a `cand` named v252 with cid 252 and coord 25 and row 5 and col 2 and value 2 and alive 1; its `in` is t106; its `in` is t110; its `in` is t122; its `in` is t133; its `in` is t138; its `in` is t145; its `in` is t146; its `in` is t151
- a `cand` named v253 with cid 253 and coord 25 and row 5 and col 2 and value 3 and alive 1; its `in` is t104; its `in` is t107; its `in` is t116; its `in` is t127; its `in` is t132; its `in` is t134; its `in` is t143
- a `cand` named v254 with cid 254 and coord 25 and row 5 and col 2 and value 4 and alive 1; its `in` is t102; its `in` is t108; its `in` is t120; its `in` is t126; its `in` is t135; its `in` is t141
- a `cand` named v255 with cid 255 and coord 25 and row 5 and col 2 and value 5 and alive 1; its `in` is t100; its `in` is t103; its `in` is t105; its `in` is t111; its `in` is t112; its `in` is t114; its `in` is t119; its `in` is t121; its `in` is t124; its `in` is t128; its `in` is t130; its `in` is t147; its `in` is t149
- a `cand` named v256 with cid 256 and coord 25 and row 5 and col 2 and value 6 and alive 1; its `in` is t101; its `in` is t109; its `in` is t113; its `in` is t117; its `in` is t136; its `in` is t139
- a `cand` named v261 with cid 261 and coord 26 and row 6 and col 2 and value 1 and alive 1; its `in` is t100; its `in` is t101; its `in` is t102; its `in` is t103; its `in` is t104; its `in` is t105; its `in` is t106; its `in` is t107; its `in` is t108; its `in` is t109; its `in` is t110; its `in` is t111
- a `cand` named v262 with cid 262 and coord 26 and row 6 and col 2 and value 2 and alive 1; its `in` is t112; its `in` is t113; its `in` is t114; its `in` is t115; its `in` is t116; its `in` is t117; its `in` is t118; its `in` is t119
- a `cand` named v263 with cid 263 and coord 26 and row 6 and col 2 and value 3 and alive 1; its `in` is t120; its `in` is t121; its `in` is t122; its `in` is t123; its `in` is t124; its `in` is t125; its `in` is t126
- a `cand` named v264 with cid 264 and coord 26 and row 6 and col 2 and value 4 and alive 1; its `in` is t127; its `in` is t128; its `in` is t129; its `in` is t130; its `in` is t131; its `in` is t132
- a `cand` named v265 with cid 265 and coord 26 and row 6 and col 2 and value 5 and alive 1; its `in` is t133; its `in` is t134; its `in` is t135; its `in` is t136; its `in` is t137; its `in` is t138; its `in` is t139; its `in` is t140; its `in` is t141; its `in` is t142; its `in` is t143; its `in` is t144; its `in` is t145
- a `cand` named v266 with cid 266 and coord 26 and row 6 and col 2 and value 6 and alive 1; its `in` is t146; its `in` is t147; its `in` is t148; its `in` is t149; its `in` is t150; its `in` is t151
- a `cand` named v311 with cid 311 and coord 31 and row 1 and col 3 and value 1 and alive 1; its `in` is t29
- a `cand` named v312 with cid 312 and coord 31 and row 1 and col 3 and value 2 and alive 1; its `in` is t28
- a `cand` named v313 with cid 313 and coord 31 and row 1 and col 3 and value 3 and alive 1; its `in` is t27
- a `cand` named v314 with cid 314 and coord 31 and row 1 and col 3 and value 4 and alive 1; its `in` is t26
- a `cand` named v315 with cid 315 and coord 31 and row 1 and col 3 and value 5 and alive 1; its `in` is t25
- a `cand` named v316 with cid 316 and coord 31 and row 1 and col 3 and value 6 and alive 1; its `in` is t24
- a `cand` named v321 with cid 321 and coord 32 and row 2 and col 3 and value 1 and alive 1; its `in` is t13; its `in` is t14
- a `cand` named v322 with cid 322 and coord 32 and row 2 and col 3 and value 2 and alive 1; its `in` is t15; its `in` is t16; its `in` is t17; its `in` is t22
- a `cand` named v323 with cid 323 and coord 32 and row 2 and col 3 and value 3 and alive 1; its `in` is t18; its `in` is t19
- a `cand` named v324 with cid 324 and coord 32 and row 2 and col 3 and value 4 and alive 1; its `in` is t6; its `in` is t7; its `in` is t8; its `in` is t9; its `in` is t12; its `in` is t23
- a `cand` named v325 with cid 325 and coord 32 and row 2 and col 3 and value 5 and alive 1
- a `cand` named v326 with cid 326 and coord 32 and row 2 and col 3 and value 6 and alive 1; its `in` is t10; its `in` is t11; its `in` is t20; its `in` is t21
- a `cand` named v331 with cid 331 and coord 33 and row 3 and col 3 and value 1 and alive 1; its `in` is t6
- a `cand` named v332 with cid 332 and coord 33 and row 3 and col 3 and value 2 and alive 1; its `in` is t7; its `in` is t8; its `in` is t9; its `in` is t10; its `in` is t11
- a `cand` named v333 with cid 333 and coord 33 and row 3 and col 3 and value 3 and alive 1; its `in` is t12
- a `cand` named v334 with cid 334 and coord 33 and row 3 and col 3 and value 4 and alive 1; its `in` is t13; its `in` is t14; its `in` is t15; its `in` is t16; its `in` is t17; its `in` is t18; its `in` is t19; its `in` is t20; its `in` is t21
- a `cand` named v335 with cid 335 and coord 33 and row 3 and col 3 and value 5 and alive 1
- a `cand` named v336 with cid 336 and coord 33 and row 3 and col 3 and value 6 and alive 1; its `in` is t22; its `in` is t23
- a `cand` named v341 with cid 341 and coord 34 and row 4 and col 3 and value 1 and alive 1; its `in` is t77
- a `cand` named v342 with cid 342 and coord 34 and row 4 and col 3 and value 2 and alive 1; its `in` is t78
- a `cand` named v343 with cid 343 and coord 34 and row 4 and col 3 and value 3 and alive 1
- a `cand` named v344 with cid 344 and coord 34 and row 4 and col 3 and value 4 and alive 1
- a `cand` named v345 with cid 345 and coord 34 and row 4 and col 3 and value 5 and alive 1; its `in` is t75
- a `cand` named v346 with cid 346 and coord 34 and row 4 and col 3 and value 6 and alive 1; its `in` is t76
- a `cand` named v351 with cid 351 and coord 35 and row 5 and col 3 and value 1 and alive 1; its `in` is t75
- a `cand` named v352 with cid 352 and coord 35 and row 5 and col 3 and value 2 and alive 1; its `in` is t76
- a `cand` named v353 with cid 353 and coord 35 and row 5 and col 3 and value 3 and alive 1
- a `cand` named v354 with cid 354 and coord 35 and row 5 and col 3 and value 4 and alive 1
- a `cand` named v355 with cid 355 and coord 35 and row 5 and col 3 and value 5 and alive 1; its `in` is t77
- a `cand` named v356 with cid 356 and coord 35 and row 5 and col 3 and value 6 and alive 1; its `in` is t78
- a `cand` named v361 with cid 361 and coord 36 and row 6 and col 3 and value 1 and alive 1; its `in` is t153
- a `cand` named v362 with cid 362 and coord 36 and row 6 and col 3 and value 2 and alive 1; its `in` is t152; its `in` is t155
- a `cand` named v363 with cid 363 and coord 36 and row 6 and col 3 and value 3 and alive 1; its `in` is t154; its `in` is t157
- a `cand` named v364 with cid 364 and coord 36 and row 6 and col 3 and value 4 and alive 1; its `in` is t156; its `in` is t159
- a `cand` named v365 with cid 365 and coord 36 and row 6 and col 3 and value 5 and alive 1; its `in` is t158; its `in` is t161
- a `cand` named v366 with cid 366 and coord 36 and row 6 and col 3 and value 6 and alive 1; its `in` is t160
- a `cand` named v411 with cid 411 and coord 41 and row 1 and col 4 and value 1 and alive 1; its `in` is t24
- a `cand` named v412 with cid 412 and coord 41 and row 1 and col 4 and value 2 and alive 1; its `in` is t25
- a `cand` named v413 with cid 413 and coord 41 and row 1 and col 4 and value 3 and alive 1; its `in` is t26
- a `cand` named v414 with cid 414 and coord 41 and row 1 and col 4 and value 4 and alive 1; its `in` is t27
- a `cand` named v415 with cid 415 and coord 41 and row 1 and col 4 and value 5 and alive 1; its `in` is t28
- a `cand` named v416 with cid 416 and coord 41 and row 1 and col 4 and value 6 and alive 1; its `in` is t29
- a `cand` named v421 with cid 421 and coord 42 and row 2 and col 4 and value 1 and alive 1; its `in` is t37
- a `cand` named v422 with cid 422 and coord 42 and row 2 and col 4 and value 2 and alive 1; its `in` is t36; its `in` is t40
- a `cand` named v423 with cid 423 and coord 42 and row 2 and col 4 and value 3 and alive 1; its `in` is t41
- a `cand` named v424 with cid 424 and coord 42 and row 2 and col 4 and value 4 and alive 1; its `in` is t38
- a `cand` named v425 with cid 425 and coord 42 and row 2 and col 4 and value 5 and alive 1
- a `cand` named v426 with cid 426 and coord 42 and row 2 and col 4 and value 6 and alive 1; its `in` is t39
- a `cand` named v431 with cid 431 and coord 43 and row 3 and col 4 and value 1 and alive 1; its `in` is t69; its `in` is t73
- a `cand` named v432 with cid 432 and coord 43 and row 3 and col 4 and value 2 and alive 1; its `in` is t64; its `in` is t72
- a `cand` named v433 with cid 433 and coord 43 and row 3 and col 4 and value 3 and alive 1; its `in` is t60; its `in` is t63; its `in` is t68
- a `cand` named v434 with cid 434 and coord 43 and row 3 and col 4 and value 4 and alive 1; its `in` is t57; its `in` is t59; its `in` is t67; its `in` is t71
- a `cand` named v435 with cid 435 and coord 43 and row 3 and col 4 and value 5 and alive 1; its `in` is t55; its `in` is t58; its `in` is t62; its `in` is t66; its `in` is t70
- a `cand` named v436 with cid 436 and coord 43 and row 3 and col 4 and value 6 and alive 1; its `in` is t54; its `in` is t56; its `in` is t61; its `in` is t65
- a `cand` named v441 with cid 441 and coord 44 and row 4 and col 4 and value 1 and alive 1; its `in` is t82
- a `cand` named v442 with cid 442 and coord 44 and row 4 and col 4 and value 2 and alive 1; its `in` is t83
- a `cand` named v443 with cid 443 and coord 44 and row 4 and col 4 and value 3 and alive 1; its `in` is t84
- a `cand` named v444 with cid 444 and coord 44 and row 4 and col 4 and value 4 and alive 1; its `in` is t79
- a `cand` named v445 with cid 445 and coord 44 and row 4 and col 4 and value 5 and alive 1; its `in` is t80
- a `cand` named v446 with cid 446 and coord 44 and row 4 and col 4 and value 6 and alive 1; its `in` is t81
- a `cand` named v451 with cid 451 and coord 45 and row 5 and col 4 and value 1 and alive 1; its `in` is t79
- a `cand` named v452 with cid 452 and coord 45 and row 5 and col 4 and value 2 and alive 1; its `in` is t80
- a `cand` named v453 with cid 453 and coord 45 and row 5 and col 4 and value 3 and alive 1; its `in` is t81
- a `cand` named v454 with cid 454 and coord 45 and row 5 and col 4 and value 4 and alive 1; its `in` is t82
- a `cand` named v455 with cid 455 and coord 45 and row 5 and col 4 and value 5 and alive 1; its `in` is t83
- a `cand` named v456 with cid 456 and coord 45 and row 5 and col 4 and value 6 and alive 1; its `in` is t84
- a `cand` named v461 with cid 461 and coord 46 and row 6 and col 4 and value 1 and alive 1; its `in` is t152
- a `cand` named v462 with cid 462 and coord 46 and row 6 and col 4 and value 2 and alive 1; its `in` is t153; its `in` is t154
- a `cand` named v463 with cid 463 and coord 46 and row 6 and col 4 and value 3 and alive 1; its `in` is t155; its `in` is t156
- a `cand` named v464 with cid 464 and coord 46 and row 6 and col 4 and value 4 and alive 1; its `in` is t157; its `in` is t158
- a `cand` named v465 with cid 465 and coord 46 and row 6 and col 4 and value 5 and alive 1; its `in` is t159; its `in` is t160
- a `cand` named v466 with cid 466 and coord 46 and row 6 and col 4 and value 6 and alive 1; its `in` is t161
- a `cand` named v511 with cid 511 and coord 51 and row 1 and col 5 and value 1 and alive 1; its `in` is t33
- a `cand` named v512 with cid 512 and coord 51 and row 1 and col 5 and value 2 and alive 1; its `in` is t34
- a `cand` named v513 with cid 513 and coord 51 and row 1 and col 5 and value 3 and alive 1; its `in` is t35
- a `cand` named v514 with cid 514 and coord 51 and row 1 and col 5 and value 4 and alive 1; its `in` is t30
- a `cand` named v515 with cid 515 and coord 51 and row 1 and col 5 and value 5 and alive 1; its `in` is t31
- a `cand` named v516 with cid 516 and coord 51 and row 1 and col 5 and value 6 and alive 1; its `in` is t32
- a `cand` named v521 with cid 521 and coord 52 and row 2 and col 5 and value 1 and alive 1; its `in` is t36
- a `cand` named v522 with cid 522 and coord 52 and row 2 and col 5 and value 2 and alive 1; its `in` is t37; its `in` is t38
- a `cand` named v523 with cid 523 and coord 52 and row 2 and col 5 and value 3 and alive 1; its `in` is t39
- a `cand` named v524 with cid 524 and coord 52 and row 2 and col 5 and value 4 and alive 1; its `in` is t40
- a `cand` named v525 with cid 525 and coord 52 and row 2 and col 5 and value 5 and alive 1
- a `cand` named v526 with cid 526 and coord 52 and row 2 and col 5 and value 6 and alive 1; its `in` is t41
- a `cand` named v531 with cid 531 and coord 53 and row 3 and col 5 and value 1 and alive 1; its `in` is t65; its `in` is t70
- a `cand` named v532 with cid 532 and coord 53 and row 3 and col 5 and value 2 and alive 1; its `in` is t61; its `in` is t66; its `in` is t71
- a `cand` named v533 with cid 533 and coord 53 and row 3 and col 5 and value 3 and alive 1; its `in` is t62; its `in` is t67
- a `cand` named v534 with cid 534 and coord 53 and row 3 and col 5 and value 4 and alive 1; its `in` is t56; its `in` is t58; its `in` is t68; its `in` is t72
- a `cand` named v535 with cid 535 and coord 53 and row 3 and col 5 and value 5 and alive 1; its `in` is t54; its `in` is t59; its `in` is t63; its `in` is t73
- a `cand` named v536 with cid 536 and coord 53 and row 3 and col 5 and value 6 and alive 1; its `in` is t55; its `in` is t57; its `in` is t60; its `in` is t64; its `in` is t69
- a `cand` named v541 with cid 541 and coord 54 and row 4 and col 5 and value 1 and alive 1; its `in` is t54; its `in` is t55
- a `cand` named v542 with cid 542 and coord 54 and row 4 and col 5 and value 2 and alive 1; its `in` is t56; its `in` is t57
- a `cand` named v543 with cid 543 and coord 54 and row 4 and col 5 and value 3 and alive 1; its `in` is t58; its `in` is t59; its `in` is t60
- a `cand` named v544 with cid 544 and coord 54 and row 4 and col 5 and value 4 and alive 1; its `in` is t61; its `in` is t62; its `in` is t63; its `in` is t64
- a `cand` named v545 with cid 545 and coord 54 and row 4 and col 5 and value 5 and alive 1; its `in` is t65; its `in` is t66; its `in` is t67; its `in` is t68; its `in` is t69
- a `cand` named v546 with cid 546 and coord 54 and row 4 and col 5 and value 6 and alive 1; its `in` is t70; its `in` is t71; its `in` is t72; its `in` is t73
- a `cand` named v551 with cid 551 and coord 55 and row 5 and col 5 and value 1 and alive 1
- a `cand` named v552 with cid 552 and coord 55 and row 5 and col 5 and value 2 and alive 1; its `in` is t85; its `in` is t86
- a `cand` named v553 with cid 553 and coord 55 and row 5 and col 5 and value 3 and alive 1; its `in` is t87; its `in` is t88
- a `cand` named v554 with cid 554 and coord 55 and row 5 and col 5 and value 4 and alive 1; its `in` is t89; its `in` is t90; its `in` is t91
- a `cand` named v555 with cid 555 and coord 55 and row 5 and col 5 and value 5 and alive 1; its `in` is t92; its `in` is t93; its `in` is t94
- a `cand` named v556 with cid 556 and coord 55 and row 5 and col 5 and value 6 and alive 1; its `in` is t95; its `in` is t96; its `in` is t97; its `in` is t98; its `in` is t99
- a `cand` named v561 with cid 561 and coord 56 and row 6 and col 5 and value 1 and alive 1; its `in` is t167
- a `cand` named v562 with cid 562 and coord 56 and row 6 and col 5 and value 2 and alive 1; its `in` is t166
- a `cand` named v563 with cid 563 and coord 56 and row 6 and col 5 and value 3 and alive 1; its `in` is t165
- a `cand` named v564 with cid 564 and coord 56 and row 6 and col 5 and value 4 and alive 1; its `in` is t164
- a `cand` named v565 with cid 565 and coord 56 and row 6 and col 5 and value 5 and alive 1; its `in` is t163
- a `cand` named v566 with cid 566 and coord 56 and row 6 and col 5 and value 6 and alive 1; its `in` is t162
- a `cand` named v611 with cid 611 and coord 61 and row 1 and col 6 and value 1 and alive 1; its `in` is t30
- a `cand` named v612 with cid 612 and coord 61 and row 1 and col 6 and value 2 and alive 1; its `in` is t31
- a `cand` named v613 with cid 613 and coord 61 and row 1 and col 6 and value 3 and alive 1; its `in` is t32
- a `cand` named v614 with cid 614 and coord 61 and row 1 and col 6 and value 4 and alive 1; its `in` is t33
- a `cand` named v615 with cid 615 and coord 61 and row 1 and col 6 and value 5 and alive 1; its `in` is t34
- a `cand` named v616 with cid 616 and coord 61 and row 1 and col 6 and value 6 and alive 1; its `in` is t35
- a `cand` named v621 with cid 621 and coord 62 and row 2 and col 6 and value 1 and alive 1; its `in` is t43
- a `cand` named v622 with cid 622 and coord 62 and row 2 and col 6 and value 2 and alive 1; its `in` is t42; its `in` is t45
- a `cand` named v623 with cid 623 and coord 62 and row 2 and col 6 and value 3 and alive 1; its `in` is t44; its `in` is t47
- a `cand` named v624 with cid 624 and coord 62 and row 2 and col 6 and value 4 and alive 1; its `in` is t46; its `in` is t49
- a `cand` named v625 with cid 625 and coord 62 and row 2 and col 6 and value 5 and alive 1; its `in` is t48; its `in` is t51
- a `cand` named v626 with cid 626 and coord 62 and row 2 and col 6 and value 6 and alive 1; its `in` is t50
- a `cand` named v631 with cid 631 and coord 63 and row 3 and col 6 and value 1 and alive 1; its `in` is t42
- a `cand` named v632 with cid 632 and coord 63 and row 3 and col 6 and value 2 and alive 1; its `in` is t43; its `in` is t44
- a `cand` named v633 with cid 633 and coord 63 and row 3 and col 6 and value 3 and alive 1; its `in` is t45; its `in` is t46
- a `cand` named v634 with cid 634 and coord 63 and row 3 and col 6 and value 4 and alive 1; its `in` is t47; its `in` is t48
- a `cand` named v635 with cid 635 and coord 63 and row 3 and col 6 and value 5 and alive 1; its `in` is t49; its `in` is t50
- a `cand` named v636 with cid 636 and coord 63 and row 3 and col 6 and value 6 and alive 1; its `in` is t51
- a `cand` named v641 with cid 641 and coord 64 and row 4 and col 6 and value 1 and alive 1
- a `cand` named v642 with cid 642 and coord 64 and row 4 and col 6 and value 2 and alive 1; its `in` is t94; its `in` is t99
- a `cand` named v643 with cid 643 and coord 64 and row 4 and col 6 and value 3 and alive 1; its `in` is t91; its `in` is t98
- a `cand` named v644 with cid 644 and coord 64 and row 4 and col 6 and value 4 and alive 1; its `in` is t88; its `in` is t90; its `in` is t97
- a `cand` named v645 with cid 645 and coord 64 and row 4 and col 6 and value 5 and alive 1; its `in` is t86; its `in` is t93; its `in` is t96
- a `cand` named v646 with cid 646 and coord 64 and row 4 and col 6 and value 6 and alive 1; its `in` is t85; its `in` is t87; its `in` is t89; its `in` is t92; its `in` is t95
- a `cand` named v651 with cid 651 and coord 65 and row 5 and col 6 and value 1 and alive 1; its `in` is t95
- a `cand` named v652 with cid 652 and coord 65 and row 5 and col 6 and value 2 and alive 1; its `in` is t92; its `in` is t96
- a `cand` named v653 with cid 653 and coord 65 and row 5 and col 6 and value 3 and alive 1; its `in` is t89; its `in` is t93; its `in` is t97
- a `cand` named v654 with cid 654 and coord 65 and row 5 and col 6 and value 4 and alive 1; its `in` is t87; its `in` is t98
- a `cand` named v655 with cid 655 and coord 65 and row 5 and col 6 and value 5 and alive 1; its `in` is t85; its `in` is t90; its `in` is t99
- a `cand` named v656 with cid 656 and coord 65 and row 5 and col 6 and value 6 and alive 1; its `in` is t86; its `in` is t88; its `in` is t91; its `in` is t94
- a `cand` named v661 with cid 661 and coord 66 and row 6 and col 6 and value 1 and alive 1; its `in` is t162
- a `cand` named v662 with cid 662 and coord 66 and row 6 and col 6 and value 2 and alive 1; its `in` is t163
- a `cand` named v663 with cid 663 and coord 66 and row 6 and col 6 and value 3 and alive 1; its `in` is t164
- a `cand` named v664 with cid 664 and coord 66 and row 6 and col 6 and value 4 and alive 1; its `in` is t165
- a `cand` named v665 with cid 665 and coord 66 and row 6 and col 6 and value 5 and alive 1; its `in` is t166
- a `cand` named v666 with cid 666 and coord 66 and row 6 and col 6 and value 6 and alive 1; its `in` is t167
- a `tuple` named t0 with tid 0 and alive 1; its `uses` is v115; its `uses` is v124; its `uses` is v131
- a `tuple` named t1 with tid 1 and alive 1; its `uses` is v114; its `uses` is v125; its `uses` is v131
- a `tuple` named t2 with tid 2 and alive 1; its `uses` is v115; its `uses` is v121; its `uses` is v134
- a `tuple` named t3 with tid 3 and alive 1; its `uses` is v111; its `uses` is v125; its `uses` is v134
- a `tuple` named t4 with tid 4 and alive 1; its `uses` is v114; its `uses` is v121; its `uses` is v135
- a `tuple` named t5 with tid 5 and alive 1; its `uses` is v111; its `uses` is v124; its `uses` is v135
- a `tuple` named t6 with tid 6 and alive 1; its `uses` is v214; its `uses` is v226; its `uses` is v324; its `uses` is v331
- a `tuple` named t7 with tid 7 and alive 1; its `uses` is v216; its `uses` is v222; its `uses` is v324; its `uses` is v332
- a `tuple` named t8 with tid 8 and alive 1; its `uses` is v214; its `uses` is v223; its `uses` is v324; its `uses` is v332
- a `tuple` named t9 with tid 9 and alive 1; its `uses` is v212; its `uses` is v226; its `uses` is v324; its `uses` is v332
- a `tuple` named t10 with tid 10 and alive 1; its `uses` is v214; its `uses` is v222; its `uses` is v326; its `uses` is v332
- a `tuple` named t11 with tid 11 and alive 1; its `uses` is v212; its `uses` is v224; its `uses` is v326; its `uses` is v332
- a `tuple` named t12 with tid 12 and alive 1; its `uses` is v214; its `uses` is v222; its `uses` is v324; its `uses` is v333
- a `tuple` named t13 with tid 13 and alive 1; its `uses` is v216; its `uses` is v224; its `uses` is v321; its `uses` is v334
- a `tuple` named t14 with tid 14 and alive 1; its `uses` is v214; its `uses` is v226; its `uses` is v321; its `uses` is v334
- a `tuple` named t15 with tid 15 and alive 1; its `uses` is v214; its `uses` is v223; its `uses` is v322; its `uses` is v334
- a `tuple` named t16 with tid 16 and alive 1; its `uses` is v213; its `uses` is v224; its `uses` is v322; its `uses` is v334
- a `tuple` named t17 with tid 17 and alive 1; its `uses` is v212; its `uses` is v226; its `uses` is v322; its `uses` is v334
- a `tuple` named t18 with tid 18 and alive 1; its `uses` is v214; its `uses` is v222; its `uses` is v323; its `uses` is v334
- a `tuple` named t19 with tid 19 and alive 1; its `uses` is v212; its `uses` is v224; its `uses` is v323; its `uses` is v334
- a `tuple` named t20 with tid 20 and alive 1; its `uses` is v214; its `uses` is v221; its `uses` is v326; its `uses` is v334
- a `tuple` named t21 with tid 21 and alive 1; its `uses` is v211; its `uses` is v224; its `uses` is v326; its `uses` is v334
- a `tuple` named t22 with tid 22 and alive 1; its `uses` is v212; its `uses` is v224; its `uses` is v322; its `uses` is v336
- a `tuple` named t23 with tid 23 and alive 1; its `uses` is v214; its `uses` is v221; its `uses` is v324; its `uses` is v336
- a `tuple` named t24 with tid 24 and alive 1; its `uses` is v316; its `uses` is v411
- a `tuple` named t25 with tid 25 and alive 1; its `uses` is v315; its `uses` is v412
- a `tuple` named t26 with tid 26 and alive 1; its `uses` is v314; its `uses` is v413
- a `tuple` named t27 with tid 27 and alive 1; its `uses` is v313; its `uses` is v414
- a `tuple` named t28 with tid 28 and alive 1; its `uses` is v312; its `uses` is v415
- a `tuple` named t29 with tid 29 and alive 1; its `uses` is v311; its `uses` is v416
- a `tuple` named t30 with tid 30 and alive 1; its `uses` is v514; its `uses` is v611
- a `tuple` named t31 with tid 31 and alive 1; its `uses` is v515; its `uses` is v612
- a `tuple` named t32 with tid 32 and alive 1; its `uses` is v516; its `uses` is v613
- a `tuple` named t33 with tid 33 and alive 1; its `uses` is v511; its `uses` is v614
- a `tuple` named t34 with tid 34 and alive 1; its `uses` is v512; its `uses` is v615
- a `tuple` named t35 with tid 35 and alive 1; its `uses` is v513; its `uses` is v616
- a `tuple` named t36 with tid 36 and alive 1; its `uses` is v422; its `uses` is v521
- a `tuple` named t37 with tid 37 and alive 1; its `uses` is v421; its `uses` is v522
- a `tuple` named t38 with tid 38 and alive 1; its `uses` is v424; its `uses` is v522
- a `tuple` named t39 with tid 39 and alive 1; its `uses` is v426; its `uses` is v523
- a `tuple` named t40 with tid 40 and alive 1; its `uses` is v422; its `uses` is v524
- a `tuple` named t41 with tid 41 and alive 1; its `uses` is v423; its `uses` is v526
- a `tuple` named t42 with tid 42 and alive 1; its `uses` is v622; its `uses` is v631
- a `tuple` named t43 with tid 43 and alive 1; its `uses` is v621; its `uses` is v632
- a `tuple` named t44 with tid 44 and alive 1; its `uses` is v623; its `uses` is v632
- a `tuple` named t45 with tid 45 and alive 1; its `uses` is v622; its `uses` is v633
- a `tuple` named t46 with tid 46 and alive 1; its `uses` is v624; its `uses` is v633
- a `tuple` named t47 with tid 47 and alive 1; its `uses` is v623; its `uses` is v634
- a `tuple` named t48 with tid 48 and alive 1; its `uses` is v625; its `uses` is v634
- a `tuple` named t49 with tid 49 and alive 1; its `uses` is v624; its `uses` is v635
- a `tuple` named t50 with tid 50 and alive 1; its `uses` is v626; its `uses` is v635
- a `tuple` named t51 with tid 51 and alive 1; its `uses` is v625; its `uses` is v636
- a `tuple` named t52 with tid 52 and alive 1; its `uses` is v236; its `uses` is v241
- a `tuple` named t53 with tid 53 and alive 1; its `uses` is v231; its `uses` is v246
- a `tuple` named t54 with tid 54 and alive 1; its `uses` is v436; its `uses` is v535; its `uses` is v541
- a `tuple` named t55 with tid 55 and alive 1; its `uses` is v435; its `uses` is v536; its `uses` is v541
- a `tuple` named t56 with tid 56 and alive 1; its `uses` is v436; its `uses` is v534; its `uses` is v542
- a `tuple` named t57 with tid 57 and alive 1; its `uses` is v434; its `uses` is v536; its `uses` is v542
- a `tuple` named t58 with tid 58 and alive 1; its `uses` is v435; its `uses` is v534; its `uses` is v543
- a `tuple` named t59 with tid 59 and alive 1; its `uses` is v434; its `uses` is v535; its `uses` is v543
- a `tuple` named t60 with tid 60 and alive 1; its `uses` is v433; its `uses` is v536; its `uses` is v543
- a `tuple` named t61 with tid 61 and alive 1; its `uses` is v436; its `uses` is v532; its `uses` is v544
- a `tuple` named t62 with tid 62 and alive 1; its `uses` is v435; its `uses` is v533; its `uses` is v544
- a `tuple` named t63 with tid 63 and alive 1; its `uses` is v433; its `uses` is v535; its `uses` is v544
- a `tuple` named t64 with tid 64 and alive 1; its `uses` is v432; its `uses` is v536; its `uses` is v544
- a `tuple` named t65 with tid 65 and alive 1; its `uses` is v436; its `uses` is v531; its `uses` is v545
- a `tuple` named t66 with tid 66 and alive 1; its `uses` is v435; its `uses` is v532; its `uses` is v545
- a `tuple` named t67 with tid 67 and alive 1; its `uses` is v434; its `uses` is v533; its `uses` is v545
- a `tuple` named t68 with tid 68 and alive 1; its `uses` is v433; its `uses` is v534; its `uses` is v545
- a `tuple` named t69 with tid 69 and alive 1; its `uses` is v431; its `uses` is v536; its `uses` is v545
- a `tuple` named t70 with tid 70 and alive 1; its `uses` is v435; its `uses` is v531; its `uses` is v546
- a `tuple` named t71 with tid 71 and alive 1; its `uses` is v434; its `uses` is v532; its `uses` is v546
- a `tuple` named t72 with tid 72 and alive 1; its `uses` is v432; its `uses` is v534; its `uses` is v546
- a `tuple` named t73 with tid 73 and alive 1; its `uses` is v431; its `uses` is v535; its `uses` is v546
- a `tuple` named t74 with tid 74 and alive 1; its `uses` is v146
- a `tuple` named t75 with tid 75 and alive 1; its `uses` is v345; its `uses` is v351
- a `tuple` named t76 with tid 76 and alive 1; its `uses` is v346; its `uses` is v352
- a `tuple` named t77 with tid 77 and alive 1; its `uses` is v341; its `uses` is v355
- a `tuple` named t78 with tid 78 and alive 1; its `uses` is v342; its `uses` is v356
- a `tuple` named t79 with tid 79 and alive 1; its `uses` is v444; its `uses` is v451
- a `tuple` named t80 with tid 80 and alive 1; its `uses` is v445; its `uses` is v452
- a `tuple` named t81 with tid 81 and alive 1; its `uses` is v446; its `uses` is v453
- a `tuple` named t82 with tid 82 and alive 1; its `uses` is v441; its `uses` is v454
- a `tuple` named t83 with tid 83 and alive 1; its `uses` is v442; its `uses` is v455
- a `tuple` named t84 with tid 84 and alive 1; its `uses` is v443; its `uses` is v456
- a `tuple` named t85 with tid 85 and alive 1; its `uses` is v646; its `uses` is v655; its `uses` is v552
- a `tuple` named t86 with tid 86 and alive 1; its `uses` is v645; its `uses` is v656; its `uses` is v552
- a `tuple` named t87 with tid 87 and alive 1; its `uses` is v646; its `uses` is v654; its `uses` is v553
- a `tuple` named t88 with tid 88 and alive 1; its `uses` is v644; its `uses` is v656; its `uses` is v553
- a `tuple` named t89 with tid 89 and alive 1; its `uses` is v646; its `uses` is v653; its `uses` is v554
- a `tuple` named t90 with tid 90 and alive 1; its `uses` is v644; its `uses` is v655; its `uses` is v554
- a `tuple` named t91 with tid 91 and alive 1; its `uses` is v643; its `uses` is v656; its `uses` is v554
- a `tuple` named t92 with tid 92 and alive 1; its `uses` is v646; its `uses` is v652; its `uses` is v555
- a `tuple` named t93 with tid 93 and alive 1; its `uses` is v645; its `uses` is v653; its `uses` is v555
- a `tuple` named t94 with tid 94 and alive 1; its `uses` is v642; its `uses` is v656; its `uses` is v555
- a `tuple` named t95 with tid 95 and alive 1; its `uses` is v646; its `uses` is v651; its `uses` is v556
- a `tuple` named t96 with tid 96 and alive 1; its `uses` is v645; its `uses` is v652; its `uses` is v556
- a `tuple` named t97 with tid 97 and alive 1; its `uses` is v644; its `uses` is v653; its `uses` is v556
- a `tuple` named t98 with tid 98 and alive 1; its `uses` is v643; its `uses` is v654; its `uses` is v556
- a `tuple` named t99 with tid 99 and alive 1; its `uses` is v642; its `uses` is v655; its `uses` is v556
- a `tuple` named t100 with tid 100 and alive 1; its `uses` is v156; its `uses` is v255; its `uses` is v162; its `uses` is v261
- a `tuple` named t101 with tid 101 and alive 1; its `uses` is v155; its `uses` is v256; its `uses` is v162; its `uses` is v261
- a `tuple` named t102 with tid 102 and alive 1; its `uses` is v155; its `uses` is v254; its `uses` is v163; its `uses` is v261
- a `tuple` named t103 with tid 103 and alive 1; its `uses` is v154; its `uses` is v255; its `uses` is v163; its `uses` is v261
- a `tuple` named t104 with tid 104 and alive 1; its `uses` is v155; its `uses` is v253; its `uses` is v164; its `uses` is v261
- a `tuple` named t105 with tid 105 and alive 1; its `uses` is v153; its `uses` is v255; its `uses` is v164; its `uses` is v261
- a `tuple` named t106 with tid 106 and alive 1; its `uses` is v156; its `uses` is v252; its `uses` is v165; its `uses` is v261
- a `tuple` named t107 with tid 107 and alive 1; its `uses` is v154; its `uses` is v253; its `uses` is v165; its `uses` is v261
- a `tuple` named t108 with tid 108 and alive 1; its `uses` is v153; its `uses` is v254; its `uses` is v165; its `uses` is v261
- a `tuple` named t109 with tid 109 and alive 1; its `uses` is v152; its `uses` is v256; its `uses` is v165; its `uses` is v261
- a `tuple` named t110 with tid 110 and alive 1; its `uses` is v155; its `uses` is v252; its `uses` is v166; its `uses` is v261
- a `tuple` named t111 with tid 111 and alive 1; its `uses` is v152; its `uses` is v255; its `uses` is v166; its `uses` is v261
- a `tuple` named t112 with tid 112 and alive 1; its `uses` is v156; its `uses` is v255; its `uses` is v161; its `uses` is v262
- a `tuple` named t113 with tid 113 and alive 1; its `uses` is v155; its `uses` is v256; its `uses` is v161; its `uses` is v262
- a `tuple` named t114 with tid 114 and alive 1; its `uses` is v152; its `uses` is v255; its `uses` is v163; its `uses` is v262
- a `tuple` named t115 with tid 115 and alive 1; its `uses` is v156; its `uses` is v251; its `uses` is v165; its `uses` is v262
- a `tuple` named t116 with tid 116 and alive 1; its `uses` is v152; its `uses` is v253; its `uses` is v165; its `uses` is v262
- a `tuple` named t117 with tid 117 and alive 1; its `uses` is v151; its `uses` is v256; its `uses` is v165; its `uses` is v262
- a `tuple` named t118 with tid 118 and alive 1; its `uses` is v155; its `uses` is v251; its `uses` is v166; its `uses` is v262
- a `tuple` named t119 with tid 119 and alive 1; its `uses` is v151; its `uses` is v255; its `uses` is v166; its `uses` is v262
- a `tuple` named t120 with tid 120 and alive 1; its `uses` is v155; its `uses` is v254; its `uses` is v161; its `uses` is v263
- a `tuple` named t121 with tid 121 and alive 1; its `uses` is v154; its `uses` is v255; its `uses` is v161; its `uses` is v263
- a `tuple` named t122 with tid 122 and alive 1; its `uses` is v155; its `uses` is v252; its `uses` is v162; its `uses` is v263
- a `tuple` named t123 with tid 123 and alive 1; its `uses` is v155; its `uses` is v251; its `uses` is v164; its `uses` is v263
- a `tuple` named t124 with tid 124 and alive 1; its `uses` is v151; its `uses` is v255; its `uses` is v164; its `uses` is v263
- a `tuple` named t125 with tid 125 and alive 1; its `uses` is v154; its `uses` is v251; its `uses` is v165; its `uses` is v263
- a `tuple` named t126 with tid 126 and alive 1; its `uses` is v151; its `uses` is v254; its `uses` is v165; its `uses` is v263
- a `tuple` named t127 with tid 127 and alive 1; its `uses` is v155; its `uses` is v253; its `uses` is v161; its `uses` is v264
- a `tuple` named t128 with tid 128 and alive 1; its `uses` is v153; its `uses` is v255; its `uses` is v161; its `uses` is v264
- a `tuple` named t129 with tid 129 and alive 1; its `uses` is v155; its `uses` is v251; its `uses` is v163; its `uses` is v264
- a `tuple` named t130 with tid 130 and alive 1; its `uses` is v151; its `uses` is v255; its `uses` is v163; its `uses` is v264
- a `tuple` named t131 with tid 131 and alive 1; its `uses` is v153; its `uses` is v251; its `uses` is v165; its `uses` is v264
- a `tuple` named t132 with tid 132 and alive 1; its `uses` is v151; its `uses` is v253; its `uses` is v165; its `uses` is v264
- a `tuple` named t133 with tid 133 and alive 1; its `uses` is v156; its `uses` is v252; its `uses` is v161; its `uses` is v265
- a `tuple` named t134 with tid 134 and alive 1; its `uses` is v154; its `uses` is v253; its `uses` is v161; its `uses` is v265
- a `tuple` named t135 with tid 135 and alive 1; its `uses` is v153; its `uses` is v254; its `uses` is v161; its `uses` is v265
- a `tuple` named t136 with tid 136 and alive 1; its `uses` is v152; its `uses` is v256; its `uses` is v161; its `uses` is v265
- a `tuple` named t137 with tid 137 and alive 1; its `uses` is v156; its `uses` is v251; its `uses` is v162; its `uses` is v265
- a `tuple` named t138 with tid 138 and alive 1; its `uses` is v153; its `uses` is v252; its `uses` is v162; its `uses` is v265
- a `tuple` named t139 with tid 139 and alive 1; its `uses` is v151; its `uses` is v256; its `uses` is v162; its `uses` is v265
- a `tuple` named t140 with tid 140 and alive 1; its `uses` is v154; its `uses` is v251; its `uses` is v163; its `uses` is v265
- a `tuple` named t141 with tid 141 and alive 1; its `uses` is v151; its `uses` is v254; its `uses` is v163; its `uses` is v265
- a `tuple` named t142 with tid 142 and alive 1; its `uses` is v153; its `uses` is v251; its `uses` is v164; its `uses` is v265
- a `tuple` named t143 with tid 143 and alive 1; its `uses` is v151; its `uses` is v253; its `uses` is v164; its `uses` is v265
- a `tuple` named t144 with tid 144 and alive 1; its `uses` is v152; its `uses` is v251; its `uses` is v166; its `uses` is v265
- a `tuple` named t145 with tid 145 and alive 1; its `uses` is v151; its `uses` is v252; its `uses` is v166; its `uses` is v265
- a `tuple` named t146 with tid 146 and alive 1; its `uses` is v155; its `uses` is v252; its `uses` is v161; its `uses` is v266
- a `tuple` named t147 with tid 147 and alive 1; its `uses` is v152; its `uses` is v255; its `uses` is v161; its `uses` is v266
- a `tuple` named t148 with tid 148 and alive 1; its `uses` is v155; its `uses` is v251; its `uses` is v162; its `uses` is v266
- a `tuple` named t149 with tid 149 and alive 1; its `uses` is v151; its `uses` is v255; its `uses` is v162; its `uses` is v266
- a `tuple` named t150 with tid 150 and alive 1; its `uses` is v152; its `uses` is v251; its `uses` is v165; its `uses` is v266
- a `tuple` named t151 with tid 151 and alive 1; its `uses` is v151; its `uses` is v252; its `uses` is v165; its `uses` is v266
- a `tuple` named t152 with tid 152 and alive 1; its `uses` is v362; its `uses` is v461
- a `tuple` named t153 with tid 153 and alive 1; its `uses` is v361; its `uses` is v462
- a `tuple` named t154 with tid 154 and alive 1; its `uses` is v363; its `uses` is v462
- a `tuple` named t155 with tid 155 and alive 1; its `uses` is v362; its `uses` is v463
- a `tuple` named t156 with tid 156 and alive 1; its `uses` is v364; its `uses` is v463
- a `tuple` named t157 with tid 157 and alive 1; its `uses` is v363; its `uses` is v464
- a `tuple` named t158 with tid 158 and alive 1; its `uses` is v365; its `uses` is v464
- a `tuple` named t159 with tid 159 and alive 1; its `uses` is v364; its `uses` is v465
- a `tuple` named t160 with tid 160 and alive 1; its `uses` is v366; its `uses` is v465
- a `tuple` named t161 with tid 161 and alive 1; its `uses` is v365; its `uses` is v466
- a `tuple` named t162 with tid 162 and alive 1; its `uses` is v566; its `uses` is v661
- a `tuple` named t163 with tid 163 and alive 1; its `uses` is v565; its `uses` is v662
- a `tuple` named t164 with tid 164 and alive 1; its `uses` is v564; its `uses` is v663
- a `tuple` named t165 with tid 165 and alive 1; its `uses` is v563; its `uses` is v664
- a `tuple` named t166 with tid 166 and alive 1; its `uses` is v562; its `uses` is v665
- a `tuple` named t167 with tid 167 and alive 1; its `uses` is v561; its `uses` is v666
- a `puzzle` named puzzle with pid 1 and marks 0 and gcell 0
Links between objects never change.

**Failure state.** A state is a failure state when some cell has self.mark = 0 and no cand that self.cand points to have alive = 1 (with `self` the cell). an undecided cell has no candidate left

**Failure state.** A state is a failure state when some cell has self.mark ≠ 0 and no cand that self.cand points to have value = self.mark and alive = 1 (with `self` the cell). a decided cell's number has been dropped

**Goal.** Some puzzle has marks 36. When the goal holds in the task state, the agent reports success and halts.

## Operators

An operator's changes are made together: every value on the right is read before any change.

**assign(p: puzzle, c: cell, x: cand).** Proposed when c.mark = 0 and c.cand is x and x.alive = 1. Decide a cell's number.
- and when one of these holds: no cand that c.cand points to have alive = 1 and value ≠ x.value; or no cand has row = c.row and value = x.value and alive = 1 and coord ≠ c.coord; or no cand has col = c.col and value = x.value and alive = 1 and coord ≠ c.coord.
- Effect: c.mark := x.value; p.marks := p.marks + 1; writes "Set cell: ⟨c.coord⟩ to ⟨x.value⟩".

**cleanup(c: cell, z: cand).** Proposed when c.mark ≠ 0 and c.cand is z and z.alive = 1 and z.value ≠ c.mark.
- Effect: z.alive := 0.

**eliminate(c1: cell, c2: cell, y: cand).** Proposed when c1.mark ≠ 0 and c1 and c2 are different objects and c2.cand is y and y.alive = 1 and y.value = c1.mark.
- and when one of these holds: c2.row = c1.row; or c2.col = c1.col.
- Effect: y.alive := 0.

**drop-tuple(t: tuple, x: cand).** Proposed when t.alive = 1 and t.uses is x and x.alive = 0.
- Effect: t.alive := 0.

**prune(x: cand).** Proposed when x.alive = 1 and no tuple that x.in points to have alive = 1.
- Effect: x.alive := 0.

**choose-cell(p: puzzle, c: cell).** Proposed when p.gcell = 0 and c.mark = 0 and at least 2 cands that c.cand points to have alive = 1 and fewer than 3 cands that c.cand points to have alive = 1.
- Effect: p.gcell := c.coord; writes "Guess cell: ⟨c.coord⟩".

**choose-cell-3(p: puzzle, c: cell).** Proposed when p.gcell = 0 and c.mark = 0 and at least 3 cands that c.cand points to have alive = 1 and fewer than 4 cands that c.cand points to have alive = 1.
- Effect: p.gcell := c.coord; writes "Guess cell: ⟨c.coord⟩".

**guess(p: puzzle, c: cell, x: cand).** Proposed when p.gcell = c.coord and c.cand is x and x.alive = 1.
- Effect: c.mark := x.value; p.marks := p.marks + 1; p.gcell := 0; writes "Guess: ⟨c.coord⟩ is ⟨x.value⟩".

## Choosing among proposed operators

When several operators are proposed, the agent tries each one in an internal copy of the state (look-ahead search, Soar's default selection library) and prefers those that lead to the goal. Returning to an earlier state is not detected.
A failure state reached in look-ahead is a failure: the operator leading to it is rejected.

The agent remembers the last task operator applied (its name and parameters). Search-control preferences:
- **choose-cell-last**: a proposed choose-cell whose  is worst. Only when propagation has stopped.
- **choose-cell-3-last**: a proposed choose-cell-3 whose  is worst. Only when propagation has stopped.
- **two-before-three**: a proposed choose-cell whose  is better than a proposed choose-cell-3.

## Learning

Chunking on (`chunk always`).

## Assumptions (added; not in the task description)

- **A1** [open] The task: solve one KenKen puzzle (an n × n Latin square whose cages give their values under their operations); one variant per puzzle of V1 (its sixteen boards), instead of V1's one agent that works through the boards in turn. The harness runs them in V1's order.
- **A2** [open] Each cell has one candidate object per number (alive or dropped) instead of a set of legal values; a decided cell has a mark. Propagation: decide a cell with one live candidate or with a number no other cell of its row or column can take (the originals' mark-single-value and notice-single-column-row-value); drop the other candidates of a decided cell; drop a decided number from the cell's row and column (remove-column-row-values).
- **A3** [open] Cage arithmetic: each cage's tuples of values that satisfy it are computed from the cage and made objects (as the originals' number tables are written out); a tuple that uses a dropped candidate is dropped, and a candidate no live tuple of its cage uses is dropped. This replaces the originals' check-group substate (two-cell cages against the number tables), the subgroups made when a cell of a larger cage is decided, and the linear-sum groups; it is complete for each cage on its own (generalised arc consistency), so it can narrow more than the originals.
- **A4** [open] Guessing as in V1: when propagation stops, choose an undecided cell with two live candidates (else three), then guess its number; the guesses tie and look-ahead in the selection space evaluates them (Soar's default library), a state with an undecided cell without candidates, or a decided cell whose number has been dropped, being a failure (without the second, two cells of a row decided the same number went unnoticed, a wrong guess reached the goal, and one run of 6-3 ended with 12 wrong cells). Chunking is on, with V1's `chunk allow-local-negations off` (with local negations on, building the first look-ahead chunk did not finish). Duplicate states are not checked (propagation never repeats a state).
- **A5** [open] Output: each decided cell is written (Set cell / Guess); the originals' board printing (print-board, print-row) is left out.
- **A6** [open] V2 (one 4 × 4 board, the same propagation without guessing, check-group with a substate) is not given its own variant: it loops after solving (state no-change at the goal, no halt). Its board is V1's 4-3, variant kenken-4-3.
