# Knight's tour — step 6

Lean: `agentgen/Agent/Families/Knights.lean`.

Variants:
- `knights-6` (6 × 6, V2's strategy level-5) replaces knights V2.
- `knights-8` (8 × 8, V1's strategy level-3) replaces knights V1.

The task: count closed knight's tours from square 23 by depth-first search with backtracking, within a move budget.

## Structure

Operators:
- `knight-move`: to an unused square a move away, not yet tried from here.
- `backup`: at a dead end, after a tour, or when a strategy prunes. It frees the square and marks it tried from the square below.
- `detect-goal`: counts a closed tour.
- `exhausted`: back at the first square with nothing left to try.
- `finish-run`: the budget is spent.

Search control is a set of preferences:
- finish-run > everything; detect-goal > backup > knight-move.
- Lower degree first (V2) or lower original degree first (V1).
- A square with one exit is best (V2).

Pruning comes from alternative proposals of `backup` (`proposeOr`):
- dead end;
- after a tour;
- two neighbours with one exit each;
- a one-exit square already tried (V2).

New general DSL features, with every earlier family's output unchanged:
- **`Guard.linked`**: "at least k / no objects that p links to satisfy …". The "none" form compiles to a negated conjunction.
- **`Case.each`**: effects on every object a parameter links to; used for the degree updates and for clearing the tried marks.
- **Binary preferences** (`Pref.than`, `Pref.versus`): `o > o2` with conditions comparing the two, e.g. lower degree. In the semantics, dominated candidates are removed (`Agent.prefCands`).
- **Set-valued attributes**: `multi` integer attributes; add and remove effects; `Cmp.lacks` (does not contain). `lacks` becomes a negated condition, nested inside negated conjunctions.

## Results (Soar 9.6.5, 20000 decisions, seeds 1–5)

| Agent | Closed tours found |
|---|---|
| knights V2 (6 × 6, level-5) | 361, 273, 274, 276, 361 |
| `knights-6` | 347, 434, 432, 432, 359 |
| knights V1 (8 × 8, level-3) | 0, 0, 0, 0, 0 |
| `knights-8` | 79, 0, 34, 56, 39 |

Checks on `knights-6`:
- Over 3,000 decisions, every counted tour was reconstructed from the `prev` links in Soar: 78 tours, all valid and all distinct.
- Time per decision is about 3× the original's: about 10 s per 20,000 decisions against 3 s.

Soar vs soar-lean (`leancmp/`), 300 decisions with `--first`, a window that includes 93 backups and 6 tours:
- `knights-6`: MATCH.
- `knights-8`: MATCH.

Theorems:
- `conventions`.
- `six_finds_valid_tours`: following the description's preferences, with ties broken by the first candidate, the 6 × 6 run finds closed tours within 400 operators (8), and each is a valid closed tour. Validity means the path from square 23 via `prev` covers all 36 squares once, by knight's moves, and the last square is a knight's move from 23.

Development notes (both fixed before these results):
- A single `blocked` mark per square lost the mark from an earlier square on the path, so the search found the same two tours every 11 decisions. The tried marks are now a set (A3).
- Counting only unused squares in the degree (not the first square) found no tours in 20,000 decisions (A4).

## Assumptions (open, for JL)

- **A1. Backtracking.** The task is counting closed tours by depth-first search with backtracking, within a move budget. Backtracking is the task's method, as in the originals' backup operator. It is not the recovery from a failure state that ELB-014 rules out.
- **A2. One strategy per agent.** Each agent is one run with one strategy (a variant). The originals chain strategies and runs per level in one agent; repeated runs are the harness's seeds.
- **A3. Tried marks and the path.**
  - A move tried and backed out of is recorded on the square tried, in a set of the visit numbers of the squares it was tried from. The originals use a `^moved` set of squares on the square tried from.
  - The marks from a square are cleared when the search backs up from it, as in the originals.
  - The path is the squares' `prev` links. Every `prev` starts at its own square, so that there is always a link to replace.
- **A4. Degrees and the board.**
  - A degree counts the unused squares a move away plus the first square, as in the originals. The first square is the final move's exit.
  - The board is computed. The originals' 6 × 6 board lists b52 twice for b44 (b56 is missing), and their 8 × 8 board maps `^82` to b62.
- **A5. Strategies.** The two strategies are V2 level-5 and V1 level-3, as listed above. Rules for flags neither original uses are left out: multiple-moves-degree-1 over the board, distance-2, final-move-degree-0 and degree-negative.
- **A6. Ending a run.** A run ends when the budget is spent (finish-run) or the search is exhausted. Both write the count and halt.
